import ConnectedOpposite180

set_option warningAsError true
namespace Minimal180.MarkMove
open Finset SimpleGraph Graffiti177 Rooted180 Converse180 Assembly180 Substitution Transversals PairRepair
open Classical
variable {V : Type*} [Fintype V] [DecidableEq V]

noncomputable def highPins (G : SimpleGraph V) (K : Finset V) : Finset V :=
  K.filter (fun x => 3≤G.degree x)

private theorem restore_terminal (G : SimpleGraph V) (a b v y : V) (S : Finset V) (t : Bool)
    (va : v≠a) (vb : v≠b) (old : TerminalColor G a b (S.erase v) t)
    (small : (G.neighborFinset v∩(({a,b}:Finset V)∪S.erase y)).card≤1) :
    TerminalColor G a b (S.erase y) t := by
  classical
  obtain ⟨e,ok,ea,eb⟩ := old
  let U := ({a,b}:Finset V)∪S.erase y
  let N := G.neighborFinset v∩U
  have mono : ∃ k : Bool,∀ i∈N,e i=k := by
    by_cases hit : N.Nonempty
    · obtain ⟨j,jm⟩ := hit
      exact ⟨e j,fun i im => congrArg e (card_le_one.mp small i im j jm)⟩
    · exact ⟨false,fun i im => (hit ⟨i,im⟩).elim⟩
  obtain ⟨k,tone⟩ := mono
  let f (i : V) := if i=v then !k else e i
  refine ⟨f,?_,by simp [f,va.symm,ea],by simp [f,vb.symm,eb]⟩
  have prior {i} (im : i∈U) (iv : i≠v) : i∈({a,b}:Finset V)∪S.erase v :=
    (mem_union.mp im).elim (mem_union_left _) fun m => mem_union_right _ (mem_erase.mpr ⟨iv,mem_of_mem_erase m⟩)
  intro i im j jm ed
  by_cases iv : i=v <;> by_cases jv : j=v
  · exact (ed.ne (iv.trans jv.symm)).elim
  · have h := tone j (mem_inter.mpr ⟨(G.mem_neighborFinset ..).mpr (iv ▸ ed),jm⟩)
    simp [f,iv,jv,h]
  · have h := tone i (mem_inter.mpr ⟨(G.mem_neighborFinset ..).mpr (jv ▸ ed.symm),im⟩)
    simp [f,iv,jv,h]
  · simpa [f,iv,jv] using ok i (prior im iv) j (prior jm jv) ed

/-- Independent pins of degree at most two can be ignored even for a
prescribed relative terminal color, provided the region admits a free deletion. -/
theorem drop_high_iff (G : SimpleGraph V) (a b : V) (K S : Finset V) (ki : Indep G K)
    (ak : a∈K) (ao : a∉S) (bo : b∉S) (free : ∃ z∈S,z∉K) (t : Bool) :
    DropColor G a b K S t ↔ DropColor G a b (highPins G K) S t := by
  classical
  constructor
  · rintro ⟨x,xm,xk,col⟩
    exact ⟨x,xm,fun h => xk (mem_filter.mp h).1,col⟩
  · rintro ⟨v,vm,vh,col⟩
    by_cases vk : v∈K
    swap
    · exact ⟨v,vm,vk,col⟩
    have low : G.degree v≤2 := by
      by_contra! big
      exact vh (mem_filter.mpr ⟨vk,big⟩)
    have va : v≠a := fun e => ao (e ▸ vm)
    have vb : v≠b := fun e => bo (e ▸ vm)
    let U (y : V) := ({a,b}:Finset V)∪S.erase y
    by_cases hits : ∃ y∈S,G.Adj v y
    · obtain ⟨y,ym,vy⟩ := hits
      have yk : y∉K := fun m => ki v vk y m vy.ne vy
      have yn : y∈G.neighborFinset v := (G.mem_neighborFinset ..).mpr vy
      have yo : y∉U y := by
        have ya : y≠a := fun e => ao (e ▸ ym)
        have yb : y≠b := fun e => bo (e ▸ ym)
        simp [U,ya,yb]
      have sub : G.neighborFinset v∩U y⊆(G.neighborFinset v).erase y := by
        intro i im
        exact mem_erase.mpr ⟨fun e => yo (e ▸ (mem_inter.mp im).2),(mem_inter.mp im).1⟩
      have count := card_erase_add_one yn
      rw [card_neighborFinset_eq_degree] at count
      exact ⟨y,ym,yk,restore_terminal G a b v y S t va vb col ((card_le_card sub).trans (by omega))⟩
    · obtain ⟨y,ym,yk⟩ := free
      have sub : G.neighborFinset v∩U y⊆{b} := by
        intro i im
        have vi := (G.mem_neighborFinset ..).mp (mem_inter.mp im).1
        rcases mem_union.mp (mem_inter.mp im).2 with tip|wing
        · rcases mem_insert.mp tip with e|m
          · exact (ki v vk a ak va (e ▸ vi)).elim
          · exact m
        · exact (hits ⟨i,mem_of_mem_erase wing,vi⟩).elim
      exact ⟨y,ym,yk,restore_terminal G a b v y S t va vb col (by simpa only [card_singleton] using card_le_card sub)⟩

/-- Sign-by-sign equivalence, also valid when the terminal mask is empty. -/
theorem mask_high_iff (G : SimpleGraph V) (a b : V) (ab : a≠b) (na : ¬G.Adj a b)
    (K S : Finset V) (ki : Indep G K) (ak : a∈K) (ao : a∉S) (bo : b∉S)
    (c : V→Bool) (cp : ProperOn G S c) (free : ∃ z∈S,z∉K) (t : Bool) :
    DropCheck G a b K S c t ↔ DropCheck G a b (highPins G K) S c t := by
  have rule (x : V) := terminal_iff_contacts G a b ab na (S.erase x) (fun m => ao (mem_of_mem_erase m))
    (fun m => bo (mem_of_mem_erase m)) c (fun i im j jm => cp i (mem_of_mem_erase im) j (mem_of_mem_erase jm)) t
  have bridge (J : Finset V) : DropCheck G a b J S c t ↔ DropColor G a b J S t :=
    ⟨fun ⟨i,im,ij,h⟩ => ⟨i,im,ij,(rule i).mpr h⟩,fun ⟨i,im,ij,h⟩ => ⟨i,im,ij,(rule i).mp h⟩⟩
  exact (bridge K).trans ((drop_high_iff G a b K S ki ak ao bo free t).trans (bridge _).symm)

#print axioms drop_high_iff
#print axioms mask_high_iff
end Minimal180.MarkMove
