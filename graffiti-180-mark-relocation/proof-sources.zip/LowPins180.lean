import LowMasks180
import Credit180

set_option warningAsError true
namespace Minimal180.MarkMove
open Finset SimpleGraph Graffiti177 Rooted180 Converse180 Assembly180 Substitution Transversals PairRepair
open Classical
variable {V : Type*} [Fintype V] [DecidableEq V]

private theorem restore_pin (G : SimpleGraph V) (K Z : Finset V) (ki : Indep G K) (bi : TwoColor G Z)
    (v : V) (vk : v∈K) (low : G.degree v≤2) :
    ∃ W,TwoColor G W ∧ K∩Z⊆W ∧ v∈W ∧ Z.card≤W.card := by
  classical
  by_cases vz : v∈Z
  · exact ⟨Z,bi,inter_subset_right,vz,le_rfl⟩
  obtain ⟨c,cp⟩ := (color_function ..).mp bi
  let N := G.neighborFinset v∩Z
  obtain ⟨i,cheap⟩ := cheap_side N c
  let F := N.filter (fun x => c x=i)
  have nc : N.card≤G.degree v := (card_le_card inter_subset_left).trans_eq (card_neighborFinset_eq_degree ..)
  have fs : F⊆Z := filter_subset .. |>.trans inter_subset_right
  have clear : Disjoint K F := by
    apply disjoint_left.mpr
    intro x xk xf
    have edge := (G.mem_neighborFinset ..).mp (mem_inter.mp (mem_filter.mp xf).1).1
    exact ki v vk x xk edge.ne edge
  let W := insert v (Z\F)
  have wm : v∈W := mem_insert_self ..
  have col : TwoColor G W := by
    apply add_mono G (Z\F) v (!i) c (fun x xm y ym => cp x (mem_sdiff.mp xm).1 y (mem_sdiff.mp ym).1)
    intro x xm ed
    have no : c x≠i := fun e => (mem_sdiff.mp xm).2 (mem_filter.mpr ⟨mem_inter.mpr
      ⟨(G.mem_neighborFinset ..).mpr ed,(mem_sdiff.mp xm).1⟩,e⟩)
    cases h : c x <;> cases i <;> simp_all
  have sub : K∩Z⊆W := fun x xm => mem_insert_of_mem (mem_sdiff.mpr
    ⟨(mem_inter.mp xm).2,disjoint_left.mp clear (mem_inter.mp xm).1⟩)
  have sum := card_sdiff_add_card_eq_card fs
  have size : W.card=(Z\F).card+1 := card_insert_of_not_mem (fun m => vz (mem_sdiff.mp m).1)
  change 2*F.card≤N.card at cheap
  exact ⟨W,col,sub,wm,by omega⟩

/-- Every independent pin of degree at most two can be restored without
lowering the size of the induced bipartite witness. -/
theorem restore_low_pins (G : SimpleGraph V) (K Z : Finset V) (ki : Indep G K) (bi : TwoColor G Z)
    (high : highPins G K⊆Z) : ∃ W,TwoColor G W ∧ K⊆W ∧ Z.card≤W.card := by
  classical
  suffices build : ∀ D : Finset V,D⊆K → ∃ W,TwoColor G W ∧ D⊆W ∧ K∩Z⊆W ∧ Z.card≤W.card by
    obtain ⟨W,col,sub,_,sz⟩ := build K Subset.rfl
    exact ⟨W,col,sub,sz⟩
  intro D
  induction D using Finset.induction_on with
  | empty => exact fun _ => ⟨Z,bi,empty_subset _,inter_subset_right,le_rfl⟩
  | @insert v D _ ih =>
    intro ds
    have vk := ds (mem_insert_self ..)
    obtain ⟨U,uc,du,keep,sz⟩ := ih ((subset_insert v D).trans ds)
    by_cases hit : v∈U
    · exact ⟨U,uc,insert_subset hit du,keep,sz⟩
    have low : G.degree v≤2 := by
      by_contra! hi
      exact hit (keep (mem_inter.mpr ⟨vk,high (mem_filter.mpr ⟨vk,hi⟩)⟩))
    obtain ⟨W,wc,ku,vw,uw⟩ := restore_pin G K U ki uc v vk low
    exact ⟨W,wc,insert_subset vw (fun x xm => ku (mem_inter.mpr ⟨ds (mem_insert_of_mem xm),du xm⟩)),
      fun x xm => ku (mem_inter.mpr ⟨(mem_inter.mp xm).1,keep xm⟩),sz.trans uw⟩

theorem protected_high_iff (G : SimpleGraph V) (gc : G.Connected) (hn : 1<Fintype.card V)
    (r : V) (p : Bool) (A : Finset V) (ai : Indep G A) :
    Protected G r p A ↔ ∃ Z,TwoColor G Z ∧ highPins G (A∩insert r (parity G r p))⊆Z ∧
      Fintype.card V-Z.card≤allowance G r p A := by
  rw [protected_iff G gc hn r p A ai]
  constructor
  · rintro ⟨Z,col,sub,sz⟩
    exact ⟨Z,col,(filter_subset ..).trans sub,sz⟩
  · rintro ⟨Z,col,sub,sz⟩
    obtain ⟨W,wc,keep,big⟩ := restore_low_pins G _ Z
      (fun x xm y ym => ai x (mem_inter.mp xm).1 y (mem_inter.mp ym).1) col sub
    exact ⟨W,wc,keep,by omega⟩

#print axioms restore_low_pins
#print axioms protected_high_iff
end Minimal180.MarkMove
