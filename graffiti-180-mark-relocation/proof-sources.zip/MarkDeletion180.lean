import ConnectedOpposite180

set_option warningAsError true
namespace Minimal180.MarkMove
open Finset SimpleGraph Graffiti177 Rooted180 Converse180 Assembly180 Substitution Transversals PairRepair
open Classical
variable {V : Type*} [Fintype V] [DecidableEq V]

theorem tree_score (G T : SimpleGraph V) (st : T≤G) (tr : T.IsTree) (U : Finset V) :
    (U∩leaves T).card≤weightedLeaves G U := by
  classical
  exact le_sup (f:=fun J => (U∩leaves J).card) (mem_filter.mpr ⟨mem_univ _,st,tr⟩)

theorem weight_inclusion (G : SimpleGraph V) (gc : G.Connected) {E F : Finset V} (sub : E⊆F) :
    weightedLeaves G E≤weightedLeaves G F := by
  obtain ⟨T,st,tr,opt⟩ := tree_opt G gc E
  exact opt ▸ (card_le_card (inter_subset_inter sub (Subset.rfl))).trans (tree_score G T st tr F)

omit [Fintype V] in
theorem erase_eligible {A P : Finset V} {v r : V} (nr : v≠r) :
    eligible (A.erase v) P r=if v∈P then eligible A P r else (eligible A P r).erase v := by
  ext x
  have rn := nr.symm
  by_cases vp : v∈P <;> by_cases xv : x=v
  all_goals simp_all only [if_true,if_false,eligible_iff,mem_erase]
  all_goals tauto

omit [Fintype V] in
private theorem score_change (E L : Finset V) (v : V) (vm : v∈E) :
    ((E.erase v)∩L).card+ (if v∈L then 1 else 0)=(E∩L).card := by
  have shape : E.erase v∩L=(E∩L).erase v := by ext;simp [and_assoc]
  rw [shape]
  by_cases vl : v∈L
  · simp [vl,card_erase_add_one (mem_inter.mpr ⟨vm,vl⟩)]
  · simp [vl,erase_eq_of_not_mem (show v∉E∩L by simp [vl])]

theorem unavoidable (G : SimpleGraph V) (gc : G.Connected) (E : Finset V) (v : V) (vm : v∈E) :
    (weightedLeaves G (E.erase v)+1=weightedLeaves G E ↔
      ∀ T≤G,T.IsTree → (E∩leaves T).card=weightedLeaves G E → v∈leaves T) ∧
    (weightedLeaves G (E.erase v)=weightedLeaves G E ∨
      weightedLeaves G (E.erase v)+1=weightedLeaves G E) := by
  classical
  have mono := weight_inclusion G gc (erase_subset v E)
  obtain ⟨H,sh,th,eh⟩ := tree_opt G gc E
  have bound := tree_score G H sh th (E.erase v)
  have h := score_change E (leaves H) v vm
  have gap : weightedLeaves G E≤weightedLeaves G (E.erase v)+1 := by split at h <;> omega
  refine ⟨⟨?_,?_⟩,by omega⟩
  · intro loss T st tr opt
    by_contra no
    have law := score_change E (leaves T) v vm
    rw [if_neg no] at law
    have := tree_score G T st tr (E.erase v)
    omega
  · intro all
    by_contra bad
    have same : weightedLeaves G (E.erase v)=weightedLeaves G E := by omega
    obtain ⟨T,st,tr,old⟩ := tree_opt G gc (E.erase v)
    have law := score_change E (leaves T) v vm
    have top := tree_score G T st tr E
    by_cases yes : v∈leaves T
    · rw [if_pos yes] at law;omega
    · rw [if_neg yes] at law
      exact yes (all T st tr (by omega))

theorem delete_mark (G : SimpleGraph V) (gc : G.Connected) (hn : 1<Fintype.card V)
    (r v : V) (p : Bool) (A : Finset V) (ai : Indep G A) (vm : v∈A) (nr : v≠r) :
    let P := parity G r p
    let E := eligible A P r
    let B := allowance G r p A
    let B' := allowance G r p (A.erase v)
    (v∈P → B'=B+1) ∧ (v∉P →
      (B'=B ↔ ∀ T≤G,T.IsTree → (E∩leaves T).card=weightedLeaves G E → v∈leaves T) ∧
      (B'=B ∨ B'=B+1)) := by
  dsimp only
  have ind : Indep G (A.erase v) := fun i im j jm => ai i (mem_of_mem_erase im) j (mem_of_mem_erase jm)
  have h := allowance_eq G gc hn r p A ai
  have k := allowance_eq G gc hn r p (A.erase v) ind
  dsimp only at h k
  rw [erase_eligible nr] at k
  have c := card_erase_add_one vm
  constructor
  · intro vp;rw [if_pos vp] at k;omega
  · intro vp
    rw [if_neg vp] at k
    have ⟨rule,range⟩ := unavoidable G gc (eligible A (parity G r p) r) v (eligible_iff.mpr ⟨Or.inl vm,Or.inl nr⟩)
    exact ⟨(show allowance G r p (A.erase v)=allowance G r p A ↔ _ by omega).trans rule,by omega⟩

#print axioms unavoidable
#print axioms delete_mark
end Minimal180.MarkMove
