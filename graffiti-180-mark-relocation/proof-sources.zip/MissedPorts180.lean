import ConnectedOpposite180

set_option warningAsError true
namespace Minimal180.MarkMove
open Finset SimpleGraph Graffiti177 Rooted180 Converse180 Assembly180 Substitution Transversals PairRepair OppositeGain
open Classical
variable {V : Type*} [Fintype V] [DecidableEq V]

/-- Endpoints outside the independent marking of selected-parity edges missed
by the center's entire open neighborhood. -/
noncomputable def missedEnds (G : SimpleGraph V) (a : V) (A P : Finset V) : Finset V :=
  (P\A).filter (fun x => ¬G.Adj a x ∧ ∃ y∈P,G.Adj x y ∧ ¬G.Adj a y)

/-- Distinct missed endpoints have disjoint sets of shortest predecessors.
Choosing one injects these endpoints into the off-parity nonroot marks. -/
theorem missed_count (G : SimpleGraph V) (gc : G.Connected) (hn : 1<Fintype.card V)
    (r a : V) (ar : a≠r) (p : Bool) (A : Finset V) (ai : Indep G A) (am : a∈A)
    (ap : a∈parity G r p) (sat : G.degree a=allowance G r p A+2) :
    (missedEnds G a A (parity G r p)).card≤(A\insert r (parity G r p)).card := by
  classical
  let P := parity G r p
  let S := missedEnds G a A P
  have specs {x} (xm : x∈S) : x∈P ∧ x∉A ∧ ¬G.Adj a x ∧ ∃ y∈P,G.Adj x y ∧ ¬G.Adj a y := by
    obtain ⟨m,h,y,yp,ed,ay⟩ := mem_filter.mp xm
    exact ⟨(mem_sdiff.mp m).1,(mem_sdiff.mp m).2,h,y,yp,ed,ay⟩
  have ex (x : ↥S) : ∃ z,z≠r ∧ z∈A ∧ z∉P ∧ G.Adj x.val z ∧ G.dist x.val r=G.dist z r+1 := by
    obtain ⟨xp,xm,ax,y,yp,xy,_⟩ := specs x.property
    obtain ⟨z,zr,za,zp,xz,d,_⟩ := missed_edge_parent G gc hn r a ar p A ai am ap sat xp yp xy xm ax
    exact ⟨z,zr,za,zp,xz,d⟩
  let f (x : ↥S) : ↥(A\insert r P) :=
    ⟨(ex x).choose,mem_sdiff.mpr ⟨(ex x).choose_spec.2.1,fun m => (mem_insert.mp m).elim
      (ex x).choose_spec.1 (ex x).choose_spec.2.2.1⟩⟩
  have inj : Function.Injective f := by
    intro x y eq
    have xy : (ex x).choose=(ex y).choose := congrArg Subtype.val eq
    obtain ⟨zr,za,zp,xz,dx⟩ := (ex x).choose_spec
    obtain ⟨_,_,_,yz,dy⟩ := (ex y).choose_spec
    rw [←xy] at yz dy
    exact Subtype.ext (unique_successor G gc hn r a _ x y ar zr (fun e => zp (e ▸ ap)) p A ai am za sat
      (specs x.property).2.1 (specs y.property).2.1 (specs x.property).2.2.1 (specs y.property).2.2.1 xz yz dx dy)
  simpa only [Fintype.card_coe] using Fintype.card_le_of_injective f inj

/-- A witness using the original distance parity on every retained vertex. -/
def ParityFits (G : SimpleGraph V) (r : V) (p : Bool) (A : Finset V) : Prop :=
  let P := parity G r p
  ∃ Z,ProperOn G Z (fun x => decide (x∈P)) ∧ A∩insert r P⊆Z ∧ Fintype.card V-Z.card≤allowance G r p A

theorem ParityFits.protected {G : SimpleGraph V} (gc : G.Connected) (hn : 1<Fintype.card V)
    {r : V} {p : Bool} {A : Finset V} (ai : Indep G A) (h : ParityFits G r p A) : Protected G r p A := by
  obtain ⟨Z,proper,keep,cost⟩ := h
  exact (protected_iff G gc hn r p A ai).mpr ⟨Z,(color_function ..).mpr ⟨_,proper⟩,keep,cost⟩

/-- A set of unpinned, selected-parity vertices outside the open neighborhood
meeting every selected-parity edge whose endpoints both miss that neighborhood. -/
def RemoteCover (G : SimpleGraph V) (a : V) (P K S : Finset V) : Prop :=
  S⊆P\G.neighborFinset a ∧ Disjoint S K ∧
    ∀ x∈P,∀ y∈P,G.Adj x y → ¬G.Adj a x → ¬G.Adj a y → x∈S ∨ y∈S

/-- A vertex cover of the remote horizontal edges can be paid for by additional retained ports. -/
theorem parity_from_cover (G : SimpleGraph V) (gc : G.Connected) (hn : 1<Fintype.card V)
    (r a : V) (ar : a≠r) (p : Bool) (A : Finset V) (ai : Indep G A) (am : a∈A)
    (ap : a∈parity G r p) (sat : G.degree a=allowance G r p A+2)
    (J : Finset V) (ji : Indep G J) (js : J⊆G.neighborFinset a\parity G r p)
    (S : Finset V) (sc : RemoteCover G a (parity G r p) (A∩insert r (parity G r p)) S)
    (large : S.card+2≤J.card) : ParityFits G r p A := by
  classical
  let P := parity G r p
  let M := (G.neighborFinset a\J)∪S
  let Z := univ\M
  have clear {x} (xm : x∈Z) : x∉S := fun s => (mem_sdiff.mp xm).2 (mem_union_right _ s)
  have inside {x} (xm : x∈Z) (ax : G.Adj a x) : x∈J := by
    by_contra no
    exact (mem_sdiff.mp xm).2 (mem_union_left _ (mem_sdiff.mpr ⟨(G.mem_neighborFinset ..).mpr ax,no⟩))
  have bip : ProperOn G Z (fun x => decide (x∈P)) := by
    intro x xm y ym ed eq
    have iff : x∈P ↔ y∈P := by simpa using eq
    by_cases xp : x∈P
    · have yp := iff.mp xp
      have ax : ¬G.Adj a x := fun h => (mem_sdiff.mp (js (inside xm h))).2 xp
      have ay : ¬G.Adj a y := fun h => (mem_sdiff.mp (js (inside ym h))).2 yp
      exact (sc.2.2 x xp y yp ed ax ay).elim (clear xm) (clear ym)
    · have yp := mt iff.mpr xp
      obtain ⟨ax,ay⟩ := opposite_edges_confined G gc hn r a ar p A ai am ap sat ed xp yp
      exact ji x (inside xm ax) y (inside ym ay) ed.ne ed
  refine ⟨Z,bip,?_,?_⟩
  · intro x xm
    have xa := (mem_inter.mp xm).1
    refine mem_sdiff.mpr ⟨mem_univ _,fun m => ?_⟩
    rcases mem_union.mp m with n|s
    · have e := (G.mem_neighborFinset ..).mp (mem_sdiff.mp n).1
      exact ai a am x xa e.ne e
    · exact disjoint_left.mp sc.2.1 s xm
  · have nsz := card_sdiff_add_card_eq_card (js.trans sdiff_subset)
    rw [card_neighborFinset_eq_degree] at nsz
    have tot := card_sdiff_add_card_eq_card (subset_univ M)
    change Z.card+M.card=Fintype.card V at tot
    have bound : M.card≤(G.neighborFinset a\J).card+S.card := card_union_le ..
    omega

/-- Retain an independent set of opposite-parity neighbors of the center.
Every one beyond the two mandatory ports pays for a missed endpoint. -/
theorem parity_certificate (G : SimpleGraph V) (gc : G.Connected) (hn : 1<Fintype.card V)
    (r a : V) (ar : a≠r) (p : Bool) (A : Finset V) (ai : Indep G A) (am : a∈A)
    (ap : a∈parity G r p) (sat : G.degree a=allowance G r p A+2)
    (J : Finset V) (ji : Indep G J) (js : J⊆G.neighborFinset a\parity G r p)
    (large : (missedEnds G a A (parity G r p)).card+2≤J.card) : ParityFits G r p A  := by
  classical
  apply parity_from_cover G gc hn r a ar p A ai am ap sat J ji js _ _ large
  constructor
  · intro x xm
    obtain ⟨m,ax,_⟩ := mem_filter.mp xm
    exact mem_sdiff.mpr ⟨(mem_sdiff.mp m).1,fun n => ax ((G.mem_neighborFinset ..).mp n)⟩
  constructor
  · exact disjoint_left.mpr fun x xm xk => (mem_sdiff.mp (mem_filter.mp xm).1).2 (mem_inter.mp xk).1
  · intro x xp y yp xy ax ay
    by_cases xa : x∈A
    · exact Or.inr (mem_filter.mpr ⟨mem_sdiff.mpr ⟨yp,fun ya => ai x xa y ya xy.ne xy⟩,ay,x,xp,xy.symm,ax⟩)
    · exact Or.inl (mem_filter.mpr ⟨mem_sdiff.mpr ⟨xp,xa⟩,ax,y,yp,xy,ay⟩)

theorem retained_ports_repair (G : SimpleGraph V) (gc : G.Connected) (hn : 1<Fintype.card V)
    (r a : V) (ar : a≠r) (p : Bool) (A : Finset V) (ai : Indep G A) (am : a∈A)
    (ap : a∈parity G r p) (sat : G.degree a=allowance G r p A+2)
    (J : Finset V) (ji : Indep G J) (js : J⊆G.neighborFinset a\parity G r p)
    (large : (missedEnds G a A (parity G r p)).card+2≤J.card) : Protected G r p A :=
  (parity_certificate G gc hn r a ar p A ai am ap sat J ji js large).protected gc hn ai

theorem off_parity_repair (G : SimpleGraph V) (gc : G.Connected) (hn : 1<Fintype.card V)
    (r a : V) (ar : a≠r) (p : Bool) (A : Finset V) (ai : Indep G A) (am : a∈A)
    (ap : a∈parity G r p) (sat : G.degree a=allowance G r p A+2)
    (J : Finset V) (ji : Indep G J) (js : J⊆G.neighborFinset a\parity G r p)
    (large : (A\insert r (parity G r p)).card+2≤J.card) : Protected G r p A :=
  retained_ports_repair G gc hn r a ar p A ai am ap sat J ji js
    (le_trans (Nat.add_le_add_right (missed_count G gc hn r a ar p A ai am ap sat) 2) large)

#print axioms missed_count
#print axioms parity_from_cover
#print axioms parity_certificate
#print axioms retained_ports_repair
#print axioms off_parity_repair
end Minimal180.MarkMove
