import MissedPorts180

set_option warningAsError true
namespace Minimal180.MarkMove
open Finset SimpleGraph Graffiti177 Rooted180 Converse180 Assembly180 Substitution Transversals PairRepair OppositeGain
open Classical
variable {V : Type*} [Fintype V] [DecidableEq V]

/-- Exact feasibility test for retaining the original parity colors at a
saturated center. It separates the cost inside and outside its open neighborhood. -/
theorem parity_cover_iff (G : SimpleGraph V) (gc : G.Connected) (hn : 1<Fintype.card V)
    (r a : V) (ar : a≠r) (p : Bool) (A : Finset V) (ai : Indep G A) (am : a∈A)
    (ap : a∈parity G r p) (sat : G.degree a=allowance G r p A+2) :
    let P := parity G r p
    let K := A∩insert r P
    ParityFits G r p A ↔ ∃ J S : Finset V,Indep G J ∧ J⊆G.neighborFinset a\P ∧
      RemoteCover G a P K S ∧ S.card+2≤J.card := by
  classical
  intro P K
  constructor
  swap
  · rintro ⟨J,S,ji,js,sc,pay⟩
    exact parity_from_cover G gc hn r a ar p A ai am ap sat J ji js S sc pay
  rintro ⟨Z,proper,keep,cost⟩
  let N := G.neighborFinset a
  let J := N∩Z
  let S := (P\N)\Z
  have az : a∈Z := keep (mem_inter.mpr ⟨am,mem_insert_of_mem ap⟩)
  have diff {x y} (xz : x∈Z) (yz : y∈Z) (ed : G.Adj x y) : ¬(x∈P ↔ y∈P) := by
    intro eq
    exact proper x xz y yz ed (by simpa only [decide_eq_decide] using eq)
  have js : J⊆N\P := by
    intro x xm
    obtain ⟨xn,xz⟩ := mem_inter.mp xm
    exact mem_sdiff.mpr ⟨xn,fun xp => diff az xz ((G.mem_neighborFinset ..).mp xn) (iff_of_true ap xp)⟩
  have ji : Indep G J := fun x xm y ym _ ed => diff (mem_inter.mp xm).2 (mem_inter.mp ym).2 ed
    (iff_of_false (mem_sdiff.mp (js xm)).2 (mem_sdiff.mp (js ym)).2)
  have sc : RemoteCover G a P K S := by
    refine ⟨sdiff_subset,disjoint_left.mpr (fun x xm xk => (mem_sdiff.mp xm).2 (keep xk)),?_⟩
    intro x xp y yp xy ax ay
    by_cases xz : x∈Z
    · exact Or.inr (mem_sdiff.mpr ⟨mem_sdiff.mpr ⟨yp,fun n => ay ((G.mem_neighborFinset ..).mp n)⟩,
        fun yz => diff xz yz xy (iff_of_true xp yp)⟩)
    · exact Or.inl (mem_sdiff.mpr ⟨mem_sdiff.mpr ⟨xp,fun n => ax ((G.mem_neighborFinset ..).mp n)⟩,xz⟩)
  have dis : Disjoint (N\J) S := disjoint_left.mpr fun x xm xs =>
    (mem_sdiff.mp (mem_sdiff.mp xs).1).2 (mem_sdiff.mp xm).1
  have sub : (N\J)∪S⊆univ\Z := by
    intro x xm
    refine mem_sdiff.mpr ⟨mem_univ _,?_⟩
    rcases mem_union.mp xm with m|s
    · exact fun xz => (mem_sdiff.mp m).2 (mem_inter.mpr ⟨(mem_sdiff.mp m).1,xz⟩)
    · exact (mem_sdiff.mp s).2
  have total := card_le_card sub
  rw [card_union_of_disjoint dis] at total
  have rem := card_sdiff_add_card_eq_card (subset_univ Z)
  rw [card_univ] at rem
  have count := card_sdiff_add_card_eq_card (show J⊆N from inter_subset_left)
  change (N\J).card+J.card=(G.neighborFinset a).card at count
  rw [card_neighborFinset_eq_degree] at count
  exact ⟨J,S,ji,js,sc,by omega⟩

/-- When there is at most one missed unmarked endpoint, a single remote
edge is sufficient to make the third independent opposite-parity port necessary. -/
theorem single_end_iff (G : SimpleGraph V) (gc : G.Connected) (hn : 1<Fintype.card V)
    (r a : V) (ar : a≠r) (p : Bool) (A : Finset V) (ai : Indep G A) (am : a∈A)
    (ap : a∈parity G r p) (sat : G.degree a=allowance G r p A+2)
    (small : (missedEnds G a A (parity G r p)).card≤1) :
    ParityFits G r p A ↔ ∃ J : Finset V,Indep G J ∧ J⊆G.neighborFinset a\parity G r p ∧
      (missedEnds G a A (parity G r p)).card+2≤J.card := by
  classical
  constructor
  · intro fits
    obtain ⟨J,S,ji,js,cover,pay⟩ := (parity_cover_iff G gc hn r a ar p A ai am ap sat).mp fits
    refine ⟨J,ji,js,?_⟩
    by_cases live : (missedEnds G a A (parity G r p)).Nonempty
    · obtain ⟨x,xm⟩ := live
      obtain ⟨m,ax,y,yp,ed,ay⟩ := mem_filter.mp xm
      have hit := cover.2.2 x (mem_sdiff.mp m).1 y yp ed ax ay
      have pos : 0<S.card := card_pos.mpr (hit.elim (fun h => ⟨x,h⟩) (fun h => ⟨y,h⟩))
      omega
    · have zero := Finset.not_nonempty_iff_eq_empty.mp live
      rw [zero,card_empty];omega
  · rintro ⟨J,ji,js,pay⟩
    exact parity_certificate G gc hn r a ar p A ai am ap sat J ji js pay

#print axioms parity_cover_iff
#print axioms single_end_iff
end Minimal180.MarkMove
