import PoolRepair180

set_option warningAsError true
set_option compiler.extract_closed false
set_option maxHeartbeats 3000000
set_option maxRecDepth 20000
namespace Minimal180.MarkMove.Pendant
open Finset SimpleGraph Graffiti177 Graffiti318 Rooted180 Converse180 Assembly180 Substitution Transversals PairRepair
abbrev V := Fin 11
noncomputable def edges : List (V×V) := [(0,8),(0,4),(0,5),(0,6),(1,5),(1,7),(2,6),(2,7),(3,8),(3,7),(4,8),(5,6),(7,8),(6,9),(9,10)]
noncomputable def G : SimpleGraph V where
  Adj x y := x≠y ∧ ((x,y)∈edges ∨ (y,x)∈edges)
  symm _ _ h := ⟨h.1.symm,h.2.symm⟩
  loopless _ h := h.1 rfl
noncomputable instance : DecidableRel G.Adj := fun x y => inferInstanceAs (Decidable (x≠y ∧ ((x,y)∈edges ∨ (y,x)∈edges)))
noncomputable abbrev A : Finset V := {0,1,2,3,9}
noncomputable abbrev K : Finset V := {0,1,2,3}
noncomputable abbrev P : Finset V := {0,1,2,3,6,8,10}
noncomputable abbrev E : Finset V := {0,1,2,3,6,8,9,10}
noncomputable def d (x : V) := ([2,0,2,2,3,1,2,1,2,3,4]:List ℕ)[x.val]!

theorem data : G.Connected ∧ parity G 1 false=P ∧ Indep G A ∧ eligible A P 1=E ∧ A∩insert 1 P=K := by
  obtain ⟨gc,dist⟩ : G.Connected ∧ ∀ x,G.dist x 1=d x := by
    apply layers
    · exact (by decide : d 1=0)
    · intro x y
      exact (show ∀ i j : V,G.Adj i j → d i≤d j+1 by decide) x y
    · exact (show ∀ x : V,x≠1 → ∃ y,G.Adj x y ∧ d x=d y+1 by decide)
  exact ⟨gc,by ext x;simp only [mem_parity,dist];exact (show ∀ v : V,d v%2=false.toNat ↔ v∈P by decide) x,
    by unfold Indep;decide,by decide,by decide⟩

noncomputable abbrev possible : Finset V := {0,1,2,3,8,10}
noncomputable def paintCut (q x : V) := decide (x∈(([
    {7},{4},{4},{4},∅,∅,∅,∅,{4,7,8},∅,{4}]:List (Finset V))[q.val]!))

private theorem five_check (L : Finset V) (inc : L⊆possible) (five : L.card=5) : ¬Con G (univ\L) := by
  have count := card_sdiff_add_card_eq_card inc
  rw [five,show possible.card=6 by decide] at count
  obtain ⟨q,one⟩ := card_eq_one.mp (show (possible\L).card=1 by omega)
  have qp := (mem_sdiff.mp (show q∈possible\L from one ▸ mem_singleton_self _)).1
  have eq : L=possible.erase q := by
    ext x
    have rel := Finset.ext_iff.mp one x
    simp only [mem_sdiff,mem_singleton] at rel
    simp only [mem_erase]
    exact ⟨fun m => ⟨fun e => (rel.mpr e).2 m,inc m⟩,fun ⟨ne,m⟩ => Classical.byContradiction (fun no => ne (rel.mp ⟨m,no⟩))⟩
  obtain ⟨edges,non⟩ := (show ∀ q∈possible,OnEdges G (univ\possible.erase q) (paintCut q) ∧
    ¬ConstantOn (univ\possible.erase q) (paintCut q) by unfold OnEdges ConstantOn;decide) q qp
  rw [eq]
  exact fun c => non (((connected_cuts G _).mp c).2 _ edges)

theorem equal_scores : weightedLeaves G E=4 ∧ weightedLeaves G P=4 := by
  let J : Finset V := {9,8,5,0,6}
  have jc : Con G J := by
    have h₁ := con_insert G (con_single G (6:V)) (mem_singleton_self _) (by decide : G.Adj 0 6)
    have h₂ := con_insert G h₁ (show (6:V)∈({0,6}:Finset V) by decide) (by decide : G.Adj 5 6)
    have h₃ := con_insert G h₂ (show (0:V)∈({5,0,6}:Finset V) by decide) (by decide : G.Adj 8 0)
    exact con_insert G h₃ (show (6:V)∈({8,5,0,6}:Finset V) by decide) (by decide : G.Adj 9 6)
  have low := weightedCore G J P jc (by dsimp [J,Dominates];decide)
  rw [show (P\J).card=4 by decide] at low
  have mono := weight_inclusion G data.1 (show P⊆E by decide)
  suffices cap : weightedLeaves G E≤4 by omega
  by_contra! big
  obtain ⟨T,st,tr,opt⟩ := tree_opt G data.1 E
  obtain ⟨L,sub,five⟩ := exists_subset_card_eq (show 5≤(E∩leaves T).card by omega)
  have never (v : V) (vm : v∈({6,9}:Finset V)) : v∉leaves T := by
    intro leaf
    have one := (leaf_core G T st tr (by decide) {v} (singleton_subset_iff.mpr leaf)).1
    let c (x : V) := decide (x∈({9,10}:Finset V))
    obtain ⟨agree,non⟩ := (show ∀ i∈({6,9}:Finset V),OnEdges G (univ\{i}) c ∧ ¬ConstantOn (univ\{i}) c by
      unfold OnEdges ConstantOn;decide) v vm
    exact non (((connected_cuts G _).mp one).2 _ agree)
  have shape : E\({6,9}:Finset V)=possible := by decide
  have inc : L⊆possible := fun x xm => shape ▸ mem_sdiff.mpr
    ⟨(mem_inter.mp (sub xm)).1,fun m => never x m (mem_inter.mp (sub xm)).2⟩
  exact five_check L inc five (leaf_core G T st tr (by decide) L (sub.trans inter_subset_right)).1

theorem budgets : allowance G 1 false A=2 ∧ allowance G 1 false (A.erase 9)=3 ∧
    allowance G 1 false (insert 10 (A.erase 9))=2 := by
  obtain ⟨gc,par,ai,el,_⟩ := data
  have h := allowance_eq G gc (by decide) 1 false A ai
  have k := allowance_eq G gc (by decide) 1 false (A.erase 9) (by unfold Indep;decide)
  dsimp only at h k
  rw [par,el,equal_scores.1,show A.card=5 by decide,show P.card=7 by decide,show Fintype.card V=11 by decide] at h
  rw [par,show eligible (A.erase 9) P 1=P by decide,equal_scores.2,show (A.erase 9).card=4 by decide,
    show P.card=7 by decide,show Fintype.card V=11 by decide] at k
  have dg : G.degree 0=4 := (card_neighborFinset_eq_degree G 0).symm.trans (by decide)
  have same (F H : Fintype (G.neighborSet 0)) : @SimpleGraph.degree V G 0 F=@SimpleGraph.degree V G 0 H := by
    rw [Subsingleton.elim F H]
  have any (F : Fintype (G.neighborSet 0)) : @SimpleGraph.degree V G 0 F=4 := (same F _).trans dg
  have move := relocate G gc (by decide) 1 0 9 10 false A ai (by decide) (by rw [par];decide)
    ((any _).trans (by omega)) (by decide) (by decide) (by decide) (by rw [par];decide) (by decide)
  exact ⟨by omega,by omega,by omega⟩

/-- The sole off-parity mark is an internal degree-two vertex. Removing it
raises the tight allowance, and relocation to its successor preserves it. -/
theorem mixed_regression : A\insert 1 (parity G 1 false)={9} ∧ G.degree 9=2 ∧
    allowance G 1 false A=2 ∧ allowance G 1 false (A.erase 9)=3 ∧
    allowance G 1 false (insert 10 (A.erase 9))=2 ∧ Protected G 1 false A := by
  obtain ⟨gc,par,ai,_,key⟩ := data
  have bi : TwoColor G (univ\({0,7}:Finset V)) := by
    let c (x : V) := decide (x∈({2,5,8,9}:Finset V))
    exact (color_function ..).mpr ⟨c,by unfold ProperOn;decide⟩
  refine ⟨by rw [par];decide,(card_neighborFinset_eq_degree G 9).symm.trans (by decide),
    budgets.1,budgets.2.1,budgets.2.2,?_⟩
  apply pool_repair G gc (by decide) 1 0 7 (by decide) false A ai (by decide) bi (by rw [par];decide)
    (by rw [par];decide) K {10}
  · rw [par,key]
  · rw [par,key];exact filter_subset ..
  · rw [par]
    intro x xm
    obtain rfl := mem_singleton.mp xm
    simp only [pool,mem_filter]
    exact ⟨by decide,by decide,by decide,by decide,by decide⟩
  · unfold Indep;decide
  · decide

noncomputable abbrev C : Finset V := {10,9,2,6,5,1}
noncomputable abbrev D : Finset V := {3,4,8}
noncomputable def paint (x : V) := decide (x∈({2,5,8,9}:Finset V))

theorem active_regions : TwoRegions G 0 7 C D ∅ ∧ Con G C ∧ Con G D ∧
    ProperOn G (univ\({0,7}:Finset V)) paint ∧ MixedAt G 0 C paint ∧ MixedAt G 0 D paint ∧
    ∃ t,DropCheck G 0 7 K C paint t ∧ DropCheck G 0 7 K D paint t := by
  have parts : TwoRegions G 0 7 C D ∅ := ⟨by decide,by decide,by decide,by decide,by decide,by decide⟩
  have cc : Con G C := by
    have h₁ := con_insert G (con_single G (1:V)) (mem_singleton_self _) (by decide : G.Adj 5 1)
    have h₂ := con_insert G h₁ (show (5:V)∈({5,1}:Finset V) by decide) (by decide : G.Adj 6 5)
    have h₃ := con_insert G h₂ (show (6:V)∈({6,5,1}:Finset V) by decide) (by decide : G.Adj 2 6)
    have h₄ := con_insert G h₃ (show (6:V)∈({2,6,5,1}:Finset V) by decide) (by decide : G.Adj 9 6)
    exact con_insert G h₄ (show (9:V)∈({9,2,6,5,1}:Finset V) by decide) (by decide : G.Adj 10 9)
  have dc : Con G D := by
    have h₁ := con_insert G (con_single G (8:V)) (mem_singleton_self _) (by decide : G.Adj 4 8)
    exact con_insert G h₁ (show (8:V)∈({4,8}:Finset V) by decide) (by decide : G.Adj 3 8)
  have cp : ProperOn G (univ\({0,7}:Finset V)) paint := by unfold ProperOn;decide
  have lc : MixedAt G 0 C paint := ⟨5,6,by decide,by decide,by decide,by decide,
    joined_step G C (joined_self G C (by decide : (5:V)∈C)) (by decide) (by decide)⟩
  have rc : MixedAt G 0 D paint := ⟨8,4,by decide,by decide,by decide,by decide,
    joined_step G D (joined_self G D (by decide : (8:V)∈D)) (by decide) (by decide)⟩
  have dg : G.degree 0=4 := (card_neighborFinset_eq_degree G 0).symm.trans (by decide)
  have same (F H : Fintype (G.neighborSet 0)) : @SimpleGraph.degree V G 0 F=@SimpleGraph.degree V G 0 H := by
    rw [Subsingleton.elim F H]
  have any (F : Fintype (G.neighborSet 0)) : @SimpleGraph.degree V G 0 F=4 := (same F _).trans dg
  refine ⟨parts,cc,dc,cp,lc,rc,?_⟩
  have h := (active_contacts_iff G data.1 (by decide) 1 false A data.2.2.1 0 7 (by decide) (by decide)
    ((color_function ..).mpr ⟨paint,cp⟩) (by decide) (by rw [data.2.1];decide) (any _) budgets.1 C D ∅ parts paint cp lc rc).mp
    mixed_regression.2.2.2.2.2
  simpa only [data.2.1,data.2.2.2.2] using h

private noncomputable def level (i j : V) : ℕ := (([[0,0,2,2,2,1,3,1,2,2,2],[0,0,2,2,1,1,1,2,1,2,2],[2,2,0,4,3,2,3,3,3,4,4],[2,2,4,0,3,2,3,3,3,4,4],[2,1,3,3,0,2,3,2,3,3,3],[1,1,2,2,2,0,2,2,2,2,2],[3,1,3,3,3,2,0,2,3,3,3],[1,2,3,3,2,2,2,0,2,3,3],[2,1,3,3,3,2,3,2,0,3,3],[2,2,4,4,3,2,3,3,3,0,4],[2,2,4,4,3,2,3,3,3,4,0]] : List (List ℕ))[i.val]!)[j.val]!

theorem prime : Substitution.Prime G := by
  intro M hom big
  have force {u v w : V} (um : u∈M) (vm : v∈M) (diff : ¬(G.Adj w u ↔ G.Adj w v)) : w∈M := by
    by_contra miss
    exact diff (hom w miss u um v vm)
  have start (m0 : (0:V)∈M) (m1 : (1:V)∈M) : M=univ := by
    have m4 : (4:V)∈M := force m0 m1 (by decide)
    have m5 : (5:V)∈M := force m0 m4 (by decide)
    have m6 : (6:V)∈M := force m0 m1 (by decide)
    have m2 : (2:V)∈M := force m6 m0 (by decide)
    have m7 : (7:V)∈M := force m1 m0 (by decide)
    have m3 : (3:V)∈M := force m7 m0 (by decide)
    have m8 : (8:V)∈M := force m0 m1 (by decide)
    have m9 : (9:V)∈M := force m6 m0 (by decide)
    have m10 : (10:V)∈M := force m9 m0 (by decide)
    apply eq_univ_of_forall
    intro v
    fin_cases v <;> assumption
  have claim (k : ℕ) : ∀ i j : V,i∈M → j∈M → i≠j → level i j=k → M=univ := by
    induction k using Nat.strong_induction_on with
    | h k lower =>
      intro i j im jm ne eq
      by_cases zero : level i j=0
      · rcases (show ∀ u v : V,u≠v → level u v=0 → (u=0 ∧ v=1) ∨ (u=1 ∧ v=0) by decide) i j ne zero with h|h
        · exact start (h.1 ▸ im) (h.2 ▸ jm)
        · exact start (h.2 ▸ jm) (h.1 ▸ im)
      · have step : ∀ u v : V,u≠v → level u v≠0 → ∃ w : V,¬(G.Adj w u ↔ G.Adj w v) ∧
            ((w≠u ∧ level w u<level u v) ∨ (w≠v ∧ level w v<level u v)) := by decide
        obtain ⟨w,diff,alt⟩ := step i j ne zero
        have wm := force im jm diff
        rcases alt with ⟨wi,low⟩|⟨wj,low⟩
        · exact lower _ (low.trans_eq eq) w i wm im wi rfl
        · exact lower _ (low.trans_eq eq) w j wm jm wj rfl
  obtain ⟨i,im,j,jm,ne⟩ := one_lt_card.mp big
  exact claim _ i j im jm ne rfl

/-- These are the only two tight independent markings at this root and
parity that retain the center, allowing arbitrary relocation. -/
theorem only_tight (X : Finset V) (xi : Indep G X) (center : (0:V)∈X) :
    allowance G 1 false X=2 ↔ X=A ∨ X=insert 10 (A.erase 9) := by
  constructor
  swap
  · rintro (rfl|rfl)
    · exact budgets.1
    · exact budgets.2.2
  intro two
  let J : Finset V := {9,7,6,0,1,5}
  have jc : Con G J := by
    have h₁ := con_insert G (con_single G (5:V)) (mem_singleton_self _) (by decide : G.Adj 1 5)
    have h₂ := con_insert G h₁ (show (5:V)∈({1,5}:Finset V) by decide) (by decide : G.Adj 0 5)
    have h₃ := con_insert G h₂ (show (5:V)∈({0,1,5}:Finset V) by decide) (by decide : G.Adj 6 5)
    have h₄ := con_insert G h₃ (show (1:V)∈({6,0,1,5}:Finset V) by decide) (by decide : G.Adj 7 1)
    exact con_insert G h₄ (show (6:V)∈({7,6,0,1,5}:Finset V) by decide) (by decide : G.Adj 9 6)
  have low := weightedCore G J (eligible X P 1) jc (by dsimp [J,Dominates];decide)
  have sub : (P.erase 1)\J⊆(eligible X P 1)\J := fun x m => mem_sdiff.mpr
    ⟨eligible_iff.mpr ⟨Or.inr (mem_of_mem_erase (mem_sdiff.mp m).1),Or.inl (mem_erase.mp (mem_sdiff.mp m).1).1⟩,(mem_sdiff.mp m).2⟩
  have four := (card_le_card sub).trans low
  rw [show ((P.erase 1)\J).card=4 by decide] at four
  have eq := allowance_eq G data.1 (by decide) 1 false X xi
  dsimp only at eq
  rw [data.2.1,two,show P.card=7 by decide,show Fintype.card V=11 by decide] at eq
  have big : 5≤X.card := by omega
  have apart (v w : V) (vm : v∈X) (wm : w∈X) : ¬G.Adj v w := fun ed => xi v vm w wm ed.ne ed
  have bfree : (7:V)∉X := by
    intro bm
    have cap : X⊆({0,7,9,10}:Finset V) := fun v vm => (show ∀ i : V,¬G.Adj 0 i → ¬G.Adj 7 i →
      i∈({0,7,9,10}:Finset V) by decide) v (apart 0 v center vm) (apart 7 v bm vm)
    have h := card_le_card cap
    rw [show ({0,7,9,10}:Finset V).card=4 by decide] at h
    omega
  by_cases nine : (9:V)∈X
  · have cap : X⊆A := fun v vm => (show ∀ i : V,¬G.Adj 0 i → ¬G.Adj 9 i → i≠7 → i∈A by decide)
      v (apart 0 v center vm) (apart 9 v nine vm) (fun e => bfree (e ▸ vm))
    exact Or.inl (eq_of_subset_of_card_le cap (by simpa only [show A.card=5 by decide] using big))
  · have cap : X⊆insert 10 (A.erase 9) := fun v vm => (show ∀ i : V,¬G.Adj 0 i → i≠9 → i≠7 →
      i∈insert 10 (A.erase 9) by decide) v (apart 0 v center vm) (fun e => nine (e ▸ vm)) (fun e => bfree (e ▸ vm))
    exact Or.inr (eq_of_subset_of_card_le cap (by simpa only [show (insert 10 (A.erase 9)).card=5 by decide] using big))

theorem root_and_cut : (∀ v,¬DomEdge G 1 v) ∧ ¬Con G (univ\{9}) := by
  constructor
  · unfold DomEdge;decide
  · let c (x : V) := decide (x=10)
    have ok : OnEdges G (univ\{9}) c := by unfold OnEdges;decide
    have nc : ¬ConstantOn (univ\{9}) c := by unfold ConstantOn;decide
    exact fun c₀ => nc (((connected_cuts G _).mp c₀).2 c ok)

theorem ordinary : 1+independence G+maxEven G≤maxLeaves G+bipartiteNum G := by
  have bi := (color_function G (univ\({0,7}:Finset V))).mpr ⟨paint,active_regions.2.2.2.1⟩
  have lower := size_bip G bi
  rw [show (univ\({0,7}:Finset V)).card=9 by decide] at lower
  have rk : Fintype.card V≤bipartiteNum G+2 := by rw [show Fintype.card V=11 by decide];omega
  exact ordinary_of_rooted G data.1 (RootEar.family_of_rank G data.1 (by decide) rk).rooted

#print axioms root_and_cut
#print axioms ordinary
#print axioms only_tight
#print axioms prime
#print axioms active_regions
#print axioms equal_scores
#print axioms budgets
#print axioms mixed_regression
end Minimal180.MarkMove.Pendant
