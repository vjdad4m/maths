import SaturatedMoves180
import LowPins180

set_option warningAsError true
namespace Minimal180.MarkMove
open Finset SimpleGraph Graffiti177 Rooted180 Converse180 Assembly180 Substitution Transversals PairRepair OppositeGain
open Classical
variable {V : Type*} [Fintype V] [DecidableEq V]

/-- Vertices available for new marks at the original root and parity after keeping J. -/
noncomputable def pool (G : SimpleGraph V) (r b : V) (P J : Finset V) : Finset V :=
  P.filter (fun y => y≠r ∧ y≠b ∧ y∉J ∧ ∀ z∈J,¬G.Adj y z)

theorem pool_repair (G : SimpleGraph V) (gc : G.Connected) (hn : 1<Fintype.card V)
    (r a b : V) (ar : a≠r) (p : Bool) (A : Finset V) (ai : Indep G A) (ab : a≠b)
    (bi : TwoColor G (univ\{a,b})) (ak : a∈A∩insert r (parity G r p)) (bk : b∉A∩insert r (parity G r p))
    (J Y : Finset V) (base : J⊆A∩insert r (parity G r p))
    (high : highPins G (A∩insert r (parity G r p))⊆J)
    (ys : Y⊆pool G r b (parity G r p) J) (yi : Indep G Y) (size : A.card≤J.card+Y.card) :
    Protected G r p A := by
  classical
  by_contra bad
  obtain ⟨dg,two,_⟩ := solo_rigidity G gc hn r p A ai bad a b ab bi ak bk
  have large : 2<Fintype.card V := by have := G.degree_lt_card_verts a;omega
  let P := parity G r p
  let K := A∩insert r P
  let X := J∪Y
  have aj : a∈J := high (mem_filter.mpr ⟨ak,by omega⟩)
  have ys' (y : V) (ym : y∈Y) : y∈P ∧ y≠r ∧ y≠b ∧ y∉J ∧ ∀ z∈J,¬G.Adj y z := mem_filter.mp (ys ym)
  have dis : Disjoint J Y := disjoint_left.mpr (fun y yj ym => (ys' y ym).2.2.2.1 yj)
  have ja : J⊆A := base.trans inter_subset_left
  have xi : Indep G X := by
    intro i im j jm ne ed
    rcases mem_union.mp im with ii|ii <;> rcases mem_union.mp jm with jj|jj
    · exact ai i (ja ii) j (ja jj) ne ed
    · exact (ys' j jj).2.2.2.2 i ii ed.symm
    · exact (ys' i ii).2.2.2.2 j jj ed
    · exact yi i ii j jj ne ed
  have scope : X⊆insert r P := by
    intro v vm
    exact (mem_union.mp vm).elim (fun j => (mem_inter.mp (base j)).2) (fun y => mem_insert_of_mem (ys' v y).1)
  have xa : a∈X∩insert r P := mem_inter.mpr ⟨mem_union_left _ aj,(mem_inter.mp ak).2⟩
  have xb : b∉X∩insert r P := by
    intro hit
    rcases mem_union.mp (mem_inter.mp hit).1 with j|y
    · exact bk (base j)
    · exact (ys' b y).2.2.1 rfl
  have sub : eligible X P r⊆eligible A P r := by
    intro v vm
    obtain ⟨mark,root⟩ := eligible_iff.mp vm
    apply eligible_iff.mpr
    constructor
    · exact mark.elim (fun x => (mem_union.mp x).elim (fun j => Or.inl (ja j)) (fun y => Or.inr (ys' v y).1)) Or.inr
    · exact root.imp_right fun ⟨rx,rp⟩ => ⟨ja ((mem_union.mp rx).resolve_right (fun y => (ys' r y).2.1 rfl)),rp⟩
  have big : A.card≤X.card := by simpa only [X,card_union_of_disjoint dis] using size
  have sat : G.degree a=allowance G r p A+2 := by omega
  have same := ((saturation_move G gc large r a p A X ai xi xa sat sub).2 big).2.1
  have done := solo_scope G gc hn r a b ar p X xi ab bi xa xb (Or.inl scope)
  obtain ⟨W,wc,keep,cost⟩ := (protected_iff G gc hn r p X xi).mp done
  apply bad
  apply (protected_high_iff G gc hn r p A ai).mpr
  refine ⟨W,wc,fun v vh => keep (mem_inter.mpr ⟨mem_union_left _ (high vh),(mem_inter.mp (base (high vh))).2⟩),?_⟩
  rwa [same] at cost

/-- Failure forces both independent sides of the available bipartite region
to be too small. The estimate applies to every admissible choice of retained pins. -/
theorem failed_pool_bound (G : SimpleGraph V) (gc : G.Connected) (hn : 1<Fintype.card V)
    (r a b : V) (ar : a≠r) (p : Bool) (A : Finset V) (ai : Indep G A) (ab : a≠b)
    (bi : TwoColor G (univ\{a,b})) (ak : a∈A∩insert r (parity G r p)) (bk : b∉A∩insert r (parity G r p))
    (bad : ¬Protected G r p A) (J : Finset V) (base : J⊆A∩insert r (parity G r p))
    (high : highPins G (A∩insert r (parity G r p))⊆J) :
    (pool G r b (parity G r p) J).card+2+2*J.card≤2*A.card := by
  classical
  let S := pool G r b (parity G r p) J
  obtain ⟨dg,_,_⟩ := solo_rigidity G gc hn r p A ai bad a b ab bi ak bk
  have aj : a∈J := high (mem_filter.mpr ⟨ak,by omega⟩)
  have sr : S⊆univ\{a,b} := by
    intro v vm
    obtain ⟨_,_,vb,vj,_⟩ := mem_filter.mp vm
    exact mem_sdiff.mpr ⟨mem_univ _,fun m => (mem_insert.mp m).elim (fun e => vj (e ▸ aj)) (fun e => vb (mem_singleton.mp e))⟩
  obtain ⟨c,cp⟩ := (color_function ..).mp bi
  obtain ⟨L,R,dis,eq,li,ri⟩ := (color_function G S).mpr ⟨c,fun x xm y ym => cp x (sr xm) y (sr ym)⟩
  have lim (Y : Finset V) (ys : Y⊆S) (yi : Indep G Y) : J.card+Y.card<A.card :=
    Nat.lt_of_not_ge (fun big => bad (pool_repair G gc hn r a b ar p A ai ab bi ak bk J Y base high ys yi big))
  have l := lim L (eq ▸ subset_union_left) li
  have u := lim R (eq ▸ subset_union_right) ri
  have total : L.card+R.card=S.card := (card_union_of_disjoint dis).symm.trans (congrArg card eq)
  change S.card+2+2*J.card≤2*A.card
  omega

#print axioms pool_repair
#print axioms failed_pool_bound
end Minimal180.MarkMove
