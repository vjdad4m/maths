import MarkDeletion180

set_option warningAsError true
namespace Minimal180.MarkMove
open Finset SimpleGraph Graffiti177 Rooted180 Converse180 Assembly180 Substitution Transversals
open Classical
variable {V : Type*} [Fintype V] [DecidableEq V]

/-- At a saturated protected center, an independent replacement whose eligible
set shrinks cannot increase cardinality. Equality preserves both optima. -/
theorem saturation_move (G : SimpleGraph V) (gc : G.Connected) (hn : 2<Fintype.card V)
    (r a : V) (p : Bool) (A X : Finset V) (ai : Indep G A) (xi : Indep G X)
    (keep : a∈X∩insert r (parity G r p)) (sat : G.degree a=allowance G r p A+2)
    (sub : eligible X (parity G r p) r⊆eligible A (parity G r p) r) :
    X.card≤A.card ∧ (A.card≤X.card →
      X.card=A.card ∧ allowance G r p X=allowance G r p A ∧
      weightedLeaves G (eligible X (parity G r p) r)=weightedLeaves G (eligible A (parity G r p) r)) := by
  have ha := allowance_eq G gc (by omega) r p A ai
  have hx := allowance_eq G gc (by omega) r p X xi
  dsimp only at ha hx
  have pay := protected_degree G gc hn r a p X xi keep
  have mono := weight_inclusion G gc sub
  exact ⟨by omega,fun _ => ⟨by omega,by omega,by omega⟩⟩

theorem relocate (G : SimpleGraph V) (gc : G.Connected) (hn : 2<Fintype.card V)
    (r a v y : V) (p : Bool) (A : Finset V) (ai : Indep G A) (av : a≠v)
    (ak : a∈A∩insert r (parity G r p)) (sat : G.degree a=allowance G r p A+2)
    (vm : v∈A) (free : y∉A) (yr : y≠r) (yp : y∈parity G r p)
    (clear : ∀ z∈A.erase v,¬G.Adj y z) :
    allowance G r p (insert y (A.erase v))=allowance G r p A := by
  let X := insert y (A.erase v)
  have xi : Indep G X := by
    intro i im j jm ne ed
    rcases mem_insert.mp im with e|ii <;> rcases mem_insert.mp jm with f|jj
    · exact ne (e.trans f.symm)
    · exact clear j jj (e ▸ ed)
    · exact clear i ii (f ▸ ed.symm)
    · exact ai i (mem_of_mem_erase ii) j (mem_of_mem_erase jj) ne ed
  have xa : a∈X∩insert r (parity G r p) := mem_inter.mpr
    ⟨mem_insert_of_mem (mem_erase.mpr ⟨av,(mem_inter.mp ak).1⟩),(mem_inter.mp ak).2⟩
  have basic {z} (zm : z∈X) : z=y ∨ z∈A := (mem_insert.mp zm).imp_right mem_of_mem_erase
  have sub : eligible X (parity G r p) r⊆eligible A (parity G r p) r := by
    intro z zm
    obtain ⟨side,root⟩ := eligible_iff.mp zm
    apply eligible_iff.mpr
    constructor
    · rcases side with mark|par
      · exact (basic mark).elim (fun e => Or.inr (e ▸ yp)) Or.inl
      · exact Or.inr par
    · exact root.imp_right fun ⟨rx,rp⟩ => ⟨(basic rx).resolve_left (Ne.symm yr),rp⟩
  have miss : y∉A.erase v := fun m => free (mem_of_mem_erase m)
  have eq : X.card=A.card := (card_insert_of_not_mem miss).trans (card_erase_add_one vm)
  exact ((saturation_move G gc hn r a p A X ai xi xa sat sub).2 eq.ge).2.1

#print axioms saturation_move
#print axioms relocate
end Minimal180.MarkMove
