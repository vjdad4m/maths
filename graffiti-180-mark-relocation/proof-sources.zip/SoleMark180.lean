import MissedPorts180
import PoolRepair180

set_option warningAsError true
namespace Minimal180.MarkMove
open Finset SimpleGraph Graffiti177 Rooted180 Converse180 Assembly180 Substitution Transversals PairRepair OppositeGain
open Classical
variable {V : Type*} [Fintype V] [DecidableEq V]

/-- A failed single off-parity mark cannot be deleted at constant allowance.
There is an original maximizing tree in which the mark is internal. -/
theorem sole_mark_failure (G : SimpleGraph V) (gc : G.Connected) (hn : 1<Fintype.card V)
    (r a b v : V) (ar : a≠r) (p : Bool) (A : Finset V) (ai : Indep G A) (ab : a≠b)
    (bi : TwoColor G (univ\{a,b})) (ak : a∈A∩insert r (parity G r p)) (bk : b∉A∩insert r (parity G r p))
    (only : A\insert r (parity G r p)={v}) (bad : ¬Protected G r p A) :
    allowance G r p A=2 ∧ allowance G r p (A.erase v)=3 ∧
    (∃ T≤G,T.IsTree ∧ (eligible A (parity G r p) r∩leaves T).card=weightedLeaves G (eligible A (parity G r p) r) ∧
      v∉leaves T) ∧
    pool G r b (parity G r p) (A∩insert r (parity G r p))=∅ ∧
    (missedEnds G a A (parity G r p)).card=1 ∧
    ∀ J : Finset V,Indep G J → J⊆G.neighborFinset a\parity G r p → J.card≤2 := by
  classical
  let P := parity G r p
  let K := A∩insert r P
  have vm : v∈A\insert r P := only ▸ mem_singleton_self _
  have va := (mem_sdiff.mp vm).1
  have vr : v≠r := fun e => (mem_sdiff.mp vm).2 (mem_insert.mpr (Or.inl e))
  have vp : v∉P := fun m => (mem_sdiff.mp vm).2 (mem_insert_of_mem m)
  have eq : A.erase v=K := by
    ext x
    have rel := Finset.ext_iff.mp only x
    simp only [mem_sdiff,mem_singleton] at rel
    change (x∈A.erase v) ↔ x∈A∩insert r P
    simp only [mem_erase,mem_inter]
    tauto
  have ki : Indep G K := fun i im j jm => ai i (mem_inter.mp im).1 j (mem_inter.mp jm).1
  have pins : K∩insert r P=K := inter_eq_left.mpr inter_subset_right
  have pass := solo_scope G gc hn r a b ar p K ki ab bi (mem_inter.mpr ⟨ak,(mem_inter.mp ak).2⟩) (fun m => bk (mem_inter.mp m).1) (Or.inl inter_subset_right)
  obtain ⟨dg,two,_⟩ := solo_rigidity G gc hn r p A ai bad a b ab bi ak bk
  have rise : allowance G r p (A.erase v)≠allowance G r p A := by
    intro same
    rw [eq] at same
    obtain ⟨Z,col,keep,cost⟩ := (protected_iff G gc hn r p K ki).mp pass
    change K∩insert r P⊆Z at keep
    rw [pins] at keep
    exact bad ((protected_iff G gc hn r p A ai).mpr ⟨Z,col,keep,same ▸ cost⟩)
  have ⟨rule,values⟩ := (delete_mark G gc hn r v p A ai va vr).2 vp
  have loss := values.resolve_left rise
  have fail := mt rule.mpr rise
  push_neg at fail
  have poolLim := failed_pool_bound G gc hn r a b ar p A ai ab bi ak bk bad K Subset.rfl (filter_subset ..)
  have part := card_sdiff_add_card_inter A (insert r P)
  have one : (A\insert r P).card=1 := by rw [only,card_singleton]
  change (A\insert r P).card+K.card=A.card at part
  change (pool G r b P K).card+2+2*K.card≤2*A.card at poolLim
  have zero : pool G r b P K=∅ := card_eq_zero.mp (by omega)
  have ap := (mem_insert.mp (mem_inter.mp ak).2).resolve_left ar
  have am := (mem_inter.mp ak).1
  have sat : G.degree a=allowance G r p A+2 := by omega
  have cap := missed_count G gc hn r a ar p A ai am ap sat
  have live : (missedEnds G a A P).Nonempty := by
    obtain ⟨x,y,_,ed,xp,yp,xa,ax,ay,_⟩ := remote_obstruction G gc hn r a b ar p A ai ab bi ak bk bad
    exact ⟨x,mem_filter.mpr ⟨mem_sdiff.mpr ⟨xp,xa⟩,ax,y,yp,ed,ay⟩⟩
  have pos := card_pos.mpr live
  change (missedEnds G a A P).card≤(A\insert r P).card at cap
  have liveOne : (missedEnds G a A P).card=1 := by omega
  refine ⟨two,by omega,fail,zero,liveOne,?_⟩
  intro J ji js
  by_contra small
  have large : 3≤J.card := by omega
  exact bad (off_parity_repair G gc hn r a ar p A ai am ap sat J ji js (by change (A\insert r P).card+2≤J.card;omega))

#print axioms sole_mark_failure
end Minimal180.MarkMove
