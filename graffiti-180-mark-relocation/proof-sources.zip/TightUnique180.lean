import TightFlip180

set_option warningAsError true
set_option maxHeartbeats 2000000
set_option maxRecDepth 20000
set_option compiler.extract_closed false
namespace Minimal180.PairRepair.Tight
open Finset SimpleGraph Graffiti177 Rooted180 Converse180 Assembly180 Substitution Transversals

/-- The original independent set is the only marking retaining the center
and allowance two at the same root and parity. -/
theorem unique_tight_marking (X : Finset V) (xi : Indep G X) (center : (0:V)∈X) :
    allowance G 1 false X=2 ↔ X=A := by
  constructor
  · intro two
    let J : Finset V := {7,0,1,5}
    have co : Con G J := by
      have h₁ := con_insert G (con_single G (5:V)) (mem_singleton_self _) (by decide : G.Adj 1 5)
      have h₂ := con_insert G h₁ (show (5:V)∈({1,5}:Finset V) by decide) (by decide : G.Adj 0 5)
      exact con_insert G h₂ (show (1:V)∈({0,1,5}:Finset V) by decide) (by decide : G.Adj 7 1)
    have cover : ∀ v∉J,Dominates G J v := by dsimp [J,Dominates];decide
    have low := weightedCore G J (eligible X P 1) co cover
    have sub : (P.erase 1)\J⊆(eligible X P 1)\J := by
      intro v vm
      obtain ⟨vp,vj⟩ := mem_sdiff.mp vm
      exact mem_sdiff.mpr ⟨eligible_iff.mpr ⟨Or.inr (mem_of_mem_erase vp),Or.inl (mem_erase.mp vp).1⟩,vj⟩
    have four := (card_le_card sub).trans low
    rw [show ((P.erase 1)\J).card=4 by decide] at four
    have eq := allowance_eq G data.1 (by decide) 1 false X xi
    dsimp only at eq
    rw [data.2.1,two,show P.card=6 by decide,show Fintype.card V=9 by decide] at eq
    have only : ∀ Y : Finset V,Indep G Y → (0:V)∈Y → 4≤Y.card → Y=A := by
      unfold Indep
      decide
    exact only X xi center (by omega)
  · rintro rfl;exact budget

theorem forced_low_marks (X : Finset V) (xi : Indep G X) (center : (0:V)∈X)
    (two : allowance G 1 false X=2) :
    (2:V)∈X ∧ (3:V)∈X ∧ G.degree 2=2 ∧ G.degree 3=2 ∧ Protected G 1 false X := by
  obtain rfl := (unique_tight_marking X xi center).mp two
  refine ⟨by decide,by decide,?_,?_,tight_regression.2.2.2.2.2⟩
  · exact (card_neighborFinset_eq_degree G 2).symm.trans (by decide : (G.neighborFinset 2).card=2)
  · exact (card_neighborFinset_eq_degree G 3).symm.trans (by decide : (G.neighborFinset 3).card=2)

#print axioms unique_tight_marking
#print axioms forced_low_marks
end Minimal180.PairRepair.Tight
