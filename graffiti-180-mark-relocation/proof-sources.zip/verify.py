"""Rebuild and kernel-replay the local #180 marking results using Lean 4.19."""
import argparse
import hashlib
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import zipfile

sys.dont_write_bytecode = True
root = Path(__file__).resolve().parent
old_sha = '19309e7ec85488b6566f3bf853dd636e2f1d420b4c42769e5435cbdf39f5c0d0'
math_sha = 'c44e0c8ee63ca166450922a373c7409c5d26b00b'
allowed = {'propext', 'Classical.choice', 'Quot.sound'}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def checked_cache(directory, manifest):
    entries = {line.split()[1]: line.split()[0] for line in manifest.read_text().splitlines()}
    assert {p.name for p in directory.glob('*.olean')} == set(entries)
    assert all(digest(directory / k) == v for k, v in entries.items())
    return len(entries)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--caches', type=Path, nargs=4, metavar=('FOUNDATION','PAIR','COMPONENT','OPPOSITE'))
    parser.add_argument('--work', type=Path)
    args = parser.parse_args()
    work = args.work.resolve() if args.work else Path(tempfile.mkdtemp(prefix='graff180-mark-replay-'))
    work.mkdir(exist_ok=True, parents=True)
    prior = work / 'frozen'
    prior.mkdir()
    archive = root / 'opposite-gain-180.zip'
    assert digest(archive) == old_sha
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        z.extractall(prior)
    subprocess.run(['sha256sum','--check','--status','bundle.sha256'],cwd=prior,check=True)
    env = dict(os.environ)
    if env.get('LEAN_BIN'):
        env['PATH'] = str(Path(env['LEAN_BIN']).resolve()) + os.pathsep + env['PATH']
    math = Path(env['MATHLIB_DIR']).resolve()
    assert subprocess.check_output(['git','-C',math,'rev-parse','HEAD'],text=True).strip() == math_sha
    version = subprocess.check_output(['lean','--version'],env=env,text=True).strip()
    assert 'version 4.19.0,' in version
    print(version,flush=True)
    print('Mathlib '+math_sha,flush=True)
    print('Frozen archive '+old_sha,flush=True)
    if args.caches:
        caches = [p.resolve() for p in args.caches]
    else:
        dest = work / 'dependencies'
        subprocess.run([sys.executable,prior/'verify.py','--work',dest],env=env,check=True)
        foundation, = (dest/'cold/prior/cold').glob('apex-tests-180.*')
        pair, = (dest/'cold/prior').glob('new-*')
        component, = (dest/'cold').glob('new-*')
        opposite, = dest.glob('new-*')
        caches = [foundation,pair,component,opposite]
    manifests = [prior/(label+'-objects.sha256') for label in ['foundation','pair','component']]
    manifests.append(root/'opposite-objects.sha256')
    count = sum(checked_cache(p, m) for p, m in zip(caches, manifests))
    assert count == 216
    print('Verified 216 frozen objects by SHA-256.',flush=True)
    outdir = work / 'new'
    outdir.mkdir()
    libs = [math/'.lake/build/lib/lean',*sorted((math/'.lake/packages').glob('*/.lake/build/lib/lean'))]
    env['LEAN_PATH'] = os.pathsep.join(map(str,[outdir,*reversed(caches),*libs]))
    ndecl = nreport = nmod = 0
    for row in (root/'modules.txt').read_text().splitlines():
        name, target = row.split()
        source, obj = root/(name+'.lean'), outdir/(name+'.olean')
        assert not re.search(r'\b(sorry|admit|native_decide|axiom|unsafe|partial)\b',source.read_text())
        proc = subprocess.run(['lean','-j1','-s','65536','-DwarningAsError=true','--root='+str(root),'-o',obj,source],
                              env=env,capture_output=True,text=True)
        msg = proc.stdout + proc.stderr
        print(msg,end='',flush=True)
        proc.check_returncode()
        assert not re.search(r'warning:|error:|sorryAx',msg,re.I)
        reports = dict(re.findall(r"'([^']+)' depends on axioms:\s*\[([^\]]+)\]",msg))
        assert target in reports
        assert all({a.strip() for a in axioms.split(',')} <= allowed for axioms in reports.values())
        out = subprocess.check_output(['lean','-j1','-DwarningAsError=true','--run',prior/'Replay.lean',obj,target],env=env,text=True)
        print(out,end='',flush=True)
        checked = re.fullmatch(r'Kernel replay accepted (\d+) declarations including '+re.escape(target)+r'\.\n',out)
        assert checked
        ndecl += int(checked[1]); nreport += len(reports); nmod += 1
    print(f'{nmod} modules, {ndecl} declarations, {nreport} axiom reports. Every report uses only the standard axioms.',flush=True)

if __name__ == '__main__':
    main()
