import AdjacentCutFiveCompact559189

namespace Graffiti189AdjacentThreeProfile

private theorem local_bounds (P : Profile) (ok : localOK P=true) :
    2≤pn P ∧ 0<aPort P ∧ 0<bPort P ∧ (size P=4 → P 8≠4) ∧ lowRequired P≤1 := by
  unfold localOK at ok
  obtain ⟨p,a,b,_,_,c,l,_,_⟩ := of_decide_eq_true ok
  exact ⟨p,a,b,c,l⟩

private theorem pair_bounds (P Q : Profile) (ok : pairOK P Q=true) :
    lowRequired P + lowRequired Q ≤ 1 ∧ aCharge P + aCharge Q ≤ 5 ∧
    bCharge P + bCharge Q ≤ 5 ∧ aPort P + aPort Q ≤ 5 ∧ bPort P + bPort Q ≤ 5 := by
  simp only [pairOK,Bool.and_eq_true,and_assoc] at ok
  exact of_decide_eq_true ok.1

theorem low_four_eq (P : Profile) (h : size P=4) :
    lowRequired P + P 8 = 4 := by
  have parts := size_eq_dn_add_pn P
  have p6 : P 6 ≤ pn P := by simp only [pn]; omega
  have p7 : P 7 ≤ pn P := by simp only [pn]; omega
  have a : dn P - 1 + P 6 < 5 := by omega
  have b : dn P - 1 + P 7 < 5 := by omega
  have d : dn P - 1 < 5 := by omega
  simp [lowRequired,chargeBad,h,a,b,d]
  simp only [dn,pn] at parts
  omega

theorem low_five_eq (P : Profile) (h : size P=5) :
    lowRequired P = dn P := by
  have parts := size_eq_dn_add_pn P
  by_cases zero : dn P=0
  · have z : P 0=0 ∧ P 1=0 ∧ P 2=0 ∧ P 3+P 4+P 5=0 := by
      simp only [dn] at zero
      omega
    simp [lowRequired,chargeBad,h,zero,z.1,z.2.1,z.2.2.1,z.2.2.2]
  · have p6 : P 6 ≤ pn P := by simp only [pn]; omega
    have p7 : P 7 ≤ pn P := by simp only [pn]; omega
    have a : dn P - 1 + P 6 < 5 := by omega
    have b : dn P - 1 + P 7 < 5 := by omega
    have d : dn P - 1 < 5 := by omega
    simp [lowRequired,chargeBad,h,a,b,d]
    unfold dn
    omega

theorem order_six_total_charge_lower (P : Profile) (sz : size P=6) (ok : localOK P=true) :
    12 ≤ aPort P+bPort P+aCharge P+bCharge P+2*lowRequired P := by
  obtain ⟨p,a,b,_,_⟩ := local_bounds P ok
  have parts := size_eq_dn_add_pn P
  by_cases z : dn P=0
  · have pn6 : pn P=6 := by omega
    have zz : P 0=0 ∧ P 1=0 ∧ P 2=0 ∧ P 3=0 ∧ P 4=0 ∧ P 5=0 := by
      unfold dn at z
      omega
    obtain ⟨z0,z1,z2,z3,z4,z5⟩ := zz
    simp only [pn] at pn6
    simp only [aPort,bPort,aCharge,bCharge,ea,eb,ec,oa,ob,oc,z0,z1,z2,z3,z4,z5]
    omega
  have a' : dn P-1+P 6 < 5 := by
    simp only [pn,bPort] at parts b
    omega
  have b' : dn P-1+P 7 < 5 := by
    simp only [pn,aPort] at parts a
    omega
  have d : dn P-1 < 5 := by omega
  simp only [lowRequired,chargeBad,sz,if_pos a',if_pos b',if_pos d]
  simp only [aPort,bPort,aCharge,bCharge,ea,eb,ec,oa,ob,oc]
  simp only [dn,pn] at parts
  omega

theorem impossible_heads_44 (P Q : Profile) (ps : size P=4) (qs : size Q=4)
    (hp : localOK P=true) (hq : localOK Q=true) (pair : pairOK P Q=true) : False := by
  have lp := low_four_eq P ps
  have lq := low_four_eq Q qs
  have p := (local_bounds P hp).2.2.2.2
  have q := (local_bounds Q hq).2.2.2.2
  have ports := (pair_bounds P Q pair).2.2.2.1
  simp only [aPort] at ports
  omega

theorem impossible_heads_45 (P Q : Profile) (ps : size P=4) (qs : size Q=5)
    (hp : localOK P=true) (pair : pairOK P Q=true) : False := by
  have lp := low_four_eq P ps
  have lq := low_five_eq Q qs
  have pp := (local_bounds P hp).2.2.2.1 ps
  have pl := (local_bounds P hp).2.2.2.2
  obtain ⟨low,_,_,av,bv⟩ := pair_bounds P Q pair
  have parts := size_eq_dn_add_pn Q
  simp only [aPort,bPort] at av bv
  simp only [pn] at parts
  omega

theorem impossible_heads_66 (P Q : Profile) (ps : size P=6) (qs : size Q=6)
    (hp : localOK P=true) (hq : localOK Q=true) (pair : pairOK P Q=true) : False := by
  have p := order_six_total_charge_lower P ps hp
  have q := order_six_total_charge_lower Q qs hq
  obtain ⟨low,av,bv,ap,bp⟩ := pair_bounds P Q pair
  omega

#print axioms impossible_heads_44
#print axioms impossible_heads_45
#print axioms impossible_heads_66
end Graffiti189AdjacentThreeProfile
