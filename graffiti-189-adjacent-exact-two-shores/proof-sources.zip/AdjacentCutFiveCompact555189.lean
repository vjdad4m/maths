import AdjacentCutFiveCompact559189

namespace Graffiti189AdjacentThreeProfile
def compact555 : Bool :=
  compressedFive.all (fun p =>
    ((compressedFive.filter (pairOK p)).all fun q =>
      ((tailCandidates 5 (5-aCharge p-aCharge q) (5-bCharge p-bCharge q)).all
        fun r => !(tailOK p q r))))

theorem no_555_of_test (P Q : Profile) (R : Totals)
    (ps : size P=5) (qs : size Q=5) (rs : R.size=5)
    (hp : localOK P = true) (hq : localOK Q = true) (pq : pairOK P Q = true)
    (ra : R.chargeA ≤ 5-aCharge P-aCharge Q)
    (rb : R.chargeB ≤ 5-bCharge P-bCharge Q) (test : compact555 = true) :
    tailOK P Q R = false := by
  unfold compact555 at test
  have h := List.all_eq_true.mp test P (mem_compressed_five P ps hp)
  have k := List.all_eq_true.mp h Q (List.mem_filter.mpr ⟨mem_compressed_five Q qs hq,pq⟩)
  have rt := tail_mem R _ _ ra rb
  rw [rs] at rt
  have v := List.all_eq_true.mp k R rt
  simpa using v


set_option maxRecDepth 1000000 in
set_option maxHeartbeats 100000000 in
theorem compact_555_true : compact555 = true := by rfl

theorem no_555 (P Q : Profile) (R : Totals)
    (ps : size P=5) (qs : size Q=5) (rs : R.size=5)
    (hp : localOK P = true) (hq : localOK Q = true) (pq : pairOK P Q = true)
    (ra : R.chargeA ≤ 5-aCharge P-aCharge Q)
    (rb : R.chargeB ≤ 5-bCharge P-bCharge Q) :
    tailOK P Q R = false :=
  no_555_of_test P Q R ps qs rs hp hq pq ra rb compact_555_true

#print axioms no_555
end Graffiti189AdjacentThreeProfile
