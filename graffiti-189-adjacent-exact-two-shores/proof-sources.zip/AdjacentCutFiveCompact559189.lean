import AdjacentCutFiveCompactArithmetic189

namespace Graffiti189AdjacentThreeProfile
open scoped BigOperators

theorem size_eq_dn_add_pn (P : Profile) : size P = dn P + pn P := by
  rw [← summarize_size]
  simp [summarize,Totals.size,ea,eb,ec,oa,ob,oc,dn,pn]
  omega

theorem order_five_at_most_one_dark (P : Profile) (sz : size P=5) (ok : localOK P=true) :
    dn P ≤ 1 := by
  have lo := (of_decide_eq_true ok).2.2.2.2.2.2.1
  have partition := size_eq_dn_add_pn P
  by_cases zero : dn P = 0
  · omega
  have b0 : dn P - 1 + P 6 < 5 := by
    have h : P 6 ≤ pn P := by unfold pn; omega
    omega
  have b1 : dn P - 1 + P 7 < 5 := by
    have h : P 7 ≤ pn P := by unfold pn; omega
    omega
  have b2 : size P - 1 < 5 := by omega
  have b3 : dn P - 1 < 5 := by omega
  unfold lowRequired at lo
  simp only [chargeBad, if_pos b0, if_pos b1, if_pos b2, if_pos b3] at lo
  unfold dn
  omega

private def darkPart (P : Profile) : Fin 6 → Nat := fun i => P (i.castAdd 3)
private def portPart (P : Profile) : Fin 3 → Nat := fun i => P (i.natAdd 6)

private theorem dark_part_sum (P : Profile) : (∑ i, darkPart P i) = dn P := by
  simp [Fin.sum_univ_succ,darkPart,dn]
  omega

private theorem port_part_sum (P : Profile) : (∑ i, portPart P i) = pn P := by
  simp [Fin.sum_univ_succ,portPart,pn]
  omega

private theorem parts_append (P : Profile) : Fin.append (darkPart P) (portPart P) = P := by
  funext i
  refine Fin.addCases ?_ ?_ i
  · intro a; simp [darkPart]
  · intro b; simp [portPart]

/-- For order 5, split on the three port counts with total 4 or 5
first; at most one dark vertex then needs a six-type allocation. -/
def compressedFive : List Profile :=
  ([4,5] : List Nat).flatMap fun p =>
  (comps 3 p).flatMap fun port =>
  ((comps 6 (5-p)).map (fun dark => Fin.append dark port)).filter localOK

theorem mem_compressed_five (P : Profile) (sz : size P=5) (ok : localOK P=true) :
    P ∈ compressedFive := by
  have dark := order_five_at_most_one_dark P sz ok
  have partition := size_eq_dn_add_pn P
  have pp : pn P = 4 ∨ pn P = 5 := by omega
  have pnMem : pn P ∈ ([4,5] : List Nat) := by rcases pp with h|h <;> simp [h]
  have portMem : portPart P ∈ comps 3 (pn P) := by
    rw [←port_part_sum]
    exact mem_comps 3 (portPart P)
  have darkMem : darkPart P ∈ comps 6 (5-pn P) := by
    rw [show 5-pn P = dn P by omega,←dark_part_sum]
    exact mem_comps 6 (darkPart P)
  unfold compressedFive
  exact List.mem_flatMap.mpr ⟨pn P,pnMem,List.mem_flatMap.mpr ⟨portPart P,portMem,
    List.mem_filter.mpr ⟨List.mem_map.mpr ⟨darkPart P,darkMem,parts_append P⟩,ok⟩⟩⟩

def compact559 : Bool :=
  compressedFive.all (fun p =>
    ((compressedFive.filter (pairOK p)).all fun q =>
      ((tailCandidates 9 (5-aCharge p-aCharge q) (5-bCharge p-bCharge q)).all
        fun r => !(tailOK p q r))))

theorem no_559_of_test (P Q : Profile) (R : Totals)
    (ps : size P=5) (qs : size Q=5) (rs : R.size=9)
    (hp : localOK P = true) (hq : localOK Q = true) (pq : pairOK P Q = true)
    (ra : R.chargeA ≤ 5-aCharge P-aCharge Q)
    (rb : R.chargeB ≤ 5-bCharge P-bCharge Q) (test : compact559 = true) :
    tailOK P Q R = false := by
  unfold compact559 at test
  have h := List.all_eq_true.mp test P (mem_compressed_five P ps hp)
  have k := List.all_eq_true.mp h Q (List.mem_filter.mpr ⟨mem_compressed_five Q qs hq,pq⟩)
  have rt := tail_mem R _ _ ra rb
  rw [rs] at rt
  have v := List.all_eq_true.mp k R rt
  simpa using v

#print axioms no_559_of_test
end Graffiti189AdjacentThreeProfile
