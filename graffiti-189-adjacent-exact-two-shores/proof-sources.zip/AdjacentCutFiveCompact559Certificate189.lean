import AdjacentCutFiveCompact559189

namespace Graffiti189AdjacentThreeProfile
/- Kernel replay of the compact bounded-order arithmetic branch.
No graph-to-profile assertion is made in this module. -/
set_option maxRecDepth 1000000 in
set_option maxHeartbeats 200000000 in
theorem compact_559_true : compact559 = true := by rfl

theorem no_559 (P Q : Profile) (R : Totals)
    (ps : size P=5) (qs : size Q=5) (rs : R.size=9)
    (hp : localOK P = true) (hq : localOK Q = true) (pq : pairOK P Q = true)
    (ra : R.chargeA ≤ 5-aCharge P-aCharge Q)
    (rb : R.chargeB ≤ 5-bCharge P-bCharge Q) :
    tailOK P Q R = false :=
  no_559_of_test P Q R ps qs rs hp hq pq ra rb compact_559_true

#print axioms no_559
end Graffiti189AdjacentThreeProfile
