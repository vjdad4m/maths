import AdjacentCutFiveProfileArithmetic189

namespace Graffiti189AdjacentThreeProfile
set_option maxHeartbeats 80000

/-- For the third shore only the six aggregate parity/color classes
are needed; no allocation of its ports or low vertices is enumerated. -/
structure Totals where
  ea : ℕ
  eb : ℕ
  ec : ℕ
  oa : ℕ
  ob : ℕ
  oc : ℕ

def summarize (P : Profile) : Totals := ⟨ea P,eb P,ec P,oa P,ob P,oc P⟩
def Totals.size (S : Totals) := S.ea+S.eb+S.ec+S.oa+S.ob+S.oc
def Totals.chargeA (S : Totals) := S.ea+S.ec+S.ob
def Totals.chargeB (S : Totals) := S.eb+S.ec+S.oa
def Totals.add (S T : Totals) : Totals :=
  ⟨S.ea+T.ea,S.eb+T.eb,S.ec+T.ec,S.oa+T.oa,S.ob+T.ob,S.oc+T.oc⟩

theorem summarize_size (P : Profile) : (summarize P).size = size P := by
  simp [summarize,Totals.size,size,ea,eb,ec,oa,ob,oc,Fin.sum_univ_succ]
  omega

def rowsTotal (P Q : Totals) : Bool :=
  decide ((P.ea > 0 → 1 + Q.ea + Q.ec + Q.ob ≤ 5) ∧
    (P.eb > 0 → 1 + Q.eb + Q.ec + Q.oa ≤ 5) ∧
    (P.ec > 0 → 2 + Q.ea + Q.eb + Q.ec ≤ 5) ∧
    (P.oa > 0 → 1 + Q.oa + Q.oc + Q.eb ≤ 5) ∧
    (P.ob > 0 → 1 + Q.ob + Q.oc + Q.ea ≤ 5) ∧
    (P.oc > 0 → Q.oa + Q.ob + Q.oc ≤ 5))

theorem rows_total_summarize (P Q : Profile) :
    rowsTotal (summarize P) (summarize Q) = rows P Q := rfl

theorem summarize_add (P Q : Profile) :
    summarize (addProfiles P Q) = (summarize P).add (summarize Q) := by
  unfold summarize addProfiles Totals.add ea eb ec oa ob oc
  congr 1 <;> (dsimp; omega)

private def rangeLE (n : ℕ) := List.range (n+1)

private theorem mem_rangeLE {n i : ℕ} (h : i ≤ n) : i ∈ rangeLE n :=
  List.mem_range.mpr (by omega)

def rawTailCandidates (n A B : ℕ) : List Totals :=
  (rangeLE (min A B)).flatMap fun c =>
  (rangeLE (A-c)).flatMap fun a =>
  (rangeLE (B-c)).flatMap fun b =>
  (rangeLE (A-c-a)).flatMap fun v =>
  (rangeLE (B-c-b)).map fun u =>
    ⟨a,b,c,u,v,n-(a+b+c+u+v)⟩

def tailCandidates (n A B : ℕ) := (rawTailCandidates n A B).filter (fun S => S.size == n)

theorem tail_mem (S : Totals) (A B : ℕ)
    (a : S.chargeA ≤ A) (b : S.chargeB ≤ B) :
    S ∈ tailCandidates S.size A B := by
  apply List.mem_filter.mpr
  refine ⟨?_,by simp⟩
  cases S with
  | mk ea eb ec oa ob oc =>
    simp only [Totals.chargeA, Totals.chargeB] at a b
    simp only [rawTailCandidates,List.mem_flatMap,List.mem_map,Totals.size] at *
    exact ⟨ec,mem_rangeLE (by omega),ea,mem_rangeLE (by omega),
      eb,mem_rangeLE (by omega),ob,mem_rangeLE (by omega),oa,mem_rangeLE (by omega),
      by congr 1; omega⟩

def enoughOdd (T : Totals) : Bool :=
  decide (2≤T.oa+T.ob+T.oc ∧ 0<T.oa+T.oc ∧ 0<T.ob+T.oc)

def tailOK (P Q : Profile) (R : Totals) : Bool :=
  let X := summarize P
  let Y := summarize Q
  enoughOdd R &&
    rowsTotal X (Y.add R) &&
    rowsTotal Y (X.add R) &&
    rowsTotal R (X.add Y)

def compactTest (x y z : ℕ) : Bool :=
  let A := localCandidates x
  let B := localCandidates y
  A.all (fun p =>
    ((B.filter (pairOK p)).all fun q =>
      ((tailCandidates z (5-aCharge p-aCharge q) (5-bCharge p-bCharge q)).all
        fun r => !(tailOK p q r))))

theorem impossible_of_compact_test (P Q : Profile) (R : Totals)
    (hp : localOK P = true) (hq : localOK Q = true) (pq : pairOK P Q = true)
    (ra : R.chargeA ≤ 5-aCharge P-aCharge Q)
    (rb : R.chargeB ≤ 5-bCharge P-bCharge Q)
    (test : compactTest (size P) (size Q) R.size = true) :
    tailOK P Q R = false := by
  unfold compactTest at test
  have h := List.all_eq_true.mp test P (local_mem P hp)
  have k := List.all_eq_true.mp h Q (List.mem_filter.mpr ⟨local_mem Q hq,pq⟩)
  have v := List.all_eq_true.mp k R (tail_mem R _ _ ra rb)
  simpa using v

#print axioms impossible_of_compact_test
end Graffiti189AdjacentThreeProfile
