import AdjacentCutFiveCompact559Certificate189
import AdjacentCutFiveTailMonotone189
import AdjacentCutFiveAnalyticHeads189

namespace Graffiti189AdjacentThreeProfile

def lowGiven (n : ℕ) (P : Profile) :=
  chargeBad n (P 6) + chargeBad n (P 7) + chargeBad (n+1) (P 8) +
  chargeBad (dn P - 1 + P 6) (P 0) + chargeBad (dn P - 1 + P 7) (P 1) +
  chargeBad (n - 1) (P 2) + chargeBad (dn P - 1) (P 3+P 4+P 5)

theorem lowGiven_eq (P : Profile) {n : ℕ} (h : size P=n) : lowGiven n P=lowRequired P := by
  simp [lowGiven,lowRequired,h]

def localGiven (n : ℕ) (P : Profile) : Bool :=
  decide (2 ≤ pn P ∧ 0 < aPort P ∧ 0 < bPort P ∧
    (P 0 + P 3 > 0 → P 6 > 0) ∧ (P 1 + P 4 > 0 → P 7 > 0) ∧
    (n = 4 → P 8 ≠ 4) ∧ lowGiven n P ≤ 1 ∧ aCharge P ≤ 5 ∧ bCharge P ≤ 5)

theorem localGiven_eq (P : Profile) {n : ℕ} (h : size P=n) : localGiven n P = localOK P := by
  simp [localGiven,localOK,h,lowGiven_eq P h]

def pairGiven (n m : ℕ) (P Q : Profile) : Bool :=
  decide (lowGiven n P + lowGiven m Q ≤ 1 ∧ aCharge P + aCharge Q ≤ 5 ∧
    bCharge P + bCharge Q ≤ 5 ∧ aPort P + aPort Q ≤ 5 ∧ bPort P + bPort Q ≤ 5) &&
  rows P Q && rows Q P

theorem pairGiven_eq (P Q : Profile) {n m : ℕ} (hp : size P=n) (hq : size Q=m) :
    pairGiven n m P Q = pairOK P Q := by
  simp [pairGiven,pairOK,lowGiven_eq P hp,lowGiven_eq Q hq]

def fastHeads (n : ℕ) : List Profile :=
  if n=5 then compressedFive else (comps 9 n).filter (localGiven n)

theorem fast_head_mem (P : Profile) (ok : localOK P=true) :
    P∈fastHeads (size P) := by
  unfold fastHeads
  split
  · exact mem_compressed_five P (by assumption) ok
  · exact List.mem_filter.mpr ⟨mem_comps 9 P,(localGiven_eq P rfl).trans ok⟩

def compactOrderTest (x y z : ℕ) : Bool :=
  let A := fastHeads x
  let B := fastHeads y
  A.all (fun p =>
    ((B.filter (pairGiven x y p)).all fun q =>
      ((tailCandidates z (5-aCharge p-aCharge q) (5-bCharge p-bCharge q)).all
        fun r => !(tailOK p q r))))


end Graffiti189AdjacentThreeProfile
