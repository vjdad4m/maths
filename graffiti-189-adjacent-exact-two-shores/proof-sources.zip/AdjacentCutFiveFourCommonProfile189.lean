import AdjacentCutFiveThreeFourCommon189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph Shore mem_shore shore_off shore_closed shore_nonempty shore_connected
  shore_hit_a shore_hit_b shore_disjoint from AdjacentCutFiveActual189
open private Vis vis_sub vis_card_ge_two degree_le_shore positive_cap foreign_pos_even
  from AdjacentCutFiveComponents189
open private mem_positive d2 from AdjacentCutFiveBound189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp := (CutGraph (G:=G) a b).ConnectedComponent

open private foreign_quota_from_four_common each_port_universal_from_four_common
  vis_card_two_of_color_quota dark_if_two_port_has_high from AdjacentCutFiveThreeFourCommon189
/-- Three nonsingleton shores cannot have a wholly high order-four shore. -/
theorem four_common_ports_profile_impossible (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ x,(EvenFrom G x).card≤6)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    (degree : ∀ x y : V,x≠y → 5≤G.degree x ∨ 5≤G.degree y)
    {D C E : Cmp (G:=G) (a:=a) (b:=b)} (dc : D≠C) (de : D≠E) (ce : C≠E)
    (four : (Shore D).card=4) (common : ∀ z∈Shore D,G.Adj a z ∧ G.Adj b z)
    (c4 : 4≤(Shore C).card) (e4 : 4≤(Shore E).card) : False := by
  classical
  have porttwo {K L : Cmp (G:=G) (a:=a) (b:=b)} (dk : D≠K) (dl : D≠L) (kl : K≠L)
      (big : 4≤(Shore L).card) : (Vis L).card=2 := by
    obtain ⟨x,xk,ax⟩ := shore_hit_a ab.ne conn K
    obtain ⟨y,yk,by'⟩ := shore_hit_b ab.ne conn K
    exact vis_card_two_of_color_quota conn ab.ne L (by omega)
      (foreign_quota_from_four_common hc even dk dl kl four common xk ax (.inl rfl))
      (foreign_quota_from_four_common hc even dk dl kl four common yk by' (.inr rfl))
  have c2 := porttwo de dc ce.symm c4
  have e2 := porttwo dc de ce e4
  have allCommon {K L : Cmp (G:=G) (a:=a) (b:=b)} (dk : D≠K) (dl : D≠L) (kl : K≠L)
      {z : V} (zk : z∈Shore K) (zd : z∉Vis K) :
      G.dist a z=2 ∧ G.dist b z=2 := by
    obtain ⟨x,xk,ax⟩ := shore_hit_a ab.ne conn K
    obtain ⟨y,yk,by'⟩ := shore_hit_b ab.ne conn K
    have nx : z≠x := fun h=>zd (mem_filter.mpr ⟨zk,h ▸ (.inl ax)⟩)
    have ny : z≠y := fun h=>zd (mem_filter.mpr ⟨zk,h ▸ (.inr by')⟩)
    have az : ¬G.Adj a z := fun h=>zd (mem_filter.mpr ⟨zk,.inl h⟩)
    have bz : ¬G.Adj b z := fun h=>zd (mem_filter.mpr ⟨zk,.inr h⟩)
    have xz := (each_port_universal_from_four_common hc even conn ab.ne dk dl kl four common
      xk (.inl ax) z zk).resolve_left nx
    have yz := (each_port_universal_from_four_common hc even conn ab.ne dk dl kl four common
      yk (.inr by') z zk).resolve_left ny
    have da := d2 hc (fun e=>(shore_off K).1 (by simpa only [← e] using zk)) az ax xz
    have db := d2 hc (fun e=>(shore_off K).2 (by simpa only [← e] using zk)) bz by' yz
    exact ⟨(mem_filter.mp da).2,(mem_filter.mp db).2⟩
  obtain ⟨z,zc,zv,zhi⟩ := dark_if_two_port_has_high degree c4 c2
  obtain ⟨w,we,wv,whi⟩ := dark_if_two_port_has_high degree e4 e2
  have zcom := allCommon dc de ce zc zv
  have wcom := allCommon de dc ce.symm we wv
  have wdepth : depth G a b w=2 := by simp [depth,wcom.1,wcom.2]
  have ns := dark_neighbors_in_shore hc we (by omega : depth G a b w ≠ 1)
  have wle := card_le_card ns
  rw [card_neighborFinset_eq_degree] at wle
  have wc := card_erase_add_one we
  have e6 : 6≤(Shore E).card := by omega
  have sub : Shore E \ Vis E ⊆ NearTwo E := by
    intro u hu
    obtain ⟨ue,uv⟩ := mem_sdiff.mp hu
    have d := allCommon de dc ce.symm ue uv
    exact mem_near_two.mpr ⟨ue,by simp [depth,d.1,d.2]⟩
  have e4near := card_le_card sub
  have csum := card_sdiff_add_card_eq_card (vis_sub E)
  have near3 := common_near_two_forbids_four_foreign hc ab even ce zc zcom.1 zcom.2
  omega


#print axioms four_common_ports_profile_impossible
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
