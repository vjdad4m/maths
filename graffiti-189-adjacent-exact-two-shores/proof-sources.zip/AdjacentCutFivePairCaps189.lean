import AdjacentCutFiveFastCore189

namespace Graffiti189AdjacentThreeProfile
set_option linter.unnecessarySeqFocus false

private def upto (n : ℕ) := List.range (n+1)
private theorem upto_mem {n j : ℕ} (h : j≤n) : j∈upto n :=
  List.mem_range.mpr (by omega)

def darkTotals (Q : Profile) : Totals := ⟨Q 0,Q 1,Q 2,Q 3,Q 4,Q 5⟩

def withPorts (R : Totals) (pa pb pc : ℕ) : Profile :=
  Fin.cons R.ea (Fin.cons R.eb (Fin.cons R.ec (Fin.cons R.oa (Fin.cons R.ob
    (Fin.cons R.oc (Fin.cons pa (Fin.cons pb (Fin.cons pc Fin.elim0))))))))

theorem withPorts_darkTotals (Q : Profile) : withPorts (darkTotals Q) (Q 6) (Q 7) (Q 8) = Q := by
  funext i
  have k := i.isLt
  have cases : i.val=0 ∨ i.val=1 ∨ i.val=2 ∨ i.val=3 ∨ i.val=4 ∨
      i.val=5 ∨ i.val=6 ∨ i.val=7 ∨ i.val=8 := by omega
  rcases cases with h|h|h|h|h|h|h|h|h
  · have e : i = (0 : Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using h)
    rw [e]; rfl
  · have e : i = (1 : Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using h)
    rw [e]; rfl
  · have e : i = (2 : Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using h)
    rw [e]; rfl
  · have e : i = (3 : Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using h)
    rw [e]; rfl
  · have e : i = (4 : Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using h)
    rw [e]; rfl
  · have e : i = (5 : Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using h)
    rw [e]; rfl
  · have e : i = (6 : Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using h)
    rw [e]; rfl
  · have e : i = (7 : Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using h)
    rw [e]; rfl
  · have e : i = (8 : Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using h)
    rw [e]; rfl

private def portPairs (m A B : ℕ) : List (ℕ × ℕ × ℕ) :=
  ((upto (min m (min A B))).flatMap fun pc=>
    (upto (min (m-pc) (A-pc))).flatMap fun pa=>
      (upto (min (m-pc-pa) (B-pc))).map fun pb=>(pa,pb,pc)).filter
        (fun (pa,pb,pc)=> decide (0<pa+pc ∧ 0<pb+pc ∧ 2≤pa+pb+pc))

private theorem portPairs_mem {m A B pa pb pc : ℕ}
    (sz : pa+pb+pc≤m) (a : pa+pc≤A) (b : pb+pc≤B)
    (pa0 : 0<pa+pc) (pb0 : 0<pb+pc) (p2 : 2≤pa+pb+pc) :
    (pa,pb,pc)∈portPairs m A B := by
  unfold portPairs
  apply List.mem_filter.mpr
  refine ⟨?_,decide_eq_true ⟨pa0,pb0,p2⟩⟩
  exact List.mem_flatMap.mpr ⟨pc,upto_mem (by omega),
    List.mem_flatMap.mpr ⟨pa,upto_mem (by omega),List.mem_map.mpr ⟨pb,upto_mem (by omega),rfl⟩⟩⟩

def boundedSeconds (m : ℕ) (P : Profile) : List Profile :=
  (portPairs m (5-aPort P) (5-bPort P)).flatMap fun (pa,pb,pc)=>
    if pb≤5-aCharge P ∧ pa≤5-bCharge P then
      (tailCandidates (m-pa-pb-pc) (5-aCharge P-pb) (5-bCharge P-pa)).map
        (fun R=>withPorts R pa pb pc)
    else []

theorem mem_boundedSeconds (P Q : Profile) (ok : localOK Q=true)
    (pair : pairOK P Q=true) : Q∈boundedSeconds (size Q) P := by
  unfold localOK at ok
  obtain ⟨pn2,pa0,pb0,_,_,_,_,_,_⟩ := of_decide_eq_true ok
  simp only [pairOK,Bool.and_eq_true,and_assoc] at pair
  obtain ⟨_,ca,cb,ap,bp⟩ := of_decide_eq_true pair.1
  have part := size_eq_dn_add_pn Q
  have port : (Q 6,Q 7,Q 8)∈portPairs (size Q) (5-aPort P) (5-bPort P) :=
    portPairs_mem (by simp only [pn] at part; omega)
      (by simp only [aPort] at ap ⊢; omega)
      (by simp only [bPort] at bp ⊢; omega) pa0 pb0 pn2
  unfold boundedSeconds
  apply List.mem_flatMap.mpr
  refine ⟨(Q 6,Q 7,Q 8),port,?_⟩
  have ca' : aCharge P + (Q 0 + Q 2 + Q 4) + Q 7 ≤ 5 := by
    simp only [aCharge,ea,ec,ob] at ca ⊢
    omega
  have cb' : bCharge P + (Q 1 + Q 2 + Q 3) + Q 6 ≤ 5 := by
    simp only [bCharge,eb,ec,oa] at cb ⊢
    omega
  simp only [if_pos (show Q 7≤5-aCharge P ∧ Q 6≤5-bCharge P by omega)]
  have len : (darkTotals Q).size=size Q-Q 6-Q 7-Q 8 := by
    simp only [pn] at part
    change dn Q = _
    omega
  have dA : (darkTotals Q).chargeA≤5-aCharge P-Q 7 := by
    change Q 0+Q 2+Q 4≤_
    omega
  have dB : (darkTotals Q).chargeB≤5-bCharge P-Q 6 := by
    change Q 1+Q 2+Q 3≤_
    omega
  have tm := tail_mem _ _ _ dA dB
  rw [len] at tm
  exact List.mem_map.mpr ⟨darkTotals Q,tm,withPorts_darkTotals Q⟩

def capOrderedTest (x y z : ℕ) : Bool :=
  (fastHeads x).all (fun p =>
    (((boundedSeconds y p).filter (fun q => localGiven y q && pairGiven x y p q)).all fun q =>
      ((tailCandidates z (5-aCharge p-aCharge q) (5-bCharge p-bCharge q)).all
        fun r => !(tailOK p q r))))

theorem sound_cap_ordered (P Q : Profile) (R : Totals)
    (hp : localOK P=true) (hq : localOK Q=true) (pq : pairOK P Q=true)
    (ra : R.chargeA ≤ 5-aCharge P-aCharge Q)
    (rb : R.chargeB ≤ 5-bCharge P-bCharge Q)
    (test : capOrderedTest (size P) (size Q) R.size = true) : tailOK P Q R=false := by
  unfold capOrderedTest at test
  have h := List.all_eq_true.mp test P (fast_head_mem P hp)
  have qlocal := (localGiven_eq Q rfl).trans hq
  have pair := (pairGiven_eq P Q rfl rfl).trans pq
  have k := List.all_eq_true.mp h Q
    (List.mem_filter.mpr ⟨mem_boundedSeconds P Q hq pq,(by simp [qlocal,pair])⟩)
  have v := List.all_eq_true.mp k R (tail_mem R _ _ ra rb)
  simpa using v
#print axioms sound_cap_ordered
end Graffiti189AdjacentThreeProfile
