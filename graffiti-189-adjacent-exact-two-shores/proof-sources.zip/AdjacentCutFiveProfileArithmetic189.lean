import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Data.Fin.Tuple.Basic
import Mathlib.Data.List.Basic
import Lean.Elab.Tactic.Omega

/-! Pure arithmetic model for the exact-three nonsingleton diagnostic.
This source currently isolates the finite certificate; it is not a
checked proof that the certificate evaluates to true or that every
graph gives the required profile. -/
namespace Graffiti189AdjacentThreeProfile
open scoped BigOperators
abbrev Profile := Fin 9 → ℕ
-- entries: even A/B/both, odd-dark A/B/both, actual A/B/both ports.

def pn (P : Profile) : Nat := P 6 + P 7 + P 8
def dn (P : Profile) : Nat := P 0 + P 1 + P 2 + P 3 + P 4 + P 5
def size (P : Profile) : Nat := ∑ i : Fin 9, P i

def ea (P : Profile) := P 0
def eb (P : Profile) := P 1
def ec (P : Profile) := P 2
def oa (P : Profile) := P 3 + P 6
def ob (P : Profile) := P 4 + P 7
def oc (P : Profile) := P 5 + P 8

def aPort (P : Profile) := P 6 + P 8
def bPort (P : Profile) := P 7 + P 8
def aCharge (P : Profile) := ea P + ec P + ob P
def bCharge (P : Profile) := eb P + ec P + oa P

def chargeBad (m v : ℕ) : ℕ := if m < 5 then v else 0

def lowRequired (P : Profile) :=
  chargeBad (size P) (P 6) +
  chargeBad (size P) (P 7) +
  chargeBad (size P + 1) (P 8) +
  chargeBad (dn P - 1 + P 6) (P 0) +
  chargeBad (dn P - 1 + P 7) (P 1) +
  chargeBad (size P - 1) (P 2) +
  chargeBad (dn P - 1) (P 3 + P 4 + P 5)

def localOK (P : Profile) : Bool :=
  decide (2 ≤ pn P ∧ 0 < aPort P ∧ 0 < bPort P ∧
    (P 0 + P 3 > 0 → P 6 > 0) ∧ (P 1 + P 4 > 0 → P 7 > 0) ∧
    (size P = 4 → P 8 ≠ 4) ∧
    lowRequired P ≤ 1 ∧ aCharge P ≤ 5 ∧ bCharge P ≤ 5)

def addProfiles (P Q : Profile) : Profile := fun i => P i + Q i

-- Q represents all profiles opposite P; includes the terminal charges.
def rows (P Q : Profile) : Bool :=
  decide ((ea P > 0 → 1 + ea Q + ec Q + ob Q ≤ 5) ∧
    (eb P > 0 → 1 + eb Q + ec Q + oa Q ≤ 5) ∧
    (ec P > 0 → 2 + ea Q + eb Q + ec Q ≤ 5) ∧
    (oa P > 0 → 1 + oa Q + oc Q + eb Q ≤ 5) ∧
    (ob P > 0 → 1 + ob Q + oc Q + ea Q ≤ 5) ∧
    (oc P > 0 → oa Q + ob Q + oc Q ≤ 5))

def pairOK (P Q : Profile) : Bool :=
  decide (lowRequired P + lowRequired Q ≤ 1 ∧ aCharge P + aCharge Q ≤ 5 ∧
    bCharge P + bCharge Q ≤ 5 ∧ aPort P + aPort Q ≤ 5 ∧ bPort P + bPort Q ≤ 5) &&
  rows P Q && rows Q P

def tripleOK (P Q R : Profile) : Bool :=
  decide (lowRequired P + lowRequired Q + lowRequired R ≤ 1 ∧
    aCharge P + aCharge Q + aCharge R ≤ 5 ∧ bCharge P + bCharge Q + bCharge R ≤ 5) &&
  rows P (addProfiles Q R) && rows Q (addProfiles P R) && rows R (addProfiles P Q)

def comps : (n : Nat) → Nat → List (Fin n → Nat)
  | 0, s => if s=0 then [Fin.elim0] else []
  | n+1, s => (List.range (s+1)).flatMap fun k =>
      (comps n (s-k)).map (Fin.cons k)

theorem mem_comps (n : Nat) (P : Fin n → Nat) : P ∈ comps n (∑ i, P i) := by
  induction n with
  | zero =>
    simp only [Finset.univ_eq_empty, Finset.sum_empty, comps, ↓reduceIte, List.mem_singleton]
    funext i
    exact Fin.elim0 i
  | succ n ih =>
    rw [Fin.sum_univ_succ]
    simp only [comps, List.mem_flatMap]
    let N := ∑ i : Fin n, P i.succ
    refine ⟨P 0, List.mem_range.mpr (by change P 0 < P 0 + N + 1; omega), ?_⟩
    have e : P 0 + N - P 0 = N := by omega
    change P ∈ (comps n (P 0 + N - P 0)).map (Fin.cons (P 0))
    rw [e]
    refine List.mem_map.mpr ⟨fun i => P i.succ, ih _, ?_⟩
    funext i
    refine Fin.cases ?_ (fun j=>?_) i
    · simp
    · simp

def localCandidates (n : ℕ) : List Profile := (comps 9 n).filter localOK

theorem local_mem (P : Profile) (h : localOK P = true) :
    P ∈ localCandidates (size P) :=
  List.mem_filter.mpr ⟨mem_comps 9 P,h⟩

def testSizeTriple (x y z : ℕ) : Bool :=
  let A := localCandidates x
  let B := localCandidates y
  let C := localCandidates z
  A.all (fun p =>
    ((B.filter (pairOK p)).all fun q =>
      ((C.filter (pairOK p)).all fun r => !((pairOK q r) && tripleOK p q r))))

theorem no_triple_of_test (P Q R : Profile)
    (hp : localOK P = true) (hq : localOK Q = true) (hr : localOK R = true)
    (pq : pairOK P Q = true) (pr : pairOK P R = true) (qr : pairOK Q R = true)
    (test : testSizeTriple (size P) (size Q) (size R) = true) :
    tripleOK P Q R = false := by
  unfold testSizeTriple at test
  have t₁ := List.all_eq_true.mp test P (local_mem P hp)
  have t₂ := List.all_eq_true.mp t₁ Q (List.mem_filter.mpr ⟨local_mem Q hq,pq⟩)
  have t₃ := List.all_eq_true.mp t₂ R (List.mem_filter.mpr ⟨local_mem R hr,pr⟩)
  simpa [qr] using t₃

#print axioms no_triple_of_test
end Graffiti189AdjacentThreeProfile
