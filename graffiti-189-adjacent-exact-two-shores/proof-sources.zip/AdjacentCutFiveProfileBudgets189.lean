import AdjacentCutFiveProfileFibers189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph Finset
open scoped BigOperators
open private CutGraph Shore shore_off shore_disjoint from AdjacentCutFiveActual189
open private mem_positive from AdjacentCutFiveBound189
open private positive_cap from AdjacentCutFiveComponents189
open Graffiti189AdjacentThreeProfile
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
set_option linter.unnecessarySeqFocus false
private abbrev Cmp := (CutGraph (G:=G) a b).ConnectedComponent

private noncomputable def classified (C : Cmp (G:=G) (a:=a) (b:=b)) (T : Finset (Fin 9)) :=
  (Shore C).filter (fun z=>profileTag G a b z∈T)

private theorem classified_sub (C : Cmp (G:=G) (a:=a) (b:=b)) (T : Finset (Fin 9)) :
    classified C T ⊆ Shore C := filter_subset _ _

def leftChargeTags : Finset (Fin 9) := {0,2,4,7}
def rightChargeTags : Finset (Fin 9) := {1,2,3,6}

theorem left_charge_profile_card (C : Cmp (G:=G) (a:=a) (b:=b)) :
    (classified C leftChargeTags).card = aCharge (countProfile C) := by
  rw [show (classified C leftChargeTags).card = ∑ i∈leftChargeTags,countProfile C i from
    card_profile_tags C leftChargeTags]
  simp [leftChargeTags,Finset.sum_insert,aCharge,ea,ec,ob]
  omega

theorem right_charge_profile_card (C : Cmp (G:=G) (a:=a) (b:=b)) :
    (classified C rightChargeTags).card = bCharge (countProfile C) := by
  rw [show (classified C rightChargeTags).card = ∑ i∈rightChargeTags,countProfile C i from
    card_profile_tags C rightChargeTags]
  simp [rightChargeTags,Finset.sum_insert,bCharge,eb,ec,oa]
  omega

theorem left_charge_budget (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ x,(EvenFrom G x).card≤6)
    (U : Finset (Cmp (G:=G) (a:=a) (b:=b))) :
    (∑ C∈U,aCharge (countProfile C))≤5 := by
  classical
  have d : (↑U : Set (Cmp (G:=G) (a:=a) (b:=b))).PairwiseDisjoint
      (fun C=>classified C leftChargeTags) := by
    intro C _ D _ cd
    exact (shore_disjoint cd).mono (classified_sub C _) (classified_sub D _)
  have sub : U.biUnion (fun C=>classified C leftChargeTags) ⊆ PositiveEven G a := by
    intro z hz
    obtain ⟨C,_,zc⟩ := mem_biUnion.mp hz
    have m := mem_filter.mp zc
    refine mem_positive.mpr ⟨fun eq=>(shore_off C).1 (by simpa only [eq] using m.1), ?_⟩
    apply (even_from_left_tag hc ab z).mpr
    simpa only [leftChargeTags,mem_insert,mem_singleton,Fin.ext_iff,Fin.val_ofNat'] using m.2
  have q := (card_le_card sub).trans (positive_cap a even)
  rw [card_biUnion d] at q
  simpa only [left_charge_profile_card] using q

theorem right_charge_budget (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ x,(EvenFrom G x).card≤6)
    (U : Finset (Cmp (G:=G) (a:=a) (b:=b))) :
    (∑ C∈U,bCharge (countProfile C))≤5 := by
  classical
  have d : (↑U : Set (Cmp (G:=G) (a:=a) (b:=b))).PairwiseDisjoint
      (fun C=>classified C rightChargeTags) := by
    intro C _ D _ cd
    exact (shore_disjoint cd).mono (classified_sub C _) (classified_sub D _)
  have sub : U.biUnion (fun C=>classified C rightChargeTags) ⊆ PositiveEven G b := by
    intro z hz
    obtain ⟨C,_,zc⟩ := mem_biUnion.mp hz
    have m := mem_filter.mp zc
    refine mem_positive.mpr ⟨fun eq=>(shore_off C).2 (by simpa only [eq] using m.1), ?_⟩
    apply (even_from_right_tag hc ab z).mpr
    simpa only [rightChargeTags,mem_insert,mem_singleton,Fin.ext_iff,Fin.val_ofNat'] using m.2
  have q := (card_le_card sub).trans (positive_cap b even)
  rw [card_biUnion d] at q
  simpa only [right_charge_profile_card] using q

def competing (i j : Fin 9) : Prop :=
  (i.val%3=0 ∧ j.val%3=1) ∨ (i.val%3=1 ∧ j.val%3=0)

def sameRow (i j : Fin 9) : Prop := ((i.val<3 ↔ j.val<3) ↔ ¬ competing i j)

noncomputable def rowTags (i : Fin 9) : Finset (Fin 9) := by
  classical exact univ.filter (sameRow i)

theorem mem_rowTags (i j : Fin 9) : j∈rowTags i ↔ sameRow i j := by
  classical simp [rowTags]

def rowFee (i : Fin 9) : ℕ :=
  (if i∈leftChargeTags then 1 else 0) + (if i∈rightChargeTags then 1 else 0)

theorem row_budget (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ z,(EvenFrom G z).card≤6)
    {C : Cmp (G:=G) (a:=a) (b:=b)} {x : V} (xc : x∈Shore C)
    (U : Finset (Cmp (G:=G) (a:=a) (b:=b))) (out : C∉U) :
    rowFee (profileTag G a b x) + ∑ D∈U, ∑ i∈rowTags (profileTag G a b x),countProfile D i ≤ 5 := by
  classical
  let T := rowTags (profileTag G a b x)
  let B := U.biUnion (fun D=>classified D T)
  have BnoneA : a∉B := by
    intro hm
    obtain ⟨D,_,ha⟩ := mem_biUnion.mp hm
    exact (shore_off D).1 (classified_sub D _ ha)
  have BnoneB : b∉B := by
    intro hm
    obtain ⟨D,_,ha⟩ := mem_biUnion.mp hm
    exact (shore_off D).2 (classified_sub D _ ha)
  have bsub : B ⊆ PositiveEven G x := by
    intro z hz
    obtain ⟨D,du,zc⟩ := mem_biUnion.mp hz
    have cd : C≠D := fun e=>out (by simpa only [e] using du)
    have h := mem_filter.mp zc
    exact mem_positive.mpr ⟨fun eq=>disjoint_left.mp (shore_disjoint cd) xc (by
      simpa only [eq] using h.1), (foreign_even_of_tags hc ab cd xc h.1).mpr
      ((mem_rowTags _ _).mp h.2)⟩
  have bcount : B.card = ∑ D∈U, ∑ i∈T,countProfile D i := by
    have d : (↑U : Set (Cmp (G:=G) (a:=a) (b:=b))).PairwiseDisjoint
      (fun D=>classified D T) := by
      intro D _ E _ de
      exact (shore_disjoint de).mono (classified_sub D _) (classified_sub E _)
    exact (card_biUnion d).trans (sum_congr rfl (fun D _=>card_profile_tags D T))
  have ha (h : profileTag G a b x∈leftChargeTags) : a∈PositiveEven G x := by
    refine mem_positive.mpr ⟨fun eq=>(shore_off C).1 (by simpa only [eq] using xc),?_⟩
    rw [dist_comm]
    exact (even_from_left_tag hc ab x).mpr (by simpa only [leftChargeTags,mem_insert,mem_singleton,Fin.ext_iff,Fin.val_ofNat'] using h)
  have hb (h : profileTag G a b x∈rightChargeTags) : b∈PositiveEven G x := by
    refine mem_positive.mpr ⟨fun eq=>(shore_off C).2 (by simpa only [eq] using xc),?_⟩
    rw [dist_comm]
    exact (even_from_right_tag hc ab x).mpr (by simpa only [rightChargeTags,mem_insert,mem_singleton,Fin.ext_iff,Fin.val_ofNat'] using h)
  change rowFee (profileTag G a b x) + (∑ D∈U, ∑ i∈T,countProfile D i)≤5
  rw [←bcount]
  have cap := positive_cap x even
  unfold rowFee
  by_cases ya : profileTag G a b x∈leftChargeTags <;>
    by_cases yb : profileTag G a b x∈rightChargeTags <;> simp [ya,yb]
  · have sub : insert a (insert b B) ⊆ PositiveEven G x :=
      insert_subset_iff.mpr ⟨ha ya,insert_subset_iff.mpr ⟨hb yb,bsub⟩⟩
    have cnt := card_le_card sub
    rw [card_insert_of_not_mem (by simp [ab.ne,BnoneA]),card_insert_of_not_mem BnoneB] at cnt
    omega
  · have cnt := card_le_card (insert_subset_iff.mpr ⟨ha ya,bsub⟩)
    rw [card_insert_of_not_mem BnoneA] at cnt
    omega
  · have cnt := card_le_card (insert_subset_iff.mpr ⟨hb yb,bsub⟩)
    rw [card_insert_of_not_mem BnoneB] at cnt
    omega
  · exact (card_le_card bsub).trans cap

#print axioms left_charge_budget
#print axioms right_charge_budget
#print axioms row_budget
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
