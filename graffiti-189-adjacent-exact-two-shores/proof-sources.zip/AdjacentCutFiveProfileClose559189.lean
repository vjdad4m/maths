import AdjacentCutFiveProfileGlue189
import AdjacentCutFiveCompact559Certificate189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph Finset
open scoped BigOperators
open Graffiti189AdjacentThreeProfile
open private CutGraph Shore from AdjacentCutFiveActual189
open private vis_card_ge_two from AdjacentCutFiveComponents189
open private port_positive from AdjacentCutFiveProfileGlue189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
set_option linter.unnecessarySeqFocus false
private abbrev Cmp := (CutGraph (G:=G) a b).ConnectedComponent

theorem tailOK_of_three_actual_shores (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ x,(EvenFrom G x).card≤6)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    {C D E : Cmp (G:=G) (a:=a) (b:=b)} (cd : C≠D) (ce : C≠E) (de : D≠E)
    (e2 : 2≤(Shore E).card) :
    tailOK (countProfile C) (countProfile D) (summarize (countProfile E)) = true := by
  classical
  have enough : enoughOdd (summarize (countProfile E)) = true := by
    have vi := vis_card_ge_two ab.ne conn E e2
    rw [visible_count_eq hc E] at vi
    obtain ⟨l,r⟩ := port_positive hc ab.ne conn E
    unfold enoughOdd
    apply decide_eq_true
    simp only [pn,aPort,bPort] at vi l r
    simp only [summarize,oa,ob,oc]
    omega
  have agg {K L : Cmp (G:=G) (a:=a) (b:=b)} (kl : K≠L) :
      aggregateProfile {K,L} = addProfiles (countProfile K) (countProfile L) := by
    funext i
    simp [aggregateProfile,addProfiles,sum_insert,kl]
  have Crows := rows_of_actual_components hc ab even C {D,E} (by simp [cd,ce])
  have Drows := rows_of_actual_components hc ab even D {C,E} (by simp [cd.symm,de])
  have Erows := rows_of_actual_components hc ab even E {C,D} (by simp [ce.symm,de.symm])
  rw [agg de,←rows_total_summarize,summarize_add] at Crows
  rw [agg ce,←rows_total_summarize,summarize_add] at Drows
  rw [agg cd,←rows_total_summarize,summarize_add] at Erows
  simp only [tailOK,enough,Crows,Drows,Erows,Bool.and_self]

theorem compact_profile_residual_charges (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ x,(EvenFrom G x).card≤6)
    {C D E : Cmp (G:=G) (a:=a) (b:=b)} (cd : C≠D) (ce : C≠E) (de : D≠E) :
    (summarize (countProfile E)).chargeA ≤ 5-aCharge (countProfile C)-aCharge (countProfile D) ∧
    (summarize (countProfile E)).chargeB ≤ 5-bCharge (countProfile C)-bCharge (countProfile D) := by
  classical
  have l := left_charge_budget hc ab even {C,D,E}
  have r := right_charge_budget hc ab even {C,D,E}
  simp [sum_insert,cd,ce,de] at l r
  change aCharge (countProfile E) ≤ _ ∧ bCharge (countProfile E) ≤ _
  omega

/-- The (5,5,9) pattern of three actual shores is impossible. The
arithmetic is replayed in the kernel with no native reduction oracle. -/
theorem no_actual_three_shores_559 (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ x,(EvenFrom G x).card≤6)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    {C D E : Cmp (G:=G) (a:=a) (b:=b)} (cd : C≠D) (ce : C≠E) (de : D≠E)
    (c5 : (Shore C).card=5) (d5 : (Shore D).card=5) (e9 : (Shore E).card=9) :
    False := by
  have hp := localOK_actual_three_shore hc ab even conn degree cd ce de (by omega) (by omega) (by omega)
  have hq := localOK_actual_three_shore hc ab even conn degree cd.symm de ce (by omega) (by omega) (by omega)
  have hpair := pairOK_actual_three_shores hc ab even conn degree cd ce de
  obtain ⟨ra,rb⟩ := compact_profile_residual_charges hc ab even cd ce de
  have cs : size (countProfile C)=5 := (countProfile_size C).trans c5
  have ds : size (countProfile D)=5 := (countProfile_size D).trans d5
  have es : (summarize (countProfile E)).size=9 := (summarize_size _).trans ((countProfile_size E).trans e9)
  have no := no_559 _ _ _ cs ds es hp hq hpair ra rb
  have yes := tailOK_of_three_actual_shores hc ab even conn cd ce de (by omega)
  simp [yes] at no

#print axioms no_actual_three_shores_559
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
