import AdjacentCutFiveShallow189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph Shore shore_off from AdjacentCutFiveActual189
open private Vis vis_sub from AdjacentCutFiveComponents189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp := (CutGraph (G:=G) a b).ConnectedComponent

noncomputable def LeftOnly (C : Cmp (G:=G) (a:=a) (b:=b)) : Finset V := by
  classical exact (Shore C).filter (fun z => G.Adj a z ∧ ¬ G.Adj b z)

noncomputable def RightOnly (C : Cmp (G:=G) (a:=a) (b:=b)) : Finset V := by
  classical exact (Shore C).filter (fun z => G.Adj b z ∧ ¬ G.Adj a z)

private theorem dark_of_depth_ne_one (hc : G.Connected)
    {C : Cmp (G:=G) (a:=a) (b:=b)} {z : V} (zc : z∈Shore C) (d : depth G a b z ≠ 1) :
    z∉Vis C := by
  classical
  intro h
  have zA : z≠a := fun e=>(shore_off C).1 (by simpa only [e] using zc)
  have zB : z≠b := fun e=>(shore_off C).2 (by simpa only [e] using zc)
  exact d (depth_eq_one_of_port hc zA zB (mem_filter.mp h).2)

private theorem dark_degree_le_with_allowed_ports (hc : G.Connected)
    {C : Cmp (G:=G) (a:=a) (b:=b)} {z : V} (zc : z∈Shore C) (d : depth G a b z ≠ 1)
    (P : Finset V) (allows : ∀ w∈Vis C,G.Adj z w → w∈P) :
    G.degree z + 1 ≤ ((Shore C) \ Vis C).card + P.card := by
  classical
  let D := Shore C \ Vis C
  have zd : z∈D := mem_sdiff.mpr ⟨zc,dark_of_depth_ne_one hc zc d⟩
  have sub : G.neighborFinset z ⊆ D.erase z ∪ P := by
    intro w wm
    have mw := mem_erase.mp (dark_neighbors_in_shore hc zc d wm)
    by_cases v : w∈Vis C
    · exact mem_union.mpr (.inr (allows w v ((mem_neighborFinset G z w).mp wm)))
    · exact mem_union.mpr (.inl (mem_erase.mpr ⟨mw.1,mem_sdiff.mpr ⟨mw.2,v⟩⟩))
  have sum := (card_le_card sub).trans (card_union_le _ _)
  have er := card_erase_add_one zd
  rw [card_neighborFinset_eq_degree] at sum
  change G.degree z + 1 ≤ D.card + P.card
  omega

theorem depth_ge_three_degree_bound (hc : G.Connected)
    {C : Cmp (G:=G) (a:=a) (b:=b)} {z : V} (zc : z∈Shore C) (d : 3≤depth G a b z) :
    G.degree z + 1 ≤ ((Shore C) \ Vis C).card := by
  classical
  have cnt := dark_degree_le_with_allowed_ports hc zc (by omega) (∅ : Finset V) (by
    intro w wm e
    have wc := vis_sub C wm
    have wA : w≠a := fun h=>(shore_off C).1 (by simpa only [h] using wc)
    have wB : w≠b := fun h=>(shore_off C).2 (by simpa only [h] using wc)
    have wd := depth_eq_one_of_port hc wA wB (mem_filter.mp wm).2
    have step := depth_step (a:=a) (b:=b) hc e
    omega)
  simpa using cnt

theorem nearer_left_dark_degree_bound (hc : G.Connected)
    {C : Cmp (G:=G) (a:=a) (b:=b)} {z : V} (zc : z∈Shore C)
    (d : 2≤depth G a b z) (lt : G.dist a z < G.dist b z) :
    G.degree z + 1 ≤ ((Shore C) \ Vis C).card + (LeftOnly C).card := by
  classical
  apply dark_degree_le_with_allowed_ports hc zc (by omega)
  intro w wm adj
  have wc := vis_sub C wm
  have bad : ¬G.Adj b w := by
    intro bw
    have up := G.dist_le (Walk.cons bw (Walk.cons adj.symm .nil))
    simp at up
    unfold depth at d
    omega
  have aw := (mem_filter.mp wm).2.resolve_right bad
  simpa only [LeftOnly,mem_filter] using ⟨wc,aw,bad⟩

theorem nearer_right_dark_degree_bound (hc : G.Connected)
    {C : Cmp (G:=G) (a:=a) (b:=b)} {z : V} (zc : z∈Shore C)
    (d : 2≤depth G a b z) (lt : G.dist b z < G.dist a z) :
    G.degree z + 1 ≤ ((Shore C) \ Vis C).card + (RightOnly C).card := by
  classical
  apply dark_degree_le_with_allowed_ports hc zc (by omega)
  intro w wm adj
  have wc := vis_sub C wm
  have bad : ¬G.Adj a w := by
    intro aw
    have up := G.dist_le (Walk.cons aw (Walk.cons adj.symm .nil))
    simp at up
    unfold depth at d
    omega
  have bw := (mem_filter.mp wm).2.resolve_left bad
  simpa only [RightOnly,mem_filter] using ⟨wc,bw,bad⟩

#print axioms depth_ge_three_degree_bound
#print axioms nearer_left_dark_degree_bound
#print axioms nearer_right_dark_degree_bound
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
