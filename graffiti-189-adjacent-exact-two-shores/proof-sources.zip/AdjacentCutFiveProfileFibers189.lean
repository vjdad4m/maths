import AdjacentCutFiveProfileTags189
import AdjacentCutFiveCompactArithmetic189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph Finset
open scoped BigOperators
open private CutGraph Shore from AdjacentCutFiveActual189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
set_option linter.unnecessarySeqFocus false

theorem card_profile_tags
    (C : (CutGraph (G:=G) a b).ConnectedComponent) (T : Finset (Fin 9)) :
    ((Shore C).filter (fun z => profileTag G a b z ∈ T)).card =
      ∑ i∈T, countProfile C i := by
  classical
  let X := (Shore C).filter (fun z => profileTag G a b z ∈ T)
  have map : X.toSet.MapsTo (profileTag G a b) T := by
    intro z hz
    exact (mem_filter.mp (show z∈X from hz)).2
  rw [show (Shore C).filter (fun z=>profileTag G a b z∈T)=X from rfl,
    card_eq_sum_card_fiberwise map]
  apply sum_congr rfl
  intro i hi
  unfold countProfile
  congr 1
  ext z
  simp only [X, mem_filter, and_assoc]
  constructor
  · exact fun ⟨u,_,e⟩=>⟨u,e⟩
  · exact fun ⟨u,e⟩=>⟨u,e ▸ hi,e⟩

theorem exists_of_positive_profile_count
    {C : (CutGraph (G:=G) a b).ConnectedComponent} {i : Fin 9}
    (pos : 0<countProfile C i) :
    ∃ z∈Shore C, profileTag G a b z=i := by
  classical
  obtain ⟨z,hz⟩ := card_pos.mp pos
  exact ⟨z,(mem_filter.mp hz).1,(mem_filter.mp hz).2⟩

theorem even_from_left_tag (hc : G.Connected) (ab : G.Adj a b) (z : V) :
    Even (G.dist a z) ↔ (profileTag G a b z).val = 0 ∨
      (profileTag G a b z).val = 2 ∨ (profileTag G a b z).val = 4 ∨
        (profileTag G a b z).val = 7 := by
  have a1 := dist_eq_one_iff_adj.mpr ab
  have b1 := dist_eq_one_iff_adj.mpr ab.symm
  have av := hc.dist_triangle (u:=a) (v:=b) (w:=z)
  have bv := hc.dist_triangle (u:=b) (v:=a) (w:=z)
  rw [a1] at av
  rw [b1] at bv
  by_cases x : G.dist a z < G.dist b z <;> by_cases y : G.dist b z < G.dist a z <;>
    by_cases d : depth G a b z = 1 <;> by_cases e : Even (depth G a b z) <;>
    simp only [profileTag,Fin.val_mk,Fin.val_ofNat',nearerColor,x,y,d,e,if_true,if_false] <;>
    simp only [Nat.even_iff,depth] at * <;> (try simp only [or_true,true_or,iff_true,false_or,or_false,iff_false]) <;> omega

theorem even_from_right_tag (hc : G.Connected) (ab : G.Adj a b) (z : V) :
    Even (G.dist b z) ↔ (profileTag G a b z).val = 1 ∨
      (profileTag G a b z).val = 2 ∨ (profileTag G a b z).val = 3 ∨
        (profileTag G a b z).val = 6 := by
  have a1 := dist_eq_one_iff_adj.mpr ab
  have b1 := dist_eq_one_iff_adj.mpr ab.symm
  have av := hc.dist_triangle (u:=a) (v:=b) (w:=z)
  have bv := hc.dist_triangle (u:=b) (v:=a) (w:=z)
  rw [a1] at av
  rw [b1] at bv
  by_cases x : G.dist a z < G.dist b z <;> by_cases y : G.dist b z < G.dist a z <;>
    by_cases d : depth G a b z = 1 <;> by_cases e : Even (depth G a b z) <;>
    simp only [profileTag,Fin.val_mk,Fin.val_ofNat',nearerColor,x,y,d,e,if_true,if_false] <;>
    simp only [Nat.even_iff,depth] at * <;> (try simp only [or_true,true_or,iff_true,false_or,or_false,iff_false]) <;> omega

#print axioms card_profile_tags
#print axioms even_from_left_tag
#print axioms even_from_right_tag
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
