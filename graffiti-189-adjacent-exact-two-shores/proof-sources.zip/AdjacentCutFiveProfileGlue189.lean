import AdjacentCutFiveProfileRows189
import AdjacentCutFiveProfileLow189
import AdjacentCutFiveFourCommonProfile189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph Finset
open scoped BigOperators
open Graffiti189AdjacentThreeProfile
open private CutGraph Shore shore_off shore_disjoint shore_hit_a shore_hit_b
  from AdjacentCutFiveActual189
open private vis_card_ge_two foreign_pos_even sum_subset_card positive_cap
  from AdjacentCutFiveComponents189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
set_option linter.unnecessarySeqFocus false
private abbrev Cmp := (CutGraph (G:=G) a b).ConnectedComponent

private theorem port_positive (hc : G.Connected) (ab : a≠b)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    (C : Cmp (G:=G) (a:=a) (b:=b)) :
    0<aPort (countProfile C) ∧ 0<bPort (countProfile C) := by
  classical
  obtain ⟨x,xc,ax⟩ := shore_hit_a ab conn C
  obtain ⟨y,yc,by'⟩ := shore_hit_b ab conn C
  rw [←a_port_count_eq hc C,←b_port_count_eq hc C]
  exact ⟨card_pos.mpr ⟨x,mem_filter.mpr ⟨xc,ax⟩⟩, card_pos.mpr ⟨y,mem_filter.mpr ⟨yc,by'⟩⟩⟩

private theorem profile_left_support (hc : G.Connected)
    (C : Cmp (G:=G) (a:=a) (b:=b))
    (h : 0<countProfile C 0 + countProfile C 3) : 0<countProfile C 6 := by
  classical
  have finds : ∃ z∈Shore C, (profileTag G a b z).val%3=0 := by
    have d : 0<countProfile C 0 ∨ 0<countProfile C 3 := by omega
    rcases d with d|d
    · obtain ⟨z,m,zr⟩ := exists_of_positive_profile_count d
      exact ⟨z,m,by rw [zr]; decide⟩
    · obtain ⟨z,m,zr⟩ := exists_of_positive_profile_count d
      exact ⟨z,m,by rw [zr]; decide⟩
  obtain ⟨z,zc,tag⟩ := finds
  rw [color_eq_tag_mod_three,color_zero_iff] at tag
  obtain ⟨u,uc,ua,ub⟩ := exclusive_left_port_of_strictly_nearer hc zc tag
  rw [←leftOnly_eq_profile hc C]
  exact card_pos.mpr ⟨u,mem_filter.mpr ⟨uc,ua,ub⟩⟩

private theorem profile_right_support (hc : G.Connected)
    (C : Cmp (G:=G) (a:=a) (b:=b))
    (h : 0<countProfile C 1 + countProfile C 4) : 0<countProfile C 7 := by
  classical
  have finds : ∃ z∈Shore C, (profileTag G a b z).val%3=1 := by
    have d : 0<countProfile C 1 ∨ 0<countProfile C 4 := by omega
    rcases d with d|d
    · obtain ⟨z,m,zr⟩ := exists_of_positive_profile_count d
      exact ⟨z,m,by rw [zr]; decide⟩
    · obtain ⟨z,m,zr⟩ := exists_of_positive_profile_count d
      exact ⟨z,m,by rw [zr]; decide⟩
  obtain ⟨z,zc,tag⟩ := finds
  rw [color_eq_tag_mod_three,color_one_iff] at tag
  obtain ⟨u,uc,ua,ub⟩ := exclusive_right_port_of_strictly_nearer hc zc tag
  rw [←rightOnly_eq_profile hc C]
  exact card_pos.mpr ⟨u,mem_filter.mpr ⟨uc,ua,ub⟩⟩

theorem localOK_actual_three_shore (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ x,(EvenFrom G x).card≤6)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    {C D E : Cmp (G:=G) (a:=a) (b:=b)} (cd : C≠D) (ce : C≠E) (de : D≠E)
    (c4 : 4≤(Shore C).card) (d4 : 4≤(Shore D).card) (e4 : 4≤(Shore E).card) :
    localOK (countProfile C) = true := by
  classical
  have vis := vis_card_ge_two ab.ne conn C (by omega)
  rw [visible_count_eq hc C] at vis
  obtain ⟨l,r⟩ := port_positive hc ab.ne conn C
  have aCap := left_charge_budget hc ab even {C}
  have bCap := right_charge_budget hc ab even {C}
  have low := count_low_required_le_one hc degree {C}
  simp only [sum_singleton] at aCap bCap low
  unfold localOK
  apply decide_eq_true
  refine ⟨vis,l,r,profile_left_support hc C,profile_right_support hc C,?_,low,aCap,bCap⟩
  intro four common
  rw [countProfile_size] at four
  let S := (Shore C).filter (fun v=>profileTag G a b v=8)
  have cap : (Shore C).card≤S.card := by
    change S.card=4 at common
    omega
  have eq : S=Shore C := eq_of_subset_of_card_le (filter_subset _ _) cap
  have all : ∀ z∈Shore C,G.Adj a z ∧ G.Adj b z := by
    intro z zc
    have s : z∈S := eq.symm ▸ zc
    have k := (mem_filter.mp s).2
    have za : z≠a := fun h=>(shore_off C).1 (by simpa only [h] using zc)
    have zb : z≠b := fun h=>(shore_off C).2 (by simpa only [h] using zc)
    exact ⟨(adj_left_tags hc za zb).mpr (.inr (by rw [k]; decide)),
      (adj_right_tags hc za zb).mpr (.inr (by rw [k]; decide))⟩
  exact four_common_ports_profile_impossible hc ab even conn degree cd ce de four all d4 e4

private theorem color_pair_budget (hc : G.Connected) (ab : a≠b)
    (even : ∀ x,(EvenFrom G x).card≤6)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    {C D E : Cmp (G:=G) (a:=a) (b:=b)} (ec : E≠C) (ed : E≠D) (cd : C≠D)
    {t : V} (te : t=a ∨ t=b) :
    ((Shore C).filter (G.Adj t)).card + ((Shore D).filter (G.Adj t)).card ≤5 := by
  classical
  obtain ⟨x,xe,tx⟩ : ∃ x∈Shore E,G.Adj t x := by
    rcases te with rfl|rfl
    · exact shore_hit_a ab conn E
    · exact shore_hit_b ab conn E
  let P := (Shore C).filter (G.Adj t)
  let Q := (Shore D).filter (G.Adj t)
  have d : Disjoint P Q := (shore_disjoint cd).mono (filter_subset _ _) (filter_subset _ _)
  have sub : P∪Q ⊆ PositiveEven G x := by
    intro z m
    rcases mem_union.mp m with m|m
    · exact foreign_pos_even hc ec xe (mem_filter.mp m).1 tx (mem_filter.mp m).2
    · exact foreign_pos_even hc ed xe (mem_filter.mp m).1 tx (mem_filter.mp m).2
  have cnt := (card_le_card sub).trans (positive_cap x even)
  rw [card_union_of_disjoint d] at cnt
  exact cnt

theorem pairOK_actual_three_shores (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ x,(EvenFrom G x).card≤6)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    {C D E : Cmp (G:=G) (a:=a) (b:=b)} (cd : C≠D) (ce : C≠E) (de : D≠E) :
    pairOK (countProfile C) (countProfile D) = true := by
  classical
  have av := left_charge_budget hc ab even {C,D}
  have bv := right_charge_budget hc ab even {C,D}
  have low := count_low_required_le_one hc degree {C,D}
  have aC := color_pair_budget hc ab.ne even conn ce.symm de.symm cd (.inl rfl)
  have bC := color_pair_budget hc ab.ne even conn ce.symm de.symm cd (.inr rfl)
  rw [a_port_count_eq hc C,a_port_count_eq hc D] at aC
  rw [b_port_count_eq hc C,b_port_count_eq hc D] at bC
  simp [sum_insert,cd] at av bv low
  have e₁ := rows_of_actual_components hc ab even C {D} (by simpa using cd)
  have e₂ := rows_of_actual_components hc ab even D {C} (by simpa using cd.symm)
  have ac (K : Cmp (G:=G) (a:=a) (b:=b)) : aggregateProfile {K}=countProfile K := by
    funext j; simp [aggregateProfile]
  rw [ac] at e₁ e₂
  unfold pairOK
  simp only [e₁,e₂,Bool.and_true]
  exact decide_eq_true ⟨low,av,bv,aC,bC⟩

#print axioms localOK_actual_three_shore
#print axioms pairOK_actual_three_shores
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
