import AdjacentCutFiveProfilePortCounts189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph Finset
open scoped BigOperators
open Graffiti189AdjacentThreeProfile
open private CutGraph Shore shore_off shore_disjoint from AdjacentCutFiveActual189
open private Vis degree_le_shore degree_le_shore_add_one from AdjacentCutFiveComponents189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
set_option linter.unnecessarySeqFocus false
private abbrev Cmp := (CutGraph (G:=G) a b).ConnectedComponent

theorem leftOnly_eq_profile (hc : G.Connected) (C : Cmp (G:=G) (a:=a) (b:=b)) :
    (LeftOnly C).card = countProfile C 6 := by
  classical
  unfold countProfile
  congr 1
  ext z
  simp only [LeftOnly,mem_filter]
  by_cases h : z∈Shore C
  · have za : z≠a := fun eq=>(shore_off C).1 (by simpa only [eq] using h)
    have zb : z≠b := fun eq=>(shore_off C).2 (by simpa only [eq] using h)
    rw [adj_left_tags hc za zb,adj_right_tags hc za zb]
    simp only [h,true_and,Fin.ext_iff,Fin.val_ofNat']
    omega
  · simp [h]

theorem rightOnly_eq_profile (hc : G.Connected) (C : Cmp (G:=G) (a:=a) (b:=b)) :
    (RightOnly C).card = countProfile C 7 := by
  classical
  unfold countProfile
  congr 1
  ext z
  simp only [RightOnly,mem_filter]
  by_cases h : z∈Shore C
  · have za : z≠a := fun eq=>(shore_off C).1 (by simpa only [eq] using h)
    have zb : z≠b := fun eq=>(shore_off C).2 (by simpa only [eq] using h)
    rw [adj_left_tags hc za zb,adj_right_tags hc za zb]
    simp only [h,true_and,Fin.ext_iff,Fin.val_ofNat']
    omega
  · simp [h]

def capacity (P : Profile) (i : Fin 9) : ℕ :=
  if i.val=0 then dn P - 1 + P 6 else
  if i.val=1 then dn P - 1 + P 7 else
  if i.val=2 then size P - 1 else
  if i.val<6 then dn P - 1 else
  if i.val<8 then size P else size P+1

theorem degree_le_profile_capacity (hc : G.Connected)
    {C : Cmp (G:=G) (a:=a) (b:=b)} {z : V} (zc : z∈Shore C) :
    G.degree z ≤ capacity (countProfile C) (profileTag G a b z) := by
  classical
  let i := profileTag G a b z
  have iz : i = profileTag G a b z := rfl
  change G.degree z ≤ capacity (countProfile C) i
  have za : z≠a := fun eq=>(shore_off C).1 (by simpa only [eq] using zc)
  have zb : z≠b := fun eq=>(shore_off C).2 (by simpa only [eq] using zc)
  have pos := depth_pos_of_shore hc zc
  have it := i.isLt
  have pt : ((6 : ℕ) ≤ i.val) ↔ depth G a b z = 1 := port_tag_iff G a b z
  have et : i.val<3 ↔ Even (depth G a b z) := even_tag_iff G a b z
  have color0 : i.val%3=0 ↔ G.dist a z<G.dist b z := by
    rw [iz,color_eq_tag_mod_three,color_zero_iff]
  have color1 : i.val%3=1 ↔ G.dist b z<G.dist a z := by
    rw [iz,color_eq_tag_mod_three,color_one_iff]
  have dark_pos (d : depth G a b z≠1) : 0<dn (countProfile C) := by
    have no : z∉Vis C := fun m=>d ((depth_one_iff_port hc za zb).mpr (mem_filter.mp m).2)
    rw [←dark_count_eq hc C]
    exact card_pos.mpr ⟨z,mem_sdiff.mpr ⟨zc,no⟩⟩
  unfold capacity
  split
  · rename_i iv
    have d : 2≤depth G a b z := by have n := pt.not.mp (by omega); omega
    have q := nearer_left_dark_degree_bound hc zc d (color0.mp (by omega))
    rw [dark_count_eq hc C,leftOnly_eq_profile hc C] at q
    have h := dark_pos (by omega)
    omega
  split
  · rename_i iv
    have d : 2≤depth G a b z := by have n := pt.not.mp (by omega); omega
    have q := nearer_right_dark_degree_bound hc zc d (color1.mp (by omega))
    rw [dark_count_eq hc C,rightOnly_eq_profile hc C] at q
    have h := dark_pos (by omega)
    omega
  split
  · rename_i iv
    have n : depth G a b z≠1 := pt.not.mp (by omega)
    have q := card_le_card (dark_neighbors_in_shore hc zc n)
    rw [card_neighborFinset_eq_degree] at q
    rw [countProfile_size]
    have c := card_erase_add_one zc
    omega
  split
  · have n := pt.not.mp (by omega)
    have o := et.not.mp (by omega)
    simp only [Nat.even_iff] at o
    have q := depth_ge_three_degree_bound hc zc (by omega)
    rw [dark_count_eq hc C] at q
    omega
  split
  · have allowed : ¬G.Adj a z ∨ ¬G.Adj b z := by
      by_cases hl : G.Adj a z
      · have cv := (adj_left_tags hc za zb).mp hl
        have no : ¬G.Adj b z := by
          intro hr
          have cv' := (adj_right_tags hc za zb).mp hr
          change i.val=6 ∨ i.val=8 at cv
          change i.val=7 ∨ i.val=8 at cv'
          omega
        exact .inr no
      · exact .inl hl
    rw [countProfile_size]
    exact degree_le_shore C zc allowed
  · rw [countProfile_size]
    exact degree_le_shore_add_one C zc

def lowTags (P : Profile) : Finset (Fin 9) := univ.filter (fun i=>capacity P i<5)

theorem sum_lowTags (P : Profile) : (∑ i∈lowTags P,P i) = lowRequired P := by
  unfold lowTags
  rw [Finset.sum_filter]
  simp [Fin.sum_univ_succ,capacity,lowRequired,chargeBad]
  by_cases h : dn P - 1 < 5 <;> simp [h] <;> omega

theorem count_low_required_le_one (hc : G.Connected)
    (degree : ∀ x y : V,x≠y → 5≤G.degree x ∨ 5≤G.degree y)
    (U : Finset (Cmp (G:=G) (a:=a) (b:=b))) :
    (∑ C∈U,lowRequired (countProfile C)) ≤ 1 := by
  classical
  let K (C : Cmp (G:=G) (a:=a) (b:=b)) :=
    (Shore C).filter (fun z=>profileTag G a b z ∈ lowTags (countProfile C))
  let L := (univ : Finset V).filter (fun z=>G.degree z<5)
  have dis : (↑U : Set (Cmp (G:=G) (a:=a) (b:=b))).PairwiseDisjoint K := by
    intro C _ D _ ne
    exact (shore_disjoint ne).mono (filter_subset _ _) (filter_subset _ _)
  have sub : U.biUnion K ⊆ L := by
    intro z hz
    obtain ⟨C,_,m⟩ := mem_biUnion.mp hz
    obtain ⟨zc,j⟩ := mem_filter.mp m
    have d := degree_le_profile_capacity hc zc
    have k := (mem_filter.mp j).2
    exact mem_filter.mpr ⟨mem_univ _,d.trans_lt k⟩
  have cap : L.card ≤1 := by
    apply card_le_one.mpr
    intro x xL y yL
    by_contra ne
    have h := degree x y ne
    have hx := (mem_filter.mp xL).2
    have hy := (mem_filter.mp yL).2
    omega
  have cnt := (card_le_card sub).trans cap
  rw [card_biUnion dis] at cnt
  have cv (C : Cmp (G:=G) (a:=a) (b:=b)) : (K C).card=lowRequired (countProfile C) :=
    (card_profile_tags C _).trans (sum_lowTags _)
  simpa only [cv] using cnt

#print axioms degree_le_profile_capacity
#print axioms count_low_required_le_one
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
