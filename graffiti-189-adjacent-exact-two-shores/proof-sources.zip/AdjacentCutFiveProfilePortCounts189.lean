import AdjacentCutFiveProfileFibers189
import AdjacentCutFiveCompact559189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph Finset
open scoped BigOperators
open Graffiti189AdjacentThreeProfile
open private CutGraph Shore shore_off from AdjacentCutFiveActual189
open private Vis vis_sub from AdjacentCutFiveComponents189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
set_option linter.unnecessarySeqFocus false
private abbrev Cmp := (CutGraph (G:=G) a b).ConnectedComponent

theorem depth_one_iff_port (hc : G.Connected) {z : V} (za : z≠a) (zb : z≠b) :
    depth G a b z =1 ↔ G.Adj a z ∨ G.Adj b z := by
  refine ⟨fun d=>?_,depth_eq_one_of_port hc za zb⟩
  have one : G.dist a z=1 ∨ G.dist b z=1 := by unfold depth at d; omega
  exact one.imp dist_eq_one_iff_adj.mp dist_eq_one_iff_adj.mp

theorem adj_left_tags (hc : G.Connected) {z : V} (za : z≠a) (zb : z≠b) :
    G.Adj a z ↔ (profileTag G a b z).val=6 ∨ (profileTag G a b z).val=8 := by
  have pa := hc.pos_dist_of_ne za.symm
  have pb := hc.pos_dist_of_ne zb.symm
  rw [←dist_eq_one_iff_adj]
  by_cases x : G.dist a z < G.dist b z <;> by_cases y : G.dist b z < G.dist a z <;>
    by_cases d : depth G a b z = 1 <;> by_cases e : Even (depth G a b z) <;>
    simp only [profileTag,Fin.val_mk,Fin.val_ofNat',nearerColor,x,y,d,e,if_true,if_false] <;>
    simp only [Nat.even_iff,depth] at * <;> (try simp only [or_true,true_or,iff_true,false_or,or_false,iff_false]) <;> omega

theorem adj_right_tags (hc : G.Connected) {z : V} (za : z≠a) (zb : z≠b) :
    G.Adj b z ↔ (profileTag G a b z).val=7 ∨ (profileTag G a b z).val=8 := by
  have pa := hc.pos_dist_of_ne za.symm
  have pb := hc.pos_dist_of_ne zb.symm
  rw [←dist_eq_one_iff_adj]
  by_cases x : G.dist a z < G.dist b z <;> by_cases y : G.dist b z < G.dist a z <;>
    by_cases d : depth G a b z = 1 <;> by_cases e : Even (depth G a b z) <;>
    simp only [profileTag,Fin.val_mk,Fin.val_ofNat',nearerColor,x,y,d,e,if_true,if_false] <;>
    simp only [Nat.even_iff,depth] at * <;> (try simp only [or_true,true_or,iff_true,false_or,or_false,iff_false]) <;> omega

private theorem left_off_of_mem {C : Cmp (G:=G) (a:=a) (b:=b)} {z : V}
    (zc : z∈Shore C) : z≠a :=
  fun h=>(shore_off C).1 (by simpa only [h] using zc)

private theorem right_off_of_mem {C : Cmp (G:=G) (a:=a) (b:=b)} {z : V}
    (zc : z∈Shore C) : z≠b :=
  fun h=>(shore_off C).2 (by simpa only [h] using zc)

theorem a_port_count_eq (hc : G.Connected) (C : Cmp (G:=G) (a:=a) (b:=b)) :
    ((Shore C).filter (G.Adj a)).card = aPort (countProfile C) := by
  classical
  let S : Finset (Fin 9) := {6,8}
  have eq : (Shore C).filter (G.Adj a) =
      (Shore C).filter (fun z=>profileTag G a b z ∈ S) := by
    ext z
    simp only [mem_filter]
    by_cases h : z∈Shore C
    · simpa [h,S,Fin.ext_iff] using adj_left_tags hc (left_off_of_mem h) (right_off_of_mem h)
    · simp [h]
  rw [eq,card_profile_tags]
  simp [S,aPort,Finset.sum_insert]

theorem b_port_count_eq (hc : G.Connected) (C : Cmp (G:=G) (a:=a) (b:=b)) :
    ((Shore C).filter (G.Adj b)).card = bPort (countProfile C) := by
  classical
  let S : Finset (Fin 9) := {7,8}
  have eq : (Shore C).filter (G.Adj b) =
      (Shore C).filter (fun z=>profileTag G a b z ∈ S) := by
    ext z
    simp only [mem_filter]
    by_cases h : z∈Shore C
    · simpa [h,S,Fin.ext_iff] using adj_right_tags hc (left_off_of_mem h) (right_off_of_mem h)
    · simp [h]
  rw [eq,card_profile_tags]
  simp [S,bPort,Finset.sum_insert]

theorem visible_count_eq (hc : G.Connected) (C : Cmp (G:=G) (a:=a) (b:=b)) :
    (Vis C).card = pn (countProfile C) := by
  classical
  let S : Finset (Fin 9) := {6,7,8}
  have eq : Vis C = (Shore C).filter (fun z=>profileTag G a b z ∈ S) := by
    ext z
    simp only [Vis,mem_filter]
    by_cases h : z∈Shore C
    · have ord := (profileTag G a b z).isLt
      simp only [h,true_and,S,mem_insert,mem_singleton,Fin.ext_iff]
      rw [←depth_one_iff_port hc (left_off_of_mem h) (right_off_of_mem h),←port_tag_iff]
      omega
    · simp [h]
  rw [eq,card_profile_tags]
  simp [S,pn,Finset.sum_insert]
  omega

theorem dark_count_eq (hc : G.Connected) (C : Cmp (G:=G) (a:=a) (b:=b)) :
    ((Shore C) \ Vis C).card = dn (countProfile C) := by
  classical
  have h := card_sdiff_add_card_eq_card (vis_sub C)
  rw [visible_count_eq hc C,← countProfile_size C,size_eq_dn_add_pn] at h
  omega

#print axioms a_port_count_eq
#print axioms b_port_count_eq
#print axioms visible_count_eq
#print axioms dark_count_eq
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
