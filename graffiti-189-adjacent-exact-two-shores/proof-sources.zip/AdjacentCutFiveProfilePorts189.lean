import AdjacentCutFiveProfiles189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph Shore shore_closed shore_off from AdjacentCutFiveActual189
open private Vis vis_sub from AdjacentCutFiveComponents189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp := (CutGraph (G:=G) a b).ConnectedComponent

private theorem walk_start_mem_shore_of_end
    {C : Cmp (G:=G) (a:=a) (b:=b)}
    {u v : V} (q : G.Walk u v) (vc : v∈Shore C)
    (aoff : a∉q.support) (boff : b∉q.support) : u∈Shore C := by
  have hr : ∀ {s t : V} (p : G.Walk s t),
      s∈Shore C → a∉p.support → b∉p.support → t∈Shore C := by
    intro s t p
    induction p with
    | nil => intro sc _ _; exact sc
    | @cons s w t sw p ih =>
      intro sc an bn
      have a' : a∉p.support := fun h=>an (by simpa only [support_cons,List.mem_cons] using Or.inr h)
      have b' : b∉p.support := fun h=>bn (by simpa only [support_cons,List.mem_cons] using Or.inr h)
      apply ih _ a' b'
      rcases shore_closed C s sc w sw with wa|wb|wc
      · exact (a' (by simpa only [← wa] using p.start_mem_support)).elim
      · exact (b' (by simpa only [← wb] using p.start_mem_support)).elim
      · exact wc
  exact hr q.reverse vc (by simpa using aoff) (by simpa using boff)

private theorem nearer_port_of_walk
    {C : Cmp (G:=G) (a:=a) (b:=b)} {s t z : V}
    (terminals : (s=a ∧ t=b) ∨ (s=b ∧ t=a)) (zc : z∈Shore C)
    (near : G.dist s z < G.dist t z)
    (p : G.Walk s z) (short : p.length = G.dist s z) :
    ∃ w∈Shore C,G.Adj s w ∧ ¬G.Adj t w := by
  classical
  cases p with
  | nil =>
    rcases terminals with ⟨rfl,_⟩|⟨rfl,_⟩
    · exact ((shore_off C).1 zc).elim
    · exact ((shore_off C).2 zc).elim
  | @cons s w z sw p =>
    have smaller : p.length < G.dist s z := by simp only [length_cons] at short; omega
    have so : s∉p.support := by
      intro h
      have le := (G.dist_le (p.dropUntil s h)).trans (length_dropUntil_le p h)
      omega
    have toff : t∉p.support := by
      intro h
      have le := (G.dist_le (p.dropUntil t h)).trans (length_dropUntil_le p h)
      omega
    have aos : a∉p.support := by
      rcases terminals with ⟨st,tt⟩|⟨st,tt⟩
      · simpa only [st] using so
      · simpa only [tt] using toff
    have bos : b∉p.support := by
      rcases terminals with ⟨st,tt⟩|⟨st,tt⟩
      · simpa only [tt] using toff
      · simpa only [st] using so
    refine ⟨w,walk_start_mem_shore_of_end p zc aos bos,sw,?_⟩
    intro tw
    have le := G.dist_le (Walk.cons tw p)
    simp only [length_cons] at le short
    omega

/-- Every vertex whose uniquely nearer endpoint is a has an a-exclusive
port in its own shore, irrespective of depth. -/
theorem exclusive_left_port_of_strictly_nearer (hc : G.Connected)
    {C : Cmp (G:=G) (a:=a) (b:=b)} {z : V} (zc : z∈Shore C)
    (near : G.dist a z < G.dist b z) :
    ∃ w∈Shore C,G.Adj a w ∧ ¬G.Adj b w := by
  obtain ⟨p,pl⟩ := hc.exists_walk_length_eq_dist a z
  exact nearer_port_of_walk (.inl ⟨rfl,rfl⟩) zc near p pl

theorem exclusive_right_port_of_strictly_nearer (hc : G.Connected)
    {C : Cmp (G:=G) (a:=a) (b:=b)} {z : V} (zc : z∈Shore C)
    (near : G.dist b z < G.dist a z) :
    ∃ w∈Shore C,G.Adj b w ∧ ¬G.Adj a w := by
  obtain ⟨p,pl⟩ := hc.exists_walk_length_eq_dist b z
  exact nearer_port_of_walk (.inr ⟨rfl,rfl⟩) zc near p pl

#print axioms exclusive_left_port_of_strictly_nearer
#print axioms exclusive_right_port_of_strictly_nearer
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
