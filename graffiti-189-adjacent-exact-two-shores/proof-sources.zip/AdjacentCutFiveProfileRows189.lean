import AdjacentCutFiveProfileBudgets189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph Finset
open scoped BigOperators
open Graffiti189AdjacentThreeProfile
open private CutGraph Shore from AdjacentCutFiveActual189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
set_option linter.unnecessarySeqFocus false
private abbrev Cmp := (CutGraph (G:=G) a b).ConnectedComponent

noncomputable def aggregateProfile (U : Finset (Cmp (G:=G) (a:=a) (b:=b))) : Profile :=
  fun i => ∑ C∈U,countProfile C i

private theorem bound_at_tag (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ z,(EvenFrom G z).card≤6)
    {C : Cmp (G:=G) (a:=a) (b:=b)} {i : Fin 9} (pos : 0<countProfile C i)
    (U : Finset (Cmp (G:=G) (a:=a) (b:=b))) (out : C∉U) :
    rowFee i + (∑ j∈rowTags i,aggregateProfile U j) ≤ 5 := by
  obtain ⟨x,xc,xt⟩ := exists_of_positive_profile_count pos
  have r := row_budget hc ab even xc U out
  rw [xt,Finset.sum_comm] at r
  exact r

private theorem row_0 : rowTags 0 = {0,2,4,7} := by
  ext j
  have h := j.isLt
  simp only [mem_rowTags,sameRow,competing,mem_insert,mem_singleton,Fin.ext_iff,Fin.val_ofNat']
  omega
private theorem fee_0 : rowFee 0 = 1 := by decide

private theorem row_1 : rowTags 1 = {1,2,3,6} := by
  ext j
  have h := j.isLt
  simp only [mem_rowTags,sameRow,competing,mem_insert,mem_singleton,Fin.ext_iff,Fin.val_ofNat']
  omega
private theorem fee_1 : rowFee 1 = 1 := by decide

private theorem row_2 : rowTags 2 = {0,1,2} := by
  ext j
  have h := j.isLt
  simp only [mem_rowTags,sameRow,competing,mem_insert,mem_singleton,Fin.ext_iff,Fin.val_ofNat']
  omega
private theorem fee_2 : rowFee 2 = 2 := by decide

private theorem row_3 : rowTags 3 = {1,3,5,6,8} := by
  ext j
  have h := j.isLt
  simp only [mem_rowTags,sameRow,competing,mem_insert,mem_singleton,Fin.ext_iff,Fin.val_ofNat']
  omega
private theorem fee_3 : rowFee 3 = 1 := by decide

private theorem row_4 : rowTags 4 = {0,4,5,7,8} := by
  ext j
  have h := j.isLt
  simp only [mem_rowTags,sameRow,competing,mem_insert,mem_singleton,Fin.ext_iff,Fin.val_ofNat']
  omega
private theorem fee_4 : rowFee 4 = 1 := by decide

private theorem row_5 : rowTags 5 = {3,4,5,6,7,8} := by
  ext j
  have h := j.isLt
  simp only [mem_rowTags,sameRow,competing,mem_insert,mem_singleton,Fin.ext_iff,Fin.val_ofNat']
  omega
private theorem fee_5 : rowFee 5 = 0 := by decide

private theorem row_6 : rowTags 6 = {1,3,5,6,8} := by
  ext j
  have h := j.isLt
  simp only [mem_rowTags,sameRow,competing,mem_insert,mem_singleton,Fin.ext_iff,Fin.val_ofNat']
  omega
private theorem fee_6 : rowFee 6 = 1 := by decide

private theorem row_7 : rowTags 7 = {0,4,5,7,8} := by
  ext j
  have h := j.isLt
  simp only [mem_rowTags,sameRow,competing,mem_insert,mem_singleton,Fin.ext_iff,Fin.val_ofNat']
  omega
private theorem fee_7 : rowFee 7 = 1 := by decide

private theorem row_8 : rowTags 8 = {3,4,5,6,7,8} := by
  ext j
  have h := j.isLt
  simp only [mem_rowTags,sameRow,competing,mem_insert,mem_singleton,Fin.ext_iff,Fin.val_ofNat']
  omega
private theorem fee_8 : rowFee 8 = 0 := by decide

theorem rows_of_actual_components (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ z,(EvenFrom G z).card≤6)
    (C : Cmp (G:=G) (a:=a) (b:=b))
    (U : Finset (Cmp (G:=G) (a:=a) (b:=b))) (out : C∉U) :
    rows (countProfile C) (aggregateProfile U) = true := by
  unfold rows
  apply decide_eq_true
  refine ⟨?_,?_,?_,?_,?_,?_⟩
  · intro pos
    have r := bound_at_tag hc ab even (i:=0) pos U out
    rw [row_0,fee_0] at r
    simp [Finset.sum_insert] at r
    simp only [ea,eb,ec,oa,ob,oc]
    omega
  · intro pos
    have r := bound_at_tag hc ab even (i:=1) pos U out
    rw [row_1,fee_1] at r
    simp [Finset.sum_insert] at r
    simp only [ea,eb,ec,oa,ob,oc]
    omega
  · intro pos
    have r := bound_at_tag hc ab even (i:=2) pos U out
    rw [row_2,fee_2] at r
    simp [Finset.sum_insert] at r
    simp only [ea,eb,ec,oa,ob,oc]
    omega
  · intro pos
    change 0 < countProfile C 3 + countProfile C 6 at pos
    have hit : 0<countProfile C 3 ∨ 0<countProfile C 6 := by omega
    rcases hit with h|h
    · have r := bound_at_tag hc ab even (i:=3) h U out
      rw [row_3,fee_3] at r
      simp [Finset.sum_insert] at r
      simp only [ea,eb,ec,oa,ob,oc]
      omega
    · have r := bound_at_tag hc ab even (i:=6) h U out
      rw [row_6,fee_6] at r
      simp [Finset.sum_insert] at r
      simp only [ea,eb,ec,oa,ob,oc]
      omega
  · intro pos
    change 0 < countProfile C 4 + countProfile C 7 at pos
    have hit : 0<countProfile C 4 ∨ 0<countProfile C 7 := by omega
    rcases hit with h|h
    · have r := bound_at_tag hc ab even (i:=4) h U out
      rw [row_4,fee_4] at r
      simp [Finset.sum_insert] at r
      simp only [ea,eb,ec,oa,ob,oc]
      omega
    · have r := bound_at_tag hc ab even (i:=7) h U out
      rw [row_7,fee_7] at r
      simp [Finset.sum_insert] at r
      simp only [ea,eb,ec,oa,ob,oc]
      omega
  · intro pos
    change 0 < countProfile C 5 + countProfile C 8 at pos
    have hit : 0<countProfile C 5 ∨ 0<countProfile C 8 := by omega
    rcases hit with h|h
    · have r := bound_at_tag hc ab even (i:=5) h U out
      rw [row_5,fee_5] at r
      simp [Finset.sum_insert] at r
      simp only [ea,eb,ec,oa,ob,oc]
      omega
    · have r := bound_at_tag hc ab even (i:=8) h U out
      rw [row_8,fee_8] at r
      simp [Finset.sum_insert] at r
      simp only [ea,eb,ec,oa,ob,oc]
      omega

#print axioms rows_of_actual_components
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
