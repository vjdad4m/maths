import AdjacentCutFiveProfileDegree189
import AdjacentCutFiveProfilePorts189
import AdjacentCutFiveProfileArithmetic189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open scoped BigOperators
open private CutGraph Shore shore_off from AdjacentCutFiveActual189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
set_option linter.unnecessarySeqFocus false

noncomputable def nearerColor (G : SimpleGraph V) (a b z : V) : ℕ :=
  if G.dist a z < G.dist b z then 0 else if G.dist b z < G.dist a z then 1 else 2

theorem nearerColor_lt_three (G : SimpleGraph V) (a b z : V) : nearerColor G a b z < 3 := by
  unfold nearerColor
  split
  · decide
  · split <;> decide

theorem color_zero_iff (G : SimpleGraph V) (a b z : V) :
    nearerColor G a b z = 0 ↔ G.dist a z < G.dist b z := by
  unfold nearerColor
  by_cases e : G.dist a z < G.dist b z <;> by_cases f : G.dist b z < G.dist a z <;> simp [e,f]

theorem color_one_iff (G : SimpleGraph V) (a b z : V) :
    nearerColor G a b z = 1 ↔ G.dist b z < G.dist a z := by
  unfold nearerColor
  split <;> simp_all
  omega

theorem color_two_iff (G : SimpleGraph V) (a b z : V) :
    nearerColor G a b z = 2 ↔ G.dist a z = G.dist b z := by
  unfold nearerColor
  by_cases e : G.dist a z < G.dist b z <;> by_cases f : G.dist b z < G.dist a z <;>
    simp [e,f] <;> omega

/-- Entries 0–2: even-depth dark vertices; 3–5: odd-depth dark
vertices; 6–8: actual depth-one ports. Each group is ordered A/B/both. -/
noncomputable def profileTag (G : SimpleGraph V) (a b z : V) : Fin 9 :=
  ⟨(if depth G a b z = 1 then 6 else if Even (depth G a b z) then 0 else 3) + nearerColor G a b z, by
    have c := nearerColor_lt_three G a b z
    split
    · omega
    · split <;> omega⟩

theorem color_eq_tag_mod_three (G : SimpleGraph V) (a b z : V) :
    (profileTag G a b z).val % 3 = nearerColor G a b z := by
  have c := nearerColor_lt_three G a b z
  unfold profileTag
  simp only
  split
  · omega
  · split <;> omega

theorem port_tag_iff (G : SimpleGraph V) (a b z : V) :
    6 ≤ (profileTag G a b z).val ↔ depth G a b z=1 := by
  have c := nearerColor_lt_three G a b z
  unfold profileTag
  simp only
  split
  · simp_all
  · split <;> omega

theorem even_tag_iff (G : SimpleGraph V) (a b z : V) :
    (profileTag G a b z).val < 3 ↔ Even (depth G a b z) := by
  have c := nearerColor_lt_three G a b z
  unfold profileTag
  simp only
  by_cases d : depth G a b z = 1
  · simp [d, Nat.even_iff]; omega
  · by_cases e : Even (depth G a b z) <;> simp [d,e] <;> omega

noncomputable def countProfile (C : (CutGraph (G := G) a b).ConnectedComponent) :
    Graffiti189AdjacentThreeProfile.Profile :=
  fun i => ((Shore C).filter (fun z => profileTag G a b z=i)).card

theorem countProfile_size (C : (CutGraph (G := G) a b).ConnectedComponent) :
    Graffiti189AdjacentThreeProfile.size (countProfile C) = (Shore C).card := by
  classical
  have h : (Shore C).toSet.MapsTo (profileTag G a b) (↑(univ : Finset (Fin 9)) : Set (Fin 9)) :=
    fun _ _ => mem_univ _
  exact (card_eq_sum_card_fiberwise h).symm

theorem foreign_even_of_tags (hc : G.Connected) (ab : G.Adj a b)
    {C D : (CutGraph (G := G) a b).ConnectedComponent} (ne : C≠D)
    {x y : V} (xc : x∈Shore C) (yd : y∈Shore D) :
    Even (G.dist x y) ↔
      (((profileTag G a b x).val<3 ↔ (profileTag G a b y).val<3) ↔
      ¬ (((profileTag G a b x).val % 3 = 0 ∧ (profileTag G a b y).val % 3 = 1) ∨
         ((profileTag G a b x).val % 3 = 1 ∧ (profileTag G a b y).val % 3 = 0))) := by
  rw [foreign_distance_by_nearer_endpoint hc ab ne xc yd,
    even_tag_iff,even_tag_iff,color_eq_tag_mod_three,color_eq_tag_mod_three,
    color_zero_iff,color_zero_iff,color_one_iff,color_one_iff]
  by_cases opp : (G.dist a x < G.dist b x ∧ G.dist b y < G.dist a y) ∨
        (G.dist b x < G.dist a x ∧ G.dist a y < G.dist b y)
  · simp only [if_pos opp,opp,not_true_eq_false,iff_false,if_true]
    simp only [Nat.even_iff]
    omega
  · simp only [if_neg opp,opp,not_false_eq_true,add_zero,iff_true,if_false]
    simp only [Nat.even_iff]
    omega

#print axioms countProfile_size
#print axioms foreign_even_of_tags
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
