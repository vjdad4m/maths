import AdjacentCutFiveThreeShape189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph Shore shore_off from AdjacentCutFiveActual189
open private Vis vis_sub vis_card_ge_two from AdjacentCutFiveComponents189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp := (CutGraph (G:=G) a b).ConnectedComponent

theorem high_vertex_shallow_in_shore_of_order_at_most_seven (hc : G.Connected) (ab : a≠b)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    {C : Cmp (G:=G) (a:=a) (b:=b)} (small : (Shore C).card≤7)
    (large : 2≤(Shore C).card) {z : V} (zc : z∈Shore C) (high : 5≤G.degree z) :
    depth G a b z ≤ 2 := by
  classical
  by_contra! far
  have n1 : depth G a b z ≠ 1 := by omega
  have zDark : z∉Vis C := by
    intro h
    have port := (mem_filter.mp h).2
    have za : z≠a := fun e=>(shore_off C).1 (by simpa only [e] using zc)
    have zb : z≠b := fun e=>(shore_off C).2 (by simpa only [e] using zc)
    exact n1 (depth_eq_one_of_port hc za zb port)
  let D := Shore C \ Vis C
  have zm : z∈D := mem_sdiff.mpr ⟨zc,zDark⟩
  have sub : G.neighborFinset z ⊆ D.erase z := by
    intro w wm
    have m := mem_erase.mp (dark_neighbors_in_shore hc zc n1 wm)
    apply mem_erase.mpr
    refine ⟨m.1,mem_sdiff.mpr ⟨m.2,?_⟩⟩
    intro h
    have p := (mem_filter.mp h).2
    have wa : w≠a := fun e=>(shore_off C).1 (by simpa only [e] using m.2)
    have wb : w≠b := fun e=>(shore_off C).2 (by simpa only [e] using m.2)
    have on := depth_eq_one_of_port hc wa wb p
    have le := depth_step (a:=a) (b:=b) hc ((mem_neighborFinset G z w).mp wm)
    omega
  have d := card_sdiff_add_card_eq_card (vis_sub C)
  change D.card + (Vis C).card = (Shore C).card at d
  have v := vis_card_ge_two ab conn C large
  have e := card_erase_add_one zm
  have le := card_le_card sub
  rw [card_neighborFinset_eq_degree] at le
  omega

theorem all_high_order_five_shore_all_visible (hc : G.Connected)
    {C : Cmp (G:=G) (a:=a) (b:=b)} (small : (Shore C).card≤5)
    (high : ∀ z∈Shore C,5≤G.degree z) :
    Vis C = Shore C := by
  classical
  apply subset_antisymm (vis_sub C)
  intro z zc
  by_cases p : G.Adj a z ∨ G.Adj b z
  · exact mem_filter.mpr ⟨zc,p⟩
  · have za : z≠a := fun e=>(shore_off C).1 (by simpa only [e] using zc)
    have zb : z≠b := fun e=>(shore_off C).2 (by simpa only [e] using zc)
    push_neg at p
    have da := hc.one_lt_dist_of_ne_of_not_adj za.symm p.1
    have db := hc.one_lt_dist_of_ne_of_not_adj zb.symm p.2
    have n1 : depth G a b z ≠ 1 := by unfold depth; omega
    have cnt := card_le_card (dark_neighbors_in_shore hc zc n1)
    have c := card_erase_add_one zc
    have h := high z zc
    rw [card_neighborFinset_eq_degree] at cnt
    omega

theorem exists_high_shallow_shore_of_three (hc : G.Connected)
    (ab : G.Adj a b) (even : ∀ x,(EvenFrom G x).card ≤ 6)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    (degree : ∀ x y : V,x≠y → 5≤G.degree x ∨ 5≤G.degree y)
    (three : Nat.card (CutGraph (G := G) a b).ConnectedComponent = 3) :
    ∃ C : Cmp (G:=G) (a:=a) (b:=b),
      5≤(Shore C).card ∧ (Shore C).card≤7 ∧
      ∀ z∈Shore C, 5≤G.degree z ∧ depth G a b z ≤ 2 := by
  obtain ⟨C,lo,hi,high⟩ := exists_high_shore_five_to_seven_of_three_at_adjacent_cut hc ab even conn degree three
  exact ⟨C,lo,hi,fun z zc=>⟨high z zc,high_vertex_shallow_in_shore_of_order_at_most_seven hc
    ab.ne conn hi (by omega) zc (high z zc)⟩⟩

#print axioms high_vertex_shallow_in_shore_of_order_at_most_seven
#print axioms all_high_order_five_shore_all_visible
#print axioms exists_high_shallow_shore_of_three
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
