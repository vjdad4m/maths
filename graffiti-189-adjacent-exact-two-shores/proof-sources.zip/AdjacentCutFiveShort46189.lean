import AdjacentCutFiveSmallSeconds189
namespace Graffiti189AdjacentThreeProfile
set_option maxRecDepth 1000000 in
set_option maxHeartbeats 60000000 in
theorem short46 : shortTest 4 6 6 = true := by rfl
#print axioms short46
end Graffiti189AdjacentThreeProfile
