import AdjacentCutFiveSmallSeconds189
namespace Graffiti189AdjacentThreeProfile
set_option maxRecDepth 1000000 in
set_option maxHeartbeats 60000000 in
theorem short47 : shortTest 4 7 7 = true := by rfl
#print axioms short47
end Graffiti189AdjacentThreeProfile
