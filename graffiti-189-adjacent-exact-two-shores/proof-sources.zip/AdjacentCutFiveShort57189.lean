import AdjacentCutFiveSmallSeconds189
namespace Graffiti189AdjacentThreeProfile

private def shortChunk (A : List Profile) (y z : ℕ) : Bool :=
  A.all (fun p =>
    (((shortSeconds 5 y p).filter (fun q => localGiven y q && pairGiven 5 y p q)).all fun q =>
      ((tailCandidates z (5-aCharge p-aCharge q) (5-bCharge p-bCharge q)).all
        fun r => !(tailOK p q r))))

private theorem glueChunk (A B : List Profile) (y z : ℕ)
    (a : shortChunk A y z=true) (b : shortChunk B y z=true) :
    shortChunk (A++B) y z=true := by
  simp only [shortChunk,List.all_append,Bool.and_eq_true] at a b ⊢
  exact ⟨a,b⟩

set_option maxRecDepth 1000000 in
set_option maxHeartbeats 60000000 in
private theorem b0 : shortChunk ((compressedFive.drop 0).take 7) 7 7=true := by rfl

set_option maxRecDepth 1000000 in
set_option maxHeartbeats 60000000 in
private theorem b7 : shortChunk ((compressedFive.drop 7).take 7) 7 7=true := by rfl

set_option maxRecDepth 1000000 in
set_option maxHeartbeats 60000000 in
private theorem b14 : shortChunk ((compressedFive.drop 14).take 7) 7 7=true := by rfl

set_option maxRecDepth 1000000 in
set_option maxHeartbeats 60000000 in
private theorem b21 : shortChunk ((compressedFive.drop 21).take 7) 7 7=true := by rfl

set_option maxRecDepth 1000000 in
set_option maxHeartbeats 60000000 in
private theorem b28 : shortChunk ((compressedFive.drop 28).take 7) 7 7=true := by rfl

set_option maxRecDepth 1000000 in
set_option maxHeartbeats 60000000 in
private theorem b35 : shortChunk ((compressedFive.drop 35).take 7) 7 7=true := by rfl

set_option maxRecDepth 1000000 in
set_option maxHeartbeats 60000000 in
private theorem b42 : shortChunk ((compressedFive.drop 42).take 7) 7 7=true := by rfl

set_option maxRecDepth 1000000 in
set_option maxHeartbeats 60000000 in
private theorem b49 : shortChunk ((compressedFive.drop 49).take 7) 7 7=true := by rfl

set_option maxRecDepth 1000000 in
set_option maxHeartbeats 60000000 in
private theorem b56 : shortChunk ((compressedFive.drop 56).take 7) 7 7=true := by rfl

set_option maxRecDepth 1000000 in
set_option maxHeartbeats 60000000 in
private theorem b63 : shortChunk ((compressedFive.drop 63).take 7) 7 7=true := by rfl

set_option maxRecDepth 1000000 in
set_option maxHeartbeats 60000000 in
private theorem b70 : shortChunk ((compressedFive.drop 70).take 7) 7 7=true := by rfl

set_option maxRecDepth 1000000 in
set_option maxHeartbeats 60000000 in
private theorem b77 : shortChunk ((compressedFive.drop 77).take 7) 7 7=true := by rfl

set_option maxRecDepth 1000000 in
set_option maxHeartbeats 10000000 in
theorem short57 : shortTest 5 7 7=true := by
  have parts : compressedFive = ((compressedFive.drop 0).take 7) ++ ((compressedFive.drop 7).take 7) ++ ((compressedFive.drop 14).take 7) ++ ((compressedFive.drop 21).take 7) ++ ((compressedFive.drop 28).take 7) ++ ((compressedFive.drop 35).take 7) ++ ((compressedFive.drop 42).take 7) ++ ((compressedFive.drop 49).take 7) ++ ((compressedFive.drop 56).take 7) ++ ((compressedFive.drop 63).take 7) ++ ((compressedFive.drop 70).take 7) ++ ((compressedFive.drop 77).take 7) := by rfl
  change shortChunk compressedFive 7 7=true
  have c70 := glueChunk ((compressedFive.drop 70).take 7) (((compressedFive.drop 77).take 7)) 7 7 b70 b77
  have c63 := glueChunk ((compressedFive.drop 63).take 7) (((compressedFive.drop 70).take 7) ++ ((compressedFive.drop 77).take 7)) 7 7 b63 c70
  have c56 := glueChunk ((compressedFive.drop 56).take 7) (((compressedFive.drop 63).take 7) ++ ((compressedFive.drop 70).take 7) ++ ((compressedFive.drop 77).take 7)) 7 7 b56 c63
  have c49 := glueChunk ((compressedFive.drop 49).take 7) (((compressedFive.drop 56).take 7) ++ ((compressedFive.drop 63).take 7) ++ ((compressedFive.drop 70).take 7) ++ ((compressedFive.drop 77).take 7)) 7 7 b49 c56
  have c42 := glueChunk ((compressedFive.drop 42).take 7) (((compressedFive.drop 49).take 7) ++ ((compressedFive.drop 56).take 7) ++ ((compressedFive.drop 63).take 7) ++ ((compressedFive.drop 70).take 7) ++ ((compressedFive.drop 77).take 7)) 7 7 b42 c49
  have c35 := glueChunk ((compressedFive.drop 35).take 7) (((compressedFive.drop 42).take 7) ++ ((compressedFive.drop 49).take 7) ++ ((compressedFive.drop 56).take 7) ++ ((compressedFive.drop 63).take 7) ++ ((compressedFive.drop 70).take 7) ++ ((compressedFive.drop 77).take 7)) 7 7 b35 c42
  have c28 := glueChunk ((compressedFive.drop 28).take 7) (((compressedFive.drop 35).take 7) ++ ((compressedFive.drop 42).take 7) ++ ((compressedFive.drop 49).take 7) ++ ((compressedFive.drop 56).take 7) ++ ((compressedFive.drop 63).take 7) ++ ((compressedFive.drop 70).take 7) ++ ((compressedFive.drop 77).take 7)) 7 7 b28 c35
  have c21 := glueChunk ((compressedFive.drop 21).take 7) (((compressedFive.drop 28).take 7) ++ ((compressedFive.drop 35).take 7) ++ ((compressedFive.drop 42).take 7) ++ ((compressedFive.drop 49).take 7) ++ ((compressedFive.drop 56).take 7) ++ ((compressedFive.drop 63).take 7) ++ ((compressedFive.drop 70).take 7) ++ ((compressedFive.drop 77).take 7)) 7 7 b21 c28
  have c14 := glueChunk ((compressedFive.drop 14).take 7) (((compressedFive.drop 21).take 7) ++ ((compressedFive.drop 28).take 7) ++ ((compressedFive.drop 35).take 7) ++ ((compressedFive.drop 42).take 7) ++ ((compressedFive.drop 49).take 7) ++ ((compressedFive.drop 56).take 7) ++ ((compressedFive.drop 63).take 7) ++ ((compressedFive.drop 70).take 7) ++ ((compressedFive.drop 77).take 7)) 7 7 b14 c21
  have c7 := glueChunk ((compressedFive.drop 7).take 7) (((compressedFive.drop 14).take 7) ++ ((compressedFive.drop 21).take 7) ++ ((compressedFive.drop 28).take 7) ++ ((compressedFive.drop 35).take 7) ++ ((compressedFive.drop 42).take 7) ++ ((compressedFive.drop 49).take 7) ++ ((compressedFive.drop 56).take 7) ++ ((compressedFive.drop 63).take 7) ++ ((compressedFive.drop 70).take 7) ++ ((compressedFive.drop 77).take 7)) 7 7 b7 c14
  have c0 := glueChunk ((compressedFive.drop 0).take 7) (((compressedFive.drop 7).take 7) ++ ((compressedFive.drop 14).take 7) ++ ((compressedFive.drop 21).take 7) ++ ((compressedFive.drop 28).take 7) ++ ((compressedFive.drop 35).take 7) ++ ((compressedFive.drop 42).take 7) ++ ((compressedFive.drop 49).take 7) ++ ((compressedFive.drop 56).take 7) ++ ((compressedFive.drop 63).take 7) ++ ((compressedFive.drop 70).take 7) ++ ((compressedFive.drop 77).take 7)) 7 7 b0 c7
  exact (congrArg (fun L=>shortChunk L 7 7) parts).trans c0

#print axioms short57
end Graffiti189AdjacentThreeProfile
