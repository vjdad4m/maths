import AdjacentCutFiveTinyHeads189

namespace Graffiti189AdjacentThreeProfile
open private upto upto_mem portPairs portPairs_mem from AdjacentCutFivePairCaps189
set_option linter.unnecessarySeqFocus false

private def triples (n : ℕ) : List (ℕ × ℕ × ℕ) :=
  (upto n).flatMap fun a=> (upto (n-a)).map fun b =>(a,b,n-a-b)

private theorem triple_mem {a b c n : ℕ} (e : a+b+c=n) : (a,b,c)∈triples n := by
  exact List.mem_flatMap.mpr ⟨a,upto_mem (by omega),
    List.mem_map.mpr ⟨b,upto_mem (by omega),by
      have h : n-a-b=c := by omega
      rw [h]⟩⟩

private theorem odd_dark_required (Q : Profile) (h : size Q≤7) (p : 2≤pn Q) :
    Q 3+Q 4+Q 5 ≤ lowRequired Q := by
  have d := size_eq_dn_add_pn Q
  have cap : dn Q-1<5 := by omega
  simp only [lowRequired,chargeBad,if_pos cap]
  omega

def shortSeconds (n m : ℕ) (P : Profile) : List Profile :=
  (portPairs m (5-aPort P) (5-bPort P)).flatMap fun (pa,pb,pc)=>
    let d := m-pa-pb-pc
    (upto (min d (1-lowGiven n P))).flatMap fun far=>
      (triples (d-far)).flatMap fun (ea,eb,ec)=>
        ((triples far).filter fun (oa,ob,_)=>
          decide (aCharge P+ea+ec+ob+pb≤5 ∧ bCharge P+eb+ec+oa+pa≤5)).map
          fun (oa,ob,oc)=>withPorts ⟨ea,eb,ec,oa,ob,oc⟩ pa pb pc

theorem mem_shortSeconds (P Q : Profile) (h7 : size Q≤7)
    (ok : localOK Q=true) (pair : pairOK P Q=true) :
    Q∈shortSeconds (size P) (size Q) P := by
  unfold localOK at ok
  obtain ⟨pn2,pa0,pb0,_,_,_,_,_,_⟩ := of_decide_eq_true ok
  simp only [pairOK,Bool.and_eq_true,and_assoc] at pair
  obtain ⟨low,ca,cb,ap,bp⟩ := of_decide_eq_true pair.1
  have part := size_eq_dn_add_pn Q
  have port : (Q 6,Q 7,Q 8)∈portPairs (size Q) (5-aPort P) (5-bPort P) :=
    portPairs_mem (by simp only [pn] at part; omega)
      (by simp only [aPort] at ap ⊢; omega) (by simp only [bPort] at bp ⊢; omega) pa0 pb0 pn2
  have far := odd_dark_required Q h7 pn2
  have len : dn Q = size Q-Q 6-Q 7-Q 8 := by
    simp only [pn] at part
    omega
  unfold shortSeconds
  apply List.mem_flatMap.mpr
  refine ⟨(Q 6,Q 7,Q 8),port,?_⟩
  dsimp only
  rw [←len,lowGiven_eq P rfl]
  refine List.mem_flatMap.mpr ⟨Q 3+Q 4+Q 5,upto_mem (by
    have d : Q 3+Q 4+Q 5 ≤ dn Q := by simp only [dn]; omega
    omega),?_⟩
  refine List.mem_flatMap.mpr ⟨(Q 0,Q 1,Q 2),triple_mem (by simp only [dn]; omega),?_⟩
  have a : aCharge P+Q 0+Q 2+Q 4+Q 7≤5 := by simp only [aCharge,ea,ec,ob] at ca ⊢; omega
  have b : bCharge P+Q 1+Q 2+Q 3+Q 6≤5 := by simp only [bCharge,eb,ec,oa] at cb ⊢; omega
  exact List.mem_map.mpr ⟨(Q 3,Q 4,Q 5),
    List.mem_filter.mpr ⟨triple_mem rfl,decide_eq_true ⟨a,b⟩⟩,withPorts_darkTotals Q⟩

def shortTest (x y z : ℕ) : Bool :=
  (tinyHeads x).all (fun p =>
    (((shortSeconds x y p).filter (fun q => localGiven y q && pairGiven x y p q)).all fun q =>
      ((tailCandidates z (5-aCharge p-aCharge q) (5-bCharge p-bCharge q)).all
        fun r => !(tailOK p q r))))

theorem sound_short_test (P Q : Profile) (R : Totals)
    (shape : size P=4 ∨ size P=5) (q7 : size Q≤7)
    (hp : localOK P=true) (hq : localOK Q=true) (pq : pairOK P Q=true)
    (ra : R.chargeA ≤ 5-aCharge P-aCharge Q)
    (rb : R.chargeB ≤ 5-bCharge P-bCharge Q)
    (test : shortTest (size P) (size Q) R.size = true) : tailOK P Q R=false := by
  unfold shortTest at test
  have h := List.all_eq_true.mp test P (mem_tinyHeads P shape hp)
  have qlocal := (localGiven_eq Q rfl).trans hq
  have pair := (pairGiven_eq P Q rfl rfl).trans pq
  have k := List.all_eq_true.mp h Q
    (List.mem_filter.mpr ⟨mem_shortSeconds P Q q7 hq pq,(by simp [qlocal,pair])⟩)
  have v := List.all_eq_true.mp k R (tail_mem R _ _ ra rb)
  simpa using v

#print axioms sound_short_test
end Graffiti189AdjacentThreeProfile
