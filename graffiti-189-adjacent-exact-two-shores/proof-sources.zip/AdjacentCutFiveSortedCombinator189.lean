import AdjacentCutFiveAnalyticHeads189
import AdjacentCutFiveTailMonotone189

namespace Graffiti189AdjacentThreeProfile
set_option maxHeartbeats 12000

private theorem possible_shapes (x y z : ℕ) (lo : 4≤x)
    (xy : x≤y) (yz : y≤z) (bound : x+y+z≤19) :
    (x=4 ∧ y=4) ∨ (x=4 ∧ y=5) ∨ (x=6 ∧ y=6) ∨ (x=5 ∧ y=5) ∨
      (x=4 ∧ y=6) ∨ (x=4 ∧ y=7) ∨ (x=5 ∧ y=6) ∨ (x=5 ∧ y=7) := by
  have xx : x=4 ∨ x=5 ∨ x=6 := by omega
  rcases xx with hx|hx|hx
  · have yy : y=4 ∨ y=5 ∨ y=6 ∨ y=7 := by omega
    rcases yy with hy|hy|hy|hy
    · exact .inl ⟨hx,hy⟩
    · exact .inr (.inl ⟨hx,hy⟩)
    · exact .inr (.inr (.inr (.inr (.inl ⟨hx,hy⟩))))
    · exact .inr (.inr (.inr (.inr (.inr (.inl ⟨hx,hy⟩)))))
  · have yy : y=5 ∨ y=6 ∨ y=7 := by omega
    rcases yy with hy|hy|hy
    · exact .inr (.inr (.inr (.inl ⟨hx,hy⟩)))
    · exact .inr (.inr (.inr (.inr (.inr (.inr (.inl ⟨hx,hy⟩))))))
    · exact .inr (.inr (.inr (.inr (.inr (.inr (.inr ⟨hx,hy⟩))))))
  · have hy : y=6 := by omega
    exact .inr (.inr (.inl ⟨hx,hy⟩))

private theorem small_second (x y z : ℕ) (lo : 4≤x)
    (_xy : x≤y) (yz : y≤z) (bound : x+y+z≤19) : y≤7 := by omega

theorem exact_sorted_arithmetic_from_checker
    (T : ℕ → ℕ → ℕ → Bool)
    (sound : ∀ (P Q : Profile) (R : Totals),
      (size P=4 ∨ size P=5) → size Q≤7 →
      localOK P=true → localOK Q=true → pairOK P Q=true →
      R.chargeA≤5-aCharge P-aCharge Q → R.chargeB≤5-bCharge P-bCharge Q →
      T (size P) (size Q) R.size=true → tailOK P Q R=false)
    (h46 : T 4 6 6=true) (h47 : T 4 7 7=true)
    (h56 : T 5 6 6=true) (h57 : T 5 7 7=true)
    (h55 : ∀ (P Q : Profile) (R : Totals), size P=5 → size Q=5 → R.size=5 →
      localOK P=true → localOK Q=true → pairOK P Q=true →
      R.chargeA≤5-aCharge P-aCharge Q → R.chargeB≤5-bCharge P-bCharge Q →
      tailOK P Q R=false)
    (P Q : Profile) (R : Totals)
    (lo : 4≤size P) (xy : size P≤size Q) (yz : size Q≤R.size)
    (sum : size P+size Q+R.size≤19)
    (hp : localOK P=true) (hq : localOK Q=true) (pq : pairOK P Q=true)
    (ra : R.chargeA ≤ 5-aCharge P-aCharge Q)
    (rb : R.chargeB ≤ 5-bCharge P-bCharge Q) :
    tailOK P Q R=false := by
  by_cases ok : tailOK P Q R=true
  · exfalso
    have odd : enoughOdd R=true := by
      simp only [tailOK,Bool.and_eq_true,and_assoc] at ok
      exact ok.1
    obtain ⟨L,sub,len,mOdd⟩ := resize_tail R odd (size Q) ((show 2≤4 by decide).trans (lo.trans xy)) yz
    have lA := sub.chargeA_le.trans ra
    have lB := sub.chargeB_le.trans rb
    have yes := tailOK_sub P Q sub mOdd ok
    have options := possible_shapes (size P) (size Q) R.size lo xy yz sum
    rcases options with ⟨p,q⟩|⟨p,q⟩|⟨p,q⟩|⟨p,q⟩|rem
    · exact impossible_heads_44 P Q p q hp hq pq
    · exact impossible_heads_45 P Q p q hp pq
    · exact impossible_heads_66 P Q p q hp hq pq
    · have impossible := h55 P Q L p q (len.trans q) hp hq pq lA lB
      exact Bool.noConfusion (yes.symm.trans impossible)
    have ps : size P=4 ∨ size P=5 := by
      rcases rem with l|l|l|l
      · exact .inl l.1
      · exact .inl l.1
      · exact .inr l.1
      · exact .inr l.1
    have q7 := small_second (size P) (size Q) R.size lo xy yz sum
    have test' : T (size P) (size Q) (size Q)=true := by
      rcases rem with ⟨p,q⟩|⟨p,q⟩|⟨p,q⟩|⟨p,q⟩
      · have eqp := congrArg (fun n=>T n (size Q) (size Q)) p
        have eqq := congrArg (fun n=>T 4 n n) q
        exact eqp.trans (eqq.trans h46)
      · have eqp := congrArg (fun n=>T n (size Q) (size Q)) p
        have eqq := congrArg (fun n=>T 4 n n) q
        exact eqp.trans (eqq.trans h47)
      · have eqp := congrArg (fun n=>T n (size Q) (size Q)) p
        have eqq := congrArg (fun n=>T 5 n n) q
        exact eqp.trans (eqq.trans h56)
      · have eqp := congrArg (fun n=>T n (size Q) (size Q)) p
        have eqq := congrArg (fun n=>T 5 n n) q
        exact eqp.trans (eqq.trans h57)
    have test : T (size P) (size Q) L.size=true :=
      (congrArg (fun n=>T (size P) (size Q) n) len).trans test'
    have impossible := sound P Q L ps q7 hp hq pq lA lB test
    exact Bool.noConfusion (yes.symm.trans impossible)

  · cases h : tailOK P Q R
    · rfl
    · exact (ok h).elim

#print axioms exact_sorted_arithmetic_from_checker
end Graffiti189AdjacentThreeProfile
