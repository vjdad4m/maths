import AdjacentCutFiveCompactArithmetic189

namespace Graffiti189AdjacentThreeProfile
set_option linter.unnecessarySeqFocus false

def Totals.Sub (X Y : Totals) : Prop :=
  X.ea≤Y.ea ∧ X.eb≤Y.eb ∧ X.ec≤Y.ec ∧ X.oa≤Y.oa ∧ X.ob≤Y.ob ∧ X.oc≤Y.oc

theorem Totals.Sub.trans {X Y Z : Totals} (h : X.Sub Y) (k : Y.Sub Z) : X.Sub Z := by
  unfold Totals.Sub at *
  omega

theorem Totals.Sub.refl (X : Totals) : X.Sub X := by simp [Totals.Sub]

theorem Totals.Sub.size_le {X Y : Totals} (h : X.Sub Y) : X.size≤Y.size := by
  unfold Totals.Sub Totals.size at *
  omega

theorem Totals.Sub.chargeA_le {X Y : Totals} (h : X.Sub Y) : X.chargeA≤Y.chargeA := by
  unfold Totals.Sub Totals.chargeA at *
  omega

theorem Totals.Sub.chargeB_le {X Y : Totals} (h : X.Sub Y) : X.chargeB≤Y.chargeB := by
  unfold Totals.Sub Totals.chargeB at *
  omega

private theorem smaller_step (L R : Totals) (h : L.Sub R) (lt : L.size<R.size) :
    ∃ M, L.Sub M ∧ M.Sub R ∧ M.size+1=R.size := by
  have diff : L.ea<R.ea ∨ L.eb<R.eb ∨ L.ec<R.ec ∨ L.oa<R.oa ∨ L.ob<R.ob ∨ L.oc<R.oc := by
    unfold Totals.Sub Totals.size at *
    omega
  rcases diff with d|d|d|d|d|d
  · refine ⟨{R with ea:=R.ea-1},?_,?_,?_⟩ <;> simp only [Totals.Sub,Totals.size] at h ⊢ <;> omega
  · refine ⟨{R with eb:=R.eb-1},?_,?_,?_⟩ <;> simp only [Totals.Sub,Totals.size] at h ⊢ <;> omega
  · refine ⟨{R with ec:=R.ec-1},?_,?_,?_⟩ <;> simp only [Totals.Sub,Totals.size] at h ⊢ <;> omega
  · refine ⟨{R with oa:=R.oa-1},?_,?_,?_⟩ <;> simp only [Totals.Sub,Totals.size] at h ⊢ <;> omega
  · refine ⟨{R with ob:=R.ob-1},?_,?_,?_⟩ <;> simp only [Totals.Sub,Totals.size] at h ⊢ <;> omega
  · refine ⟨{R with oc:=R.oc-1},?_,?_,?_⟩ <;> simp only [Totals.Sub,Totals.size] at h ⊢ <;> omega


private theorem intermediate (L R : Totals) (h : L.Sub R) (n : ℕ)
    (lo : L.size≤n) (hi : n≤R.size) :
    ∃ M, L.Sub M ∧ M.Sub R ∧ M.size=n := by
  by_cases same : n=R.size
  · exact ⟨R,h,Totals.Sub.refl R,same.symm⟩
  obtain ⟨R',hl,hr,e⟩ := smaller_step L R h (by omega)
  obtain ⟨M,h1,h2,hs⟩ := intermediate L R' hl n lo (by omega)
  exact ⟨M,h1,h2.trans hr,hs⟩
termination_by R.size
decreasing_by omega

private theorem core_two (R : Totals) (h : enoughOdd R=true) :
    ∃ L, L.Sub R ∧ L.size=2 ∧ enoughOdd L=true := by
  have k : 2≤R.oa+R.ob+R.oc ∧ 0<R.oa+R.oc ∧ 0<R.ob+R.oc := of_decide_eq_true h
  by_cases c2 : 2≤R.oc
  · refine ⟨⟨0,0,0,0,0,2⟩,?_,rfl,by decide⟩
    simp [Totals.Sub,c2]
  by_cases c1 : R.oc=1
  · by_cases a1 : 0<R.oa
    · refine ⟨⟨0,0,0,1,0,1⟩,?_,rfl,by decide⟩
      simp [Totals.Sub,c1,a1]; omega
    · have b1 : 0<R.ob := by omega
      refine ⟨⟨0,0,0,0,1,1⟩,?_,rfl,by decide⟩
      simp [Totals.Sub,c1,b1]; omega
  · have c0 : R.oc=0 := by omega
    obtain ⟨a1,b1⟩ : 0<R.oa ∧ 0<R.ob := by omega
    refine ⟨⟨0,0,0,1,1,0⟩,?_,rfl,by decide⟩
    simp [Totals.Sub,a1,b1]; omega

theorem resize_tail (R : Totals) (h : enoughOdd R=true) (n : ℕ)
    (lo : 2≤n) (hi : n≤R.size) : ∃ M, M.Sub R ∧ M.size=n ∧ enoughOdd M=true := by
  obtain ⟨L,hl,ls,lk⟩ := core_two R h
  obtain ⟨M,ml,mr,eq⟩ := intermediate L R hl n (by omega) hi
  have lk' : 2≤L.oa+L.ob+L.oc ∧ 0<L.oa+L.oc ∧ 0<L.ob+L.oc := of_decide_eq_true lk
  refine ⟨M,mr,eq,decide_eq_true ?_⟩
  unfold Totals.Sub at ml
  omega

private theorem rows_sub {X X' Y Y' : Totals} (xs : X'.Sub X) (ys : Y'.Sub Y)
    (h : rowsTotal X Y=true) : rowsTotal X' Y'=true := by
  unfold rowsTotal at h ⊢
  have e := of_decide_eq_true h
  apply decide_eq_true
  unfold Totals.Sub at xs ys
  refine ⟨?_,?_,?_,?_,?_,?_⟩
  · intro p; have z := e.1 (by omega : 0<X.ea); omega
  · intro p; have z := e.2.1 (by omega : 0<X.eb); omega
  · intro p; have z := e.2.2.1 (by omega : 0<X.ec); omega
  · intro p; have z := e.2.2.2.1 (by omega : 0<X.oa); omega
  · intro p; have z := e.2.2.2.2.1 (by omega : 0<X.ob); omega
  · intro p; have z := e.2.2.2.2.2 (by omega : 0<X.oc); omega


private theorem add_sub_right (Q : Totals) {X Y : Totals} (h : X.Sub Y) :
    (Q.add X).Sub (Q.add Y) := by
  unfold Totals.Sub Totals.add at *
  dsimp at *
  omega

theorem tailOK_sub (P Q : Profile) {R R' : Totals} (h : R'.Sub R)
    (en : enoughOdd R'=true) (ok : tailOK P Q R=true) : tailOK P Q R'=true := by
  have H : enoughOdd R = true ∧
      rowsTotal (summarize P) ((summarize Q).add R) = true ∧
      rowsTotal (summarize Q) ((summarize P).add R) = true ∧
      rowsTotal R ((summarize P).add (summarize Q)) = true := by
    simpa [tailOK,Bool.and_eq_true, and_assoc] using ok
  have r₁ := rows_sub (Totals.Sub.refl _) (add_sub_right (summarize Q) h) H.2.1
  have r₂ := rows_sub (Totals.Sub.refl _) (add_sub_right (summarize P) h) H.2.2.1
  have r₃ := rows_sub h (Totals.Sub.refl _) H.2.2.2
  simp [tailOK,en,r₁,r₂,r₃]

#print axioms resize_tail
#print axioms tailOK_sub
end Graffiti189AdjacentThreeProfile
