import AdjacentCutFiveProfileClose559189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph Finset
open scoped BigOperators
open Graffiti189AdjacentThreeProfile
open private CutGraph Shore shore_nonempty from AdjacentCutFiveActual189
open private degree_le_shore_add_one shore_sum_budget from AdjacentCutFiveComponents189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
set_option linter.unnecessarySeqFocus false
private abbrev Cmp := (CutGraph (G:=G) a b).ConnectedComponent

def SortedProfileExclusion : Prop :=
  ∀ (P Q : Profile) (R : Totals),
    4≤size P → size P≤size Q → size Q≤R.size → size P+size Q+R.size≤19 →
    localOK P=true → localOK Q=true → pairOK P Q=true →
    R.chargeA ≤ 5-aCharge P-aCharge Q →
    R.chargeB ≤ 5-bCharge P-bCharge Q →
    tailOK P Q R=false

private theorem impossible_sorted_actual_three_shores (arith : SortedProfileExclusion) (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ x,(EvenFrom G x).card≤6)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    {C D E : Cmp (G:=G) (a:=a) (b:=b)} (cd : C≠D) (ce : C≠E) (de : D≠E)
    (lo : 4≤(Shore C).card) (lr : (Shore C).card ≤ (Shore D).card)
    (rt : (Shore D).card ≤ (Shore E).card)
    (sum : (Shore C).card + (Shore D).card + (Shore E).card≤19) : False := by
  have hp := localOK_actual_three_shore hc ab even conn degree cd ce de (by omega) (by omega) (by omega)
  have hq := localOK_actual_three_shore hc ab even conn degree cd.symm de ce (by omega) (by omega) (by omega)
  have hpair := pairOK_actual_three_shores hc ab even conn degree cd ce de
  obtain ⟨ra,rb⟩ := compact_profile_residual_charges hc ab even cd ce de
  have cs := countProfile_size C
  have ds := countProfile_size D
  have es := (summarize_size (countProfile E)).trans (countProfile_size E)
  have no := arith (countProfile C) (countProfile D) (summarize (countProfile E))
    (by omega) (by omega) (by omega) (by omega) hp hq hpair ra rb
  have yes := tailOK_of_three_actual_shores hc ab even conn cd ce de (by omega)
  simp [yes] at no

/-- Under the degree-five threshold, an actual adjacent separating pair
cannot leave exactly three components. -/
theorem three_components_impossible_at_adjacent_cut_of_profile_exclusion (arith : SortedProfileExclusion) (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ x,(EvenFrom G x).card ≤ 6)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    (degree : ∀ x y : V,x≠y → 5≤G.degree x ∨ 5≤G.degree y)
    (three : Nat.card (CutGraph (G := G) a b).ConnectedComponent = 3) : False := by
  classical
  have size21 := order_le_twenty_one_of_actual_adjacent_cut hc ab even conn (by rw [three]; decide)
  have no_single := three_components_no_singleton_at_adjacent_cut hc ab even conn degree three
  let J := CutGraph (G:=G) a b
  haveI : Finite J.ConnectedComponent := Finite.of_surjective J.connectedComponentMk (fun c=>c.exists_rep)
  letI : Fintype J.ConnectedComponent := Fintype.ofFinite _
  change Nat.card J.ConnectedComponent=3 at three
  rw [Nat.card_eq_fintype_card] at three
  let U : Finset J.ConnectedComponent := univ
  have u3 : U.card=3 := by simpa [U]
  have Upos : U.Nonempty := card_pos.mp (by omega)
  obtain ⟨C,cu,minC⟩ := Finset.exists_min_image U (fun K=>(Shore K).card) Upos
  let T := U.erase C
  have t2 : T.card=2 := by have q := card_erase_add_one cu; dsimp [T]; omega
  obtain ⟨D,E,de,tEq⟩ := card_eq_two.mp t2
  have dt : D∈T := by simp [tEq]
  have et : E∈T := by simp [tEq]
  have cd : C≠D := (mem_erase.mp dt).1.symm
  have ce : C≠E := (mem_erase.mp et).1.symm
  have cl := minC D (mem_erase.mp dt).2
  have cr := minC E (mem_erase.mp et).2
  have budget := shore_sum_budget ab.ne U
  rw [←sum_erase_add U (fun K=>(Shore K).card) cu] at budget
  change (∑ K∈T,(Shore K).card) + (Shore C).card + 2 ≤ Fintype.card V at budget
  rw [tEq] at budget
  simp [sum_insert,de] at budget
  have c4 : 4≤(Shore C).card := by
    obtain ⟨x,xc⟩ := shore_nonempty C
    have p := card_pos.mpr (shore_nonempty C)
    have n := no_single C
    have k := card_erase_add_one xc
    obtain ⟨y,ym⟩ : ((Shore C).erase x).Nonempty := card_pos.mp (by omega)
    rcases degree y x (mem_erase.mp ym).1 with dy|dx
    · have q := degree_le_shore_add_one C (mem_erase.mp ym).2
      omega
    · have q := degree_le_shore_add_one C xc
      omega
  rcases le_total (Shore D).card (Shore E).card with dr|er
  · exact impossible_sorted_actual_three_shores arith hc ab even conn degree cd ce de c4 cl dr (by omega)
  · exact impossible_sorted_actual_three_shores arith hc ab even conn degree ce cd de.symm c4 cr er (by omega)

theorem component_card_le_two_at_adjacent_cut_of_profile_exclusion (arith : SortedProfileExclusion) (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ x,(EvenFrom G x).card ≤ 6)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    (degree : ∀ x y : V,x≠y → 5≤G.degree x ∨ 5≤G.degree y) :
    Nat.card (CutGraph (G := G) a b).ConnectedComponent≤2 := by
  have hi := component_card_le_three_at_adjacent_cut hc ab even conn degree
  by_contra! too
  exact three_components_impossible_at_adjacent_cut_of_profile_exclusion arith hc ab even conn degree (by omega)

#print axioms three_components_impossible_at_adjacent_cut_of_profile_exclusion
#print axioms component_card_le_two_at_adjacent_cut_of_profile_exclusion
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
