import AdjacentCutFivePairCaps189

namespace Graffiti189AdjacentThreeProfile
set_option linter.unnecessarySeqFocus false

def fourData : List Profile :=
  [withPorts ⟨0,0,1,0,0,0⟩ 0 0 3,
   withPorts ⟨0,0,0,0,0,1⟩ 0 0 3,
   withPorts ⟨0,0,0,0,0,0⟩ 1 0 3,
   withPorts ⟨0,0,0,0,0,0⟩ 0 1 3]

theorem four_mem (P : Profile) (sz : size P=4) (ok : localOK P=true) :
    P∈fourData := by
  have l := low_four_eq P sz
  unfold localOK at ok
  obtain ⟨_,_,_,la,lb,n4,lo,_,_⟩ := of_decide_eq_true ok
  have ne := n4 sz
  have p8 : P 8=3 := by omega
  have total := size_eq_dn_add_pn P
  simp only [dn,pn] at total
  have x0 : P 0=0 := by by_contra no; have x := la (by omega); omega
  have x1 : P 1=0 := by by_contra no; have x := lb (by omega); omega
  have x3 : P 3=0 := by by_contra no; have x := la (by omega); omega
  have x4 : P 4=0 := by by_contra no; have x := lb (by omega); omega
  have spl : P 2=1 ∨ P 5=1 ∨ P 6=1 ∨ P 7=1 := by omega
  rcases spl with h|h|h|h
  · have e : P=withPorts ⟨0,0,1,0,0,0⟩ 0 0 3 := by
      funext i
      have il := i.isLt
      have split : i.val=0 ∨ i.val=1 ∨ i.val=2 ∨ i.val=3 ∨ i.val=4 ∨
          i.val=5 ∨ i.val=6 ∨ i.val=7 ∨ i.val=8 := by omega
      rcases split with u|u|u|u|u|u|u|u|u
      · have eq : i=(0:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 0=0; omega
      · have eq : i=(1:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 1=0; omega
      · have eq : i=(2:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 2=1; omega
      · have eq : i=(3:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 3=0; omega
      · have eq : i=(4:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 4=0; omega
      · have eq : i=(5:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 5=0; omega
      · have eq : i=(6:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 6=0; omega
      · have eq : i=(7:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 7=0; omega
      · have eq : i=(8:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 8=3; omega
    rw [e]; simp [fourData]
  · have e : P=withPorts ⟨0,0,0,0,0,1⟩ 0 0 3 := by
      funext i
      have il := i.isLt
      have split : i.val=0 ∨ i.val=1 ∨ i.val=2 ∨ i.val=3 ∨ i.val=4 ∨
          i.val=5 ∨ i.val=6 ∨ i.val=7 ∨ i.val=8 := by omega
      rcases split with u|u|u|u|u|u|u|u|u
      · have eq : i=(0:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 0=0; omega
      · have eq : i=(1:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 1=0; omega
      · have eq : i=(2:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 2=0; omega
      · have eq : i=(3:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 3=0; omega
      · have eq : i=(4:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 4=0; omega
      · have eq : i=(5:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 5=1; omega
      · have eq : i=(6:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 6=0; omega
      · have eq : i=(7:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 7=0; omega
      · have eq : i=(8:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 8=3; omega
    rw [e]; simp [fourData]
  · have e : P=withPorts ⟨0,0,0,0,0,0⟩ 1 0 3 := by
      funext i
      have il := i.isLt
      have split : i.val=0 ∨ i.val=1 ∨ i.val=2 ∨ i.val=3 ∨ i.val=4 ∨
          i.val=5 ∨ i.val=6 ∨ i.val=7 ∨ i.val=8 := by omega
      rcases split with u|u|u|u|u|u|u|u|u
      · have eq : i=(0:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 0=0; omega
      · have eq : i=(1:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 1=0; omega
      · have eq : i=(2:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 2=0; omega
      · have eq : i=(3:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 3=0; omega
      · have eq : i=(4:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 4=0; omega
      · have eq : i=(5:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 5=0; omega
      · have eq : i=(6:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 6=1; omega
      · have eq : i=(7:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 7=0; omega
      · have eq : i=(8:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 8=3; omega
    rw [e]; simp [fourData]
  · have e : P=withPorts ⟨0,0,0,0,0,0⟩ 0 1 3 := by
      funext i
      have il := i.isLt
      have split : i.val=0 ∨ i.val=1 ∨ i.val=2 ∨ i.val=3 ∨ i.val=4 ∨
          i.val=5 ∨ i.val=6 ∨ i.val=7 ∨ i.val=8 := by omega
      rcases split with u|u|u|u|u|u|u|u|u
      · have eq : i=(0:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 0=0; omega
      · have eq : i=(1:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 1=0; omega
      · have eq : i=(2:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 2=0; omega
      · have eq : i=(3:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 3=0; omega
      · have eq : i=(4:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 4=0; omega
      · have eq : i=(5:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 5=0; omega
      · have eq : i=(6:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 6=0; omega
      · have eq : i=(7:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 7=1; omega
      · have eq : i=(8:Fin 9) := Fin.ext (by simpa only [Fin.val_ofNat'] using u)
        rw [eq]; change P 8=3; omega
    rw [e]; simp [fourData]


def tinyHeads (n : ℕ) : List Profile := if n=4 then fourData else compressedFive

theorem mem_tinyHeads (P : Profile) (shape : size P=4 ∨ size P=5) (ok : localOK P=true) :
    P∈tinyHeads (size P) := by
  rcases shape with h|h
  · simpa only [tinyHeads,h,if_true] using four_mem P h ok
  · simpa only [tinyHeads,h,show ¬(5:ℕ)=4 by decide,if_false] using mem_compressed_five P h ok

def tinyOrderedTest (x y z : ℕ) : Bool :=
  (tinyHeads x).all (fun p =>
    (((boundedSeconds y p).filter (fun q => localGiven y q && pairGiven x y p q)).all fun q =>
      ((tailCandidates z (5-aCharge p-aCharge q) (5-bCharge p-bCharge q)).all
        fun r => !(tailOK p q r))))

theorem sound_tiny_ordered (P Q : Profile) (R : Totals)
    (shape : size P=4 ∨ size P=5)
    (hp : localOK P=true) (hq : localOK Q=true) (pq : pairOK P Q=true)
    (ra : R.chargeA ≤ 5-aCharge P-aCharge Q)
    (rb : R.chargeB ≤ 5-bCharge P-bCharge Q)
    (test : tinyOrderedTest (size P) (size Q) R.size = true) : tailOK P Q R=false := by
  unfold tinyOrderedTest at test
  have h := List.all_eq_true.mp test P (mem_tinyHeads P shape hp)
  have qlocal := (localGiven_eq Q rfl).trans hq
  have pair := (pairGiven_eq P Q rfl rfl).trans pq
  have k := List.all_eq_true.mp h Q
    (List.mem_filter.mpr ⟨mem_boundedSeconds P Q hq pq,(by simp [qlocal,pair])⟩)
  have v := List.all_eq_true.mp k R (tail_mem R _ _ ra rb)
  simpa using v

#print axioms sound_tiny_ordered
end Graffiti189AdjacentThreeProfile
