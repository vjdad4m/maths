#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
sha256sum -c SHA256SUMS
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
export LEAN_PATH="$tmp${LEAN_PATH:+:$LEAN_PATH}"
repo="${GRAFF189_PREDECESSOR_REPO:-$(cd .. && pwd)}"
sep="$repo/graffiti-189/src/SmallSeparator189.lean"
cross="$repo/graffiti-189-cross-saturation/src/CrossSaturation189.lean"
printf 'fef1df0ef721e3981b12b0cc9da3b95d8dd75d6a405f6d06b2fddb10875b9d0a  %s
' "$sep" | sha256sum -c -
printf '8bbb3cd265373c2bca7b23bf7080e8b5f14c89dab7ccb40f73cf33873111230b  %s
' "$cross" | sha256sum -c -
lean --root="$(dirname "$sep")" -j1 -DElab.async=false -DwarningAsError=true -o "$tmp/SmallSeparator189.olean" "$sep"
lean --root="$(dirname "$cross")" -j1 -DElab.async=false -DwarningAsError=true -o "$tmp/CrossSaturation189.olean" "$cross"
for m in Bound Actual Components Asymmetry ThreeSingleton Minimal Metric SingletonDepth SingletonGeometry ThreeSingletonClose ThreeNonSingleton ThreeFourCommon ThreeShape ThreeTwins Profiles Shallow ProfilePorts ProfileDegree ProfileArithmetic CompactArithmetic Compact559 Compact559Certificate ProfileTags ProfileFibers ProfileBudgets ProfilePortCounts ProfileRows ProfileLow FourCommonProfile ProfileGlue ProfileClose559 ThreeReduction TailMonotone AnalyticHeads FastCore PairCaps TinyHeads SmallSeconds Short46 Short47 Compact555 Short56 Short57 SortedCombinator ThreeExactViaCombinator; do
  mod="AdjacentCutFive${m}189"
  lean --root="$PWD" -j1 -DElab.async=false -DwarningAsError=true -o "$tmp/$mod.olean" "$mod.lean"
done
