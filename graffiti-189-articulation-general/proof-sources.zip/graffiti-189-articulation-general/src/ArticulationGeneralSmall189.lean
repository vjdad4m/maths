import ArticulationGeneralPair189
import ArticulationClosure189

universe u
namespace Graffiti189LongestPath.CrossSaturation.ArticulationPair
open SimpleGraph SimpleGraph.Walk Finset
open private left_boundary' right_boundary' from ArticulationEight189
open private three_distinct_components from ArticulationSmall189
open private side_any_internal_neighbor from ArticulationClosure189
variable {V : Type u} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {c : V} (S : ArticulationPair G c)
set_option linter.unusedSectionVars false

theorem distinct_root_and_outlier_ports_general (hc : G.Connected) (n : ℕ) (n2 : 2≤n)
    (even : ∀ x, (EvenFrom G x).card≤n+1)
    (degree : ∀ u v : V,u≠v → n≤G.degree u ∨ n≤G.degree v)
    {z : V} (zl : z∈S.L) (cz : ¬G.Adj c z) (three : 3≤S.L.card) :
    ∃ u∈S.L, ∃ v∈S.L, u≠v ∧ G.Adj c u ∧ G.Adj z v := by
  classical
  obtain ⟨r,rl,cr⟩ := S.hitL
  have zv : ∃ v∈S.L,G.Adj z v := by
    obtain ⟨q⟩ := hc.preconnected z c
    cases q with
    | nil => exact (S.offL zl).elim
    | cons zv p =>
      rcases left_boundary' S zl zv with h|vl
      · exact (cz (h ▸ zv.symm)).elim
      · exact ⟨_,vl,zv⟩
  obtain ⟨v,vl,zv⟩ := zv
  apply Classical.byContradiction
  intro bad
  have eq : v=r := by
    apply Classical.byContradiction
    intro ne
    exact bad ⟨r,rl,v,vl,Ne.symm ne,cr,zv⟩
  subst v
  have soleC (u : V) (ul : u∈S.L) (cu : G.Adj c u) : u=r := by
    apply Classical.byContradiction
    intro ne
    exact bad ⟨u,ul,r,rl,ne,cu,zv⟩
  have soleZ (u : V) (zu : G.Adj z u) : u=r := by
    rcases left_boundary' S zl zu with h|ul
    · exact (cz (h ▸ zu.symm)).elim
    · apply Classical.byContradiction
      intro ne
      exact bad ⟨r,rl,u,ul,Ne.symm ne,cr,zu⟩
  have w_exists : ∃ w∈S.L,w≠z ∧ w≠r := by
    apply Classical.byContradiction
    intro no
    have sub : S.L ⊆ ({z,r} : Finset V) := by
      intro w wl
      by_cases ez : w=z
      · simp [ez]
      by_cases er : w=r
      · simp [er]
      exact (no ⟨w,wl,ez,er⟩).elim
    have h := card_le_card sub
    have b := card_insert_le z ({r} : Finset V)
    simp at b
    omega
  obtain ⟨w,wl,wz,wr⟩ := w_exists
  let T : Set V := {u | u≠r}
  let J := G.induce T
  let cc : T := ⟨c,cr.ne⟩
  let zz : T := ⟨z,zv.ne⟩
  let ww : T := ⟨w,wr⟩
  let A := insert c S.R
  have stay {u v : T} (p : J.Walk u v) :
      u.val∈A → v.val∈A := by
    induction p with
    | nil => exact id
    | @cons u y v uy q ih =>
      intro ua
      apply ih
      change G.Adj u.val y.val at uy
      rcases mem_insert.mp ua with uC|ur
      · have cy : G.Adj c y.val := uC ▸ uy
        rcases S.cover y.val with h|yl|yr
        · exact (cy.ne h.symm).elim
        · exact (y.property (soleC _ yl cy)).elim
        · exact mem_insert_of_mem yr
      · rcases right_boundary' S ur uy with h|yr
        · exact mem_insert.mpr (.inl h)
        · exact mem_insert_of_mem yr
  have zno (u : T) (uz : u.val≠z) : ¬J.Reachable zz u := by
    rintro ⟨p⟩
    have first {j k : T} (q : J.Walk j k) (jz : j.val=z) : k.val=z := by
      cases q with
      | nil => exact jz
      | @cons j v k jv q =>
        have e : G.Adj j.val v.val := jv
        exact (v.property (soleZ _ (jz ▸ e))).elim
    exact uz (first p rfl)
  have za : z≠c := fun e=>S.offL (e ▸ zl)
  have wa : w∉A := by
    intro h
    rcases mem_insert.mp h with e|wr'
    · exact S.offL (e ▸ wl)
    · exact disjoint_left.mp S.dis wl wr'
  have noCW : ¬J.Reachable cc ww := by
    rintro ⟨p⟩
    exact wa (stay p (mem_insert_self _ _))
  have threeC := three_distinct_components J zz cc ww (zno cc za.symm) (zno ww wz) noCW
  have cap := component_card_le_two_at_articulation_general hc r n n2 even degree
  change Nat.card J.ConnectedComponent≤2 at cap
  omega



theorem small_left_rooted_general (ore : RootedClosureAPI.{u})
    (hc : G.Connected) (n : ℕ) (n2 : 2≤n) (even : ∀ x, (EvenFrom G x).card≤n+1)
    (degree : ∀ u v : V,u≠v → n≤G.degree u ∨ n≤G.degree v)
    (small : S.L.card+1≤2*n) :
    ∃ y,∃ p : G.Walk c y,p.IsPath ∧ ∀ z,z∈p.support ↔ z=c ∨ z∈S.L := by
  classical
  obtain ⟨x,xl,cx⟩ := S.hitL
  by_cases single : S.L.card≤1
  · have eq : S.L={x} :=
      (eq_of_subset_of_card_le (singleton_subset_iff.mpr xl) (by simpa)).symm
    refine ⟨x,Walk.cons cx .nil,Walk.IsPath.cons (by simp) (by simpa using cx.ne),?_⟩
    intro z
    simp [eq,support_cons]
  by_cases two : S.L.card=2
  · obtain ⟨y,yl,xy⟩ := side_any_internal_neighbor S xl (by omega)
    have eq : ({x,y} : Finset V)=S.L := by
      apply eq_of_subset_of_card_le (insert_subset xl (singleton_subset_iff.mpr yl))
      rw [two]
      simp [xy.ne]
    have cy' : c≠y := fun e=>S.offL (e.symm ▸ yl)
    let q : G.Walk x y := Walk.cons xy .nil
    have qp : q.IsPath := Walk.IsPath.cons (by simp) (by simpa using xy.ne)
    have cn : c∉q.support := by simp [q,cx.ne,cy',support_cons]
    exact ⟨y,Walk.cons cx q,qp.cons cn,by intro z; simp [q,←eq,support_cons]⟩
  apply S.lift_rooted_with_articulation
  let F := insert c S.L
  let U := ↑(↑F : Set V)
  let J := G.induce (↑F : Set V)
  let root : U := ⟨c,mem_insert_self _ _⟩
  let A : Finset U := univ.filter fun z=> z.val∈S.L ∧ n≤G.degree z.val
  let K := completeWith J A
  change RootedSpan J root
  have ul : ∀ z : U, z≠root → z.val∈S.L := by
    intro z zr
    rcases mem_insert.mp z.property with e|h
    · exact (zr (Subtype.ext e)).elim
    · exact h
  have Fcard : Fintype.card U≤2*n := by
    change Fintype.card {v : V // v∈F} ≤ 2*n
    rw [Fintype.card_coe]
    have cc := card_insert_le c S.L
    change F.card≤2*n
    exact cc.trans (by omega)
  have ad (z : U) (za : z∈A) : n≤J.degree z := by
    obtain ⟨zl,dh⟩ := (mem_filter.mp za).2
    rw [S.left_degree_preserved z.val zl]
    exact dh
  apply close_completed_class ore A root (fun a ha b hb=>by
    have h1 := ad a ha
    have h2 := ad b hb
    omega)
  by_cases low : ∃ z∈S.L, ¬n≤G.degree z
  · obtain ⟨z,zl,zlow⟩ := low
    let zz : U := ⟨z,mem_insert_of_mem zl⟩
    have rzne : root≠zz := by
      intro e
      have h : c=z := congrArg Subtype.val e
      exact S.offL (h.symm ▸ zl)
    have hight (v : U) (vr : v≠root) (vz : v≠zz) : v∈A := by
      have vz' : v.val≠z := fun h=>vz (Subtype.ext h)
      exact mem_filter.mpr ⟨mem_univ _,ul v vr,(degree _ _ vz').resolve_right zlow⟩
    have clique : CompleteOn K ((univ.erase root).erase zz) := by
      intro v va w wa vw
      have vne := mem_erase.mp va
      have wne := mem_erase.mp wa
      exact completeWith_of_mem J A v (hight v (mem_erase.mp vne.2).1 vne.1)
        w (hight w (mem_erase.mp wne.2).1 wne.1) vw
    by_cases cz : G.Adj c z
    · obtain ⟨y,yl,zy⟩ := side_any_internal_neighbor S zl (by omega)
      let yy : U := ⟨y,mem_insert_of_mem yl⟩
      have yr : yy≠root := by
        intro e
        have h : y=c := congrArg Subtype.val e
        exact S.offL (h ▸ yl)
      exact rooted_path_through_outlier_into_clique K (completeWith_mono J A (show J.Adj root zz from cz))
        (completeWith_mono J A (show J.Adj zz yy from zy)) yr clique
    obtain ⟨v,vl,w,wl,vw,cv,zw⟩ := S.distinct_root_and_outlier_ports_general hc n n2 even degree zl cz (by omega)
    let vv : U := ⟨v,mem_insert_of_mem vl⟩
    let ww : U := ⟨w,mem_insert_of_mem wl⟩
    have vz : vv≠zz := by
      intro e
      have h : v=z := congrArg Subtype.val e
      exact cz (h ▸ cv)
    have wr : ww≠root := by
      intro e
      have h : w=c := congrArg Subtype.val e
      exact S.offL (h ▸ wl)
    have vvww : vv≠ww := fun h=>vw (congrArg Subtype.val h)
    exact rooted_path_from_clique_to_outlier K
      (completeWith_mono J A (show J.Adj root vv from cv))
      (completeWith_mono J A (show J.Adj ww zz from zw.symm)) rzne vz wr vvww clique
  have clique : CompleteOn K (univ.erase root) := by
    intro v va w wa vw
    have mem (o : U) (om : o∈(univ : Finset U).erase root) : o∈A := by
      have ol := ul o (mem_erase.mp om).1
      have oh : n≤G.degree o.val := Classical.byContradiction (fun neg=>low ⟨o.val,ol,neg⟩)
      exact mem_filter.mpr ⟨mem_univ _,ol,oh⟩
    exact completeWith_of_mem J A _ (mem v va) _ (mem w wa) vw
  let xx : U := ⟨x,mem_insert_of_mem xl⟩
  exact rooted_path_from_root_into_clique K (completeWith_mono J A (show J.Adj root xx from cx)) clique


#print axioms small_left_rooted_general
end Graffiti189LongestPath.CrossSaturation.ArticulationPair
