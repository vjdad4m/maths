import SmallTightTreeBag189

open Finset SimpleGraph
open scoped BigOperators
open private Graffiti189LongestPath.TreeBagTight.side_capacity_of_two_tight
  Graffiti189LongestPath.TreeBagTight.choose_low from TreeBagTight189
namespace Graffiti189LongestPath.TreeBagTight
open WeightedTreeSums TreeBagArithmetic TreeBagCapacity BagQuotient

variable {U : Type*} [Fintype U] [DecidableEq U]
  {B : SimpleGraph U} [DecidableRel B.Adj] {d : ℕ} {w : U→ℕ} {c : U→Bool}

private theorem ordinary_large_tight_bounds (h : System B d w c) (x : U)
    (tight : w x<B.degree x) (all : Ordinary B d w x) (large : 3≤w x) :
    d≤B.degree x ∧ mass w c (!c x)≤d+1 := by
  have up := degree_le_capacity_add_one h x
  have q : B.degree x=w x+1 := by omega
  obtain ⟨b,finance⟩ := all_high_finance h x all
  have qI : (B.degree x:ℤ)=(w x:ℤ)+1 := by exact_mod_cast q
  rw [qI] at b finance
  let A : ℤ := (WeightedTreeSums.mass w c (c x):ℤ)-(d:ℤ)
  let D : ℤ := (WeightedTreeSums.mass w c (!c x):ℤ)-(d:ℤ)
  change ((w x:ℤ)+1-1)*D≤(d:ℤ) at b
  change ((w x:ℤ)+1)*((d:ℤ)+1-(w x:ℤ))≤2*(d:ℤ)+A+D-(w x:ℤ) at finance
  have bb : (w x:ℤ)*D≤(d:ℤ) := by simpa only [add_sub_cancel_right] using b
  have a : A≤(w x:ℤ) := by
    have h := h.parity x
    dsimp [A]
    omega
  have largeI : (3:ℤ)≤(w x:ℤ) := by exact_mod_cast large
  have z := ordinary_tight_size (w x:ℤ) (d:ℤ) A D largeI a bb finance
  dsimp [D] at z
  omega

/-- For d≥5, the weighted quotient still has at most two tight nodes.
The exact d=6 small-center case is dispatched first. -/
theorem card_tight_degree_ge_five (h : System B d w c) (d5 : 5≤d) :
    (univ.filter (fun i => w i<B.degree i)).card≤2 := by
  classical
  let S := univ.filter (fun i => w i<B.degree i)
  by_cases small : ∃ x∈S,w x=2 ∧ Ordinary B d w x
  · obtain ⟨x,xS,wx,ord⟩ := small
    have out := small_ordinary_tight h d5 x (mem_filter.mp xS).2 wx ord
    have sub : S⊆{x} := by
      intro y yS
      apply mem_singleton.mpr
      apply Classical.byContradiction
      intro ne
      have p := out.2 y ne
      have q := (mem_filter.mp yS).2
      omega
    have n := card_le_card sub
    simp only [card_singleton] at n
    exact n.trans (by decide)
  · have large (x : U) (xt : w x<B.degree x) (xo : Ordinary B d w x) : 3≤w x := by
      have p := h.internal x (by have z := h.positivity x; omega)
      have no : w x≠2 := fun eq => small ⟨x,mem_filter.mpr ⟨mem_univ _,xt⟩,eq,xo⟩
      omega
    have inj (x y : U) (xt : w x<B.degree x) (yt : w y<B.degree y) (same : c x=c y) : x=y := by
      apply Classical.byContradiction
      intro ne
      have both := Graffiti189LongestPath.TreeBagTight.side_capacity_of_two_tight h ne same
      by_cases xO : Ordinary B d w x
      · have ⟨l,up⟩ := ordinary_large_tight_bounds h x xt xO (large x xt xO)
        have y3 := tight_degree_three h y yt
        omega
      by_cases yO : Ordinary B d w y
      · have ⟨l,up⟩ := ordinary_large_tight_bounds h y yt yO (large y yt yO)
        have x3 := tight_degree_three h x xt
        rw [←same] at up
        omega
      obtain ⟨u,xu,ulo⟩ := Graffiti189LongestPath.TreeBagTight.choose_low xO
      obtain ⟨v,yv,vlo⟩ := Graffiti189LongestPath.TreeBagTight.choose_low yO
      have uv : u=v := Classical.byContradiction (fun hn => (h.exceptional u v hn).elim ulo vlo)
      subst v
      have a : x∈B.neighborFinset u :=
        (B.mem_neighborFinset _ _).mpr ((B.mem_neighborFinset _ _).mp xu).symm
      have b : y∈B.neighborFinset u :=
        (B.mem_neighborFinset _ _).mpr ((B.mem_neighborFinset _ _).mp yv).symm
      have n := one_lt_card.mpr ⟨x,a,y,b,ne⟩
      rw [B.card_neighborFinset_eq_degree] at n
      have uBig := h.internal u (by omega)
      have uSmall := h.singleton_low u ulo
      omega
    have he : (S.image c).card=S.card := card_image_of_injOn (fun i hi j hj e =>
      inj i j (mem_filter.mp hi).2 (mem_filter.mp hj).2 e)
    have z := card_le_univ (s:=S.image c)
    rw [he] at z
    exact z

#print axioms card_tight_degree_ge_five
end Graffiti189LongestPath.TreeBagTight
