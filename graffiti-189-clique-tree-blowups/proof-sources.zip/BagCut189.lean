import BagQuotient189
import Mathlib.Combinatorics.SimpleGraph.Acyclic

open Finset SimpleGraph SimpleGraph.Walk
namespace Graffiti189LongestPath.BagQuotient
variable {U V : Type*} [Fintype U] [Fintype V] [DecidableEq U] [DecidableEq V]
  {B : SimpleGraph U} {G : SimpleGraph V} [DecidableRel B.Adj]

omit [Fintype U] [DecidableEq U] [DecidableRel B.Adj] in
private theorem two_edge_path {i j k : U} (ij : B.Adj i j) (jk : B.Adj j k) (ik : i≠k) :
    (Walk.cons ij jk.toWalk).IsPath := by
  rw [cons_isPath_iff]
  exact ⟨by simp [SimpleGraph.Adj.toWalk,jk.ne],by simp [SimpleGraph.Adj.toWalk,ij.ne,ik]⟩

omit [Fintype U] [DecidableEq U] [DecidableRel B.Adj] in
/-- In a tree any two vertices share at most one neighbor. -/
theorem common_neighbor_unique (tree : B.IsTree) {i j x y : U} (ij : i≠j)
    (ix : B.Adj i x) (jx : B.Adj j x) (iy : B.Adj i y) (jy : B.Adj j y) : x=y := by
  have a := two_edge_path (B:=B) ix jx.symm ij
  have b := two_edge_path (B:=B) iy jy.symm ij
  have eq := tree.IsAcyclic.path_unique ⟨_,a⟩ ⟨_,b⟩
  exact congrArg (fun p : B.Path i j => p.val.getVert 1) eq

omit [DecidableEq V] in
/-- A one-vertex internal tree bag is an articulation vertex in the
blow-up. -/
theorem disconnected_at_singleton_internal_bag {f : V→U} (M : Model B G f) (tree : B.IsTree)
    (i : U) (internal : 2≤B.degree i) (u : V) (ui : f u=i) (sing : (bag f i).card=1) :
    ¬(G.induce {z : V | z≠u}).Connected := by
  classical
  have bu : u∈bag f i := (mem_bag f i u).mpr ui
  have single : bag f i={u} :=
    (eq_of_subset_of_card_le (singleton_subset_iff.mpr bu) (by simp [sing])).symm
  rw [←B.card_neighborFinset_eq_degree] at internal
  obtain ⟨j,jN,k,kN,jk⟩ := one_lt_card.mp (show 1<(B.neighborFinset i).card by omega)
  have ij := (B.mem_neighborFinset _ _).mp jN
  have ik := (B.mem_neighborFinset _ _).mp kN
  obtain ⟨a,aj⟩ := M.onto j
  obtain ⟨b,bk⟩ := M.onto k
  let a' : {z : V | z≠u} := ⟨a,fun e => ij.ne (ui.symm.trans ((congrArg f e).symm.trans aj))⟩
  let b' : {z : V | z≠u} := ⟨b,fun e => ik.ne (ui.symm.trans ((congrArg f e).symm.trans bk))⟩
  intro connects
  obtain ⟨p⟩ := connects a' b'
  let q : G.Walk a b := p.map (SimpleGraph.Embedding.induce {z : V | z≠u}).toHom
  have noU : u∉q.support := by
    intro h
    change u∈(p.map _).support at h
    rw [support_map] at h
    obtain ⟨v,_,vu⟩ := List.mem_map.mp h
    exact v.property vu
  obtain ⟨route,_,map⟩ := M.project_walk q
  have noI : i∉route.support := by
    intro h
    obtain ⟨v,vq,vi⟩ := map i h
    have bv := (mem_bag f i v).mpr vi
    rw [single] at bv
    exact noU ((mem_singleton.mp bv) ▸ vq)
  let r := route.bypass.copy aj bk
  let s : B.Walk j k := .cons ij.symm ik.toWalk
  have rp : r.IsPath := by
    unfold r
    apply (isPath_copy _ _ _).mpr
    exact route.bypass_isPath
  have sp : s.IsPath := two_edge_path ij.symm ik jk
  have eq : r=s := congrArg Subtype.val (tree.IsAcyclic.path_unique ⟨r,rp⟩ ⟨s,sp⟩)
  have m : i∈s.support := by simp [s,SimpleGraph.Adj.toWalk]
  rw [←eq,support_copy] at m
  exact noI (support_bypass_subset route m)

#print axioms common_neighbor_unique
#print axioms disconnected_at_singleton_internal_bag
end Graffiti189LongestPath.BagQuotient
