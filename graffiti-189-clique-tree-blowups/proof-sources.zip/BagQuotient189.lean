import SmallSeparator189
import Mathlib.Algebra.BigOperators.Ring.Finset

open Finset SimpleGraph SimpleGraph.Walk
open scoped BigOperators
namespace Graffiti189LongestPath.BagQuotient
variable {U V : Type*} {B : SimpleGraph U} {G : SimpleGraph V}

/-- Every quotient edge is completely joined and each fiber is a clique. -/
structure Model (B : SimpleGraph U) (G : SimpleGraph V) (f : V→U) : Prop where
  onto : Function.Surjective f
  exact_edge : ∀ u v,G.Adj u v ↔ (f u=f v ∧ u≠v) ∨ B.Adj (f u) (f v)

theorem Model.project_walk {f : V→U} (M : Model B G f) {u v : V} (p : G.Walk u v) :
    ∃ q : B.Walk (f u) (f v),q.length≤p.length ∧
      ∀ x∈q.support,∃ z∈p.support,f z=x := by
  induction p with
  | @nil u =>
    exact ⟨.nil,le_rfl,fun x h => ⟨u,by simp,by simpa [eq_comm] using h⟩⟩
  | @cons u a v ua p ih =>
    obtain ⟨q,hq,sq⟩ := ih
    rcases (M.exact_edge u a).mp ua with ⟨equal,_⟩|g
    · refine ⟨q.copy equal.symm rfl,?_ ,?_⟩
      · simpa only [length_copy,length_cons] using (hq.trans (Nat.le_succ _))
      · intro x xx
        rw [support_copy] at xx
        obtain ⟨z,zp,zz⟩ := sq x xx
        exact ⟨z,List.mem_cons_of_mem _ zp,zz⟩
    · refine ⟨.cons g q,by simpa only [length_cons] using (Nat.succ_le_succ hq),?_⟩
      intro x xx
      rcases List.mem_cons.mp xx with ex|xs
      · exact ⟨u,by simp,ex.symm⟩
      · obtain ⟨z,zp,zz⟩ := sq x xs
        exact ⟨z,List.mem_cons_of_mem _ zp,zz⟩

theorem Model.lift_walk_length {f : V→U} (M : Model B G f)
    {a b : U} (q : B.Walk a b) :
    ∀ u v : V,f u=a → f v=b →
      ∃ p : G.Walk u v,p.length≤max 1 q.length := by
  induction q with
  | @nil a =>
    intro u v hu hv
    by_cases e : u=v
    · subst v; exact ⟨.nil,by simp⟩
    · have adj := (M.exact_edge u v).mpr (Or.inl ⟨hu.trans hv.symm,e⟩)
      exact ⟨adj.toWalk,by simp [SimpleGraph.Adj.toWalk]⟩
  | @cons a c b ac q ih =>
    intro u v hu hv
    cases q with
    | nil =>
      have adj := (M.exact_edge u v).mpr (Or.inr (by rwa [hu,hv]))
      exact ⟨adj.toWalk,by simp [SimpleGraph.Adj.toWalk]⟩
    | @cons c r b cr q =>
      obtain ⟨x,hx⟩ := M.onto c
      obtain ⟨p,hp⟩ := ih x v hx hv
      have adj := (M.exact_edge u x).mpr (Or.inr (by rwa [hu,hx]))
      refine ⟨.cons adj p,?_⟩
      simp only [length_cons] at hp ⊢
      omega

/-- Distinct bags have exactly the same metric as the quotient. -/
theorem Model.dist_eq {f : V→U} (M : Model B G f) (hc : G.Connected) (bc : B.Connected)
    (u v : V) (ne : f u≠f v) : G.dist u v=B.dist (f u) (f v) := by
  apply Nat.le_antisymm
  · obtain ⟨q,hq⟩ := bc.exists_walk_length_eq_dist (f u) (f v)
    obtain ⟨p,hp⟩ := M.lift_walk_length q u v rfl rfl
    have w : 1≤q.length := by
      have nl : ¬q.Nil := not_nil_of_ne ne
      exact Nat.succ_le_of_lt (not_nil_iff_lt_length.mp nl)
    rw [max_eq_right w] at hp
    exact (G.dist_le p).trans (hp.trans_eq hq)
  · obtain ⟨p,hp⟩ := hc.exists_walk_length_eq_dist u v
    obtain ⟨q,hq,_⟩ := M.project_walk p
    exact (B.dist_le q).trans (hq.trans_eq hp)

variable [Fintype V] [DecidableEq V] [DecidableEq U]
def bag (f : V→U) (i : U) : Finset V := univ.filter (fun x => f x=i)

omit [DecidableEq V] in
@[simp] theorem mem_bag (f : V→U) (i : U) (u : V) :
    u∈bag f i ↔ f u=i := by simp [bag]

omit [DecidableEq V] in
theorem bag_pairwise (f : V→U) : Pairwise (fun i j => Disjoint (bag f i) (bag f j)) :=
  fun i j ne => disjoint_left.mpr (fun u hi hj =>
    ne (((mem_bag f i u).mp hi).symm.trans ((mem_bag f j u).mp hj)))

omit [DecidableEq V] in
theorem Model.bag_nonempty {f : V→U} (M : Model B G f) (i : U) :
    (bag f i).Nonempty := by
  obtain ⟨u,hu⟩ := M.onto i
  exact ⟨u,(mem_bag f i u).mpr hu⟩

variable [Fintype U] [DecidableRel B.Adj] [DecidableRel G.Adj]

/-- Quotient neighbor masses plus the own bag give one plus the degree. -/
theorem Model.degree_succ {f : V→U} (M : Model B G f) (u : V) :
    G.degree u+1=(bag f (f u)).card+∑ i∈B.neighborFinset (f u),(bag f i).card := by
  classical
  have e : insert u (G.neighborFinset u)=
      (insert (f u) (B.neighborFinset (f u))).biUnion (bag f) := by
    ext v
    simp only [mem_insert,mem_neighborFinset,mem_biUnion,mem_bag]
    constructor
    · rintro (eq|uv)
      · exact ⟨f u,Or.inl rfl,congrArg f eq⟩
      · rcases (M.exact_edge u v).mp uv with ⟨g,_⟩|g
        · exact ⟨f u,Or.inl rfl,g.symm⟩
        · exact ⟨f v,Or.inr g,rfl⟩
    · rintro ⟨i,(h|h),vi⟩
      · by_cases e : v=u
        · exact Or.inl e
        · exact Or.inr ((M.exact_edge u v).mpr (Or.inl ⟨(vi.trans h).symm,Ne.symm e⟩))
      · exact Or.inr ((M.exact_edge u v).mpr (Or.inr (vi.symm ▸ h)))
  have e' := congrArg Finset.card e
  rw [card_insert_of_not_mem (by simp),G.card_neighborFinset_eq_degree,
    card_biUnion (fun i _ j _ ne => bag_pairwise f ne),
    Finset.sum_insert (by simp)] at e'
  exact e'

#print axioms Model.project_walk
#print axioms Model.dist_eq
#print axioms Model.degree_succ
end Graffiti189LongestPath.BagQuotient
