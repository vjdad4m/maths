import SpineWalk189
import BagWalkLift189

open Finset SimpleGraph SimpleGraph.Walk
namespace Graffiti189LongestPath.BagSpineCriterion
open SpineWalk BagWalkLift

variable {U V : Type*} [Fintype U] [DecidableEq U] [DecidableEq V] [Nonempty V]
  {B : SimpleGraph U} {G : SimpleGraph V} [DecidableRel B.Adj]

/-- A spine that passes internally through every tight quotient vertex
is a sufficient certificate for a Hamilton path through clique bags. -/
theorem traceable_of_bag_capacity_spine (hc : B.Connected)
    {a b : U} (ne : a≠b) (p : B.Walk a b) (hp : p.IsPath)
    (F : U→Finset V)
    (pair : Pairwise (fun i j => Disjoint (F i) (F j)))
    (cl : ∀ i,∀ u∈F i,∀ v∈F i,u≠v → G.Adj u v)
    (join : ∀ i j,B.Adj i j→∀ u∈F i,∀ v∈F j,G.Adj u v)
    (capacity : ∀ i,B.degree i≤(F i).card+1)
    (tight : ∀ i,(F i).card<B.degree i → i∈p.support ∧ i≠a ∧ i≠b)
    (all : ∀ v,∃ i,v∈F i) :
    ∃ (u v : V) (q : G.Walk u v),q.IsPath ∧ ∀ z,z∈q.support := by
  classical
  obtain ⟨q,s,h⟩ := exists_spanning_walk_along_spine hc ne p hp
  refine traceable_of_base_walk q F pair cl join ?_ (fun i e => (e (s i)).elim) all
  intro i
  have ci := capacity i
  have hi := h i
  by_cases gap : (F i).card<B.degree i
  · rw [if_pos (tight i gap)] at hi
    omega
  · omega

#print axioms traceable_of_bag_capacity_spine
end Graffiti189LongestPath.BagSpineCriterion
