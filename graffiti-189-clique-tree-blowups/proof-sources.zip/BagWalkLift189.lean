import SmallSeparator189
import Mathlib.Data.List.Chain

open Finset SimpleGraph
namespace Graffiti189LongestPath.BagWalkLift
variable {U V : Type*} [DecidableEq U] [DecidableEq V]
  {B : SimpleGraph U} {G : SimpleGraph V}

/-- A base walk that visits each bag at least once and at most its capacity
can be inflated into a spanning simple path through those bags.  At the
last occurrence of a bag, traverse all its remaining vertices in order. -/
theorem lift_bag_sequence (p : List U) (F : U→Finset V)
    (chain : p.Chain' B.Adj)
    (pair : Pairwise (fun i j => Disjoint (F i) (F j)))
    (cl : ∀ i,∀ u∈F i,∀ v∈F i,u≠v → G.Adj u v)
    (join : ∀ i j,B.Adj i j→∀ u∈F i,∀ v∈F j,G.Adj u v)
    (budget : ∀ i,p.count i≤(F i).card)
    (cover : ∀ i,i∉p → F i=∅) :
    ∃ r : List V, r.Nodup ∧ r.Chain' G.Adj ∧
      (∀ v,v∈r ↔ ∃ i,v∈F i) ∧
      (∀ i∈p.head?, ∃ v∈r.head?,v∈F i) := by
  classical
  induction p generalizing F with
  | nil =>
    refine ⟨[],by simp,by simp,?_,by simp⟩
    intro v
    simp only [List.not_mem_nil,false_iff]
    rintro ⟨i,vi⟩
    simp [cover i (by simp)] at vi
  | cons i p ih =>
    let A := if i∈p then {((F i).nonempty_of_ne_empty (by
      intro empty
      have b := budget i
      have pos : 0<(i::p).count i := List.count_pos_iff.mpr (by simp)
      simp [empty] at b)).choose} else F i
    have asub : A⊆F i := by
      dsimp [A]
      split
      · exact singleton_subset_iff.mpr (Classical.choose_spec _)
      · exact Subset.rfl
    have apos : A.Nonempty := by
      dsimp [A]
      split
      · simp
      · have b := budget i
        have pos : 0<(i::p).count i := List.count_pos_iff.mpr (by simp)
        exact card_pos.mp (by omega)
    let F' (j : U) := if j=i then F j\A else F j
    have sub (j : U) : F' j⊆F j := by
      dsimp [F']; split
      · exact sdiff_subset
      · exact Subset.rfl
    have dA (j : U) : Disjoint A (F' j) := by
      by_cases h : j=i
      · subst j
        exact disjoint_left.mpr (fun _ av bv =>
          (mem_sdiff.mp (show _∈F i\A from by simpa [F'] using bv)).2 av)
      · exact disjoint_left.mpr
          (fun _ av bv => disjoint_left.mp (pair (Ne.symm h)) (asub av) (sub j bv))
    have allot (j : U) : p.count j≤(F' j).card := by
      by_cases h : j=i
      · subst j
        rw [show F' i=F i\A by simp [F']]
        by_cases ip : i∈p
        · have ac : A.card=1 := by simp [A,ip]
          have q := card_sdiff_add_card_eq_card asub
          have z := budget i
          simp at z
          omega
        · have z : p.count i=0 := List.count_eq_zero.mpr ip
          omega
      · have q := budget j
        simpa [F',h, Ne.symm h] using q
    have off (j : U) (jp : j∉p) : F' j=∅ := by
      by_cases jI : j=i
      · subst j; simp [F',A,jp]
      · have jfull : j∉i::p := by simp [jI,jp]
        simpa [F',jI] using cover j jfull
    have rest : p.Chain' B.Adj := (List.chain'_cons'.mp chain).2
    obtain ⟨r,nr,cr,sr,hr⟩ := ih F' rest
      (fun a b ne => disjoint_left.mpr (fun _ ha hb => disjoint_left.mp (pair ne) (sub a ha) (sub b hb)))
      (fun j x hx y hy => cl j x (sub j hx) y (sub j hy))
      (fun a b ed x hx y hy => join a b ed x (sub a hx) y (sub b hy))
      allot off
    let a := A.toList
    have na : a.Nodup := Finset.nodup_toList _
    have am (v : V) : v∈a ↔ v∈A := Finset.mem_toList
    have nfull : (a++r).Nodup := by
      rw [List.nodup_append]
      exact ⟨na,nr,fun v va vr => by
        obtain ⟨j,vj⟩ := (sr v).mp vr
        exact disjoint_left.mp (dA j) ((am v).mp va) vj⟩
    have ca : a.Chain' G.Adj := by
      apply List.Pairwise.chain'
      apply List.pairwise_iff_getElem.mpr
      intro x y xb yb xy
      have xx : a[x]∈a := List.getElem_mem xb
      have yy : a[y]∈a := List.getElem_mem yb
      exact cl i _ (asub ((am _).mp xx)) _ (asub ((am _).mp yy))
        (fun e => (Nat.ne_of_lt xy) (Fin.val_eq_of_eq ((List.nodup_iff_injective_getElem.mp na) (a₁ := ⟨x,xb⟩) (a₂ := ⟨y,yb⟩) e)))
    have cf : (a++r).Chain' G.Adj := by
      rw [List.chain'_append]
      refine ⟨ca,cr,?_⟩
      intro u ul v vh
      cases p with
      | nil =>
        have no : v∉r := fun vr => by
          obtain ⟨j,vj⟩ := (sr v).mp vr
          have e := off j (by simp)
          simp [e] at vj
        exact (no (List.mem_of_mem_head? vh)).elim
      | cons j t =>
        have jb : j∈(j::t).head? := by simp
        obtain ⟨b,bh,bj⟩ := hr j jb
        have e : b=v := Option.some.inj ((Option.mem_def.mp bh).symm.trans (Option.mem_def.mp vh))
        have ed := (List.chain'_cons'.mp chain).1 j jb
        exact join i j ed _ (asub ((am _).mp (List.mem_of_mem_getLast? ul)))
          v (sub j (e ▸ bj))
    refine ⟨a++r,nfull,cf,?_,?_⟩
    · intro v
      constructor
      · intro vv
        rcases List.mem_append.mp vv with va|vr
        · exact ⟨i,asub ((am v).mp va)⟩
        · obtain ⟨j,jv⟩ := (sr v).mp vr
          exact ⟨j,sub j jv⟩
      · rintro ⟨j,vj⟩
        by_cases va : v∈A
        · exact List.mem_append.mpr (Or.inl ((am v).mpr va))
        · have vp : v∈F' j := by
            by_cases e : j=i
            · simp only [F',if_pos e]
              exact mem_sdiff.mpr ⟨vj,va⟩
            · simpa [F',e] using vj
          exact List.mem_append.mpr (Or.inr ((sr v).mpr ⟨j,vp⟩))
    · intro j jh
      have e : i=j := by simpa using jh
      subst j
      have az : a≠[] := by
        intro h
        obtain ⟨u,ua⟩ := apos
        have um := (am u).mpr ua
        simp [h] at um
      let v := a.head az
      have av : v∈a := List.head_mem az
      have hv : v∈(a++r).head? := by
        rw [List.head?_append, List.head?_eq_head az]
        simp [v]
      exact ⟨v,hv,asub ((am v).mp av)⟩

omit [DecidableEq V] in
private theorem walk_of_chain (a : V) (L : List V)
    (cl : List.Chain' G.Adj (a::L)) : ∃ b,∃ q : G.Walk a b,q.support=a::L := by
  induction L generalizing a with
  | nil => exact ⟨a,.nil,rfl⟩
  | cons b L ih =>
    obtain ⟨c,q,eq⟩ := ih b cl.tail
    exact ⟨c,.cons cl.rel_head q,by simp [eq]⟩

/-- Any capacity-feasible spanning bag walk gives a spanning path in the
graph with complete clique bags and complete joins on base edges. -/
theorem traceable_of_base_walk [Nonempty V] {a b : U} (p : B.Walk a b)
    (F : U→Finset V)
    (pair : Pairwise (fun i j => Disjoint (F i) (F j)))
    (cl : ∀ i,∀ u∈F i,∀ v∈F i,u≠v → G.Adj u v)
    (join : ∀ i j,B.Adj i j→∀ u∈F i,∀ v∈F j,G.Adj u v)
    (budget : ∀ i,p.support.count i≤(F i).card)
    (cover : ∀ i,i∉p.support → F i=∅)
    (all : ∀ v,∃ i,v∈F i) :
    ∃ (u v : V) (q : G.Walk u v),q.IsPath ∧ ∀ z,z∈q.support := by
  obtain ⟨r,nr,cr,sr,_⟩ := lift_bag_sequence p.support F p.chain'_adj_support
    pair cl join budget cover
  have mem (z : V) : z∈r := (sr z).mpr (all z)
  cases r with
  | nil =>
    obtain ⟨z⟩ := (inferInstance : Nonempty V)
    have h := mem z
    simp at h
  | cons u L =>
    obtain ⟨v,q,eq⟩ := walk_of_chain u L cr
    refine ⟨u,v,q,?_,?_⟩
    · rw [Walk.isPath_def,eq]
      exact nr
    · intro z
      rw [eq]
      exact mem z

#print axioms lift_bag_sequence
#print axioms traceable_of_base_walk
end Graffiti189LongestPath.BagWalkLift
