import TreeBagTight189

open Finset SimpleGraph
open scoped BigOperators
namespace Graffiti189LongestPath.TreeBagTight
open WeightedTreeSums TreeBagArithmetic TreeBagCapacity BagQuotient

variable {U : Type*} [Fintype U] [DecidableEq U]
  {B : SimpleGraph U} [DecidableRel B.Adj] {d : ℕ} {w : U→ℕ} {c : U→Bool}

private theorem two_step_weights (h : System B d w c) (x : U) :
    (∑ y∈B.neighborFinset x,∑ z∈(B.neighborFinset y).erase x,w z)+w x≤mass w c (c x) := by
  classical
  let K := B.neighborFinset x
  let A (y : U) := (B.neighborFinset y).erase x
  have sub : K.biUnion A⊆(side c (c x)).erase x := by
    intro u uu
    obtain ⟨y,yK,hu⟩ := mem_biUnion.mp uu
    obtain ⟨ne,e⟩ := mem_erase.mp hu
    have xu := same_after_twice c h.proper ((B.mem_neighborFinset _ _).mp yK)
      ((B.mem_neighborFinset _ _).mp e)
    exact mem_erase.mpr ⟨ne,(mem_side c (c x) u).mpr xu⟩
  have dis : Set.PairwiseDisjoint (↑K:Set U) A := by
    intro i hi j hj ne
    apply disjoint_left.mpr
    intro u ui uj
    obtain ⟨ux,iu⟩ := mem_erase.mp ui
    obtain ⟨_,ju⟩ := mem_erase.mp uj
    have xi := (B.mem_neighborFinset _ _).mp hi
    have xj := (B.mem_neighborFinset _ _).mp hj
    exact ux (common_neighbor_unique h.tree ne
      ((B.mem_neighborFinset _ _).mp iu) ((B.mem_neighborFinset _ _).mp ju) xi.symm xj.symm)
  have sum := Finset.sum_le_sum_of_subset sub (f:=w)
  rw [Finset.sum_biUnion dis] at sum
  have es : (∑ z∈(side c (c x)).erase x,w z)+w x=mass w c (c x) :=
    Finset.sum_erase_add _ _ ((mem_side c (c x) x).mpr rfl)
  change (∑ i∈K,∑ z∈A i,w z)+w x≤mass w c (c x)
  omega

/-- The exceptional size-two ordinary tight bag is possible only at d=6;
then it is the unique tight bag. -/
theorem small_ordinary_tight (h : System B d w c) (d5 : 5≤d) (x : U)
    (xt : w x<B.degree x) (w2 : w x=2) (ord : Ordinary B d w x) :
    d=6 ∧ ∀ y,y≠x → B.degree y≤w y := by
  classical
  let N := B.neighborFinset x
  let A (y : U) := (B.neighborFinset y).erase x
  let E := mass w c (c x)
  let O := mass w c (!c x)
  have c3 : N.card=3 := by
    rw [B.card_neighborFinset_eq_degree]
    have cap := degree_le_capacity_add_one h x
    omega
  obtain ⟨maf,fin⟩ := all_high_finance h x ord
  have d3 : (B.degree x:ℤ)=3 := by
    have zz := B.card_neighborFinset_eq_degree x
    change N.card=B.degree x at zz
    omega
  try dsimp only at maf fin
  rw [d3] at maf fin
  have e := h.parity x
  rw [w2] at e
  have wI : (w x:ℤ)=2 := by exact_mod_cast w2
  rw [wI] at fin
  have out := ordinary_tight_two (d:ℤ) ((E:ℤ)-(d:ℤ)) ((O:ℤ)-(d:ℤ)) (by omega)
    (by dsimp [E]; omega) (by dsimp [O]; nlinarith only [maf]) (by
      dsimp [E,O]; nlinarith only [fin])
  have eMass : E=d+2 := by have q := out.2.1; omega
  have oMass : O=2*d-3 := by have q := out.2.2.1; omega
  have budget : (∑ y∈N,∑ z∈A y,w z)≤d := by
    have q := two_step_weights h x
    change (∑ y∈N,∑ z∈A y,w z)+w x≤E at q
    omega
  have eachO (y : U) (yN : y∈N) : d-3≤w y := by
    have col := (mem_side _ _ _).mp (opposite c h.proper x yN)
    have m := h.parity y
    rw [col] at m
    change O≤d+w y at m
    omega
  have allO : (∑ y∈N,w y)≤O := Finset.sum_le_sum_of_subset (opposite c h.proper x)
  have eachOmax (y : U) (yN : y∈N) : w y≤3 := by
    have er := card_erase_add_one yN
    have low := Finset.sum_le_sum (s:=N.erase y) (f:=fun _ => d-3) (g:=w)
      (fun z zz => eachO z (mem_erase.mp zz).2)
    rw [Finset.sum_const_nat (fun _ _ => rfl),show (N.erase y).card=2 by omega] at low
    have eq := Finset.sum_erase_add N w yN
    omega
  have oneMore (y : U) (yN : y∈N) : 1≤∑ z∈A y,w z := by
    have a := ord y yN
    unfold High at a
    have bg := Finset.sum_erase_add (B.neighborFinset y) w
      ((B.mem_neighborFinset _ _).mpr ((B.mem_neighborFinset _ _).mp yN).symm)
    change (∑ z∈A y,w z)+w x=∑ z∈B.neighborFinset y,w z at bg
    have up := eachOmax y yN
    omega
  have eTwo (y : U) (yN : y∈N) (z : U) (zA : z∈A y) : 2≤w z := by
    have cy := same_after_twice c h.proper ((B.mem_neighborFinset _ _).mp yN)
      ((B.mem_neighborFinset _ _).mp (mem_erase.mp zA).2)
    have cap := h.parity z
    rw [cy] at cap
    change E≤d+w z at cap
    omega
  have eachA (y : U) (yN : y∈N) : 2≤∑ z∈A y,w z := by
    have nn : (A y).Nonempty := by
      apply Classical.byContradiction
      intro no
      have er : A y=∅ := not_nonempty_iff_eq_empty.mp no
      have lower := oneMore y yN
      simp [er] at lower
    obtain ⟨z,zz⟩ := nn
    have lo := eTwo y yN z zz
    have sub := Finset.sum_le_sum_of_subset (singleton_subset_iff.mpr zz) (f:=w)
    exact lo.trans (by simpa using sub)
  have six : d=6 := by
    have b := Finset.sum_le_sum (s:=N) (f:=fun _ => 2) (g:=fun y => ∑ z∈A y,w z) eachA
    rw [Finset.sum_const_nat (fun _ _ => rfl),c3] at b
    have q := out.1
    change 3*2≤∑ y∈N,∑ z∈A y,w z at b
    omega
  refine ⟨six,?_⟩
  have oe : (∑ y∈N,w y)=O := by
    have lo := Finset.sum_le_sum (s:=N) (f:=fun _ => d-3) (g:=w) eachO
    rw [Finset.sum_const_nat (fun _ _ => rfl),c3] at lo
    omega
  have oppEq : side c (!c x)=N := by
    apply Finset.Subset.antisymm _ (opposite c h.proper x)
    intro y hy
    apply Classical.byContradiction
    intro outside
    have sub : insert y N⊆side c (!c x) := insert_subset_iff.mpr ⟨hy,opposite c h.proper x⟩
    have le := Finset.sum_le_sum_of_subset sub (f:=w)
    rw [Finset.sum_insert outside] at le
    change w y+(∑ z∈N,w z)≤O at le
    have pos := h.positivity y
    omega
  have boundA (y : U) (yN : y∈N) : (∑ z∈A y,w z)≤2 := by
    let f (i : U) := ∑ z∈A i,w z
    have rest := Finset.sum_le_sum (s:=N.erase y) (f:=fun _=>2) (g:=f)
      (fun i ii => eachA i (mem_erase.mp ii).2)
    have er := card_erase_add_one yN
    rw [Finset.sum_const_nat (fun _ _ => rfl),show (N.erase y).card=2 by omega] at rest
    have eq := Finset.sum_erase_add N f yN
    change (∑ i∈N,f i)≤d at budget
    change f y≤2
    omega
  intro y ne
  by_cases colorY : c y=c x
  · have ys : B.neighborFinset y⊆N := by
      rw [←oppEq,←colorY]
      exact opposite c h.proper y
    have lo : B.degree y≤1 := by
      apply Nat.le_of_not_gt
      intro large
      rw [←B.card_neighborFinset_eq_degree] at large
      obtain ⟨a,ay,b,byY,ab⟩ := one_lt_card.mp large
      exact ab (common_neighbor_unique h.tree ne
        ((B.mem_neighborFinset _ _).mp ay) ((B.mem_neighborFinset _ _).mp (ys ay))
        ((B.mem_neighborFinset _ _).mp byY) ((B.mem_neighborFinset _ _).mp (ys byY)))
    exact lo.trans (h.positivity y)
  · have oppositeY : c y=(!c x) := by cases hX : c x <;> cases hY : c y <;> simp_all
    have yN : y∈N := oppEq ▸ ((mem_side _ _ _).mpr oppositeY)
    have up := boundA y yN
    have c1 : (A y).card≤1 := by
      have le := Finset.sum_le_sum (s:=A y) (f:=fun _ => 2) (g:=w) (eTwo y yN)
      rw [Finset.sum_const_nat (fun _ _ => rfl)] at le
      omega
    have ca := card_erase_add_one
      ((B.mem_neighborFinset _ _).mpr ((B.mem_neighborFinset _ _).mp yN).symm)
    rw [B.card_neighborFinset_eq_degree] at ca
    change (A y).card+1=B.degree y at ca
    have wy := eachO y yN
    omega

#print axioms small_ordinary_tight
end Graffiti189LongestPath.TreeBagTight
