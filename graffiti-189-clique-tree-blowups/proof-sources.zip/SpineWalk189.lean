import SmallSeparator189
import Mathlib.Data.List.Count
open Finset SimpleGraph SimpleGraph.Walk
open private Graffiti189LongestPath.outside_edge from SmallSeparator189

set_option maxHeartbeats 8000000
namespace Graffiti189LongestPath.SpineWalk

variable {U : Type*} [DecidableEq U] {B : SimpleGraph U}

/-- Inserting a single return detour increases exactly the two corresponding
vertex multiplicities. -/
theorem detour_counts {a b v x : U} (p : B.Walk a b) (vx : B.Adj v x)
    (vp : v∈p.support) :
    ∃ q : B.Walk a b,∀ u,q.support.count u=p.support.count u+
      (if u=v then 1 else 0)+(if u=x then 1 else 0) := by
  classical
  induction p with
  | @nil a =>
    have e : v=a := by simpa using vp
    subst v
    refine ⟨.cons vx (.cons vx.symm .nil),?_⟩
    intro u
    simp only [Walk.support_cons,support_nil,List.count_cons]
    simp only [Bool.true_eq,beq_iff_eq]
    simp only [show (u=a) ↔ (a=u) from eq_comm,show (u=x) ↔ (x=u) from eq_comm]
    omega
  | @cons a c b ac p ih =>
    by_cases e : v=a
    · subst v
      refine ⟨.cons vx (.cons vx.symm (.cons ac p)),?_⟩
      intro u
      simp only [Walk.support_cons,List.count_cons]
      simp only [Bool.true_eq,beq_iff_eq]
      simp only [show (u=a) ↔ (a=u) from eq_comm,show (u=x) ↔ (x=u) from eq_comm]
      omega
    · have vq : v∈p.support := (List.mem_cons.mp vp).resolve_left e
      obtain ⟨q,hq⟩ := ih vq
      refine ⟨.cons ac q,?_⟩
      intro u
      simp only [Walk.support_cons,List.count_cons,hq]
      omega

variable [Fintype U] [DecidableRel B.Adj]

private def PN {a b : U} (p : B.Walk a b) (u : U) : Finset U :=
  (B.neighborFinset u).filter (·∈p.support)

/-- Extend any initial walk to a spanning walk without violating a reserved
visit saving along its initial support.  Adding a new vertex costs one
extra visit at its attachment, but also increases that attachment's
current induced degree by one. -/
theorem exists_spanning_walk_with_reserved_savings (hc : B.Connected)
    {a b : U} (p : B.Walk a b) (reserve : U→ℕ)
    (free : ∀ u,u∉p.support → reserve u=0)
    (init : ∀ u∈p.support,p.support.count u+reserve u≤(PN p u).card) :
    ∃ q : B.Walk a b,(∀ u,u∈q.support) ∧
      (∀ u,q.support.count u+reserve u≤B.degree u) := by
  classical
  let measure (p : B.Walk a b) := Fintype.card U-p.support.toFinset.card
  have generate (n : ℕ) : ∀ (p : B.Walk a b),measure p=n →
      (∀ u,u∉p.support → reserve u=0) →
      (∀ u∈p.support,p.support.count u+reserve u≤(PN p u).card) →
      ∃ q : B.Walk a b,(∀ u,u∈q.support) ∧
        (∀ u,q.support.count u+reserve u≤B.degree u) := by
    induction n using Nat.strong_induction_on with
    | h n ih =>
      intro p pn f i
      by_cases span : ∀ u,u∈p.support
      · refine ⟨p,span,fun u => (i u (span u)).trans ?_⟩
        rw [←B.card_neighborFinset_eq_degree]
        exact card_le_card (filter_subset _ _)
      · obtain ⟨x,xo⟩ := not_forall.mp span
        obtain ⟨w,wo,v,vp,wv⟩ := Graffiti189LongestPath.outside_edge p hc ⟨x,xo⟩
        have vw := wv.symm
        obtain ⟨q,count⟩ := detour_counts p vw vp
        have new (u : U) : u∈q.support ↔ u=w∨u∈p.support := by
          rw [←List.count_pos_iff,count]
          by_cases uv : u=v
          · subst u
            simp [vp,Ne.symm vw.ne]
          · by_cases uw : u=w
            · subst u; simp [Ne.symm vw.ne]
            · simp [uv,uw,List.count_pos_iff]
        have mEq : q.support.toFinset=insert w p.support.toFinset := by
          ext u; simp only [List.mem_toFinset,mem_insert,new]
        have wN : w∉p.support.toFinset := fun h => wo (List.mem_toFinset.mp h)
        have less : measure q<n := by
          have max := card_le_univ (s:=q.support.toFinset)
          rw [mEq,card_insert_of_not_mem wN] at max
          rw [←pn]
          change Fintype.card U-q.support.toFinset.card <
            Fintype.card U-p.support.toFinset.card
          rw [mEq,card_insert_of_not_mem wN]
          omega
        apply ih (measure q) less q rfl
        · intro u uq
          exact f u (fun up => uq ((new u).mpr (Or.inr up)))
        · intro u uq
          have incl : PN p u⊆PN q u := by
            intro z hz
            obtain ⟨g,pz⟩ := mem_filter.mp hz
            exact mem_filter.mpr ⟨g,(new z).mpr (Or.inr pz)⟩
          rcases (new u).mp uq with equal|up
          · subst u
            have c : p.support.count w=0 := List.count_eq_zero.mpr wo
            have q1 : q.support.count w=1 := by rw [count,c]; simp [Ne.symm vw.ne]
            rw [q1,f w wo,Nat.add_zero]
            apply card_pos.mpr
            exact ⟨v,mem_filter.mpr ⟨(B.mem_neighborFinset _ _).mpr vw.symm,
              (new v).mpr (Or.inr vp)⟩⟩
          · by_cases e : u=v
            · subst u
              have adj : w∈PN q v := mem_filter.mpr
                ⟨(B.mem_neighborFinset _ _).mpr vw,(new w).mpr (Or.inl rfl)⟩
              have extra : insert w (PN p v)⊆PN q v := insert_subset_iff.mpr ⟨adj,incl⟩
              have h := card_le_card extra
              have z : w∉PN p v := fun h => wo (mem_filter.mp h).2
              rw [card_insert_of_not_mem z] at h
              have j := i v vp
              rw [count]
              simp only [if_pos rfl,if_true,if_neg vw.ne,Nat.add_zero]
              omega
            · rw [count]
              simp only [if_neg e,if_neg (show u≠w from fun z => wo (z ▸ up)),Nat.add_zero]
              exact (i u up).trans (card_le_card incl)
  exact generate (measure p) p rfl free init

omit [DecidableEq U] [Fintype U] [DecidableRel B.Adj] in
private theorem path_index {a b : U} (p : B.Walk a b) (u : U)
    (up : u∈p.support) : ∃ j,j≤p.length ∧ p.getVert j=u := by
  obtain ⟨j,jl,h⟩ := List.mem_iff_getElem.mp up
  have jL : j≤p.length := by rw [length_support] at jl; omega
  have h' := Option.some.inj ((getVert_eq_support_get? p jL).trans (List.getElem?_eq_getElem jl))
  exact ⟨j,jL,h'.trans h⟩

omit [DecidableEq U] [Fintype U] [DecidableRel B.Adj] in
private theorem path_index_unique {a b : U} (p : B.Walk a b) (hp : p.IsPath)
    {i j : ℕ} (hi : i≤p.length) (hj : j≤p.length)
    (same : p.getVert i=p.getVert j) : i=j := by
  have hi' : i < p.support.length := by rw [length_support]; omega
  have hj' : j < p.support.length := by rw [length_support]; omega
  have eqi : p.getVert i = p.support[i] := Option.some.inj
    ((getVert_eq_support_get? p hi).trans (List.getElem?_eq_getElem hi'))
  have eqj : p.getVert j = p.support[j] := Option.some.inj
    ((getVert_eq_support_get? p hj).trans (List.getElem?_eq_getElem hj'))
  exact hp.support_nodup.getElem_inj_iff.mp (eqi.symm.trans (same.trans eqj))

/-- In a connected graph, a selected spine gives a spanning walk that
visits each internal spine vertex at most its degree minus one times, and
each other vertex at most its degree times. -/
theorem exists_spanning_walk_along_spine (hc : B.Connected)
    {a b : U} (ne : a≠b) (p : B.Walk a b) (hp : p.IsPath) :
    ∃ q : B.Walk a b,(∀ u,u∈q.support) ∧
      (∀ u,q.support.count u+(if u∈p.support ∧ u≠a ∧ u≠b then 1 else 0)≤B.degree u) := by
  classical
  let R (u : U) := if u∈p.support ∧ u≠a ∧ u≠b then 1 else 0
  have f (u : U) (h : u∉p.support) : R u=0 := by simp [R,h]
  refine exists_spanning_walk_with_reserved_savings hc p R f ?_
  intro u up
  rw [List.count_eq_one_of_mem hp.support_nodup up]
  obtain ⟨j,jb,ju⟩ := path_index p u up
  have pn (v : U) (uv : B.Adj u v) (vp : v∈p.support) :
      v∈PN p u := mem_filter.mpr ⟨(B.mem_neighborFinset _ _).mpr uv,vp⟩
  have positive : 0<p.length := Nat.pos_of_ne_zero (fun h => ne (by
    have f := p.getVert_zero
    have g := p.getVert_length
    rw [h] at g
    exact f.symm.trans g))
  by_cases interior : u≠a ∧ u≠b
  · have l : 0<j := by
      by_contra! h
      have z : j=0 := by omega
      have e : a=u := by simpa [z] using ju
      exact interior.1 e.symm
    have r : j<p.length := by
      by_contra! h
      have z : j=p.length := by omega
      have e : b=u := by simpa [z] using ju
      exact interior.2 e.symm
    let x := p.getVert (j-1)
    let y := p.getVert (j+1)
    have ex : B.Adj x u := by
      have h := p.adj_getVert_succ (i:=j-1) (by omega)
      rwa [show j-1+1=j by omega,ju] at h
    have ey : B.Adj u y := ju ▸ p.adj_getVert_succ r
    have nx : x∈PN p u := pn x ex.symm (p.getVert_mem_support _)
    have ny : y∈PN p u := pn y ey (p.getVert_mem_support _)
    have nexy : x≠y := fun h => by
      have z := path_index_unique p hp (i:=j-1) (j:=j+1) (by omega) (by omega) h
      omega
    have c := one_lt_card.mpr ⟨x,nx,y,ny,nexy⟩
    change 1+(if u∈p.support ∧ u≠a ∧ u≠b then 1 else 0)≤(PN p u).card
    rw [if_pos ⟨up,interior.1,interior.2⟩]
    omega
  · have edge : ∃ v∈p.support,B.Adj u v := by
      by_cases h : j<p.length
      · exact ⟨p.getVert (j+1),p.getVert_mem_support _,ju ▸ p.adj_getVert_succ h⟩
      · have before : j-1<p.length := by omega
        refine ⟨p.getVert (j-1),p.getVert_mem_support _,?_⟩
        have h := (p.adj_getVert_succ before).symm
        rwa [show j-1+1=j by omega,ju] at h
    obtain ⟨v,vp,uv⟩ := edge
    have h := card_pos.mpr ⟨v,pn v uv vp⟩
    simpa [R,up,interior] using h

#print axioms detour_counts
#print axioms exists_spanning_walk_with_reserved_savings
#print axioms exists_spanning_walk_along_spine
end Graffiti189LongestPath.SpineWalk
