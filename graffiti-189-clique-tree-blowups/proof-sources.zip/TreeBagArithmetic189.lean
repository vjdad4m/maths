import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

namespace Graffiti189LongestPath.TreeBagArithmetic

theorem capacity_of_all_high (q w d : ℤ) (hw : 2≤w) (cross : q-1≤d)
    (charge : ((q-1)^2-q)*d+q*(q-1)≤q*(q-1)*w) : q≤w+1 := by
  by_contra! bad
  have hq : 4≤q := by omega
  have coef : 0≤(q-1)^2-q := by
    nlinarith only [sq_nonneg (q-4),hq]
  have low := mul_nonneg coef (show 0≤d-(q-1) by omega)
  have high := mul_nonneg (mul_nonneg (show 0≤q by omega) (show 0≤q-1 by omega))
    (show 0≤q-2-w by omega)
  nlinarith only [charge,low,high,hq]

theorem capacity_one_low_equal (p w d : ℤ) (hw : 2≤w) (hp : w+1≤p) (cross : p≤d)
    (charge : ((p-1)^2-p)*d+p^2≤p*(p-1)*w) : p=d ∧ w=p-1 := by
  have hp3 : 3≤p := by omega
  have coef : 0<(p-1)^2-p := by
    nlinarith only [sq_nonneg (p-3),hp3]
  have wcoef : 0<p*(p-1) :=
    mul_pos (show 0<p by omega) (show 0<p-1 by omega)
  have low := mul_nonneg coef.le (show 0≤d-p by omega)
  have high := mul_nonneg wcoef.le (show 0≤p-1-w by omega)
  constructor
  · by_contra! h
    have pos := mul_pos coef (show 0<d-p by omega)
    nlinarith only [charge,pos,high]
  · by_contra! h
    have pos := mul_pos wcoef (show 0<p-1-w by omega)
    nlinarith only [charge,low,pos]

theorem charged_from_summation (p w d a : ℤ) (hp : 1≤p)
    (upper : (p-1)*a≤p*(d-1)) (lower : p*(d+1)≤p*w+a+d) :
    ((p-1)^2-p)*d+p^2≤p*(p-1)*w := by
  have l := mul_nonneg (show 0≤p-1 by omega)
    (show 0≤p*w+a+d-p*(d+1) by linarith)
  nlinarith only [l,upper]

/-- Sharpen the rational bound by keeping the integer opposite-side slack. -/
theorem ordinary_tight_size (w d a b : ℤ) (hw : 3≤w) (aw : a≤w)
    (mass : w*b≤d) (sum : (w+1)*(d+1-w)≤2*d+a+b-w) :
    d≤w+1 ∧ b≤1 := by
  have L : (w-1)*d≤(w+1)*(w-1)+b := by nlinarith only [aw,sum]
  have e : d≤w+1 := by
    by_contra! h
    have prod := mul_nonneg (show 0≤w by omega)
      (show 0≤(w+1)*(w-1)+b-(w-1)*d by linarith)
    have coeff : 0≤w*(w-1)-1 := by
      nlinarith only [sq_nonneg (w-3),hw]
    have ob := mul_nonneg coeff (show 0≤d-(w+2) by omega)
    have gap : 0<w^2-2*w-2 := by nlinarith only [sq_nonneg (w-3),hw]
    nlinarith only [prod,mass,ob,gap]
  constructor
  · exact e
  · by_contra! h
    have ss := mul_nonneg (show 0≤w by omega) (show 0≤b-2 by omega)
    nlinarith only [ss,mass,e,hw]

theorem ordinary_tight_two (d a b : ℤ) (d5 : 5≤d) (aw : a≤2)
    (mass : 2*b≤d) (sum : 3*(d+1-2)≤2*d+a+b-2) :
    (d=5 ∨ d=6) ∧ a=2 ∧ b=d-3 ∧ 3*(d-1)=2*d+a+b-2 := by omega

theorem capacity_from_parity_sums (q w d b : ℤ) (w2 : 2≤w)
    (cross : q-1≤d) (mass : (q-1)*b≤d)
    (sum : q*(d+1-w)≤2*d+b) : q≤w+1 := by
  by_contra! h
  have q4 : 4≤q := by omega
  have q1 : 0≤q-1 := by omega
  have step := mul_nonneg q1 (show 0≤2*d+b-q*(d+1-w) by linarith)
  have finance : ((q-1)*(q-2)-1)*d≤q*(q-1)*(w-1) := by
    nlinarith only [step,mass]
  have c : 0≤(q-1)*(q-2)-1 := by nlinarith only [sq_nonneg (q-4),q4]
  have low := mul_nonneg c (show 0≤d-(q-1) by omega)
  have high := mul_nonneg (mul_nonneg (show 0≤q by omega) q1)
    (show 0≤q-2-w by omega)
  nlinarith only [finance,low,high,q4]

theorem capacity_one_low_from_parity_sums (p w d : ℤ) (w2 : 2≤w)
    (small : w+1≤p) (cross : p≤d) (sum : p*(d+1-w)≤2*d) :
    p=d ∧ w=p-1 := by
  have c : 0<p-2 := by omega
  have hp : 0<p := by omega
  have l := mul_nonneg c.le (show 0≤d-p by omega)
  have h := mul_nonneg hp.le (show 0≤p-1-w by omega)
  constructor
  · by_contra! ne
    have pos := mul_pos c (show 0<d-p by omega)
    nlinarith only [sum,pos,h]
  · by_contra! ne
    have pos := mul_pos hp (show 0<p-1-w by omega)
    nlinarith only [sum,l,pos]

#print axioms capacity_of_all_high
#print axioms capacity_one_low_equal
#print axioms charged_from_summation
#print axioms ordinary_tight_size
#print axioms ordinary_tight_two
#print axioms capacity_from_parity_sums
#print axioms capacity_one_low_from_parity_sums
end Graffiti189LongestPath.TreeBagArithmetic
