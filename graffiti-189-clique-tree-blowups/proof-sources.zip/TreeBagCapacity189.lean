import WeightedTreeSums189
import TreeBagArithmetic189
import Mathlib.Tactic.Linarith

open Finset SimpleGraph
open scoped BigOperators
namespace Graffiti189LongestPath.TreeBagCapacity
open WeightedTreeSums TreeBagArithmetic BagQuotient

variable {U : Type*} [Fintype U] [DecidableEq U]
  {B : SimpleGraph U} [DecidableRel B.Adj]

def High (B : SimpleGraph U) [DecidableRel B.Adj] (d : ℕ) (w : U→ℕ) (x : U) : Prop :=
  d+1≤w x+∑ y∈B.neighborFinset x,w y

structure System (B : SimpleGraph U) [DecidableRel B.Adj] (d : ℕ) (w : U→ℕ) (c : U→Bool) : Prop where
  tree : B.IsTree
  positivity : ∀ x,1≤w x
  proper : ∀ x y,B.Adj x y → c x≠c y
  parity : ∀ x,mass w c (c x)≤d+w x
  cross : ∀ x y,B.Adj x y → ∑ i∈(B.neighborFinset x).erase y,w i≤d
  exceptional : ∀ x y,x≠y → High B d w x ∨ High B d w y
  singleton_low : ∀ x,¬High B d w x → w x=1
  internal : ∀ x,2≤B.degree x → 2≤w x

variable {d : ℕ} {w : U→ℕ} {c : U→Bool}

theorem count_le_weight (h : System B d w c) (S : Finset U) : S.card≤∑ i∈S,w i := by
  have le := Finset.sum_le_sum (s:=S) (f:=fun _ => 1) (g:=w) (fun i _ => h.positivity i)
  simpa using le

private theorem exact_unit_weight (h : System B d w c) (S : Finset U)
    (sc : (∑ i∈S,w i)≤S.card) (i : U) (hi : i∈S) : w i=1 := by
  have er := card_erase_add_one hi
  have sum : (∑ j∈S.erase i,w j)+w i=∑ j∈S,w j := Finset.sum_erase_add _ _ hi
  have e := count_le_weight h (S.erase i)
  have pos := h.positivity i
  omega

omit [Fintype U] in
private theorem exists_other (S : Finset U) (many : 1<S.card) (i : U) (hi : i∈S) :
    ∃ j∈S,j≠i := by
  have e := card_erase_add_one hi
  obtain ⟨j,hj⟩ := card_pos.mp (show 0<(S.erase i).card by omega)
  exact ⟨j,(mem_erase.mp hj).2,(mem_erase.mp hj).1⟩

theorem degree_sub_one_le (h : System B d w c) (x : U) (nonzero : 0<B.degree x) :
    B.degree x-1≤d := by
  have xc : 0<(B.neighborFinset x).card := by rwa [B.card_neighborFinset_eq_degree]
  obtain ⟨i,inN⟩ := card_pos.mp xc
  have ch := h.cross x i ((B.mem_neighborFinset _ _).mp inN)
  have w := count_le_weight h ((B.neighborFinset x).erase i)
  have er := card_erase_add_one inN
  rw [B.card_neighborFinset_eq_degree] at er
  omega

/-- Finance for nodes with no low neighbor. -/
theorem all_high_finance (h : System B d w c) (x : U)
    (all : ∀ y∈B.neighborFinset x,High B d w y) :
    let q := (B.degree x:ℤ)
    let a := (mass w c (c x):ℤ)-(d:ℤ)
    let b := (mass w c (!c x):ℤ)-(d:ℤ)
    (q-1)*b≤(d:ℤ) ∧ q*((d:ℤ)+1-(w x:ℤ))≤2*(d:ℤ)+a+b-(w x:ℤ) := by
  classical
  let N := B.neighborFinset x
  let O := mass w c (!c x)
  let E := mass w c (c x)
  let q := B.degree x
  have upN : (∑ i∈N,w i)≤O := Finset.sum_le_sum_of_subset (opposite c h.proper x)
  have iw : (∑ i∈N,(w i:ℤ))≤(O:ℤ) := by exact_mod_cast upN
  have low := neighbor_mass_floor c h.proper w d h.parity x
  change (q:ℤ)*((O:ℤ)-(d:ℤ))≤∑ i∈N,(w i:ℤ) at low
  have su := sum_high_neighbors h.tree c h.proper w d x N (Subset.rfl) all
  rw [show N.card=q from B.card_neighborFinset_eq_degree x] at su
  have small : q*(d+1)+w x≤q*w x+O+E := by omega
  have sm : (q:ℤ)*((d:ℤ)+1)+(w x:ℤ)≤(q:ℤ)*(w x:ℤ)+(O:ℤ)+(E:ℤ) := by
    exact_mod_cast small
  change ((q:ℤ)-1)*((O:ℤ)-(d:ℤ))≤(d:ℤ) ∧
    (q:ℤ)*((d:ℤ)+1-(w x:ℤ))≤2*(d:ℤ)+((E:ℤ)-(d:ℤ))+((O:ℤ)-(d:ℤ))-(w x:ℤ)
  constructor
  · nlinarith only [iw,low]
  · nlinarith only [sm]

theorem low_finance (h : System B d w c) (x y : U) (yx : y∈B.neighborFinset x)
    (lo : ¬High B d w y) :
    ((B.degree x:ℤ)-1)*((d:ℤ)+1-(w x:ℤ))≤2*(d:ℤ) := by
  classical
  let N := B.neighborFinset x
  let K := N.erase y
  let E := mass w c (c x)
  let O := mass w c (!c x)
  have low := h.singleton_low y lo
  have hK (z : U) (zK : z∈K) : High B d w z :=
    (h.exceptional z y (mem_erase.mp zK).1).resolve_right lo
  have su := sum_high_neighbors h.tree c h.proper w d x K (erase_subset _ _) hK
  have se : (∑ z∈K,w z)+w y=∑ z∈N,w z := Finset.sum_erase_add _ _ yx
  have nn : (∑ z∈N,w z)≤O := Finset.sum_le_sum_of_subset (opposite c h.proper x)
  have parE : E≤d+w x := h.parity x
  have colorY := (mem_side _ _ _).mp (opposite c h.proper x yx)
  have parO := h.parity y
  rw [colorY,low] at parO
  change O≤d+1 at parO
  have f : K.card*(d+1)≤K.card*w x+2*d := by omega
  have z : (K.card:ℤ)*((d:ℤ)+1)≤(K.card:ℤ)*(w x:ℤ)+2*(d:ℤ) := by exact_mod_cast f
  have e := card_erase_add_one yx
  rw [B.card_neighborFinset_eq_degree] at e
  change K.card+1=B.degree x at e
  have eq : (K.card:ℤ)+1=(B.degree x:ℤ) := by exact_mod_cast e
  rw [show (B.degree x:ℤ)-1=(K.card:ℤ) by omega]
  nlinarith only [z]

/-- The quotient branching at a vertex cannot exceed its clique-bag
capacity by more than one. -/
theorem degree_le_capacity_add_one (h : System B d w c) (x : U) :
    B.degree x≤w x+1 := by
  classical
  by_contra! over
  have pos := h.positivity x
  have two : 2≤B.degree x := by omega
  have w2 := h.internal x two
  have cross := degree_sub_one_le h x (by omega)
  have ci : (B.degree x:ℤ)-1≤(d:ℤ) := by omega
  have wi : (2:ℤ)≤w x := by exact_mod_cast w2
  by_cases all : ∀ y∈B.neighborFinset x,High B d w y
  · obtain ⟨mass,sum⟩ := all_high_finance h x all
    have aw := h.parity x
    have sum' : (B.degree x:ℤ)*((d:ℤ)+1-(w x:ℤ))≤
        2*(d:ℤ)+((WeightedTreeSums.mass w c (!c x):ℤ)-(d:ℤ)) := by
      have ai : (WeightedTreeSums.mass w c (c x):ℤ)≤(d:ℤ)+(w x:ℤ) := by exact_mod_cast aw
      nlinarith only [sum,ai]
    have conclude := capacity_from_parity_sums (B.degree x) (w x) d _ wi ci mass sum'
    omega
  · obtain ⟨y,yN,lo⟩ : ∃ y∈B.neighborFinset x,¬High B d w y := by
      by_contra! q; exact all q
    have small : (w x:ℤ)+1≤(B.degree x:ℤ)-1 := by omega
    have out := capacity_one_low_from_parity_sums ((B.degree x:ℤ)-1) (w x) d wi small ci
      (low_finance h x y yN lo)
    have count : (B.neighborFinset x).card=B.degree x := B.card_neighborFinset_eq_degree x
    have allOne (u : U) (uN : u∈B.neighborFinset x) : w u=1 := by
      obtain ⟨v,vN,vU⟩ := exists_other (B.neighborFinset x) (by omega) u uN
      have er := card_erase_add_one vN
      have ch := h.cross x v ((B.mem_neighborFinset _ _).mp vN)
      have wh : (∑ i∈(B.neighborFinset x).erase v,w i)≤((B.neighborFinset x).erase v).card := by
        have ex := out.1
        omega
      exact exact_unit_weight h _ wh u (mem_erase.mpr ⟨vU.symm,uN⟩)
    obtain ⟨v,vN,vY⟩ := exists_other (B.neighborFinset x) (by omega) y yN
    have hv := (h.exceptional v y vY).resolve_right lo
    have unit := allOne v vN
    have only : B.neighborFinset v={x} := by
      have xN : x∈B.neighborFinset v :=
        (B.mem_neighborFinset _ _).mpr ((B.mem_neighborFinset _ _).mp vN).symm
      have atmost : B.degree v≤1 := by
        by_contra! q
        have p := h.internal v (by omega)
        omega
      exact (eq_of_subset_of_card_le (singleton_subset_iff.mpr xN)
        (by rw [card_singleton,B.card_neighborFinset_eq_degree]; exact atmost)).symm
    unfold High at hv
    rw [only,Finset.sum_singleton,unit] at hv
    have a := out.1
    have b := out.2
    omega

#print axioms degree_le_capacity_add_one
end Graffiti189LongestPath.TreeBagCapacity
