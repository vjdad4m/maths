import WeightedTreeSums189

open Finset SimpleGraph Graffiti189LongestPath
open scoped BigOperators
open private Graffiti189LongestPath.mem_distanceTwo Graffiti189LongestPath.dist_two from SmallSeparator189
namespace Graffiti189LongestPath.TreeBagCharges
open BagQuotient WeightedTreeSums TreeParity

variable {U V : Type*} [Fintype U] [Fintype V] [DecidableEq U] [DecidableEq V]
  {B : SimpleGraph U} {G : SimpleGraph V} [DecidableRel B.Adj] [DecidableRel G.Adj]

omit [DecidableRel B.Adj] [DecidableRel G.Adj] in
/-- Each color mass minus the own clique bag pays against the common even
budget of any representative of that bag. -/
theorem parity_mass_bound {f : V→U} (M : Model B G f) (hc : G.Connected)
    (tree : B.IsTree) (r x : U) (d : ℕ)
    (cap : ∀ v,(EvenFrom G v).card≤d+1) :
    mass (fun i => (bag f i).card) (color B r) (color B r x)≤d+(bag f x).card := by
  classical
  obtain ⟨u,ux⟩ := M.onto x
  let S := (side (color B r) (color B r x)).erase x
  let F := S.biUnion (bag f)
  have sub : insert u F⊆EvenFrom G u := by
    intro v hv
    rcases mem_insert.mp hv with vu|vf
    · subst v; simp [EvenFrom,SimpleGraph.dist_self]
    · obtain ⟨i,is,vi⟩ := mem_biUnion.mp vf
      obtain ⟨ne,sideI⟩ := mem_erase.mp is
      have ei : f v=i := (mem_bag f i v).mp vi
      have ni : f u≠f v := fun ej => ne (ei.symm.trans (ej.symm.trans ux))
      have ed := M.dist_eq hc tree.isConnected u v ni
      have same : color B r x=color B r i := ((mem_side _ _ _).mp sideI).symm
      have p := even_dist_of_same_color tree r x i same
      rw [ux,ei] at ed
      simp only [EvenFrom,mem_filter,mem_univ,true_and]
      exact ed.symm ▸ p
  have out : u∉F := by
    intro h
    obtain ⟨i,is,ui⟩ := mem_biUnion.mp h
    exact (mem_erase.mp is).1 (((mem_bag f i u).mp ui).symm.trans ux)
  have c := (card_le_card sub).trans (cap u)
  rw [card_insert_of_not_mem out] at c
  have eql : F.card=∑ i∈S,(bag f i).card := card_biUnion (fun _ _ _ _ ne => bag_pairwise f ne)
  rw [eql] at c
  have sum : (∑ i∈S,(bag f i).card)+(bag f x).card=
      mass (fun i => (bag f i).card) (color B r) (color B r x) :=
    Finset.sum_erase_add _ _ ((mem_side _ _ _).mpr rfl)
  omega

omit [DecidableRel G.Adj] in
/-- One other clique bag for every base neighbor of x except y contributes
all its vertices at distance two from a representative in y. -/
theorem opposite_neighbor_charge {f : V→U} (M : Model B G f) (hc : G.Connected)
    (tree : B.IsTree) (r : U) {x y : U} (xy : B.Adj x y) (d : ℕ)
    (cap : ∀ v,(EvenFrom G v).card≤d+1) :
    ∑ i∈(B.neighborFinset x).erase y,(bag f i).card≤d := by
  classical
  obtain ⟨u,uy⟩ := M.onto y
  obtain ⟨z,zx⟩ := M.onto x
  let S := (B.neighborFinset x).erase y
  have proper := fun (i j : U) (ed : B.Adj i j) => color_ne_of_adj tree r ed
  have uz : G.Adj u z := (M.exact_edge u z).mpr (Or.inr (by rw [uy,zx]; exact xy.symm))
  have sub : S.biUnion (bag f)⊆DistanceTwo G u := by
    intro v hv
    obtain ⟨i,is,vi⟩ := mem_biUnion.mp hv
    obtain ⟨ne,inN⟩ := mem_erase.mp is
    have iv : f v=i := (mem_bag f i v).mp vi
    have xi := (B.mem_neighborFinset _ _).mp inN
    have zv : G.Adj z v := (M.exact_edge z v).mpr (Or.inr (by rwa [zx,iv]))
    have same := same_after_twice (color B r) proper xy.symm xi
    have neUV : u≠v := fun h => ne (iv.symm.trans ((congrArg f h).symm.trans uy))
    have noUV : ¬G.Adj u v := by
      intro g
      rcases (M.exact_edge u v).mp g with ⟨e,_⟩|e
      · exact ne (iv.symm.trans (e.symm.trans uy))
      · rw [uy,iv] at e
        exact (proper y i e) same.symm
    exact Graffiti189LongestPath.mem_distanceTwo.mpr
      (Graffiti189LongestPath.dist_two hc neUV noUV uz zv)
  have h := (card_le_card sub).trans (distanceTwo_le_of_even d u (cap u))
  rwa [card_biUnion (fun _ _ _ _ ne => bag_pairwise f ne)] at h

#print axioms parity_mass_bound
#print axioms opposite_neighbor_charge
end Graffiti189LongestPath.TreeBagCharges
