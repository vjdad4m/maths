import TreeBagCapacity189

open Finset SimpleGraph
open scoped BigOperators
namespace Graffiti189LongestPath.TreeBagTight
open WeightedTreeSums TreeBagArithmetic TreeBagCapacity BagQuotient

variable {U : Type*} [Fintype U] [DecidableEq U]
  {B : SimpleGraph U} [DecidableRel B.Adj] {d : ℕ} {w : U→ℕ} {c : U→Bool}

def Ordinary (B : SimpleGraph U) [DecidableRel B.Adj] (d : ℕ) (w : U→ℕ) (x : U) : Prop :=
  ∀ y∈B.neighborFinset x,High B d w y

theorem tight_degree_three (h : System B d w c) (x : U) (tight : w x<B.degree x) :
    3≤B.degree x := by
  have p := h.positivity x
  have i := h.internal x (by omega)
  omega

theorem ordinary_tight_bounds (h : System B d w c) (d7 : 7≤d) (x : U)
    (tight : w x<B.degree x) (all : Ordinary B d w x) :
    d≤B.degree x ∧ mass w c (!c x)≤d+1 := by
  have up := degree_le_capacity_add_one h x
  have q : B.degree x=w x+1 := by omega
  have atLeast := tight_degree_three h x tight
  have xw := h.internal x (by omega)
  obtain ⟨b,finance⟩ := all_high_finance h x all
  have qI : (B.degree x:ℤ)=(w x:ℤ)+1 := by exact_mod_cast q
  try dsimp only at b finance
  rw [qI] at b finance
  let A : ℤ := (WeightedTreeSums.mass w c (c x):ℤ)-(d:ℤ)
  let D : ℤ := (WeightedTreeSums.mass w c (!c x):ℤ)-(d:ℤ)
  change ((w x:ℤ)+1-1)*D≤(d:ℤ) at b
  change ((w x:ℤ)+1)*((d:ℤ)+1-(w x:ℤ))≤2*(d:ℤ)+A+D-(w x:ℤ) at finance
  have bb : (w x:ℤ)*D≤(d:ℤ) := by simpa only [add_sub_cancel_right] using b
  have a : A≤(w x:ℤ) := by
    have h := h.parity x
    dsimp [A]
    omega
  have large : (3:ℤ)≤(w x:ℤ) := by
    by_contra! s
    have eq : (w x:ℤ)=2 := by omega
    rw [eq] at a bb finance
    have aux := ordinary_tight_two (d:ℤ) A D (by omega) a bb finance
    omega
  have z := ordinary_tight_size (w x:ℤ) (d:ℤ) A D large a bb finance
  dsimp [D] at z
  omega

private theorem side_capacity_of_two_tight (h : System B d w c) {x y : U}
    (xy : x≠y) (same : c x=c y) :
    B.degree x+B.degree y≤mass w c (!c x)+1 := by
  classical
  let N := B.neighborFinset x
  let M := B.neighborFinset y
  have cl : (N∩M).card≤1 := by
    by_contra! t
    obtain ⟨v,vM,u,uM,ne⟩ := one_lt_card.mp t
    obtain ⟨xv,yv⟩ := mem_inter.mp vM
    obtain ⟨xu,yu⟩ := mem_inter.mp uM
    exact ne (common_neighbor_unique h.tree xy ((B.mem_neighborFinset _ _).mp xv)
      ((B.mem_neighborFinset _ _).mp yv) ((B.mem_neighborFinset _ _).mp xu)
      ((B.mem_neighborFinset _ _).mp yu))
  have nx : N⊆side c (!c x) := opposite c h.proper x
  have my : M⊆side c (!c x) := by rw [same]; exact opposite c h.proper y
  have within := card_le_card (union_subset nx my)
  have weight := count_le_weight h (side c (!c x))
  change (side c (!c x)).card≤mass w c (!c x) at weight
  have s := card_union_add_card_inter N M
  have n := B.card_neighborFinset_eq_degree x
  have m := B.card_neighborFinset_eq_degree y
  change N.card=B.degree x at n
  change M.card=B.degree y at m
  omega

omit [DecidableEq U] in
private theorem choose_low (h : ¬Ordinary B d w x) :
    ∃ y∈B.neighborFinset x,¬High B d w y := by
  classical
  by_contra! all
  exact h all

/-- At most one tight vertex lies on each quotient color side. -/
theorem tight_color_inj (h : System B d w c) (d7 : 7≤d) {x y : U}
    (xt : w x<B.degree x) (yt : w y<B.degree y) (same : c x=c y) : x=y := by
  classical
  by_contra ne
  have both := side_capacity_of_two_tight h ne same
  by_cases xO : Ordinary B d w x
  · have ⟨l,up⟩ := ordinary_tight_bounds h d7 x xt xO
    have y3 := tight_degree_three h y yt
    omega
  by_cases yO : Ordinary B d w y
  · have ⟨l,up⟩ := ordinary_tight_bounds h d7 y yt yO
    have x3 := tight_degree_three h x xt
    rw [←same] at up
    omega
  obtain ⟨u,xu,ulo⟩ := choose_low xO
  obtain ⟨v,yv,vlo⟩ := choose_low yO
  have uv : u=v := Classical.byContradiction (fun hn => (h.exceptional u v hn).elim ulo vlo)
  subst v
  have a : x∈B.neighborFinset u :=
    (B.mem_neighborFinset _ _).mpr ((B.mem_neighborFinset _ _).mp xu).symm
  have b : y∈B.neighborFinset u :=
    (B.mem_neighborFinset _ _).mpr ((B.mem_neighborFinset _ _).mp yv).symm
  have n := one_lt_card.mpr ⟨x,a,y,b,ne⟩
  rw [B.card_neighborFinset_eq_degree] at n
  have uBig := h.internal u (by omega)
  have uSmall := h.singleton_low u ulo
  omega

theorem card_tight (h : System B d w c) (d7 : 7≤d) :
    (univ.filter (fun i => w i<B.degree i)).card≤2 := by
  classical
  let S := univ.filter (fun i => w i<B.degree i)
  have he : (S.image c).card=S.card := card_image_of_injOn (fun i hi j hj e =>
    tight_color_inj h d7 (mem_filter.mp hi).2 (mem_filter.mp hj).2 e)
  have z := card_le_univ (s:=S.image c)
  rw [he] at z
  exact z

#print axioms tight_color_inj
#print axioms card_tight
end Graffiti189LongestPath.TreeBagTight
