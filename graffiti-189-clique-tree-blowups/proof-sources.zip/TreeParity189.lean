import BagQuotient189
import Mathlib.Combinatorics.SimpleGraph.Acyclic

open Finset SimpleGraph SimpleGraph.Walk
namespace Graffiti189LongestPath.TreeParity
open BagQuotient

variable {U V : Type*} {B : SimpleGraph U} {G : SimpleGraph V}

private theorem tree_path_length (tree : B.IsTree) {a b : U} (p : B.Walk a b) (hp : p.IsPath) :
    p.length=B.dist a b := by
  obtain ⟨q,hq,h⟩ := tree.isConnected.exists_path_of_dist a b
  have e : (⟨p,hp⟩ : B.Path a b)=⟨q,hq⟩ := tree.IsAcyclic.path_unique _ _
  exact (congrArg (fun x : B.Path a b => x.val.length) e).trans h

/-- Every tree edge changes rooted distance by exactly one. -/
theorem rooted_dist_step [DecidableEq U] (tree : B.IsTree) (a x y : U)
    (xy : B.Adj x y) :
    B.dist a x+1=B.dist a y ∨ B.dist a y+1=B.dist a x := by
  obtain ⟨p,pp,pLen⟩ := tree.isConnected.exists_path_of_dist a x
  by_cases yp : y∈p.support
  · let q := p.takeUntil y yp
    have qp : q.IsPath := pp.takeUntil yp
    have qlt : q.length<p.length := length_takeUntil_lt yp xy.ne.symm
    have xo : x∉q.support := by
      intro xq
      have up := B.dist_le (q.takeUntil x xq)
      have down := q.length_takeUntil_le xq
      omega
    let r : B.Walk x a := .cons xy q.reverse
    have rp : r.IsPath := (cons_isPath_iff _ _).mpr ⟨qp.reverse,by simpa using xo⟩
    right
    have rLen := tree_path_length tree r.reverse rp.reverse
    have qLen := tree_path_length tree q qp
    simpa [r,qLen] using rLen
  · let r : B.Walk y a := .cons xy.symm p.reverse
    have rp : r.IsPath := (cons_isPath_iff _ _).mpr ⟨pp.reverse,by simpa using yp⟩
    left
    have rLen := tree_path_length tree r.reverse rp.reverse
    simpa [r,pLen] using rLen

noncomputable def color (B : SimpleGraph U) (root i : U) : Bool := decide (B.dist root i % 2=0)

theorem color_ne_of_adj [DecidableEq U] (tree : B.IsTree) (root : U) {i j : U}
    (ij : B.Adj i j) : color B root i≠color B root j := by
  unfold color
  rcases rooted_dist_step tree root i j ij with z|z
  · by_cases h : B.dist root i % 2=0
    · have no : ¬B.dist root j % 2=0 := by omega
      simp [h,no]
    · have yes : B.dist root j % 2=0 := by omega
      simp [h,yes]
  · by_cases h : B.dist root i % 2=0
    · have no : ¬B.dist root j % 2=0 := by omega
      simp [h,no]
    · have yes : B.dist root j % 2=0 := by omega
      simp [h,yes]

private theorem len_mod {a b : U} (p : B.Walk a b) (f : U→Bool)
    (proper : ∀ i j,B.Adj i j → f i≠f j) :
    p.length%2=if f a=f b then 0 else 1 := by
  induction p with
  | nil => simp
  | @cons a c b h p ih =>
    have ac := proper a c h
    simp only [length_cons]
    cases ea : f a <;> cases ec : f c <;> cases eb : f b <;>
      simp [ea,ec,eb] at ac ih ⊢ <;> omega

theorem even_dist_of_same_color [DecidableEq U] (tree : B.IsTree) (root i j : U)
    (same : color B root i=color B root j) : Even (B.dist i j) := by
  obtain ⟨p,pl⟩ := tree.isConnected.exists_walk_length_eq_dist i j
  have q := len_mod p (color B root) (fun _ _ h => color_ne_of_adj tree root h)
  rw [pl,if_pos same] at q
  exact Nat.even_iff.mpr q

#print axioms color_ne_of_adj
#print axioms even_dist_of_same_color
end Graffiti189LongestPath.TreeParity
