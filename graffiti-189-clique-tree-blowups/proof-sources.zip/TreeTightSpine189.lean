import BagSpineCriterion189
import Mathlib.Combinatorics.SimpleGraph.Acyclic

open Finset SimpleGraph SimpleGraph.Walk
namespace Graffiti189LongestPath.TreeTightSpine
variable {U : Type*} [Fintype U] [DecidableEq U]
  {B : SimpleGraph U} [DecidableRel B.Adj]

private theorem extend_left (acy : B.IsAcyclic) {a b : U}
    (p : B.Walk a b) (hp : p.IsPath) (ab : a≠b) (hi : 2≤B.degree a) :
    ∃ u,B.Adj u a ∧ u∉p.support := by
  classical
  cases p with
  | nil => exact (ab rfl).elim
  | @cons a c b ac p =>
    have cN : c∈B.neighborFinset a := (B.mem_neighborFinset _ _).mpr ac
    have cs := card_erase_add_one cN
    rw [B.card_neighborFinset_eq_degree] at cs
    obtain ⟨u,un⟩ := card_pos.mp (show 0<((B.neighborFinset a).erase c).card by omega)
    obtain ⟨uc,ua⟩ := mem_erase.mp un
    have au := (B.mem_neighborFinset _ _).mp ua
    refine ⟨u,au.symm,?_⟩
    intro h
    have up := (List.mem_cons.mp h).resolve_left au.ne.symm
    have h' : u∈(Walk.cons ac p).support := List.mem_cons_of_mem _ up
    let short := (Walk.cons ac p).takeUntil u h'
    have shortP : short.IsPath := hp.takeUntil h'
    have equal : short=au.toWalk := congrArg Subtype.val
      (acy.path_unique ⟨short,shortP⟩ (Path.singleton au))
    have get := congrArg (fun w : B.Walk a u => w.getVert 1) equal
    have edgeShape : short=(p.takeUntil u up).cons ac :=
      takeUntil_cons up au.ne ac
    rw [edgeShape] at get
    have cu : c=u := by simpa [SimpleGraph.Adj.toWalk] using get
    exact uc cu.symm

/-- A tree (indeed an acyclic connected graph) has a nontrivial spine
through the interior of any selected set of at most two non-leaves. -/
theorem exists_spine_through_two_nonleaves (tree : B.IsTree)
    (edge : ∃ a b,B.Adj a b) (T : Finset U) (size : T.card≤2)
    (high : ∀ u∈T,2≤B.degree u) :
    ∃ a b : U, a≠b ∧ ∃ p : B.Walk a b,p.IsPath ∧
      ∀ u∈T,u∈p.support ∧ u≠a ∧ u≠b := by
  classical
  by_cases empty : T=∅
  · obtain ⟨a,b,ab⟩ := edge
    exact ⟨a,b,ab.ne,ab.toWalk,by simp [SimpleGraph.Adj.toWalk,ab.ne],fun u hu => by simp [empty] at hu⟩
  · obtain ⟨x,xt⟩ := nonempty_of_ne_empty empty
    by_cases many : (T.erase x).Nonempty
    · obtain ⟨y,yt⟩ := many
      have yne := (mem_erase.mp yt).1
      have yT := (mem_erase.mp yt).2
      have eq : T={x,y} := by
        have sub : ({x,y}:Finset U)⊆T := by
          intro u hu
          rcases mem_insert.mp hu with e|e
          · exact e.symm ▸ xt
          · exact (mem_singleton.mp e).symm ▸ yT
        exact (eq_of_subset_of_card_le sub (by simpa [Ne.symm yne] using size)).symm
      obtain ⟨p,hp,_⟩ := tree.existsUnique_path x y
      obtain ⟨a,ax,out⟩ := extend_left tree.IsAcyclic p hp yne.symm (high x xt)
      let L : B.Walk a y := .cons ax p
      have lp : L.IsPath := (cons_isPath_iff _ _).mpr ⟨hp,out⟩
      have ay : a≠y := fun e => out (e.symm ▸ p.end_mem_support)
      obtain ⟨b,byy,bout⟩ := extend_left tree.IsAcyclic L.reverse lp.reverse ay.symm (high y yT)
      let R : B.Walk b a := .cons byy L.reverse
      have rp : R.IsPath := (cons_isPath_iff _ _).mpr ⟨lp.reverse,bout⟩
      have ab : a≠b := fun e => bout (e ▸ L.reverse.end_mem_support)
      have save (u : U) (up : u∈p.support) : u∈R.reverse.support ∧ u≠a ∧ u≠b := by
        have uL : u∈L.support := List.mem_cons_of_mem _ up
        have ur : u∈L.reverse.support := by simpa using uL
        have uR : u∈R.support := List.mem_cons_of_mem _ ur
        exact ⟨by simpa using uR,fun e => out (e ▸ up),fun e => bout (e ▸ ur)⟩
      refine ⟨a,b,ab,R.reverse,rp.reverse,?_⟩
      intro u hu
      rw [eq] at hu
      rcases mem_insert.mp hu with e|e
      · exact e.symm ▸ save x p.start_mem_support
      · exact (mem_singleton.mp e).symm ▸ save y p.end_mem_support
    · have eq : T={x} := by
        apply Eq.symm
        apply eq_of_subset_of_card_le (singleton_subset_iff.mpr xt)
        have s := card_erase_add_one xt
        rw [not_nonempty_iff_eq_empty.mp many] at s
        simpa using s.ge
      have deg := high x xt
      rw [←B.card_neighborFinset_eq_degree] at deg
      obtain ⟨a,an,b,bn,ab⟩ := one_lt_card.mp (show 1<(B.neighborFinset x).card by omega)
      have xa := (B.mem_neighborFinset _ _).mp an
      have xb := (B.mem_neighborFinset _ _).mp bn
      let p : B.Walk a b := .cons xa.symm xb.toWalk
      have hp : p.IsPath := by
        rw [cons_isPath_iff]
        exact ⟨by simp [SimpleGraph.Adj.toWalk,xb.ne],by simp [SimpleGraph.Adj.toWalk,xa.ne.symm,ab]⟩
      refine ⟨a,b,ab,p,hp,?_⟩
      intro u hu
      have e : u=x := mem_singleton.mp (eq ▸ hu)
      subst u
      exact ⟨by simp [p,SimpleGraph.Adj.toWalk],xa.ne,xb.ne⟩

#print axioms exists_spine_through_two_nonleaves
end Graffiti189LongestPath.TreeTightSpine
