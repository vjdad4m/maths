import BagCut189
import TreeParity189
import Mathlib.Tactic.Linarith

open Finset SimpleGraph Graffiti189LongestPath
open scoped BigOperators
namespace Graffiti189LongestPath.WeightedTreeSums

open BagQuotient
variable {U : Type*} [Fintype U] [DecidableEq U]
  {B : SimpleGraph U} [DecidableRel B.Adj]

def side (c : U→Bool) (b : Bool) : Finset U := univ.filter (fun i => c i=b)
def mass (w : U→ℕ) (c : U→Bool) (b : Bool) : ℕ := ∑ i∈side c b,w i

omit [DecidableEq U] in
@[simp] theorem mem_side (c : U→Bool) (b : Bool) (i : U) :
    i∈side c b ↔ c i=b := by simp [side]

omit [DecidableEq U] in
theorem opposite (c : U→Bool) (proper : ∀ i j,B.Adj i j → c i≠c j)
    (x : U) : B.neighborFinset x⊆side c (!c x) := by
  intro y hym
  have h := proper x y ((B.mem_neighborFinset _ _).mp hym)
  apply (mem_side c (!c x) y).mpr
  cases ex : c x <;> cases ey : c y <;> simp_all

omit [Fintype U] [DecidableEq U] [DecidableRel B.Adj] in
theorem same_after_twice (c : U→Bool) (proper : ∀ i j,B.Adj i j → c i≠c j)
    {x y z : U} (xy : B.Adj x y) (yz : B.Adj y z) : c z=c x := by
  have p := proper x y xy
  have q := proper y z yz
  cases ex : c x <;> cases ey : c y <;> cases ez : c z <;> simp_all

/-- Sum all high neighbor demands around a vertex, with disjoint
distance-two successor groups because the quotient is a tree. -/
theorem sum_high_neighbors (tree : B.IsTree) (c : U→Bool)
    (proper : ∀ i j,B.Adj i j → c i≠c j)
    (w : U→ℕ) (d : ℕ) (x : U) (K : Finset U)
    (ks : K⊆B.neighborFinset x)
    (high : ∀ y∈K,d+1≤w y+∑ z∈B.neighborFinset y,w z) :
    K.card*(d+1)+w x≤K.card*w x+(∑ y∈K,w y)+mass w c (c x) := by
  classical
  let A (y : U) := (B.neighborFinset y).erase x
  have sumE (y : U) (yK : y∈K) :
      (∑ z∈A y,w z)+w x=∑ z∈B.neighborFinset y,w z :=
    Finset.sum_erase_add _ _ ((B.mem_neighborFinset _ _).mpr
      (((B.mem_neighborFinset _ _).mp (ks yK)).symm))
  have localDemand (y : U) (yK : y∈K) : d+1≤w y+w x+∑ z∈A y,w z := by
    have h := high y yK
    have e := sumE y yK
    omega
  have z := Finset.sum_le_sum (s:=K) (f:=fun _ : U => d+1)
    (g:=fun y => w y+w x+∑ z∈A y,w z) localDemand
  have sumC (n : ℕ) : (∑ _y∈K,n)=K.card*n := Finset.sum_const_nat (fun _ _ => rfl)
  rw [sumC (d+1),sum_add_distrib,sum_add_distrib,sumC (w x)] at z
  have sub : K.biUnion A⊆(side c (c x)).erase x := by
    intro u uu
    obtain ⟨y,yK,hu⟩ := mem_biUnion.mp uu
    obtain ⟨ne,e⟩ := mem_erase.mp hu
    have xu := same_after_twice c proper ((B.mem_neighborFinset _ _).mp (ks yK))
      ((B.mem_neighborFinset _ _).mp e)
    exact mem_erase.mpr ⟨ne,(mem_side c (c x) u).mpr xu⟩
  have dis : Set.PairwiseDisjoint (↑K:Set U) A := by
    intro i hi j hj ne
    apply disjoint_left.mpr
    intro u ui uj
    obtain ⟨ux,iu⟩ := mem_erase.mp ui
    obtain ⟨_,ju⟩ := mem_erase.mp uj
    have xi := (B.mem_neighborFinset _ _).mp (ks hi)
    have xj := (B.mem_neighborFinset _ _).mp (ks hj)
    exact ux (common_neighbor_unique tree ne
      ((B.mem_neighborFinset _ _).mp iu) ((B.mem_neighborFinset _ _).mp ju) xi.symm xj.symm)
  have sum := Finset.sum_le_sum_of_subset sub (f:=w)
  rw [Finset.sum_biUnion dis] at sum
  have es : (∑ z∈(side c (c x)).erase x,w z)+w x=mass w c (c x) :=
    Finset.sum_erase_add _ _ ((mem_side c (c x) x).mpr rfl)
  omega

omit [DecidableEq U] in
theorem neighbor_mass_floor (c : U→Bool)
    (proper : ∀ i j,B.Adj i j → c i≠c j) (w : U→ℕ) (d : ℕ)
    (cap : ∀ i,mass w c (c i)≤d+w i)
    (x : U) : (B.degree x:ℤ)*((mass w c (!c x):ℤ)-(d:ℤ))≤
      ∑ y∈B.neighborFinset x,(w y:ℤ) := by
  classical
  have h (i : U) (inN : i∈B.neighborFinset x) :
      (mass w c (!c x):ℤ)-(d:ℤ)≤(w i:ℤ) := by
    have eq : c i=(!c x) := (mem_side c (!c x) i).mp (opposite c proper x inN)
    have e := cap i
    rw [eq] at e
    omega
  have z := Finset.sum_le_sum h
  rw [sum_const,nsmul_eq_mul,B.card_neighborFinset_eq_degree] at z
  exact z

#print axioms sum_high_neighbors
#print axioms neighbor_mass_floor
end Graffiti189LongestPath.WeightedTreeSums
