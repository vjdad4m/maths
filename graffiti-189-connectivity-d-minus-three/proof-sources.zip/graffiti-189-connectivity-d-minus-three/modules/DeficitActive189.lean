import Normalize189
import ExactStarShore189
open SimpleGraph SimpleGraph.Walk Finset Graffiti189LongestPath
open Graffiti189LongestPath.Normalize Graffiti189LongestPath.OneSlack Graffiti189LongestPath.Rigidity Graffiti189LongestPath.PinRun
open Graffiti189LongestPath.ActiveStarHeight
open private Graffiti189LongestPath.GapTwin.splice_gap_two_allow_midpoint from GapTwin189
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
open private Graffiti189LongestPath.OneSlack.cardinal_flankVertices
  Graffiti189LongestPath.OneSlack.first_eq_if_no_pair from OneSlack189
open private Graffiti189LongestPath.outside_edge Graffiti189LongestPath.boundary_card_of_connectivity
  Graffiti189LongestPath.pin_data Graffiti189LongestPath.no_endpoints from SmallSeparator189
open private Graffiti189LongestPath.OneSlack.pin_of_neighbor_mem from OneSlack189
set_option warningAsError true
set_option linter.unusedSectionVars false

namespace Graffiti189LongestPath.DeficitActive
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem degree_floor_when_enough_vertices (k : Nat)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (enough : k+1≤Fintype.card V) (t : V) : k≤G.degree t := by
  classical
  by_cases h : ∃ z,z≠t ∧ ¬G.Adj t z
  · obtain ⟨z,zt,n⟩ := h
    rw [←G.card_neighborFinset_eq_degree]
    exact Graffiti189LongestPath.boundary_card_of_connectivity k conn
      (mem_singleton_self t) (fun e => zt (mem_singleton.mp e))
      (fun e => n ((G.mem_neighborFinset _ _).mp e))
      (disjoint_left.mpr (fun _ a b => ((G.mem_neighborFinset _ _).mp b).ne
        (mem_singleton.mp a).symm))
      (fun a ha v _ ed => (G.mem_neighborFinset _ _).mpr ((mem_singleton.mp ha) ▸ ed))
  · have hV : (univ : Finset V)⊆insert t (G.neighborFinset t) := by
      intro z _
      by_cases zt : z=t
      · exact mem_insert.mpr (Or.inl zt)
      exact mem_insert.mpr (Or.inr ((G.mem_neighborFinset _ _).mpr
        (Classical.byContradiction (fun no => h ⟨z,zt,no⟩))))
    have e := (card_le_card hV).trans (card_insert_le _ _)
    rw [card_univ,G.card_neighborFinset_eq_degree] at e
    omega

theorem enough_vertices_of_degree (d : Nat)
    (deg : ∀ u v : V,u≠v → d≤G.degree u ∨ d≤G.degree v)
    {u v : V} (ne : u≠v) : d+1≤Fintype.card V := by
  classical
  have degree_le (x : V) : G.degree x+1≤Fintype.card V := by
    have sub : G.neighborFinset x⊆(univ:Finset V).erase x := by
      intro z zz
      exact mem_erase.mpr ⟨((G.mem_neighborFinset _ _).mp zz).ne.symm,mem_univ _⟩
    have c := card_le_card sub
    rw [G.card_neighborFinset_eq_degree,card_erase_of_mem (mem_univ _),card_univ] at c
    have e : 0<Fintype.card V := Fintype.card_pos_iff.mpr ⟨x⟩
    omega
  exact (deg u v ne).elim (fun h => by have a := degree_le u; omega)
    (fun h => by have a := degree_le v; omega)

theorem deficit_three_not_one_omitted (hc : G.Connected) (k : Nat) (hk : 4≤k)
    (cap : ∀ z,(EvenFrom G z).card≤k+4)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → k+3≤G.degree u ∨ k+3≤G.degree v)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support) :
    ∃ y,y∉p.support ∧ y≠x := by
  classical
  by_contra no
  have sole (y : V) (hy : y∉p.support) : y=x :=
    Classical.byContradiction (fun e => no ⟨y,hy,e⟩)
  have ne : a≠x := fun e => hx (e ▸ p.start_mem_support)
  have enough := enough_vertices_of_degree (k+3) deg ne
  have floor := degree_floor_when_enough_vertices k conn (by omega) x
  have high_impossible {u v y : V} {q : G.Walk u v} (hq : IsLongest q) (hy : y∉q.support)
      (other : ∀ z,z∉q.support → z=y) : ¬k+3≤G.degree y := by
    intro yd
    have eq : OmittedStar q y={y} := by
      ext z
      rw [Graffiti189LongestPath.Rigidity.mem_omittedStar,mem_singleton]
      exact ⟨fun z => other _ z.1,fun e => ⟨e.symm ▸ hy,Or.inl e⟩⟩
    have count := star_card_degree_and_pins hq hy
    rw [eq,card_singleton] at count
    obtain ⟨i,hi⟩ := card_pos.mp (by omega : 0<(Pins q y).card)
    have th := high_omitted_pin_budget hc (k+3) k cap conn hq hy
      (Graffiti189LongestPath.pin_data hi).2 yd
    omega
  have low := high_impossible hp hx sole
  have st : OmittedStar p x={x} := by
    ext z
    rw [Graffiti189LongestPath.Rigidity.mem_omittedStar,mem_singleton]
    exact ⟨fun z => sole _ z.1,fun e => ⟨e.symm ▸ hx,Or.inl e⟩⟩
  have nPins := star_card_degree_and_pins hp hx
  rw [st,card_singleton] at nPins
  have nonempty : (PairedPins p x).Nonempty := by
    by_contra h
    have e : PairedPins p x=∅ := not_nonempty_iff_eq_empty.mp h
    have f : (FlankVertices p x).card=2*(Pins p x).card := by
      rw [Graffiti189LongestPath.OneSlack.cardinal_flankVertices hp,flank_count_exact hp hx,
        Graffiti189LongestPath.OneSlack.first_eq_if_no_pair (p:=p) e]
      omega
    have s : FlankVertices p x⊆DistanceTwo G x :=
      (flanks_outside_boundary hc hp hx).trans sdiff_subset
    have c := (card_le_card s).trans (distanceTwo_le_of_even (k+3) x (cap x))
    omega
  obtain ⟨j,hj⟩ := nonempty
  obtain ⟨jp,i,ip,step⟩ := mem_filter.mp hj
  have two : ∃ t∈Pins p x,t+2∈Pins p x := by
    rcases step with step|step
    · exact ⟨i,ip,step.symm ▸ jp⟩
    · exact ⟨j,jp,step.symm ▸ ip⟩
  obtain ⟨t,tp,tq⟩ := two
  have ir := (Graffiti189LongestPath.pin_data tq).1
  have ht : t+1<p.length := by omega
  have h0 := (Graffiti189LongestPath.pin_data tp).2
  have h2 := (Graffiti189LongestPath.pin_data tq).2
  obtain ⟨q,qP,ql,qs⟩ := Graffiti189LongestPath.GapTwin.splice_gap_two_allow_midpoint p hp.1
    (.nil : G.Walk x x) (by simp [isPath_def]) t (fun z hz hp' => by simp at hz; exact (hx (hz ▸ hp')).elim)
    ht h0.symm h2
  let y := p.getVert (t+1)
  have yp : y∈p.support := p.getVert_mem_support _
  have xy : x≠y := fun e => hx (e ▸ yp)
  have yh := (deg x y xy).resolve_left low
  have yq : y∉q.support := fun e => ((qs y).mp e).elim
    (fun h => by simp at h; exact xy h.symm) (fun h => h.2 rfl)
  have so (z : V) (zo : z∉q.support) : z=y := by
    have zx : z≠x := fun e => zo ((qs z).mpr (Or.inl (by simp [e])))
    have zp : z∈p.support := Classical.byContradiction (fun e => zx (sole _ e))
    exact Classical.byContradiction (fun e => zo ((qs z).mpr (Or.inr ⟨zp,e⟩)))
  have ql' : q.length=p.length := by simpa using ql
  have hq : IsLongest q := ⟨qP,fun u v s hs => (hp.2 u v s hs).trans (le_of_eq ql'.symm)⟩
  exact (high_impossible hq yq so yh)

/-- A nonspanning longest path in the first slack regime always has a
high-degree omitted vertex that directly attaches to the path. -/
theorem deficit_three_has_high_active (hc : G.Connected) (k : Nat) (hk : 4 ≤ k)
    (cap : ∀ v, (EvenFrom G v).card ≤ k+4)
    (conn : ∀ S : Finset V, S.card < k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (deg : ∀ u v : V, u ≠ v → k+3 ≤ G.degree u ∨ k+3 ≤ G.degree v)
    {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    (nonspan : ∃ x, x ∉ p.support) :
    ∃ x, x ∉ p.support ∧ k+3 ≤ G.degree x ∧ (Pins p x).Nonempty := by
  classical
  obtain ⟨x,hx,y,hy,ex⟩ := Graffiti189LongestPath.outside_edge p hc nonspan
  by_contra hNo
  have low {u v : V} (hu : u ∉ p.support) (hv : v ∈ p.support) (e : G.Adj u v) :
      G.degree u < k+3 := by
    by_contra! h
    obtain ⟨i,hi,_⟩ := Graffiti189LongestPath.OneSlack.pin_of_neighbor_mem hp hu hv e
    exact hNo ⟨u,hu,h,i,hi⟩
  have lowx := low hx hy ex
  obtain ⟨z,hz,ne⟩ := deficit_three_not_one_omitted hc k hk cap conn deg hp hx
  let A : Finset V := univ.filter (fun u => u ∉ p.support ∧ u ≠ x)
  have ha (u : V) : u ∈ A ↔ u ∉ p.support ∧ u ≠ x := by simp [A]
  have zal : z ∈ A := (ha z).mpr ⟨hz,ne⟩
  have aa : a ∉ A := fun h => ((ha _).mp h).1 p.start_mem_support
  have ab : a ∉ ({x}:Finset V) := by
    rw [mem_singleton]
    exact fun e => hx (e ▸ p.start_mem_support)
  have dis : Disjoint A ({x}:Finset V) := disjoint_left.mpr (fun u hu hv =>
    ((ha u).mp hu).2 (mem_singleton.mp hv))
  have bnd : ∀ u ∈ A, ∀ v ∉ A, G.Adj u v → v ∈ ({x}:Finset V) := by
    intro u hu v hv e
    by_cases h : v = x
    · exact mem_singleton.mpr h
    have vOn : v ∈ p.support := by
      by_contra hn
      exact hv ((ha v).mpr ⟨hn,h⟩)
    have hLow := low ((ha u).mp hu).1 vOn e
    rcases deg u x ((ha u).mp hu).2 with h|h <;> omega
  have hc' := Graffiti189LongestPath.boundary_card_of_connectivity k conn zal aa ab dis bnd
  simp at hc'
  omega

#print axioms deficit_three_has_high_active
end Graffiti189LongestPath.DeficitActive
