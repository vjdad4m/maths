import DeficitThirdShell189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.DeficitThirdShell
open private Graffiti189LongestPath.mem_distanceTwo Graffiti189LongestPath.dist_two from SmallSeparator189
open private Graffiti189LongestPath.Rigidity.mem_external Graffiti189LongestPath.Rigidity.mem_omittedStar from Rigidity189
open private Graffiti189LongestPath.OneSlack.boundary_except_pins_two Graffiti189LongestPath.OneSlack.card_pinVertices from OneSlack189
set_option warningAsError true
set_option maxHeartbeats 6000000
namespace Graffiti189LongestPath.DeficitDonors
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem donor_shell_upper (hc : G.Connected) (k : Nat) (hk : 400≤k)
    (cap : ∀ v,(DistanceTwo G v).card≤k+3)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
    (hc3 : (Pins p x).card≤3)
    (floor : ∀ v : ↥((OmittedStar p x : Finset V) : Set V),
      (OmittedStar p x).card≤2*(G.induce (OmittedStar p x : Set V)).degree v+10)
    (small : (OmittedStar p x).card≤k+30) :
    (Shell G x 3).card≤(k-27)*(k+3) ∨
      (Shell G x 3).card≤(k+3)*(k+3-80)+3*(k+3) := by
  classical
  let d := k+3
  let A := OmittedStar p x
  let B := External G A
  let P := PinVertices p x
  let C := B\P
  let H := Shell G x 3
  let I := G.induce (A : Set V)
  let HP := P.biUnion (fun t => H∩DistanceTwo G t)
  have cw : C⊆DistanceTwo G x := Graffiti189LongestPath.OneSlack.boundary_except_pins_two hc hp hx
  have ck : C.card≤d := (card_le_card cw).trans (cap x)
  have pk : P.card≤3 := by
    have e := Graffiti189LongestPath.OneSlack.card_pinVertices hp (x:=x)
    change P.card=(Pins p x).card at e
    omega
  have pk' : HP.card≤P.card*d := by
    apply card_biUnion_le_card_mul
    intro t ht
    exact (card_le_card inter_subset_right).trans (cap t)
  have pins : HP.card≤3*d := pk'.trans (Nat.mul_le_mul_right d pk)
  have xa : x∈A := Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
  have one (v : V) : ∃ u,u∈A ∧ (v∈C → G.Adj u v) := by
    by_cases vc : v∈C
    · obtain ⟨_,w,wa,wv⟩ := Graffiti189LongestPath.Rigidity.mem_external.mp (mem_sdiff.mp vc).1
      exact ⟨w,wa,fun _ => wv⟩
    · exact ⟨x,xa,fun h => (vc h).elim⟩
  choose f property using one
  have fA (v : V) (vc : v∈C) : f v∈A ∧ G.Adj (f v) v := ⟨(property v).1,(property v).2 vc⟩
  have sparse (g : V→V) (gA : ∀ v∈C,g v∈A ∧ G.Adj (g v) v)
      (lim : (C.image g).card≤k-30) : H.card≤(k-27)*d := by
    let D := C.image g
    let HD := D.biUnion (gateThird G x C)
    have hcvr : H⊆HD∪HP := shell_three_donor_cover hc hp hx g gA
    have each (v : V) (hv : v∈D) : (gateThird G x C v).card≤d := by
      obtain ⟨c,cc,rfl⟩ := mem_image.mp hv
      exact (card_le_card (gate_third_subset hc (gA c cc).1 C)).trans (cap _)
    have total : HD.card≤D.card*d := card_biUnion_le_card_mul D _ d each
    have h := (card_le_card hcvr).trans (card_union_le HD HP)
    have w := Nat.mul_le_mul_right d lim
    have id : (k-27)*d=(k-30)*d+3*d := by rw [show k-27=(k-30)+3 by omega,Nat.add_mul]
    change D.card*d≤(k-30)*d at w
    omega
  by_cases heavy : ∃ u∈A,40≤(C.filter (G.Adj u)).card
  · obtain ⟨u,ua,hu⟩ := heavy
    let g (v : V) := if G.Adj u v then u else f v
    have f' (v : V) (vc : v∈C) : g v∈A ∧ G.Adj (g v) v := by
      by_cases e : G.Adj u v
      · simpa [g,e] using (show u∈A ∧ G.Adj u v from ⟨ua,e⟩)
      · simpa [g,e] using fA v vc
    let C' := C.filter (fun w => ¬G.Adj u w)
    have comp : C'.card+(C.filter (G.Adj u)).card=C.card := by
      have e : C\(C.filter (G.Adj u))=C' := by ext v; simp [C']; tauto
      exact e ▸ card_sdiff_add_card_eq_card (filter_subset (G.Adj u) C)
    have sub : C.image g⊆insert u (C'.image f) := by
      intro v hv
      obtain ⟨c,cc,rfl⟩ := mem_image.mp hv
      by_cases e : G.Adj u c
      · simp [g,e]
      · exact mem_insert.mpr (Or.inr (by simpa [g,e] using
          (mem_image_of_mem f (show c∈C' from mem_filter.mpr ⟨cc,e⟩))))
    have c := (card_le_card sub).trans (card_insert_le _ _)
    have im : (C'.image f).card≤C'.card := card_image_le
    exact Or.inl (sparse g f' (by omega))
  let D := C.image f
  by_cases few : D.card≤k-30
  · exact Or.inl (sparse f fA few)
  right
  have dA (v : V) (vd : v∈D) : v∈A := by
    obtain ⟨b,bc,rfl⟩ := mem_image.mp vd
    exact (fA b bc).1
  have rep₀ (v : V) : ∃ b,v∈D → b∈C ∧ f b=v := by
    by_cases vd : v∈D
    · obtain ⟨b,bc,eq⟩ := mem_image.mp vd
      exact ⟨b,fun _ => ⟨bc,eq⟩⟩
    · exact ⟨x,fun h => (vd h).elim⟩
  choose rep repP using rep₀
  have repInj : Set.InjOn rep (↑D : Set V) := by
    intro v vd w wd h
    exact ((repP v vd).2).symm.trans ((congrArg f h).trans (repP w wd).2)
  have diet (v : V) (vd : v∈D) : (gateThird G x C v).card≤d-80 := by
    let v' : ↥(A : Set V) := ⟨v,dA v vd⟩
    let N := (I.neighborFinset v').image Subtype.val
    have nab : N⊆A := by
      intro z nz
      obtain ⟨z,_,rfl⟩ := mem_image.mp nz
      exact z.property
    have nc : N.card=I.degree v' := by
      rw [←I.card_neighborFinset_eq_degree,card_image_of_injective _ Subtype.val_injective]
    have nd (z : V) (zn : z∈N) : G.Adj v z := by
      obtain ⟨z,zz,rfl⟩ := mem_image.mp zn
      exact (I.mem_neighborFinset v' z).mp zz
    let L := D∩N
    have lsub : L⊆D := inter_subset_left
    have count := card_union_add_card_inter D N
    have total := card_le_card (union_subset dA nab)
    change (D∪N).card≤A.card at total
    have bound := floor v'
    change A.card≤2*I.degree v'+10 at bound
    change A.card≤k+30 at small
    change (D∪N).card+L.card=D.card+N.card at count
    have many : 120≤L.card := by omega
    let R := L.image rep
    have ri : R.card=L.card := card_image_of_injOn (fun _ h _ j e => repInj (lsub h) (lsub j) e)
    let S := C.filter (G.Adj v)
    let W := R\S
    have sc : S.card<40 := Nat.lt_of_not_ge (fun bad => heavy ⟨v,dA v vd,bad⟩)
    have wc : 80≤W.card := by
      have c := card_sdiff_add_card_inter R S
      have e := card_le_card (inter_subset_right : R∩S⊆S)
      change W.card+(R∩S).card=R.card at c
      omega
    have sub : W⊆DistanceTwo G v := by
      intro t wt
      obtain ⟨u,ul,rfl⟩ := mem_image.mp (mem_sdiff.mp wt).1
      have ud := lsub ul
      have uv := nd u (mem_inter.mp ul).2
      obtain ⟨bc,fb⟩ := repP u ud
      have ed : G.Adj u (rep u) := Eq.mp (congrArg (fun w => G.Adj w (rep u)) fb) (fA _ bc).2
      have no : ¬G.Adj v (rep u) := fun e => (mem_sdiff.mp wt).2 (mem_filter.mpr ⟨bc,e⟩)
      have ne : v≠rep u := fun eq =>
        (Graffiti189LongestPath.Rigidity.mem_external.mp (mem_sdiff.mp bc).1).1 (eq ▸ dA v vd)
      exact Graffiti189LongestPath.mem_distanceTwo.mpr (Graffiti189LongestPath.dist_two hc ne no uv ed)
    have dis : Disjoint W (gateThird G x C v) := disjoint_left.mpr (by
      intro z zw zh
      obtain ⟨u,ul,e⟩ := mem_image.mp (mem_sdiff.mp zw).1
      have bc := (repP u (lsub ul)).1
      have q := Graffiti189LongestPath.mem_distanceTwo.mp (cw (e ▸ bc))
      have q' := mem_shell.mp (mem_gateThird.mp zh).1
      omega)
    have span := card_le_card (union_subset sub (gate_third_subset hc (dA v vd) C))
    rw [card_union_of_disjoint dis] at span
    have cb := cap v
    omega
  let HD := D.biUnion (gateThird G x C)
  have cc : H⊆HD∪HP := shell_three_donor_cover hc hp hx f fA
  have cnt : HD.card≤D.card*(d-80) := card_biUnion_le_card_mul D _ (d-80) diet
  have dc : D.card≤d := (show D.card≤C.card from card_image_le).trans ck
  have mt := Nat.mul_le_mul_right (d-80) dc
  have c := (card_le_card cc).trans (card_union_le HD HP)
  change H.card≤d*(d-80)+3*d
  omega

#print axioms donor_shell_upper
end Graffiti189LongestPath.DeficitDonors
