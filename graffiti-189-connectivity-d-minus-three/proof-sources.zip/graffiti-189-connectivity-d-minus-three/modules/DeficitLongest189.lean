import DeficitActive189
import PosaOneLow189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.DeficitActive Graffiti189LongestPath.Rigidity Graffiti189LongestPath.HighEndpoint189
open Graffiti189LongestPath.PosaCrossCycle Graffiti189LongestPath.PosaEndpointCycle
set_option warningAsError true
set_option maxHeartbeats 4200000
namespace Graffiti189LongestPath.DeficitLongest
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- A connected nontraceable graph with at most one vertex below d has
a longest path of length at least 2d, provided its minimum degree is ≥2. -/
theorem longest_length_ge_twice_of_not_traceable (hc : G.Connected) (d : Nat) (d₂ : 2≤d)
    (floor : ∀ z,2≤G.degree z) (deg : ∀ u v : V,u≠v → d≤G.degree u ∨ d≤G.degree v)
    (fail : ¬∃ (u v : V) (q : G.Walk u v),q.IsPath ∧ ∀ z,z∈q.support)
    {a b : V} {p : G.Walk a b} (hp : IsLongest p) : 2*d≤p.length := by
  classical
  obtain ⟨x,y,q,hq,_,hx,hy⟩ := rotate_to_two_high_endpoints_of_min_two d floor deg hp
  have same : q.length=p.length := le_antisymm (hp.2 x y q hq.1) (hq.2 a b p hp.1)
  rw [←same]
  apply Nat.le_of_not_gt
  intro bound
  have complete {z : V} {c : G.Walk z z} (cc : c.IsCycle) (len : q.length<c.length)
      (sup : ∀ w,w∈c.support ↔ w∈q.support) : False := by
    exact fail ⟨x,y,q,hq.1,PosaCycleExtend189.spanning_of_longest_path_cycle hq hc c cc sup len⟩
  have ap := beginning_neighbors_in_spine hq
  have bp := ending_neighbors_in_spine hq
  have p2 : 2≤q.length := by
    have sub : G.neighborFinset x⊆q.support.toFinset.erase x := by
      intro z zn
      have edge := (G.mem_neighborFinset _ _).mp zn
      exact mem_erase.mpr ⟨edge.ne.symm,List.mem_toFinset.mpr (ap z edge)⟩
    have n := card_le_card sub
    rw [G.card_neighborFinset_eq_degree,card_erase_of_mem (List.mem_toFinset.mpr q.start_mem_support),
      List.toFinset_card_of_nodup hq.1.support_nodup,length_support,Nat.add_sub_cancel] at n
    omega
  by_cases edge : G.Adj x y
  · obtain ⟨c,cp,cl,cs⟩ := close_spine_path q hq.1 p2 edge
    exact complete cp (by omega) cs
  have nedge : ¬G.Adj y x := fun e => edge e.symm
  let L := innerNeighbors q x
  let R := innerNeighbors q y
  let S := L.image (fun i => i-1)
  have lc : L.card=G.degree x := innerNeighbors_count q hq.1 x (G.loopless x) edge ap
  have rc : R.card=G.degree y := innerNeighbors_count q hq.1 y nedge (G.loopless y) bp
  have ls (i : Nat) (h : i∈L) := (mem_innerNeighbors q x i).mp h
  have rs (i : Nat) (h : i∈R) := (mem_innerNeighbors q y i).mp h
  have scl : S.card=L.card := by
    apply card_image_of_injOn
    intro i hi j hj e
    have ip := (ls i hi).1
    have jp := (ls j hj).1
    change i-1=j-1 at e
    omega
  have Rng : S∪R⊆range q.length := by
    intro z hz
    rcases mem_union.mp hz with hz|hz
    · obtain ⟨i,ii,rfl⟩ := mem_image.mp hz
      exact mem_range.mpr (by have q := (ls i ii).2.1; omega)
    · exact mem_range.mpr (rs z hz).2.1
  have nd : ¬Disjoint S R := by
    intro dis
    have u := card_le_card Rng
    rw [card_union_of_disjoint dis,card_range,scl,lc,rc] at u
    omega
  have inter : ∃ j∈S,j∈R := by
    apply Classical.byContradiction
    intro no
    exact nd (disjoint_left.mpr (fun a ha hb => no ⟨a,ha,hb⟩))
  obtain ⟨j,jS,jR⟩ := inter
  obtain ⟨i,iL,ij⟩ := mem_image.mp jS
  have jj := rs j jR
  have ii := ls i iL
  obtain ⟨c,cp,sub,cs⟩ := cycle_from_crossing q hq.1 i j jj.1 (by omega) ii.2.1 ii.2.2 jj.2.2
  have all : ∀ i≤q.length,q.getVert i∈c.support := by
    intro t tN
    apply cs
    exact PosaCrossing189.mem_kept.mpr (by omega)
  have sup : ∀ w,w∈c.support ↔ w∈q.support := by
    intro w
    refine ⟨sub w,?_⟩
    intro hw
    obtain ⟨t,eq,tN⟩ := mem_support_iff_exists_getVert.mp hw
    exact eq ▸ all t tN
  have count := cycle_ge_index_card q hq.1 c cp (range (q.length+1))
    (fun t ht => by have q := mem_range.mp ht; omega)
    (fun t ht => all t (by have q := mem_range.mp ht; omega))
  rw [card_range] at count
  exact complete cp (by omega) sup

#print axioms longest_length_ge_twice_of_not_traceable
end Graffiti189LongestPath.DeficitLongest
