import PosaOneLow189
import DeficitLongest189
import FanWeighted189
import MengerRoutable189
import SixDefectConnectivity189
import SingleHeight189
import StarCycleClosure189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack Graffiti189LongestPath.ActiveStarHeight
open Graffiti189LongestPath.ExactStarShore Graffiti189LongestPath.ShoreConnectivity Graffiti189LongestPath.ShoreDegrees
open Graffiti189LongestPath.SixDefectCharge Graffiti189LongestPath.SixDefectConnectivity Graffiti189LongestPath.StarCycleClosure
open Graffiti189LongestPath.Normalize Graffiti189LongestPath.PosaOneLow Graffiti189LongestPath.MengerRoutable Graffiti189LongestPath.FanWeighted
open Graffiti189LongestPath.CycleHallSplice Graffiti189LongestPath.UltraOrder Graffiti189LongestPath.SingleHeight
open private Graffiti189LongestPath.Rigidity.mem_external Graffiti189LongestPath.Rigidity.mem_omittedStar from Rigidity189
open private Graffiti189LongestPath.boundary_card_of_connectivity Graffiti189LongestPath.no_endpoints from SmallSeparator189
set_option warningAsError true
set_option linter.unusedVariables false
set_option maxHeartbeats 4500000
namespace Graffiti189LongestPath.DeficitShore
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem six_defect_star_stays_connected (hc : G.Connected) (k : Nat) (_hk : 6≤k)
    (cap : ∀ v,(EvenFrom G v).card≤k+4)
    (conn : ∀ D : Finset V,D.card<k → (G.induce ((↑D : Set V)ᶜ)).Connected)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p)
    (hx : x∉p.support)
    (sat : (External G (OmittedStar p x)).card≤k+6)
    (far : k≤((univ:Finset V)\(OmittedStar p x∪External G (OmittedStar p x))).card)
    (X : Finset V) (inside : X⊆OmittedStar p x)
    (small : 3*X.card+18<(OmittedStar p x).card) :
    (G.induce ((↑((OmittedStar p x)\X)):Set V)).Connected := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let U := univ\(A∪B)
  change B.card≤k+6 at sat
  have large : k≤U.card := far
  have rA {z : V} (hz : z∈U) : z∉A := fun h =>
    (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inl h))
  have rB {z : V} (hz : z∈U) : z∉B := fun h =>
    (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inr h))
  have ul : ∀ u∈U,∀ v∉U,G.Adj u v → v∈B := by
    intro u hu v hv ed
    have cov : v∈A∪B := Classical.byContradiction
      (fun h => hv (mem_sdiff.mpr ⟨mem_univ _,h⟩))
    exact (mem_union.mp cov).elim (fun h => (rB hu
      (Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨rA hu,v,h,ed.symm⟩)).elim) id
  have ub : Disjoint U B := disjoint_left.mpr (fun _ h h' => rB h h')
  have au : Disjoint A U := disjoint_left.mpr (fun _ h h' => rA h' h)
  have ab : Disjoint A B := disjoint_left.mpr (fun _ h h' =>
    (Graffiti189LongestPath.Rigidity.mem_external.mp h').1 h)
  have cA : ∀ y∈A,∀ z∉A,G.Adj y z → z∈B := fun _ hy _ hz e =>
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨hz,_,hy,e⟩
  have r : ∀ z∈A,z=x ∨ G.Adj x z := fun _ h =>
    (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp h).2
  exact six_defect_shore_stays_connected hc k A B U X x conn (by omega) ab ub au large
    (by omega) cA ul (fun v => distanceTwo_le_of_even (k+3) v (cap v)) r inside small


theorem six_defect_induced_floor (hc : G.Connected) (k : Nat) (_hk : 6≤k)
    (cap : ∀ v,(EvenFrom G v).card≤k+4)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
   
    (sat : (External G (OmittedStar p x)).card≤k+6)
    (far : k≤((univ:Finset V)\(OmittedStar p x∪External G (OmittedStar p x))).card)
    (v : ↥((OmittedStar p x : Finset V) : Set V)) :
    (OmittedStar p x).card≤2*(G.induce (OmittedStar p x : Set V)).degree v+10 := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let U := univ\(A∪B)
  let I := G.induce (A : Set V)
  change B.card≤k+6 at sat
  have large : k≤U.card := far
  have rA {z : V} (hz : z∈U) : z∉A := fun h => (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inl h))
  have rB {z : V} (hz : z∈U) : z∉B := fun h => (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inr h))
  have ul : ∀ u∈U,∀ v∉U,G.Adj u v → v∈B := by
    intro u hu v hv ed
    have cov : v∈A∪B := Classical.byContradiction (fun h => hv (mem_sdiff.mpr ⟨mem_univ _,h⟩))
    exact (mem_union.mp cov).elim (fun h => (rB hu
      (Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨rA hu,v,h,ed.symm⟩)).elim) id
  have ub : Disjoint U B := disjoint_left.mpr (fun _ h h' => rB h h')
  have au : Disjoint A U := disjoint_left.mpr (fun _ h h' => rA h' h)
  have ab : Disjoint A B := disjoint_left.mpr (fun _ h h' =>
    (Graffiti189LongestPath.Rigidity.mem_external.mp h').1 h)
  have cA : ∀ y∈A,∀ z∉A,G.Adj y z → z∈B := fun _ hy _ hz e =>
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨hz,_,hy,e⟩
  have root : ∀ z∈A,z=x ∨ G.Adj x z := fun _ h =>
    (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp h).2
  have va : v.val∈A := v.property
  have vo : v.val∉p.support := (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp va).1
  have low : k≤G.degree v.val := by
    have av : a≠v.val := fun e => vo (e ▸ p.start_mem_support)
    rw [←G.card_neighborFinset_eq_degree]
    apply Graffiti189LongestPath.boundary_card_of_connectivity k conn (A:={v.val}) (a:=a)
    · exact mem_singleton_self _
    · exact fun h => av (mem_singleton.mp h)
    · exact fun h => (Graffiti189LongestPath.no_endpoints hp vo).1 ((G.mem_neighborFinset _ _).mp h)
    · exact disjoint_left.mpr (fun _ h e => ((G.mem_neighborFinset v.val _).mp e).ne (mem_singleton.mp h).symm)
    · exact fun _ h _ _ e => (G.mem_neighborFinset _ _).mpr ((mem_singleton.mp h) ▸ e)
  have ineq := six_defect_shore_charge hc (k+3) k A U B conn (by omega) ab ub au large
    cA ul (fun v => distanceTwo_le_of_even (k+3) v (cap v)) root v
  change A.card+G.degree v.val+_≤2*I.degree v+(k+3)+7 at ineq
  change A.card≤2*I.degree v+10
  omega

theorem six_defect_root_deleted_degrees (hc : G.Connected) (k : Nat) (_hk : 6≤k)
    (cap : ∀ v,(EvenFrom G v).card≤k+4)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
   
    (sat : (External G (OmittedStar p x)).card≤k+6)
    (far : k≤((univ:Finset V)\(OmittedStar p x∪External G (OmittedStar p x))).card)
    (v : ↥(((OmittedStar p x).erase x : Finset V) : Set V)) :
    (OmittedStar p x).card≤2*(G.induce (((OmittedStar p x).erase x : Finset V) : Set V)).degree v+12 ∧
      (k+3≤G.degree v.val →
       (OmittedStar p x).card≤2*(G.induce (((OmittedStar p x).erase x : Finset V) : Set V)).degree v+9) := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let U := univ\(A∪B)
  let T := A.erase x
  let J := G.induce (T : Set V)
  let I := G.induce (A : Set V)
  change B.card≤k+6 at sat
  have large : k≤U.card := far
  have rA {z : V} (hz : z∈U) : z∉A := fun h => (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inl h))
  have rB {z : V} (hz : z∈U) : z∉B := fun h => (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inr h))
  have ul : ∀ u∈U,∀ v∉U,G.Adj u v → v∈B := by
    intro u hu v hv ed
    have cov : v∈A∪B := Classical.byContradiction (fun h => hv (mem_sdiff.mpr ⟨mem_univ _,h⟩))
    exact (mem_union.mp cov).elim (fun h => (rB hu
      (Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨rA hu,v,h,ed.symm⟩)).elim) id
  have ub : Disjoint U B := disjoint_left.mpr (fun _ h h' => rB h h')
  have au : Disjoint A U := disjoint_left.mpr (fun _ h h' => rA h' h)
  have ab : Disjoint A B := disjoint_left.mpr (fun _ h h' =>
    (Graffiti189LongestPath.Rigidity.mem_external.mp h').1 h)
  have cA : ∀ y∈A,∀ z∉A,G.Adj y z → z∈B := fun _ hy _ hz e =>
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨hz,_,hy,e⟩
  have root : ∀ z∈A,z=x ∨ G.Adj x z := fun _ h =>
    (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp h).2
  have va : v.val∈A := (mem_erase.mp v.property).2
  have vo : v.val∉p.support := (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp va).1
  have vx : G.Adj v.val x := ((root _ va).resolve_left (mem_erase.mp v.property).1).symm
  have xa : x∈A := Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
  have low : k≤G.degree v.val := by
    have av : a≠v.val := fun e => vo (e ▸ p.start_mem_support)
    rw [←G.card_neighborFinset_eq_degree]
    apply Graffiti189LongestPath.boundary_card_of_connectivity k conn (A:={v.val}) (a:=a)
    · exact mem_singleton_self _
    · exact fun h => av (mem_singleton.mp h)
    · exact fun h => (Graffiti189LongestPath.no_endpoints hp vo).1 ((G.mem_neighborFinset _ _).mp h)
    · exact disjoint_left.mpr (fun _ h e => ((G.mem_neighborFinset v.val _).mp e).ne (mem_singleton.mp h).symm)
    · exact fun _ h _ _ e => (G.mem_neighborFinset _ _).mpr ((mem_singleton.mp h) ▸ e)
  let av : ↥(A : Set V) := ⟨v.val,va⟩
  have ineq := six_defect_shore_charge hc (k+3) k A U B conn (by omega) ab ub au large
    cA ul (fun v => distanceTwo_le_of_even (k+3) v (cap v)) root av
  change A.card+G.degree v.val+_≤2*I.degree av+(k+3)+7 at ineq
  have id := universal_root_degree_drop A x xa v vx
  change J.degree v+1=I.degree av at id
  change A.card≤2*J.degree v+12 ∧ (k+3≤G.degree v.val → A.card≤2*J.degree v+9)
  omega

#print axioms universal_root_degree_drop

theorem six_defect_root_deleted_long_cycle
    (hc : G.Connected) (k : Nat) (hk : 24≤k)
    (cap : ∀ v,(EvenFrom G v).card≤k+4)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
    (sat : (External G (OmittedStar p x)).card≤k+6)
    (far : k≤((univ:Finset V)\(OmittedStar p x∪External G (OmittedStar p x))).card)
    (height : k+1≤(OmittedStar p x).card)
    (deg : ∀ u v : V,u≠v → k+3≤G.degree u ∨ k+3≤G.degree v) :
    ∃ a, ∃ c : (G.induce (((OmittedStar p x).erase x : Finset V) : Set V)).Walk a a,
      c.IsCycle ∧ 2*(((OmittedStar p x).card-10)/2)≤c.length := by
  classical
  let A := OmittedStar p x
  let T := A.erase x
  let W := ↥(T : Set V)
  let J := G.induce (T : Set V)
  let m := (A.card-10)/2
  have xt : x∈A := Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
  have h : k+1≤A.card := height
  have wc : Fintype.card W=A.card-1 := by
    change Fintype.card ↥T=A.card-1
    exact (Fintype.card_coe T).trans (card_erase_of_mem xt)
  have del (S : Finset W) (sc : S.card<2) :
      (J.induce ((↑S : Set W)ᶜ)).Connected := by
    let e : W ↪ V := ⟨Subtype.val,Subtype.val_injective⟩
    let X := insert x (S.map e)
    have xs : X⊆A := by
      intro v vx
      rcases mem_insert.mp vx with rfl|h
      · exact xt
      · obtain ⟨w,_,rfl⟩ := mem_map.mp h
        exact (mem_erase.mp w.property).2
    have xl := (card_insert_le x (S.map e)).trans (by rw [card_map])
    change X.card≤S.card+1 at xl
    have sz : 3*X.card+18<(OmittedStar p x).card := by change 3*X.card+18<A.card; omega
    have con := six_defect_star_stays_connected hc k (by omega) cap conn
      hp hx sat far X xs sz
    exact (erase_root_and_set_iso (G:=G) A x S).connected_iff.mp con
  have low (v : W) : 2≤J.degree v := by
    have dg := (six_defect_root_deleted_degrees hc k (by omega) cap conn hp
      hx sat far v).1
    change A.card≤2*J.degree v+12 at dg
    omega
  have highJ (v : W) (vh : k+3≤G.degree v.val) : m≤J.degree v := by
    have dg := (six_defect_root_deleted_degrees hc k (by omega) cap conn hp
      hx sat far v).2 vh
    change A.card≤2*J.degree v+9 at dg
    dsimp [m]
    omega
  have pair (u v : W) (ne : u≠v) : m≤J.degree u ∨ m≤J.degree v :=
    (deg u.val v.val (fun e => ne (Subtype.ext e))).imp (highJ u) (highJ v)
  have mc : 2≤m := by dsimp [m]; omega
  obtain ⟨r,c,cc,cl⟩ := proved_one_low_circumference W J m mc (by omega) del low pair
  have mm : 2*m≤Fintype.card W := by dsimp [m]; omega
  rw [min_eq_right mm] at cl
  exact ⟨r,c,cc,cl⟩


theorem six_defect_no_long_shore_cycle (hc : G.Connected) (k : Nat) (hk : 6≤k)
    (cap : ∀ v,(EvenFrom G v).card≤k+4)
    (conn : ∀ D : Finset V,D.card<k → (G.induce ((↑D : Set V)ᶜ)).Connected)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p)
    (hx : x∉p.support)
    (sat : (External G (OmittedStar p x)).card≤k+6)
    (far : k≤((univ:Finset V)\(OmittedStar p x∪External G (OmittedStar p x))).card)
    (large : 24<(OmittedStar p x).card)
    (len : Nat)
    (ash : k≤(OmittedStar p x).card)
    (long : Fintype.card V < (OmittedStar p x).card+k+(k+1)*(len+1))
    (cyc : ∃ z, ∃ c : (G.induce (((OmittedStar p x).erase x : Finset V) : Set V)).Walk z z,
      c.IsCycle ∧ max 2 len≤c.length) : False := by
  classical
  let A := OmittedStar p x
  change k≤A.card at ash
  change 24<A.card at large
  let Z : Set V := ((A.erase x : Finset V) : Set V)
  let J := G.induce Z
  have sepConn (S : Finset Z) (sc : S.card<2) :
      (J.induce ((↑S : Set Z)ᶜ)).Connected := by
    let e : Z ↪ V := ⟨Subtype.val,Subtype.val_injective⟩
    let X := insert x (S.map e)
    have xs : X⊆A := by
      intro v vx
      rcases mem_insert.mp vx with rfl|h
      · exact Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
      · obtain ⟨w,_,rfl⟩ := mem_map.mp h
        exact (mem_erase.mp w.property).2
    have xl := (card_insert_le x (S.map e)).trans (by rw [card_map])
    change X.card≤S.card+1 at xl
    have con := six_defect_star_stays_connected hc k hk cap conn hp
      hx sat far X xs (show 3*X.card+18<A.card by omega)
    exact (erase_root_and_set_iso (G:=G) A x S).connected_iff.mp con
  let f : J →g G := ⟨Subtype.val, fun e => e⟩
  have fi : Function.Injective f := Subtype.val_injective
  have off (z : Z) : x≠f z := fun e => (mem_erase.mp z.property).1 e.symm
  have adj (z : Z) : G.Adj x (f z) := by
    have zz := (mem_erase.mp z.property).2
    exact (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp zz).2.resolve_left (fun ne => off z ne.symm)
  obtain ⟨a,c,hc',cl⟩ := cyc
  have big : 2≤c.support.toFinset.card := by
    rw [cycle_card_support c hc']
    exact (le_max_left _ _).trans cl
  have L : len≤c.length := (le_max_right _ _).trans cl
  have route : ∀ u∈A,∀ v∈A,u≠v →
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈A) ∧ len+1≤q.length+1 := by
    intro u ua v va uv
    have rA {z : V} (e : z=x ∨ ∃ w : Z,f w=z) : z∈A := by
      rcases e with rfl|⟨w,rfl⟩
      · exact Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
      · exact (mem_erase.mp w.property).2
    by_cases hu : u=x
    · subst u
      let t : Z := ⟨v,mem_erase.mpr ⟨uv.symm,va⟩⟩
      obtain ⟨q,qp,ql,qs⟩ := cycle_to_prescribed_root_route f fi off adj c hc'
        (t:=t) (fun s h => sepConn s (by omega))
      exact ⟨q,qp,fun z hz => rA (qs z hz),by omega⟩
    by_cases hv : v=x
    · subst v
      let t : Z := ⟨u,mem_erase.mpr ⟨hu,ua⟩⟩
      obtain ⟨q,qp,ql,qs⟩ := cycle_to_prescribed_root_route f fi off adj c hc'
        (t:=t) (fun s h => sepConn s (by omega))
      exact ⟨q.reverse,qp.reverse,fun z hz => rA (qs z (by
        simpa only [support_reverse,List.mem_reverse] using hz)),by simpa using (by omega : len+1≤q.length+1)⟩
    let s : Z := ⟨u,mem_erase.mpr ⟨hu,ua⟩⟩
    let t : Z := ⟨v,mem_erase.mpr ⟨hv,va⟩⟩
    have ne : s≠t := fun e => uv (congrArg Subtype.val e)
    obtain ⟨q,qp,ql,qs⟩ := cycle_to_prescribed_route f fi ne off adj c hc' big sepConn
    exact ⟨q,qp,fun z hz => rA (qs z hz),by omega⟩
  have ao : ∀ z∈A,z∉p.support := fun _ z => (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp z).1
  obtain ⟨F⟩ := hooks_of_small_deletion_connectivity A k hp ao ash (support_large k conn hp hx) conn
  have low := weighted_hooked_lower k (by omega) hp (len+1) A ao (by omega) route F
  change Fintype.card V<A.card+k+(k+1)*(len+1) at long
  omega

#print axioms erase_root_and_set_iso

#print axioms six_defect_root_deleted_long_cycle
#print axioms six_defect_no_long_shore_cycle
end Graffiti189LongestPath.DeficitShore
