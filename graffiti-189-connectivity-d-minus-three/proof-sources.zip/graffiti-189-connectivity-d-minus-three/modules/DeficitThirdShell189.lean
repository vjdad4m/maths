import OneSlack189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack
open private Graffiti189LongestPath.distance_on_geodesic Graffiti189LongestPath.pin_data
  Graffiti189LongestPath.mem_distanceTwo Graffiti189LongestPath.dist_two from SmallSeparator189
open private Graffiti189LongestPath.Rigidity.mem_external Graffiti189LongestPath.Rigidity.mem_omittedStar from Rigidity189
open private Graffiti189LongestPath.OneSlack.pin_of_neighbor_mem Graffiti189LongestPath.OneSlack.card_pinVertices
  Graffiti189LongestPath.OneSlack.boundary_except_pins_two from OneSlack189
set_option warningAsError true
set_option maxHeartbeats 4500000
namespace Graffiti189LongestPath.DeficitThirdShell
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- Third-shell vertices reachable through a nonpin gateway of `u`. -/
noncomputable def gateThird (G : SimpleGraph V) [DecidableRel G.Adj] (x : V) (C : Finset V) (u : V) : Finset V := by
  classical
  exact (Shell G x 3).filter (fun z => ∃ b∈C,G.Adj u b ∧ G.Adj b z)

omit [DecidableEq V] in
theorem mem_gateThird {x u z : V} {C : Finset V} :
    z∈gateThird G x C u ↔ z∈Shell G x 3 ∧ ∃ b∈C,G.Adj u b ∧ G.Adj b z := by
  classical
  simp [gateThird]

theorem gate_third_subset (hc : G.Connected) {a b x u : V} {p : G.Walk a b}
    (ua : u∈OmittedStar p x) (C : Finset V) : gateThird G x C u⊆DistanceTwo G u := by
  intro z hz
  obtain ⟨zz,s,_,us,sz⟩ := mem_gateThird.mp hz
  have zd := mem_shell.mp zz
  have ux : G.dist x u≤1 := by
    rcases (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp ua).2 with h|h
    · rw [h,dist_self]; omega
    · rw [dist_eq_one_iff_adj.mpr h]
  have ne : u≠z := fun e => by rw [e] at ux; omega
  have no : ¬G.Adj u z := by
    intro ed
    have uz := dist_eq_one_iff_adj.mpr ed
    have tr := hc.dist_triangle (u:=x) (v:=u) (w:=z)
    omega
  exact Graffiti189LongestPath.mem_distanceTwo.mpr (Graffiti189LongestPath.dist_two hc ne no us sz)

/-- Every third-shell vertex goes through either a charged pin or a donor
chosen for a nonpin gateway. All gates with the same donor share one budget. -/
theorem shell_three_donor_cover (hc : G.Connected)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
    (f : V → V)
    (chooseA : ∀ v∈External G (OmittedStar p x)\PinVertices p x,
      f v∈OmittedStar p x ∧ G.Adj (f v) v) :
    let C := External G (OmittedStar p x)\PinVertices p x
    Shell G x 3 ⊆
      (C.image f).biUnion (gateThird G x C) ∪
      (PinVertices p x).biUnion (fun t => Shell G x 3 ∩ DistanceTwo G t) := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let C := B\PinVertices p x
  let H := Shell G x 3
  change H ⊆ (C.image f).biUnion (gateThird G x C) ∪ _
  intro z hz
  have dz := mem_shell.mp hz
  obtain ⟨q,ql⟩ := hc.exists_walk_length_eq_dist x z
  have len := ql.trans dz
  let u := q.getVert 2
  have du : G.dist x u=2 := Graffiti189LongestPath.distance_on_geodesic hc q ql 2 (by omega)
  have uz : G.Adj u z := by
    have e := q.adj_getVert_succ (i:=2) (by omega : 2<q.length)
    rwa [show q.getVert 3=z by rw [←len,getVert_length]] at e
  by_cases ub : u∈B
  · have no : u∉PinVertices p x := by
      intro h
      obtain ⟨l,hl,eq⟩ := mem_image.mp h
      have ed : G.Adj x u := eq ▸ (Graffiti189LongestPath.pin_data hl).2
      have e := dist_eq_one_iff_adj.mpr ed
      omega
    have uc : u∈C := mem_sdiff.mpr ⟨ub,no⟩
    exact mem_union.mpr (Or.inl (mem_biUnion.mpr
      ⟨f u,mem_image_of_mem _ uc,mem_gateThird.mpr ⟨hz,u,uc,(chooseA u uc).2,uz⟩⟩))
  let t := q.getVert 1
  have xt : G.Adj x t := by simpa [t] using q.adj_getVert_succ (i:=0) (by omega)
  have tu : G.Adj t u := q.adj_getVert_succ (i:=1) (by omega)
  have tp : t∈p.support := by
    apply Classical.byContradiction
    intro no
    have ta : t∈A := Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨no,Or.inr xt⟩
    have ua : u∉A := by
      intro e
      have dc := (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp e).2
      rcases dc with ee|ee
      · rw [ee,dist_self] at du; omega
      · have c := dist_eq_one_iff_adj.mpr ee; omega
    exact ub (Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨ua,t,ta,tu⟩)
  obtain ⟨i,hi,eq⟩ := Graffiti189LongestPath.OneSlack.pin_of_neighbor_mem hp hx tp xt
  have tv : t∈PinVertices p x := mem_image.mpr ⟨i,hi,eq⟩
  have dt := dist_eq_one_iff_adj.mpr xt
  have tz : t≠z := fun e => by rw [e] at dt; omega
  have tn : ¬G.Adj t z := by
    intro e
    have d' := dist_eq_one_iff_adj.mpr e
    have tr := hc.dist_triangle (u:=x) (v:=t) (w:=z)
    omega
  exact mem_union.mpr (Or.inr (mem_biUnion.mpr ⟨t,tv,mem_inter.mpr
    ⟨hz,Graffiti189LongestPath.mem_distanceTwo.mpr (Graffiti189LongestPath.dist_two hc tz tn tu uz)⟩⟩))

/-- Outside the star, the cut, and the two last shell levels, only the
distance-two budget at the root remains. -/
theorem order_le_star_cut_two_three_four (hc : G.Connected)
    {a b x : V} {p : G.Walk a b} (hx : x∉p.support)
    (rad : ∀ z,G.dist x z≤4) :
    Fintype.card V≤(OmittedStar p x).card+(External G (OmittedStar p x)).card+
      (DistanceTwo G x).card+(Shell G x 3).card+(Shell G x 4).card := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let F := DistanceTwo G x
  let H := Shell G x 3
  let W := Shell G x 4
  have cover : (univ : Finset V)⊆A∪B∪F∪H∪W := by
    intro z _
    by_cases wz : G.dist x z=4
    · exact mem_union.mpr (Or.inr (mem_shell.mpr wz))
    apply mem_union.mpr
    left
    by_cases hz : G.dist x z=3
    · exact mem_union.mpr (Or.inr (mem_shell.mpr hz))
    apply mem_union.mpr
    left
    by_cases fz : G.dist x z=2
    · exact mem_union.mpr (Or.inr (Graffiti189LongestPath.mem_distanceTwo.mpr fz))
    apply mem_union.mpr
    left
    have xa : x∈A := Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
    by_cases za : z∈A
    · exact mem_union.mpr (Or.inl za)
    have nez : x≠z := fun e => za (e ▸ xa)
    have adj : G.Adj x z := by
      apply dist_eq_one_iff_adj.mp
      have n : G.dist x z≠0 := fun e => nez (hc.dist_eq_zero_iff.mp e)
      have r := rad z
      omega
    exact mem_union.mpr (Or.inr (Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨za,x,xa,adj⟩))
  have c := card_le_card cover
  rw [card_univ] at c
  have e₁ := card_union_le A B
  have e₂ := card_union_le (A∪B) F
  have e₃ := card_union_le (A∪B∪F) H
  have e₄ := card_union_le (A∪B∪F∪H) W
  change Fintype.card V≤A.card+B.card+F.card+H.card+W.card
  omega

#print axioms shell_three_donor_cover
#print axioms order_le_star_cut_two_three_four
end Graffiti189LongestPath.DeficitThirdShell
