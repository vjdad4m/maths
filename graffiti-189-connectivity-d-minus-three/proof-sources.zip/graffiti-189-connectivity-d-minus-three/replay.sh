#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")" && pwd)
obj=$(mktemp -d)
trap 'rm -rf "$obj"' EXIT
echo '== DeficitThreeAll189 =='
lean -j1 -DElab.async=false -DwarningAsError=true --root="$root" \
  -o "$obj/DeficitThreeAll189.olean" "$root/DeficitThreeAll189.lean"
