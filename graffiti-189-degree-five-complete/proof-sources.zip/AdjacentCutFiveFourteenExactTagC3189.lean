import AdjacentCutFiveFourteenLabelTransferC3189
import AdjacentCutFiveFourteenExactTagShared189
import AdjacentCutFiveFourteenSingletonTerminal189
import AdjacentCutFiveMixedFourteenSixteen189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent.SingletonRUP
open Finset SimpleGraph SimpleGraph.Walk ArticulationPair
open private CutGraph Shore shore_off shore_closed shore_disjoint shore_hit_a shore_hit_b from AdjacentCutFiveActual189
open private key classSet prof key_facts from AdjacentCutFiveTopProfiles189
open private key_a_port key_b_port from AdjacentCutFiveTopFlatten189
open private even_two_three_info even_three_two_info restrict_unique_profile disjoint_profile_sets
  from AdjacentCutFiveSixteenSingletonGeometry189
open private predecessor_of_positive_dist left_even_adjoins_exclusive right_even_adjoins_exclusive
  from AdjacentCutFiveSixteenSingletonDepth189
open private d2 from AdjacentCutFiveBound189
open private shore_sum_with_cover from AdjacentCutFiveMixedFourteenSixteen189
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
set_option maxHeartbeats 4000000
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

open private common_port_subset common_incidence all_classes even_equal_dist_two
  from AdjacentCutFiveFourteenExactTagShared189

/-- Graph-level closure of the three-common equal-even-two order-fourteen profile. -/
theorem traceable_order_fourteen_EC2_three_common
    (hc : G.Connected) (ab : G.Adj a b) (even : ∀ z,(EvenFrom G z).card≤6)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    {C D : Cmp G a b} (cd : C≠D)
    (cover : ∀ {z : V}, z≠a → z≠b → z∈Shore C ∨ z∈Shore D)
    (one : (Shore C).card=1) (big : (Shore D).card=11)
    (aa : (prof D).ea=2) (bb : (prof D).eb=2) (ee : (prof D).ec=2)
    (oa : (prof D).oa=1) (ob : (prof D).ob=1) (oc : (prof D).oc=3)    (three_common : (commonPorts D).card=3) :
    ∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support := by
  classical
  obtain ⟨s,sC⟩ := card_eq_one.mp one
  have sc : s∈Shore C := by simp [sC]
  obtain ⟨h,hm,ah⟩ := shore_hit_a ab.ne conn C
  obtain ⟨k,km,bk⟩ := shore_hit_b ab.ne conn C
  have as' : G.Adj a s := (show h=s by simpa [sC] using hm) ▸ ah
  have bs' : G.Adj b s := (show k=s by simpa [sC] using km) ▸ bk
  have sD : s∉Shore D := fun f=>disjoint_left.mp (shore_disjoint cd) sc f
  obtain ⟨_,_,high⟩ := adjacent_singleton_terminal_count ab degree cd cover one
  have n : Fintype.card V=14 := by
    have h := shore_sum_with_cover ab.ne cd cover
    omega
  have nu {z : V} (zm : z∈Shore D) : ¬G.Adj s z := by
    intro sz
    rcases shore_closed C s sc z sz with h|h|h
    · exact (shore_off D).1 (h ▸ zm)
    · exact (shore_off D).2 (h ▸ zm)
    exact disjoint_left.mp (shore_disjoint cd) h zm
  have dside {z : V} (zm : z∈Shore D) : z≠a ∧ z≠b :=
    ⟨fun e=>(shore_off D).1 (e ▸ zm),fun e=>(shore_off D).2 (e ▸ zm)⟩
  have A : (classSet D 0).card=2 := aa
  obtain ⟨u,v,uv,Aset⟩ := card_eq_two.mp A
  have um : u∈classSet D 0 := by rw [Aset]; simp
  have vm : v∈classSet D 0 := by rw [Aset]; simp
  have ud := (mem_filter.mp um).1
  have vd := (mem_filter.mp vm).1
  have evenA {z : V} (zm : z∈classSet D 0) := even_two_three_info hc ab oa zm
  obtain ⟨x,xd,ax,bx⟩ := exclusive_left_port_of_strictly_nearer hc ud (by have h:=evenA um; omega)
  have dx := (mem_filter.mp (d2 hc (dside xd).2.symm bx ab.symm ax)).2
  have xk : key G a b x=3 := by simp [key,dist_eq_one_iff_adj.mpr ax,dx]
  have L := restrict_unique_profile oa xd xk
  have xport (z : V) (zm : z∈classSet D 3) : G.Adj a z := by
    have z' : z∈({x}:Finset V) := L ▸ zm
    exact (mem_singleton.mp z').symm ▸ ax
  have xu := left_even_adjoins_exclusive hc ab L ud (evenA um).1 (evenA um).2
  have xv := left_even_adjoins_exclusive hc ab L vd (evenA vm).1 (evenA vm).2
  have yPick : ∃ y∈classSet D 4,G.Adj b y ∧ ¬G.Adj a y := by
    have Bpos : 0<(classSet D 1).card := by change (classSet D 1).card=_ at bb; omega
    obtain ⟨z,zm⟩ := card_pos.mp Bpos
    obtain ⟨zd,zk⟩ := mem_filter.mp zm
    obtain ⟨f,g,_⟩ := key_facts hc ab z
    rw [zk] at f g
    change G.dist a z=depth G a b z+1 at f
    change G.dist b z=depth G a b z+0 at g
    obtain ⟨y,yd,by',ay⟩ := exclusive_right_port_of_strictly_nearer hc zd (by omega)
    have dy := (mem_filter.mp (d2 hc (dside yd).1.symm ay ab by')).2
    have yk : key G a b y=4 := by simp [key,dist_eq_one_iff_adj.mpr by',dy]
    exact ⟨y,mem_filter.mpr ⟨yd,yk⟩,by',ay⟩
  obtain ⟨y,ym,by',ay⟩ := yPick
  have yd := (mem_filter.mp ym).1
  have dy := (mem_filter.mp (d2 hc (dside yd).1.symm ay ab by')).2
  have O : (classSet D 5).card=3 := oc
  have Osub : commonPorts D⊆classSet D 5 := filter_subset _ _
  obtain ⟨c,d,k,cdk,ck,dk,Kset⟩ := card_eq_three.mp three_common
  have cm : c∈commonPorts D := by rw [Kset]; simp
  have dm : d∈commonPorts D := by rw [Kset]; simp
  have km : k∈commonPorts D := by rw [Kset]; simp
  have dc := common_port_subset D cm
  have dd := common_port_subset D dm
  have kd := common_port_subset D km
  have cp := common_incidence D cm
  have dp := common_incidence D dm
  have kp := common_incidence D km
  have Kexact : commonPorts D=classSet D 5 := eq_of_subset_of_card_le Osub (by omega)
  have OCset : classSet D 5={c,d,k} := Kexact.symm.trans Kset
  have Opart (z : V) (zm : z∈classSet D 5) : z=c ∨ z=d ∨ z=k := by
    have p : z∈({c,d,k}:Finset V) := OCset ▸ zm
    simpa using p
  have R := restrict_unique_profile ob yd (mem_filter.mp ym).2
  have yport (z : V) (zm : z∈classSet D 4) : G.Adj b z := by
    have j : z∈({y}:Finset V) := R ▸ zm
    exact (mem_singleton.mp j).symm ▸ by'
  have B : (classSet D 1).card=2 := bb
  obtain ⟨p,q,pq,Bset⟩ := card_eq_two.mp B
  have pm : p∈classSet D 1 := by rw [Bset]; simp
  have qm : q∈classSet D 1 := by rw [Bset]; simp
  have pd := (mem_filter.mp pm).1
  have qd := (mem_filter.mp qm).1
  have evenB {z : V} (zm : z∈classSet D 1) := even_three_two_info hc ab ob zm
  have yp := right_even_adjoins_exclusive hc ab R pd (evenB pm).1 (evenB pm).2
  have yq := right_even_adjoins_exclusive hc ab R qd (evenB qm).1 (evenB qm).2
  have E : (classSet D 2).card=2 := ee
  obtain ⟨e,f,ef,Eset⟩ := card_eq_two.mp E
  have em : e∈classSet D 2 := by rw [Eset]; simp
  have fm : f∈classSet D 2 := by rw [Eset]; simp
  have ed := (mem_filter.mp em).1
  have fd := (mem_filter.mp fm).1
  have ORsize : ((classSet D 5)\commonPorts D).card≤1 := by
    rw [Kexact,sdiff_self]
    change (∅ : Finset V).card ≤ 1
    simp
  have lightE (z : V) (zm : z∈classSet D 2) : G.dist a z=2 ∧ G.dist b z=2 :=
    even_equal_dist_two hc ab high (fun i h=>(evenA h).1.le) (fun i h=>(evenB h).2.le)
      xport yport E.le ORsize zm
  let labels : Fin 14 → V := ![a,b,s,x,y,c,d,k,u,v,p,q,e,f]
  have survey (j : V) : j=a ∨ j=b ∨ j=s ∨ j=x ∨ j=y ∨ j=c ∨ j=d ∨ j=k ∨ j=u ∨ j=v ∨ j=p ∨ j=q ∨ j=e ∨ j=f := by
    by_cases ja : j=a
    · exact .inl ja
    by_cases jb : j=b
    · exact .inr (.inl jb)
    rcases cover ja jb with jc|jd
    · have hs : j=s := by simpa [sC] using jc
      tauto
    rcases all_classes jd with h|h|h|h|h|h
    · have t : j=u ∨ j=v := by
        have k : j∈({u,v}:Finset V) := Aset ▸ h
        simpa using k
      tauto
    · have t : j=p ∨ j=q := by
        have k : j∈({p,q}:Finset V) := Bset ▸ h
        simpa using k
      tauto
    · have t : j=e ∨ j=f := by
        have k : j∈({e,f}:Finset V) := Eset ▸ h
        simpa using k
      tauto
    · have t : j=x := by
        have k : j∈({x}:Finset V) := L ▸ h
        simpa using k
      tauto
    · have t : j=y := by
        have k : j∈({y}:Finset V) := R ▸ h
        simpa using k
      tauto
    · have t : j=c ∨ j=d ∨ j=k := by
        exact Opart j h
      tauto
  have sur : Function.Surjective labels := by
    intro z
    rcases survey z with h|h|h|h|h|h|h|h|h|h|h|h|h|h
    · exact ⟨0,show a=z from h.symm⟩
    · exact ⟨1,show b=z from h.symm⟩
    · exact ⟨2,show s=z from h.symm⟩
    · exact ⟨3,show x=z from h.symm⟩
    · exact ⟨4,show y=z from h.symm⟩
    · exact ⟨5,show c=z from h.symm⟩
    · exact ⟨6,show d=z from h.symm⟩
    · exact ⟨7,show k=z from h.symm⟩
    · exact ⟨8,show u=z from h.symm⟩
    · exact ⟨9,show v=z from h.symm⟩
    · exact ⟨10,show p=z from h.symm⟩
    · exact ⟨11,show q=z from h.symm⟩
    · exact ⟨12,show e=z from h.symm⟩
    · exact ⟨13,show f=z from h.symm⟩
  have allHigh (i : Fin 14) (hi : (3 : Nat) ≤ i.val) : 5≤G.degree (labels i) := by
    fin_cases i
    · exact ((show ¬((3 : Nat) ≤ (0 : Fin 14).val) by decide) hi).elim
    · exact ((show ¬((3 : Nat) ≤ (1 : Fin 14).val) by decide) hi).elim
    · exact ((show ¬((3 : Nat) ≤ (2 : Fin 14).val) by decide) hi).elim
    · exact high _ xd
    · exact high _ yd
    · exact high _ dc
    · exact high _ dd
    · exact high _ kd
    · exact high _ ud
    · exact high _ vd
    · exact high _ pd
    · exact high _ qd
    · exact high _ ed
    · exact high _ fd
  have nos (i : Fin 14) (hi : (3 : Nat) ≤ i.val) : ¬G.Adj (labels 2) (labels i) := by
    fin_cases i
    · exact ((show ¬((3 : Nat) ≤ (0 : Fin 14).val) by decide) hi).elim
    · exact ((show ¬((3 : Nat) ≤ (1 : Fin 14).val) by decide) hi).elim
    · exact ((show ¬((3 : Nat) ≤ (2 : Fin 14).val) by decide) hi).elim
    · exact nu xd
    · exact nu yd
    · exact nu dc
    · exact nu dd
    · exact nu kd
    · exact nu ud
    · exact nu vd
    · exact nu pd
    · exact nu qd
    · exact nu ed
    · exact nu fd
  have da : ∀ i, G.dist (labels 0) (labels i)=ec3.fromA i := by
    intro i; fin_cases i
    · exact dist_self
    · exact dist_eq_one_iff_adj.mpr ab
    · exact dist_eq_one_iff_adj.mpr as'
    · exact dist_eq_one_iff_adj.mpr ax
    · exact dy
    · exact dist_eq_one_iff_adj.mpr cp.1
    · exact dist_eq_one_iff_adj.mpr dp.1
    · exact dist_eq_one_iff_adj.mpr kp.1
    · exact (evenA um).1
    · exact (evenA vm).1
    · exact (evenB pm).1
    · exact (evenB qm).1
    · exact (lightE e em).1
    · exact (lightE f fm).1
  have db : ∀ i, G.dist (labels 1) (labels i)=ec3.fromB i := by
    intro i; fin_cases i
    · exact dist_eq_one_iff_adj.mpr ab.symm
    · exact dist_self
    · exact dist_eq_one_iff_adj.mpr bs'
    · exact dx
    · exact dist_eq_one_iff_adj.mpr by'
    · exact dist_eq_one_iff_adj.mpr cp.2
    · exact dist_eq_one_iff_adj.mpr dp.2
    · exact dist_eq_one_iff_adj.mpr kp.2
    · exact (evenA um).2
    · exact (evenA vm).2
    · exact (evenB pm).2
    · exact (evenB qm).2
    · exact (lightE e em).2
    · exact (lightE f fm).2
  exact ec3_distance_label_traceable labels sur n hc even allHigh da db nos xu xv yp yq

#print axioms traceable_order_fourteen_EC2_three_common
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent.SingletonRUP
