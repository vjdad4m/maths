import AdjacentCutFiveFourteenSingletonTerminal189
import AdjacentCutFiveMixedFourteenSixteen189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent.SingletonRUP
open Finset SimpleGraph SimpleGraph.Walk ArticulationPair
open private CutGraph Shore shore_off shore_closed shore_disjoint shore_hit_a shore_hit_b from AdjacentCutFiveActual189
open private key classSet prof key_facts from AdjacentCutFiveTopProfiles189
open private key_a_port key_b_port from AdjacentCutFiveTopFlatten189
open private even_two_three_info even_three_two_info restrict_unique_profile disjoint_profile_sets
  from AdjacentCutFiveSixteenSingletonGeometry189
open private predecessor_of_positive_dist left_even_adjoins_exclusive right_even_adjoins_exclusive
  from AdjacentCutFiveSixteenSingletonDepth189
open private d2 from AdjacentCutFiveBound189
open private shore_sum_with_cover from AdjacentCutFiveMixedFourteenSixteen189
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
set_option maxHeartbeats 4000000
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

noncomputable def commonPorts (D : Cmp G a b) : Finset V :=
  by classical exact (classSet D 5).filter (fun x=>G.Adj a x ∧ G.Adj b x)

private theorem common_port_subset (D : Cmp G a b) : commonPorts D⊆Shore D := by
  intro z h
  exact (mem_filter.mp (mem_filter.mp h).1).1

private theorem common_incidence (D : Cmp G a b) {z : V} (h : z∈commonPorts D) :
    G.Adj a z ∧ G.Adj b z := (mem_filter.mp h).2

private theorem common_card_ge_two (hc : G.Connected) (ab : G.Adj a b)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    {C D : Cmp G a b} (cd : C≠D)
    (cover : ∀ {z : V}, z≠a → z≠b → z∈Shore C ∨ z∈Shore D)
    (one : (Shore C).card=1) (oa : (prof D).oa=1) : 2≤(commonPorts D).card := by
  classical
  have n := (adjacent_singleton_terminal_count ab degree cd cover one).1
  have s : (Shore D).filter (G.Adj a)⊆classSet D 3∪commonPorts D := by
    intro z zm
    obtain ⟨zd,az⟩ := mem_filter.mp zm
    have nb : z≠b := fun e=>(shore_off D).2 (e ▸ zd)
    rcases key_a_port hc ab nb az with h|h
    · exact mem_union_left _ (mem_filter.mpr ⟨zd,h⟩)
    obtain ⟨dA,dB,_⟩ := key_facts hc ab z
    rw [h] at dA dB
    have bz : G.Adj b z := dist_eq_one_iff_adj.mp (dB.trans (dA.symm.trans (dist_eq_one_iff_adj.mpr az)))
    exact mem_union_right _ (mem_filter.mpr ⟨mem_filter.mpr ⟨zd,h⟩,az,bz⟩)
  have c := (card_le_card s).trans (card_union_le _ _)
  change (classSet D 3).card=1 at oa
  omega

private theorem all_classes {D : Cmp G a b} {z : V} (zd : z∈Shore D) :
    z∈classSet D 0 ∨ z∈classSet D 1 ∨ z∈classSet D 2 ∨
    z∈classSet D 3 ∨ z∈classSet D 4 ∨ z∈classSet D 5 := by
  have ks : key G a b z=0 ∨ key G a b z=1 ∨ key G a b z=2 ∨
    key G a b z=3 ∨ key G a b z=4 ∨ key G a b z=5 := by omega
  simpa only [classSet,mem_filter,zd,true_and] using ks

private theorem degree_outside_small {z : V} (h : 5≤G.degree z)
    (S : Finset V) (less : S.card≤4) (only : ∀ u,G.Adj z u → u∈S) : False := by
  classical
  have f : G.neighborFinset z⊆S := fun u hu=>only u ((mem_neighborFinset _ _ _).mp hu)
  have c := (card_le_card f).trans less
  rw [card_neighborFinset_eq_degree] at c
  omega

private theorem odd_b_port_card_two
    (hc : G.Connected) (ab : G.Adj a b)
    {D : Cmp G a b} (high : ∀ z∈Shore D,5≤G.degree z)
    (A1 : (prof D).oa=1)
    (Aport : ∀ z∈classSet D 3,G.Adj a z) (B2 : (prof D).ob=2)
    (E1 : (prof D).ec=1) (bn3 : (prof D).eb≤3)
    (Cport : ∀ z∈classSet D 5,G.Adj a z ∧ G.Adj b z)
    {y : V} (ym : y∈classSet D 4) (by' : G.Adj b y) :
    ∀ w∈classSet D 4,G.Adj b w := by
  classical
  intro w wm
  by_cases h : G.Adj b w
  · exact h
  exfalso
  have wy : w≠y := fun e=>h (e ▸ by')
  have ex : classSet D 4={y,w} := by
    symm
    apply eq_of_subset_of_card_le (by simpa using (insert_subset_iff.mpr
      ⟨ym,singleton_subset_iff.mpr wm⟩ : ({y,w}:Finset V)⊆classSet D 4))
    simpa [wy.symm] using Nat.le_of_eq B2
  have wk := (mem_filter.mp wm).2
  have wd := (mem_filter.mp wm).1
  obtain ⟨da,db,odd⟩ := key_facts hc ab w
  rw [wk] at da db odd
  change G.dist a w=depth G a b w+1 at da
  change G.dist b w=depth G a b w+0 at db
  change depth G a b w%2=1 at odd
  have w3 : 3≤G.dist b w := by
    apply Classical.byContradiction
    intro k
    exact h (dist_eq_one_iff_adj.mp (by omega))
  have w4 : 4≤G.dist a w := by omega
  apply degree_outside_small (high w wd) (classSet D 1∪classSet D 2)
  · have c := card_union_le (classSet D 1) (classSet D 2)
    change (classSet D 1).card≤3 at bn3
    change (classSet D 2).card=1 at E1
    omega
  intro z wz
  rcases shore_closed D w wd z wz with zA|zB|zs
  · have d := dist_eq_one_iff_adj.mpr (zA ▸ wz.symm)
    omega
  · exact (h (zB ▸ wz.symm)).elim
  have banA (lt : G.dist a z≤2) : False := by
    have tr := hc.dist_triangle (u:=a) (v:=z) (w:=w)
    rw [dist_eq_one_iff_adj.mpr wz.symm] at tr
    omega
  have banB (lt : G.dist b z≤1) : False := by
    have tr := hc.dist_triangle (u:=b) (v:=z) (w:=w)
    rw [dist_eq_one_iff_adj.mpr wz.symm] at tr
    omega
  rcases all_classes zs with m|m|m|m|m|m
  · exact (banA (even_two_three_info hc ab A1 m).1.le).elim
  · exact mem_union_left _ m
  · exact mem_union_right _ m
  · exact (banA (by have k := dist_eq_one_iff_adj.mpr (Aport z m); omega)).elim
  · have zt : z∈({y,w}:Finset V) := ex ▸ m
    rcases (by simpa using zt : z=y ∨ z=w) with rfl|rfl
    · exact (banB (by have k := dist_eq_one_iff_adj.mpr by'; omega)).elim
    exact (G.loopless _ wz).elim
  · exact (banA (by have k := dist_eq_one_iff_adj.mpr (Cport z m).1; omega)).elim

private theorem depth_B_even_two
    (hc : G.Connected) (ab : G.Adj a b) {D : Cmp G a b}
    (ports : ∀ z∈classSet D 4,G.Adj b z)
    {z : V} (zm : z∈classSet D 1) : G.dist a z=3 ∧ G.dist b z=2 := by
  classical
  obtain ⟨zd,zk⟩ := mem_filter.mp zm
  obtain ⟨da,db,even⟩ := key_facts hc ab z
  rw [zk] at da db even
  change G.dist a z=depth G a b z+1 at da
  change G.dist b z=depth G a b z+0 at db
  change depth G a b z%2=0 at even
  have bz : b≠z := fun e=>(shore_off D).2 (e.symm ▸ zd)
  have pos := hc.pos_dist_of_ne bz
  have b2 : G.dist b z=2 := by
    apply Classical.byContradiction
    intro no
    have b4 : 4≤G.dist b z := by omega
    have pos' : 0<G.dist z b := by rw [dist_comm]; omega
    obtain ⟨u,zu,du⟩ := predecessor_of_positive_dist hc pos'
    rw [dist_comm (u:=z) (v:=b),dist_comm (u:=u) (v:=b)] at du
    have ud : u∈Shore D := by
      rcases shore_closed D z zd u zu with h|h|h
      · have c := hc.dist_triangle (u:=b) (v:=u) (w:=z)
        have az : G.Adj a z := by simpa [h] using zu.symm
        rw [h,dist_eq_one_iff_adj.mpr ab.symm,dist_eq_one_iff_adj.mpr az] at c
        omega
      · have bz : G.Adj b z := by simpa [h] using zu.symm
        have c := dist_eq_one_iff_adj.mpr bz
        omega
      exact h
    have tr := hc.dist_triangle (u:=a) (v:=u) (w:=z)
    rw [dist_eq_one_iff_adj.mpr zu.symm] at tr
    have bu : G.dist b u<G.dist a u := by omega
    have mo : G.dist b u%2=1 := by omega
    have uk : key G a b u=4 := by simp [key,bu,not_lt.mpr bu.le,Nat.even_iff,mo]
    have p := dist_eq_one_iff_adj.mpr (ports u (mem_filter.mpr ⟨ud,uk⟩))
    omega
  exact ⟨by omega,b2⟩

private theorem even_equal_dist_two (hc : G.Connected) (ab : G.Adj a b)
    {D : Cmp G a b} (high : ∀ z∈Shore D,5≤G.degree z)
    (lightA : ∀ z∈classSet D 0,G.dist a z≤2)
    (lightB : ∀ z∈classSet D 1,G.dist b z≤2)
    (portsA : ∀ z∈classSet D 3,G.Adj a z)
    (portsB : ∀ z∈classSet D 4,G.Adj b z)
    (e2 : (classSet D 2).card≤2)
    (o1 : ((classSet D 5)\commonPorts D).card≤1)
    {z : V} (zm : z∈classSet D 2) : G.dist a z=2 ∧ G.dist b z=2 := by
  classical
  obtain ⟨zd,zk⟩ := mem_filter.mp zm
  obtain ⟨da,db,even⟩ := key_facts hc ab z
  rw [zk] at da db even
  change G.dist a z=depth G a b z+0 at da
  change G.dist b z=depth G a b z+0 at db
  change depth G a b z%2=0 at even
  have az : a≠z := fun e=>(shore_off D).1 (e.symm ▸ zd)
  have pos := hc.pos_dist_of_ne az
  have d2 : depth G a b z=2 := by
    apply Classical.byContradiction
    intro d
    have big : 4≤depth G a b z := by omega
    let R := classSet D 2 ∪ ((classSet D 5)\commonPorts D)
    apply degree_outside_small (high z zd) R
    · dsimp only [R]
      have c := card_union_le (classSet D 2) ((classSet D 5)\commonPorts D)
      omega
    intro w zw
    have banA (lw : G.dist a w≤2) : False := by
      have t := hc.dist_triangle (u:=a) (v:=w) (w:=z)
      rw [dist_eq_one_iff_adj.mpr zw.symm] at t
      omega
    have banB (lw : G.dist b w≤2) : False := by
      have t := hc.dist_triangle (u:=b) (v:=w) (w:=z)
      rw [dist_eq_one_iff_adj.mpr zw.symm] at t
      omega
    rcases shore_closed D z zd w zw with ha|hb|wd
    · exact (banA (by rw [ha,dist_self]; decide)).elim
    · exact (banB (by rw [hb,dist_self]; decide)).elim
    rcases all_classes wd with r|r|r|r|r|r
    · exact (banA (lightA w r)).elim
    · exact (banB (lightB w r)).elim
    · exact mem_union_left _ r
    · exact (banA (by have k := dist_eq_one_iff_adj.mpr (portsA w r); omega)).elim
    · exact (banB (by have k := dist_eq_one_iff_adj.mpr (portsB w r); omega)).elim
    · exact mem_union_right _ (mem_sdiff.mpr ⟨r,fun cm=>
        banA (by have k := dist_eq_one_iff_adj.mpr (common_incidence D cm).1; omega)⟩)
  exact ⟨by omega,by omega⟩

private theorem equal_odd_single_dark_three (hc : G.Connected) (ab : G.Adj a b)
    {D : Cmp G a b} (high : ∀ z∈Shore D,5≤G.degree z)
    (lightA : ∀ z∈classSet D 0,G.dist a z≤2)
    (lightB : ∀ z∈classSet D 1,G.dist b z≤2)
    (lightE : ∀ z∈classSet D 2,G.dist a z≤2)
    (portsA : ∀ z∈classSet D 3,G.Adj a z)
    (portsB : ∀ z∈classSet D 4,G.Adj b z)
    {w : V} (wset : (classSet D 5)\commonPorts D = {w})
    (wm : w∈classSet D 5) :
    G.dist a w=3 ∧ G.dist b w=3 := by
  classical
  obtain ⟨wd,wk⟩ := mem_filter.mp wm
  obtain ⟨A,B,odd⟩ := key_facts hc ab w
  rw [wk] at A B odd
  change G.dist a w=depth G a b w+0 at A
  change G.dist b w=depth G a b w+0 at B
  change depth G a b w%2=1 at odd
  have one : depth G a b w≠1 := by
    intro e
    have m : w∈commonPorts D :=
      mem_filter.mpr ⟨wm,dist_eq_one_iff_adj.mp (by omega),dist_eq_one_iff_adj.mp (by omega)⟩
    have k : w∈(classSet D 5)\commonPorts D := by
      rw [wset]
      simp
    exact (mem_sdiff.mp k).2 m
  have d : depth G a b w=3 := by
    apply Classical.byContradiction
    intro d
    have big : 5≤depth G a b w := by omega
    apply degree_outside_small (high w wd) (∅ : Finset V) (by simp)
    intro z wz
    exfalso
    have banA (lw : G.dist a z≤2) : False := by
      have t := hc.dist_triangle (u:=a) (v:=z) (w:=w)
      rw [dist_eq_one_iff_adj.mpr wz.symm] at t
      omega
    have banB (lw : G.dist b z≤2) : False := by
      have t := hc.dist_triangle (u:=b) (v:=z) (w:=w)
      rw [dist_eq_one_iff_adj.mpr wz.symm] at t
      omega
    rcases shore_closed D w wd z wz with ha|hb|zd
    · exact banA (by rw [ha,dist_self]; decide)
    · exact banB (by rw [hb,dist_self]; decide)
    rcases all_classes zd with r|r|r|r|r|r
    · exact banA (lightA z r)
    · exact banB (lightB z r)
    · exact banA (lightE z r)
    · exact banA (by have k := dist_eq_one_iff_adj.mpr (portsA z r); omega)
    · exact banB (by have k := dist_eq_one_iff_adj.mpr (portsB z r); omega)
    by_cases zm : z∈commonPorts D
    · exact banA (by have k := dist_eq_one_iff_adj.mpr (common_incidence D zm).1; omega)
    have h : z∈({w}:Finset V) := wset ▸ (mem_sdiff.mpr ⟨r,zm⟩ : z∈(classSet D 5)\commonPorts D)
    exact wz.ne.symm (mem_singleton.mp h)
  exact ⟨by omega,by omega⟩


end Graffiti189LongestPath.CrossSaturation.FiveAdjacent.SingletonRUP
