import AdjacentCutFiveBound189
import Mathlib.Data.Fintype.EquivFin

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
variable {V W : Type*} [Fintype V] [Fintype W] [DecidableEq V] [DecidableEq W]
    {G : SimpleGraph V} {J : SimpleGraph W} [DecidableRel J.Adj] [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

theorem label_dist (f : J ≃g G) (hc : G.Connected) (i j : W) :
    J.dist i j=G.dist (f i) (f j) := by
  have c : J.Connected := f.connected_iff.mpr hc
  obtain ⟨p,pl⟩ := c.exists_walk_length_eq_dist i j
  obtain ⟨q,ql⟩ := hc.exists_walk_length_eq_dist (f i) (f j)
  have h := G.dist_le (p.map f.toHom)
  rw [length_map,pl] at h
  have k := J.dist_le (q.map f.symm.toHom)
  rw [length_map,ql] at k
  have k' : J.dist i j≤G.dist (f i) (f j) := by simpa using k
  exact le_antisymm k' h

theorem label_degree (f : J ≃g G) (i : W) : J.degree i=G.degree (f i) := by
  classical
  rw [←card_neighborFinset_eq_degree,←card_neighborFinset_eq_degree]
  apply card_bij (fun u _=>f u)
  · intro u h
    exact (mem_neighborFinset _ _ _).mpr ((f.map_rel_iff).mpr ((mem_neighborFinset _ _ _).mp h))
  · exact fun u _ v _ e=>f.injective e
  · intro u h
    obtain ⟨x,rfl⟩ := f.surjective u
    exact ⟨x,(mem_neighborFinset _ _ _).mpr ((f.map_rel_iff).mp ((mem_neighborFinset _ _ _).mp h)),rfl⟩

theorem label_even (f : J ≃g G) (hc : G.Connected) (i : W) :
    (EvenFrom J i).card=(EvenFrom G (f i)).card := by
  classical
  apply card_bij (fun u _=>f u)
  · intro u h
    have d := (mem_filter.mp h).2
    exact mem_filter.mpr ⟨mem_univ _,label_dist f hc i u ▸ d⟩
  · exact fun u _ v _ e=>f.injective e
  · intro u um
    obtain ⟨v,rfl⟩ := f.surjective u
    exact ⟨v,mem_filter.mpr ⟨mem_univ _,(label_dist f hc i v).symm ▸ (mem_filter.mp um).2⟩,rfl⟩

theorem traceable_label (f : J ≃g G)
    (sp : ∃ s t,∃ p : J.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) :
    ∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support := by
  obtain ⟨s,t,p,pp,ps⟩ := sp
  refine ⟨f s,f t,p.map f.toHom,?_,?_⟩
  · apply IsPath.mk'
    rw [support_map]
    exact pp.support_nodup.map f.injective
  intro z
  obtain ⟨v,rfl⟩ := f.surjective z
  rw [support_map,List.mem_map]
  exact ⟨v,ps v,rfl⟩

#print axioms label_dist
#print axioms label_degree
#print axioms label_even
#print axioms traceable_label
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
