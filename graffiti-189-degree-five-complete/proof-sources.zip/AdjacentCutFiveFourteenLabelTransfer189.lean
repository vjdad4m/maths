import AdjacentCutFiveFourteenLabel189
import AdjacentCutFiveFourteenLabeledEC2189
import AdjacentCutFiveFourteenLabeledEC1189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent.SingletonRUP
open SimpleGraph Finset
variable {T : Type*} [Fintype T] [DecidableEq T] {G : SimpleGraph T} [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

theorem ec2_distance_label_impossible (f : Fin 14 → T) (sur : Function.Surjective f)
    (n : Fintype.card T=14) (hc : G.Connected) (even : ∀ z,(EvenFrom G z).card≤6)
    (high : ∀ (i : Fin 14), (3 : Nat) ≤ i.val → 5≤G.degree (f i))
    (a : ∀ i, G.dist (f 0) (f i)=ec2.fromA i)
    (b : ∀ i, G.dist (f 1) (f i)=ec2.fromB i)
    (s : ∀ (i : Fin 14), (3 : Nat) ≤ i.val → ¬G.Adj (f 2) (f i))
    (x7 : G.Adj (f 3) (f 7)) (x8 : G.Adj (f 3) (f 8))
    (y9 : G.Adj (f 4) (f 9)) (y10 : G.Adj (f 4) (f 10)) : False := by
  classical
  let e : Fin 14 ≃ T := Equiv.ofBijective f
    ((Fintype.bijective_iff_surjective_and_card f).mpr ⟨sur,by simp [n]⟩)
  let J : SimpleGraph (Fin 14) := G.comap e
  let iso : J ≃g G := SimpleGraph.Iso.comap e G
  exact ec2.no_label_data (J:=J)
    ⟨iso.connected_iff.mpr hc, (fun i=>by rw [label_even iso hc i]; exact even (f i)),
      (fun i h=>by rw [label_degree iso i]; exact high i h),
      (fun i=>by rw [label_dist iso hc]; exact a i),
      (fun i=>by rw [label_dist iso hc]; exact b i),s,x7,x8,y9,y10⟩

theorem ec1_distance_label_traceable (f : Fin 14 → T) (sur : Function.Surjective f)
    (n : Fintype.card T=14) (hc : G.Connected) (even : ∀ z,(EvenFrom G z).card≤6)
    (high : ∀ (i : Fin 14), (3 : Nat) ≤ i.val → 5≤G.degree (f i))
    (a : ∀ i, G.dist (f 0) (f i)=ec1.fromA i)
    (b : ∀ i, G.dist (f 1) (f i)=ec1.fromB i)
    (s : ∀ (i : Fin 14), (3 : Nat) ≤ i.val → ¬G.Adj (f 2) (f i))
    (x8 : G.Adj (f 3) (f 8)) (x9 : G.Adj (f 3) (f 9)) :
    ∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support := by
  classical
  let e : Fin 14 ≃ T := Equiv.ofBijective f
    ((Fintype.bijective_iff_surjective_and_card f).mpr ⟨sur,by simp [n]⟩)
  let J : SimpleGraph (Fin 14) := G.comap e
  let iso : J ≃g G := SimpleGraph.Iso.comap e G
  apply traceable_label iso
  exact ec1.traceable_of_label_data (J:=J)
    ⟨iso.connected_iff.mpr hc, (fun i=>by rw [label_even iso hc i]; exact even (f i)),
      (fun i h=>by rw [label_degree iso i]; exact high i h),
      (fun i=>by rw [label_dist iso hc]; exact a i),
      (fun i=>by rw [label_dist iso hc]; exact b i),s,x8,x9⟩

#print axioms ec2_distance_label_impossible
#print axioms ec1_distance_label_traceable
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent.SingletonRUP
