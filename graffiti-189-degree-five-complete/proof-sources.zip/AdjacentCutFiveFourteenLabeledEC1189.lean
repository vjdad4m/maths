import AdjacentCutFiveFourteenRUPSemEC1189
import AdjacentCutFiveFourteenDarkLift189
import AdjacentCutFiveSixteenSingletonDepth189
import AdjacentCutFiveMixedRouteSmall189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent.SingletonRUP.ec1
open Finset SimpleGraph SimpleGraph.Walk ArticulationPair
open private predecessor_of_positive_dist from AdjacentCutFiveSixteenSingletonDepth189
open private inside_lower_of_boundary from AdjacentCutFiveMixedRouteSmall189
variable {J : SimpleGraph V} [DecidableRel J.Adj]
set_option linter.unusedSectionVars false
set_option maxHeartbeats 2000000

def fromA (i : V) : Nat :=
  match i.val with
  | 0 => 0
  | 1 => 1
  | 2 => 1
  | 3 => 1
  | 4 => 2
  | 5 => 2
  | 6 => 1
  | 7 => 1
  | 8 => 2
  | 9 => 2
  | 10 => 3
  | 11 => 3
  | 12 => 3
  | 13 => 2
  | _ => 0

def fromB (i : V) : Nat :=
  match i.val with
  | 0 => 1
  | 1 => 0
  | 2 => 1
  | 3 => 2
  | 4 => 1
  | 5 => 1
  | 6 => 1
  | 7 => 1
  | 8 => 3
  | 9 => 3
  | 10 => 2
  | 11 => 2
  | 12 => 2
  | 13 => 2
  | _ => 0

structure LabelData (J : SimpleGraph V) [DecidableRel J.Adj] : Prop where
  hc : J.Connected
  even : ∀ z, (EvenFrom J z).card≤6
  high : ∀ z : V, 3≤z.val → 5≤J.degree z
  fa : ∀ z, J.dist 0 z=fromA z
  fb : ∀ z, J.dist 1 z=fromB z
  no_s : ∀ z : V, 3≤z.val → ¬J.Adj 2 z
  f38 : J.Adj 3 8
  f39 : J.Adj 3 9

private theorem fixed_cases (i j : V) (m : fixedMatrix i j=true) :
  i=0 ∧ fromA j=1 ∨
  j=0 ∧ fromA i=1 ∨
  i=1 ∧ fromB j=1 ∨
  j=1 ∧ fromB i=1 ∨
  i=3 ∧ j=8 ∨
  i=3 ∧ j=9 ∨
  i=8 ∧ j=3 ∨
  i=9 ∧ j=3 := by
  revert m i j
  decide

private theorem forbid_cases (i j : V) (m : allowedMatrix i j=false) :
    i=j ∨ (i=2 ∧ (j≠0 ∧ j≠1 ∧ j≠2)) ∨ (j=2 ∧ (i≠0 ∧ i≠1 ∧ i≠2)) ∨
    fromA i+1<fromA j ∨ fromA j+1<fromA i ∨
    fromB i+1<fromB j ∨ fromB j+1<fromB i := by
  revert m i j
  decide

private theorem fixed_of (H : LabelData J) (i j : V) (m : fixedMatrix i j=true) : J.Adj i j := by
  rcases fixed_cases i j m with ⟨rfl,h⟩|⟨rfl,h⟩|⟨rfl,h⟩|⟨rfl,h⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩
  · exact dist_eq_one_iff_adj.mp ((H.fa _).trans h)
  · exact (dist_eq_one_iff_adj.mp ((H.fa _).trans h)).symm
  · exact dist_eq_one_iff_adj.mp ((H.fb _).trans h)
  · exact (dist_eq_one_iff_adj.mp ((H.fb _).trans h)).symm
  · exact H.f38
  · exact H.f39
  · exact H.f38.symm
  · exact H.f39.symm

private theorem pos_tail : ∀ j : V, j≠0 ∧ j≠1 ∧ j≠2 → (3 : Nat) ≤ j.val := by decide

private theorem forbid_of (H : LabelData J) (i j : V) (m : allowedMatrix i j=false) : ¬J.Adj i j := by
  intro e
  rcases forbid_cases i j m with rfl|⟨rfl,h⟩|⟨rfl,h⟩|h|h|h|h
  · exact J.loopless _ e
  · exact H.no_s _ (pos_tail _ h) e
  · exact H.no_s _ (pos_tail _ h) e.symm
  · have t := H.hc.dist_triangle (u:=0) (v:=i) (w:=j)
    rw [H.fa i,H.fa j,dist_eq_one_iff_adj.mpr e] at t
    omega
  · have t := H.hc.dist_triangle (u:=0) (v:=j) (w:=i)
    rw [H.fa i,H.fa j,dist_eq_one_iff_adj.mpr e.symm] at t
    omega
  · have t := H.hc.dist_triangle (u:=1) (v:=i) (w:=j)
    rw [H.fb i,H.fb j,dist_eq_one_iff_adj.mpr e] at t
    omega
  · have t := H.hc.dist_triangle (u:=1) (v:=j) (w:=i)
    rw [H.fb i,H.fb j,dist_eq_one_iff_adj.mpr e.symm] at t
    omega

private theorem predA (H : LabelData J) (v : V) (dv : fromA v=2) :
    ∃ w,J.Adj w v ∧ fromA w=1 := by
  have d : J.dist v 0=2 := by rw [dist_comm,H.fa,dv]
  obtain ⟨w,e,q⟩ := predecessor_of_positive_dist H.hc (x:=v) (t:=0) (by omega)
  rw [d,dist_comm (u:=w) (v:=0),H.fa] at q
  exact ⟨w,e.symm,by omega⟩

private theorem predB (H : LabelData J) (v : V) (dv : fromB v=2) :
    ∃ w,J.Adj w v ∧ fromB w=1 := by
  have d : J.dist v 1=2 := by rw [dist_comm,H.fb,dv]
  obtain ⟨w,e,q⟩ := predecessor_of_positive_dist H.hc (x:=v) (t:=1) (by omega)
  rw [d,dist_comm (u:=w) (v:=1),H.fb] at q
  exact ⟨w,e.symm,by omega⟩

private theorem nearA13_of (H : LabelData J) : J.Adj (6:V) 13 ∨ J.Adj (7:V) 13 ∨ J.Adj (3:V) 13 := by
  obtain ⟨w,wv,d⟩ := predA H 13 (by decide)
  have e : w=1 ∨ w=2 ∨ w=3 ∨ w=6 ∨ w=7 := by
    clear wv H
    revert d w
    decide
  rcases e with rfl|rfl|rfl|rfl|rfl
  · exact (forbid_of H 1 13 (by decide) wv).elim
  · exact (forbid_of H 2 13 (by decide) wv).elim
  · tauto
  · tauto
  · tauto
private theorem nearB10_of (H : LabelData J) : J.Adj (4:V) 10 ∨ J.Adj (5:V) 10 := by
  obtain ⟨w,wv,d⟩ := predB H 10 (by decide)
  have e : w=0 ∨ w=2 ∨ w=4 ∨ w=5 ∨ w=6 ∨ w=7 := by
    clear wv H
    revert d w
    decide
  rcases e with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (forbid_of H 0 10 (by decide) wv).elim
  · exact (forbid_of H 2 10 (by decide) wv).elim
  · tauto
  · tauto
  · exact (forbid_of H 6 10 (by decide) wv).elim
  · exact (forbid_of H 7 10 (by decide) wv).elim
private theorem nearB11_of (H : LabelData J) : J.Adj (4:V) 11 ∨ J.Adj (5:V) 11 := by
  obtain ⟨w,wv,d⟩ := predB H 11 (by decide)
  have e : w=0 ∨ w=2 ∨ w=4 ∨ w=5 ∨ w=6 ∨ w=7 := by
    clear wv H
    revert d w
    decide
  rcases e with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (forbid_of H 0 11 (by decide) wv).elim
  · exact (forbid_of H 2 11 (by decide) wv).elim
  · tauto
  · tauto
  · exact (forbid_of H 6 11 (by decide) wv).elim
  · exact (forbid_of H 7 11 (by decide) wv).elim
private theorem nearB12_of (H : LabelData J) : J.Adj (4:V) 12 ∨ J.Adj (5:V) 12 := by
  obtain ⟨w,wv,d⟩ := predB H 12 (by decide)
  have e : w=0 ∨ w=2 ∨ w=4 ∨ w=5 ∨ w=6 ∨ w=7 := by
    clear wv H
    revert d w
    decide
  rcases e with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (forbid_of H 0 12 (by decide) wv).elim
  · exact (forbid_of H 2 12 (by decide) wv).elim
  · tauto
  · tauto
  · exact (forbid_of H 6 12 (by decide) wv).elim
  · exact (forbid_of H 7 12 (by decide) wv).elim
private theorem nearB13_of (H : LabelData J) : J.Adj (6:V) 13 ∨ J.Adj (7:V) 13 ∨ J.Adj (4:V) 13 ∨ J.Adj (5:V) 13 := by
  obtain ⟨w,wv,d⟩ := predB H 13 (by decide)
  have e : w=0 ∨ w=2 ∨ w=4 ∨ w=5 ∨ w=6 ∨ w=7 := by
    clear wv H
    revert d w
    decide
  rcases e with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (forbid_of H 0 13 (by decide) wv).elim
  · exact (forbid_of H 2 13 (by decide) wv).elim
  · tauto
  · tauto
  · tauto
  · tauto

private theorem toGeometry (H : LabelData J) : Geometry J :=
  ⟨H.hc,H.even,H.high,fixed_of H,forbid_of H, nearA13_of H,nearB10_of H,nearB11_of H,nearB12_of H,nearB13_of H⟩

theorem labelled_visible_route_data (H : LabelData J) : Shape J :=
  normalized_route_geometry (toGeometry H)


theorem traceable_of_label_data (H : LabelData J) :
    ∃ s t,∃ p : J.Walk s t,p.IsPath ∧ ∀ z,z∈p.support := by
  classical
  have ⟨ce,de,dx,n10,n11,n12⟩ := labelled_visible_route_data H
  let W : Finset V := {8,9,10,11,12}
  have inn (u : V) (um : u∈W) : 3≤(inside J W u).card := by
    have loc : u=8 ∨ u=9 ∨ u=10 ∨ u=11 ∨ u=12 := by simpa [W] using um
    have boundary (u : V) (um : u∈W) : ∀ z,J.Adj u z → z∈W ∨ z∈({3,13}:Finset V) ∨ z∈({4,5}:Finset V) := by
      intro z e
      have a : allowedMatrix u z=true := by
        cases b : allowedMatrix u z
        · exact (forbid_of H u z b e).elim
        · rfl
      have q : ∀ (u z : V), u∈({8,9,10,11,12}:Finset V) →
          allowedMatrix u z=true → z∈({8,9,10,11,12}:Finset V) ∨
          z∈({3,13}:Finset V) ∨ z∈({4,5}:Finset V) := by decide
      exact q u z um a
    have h := H.high u (by rcases loc with rfl|rfl|rfl|rfl|rfl <;> decide)
    have split (P : Finset V) (two : P.card≤2)
        (bd : ∀ z,J.Adj u z → z∈W ∨ z∈P) : 3≤(inside J W u).card := by
      have q := inside_lower_of_boundary (G:=J) W P bd
      omega
    by_cases uA : u=8 ∨ u=9
    · apply split {3,13} (by decide)
      intro z uz
      rcases boundary u um z uz with m|m|m
      · exact .inl m
      · exact .inr m
      have n : z=4 ∨ z=5 := by simpa using m
      rcases uA with rfl|rfl <;> rcases n with rfl|rfl
      all_goals exact (forbid_of H _ _ (by decide) uz).elim
    apply split {4,5} (by decide)
    intro z uz
    rcases boundary u um z uz with m|m|m
    · exact .inl m
    · have q : z=3 ∨ z=13 := by simpa using m
      have k : u=10 ∨ u=11 ∨ u=12 := by tauto
      rcases k with rfl|rfl|rfl <;> rcases q with rfl|rfl
      · exact (forbid_of H _ _ (by decide) uz).elim
      · exact (n10 uz).elim
      · exact (forbid_of H _ _ (by decide) uz).elim
      · exact (n11 uz).elim
      · exact (forbid_of H _ _ (by decide) uz).elim
      · exact (n12 uz).elim
    exact .inr m
  have core : RouteOn J W 8 10 := terminal_route_on_of_local_ore W (by decide) (by decide) (by decide)
    (by intro u um v vm _ _; have p := inn u um; have q := inn v vm
        have k : W.card=5 := by decide
        omega)
  have h3 := core.prefix H.f38 (by decide)
  have h7 := h3.prefix dx.symm (by decide)
  have h13 := h7.prefix de.symm (by decide)
  have h6 := h13.prefix ce (by decide)
  have h0 := h6.prefix (fixed_of H 0 6 (by decide)) (by decide)
  have headRoute := h0.prefix (fixed_of H 2 0 (by decide)) (by decide)
  rcases nearB10_of H with hy|hz
  · have r4 := headRoute.suffix hy.symm (by decide)
    have r1 := r4.suffix (fixed_of H 4 1 (by decide)) (by decide)
    have full := r1.suffix (fixed_of H 1 5 (by decide)) (by decide)
    obtain ⟨p,pp,ps⟩ := full
    exact ⟨2,5,p,pp,fun z=>(ps z).mpr ((by decide : ∀ j : V, j∈({5,1,4,2,0,6,13,7,3,8,9,10,11,12} : Finset V)) z)⟩
  have r5 := headRoute.suffix hz.symm (by decide)
  have r1 := r5.suffix (fixed_of H 5 1 (by decide)) (by decide)
  have full := r1.suffix (fixed_of H 1 4 (by decide)) (by decide)
  obtain ⟨p,pp,ps⟩ := full
  exact ⟨2,4,p,pp,fun z=>(ps z).mpr ((by decide : ∀ j : V, j∈({4,1,5,2,0,6,13,7,3,8,9,10,11,12} : Finset V)) z)⟩
#print axioms labelled_visible_route_data
#print axioms traceable_of_label_data
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent.SingletonRUP.ec1
