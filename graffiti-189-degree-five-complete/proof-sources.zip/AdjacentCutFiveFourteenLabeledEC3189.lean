import AdjacentCutFiveFourteenRUPSemEC3189
import AdjacentCutFiveFourteenDarkLift189
import AdjacentCutFiveSixteenSingletonDepth189
import AdjacentCutFiveMixedRouteSmall189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent.SingletonRUP.ec3
open Finset SimpleGraph SimpleGraph.Walk ArticulationPair
open private predecessor_of_positive_dist from AdjacentCutFiveSixteenSingletonDepth189
open private inside_lower_of_boundary from AdjacentCutFiveMixedRouteSmall189
variable {J : SimpleGraph V} [DecidableRel J.Adj]
set_option linter.unusedSectionVars false
set_option maxHeartbeats 2000000

def fromA (i : V) : Nat :=
  match i.val with
  | 0 => 0
  | 1 => 1
  | 2 => 1
  | 3 => 1
  | 4 => 2
  | 5 => 1
  | 6 => 1
  | 7 => 1
  | 8 => 2
  | 9 => 2
  | 10 => 3
  | 11 => 3
  | 12 => 2
  | 13 => 2
  | _ => 0

def fromB (i : V) : Nat :=
  match i.val with
  | 0 => 1
  | 1 => 0
  | 2 => 1
  | 3 => 2
  | 4 => 1
  | 5 => 1
  | 6 => 1
  | 7 => 1
  | 8 => 3
  | 9 => 3
  | 10 => 2
  | 11 => 2
  | 12 => 2
  | 13 => 2
  | _ => 0

structure LabelData (J : SimpleGraph V) [DecidableRel J.Adj] : Prop where
  hc : J.Connected
  even : ∀ z, (EvenFrom J z).card≤6
  high : ∀ z : V, 3≤z.val → 5≤J.degree z
  fa : ∀ z, J.dist 0 z=fromA z
  fb : ∀ z, J.dist 1 z=fromB z
  no_s : ∀ z : V, 3≤z.val → ¬J.Adj 2 z
  f38 : J.Adj 3 8
  f39 : J.Adj 3 9
  f410 : J.Adj 4 10
  f411 : J.Adj 4 11

private theorem fixed_cases (i j : V) (m : fixedMatrix i j=true) :
  i=0 ∧ fromA j=1 ∨
  j=0 ∧ fromA i=1 ∨
  i=1 ∧ fromB j=1 ∨
  j=1 ∧ fromB i=1 ∨
  i=3 ∧ j=8 ∨
  i=3 ∧ j=9 ∨
  i=4 ∧ j=10 ∨
  i=4 ∧ j=11 ∨
  i=8 ∧ j=3 ∨
  i=9 ∧ j=3 ∨
  i=10 ∧ j=4 ∨
  i=11 ∧ j=4 := by
  revert m i j
  decide

private theorem forbid_cases (i j : V) (m : allowedMatrix i j=false) :
    i=j ∨ (i=2 ∧ (j≠0 ∧ j≠1 ∧ j≠2)) ∨ (j=2 ∧ (i≠0 ∧ i≠1 ∧ i≠2)) ∨
    fromA i+1<fromA j ∨ fromA j+1<fromA i ∨
    fromB i+1<fromB j ∨ fromB j+1<fromB i := by
  revert m i j
  decide

private theorem fixed_of (H : LabelData J) (i j : V) (m : fixedMatrix i j=true) : J.Adj i j := by
  rcases fixed_cases i j m with ⟨rfl,h⟩|⟨rfl,h⟩|⟨rfl,h⟩|⟨rfl,h⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩
  · exact dist_eq_one_iff_adj.mp ((H.fa _).trans h)
  · exact (dist_eq_one_iff_adj.mp ((H.fa _).trans h)).symm
  · exact dist_eq_one_iff_adj.mp ((H.fb _).trans h)
  · exact (dist_eq_one_iff_adj.mp ((H.fb _).trans h)).symm
  · exact H.f38
  · exact H.f39
  · exact H.f410
  · exact H.f411
  · exact H.f38.symm
  · exact H.f39.symm
  · exact H.f410.symm
  · exact H.f411.symm

private theorem pos_tail : ∀ j : V,j≠0 ∧ j≠1 ∧ j≠2 → (3 : Nat) ≤ j.val := by decide

private theorem forbid_of (H : LabelData J) (i j : V) (m : allowedMatrix i j=false) : ¬J.Adj i j := by
  intro e
  rcases forbid_cases i j m with rfl|⟨rfl,h⟩|⟨rfl,h⟩|h|h|h|h
  · exact J.loopless _ e
  · exact H.no_s _ (pos_tail _ h) e
  · exact H.no_s _ (pos_tail _ h) e.symm
  · have t := H.hc.dist_triangle (u:=0) (v:=i) (w:=j)
    rw [H.fa i,H.fa j,dist_eq_one_iff_adj.mpr e] at t
    omega
  · have t := H.hc.dist_triangle (u:=0) (v:=j) (w:=i)
    rw [H.fa i,H.fa j,dist_eq_one_iff_adj.mpr e.symm] at t
    omega
  · have t := H.hc.dist_triangle (u:=1) (v:=i) (w:=j)
    rw [H.fb i,H.fb j,dist_eq_one_iff_adj.mpr e] at t
    omega
  · have t := H.hc.dist_triangle (u:=1) (v:=j) (w:=i)
    rw [H.fb i,H.fb j,dist_eq_one_iff_adj.mpr e.symm] at t
    omega

private theorem predA (H : LabelData J) (v : V) (dv : fromA v=2) :
    ∃ w,J.Adj w v ∧ fromA w=1 := by
  have d : J.dist v 0=2 := by rw [dist_comm,H.fa,dv]
  obtain ⟨w,e,q⟩ := predecessor_of_positive_dist H.hc (x:=v) (t:=0) (by omega)
  rw [d,dist_comm (u:=w) (v:=0),H.fa] at q
  exact ⟨w,e.symm,by omega⟩

private theorem predB (H : LabelData J) (v : V) (dv : fromB v=2) :
    ∃ w,J.Adj w v ∧ fromB w=1 := by
  have d : J.dist v 1=2 := by rw [dist_comm,H.fb,dv]
  obtain ⟨w,e,q⟩ := predecessor_of_positive_dist H.hc (x:=v) (t:=1) (by omega)
  rw [d,dist_comm (u:=w) (v:=1),H.fb] at q
  exact ⟨w,e.symm,by omega⟩

private theorem nearA12_of (H : LabelData J) : J.Adj (5:V) 12 ∨ J.Adj (6:V) 12 ∨ J.Adj (7:V) 12 ∨ J.Adj (3:V) 12 := by
  obtain ⟨w,wv,d⟩ := predA H 12 (by decide)
  have e : w=1 ∨ w=2 ∨ w=3 ∨ w=5 ∨ w=6 ∨ w=7 := by
    clear wv H
    revert d w
    decide
  rcases e with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (forbid_of H 1 12 (by decide) wv).elim
  · exact (forbid_of H 2 12 (by decide) wv).elim
  · tauto
  · tauto
  · tauto
  · tauto
private theorem nearA13_of (H : LabelData J) : J.Adj (5:V) 13 ∨ J.Adj (6:V) 13 ∨ J.Adj (7:V) 13 ∨ J.Adj (3:V) 13 := by
  obtain ⟨w,wv,d⟩ := predA H 13 (by decide)
  have e : w=1 ∨ w=2 ∨ w=3 ∨ w=5 ∨ w=6 ∨ w=7 := by
    clear wv H
    revert d w
    decide
  rcases e with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (forbid_of H 1 13 (by decide) wv).elim
  · exact (forbid_of H 2 13 (by decide) wv).elim
  · tauto
  · tauto
  · tauto
  · tauto
private theorem nearB12_of (H : LabelData J) : J.Adj (5:V) 12 ∨ J.Adj (6:V) 12 ∨ J.Adj (7:V) 12 ∨ J.Adj (4:V) 12 := by
  obtain ⟨w,wv,d⟩ := predB H 12 (by decide)
  have e : w=0 ∨ w=2 ∨ w=4 ∨ w=5 ∨ w=6 ∨ w=7 := by
    clear wv H
    revert d w
    decide
  rcases e with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (forbid_of H 0 12 (by decide) wv).elim
  · exact (forbid_of H 2 12 (by decide) wv).elim
  · tauto
  · tauto
  · tauto
  · tauto
private theorem nearB13_of (H : LabelData J) : J.Adj (5:V) 13 ∨ J.Adj (6:V) 13 ∨ J.Adj (7:V) 13 ∨ J.Adj (4:V) 13 := by
  obtain ⟨w,wv,d⟩ := predB H 13 (by decide)
  have e : w=0 ∨ w=2 ∨ w=4 ∨ w=5 ∨ w=6 ∨ w=7 := by
    clear wv H
    revert d w
    decide
  rcases e with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (forbid_of H 0 13 (by decide) wv).elim
  · exact (forbid_of H 2 13 (by decide) wv).elim
  · tauto
  · tauto
  · tauto
  · tauto

private theorem toGeometry (H : LabelData J) : Geometry J :=
  ⟨H.hc,H.even,H.high,fixed_of H,forbid_of H, nearA12_of H,nearA13_of H,nearB12_of H,nearB13_of H⟩

theorem traceable_of_label_data (H : LabelData J) : ∃ s t,∃ p : J.Walk s t,p.IsPath ∧ ∀ z,z∈p.support :=
  normalized_all_routes (toGeometry H)

#print axioms traceable_of_label_data
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent.SingletonRUP.ec3
