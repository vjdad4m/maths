import DiversityElevenMathlibRup384b

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent.SingletonRUP
set_option maxRecDepth 32768
set_option maxHeartbeats 100000000
packed_rup ec2_exclusion
  (include_str "single14-rup/ec2_slice.cnf")
  (include_str "single14-rup/ec2_slice.lrat")
packed_rup ec1_bridge
  (include_str "single14-rup/ec1_slice.cnf")
  (include_str "single14-rup/ec1_slice.lrat")

#print axioms ec2_exclusion
#print axioms ec1_bridge
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent.SingletonRUP
