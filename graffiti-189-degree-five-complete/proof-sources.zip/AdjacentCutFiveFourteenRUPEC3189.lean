import DiversityElevenMathlibRup384b

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent.SingletonRUP
set_option maxRecDepth 32768
set_option maxHeartbeats 100000000
packed_rup ec3_all_paths
  (include_str "single14-rup/ec3_slice.cnf")
  (include_str "single14-rup/ec3_slice.lrat")

#print axioms ec3_all_paths
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent.SingletonRUP
