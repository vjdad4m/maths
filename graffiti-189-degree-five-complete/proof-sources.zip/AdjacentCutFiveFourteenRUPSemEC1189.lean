import AdjacentCutFiveFourteenRUPE189
import AdjacentCutFiveBound189
import DiversityElevenCircuitBits384b
import Mathlib.Tactic.FinCases

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent.SingletonRUP.ec1
open SimpleGraph Finset Sat
open private d2 mem_positive from AdjacentCutFiveBound189
open private positive_card from AdjacentCutFiveBound189
open Graffiti384b.DiversityEleven.PendantCircuit (fmla_and fmla_one)
set_option linter.unusedVariables false
set_option linter.unusedSectionVars false
set_option maxRecDepth 32768
set_option maxHeartbeats 100000000
abbrev V := Fin 14
variable {G : SimpleGraph V} [DecidableRel G.Adj]

def fixedMatrix (i j : V) : Bool :=
  match i.val,j.val with
  | 0, 1 | 1, 0 => true
  | 0, 2 | 2, 0 => true
  | 0, 3 | 3, 0 => true
  | 0, 6 | 6, 0 => true
  | 0, 7 | 7, 0 => true
  | 1, 2 | 2, 1 => true
  | 1, 4 | 4, 1 => true
  | 1, 5 | 5, 1 => true
  | 1, 6 | 6, 1 => true
  | 1, 7 | 7, 1 => true
  | 3, 8 | 8, 3 => true
  | 3, 9 | 9, 3 => true
  | _, _ => false

def allowedMatrix (i j : V) : Bool :=
  match i.val,j.val with
  | 0, 1 | 1, 0 => true
  | 0, 2 | 2, 0 => true
  | 0, 3 | 3, 0 => true
  | 0, 6 | 6, 0 => true
  | 0, 7 | 7, 0 => true
  | 1, 2 | 2, 1 => true
  | 1, 4 | 4, 1 => true
  | 1, 5 | 5, 1 => true
  | 1, 6 | 6, 1 => true
  | 1, 7 | 7, 1 => true
  | 3, 4 | 4, 3 => true
  | 3, 5 | 5, 3 => true
  | 3, 6 | 6, 3 => true
  | 3, 7 | 7, 3 => true
  | 3, 8 | 8, 3 => true
  | 3, 9 | 9, 3 => true
  | 3, 13 | 13, 3 => true
  | 4, 5 | 5, 4 => true
  | 4, 6 | 6, 4 => true
  | 4, 7 | 7, 4 => true
  | 4, 10 | 10, 4 => true
  | 4, 11 | 11, 4 => true
  | 4, 12 | 12, 4 => true
  | 4, 13 | 13, 4 => true
  | 5, 6 | 6, 5 => true
  | 5, 7 | 7, 5 => true
  | 5, 10 | 10, 5 => true
  | 5, 11 | 11, 5 => true
  | 5, 12 | 12, 5 => true
  | 5, 13 | 13, 5 => true
  | 6, 7 | 7, 6 => true
  | 6, 13 | 13, 6 => true
  | 7, 13 | 13, 7 => true
  | 8, 9 | 9, 8 => true
  | 8, 10 | 10, 8 => true
  | 8, 11 | 11, 8 => true
  | 8, 12 | 12, 8 => true
  | 8, 13 | 13, 8 => true
  | 9, 10 | 10, 9 => true
  | 9, 11 | 11, 9 => true
  | 9, 12 | 12, 9 => true
  | 9, 13 | 13, 9 => true
  | 10, 11 | 11, 10 => true
  | 10, 12 | 12, 10 => true
  | 10, 13 | 13, 10 => true
  | 11, 12 | 12, 11 => true
  | 11, 13 | 13, 11 => true
  | 12, 13 | 13, 12 => true
  | _, _ => false

structure Geometry (G : SimpleGraph V) [DecidableRel G.Adj] : Prop where
  conn : G.Connected
  even : ∀ i, (EvenFrom G i).card≤6
  high : ∀ i : V, 3≤i.val → 5≤G.degree i
  fixed : ∀ i j, fixedMatrix i j = true → G.Adj i j
  forbidden : ∀ i j, allowedMatrix i j = false → ¬G.Adj i j
  nearA13 : G.Adj (6:V) 13 ∨ G.Adj (7:V) 13 ∨ G.Adj (3:V) 13
  nearB10 : G.Adj (4:V) 10 ∨ G.Adj (5:V) 10
  nearB11 : G.Adj (4:V) 11 ∨ G.Adj (5:V) 11
  nearB12 : G.Adj (4:V) 12 ∨ G.Adj (5:V) 12
  nearB13 : G.Adj (6:V) 13 ∨ G.Adj (7:V) 13 ∨ G.Adj (4:V) 13 ∨ G.Adj (5:V) 13

def Shape (G : SimpleGraph V) : Prop := G.Adj 6 13 ∧ G.Adj 7 13 ∧ G.Adj 3 7 ∧ ¬G.Adj 10 13 ∧ ¬G.Adj 11 13 ∧ ¬G.Adj 12 13

def val (G : SimpleGraph V) : Sat.Valuation := fun i =>
  match i with
  | 0 => G.Adj (3:V) 4
  | 1 => G.Adj (3:V) 5
  | 2 => G.Adj (3:V) 6
  | 3 => G.Adj (3:V) 7
  | 4 => G.Adj (3:V) 13
  | 5 => G.Adj (4:V) 5
  | 6 => G.Adj (4:V) 6
  | 7 => G.Adj (4:V) 7
  | 8 => G.Adj (4:V) 10
  | 9 => G.Adj (4:V) 11
  | 10 => G.Adj (4:V) 12
  | 11 => G.Adj (4:V) 13
  | 12 => G.Adj (5:V) 6
  | 13 => G.Adj (5:V) 7
  | 14 => G.Adj (5:V) 10
  | 15 => G.Adj (5:V) 11
  | 16 => G.Adj (5:V) 12
  | 17 => G.Adj (5:V) 13
  | 18 => G.Adj (6:V) 7
  | 19 => G.Adj (6:V) 13
  | 20 => G.Adj (7:V) 13
  | 21 => G.Adj (8:V) 9
  | 22 => G.Adj (8:V) 10
  | 23 => G.Adj (8:V) 11
  | 24 => G.Adj (8:V) 12
  | 25 => G.Adj (8:V) 13
  | 26 => G.Adj (9:V) 10
  | 27 => G.Adj (9:V) 11
  | 28 => G.Adj (9:V) 12
  | 29 => G.Adj (9:V) 13
  | 30 => G.Adj (10:V) 11
  | 31 => G.Adj (10:V) 12
  | 32 => G.Adj (10:V) 13
  | 33 => G.Adj (11:V) 12
  | 34 => G.Adj (11:V) 13
  | 35 => G.Adj (12:V) 13
  | 36 => G.dist (1:V) 3 = 2
  | 37 => G.dist (2:V) 3 = 2
  | 38 => G.dist (3:V) 4 = 2
  | 39 => G.dist (3:V) 5 = 2
  | 40 => G.dist (3:V) 6 = 2
  | 41 => G.dist (3:V) 7 = 2
  | 42 => G.dist (3:V) 10 = 2
  | 43 => G.dist (3:V) 11 = 2
  | 44 => G.dist (3:V) 12 = 2
  | 45 => G.dist (3:V) 13 = 2
  | 46 => G.dist (0:V) 4 = 2
  | 47 => G.dist (2:V) 4 = 2
  | 48 => G.dist (4:V) 5 = 2
  | 49 => G.dist (4:V) 6 = 2
  | 50 => G.dist (4:V) 7 = 2
  | 51 => G.dist (4:V) 8 = 2
  | 52 => G.dist (4:V) 9 = 2
  | 53 => G.dist (4:V) 10 = 2
  | 54 => G.dist (4:V) 11 = 2
  | 55 => G.dist (4:V) 12 = 2
  | 56 => G.dist (4:V) 13 = 2
  | 57 => G.dist (0:V) 5 = 2
  | 58 => G.dist (2:V) 5 = 2
  | 59 => G.dist (5:V) 6 = 2
  | 60 => G.dist (5:V) 7 = 2
  | 61 => G.dist (5:V) 8 = 2
  | 62 => G.dist (5:V) 9 = 2
  | 63 => G.dist (5:V) 10 = 2
  | 64 => G.dist (5:V) 11 = 2
  | 65 => G.dist (5:V) 12 = 2
  | 66 => G.dist (5:V) 13 = 2
  | 67 => G.dist (2:V) 6 = 2
  | 68 => G.dist (6:V) 7 = 2
  | 69 => G.dist (6:V) 8 = 2
  | 70 => G.dist (6:V) 9 = 2
  | 71 => G.dist (6:V) 10 = 2
  | 72 => G.dist (6:V) 11 = 2
  | 73 => G.dist (6:V) 12 = 2
  | 74 => G.dist (6:V) 13 = 2
  | 75 => G.dist (2:V) 7 = 2
  | 76 => G.dist (7:V) 8 = 2
  | 77 => G.dist (7:V) 9 = 2
  | 78 => G.dist (7:V) 10 = 2
  | 79 => G.dist (7:V) 11 = 2
  | 80 => G.dist (7:V) 12 = 2
  | 81 => G.dist (7:V) 13 = 2
  | _ => False


private theorem degree_small_contra (H : Geometry G) (i : V) (hi : 3≤i.val)
    (S : Finset V) (small : S.card≤4) (not_edge : ∀ j, j∉S → ¬G.Adj i j) : False := by
  classical
  have sub : G.neighborFinset i ⊆ S := by
    intro j h
    apply Classical.byContradiction
    intro no
    exact not_edge j no ((mem_neighborFinset G i j).mp h)
  have cap := (card_le_card sub).trans small
  rw [card_neighborFinset_eq_degree] at cap
  have deg := H.high i hi
  omega

private theorem distance_two_from_two_edges (H : Geometry G) (i k j : V)
    (ne : i≠j) (no : ¬G.Adj i j) (u : G.Adj i k) (v : G.Adj k j) : G.dist i j=2 :=
  (mem_filter.mp (d2 H.conn ne no u v)).2

private theorem six_twos_contra (H : Geometry G) (i : V) (S : Finset V)
    (card6 : S.card=6) (off : i∉S) (all : ∀ j∈S, G.dist i j=2) : False := by
  classical
  have s : S⊆PositiveEven G i := by
    intro j jm
    exact mem_positive.mpr ⟨fun k=>off (k ▸ jm),by rw [all j jm]; decide⟩
  have count := (card_le_card s).trans (positive_card (H.even i))
  omega

private theorem sat_0 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 0, .pos 5, .pos 7, .pos 8, .pos 10] := by
  change ¬(G.Adj (3:V) 4) → ¬(G.Adj (4:V) 5) → ¬(G.Adj (4:V) 7) → ¬(G.Adj (4:V) 10) → ¬(G.Adj (4:V) 12) → False
  intro h0 h1 h2 h3 h4
  apply degree_small_contra H 4 (by decide) ({1,6,11,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 4 0 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 4 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 4 4 (by decide))
  · exact h1
  · exact (hj (by decide)).elim
  · exact h2
  · exact (H.forbidden 4 8 (by decide))
  · exact (H.forbidden 4 9 (by decide))
  · exact h3
  · exact (hj (by decide)).elim
  · exact h4
  · exact (hj (by decide)).elim

private theorem sat_1 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 0, .pos 5, .pos 8, .pos 9, .pos 10] := by
  change ¬(G.Adj (3:V) 4) → ¬(G.Adj (4:V) 5) → ¬(G.Adj (4:V) 10) → ¬(G.Adj (4:V) 11) → ¬(G.Adj (4:V) 12) → False
  intro h0 h1 h2 h3 h4
  apply degree_small_contra H 4 (by decide) ({1,6,7,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 4 0 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 4 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 4 4 (by decide))
  · exact h1
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 4 8 (by decide))
  · exact (H.forbidden 4 9 (by decide))
  · exact h2
  · exact h3
  · exact h4
  · exact (hj (by decide)).elim

private theorem sat_2 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 0, .pos 5, .pos 8, .pos 9, .pos 11] := by
  change ¬(G.Adj (3:V) 4) → ¬(G.Adj (4:V) 5) → ¬(G.Adj (4:V) 10) → ¬(G.Adj (4:V) 11) → ¬(G.Adj (4:V) 13) → False
  intro h0 h1 h2 h3 h4
  apply degree_small_contra H 4 (by decide) ({1,6,7,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 4 0 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 4 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 4 4 (by decide))
  · exact h1
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 4 8 (by decide))
  · exact (H.forbidden 4 9 (by decide))
  · exact h2
  · exact h3
  · exact (hj (by decide)).elim
  · exact h4

private theorem sat_3 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 0, .pos 5, .pos 8, .pos 10, .pos 11] := by
  change ¬(G.Adj (3:V) 4) → ¬(G.Adj (4:V) 5) → ¬(G.Adj (4:V) 10) → ¬(G.Adj (4:V) 12) → ¬(G.Adj (4:V) 13) → False
  intro h0 h1 h2 h3 h4
  apply degree_small_contra H 4 (by decide) ({1,6,7,11} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 4 0 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 4 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 4 4 (by decide))
  · exact h1
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 4 8 (by decide))
  · exact (H.forbidden 4 9 (by decide))
  · exact h2
  · exact (hj (by decide)).elim
  · exact h3
  · exact h4

private theorem sat_4 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 0, .pos 5, .pos 9, .pos 10, .pos 11] := by
  change ¬(G.Adj (3:V) 4) → ¬(G.Adj (4:V) 5) → ¬(G.Adj (4:V) 11) → ¬(G.Adj (4:V) 12) → ¬(G.Adj (4:V) 13) → False
  intro h0 h1 h2 h3 h4
  apply degree_small_contra H 4 (by decide) ({1,6,7,10} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 4 0 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 4 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 4 4 (by decide))
  · exact h1
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 4 8 (by decide))
  · exact (H.forbidden 4 9 (by decide))
  · exact (hj (by decide)).elim
  · exact h2
  · exact h3
  · exact h4

private theorem sat_5 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 0, .pos 7, .pos 8, .pos 9, .pos 11] := by
  change ¬(G.Adj (3:V) 4) → ¬(G.Adj (4:V) 7) → ¬(G.Adj (4:V) 10) → ¬(G.Adj (4:V) 11) → ¬(G.Adj (4:V) 13) → False
  intro h0 h1 h2 h3 h4
  apply degree_small_contra H 4 (by decide) ({1,5,6,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 4 0 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 4 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 4 4 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h1
  · exact (H.forbidden 4 8 (by decide))
  · exact (H.forbidden 4 9 (by decide))
  · exact h2
  · exact h3
  · exact (hj (by decide)).elim
  · exact h4

private theorem sat_6 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 0, .pos 7, .pos 9, .pos 10, .pos 11] := by
  change ¬(G.Adj (3:V) 4) → ¬(G.Adj (4:V) 7) → ¬(G.Adj (4:V) 11) → ¬(G.Adj (4:V) 12) → ¬(G.Adj (4:V) 13) → False
  intro h0 h1 h2 h3 h4
  apply degree_small_contra H 4 (by decide) ({1,5,6,10} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 4 0 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 4 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 4 4 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h1
  · exact (H.forbidden 4 8 (by decide))
  · exact (H.forbidden 4 9 (by decide))
  · exact (hj (by decide)).elim
  · exact h2
  · exact h3
  · exact h4

private theorem sat_7 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 5, .pos 6, .pos 8, .pos 9, .pos 10] := by
  change ¬(G.Adj (4:V) 5) → ¬(G.Adj (4:V) 6) → ¬(G.Adj (4:V) 10) → ¬(G.Adj (4:V) 11) → ¬(G.Adj (4:V) 12) → False
  intro h0 h1 h2 h3 h4
  apply degree_small_contra H 4 (by decide) ({1,3,7,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 4 0 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 4 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 4 4 (by decide))
  · exact h0
  · exact h1
  · exact (hj (by decide)).elim
  · exact (H.forbidden 4 8 (by decide))
  · exact (H.forbidden 4 9 (by decide))
  · exact h2
  · exact h3
  · exact h4
  · exact (hj (by decide)).elim

private theorem sat_8 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 5, .pos 7, .pos 9, .pos 10, .pos 11] := by
  change ¬(G.Adj (4:V) 5) → ¬(G.Adj (4:V) 7) → ¬(G.Adj (4:V) 11) → ¬(G.Adj (4:V) 12) → ¬(G.Adj (4:V) 13) → False
  intro h0 h1 h2 h3 h4
  apply degree_small_contra H 4 (by decide) ({1,3,6,10} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 4 0 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 4 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 4 4 (by decide))
  · exact h0
  · exact (hj (by decide)).elim
  · exact h1
  · exact (H.forbidden 4 8 (by decide))
  · exact (H.forbidden 4 9 (by decide))
  · exact (hj (by decide)).elim
  · exact h2
  · exact h3
  · exact h4

private theorem sat_9 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 5, .pos 8, .pos 9, .pos 10, .pos 11] := by
  change ¬(G.Adj (4:V) 5) → ¬(G.Adj (4:V) 10) → ¬(G.Adj (4:V) 11) → ¬(G.Adj (4:V) 12) → ¬(G.Adj (4:V) 13) → False
  intro h0 h1 h2 h3 h4
  apply degree_small_contra H 4 (by decide) ({1,3,6,7} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 4 0 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 4 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 4 4 (by decide))
  · exact h0
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 4 8 (by decide))
  · exact (H.forbidden 4 9 (by decide))
  · exact h1
  · exact h2
  · exact h3
  · exact h4

private theorem sat_10 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 1, .pos 5, .pos 14, .pos 15, .pos 16] := by
  change ¬(G.Adj (3:V) 5) → ¬(G.Adj (4:V) 5) → ¬(G.Adj (5:V) 10) → ¬(G.Adj (5:V) 11) → ¬(G.Adj (5:V) 12) → False
  intro h0 h1 h2 h3 h4
  apply degree_small_contra H 5 (by decide) ({1,6,7,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 5 0 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 5 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (H.forbidden 5 5 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 5 8 (by decide))
  · exact (H.forbidden 5 9 (by decide))
  · exact h2
  · exact h3
  · exact h4
  · exact (hj (by decide)).elim

private theorem sat_11 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 5, .pos 14, .pos 15, .pos 16, .pos 17] := by
  change ¬(G.Adj (4:V) 5) → ¬(G.Adj (5:V) 10) → ¬(G.Adj (5:V) 11) → ¬(G.Adj (5:V) 12) → ¬(G.Adj (5:V) 13) → False
  intro h0 h1 h2 h3 h4
  apply degree_small_contra H 5 (by decide) ({1,3,6,7} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 5 0 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 5 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 5 5 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 5 8 (by decide))
  · exact (H.forbidden 5 9 (by decide))
  · exact h1
  · exact h2
  · exact h3
  · exact h4

private theorem sat_12 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 3, .pos 7, .pos 13] := by
  change ¬(G.Adj (3:V) 7) → ¬(G.Adj (4:V) 7) → ¬(G.Adj (5:V) 7) → False
  intro h0 h1 h2
  apply degree_small_contra H 7 (by decide) ({0,1,6,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (fun z => h2 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 7 (by decide))
  · exact (H.forbidden 7 8 (by decide))
  · exact (H.forbidden 7 9 (by decide))
  · exact (H.forbidden 7 10 (by decide))
  · exact (H.forbidden 7 11 (by decide))
  · exact (H.forbidden 7 12 (by decide))
  · exact (hj (by decide)).elim

private theorem sat_13 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 3, .pos 7, .pos 20] := by
  change ¬(G.Adj (3:V) 7) → ¬(G.Adj (4:V) 7) → ¬(G.Adj (7:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 7 (by decide) ({0,1,5,6} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 7 (by decide))
  · exact (H.forbidden 7 8 (by decide))
  · exact (H.forbidden 7 9 (by decide))
  · exact (H.forbidden 7 10 (by decide))
  · exact (H.forbidden 7 11 (by decide))
  · exact (H.forbidden 7 12 (by decide))
  · exact h2

private theorem sat_14 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 3, .pos 13, .pos 20] := by
  change ¬(G.Adj (3:V) 7) → ¬(G.Adj (5:V) 7) → ¬(G.Adj (7:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 7 (by decide) ({0,1,4,6} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 7 (by decide))
  · exact (H.forbidden 7 8 (by decide))
  · exact (H.forbidden 7 9 (by decide))
  · exact (H.forbidden 7 10 (by decide))
  · exact (H.forbidden 7 11 (by decide))
  · exact (H.forbidden 7 12 (by decide))
  · exact h2

private theorem sat_15 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 3, .pos 18, .pos 20] := by
  change ¬(G.Adj (3:V) 7) → ¬(G.Adj (6:V) 7) → ¬(G.Adj (7:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 7 (by decide) ({0,1,4,5} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (fun z => h1 z.symm)
  · exact (H.forbidden 7 7 (by decide))
  · exact (H.forbidden 7 8 (by decide))
  · exact (H.forbidden 7 9 (by decide))
  · exact (H.forbidden 7 10 (by decide))
  · exact (H.forbidden 7 11 (by decide))
  · exact (H.forbidden 7 12 (by decide))
  · exact h2

private theorem sat_16 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 7, .pos 13, .pos 18] := by
  change ¬(G.Adj (4:V) 7) → ¬(G.Adj (5:V) 7) → ¬(G.Adj (6:V) 7) → False
  intro h0 h1 h2
  apply degree_small_contra H 7 (by decide) ({0,1,3,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (fun z => h2 z.symm)
  · exact (H.forbidden 7 7 (by decide))
  · exact (H.forbidden 7 8 (by decide))
  · exact (H.forbidden 7 9 (by decide))
  · exact (H.forbidden 7 10 (by decide))
  · exact (H.forbidden 7 11 (by decide))
  · exact (H.forbidden 7 12 (by decide))
  · exact (hj (by decide)).elim

private theorem sat_17 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 7, .pos 13, .pos 20] := by
  change ¬(G.Adj (4:V) 7) → ¬(G.Adj (5:V) 7) → ¬(G.Adj (7:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 7 (by decide) ({0,1,3,6} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 7 (by decide))
  · exact (H.forbidden 7 8 (by decide))
  · exact (H.forbidden 7 9 (by decide))
  · exact (H.forbidden 7 10 (by decide))
  · exact (H.forbidden 7 11 (by decide))
  · exact (H.forbidden 7 12 (by decide))
  · exact h2

private theorem sat_18 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 7, .pos 18, .pos 20] := by
  change ¬(G.Adj (4:V) 7) → ¬(G.Adj (6:V) 7) → ¬(G.Adj (7:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 7 (by decide) ({0,1,3,5} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (fun z => h1 z.symm)
  · exact (H.forbidden 7 7 (by decide))
  · exact (H.forbidden 7 8 (by decide))
  · exact (H.forbidden 7 9 (by decide))
  · exact (H.forbidden 7 10 (by decide))
  · exact (H.forbidden 7 11 (by decide))
  · exact (H.forbidden 7 12 (by decide))
  · exact h2

private theorem sat_19 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 13, .pos 18, .pos 20] := by
  change ¬(G.Adj (5:V) 7) → ¬(G.Adj (6:V) 7) → ¬(G.Adj (7:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 7 (by decide) ({0,1,3,4} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (H.forbidden 7 7 (by decide))
  · exact (H.forbidden 7 8 (by decide))
  · exact (H.forbidden 7 9 (by decide))
  · exact (H.forbidden 7 10 (by decide))
  · exact (H.forbidden 7 11 (by decide))
  · exact (H.forbidden 7 12 (by decide))
  · exact h2

private theorem sat_20 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 22, .pos 23] := by
  change ¬(G.Adj (8:V) 10) → ¬(G.Adj (8:V) 11) → False
  intro h0 h1
  apply degree_small_contra H 8 (by decide) ({3,9,12,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 8 0 (by decide))
  · exact (H.forbidden 8 1 (by decide))
  · exact (H.forbidden 8 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 8 4 (by decide))
  · exact (H.forbidden 8 5 (by decide))
  · exact (H.forbidden 8 6 (by decide))
  · exact (H.forbidden 8 7 (by decide))
  · exact (H.forbidden 8 8 (by decide))
  · exact (hj (by decide)).elim
  · exact h0
  · exact h1
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim

private theorem sat_21 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 22, .pos 24] := by
  change ¬(G.Adj (8:V) 10) → ¬(G.Adj (8:V) 12) → False
  intro h0 h1
  apply degree_small_contra H 8 (by decide) ({3,9,11,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 8 0 (by decide))
  · exact (H.forbidden 8 1 (by decide))
  · exact (H.forbidden 8 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 8 4 (by decide))
  · exact (H.forbidden 8 5 (by decide))
  · exact (H.forbidden 8 6 (by decide))
  · exact (H.forbidden 8 7 (by decide))
  · exact (H.forbidden 8 8 (by decide))
  · exact (hj (by decide)).elim
  · exact h0
  · exact (hj (by decide)).elim
  · exact h1
  · exact (hj (by decide)).elim

private theorem sat_22 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 22, .pos 25] := by
  change ¬(G.Adj (8:V) 10) → ¬(G.Adj (8:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 8 (by decide) ({3,9,11,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 8 0 (by decide))
  · exact (H.forbidden 8 1 (by decide))
  · exact (H.forbidden 8 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 8 4 (by decide))
  · exact (H.forbidden 8 5 (by decide))
  · exact (H.forbidden 8 6 (by decide))
  · exact (H.forbidden 8 7 (by decide))
  · exact (H.forbidden 8 8 (by decide))
  · exact (hj (by decide)).elim
  · exact h0
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h1

private theorem sat_23 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 23, .pos 24] := by
  change ¬(G.Adj (8:V) 11) → ¬(G.Adj (8:V) 12) → False
  intro h0 h1
  apply degree_small_contra H 8 (by decide) ({3,9,10,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 8 0 (by decide))
  · exact (H.forbidden 8 1 (by decide))
  · exact (H.forbidden 8 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 8 4 (by decide))
  · exact (H.forbidden 8 5 (by decide))
  · exact (H.forbidden 8 6 (by decide))
  · exact (H.forbidden 8 7 (by decide))
  · exact (H.forbidden 8 8 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h0
  · exact h1
  · exact (hj (by decide)).elim

private theorem sat_24 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 23, .pos 25] := by
  change ¬(G.Adj (8:V) 11) → ¬(G.Adj (8:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 8 (by decide) ({3,9,10,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 8 0 (by decide))
  · exact (H.forbidden 8 1 (by decide))
  · exact (H.forbidden 8 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 8 4 (by decide))
  · exact (H.forbidden 8 5 (by decide))
  · exact (H.forbidden 8 6 (by decide))
  · exact (H.forbidden 8 7 (by decide))
  · exact (H.forbidden 8 8 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h0
  · exact (hj (by decide)).elim
  · exact h1

private theorem sat_25 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 24, .pos 25] := by
  change ¬(G.Adj (8:V) 12) → ¬(G.Adj (8:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 8 (by decide) ({3,9,10,11} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 8 0 (by decide))
  · exact (H.forbidden 8 1 (by decide))
  · exact (H.forbidden 8 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 8 4 (by decide))
  · exact (H.forbidden 8 5 (by decide))
  · exact (H.forbidden 8 6 (by decide))
  · exact (H.forbidden 8 7 (by decide))
  · exact (H.forbidden 8 8 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h0
  · exact h1

private theorem sat_26 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 26, .pos 28] := by
  change ¬(G.Adj (9:V) 10) → ¬(G.Adj (9:V) 12) → False
  intro h0 h1
  apply degree_small_contra H 9 (by decide) ({3,8,11,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 9 0 (by decide))
  · exact (H.forbidden 9 1 (by decide))
  · exact (H.forbidden 9 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 4 (by decide))
  · exact (H.forbidden 9 5 (by decide))
  · exact (H.forbidden 9 6 (by decide))
  · exact (H.forbidden 9 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 9 (by decide))
  · exact h0
  · exact (hj (by decide)).elim
  · exact h1
  · exact (hj (by decide)).elim

private theorem sat_27 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 26, .pos 29] := by
  change ¬(G.Adj (9:V) 10) → ¬(G.Adj (9:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 9 (by decide) ({3,8,11,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 9 0 (by decide))
  · exact (H.forbidden 9 1 (by decide))
  · exact (H.forbidden 9 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 4 (by decide))
  · exact (H.forbidden 9 5 (by decide))
  · exact (H.forbidden 9 6 (by decide))
  · exact (H.forbidden 9 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 9 (by decide))
  · exact h0
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h1

private theorem sat_28 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 27, .pos 28] := by
  change ¬(G.Adj (9:V) 11) → ¬(G.Adj (9:V) 12) → False
  intro h0 h1
  apply degree_small_contra H 9 (by decide) ({3,8,10,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 9 0 (by decide))
  · exact (H.forbidden 9 1 (by decide))
  · exact (H.forbidden 9 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 4 (by decide))
  · exact (H.forbidden 9 5 (by decide))
  · exact (H.forbidden 9 6 (by decide))
  · exact (H.forbidden 9 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 9 (by decide))
  · exact (hj (by decide)).elim
  · exact h0
  · exact h1
  · exact (hj (by decide)).elim

private theorem sat_29 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 27, .pos 29] := by
  change ¬(G.Adj (9:V) 11) → ¬(G.Adj (9:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 9 (by decide) ({3,8,10,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 9 0 (by decide))
  · exact (H.forbidden 9 1 (by decide))
  · exact (H.forbidden 9 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 4 (by decide))
  · exact (H.forbidden 9 5 (by decide))
  · exact (H.forbidden 9 6 (by decide))
  · exact (H.forbidden 9 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 9 (by decide))
  · exact (hj (by decide)).elim
  · exact h0
  · exact (hj (by decide)).elim
  · exact h1

private theorem sat_30 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 28, .pos 29] := by
  change ¬(G.Adj (9:V) 12) → ¬(G.Adj (9:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 9 (by decide) ({3,8,10,11} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 9 0 (by decide))
  · exact (H.forbidden 9 1 (by decide))
  · exact (H.forbidden 9 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 4 (by decide))
  · exact (H.forbidden 9 5 (by decide))
  · exact (H.forbidden 9 6 (by decide))
  · exact (H.forbidden 9 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 9 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h0
  · exact h1

private theorem sat_31 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 8, .pos 22, .pos 30] := by
  change ¬(G.Adj (4:V) 10) → ¬(G.Adj (8:V) 10) → ¬(G.Adj (10:V) 11) → False
  intro h0 h1 h2
  apply degree_small_contra H 10 (by decide) ({5,9,12,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 6 (by decide))
  · exact (H.forbidden 10 7 (by decide))
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 10 (by decide))
  · exact h2
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim

private theorem sat_32 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 8, .pos 22, .pos 32] := by
  change ¬(G.Adj (4:V) 10) → ¬(G.Adj (8:V) 10) → ¬(G.Adj (10:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 10 (by decide) ({5,9,11,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 6 (by decide))
  · exact (H.forbidden 10 7 (by decide))
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 10 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h2

private theorem sat_33 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 8, .pos 26, .pos 30] := by
  change ¬(G.Adj (4:V) 10) → ¬(G.Adj (9:V) 10) → ¬(G.Adj (10:V) 11) → False
  intro h0 h1 h2
  apply degree_small_contra H 10 (by decide) ({5,8,12,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 6 (by decide))
  · exact (H.forbidden 10 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h1 z.symm)
  · exact (H.forbidden 10 10 (by decide))
  · exact h2
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim

private theorem sat_34 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 8, .pos 26, .pos 32] := by
  change ¬(G.Adj (4:V) 10) → ¬(G.Adj (9:V) 10) → ¬(G.Adj (10:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 10 (by decide) ({5,8,11,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 6 (by decide))
  · exact (H.forbidden 10 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h1 z.symm)
  · exact (H.forbidden 10 10 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h2

private theorem sat_35 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 8, .pos 30, .pos 31] := by
  change ¬(G.Adj (4:V) 10) → ¬(G.Adj (10:V) 11) → ¬(G.Adj (10:V) 12) → False
  intro h0 h1 h2
  apply degree_small_contra H 10 (by decide) ({5,8,9,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 6 (by decide))
  · exact (H.forbidden 10 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 10 (by decide))
  · exact h1
  · exact h2
  · exact (hj (by decide)).elim

private theorem sat_36 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 8, .pos 30, .pos 32] := by
  change ¬(G.Adj (4:V) 10) → ¬(G.Adj (10:V) 11) → ¬(G.Adj (10:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 10 (by decide) ({5,8,9,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 6 (by decide))
  · exact (H.forbidden 10 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 10 (by decide))
  · exact h1
  · exact (hj (by decide)).elim
  · exact h2

private theorem sat_37 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 8, .pos 31, .pos 32] := by
  change ¬(G.Adj (4:V) 10) → ¬(G.Adj (10:V) 12) → ¬(G.Adj (10:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 10 (by decide) ({5,8,9,11} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 6 (by decide))
  · exact (H.forbidden 10 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 10 (by decide))
  · exact (hj (by decide)).elim
  · exact h1
  · exact h2

private theorem sat_38 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 14, .pos 22, .pos 32] := by
  change ¬(G.Adj (5:V) 10) → ¬(G.Adj (8:V) 10) → ¬(G.Adj (10:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 10 (by decide) ({4,9,11,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 10 6 (by decide))
  · exact (H.forbidden 10 7 (by decide))
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 10 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h2

private theorem sat_39 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 14, .pos 26, .pos 32] := by
  change ¬(G.Adj (5:V) 10) → ¬(G.Adj (9:V) 10) → ¬(G.Adj (10:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 10 (by decide) ({4,8,11,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 10 6 (by decide))
  · exact (H.forbidden 10 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h1 z.symm)
  · exact (H.forbidden 10 10 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h2

private theorem sat_40 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 14, .pos 30, .pos 32] := by
  change ¬(G.Adj (5:V) 10) → ¬(G.Adj (10:V) 11) → ¬(G.Adj (10:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 10 (by decide) ({4,8,9,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 10 6 (by decide))
  · exact (H.forbidden 10 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 10 (by decide))
  · exact h1
  · exact (hj (by decide)).elim
  · exact h2

private theorem sat_41 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 14, .pos 31, .pos 32] := by
  change ¬(G.Adj (5:V) 10) → ¬(G.Adj (10:V) 12) → ¬(G.Adj (10:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 10 (by decide) ({4,8,9,11} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 10 6 (by decide))
  · exact (H.forbidden 10 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 10 (by decide))
  · exact (hj (by decide)).elim
  · exact h1
  · exact h2

private theorem sat_42 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 22, .pos 26, .pos 32] := by
  change ¬(G.Adj (8:V) 10) → ¬(G.Adj (9:V) 10) → ¬(G.Adj (10:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 10 (by decide) ({4,5,11,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 6 (by decide))
  · exact (H.forbidden 10 7 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (H.forbidden 10 10 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h2

private theorem sat_43 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 9, .pos 23, .pos 34] := by
  change ¬(G.Adj (4:V) 11) → ¬(G.Adj (8:V) 11) → ¬(G.Adj (11:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 11 (by decide) ({5,9,10,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 11 0 (by decide))
  · exact (H.forbidden 11 1 (by decide))
  · exact (H.forbidden 11 2 (by decide))
  · exact (H.forbidden 11 3 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 11 6 (by decide))
  · exact (H.forbidden 11 7 (by decide))
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 11 11 (by decide))
  · exact (hj (by decide)).elim
  · exact h2

private theorem sat_44 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 15, .pos 23, .pos 34] := by
  change ¬(G.Adj (5:V) 11) → ¬(G.Adj (8:V) 11) → ¬(G.Adj (11:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 11 (by decide) ({4,9,10,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 11 0 (by decide))
  · exact (H.forbidden 11 1 (by decide))
  · exact (H.forbidden 11 2 (by decide))
  · exact (H.forbidden 11 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 11 6 (by decide))
  · exact (H.forbidden 11 7 (by decide))
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 11 11 (by decide))
  · exact (hj (by decide)).elim
  · exact h2

private theorem sat_45 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 15, .pos 27, .pos 34] := by
  change ¬(G.Adj (5:V) 11) → ¬(G.Adj (9:V) 11) → ¬(G.Adj (11:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 11 (by decide) ({4,8,10,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 11 0 (by decide))
  · exact (H.forbidden 11 1 (by decide))
  · exact (H.forbidden 11 2 (by decide))
  · exact (H.forbidden 11 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 11 6 (by decide))
  · exact (H.forbidden 11 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 11 11 (by decide))
  · exact (hj (by decide)).elim
  · exact h2

private theorem sat_46 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 15, .pos 30, .pos 34] := by
  change ¬(G.Adj (5:V) 11) → ¬(G.Adj (10:V) 11) → ¬(G.Adj (11:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 11 (by decide) ({4,8,9,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 11 0 (by decide))
  · exact (H.forbidden 11 1 (by decide))
  · exact (H.forbidden 11 2 (by decide))
  · exact (H.forbidden 11 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 11 6 (by decide))
  · exact (H.forbidden 11 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (fun z => h1 z.symm)
  · exact (H.forbidden 11 11 (by decide))
  · exact (hj (by decide)).elim
  · exact h2

private theorem sat_47 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 15, .pos 33, .pos 34] := by
  change ¬(G.Adj (5:V) 11) → ¬(G.Adj (11:V) 12) → ¬(G.Adj (11:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 11 (by decide) ({4,8,9,10} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 11 0 (by decide))
  · exact (H.forbidden 11 1 (by decide))
  · exact (H.forbidden 11 2 (by decide))
  · exact (H.forbidden 11 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 11 6 (by decide))
  · exact (H.forbidden 11 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 11 11 (by decide))
  · exact h1
  · exact h2

private theorem sat_48 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 23, .pos 27, .pos 34] := by
  change ¬(G.Adj (8:V) 11) → ¬(G.Adj (9:V) 11) → ¬(G.Adj (11:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 11 (by decide) ({4,5,10,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 11 0 (by decide))
  · exact (H.forbidden 11 1 (by decide))
  · exact (H.forbidden 11 2 (by decide))
  · exact (H.forbidden 11 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 11 6 (by decide))
  · exact (H.forbidden 11 7 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 11 11 (by decide))
  · exact (hj (by decide)).elim
  · exact h2

private theorem sat_49 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 10, .pos 24, .pos 31] := by
  change ¬(G.Adj (4:V) 12) → ¬(G.Adj (8:V) 12) → ¬(G.Adj (10:V) 12) → False
  intro h0 h1 h2
  apply degree_small_contra H 12 (by decide) ({5,9,11,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 12 0 (by decide))
  · exact (H.forbidden 12 1 (by decide))
  · exact (H.forbidden 12 2 (by decide))
  · exact (H.forbidden 12 3 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 12 6 (by decide))
  · exact (H.forbidden 12 7 (by decide))
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (fun z => h2 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 12 12 (by decide))
  · exact (hj (by decide)).elim

private theorem sat_50 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 10, .pos 24, .pos 35] := by
  change ¬(G.Adj (4:V) 12) → ¬(G.Adj (8:V) 12) → ¬(G.Adj (12:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 12 (by decide) ({5,9,10,11} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 12 0 (by decide))
  · exact (H.forbidden 12 1 (by decide))
  · exact (H.forbidden 12 2 (by decide))
  · exact (H.forbidden 12 3 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 12 6 (by decide))
  · exact (H.forbidden 12 7 (by decide))
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 12 12 (by decide))
  · exact h2

private theorem sat_51 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 10, .pos 28, .pos 31] := by
  change ¬(G.Adj (4:V) 12) → ¬(G.Adj (9:V) 12) → ¬(G.Adj (10:V) 12) → False
  intro h0 h1 h2
  apply degree_small_contra H 12 (by decide) ({5,8,11,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 12 0 (by decide))
  · exact (H.forbidden 12 1 (by decide))
  · exact (H.forbidden 12 2 (by decide))
  · exact (H.forbidden 12 3 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 12 6 (by decide))
  · exact (H.forbidden 12 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h1 z.symm)
  · exact (fun z => h2 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 12 12 (by decide))
  · exact (hj (by decide)).elim

private theorem sat_52 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 10, .pos 28, .pos 35] := by
  change ¬(G.Adj (4:V) 12) → ¬(G.Adj (9:V) 12) → ¬(G.Adj (12:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 12 (by decide) ({5,8,10,11} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 12 0 (by decide))
  · exact (H.forbidden 12 1 (by decide))
  · exact (H.forbidden 12 2 (by decide))
  · exact (H.forbidden 12 3 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 12 6 (by decide))
  · exact (H.forbidden 12 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 12 12 (by decide))
  · exact h2

private theorem sat_53 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 10, .pos 31, .pos 33] := by
  change ¬(G.Adj (4:V) 12) → ¬(G.Adj (10:V) 12) → ¬(G.Adj (11:V) 12) → False
  intro h0 h1 h2
  apply degree_small_contra H 12 (by decide) ({5,8,9,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 12 0 (by decide))
  · exact (H.forbidden 12 1 (by decide))
  · exact (H.forbidden 12 2 (by decide))
  · exact (H.forbidden 12 3 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 12 6 (by decide))
  · exact (H.forbidden 12 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (fun z => h1 z.symm)
  · exact (fun z => h2 z.symm)
  · exact (H.forbidden 12 12 (by decide))
  · exact (hj (by decide)).elim

private theorem sat_54 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 10, .pos 31, .pos 35] := by
  change ¬(G.Adj (4:V) 12) → ¬(G.Adj (10:V) 12) → ¬(G.Adj (12:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 12 (by decide) ({5,8,9,11} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 12 0 (by decide))
  · exact (H.forbidden 12 1 (by decide))
  · exact (H.forbidden 12 2 (by decide))
  · exact (H.forbidden 12 3 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 12 6 (by decide))
  · exact (H.forbidden 12 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 12 12 (by decide))
  · exact h2

private theorem sat_55 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 16, .pos 24, .pos 35] := by
  change ¬(G.Adj (5:V) 12) → ¬(G.Adj (8:V) 12) → ¬(G.Adj (12:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 12 (by decide) ({4,9,10,11} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 12 0 (by decide))
  · exact (H.forbidden 12 1 (by decide))
  · exact (H.forbidden 12 2 (by decide))
  · exact (H.forbidden 12 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 12 6 (by decide))
  · exact (H.forbidden 12 7 (by decide))
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 12 12 (by decide))
  · exact h2

private theorem sat_56 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 16, .pos 28, .pos 35] := by
  change ¬(G.Adj (5:V) 12) → ¬(G.Adj (9:V) 12) → ¬(G.Adj (12:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 12 (by decide) ({4,8,10,11} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 12 0 (by decide))
  · exact (H.forbidden 12 1 (by decide))
  · exact (H.forbidden 12 2 (by decide))
  · exact (H.forbidden 12 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 12 6 (by decide))
  · exact (H.forbidden 12 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 12 12 (by decide))
  · exact h2

private theorem sat_57 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 16, .pos 31, .pos 35] := by
  change ¬(G.Adj (5:V) 12) → ¬(G.Adj (10:V) 12) → ¬(G.Adj (12:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 12 (by decide) ({4,8,9,11} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 12 0 (by decide))
  · exact (H.forbidden 12 1 (by decide))
  · exact (H.forbidden 12 2 (by decide))
  · exact (H.forbidden 12 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 12 6 (by decide))
  · exact (H.forbidden 12 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 12 12 (by decide))
  · exact h2

private theorem sat_58 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 16, .pos 33, .pos 35] := by
  change ¬(G.Adj (5:V) 12) → ¬(G.Adj (11:V) 12) → ¬(G.Adj (12:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 12 (by decide) ({4,8,9,10} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 12 0 (by decide))
  · exact (H.forbidden 12 1 (by decide))
  · exact (H.forbidden 12 2 (by decide))
  · exact (H.forbidden 12 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 12 6 (by decide))
  · exact (H.forbidden 12 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (fun z => h1 z.symm)
  · exact (H.forbidden 12 12 (by decide))
  · exact h2

private theorem sat_59 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 24, .pos 28, .pos 35] := by
  change ¬(G.Adj (8:V) 12) → ¬(G.Adj (9:V) 12) → ¬(G.Adj (12:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 12 (by decide) ({4,5,10,11} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 12 0 (by decide))
  · exact (H.forbidden 12 1 (by decide))
  · exact (H.forbidden 12 2 (by decide))
  · exact (H.forbidden 12 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 12 6 (by decide))
  · exact (H.forbidden 12 7 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 12 12 (by decide))
  · exact h2

private theorem sat_60 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 31, .pos 33, .pos 35] := by
  change ¬(G.Adj (10:V) 12) → ¬(G.Adj (11:V) 12) → ¬(G.Adj (12:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 12 (by decide) ({4,5,8,9} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 12 0 (by decide))
  · exact (H.forbidden 12 1 (by decide))
  · exact (H.forbidden 12 2 (by decide))
  · exact (H.forbidden 12 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 12 6 (by decide))
  · exact (H.forbidden 12 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (H.forbidden 12 12 (by decide))
  · exact h2

private theorem sat_61 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 4, .pos 19, .pos 20] := by
  change ¬(G.Adj (3:V) 13) → ¬(G.Adj (6:V) 13) → ¬(G.Adj (7:V) 13) → False
  intro h0 h1 h2
  have k := H.nearA13
  tauto

private theorem sat_62 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 11, .pos 17, .pos 19, .pos 20] := by
  change ¬(G.Adj (4:V) 13) → ¬(G.Adj (5:V) 13) → ¬(G.Adj (6:V) 13) → ¬(G.Adj (7:V) 13) → False
  intro h0 h1 h2 h3
  have k := H.nearB13
  tauto

private theorem sat_63 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 8, .pos 14] := by
  change ¬(G.Adj (4:V) 10) → ¬(G.Adj (5:V) 10) → False
  intro h0 h1
  have k := H.nearB10
  tauto

private theorem sat_64 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 9, .pos 15] := by
  change ¬(G.Adj (4:V) 11) → ¬(G.Adj (5:V) 11) → False
  intro h0 h1
  have k := H.nearB11
  tauto

private theorem sat_65 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 10, .pos 16] := by
  change ¬(G.Adj (4:V) 12) → ¬(G.Adj (5:V) 12) → False
  intro h0 h1
  have k := H.nearB12
  tauto

private theorem sat_66 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 36] := by
  change ¬(G.dist (1:V) 3 = 2) → False
  intro h0
  exact h0 (by rw [dist_comm]; exact distance_two_from_two_edges H 3 0 1 (by decide) (H.forbidden 3 1 (by decide)) (H.fixed 3 0 (by decide)) (H.fixed 0 1 (by decide)))

private theorem sat_67 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 37] := by
  change ¬(G.dist (2:V) 3 = 2) → False
  intro h0
  exact h0 (by rw [dist_comm]; exact distance_two_from_two_edges H 3 0 2 (by decide) (H.forbidden 3 2 (by decide)) (H.fixed 3 0 (by decide)) (H.fixed 0 2 (by decide)))

private theorem sat_68 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 0, .neg 3, .neg 7, .pos 38] := by
  change ¬(G.Adj (3:V) 4) → (G.Adj (3:V) 7) → (G.Adj (4:V) 7) → ¬(G.dist (3:V) 4 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 3 7 4 (by decide) h0 h1 h2.symm)

private theorem sat_69 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 1, .neg 3, .neg 13, .pos 39] := by
  change ¬(G.Adj (3:V) 5) → (G.Adj (3:V) 7) → (G.Adj (5:V) 7) → ¬(G.dist (3:V) 5 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 3 7 5 (by decide) h0 h1 h2.symm)

private theorem sat_70 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 2, .pos 40] := by
  change ¬(G.Adj (3:V) 6) → ¬(G.dist (3:V) 6 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 3 0 6 (by decide) h0 (H.fixed 3 0 (by decide)) (H.fixed 0 6 (by decide)))

private theorem sat_71 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 3, .pos 41] := by
  change ¬(G.Adj (3:V) 7) → ¬(G.dist (3:V) 7 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 3 0 7 (by decide) h0 (H.fixed 3 0 (by decide)) (H.fixed 0 7 (by decide)))

private theorem sat_72 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 22, .pos 42] := by
  change (G.Adj (8:V) 10) → ¬(G.dist (3:V) 10 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 3 8 10 (by decide) (H.forbidden 3 10 (by decide)) (H.fixed 3 8 (by decide)) h0)

private theorem sat_73 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 26, .pos 42] := by
  change (G.Adj (9:V) 10) → ¬(G.dist (3:V) 10 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 3 9 10 (by decide) (H.forbidden 3 10 (by decide)) (H.fixed 3 9 (by decide)) h0)

private theorem sat_74 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 23, .pos 43] := by
  change (G.Adj (8:V) 11) → ¬(G.dist (3:V) 11 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 3 8 11 (by decide) (H.forbidden 3 11 (by decide)) (H.fixed 3 8 (by decide)) h0)

private theorem sat_75 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 27, .pos 43] := by
  change (G.Adj (9:V) 11) → ¬(G.dist (3:V) 11 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 3 9 11 (by decide) (H.forbidden 3 11 (by decide)) (H.fixed 3 9 (by decide)) h0)

private theorem sat_76 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 24, .pos 44] := by
  change (G.Adj (8:V) 12) → ¬(G.dist (3:V) 12 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 3 8 12 (by decide) (H.forbidden 3 12 (by decide)) (H.fixed 3 8 (by decide)) h0)

private theorem sat_77 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 28, .pos 44] := by
  change (G.Adj (9:V) 12) → ¬(G.dist (3:V) 12 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 3 9 12 (by decide) (H.forbidden 3 12 (by decide)) (H.fixed 3 9 (by decide)) h0)

private theorem sat_78 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 46] := by
  change ¬(G.dist (0:V) 4 = 2) → False
  intro h0
  exact h0 (by rw [dist_comm]; exact distance_two_from_two_edges H 4 1 0 (by decide) (H.forbidden 4 0 (by decide)) (H.fixed 4 1 (by decide)) (H.fixed 1 0 (by decide)))

private theorem sat_79 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 47] := by
  change ¬(G.dist (2:V) 4 = 2) → False
  intro h0
  exact h0 (by rw [dist_comm]; exact distance_two_from_two_edges H 4 1 2 (by decide) (H.forbidden 4 2 (by decide)) (H.fixed 4 1 (by decide)) (H.fixed 1 2 (by decide)))

private theorem sat_80 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 5, .pos 48] := by
  change ¬(G.Adj (4:V) 5) → ¬(G.dist (4:V) 5 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 4 1 5 (by decide) h0 (H.fixed 4 1 (by decide)) (H.fixed 1 5 (by decide)))

private theorem sat_81 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 6, .pos 49] := by
  change ¬(G.Adj (4:V) 6) → ¬(G.dist (4:V) 6 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 4 1 6 (by decide) h0 (H.fixed 4 1 (by decide)) (H.fixed 1 6 (by decide)))

private theorem sat_82 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 7, .pos 50] := by
  change ¬(G.Adj (4:V) 7) → ¬(G.dist (4:V) 7 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 4 1 7 (by decide) h0 (H.fixed 4 1 (by decide)) (H.fixed 1 7 (by decide)))

private theorem sat_83 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 0, .pos 51] := by
  change (G.Adj (3:V) 4) → ¬(G.dist (4:V) 8 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 4 3 8 (by decide) (H.forbidden 4 8 (by decide)) h0.symm (H.fixed 3 8 (by decide)))

private theorem sat_84 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 8, .neg 22, .pos 51] := by
  change (G.Adj (4:V) 10) → (G.Adj (8:V) 10) → ¬(G.dist (4:V) 8 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 4 10 8 (by decide) (H.forbidden 4 8 (by decide)) h0 h1.symm)

private theorem sat_85 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 9, .neg 23, .pos 51] := by
  change (G.Adj (4:V) 11) → (G.Adj (8:V) 11) → ¬(G.dist (4:V) 8 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 4 11 8 (by decide) (H.forbidden 4 8 (by decide)) h0 h1.symm)

private theorem sat_86 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 10, .neg 24, .pos 51] := by
  change (G.Adj (4:V) 12) → (G.Adj (8:V) 12) → ¬(G.dist (4:V) 8 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 4 12 8 (by decide) (H.forbidden 4 8 (by decide)) h0 h1.symm)

private theorem sat_87 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 11, .neg 25, .pos 51] := by
  change (G.Adj (4:V) 13) → (G.Adj (8:V) 13) → ¬(G.dist (4:V) 8 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 4 13 8 (by decide) (H.forbidden 4 8 (by decide)) h0 h1.symm)

private theorem sat_88 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 0, .pos 52] := by
  change (G.Adj (3:V) 4) → ¬(G.dist (4:V) 9 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 4 3 9 (by decide) (H.forbidden 4 9 (by decide)) h0.symm (H.fixed 3 9 (by decide)))

private theorem sat_89 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 8, .neg 26, .pos 52] := by
  change (G.Adj (4:V) 10) → (G.Adj (9:V) 10) → ¬(G.dist (4:V) 9 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 4 10 9 (by decide) (H.forbidden 4 9 (by decide)) h0 h1.symm)

private theorem sat_90 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 9, .neg 27, .pos 52] := by
  change (G.Adj (4:V) 11) → (G.Adj (9:V) 11) → ¬(G.dist (4:V) 9 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 4 11 9 (by decide) (H.forbidden 4 9 (by decide)) h0 h1.symm)

private theorem sat_91 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 10, .neg 28, .pos 52] := by
  change (G.Adj (4:V) 12) → (G.Adj (9:V) 12) → ¬(G.dist (4:V) 9 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 4 12 9 (by decide) (H.forbidden 4 9 (by decide)) h0 h1.symm)

private theorem sat_92 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 11, .neg 29, .pos 52] := by
  change (G.Adj (4:V) 13) → (G.Adj (9:V) 13) → ¬(G.dist (4:V) 9 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 4 13 9 (by decide) (H.forbidden 4 9 (by decide)) h0 h1.symm)

private theorem sat_93 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 5, .pos 8, .neg 14, .pos 53] := by
  change (G.Adj (4:V) 5) → ¬(G.Adj (4:V) 10) → (G.Adj (5:V) 10) → ¬(G.dist (4:V) 10 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 5 10 (by decide) h1 h0 h2)

private theorem sat_94 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 8, .neg 9, .neg 30, .pos 53] := by
  change ¬(G.Adj (4:V) 10) → (G.Adj (4:V) 11) → (G.Adj (10:V) 11) → ¬(G.dist (4:V) 10 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 11 10 (by decide) h0 h1 h2.symm)

private theorem sat_95 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 8, .neg 10, .neg 31, .pos 53] := by
  change ¬(G.Adj (4:V) 10) → (G.Adj (4:V) 12) → (G.Adj (10:V) 12) → ¬(G.dist (4:V) 10 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 12 10 (by decide) h0 h1 h2.symm)

private theorem sat_96 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 8, .neg 11, .neg 32, .pos 53] := by
  change ¬(G.Adj (4:V) 10) → (G.Adj (4:V) 13) → (G.Adj (10:V) 13) → ¬(G.dist (4:V) 10 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 13 10 (by decide) h0 h1 h2.symm)

private theorem sat_97 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 5, .pos 9, .neg 15, .pos 54] := by
  change (G.Adj (4:V) 5) → ¬(G.Adj (4:V) 11) → (G.Adj (5:V) 11) → ¬(G.dist (4:V) 11 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 5 11 (by decide) h1 h0 h2)

private theorem sat_98 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 8, .pos 9, .neg 30, .pos 54] := by
  change (G.Adj (4:V) 10) → ¬(G.Adj (4:V) 11) → (G.Adj (10:V) 11) → ¬(G.dist (4:V) 11 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 10 11 (by decide) h1 h0 h2)

private theorem sat_99 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 9, .neg 10, .neg 33, .pos 54] := by
  change ¬(G.Adj (4:V) 11) → (G.Adj (4:V) 12) → (G.Adj (11:V) 12) → ¬(G.dist (4:V) 11 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 12 11 (by decide) h0 h1 h2.symm)

private theorem sat_100 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 9, .neg 11, .neg 34, .pos 54] := by
  change ¬(G.Adj (4:V) 11) → (G.Adj (4:V) 13) → (G.Adj (11:V) 13) → ¬(G.dist (4:V) 11 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 13 11 (by decide) h0 h1 h2.symm)

private theorem sat_101 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 5, .pos 10, .neg 16, .pos 55] := by
  change (G.Adj (4:V) 5) → ¬(G.Adj (4:V) 12) → (G.Adj (5:V) 12) → ¬(G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 5 12 (by decide) h1 h0 h2)

private theorem sat_102 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 8, .pos 10, .neg 31, .pos 55] := by
  change (G.Adj (4:V) 10) → ¬(G.Adj (4:V) 12) → (G.Adj (10:V) 12) → ¬(G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 10 12 (by decide) h1 h0 h2)

private theorem sat_103 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 9, .pos 10, .neg 33, .pos 55] := by
  change (G.Adj (4:V) 11) → ¬(G.Adj (4:V) 12) → (G.Adj (11:V) 12) → ¬(G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 11 12 (by decide) h1 h0 h2)

private theorem sat_104 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 10, .neg 11, .neg 35, .pos 55] := by
  change ¬(G.Adj (4:V) 12) → (G.Adj (4:V) 13) → (G.Adj (12:V) 13) → ¬(G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 13 12 (by decide) h0 h1 h2.symm)

private theorem sat_105 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 7, .pos 11, .neg 20, .pos 56] := by
  change (G.Adj (4:V) 7) → ¬(G.Adj (4:V) 13) → (G.Adj (7:V) 13) → ¬(G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 7 13 (by decide) h1 h0 h2)

private theorem sat_106 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 8, .pos 11, .neg 32, .pos 56] := by
  change (G.Adj (4:V) 10) → ¬(G.Adj (4:V) 13) → (G.Adj (10:V) 13) → ¬(G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 10 13 (by decide) h1 h0 h2)

private theorem sat_107 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 9, .pos 11, .neg 34, .pos 56] := by
  change (G.Adj (4:V) 11) → ¬(G.Adj (4:V) 13) → (G.Adj (11:V) 13) → ¬(G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 11 13 (by decide) h1 h0 h2)

private theorem sat_108 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 10, .pos 11, .neg 35, .pos 56] := by
  change (G.Adj (4:V) 12) → ¬(G.Adj (4:V) 13) → (G.Adj (12:V) 13) → ¬(G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 12 13 (by decide) h1 h0 h2)

private theorem sat_109 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 57] := by
  change ¬(G.dist (0:V) 5 = 2) → False
  intro h0
  exact h0 (by rw [dist_comm]; exact distance_two_from_two_edges H 5 1 0 (by decide) (H.forbidden 5 0 (by decide)) (H.fixed 5 1 (by decide)) (H.fixed 1 0 (by decide)))

private theorem sat_110 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 58] := by
  change ¬(G.dist (2:V) 5 = 2) → False
  intro h0
  exact h0 (by rw [dist_comm]; exact distance_two_from_two_edges H 5 1 2 (by decide) (H.forbidden 5 2 (by decide)) (H.fixed 5 1 (by decide)) (H.fixed 1 2 (by decide)))

private theorem sat_111 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 12, .pos 59] := by
  change ¬(G.Adj (5:V) 6) → ¬(G.dist (5:V) 6 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 5 1 6 (by decide) h0 (H.fixed 5 1 (by decide)) (H.fixed 1 6 (by decide)))

private theorem sat_112 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 13, .pos 60] := by
  change ¬(G.Adj (5:V) 7) → ¬(G.dist (5:V) 7 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 5 1 7 (by decide) h0 (H.fixed 5 1 (by decide)) (H.fixed 1 7 (by decide)))

private theorem sat_113 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 1, .pos 61] := by
  change (G.Adj (3:V) 5) → ¬(G.dist (5:V) 8 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 5 3 8 (by decide) (H.forbidden 5 8 (by decide)) h0.symm (H.fixed 3 8 (by decide)))

private theorem sat_114 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 14, .neg 22, .pos 61] := by
  change (G.Adj (5:V) 10) → (G.Adj (8:V) 10) → ¬(G.dist (5:V) 8 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 5 10 8 (by decide) (H.forbidden 5 8 (by decide)) h0 h1.symm)

private theorem sat_115 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 15, .neg 23, .pos 61] := by
  change (G.Adj (5:V) 11) → (G.Adj (8:V) 11) → ¬(G.dist (5:V) 8 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 5 11 8 (by decide) (H.forbidden 5 8 (by decide)) h0 h1.symm)

private theorem sat_116 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 16, .neg 24, .pos 61] := by
  change (G.Adj (5:V) 12) → (G.Adj (8:V) 12) → ¬(G.dist (5:V) 8 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 5 12 8 (by decide) (H.forbidden 5 8 (by decide)) h0 h1.symm)

private theorem sat_117 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 1, .pos 62] := by
  change (G.Adj (3:V) 5) → ¬(G.dist (5:V) 9 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 5 3 9 (by decide) (H.forbidden 5 9 (by decide)) h0.symm (H.fixed 3 9 (by decide)))

private theorem sat_118 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 14, .neg 26, .pos 62] := by
  change (G.Adj (5:V) 10) → (G.Adj (9:V) 10) → ¬(G.dist (5:V) 9 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 5 10 9 (by decide) (H.forbidden 5 9 (by decide)) h0 h1.symm)

private theorem sat_119 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 15, .neg 27, .pos 62] := by
  change (G.Adj (5:V) 11) → (G.Adj (9:V) 11) → ¬(G.dist (5:V) 9 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 5 11 9 (by decide) (H.forbidden 5 9 (by decide)) h0 h1.symm)

private theorem sat_120 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 16, .neg 28, .pos 62] := by
  change (G.Adj (5:V) 12) → (G.Adj (9:V) 12) → ¬(G.dist (5:V) 9 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 5 12 9 (by decide) (H.forbidden 5 9 (by decide)) h0 h1.symm)

private theorem sat_121 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 17, .neg 29, .pos 62] := by
  change (G.Adj (5:V) 13) → (G.Adj (9:V) 13) → ¬(G.dist (5:V) 9 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 5 13 9 (by decide) (H.forbidden 5 9 (by decide)) h0 h1.symm)

private theorem sat_122 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 5, .neg 8, .pos 14, .pos 63] := by
  change (G.Adj (4:V) 5) → (G.Adj (4:V) 10) → ¬(G.Adj (5:V) 10) → ¬(G.dist (5:V) 10 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 5 4 10 (by decide) h2 h0.symm h1)

private theorem sat_123 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 14, .neg 16, .neg 31, .pos 63] := by
  change ¬(G.Adj (5:V) 10) → (G.Adj (5:V) 12) → (G.Adj (10:V) 12) → ¬(G.dist (5:V) 10 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 5 12 10 (by decide) h0 h1 h2.symm)

private theorem sat_124 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 14, .neg 17, .neg 32, .pos 63] := by
  change ¬(G.Adj (5:V) 10) → (G.Adj (5:V) 13) → (G.Adj (10:V) 13) → ¬(G.dist (5:V) 10 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 5 13 10 (by decide) h0 h1 h2.symm)

private theorem sat_125 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 5, .neg 9, .pos 15, .pos 64] := by
  change (G.Adj (4:V) 5) → (G.Adj (4:V) 11) → ¬(G.Adj (5:V) 11) → ¬(G.dist (5:V) 11 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 5 4 11 (by decide) h2 h0.symm h1)

private theorem sat_126 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 15, .neg 16, .neg 33, .pos 64] := by
  change ¬(G.Adj (5:V) 11) → (G.Adj (5:V) 12) → (G.Adj (11:V) 12) → ¬(G.dist (5:V) 11 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 5 12 11 (by decide) h0 h1 h2.symm)

private theorem sat_127 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 5, .neg 10, .pos 16, .pos 65] := by
  change (G.Adj (4:V) 5) → (G.Adj (4:V) 12) → ¬(G.Adj (5:V) 12) → ¬(G.dist (5:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 5 4 12 (by decide) h2 h0.symm h1)

private theorem sat_128 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 13, .pos 17, .neg 20, .pos 66] := by
  change (G.Adj (5:V) 7) → ¬(G.Adj (5:V) 13) → (G.Adj (7:V) 13) → ¬(G.dist (5:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 5 7 13 (by decide) h1 h0 h2)

private theorem sat_129 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 14, .pos 17, .neg 32, .pos 66] := by
  change (G.Adj (5:V) 10) → ¬(G.Adj (5:V) 13) → (G.Adj (10:V) 13) → ¬(G.dist (5:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 5 10 13 (by decide) h1 h0 h2)

private theorem sat_130 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 16, .pos 17, .neg 35, .pos 66] := by
  change (G.Adj (5:V) 12) → ¬(G.Adj (5:V) 13) → (G.Adj (12:V) 13) → ¬(G.dist (5:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 5 12 13 (by decide) h1 h0 h2)

private theorem sat_131 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 67] := by
  change ¬(G.dist (2:V) 6 = 2) → False
  intro h0
  exact h0 (by rw [dist_comm]; exact distance_two_from_two_edges H 6 0 2 (by decide) (H.forbidden 6 2 (by decide)) (H.fixed 6 0 (by decide)) (H.fixed 0 2 (by decide)))

private theorem sat_132 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 18, .pos 68] := by
  change ¬(G.Adj (6:V) 7) → ¬(G.dist (6:V) 7 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 6 0 7 (by decide) h0 (H.fixed 6 0 (by decide)) (H.fixed 0 7 (by decide)))

private theorem sat_133 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 18, .pos 68] := by
  change ¬(G.Adj (6:V) 7) → ¬(G.dist (6:V) 7 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 6 1 7 (by decide) h0 (H.fixed 6 1 (by decide)) (H.fixed 1 7 (by decide)))

private theorem sat_134 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 2, .pos 69] := by
  change (G.Adj (3:V) 6) → ¬(G.dist (6:V) 8 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 6 3 8 (by decide) (H.forbidden 6 8 (by decide)) h0.symm (H.fixed 3 8 (by decide)))

private theorem sat_135 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 2, .pos 70] := by
  change (G.Adj (3:V) 6) → ¬(G.dist (6:V) 9 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 6 3 9 (by decide) (H.forbidden 6 9 (by decide)) h0.symm (H.fixed 3 9 (by decide)))

private theorem sat_136 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 19, .neg 29, .pos 70] := by
  change (G.Adj (6:V) 13) → (G.Adj (9:V) 13) → ¬(G.dist (6:V) 9 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 6 13 9 (by decide) (H.forbidden 6 9 (by decide)) h0 h1.symm)

private theorem sat_137 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 6, .neg 8, .pos 71] := by
  change (G.Adj (4:V) 6) → (G.Adj (4:V) 10) → ¬(G.dist (6:V) 10 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 6 4 10 (by decide) (H.forbidden 6 10 (by decide)) h0.symm h1)

private theorem sat_138 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 12, .neg 14, .pos 71] := by
  change (G.Adj (5:V) 6) → (G.Adj (5:V) 10) → ¬(G.dist (6:V) 10 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 6 5 10 (by decide) (H.forbidden 6 10 (by decide)) h0.symm h1)

private theorem sat_139 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 6, .neg 9, .pos 72] := by
  change (G.Adj (4:V) 6) → (G.Adj (4:V) 11) → ¬(G.dist (6:V) 11 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 6 4 11 (by decide) (H.forbidden 6 11 (by decide)) h0.symm h1)

private theorem sat_140 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 12, .neg 15, .pos 72] := by
  change (G.Adj (5:V) 6) → (G.Adj (5:V) 11) → ¬(G.dist (6:V) 11 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 6 5 11 (by decide) (H.forbidden 6 11 (by decide)) h0.symm h1)

private theorem sat_141 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 6, .neg 10, .pos 73] := by
  change (G.Adj (4:V) 6) → (G.Adj (4:V) 12) → ¬(G.dist (6:V) 12 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 6 4 12 (by decide) (H.forbidden 6 12 (by decide)) h0.symm h1)

private theorem sat_142 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 12, .neg 16, .pos 73] := by
  change (G.Adj (5:V) 6) → (G.Adj (5:V) 12) → ¬(G.dist (6:V) 12 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 6 5 12 (by decide) (H.forbidden 6 12 (by decide)) h0.symm h1)

private theorem sat_143 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 6, .neg 11, .pos 19, .pos 74] := by
  change (G.Adj (4:V) 6) → (G.Adj (4:V) 13) → ¬(G.Adj (6:V) 13) → ¬(G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 6 4 13 (by decide) h2 h0.symm h1)

private theorem sat_144 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 18, .pos 19, .neg 20, .pos 74] := by
  change (G.Adj (6:V) 7) → ¬(G.Adj (6:V) 13) → (G.Adj (7:V) 13) → ¬(G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 6 7 13 (by decide) h1 h0 h2)

private theorem sat_145 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.pos 75] := by
  change ¬(G.dist (2:V) 7 = 2) → False
  intro h0
  exact h0 (by rw [dist_comm]; exact distance_two_from_two_edges H 7 0 2 (by decide) (H.forbidden 7 2 (by decide)) (H.fixed 7 0 (by decide)) (H.fixed 0 2 (by decide)))

private theorem sat_146 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 3, .pos 76] := by
  change (G.Adj (3:V) 7) → ¬(G.dist (7:V) 8 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 7 3 8 (by decide) (H.forbidden 7 8 (by decide)) h0.symm (H.fixed 3 8 (by decide)))

private theorem sat_147 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 20, .neg 25, .pos 76] := by
  change (G.Adj (7:V) 13) → (G.Adj (8:V) 13) → ¬(G.dist (7:V) 8 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 7 13 8 (by decide) (H.forbidden 7 8 (by decide)) h0 h1.symm)

private theorem sat_148 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 3, .pos 77] := by
  change (G.Adj (3:V) 7) → ¬(G.dist (7:V) 9 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 7 3 9 (by decide) (H.forbidden 7 9 (by decide)) h0.symm (H.fixed 3 9 (by decide)))

private theorem sat_149 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 20, .neg 29, .pos 77] := by
  change (G.Adj (7:V) 13) → (G.Adj (9:V) 13) → ¬(G.dist (7:V) 9 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 7 13 9 (by decide) (H.forbidden 7 9 (by decide)) h0 h1.symm)

private theorem sat_150 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 7, .neg 8, .pos 78] := by
  change (G.Adj (4:V) 7) → (G.Adj (4:V) 10) → ¬(G.dist (7:V) 10 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 7 4 10 (by decide) (H.forbidden 7 10 (by decide)) h0.symm h1)

private theorem sat_151 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 13, .neg 14, .pos 78] := by
  change (G.Adj (5:V) 7) → (G.Adj (5:V) 10) → ¬(G.dist (7:V) 10 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 7 5 10 (by decide) (H.forbidden 7 10 (by decide)) h0.symm h1)

private theorem sat_152 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 20, .neg 32, .pos 78] := by
  change (G.Adj (7:V) 13) → (G.Adj (10:V) 13) → ¬(G.dist (7:V) 10 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 7 13 10 (by decide) (H.forbidden 7 10 (by decide)) h0 h1.symm)

private theorem sat_153 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 7, .neg 9, .pos 79] := by
  change (G.Adj (4:V) 7) → (G.Adj (4:V) 11) → ¬(G.dist (7:V) 11 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 7 4 11 (by decide) (H.forbidden 7 11 (by decide)) h0.symm h1)

private theorem sat_154 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 13, .neg 15, .pos 79] := by
  change (G.Adj (5:V) 7) → (G.Adj (5:V) 11) → ¬(G.dist (7:V) 11 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 7 5 11 (by decide) (H.forbidden 7 11 (by decide)) h0.symm h1)

private theorem sat_155 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 20, .neg 34, .pos 79] := by
  change (G.Adj (7:V) 13) → (G.Adj (11:V) 13) → ¬(G.dist (7:V) 11 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 7 13 11 (by decide) (H.forbidden 7 11 (by decide)) h0 h1.symm)

private theorem sat_156 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 7, .neg 10, .pos 80] := by
  change (G.Adj (4:V) 7) → (G.Adj (4:V) 12) → ¬(G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 7 4 12 (by decide) (H.forbidden 7 12 (by decide)) h0.symm h1)

private theorem sat_157 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 13, .neg 16, .pos 80] := by
  change (G.Adj (5:V) 7) → (G.Adj (5:V) 12) → ¬(G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 7 5 12 (by decide) (H.forbidden 7 12 (by decide)) h0.symm h1)

private theorem sat_158 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 20, .neg 35, .pos 80] := by
  change (G.Adj (7:V) 13) → (G.Adj (12:V) 13) → ¬(G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 7 13 12 (by decide) (H.forbidden 7 12 (by decide)) h0 h1.symm)

private theorem sat_159 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 3, .neg 4, .pos 20, .pos 81] := by
  change (G.Adj (3:V) 7) → (G.Adj (3:V) 13) → ¬(G.Adj (7:V) 13) → ¬(G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 7 3 13 (by decide) h2 h0.symm h1)

private theorem sat_160 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 7, .neg 11, .pos 20, .pos 81] := by
  change (G.Adj (4:V) 7) → (G.Adj (4:V) 13) → ¬(G.Adj (7:V) 13) → ¬(G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 7 4 13 (by decide) h2 h0.symm h1)

private theorem sat_161 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 13, .neg 17, .pos 20, .pos 81] := by
  change (G.Adj (5:V) 7) → (G.Adj (5:V) 13) → ¬(G.Adj (7:V) 13) → ¬(G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 7 5 13 (by decide) h2 h0.symm h1)

private theorem sat_162 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 18, .neg 19, .pos 20, .pos 81] := by
  change (G.Adj (6:V) 7) → (G.Adj (6:V) 13) → ¬(G.Adj (7:V) 13) → ¬(G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 7 6 13 (by decide) h2 h0.symm h1)

private theorem sat_163 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 36, .neg 37, .neg 39, .neg 42, .neg 43, .neg 44] := by
  change (G.dist (1:V) 3 = 2) → (G.dist (2:V) 3 = 2) → (G.dist (3:V) 5 = 2) → (G.dist (3:V) 10 = 2) → (G.dist (3:V) 11 = 2) → (G.dist (3:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 3 ({1,2,5,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_164 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 36, .neg 37, .neg 40, .neg 42, .neg 43, .neg 44] := by
  change (G.dist (1:V) 3 = 2) → (G.dist (2:V) 3 = 2) → (G.dist (3:V) 6 = 2) → (G.dist (3:V) 10 = 2) → (G.dist (3:V) 11 = 2) → (G.dist (3:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 3 ({1,2,6,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_165 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 36, .neg 37, .neg 41, .neg 42, .neg 43, .neg 44] := by
  change (G.dist (1:V) 3 = 2) → (G.dist (2:V) 3 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (3:V) 10 = 2) → (G.dist (3:V) 11 = 2) → (G.dist (3:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 3 ({1,2,7,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_166 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 38, .neg 46, .neg 47, .neg 48, .neg 51, .neg 53] := by
  change (G.dist (3:V) 4 = 2) → (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 10 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({3,0,2,5,8,10} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_167 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 38, .neg 46, .neg 47, .neg 48, .neg 51, .neg 55] := by
  change (G.dist (3:V) 4 = 2) → (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({3,0,2,5,8,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_168 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 38, .neg 46, .neg 47, .neg 48, .neg 53, .neg 54] := by
  change (G.dist (3:V) 4 = 2) → (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (4:V) 10 = 2) → (G.dist (4:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({3,0,2,5,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_169 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 38, .neg 46, .neg 47, .neg 48, .neg 53, .neg 55] := by
  change (G.dist (3:V) 4 = 2) → (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (4:V) 10 = 2) → (G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({3,0,2,5,10,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_170 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 38, .neg 46, .neg 47, .neg 48, .neg 54, .neg 55] := by
  change (G.dist (3:V) 4 = 2) → (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (4:V) 11 = 2) → (G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({3,0,2,5,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_171 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 38, .neg 46, .neg 47, .neg 51, .neg 53, .neg 54] := by
  change (G.dist (3:V) 4 = 2) → (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 10 = 2) → (G.dist (4:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({3,0,2,8,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_172 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 38, .neg 46, .neg 47, .neg 51, .neg 53, .neg 55] := by
  change (G.dist (3:V) 4 = 2) → (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 10 = 2) → (G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({3,0,2,8,10,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_173 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 38, .neg 46, .neg 47, .neg 51, .neg 54, .neg 55] := by
  change (G.dist (3:V) 4 = 2) → (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 11 = 2) → (G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({3,0,2,8,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_174 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 38, .neg 46, .neg 47, .neg 52, .neg 53, .neg 54] := by
  change (G.dist (3:V) 4 = 2) → (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (4:V) 10 = 2) → (G.dist (4:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({3,0,2,9,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_175 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 38, .neg 46, .neg 47, .neg 52, .neg 53, .neg 55] := by
  change (G.dist (3:V) 4 = 2) → (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (4:V) 10 = 2) → (G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({3,0,2,9,10,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_176 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 38, .neg 46, .neg 47, .neg 52, .neg 54, .neg 55] := by
  change (G.dist (3:V) 4 = 2) → (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (4:V) 11 = 2) → (G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({3,0,2,9,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_177 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 38, .neg 46, .neg 47, .neg 53, .neg 54, .neg 55] := by
  change (G.dist (3:V) 4 = 2) → (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 10 = 2) → (G.dist (4:V) 11 = 2) → (G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({3,0,2,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_178 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 38, .neg 46, .neg 47, .neg 53, .neg 54, .neg 56] := by
  change (G.dist (3:V) 4 = 2) → (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 10 = 2) → (G.dist (4:V) 11 = 2) → (G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({3,0,2,10,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_179 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 38, .neg 46, .neg 47, .neg 53, .neg 55, .neg 56] := by
  change (G.dist (3:V) 4 = 2) → (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 10 = 2) → (G.dist (4:V) 12 = 2) → (G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({3,0,2,10,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_180 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 38, .neg 46, .neg 47, .neg 54, .neg 55, .neg 56] := by
  change (G.dist (3:V) 4 = 2) → (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 11 = 2) → (G.dist (4:V) 12 = 2) → (G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({3,0,2,11,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_181 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 46, .neg 47, .neg 48, .neg 50, .neg 51, .neg 52] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,5,7,8,9} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_182 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 46, .neg 47, .neg 48, .neg 50, .neg 51, .neg 53] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 10 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,5,7,8,10} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_183 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 46, .neg 47, .neg 48, .neg 50, .neg 51, .neg 55] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,5,7,8,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_184 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 46, .neg 47, .neg 48, .neg 50, .neg 53, .neg 55] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (4:V) 10 = 2) → (G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,5,7,10,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_185 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 46, .neg 47, .neg 48, .neg 51, .neg 52, .neg 53] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (4:V) 10 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,5,8,9,10} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_186 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 46, .neg 47, .neg 48, .neg 51, .neg 52, .neg 54] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (4:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,5,8,9,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_187 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 46, .neg 47, .neg 48, .neg 51, .neg 52, .neg 55] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,5,8,9,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_188 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 46, .neg 47, .neg 48, .neg 51, .neg 52, .neg 56] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,5,8,9,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_189 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 46, .neg 47, .neg 48, .neg 51, .neg 53, .neg 55] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 10 = 2) → (G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,5,8,10,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_190 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 46, .neg 47, .neg 49, .neg 50, .neg 51, .neg 52] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,6,7,8,9} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_191 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 46, .neg 47, .neg 50, .neg 51, .neg 52, .neg 53] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (4:V) 10 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,7,8,9,10} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_192 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 46, .neg 47, .neg 50, .neg 51, .neg 52, .neg 54] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (4:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,7,8,9,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_193 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 46, .neg 47, .neg 50, .neg 51, .neg 52, .neg 55] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,7,8,9,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_194 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 46, .neg 47, .neg 50, .neg 51, .neg 54, .neg 55] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 11 = 2) → (G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,7,8,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_195 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 46, .neg 47, .neg 50, .neg 52, .neg 54, .neg 55] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (4:V) 11 = 2) → (G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,7,9,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_196 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 46, .neg 47, .neg 51, .neg 52, .neg 53, .neg 54] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (4:V) 10 = 2) → (G.dist (4:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,8,9,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_197 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 46, .neg 47, .neg 51, .neg 52, .neg 53, .neg 55] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (4:V) 10 = 2) → (G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,8,9,10,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_198 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 46, .neg 47, .neg 51, .neg 52, .neg 54, .neg 55] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (4:V) 11 = 2) → (G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,8,9,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_199 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 46, .neg 47, .neg 51, .neg 53, .neg 54, .neg 55] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 10 = 2) → (G.dist (4:V) 11 = 2) → (G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,8,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_200 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 46, .neg 47, .neg 53, .neg 54, .neg 55, .neg 56] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 10 = 2) → (G.dist (4:V) 11 = 2) → (G.dist (4:V) 12 = 2) → (G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,10,11,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_201 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 39, .neg 57, .neg 58, .neg 63, .neg 64, .neg 65] := by
  change (G.dist (3:V) 5 = 2) → (G.dist (0:V) 5 = 2) → (G.dist (2:V) 5 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (5:V) 11 = 2) → (G.dist (5:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({3,0,2,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_202 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 48, .neg 57, .neg 58, .neg 59, .neg 61, .neg 62] := by
  change (G.dist (4:V) 5 = 2) → (G.dist (0:V) 5 = 2) → (G.dist (2:V) 5 = 2) → (G.dist (5:V) 6 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (5:V) 9 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({4,0,2,6,8,9} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_203 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 48, .neg 57, .neg 58, .neg 60, .neg 61, .neg 62] := by
  change (G.dist (4:V) 5 = 2) → (G.dist (0:V) 5 = 2) → (G.dist (2:V) 5 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (5:V) 9 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({4,0,2,7,8,9} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_204 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 48, .neg 57, .neg 58, .neg 61, .neg 62, .neg 63] := by
  change (G.dist (4:V) 5 = 2) → (G.dist (0:V) 5 = 2) → (G.dist (2:V) 5 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (5:V) 10 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({4,0,2,8,9,10} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_205 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 48, .neg 57, .neg 58, .neg 61, .neg 62, .neg 66] := by
  change (G.dist (4:V) 5 = 2) → (G.dist (0:V) 5 = 2) → (G.dist (2:V) 5 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (5:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({4,0,2,8,9,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_206 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 57, .neg 58, .neg 59, .neg 60, .neg 61, .neg 62] := by
  change (G.dist (0:V) 5 = 2) → (G.dist (2:V) 5 = 2) → (G.dist (5:V) 6 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (5:V) 9 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({0,2,6,7,8,9} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_207 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 57, .neg 58, .neg 60, .neg 61, .neg 62, .neg 63] := by
  change (G.dist (0:V) 5 = 2) → (G.dist (2:V) 5 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (5:V) 10 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({0,2,7,8,9,10} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_208 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 57, .neg 58, .neg 61, .neg 62, .neg 63, .neg 64] := by
  change (G.dist (0:V) 5 = 2) → (G.dist (2:V) 5 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (5:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({0,2,8,9,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_209 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 57, .neg 58, .neg 61, .neg 63, .neg 64, .neg 65] := by
  change (G.dist (0:V) 5 = 2) → (G.dist (2:V) 5 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (5:V) 11 = 2) → (G.dist (5:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({0,2,8,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_210 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 57, .neg 58, .neg 62, .neg 63, .neg 64, .neg 65] := by
  change (G.dist (0:V) 5 = 2) → (G.dist (2:V) 5 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (5:V) 11 = 2) → (G.dist (5:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({0,2,9,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_211 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 57, .neg 58, .neg 63, .neg 64, .neg 65, .neg 66] := by
  change (G.dist (0:V) 5 = 2) → (G.dist (2:V) 5 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (5:V) 11 = 2) → (G.dist (5:V) 12 = 2) → (G.dist (5:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({0,2,10,11,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_212 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 40, .neg 67, .neg 70, .neg 71, .neg 72, .neg 73] := by
  change (G.dist (3:V) 6 = 2) → (G.dist (2:V) 6 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (6:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({3,2,9,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_213 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 40, .neg 67, .neg 71, .neg 72, .neg 73, .neg 74] := by
  change (G.dist (3:V) 6 = 2) → (G.dist (2:V) 6 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (6:V) 12 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({3,2,10,11,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_214 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 67, .neg 69, .neg 70, .neg 71, .neg 72, .neg 73] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (6:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,8,9,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact h1
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_215 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 67, .neg 69, .neg 70, .neg 72, .neg 73, .neg 74] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (6:V) 12 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,8,9,11,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact h1
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_216 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 67, .neg 69, .neg 71, .neg 72, .neg 73, .neg 74] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (6:V) 12 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,8,10,11,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact h1
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_217 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 41, .neg 50, .neg 75, .neg 76, .neg 77, .neg 78] := by
  change (G.dist (3:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({3,4,2,8,9,10} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_218 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 41, .neg 50, .neg 75, .neg 76, .neg 77, .neg 79] := by
  change (G.dist (3:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({3,4,2,8,9,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_219 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 41, .neg 50, .neg 75, .neg 76, .neg 77, .neg 80] := by
  change (G.dist (3:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({3,4,2,8,9,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_220 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 41, .neg 50, .neg 75, .neg 77, .neg 78, .neg 81] := by
  change (G.dist (3:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({3,4,2,9,10,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_221 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 41, .neg 50, .neg 75, .neg 77, .neg 79, .neg 80] := by
  change (G.dist (3:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({3,4,2,9,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_222 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 41, .neg 50, .neg 75, .neg 77, .neg 79, .neg 81] := by
  change (G.dist (3:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({3,4,2,9,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_223 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 41, .neg 50, .neg 75, .neg 77, .neg 80, .neg 81] := by
  change (G.dist (3:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 12 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({3,4,2,9,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_224 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 41, .neg 50, .neg 75, .neg 79, .neg 80, .neg 81] := by
  change (G.dist (3:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 12 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({3,4,2,11,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_225 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 41, .neg 60, .neg 75, .neg 76, .neg 77, .neg 78] := by
  change (G.dist (3:V) 7 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({3,5,2,8,9,10} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_226 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 41, .neg 60, .neg 75, .neg 76, .neg 77, .neg 79] := by
  change (G.dist (3:V) 7 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({3,5,2,8,9,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_227 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 41, .neg 60, .neg 75, .neg 76, .neg 77, .neg 80] := by
  change (G.dist (3:V) 7 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({3,5,2,8,9,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_228 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 41, .neg 60, .neg 75, .neg 76, .neg 77, .neg 81] := by
  change (G.dist (3:V) 7 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({3,5,2,8,9,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_229 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 41, .neg 60, .neg 75, .neg 77, .neg 78, .neg 80] := by
  change (G.dist (3:V) 7 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({3,5,2,9,10,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_230 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 41, .neg 60, .neg 75, .neg 77, .neg 80, .neg 81] := by
  change (G.dist (3:V) 7 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 12 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({3,5,2,9,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_231 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 41, .neg 60, .neg 75, .neg 79, .neg 80, .neg 81] := by
  change (G.dist (3:V) 7 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 12 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({3,5,2,11,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_232 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 41, .neg 75, .neg 76, .neg 77, .neg 78, .neg 79] := by
  change (G.dist (3:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({3,2,8,9,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_233 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 41, .neg 75, .neg 76, .neg 77, .neg 78, .neg 80] := by
  change (G.dist (3:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({3,2,8,9,10,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_234 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 41, .neg 75, .neg 77, .neg 78, .neg 79, .neg 80] := by
  change (G.dist (3:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({3,2,9,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_235 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 41, .neg 75, .neg 77, .neg 78, .neg 80, .neg 81] := by
  change (G.dist (3:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 12 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({3,2,9,10,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_236 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 41, .neg 75, .neg 78, .neg 79, .neg 80, .neg 81] := by
  change (G.dist (3:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 12 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({3,2,10,11,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_237 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 50, .neg 60, .neg 75, .neg 76, .neg 77, .neg 78] := by
  change (G.dist (4:V) 7 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({4,5,2,8,9,10} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_238 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 50, .neg 60, .neg 75, .neg 76, .neg 77, .neg 79] := by
  change (G.dist (4:V) 7 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({4,5,2,8,9,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_239 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 50, .neg 60, .neg 75, .neg 76, .neg 77, .neg 80] := by
  change (G.dist (4:V) 7 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({4,5,2,8,9,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_240 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 50, .neg 60, .neg 75, .neg 76, .neg 77, .neg 81] := by
  change (G.dist (4:V) 7 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({4,5,2,8,9,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_241 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 50, .neg 68, .neg 75, .neg 76, .neg 77, .neg 78] := by
  change (G.dist (4:V) 7 = 2) → (G.dist (6:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({4,6,2,8,9,10} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_242 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 50, .neg 68, .neg 75, .neg 76, .neg 77, .neg 79] := by
  change (G.dist (4:V) 7 = 2) → (G.dist (6:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({4,6,2,8,9,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_243 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 50, .neg 68, .neg 75, .neg 76, .neg 77, .neg 80] := by
  change (G.dist (4:V) 7 = 2) → (G.dist (6:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({4,6,2,8,9,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_244 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 50, .neg 75, .neg 76, .neg 77, .neg 78, .neg 79] := by
  change (G.dist (4:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({4,2,8,9,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_245 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 50, .neg 75, .neg 76, .neg 77, .neg 78, .neg 80] := by
  change (G.dist (4:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({4,2,8,9,10,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_246 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 50, .neg 75, .neg 76, .neg 77, .neg 78, .neg 81] := by
  change (G.dist (4:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({4,2,8,9,10,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_247 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 50, .neg 75, .neg 76, .neg 77, .neg 79, .neg 80] := by
  change (G.dist (4:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({4,2,8,9,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_248 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 50, .neg 75, .neg 76, .neg 77, .neg 79, .neg 81] := by
  change (G.dist (4:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({4,2,8,9,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_249 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 50, .neg 75, .neg 76, .neg 77, .neg 80, .neg 81] := by
  change (G.dist (4:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 12 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({4,2,8,9,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_250 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 60, .neg 68, .neg 75, .neg 76, .neg 77, .neg 81] := by
  change (G.dist (5:V) 7 = 2) → (G.dist (6:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({5,6,2,8,9,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_251 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 60, .neg 75, .neg 76, .neg 77, .neg 78, .neg 79] := by
  change (G.dist (5:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({5,2,8,9,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_252 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 60, .neg 75, .neg 76, .neg 77, .neg 78, .neg 80] := by
  change (G.dist (5:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({5,2,8,9,10,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_253 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 60, .neg 75, .neg 76, .neg 77, .neg 78, .neg 81] := by
  change (G.dist (5:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({5,2,8,9,10,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_254 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 60, .neg 75, .neg 76, .neg 77, .neg 79, .neg 80] := by
  change (G.dist (5:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({5,2,8,9,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_255 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 60, .neg 75, .neg 76, .neg 77, .neg 79, .neg 81] := by
  change (G.dist (5:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({5,2,8,9,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_256 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 60, .neg 75, .neg 76, .neg 77, .neg 80, .neg 81] := by
  change (G.dist (5:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 12 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({5,2,8,9,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_257 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 68, .neg 75, .neg 76, .neg 77, .neg 78, .neg 80] := by
  change (G.dist (6:V) 7 = 2) → (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({6,2,8,9,10,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_258 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 75, .neg 76, .neg 77, .neg 78, .neg 79, .neg 80] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,8,9,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact h1
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_259 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 75, .neg 76, .neg 77, .neg 78, .neg 80, .neg 81] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 12 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,8,9,10,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact h1
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_260 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 75, .neg 76, .neg 77, .neg 79, .neg 80, .neg 81] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 12 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,8,9,11,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact h1
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_261 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 75, .neg 77, .neg 78, .neg 79, .neg 80, .neg 81] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 12 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,9,10,11,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact h1
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_262 (H : Geometry G) (bad : ¬Shape G) : (val G).satisfies [.neg 3, .neg 19, .neg 20, .pos 32, .pos 34, .pos 35] := by
  change (G.Adj (3:V) 7) → (G.Adj (6:V) 13) → (G.Adj (7:V) 13) → ¬(G.Adj (10:V) 13) → ¬(G.Adj (11:V) 13) → ¬(G.Adj (12:V) 13) → False
  intro h0 h1 h2 h3 h4 h5
  apply bad
  exact ⟨h1,h2,h0,h3,h4,h5⟩

theorem normalized_route_geometry (H : Geometry G) : Shape G := by
  apply Classical.byContradiction
  intro bad
  have hf : (val G).satisfies_fmla ec1_bridge.formula :=
    (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_0 H bad)) (fmla_one _ _ (sat_1 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_2 H bad)) (fmla_one _ _ (sat_3 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_4 H bad)) (fmla_one _ _ (sat_5 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_6 H bad)) (fmla_one _ _ (sat_7 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_8 H bad)) (fmla_one _ _ (sat_9 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_10 H bad)) (fmla_one _ _ (sat_11 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_12 H bad)) (fmla_one _ _ (sat_13 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_14 H bad)) (fmla_one _ _ (sat_15 H bad)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_16 H bad)) (fmla_one _ _ (sat_17 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_18 H bad)) (fmla_one _ _ (sat_19 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_20 H bad)) (fmla_one _ _ (sat_21 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_22 H bad)) (fmla_one _ _ (sat_23 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_24 H bad)) (fmla_one _ _ (sat_25 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_26 H bad)) (fmla_one _ _ (sat_27 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_28 H bad)) (fmla_one _ _ (sat_29 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_30 H bad)) (fmla_one _ _ (sat_31 H bad))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_32 H bad)) (fmla_one _ _ (sat_33 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_34 H bad)) (fmla_one _ _ (sat_35 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_36 H bad)) (fmla_one _ _ (sat_37 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_38 H bad)) (fmla_one _ _ (sat_39 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_40 H bad)) (fmla_one _ _ (sat_41 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_42 H bad)) (fmla_one _ _ (sat_43 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_44 H bad)) (fmla_one _ _ (sat_45 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_46 H bad)) (fmla_one _ _ (sat_47 H bad)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_48 H bad)) (fmla_one _ _ (sat_49 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_50 H bad)) (fmla_one _ _ (sat_51 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_52 H bad)) (fmla_one _ _ (sat_53 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_54 H bad)) (fmla_one _ _ (sat_55 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_56 H bad)) (fmla_one _ _ (sat_57 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_58 H bad)) (fmla_one _ _ (sat_59 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_60 H bad)) (fmla_one _ _ (sat_61 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_62 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_63 H bad)) (fmla_one _ _ (sat_64 H bad))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_65 H bad)) (fmla_one _ _ (sat_66 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_67 H bad)) (fmla_one _ _ (sat_68 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_69 H bad)) (fmla_one _ _ (sat_70 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_71 H bad)) (fmla_one _ _ (sat_72 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_73 H bad)) (fmla_one _ _ (sat_74 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_75 H bad)) (fmla_one _ _ (sat_76 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_77 H bad)) (fmla_one _ _ (sat_78 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_79 H bad)) (fmla_one _ _ (sat_80 H bad)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_81 H bad)) (fmla_one _ _ (sat_82 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_83 H bad)) (fmla_one _ _ (sat_84 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_85 H bad)) (fmla_one _ _ (sat_86 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_87 H bad)) (fmla_one _ _ (sat_88 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_89 H bad)) (fmla_one _ _ (sat_90 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_91 H bad)) (fmla_one _ _ (sat_92 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_93 H bad)) (fmla_one _ _ (sat_94 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_95 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_96 H bad)) (fmla_one _ _ (sat_97 H bad)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_98 H bad)) (fmla_one _ _ (sat_99 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_100 H bad)) (fmla_one _ _ (sat_101 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_102 H bad)) (fmla_one _ _ (sat_103 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_104 H bad)) (fmla_one _ _ (sat_105 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_106 H bad)) (fmla_one _ _ (sat_107 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_108 H bad)) (fmla_one _ _ (sat_109 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_110 H bad)) (fmla_one _ _ (sat_111 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_112 H bad)) (fmla_one _ _ (sat_113 H bad)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_114 H bad)) (fmla_one _ _ (sat_115 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_116 H bad)) (fmla_one _ _ (sat_117 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_118 H bad)) (fmla_one _ _ (sat_119 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_120 H bad)) (fmla_one _ _ (sat_121 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_122 H bad)) (fmla_one _ _ (sat_123 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_124 H bad)) (fmla_one _ _ (sat_125 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_126 H bad)) (fmla_one _ _ (sat_127 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_128 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_129 H bad)) (fmla_one _ _ (sat_130 H bad)))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_131 H bad)) (fmla_one _ _ (sat_132 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_133 H bad)) (fmla_one _ _ (sat_134 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_135 H bad)) (fmla_one _ _ (sat_136 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_137 H bad)) (fmla_one _ _ (sat_138 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_139 H bad)) (fmla_one _ _ (sat_140 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_141 H bad)) (fmla_one _ _ (sat_142 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_143 H bad)) (fmla_one _ _ (sat_144 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_145 H bad)) (fmla_one _ _ (sat_146 H bad)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_147 H bad)) (fmla_one _ _ (sat_148 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_149 H bad)) (fmla_one _ _ (sat_150 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_151 H bad)) (fmla_one _ _ (sat_152 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_153 H bad)) (fmla_one _ _ (sat_154 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_155 H bad)) (fmla_one _ _ (sat_156 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_157 H bad)) (fmla_one _ _ (sat_158 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_159 H bad)) (fmla_one _ _ (sat_160 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_161 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_162 H bad)) (fmla_one _ _ (sat_163 H bad)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_164 H bad)) (fmla_one _ _ (sat_165 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_166 H bad)) (fmla_one _ _ (sat_167 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_168 H bad)) (fmla_one _ _ (sat_169 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_170 H bad)) (fmla_one _ _ (sat_171 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_172 H bad)) (fmla_one _ _ (sat_173 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_174 H bad)) (fmla_one _ _ (sat_175 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_176 H bad)) (fmla_one _ _ (sat_177 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_178 H bad)) (fmla_one _ _ (sat_179 H bad)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_180 H bad)) (fmla_one _ _ (sat_181 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_182 H bad)) (fmla_one _ _ (sat_183 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_184 H bad)) (fmla_one _ _ (sat_185 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_186 H bad)) (fmla_one _ _ (sat_187 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_188 H bad)) (fmla_one _ _ (sat_189 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_190 H bad)) (fmla_one _ _ (sat_191 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_192 H bad)) (fmla_one _ _ (sat_193 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_194 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_195 H bad)) (fmla_one _ _ (sat_196 H bad))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_197 H bad)) (fmla_one _ _ (sat_198 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_199 H bad)) (fmla_one _ _ (sat_200 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_201 H bad)) (fmla_one _ _ (sat_202 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_203 H bad)) (fmla_one _ _ (sat_204 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_205 H bad)) (fmla_one _ _ (sat_206 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_207 H bad)) (fmla_one _ _ (sat_208 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_209 H bad)) (fmla_one _ _ (sat_210 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_211 H bad)) (fmla_one _ _ (sat_212 H bad)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_213 H bad)) (fmla_one _ _ (sat_214 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_215 H bad)) (fmla_one _ _ (sat_216 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_217 H bad)) (fmla_one _ _ (sat_218 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_219 H bad)) (fmla_one _ _ (sat_220 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_221 H bad)) (fmla_one _ _ (sat_222 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_223 H bad)) (fmla_one _ _ (sat_224 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_225 H bad)) (fmla_one _ _ (sat_226 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_227 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_228 H bad)) (fmla_one _ _ (sat_229 H bad)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_230 H bad)) (fmla_one _ _ (sat_231 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_232 H bad)) (fmla_one _ _ (sat_233 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_234 H bad)) (fmla_one _ _ (sat_235 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_236 H bad)) (fmla_one _ _ (sat_237 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_238 H bad)) (fmla_one _ _ (sat_239 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_240 H bad)) (fmla_one _ _ (sat_241 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_242 H bad)) (fmla_one _ _ (sat_243 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_244 H bad)) (fmla_one _ _ (sat_245 H bad)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_246 H bad)) (fmla_one _ _ (sat_247 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_248 H bad)) (fmla_one _ _ (sat_249 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_250 H bad)) (fmla_one _ _ (sat_251 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_252 H bad)) (fmla_one _ _ (sat_253 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_254 H bad)) (fmla_one _ _ (sat_255 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_256 H bad)) (fmla_one _ _ (sat_257 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_258 H bad)) (fmla_one _ _ (sat_259 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_260 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_261 H bad)) (fmla_one _ _ (sat_262 H bad)))))))))))
  exact ec1_bridge (val G) hf

#print axioms normalized_route_geometry
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent.SingletonRUP.ec1
