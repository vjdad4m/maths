import AdjacentCutFiveFourteenRUPE189
import AdjacentCutFiveBound189
import DiversityElevenCircuitBits384b
import Mathlib.Tactic.FinCases

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent.SingletonRUP.ec2
open SimpleGraph Finset Sat
open private d2 mem_positive from AdjacentCutFiveBound189
open private positive_card from AdjacentCutFiveBound189
open Graffiti384b.DiversityEleven.PendantCircuit (fmla_and fmla_one)
set_option linter.unusedVariables false
set_option linter.unusedSectionVars false
set_option maxRecDepth 32768
set_option maxHeartbeats 100000000
abbrev V := Fin 14
variable {G : SimpleGraph V} [DecidableRel G.Adj]

def fixedMatrix (i j : V) : Bool :=
  match i.val,j.val with
  | 0, 1 | 1, 0 => true
  | 0, 2 | 2, 0 => true
  | 0, 3 | 3, 0 => true
  | 0, 5 | 5, 0 => true
  | 0, 6 | 6, 0 => true
  | 1, 2 | 2, 1 => true
  | 1, 4 | 4, 1 => true
  | 1, 5 | 5, 1 => true
  | 1, 6 | 6, 1 => true
  | 3, 7 | 7, 3 => true
  | 3, 8 | 8, 3 => true
  | 4, 9 | 9, 4 => true
  | 4, 10 | 10, 4 => true
  | _, _ => false

def allowedMatrix (i j : V) : Bool :=
  match i.val,j.val with
  | 0, 1 | 1, 0 => true
  | 0, 2 | 2, 0 => true
  | 0, 3 | 3, 0 => true
  | 0, 5 | 5, 0 => true
  | 0, 6 | 6, 0 => true
  | 1, 2 | 2, 1 => true
  | 1, 4 | 4, 1 => true
  | 1, 5 | 5, 1 => true
  | 1, 6 | 6, 1 => true
  | 3, 4 | 4, 3 => true
  | 3, 5 | 5, 3 => true
  | 3, 6 | 6, 3 => true
  | 3, 7 | 7, 3 => true
  | 3, 8 | 8, 3 => true
  | 3, 11 | 11, 3 => true
  | 3, 12 | 12, 3 => true
  | 4, 5 | 5, 4 => true
  | 4, 6 | 6, 4 => true
  | 4, 9 | 9, 4 => true
  | 4, 10 | 10, 4 => true
  | 4, 11 | 11, 4 => true
  | 4, 12 | 12, 4 => true
  | 5, 6 | 6, 5 => true
  | 5, 11 | 11, 5 => true
  | 5, 12 | 12, 5 => true
  | 6, 11 | 11, 6 => true
  | 6, 12 | 12, 6 => true
  | 7, 8 | 8, 7 => true
  | 7, 9 | 9, 7 => true
  | 7, 10 | 10, 7 => true
  | 7, 11 | 11, 7 => true
  | 7, 12 | 12, 7 => true
  | 7, 13 | 13, 7 => true
  | 8, 9 | 9, 8 => true
  | 8, 10 | 10, 8 => true
  | 8, 11 | 11, 8 => true
  | 8, 12 | 12, 8 => true
  | 8, 13 | 13, 8 => true
  | 9, 10 | 10, 9 => true
  | 9, 11 | 11, 9 => true
  | 9, 12 | 12, 9 => true
  | 9, 13 | 13, 9 => true
  | 10, 11 | 11, 10 => true
  | 10, 12 | 12, 10 => true
  | 10, 13 | 13, 10 => true
  | 11, 12 | 12, 11 => true
  | 11, 13 | 13, 11 => true
  | 12, 13 | 13, 12 => true
  | _, _ => false

structure Geometry (G : SimpleGraph V) [DecidableRel G.Adj] : Prop where
  conn : G.Connected
  even : ∀ i, (EvenFrom G i).card≤6
  high : ∀ i : V, 3≤i.val → 5≤G.degree i
  fixed : ∀ i j, fixedMatrix i j = true → G.Adj i j
  forbidden : ∀ i j, allowedMatrix i j = false → ¬G.Adj i j
  nearA11 : G.Adj (5:V) 11 ∨ G.Adj (6:V) 11 ∨ G.Adj (3:V) 11
  nearA12 : G.Adj (5:V) 12 ∨ G.Adj (6:V) 12 ∨ G.Adj (3:V) 12
  nearB11 : G.Adj (5:V) 11 ∨ G.Adj (6:V) 11 ∨ G.Adj (4:V) 11
  nearB12 : G.Adj (5:V) 12 ∨ G.Adj (6:V) 12 ∨ G.Adj (4:V) 12

def val (G : SimpleGraph V) : Sat.Valuation := fun i =>
  match i with
  | 0 => G.Adj (3:V) 4
  | 1 => G.Adj (3:V) 5
  | 2 => G.Adj (3:V) 6
  | 3 => G.Adj (3:V) 11
  | 4 => G.Adj (3:V) 12
  | 5 => G.Adj (4:V) 5
  | 6 => G.Adj (4:V) 6
  | 7 => G.Adj (4:V) 11
  | 8 => G.Adj (4:V) 12
  | 9 => G.Adj (5:V) 6
  | 10 => G.Adj (5:V) 11
  | 11 => G.Adj (5:V) 12
  | 12 => G.Adj (6:V) 11
  | 13 => G.Adj (6:V) 12
  | 14 => G.Adj (7:V) 8
  | 15 => G.Adj (7:V) 9
  | 16 => G.Adj (7:V) 10
  | 17 => G.Adj (7:V) 11
  | 18 => G.Adj (7:V) 12
  | 19 => G.Adj (7:V) 13
  | 20 => G.Adj (8:V) 9
  | 21 => G.Adj (8:V) 10
  | 22 => G.Adj (8:V) 11
  | 23 => G.Adj (8:V) 12
  | 24 => G.Adj (8:V) 13
  | 25 => G.Adj (9:V) 10
  | 26 => G.Adj (9:V) 11
  | 27 => G.Adj (9:V) 12
  | 28 => G.Adj (9:V) 13
  | 29 => G.Adj (10:V) 11
  | 30 => G.Adj (10:V) 12
  | 31 => G.Adj (10:V) 13
  | 32 => G.Adj (11:V) 12
  | 33 => G.Adj (11:V) 13
  | 34 => G.Adj (12:V) 13
  | 35 => G.dist (1:V) 3 = 2
  | 36 => G.dist (2:V) 3 = 2
  | 37 => G.dist (3:V) 4 = 2
  | 38 => G.dist (3:V) 5 = 2
  | 39 => G.dist (3:V) 6 = 2
  | 40 => G.dist (3:V) 9 = 2
  | 41 => G.dist (3:V) 10 = 2
  | 42 => G.dist (3:V) 11 = 2
  | 43 => G.dist (3:V) 12 = 2
  | 44 => G.dist (3:V) 13 = 2
  | 45 => G.dist (0:V) 4 = 2
  | 46 => G.dist (2:V) 4 = 2
  | 47 => G.dist (4:V) 5 = 2
  | 48 => G.dist (4:V) 6 = 2
  | 49 => G.dist (4:V) 7 = 2
  | 50 => G.dist (4:V) 8 = 2
  | 51 => G.dist (4:V) 11 = 2
  | 52 => G.dist (4:V) 12 = 2
  | 53 => G.dist (4:V) 13 = 2
  | 54 => G.dist (2:V) 5 = 2
  | 55 => G.dist (5:V) 6 = 2
  | 56 => G.dist (5:V) 7 = 2
  | 57 => G.dist (5:V) 8 = 2
  | 58 => G.dist (5:V) 9 = 2
  | 59 => G.dist (5:V) 10 = 2
  | 60 => G.dist (5:V) 11 = 2
  | 61 => G.dist (5:V) 12 = 2
  | 62 => G.dist (5:V) 13 = 2
  | 63 => G.dist (2:V) 6 = 2
  | 64 => G.dist (6:V) 7 = 2
  | 65 => G.dist (6:V) 8 = 2
  | 66 => G.dist (6:V) 9 = 2
  | 67 => G.dist (6:V) 10 = 2
  | 68 => G.dist (6:V) 11 = 2
  | 69 => G.dist (6:V) 12 = 2
  | 70 => G.dist (6:V) 13 = 2
  | _ => False


private theorem degree_small_contra (H : Geometry G) (i : V) (hi : 3≤i.val)
    (S : Finset V) (small : S.card≤4) (not_edge : ∀ j, j∉S → ¬G.Adj i j) : False := by
  classical
  have sub : G.neighborFinset i ⊆ S := by
    intro j h
    apply Classical.byContradiction
    intro no
    exact not_edge j no ((mem_neighborFinset G i j).mp h)
  have cap := (card_le_card sub).trans small
  rw [card_neighborFinset_eq_degree] at cap
  have deg := H.high i hi
  omega

private theorem distance_two_from_two_edges (H : Geometry G) (i k j : V)
    (ne : i≠j) (no : ¬G.Adj i j) (u : G.Adj i k) (v : G.Adj k j) : G.dist i j=2 :=
  (mem_filter.mp (d2 H.conn ne no u v)).2

private theorem six_twos_contra (H : Geometry G) (i : V) (S : Finset V)
    (card6 : S.card=6) (off : i∉S) (all : ∀ j∈S, G.dist i j=2) : False := by
  classical
  have s : S⊆PositiveEven G i := by
    intro j jm
    exact mem_positive.mpr ⟨fun k=>off (k ▸ jm),by rw [all j jm]; decide⟩
  have count := (card_le_card s).trans (positive_card (H.even i))
  omega

private theorem sat_0 (H : Geometry G) : (val G).satisfies [.pos 0, .pos 2, .pos 3, .pos 4] := by
  change ¬(G.Adj (3:V) 4) → ¬(G.Adj (3:V) 6) → ¬(G.Adj (3:V) 11) → ¬(G.Adj (3:V) 12) → False
  intro h0 h1 h2 h3
  apply degree_small_contra H 3 (by decide) ({0,5,7,8} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (hj (by decide)).elim
  · exact (H.forbidden 3 1 (by decide))
  · exact (H.forbidden 3 2 (by decide))
  · exact (H.forbidden 3 3 (by decide))
  · exact h0
  · exact (hj (by decide)).elim
  · exact h1
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 3 9 (by decide))
  · exact (H.forbidden 3 10 (by decide))
  · exact h2
  · exact h3
  · exact (H.forbidden 3 13 (by decide))

private theorem sat_1 (H : Geometry G) : (val G).satisfies [.pos 0, .pos 6, .pos 7, .pos 8] := by
  change ¬(G.Adj (3:V) 4) → ¬(G.Adj (4:V) 6) → ¬(G.Adj (4:V) 11) → ¬(G.Adj (4:V) 12) → False
  intro h0 h1 h2 h3
  apply degree_small_contra H 4 (by decide) ({1,5,9,10} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 4 0 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 4 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 4 4 (by decide))
  · exact (hj (by decide)).elim
  · exact h1
  · exact (H.forbidden 4 7 (by decide))
  · exact (H.forbidden 4 8 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h2
  · exact h3
  · exact (H.forbidden 4 13 (by decide))

private theorem sat_2 (H : Geometry G) : (val G).satisfies [.pos 2, .pos 6, .pos 12] := by
  change ¬(G.Adj (3:V) 6) → ¬(G.Adj (4:V) 6) → ¬(G.Adj (6:V) 11) → False
  intro h0 h1 h2
  apply degree_small_contra H 6 (by decide) ({0,1,5,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 6 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 6 6 (by decide))
  · exact (H.forbidden 6 7 (by decide))
  · exact (H.forbidden 6 8 (by decide))
  · exact (H.forbidden 6 9 (by decide))
  · exact (H.forbidden 6 10 (by decide))
  · exact h2
  · exact (hj (by decide)).elim
  · exact (H.forbidden 6 13 (by decide))

private theorem sat_3 (H : Geometry G) : (val G).satisfies [.pos 2, .pos 6, .pos 13] := by
  change ¬(G.Adj (3:V) 6) → ¬(G.Adj (4:V) 6) → ¬(G.Adj (6:V) 12) → False
  intro h0 h1 h2
  apply degree_small_contra H 6 (by decide) ({0,1,5,11} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 6 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 6 6 (by decide))
  · exact (H.forbidden 6 7 (by decide))
  · exact (H.forbidden 6 8 (by decide))
  · exact (H.forbidden 6 9 (by decide))
  · exact (H.forbidden 6 10 (by decide))
  · exact (hj (by decide)).elim
  · exact h2
  · exact (H.forbidden 6 13 (by decide))

private theorem sat_4 (H : Geometry G) : (val G).satisfies [.pos 6, .pos 12, .pos 13] := by
  change ¬(G.Adj (4:V) 6) → ¬(G.Adj (6:V) 11) → ¬(G.Adj (6:V) 12) → False
  intro h0 h1 h2
  apply degree_small_contra H 6 (by decide) ({0,1,3,5} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 6 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 6 6 (by decide))
  · exact (H.forbidden 6 7 (by decide))
  · exact (H.forbidden 6 8 (by decide))
  · exact (H.forbidden 6 9 (by decide))
  · exact (H.forbidden 6 10 (by decide))
  · exact h1
  · exact h2
  · exact (H.forbidden 6 13 (by decide))

private theorem sat_5 (H : Geometry G) : (val G).satisfies [.pos 15, .pos 16, .pos 17] := by
  change ¬(G.Adj (7:V) 9) → ¬(G.Adj (7:V) 10) → ¬(G.Adj (7:V) 11) → False
  intro h0 h1 h2
  apply degree_small_contra H 7 (by decide) ({3,8,12,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 7 0 (by decide))
  · exact (H.forbidden 7 1 (by decide))
  · exact (H.forbidden 7 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 4 (by decide))
  · exact (H.forbidden 7 5 (by decide))
  · exact (H.forbidden 7 6 (by decide))
  · exact (H.forbidden 7 7 (by decide))
  · exact (hj (by decide)).elim
  · exact h0
  · exact h1
  · exact h2
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim

private theorem sat_6 (H : Geometry G) : (val G).satisfies [.pos 15, .pos 16, .pos 18] := by
  change ¬(G.Adj (7:V) 9) → ¬(G.Adj (7:V) 10) → ¬(G.Adj (7:V) 12) → False
  intro h0 h1 h2
  apply degree_small_contra H 7 (by decide) ({3,8,11,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 7 0 (by decide))
  · exact (H.forbidden 7 1 (by decide))
  · exact (H.forbidden 7 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 4 (by decide))
  · exact (H.forbidden 7 5 (by decide))
  · exact (H.forbidden 7 6 (by decide))
  · exact (H.forbidden 7 7 (by decide))
  · exact (hj (by decide)).elim
  · exact h0
  · exact h1
  · exact (hj (by decide)).elim
  · exact h2
  · exact (hj (by decide)).elim

private theorem sat_7 (H : Geometry G) : (val G).satisfies [.pos 15, .pos 17, .pos 18] := by
  change ¬(G.Adj (7:V) 9) → ¬(G.Adj (7:V) 11) → ¬(G.Adj (7:V) 12) → False
  intro h0 h1 h2
  apply degree_small_contra H 7 (by decide) ({3,8,10,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 7 0 (by decide))
  · exact (H.forbidden 7 1 (by decide))
  · exact (H.forbidden 7 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 4 (by decide))
  · exact (H.forbidden 7 5 (by decide))
  · exact (H.forbidden 7 6 (by decide))
  · exact (H.forbidden 7 7 (by decide))
  · exact (hj (by decide)).elim
  · exact h0
  · exact (hj (by decide)).elim
  · exact h1
  · exact h2
  · exact (hj (by decide)).elim

private theorem sat_8 (H : Geometry G) : (val G).satisfies [.pos 17, .pos 18, .pos 19] := by
  change ¬(G.Adj (7:V) 11) → ¬(G.Adj (7:V) 12) → ¬(G.Adj (7:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 7 (by decide) ({3,8,9,10} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 7 0 (by decide))
  · exact (H.forbidden 7 1 (by decide))
  · exact (H.forbidden 7 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 4 (by decide))
  · exact (H.forbidden 7 5 (by decide))
  · exact (H.forbidden 7 6 (by decide))
  · exact (H.forbidden 7 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h0
  · exact h1
  · exact h2

private theorem sat_9 (H : Geometry G) : (val G).satisfies [.pos 20, .pos 21, .pos 22] := by
  change ¬(G.Adj (8:V) 9) → ¬(G.Adj (8:V) 10) → ¬(G.Adj (8:V) 11) → False
  intro h0 h1 h2
  apply degree_small_contra H 8 (by decide) ({3,7,12,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 8 0 (by decide))
  · exact (H.forbidden 8 1 (by decide))
  · exact (H.forbidden 8 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 8 4 (by decide))
  · exact (H.forbidden 8 5 (by decide))
  · exact (H.forbidden 8 6 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 8 8 (by decide))
  · exact h0
  · exact h1
  · exact h2
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim

private theorem sat_10 (H : Geometry G) : (val G).satisfies [.pos 20, .pos 21, .pos 23] := by
  change ¬(G.Adj (8:V) 9) → ¬(G.Adj (8:V) 10) → ¬(G.Adj (8:V) 12) → False
  intro h0 h1 h2
  apply degree_small_contra H 8 (by decide) ({3,7,11,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 8 0 (by decide))
  · exact (H.forbidden 8 1 (by decide))
  · exact (H.forbidden 8 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 8 4 (by decide))
  · exact (H.forbidden 8 5 (by decide))
  · exact (H.forbidden 8 6 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 8 8 (by decide))
  · exact h0
  · exact h1
  · exact (hj (by decide)).elim
  · exact h2
  · exact (hj (by decide)).elim

private theorem sat_11 (H : Geometry G) : (val G).satisfies [.pos 21, .pos 22, .pos 23] := by
  change ¬(G.Adj (8:V) 10) → ¬(G.Adj (8:V) 11) → ¬(G.Adj (8:V) 12) → False
  intro h0 h1 h2
  apply degree_small_contra H 8 (by decide) ({3,7,9,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 8 0 (by decide))
  · exact (H.forbidden 8 1 (by decide))
  · exact (H.forbidden 8 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 8 4 (by decide))
  · exact (H.forbidden 8 5 (by decide))
  · exact (H.forbidden 8 6 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 8 8 (by decide))
  · exact (hj (by decide)).elim
  · exact h0
  · exact h1
  · exact h2
  · exact (hj (by decide)).elim

private theorem sat_12 (H : Geometry G) : (val G).satisfies [.pos 15, .pos 20, .pos 26] := by
  change ¬(G.Adj (7:V) 9) → ¬(G.Adj (8:V) 9) → ¬(G.Adj (9:V) 11) → False
  intro h0 h1 h2
  apply degree_small_contra H 9 (by decide) ({4,10,12,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 9 0 (by decide))
  · exact (H.forbidden 9 1 (by decide))
  · exact (H.forbidden 9 2 (by decide))
  · exact (H.forbidden 9 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 5 (by decide))
  · exact (H.forbidden 9 6 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (H.forbidden 9 9 (by decide))
  · exact (hj (by decide)).elim
  · exact h2
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim

private theorem sat_13 (H : Geometry G) : (val G).satisfies [.pos 15, .pos 20, .pos 27] := by
  change ¬(G.Adj (7:V) 9) → ¬(G.Adj (8:V) 9) → ¬(G.Adj (9:V) 12) → False
  intro h0 h1 h2
  apply degree_small_contra H 9 (by decide) ({4,10,11,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 9 0 (by decide))
  · exact (H.forbidden 9 1 (by decide))
  · exact (H.forbidden 9 2 (by decide))
  · exact (H.forbidden 9 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 5 (by decide))
  · exact (H.forbidden 9 6 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (H.forbidden 9 9 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h2
  · exact (hj (by decide)).elim

private theorem sat_14 (H : Geometry G) : (val G).satisfies [.pos 16, .pos 21, .pos 29] := by
  change ¬(G.Adj (7:V) 10) → ¬(G.Adj (8:V) 10) → ¬(G.Adj (10:V) 11) → False
  intro h0 h1 h2
  apply degree_small_contra H 10 (by decide) ({4,9,12,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 5 (by decide))
  · exact (H.forbidden 10 6 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 10 (by decide))
  · exact h2
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim

private theorem sat_15 (H : Geometry G) : (val G).satisfies [.pos 16, .pos 21, .pos 30] := by
  change ¬(G.Adj (7:V) 10) → ¬(G.Adj (8:V) 10) → ¬(G.Adj (10:V) 12) → False
  intro h0 h1 h2
  apply degree_small_contra H 10 (by decide) ({4,9,11,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 5 (by decide))
  · exact (H.forbidden 10 6 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 10 (by decide))
  · exact (hj (by decide)).elim
  · exact h2
  · exact (hj (by decide)).elim

private theorem sat_16 (H : Geometry G) : (val G).satisfies [.pos 16, .pos 29, .pos 30] := by
  change ¬(G.Adj (7:V) 10) → ¬(G.Adj (10:V) 11) → ¬(G.Adj (10:V) 12) → False
  intro h0 h1 h2
  apply degree_small_contra H 10 (by decide) ({4,8,9,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 5 (by decide))
  · exact (H.forbidden 10 6 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 10 (by decide))
  · exact h1
  · exact h2
  · exact (hj (by decide)).elim

private theorem sat_17 (H : Geometry G) : (val G).satisfies [.pos 21, .pos 29, .pos 30] := by
  change ¬(G.Adj (8:V) 10) → ¬(G.Adj (10:V) 11) → ¬(G.Adj (10:V) 12) → False
  intro h0 h1 h2
  apply degree_small_contra H 10 (by decide) ({4,7,9,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 5 (by decide))
  · exact (H.forbidden 10 6 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 10 (by decide))
  · exact h1
  · exact h2
  · exact (hj (by decide)).elim

private theorem sat_18 (H : Geometry G) : (val G).satisfies [.pos 29, .pos 30, .pos 31] := by
  change ¬(G.Adj (10:V) 11) → ¬(G.Adj (10:V) 12) → ¬(G.Adj (10:V) 13) → False
  intro h0 h1 h2
  apply degree_small_contra H 10 (by decide) ({4,7,8,9} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 5 (by decide))
  · exact (H.forbidden 10 6 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 10 (by decide))
  · exact h0
  · exact h1
  · exact h2

private theorem sat_19 (H : Geometry G) : (val G).satisfies [.pos 19, .pos 24] := by
  change ¬(G.Adj (7:V) 13) → ¬(G.Adj (8:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 13 (by decide) ({9,10,11,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 13 0 (by decide))
  · exact (H.forbidden 13 1 (by decide))
  · exact (H.forbidden 13 2 (by decide))
  · exact (H.forbidden 13 3 (by decide))
  · exact (H.forbidden 13 4 (by decide))
  · exact (H.forbidden 13 5 (by decide))
  · exact (H.forbidden 13 6 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 13 13 (by decide))

private theorem sat_20 (H : Geometry G) : (val G).satisfies [.pos 28, .pos 31] := by
  change ¬(G.Adj (9:V) 13) → ¬(G.Adj (10:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 13 (by decide) ({7,8,11,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 13 0 (by decide))
  · exact (H.forbidden 13 1 (by decide))
  · exact (H.forbidden 13 2 (by decide))
  · exact (H.forbidden 13 3 (by decide))
  · exact (H.forbidden 13 4 (by decide))
  · exact (H.forbidden 13 5 (by decide))
  · exact (H.forbidden 13 6 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 13 13 (by decide))

private theorem sat_21 (H : Geometry G) : (val G).satisfies [.pos 28, .pos 33] := by
  change ¬(G.Adj (9:V) 13) → ¬(G.Adj (11:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 13 (by decide) ({7,8,10,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 13 0 (by decide))
  · exact (H.forbidden 13 1 (by decide))
  · exact (H.forbidden 13 2 (by decide))
  · exact (H.forbidden 13 3 (by decide))
  · exact (H.forbidden 13 4 (by decide))
  · exact (H.forbidden 13 5 (by decide))
  · exact (H.forbidden 13 6 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 13 13 (by decide))

private theorem sat_22 (H : Geometry G) : (val G).satisfies [.pos 28, .pos 34] := by
  change ¬(G.Adj (9:V) 13) → ¬(G.Adj (12:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 13 (by decide) ({7,8,10,11} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 13 0 (by decide))
  · exact (H.forbidden 13 1 (by decide))
  · exact (H.forbidden 13 2 (by decide))
  · exact (H.forbidden 13 3 (by decide))
  · exact (H.forbidden 13 4 (by decide))
  · exact (H.forbidden 13 5 (by decide))
  · exact (H.forbidden 13 6 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (fun z => h1 z.symm)
  · exact (H.forbidden 13 13 (by decide))

private theorem sat_23 (H : Geometry G) : (val G).satisfies [.pos 33, .pos 34] := by
  change ¬(G.Adj (11:V) 13) → ¬(G.Adj (12:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 13 (by decide) ({7,8,9,10} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 13 0 (by decide))
  · exact (H.forbidden 13 1 (by decide))
  · exact (H.forbidden 13 2 (by decide))
  · exact (H.forbidden 13 3 (by decide))
  · exact (H.forbidden 13 4 (by decide))
  · exact (H.forbidden 13 5 (by decide))
  · exact (H.forbidden 13 6 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (H.forbidden 13 13 (by decide))

private theorem sat_24 (H : Geometry G) : (val G).satisfies [.pos 3, .pos 10, .pos 12] := by
  change ¬(G.Adj (3:V) 11) → ¬(G.Adj (5:V) 11) → ¬(G.Adj (6:V) 11) → False
  intro h0 h1 h2
  have k := H.nearA11
  tauto

private theorem sat_25 (H : Geometry G) : (val G).satisfies [.pos 7, .pos 10, .pos 12] := by
  change ¬(G.Adj (4:V) 11) → ¬(G.Adj (5:V) 11) → ¬(G.Adj (6:V) 11) → False
  intro h0 h1 h2
  have k := H.nearB11
  tauto

private theorem sat_26 (H : Geometry G) : (val G).satisfies [.pos 4, .pos 11, .pos 13] := by
  change ¬(G.Adj (3:V) 12) → ¬(G.Adj (5:V) 12) → ¬(G.Adj (6:V) 12) → False
  intro h0 h1 h2
  have k := H.nearA12
  tauto

private theorem sat_27 (H : Geometry G) : (val G).satisfies [.pos 8, .pos 11, .pos 13] := by
  change ¬(G.Adj (4:V) 12) → ¬(G.Adj (5:V) 12) → ¬(G.Adj (6:V) 12) → False
  intro h0 h1 h2
  have k := H.nearB12
  tauto

private theorem sat_28 (H : Geometry G) : (val G).satisfies [.pos 35] := by
  change ¬(G.dist (1:V) 3 = 2) → False
  intro h0
  exact h0 (by rw [dist_comm]; exact distance_two_from_two_edges H 3 0 1 (by decide) (H.forbidden 3 1 (by decide)) (H.fixed 3 0 (by decide)) (H.fixed 0 1 (by decide)))

private theorem sat_29 (H : Geometry G) : (val G).satisfies [.pos 36] := by
  change ¬(G.dist (2:V) 3 = 2) → False
  intro h0
  exact h0 (by rw [dist_comm]; exact distance_two_from_two_edges H 3 0 2 (by decide) (H.forbidden 3 2 (by decide)) (H.fixed 3 0 (by decide)) (H.fixed 0 2 (by decide)))

private theorem sat_30 (H : Geometry G) : (val G).satisfies [.pos 2, .pos 39] := by
  change ¬(G.Adj (3:V) 6) → ¬(G.dist (3:V) 6 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 3 0 6 (by decide) h0 (H.fixed 3 0 (by decide)) (H.fixed 0 6 (by decide)))

private theorem sat_31 (H : Geometry G) : (val G).satisfies [.neg 0, .pos 40] := by
  change (G.Adj (3:V) 4) → ¬(G.dist (3:V) 9 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 3 4 9 (by decide) (H.forbidden 3 9 (by decide)) h0 (H.fixed 4 9 (by decide)))

private theorem sat_32 (H : Geometry G) : (val G).satisfies [.neg 15, .pos 40] := by
  change (G.Adj (7:V) 9) → ¬(G.dist (3:V) 9 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 3 7 9 (by decide) (H.forbidden 3 9 (by decide)) (H.fixed 3 7 (by decide)) h0)

private theorem sat_33 (H : Geometry G) : (val G).satisfies [.neg 20, .pos 40] := by
  change (G.Adj (8:V) 9) → ¬(G.dist (3:V) 9 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 3 8 9 (by decide) (H.forbidden 3 9 (by decide)) (H.fixed 3 8 (by decide)) h0)

private theorem sat_34 (H : Geometry G) : (val G).satisfies [.neg 3, .neg 26, .pos 40] := by
  change (G.Adj (3:V) 11) → (G.Adj (9:V) 11) → ¬(G.dist (3:V) 9 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 3 11 9 (by decide) (H.forbidden 3 9 (by decide)) h0 h1.symm)

private theorem sat_35 (H : Geometry G) : (val G).satisfies [.neg 4, .neg 27, .pos 40] := by
  change (G.Adj (3:V) 12) → (G.Adj (9:V) 12) → ¬(G.dist (3:V) 9 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 3 12 9 (by decide) (H.forbidden 3 9 (by decide)) h0 h1.symm)

private theorem sat_36 (H : Geometry G) : (val G).satisfies [.neg 0, .pos 41] := by
  change (G.Adj (3:V) 4) → ¬(G.dist (3:V) 10 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 3 4 10 (by decide) (H.forbidden 3 10 (by decide)) h0 (H.fixed 4 10 (by decide)))

private theorem sat_37 (H : Geometry G) : (val G).satisfies [.neg 16, .pos 41] := by
  change (G.Adj (7:V) 10) → ¬(G.dist (3:V) 10 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 3 7 10 (by decide) (H.forbidden 3 10 (by decide)) (H.fixed 3 7 (by decide)) h0)

private theorem sat_38 (H : Geometry G) : (val G).satisfies [.neg 21, .pos 41] := by
  change (G.Adj (8:V) 10) → ¬(G.dist (3:V) 10 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 3 8 10 (by decide) (H.forbidden 3 10 (by decide)) (H.fixed 3 8 (by decide)) h0)

private theorem sat_39 (H : Geometry G) : (val G).satisfies [.neg 3, .neg 29, .pos 41] := by
  change (G.Adj (3:V) 11) → (G.Adj (10:V) 11) → ¬(G.dist (3:V) 10 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 3 11 10 (by decide) (H.forbidden 3 10 (by decide)) h0 h1.symm)

private theorem sat_40 (H : Geometry G) : (val G).satisfies [.neg 4, .neg 30, .pos 41] := by
  change (G.Adj (3:V) 12) → (G.Adj (10:V) 12) → ¬(G.dist (3:V) 10 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 3 12 10 (by decide) (H.forbidden 3 10 (by decide)) h0 h1.symm)

private theorem sat_41 (H : Geometry G) : (val G).satisfies [.neg 19, .pos 44] := by
  change (G.Adj (7:V) 13) → ¬(G.dist (3:V) 13 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 3 7 13 (by decide) (H.forbidden 3 13 (by decide)) (H.fixed 3 7 (by decide)) h0)

private theorem sat_42 (H : Geometry G) : (val G).satisfies [.neg 24, .pos 44] := by
  change (G.Adj (8:V) 13) → ¬(G.dist (3:V) 13 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 3 8 13 (by decide) (H.forbidden 3 13 (by decide)) (H.fixed 3 8 (by decide)) h0)

private theorem sat_43 (H : Geometry G) : (val G).satisfies [.pos 45] := by
  change ¬(G.dist (0:V) 4 = 2) → False
  intro h0
  exact h0 (by rw [dist_comm]; exact distance_two_from_two_edges H 4 1 0 (by decide) (H.forbidden 4 0 (by decide)) (H.fixed 4 1 (by decide)) (H.fixed 1 0 (by decide)))

private theorem sat_44 (H : Geometry G) : (val G).satisfies [.pos 46] := by
  change ¬(G.dist (2:V) 4 = 2) → False
  intro h0
  exact h0 (by rw [dist_comm]; exact distance_two_from_two_edges H 4 1 2 (by decide) (H.forbidden 4 2 (by decide)) (H.fixed 4 1 (by decide)) (H.fixed 1 2 (by decide)))

private theorem sat_45 (H : Geometry G) : (val G).satisfies [.pos 6, .pos 48] := by
  change ¬(G.Adj (4:V) 6) → ¬(G.dist (4:V) 6 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 4 1 6 (by decide) h0 (H.fixed 4 1 (by decide)) (H.fixed 1 6 (by decide)))

private theorem sat_46 (H : Geometry G) : (val G).satisfies [.neg 15, .pos 49] := by
  change (G.Adj (7:V) 9) → ¬(G.dist (4:V) 7 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 4 9 7 (by decide) (H.forbidden 4 7 (by decide)) (H.fixed 4 9 (by decide)) h0.symm)

private theorem sat_47 (H : Geometry G) : (val G).satisfies [.neg 16, .pos 49] := by
  change (G.Adj (7:V) 10) → ¬(G.dist (4:V) 7 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 4 10 7 (by decide) (H.forbidden 4 7 (by decide)) (H.fixed 4 10 (by decide)) h0.symm)

private theorem sat_48 (H : Geometry G) : (val G).satisfies [.neg 7, .neg 17, .pos 49] := by
  change (G.Adj (4:V) 11) → (G.Adj (7:V) 11) → ¬(G.dist (4:V) 7 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 4 11 7 (by decide) (H.forbidden 4 7 (by decide)) h0 h1.symm)

private theorem sat_49 (H : Geometry G) : (val G).satisfies [.neg 8, .neg 18, .pos 49] := by
  change (G.Adj (4:V) 12) → (G.Adj (7:V) 12) → ¬(G.dist (4:V) 7 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 4 12 7 (by decide) (H.forbidden 4 7 (by decide)) h0 h1.symm)

private theorem sat_50 (H : Geometry G) : (val G).satisfies [.neg 0, .pos 50] := by
  change (G.Adj (3:V) 4) → ¬(G.dist (4:V) 8 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 4 3 8 (by decide) (H.forbidden 4 8 (by decide)) h0.symm (H.fixed 3 8 (by decide)))

private theorem sat_51 (H : Geometry G) : (val G).satisfies [.neg 20, .pos 50] := by
  change (G.Adj (8:V) 9) → ¬(G.dist (4:V) 8 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 4 9 8 (by decide) (H.forbidden 4 8 (by decide)) (H.fixed 4 9 (by decide)) h0.symm)

private theorem sat_52 (H : Geometry G) : (val G).satisfies [.neg 21, .pos 50] := by
  change (G.Adj (8:V) 10) → ¬(G.dist (4:V) 8 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 4 10 8 (by decide) (H.forbidden 4 8 (by decide)) (H.fixed 4 10 (by decide)) h0.symm)

private theorem sat_53 (H : Geometry G) : (val G).satisfies [.neg 7, .neg 22, .pos 50] := by
  change (G.Adj (4:V) 11) → (G.Adj (8:V) 11) → ¬(G.dist (4:V) 8 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 4 11 8 (by decide) (H.forbidden 4 8 (by decide)) h0 h1.symm)

private theorem sat_54 (H : Geometry G) : (val G).satisfies [.neg 8, .neg 23, .pos 50] := by
  change (G.Adj (4:V) 12) → (G.Adj (8:V) 12) → ¬(G.dist (4:V) 8 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 4 12 8 (by decide) (H.forbidden 4 8 (by decide)) h0 h1.symm)

private theorem sat_55 (H : Geometry G) : (val G).satisfies [.pos 7, .neg 29, .pos 51] := by
  change ¬(G.Adj (4:V) 11) → (G.Adj (10:V) 11) → ¬(G.dist (4:V) 11 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 4 10 11 (by decide) h0 (H.fixed 4 10 (by decide)) h1)

private theorem sat_56 (H : Geometry G) : (val G).satisfies [.pos 8, .neg 30, .pos 52] := by
  change ¬(G.Adj (4:V) 12) → (G.Adj (10:V) 12) → ¬(G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 4 10 12 (by decide) h0 (H.fixed 4 10 (by decide)) h1)

private theorem sat_57 (H : Geometry G) : (val G).satisfies [.neg 28, .pos 53] := by
  change (G.Adj (9:V) 13) → ¬(G.dist (4:V) 13 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 4 9 13 (by decide) (H.forbidden 4 13 (by decide)) (H.fixed 4 9 (by decide)) h0)

private theorem sat_58 (H : Geometry G) : (val G).satisfies [.neg 31, .pos 53] := by
  change (G.Adj (10:V) 13) → ¬(G.dist (4:V) 13 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 4 10 13 (by decide) (H.forbidden 4 13 (by decide)) (H.fixed 4 10 (by decide)) h0)

private theorem sat_59 (H : Geometry G) : (val G).satisfies [.pos 9, .pos 55] := by
  change ¬(G.Adj (5:V) 6) → ¬(G.dist (5:V) 6 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 5 0 6 (by decide) h0 (H.fixed 5 0 (by decide)) (H.fixed 0 6 (by decide)))

private theorem sat_60 (H : Geometry G) : (val G).satisfies [.pos 63] := by
  change ¬(G.dist (2:V) 6 = 2) → False
  intro h0
  exact h0 (by rw [dist_comm]; exact distance_two_from_two_edges H 6 0 2 (by decide) (H.forbidden 6 2 (by decide)) (H.fixed 6 0 (by decide)) (H.fixed 0 2 (by decide)))

private theorem sat_61 (H : Geometry G) : (val G).satisfies [.neg 2, .pos 64] := by
  change (G.Adj (3:V) 6) → ¬(G.dist (6:V) 7 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 6 3 7 (by decide) (H.forbidden 6 7 (by decide)) h0.symm (H.fixed 3 7 (by decide)))

private theorem sat_62 (H : Geometry G) : (val G).satisfies [.neg 12, .neg 17, .pos 64] := by
  change (G.Adj (6:V) 11) → (G.Adj (7:V) 11) → ¬(G.dist (6:V) 7 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 6 11 7 (by decide) (H.forbidden 6 7 (by decide)) h0 h1.symm)

private theorem sat_63 (H : Geometry G) : (val G).satisfies [.neg 13, .neg 18, .pos 64] := by
  change (G.Adj (6:V) 12) → (G.Adj (7:V) 12) → ¬(G.dist (6:V) 7 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 6 12 7 (by decide) (H.forbidden 6 7 (by decide)) h0 h1.symm)

private theorem sat_64 (H : Geometry G) : (val G).satisfies [.neg 2, .pos 65] := by
  change (G.Adj (3:V) 6) → ¬(G.dist (6:V) 8 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 6 3 8 (by decide) (H.forbidden 6 8 (by decide)) h0.symm (H.fixed 3 8 (by decide)))

private theorem sat_65 (H : Geometry G) : (val G).satisfies [.neg 12, .neg 22, .pos 65] := by
  change (G.Adj (6:V) 11) → (G.Adj (8:V) 11) → ¬(G.dist (6:V) 8 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 6 11 8 (by decide) (H.forbidden 6 8 (by decide)) h0 h1.symm)

private theorem sat_66 (H : Geometry G) : (val G).satisfies [.neg 13, .neg 23, .pos 65] := by
  change (G.Adj (6:V) 12) → (G.Adj (8:V) 12) → ¬(G.dist (6:V) 8 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 6 12 8 (by decide) (H.forbidden 6 8 (by decide)) h0 h1.symm)

private theorem sat_67 (H : Geometry G) : (val G).satisfies [.neg 6, .pos 66] := by
  change (G.Adj (4:V) 6) → ¬(G.dist (6:V) 9 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 6 4 9 (by decide) (H.forbidden 6 9 (by decide)) h0.symm (H.fixed 4 9 (by decide)))

private theorem sat_68 (H : Geometry G) : (val G).satisfies [.neg 6, .pos 67] := by
  change (G.Adj (4:V) 6) → ¬(G.dist (6:V) 10 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 6 4 10 (by decide) (H.forbidden 6 10 (by decide)) h0.symm (H.fixed 4 10 (by decide)))

private theorem sat_69 (H : Geometry G) : (val G).satisfies [.neg 12, .neg 29, .pos 67] := by
  change (G.Adj (6:V) 11) → (G.Adj (10:V) 11) → ¬(G.dist (6:V) 10 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 6 11 10 (by decide) (H.forbidden 6 10 (by decide)) h0 h1.symm)

private theorem sat_70 (H : Geometry G) : (val G).satisfies [.neg 13, .neg 30, .pos 67] := by
  change (G.Adj (6:V) 12) → (G.Adj (10:V) 12) → ¬(G.dist (6:V) 10 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 6 12 10 (by decide) (H.forbidden 6 10 (by decide)) h0 h1.symm)

private theorem sat_71 (H : Geometry G) : (val G).satisfies [.neg 2, .neg 3, .pos 12, .pos 68] := by
  change (G.Adj (3:V) 6) → (G.Adj (3:V) 11) → ¬(G.Adj (6:V) 11) → ¬(G.dist (6:V) 11 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 6 3 11 (by decide) h2 h0.symm h1)

private theorem sat_72 (H : Geometry G) : (val G).satisfies [.neg 6, .neg 7, .pos 12, .pos 68] := by
  change (G.Adj (4:V) 6) → (G.Adj (4:V) 11) → ¬(G.Adj (6:V) 11) → ¬(G.dist (6:V) 11 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 6 4 11 (by decide) h2 h0.symm h1)

private theorem sat_73 (H : Geometry G) : (val G).satisfies [.neg 9, .neg 10, .pos 12, .pos 68] := by
  change (G.Adj (5:V) 6) → (G.Adj (5:V) 11) → ¬(G.Adj (6:V) 11) → ¬(G.dist (6:V) 11 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 6 5 11 (by decide) h2 h0.symm h1)

private theorem sat_74 (H : Geometry G) : (val G).satisfies [.neg 2, .neg 4, .pos 13, .pos 69] := by
  change (G.Adj (3:V) 6) → (G.Adj (3:V) 12) → ¬(G.Adj (6:V) 12) → ¬(G.dist (6:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 6 3 12 (by decide) h2 h0.symm h1)

private theorem sat_75 (H : Geometry G) : (val G).satisfies [.neg 6, .neg 8, .pos 13, .pos 69] := by
  change (G.Adj (4:V) 6) → (G.Adj (4:V) 12) → ¬(G.Adj (6:V) 12) → ¬(G.dist (6:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 6 4 12 (by decide) h2 h0.symm h1)

private theorem sat_76 (H : Geometry G) : (val G).satisfies [.neg 9, .neg 11, .pos 13, .pos 69] := by
  change (G.Adj (5:V) 6) → (G.Adj (5:V) 12) → ¬(G.Adj (6:V) 12) → ¬(G.dist (6:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 6 5 12 (by decide) h2 h0.symm h1)

private theorem sat_77 (H : Geometry G) : (val G).satisfies [.neg 12, .neg 33, .pos 70] := by
  change (G.Adj (6:V) 11) → (G.Adj (11:V) 13) → ¬(G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 6 11 13 (by decide) (H.forbidden 6 13 (by decide)) h0 h1)

private theorem sat_78 (H : Geometry G) : (val G).satisfies [.neg 13, .neg 34, .pos 70] := by
  change (G.Adj (6:V) 12) → (G.Adj (12:V) 13) → ¬(G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 6 12 13 (by decide) (H.forbidden 6 13 (by decide)) h0 h1)

private theorem sat_79 (H : Geometry G) : (val G).satisfies [.neg 35, .neg 36, .neg 39, .neg 40, .neg 41, .neg 44] := by
  change (G.dist (1:V) 3 = 2) → (G.dist (2:V) 3 = 2) → (G.dist (3:V) 6 = 2) → (G.dist (3:V) 9 = 2) → (G.dist (3:V) 10 = 2) → (G.dist (3:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 3 ({1,2,6,9,10,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_80 (H : Geometry G) : (val G).satisfies [.neg 45, .neg 46, .neg 48, .neg 49, .neg 50, .neg 53] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,6,7,8,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_81 (H : Geometry G) : (val G).satisfies [.neg 45, .neg 46, .neg 48, .neg 49, .neg 51, .neg 53] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (4:V) 11 = 2) → (G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,6,7,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_82 (H : Geometry G) : (val G).satisfies [.neg 45, .neg 46, .neg 48, .neg 49, .neg 52, .neg 53] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (4:V) 12 = 2) → (G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,6,7,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_83 (H : Geometry G) : (val G).satisfies [.neg 45, .neg 46, .neg 48, .neg 50, .neg 51, .neg 53] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 11 = 2) → (G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,6,8,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_84 (H : Geometry G) : (val G).satisfies [.neg 45, .neg 46, .neg 48, .neg 50, .neg 52, .neg 53] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 12 = 2) → (G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,6,8,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_85 (H : Geometry G) : (val G).satisfies [.neg 45, .neg 46, .neg 48, .neg 51, .neg 52, .neg 53] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (4:V) 11 = 2) → (G.dist (4:V) 12 = 2) → (G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,6,11,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_86 (H : Geometry G) : (val G).satisfies [.neg 39, .neg 48, .neg 63, .neg 64, .neg 67, .neg 70] := by
  change (G.dist (3:V) 6 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (2:V) 6 = 2) → (G.dist (6:V) 7 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({3,4,2,7,10,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_87 (H : Geometry G) : (val G).satisfies [.neg 39, .neg 48, .neg 63, .neg 65, .neg 67, .neg 70] := by
  change (G.dist (3:V) 6 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (2:V) 6 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({3,4,2,8,10,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_88 (H : Geometry G) : (val G).satisfies [.neg 39, .neg 48, .neg 63, .neg 66, .neg 67, .neg 70] := by
  change (G.dist (3:V) 6 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (2:V) 6 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({3,4,2,9,10,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_89 (H : Geometry G) : (val G).satisfies [.neg 39, .neg 48, .neg 63, .neg 67, .neg 69, .neg 70] := by
  change (G.dist (3:V) 6 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (2:V) 6 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 12 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({3,4,2,10,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_90 (H : Geometry G) : (val G).satisfies [.neg 39, .neg 55, .neg 63, .neg 66, .neg 67, .neg 70] := by
  change (G.dist (3:V) 6 = 2) → (G.dist (5:V) 6 = 2) → (G.dist (2:V) 6 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({3,5,2,9,10,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_91 (H : Geometry G) : (val G).satisfies [.neg 39, .neg 63, .neg 64, .neg 66, .neg 67, .neg 70] := by
  change (G.dist (3:V) 6 = 2) → (G.dist (2:V) 6 = 2) → (G.dist (6:V) 7 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({3,2,7,9,10,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_92 (H : Geometry G) : (val G).satisfies [.neg 39, .neg 63, .neg 65, .neg 66, .neg 67, .neg 70] := by
  change (G.dist (3:V) 6 = 2) → (G.dist (2:V) 6 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({3,2,8,9,10,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_93 (H : Geometry G) : (val G).satisfies [.neg 39, .neg 63, .neg 66, .neg 67, .neg 68, .neg 70] := by
  change (G.dist (3:V) 6 = 2) → (G.dist (2:V) 6 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({3,2,9,10,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_94 (H : Geometry G) : (val G).satisfies [.neg 39, .neg 63, .neg 66, .neg 67, .neg 69, .neg 70] := by
  change (G.dist (3:V) 6 = 2) → (G.dist (2:V) 6 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 12 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({3,2,9,10,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_95 (H : Geometry G) : (val G).satisfies [.neg 48, .neg 55, .neg 63, .neg 64, .neg 65, .neg 70] := by
  change (G.dist (4:V) 6 = 2) → (G.dist (5:V) 6 = 2) → (G.dist (2:V) 6 = 2) → (G.dist (6:V) 7 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({4,5,2,7,8,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_96 (H : Geometry G) : (val G).satisfies [.neg 48, .neg 63, .neg 64, .neg 65, .neg 67, .neg 70] := by
  change (G.dist (4:V) 6 = 2) → (G.dist (2:V) 6 = 2) → (G.dist (6:V) 7 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({4,2,7,8,10,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_97 (H : Geometry G) : (val G).satisfies [.neg 48, .neg 63, .neg 64, .neg 65, .neg 68, .neg 70] := by
  change (G.dist (4:V) 6 = 2) → (G.dist (2:V) 6 = 2) → (G.dist (6:V) 7 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({4,2,7,8,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_98 (H : Geometry G) : (val G).satisfies [.neg 48, .neg 63, .neg 64, .neg 65, .neg 69, .neg 70] := by
  change (G.dist (4:V) 6 = 2) → (G.dist (2:V) 6 = 2) → (G.dist (6:V) 7 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 12 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({4,2,7,8,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_99 (H : Geometry G) : (val G).satisfies [.neg 55, .neg 63, .neg 64, .neg 65, .neg 66, .neg 67] := by
  change (G.dist (5:V) 6 = 2) → (G.dist (2:V) 6 = 2) → (G.dist (6:V) 7 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({5,2,7,8,9,10} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_100 (H : Geometry G) : (val G).satisfies [.neg 63, .neg 64, .neg 65, .neg 66, .neg 67, .neg 68] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (6:V) 7 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,7,8,9,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact h1
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_101 (H : Geometry G) : (val G).satisfies [.neg 63, .neg 64, .neg 65, .neg 66, .neg 67, .neg 69] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (6:V) 7 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,7,8,9,10,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact h1
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_102 (H : Geometry G) : (val G).satisfies [.neg 63, .neg 64, .neg 65, .neg 66, .neg 67, .neg 70] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (6:V) 7 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,7,8,9,10,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact h1
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_103 (H : Geometry G) : (val G).satisfies [.neg 63, .neg 64, .neg 66, .neg 67, .neg 69, .neg 70] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (6:V) 7 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 12 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,7,9,10,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact h1
  · exact h2
  · exact h3
  · exact h4
  · exact h5

theorem normalized_geometry_impossible (H : Geometry G) : False := by
  have hf : (val G).satisfies_fmla ec2_exclusion.formula :=
    (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_0 H)) (fmla_and _ _ _ (fmla_one _ _ (sat_1 H)) (fmla_one _ _ (sat_2 H)))) (fmla_and _ _ _ (fmla_one _ _ (sat_3 H)) (fmla_and _ _ _ (fmla_one _ _ (sat_4 H)) (fmla_one _ _ (sat_5 H))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_6 H)) (fmla_and _ _ _ (fmla_one _ _ (sat_7 H)) (fmla_one _ _ (sat_8 H)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_9 H)) (fmla_one _ _ (sat_10 H))) (fmla_and _ _ _ (fmla_one _ _ (sat_11 H)) (fmla_one _ _ (sat_12 H)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_13 H)) (fmla_and _ _ _ (fmla_one _ _ (sat_14 H)) (fmla_one _ _ (sat_15 H)))) (fmla_and _ _ _ (fmla_one _ _ (sat_16 H)) (fmla_and _ _ _ (fmla_one _ _ (sat_17 H)) (fmla_one _ _ (sat_18 H))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_19 H)) (fmla_and _ _ _ (fmla_one _ _ (sat_20 H)) (fmla_one _ _ (sat_21 H)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_22 H)) (fmla_one _ _ (sat_23 H))) (fmla_and _ _ _ (fmla_one _ _ (sat_24 H)) (fmla_one _ _ (sat_25 H))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_26 H)) (fmla_and _ _ _ (fmla_one _ _ (sat_27 H)) (fmla_one _ _ (sat_28 H)))) (fmla_and _ _ _ (fmla_one _ _ (sat_29 H)) (fmla_and _ _ _ (fmla_one _ _ (sat_30 H)) (fmla_one _ _ (sat_31 H))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_32 H)) (fmla_and _ _ _ (fmla_one _ _ (sat_33 H)) (fmla_one _ _ (sat_34 H)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_35 H)) (fmla_one _ _ (sat_36 H))) (fmla_and _ _ _ (fmla_one _ _ (sat_37 H)) (fmla_one _ _ (sat_38 H)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_39 H)) (fmla_and _ _ _ (fmla_one _ _ (sat_40 H)) (fmla_one _ _ (sat_41 H)))) (fmla_and _ _ _ (fmla_one _ _ (sat_42 H)) (fmla_and _ _ _ (fmla_one _ _ (sat_43 H)) (fmla_one _ _ (sat_44 H))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_45 H)) (fmla_and _ _ _ (fmla_one _ _ (sat_46 H)) (fmla_one _ _ (sat_47 H)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_48 H)) (fmla_one _ _ (sat_49 H))) (fmla_and _ _ _ (fmla_one _ _ (sat_50 H)) (fmla_one _ _ (sat_51 H)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_52 H)) (fmla_and _ _ _ (fmla_one _ _ (sat_53 H)) (fmla_one _ _ (sat_54 H)))) (fmla_and _ _ _ (fmla_one _ _ (sat_55 H)) (fmla_and _ _ _ (fmla_one _ _ (sat_56 H)) (fmla_one _ _ (sat_57 H))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_58 H)) (fmla_and _ _ _ (fmla_one _ _ (sat_59 H)) (fmla_one _ _ (sat_60 H)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_61 H)) (fmla_one _ _ (sat_62 H))) (fmla_and _ _ _ (fmla_one _ _ (sat_63 H)) (fmla_one _ _ (sat_64 H)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_65 H)) (fmla_and _ _ _ (fmla_one _ _ (sat_66 H)) (fmla_one _ _ (sat_67 H)))) (fmla_and _ _ _ (fmla_one _ _ (sat_68 H)) (fmla_and _ _ _ (fmla_one _ _ (sat_69 H)) (fmla_one _ _ (sat_70 H))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_71 H)) (fmla_and _ _ _ (fmla_one _ _ (sat_72 H)) (fmla_one _ _ (sat_73 H)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_74 H)) (fmla_one _ _ (sat_75 H))) (fmla_and _ _ _ (fmla_one _ _ (sat_76 H)) (fmla_one _ _ (sat_77 H))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_78 H)) (fmla_and _ _ _ (fmla_one _ _ (sat_79 H)) (fmla_one _ _ (sat_80 H)))) (fmla_and _ _ _ (fmla_one _ _ (sat_81 H)) (fmla_and _ _ _ (fmla_one _ _ (sat_82 H)) (fmla_one _ _ (sat_83 H))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_84 H)) (fmla_and _ _ _ (fmla_one _ _ (sat_85 H)) (fmla_one _ _ (sat_86 H)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_87 H)) (fmla_one _ _ (sat_88 H))) (fmla_and _ _ _ (fmla_one _ _ (sat_89 H)) (fmla_one _ _ (sat_90 H)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_91 H)) (fmla_and _ _ _ (fmla_one _ _ (sat_92 H)) (fmla_one _ _ (sat_93 H)))) (fmla_and _ _ _ (fmla_one _ _ (sat_94 H)) (fmla_and _ _ _ (fmla_one _ _ (sat_95 H)) (fmla_one _ _ (sat_96 H))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_97 H)) (fmla_and _ _ _ (fmla_one _ _ (sat_98 H)) (fmla_one _ _ (sat_99 H)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_100 H)) (fmla_one _ _ (sat_101 H))) (fmla_and _ _ _ (fmla_one _ _ (sat_102 H)) (fmla_one _ _ (sat_103 H)))))))))
  exact ec2_exclusion (val G) hf

#print axioms normalized_geometry_impossible
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent.SingletonRUP.ec2
