import AdjacentCutFiveFourteenRUPEC3189
import AdjacentCutFiveFourteenRUPE189
import AdjacentCutFiveBound189
import DiversityElevenCircuitBits384b
import Mathlib.Tactic.FinCases

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent.SingletonRUP.ec3
open SimpleGraph Finset Sat
open private d2 mem_positive from AdjacentCutFiveBound189
open private positive_card from AdjacentCutFiveBound189
open Graffiti384b.DiversityEleven.PendantCircuit (fmla_and fmla_one)
set_option linter.unusedVariables false
set_option linter.unusedSectionVars false
set_option maxRecDepth 32768
set_option maxHeartbeats 100000000
abbrev V := Fin 14
variable {G : SimpleGraph V} [DecidableRel G.Adj]

def fixedMatrix (i j : V) : Bool :=
  match i.val,j.val with
  | 0, 1 | 1, 0 => true
  | 0, 2 | 2, 0 => true
  | 0, 3 | 3, 0 => true
  | 0, 5 | 5, 0 => true
  | 0, 6 | 6, 0 => true
  | 0, 7 | 7, 0 => true
  | 1, 2 | 2, 1 => true
  | 1, 4 | 4, 1 => true
  | 1, 5 | 5, 1 => true
  | 1, 6 | 6, 1 => true
  | 1, 7 | 7, 1 => true
  | 3, 8 | 8, 3 => true
  | 3, 9 | 9, 3 => true
  | 4, 10 | 10, 4 => true
  | 4, 11 | 11, 4 => true
  | _, _ => false

def allowedMatrix (i j : V) : Bool :=
  match i.val,j.val with
  | 0, 1 | 1, 0 => true
  | 0, 2 | 2, 0 => true
  | 0, 3 | 3, 0 => true
  | 0, 5 | 5, 0 => true
  | 0, 6 | 6, 0 => true
  | 0, 7 | 7, 0 => true
  | 1, 2 | 2, 1 => true
  | 1, 4 | 4, 1 => true
  | 1, 5 | 5, 1 => true
  | 1, 6 | 6, 1 => true
  | 1, 7 | 7, 1 => true
  | 3, 4 | 4, 3 => true
  | 3, 5 | 5, 3 => true
  | 3, 6 | 6, 3 => true
  | 3, 7 | 7, 3 => true
  | 3, 8 | 8, 3 => true
  | 3, 9 | 9, 3 => true
  | 3, 12 | 12, 3 => true
  | 3, 13 | 13, 3 => true
  | 4, 5 | 5, 4 => true
  | 4, 6 | 6, 4 => true
  | 4, 7 | 7, 4 => true
  | 4, 10 | 10, 4 => true
  | 4, 11 | 11, 4 => true
  | 4, 12 | 12, 4 => true
  | 4, 13 | 13, 4 => true
  | 5, 6 | 6, 5 => true
  | 5, 7 | 7, 5 => true
  | 5, 12 | 12, 5 => true
  | 5, 13 | 13, 5 => true
  | 6, 7 | 7, 6 => true
  | 6, 12 | 12, 6 => true
  | 6, 13 | 13, 6 => true
  | 7, 12 | 12, 7 => true
  | 7, 13 | 13, 7 => true
  | 8, 9 | 9, 8 => true
  | 8, 10 | 10, 8 => true
  | 8, 11 | 11, 8 => true
  | 8, 12 | 12, 8 => true
  | 8, 13 | 13, 8 => true
  | 9, 10 | 10, 9 => true
  | 9, 11 | 11, 9 => true
  | 9, 12 | 12, 9 => true
  | 9, 13 | 13, 9 => true
  | 10, 11 | 11, 10 => true
  | 10, 12 | 12, 10 => true
  | 10, 13 | 13, 10 => true
  | 11, 12 | 12, 11 => true
  | 11, 13 | 13, 11 => true
  | 12, 13 | 13, 12 => true
  | _, _ => false

structure Geometry (G : SimpleGraph V) [DecidableRel G.Adj] : Prop where
  conn : G.Connected
  even : ∀ i, (EvenFrom G i).card≤6
  high : ∀ i : V, 3≤i.val → 5≤G.degree i
  fixed : ∀ i j, fixedMatrix i j = true → G.Adj i j
  forbidden : ∀ i j, allowedMatrix i j = false → ¬G.Adj i j
  nearA12 : G.Adj (5:V) 12 ∨ G.Adj (6:V) 12 ∨ G.Adj (7:V) 12 ∨ G.Adj (3:V) 12
  nearA13 : G.Adj (5:V) 13 ∨ G.Adj (6:V) 13 ∨ G.Adj (7:V) 13 ∨ G.Adj (3:V) 13
  nearB12 : G.Adj (5:V) 12 ∨ G.Adj (6:V) 12 ∨ G.Adj (7:V) 12 ∨ G.Adj (4:V) 12
  nearB13 : G.Adj (5:V) 13 ∨ G.Adj (6:V) 13 ∨ G.Adj (7:V) 13 ∨ G.Adj (4:V) 13

def val (G : SimpleGraph V) : Sat.Valuation := fun i =>
  match i with
  | 0 => G.Adj (3:V) 4
  | 1 => G.Adj (3:V) 5
  | 2 => G.Adj (3:V) 6
  | 3 => G.Adj (3:V) 7
  | 4 => G.Adj (3:V) 12
  | 5 => G.Adj (3:V) 13
  | 6 => G.Adj (4:V) 5
  | 7 => G.Adj (4:V) 6
  | 8 => G.Adj (4:V) 7
  | 9 => G.Adj (4:V) 12
  | 10 => G.Adj (4:V) 13
  | 11 => G.Adj (5:V) 6
  | 12 => G.Adj (5:V) 7
  | 13 => G.Adj (5:V) 12
  | 14 => G.Adj (5:V) 13
  | 15 => G.Adj (6:V) 7
  | 16 => G.Adj (6:V) 12
  | 17 => G.Adj (6:V) 13
  | 18 => G.Adj (7:V) 12
  | 19 => G.Adj (7:V) 13
  | 20 => G.Adj (8:V) 9
  | 21 => G.Adj (8:V) 10
  | 22 => G.Adj (8:V) 11
  | 23 => G.Adj (8:V) 12
  | 24 => G.Adj (8:V) 13
  | 25 => G.Adj (9:V) 10
  | 26 => G.Adj (9:V) 11
  | 27 => G.Adj (9:V) 12
  | 28 => G.Adj (9:V) 13
  | 29 => G.Adj (10:V) 11
  | 30 => G.Adj (10:V) 12
  | 31 => G.Adj (10:V) 13
  | 32 => G.Adj (11:V) 12
  | 33 => G.Adj (11:V) 13
  | 34 => G.Adj (12:V) 13
  | 35 => G.dist (0:V) 4 = 2
  | 36 => G.dist (0:V) 8 = 2
  | 37 => G.dist (0:V) 9 = 2
  | 38 => G.dist (0:V) 12 = 2
  | 39 => G.dist (0:V) 13 = 2
  | 40 => G.dist (1:V) 3 = 2
  | 41 => G.dist (1:V) 10 = 2
  | 42 => G.dist (1:V) 11 = 2
  | 43 => G.dist (1:V) 12 = 2
  | 44 => G.dist (1:V) 13 = 2
  | 45 => G.dist (2:V) 3 = 2
  | 46 => G.dist (2:V) 4 = 2
  | 47 => G.dist (2:V) 5 = 2
  | 48 => G.dist (2:V) 6 = 2
  | 49 => G.dist (2:V) 7 = 2
  | 50 => G.dist (3:V) 4 = 2
  | 51 => G.dist (3:V) 5 = 2
  | 52 => G.dist (3:V) 6 = 2
  | 53 => G.dist (3:V) 7 = 2
  | 54 => G.dist (3:V) 10 = 2
  | 55 => G.dist (3:V) 11 = 2
  | 56 => G.dist (3:V) 12 = 2
  | 57 => G.dist (3:V) 13 = 2
  | 58 => G.dist (4:V) 5 = 2
  | 59 => G.dist (4:V) 6 = 2
  | 60 => G.dist (4:V) 7 = 2
  | 61 => G.dist (4:V) 8 = 2
  | 62 => G.dist (4:V) 9 = 2
  | 63 => G.dist (4:V) 12 = 2
  | 64 => G.dist (4:V) 13 = 2
  | 65 => G.dist (5:V) 6 = 2
  | 66 => G.dist (5:V) 7 = 2
  | 67 => G.dist (5:V) 8 = 2
  | 68 => G.dist (5:V) 9 = 2
  | 69 => G.dist (5:V) 10 = 2
  | 70 => G.dist (5:V) 11 = 2
  | 71 => G.dist (5:V) 12 = 2
  | 72 => G.dist (5:V) 13 = 2
  | 73 => G.dist (6:V) 7 = 2
  | 74 => G.dist (6:V) 8 = 2
  | 75 => G.dist (6:V) 9 = 2
  | 76 => G.dist (6:V) 10 = 2
  | 77 => G.dist (6:V) 11 = 2
  | 78 => G.dist (6:V) 12 = 2
  | 79 => G.dist (6:V) 13 = 2
  | 80 => G.dist (7:V) 8 = 2
  | 81 => G.dist (7:V) 9 = 2
  | 82 => G.dist (7:V) 10 = 2
  | 83 => G.dist (7:V) 11 = 2
  | 84 => G.dist (7:V) 12 = 2
  | 85 => G.dist (7:V) 13 = 2
  | 86 => G.dist (8:V) 9 = 2
  | 87 => G.dist (8:V) 10 = 2
  | 88 => G.dist (8:V) 11 = 2
  | 89 => G.dist (8:V) 12 = 2
  | 90 => G.dist (8:V) 13 = 2
  | 91 => G.dist (9:V) 10 = 2
  | 92 => G.dist (9:V) 11 = 2
  | 93 => G.dist (9:V) 12 = 2
  | 94 => G.dist (9:V) 13 = 2
  | 95 => G.dist (10:V) 11 = 2
  | 96 => G.dist (10:V) 12 = 2
  | 97 => G.dist (10:V) 13 = 2
  | 98 => G.dist (11:V) 12 = 2
  | 99 => G.dist (11:V) 13 = 2
  | 100 => G.dist (12:V) 13 = 2
  | _ => False


private theorem degree_small_contra (H : Geometry G) (i : V) (hi : 3≤i.val)
    (S : Finset V) (small : S.card≤4) (not_edge : ∀ j, j∉S → ¬G.Adj i j) : False := by
  classical
  have sub : G.neighborFinset i ⊆ S := by
    intro j h
    apply Classical.byContradiction
    intro no
    exact not_edge j no ((mem_neighborFinset G i j).mp h)
  have cap := (card_le_card sub).trans small
  rw [card_neighborFinset_eq_degree] at cap
  have deg := H.high i hi
  omega

private theorem distance_two_from_two_edges (H : Geometry G) (i k j : V)
    (ne : i≠j) (no : ¬G.Adj i j) (u : G.Adj i k) (v : G.Adj k j) : G.dist i j=2 :=
  (mem_filter.mp (d2 H.conn ne no u v)).2

private theorem six_twos_contra (H : Geometry G) (i : V) (S : Finset V)
    (card6 : S.card=6) (off : i∉S) (all : ∀ j∈S, G.dist i j=2) : False := by
  classical
  have s : S⊆PositiveEven G i := by
    intro j jm
    exact mem_positive.mpr ⟨fun k=>off (k ▸ jm),by rw [all j jm]; decide⟩
  have count := (card_le_card s).trans (positive_card (H.even i))
  omega

private theorem sat_0 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 1, .pos 6, .pos 11, .pos 13] := by
  change ¬(G.Adj (3:V) 5) → ¬(G.Adj (4:V) 5) → ¬(G.Adj (5:V) 6) → ¬(G.Adj (5:V) 12) → False
  intro h0 h1 h2 h3
  apply degree_small_contra H 5 (by decide) ({0,1,7,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 5 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (H.forbidden 5 5 (by decide))
  · exact h2
  · exact (hj (by decide)).elim
  · exact (H.forbidden 5 8 (by decide))
  · exact (H.forbidden 5 9 (by decide))
  · exact (H.forbidden 5 10 (by decide))
  · exact (H.forbidden 5 11 (by decide))
  · exact h3
  · exact (hj (by decide)).elim

private theorem sat_1 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 1, .pos 6, .pos 13, .pos 14] := by
  change ¬(G.Adj (3:V) 5) → ¬(G.Adj (4:V) 5) → ¬(G.Adj (5:V) 12) → ¬(G.Adj (5:V) 13) → False
  intro h0 h1 h2 h3
  apply degree_small_contra H 5 (by decide) ({0,1,6,7} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 5 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (H.forbidden 5 5 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 5 8 (by decide))
  · exact (H.forbidden 5 9 (by decide))
  · exact (H.forbidden 5 10 (by decide))
  · exact (H.forbidden 5 11 (by decide))
  · exact h2
  · exact h3

private theorem sat_2 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 1, .pos 11, .pos 13, .pos 14] := by
  change ¬(G.Adj (3:V) 5) → ¬(G.Adj (5:V) 6) → ¬(G.Adj (5:V) 12) → ¬(G.Adj (5:V) 13) → False
  intro h0 h1 h2 h3
  apply degree_small_contra H 5 (by decide) ({0,1,4,7} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 5 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 5 5 (by decide))
  · exact h1
  · exact (hj (by decide)).elim
  · exact (H.forbidden 5 8 (by decide))
  · exact (H.forbidden 5 9 (by decide))
  · exact (H.forbidden 5 10 (by decide))
  · exact (H.forbidden 5 11 (by decide))
  · exact h2
  · exact h3

private theorem sat_3 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 2, .pos 7, .pos 11, .pos 16] := by
  change ¬(G.Adj (3:V) 6) → ¬(G.Adj (4:V) 6) → ¬(G.Adj (5:V) 6) → ¬(G.Adj (6:V) 12) → False
  intro h0 h1 h2 h3
  apply degree_small_contra H 6 (by decide) ({0,1,7,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 6 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (fun z => h2 z.symm)
  · exact (H.forbidden 6 6 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 6 8 (by decide))
  · exact (H.forbidden 6 9 (by decide))
  · exact (H.forbidden 6 10 (by decide))
  · exact (H.forbidden 6 11 (by decide))
  · exact h3
  · exact (hj (by decide)).elim

private theorem sat_4 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 2, .pos 7, .pos 16, .pos 17] := by
  change ¬(G.Adj (3:V) 6) → ¬(G.Adj (4:V) 6) → ¬(G.Adj (6:V) 12) → ¬(G.Adj (6:V) 13) → False
  intro h0 h1 h2 h3
  apply degree_small_contra H 6 (by decide) ({0,1,5,7} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 6 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 6 6 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 6 8 (by decide))
  · exact (H.forbidden 6 9 (by decide))
  · exact (H.forbidden 6 10 (by decide))
  · exact (H.forbidden 6 11 (by decide))
  · exact h2
  · exact h3

private theorem sat_5 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 2, .pos 11, .pos 16, .pos 17] := by
  change ¬(G.Adj (3:V) 6) → ¬(G.Adj (5:V) 6) → ¬(G.Adj (6:V) 12) → ¬(G.Adj (6:V) 13) → False
  intro h0 h1 h2 h3
  apply degree_small_contra H 6 (by decide) ({0,1,4,7} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 6 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (fun z => h1 z.symm)
  · exact (H.forbidden 6 6 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 6 8 (by decide))
  · exact (H.forbidden 6 9 (by decide))
  · exact (H.forbidden 6 10 (by decide))
  · exact (H.forbidden 6 11 (by decide))
  · exact h2
  · exact h3

private theorem sat_6 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 3, .pos 8, .pos 12, .pos 18] := by
  change ¬(G.Adj (3:V) 7) → ¬(G.Adj (4:V) 7) → ¬(G.Adj (5:V) 7) → ¬(G.Adj (7:V) 12) → False
  intro h0 h1 h2 h3
  apply degree_small_contra H 7 (by decide) ({0,1,6,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (fun z => h2 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 7 (by decide))
  · exact (H.forbidden 7 8 (by decide))
  · exact (H.forbidden 7 9 (by decide))
  · exact (H.forbidden 7 10 (by decide))
  · exact (H.forbidden 7 11 (by decide))
  · exact h3
  · exact (hj (by decide)).elim

private theorem sat_7 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 3, .pos 8, .pos 12, .pos 19] := by
  change ¬(G.Adj (3:V) 7) → ¬(G.Adj (4:V) 7) → ¬(G.Adj (5:V) 7) → ¬(G.Adj (7:V) 13) → False
  intro h0 h1 h2 h3
  apply degree_small_contra H 7 (by decide) ({0,1,6,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (fun z => h2 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 7 (by decide))
  · exact (H.forbidden 7 8 (by decide))
  · exact (H.forbidden 7 9 (by decide))
  · exact (H.forbidden 7 10 (by decide))
  · exact (H.forbidden 7 11 (by decide))
  · exact (hj (by decide)).elim
  · exact h3

private theorem sat_8 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 3, .pos 8, .pos 15, .pos 18] := by
  change ¬(G.Adj (3:V) 7) → ¬(G.Adj (4:V) 7) → ¬(G.Adj (6:V) 7) → ¬(G.Adj (7:V) 12) → False
  intro h0 h1 h2 h3
  apply degree_small_contra H 7 (by decide) ({0,1,5,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (fun z => h2 z.symm)
  · exact (H.forbidden 7 7 (by decide))
  · exact (H.forbidden 7 8 (by decide))
  · exact (H.forbidden 7 9 (by decide))
  · exact (H.forbidden 7 10 (by decide))
  · exact (H.forbidden 7 11 (by decide))
  · exact h3
  · exact (hj (by decide)).elim

private theorem sat_9 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 3, .pos 8, .pos 18, .pos 19] := by
  change ¬(G.Adj (3:V) 7) → ¬(G.Adj (4:V) 7) → ¬(G.Adj (7:V) 12) → ¬(G.Adj (7:V) 13) → False
  intro h0 h1 h2 h3
  apply degree_small_contra H 7 (by decide) ({0,1,5,6} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 7 (by decide))
  · exact (H.forbidden 7 8 (by decide))
  · exact (H.forbidden 7 9 (by decide))
  · exact (H.forbidden 7 10 (by decide))
  · exact (H.forbidden 7 11 (by decide))
  · exact h2
  · exact h3

private theorem sat_10 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 3, .pos 12, .pos 15, .pos 19] := by
  change ¬(G.Adj (3:V) 7) → ¬(G.Adj (5:V) 7) → ¬(G.Adj (6:V) 7) → ¬(G.Adj (7:V) 13) → False
  intro h0 h1 h2 h3
  apply degree_small_contra H 7 (by decide) ({0,1,4,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (fun z => h1 z.symm)
  · exact (fun z => h2 z.symm)
  · exact (H.forbidden 7 7 (by decide))
  · exact (H.forbidden 7 8 (by decide))
  · exact (H.forbidden 7 9 (by decide))
  · exact (H.forbidden 7 10 (by decide))
  · exact (H.forbidden 7 11 (by decide))
  · exact (hj (by decide)).elim
  · exact h3

private theorem sat_11 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 8, .pos 12, .pos 18, .pos 19] := by
  change ¬(G.Adj (4:V) 7) → ¬(G.Adj (5:V) 7) → ¬(G.Adj (7:V) 12) → ¬(G.Adj (7:V) 13) → False
  intro h0 h1 h2 h3
  apply degree_small_contra H 7 (by decide) ({0,1,3,6} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 7 (by decide))
  · exact (H.forbidden 7 8 (by decide))
  · exact (H.forbidden 7 9 (by decide))
  · exact (H.forbidden 7 10 (by decide))
  · exact (H.forbidden 7 11 (by decide))
  · exact h2
  · exact h3

private theorem sat_12 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 8, .pos 15, .pos 18, .pos 19] := by
  change ¬(G.Adj (4:V) 7) → ¬(G.Adj (6:V) 7) → ¬(G.Adj (7:V) 12) → ¬(G.Adj (7:V) 13) → False
  intro h0 h1 h2 h3
  apply degree_small_contra H 7 (by decide) ({0,1,3,5} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 7 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (fun z => h1 z.symm)
  · exact (H.forbidden 7 7 (by decide))
  · exact (H.forbidden 7 8 (by decide))
  · exact (H.forbidden 7 9 (by decide))
  · exact (H.forbidden 7 10 (by decide))
  · exact (H.forbidden 7 11 (by decide))
  · exact h2
  · exact h3

private theorem sat_13 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 20, .pos 21] := by
  change ¬(G.Adj (8:V) 9) → ¬(G.Adj (8:V) 10) → False
  intro h0 h1
  apply degree_small_contra H 8 (by decide) ({3,11,12,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 8 0 (by decide))
  · exact (H.forbidden 8 1 (by decide))
  · exact (H.forbidden 8 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 8 4 (by decide))
  · exact (H.forbidden 8 5 (by decide))
  · exact (H.forbidden 8 6 (by decide))
  · exact (H.forbidden 8 7 (by decide))
  · exact (H.forbidden 8 8 (by decide))
  · exact h0
  · exact h1
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim

private theorem sat_14 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 20, .pos 22] := by
  change ¬(G.Adj (8:V) 9) → ¬(G.Adj (8:V) 11) → False
  intro h0 h1
  apply degree_small_contra H 8 (by decide) ({3,10,12,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 8 0 (by decide))
  · exact (H.forbidden 8 1 (by decide))
  · exact (H.forbidden 8 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 8 4 (by decide))
  · exact (H.forbidden 8 5 (by decide))
  · exact (H.forbidden 8 6 (by decide))
  · exact (H.forbidden 8 7 (by decide))
  · exact (H.forbidden 8 8 (by decide))
  · exact h0
  · exact (hj (by decide)).elim
  · exact h1
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim

private theorem sat_15 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 20, .pos 23] := by
  change ¬(G.Adj (8:V) 9) → ¬(G.Adj (8:V) 12) → False
  intro h0 h1
  apply degree_small_contra H 8 (by decide) ({3,10,11,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 8 0 (by decide))
  · exact (H.forbidden 8 1 (by decide))
  · exact (H.forbidden 8 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 8 4 (by decide))
  · exact (H.forbidden 8 5 (by decide))
  · exact (H.forbidden 8 6 (by decide))
  · exact (H.forbidden 8 7 (by decide))
  · exact (H.forbidden 8 8 (by decide))
  · exact h0
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h1
  · exact (hj (by decide)).elim

private theorem sat_16 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 20, .pos 24] := by
  change ¬(G.Adj (8:V) 9) → ¬(G.Adj (8:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 8 (by decide) ({3,10,11,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 8 0 (by decide))
  · exact (H.forbidden 8 1 (by decide))
  · exact (H.forbidden 8 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 8 4 (by decide))
  · exact (H.forbidden 8 5 (by decide))
  · exact (H.forbidden 8 6 (by decide))
  · exact (H.forbidden 8 7 (by decide))
  · exact (H.forbidden 8 8 (by decide))
  · exact h0
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h1

private theorem sat_17 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 21, .pos 22] := by
  change ¬(G.Adj (8:V) 10) → ¬(G.Adj (8:V) 11) → False
  intro h0 h1
  apply degree_small_contra H 8 (by decide) ({3,9,12,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 8 0 (by decide))
  · exact (H.forbidden 8 1 (by decide))
  · exact (H.forbidden 8 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 8 4 (by decide))
  · exact (H.forbidden 8 5 (by decide))
  · exact (H.forbidden 8 6 (by decide))
  · exact (H.forbidden 8 7 (by decide))
  · exact (H.forbidden 8 8 (by decide))
  · exact (hj (by decide)).elim
  · exact h0
  · exact h1
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim

private theorem sat_18 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 21, .pos 23] := by
  change ¬(G.Adj (8:V) 10) → ¬(G.Adj (8:V) 12) → False
  intro h0 h1
  apply degree_small_contra H 8 (by decide) ({3,9,11,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 8 0 (by decide))
  · exact (H.forbidden 8 1 (by decide))
  · exact (H.forbidden 8 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 8 4 (by decide))
  · exact (H.forbidden 8 5 (by decide))
  · exact (H.forbidden 8 6 (by decide))
  · exact (H.forbidden 8 7 (by decide))
  · exact (H.forbidden 8 8 (by decide))
  · exact (hj (by decide)).elim
  · exact h0
  · exact (hj (by decide)).elim
  · exact h1
  · exact (hj (by decide)).elim

private theorem sat_19 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 21, .pos 24] := by
  change ¬(G.Adj (8:V) 10) → ¬(G.Adj (8:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 8 (by decide) ({3,9,11,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 8 0 (by decide))
  · exact (H.forbidden 8 1 (by decide))
  · exact (H.forbidden 8 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 8 4 (by decide))
  · exact (H.forbidden 8 5 (by decide))
  · exact (H.forbidden 8 6 (by decide))
  · exact (H.forbidden 8 7 (by decide))
  · exact (H.forbidden 8 8 (by decide))
  · exact (hj (by decide)).elim
  · exact h0
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h1

private theorem sat_20 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 22, .pos 23] := by
  change ¬(G.Adj (8:V) 11) → ¬(G.Adj (8:V) 12) → False
  intro h0 h1
  apply degree_small_contra H 8 (by decide) ({3,9,10,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 8 0 (by decide))
  · exact (H.forbidden 8 1 (by decide))
  · exact (H.forbidden 8 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 8 4 (by decide))
  · exact (H.forbidden 8 5 (by decide))
  · exact (H.forbidden 8 6 (by decide))
  · exact (H.forbidden 8 7 (by decide))
  · exact (H.forbidden 8 8 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h0
  · exact h1
  · exact (hj (by decide)).elim

private theorem sat_21 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 22, .pos 24] := by
  change ¬(G.Adj (8:V) 11) → ¬(G.Adj (8:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 8 (by decide) ({3,9,10,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 8 0 (by decide))
  · exact (H.forbidden 8 1 (by decide))
  · exact (H.forbidden 8 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 8 4 (by decide))
  · exact (H.forbidden 8 5 (by decide))
  · exact (H.forbidden 8 6 (by decide))
  · exact (H.forbidden 8 7 (by decide))
  · exact (H.forbidden 8 8 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h0
  · exact (hj (by decide)).elim
  · exact h1

private theorem sat_22 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 23, .pos 24] := by
  change ¬(G.Adj (8:V) 12) → ¬(G.Adj (8:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 8 (by decide) ({3,9,10,11} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 8 0 (by decide))
  · exact (H.forbidden 8 1 (by decide))
  · exact (H.forbidden 8 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 8 4 (by decide))
  · exact (H.forbidden 8 5 (by decide))
  · exact (H.forbidden 8 6 (by decide))
  · exact (H.forbidden 8 7 (by decide))
  · exact (H.forbidden 8 8 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h0
  · exact h1

private theorem sat_23 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 20, .pos 25] := by
  change ¬(G.Adj (8:V) 9) → ¬(G.Adj (9:V) 10) → False
  intro h0 h1
  apply degree_small_contra H 9 (by decide) ({3,11,12,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 9 0 (by decide))
  · exact (H.forbidden 9 1 (by decide))
  · exact (H.forbidden 9 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 4 (by decide))
  · exact (H.forbidden 9 5 (by decide))
  · exact (H.forbidden 9 6 (by decide))
  · exact (H.forbidden 9 7 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 9 9 (by decide))
  · exact h1
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim

private theorem sat_24 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 20, .pos 26] := by
  change ¬(G.Adj (8:V) 9) → ¬(G.Adj (9:V) 11) → False
  intro h0 h1
  apply degree_small_contra H 9 (by decide) ({3,10,12,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 9 0 (by decide))
  · exact (H.forbidden 9 1 (by decide))
  · exact (H.forbidden 9 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 4 (by decide))
  · exact (H.forbidden 9 5 (by decide))
  · exact (H.forbidden 9 6 (by decide))
  · exact (H.forbidden 9 7 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 9 9 (by decide))
  · exact (hj (by decide)).elim
  · exact h1
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim

private theorem sat_25 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 20, .pos 27] := by
  change ¬(G.Adj (8:V) 9) → ¬(G.Adj (9:V) 12) → False
  intro h0 h1
  apply degree_small_contra H 9 (by decide) ({3,10,11,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 9 0 (by decide))
  · exact (H.forbidden 9 1 (by decide))
  · exact (H.forbidden 9 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 4 (by decide))
  · exact (H.forbidden 9 5 (by decide))
  · exact (H.forbidden 9 6 (by decide))
  · exact (H.forbidden 9 7 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 9 9 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h1
  · exact (hj (by decide)).elim

private theorem sat_26 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 20, .pos 28] := by
  change ¬(G.Adj (8:V) 9) → ¬(G.Adj (9:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 9 (by decide) ({3,10,11,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 9 0 (by decide))
  · exact (H.forbidden 9 1 (by decide))
  · exact (H.forbidden 9 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 4 (by decide))
  · exact (H.forbidden 9 5 (by decide))
  · exact (H.forbidden 9 6 (by decide))
  · exact (H.forbidden 9 7 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 9 9 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h1

private theorem sat_27 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 25, .pos 26] := by
  change ¬(G.Adj (9:V) 10) → ¬(G.Adj (9:V) 11) → False
  intro h0 h1
  apply degree_small_contra H 9 (by decide) ({3,8,12,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 9 0 (by decide))
  · exact (H.forbidden 9 1 (by decide))
  · exact (H.forbidden 9 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 4 (by decide))
  · exact (H.forbidden 9 5 (by decide))
  · exact (H.forbidden 9 6 (by decide))
  · exact (H.forbidden 9 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 9 (by decide))
  · exact h0
  · exact h1
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim

private theorem sat_28 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 25, .pos 27] := by
  change ¬(G.Adj (9:V) 10) → ¬(G.Adj (9:V) 12) → False
  intro h0 h1
  apply degree_small_contra H 9 (by decide) ({3,8,11,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 9 0 (by decide))
  · exact (H.forbidden 9 1 (by decide))
  · exact (H.forbidden 9 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 4 (by decide))
  · exact (H.forbidden 9 5 (by decide))
  · exact (H.forbidden 9 6 (by decide))
  · exact (H.forbidden 9 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 9 (by decide))
  · exact h0
  · exact (hj (by decide)).elim
  · exact h1
  · exact (hj (by decide)).elim

private theorem sat_29 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 25, .pos 28] := by
  change ¬(G.Adj (9:V) 10) → ¬(G.Adj (9:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 9 (by decide) ({3,8,11,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 9 0 (by decide))
  · exact (H.forbidden 9 1 (by decide))
  · exact (H.forbidden 9 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 4 (by decide))
  · exact (H.forbidden 9 5 (by decide))
  · exact (H.forbidden 9 6 (by decide))
  · exact (H.forbidden 9 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 9 (by decide))
  · exact h0
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h1

private theorem sat_30 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 26, .pos 27] := by
  change ¬(G.Adj (9:V) 11) → ¬(G.Adj (9:V) 12) → False
  intro h0 h1
  apply degree_small_contra H 9 (by decide) ({3,8,10,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 9 0 (by decide))
  · exact (H.forbidden 9 1 (by decide))
  · exact (H.forbidden 9 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 4 (by decide))
  · exact (H.forbidden 9 5 (by decide))
  · exact (H.forbidden 9 6 (by decide))
  · exact (H.forbidden 9 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 9 (by decide))
  · exact (hj (by decide)).elim
  · exact h0
  · exact h1
  · exact (hj (by decide)).elim

private theorem sat_31 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 26, .pos 28] := by
  change ¬(G.Adj (9:V) 11) → ¬(G.Adj (9:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 9 (by decide) ({3,8,10,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 9 0 (by decide))
  · exact (H.forbidden 9 1 (by decide))
  · exact (H.forbidden 9 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 4 (by decide))
  · exact (H.forbidden 9 5 (by decide))
  · exact (H.forbidden 9 6 (by decide))
  · exact (H.forbidden 9 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 9 (by decide))
  · exact (hj (by decide)).elim
  · exact h0
  · exact (hj (by decide)).elim
  · exact h1

private theorem sat_32 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 27, .pos 28] := by
  change ¬(G.Adj (9:V) 12) → ¬(G.Adj (9:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 9 (by decide) ({3,8,10,11} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 9 0 (by decide))
  · exact (H.forbidden 9 1 (by decide))
  · exact (H.forbidden 9 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 4 (by decide))
  · exact (H.forbidden 9 5 (by decide))
  · exact (H.forbidden 9 6 (by decide))
  · exact (H.forbidden 9 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 9 9 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h0
  · exact h1

private theorem sat_33 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 21, .pos 25] := by
  change ¬(G.Adj (8:V) 10) → ¬(G.Adj (9:V) 10) → False
  intro h0 h1
  apply degree_small_contra H 10 (by decide) ({4,11,12,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 5 (by decide))
  · exact (H.forbidden 10 6 (by decide))
  · exact (H.forbidden 10 7 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (H.forbidden 10 10 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim

private theorem sat_34 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 21, .pos 29] := by
  change ¬(G.Adj (8:V) 10) → ¬(G.Adj (10:V) 11) → False
  intro h0 h1
  apply degree_small_contra H 10 (by decide) ({4,9,12,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 5 (by decide))
  · exact (H.forbidden 10 6 (by decide))
  · exact (H.forbidden 10 7 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 10 (by decide))
  · exact h1
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim

private theorem sat_35 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 21, .pos 30] := by
  change ¬(G.Adj (8:V) 10) → ¬(G.Adj (10:V) 12) → False
  intro h0 h1
  apply degree_small_contra H 10 (by decide) ({4,9,11,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 5 (by decide))
  · exact (H.forbidden 10 6 (by decide))
  · exact (H.forbidden 10 7 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 10 (by decide))
  · exact (hj (by decide)).elim
  · exact h1
  · exact (hj (by decide)).elim

private theorem sat_36 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 21, .pos 31] := by
  change ¬(G.Adj (8:V) 10) → ¬(G.Adj (10:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 10 (by decide) ({4,9,11,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 5 (by decide))
  · exact (H.forbidden 10 6 (by decide))
  · exact (H.forbidden 10 7 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 10 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h1

private theorem sat_37 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 25, .pos 30] := by
  change ¬(G.Adj (9:V) 10) → ¬(G.Adj (10:V) 12) → False
  intro h0 h1
  apply degree_small_contra H 10 (by decide) ({4,8,11,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 5 (by decide))
  · exact (H.forbidden 10 6 (by decide))
  · exact (H.forbidden 10 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 10 10 (by decide))
  · exact (hj (by decide)).elim
  · exact h1
  · exact (hj (by decide)).elim

private theorem sat_38 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 25, .pos 31] := by
  change ¬(G.Adj (9:V) 10) → ¬(G.Adj (10:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 10 (by decide) ({4,8,11,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 5 (by decide))
  · exact (H.forbidden 10 6 (by decide))
  · exact (H.forbidden 10 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 10 10 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact h1

private theorem sat_39 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 29, .pos 30] := by
  change ¬(G.Adj (10:V) 11) → ¬(G.Adj (10:V) 12) → False
  intro h0 h1
  apply degree_small_contra H 10 (by decide) ({4,8,9,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 5 (by decide))
  · exact (H.forbidden 10 6 (by decide))
  · exact (H.forbidden 10 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 10 (by decide))
  · exact h0
  · exact h1
  · exact (hj (by decide)).elim

private theorem sat_40 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 29, .pos 31] := by
  change ¬(G.Adj (10:V) 11) → ¬(G.Adj (10:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 10 (by decide) ({4,8,9,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 5 (by decide))
  · exact (H.forbidden 10 6 (by decide))
  · exact (H.forbidden 10 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 10 (by decide))
  · exact h0
  · exact (hj (by decide)).elim
  · exact h1

private theorem sat_41 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 30, .pos 31] := by
  change ¬(G.Adj (10:V) 12) → ¬(G.Adj (10:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 10 (by decide) ({4,8,9,11} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 10 0 (by decide))
  · exact (H.forbidden 10 1 (by decide))
  · exact (H.forbidden 10 2 (by decide))
  · exact (H.forbidden 10 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 5 (by decide))
  · exact (H.forbidden 10 6 (by decide))
  · exact (H.forbidden 10 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 10 10 (by decide))
  · exact (hj (by decide)).elim
  · exact h0
  · exact h1

private theorem sat_42 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 22, .pos 26] := by
  change ¬(G.Adj (8:V) 11) → ¬(G.Adj (9:V) 11) → False
  intro h0 h1
  apply degree_small_contra H 11 (by decide) ({4,10,12,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 11 0 (by decide))
  · exact (H.forbidden 11 1 (by decide))
  · exact (H.forbidden 11 2 (by decide))
  · exact (H.forbidden 11 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 11 5 (by decide))
  · exact (H.forbidden 11 6 (by decide))
  · exact (H.forbidden 11 7 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 11 11 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim

private theorem sat_43 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 22, .pos 32] := by
  change ¬(G.Adj (8:V) 11) → ¬(G.Adj (11:V) 12) → False
  intro h0 h1
  apply degree_small_contra H 11 (by decide) ({4,9,10,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 11 0 (by decide))
  · exact (H.forbidden 11 1 (by decide))
  · exact (H.forbidden 11 2 (by decide))
  · exact (H.forbidden 11 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 11 5 (by decide))
  · exact (H.forbidden 11 6 (by decide))
  · exact (H.forbidden 11 7 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 11 11 (by decide))
  · exact h1
  · exact (hj (by decide)).elim

private theorem sat_44 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 22, .pos 33] := by
  change ¬(G.Adj (8:V) 11) → ¬(G.Adj (11:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 11 (by decide) ({4,9,10,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 11 0 (by decide))
  · exact (H.forbidden 11 1 (by decide))
  · exact (H.forbidden 11 2 (by decide))
  · exact (H.forbidden 11 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 11 5 (by decide))
  · exact (H.forbidden 11 6 (by decide))
  · exact (H.forbidden 11 7 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 11 11 (by decide))
  · exact (hj (by decide)).elim
  · exact h1

private theorem sat_45 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 26, .pos 29] := by
  change ¬(G.Adj (9:V) 11) → ¬(G.Adj (10:V) 11) → False
  intro h0 h1
  apply degree_small_contra H 11 (by decide) ({4,8,12,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 11 0 (by decide))
  · exact (H.forbidden 11 1 (by decide))
  · exact (H.forbidden 11 2 (by decide))
  · exact (H.forbidden 11 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 11 5 (by decide))
  · exact (H.forbidden 11 6 (by decide))
  · exact (H.forbidden 11 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (H.forbidden 11 11 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim

private theorem sat_46 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 26, .pos 32] := by
  change ¬(G.Adj (9:V) 11) → ¬(G.Adj (11:V) 12) → False
  intro h0 h1
  apply degree_small_contra H 11 (by decide) ({4,8,10,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 11 0 (by decide))
  · exact (H.forbidden 11 1 (by decide))
  · exact (H.forbidden 11 2 (by decide))
  · exact (H.forbidden 11 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 11 5 (by decide))
  · exact (H.forbidden 11 6 (by decide))
  · exact (H.forbidden 11 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 11 11 (by decide))
  · exact h1
  · exact (hj (by decide)).elim

private theorem sat_47 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 26, .pos 33] := by
  change ¬(G.Adj (9:V) 11) → ¬(G.Adj (11:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 11 (by decide) ({4,8,10,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 11 0 (by decide))
  · exact (H.forbidden 11 1 (by decide))
  · exact (H.forbidden 11 2 (by decide))
  · exact (H.forbidden 11 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 11 5 (by decide))
  · exact (H.forbidden 11 6 (by decide))
  · exact (H.forbidden 11 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (H.forbidden 11 11 (by decide))
  · exact (hj (by decide)).elim
  · exact h1

private theorem sat_48 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 29, .pos 32] := by
  change ¬(G.Adj (10:V) 11) → ¬(G.Adj (11:V) 12) → False
  intro h0 h1
  apply degree_small_contra H 11 (by decide) ({4,8,9,13} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 11 0 (by decide))
  · exact (H.forbidden 11 1 (by decide))
  · exact (H.forbidden 11 2 (by decide))
  · exact (H.forbidden 11 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 11 5 (by decide))
  · exact (H.forbidden 11 6 (by decide))
  · exact (H.forbidden 11 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 11 11 (by decide))
  · exact h1
  · exact (hj (by decide)).elim

private theorem sat_49 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 29, .pos 33] := by
  change ¬(G.Adj (10:V) 11) → ¬(G.Adj (11:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 11 (by decide) ({4,8,9,12} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 11 0 (by decide))
  · exact (H.forbidden 11 1 (by decide))
  · exact (H.forbidden 11 2 (by decide))
  · exact (H.forbidden 11 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 11 5 (by decide))
  · exact (H.forbidden 11 6 (by decide))
  · exact (H.forbidden 11 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (H.forbidden 11 11 (by decide))
  · exact (hj (by decide)).elim
  · exact h1

private theorem sat_50 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 32, .pos 33] := by
  change ¬(G.Adj (11:V) 12) → ¬(G.Adj (11:V) 13) → False
  intro h0 h1
  apply degree_small_contra H 11 (by decide) ({4,8,9,10} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 11 0 (by decide))
  · exact (H.forbidden 11 1 (by decide))
  · exact (H.forbidden 11 2 (by decide))
  · exact (H.forbidden 11 3 (by decide))
  · exact (hj (by decide)).elim
  · exact (H.forbidden 11 5 (by decide))
  · exact (H.forbidden 11 6 (by decide))
  · exact (H.forbidden 11 7 (by decide))
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (H.forbidden 11 11 (by decide))
  · exact h0
  · exact h1

private theorem sat_51 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 4, .pos 23, .pos 27, .pos 30, .pos 32, .pos 34] := by
  change ¬(G.Adj (3:V) 12) → ¬(G.Adj (8:V) 12) → ¬(G.Adj (9:V) 12) → ¬(G.Adj (10:V) 12) → ¬(G.Adj (11:V) 12) → ¬(G.Adj (12:V) 13) → False
  intro h0 h1 h2 h3 h4 h5
  apply degree_small_contra H 12 (by decide) ({4,5,6,7} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 12 0 (by decide))
  · exact (H.forbidden 12 1 (by decide))
  · exact (H.forbidden 12 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (fun z => h1 z.symm)
  · exact (fun z => h2 z.symm)
  · exact (fun z => h3 z.symm)
  · exact (fun z => h4 z.symm)
  · exact (H.forbidden 12 12 (by decide))
  · exact h5

private theorem sat_52 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 9, .pos 13, .pos 16, .pos 30, .pos 32, .pos 34] := by
  change ¬(G.Adj (4:V) 12) → ¬(G.Adj (5:V) 12) → ¬(G.Adj (6:V) 12) → ¬(G.Adj (10:V) 12) → ¬(G.Adj (11:V) 12) → ¬(G.Adj (12:V) 13) → False
  intro h0 h1 h2 h3 h4 h5
  apply degree_small_contra H 12 (by decide) ({3,7,8,9} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 12 0 (by decide))
  · exact (H.forbidden 12 1 (by decide))
  · exact (H.forbidden 12 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (fun z => h2 z.symm)
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (fun z => h3 z.symm)
  · exact (fun z => h4 z.symm)
  · exact (H.forbidden 12 12 (by decide))
  · exact h5

private theorem sat_53 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 9, .pos 23, .pos 27, .pos 30, .pos 32, .pos 34] := by
  change ¬(G.Adj (4:V) 12) → ¬(G.Adj (8:V) 12) → ¬(G.Adj (9:V) 12) → ¬(G.Adj (10:V) 12) → ¬(G.Adj (11:V) 12) → ¬(G.Adj (12:V) 13) → False
  intro h0 h1 h2 h3 h4 h5
  apply degree_small_contra H 12 (by decide) ({3,5,6,7} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 12 0 (by decide))
  · exact (H.forbidden 12 1 (by decide))
  · exact (H.forbidden 12 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (fun z => h1 z.symm)
  · exact (fun z => h2 z.symm)
  · exact (fun z => h3 z.symm)
  · exact (fun z => h4 z.symm)
  · exact (H.forbidden 12 12 (by decide))
  · exact h5

private theorem sat_54 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 5, .pos 24, .pos 28, .pos 31, .pos 33, .pos 34] := by
  change ¬(G.Adj (3:V) 13) → ¬(G.Adj (8:V) 13) → ¬(G.Adj (9:V) 13) → ¬(G.Adj (10:V) 13) → ¬(G.Adj (11:V) 13) → ¬(G.Adj (12:V) 13) → False
  intro h0 h1 h2 h3 h4 h5
  apply degree_small_contra H 13 (by decide) ({4,5,6,7} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 13 0 (by decide))
  · exact (H.forbidden 13 1 (by decide))
  · exact (H.forbidden 13 2 (by decide))
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (fun z => h1 z.symm)
  · exact (fun z => h2 z.symm)
  · exact (fun z => h3 z.symm)
  · exact (fun z => h4 z.symm)
  · exact (fun z => h5 z.symm)
  · exact (H.forbidden 13 13 (by decide))

private theorem sat_55 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 10, .pos 14, .pos 17, .pos 31, .pos 33, .pos 34] := by
  change ¬(G.Adj (4:V) 13) → ¬(G.Adj (5:V) 13) → ¬(G.Adj (6:V) 13) → ¬(G.Adj (10:V) 13) → ¬(G.Adj (11:V) 13) → ¬(G.Adj (12:V) 13) → False
  intro h0 h1 h2 h3 h4 h5
  apply degree_small_contra H 13 (by decide) ({3,7,8,9} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 13 0 (by decide))
  · exact (H.forbidden 13 1 (by decide))
  · exact (H.forbidden 13 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (fun z => h1 z.symm)
  · exact (fun z => h2 z.symm)
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (fun z => h3 z.symm)
  · exact (fun z => h4 z.symm)
  · exact (fun z => h5 z.symm)
  · exact (H.forbidden 13 13 (by decide))

private theorem sat_56 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 10, .pos 24, .pos 28, .pos 31, .pos 33, .pos 34] := by
  change ¬(G.Adj (4:V) 13) → ¬(G.Adj (8:V) 13) → ¬(G.Adj (9:V) 13) → ¬(G.Adj (10:V) 13) → ¬(G.Adj (11:V) 13) → ¬(G.Adj (12:V) 13) → False
  intro h0 h1 h2 h3 h4 h5
  apply degree_small_contra H 13 (by decide) ({3,5,6,7} : Finset V) (by decide)
  intro j hj
  fin_cases j
  · exact (H.forbidden 13 0 (by decide))
  · exact (H.forbidden 13 1 (by decide))
  · exact (H.forbidden 13 2 (by decide))
  · exact (hj (by decide)).elim
  · exact (fun z => h0 z.symm)
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (hj (by decide)).elim
  · exact (fun z => h1 z.symm)
  · exact (fun z => h2 z.symm)
  · exact (fun z => h3 z.symm)
  · exact (fun z => h4 z.symm)
  · exact (fun z => h5 z.symm)
  · exact (H.forbidden 13 13 (by decide))

private theorem sat_57 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 4, .pos 13, .pos 16, .pos 18] := by
  change ¬(G.Adj (3:V) 12) → ¬(G.Adj (5:V) 12) → ¬(G.Adj (6:V) 12) → ¬(G.Adj (7:V) 12) → False
  intro h0 h1 h2 h3
  have k := H.nearA12
  tauto

private theorem sat_58 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 9, .pos 13, .pos 16, .pos 18] := by
  change ¬(G.Adj (4:V) 12) → ¬(G.Adj (5:V) 12) → ¬(G.Adj (6:V) 12) → ¬(G.Adj (7:V) 12) → False
  intro h0 h1 h2 h3
  have k := H.nearB12
  tauto

private theorem sat_59 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 5, .pos 14, .pos 17, .pos 19] := by
  change ¬(G.Adj (3:V) 13) → ¬(G.Adj (5:V) 13) → ¬(G.Adj (6:V) 13) → ¬(G.Adj (7:V) 13) → False
  intro h0 h1 h2 h3
  have k := H.nearA13
  tauto

private theorem sat_60 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 10, .pos 14, .pos 17, .pos 19] := by
  change ¬(G.Adj (4:V) 13) → ¬(G.Adj (5:V) 13) → ¬(G.Adj (6:V) 13) → ¬(G.Adj (7:V) 13) → False
  intro h0 h1 h2 h3
  have k := H.nearB13
  tauto

private theorem sat_61 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 35] := by
  change ¬(G.dist (0:V) 4 = 2) → False
  intro h0
  exact h0 (distance_two_from_two_edges H 0 1 4 (by decide) (H.forbidden 0 4 (by decide)) (H.fixed 0 1 (by decide)) (H.fixed 1 4 (by decide)))

private theorem sat_62 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 36] := by
  change ¬(G.dist (0:V) 8 = 2) → False
  intro h0
  exact h0 (distance_two_from_two_edges H 0 3 8 (by decide) (H.forbidden 0 8 (by decide)) (H.fixed 0 3 (by decide)) (H.fixed 3 8 (by decide)))

private theorem sat_63 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 37] := by
  change ¬(G.dist (0:V) 9 = 2) → False
  intro h0
  exact h0 (distance_two_from_two_edges H 0 3 9 (by decide) (H.forbidden 0 9 (by decide)) (H.fixed 0 3 (by decide)) (H.fixed 3 9 (by decide)))

private theorem sat_64 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 18, .pos 38] := by
  change (G.Adj (7:V) 12) → ¬(G.dist (0:V) 12 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 0 7 12 (by decide) (H.forbidden 0 12 (by decide)) (H.fixed 0 7 (by decide)) h0)

private theorem sat_65 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 5, .pos 39] := by
  change (G.Adj (3:V) 13) → ¬(G.dist (0:V) 13 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 0 3 13 (by decide) (H.forbidden 0 13 (by decide)) (H.fixed 0 3 (by decide)) h0)

private theorem sat_66 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 14, .pos 39] := by
  change (G.Adj (5:V) 13) → ¬(G.dist (0:V) 13 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 0 5 13 (by decide) (H.forbidden 0 13 (by decide)) (H.fixed 0 5 (by decide)) h0)

private theorem sat_67 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 19, .pos 39] := by
  change (G.Adj (7:V) 13) → ¬(G.dist (0:V) 13 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 0 7 13 (by decide) (H.forbidden 0 13 (by decide)) (H.fixed 0 7 (by decide)) h0)

private theorem sat_68 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 40] := by
  change ¬(G.dist (1:V) 3 = 2) → False
  intro h0
  exact h0 (distance_two_from_two_edges H 1 0 3 (by decide) (H.forbidden 1 3 (by decide)) (H.fixed 1 0 (by decide)) (H.fixed 0 3 (by decide)))

private theorem sat_69 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 41] := by
  change ¬(G.dist (1:V) 10 = 2) → False
  intro h0
  exact h0 (distance_two_from_two_edges H 1 4 10 (by decide) (H.forbidden 1 10 (by decide)) (H.fixed 1 4 (by decide)) (H.fixed 4 10 (by decide)))

private theorem sat_70 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 42] := by
  change ¬(G.dist (1:V) 11 = 2) → False
  intro h0
  exact h0 (distance_two_from_two_edges H 1 4 11 (by decide) (H.forbidden 1 11 (by decide)) (H.fixed 1 4 (by decide)) (H.fixed 4 11 (by decide)))

private theorem sat_71 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 18, .pos 43] := by
  change (G.Adj (7:V) 12) → ¬(G.dist (1:V) 12 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 1 7 12 (by decide) (H.forbidden 1 12 (by decide)) (H.fixed 1 7 (by decide)) h0)

private theorem sat_72 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 10, .pos 44] := by
  change (G.Adj (4:V) 13) → ¬(G.dist (1:V) 13 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 1 4 13 (by decide) (H.forbidden 1 13 (by decide)) (H.fixed 1 4 (by decide)) h0)

private theorem sat_73 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 19, .pos 44] := by
  change (G.Adj (7:V) 13) → ¬(G.dist (1:V) 13 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 1 7 13 (by decide) (H.forbidden 1 13 (by decide)) (H.fixed 1 7 (by decide)) h0)

private theorem sat_74 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 45] := by
  change ¬(G.dist (2:V) 3 = 2) → False
  intro h0
  exact h0 (distance_two_from_two_edges H 2 0 3 (by decide) (H.forbidden 2 3 (by decide)) (H.fixed 2 0 (by decide)) (H.fixed 0 3 (by decide)))

private theorem sat_75 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 46] := by
  change ¬(G.dist (2:V) 4 = 2) → False
  intro h0
  exact h0 (distance_two_from_two_edges H 2 1 4 (by decide) (H.forbidden 2 4 (by decide)) (H.fixed 2 1 (by decide)) (H.fixed 1 4 (by decide)))

private theorem sat_76 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 47] := by
  change ¬(G.dist (2:V) 5 = 2) → False
  intro h0
  exact h0 (distance_two_from_two_edges H 2 0 5 (by decide) (H.forbidden 2 5 (by decide)) (H.fixed 2 0 (by decide)) (H.fixed 0 5 (by decide)))

private theorem sat_77 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 48] := by
  change ¬(G.dist (2:V) 6 = 2) → False
  intro h0
  exact h0 (distance_two_from_two_edges H 2 0 6 (by decide) (H.forbidden 2 6 (by decide)) (H.fixed 2 0 (by decide)) (H.fixed 0 6 (by decide)))

private theorem sat_78 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 49] := by
  change ¬(G.dist (2:V) 7 = 2) → False
  intro h0
  exact h0 (distance_two_from_two_edges H 2 0 7 (by decide) (H.forbidden 2 7 (by decide)) (H.fixed 2 0 (by decide)) (H.fixed 0 7 (by decide)))

private theorem sat_79 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 0, .neg 1, .neg 6, .pos 50] := by
  change ¬(G.Adj (3:V) 4) → (G.Adj (3:V) 5) → (G.Adj (4:V) 5) → ¬(G.dist (3:V) 4 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 3 5 4 (by decide) h0 h1 h2.symm)

private theorem sat_80 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 0, .neg 2, .neg 7, .pos 50] := by
  change ¬(G.Adj (3:V) 4) → (G.Adj (3:V) 6) → (G.Adj (4:V) 6) → ¬(G.dist (3:V) 4 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 3 6 4 (by decide) h0 h1 h2.symm)

private theorem sat_81 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 0, .neg 3, .neg 8, .pos 50] := by
  change ¬(G.Adj (3:V) 4) → (G.Adj (3:V) 7) → (G.Adj (4:V) 7) → ¬(G.dist (3:V) 4 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 3 7 4 (by decide) h0 h1 h2.symm)

private theorem sat_82 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 0, .neg 4, .neg 9, .pos 50] := by
  change ¬(G.Adj (3:V) 4) → (G.Adj (3:V) 12) → (G.Adj (4:V) 12) → ¬(G.dist (3:V) 4 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 3 12 4 (by decide) h0 h1 h2.symm)

private theorem sat_83 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 0, .neg 5, .neg 10, .pos 50] := by
  change ¬(G.Adj (3:V) 4) → (G.Adj (3:V) 13) → (G.Adj (4:V) 13) → ¬(G.dist (3:V) 4 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 3 13 4 (by decide) h0 h1 h2.symm)

private theorem sat_84 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 1, .pos 51] := by
  change ¬(G.Adj (3:V) 5) → ¬(G.dist (3:V) 5 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 3 0 5 (by decide) h0 (H.fixed 3 0 (by decide)) (H.fixed 0 5 (by decide)))

private theorem sat_85 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 2, .pos 52] := by
  change ¬(G.Adj (3:V) 6) → ¬(G.dist (3:V) 6 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 3 0 6 (by decide) h0 (H.fixed 3 0 (by decide)) (H.fixed 0 6 (by decide)))

private theorem sat_86 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 3, .pos 53] := by
  change ¬(G.Adj (3:V) 7) → ¬(G.dist (3:V) 7 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 3 0 7 (by decide) h0 (H.fixed 3 0 (by decide)) (H.fixed 0 7 (by decide)))

private theorem sat_87 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 0, .pos 54] := by
  change (G.Adj (3:V) 4) → ¬(G.dist (3:V) 10 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 3 4 10 (by decide) (H.forbidden 3 10 (by decide)) h0 (H.fixed 4 10 (by decide)))

private theorem sat_88 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 21, .pos 54] := by
  change (G.Adj (8:V) 10) → ¬(G.dist (3:V) 10 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 3 8 10 (by decide) (H.forbidden 3 10 (by decide)) (H.fixed 3 8 (by decide)) h0)

private theorem sat_89 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 25, .pos 54] := by
  change (G.Adj (9:V) 10) → ¬(G.dist (3:V) 10 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 3 9 10 (by decide) (H.forbidden 3 10 (by decide)) (H.fixed 3 9 (by decide)) h0)

private theorem sat_90 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 22, .pos 55] := by
  change (G.Adj (8:V) 11) → ¬(G.dist (3:V) 11 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 3 8 11 (by decide) (H.forbidden 3 11 (by decide)) (H.fixed 3 8 (by decide)) h0)

private theorem sat_91 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 26, .pos 55] := by
  change (G.Adj (9:V) 11) → ¬(G.dist (3:V) 11 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 3 9 11 (by decide) (H.forbidden 3 11 (by decide)) (H.fixed 3 9 (by decide)) h0)

private theorem sat_92 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 0, .pos 4, .neg 9, .pos 56] := by
  change (G.Adj (3:V) 4) → ¬(G.Adj (3:V) 12) → (G.Adj (4:V) 12) → ¬(G.dist (3:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 3 4 12 (by decide) h1 h0 h2)

private theorem sat_93 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 1, .pos 4, .neg 13, .pos 56] := by
  change (G.Adj (3:V) 5) → ¬(G.Adj (3:V) 12) → (G.Adj (5:V) 12) → ¬(G.dist (3:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 3 5 12 (by decide) h1 h0 h2)

private theorem sat_94 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 2, .pos 4, .neg 16, .pos 56] := by
  change (G.Adj (3:V) 6) → ¬(G.Adj (3:V) 12) → (G.Adj (6:V) 12) → ¬(G.dist (3:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 3 6 12 (by decide) h1 h0 h2)

private theorem sat_95 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 3, .pos 4, .neg 18, .pos 56] := by
  change (G.Adj (3:V) 7) → ¬(G.Adj (3:V) 12) → (G.Adj (7:V) 12) → ¬(G.dist (3:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 3 7 12 (by decide) h1 h0 h2)

private theorem sat_96 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 4, .neg 23, .pos 56] := by
  change ¬(G.Adj (3:V) 12) → (G.Adj (8:V) 12) → ¬(G.dist (3:V) 12 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 3 8 12 (by decide) h0 (H.fixed 3 8 (by decide)) h1)

private theorem sat_97 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 4, .neg 27, .pos 56] := by
  change ¬(G.Adj (3:V) 12) → (G.Adj (9:V) 12) → ¬(G.dist (3:V) 12 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 3 9 12 (by decide) h0 (H.fixed 3 9 (by decide)) h1)

private theorem sat_98 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 0, .pos 5, .neg 10, .pos 57] := by
  change (G.Adj (3:V) 4) → ¬(G.Adj (3:V) 13) → (G.Adj (4:V) 13) → ¬(G.dist (3:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 3 4 13 (by decide) h1 h0 h2)

private theorem sat_99 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 1, .pos 5, .neg 14, .pos 57] := by
  change (G.Adj (3:V) 5) → ¬(G.Adj (3:V) 13) → (G.Adj (5:V) 13) → ¬(G.dist (3:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 3 5 13 (by decide) h1 h0 h2)

private theorem sat_100 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 2, .pos 5, .neg 17, .pos 57] := by
  change (G.Adj (3:V) 6) → ¬(G.Adj (3:V) 13) → (G.Adj (6:V) 13) → ¬(G.dist (3:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 3 6 13 (by decide) h1 h0 h2)

private theorem sat_101 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 3, .pos 5, .neg 19, .pos 57] := by
  change (G.Adj (3:V) 7) → ¬(G.Adj (3:V) 13) → (G.Adj (7:V) 13) → ¬(G.dist (3:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 3 7 13 (by decide) h1 h0 h2)

private theorem sat_102 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 5, .neg 24, .pos 57] := by
  change ¬(G.Adj (3:V) 13) → (G.Adj (8:V) 13) → ¬(G.dist (3:V) 13 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 3 8 13 (by decide) h0 (H.fixed 3 8 (by decide)) h1)

private theorem sat_103 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 6, .pos 58] := by
  change ¬(G.Adj (4:V) 5) → ¬(G.dist (4:V) 5 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 4 1 5 (by decide) h0 (H.fixed 4 1 (by decide)) (H.fixed 1 5 (by decide)))

private theorem sat_104 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 7, .pos 59] := by
  change ¬(G.Adj (4:V) 6) → ¬(G.dist (4:V) 6 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 4 1 6 (by decide) h0 (H.fixed 4 1 (by decide)) (H.fixed 1 6 (by decide)))

private theorem sat_105 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 8, .pos 60] := by
  change ¬(G.Adj (4:V) 7) → ¬(G.dist (4:V) 7 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 4 1 7 (by decide) h0 (H.fixed 4 1 (by decide)) (H.fixed 1 7 (by decide)))

private theorem sat_106 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 21, .pos 61] := by
  change (G.Adj (8:V) 10) → ¬(G.dist (4:V) 8 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 4 10 8 (by decide) (H.forbidden 4 8 (by decide)) (H.fixed 4 10 (by decide)) h0.symm)

private theorem sat_107 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 22, .pos 61] := by
  change (G.Adj (8:V) 11) → ¬(G.dist (4:V) 8 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 4 11 8 (by decide) (H.forbidden 4 8 (by decide)) (H.fixed 4 11 (by decide)) h0.symm)

private theorem sat_108 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 25, .pos 62] := by
  change (G.Adj (9:V) 10) → ¬(G.dist (4:V) 9 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 4 10 9 (by decide) (H.forbidden 4 9 (by decide)) (H.fixed 4 10 (by decide)) h0.symm)

private theorem sat_109 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 26, .pos 62] := by
  change (G.Adj (9:V) 11) → ¬(G.dist (4:V) 9 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 4 11 9 (by decide) (H.forbidden 4 9 (by decide)) (H.fixed 4 11 (by decide)) h0.symm)

private theorem sat_110 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 0, .neg 4, .pos 9, .pos 63] := by
  change (G.Adj (3:V) 4) → (G.Adj (3:V) 12) → ¬(G.Adj (4:V) 12) → ¬(G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 3 12 (by decide) h2 h0.symm h1)

private theorem sat_111 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 6, .pos 9, .neg 13, .pos 63] := by
  change (G.Adj (4:V) 5) → ¬(G.Adj (4:V) 12) → (G.Adj (5:V) 12) → ¬(G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 5 12 (by decide) h1 h0 h2)

private theorem sat_112 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 7, .pos 9, .neg 16, .pos 63] := by
  change (G.Adj (4:V) 6) → ¬(G.Adj (4:V) 12) → (G.Adj (6:V) 12) → ¬(G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 6 12 (by decide) h1 h0 h2)

private theorem sat_113 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 8, .pos 9, .neg 18, .pos 63] := by
  change (G.Adj (4:V) 7) → ¬(G.Adj (4:V) 12) → (G.Adj (7:V) 12) → ¬(G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 7 12 (by decide) h1 h0 h2)

private theorem sat_114 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 9, .neg 30, .pos 63] := by
  change ¬(G.Adj (4:V) 12) → (G.Adj (10:V) 12) → ¬(G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 4 10 12 (by decide) h0 (H.fixed 4 10 (by decide)) h1)

private theorem sat_115 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 9, .neg 32, .pos 63] := by
  change ¬(G.Adj (4:V) 12) → (G.Adj (11:V) 12) → ¬(G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 4 11 12 (by decide) h0 (H.fixed 4 11 (by decide)) h1)

private theorem sat_116 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 9, .neg 10, .neg 34, .pos 63] := by
  change ¬(G.Adj (4:V) 12) → (G.Adj (4:V) 13) → (G.Adj (12:V) 13) → ¬(G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 13 12 (by decide) h0 h1 h2.symm)

private theorem sat_117 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 0, .neg 5, .pos 10, .pos 64] := by
  change (G.Adj (3:V) 4) → (G.Adj (3:V) 13) → ¬(G.Adj (4:V) 13) → ¬(G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 3 13 (by decide) h2 h0.symm h1)

private theorem sat_118 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 6, .pos 10, .neg 14, .pos 64] := by
  change (G.Adj (4:V) 5) → ¬(G.Adj (4:V) 13) → (G.Adj (5:V) 13) → ¬(G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 5 13 (by decide) h1 h0 h2)

private theorem sat_119 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 7, .pos 10, .neg 17, .pos 64] := by
  change (G.Adj (4:V) 6) → ¬(G.Adj (4:V) 13) → (G.Adj (6:V) 13) → ¬(G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 6 13 (by decide) h1 h0 h2)

private theorem sat_120 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 8, .pos 10, .neg 19, .pos 64] := by
  change (G.Adj (4:V) 7) → ¬(G.Adj (4:V) 13) → (G.Adj (7:V) 13) → ¬(G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 7 13 (by decide) h1 h0 h2)

private theorem sat_121 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 10, .neg 31, .pos 64] := by
  change ¬(G.Adj (4:V) 13) → (G.Adj (10:V) 13) → ¬(G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 4 10 13 (by decide) h0 (H.fixed 4 10 (by decide)) h1)

private theorem sat_122 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 10, .neg 33, .pos 64] := by
  change ¬(G.Adj (4:V) 13) → (G.Adj (11:V) 13) → ¬(G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 4 11 13 (by decide) h0 (H.fixed 4 11 (by decide)) h1)

private theorem sat_123 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 9, .pos 10, .neg 34, .pos 64] := by
  change (G.Adj (4:V) 12) → ¬(G.Adj (4:V) 13) → (G.Adj (12:V) 13) → ¬(G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 4 12 13 (by decide) h1 h0 h2)

private theorem sat_124 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 11, .pos 65] := by
  change ¬(G.Adj (5:V) 6) → ¬(G.dist (5:V) 6 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 5 0 6 (by decide) h0 (H.fixed 5 0 (by decide)) (H.fixed 0 6 (by decide)))

private theorem sat_125 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 11, .pos 65] := by
  change ¬(G.Adj (5:V) 6) → ¬(G.dist (5:V) 6 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 5 1 6 (by decide) h0 (H.fixed 5 1 (by decide)) (H.fixed 1 6 (by decide)))

private theorem sat_126 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 12, .pos 66] := by
  change ¬(G.Adj (5:V) 7) → ¬(G.dist (5:V) 7 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 5 0 7 (by decide) h0 (H.fixed 5 0 (by decide)) (H.fixed 0 7 (by decide)))

private theorem sat_127 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 1, .pos 67] := by
  change (G.Adj (3:V) 5) → ¬(G.dist (5:V) 8 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 5 3 8 (by decide) (H.forbidden 5 8 (by decide)) h0.symm (H.fixed 3 8 (by decide)))

private theorem sat_128 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 13, .neg 23, .pos 67] := by
  change (G.Adj (5:V) 12) → (G.Adj (8:V) 12) → ¬(G.dist (5:V) 8 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 5 12 8 (by decide) (H.forbidden 5 8 (by decide)) h0 h1.symm)

private theorem sat_129 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 14, .neg 24, .pos 67] := by
  change (G.Adj (5:V) 13) → (G.Adj (8:V) 13) → ¬(G.dist (5:V) 8 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 5 13 8 (by decide) (H.forbidden 5 8 (by decide)) h0 h1.symm)

private theorem sat_130 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 1, .pos 68] := by
  change (G.Adj (3:V) 5) → ¬(G.dist (5:V) 9 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 5 3 9 (by decide) (H.forbidden 5 9 (by decide)) h0.symm (H.fixed 3 9 (by decide)))

private theorem sat_131 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 13, .neg 27, .pos 68] := by
  change (G.Adj (5:V) 12) → (G.Adj (9:V) 12) → ¬(G.dist (5:V) 9 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 5 12 9 (by decide) (H.forbidden 5 9 (by decide)) h0 h1.symm)

private theorem sat_132 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 14, .neg 28, .pos 68] := by
  change (G.Adj (5:V) 13) → (G.Adj (9:V) 13) → ¬(G.dist (5:V) 9 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 5 13 9 (by decide) (H.forbidden 5 9 (by decide)) h0 h1.symm)

private theorem sat_133 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 6, .pos 69] := by
  change (G.Adj (4:V) 5) → ¬(G.dist (5:V) 10 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 5 4 10 (by decide) (H.forbidden 5 10 (by decide)) h0.symm (H.fixed 4 10 (by decide)))

private theorem sat_134 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 13, .neg 30, .pos 69] := by
  change (G.Adj (5:V) 12) → (G.Adj (10:V) 12) → ¬(G.dist (5:V) 10 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 5 12 10 (by decide) (H.forbidden 5 10 (by decide)) h0 h1.symm)

private theorem sat_135 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 14, .neg 31, .pos 69] := by
  change (G.Adj (5:V) 13) → (G.Adj (10:V) 13) → ¬(G.dist (5:V) 10 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 5 13 10 (by decide) (H.forbidden 5 10 (by decide)) h0 h1.symm)

private theorem sat_136 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 6, .pos 70] := by
  change (G.Adj (4:V) 5) → ¬(G.dist (5:V) 11 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 5 4 11 (by decide) (H.forbidden 5 11 (by decide)) h0.symm (H.fixed 4 11 (by decide)))

private theorem sat_137 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 13, .neg 32, .pos 70] := by
  change (G.Adj (5:V) 12) → (G.Adj (11:V) 12) → ¬(G.dist (5:V) 11 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 5 12 11 (by decide) (H.forbidden 5 11 (by decide)) h0 h1.symm)

private theorem sat_138 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 14, .neg 33, .pos 70] := by
  change (G.Adj (5:V) 13) → (G.Adj (11:V) 13) → ¬(G.dist (5:V) 11 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 5 13 11 (by decide) (H.forbidden 5 11 (by decide)) h0 h1.symm)

private theorem sat_139 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 1, .neg 4, .pos 13, .pos 71] := by
  change (G.Adj (3:V) 5) → (G.Adj (3:V) 12) → ¬(G.Adj (5:V) 12) → ¬(G.dist (5:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 5 3 12 (by decide) h2 h0.symm h1)

private theorem sat_140 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 6, .neg 9, .pos 13, .pos 71] := by
  change (G.Adj (4:V) 5) → (G.Adj (4:V) 12) → ¬(G.Adj (5:V) 12) → ¬(G.dist (5:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 5 4 12 (by decide) h2 h0.symm h1)

private theorem sat_141 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 11, .pos 13, .neg 16, .pos 71] := by
  change (G.Adj (5:V) 6) → ¬(G.Adj (5:V) 12) → (G.Adj (6:V) 12) → ¬(G.dist (5:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 5 6 12 (by decide) h1 h0 h2)

private theorem sat_142 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 12, .pos 13, .neg 18, .pos 71] := by
  change (G.Adj (5:V) 7) → ¬(G.Adj (5:V) 12) → (G.Adj (7:V) 12) → ¬(G.dist (5:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 5 7 12 (by decide) h1 h0 h2)

private theorem sat_143 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 6, .neg 10, .pos 14, .pos 72] := by
  change (G.Adj (4:V) 5) → (G.Adj (4:V) 13) → ¬(G.Adj (5:V) 13) → ¬(G.dist (5:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 5 4 13 (by decide) h2 h0.symm h1)

private theorem sat_144 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 12, .pos 14, .neg 19, .pos 72] := by
  change (G.Adj (5:V) 7) → ¬(G.Adj (5:V) 13) → (G.Adj (7:V) 13) → ¬(G.dist (5:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 5 7 13 (by decide) h1 h0 h2)

private theorem sat_145 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 15, .pos 73] := by
  change ¬(G.Adj (6:V) 7) → ¬(G.dist (6:V) 7 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 6 0 7 (by decide) h0 (H.fixed 6 0 (by decide)) (H.fixed 0 7 (by decide)))

private theorem sat_146 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 15, .pos 73] := by
  change ¬(G.Adj (6:V) 7) → ¬(G.dist (6:V) 7 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 6 1 7 (by decide) h0 (H.fixed 6 1 (by decide)) (H.fixed 1 7 (by decide)))

private theorem sat_147 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 2, .pos 74] := by
  change (G.Adj (3:V) 6) → ¬(G.dist (6:V) 8 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 6 3 8 (by decide) (H.forbidden 6 8 (by decide)) h0.symm (H.fixed 3 8 (by decide)))

private theorem sat_148 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 16, .neg 23, .pos 74] := by
  change (G.Adj (6:V) 12) → (G.Adj (8:V) 12) → ¬(G.dist (6:V) 8 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 6 12 8 (by decide) (H.forbidden 6 8 (by decide)) h0 h1.symm)

private theorem sat_149 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 17, .neg 24, .pos 74] := by
  change (G.Adj (6:V) 13) → (G.Adj (8:V) 13) → ¬(G.dist (6:V) 8 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 6 13 8 (by decide) (H.forbidden 6 8 (by decide)) h0 h1.symm)

private theorem sat_150 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 2, .pos 75] := by
  change (G.Adj (3:V) 6) → ¬(G.dist (6:V) 9 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 6 3 9 (by decide) (H.forbidden 6 9 (by decide)) h0.symm (H.fixed 3 9 (by decide)))

private theorem sat_151 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 16, .neg 27, .pos 75] := by
  change (G.Adj (6:V) 12) → (G.Adj (9:V) 12) → ¬(G.dist (6:V) 9 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 6 12 9 (by decide) (H.forbidden 6 9 (by decide)) h0 h1.symm)

private theorem sat_152 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 17, .neg 28, .pos 75] := by
  change (G.Adj (6:V) 13) → (G.Adj (9:V) 13) → ¬(G.dist (6:V) 9 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 6 13 9 (by decide) (H.forbidden 6 9 (by decide)) h0 h1.symm)

private theorem sat_153 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 7, .pos 76] := by
  change (G.Adj (4:V) 6) → ¬(G.dist (6:V) 10 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 6 4 10 (by decide) (H.forbidden 6 10 (by decide)) h0.symm (H.fixed 4 10 (by decide)))

private theorem sat_154 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 16, .neg 30, .pos 76] := by
  change (G.Adj (6:V) 12) → (G.Adj (10:V) 12) → ¬(G.dist (6:V) 10 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 6 12 10 (by decide) (H.forbidden 6 10 (by decide)) h0 h1.symm)

private theorem sat_155 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 17, .neg 31, .pos 76] := by
  change (G.Adj (6:V) 13) → (G.Adj (10:V) 13) → ¬(G.dist (6:V) 10 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 6 13 10 (by decide) (H.forbidden 6 10 (by decide)) h0 h1.symm)

private theorem sat_156 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 7, .pos 77] := by
  change (G.Adj (4:V) 6) → ¬(G.dist (6:V) 11 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 6 4 11 (by decide) (H.forbidden 6 11 (by decide)) h0.symm (H.fixed 4 11 (by decide)))

private theorem sat_157 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 16, .neg 32, .pos 77] := by
  change (G.Adj (6:V) 12) → (G.Adj (11:V) 12) → ¬(G.dist (6:V) 11 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 6 12 11 (by decide) (H.forbidden 6 11 (by decide)) h0 h1.symm)

private theorem sat_158 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 17, .neg 33, .pos 77] := by
  change (G.Adj (6:V) 13) → (G.Adj (11:V) 13) → ¬(G.dist (6:V) 11 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 6 13 11 (by decide) (H.forbidden 6 11 (by decide)) h0 h1.symm)

private theorem sat_159 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 2, .neg 4, .pos 16, .pos 78] := by
  change (G.Adj (3:V) 6) → (G.Adj (3:V) 12) → ¬(G.Adj (6:V) 12) → ¬(G.dist (6:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 6 3 12 (by decide) h2 h0.symm h1)

private theorem sat_160 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 7, .neg 9, .pos 16, .pos 78] := by
  change (G.Adj (4:V) 6) → (G.Adj (4:V) 12) → ¬(G.Adj (6:V) 12) → ¬(G.dist (6:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 6 4 12 (by decide) h2 h0.symm h1)

private theorem sat_161 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 11, .neg 13, .pos 16, .pos 78] := by
  change (G.Adj (5:V) 6) → (G.Adj (5:V) 12) → ¬(G.Adj (6:V) 12) → ¬(G.dist (6:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 6 5 12 (by decide) h2 h0.symm h1)

private theorem sat_162 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 15, .pos 16, .neg 18, .pos 78] := by
  change (G.Adj (6:V) 7) → ¬(G.Adj (6:V) 12) → (G.Adj (7:V) 12) → ¬(G.dist (6:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 6 7 12 (by decide) h1 h0 h2)

private theorem sat_163 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 2, .neg 5, .pos 17, .pos 79] := by
  change (G.Adj (3:V) 6) → (G.Adj (3:V) 13) → ¬(G.Adj (6:V) 13) → ¬(G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 6 3 13 (by decide) h2 h0.symm h1)

private theorem sat_164 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 7, .neg 10, .pos 17, .pos 79] := by
  change (G.Adj (4:V) 6) → (G.Adj (4:V) 13) → ¬(G.Adj (6:V) 13) → ¬(G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 6 4 13 (by decide) h2 h0.symm h1)

private theorem sat_165 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 15, .pos 17, .neg 19, .pos 79] := by
  change (G.Adj (6:V) 7) → ¬(G.Adj (6:V) 13) → (G.Adj (7:V) 13) → ¬(G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 6 7 13 (by decide) h1 h0 h2)

private theorem sat_166 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 3, .pos 80] := by
  change (G.Adj (3:V) 7) → ¬(G.dist (7:V) 8 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 7 3 8 (by decide) (H.forbidden 7 8 (by decide)) h0.symm (H.fixed 3 8 (by decide)))

private theorem sat_167 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 18, .neg 23, .pos 80] := by
  change (G.Adj (7:V) 12) → (G.Adj (8:V) 12) → ¬(G.dist (7:V) 8 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 7 12 8 (by decide) (H.forbidden 7 8 (by decide)) h0 h1.symm)

private theorem sat_168 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 19, .neg 24, .pos 80] := by
  change (G.Adj (7:V) 13) → (G.Adj (8:V) 13) → ¬(G.dist (7:V) 8 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 7 13 8 (by decide) (H.forbidden 7 8 (by decide)) h0 h1.symm)

private theorem sat_169 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 3, .pos 81] := by
  change (G.Adj (3:V) 7) → ¬(G.dist (7:V) 9 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 7 3 9 (by decide) (H.forbidden 7 9 (by decide)) h0.symm (H.fixed 3 9 (by decide)))

private theorem sat_170 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 18, .neg 27, .pos 81] := by
  change (G.Adj (7:V) 12) → (G.Adj (9:V) 12) → ¬(G.dist (7:V) 9 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 7 12 9 (by decide) (H.forbidden 7 9 (by decide)) h0 h1.symm)

private theorem sat_171 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 19, .neg 28, .pos 81] := by
  change (G.Adj (7:V) 13) → (G.Adj (9:V) 13) → ¬(G.dist (7:V) 9 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 7 13 9 (by decide) (H.forbidden 7 9 (by decide)) h0 h1.symm)

private theorem sat_172 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 8, .pos 82] := by
  change (G.Adj (4:V) 7) → ¬(G.dist (7:V) 10 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 7 4 10 (by decide) (H.forbidden 7 10 (by decide)) h0.symm (H.fixed 4 10 (by decide)))

private theorem sat_173 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 18, .neg 30, .pos 82] := by
  change (G.Adj (7:V) 12) → (G.Adj (10:V) 12) → ¬(G.dist (7:V) 10 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 7 12 10 (by decide) (H.forbidden 7 10 (by decide)) h0 h1.symm)

private theorem sat_174 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 19, .neg 31, .pos 82] := by
  change (G.Adj (7:V) 13) → (G.Adj (10:V) 13) → ¬(G.dist (7:V) 10 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 7 13 10 (by decide) (H.forbidden 7 10 (by decide)) h0 h1.symm)

private theorem sat_175 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 8, .pos 83] := by
  change (G.Adj (4:V) 7) → ¬(G.dist (7:V) 11 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 7 4 11 (by decide) (H.forbidden 7 11 (by decide)) h0.symm (H.fixed 4 11 (by decide)))

private theorem sat_176 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 18, .neg 32, .pos 83] := by
  change (G.Adj (7:V) 12) → (G.Adj (11:V) 12) → ¬(G.dist (7:V) 11 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 7 12 11 (by decide) (H.forbidden 7 11 (by decide)) h0 h1.symm)

private theorem sat_177 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 19, .neg 33, .pos 83] := by
  change (G.Adj (7:V) 13) → (G.Adj (11:V) 13) → ¬(G.dist (7:V) 11 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 7 13 11 (by decide) (H.forbidden 7 11 (by decide)) h0 h1.symm)

private theorem sat_178 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 3, .neg 4, .pos 18, .pos 84] := by
  change (G.Adj (3:V) 7) → (G.Adj (3:V) 12) → ¬(G.Adj (7:V) 12) → ¬(G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 7 3 12 (by decide) h2 h0.symm h1)

private theorem sat_179 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 8, .neg 9, .pos 18, .pos 84] := by
  change (G.Adj (4:V) 7) → (G.Adj (4:V) 12) → ¬(G.Adj (7:V) 12) → ¬(G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 7 4 12 (by decide) h2 h0.symm h1)

private theorem sat_180 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 12, .neg 13, .pos 18, .pos 84] := by
  change (G.Adj (5:V) 7) → (G.Adj (5:V) 12) → ¬(G.Adj (7:V) 12) → ¬(G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 7 5 12 (by decide) h2 h0.symm h1)

private theorem sat_181 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 15, .neg 16, .pos 18, .pos 84] := by
  change (G.Adj (6:V) 7) → (G.Adj (6:V) 12) → ¬(G.Adj (7:V) 12) → ¬(G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 7 6 12 (by decide) h2 h0.symm h1)

private theorem sat_182 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 3, .neg 5, .pos 19, .pos 85] := by
  change (G.Adj (3:V) 7) → (G.Adj (3:V) 13) → ¬(G.Adj (7:V) 13) → ¬(G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 7 3 13 (by decide) h2 h0.symm h1)

private theorem sat_183 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 8, .neg 10, .pos 19, .pos 85] := by
  change (G.Adj (4:V) 7) → (G.Adj (4:V) 13) → ¬(G.Adj (7:V) 13) → ¬(G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 7 4 13 (by decide) h2 h0.symm h1)

private theorem sat_184 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 12, .neg 14, .pos 19, .pos 85] := by
  change (G.Adj (5:V) 7) → (G.Adj (5:V) 13) → ¬(G.Adj (7:V) 13) → ¬(G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 7 5 13 (by decide) h2 h0.symm h1)

private theorem sat_185 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 15, .neg 17, .pos 19, .pos 85] := by
  change (G.Adj (6:V) 7) → (G.Adj (6:V) 13) → ¬(G.Adj (7:V) 13) → ¬(G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 7 6 13 (by decide) h2 h0.symm h1)

private theorem sat_186 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 18, .pos 19, .neg 34, .pos 85] := by
  change (G.Adj (7:V) 12) → ¬(G.Adj (7:V) 13) → (G.Adj (12:V) 13) → ¬(G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 7 12 13 (by decide) h1 h0 h2)

private theorem sat_187 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 20, .pos 86] := by
  change ¬(G.Adj (8:V) 9) → ¬(G.dist (8:V) 9 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 8 3 9 (by decide) h0 (H.fixed 8 3 (by decide)) (H.fixed 3 9 (by decide)))

private theorem sat_188 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 20, .pos 21, .neg 25, .pos 87] := by
  change (G.Adj (8:V) 9) → ¬(G.Adj (8:V) 10) → (G.Adj (9:V) 10) → ¬(G.dist (8:V) 10 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 8 9 10 (by decide) h1 h0 h2)

private theorem sat_189 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 21, .neg 22, .neg 29, .pos 87] := by
  change ¬(G.Adj (8:V) 10) → (G.Adj (8:V) 11) → (G.Adj (10:V) 11) → ¬(G.dist (8:V) 10 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 8 11 10 (by decide) h0 h1 h2.symm)

private theorem sat_190 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 21, .neg 23, .neg 30, .pos 87] := by
  change ¬(G.Adj (8:V) 10) → (G.Adj (8:V) 12) → (G.Adj (10:V) 12) → ¬(G.dist (8:V) 10 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 8 12 10 (by decide) h0 h1 h2.symm)

private theorem sat_191 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 21, .neg 24, .neg 31, .pos 87] := by
  change ¬(G.Adj (8:V) 10) → (G.Adj (8:V) 13) → (G.Adj (10:V) 13) → ¬(G.dist (8:V) 10 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 8 13 10 (by decide) h0 h1 h2.symm)

private theorem sat_192 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 21, .pos 22, .neg 29, .pos 88] := by
  change (G.Adj (8:V) 10) → ¬(G.Adj (8:V) 11) → (G.Adj (10:V) 11) → ¬(G.dist (8:V) 11 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 8 10 11 (by decide) h1 h0 h2)

private theorem sat_193 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 22, .neg 23, .neg 32, .pos 88] := by
  change ¬(G.Adj (8:V) 11) → (G.Adj (8:V) 12) → (G.Adj (11:V) 12) → ¬(G.dist (8:V) 11 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 8 12 11 (by decide) h0 h1 h2.symm)

private theorem sat_194 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 4, .pos 23, .pos 89] := by
  change (G.Adj (3:V) 12) → ¬(G.Adj (8:V) 12) → ¬(G.dist (8:V) 12 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 8 3 12 (by decide) h1 (H.fixed 8 3 (by decide)) h0)

private theorem sat_195 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 21, .pos 23, .neg 30, .pos 89] := by
  change (G.Adj (8:V) 10) → ¬(G.Adj (8:V) 12) → (G.Adj (10:V) 12) → ¬(G.dist (8:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 8 10 12 (by decide) h1 h0 h2)

private theorem sat_196 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 22, .pos 23, .neg 32, .pos 89] := by
  change (G.Adj (8:V) 11) → ¬(G.Adj (8:V) 12) → (G.Adj (11:V) 12) → ¬(G.dist (8:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 8 11 12 (by decide) h1 h0 h2)

private theorem sat_197 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 23, .neg 24, .neg 34, .pos 89] := by
  change ¬(G.Adj (8:V) 12) → (G.Adj (8:V) 13) → (G.Adj (12:V) 13) → ¬(G.dist (8:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 8 13 12 (by decide) h0 h1 h2.symm)

private theorem sat_198 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 5, .pos 24, .pos 90] := by
  change (G.Adj (3:V) 13) → ¬(G.Adj (8:V) 13) → ¬(G.dist (8:V) 13 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 8 3 13 (by decide) h1 (H.fixed 8 3 (by decide)) h0)

private theorem sat_199 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 20, .pos 24, .neg 28, .pos 90] := by
  change (G.Adj (8:V) 9) → ¬(G.Adj (8:V) 13) → (G.Adj (9:V) 13) → ¬(G.dist (8:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 8 9 13 (by decide) h1 h0 h2)

private theorem sat_200 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 21, .pos 24, .neg 31, .pos 90] := by
  change (G.Adj (8:V) 10) → ¬(G.Adj (8:V) 13) → (G.Adj (10:V) 13) → ¬(G.dist (8:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 8 10 13 (by decide) h1 h0 h2)

private theorem sat_201 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 22, .pos 24, .neg 33, .pos 90] := by
  change (G.Adj (8:V) 11) → ¬(G.Adj (8:V) 13) → (G.Adj (11:V) 13) → ¬(G.dist (8:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 8 11 13 (by decide) h1 h0 h2)

private theorem sat_202 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 23, .pos 24, .neg 34, .pos 90] := by
  change (G.Adj (8:V) 12) → ¬(G.Adj (8:V) 13) → (G.Adj (12:V) 13) → ¬(G.dist (8:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 8 12 13 (by decide) h1 h0 h2)

private theorem sat_203 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 20, .neg 21, .pos 25, .pos 91] := by
  change (G.Adj (8:V) 9) → (G.Adj (8:V) 10) → ¬(G.Adj (9:V) 10) → ¬(G.dist (9:V) 10 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 9 8 10 (by decide) h2 h0.symm h1)

private theorem sat_204 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 25, .neg 27, .neg 30, .pos 91] := by
  change ¬(G.Adj (9:V) 10) → (G.Adj (9:V) 12) → (G.Adj (10:V) 12) → ¬(G.dist (9:V) 10 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 9 12 10 (by decide) h0 h1 h2.symm)

private theorem sat_205 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 20, .neg 22, .pos 26, .pos 92] := by
  change (G.Adj (8:V) 9) → (G.Adj (8:V) 11) → ¬(G.Adj (9:V) 11) → ¬(G.dist (9:V) 11 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 9 8 11 (by decide) h2 h0.symm h1)

private theorem sat_206 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 25, .pos 26, .neg 29, .pos 92] := by
  change (G.Adj (9:V) 10) → ¬(G.Adj (9:V) 11) → (G.Adj (10:V) 11) → ¬(G.dist (9:V) 11 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 9 10 11 (by decide) h1 h0 h2)

private theorem sat_207 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 4, .pos 27, .pos 93] := by
  change (G.Adj (3:V) 12) → ¬(G.Adj (9:V) 12) → ¬(G.dist (9:V) 12 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 9 3 12 (by decide) h1 (H.fixed 9 3 (by decide)) h0)

private theorem sat_208 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 20, .neg 23, .pos 27, .pos 93] := by
  change (G.Adj (8:V) 9) → (G.Adj (8:V) 12) → ¬(G.Adj (9:V) 12) → ¬(G.dist (9:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 9 8 12 (by decide) h2 h0.symm h1)

private theorem sat_209 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 25, .pos 27, .neg 30, .pos 93] := by
  change (G.Adj (9:V) 10) → ¬(G.Adj (9:V) 12) → (G.Adj (10:V) 12) → ¬(G.dist (9:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 9 10 12 (by decide) h1 h0 h2)

private theorem sat_210 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 27, .neg 28, .neg 34, .pos 93] := by
  change ¬(G.Adj (9:V) 12) → (G.Adj (9:V) 13) → (G.Adj (12:V) 13) → ¬(G.dist (9:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 9 13 12 (by decide) h0 h1 h2.symm)

private theorem sat_211 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 5, .pos 28, .pos 94] := by
  change (G.Adj (3:V) 13) → ¬(G.Adj (9:V) 13) → ¬(G.dist (9:V) 13 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 9 3 13 (by decide) h1 (H.fixed 9 3 (by decide)) h0)

private theorem sat_212 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 20, .neg 24, .pos 28, .pos 94] := by
  change (G.Adj (8:V) 9) → (G.Adj (8:V) 13) → ¬(G.Adj (9:V) 13) → ¬(G.dist (9:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 9 8 13 (by decide) h2 h0.symm h1)

private theorem sat_213 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 25, .pos 28, .neg 31, .pos 94] := by
  change (G.Adj (9:V) 10) → ¬(G.Adj (9:V) 13) → (G.Adj (10:V) 13) → ¬(G.dist (9:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 9 10 13 (by decide) h1 h0 h2)

private theorem sat_214 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 26, .pos 28, .neg 33, .pos 94] := by
  change (G.Adj (9:V) 11) → ¬(G.Adj (9:V) 13) → (G.Adj (11:V) 13) → ¬(G.dist (9:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 9 11 13 (by decide) h1 h0 h2)

private theorem sat_215 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 27, .pos 28, .neg 34, .pos 94] := by
  change (G.Adj (9:V) 12) → ¬(G.Adj (9:V) 13) → (G.Adj (12:V) 13) → ¬(G.dist (9:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 9 12 13 (by decide) h1 h0 h2)

private theorem sat_216 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 29, .pos 95] := by
  change ¬(G.Adj (10:V) 11) → ¬(G.dist (10:V) 11 = 2) → False
  intro h0 h1
  exact h1 (distance_two_from_two_edges H 10 4 11 (by decide) h0 (H.fixed 10 4 (by decide)) (H.fixed 4 11 (by decide)))

private theorem sat_217 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 9, .pos 30, .pos 96] := by
  change (G.Adj (4:V) 12) → ¬(G.Adj (10:V) 12) → ¬(G.dist (10:V) 12 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 10 4 12 (by decide) h1 (H.fixed 10 4 (by decide)) h0)

private theorem sat_218 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 21, .neg 23, .pos 30, .pos 96] := by
  change (G.Adj (8:V) 10) → (G.Adj (8:V) 12) → ¬(G.Adj (10:V) 12) → ¬(G.dist (10:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 10 8 12 (by decide) h2 h0.symm h1)

private theorem sat_219 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 29, .pos 30, .neg 32, .pos 96] := by
  change (G.Adj (10:V) 11) → ¬(G.Adj (10:V) 12) → (G.Adj (11:V) 12) → ¬(G.dist (10:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 10 11 12 (by decide) h1 h0 h2)

private theorem sat_220 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 10, .pos 31, .pos 97] := by
  change (G.Adj (4:V) 13) → ¬(G.Adj (10:V) 13) → ¬(G.dist (10:V) 13 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 10 4 13 (by decide) h1 (H.fixed 10 4 (by decide)) h0)

private theorem sat_221 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 29, .pos 31, .neg 33, .pos 97] := by
  change (G.Adj (10:V) 11) → ¬(G.Adj (10:V) 13) → (G.Adj (11:V) 13) → ¬(G.dist (10:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 10 11 13 (by decide) h1 h0 h2)

private theorem sat_222 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 30, .pos 31, .neg 34, .pos 97] := by
  change (G.Adj (10:V) 12) → ¬(G.Adj (10:V) 13) → (G.Adj (12:V) 13) → ¬(G.dist (10:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 10 12 13 (by decide) h1 h0 h2)

private theorem sat_223 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 9, .pos 32, .pos 98] := by
  change (G.Adj (4:V) 12) → ¬(G.Adj (11:V) 12) → ¬(G.dist (11:V) 12 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 11 4 12 (by decide) h1 (H.fixed 11 4 (by decide)) h0)

private theorem sat_224 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 22, .neg 23, .pos 32, .pos 98] := by
  change (G.Adj (8:V) 11) → (G.Adj (8:V) 12) → ¬(G.Adj (11:V) 12) → ¬(G.dist (11:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 11 8 12 (by decide) h2 h0.symm h1)

private theorem sat_225 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 26, .neg 27, .pos 32, .pos 98] := by
  change (G.Adj (9:V) 11) → (G.Adj (9:V) 12) → ¬(G.Adj (11:V) 12) → ¬(G.dist (11:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 11 9 12 (by decide) h2 h0.symm h1)

private theorem sat_226 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 29, .neg 30, .pos 32, .pos 98] := by
  change (G.Adj (10:V) 11) → (G.Adj (10:V) 12) → ¬(G.Adj (11:V) 12) → ¬(G.dist (11:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 11 10 12 (by decide) h2 h0.symm h1)

private theorem sat_227 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.pos 32, .neg 33, .neg 34, .pos 98] := by
  change ¬(G.Adj (11:V) 12) → (G.Adj (11:V) 13) → (G.Adj (12:V) 13) → ¬(G.dist (11:V) 12 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 11 13 12 (by decide) h0 h1 h2.symm)

private theorem sat_228 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 10, .pos 33, .pos 99] := by
  change (G.Adj (4:V) 13) → ¬(G.Adj (11:V) 13) → ¬(G.dist (11:V) 13 = 2) → False
  intro h0 h1 h2
  exact h2 (distance_two_from_two_edges H 11 4 13 (by decide) h1 (H.fixed 11 4 (by decide)) h0)

private theorem sat_229 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 22, .neg 24, .pos 33, .pos 99] := by
  change (G.Adj (8:V) 11) → (G.Adj (8:V) 13) → ¬(G.Adj (11:V) 13) → ¬(G.dist (11:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 11 8 13 (by decide) h2 h0.symm h1)

private theorem sat_230 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 26, .neg 28, .pos 33, .pos 99] := by
  change (G.Adj (9:V) 11) → (G.Adj (9:V) 13) → ¬(G.Adj (11:V) 13) → ¬(G.dist (11:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 11 9 13 (by decide) h2 h0.symm h1)

private theorem sat_231 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 29, .neg 31, .pos 33, .pos 99] := by
  change (G.Adj (10:V) 11) → (G.Adj (10:V) 13) → ¬(G.Adj (11:V) 13) → ¬(G.dist (11:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 11 10 13 (by decide) h2 h0.symm h1)

private theorem sat_232 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 32, .pos 33, .neg 34, .pos 99] := by
  change (G.Adj (11:V) 12) → ¬(G.Adj (11:V) 13) → (G.Adj (12:V) 13) → ¬(G.dist (11:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 11 12 13 (by decide) h1 h0 h2)

private theorem sat_233 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 9, .neg 10, .pos 34, .pos 100] := by
  change (G.Adj (4:V) 12) → (G.Adj (4:V) 13) → ¬(G.Adj (12:V) 13) → ¬(G.dist (12:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 12 4 13 (by decide) h2 h0.symm h1)

private theorem sat_234 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 16, .neg 17, .pos 34, .pos 100] := by
  change (G.Adj (6:V) 12) → (G.Adj (6:V) 13) → ¬(G.Adj (12:V) 13) → ¬(G.dist (12:V) 13 = 2) → False
  intro h0 h1 h2 h3
  exact h3 (distance_two_from_two_edges H 12 6 13 (by decide) h2 h0.symm h1)

private theorem sat_235 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 40, .neg 45, .neg 50, .neg 51, .neg 54, .neg 55] := by
  change (G.dist (1:V) 3 = 2) → (G.dist (2:V) 3 = 2) → (G.dist (3:V) 4 = 2) → (G.dist (3:V) 5 = 2) → (G.dist (3:V) 10 = 2) → (G.dist (3:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 3 ({1,2,4,5,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_236 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 40, .neg 45, .neg 50, .neg 52, .neg 54, .neg 55] := by
  change (G.dist (1:V) 3 = 2) → (G.dist (2:V) 3 = 2) → (G.dist (3:V) 4 = 2) → (G.dist (3:V) 6 = 2) → (G.dist (3:V) 10 = 2) → (G.dist (3:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 3 ({1,2,4,6,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_237 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 40, .neg 45, .neg 50, .neg 53, .neg 54, .neg 55] := by
  change (G.dist (1:V) 3 = 2) → (G.dist (2:V) 3 = 2) → (G.dist (3:V) 4 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (3:V) 10 = 2) → (G.dist (3:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 3 ({1,2,4,7,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_238 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 40, .neg 45, .neg 50, .neg 54, .neg 55, .neg 56] := by
  change (G.dist (1:V) 3 = 2) → (G.dist (2:V) 3 = 2) → (G.dist (3:V) 4 = 2) → (G.dist (3:V) 10 = 2) → (G.dist (3:V) 11 = 2) → (G.dist (3:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 3 ({1,2,4,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_239 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 40, .neg 45, .neg 51, .neg 52, .neg 54, .neg 55] := by
  change (G.dist (1:V) 3 = 2) → (G.dist (2:V) 3 = 2) → (G.dist (3:V) 5 = 2) → (G.dist (3:V) 6 = 2) → (G.dist (3:V) 10 = 2) → (G.dist (3:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 3 ({1,2,5,6,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_240 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 40, .neg 45, .neg 51, .neg 53, .neg 54, .neg 55] := by
  change (G.dist (1:V) 3 = 2) → (G.dist (2:V) 3 = 2) → (G.dist (3:V) 5 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (3:V) 10 = 2) → (G.dist (3:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 3 ({1,2,5,7,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_241 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 40, .neg 45, .neg 51, .neg 54, .neg 55, .neg 56] := by
  change (G.dist (1:V) 3 = 2) → (G.dist (2:V) 3 = 2) → (G.dist (3:V) 5 = 2) → (G.dist (3:V) 10 = 2) → (G.dist (3:V) 11 = 2) → (G.dist (3:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 3 ({1,2,5,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_242 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 40, .neg 45, .neg 51, .neg 54, .neg 55, .neg 57] := by
  change (G.dist (1:V) 3 = 2) → (G.dist (2:V) 3 = 2) → (G.dist (3:V) 5 = 2) → (G.dist (3:V) 10 = 2) → (G.dist (3:V) 11 = 2) → (G.dist (3:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 3 ({1,2,5,10,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_243 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 40, .neg 45, .neg 52, .neg 53, .neg 54, .neg 55] := by
  change (G.dist (1:V) 3 = 2) → (G.dist (2:V) 3 = 2) → (G.dist (3:V) 6 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (3:V) 10 = 2) → (G.dist (3:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 3 ({1,2,6,7,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_244 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 40, .neg 45, .neg 52, .neg 54, .neg 55, .neg 56] := by
  change (G.dist (1:V) 3 = 2) → (G.dist (2:V) 3 = 2) → (G.dist (3:V) 6 = 2) → (G.dist (3:V) 10 = 2) → (G.dist (3:V) 11 = 2) → (G.dist (3:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 3 ({1,2,6,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_245 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 40, .neg 45, .neg 52, .neg 54, .neg 55, .neg 57] := by
  change (G.dist (1:V) 3 = 2) → (G.dist (2:V) 3 = 2) → (G.dist (3:V) 6 = 2) → (G.dist (3:V) 10 = 2) → (G.dist (3:V) 11 = 2) → (G.dist (3:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 3 ({1,2,6,10,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_246 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 40, .neg 45, .neg 53, .neg 54, .neg 55, .neg 56] := by
  change (G.dist (1:V) 3 = 2) → (G.dist (2:V) 3 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (3:V) 10 = 2) → (G.dist (3:V) 11 = 2) → (G.dist (3:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 3 ({1,2,7,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_247 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 40, .neg 45, .neg 53, .neg 54, .neg 55, .neg 57] := by
  change (G.dist (1:V) 3 = 2) → (G.dist (2:V) 3 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (3:V) 10 = 2) → (G.dist (3:V) 11 = 2) → (G.dist (3:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 3 ({1,2,7,10,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_248 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 40, .neg 45, .neg 54, .neg 55, .neg 56, .neg 57] := by
  change (G.dist (1:V) 3 = 2) → (G.dist (2:V) 3 = 2) → (G.dist (3:V) 10 = 2) → (G.dist (3:V) 11 = 2) → (G.dist (3:V) 12 = 2) → (G.dist (3:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 3 ({1,2,10,11,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_249 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 35, .neg 46, .neg 50, .neg 58, .neg 61, .neg 62] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (3:V) 4 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,3,5,8,9} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_250 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 35, .neg 46, .neg 50, .neg 59, .neg 61, .neg 62] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (3:V) 4 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,3,6,8,9} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_251 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 35, .neg 46, .neg 50, .neg 60, .neg 61, .neg 62] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (3:V) 4 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,3,7,8,9} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_252 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 35, .neg 46, .neg 50, .neg 61, .neg 62, .neg 63] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (3:V) 4 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,3,8,9,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_253 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 35, .neg 46, .neg 50, .neg 61, .neg 62, .neg 64] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (3:V) 4 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,3,8,9,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_254 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 35, .neg 46, .neg 58, .neg 59, .neg 61, .neg 62] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,5,6,8,9} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_255 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 35, .neg 46, .neg 58, .neg 60, .neg 61, .neg 62] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,5,7,8,9} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_256 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 35, .neg 46, .neg 58, .neg 61, .neg 62, .neg 63] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,5,8,9,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_257 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 35, .neg 46, .neg 58, .neg 61, .neg 62, .neg 64] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,5,8,9,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_258 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 35, .neg 46, .neg 59, .neg 60, .neg 61, .neg 62] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,6,7,8,9} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_259 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 35, .neg 46, .neg 59, .neg 61, .neg 62, .neg 63] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,6,8,9,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_260 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 35, .neg 46, .neg 59, .neg 61, .neg 62, .neg 64] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,6,8,9,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_261 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 35, .neg 46, .neg 60, .neg 61, .neg 62, .neg 63] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (4:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,7,8,9,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_262 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 35, .neg 46, .neg 60, .neg 61, .neg 62, .neg 64] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,7,8,9,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_263 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 35, .neg 46, .neg 61, .neg 62, .neg 63, .neg 64] := by
  change (G.dist (0:V) 4 = 2) → (G.dist (2:V) 4 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (4:V) 12 = 2) → (G.dist (4:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 4 ({0,2,8,9,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_264 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 47, .neg 51, .neg 58, .neg 67, .neg 68, .neg 71] := by
  change (G.dist (2:V) 5 = 2) → (G.dist (3:V) 5 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (5:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({2,3,4,8,9,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_265 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 47, .neg 51, .neg 58, .neg 67, .neg 69, .neg 72] := by
  change (G.dist (2:V) 5 = 2) → (G.dist (3:V) 5 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (5:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({2,3,4,8,10,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_266 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 47, .neg 51, .neg 65, .neg 68, .neg 69, .neg 70] := by
  change (G.dist (2:V) 5 = 2) → (G.dist (3:V) 5 = 2) → (G.dist (5:V) 6 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (5:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({2,3,6,9,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_267 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 47, .neg 51, .neg 65, .neg 69, .neg 70, .neg 72] := by
  change (G.dist (2:V) 5 = 2) → (G.dist (3:V) 5 = 2) → (G.dist (5:V) 6 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (5:V) 11 = 2) → (G.dist (5:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({2,3,6,10,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_268 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 47, .neg 51, .neg 66, .neg 67, .neg 69, .neg 70] := by
  change (G.dist (2:V) 5 = 2) → (G.dist (3:V) 5 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (5:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({2,3,7,8,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_269 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 47, .neg 51, .neg 66, .neg 69, .neg 70, .neg 71] := by
  change (G.dist (2:V) 5 = 2) → (G.dist (3:V) 5 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (5:V) 11 = 2) → (G.dist (5:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({2,3,7,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_270 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 47, .neg 51, .neg 66, .neg 69, .neg 70, .neg 72] := by
  change (G.dist (2:V) 5 = 2) → (G.dist (3:V) 5 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (5:V) 11 = 2) → (G.dist (5:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({2,3,7,10,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_271 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 47, .neg 51, .neg 67, .neg 68, .neg 69, .neg 70] := by
  change (G.dist (2:V) 5 = 2) → (G.dist (3:V) 5 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (5:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({2,3,8,9,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_272 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 47, .neg 51, .neg 67, .neg 69, .neg 70, .neg 71] := by
  change (G.dist (2:V) 5 = 2) → (G.dist (3:V) 5 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (5:V) 11 = 2) → (G.dist (5:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({2,3,8,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_273 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 47, .neg 51, .neg 67, .neg 69, .neg 70, .neg 72] := by
  change (G.dist (2:V) 5 = 2) → (G.dist (3:V) 5 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (5:V) 11 = 2) → (G.dist (5:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({2,3,8,10,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_274 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 47, .neg 51, .neg 68, .neg 69, .neg 70, .neg 71] := by
  change (G.dist (2:V) 5 = 2) → (G.dist (3:V) 5 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (5:V) 11 = 2) → (G.dist (5:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({2,3,9,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_275 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 47, .neg 51, .neg 69, .neg 70, .neg 71, .neg 72] := by
  change (G.dist (2:V) 5 = 2) → (G.dist (3:V) 5 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (5:V) 11 = 2) → (G.dist (5:V) 12 = 2) → (G.dist (5:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({2,3,10,11,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_276 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 47, .neg 58, .neg 65, .neg 67, .neg 68, .neg 70] := by
  change (G.dist (2:V) 5 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (5:V) 6 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (5:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({2,4,6,8,9,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_277 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 47, .neg 58, .neg 65, .neg 67, .neg 68, .neg 71] := by
  change (G.dist (2:V) 5 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (5:V) 6 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (5:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({2,4,6,8,9,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_278 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 47, .neg 58, .neg 65, .neg 67, .neg 68, .neg 72] := by
  change (G.dist (2:V) 5 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (5:V) 6 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (5:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({2,4,6,8,9,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_279 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 47, .neg 58, .neg 65, .neg 68, .neg 70, .neg 71] := by
  change (G.dist (2:V) 5 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (5:V) 6 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (5:V) 11 = 2) → (G.dist (5:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({2,4,6,9,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_280 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 47, .neg 58, .neg 67, .neg 68, .neg 69, .neg 70] := by
  change (G.dist (2:V) 5 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (5:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({2,4,8,9,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_281 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 47, .neg 58, .neg 67, .neg 68, .neg 69, .neg 71] := by
  change (G.dist (2:V) 5 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (5:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({2,4,8,9,10,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_282 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 47, .neg 58, .neg 67, .neg 68, .neg 69, .neg 72] := by
  change (G.dist (2:V) 5 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (5:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({2,4,8,9,10,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_283 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 47, .neg 58, .neg 67, .neg 68, .neg 71, .neg 72] := by
  change (G.dist (2:V) 5 = 2) → (G.dist (4:V) 5 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (5:V) 12 = 2) → (G.dist (5:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({2,4,8,9,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_284 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 47, .neg 65, .neg 67, .neg 68, .neg 69, .neg 70] := by
  change (G.dist (2:V) 5 = 2) → (G.dist (5:V) 6 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (5:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({2,6,8,9,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact h1
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_285 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 47, .neg 66, .neg 67, .neg 68, .neg 69, .neg 70] := by
  change (G.dist (2:V) 5 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (5:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({2,7,8,9,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact h1
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_286 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 47, .neg 67, .neg 68, .neg 69, .neg 70, .neg 71] := by
  change (G.dist (2:V) 5 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (5:V) 11 = 2) → (G.dist (5:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({2,8,9,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact h1
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_287 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 47, .neg 67, .neg 68, .neg 69, .neg 70, .neg 72] := by
  change (G.dist (2:V) 5 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (5:V) 11 = 2) → (G.dist (5:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 5 ({2,8,9,10,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact h1
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_288 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 52, .neg 59, .neg 74, .neg 75, .neg 79] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (3:V) 6 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,3,4,8,9,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_289 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 52, .neg 59, .neg 75, .neg 76, .neg 78] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (3:V) 6 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,3,4,9,10,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_290 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 52, .neg 59, .neg 75, .neg 77, .neg 78] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (3:V) 6 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (6:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,3,4,9,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_291 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 52, .neg 65, .neg 74, .neg 76, .neg 77] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (3:V) 6 = 2) → (G.dist (5:V) 6 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,3,5,8,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_292 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 52, .neg 65, .neg 76, .neg 77, .neg 78] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (3:V) 6 = 2) → (G.dist (5:V) 6 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (6:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,3,5,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_293 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 52, .neg 65, .neg 76, .neg 77, .neg 79] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (3:V) 6 = 2) → (G.dist (5:V) 6 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,3,5,10,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_294 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 52, .neg 73, .neg 76, .neg 77, .neg 78] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (3:V) 6 = 2) → (G.dist (6:V) 7 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (6:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,3,7,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_295 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 52, .neg 73, .neg 76, .neg 77, .neg 79] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (3:V) 6 = 2) → (G.dist (6:V) 7 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,3,7,10,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_296 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 52, .neg 74, .neg 75, .neg 76, .neg 77] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (3:V) 6 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,3,8,9,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_297 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 52, .neg 74, .neg 76, .neg 77, .neg 78] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (3:V) 6 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (6:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,3,8,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_298 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 52, .neg 74, .neg 76, .neg 77, .neg 79] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (3:V) 6 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,3,8,10,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_299 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 52, .neg 75, .neg 76, .neg 77, .neg 78] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (3:V) 6 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (6:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,3,9,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_300 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 52, .neg 75, .neg 76, .neg 77, .neg 79] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (3:V) 6 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,3,9,10,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_301 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 52, .neg 76, .neg 77, .neg 78, .neg 79] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (3:V) 6 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (6:V) 12 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,3,10,11,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_302 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 59, .neg 65, .neg 74, .neg 75, .neg 78] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (5:V) 6 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,4,5,8,9,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_303 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 59, .neg 65, .neg 74, .neg 75, .neg 79] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (5:V) 6 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,4,5,8,9,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_304 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 59, .neg 65, .neg 75, .neg 76, .neg 78] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (5:V) 6 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,4,5,9,10,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_305 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 59, .neg 65, .neg 75, .neg 77, .neg 78] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (5:V) 6 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (6:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,4,5,9,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_306 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 59, .neg 74, .neg 75, .neg 76, .neg 77] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,4,8,9,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_307 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 59, .neg 74, .neg 75, .neg 76, .neg 78] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,4,8,9,10,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_308 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 59, .neg 74, .neg 75, .neg 76, .neg 79] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,4,8,9,10,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_309 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 59, .neg 74, .neg 75, .neg 77, .neg 78] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (6:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,4,8,9,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_310 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 59, .neg 74, .neg 75, .neg 77, .neg 79] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,4,8,9,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_311 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 59, .neg 74, .neg 75, .neg 78, .neg 79] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (4:V) 6 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 12 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,4,8,9,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_312 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 65, .neg 74, .neg 75, .neg 76, .neg 77] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (5:V) 6 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,5,8,9,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_313 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 65, .neg 74, .neg 75, .neg 77, .neg 79] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (5:V) 6 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,5,8,9,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_314 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 73, .neg 74, .neg 75, .neg 76, .neg 77] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (6:V) 7 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,7,8,9,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact h1
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_315 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 74, .neg 75, .neg 76, .neg 77, .neg 78] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (6:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,8,9,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact h1
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_316 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 74, .neg 75, .neg 76, .neg 77, .neg 79] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,8,9,10,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact h1
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_317 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 48, .neg 75, .neg 76, .neg 77, .neg 78, .neg 79] := by
  change (G.dist (2:V) 6 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (6:V) 12 = 2) → (G.dist (6:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 6 ({2,9,10,11,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact h1
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_318 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 53, .neg 60, .neg 80, .neg 82, .neg 83] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,3,4,8,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_319 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 53, .neg 60, .neg 80, .neg 82, .neg 85] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,3,4,8,10,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_320 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 53, .neg 60, .neg 80, .neg 83, .neg 84] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,3,4,8,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_321 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 53, .neg 60, .neg 80, .neg 83, .neg 85] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,3,4,8,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_322 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 53, .neg 60, .neg 81, .neg 82, .neg 85] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,3,4,9,10,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_323 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 53, .neg 60, .neg 81, .neg 83, .neg 84] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,3,4,9,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_324 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 53, .neg 60, .neg 82, .neg 83, .neg 85] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,3,4,10,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_325 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 53, .neg 60, .neg 82, .neg 84, .neg 85] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 12 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,3,4,10,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_326 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 53, .neg 60, .neg 83, .neg 84, .neg 85] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 12 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,3,4,11,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_327 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 53, .neg 66, .neg 80, .neg 82, .neg 83] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,3,5,8,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_328 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 53, .neg 66, .neg 81, .neg 82, .neg 83] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,3,5,9,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_329 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 53, .neg 66, .neg 82, .neg 83, .neg 84] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,3,5,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_330 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 53, .neg 66, .neg 82, .neg 83, .neg 85] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,3,5,10,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_331 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 53, .neg 73, .neg 80, .neg 82, .neg 83] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (6:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,3,6,8,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_332 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 53, .neg 73, .neg 81, .neg 82, .neg 83] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (6:V) 7 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,3,6,9,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_333 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 53, .neg 73, .neg 82, .neg 83, .neg 84] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (6:V) 7 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,3,6,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_334 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 53, .neg 73, .neg 82, .neg 83, .neg 85] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (6:V) 7 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,3,6,10,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_335 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 53, .neg 80, .neg 81, .neg 82, .neg 83] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,3,8,9,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_336 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 53, .neg 80, .neg 82, .neg 83, .neg 84] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,3,8,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_337 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 53, .neg 80, .neg 82, .neg 83, .neg 85] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,3,8,10,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_338 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 53, .neg 81, .neg 82, .neg 83, .neg 84] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,3,9,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_339 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 53, .neg 81, .neg 82, .neg 83, .neg 85] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,3,9,10,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_340 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 53, .neg 82, .neg 83, .neg 84, .neg 85] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (3:V) 7 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 12 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,3,10,11,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_341 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 60, .neg 66, .neg 80, .neg 81, .neg 83] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,4,5,8,9,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_342 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 60, .neg 66, .neg 80, .neg 81, .neg 84] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,4,5,8,9,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_343 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 60, .neg 66, .neg 80, .neg 81, .neg 85] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,4,5,8,9,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_344 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 60, .neg 73, .neg 80, .neg 81, .neg 83] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (6:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,4,6,8,9,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_345 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 60, .neg 73, .neg 80, .neg 81, .neg 84] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (6:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,4,6,8,9,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact h3
  · exact h4
  · exact h5

private theorem sat_346 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 60, .neg 80, .neg 81, .neg 82, .neg 83] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,4,8,9,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_347 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 60, .neg 80, .neg 81, .neg 82, .neg 84] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,4,8,9,10,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_348 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 60, .neg 80, .neg 81, .neg 82, .neg 85] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,4,8,9,10,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_349 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 60, .neg 80, .neg 81, .neg 83, .neg 84] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,4,8,9,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_350 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 60, .neg 80, .neg 81, .neg 83, .neg 85] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,4,8,9,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_351 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 60, .neg 80, .neg 81, .neg 84, .neg 85] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 12 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,4,8,9,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_352 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 60, .neg 80, .neg 82, .neg 83, .neg 84] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (4:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,4,8,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_353 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 66, .neg 80, .neg 81, .neg 82, .neg 83] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (5:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,5,8,9,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_354 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 73, .neg 80, .neg 81, .neg 82, .neg 83] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (6:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,6,8,9,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_355 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 80, .neg 81, .neg 82, .neg 83, .neg 84] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,8,9,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact h1
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_356 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 49, .neg 80, .neg 81, .neg 82, .neg 83, .neg 85] := by
  change (G.dist (2:V) 7 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (7:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 7 ({2,8,9,10,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact h1
  · exact h2
  · exact h3
  · exact h4
  · exact h5

private theorem sat_357 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 36, .neg 61, .neg 67, .neg 74, .neg 80, .neg 86] := by
  change (G.dist (0:V) 8 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (8:V) 9 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 8 ({0,4,5,6,7,9} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact h5

private theorem sat_358 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 36, .neg 61, .neg 67, .neg 74, .neg 80, .neg 87] := by
  change (G.dist (0:V) 8 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (8:V) 10 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 8 ({0,4,5,6,7,10} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact h5

private theorem sat_359 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 36, .neg 61, .neg 67, .neg 74, .neg 80, .neg 88] := by
  change (G.dist (0:V) 8 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (8:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 8 ({0,4,5,6,7,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact h5

private theorem sat_360 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 36, .neg 61, .neg 67, .neg 74, .neg 80, .neg 89] := by
  change (G.dist (0:V) 8 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (8:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 8 ({0,4,5,6,7,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact h5

private theorem sat_361 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 36, .neg 61, .neg 67, .neg 74, .neg 80, .neg 90] := by
  change (G.dist (0:V) 8 = 2) → (G.dist (4:V) 8 = 2) → (G.dist (5:V) 8 = 2) → (G.dist (6:V) 8 = 2) → (G.dist (7:V) 8 = 2) → (G.dist (8:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 8 ({0,4,5,6,7,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact h5

private theorem sat_362 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 37, .neg 62, .neg 68, .neg 75, .neg 81, .neg 86] := by
  change (G.dist (0:V) 9 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (8:V) 9 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 9 ({0,4,5,6,7,8} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact (by rw [dist_comm]; exact h5)

private theorem sat_363 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 37, .neg 62, .neg 68, .neg 75, .neg 81, .neg 91] := by
  change (G.dist (0:V) 9 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (9:V) 10 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 9 ({0,4,5,6,7,10} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact h5

private theorem sat_364 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 37, .neg 62, .neg 68, .neg 75, .neg 81, .neg 92] := by
  change (G.dist (0:V) 9 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (9:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 9 ({0,4,5,6,7,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact h5

private theorem sat_365 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 37, .neg 62, .neg 68, .neg 75, .neg 81, .neg 93] := by
  change (G.dist (0:V) 9 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (9:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 9 ({0,4,5,6,7,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact h5

private theorem sat_366 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 37, .neg 62, .neg 68, .neg 75, .neg 81, .neg 94] := by
  change (G.dist (0:V) 9 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (9:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 9 ({0,4,5,6,7,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact h5

private theorem sat_367 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 37, .neg 62, .neg 68, .neg 81, .neg 93, .neg 94] := by
  change (G.dist (0:V) 9 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (5:V) 9 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (9:V) 12 = 2) → (G.dist (9:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 9 ({0,4,5,7,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact h4
  · exact h5

private theorem sat_368 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 37, .neg 62, .neg 75, .neg 81, .neg 93, .neg 94] := by
  change (G.dist (0:V) 9 = 2) → (G.dist (4:V) 9 = 2) → (G.dist (6:V) 9 = 2) → (G.dist (7:V) 9 = 2) → (G.dist (9:V) 12 = 2) → (G.dist (9:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 9 ({0,4,6,7,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact h4
  · exact h5

private theorem sat_369 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 41, .neg 54, .neg 69, .neg 76, .neg 82, .neg 87] := by
  change (G.dist (1:V) 10 = 2) → (G.dist (3:V) 10 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (8:V) 10 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 10 ({1,3,5,6,7,8} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact (by rw [dist_comm]; exact h5)

private theorem sat_370 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 41, .neg 54, .neg 69, .neg 76, .neg 82, .neg 91] := by
  change (G.dist (1:V) 10 = 2) → (G.dist (3:V) 10 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (9:V) 10 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 10 ({1,3,5,6,7,9} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact (by rw [dist_comm]; exact h5)

private theorem sat_371 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 41, .neg 54, .neg 69, .neg 76, .neg 82, .neg 95] := by
  change (G.dist (1:V) 10 = 2) → (G.dist (3:V) 10 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (10:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 10 ({1,3,5,6,7,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact h5

private theorem sat_372 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 41, .neg 54, .neg 69, .neg 76, .neg 82, .neg 96] := by
  change (G.dist (1:V) 10 = 2) → (G.dist (3:V) 10 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (10:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 10 ({1,3,5,6,7,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact h5

private theorem sat_373 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 41, .neg 54, .neg 69, .neg 76, .neg 82, .neg 97] := by
  change (G.dist (1:V) 10 = 2) → (G.dist (3:V) 10 = 2) → (G.dist (5:V) 10 = 2) → (G.dist (6:V) 10 = 2) → (G.dist (7:V) 10 = 2) → (G.dist (10:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 10 ({1,3,5,6,7,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact h5

private theorem sat_374 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 42, .neg 55, .neg 70, .neg 77, .neg 83, .neg 95] := by
  change (G.dist (1:V) 11 = 2) → (G.dist (3:V) 11 = 2) → (G.dist (5:V) 11 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (10:V) 11 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 11 ({1,3,5,6,7,10} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact (by rw [dist_comm]; exact h5)

private theorem sat_375 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 42, .neg 55, .neg 70, .neg 77, .neg 83, .neg 98] := by
  change (G.dist (1:V) 11 = 2) → (G.dist (3:V) 11 = 2) → (G.dist (5:V) 11 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (11:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 11 ({1,3,5,6,7,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact h5

private theorem sat_376 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 42, .neg 55, .neg 70, .neg 77, .neg 83, .neg 99] := by
  change (G.dist (1:V) 11 = 2) → (G.dist (3:V) 11 = 2) → (G.dist (5:V) 11 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (7:V) 11 = 2) → (G.dist (11:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 11 ({1,3,5,6,7,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact h5

private theorem sat_377 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 42, .neg 55, .neg 70, .neg 77, .neg 88, .neg 99] := by
  change (G.dist (1:V) 11 = 2) → (G.dist (3:V) 11 = 2) → (G.dist (5:V) 11 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (8:V) 11 = 2) → (G.dist (11:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 11 ({1,3,5,6,8,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact h5

private theorem sat_378 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 42, .neg 55, .neg 70, .neg 77, .neg 92, .neg 99] := by
  change (G.dist (1:V) 11 = 2) → (G.dist (3:V) 11 = 2) → (G.dist (5:V) 11 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (9:V) 11 = 2) → (G.dist (11:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 11 ({1,3,5,6,9,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact h5

private theorem sat_379 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 42, .neg 55, .neg 70, .neg 77, .neg 95, .neg 99] := by
  change (G.dist (1:V) 11 = 2) → (G.dist (3:V) 11 = 2) → (G.dist (5:V) 11 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (10:V) 11 = 2) → (G.dist (11:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 11 ({1,3,5,6,10,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact h5

private theorem sat_380 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 42, .neg 55, .neg 70, .neg 77, .neg 98, .neg 99] := by
  change (G.dist (1:V) 11 = 2) → (G.dist (3:V) 11 = 2) → (G.dist (5:V) 11 = 2) → (G.dist (6:V) 11 = 2) → (G.dist (11:V) 12 = 2) → (G.dist (11:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 11 ({1,3,5,6,12,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact h4
  · exact h5

private theorem sat_381 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 38, .neg 43, .neg 56, .neg 78, .neg 96, .neg 98] := by
  change (G.dist (0:V) 12 = 2) → (G.dist (1:V) 12 = 2) → (G.dist (3:V) 12 = 2) → (G.dist (6:V) 12 = 2) → (G.dist (10:V) 12 = 2) → (G.dist (11:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 12 ({0,1,3,6,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact (by rw [dist_comm]; exact h5)

private theorem sat_382 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 38, .neg 43, .neg 56, .neg 89, .neg 96, .neg 98] := by
  change (G.dist (0:V) 12 = 2) → (G.dist (1:V) 12 = 2) → (G.dist (3:V) 12 = 2) → (G.dist (8:V) 12 = 2) → (G.dist (10:V) 12 = 2) → (G.dist (11:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 12 ({0,1,3,8,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact (by rw [dist_comm]; exact h5)

private theorem sat_383 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 38, .neg 43, .neg 56, .neg 96, .neg 98, .neg 100] := by
  change (G.dist (0:V) 12 = 2) → (G.dist (1:V) 12 = 2) → (G.dist (3:V) 12 = 2) → (G.dist (10:V) 12 = 2) → (G.dist (11:V) 12 = 2) → (G.dist (12:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 12 ({0,1,3,10,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact h5

private theorem sat_384 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 38, .neg 43, .neg 63, .neg 89, .neg 93, .neg 98] := by
  change (G.dist (0:V) 12 = 2) → (G.dist (1:V) 12 = 2) → (G.dist (4:V) 12 = 2) → (G.dist (8:V) 12 = 2) → (G.dist (9:V) 12 = 2) → (G.dist (11:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 12 ({0,1,4,8,9,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact (by rw [dist_comm]; exact h5)

private theorem sat_385 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 38, .neg 43, .neg 71, .neg 78, .neg 89, .neg 93] := by
  change (G.dist (0:V) 12 = 2) → (G.dist (1:V) 12 = 2) → (G.dist (5:V) 12 = 2) → (G.dist (6:V) 12 = 2) → (G.dist (8:V) 12 = 2) → (G.dist (9:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 12 ({0,1,5,6,8,9} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact (by rw [dist_comm]; exact h5)

private theorem sat_386 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 38, .neg 43, .neg 71, .neg 89, .neg 93, .neg 98] := by
  change (G.dist (0:V) 12 = 2) → (G.dist (1:V) 12 = 2) → (G.dist (5:V) 12 = 2) → (G.dist (8:V) 12 = 2) → (G.dist (9:V) 12 = 2) → (G.dist (11:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 12 ({0,1,5,8,9,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact (by rw [dist_comm]; exact h5)

private theorem sat_387 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 38, .neg 43, .neg 78, .neg 89, .neg 93, .neg 96] := by
  change (G.dist (0:V) 12 = 2) → (G.dist (1:V) 12 = 2) → (G.dist (6:V) 12 = 2) → (G.dist (8:V) 12 = 2) → (G.dist (9:V) 12 = 2) → (G.dist (10:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 12 ({0,1,6,8,9,10} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact (by rw [dist_comm]; exact h5)

private theorem sat_388 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 38, .neg 43, .neg 78, .neg 89, .neg 96, .neg 98] := by
  change (G.dist (0:V) 12 = 2) → (G.dist (1:V) 12 = 2) → (G.dist (6:V) 12 = 2) → (G.dist (8:V) 12 = 2) → (G.dist (10:V) 12 = 2) → (G.dist (11:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 12 ({0,1,6,8,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact (by rw [dist_comm]; exact h5)

private theorem sat_389 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 38, .neg 43, .neg 78, .neg 93, .neg 96, .neg 98] := by
  change (G.dist (0:V) 12 = 2) → (G.dist (1:V) 12 = 2) → (G.dist (6:V) 12 = 2) → (G.dist (9:V) 12 = 2) → (G.dist (10:V) 12 = 2) → (G.dist (11:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 12 ({0,1,6,9,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact (by rw [dist_comm]; exact h5)

private theorem sat_390 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 38, .neg 43, .neg 78, .neg 96, .neg 98, .neg 100] := by
  change (G.dist (0:V) 12 = 2) → (G.dist (1:V) 12 = 2) → (G.dist (6:V) 12 = 2) → (G.dist (10:V) 12 = 2) → (G.dist (11:V) 12 = 2) → (G.dist (12:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 12 ({0,1,6,10,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact h5

private theorem sat_391 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 38, .neg 43, .neg 89, .neg 93, .neg 96, .neg 98] := by
  change (G.dist (0:V) 12 = 2) → (G.dist (1:V) 12 = 2) → (G.dist (8:V) 12 = 2) → (G.dist (9:V) 12 = 2) → (G.dist (10:V) 12 = 2) → (G.dist (11:V) 12 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 12 ({0,1,8,9,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact (by rw [dist_comm]; exact h5)

private theorem sat_392 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 38, .neg 43, .neg 89, .neg 96, .neg 98, .neg 100] := by
  change (G.dist (0:V) 12 = 2) → (G.dist (1:V) 12 = 2) → (G.dist (8:V) 12 = 2) → (G.dist (10:V) 12 = 2) → (G.dist (11:V) 12 = 2) → (G.dist (12:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 12 ({0,1,8,10,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact h5

private theorem sat_393 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 38, .neg 43, .neg 93, .neg 96, .neg 98, .neg 100] := by
  change (G.dist (0:V) 12 = 2) → (G.dist (1:V) 12 = 2) → (G.dist (9:V) 12 = 2) → (G.dist (10:V) 12 = 2) → (G.dist (11:V) 12 = 2) → (G.dist (12:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 12 ({0,1,9,10,11,13} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact h5

private theorem sat_394 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 39, .neg 44, .neg 57, .neg 90, .neg 97, .neg 99] := by
  change (G.dist (0:V) 13 = 2) → (G.dist (1:V) 13 = 2) → (G.dist (3:V) 13 = 2) → (G.dist (8:V) 13 = 2) → (G.dist (10:V) 13 = 2) → (G.dist (11:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 13 ({0,1,3,8,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact (by rw [dist_comm]; exact h5)

private theorem sat_395 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 39, .neg 44, .neg 72, .neg 90, .neg 94, .neg 97] := by
  change (G.dist (0:V) 13 = 2) → (G.dist (1:V) 13 = 2) → (G.dist (5:V) 13 = 2) → (G.dist (8:V) 13 = 2) → (G.dist (9:V) 13 = 2) → (G.dist (10:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 13 ({0,1,5,8,9,10} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact (by rw [dist_comm]; exact h5)

private theorem sat_396 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 39, .neg 44, .neg 72, .neg 90, .neg 94, .neg 99] := by
  change (G.dist (0:V) 13 = 2) → (G.dist (1:V) 13 = 2) → (G.dist (5:V) 13 = 2) → (G.dist (8:V) 13 = 2) → (G.dist (9:V) 13 = 2) → (G.dist (11:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 13 ({0,1,5,8,9,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact (by rw [dist_comm]; exact h5)

private theorem sat_397 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 39, .neg 44, .neg 79, .neg 90, .neg 94, .neg 97] := by
  change (G.dist (0:V) 13 = 2) → (G.dist (1:V) 13 = 2) → (G.dist (6:V) 13 = 2) → (G.dist (8:V) 13 = 2) → (G.dist (9:V) 13 = 2) → (G.dist (10:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 13 ({0,1,6,8,9,10} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact (by rw [dist_comm]; exact h5)

private theorem sat_398 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 39, .neg 44, .neg 79, .neg 90, .neg 94, .neg 99] := by
  change (G.dist (0:V) 13 = 2) → (G.dist (1:V) 13 = 2) → (G.dist (6:V) 13 = 2) → (G.dist (8:V) 13 = 2) → (G.dist (9:V) 13 = 2) → (G.dist (11:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 13 ({0,1,6,8,9,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact (by rw [dist_comm]; exact h5)

private theorem sat_399 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 39, .neg 44, .neg 90, .neg 94, .neg 97, .neg 99] := by
  change (G.dist (0:V) 13 = 2) → (G.dist (1:V) 13 = 2) → (G.dist (8:V) 13 = 2) → (G.dist (9:V) 13 = 2) → (G.dist (10:V) 13 = 2) → (G.dist (11:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 13 ({0,1,8,9,10,11} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact (by rw [dist_comm]; exact h5)

private theorem sat_400 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 39, .neg 44, .neg 90, .neg 94, .neg 97, .neg 100] := by
  change (G.dist (0:V) 13 = 2) → (G.dist (1:V) 13 = 2) → (G.dist (8:V) 13 = 2) → (G.dist (9:V) 13 = 2) → (G.dist (10:V) 13 = 2) → (G.dist (12:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 13 ({0,1,8,9,10,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact (by rw [dist_comm]; exact h5)

private theorem sat_401 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 39, .neg 44, .neg 90, .neg 97, .neg 99, .neg 100] := by
  change (G.dist (0:V) 13 = 2) → (G.dist (1:V) 13 = 2) → (G.dist (8:V) 13 = 2) → (G.dist (10:V) 13 = 2) → (G.dist (11:V) 13 = 2) → (G.dist (12:V) 13 = 2) → False
  intro h0 h1 h2 h3 h4 h5
  apply six_twos_contra H 13 ({0,1,8,10,11,12} : Finset V) (by decide) (by decide)
  intro j hj
  simp only [mem_insert,mem_singleton] at hj
  rcases hj with rfl|rfl|rfl|rfl|rfl|rfl
  · exact (by rw [dist_comm]; exact h0)
  · exact (by rw [dist_comm]; exact h1)
  · exact (by rw [dist_comm]; exact h2)
  · exact (by rw [dist_comm]; exact h3)
  · exact (by rw [dist_comm]; exact h4)
  · exact (by rw [dist_comm]; exact h5)

private theorem sat_402 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 0, .neg 1, .neg 11, .neg 15, .neg 18, .neg 20, .neg 23, .neg 25, .neg 29, .neg 33] := by
  change (G.Adj (3:V) 4) → (G.Adj (3:V) 5) → (G.Adj (5:V) 6) → (G.Adj (6:V) 7) → (G.Adj (7:V) 12) → (G.Adj (8:V) 9) → (G.Adj (8:V) 12) → (G.Adj (9:V) 10) → (G.Adj (10:V) 11) → (G.Adj (11:V) 13) → False
  intro h0 h1 h2 h3 h4 h5 h6 h7 h8 h9
  apply bad
  let path : G.Walk 2 13 := (.cons (H.fixed 2 0 (by decide)) (.cons (H.fixed 0 1 (by decide)) (.cons (H.fixed 1 4 (by decide)) (.cons h0.symm (.cons h1 (.cons h2 (.cons h3 (.cons h4 (.cons h6.symm (.cons h5 (.cons h7 (.cons h8 (.cons h9 .nil)))))))))))))
  refine ⟨2,13,path,?_,?_⟩
  · rw [SimpleGraph.Walk.isPath_def]
    change List.Nodup ([2,0,1,4,3,5,6,7,12,8,9,10,11,13] : List V)
    decide
  change ∀ z : V, z∈([2,0,1,4,3,5,6,7,12,8,9,10,11,13] : List V)
  decide

private theorem sat_403 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 0, .neg 1, .neg 11, .neg 15, .neg 19, .neg 20, .neg 24, .neg 25, .neg 29, .neg 32] := by
  change (G.Adj (3:V) 4) → (G.Adj (3:V) 5) → (G.Adj (5:V) 6) → (G.Adj (6:V) 7) → (G.Adj (7:V) 13) → (G.Adj (8:V) 9) → (G.Adj (8:V) 13) → (G.Adj (9:V) 10) → (G.Adj (10:V) 11) → (G.Adj (11:V) 12) → False
  intro h0 h1 h2 h3 h4 h5 h6 h7 h8 h9
  apply bad
  let path : G.Walk 2 12 := (.cons (H.fixed 2 0 (by decide)) (.cons (H.fixed 0 1 (by decide)) (.cons (H.fixed 1 4 (by decide)) (.cons h0.symm (.cons h1 (.cons h2 (.cons h3 (.cons h4 (.cons h6.symm (.cons h5 (.cons h7 (.cons h8 (.cons h9 .nil)))))))))))))
  refine ⟨2,12,path,?_,?_⟩
  · rw [SimpleGraph.Walk.isPath_def]
    change List.Nodup ([2,0,1,4,3,5,6,7,13,8,9,10,11,12] : List V)
    decide
  change ∀ z : V, z∈([2,0,1,4,3,5,6,7,13,8,9,10,11,12] : List V)
  decide

private theorem sat_404 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 0, .neg 1, .neg 11, .neg 15, .neg 19, .neg 20, .neg 21, .neg 26, .neg 31, .neg 32] := by
  change (G.Adj (3:V) 4) → (G.Adj (3:V) 5) → (G.Adj (5:V) 6) → (G.Adj (6:V) 7) → (G.Adj (7:V) 13) → (G.Adj (8:V) 9) → (G.Adj (8:V) 10) → (G.Adj (9:V) 11) → (G.Adj (10:V) 13) → (G.Adj (11:V) 12) → False
  intro h0 h1 h2 h3 h4 h5 h6 h7 h8 h9
  apply bad
  let path : G.Walk 2 12 := (.cons (H.fixed 2 0 (by decide)) (.cons (H.fixed 0 1 (by decide)) (.cons (H.fixed 1 4 (by decide)) (.cons h0.symm (.cons h1 (.cons h2 (.cons h3 (.cons h4 (.cons h8.symm (.cons h6.symm (.cons h5 (.cons h7 (.cons h9 .nil)))))))))))))
  refine ⟨2,12,path,?_,?_⟩
  · rw [SimpleGraph.Walk.isPath_def]
    change List.Nodup ([2,0,1,4,3,5,6,7,13,10,8,9,11,12] : List V)
    decide
  change ∀ z : V, z∈([2,0,1,4,3,5,6,7,13,10,8,9,11,12] : List V)
  decide

private theorem sat_405 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 0, .neg 1, .neg 11, .neg 15, .neg 19, .neg 20, .neg 21, .neg 28, .neg 29, .neg 32] := by
  change (G.Adj (3:V) 4) → (G.Adj (3:V) 5) → (G.Adj (5:V) 6) → (G.Adj (6:V) 7) → (G.Adj (7:V) 13) → (G.Adj (8:V) 9) → (G.Adj (8:V) 10) → (G.Adj (9:V) 13) → (G.Adj (10:V) 11) → (G.Adj (11:V) 12) → False
  intro h0 h1 h2 h3 h4 h5 h6 h7 h8 h9
  apply bad
  let path : G.Walk 2 12 := (.cons (H.fixed 2 0 (by decide)) (.cons (H.fixed 0 1 (by decide)) (.cons (H.fixed 1 4 (by decide)) (.cons h0.symm (.cons h1 (.cons h2 (.cons h3 (.cons h4 (.cons h7.symm (.cons h5.symm (.cons h6 (.cons h8 (.cons h9 .nil)))))))))))))
  refine ⟨2,12,path,?_,?_⟩
  · rw [SimpleGraph.Walk.isPath_def]
    change List.Nodup ([2,0,1,4,3,5,6,7,13,9,8,10,11,12] : List V)
    decide
  change ∀ z : V, z∈([2,0,1,4,3,5,6,7,13,9,8,10,11,12] : List V)
  decide

private theorem sat_406 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 0, .neg 2, .neg 11, .neg 12, .neg 19, .neg 20, .neg 24, .neg 25, .neg 29, .neg 32] := by
  change (G.Adj (3:V) 4) → (G.Adj (3:V) 6) → (G.Adj (5:V) 6) → (G.Adj (5:V) 7) → (G.Adj (7:V) 13) → (G.Adj (8:V) 9) → (G.Adj (8:V) 13) → (G.Adj (9:V) 10) → (G.Adj (10:V) 11) → (G.Adj (11:V) 12) → False
  intro h0 h1 h2 h3 h4 h5 h6 h7 h8 h9
  apply bad
  let path : G.Walk 2 12 := (.cons (H.fixed 2 0 (by decide)) (.cons (H.fixed 0 1 (by decide)) (.cons (H.fixed 1 4 (by decide)) (.cons h0.symm (.cons h1 (.cons h2.symm (.cons h3 (.cons h4 (.cons h6.symm (.cons h5 (.cons h7 (.cons h8 (.cons h9 .nil)))))))))))))
  refine ⟨2,12,path,?_,?_⟩
  · rw [SimpleGraph.Walk.isPath_def]
    change List.Nodup ([2,0,1,4,3,6,5,7,13,8,9,10,11,12] : List V)
    decide
  change ∀ z : V, z∈([2,0,1,4,3,6,5,7,13,8,9,10,11,12] : List V)
  decide

private theorem sat_407 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 0, .neg 1, .neg 11, .neg 15, .neg 18, .neg 20, .neg 21, .neg 26, .neg 30, .neg 33] := by
  change (G.Adj (3:V) 4) → (G.Adj (3:V) 5) → (G.Adj (5:V) 6) → (G.Adj (6:V) 7) → (G.Adj (7:V) 12) → (G.Adj (8:V) 9) → (G.Adj (8:V) 10) → (G.Adj (9:V) 11) → (G.Adj (10:V) 12) → (G.Adj (11:V) 13) → False
  intro h0 h1 h2 h3 h4 h5 h6 h7 h8 h9
  apply bad
  let path : G.Walk 2 13 := (.cons (H.fixed 2 0 (by decide)) (.cons (H.fixed 0 1 (by decide)) (.cons (H.fixed 1 4 (by decide)) (.cons h0.symm (.cons h1 (.cons h2 (.cons h3 (.cons h4 (.cons h8.symm (.cons h6.symm (.cons h5 (.cons h7 (.cons h9 .nil)))))))))))))
  refine ⟨2,13,path,?_,?_⟩
  · rw [SimpleGraph.Walk.isPath_def]
    change List.Nodup ([2,0,1,4,3,5,6,7,12,10,8,9,11,13] : List V)
    decide
  change ∀ z : V, z∈([2,0,1,4,3,5,6,7,12,10,8,9,11,13] : List V)
  decide

private theorem sat_408 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 0, .neg 1, .neg 11, .neg 15, .neg 18, .neg 20, .neg 21, .neg 27, .neg 29, .neg 33] := by
  change (G.Adj (3:V) 4) → (G.Adj (3:V) 5) → (G.Adj (5:V) 6) → (G.Adj (6:V) 7) → (G.Adj (7:V) 12) → (G.Adj (8:V) 9) → (G.Adj (8:V) 10) → (G.Adj (9:V) 12) → (G.Adj (10:V) 11) → (G.Adj (11:V) 13) → False
  intro h0 h1 h2 h3 h4 h5 h6 h7 h8 h9
  apply bad
  let path : G.Walk 2 13 := (.cons (H.fixed 2 0 (by decide)) (.cons (H.fixed 0 1 (by decide)) (.cons (H.fixed 1 4 (by decide)) (.cons h0.symm (.cons h1 (.cons h2 (.cons h3 (.cons h4 (.cons h7.symm (.cons h5.symm (.cons h6 (.cons h8 (.cons h9 .nil)))))))))))))
  refine ⟨2,13,path,?_,?_⟩
  · rw [SimpleGraph.Walk.isPath_def]
    change List.Nodup ([2,0,1,4,3,5,6,7,12,9,8,10,11,13] : List V)
    decide
  change ∀ z : V, z∈([2,0,1,4,3,5,6,7,12,9,8,10,11,13] : List V)
  decide

private theorem sat_409 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 0, .neg 1, .neg 11, .neg 15, .neg 18, .neg 20, .neg 22, .neg 25, .neg 31, .neg 32] := by
  change (G.Adj (3:V) 4) → (G.Adj (3:V) 5) → (G.Adj (5:V) 6) → (G.Adj (6:V) 7) → (G.Adj (7:V) 12) → (G.Adj (8:V) 9) → (G.Adj (8:V) 11) → (G.Adj (9:V) 10) → (G.Adj (10:V) 13) → (G.Adj (11:V) 12) → False
  intro h0 h1 h2 h3 h4 h5 h6 h7 h8 h9
  apply bad
  let path : G.Walk 2 13 := (.cons (H.fixed 2 0 (by decide)) (.cons (H.fixed 0 1 (by decide)) (.cons (H.fixed 1 4 (by decide)) (.cons h0.symm (.cons h1 (.cons h2 (.cons h3 (.cons h4 (.cons h9.symm (.cons h6.symm (.cons h5 (.cons h7 (.cons h8 .nil)))))))))))))
  refine ⟨2,13,path,?_,?_⟩
  · rw [SimpleGraph.Walk.isPath_def]
    change List.Nodup ([2,0,1,4,3,5,6,7,12,11,8,9,10,13] : List V)
    decide
  change ∀ z : V, z∈([2,0,1,4,3,5,6,7,12,11,8,9,10,13] : List V)
  decide

private theorem sat_410 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 0, .neg 2, .neg 11, .neg 12, .neg 18, .neg 20, .neg 23, .neg 25, .neg 29, .neg 33] := by
  change (G.Adj (3:V) 4) → (G.Adj (3:V) 6) → (G.Adj (5:V) 6) → (G.Adj (5:V) 7) → (G.Adj (7:V) 12) → (G.Adj (8:V) 9) → (G.Adj (8:V) 12) → (G.Adj (9:V) 10) → (G.Adj (10:V) 11) → (G.Adj (11:V) 13) → False
  intro h0 h1 h2 h3 h4 h5 h6 h7 h8 h9
  apply bad
  let path : G.Walk 2 13 := (.cons (H.fixed 2 0 (by decide)) (.cons (H.fixed 0 1 (by decide)) (.cons (H.fixed 1 4 (by decide)) (.cons h0.symm (.cons h1 (.cons h2.symm (.cons h3 (.cons h4 (.cons h6.symm (.cons h5 (.cons h7 (.cons h8 (.cons h9 .nil)))))))))))))
  refine ⟨2,13,path,?_,?_⟩
  · rw [SimpleGraph.Walk.isPath_def]
    change List.Nodup ([2,0,1,4,3,6,5,7,12,8,9,10,11,13] : List V)
    decide
  change ∀ z : V, z∈([2,0,1,4,3,6,5,7,12,8,9,10,11,13] : List V)
  decide

private theorem sat_411 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 0, .neg 1, .neg 11, .neg 15, .neg 19, .neg 20, .neg 22, .neg 25, .neg 30, .neg 33] := by
  change (G.Adj (3:V) 4) → (G.Adj (3:V) 5) → (G.Adj (5:V) 6) → (G.Adj (6:V) 7) → (G.Adj (7:V) 13) → (G.Adj (8:V) 9) → (G.Adj (8:V) 11) → (G.Adj (9:V) 10) → (G.Adj (10:V) 12) → (G.Adj (11:V) 13) → False
  intro h0 h1 h2 h3 h4 h5 h6 h7 h8 h9
  apply bad
  let path : G.Walk 2 12 := (.cons (H.fixed 2 0 (by decide)) (.cons (H.fixed 0 1 (by decide)) (.cons (H.fixed 1 4 (by decide)) (.cons h0.symm (.cons h1 (.cons h2 (.cons h3 (.cons h4 (.cons h9.symm (.cons h6.symm (.cons h5 (.cons h7 (.cons h8 .nil)))))))))))))
  refine ⟨2,12,path,?_,?_⟩
  · rw [SimpleGraph.Walk.isPath_def]
    change List.Nodup ([2,0,1,4,3,5,6,7,13,11,8,9,10,12] : List V)
    decide
  change ∀ z : V, z∈([2,0,1,4,3,5,6,7,13,11,8,9,10,12] : List V)
  decide

private theorem sat_412 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 0, .neg 1, .neg 11, .neg 15, .neg 18, .neg 21, .neg 22, .neg 26, .neg 28, .neg 30] := by
  change (G.Adj (3:V) 4) → (G.Adj (3:V) 5) → (G.Adj (5:V) 6) → (G.Adj (6:V) 7) → (G.Adj (7:V) 12) → (G.Adj (8:V) 10) → (G.Adj (8:V) 11) → (G.Adj (9:V) 11) → (G.Adj (9:V) 13) → (G.Adj (10:V) 12) → False
  intro h0 h1 h2 h3 h4 h5 h6 h7 h8 h9
  apply bad
  let path : G.Walk 2 13 := (.cons (H.fixed 2 0 (by decide)) (.cons (H.fixed 0 1 (by decide)) (.cons (H.fixed 1 4 (by decide)) (.cons h0.symm (.cons h1 (.cons h2 (.cons h3 (.cons h4 (.cons h9.symm (.cons h5.symm (.cons h6 (.cons h7.symm (.cons h8 .nil)))))))))))))
  refine ⟨2,13,path,?_,?_⟩
  · rw [SimpleGraph.Walk.isPath_def]
    change List.Nodup ([2,0,1,4,3,5,6,7,12,10,8,11,9,13] : List V)
    decide
  change ∀ z : V, z∈([2,0,1,4,3,5,6,7,12,10,8,11,9,13] : List V)
  decide

private theorem sat_413 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 0, .neg 2, .neg 11, .neg 12, .neg 18, .neg 21, .neg 23, .neg 26, .neg 28, .neg 29] := by
  change (G.Adj (3:V) 4) → (G.Adj (3:V) 6) → (G.Adj (5:V) 6) → (G.Adj (5:V) 7) → (G.Adj (7:V) 12) → (G.Adj (8:V) 10) → (G.Adj (8:V) 12) → (G.Adj (9:V) 11) → (G.Adj (9:V) 13) → (G.Adj (10:V) 11) → False
  intro h0 h1 h2 h3 h4 h5 h6 h7 h8 h9
  apply bad
  let path : G.Walk 2 13 := (.cons (H.fixed 2 0 (by decide)) (.cons (H.fixed 0 1 (by decide)) (.cons (H.fixed 1 4 (by decide)) (.cons h0.symm (.cons h1 (.cons h2.symm (.cons h3 (.cons h4 (.cons h6.symm (.cons h5 (.cons h9 (.cons h7.symm (.cons h8 .nil)))))))))))))
  refine ⟨2,13,path,?_,?_⟩
  · rw [SimpleGraph.Walk.isPath_def]
    change List.Nodup ([2,0,1,4,3,6,5,7,12,8,10,11,9,13] : List V)
    decide
  change ∀ z : V, z∈([2,0,1,4,3,6,5,7,12,8,10,11,9,13] : List V)
  decide

private theorem sat_414 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 0, .neg 2, .neg 11, .neg 12, .neg 18, .neg 20, .neg 23, .neg 26, .neg 29, .neg 31] := by
  change (G.Adj (3:V) 4) → (G.Adj (3:V) 6) → (G.Adj (5:V) 6) → (G.Adj (5:V) 7) → (G.Adj (7:V) 12) → (G.Adj (8:V) 9) → (G.Adj (8:V) 12) → (G.Adj (9:V) 11) → (G.Adj (10:V) 11) → (G.Adj (10:V) 13) → False
  intro h0 h1 h2 h3 h4 h5 h6 h7 h8 h9
  apply bad
  let path : G.Walk 2 13 := (.cons (H.fixed 2 0 (by decide)) (.cons (H.fixed 0 1 (by decide)) (.cons (H.fixed 1 4 (by decide)) (.cons h0.symm (.cons h1 (.cons h2.symm (.cons h3 (.cons h4 (.cons h6.symm (.cons h5 (.cons h7 (.cons h8.symm (.cons h9 .nil)))))))))))))
  refine ⟨2,13,path,?_,?_⟩
  · rw [SimpleGraph.Walk.isPath_def]
    change List.Nodup ([2,0,1,4,3,6,5,7,12,8,9,11,10,13] : List V)
    decide
  change ∀ z : V, z∈([2,0,1,4,3,6,5,7,12,8,9,11,10,13] : List V)
  decide

private theorem sat_415 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 0, .neg 2, .neg 11, .neg 12, .neg 18, .neg 20, .neg 21, .neg 27, .neg 29, .neg 33] := by
  change (G.Adj (3:V) 4) → (G.Adj (3:V) 6) → (G.Adj (5:V) 6) → (G.Adj (5:V) 7) → (G.Adj (7:V) 12) → (G.Adj (8:V) 9) → (G.Adj (8:V) 10) → (G.Adj (9:V) 12) → (G.Adj (10:V) 11) → (G.Adj (11:V) 13) → False
  intro h0 h1 h2 h3 h4 h5 h6 h7 h8 h9
  apply bad
  let path : G.Walk 2 13 := (.cons (H.fixed 2 0 (by decide)) (.cons (H.fixed 0 1 (by decide)) (.cons (H.fixed 1 4 (by decide)) (.cons h0.symm (.cons h1 (.cons h2.symm (.cons h3 (.cons h4 (.cons h7.symm (.cons h5.symm (.cons h6 (.cons h8 (.cons h9 .nil)))))))))))))
  refine ⟨2,13,path,?_,?_⟩
  · rw [SimpleGraph.Walk.isPath_def]
    change List.Nodup ([2,0,1,4,3,6,5,7,12,9,8,10,11,13] : List V)
    decide
  change ∀ z : V, z∈([2,0,1,4,3,6,5,7,12,9,8,10,11,13] : List V)
  decide

private theorem sat_416 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 1, .neg 2, .neg 6, .neg 15, .neg 18, .neg 20, .neg 23, .neg 25, .neg 29, .neg 33] := by
  change (G.Adj (3:V) 5) → (G.Adj (3:V) 6) → (G.Adj (4:V) 5) → (G.Adj (6:V) 7) → (G.Adj (7:V) 12) → (G.Adj (8:V) 9) → (G.Adj (8:V) 12) → (G.Adj (9:V) 10) → (G.Adj (10:V) 11) → (G.Adj (11:V) 13) → False
  intro h0 h1 h2 h3 h4 h5 h6 h7 h8 h9
  apply bad
  let path : G.Walk 2 13 := (.cons (H.fixed 2 0 (by decide)) (.cons (H.fixed 0 1 (by decide)) (.cons (H.fixed 1 4 (by decide)) (.cons h2 (.cons h0.symm (.cons h1 (.cons h3 (.cons h4 (.cons h6.symm (.cons h5 (.cons h7 (.cons h8 (.cons h9 .nil)))))))))))))
  refine ⟨2,13,path,?_,?_⟩
  · rw [SimpleGraph.Walk.isPath_def]
    change List.Nodup ([2,0,1,4,5,3,6,7,12,8,9,10,11,13] : List V)
    decide
  change ∀ z : V, z∈([2,0,1,4,5,3,6,7,12,8,9,10,11,13] : List V)
  decide

private theorem sat_417 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 0, .neg 2, .neg 11, .neg 12, .neg 18, .neg 20, .neg 21, .neg 26, .neg 30, .neg 33] := by
  change (G.Adj (3:V) 4) → (G.Adj (3:V) 6) → (G.Adj (5:V) 6) → (G.Adj (5:V) 7) → (G.Adj (7:V) 12) → (G.Adj (8:V) 9) → (G.Adj (8:V) 10) → (G.Adj (9:V) 11) → (G.Adj (10:V) 12) → (G.Adj (11:V) 13) → False
  intro h0 h1 h2 h3 h4 h5 h6 h7 h8 h9
  apply bad
  let path : G.Walk 2 13 := (.cons (H.fixed 2 0 (by decide)) (.cons (H.fixed 0 1 (by decide)) (.cons (H.fixed 1 4 (by decide)) (.cons h0.symm (.cons h1 (.cons h2.symm (.cons h3 (.cons h4 (.cons h8.symm (.cons h6.symm (.cons h5 (.cons h7 (.cons h9 .nil)))))))))))))
  refine ⟨2,13,path,?_,?_⟩
  · rw [SimpleGraph.Walk.isPath_def]
    change List.Nodup ([2,0,1,4,3,6,5,7,12,10,8,9,11,13] : List V)
    decide
  change ∀ z : V, z∈([2,0,1,4,3,6,5,7,12,10,8,9,11,13] : List V)
  decide

private theorem sat_418 (H : Geometry G) (bad : ¬∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support) : (val G).satisfies [.neg 0, .neg 1, .neg 11, .neg 15, .neg 19, .neg 21, .neg 22, .neg 26, .neg 27, .neg 31] := by
  change (G.Adj (3:V) 4) → (G.Adj (3:V) 5) → (G.Adj (5:V) 6) → (G.Adj (6:V) 7) → (G.Adj (7:V) 13) → (G.Adj (8:V) 10) → (G.Adj (8:V) 11) → (G.Adj (9:V) 11) → (G.Adj (9:V) 12) → (G.Adj (10:V) 13) → False
  intro h0 h1 h2 h3 h4 h5 h6 h7 h8 h9
  apply bad
  let path : G.Walk 2 12 := (.cons (H.fixed 2 0 (by decide)) (.cons (H.fixed 0 1 (by decide)) (.cons (H.fixed 1 4 (by decide)) (.cons h0.symm (.cons h1 (.cons h2 (.cons h3 (.cons h4 (.cons h9.symm (.cons h5.symm (.cons h6 (.cons h7.symm (.cons h8 .nil)))))))))))))
  refine ⟨2,12,path,?_,?_⟩
  · rw [SimpleGraph.Walk.isPath_def]
    change List.Nodup ([2,0,1,4,3,5,6,7,13,10,8,11,9,12] : List V)
    decide
  change ∀ z : V, z∈([2,0,1,4,3,5,6,7,13,10,8,11,9,12] : List V)
  decide

theorem normalized_all_routes (H : Geometry G) : ∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support := by
  apply Classical.byContradiction
  intro bad
  have hf : (val G).satisfies_fmla ec3_all_paths.formula :=
    (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_0 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_1 H bad)) (fmla_one _ _ (sat_2 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_3 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_4 H bad)) (fmla_one _ _ (sat_5 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_6 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_7 H bad)) (fmla_one _ _ (sat_8 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_9 H bad)) (fmla_one _ _ (sat_10 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_11 H bad)) (fmla_one _ _ (sat_12 H bad)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_13 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_14 H bad)) (fmla_one _ _ (sat_15 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_16 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_17 H bad)) (fmla_one _ _ (sat_18 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_19 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_20 H bad)) (fmla_one _ _ (sat_21 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_22 H bad)) (fmla_one _ _ (sat_23 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_24 H bad)) (fmla_one _ _ (sat_25 H bad))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_26 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_27 H bad)) (fmla_one _ _ (sat_28 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_29 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_30 H bad)) (fmla_one _ _ (sat_31 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_32 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_33 H bad)) (fmla_one _ _ (sat_34 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_35 H bad)) (fmla_one _ _ (sat_36 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_37 H bad)) (fmla_one _ _ (sat_38 H bad)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_39 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_40 H bad)) (fmla_one _ _ (sat_41 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_42 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_43 H bad)) (fmla_one _ _ (sat_44 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_45 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_46 H bad)) (fmla_one _ _ (sat_47 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_48 H bad)) (fmla_one _ _ (sat_49 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_50 H bad)) (fmla_one _ _ (sat_51 H bad)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_52 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_53 H bad)) (fmla_one _ _ (sat_54 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_55 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_56 H bad)) (fmla_one _ _ (sat_57 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_58 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_59 H bad)) (fmla_one _ _ (sat_60 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_61 H bad)) (fmla_one _ _ (sat_62 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_63 H bad)) (fmla_one _ _ (sat_64 H bad)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_65 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_66 H bad)) (fmla_one _ _ (sat_67 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_68 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_69 H bad)) (fmla_one _ _ (sat_70 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_71 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_72 H bad)) (fmla_one _ _ (sat_73 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_74 H bad)) (fmla_one _ _ (sat_75 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_76 H bad)) (fmla_one _ _ (sat_77 H bad))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_78 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_79 H bad)) (fmla_one _ _ (sat_80 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_81 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_82 H bad)) (fmla_one _ _ (sat_83 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_84 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_85 H bad)) (fmla_one _ _ (sat_86 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_87 H bad)) (fmla_one _ _ (sat_88 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_89 H bad)) (fmla_one _ _ (sat_90 H bad)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_91 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_92 H bad)) (fmla_one _ _ (sat_93 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_94 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_95 H bad)) (fmla_one _ _ (sat_96 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_97 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_98 H bad)) (fmla_one _ _ (sat_99 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_100 H bad)) (fmla_one _ _ (sat_101 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_102 H bad)) (fmla_one _ _ (sat_103 H bad))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_104 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_105 H bad)) (fmla_one _ _ (sat_106 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_107 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_108 H bad)) (fmla_one _ _ (sat_109 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_110 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_111 H bad)) (fmla_one _ _ (sat_112 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_113 H bad)) (fmla_one _ _ (sat_114 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_115 H bad)) (fmla_one _ _ (sat_116 H bad)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_117 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_118 H bad)) (fmla_one _ _ (sat_119 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_120 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_121 H bad)) (fmla_one _ _ (sat_122 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_123 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_124 H bad)) (fmla_one _ _ (sat_125 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_126 H bad)) (fmla_one _ _ (sat_127 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_128 H bad)) (fmla_one _ _ (sat_129 H bad))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_130 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_131 H bad)) (fmla_one _ _ (sat_132 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_133 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_134 H bad)) (fmla_one _ _ (sat_135 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_136 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_137 H bad)) (fmla_one _ _ (sat_138 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_139 H bad)) (fmla_one _ _ (sat_140 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_141 H bad)) (fmla_one _ _ (sat_142 H bad)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_143 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_144 H bad)) (fmla_one _ _ (sat_145 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_146 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_147 H bad)) (fmla_one _ _ (sat_148 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_149 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_150 H bad)) (fmla_one _ _ (sat_151 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_152 H bad)) (fmla_one _ _ (sat_153 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_154 H bad)) (fmla_one _ _ (sat_155 H bad)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_156 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_157 H bad)) (fmla_one _ _ (sat_158 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_159 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_160 H bad)) (fmla_one _ _ (sat_161 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_162 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_163 H bad)) (fmla_one _ _ (sat_164 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_165 H bad)) (fmla_one _ _ (sat_166 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_167 H bad)) (fmla_one _ _ (sat_168 H bad)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_169 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_170 H bad)) (fmla_one _ _ (sat_171 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_172 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_173 H bad)) (fmla_one _ _ (sat_174 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_175 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_176 H bad)) (fmla_one _ _ (sat_177 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_178 H bad)) (fmla_one _ _ (sat_179 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_180 H bad)) (fmla_one _ _ (sat_181 H bad))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_182 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_183 H bad)) (fmla_one _ _ (sat_184 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_185 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_186 H bad)) (fmla_one _ _ (sat_187 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_188 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_189 H bad)) (fmla_one _ _ (sat_190 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_191 H bad)) (fmla_one _ _ (sat_192 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_193 H bad)) (fmla_one _ _ (sat_194 H bad)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_195 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_196 H bad)) (fmla_one _ _ (sat_197 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_198 H bad)) (fmla_one _ _ (sat_199 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_200 H bad)) (fmla_one _ _ (sat_201 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_202 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_203 H bad)) (fmla_one _ _ (sat_204 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_205 H bad)) (fmla_one _ _ (sat_206 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_207 H bad)) (fmla_one _ _ (sat_208 H bad)))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_209 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_210 H bad)) (fmla_one _ _ (sat_211 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_212 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_213 H bad)) (fmla_one _ _ (sat_214 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_215 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_216 H bad)) (fmla_one _ _ (sat_217 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_218 H bad)) (fmla_one _ _ (sat_219 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_220 H bad)) (fmla_one _ _ (sat_221 H bad)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_222 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_223 H bad)) (fmla_one _ _ (sat_224 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_225 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_226 H bad)) (fmla_one _ _ (sat_227 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_228 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_229 H bad)) (fmla_one _ _ (sat_230 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_231 H bad)) (fmla_one _ _ (sat_232 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_233 H bad)) (fmla_one _ _ (sat_234 H bad))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_235 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_236 H bad)) (fmla_one _ _ (sat_237 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_238 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_239 H bad)) (fmla_one _ _ (sat_240 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_241 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_242 H bad)) (fmla_one _ _ (sat_243 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_244 H bad)) (fmla_one _ _ (sat_245 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_246 H bad)) (fmla_one _ _ (sat_247 H bad)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_248 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_249 H bad)) (fmla_one _ _ (sat_250 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_251 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_252 H bad)) (fmla_one _ _ (sat_253 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_254 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_255 H bad)) (fmla_one _ _ (sat_256 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_257 H bad)) (fmla_one _ _ (sat_258 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_259 H bad)) (fmla_one _ _ (sat_260 H bad)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_261 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_262 H bad)) (fmla_one _ _ (sat_263 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_264 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_265 H bad)) (fmla_one _ _ (sat_266 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_267 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_268 H bad)) (fmla_one _ _ (sat_269 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_270 H bad)) (fmla_one _ _ (sat_271 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_272 H bad)) (fmla_one _ _ (sat_273 H bad)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_274 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_275 H bad)) (fmla_one _ _ (sat_276 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_277 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_278 H bad)) (fmla_one _ _ (sat_279 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_280 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_281 H bad)) (fmla_one _ _ (sat_282 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_283 H bad)) (fmla_one _ _ (sat_284 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_285 H bad)) (fmla_one _ _ (sat_286 H bad))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_287 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_288 H bad)) (fmla_one _ _ (sat_289 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_290 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_291 H bad)) (fmla_one _ _ (sat_292 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_293 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_294 H bad)) (fmla_one _ _ (sat_295 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_296 H bad)) (fmla_one _ _ (sat_297 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_298 H bad)) (fmla_one _ _ (sat_299 H bad)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_300 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_301 H bad)) (fmla_one _ _ (sat_302 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_303 H bad)) (fmla_one _ _ (sat_304 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_305 H bad)) (fmla_one _ _ (sat_306 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_307 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_308 H bad)) (fmla_one _ _ (sat_309 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_310 H bad)) (fmla_one _ _ (sat_311 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_312 H bad)) (fmla_one _ _ (sat_313 H bad))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_314 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_315 H bad)) (fmla_one _ _ (sat_316 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_317 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_318 H bad)) (fmla_one _ _ (sat_319 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_320 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_321 H bad)) (fmla_one _ _ (sat_322 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_323 H bad)) (fmla_one _ _ (sat_324 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_325 H bad)) (fmla_one _ _ (sat_326 H bad)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_327 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_328 H bad)) (fmla_one _ _ (sat_329 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_330 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_331 H bad)) (fmla_one _ _ (sat_332 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_333 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_334 H bad)) (fmla_one _ _ (sat_335 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_336 H bad)) (fmla_one _ _ (sat_337 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_338 H bad)) (fmla_one _ _ (sat_339 H bad))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_340 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_341 H bad)) (fmla_one _ _ (sat_342 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_343 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_344 H bad)) (fmla_one _ _ (sat_345 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_346 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_347 H bad)) (fmla_one _ _ (sat_348 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_349 H bad)) (fmla_one _ _ (sat_350 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_351 H bad)) (fmla_one _ _ (sat_352 H bad)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_353 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_354 H bad)) (fmla_one _ _ (sat_355 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_356 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_357 H bad)) (fmla_one _ _ (sat_358 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_359 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_360 H bad)) (fmla_one _ _ (sat_361 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_362 H bad)) (fmla_one _ _ (sat_363 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_364 H bad)) (fmla_one _ _ (sat_365 H bad)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_366 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_367 H bad)) (fmla_one _ _ (sat_368 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_369 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_370 H bad)) (fmla_one _ _ (sat_371 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_372 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_373 H bad)) (fmla_one _ _ (sat_374 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_375 H bad)) (fmla_one _ _ (sat_376 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_377 H bad)) (fmla_one _ _ (sat_378 H bad)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_379 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_380 H bad)) (fmla_one _ _ (sat_381 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_382 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_383 H bad)) (fmla_one _ _ (sat_384 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_385 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_386 H bad)) (fmla_one _ _ (sat_387 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_388 H bad)) (fmla_one _ _ (sat_389 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_390 H bad)) (fmla_one _ _ (sat_391 H bad))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_392 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_393 H bad)) (fmla_one _ _ (sat_394 H bad)))) (fmla_and _ _ _ (fmla_one _ _ (sat_395 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_396 H bad)) (fmla_one _ _ (sat_397 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_398 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_399 H bad)) (fmla_one _ _ (sat_400 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_401 H bad)) (fmla_one _ _ (sat_402 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_403 H bad)) (fmla_one _ _ (sat_404 H bad)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_405 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_406 H bad)) (fmla_one _ _ (sat_407 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_408 H bad)) (fmla_one _ _ (sat_409 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_410 H bad)) (fmla_one _ _ (sat_411 H bad))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_412 H bad)) (fmla_and _ _ _ (fmla_one _ _ (sat_413 H bad)) (fmla_one _ _ (sat_414 H bad)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_415 H bad)) (fmla_one _ _ (sat_416 H bad))) (fmla_and _ _ _ (fmla_one _ _ (sat_417 H bad)) (fmla_one _ _ (sat_418 H bad)))))))))))
  exact ec3_all_paths (val G) hf

#print axioms normalized_all_routes
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent.SingletonRUP.ec3
