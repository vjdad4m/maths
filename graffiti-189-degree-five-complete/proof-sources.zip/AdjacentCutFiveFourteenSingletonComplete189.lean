import AdjacentCutFiveFourteenSingletonReduced189
import AdjacentCutFiveFourteenExactTagC3189
import AdjacentCutFiveFourteenExactTag189
import AdjacentCutFiveFourteenMultiComplete189
import AdjacentCutFiveFifteenSingletonResidual189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset SingletonRUP
open private CutGraph Shore from AdjacentCutFiveActual189
open private prof classSet from AdjacentCutFiveTopProfiles189
open private swapCut from AdjacentCutFiveMixedNineGeom189
open private classSet_swap swapIndex from AdjacentCutFiveFifteenSingletonResidual189
open private common_card_ge_two from AdjacentCutFiveFourteenExactTagShared189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
set_option linter.unusedSectionVars false
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

set_option maxHeartbeats 1000000 in
private theorem finish_oriented_fourteen_singleton {a b : V}
    (hc : G.Connected) (ab : G.Adj a b) (even : ∀ z,(EvenFrom G z).card≤6)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    {C D : Cmp G a b} (cd : C≠D)
    (cover : ∀ {z : V}, z≠a → z≠b → z∈Shore C ∨ z∈Shore D)
    (one : (Shore C).card=1) (big : (Shore D).card=11)
    (cases' : (let y := prof D; AdjProfile.Singleton14AfterEC1 y.ea y.eb y.ec y.oa y.ob y.oc)) :
    ∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support := by
  classical
  unfold AdjProfile.Singleton14AfterEC1 at cases'
  rcases cases' with ⟨ea,eb,ec,oa,ob,oc⟩|⟨ea,eb,ec,oa,ob,oc⟩|⟨ea,eb,ec,oa,ob,oc⟩|⟨ea,eb,ec,oa,ob,oc⟩|⟨ea,eb,ec,oa,ob,oc⟩
  · have d := common_card_ge_two hc ab degree cd cover one oa
    have u : commonPorts D⊆classSet D 5 := filter_subset _ _
    have e := card_le_card u
    change (classSet D 5).card=3 at oc
    by_cases t : (commonPorts D).card=2
    · exact (no_order_fourteen_EC2_two_common hc ab even conn degree cd cover one big ea eb ec oa ob oc t).elim
    exact traceable_order_fourteen_EC2_three_common hc ab even conn degree cd cover one big ea eb ec oa ob oc (by omega)
  · exact traceable_of_adjacent_singleton_eleven_EC1_multi hc ab even conn degree cd cover one big ea eb ec oa ob oc
  · exact (impossible_actual_adjacent_singleton_multi_empty_even_fourteen hc ab even conn degree cd cover one ec
      (.inl ⟨ea,eb,oa,ob,oc⟩)).elim
  · exact (impossible_actual_adjacent_singleton_multi_empty_even_fourteen hc ab even conn degree cd cover one ec
      (.inr (.inl ⟨ea,eb,oa,ob,oc⟩))).elim
  exact (impossible_actual_adjacent_singleton_multi_empty_even_fourteen hc ab even conn degree cd cover one ec
    (.inr (.inr ⟨ea,eb,oa,ob,oc⟩))).elim

theorem traceable_of_adjacent_singleton_eleven_shores {a b : V}
    (hc : G.Connected) (ab : G.Adj a b) (even : ∀ z,(EvenFrom G z).card≤6)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    {C D : Cmp G a b} (cd : C≠D)
    (cover : ∀ {z : V}, z≠a → z≠b → z∈Shore C ∨ z∈Shore D)
    (one : (Shore C).card=1) (big : (Shore D).card=11) :
    ∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support := by
  classical
  by_contra fail
  rcases narrowed_frontier_of_adjacent_singleton_eleven_counterexample hc ab even conn degree cd cover one big fail with h|h
  · exact fail (finish_oriented_fourteen_singleton hc ab even conn degree cd cover one big h)
  apply fail
  apply finish_oriented_fourteen_singleton hc ab.symm even conn degree (C:=swapCut C) (D:=swapCut D)
    (fun e=>cd (swapCut.injective e)) (fun zb za=>by rw [shore_swapCut,shore_swapCut]; exact cover za zb)
  · rwa [shore_swapCut]
  · rwa [shore_swapCut]
  change AdjProfile.Singleton14AfterEC1
    (classSet (swapCut D) 0).card (classSet (swapCut D) 1).card
    (classSet (swapCut D) 2).card (classSet (swapCut D) 3).card
    (classSet (swapCut D) 4).card (classSet (swapCut D) 5).card
  rw [classSet_swap D 0,classSet_swap D 1,classSet_swap D 2,
    classSet_swap D 3,classSet_swap D 4,classSet_swap D 5]
  exact h

#print axioms traceable_of_adjacent_singleton_eleven_shores
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
