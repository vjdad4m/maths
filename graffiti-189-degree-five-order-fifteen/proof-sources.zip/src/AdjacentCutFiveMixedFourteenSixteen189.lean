import AdjacentCutFiveMixedNineGeom189
import AdjacentCutFiveOrderSixteenProfiles189
import AdjacentCutFiveTwinFourteen189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph Shore shore_disjoint shore_off from AdjacentCutFiveActual189
open private degree_le_shore_add_one from AdjacentCutFiveComponents189
open private actual_two_shores from AdjacentCutFiveTwoOrderTwenty189
open private swapCut from AdjacentCutFiveMixedNineGeom189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev RouteCmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

private theorem shore_sum_with_cover (ab : a≠b) {C D : RouteCmp G a b} (cd : C≠D)
    (cover : ∀ {z : V}, z≠a → z≠b → z∈Shore C ∨ z∈Shore D) :
    (Shore C).card+(Shore D).card=Fintype.card V-2 := by
  classical
  have eq : Shore C ∪ Shore D = (univ.erase a |>.erase b : Finset V) := by
    ext z
    simp only [mem_union,mem_erase,mem_univ,and_true]
    constructor
    · rintro (h|h)
      · exact ⟨fun e=>(shore_off C).2 (e ▸ h),fun e=>(shore_off C).1 (e ▸ h)⟩
      · exact ⟨fun e=>(shore_off D).2 (e ▸ h),fun e=>(shore_off D).1 (e ▸ h)⟩
    · exact fun h=>cover h.2 h.1
  have sum := card_union_of_disjoint (shore_disjoint cd)
  rw [eq,card_erase_of_mem (by simp [ab.symm]),card_erase_of_mem (mem_univ _),card_univ] at sum
  omega

private theorem four_of_nonsingle_shore {C : RouteCmp G a b}
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (two : 2≤(Shore C).card) : 4≤(Shore C).card := by
  obtain ⟨u,um,v,vm,uv⟩ := one_lt_card.mp two
  have du := degree_le_shore_add_one C um
  have dv := degree_le_shore_add_one C vm
  rcases degree u v uv with h|h <;> omega

private theorem port_four_of_all_except {C : RouteCmp G a b} {x t : V}
    (five : (Shore C).card=5) (xm : x∈Shore C)
    (h : ∀ z∈Shore C,z≠x → G.Adj t z) :
    4≤((Shore C).filter (G.Adj t)).card := by
  classical
  have sub : (Shore C).erase x⊆(Shore C).filter (G.Adj t) := by
    intro z zm
    obtain ⟨ne,m⟩ := mem_erase.mp zm
    exact mem_filter.mpr ⟨m,h z m ne⟩
  have c := card_le_card sub
  rw [card_erase_of_mem xm,five] at c
  exact c

/-- Every genuine adjacent two-cut with two nonsingleton shores is traceable
at orders fourteen through sixteen, at the degree-five threshold. -/
theorem traceable_of_actual_adjacent_nonsingleton_two_shores_fourteen_sixteen
    (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ x,(EvenFrom G x).card≤6)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (two : Nat.card (RouteCmp G a b)=2)
    (nonSingle : ∀ K : RouteCmp G a b,2≤(Shore K).card)
    (n14 : 14≤Fintype.card V) (n16 : Fintype.card V≤16) :
    ∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support := by
  classical
  by_cases twin : ∀ z,z≠a → z≠b → (G.Adj a z ↔ G.Adj b z)
  · exact traceable_of_adjacent_twins_two_shores_order_ge_fourteen hc ab even twin conn degree two n14
  obtain ⟨U,W,uw,cov⟩ := actual_two_shores two
  have sorted : ∃ C D : RouteCmp G a b,C≠D ∧ (Shore C).card≤(Shore D).card ∧
      ∀ {z : V}, z≠a → z≠b → z∈Shore C ∨ z∈Shore D := by
    by_cases h : (Shore U).card≤(Shore W).card
    · exact ⟨U,W,uw,h,cov⟩
    exact ⟨W,U,uw.symm,by omega,fun za zb=>(cov za zb).symm⟩
  obtain ⟨C,D,cd,ord,cover⟩ := sorted
  have sum := shore_sum_with_cover ab.ne cd cover
  have c4 := four_of_nonsingle_shore degree (nonSingle C)
  have d4 := four_of_nonsingle_shore degree (nonSingle D)
  by_cases d8 : (Shore D).card≤8
  · exact traceable_of_mixed_adjacent_two_shores_seven_eight ab conn degree cd cover
      (nonSingle C) (by omega) (nonSingle D) d8
  by_cases d10 : (Shore D).card=10
  · have four : (Shore C).card=4 := by omega
    have common := all_common_of_adjacent_four_ten_shores hc ab even conn degree cd four d10
    have exclusive : ∃ x∈Shore D,(G.Adj a x ∧ ¬G.Adj b x) ∨ (G.Adj b x ∧ ¬G.Adj a x) := by
      by_contra ex
      apply twin
      intro z za zb
      rcases cover za zb with zc|zd
      · exact iff_of_true (common z zc).1 (common z zc).2
      constructor
      · intro az
        by_contra bz
        exact ex ⟨z,zd,.inl ⟨az,bz⟩⟩
      · intro bz
        by_contra az
        exact ex ⟨z,zd,.inr ⟨bz,az⟩⟩
    exact traceable_of_adjacent_four_common_ten_non_twin hc ab even conn degree cd cover four d10 common exclusive
  have nine : (Shore D).card=9 := by omega
  by_cases four : (Shore C).card=4
  · exact traceable_of_adjacent_four_nine_non_twin hc ab even conn degree cd cover four nine twin
  have five : (Shore C).card=5 := by omega
  obtain ⟨q,qm,e,other⟩ :=
    one_exclusive_of_adjacent_five_nine_unequal_shores hc ab even conn degree cd cover five nine twin
  rcases e with ⟨aq,_⟩|⟨bq,_⟩
  · have shC := shore_swapCut C
    have shD := shore_swapCut D
    have aAll (z : V) (zm : z∈Shore C) : G.Adj a z := by
      by_cases zq : z=q
      · rwa [zq]
      exact (other z zm zq).1
    have bFour := port_four_of_all_except five qm (fun z zm zq=>(other z zm zq).2)
    apply traceable_of_adjacent_five_shore_with_four_common hc ab.symm even conn degree
      (C:=swapCut C) (D:=swapCut D) (fun h=>cd (swapCut.injective h))
      (fun zb za=>by rw [shC,shD]; exact cover za zb)
    · rwa [shC]
    · rw [shD]; omega
    · exact fun z zm=>aAll z (shC ▸ zm)
    · rwa [shC]
  have bAll (z : V) (zm : z∈Shore C) : G.Adj b z := by
    by_cases zq : z=q
    · rwa [zq]
    exact (other z zm zq).2
  have aFour := port_four_of_all_except five qm (fun z zm zq=>(other z zm zq).1)
  exact traceable_of_adjacent_five_shore_with_four_common hc ab even conn degree cd cover five nine.ge bAll aFour

#print axioms traceable_of_actual_adjacent_nonsingleton_two_shores_fourteen_sixteen
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
