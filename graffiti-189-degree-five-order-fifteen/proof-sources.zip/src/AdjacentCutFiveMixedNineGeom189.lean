import AdjacentCutFiveMixedNineRoutes189
import AdjacentCutFiveProfilePorts189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset ArticulationPair
open private CutGraph Shore mem_shore shore_closed shore_off shore_disjoint shore_hit_a shore_hit_b from AdjacentCutFiveActual189
open private Vis positive_cap foreign_pos_even degree_le_shore from AdjacentCutFiveComponents189
open private d2 mem_positive from AdjacentCutFiveBound189
open private lift_side_path from DegreeFiveSmallSides189
open private four_common_exclusive_univ four_common_sees_visible from AdjacentCutFiveMixedFourRoutes189
open private near_universal_route_of_nine_shore from AdjacentCutFiveMixedNineRoutes189
open private MixedRootCases from AdjacentCutFiveMixedSevenEight189
open private inside_neighbor_of_nonsingle degree_two_if_nonadjacent from AdjacentCutFiveMixedTwoAugment189
open private augment_both_one_or_two from AdjacentCutFiveMixedBothTerminals189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev RouteCmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

private theorem local_even_one_of_foreign_four (hc : G.Connected)
    (even : ∀ x,(EvenFrom G x).card≤6)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    {D : RouteCmp G a b} {x : V} {F : Finset V}
    (f4 : 4≤F.card) (sep : Disjoint F (Shore D)) (spent : F⊆PositiveEven G x)
    (noFar : ∀ z∈Vis D,G.dist x z≤2) :
    ((Shore D).filter (fun z=>z≠x ∧ ¬G.Adj x z)).card≤1 := by
  classical
  let Q := Shore D ∩ DistanceTwo G x
  have qOff : Disjoint F Q := sep.mono_right inter_subset_left
  have qp : Q⊆PositiveEven G x := by
    intro v vm
    have d : G.dist x v=2 := (mem_filter.mp (mem_inter.mp vm).2).2
    have ne : v≠x := by
      intro h
      subst v
      rw [SimpleGraph.dist_self] at d
      omega
    exact mem_positive.mpr ⟨ne,by rw [d]; decide⟩
  have mask := (card_le_card (union_subset spent qp)).trans (positive_cap x even)
  rw [card_union_of_disjoint qOff] at mask
  have q1 : Q.card<2 := by omega
  have far {z : V} (zm : z∈Shore D) (zd : 3≤G.dist x z) : False := by
    let U := (↑Q : Set V)ᶜ
    have zz : z∈U := by
      intro c
      have d := (mem_filter.mp (mem_inter.mp (show z∈Q from c)).2).2
      omega
    have xx : x∈U := by
      intro c
      have d := (mem_filter.mp (mem_inter.mp (show x∈Q from c)).2).2
      rw [SimpleGraph.dist_self] at d
      omega
    have propagate {u v : U} (p : (G.induce U).Walk u v) :
        u.val∈Shore D ∧ 3≤G.dist x u.val → v.val∈Shore D ∧ 3≤G.dist x v.val := by
      induction p with
      | nil => exact id
      | @cons u w v e p ih =>
        intro ⟨lu,du⟩
        apply ih
        change G.Adj u.val w.val at e
        rcases shore_closed D u.val lu w.val e with h|h|lw
        · have port : u.val∈Vis D := mem_filter.mpr ⟨lu,.inl (h ▸ e.symm)⟩
          have k := noFar u.val port
          omega
        · have port : u.val∈Vis D := mem_filter.mpr ⟨lu,.inr (h ▸ e.symm)⟩
          have k := noFar u.val port
          omega
        refine ⟨lw,?_⟩
        apply Classical.byContradiction
        intro small
        have tri := hc.dist_triangle (u:=x) (v:=w.val) (w:=u.val)
        rw [dist_eq_one_iff_adj.mpr e.symm] at tri
        have d : G.dist x w.val=2 := by omega
        exact w.property (mem_inter.mpr ⟨lw,mem_filter.mpr ⟨mem_univ _,d⟩⟩)
    obtain ⟨p⟩ := (conn Q q1).preconnected (⟨z,zz⟩ : U) ⟨x,xx⟩
    have e := (propagate p ⟨zm,zd⟩).2
    change 3≤G.dist x x at e
    rw [SimpleGraph.dist_self] at e
    omega
  have nz : ∀ z∈(Shore D).filter (fun z=>z≠x ∧ ¬G.Adj x z), z∈Q := by
    intro z hz
    obtain ⟨zm,zn,non⟩ := mem_filter.mp hz
    have l := hc.one_lt_dist_of_ne_of_not_adj zn.symm non
    have d : G.dist x z=2 := by
      apply Classical.byContradiction
      intro e
      exact far zm (by omega)
    exact mem_inter.mpr ⟨zm,mem_filter.mpr ⟨mem_univ _,d⟩⟩
  exact (card_le_card nz).trans (by omega)

private theorem near_card_of_one_miss {D : RouteCmp G a b} {x : V}
    (one : ((Shore D).filter (fun z=>z≠x ∧ ¬G.Adj x z)).card≤1) :
    (Shore D).card≤(inside G (Shore D) x).card+2 := by
  classical
  let N := (Shore D).filter (fun z=>z≠x ∧ ¬G.Adj x z)
  have one' : N.card≤1 := one
  have sub : Shore D⊆insert x (N∪inside G (Shore D) x) := by
    intro z zm
    by_cases zz : z=x
    · exact mem_insert.mpr (.inl zz)
    by_cases xz : G.Adj x z
    · exact mem_insert_of_mem (mem_union_right _ (mem_filter.mpr ⟨zm,xz⟩))
    · exact mem_insert_of_mem (mem_union_left _ (mem_filter.mpr ⟨zm,zz,xz⟩))
  have p := (card_le_card sub).trans (card_insert_le _ _)
  have q := card_union_le N (inside G (Shore D) x)
  omega

private theorem depth_partition_nine (hc : G.Connected) {C D : RouteCmp G a b}
    (cd : C≠D) (even : ∀ x,(EvenFrom G x).card≤6)
    {c : V} (cc : c∈Shore C) (ac : G.Adj a c) (bc : G.Adj b c) (d9 : (Shore D).card=9) :
    4≤((Shore D).filter (fun z=>Even (depth G a b z))).card := by
  classical
  let E := (Shore D).filter (fun z=>Even (depth G a b z))
  let O := (Shore D).filter (fun z=>¬Even (depth G a b z))
  have u : O⊆PositiveEven G c := by
    intro z zm
    obtain ⟨zd,oz⟩ := mem_filter.mp zm
    have no : z∉Shore C := fun zc=>disjoint_left.mp (shore_disjoint cd) zc zd
    have f := cross_metric (Shore C) hc cc no (shore_closed C)
    have ca := dist_eq_one_iff_adj.mpr ac.symm
    have cb := dist_eq_one_iff_adj.mpr bc.symm
    rw [ca,cb] at f
    have f' : G.dist c z=1+depth G a b z := by unfold depth; omega
    have cz : z≠c := fun e=>no (e.symm ▸ cc)
    exact mem_positive.mpr ⟨cz,by
      rw [f']
      simp only [Nat.even_iff] at oz ⊢
      omega⟩
  have cap := (card_le_card u).trans (positive_cap c even)
  have count := filter_card_add_filter_neg_card_eq_card (s:=Shore D)
    (p:=fun z=>Even (depth G a b z))
  change E.card+O.card=(Shore D).card at count
  change 4≤E.card
  omega

private theorem mixed_four_exclusive_profile (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ x,(EvenFrom G x).card≤6)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    {C D : RouteCmp G a b} (cd : C≠D) (c4 : (Shore C).card=4) (d9 : (Shore D).card=9) :
    (∀ z∈Shore C,G.Adj a z ∧ G.Adj b z) ∨
      ∃ q∈Shore C,G.degree q≤4 ∧ ¬(G.Adj a q ∧ G.Adj b q) ∧ (G.Adj a q ∨ G.Adj b q) ∧
        ∀ z∈Shore C,z≠q → G.Adj a z ∧ G.Adj b z := by
  classical
  by_cases c : ∀ z∈Shore C,G.Adj a z ∧ G.Adj b z
  · exact .inl c
  push_neg at c
  obtain ⟨q,qm,qn⟩ := c
  have miss : ¬G.Adj a q ∨ ¬G.Adj b q := by
    by_cases h : G.Adj a q
    · exact .inr (fun n=>qn h n)
    · exact .inl h
  have lo := degree_le_shore C qm miss
  rw [c4] at lo
  have oth (z : V) (zm : z∈Shore C) (zq : z≠q) : G.Adj a z ∧ G.Adj b z := by
    have zh := (degree z q zq).resolve_right (by omega)
    by_contra bad
    have no : ¬G.Adj a z ∨ ¬G.Adj b z := by
      by_cases az : G.Adj a z
      · exact .inr (fun bz=>bad ⟨az,bz⟩)
      · exact .inl az
    have d := degree_le_shore C zm no
    omega
  refine .inr ⟨q,qm,lo,?_,?_,oth⟩
  · exact fun h=>miss.elim (fun n=>n h.1) (fun n=>n h.2)
  by_contra h
  have na : ¬G.Adj a q := fun e=>h (.inl e)
  have nb : ¬G.Adj b q := fun e=>h (.inr e)
  obtain ⟨x,xm,qx⟩ := inside_neighbor_of_nonsingle qm (by omega)
  obtain ⟨ax,bx⟩ := oth x xm qx.ne.symm
  have aq : a≠q := fun e=>(shore_off C).1 (e.symm ▸ qm)
  have bq : b≠q := fun e=>(shore_off C).2 (e.symm ▸ qm)
  have da := (mem_filter.mp (d2 hc aq na ax qx.symm)).2
  have db := (mem_filter.mp (d2 hc bq nb bx qx.symm)).2
  let E := (Shore D).filter (fun z=>Even (depth G a b z))
  have E4 : 4≤E.card := depth_partition_nine hc cd even xm ax bx d9
  have f : insert a (insert b E)⊆PositiveEven G q := by
    intro z zm
    rcases mem_insert.mp zm with hz|zm
    · rw [hz]
      exact mem_positive.mpr ⟨aq,by rw [dist_comm,da]; decide⟩
    rcases mem_insert.mp zm with hz|zm
    · rw [hz]
      exact mem_positive.mpr ⟨bq,by rw [dist_comm,db]; decide⟩
    obtain ⟨zm,ed⟩ := mem_filter.mp zm
    have no : z∉Shore C := fun zc=>disjoint_left.mp (shore_disjoint cd) zc zm
    have zq : z≠q := fun hz=>no (hz.symm ▸ qm)
    have g := cross_metric (Shore C) hc qm no (shore_closed C)
    rw [dist_comm (G:=G) (u:=q) (v:=a),dist_comm (G:=G) (u:=q) (v:=b),da,db] at g
    have g' : G.dist q z=2+depth G a b z := by unfold depth; omega
    exact mem_positive.mpr ⟨zq,by rw [g']; simp only [Nat.even_iff] at ed ⊢; omega⟩
  have bo : b∉E := fun m=>(shore_off D).2 (mem_filter.mp m).1
  have ao : a∉insert b E := by
    intro m
    rcases mem_insert.mp m with hz|m
    · exact ab.ne hz
    · exact (shore_off D).1 (mem_filter.mp m).1
  have card := (card_le_card f).trans (positive_cap q even)
  rw [card_insert_of_not_mem ao,card_insert_of_not_mem bo] at card
  omega

private theorem mixed_nine_from_four_left_exclusive (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ x,(EvenFrom G x).card≤6)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    {C D : RouteCmp G a b} (cd : C≠D) (c4 : (Shore C).card=4) (d9 : (Shore D).card=9)
    {q : V} (qm : q∈Shore C) (aq : G.Adj a q) (nq : ¬G.Adj b q)
    (other : ∀ z∈Shore C,z≠q → G.Adj a z ∧ G.Adj b z) :
    4≤(Vis D).card ∧ ∀ w∈Vis D,(Shore D).card≤(inside G (Shore D) w).card+2 := by
  classical
  have had (z : V) (zm : z∈Shore C) : G.Adj a z := by
    by_cases hz : z=q
    · rwa [hz]
    · exact (other z zm hz).1
  have near_of_vis_dist {w : V} (wm : w∈Vis D) (fd : ∀ z∈Vis D,G.dist w z≤2) :
      ((Shore D).filter (fun z=>z≠w ∧ ¬G.Adj w z)).card≤1 := by
    obtain ⟨wd,wp⟩ := mem_filter.mp wm
    by_cases aw : G.Adj a w
    · apply local_even_one_of_foreign_four hc even conn (D:=D) (F:=Shore C)
        (by omega) (shore_disjoint cd) (fun _ zc=>foreign_pos_even hc cd.symm wd zc aw (had _ zc)) fd
    have bw := wp.resolve_left aw
    let F := insert a ((Shore C).erase q)
    have ao : a∉(Shore C).erase q := fun h=>(shore_off C).1 (mem_erase.mp h).2
    have f4 : 4≤F.card := by
      change 4≤(insert a ((Shore C).erase q)).card
      rw [card_insert_of_not_mem ao,card_erase_of_mem qm,c4]
    have sep : Disjoint F (Shore D) := by
      apply disjoint_left.mpr
      intro z zm zd
      rcases mem_insert.mp zm with rfl|h
      · exact (shore_off D).1 zd
      · exact disjoint_left.mp (shore_disjoint cd) (mem_erase.mp h).2 zd
    refine local_even_one_of_foreign_four hc even conn f4 sep ?_ fd
    intro z zm
    rcases mem_insert.mp zm with e|h
    · rw [e]
      have wa : w≠a := fun e=>(shore_off D).1 (e ▸ wd)
      have d := (mem_filter.mp (d2 hc wa (fun e=>aw e.symm) bw.symm ab.symm)).2
      exact mem_positive.mpr ⟨wa.symm,by rw [d]; decide⟩
    obtain ⟨zq,zc⟩ := mem_erase.mp h
    exact foreign_pos_even hc cd.symm wd zc bw (other z zc zq).2
  obtain ⟨p,pd,bp⟩ := shore_hit_b ab.ne conn D
  have pk : p∈Vis D := mem_filter.mpr ⟨pd,.inr bp⟩
  by_cases ax : ∃ x∈Shore D,G.Adj a x ∧ ¬G.Adj b x
  · obtain ⟨x,xd,xa,xb⟩ := ax
    have xall := four_common_exclusive_univ hc even cd c4 ab xa xb xd
      (shore_off C).2 (shore_off D).2 had
    have dk : (Shore D \ Vis D).card≤5 := by
      have ds : Shore D \ Vis D⊆PositiveEven G a := by
        intro z zm
        obtain ⟨zd,zn⟩ := mem_sdiff.mp zm
        have na : ¬G.Adj a z := fun e=>zn (mem_filter.mpr ⟨zd,.inl e⟩)
        have az : a≠z := fun e=>(shore_off D).1 (e.symm ▸ zd)
        have xz := (xall z zd).resolve_left (fun e=>na (e.symm ▸ xa))
        have dst := (mem_filter.mp (d2 hc az na xa xz)).2
        exact mem_positive.mpr ⟨az.symm,by rw [dst]; decide⟩
      exact (card_le_card ds).trans (positive_cap a even)
    have eq := card_sdiff_add_card_eq_card (show Vis D⊆Shore D from fun _ h=>(mem_filter.mp h).1)
    refine ⟨by omega,fun w wm=>near_card_of_one_miss (near_of_vis_dist wm ?_)⟩
    intro z zm
    have wz := hc.dist_triangle (u:=w) (v:=x) (w:=z)
    have one (t : V) (tm : t∈Shore D) : G.dist x t≤1 := by
      rcases xall t tm with h|h
      · rw [h,SimpleGraph.dist_self]; omega
      · rw [dist_eq_one_iff_adj.mpr h]
    have ww := one w (mem_filter.mp wm).1
    have zz := one z (mem_filter.mp zm).1
    rw [dist_comm (G:=G) (u:=w) (v:=x)] at wz
    omega
  have bport (x : V) (xm : x∈Vis D) : G.Adj b x := by
    obtain ⟨xd,h⟩ := mem_filter.mp xm
    by_cases xb : G.Adj b x
    · exact xb
    exact (ax ⟨x,xd,h.resolve_right xb,xb⟩).elim
  have local' (w : V) (wm : w∈Vis D) :
      ((Shore D).filter (fun z=>z≠w ∧ ¬G.Adj w z)).card≤1 := by
    apply near_of_vis_dist wm
    intro z zm
    have e := G.dist_le (Walk.cons (bport w wm).symm (Walk.cons (bport z zm) .nil))
    simpa using e
  refine ⟨?_,fun w wm=>near_card_of_one_miss (local' w wm)⟩
  let E := (Shore D).filter (fun z=>Even (G.dist b z))
  have bq : b≠q := fun e=>(shore_off C).2 (e.symm ▸ qm)
  have qd := (mem_filter.mp (d2 hc bq nq ab.symm aq)).2
  have eq : insert q E⊆PositiveEven G b := by
    intro z zm
    rcases mem_insert.mp zm with h|h
    · rw [h]
      exact mem_positive.mpr ⟨bq.symm,by rw [qd]; decide⟩
    obtain ⟨zd,ev⟩ := mem_filter.mp h
    exact mem_positive.mpr ⟨fun e=>(shore_off D).2 (e ▸ zd),ev⟩
  have cap := (card_le_card eq).trans (positive_cap b even)
  have qo : q∉E := fun e=>disjoint_left.mp (shore_disjoint cd) qm (mem_filter.mp e).1
  rw [card_insert_of_not_mem qo] at cap
  let N := (Shore D).filter (fun z=>z≠p ∧ ¬G.Adj p z)
  have n1 : N.card≤1 := local' p pk
  have sub : Shore D⊆Vis D∪(E∪N) := by
    intro z zd
    by_cases vis : z∈Vis D
    · exact mem_union_left _ vis
    have zp : z≠p := fun e=>vis (e.symm ▸ pk)
    by_cases pz : G.Adj p z
    · have bz : b≠z := fun e=>(shore_off D).2 (e.symm ▸ zd)
      have nb : ¬G.Adj b z := fun h=>vis (mem_filter.mpr ⟨zd,.inr h⟩)
      have d := (mem_filter.mp (d2 hc bz nb bp pz)).2
      exact mem_union_right _ (mem_union_left _ (mem_filter.mpr ⟨zd,by rw [d]; decide⟩))
    · exact mem_union_right _ (mem_union_right _ (mem_filter.mpr ⟨zd,zp,pz⟩))
  have p := (card_le_card sub).trans (card_union_le (Vis D) (E∪N))
  have j := card_union_le E N
  omega

/-- A four-vertex shore and a nine-vertex shore are traceable when the four-shore
is all common, or it has one exceptional left-only port and three common ports.
For the all-common clause assume the cut has an exclusive port in the nine-shore. -/
theorem traceable_of_adjacent_four_nine_oriented (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ x,(EvenFrom G x).card≤6)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    {C D : RouteCmp G a b} (cd : C≠D)
    (cover : ∀ {z : V}, z≠a → z≠b → z∈Shore C ∨ z∈Shore D)
    (c4 : (Shore C).card=4) (d9 : (Shore D).card=9)
    (shape : ((∀ z∈Shore C,G.Adj a z ∧ G.Adj b z) ∧
       ∃ x∈Shore D,(G.Adj a x ∧ ¬G.Adj b x) ∨ (G.Adj b x ∧ ¬G.Adj a x)) ∨
      ∃ q∈Shore C,G.Adj a q ∧ ¬G.Adj b q ∧ ∀ z∈Shore C,z≠q → G.Adj a z ∧ G.Adj b z) :
    ∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support := by
  classical
  have allRoute {r t : V} (rm : r∈Vis D) (path : RouteOn G (Shore D) r t)
      (al : MixedRootCases C a) (bl : MixedRootCases C b) :
      ∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support := by
    have run {x y : V} (xy : G.Adj x y) (xo : ∀ K : RouteCmp G a b,x∉Shore K)
        (yo : ∀ K : RouteCmp G a b,y∉Shore K)
        (cov : ∀ {z : V}, z≠x → z≠y → z∈Shore C ∨ z∈Shore D)
        (bd : ∀ u∈Shore C,∀ z,G.Adj u z → z=x ∨ z=y ∨ z∈Shore C)
        (root : MixedRootCases C x) (yr : G.Adj y r) :
        ∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support := by
      obtain ⟨s,p⟩ := augment_both_one_or_two xy (xo C) (yo C) (by omega) bd root
      have apart : Disjoint (insert y (insert x (Shore C))) (Shore D) := by
        apply disjoint_left.mpr
        intro u um ud
        rcases mem_insert.mp um with rfl|um
        · exact yo D ud
        rcases mem_insert.mp um with rfl|um
        · exact xo D ud
        exact disjoint_left.mp (shore_disjoint cd) um ud
      obtain ⟨w,wp,ws⟩ := p.reverse.join path apart yr
      refine ⟨s,t,w,wp,fun v=>(ws v).mpr ?_⟩
      by_cases e : v=x
      · simp [e]
      by_cases f : v=y
      · simp [f]
      rcases cov e f with h|h <;> simp [h]
    rcases (mem_filter.mp rm).2 with ar|br
    · exact run ab.symm (fun K=>(shore_off K).2) (fun K=>(shore_off K).1)
        (fun nb na=>cover na nb) (fun u um z uz=>by simpa only [or_left_comm] using shore_closed C u um z uz)
        bl ar
    · exact run ab (fun K=>(shore_off K).1) (fun K=>(shore_off K).2) cover
        (shore_closed C) al br
  rcases shape with ⟨common,x,xd,e⟩|⟨q,qm,aq,bq,cq⟩
  · have casesAny {x : V} (add : ∀ u∈Shore C,G.Adj x u) : MixedRootCases C x := by
      by_cases h : ∀ u∈Shore C,5≤G.degree u
      · obtain ⟨u,um⟩ := card_pos.mp (show 0<(Shore C).card by omega)
        exact .inl ⟨h,u,um,add u um⟩
      push_neg at h
      obtain ⟨l,lm,ld⟩ := h
      exact .inr ⟨l,lm,fun u _ e=>(degree u l e).resolve_right (by omega),
        .inl ⟨add l lm,inside_neighbor_of_nonsingle lm (by omega)⟩⟩
    have run {s : V} (xs : G.Adj s x) (so : s∉Shore D)
        (r : x∈Vis D) (sp : ∀ z∈Shore D,G.Adj s z → z∈Vis D)
        (u : ∀ z∈Shore D,z=x ∨ G.Adj x z) :
        ∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support := by
      have dark : Shore D \ Vis D⊆PositiveEven G s := by
        intro z zm
        obtain ⟨zd,zv⟩ := mem_sdiff.mp zm
        have n : ¬G.Adj s z := fun h=>zv (sp _ zd h)
        have sz : s≠z := fun e=>so (e.symm ▸ zd)
        have xz := (u z zd).resolve_left (fun e=>n (e.symm ▸ xs))
        have d := (mem_filter.mp (d2 hc sz n xs xz)).2
        exact mem_positive.mpr ⟨sz.symm,by rw [d]; decide⟩
      have f := (card_le_card dark).trans (positive_cap s even)
      have g := card_sdiff_add_card_eq_card (show Vis D⊆Shore D from fun _ h=>(mem_filter.mp h).1)
      obtain ⟨r,rm,t,p⟩ := near_universal_route_of_nine_shore degree d9 (by omega) (.inr ⟨x,r,u⟩)
        (fun _ h=>four_common_sees_visible hc even cd c4 common u h)
      exact allRoute rm p (casesAny (fun z zm=>(common z zm).1)) (casesAny (fun z zm=>(common z zm).2))
    rcases e with ⟨ax,nx⟩|⟨bx,nx⟩
    · exact run ax (shore_off D).1 (mem_filter.mpr ⟨xd,.inl ax⟩) (fun _ zd az=>mem_filter.mpr ⟨zd,.inl az⟩)
        (four_common_exclusive_univ hc even cd c4 ab ax nx xd (shore_off C).2 (shore_off D).2 (fun z zm=>(common z zm).1))
    · exact run bx (shore_off D).2 (mem_filter.mpr ⟨xd,.inr bx⟩) (fun _ zd bz=>mem_filter.mpr ⟨zd,.inr bz⟩)
        (four_common_exclusive_univ hc even cd c4 ab.symm bx nx xd (shore_off C).1 (shore_off D).1 (fun z zm=>(common z zm).2))
  have lo := degree_le_shore C qm (.inr bq)
  rw [c4] at lo
  have h (u : V) (_ : u∈Shore C) (uq : u≠q) : 5≤G.degree u :=
    (degree u q uq).resolve_right (by omega)
  have dh (u : V) (um : u∈Shore D) : 5≤G.degree u :=
    (degree u q (fun e=>disjoint_left.mp (shore_disjoint cd) qm (e ▸ um))).resolve_right (by omega)
  have al : MixedRootCases C a := .inr ⟨q,qm,h,.inl ⟨aq,inside_neighbor_of_nonsingle qm (by omega)⟩⟩
  have bl : MixedRootCases C b := by
    obtain ⟨r,rm,br⟩ := shore_hit_b ab.ne conn C
    have rq : r≠q := fun e=>bq (e ▸ br)
    -- Because all three high vertices in the size-four shore have degree five,
    -- each is adjacent to q; choose one different from the b-port r.
    have cap (u : V) (um : u∈Shore C) (uq : u≠q) : G.Adj q u := by
      by_contra e
      have sub : G.neighborFinset u⊆insert a (insert b (((Shore C).erase u).erase q)) := by
        intro z zm
        have uz := (mem_neighborFinset G u z).mp zm
        rcases shore_closed C u um z uz with rfl|rfl|zc
        · simp
        · simp
        exact mem_insert_of_mem (mem_insert_of_mem (mem_erase.mpr
          ⟨fun e'=>e (e' ▸ uz.symm),mem_erase.mpr ⟨uz.ne.symm,zc⟩⟩))
      have p := card_le_card sub
      have i := card_insert_le a (insert b (((Shore C).erase u).erase q))
      have j := card_insert_le b (((Shore C).erase u).erase q)
      have k : (((Shore C).erase u).erase q).card=2 := by
        rw [card_erase_of_mem,card_erase_of_mem um,c4]
        exact mem_erase.mpr ⟨uq.symm,qm⟩
      have d := h u um uq
      rw [card_neighborFinset_eq_degree] at p
      omega
    have sz : 2≤(((Shore C).erase q).erase r).card := by
      rw [card_erase_of_mem,card_erase_of_mem qm,c4]
      exact mem_erase.mpr ⟨rq,rm⟩
    obtain ⟨v,vm⟩ := card_pos.mp (show 0<(((Shore C).erase q).erase r).card by omega)
    obtain ⟨vr,vm'⟩ := mem_erase.mp vm
    obtain ⟨vq,vs⟩ := mem_erase.mp vm'
    exact .inr ⟨q,qm,h,.inr ⟨r,rm,v,vs,rq,vr.symm,br,cap v vs vq⟩⟩
  obtain ⟨k4,near⟩ := mixed_nine_from_four_left_exclusive hc ab even conn cd c4 d9 qm aq bq cq
  obtain ⟨r,rm,t,p⟩ := near_universal_route_of_nine_shore degree d9 k4 (.inl dh) near
  exact allRoute rm p al bl

/-- Reversing the distinguished cut vertices leaves all shores unchanged. -/
private def swap_cut_graph : (CutGraph (G:=G) a b) ≃g (CutGraph (G:=G) b a) where
  toEquiv :=
    ⟨fun x=>⟨x.val,x.property.2,x.property.1⟩,
      fun x=>⟨x.val,x.property.2,x.property.1⟩,
      fun _=>rfl,fun _=>rfl⟩
  map_rel_iff' := Iff.rfl

private abbrev swapCut :
    (CutGraph (G:=G) a b).ConnectedComponent ≃ (CutGraph (G:=G) b a).ConnectedComponent :=
  swap_cut_graph.connectedComponentEquiv

theorem shore_swapCut (C : (CutGraph (G:=G) a b).ConnectedComponent) :
    Shore (swapCut C) = Shore C := by
  ext v
  rw [mem_shore,mem_shore]
  constructor
  · rintro ⟨h,e⟩
    have e' : swapCut ((CutGraph (G:=G) a b).connectedComponentMk ⟨v,h.2,h.1⟩) = swapCut C := e
    exact ⟨⟨h.2,h.1⟩,swapCut.injective e'⟩
  · rintro ⟨h,e⟩
    exact ⟨⟨h.2,h.1⟩,congrArg swapCut e⟩

theorem traceable_of_adjacent_four_nine_non_twin (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ x,(EvenFrom G x).card≤6)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    {C D : RouteCmp G a b} (cd : C≠D)
    (cover : ∀ {z : V}, z≠a → z≠b → z∈Shore C ∨ z∈Shore D)
    (c4 : (Shore C).card=4) (d9 : (Shore D).card=9)
    (nt : ¬∀ z,z≠a → z≠b → (G.Adj a z ↔ G.Adj b z)) :
    ∃ s t,∃ p : G.Walk s t,p.IsPath ∧ ∀ z,z∈p.support := by
  classical
  rcases mixed_four_exclusive_profile hc ab even degree cd c4 d9 with common|⟨q,qm,_,nonc,e,other⟩
  · have e : ∃ x∈Shore D,(G.Adj a x ∧ ¬G.Adj b x) ∨ (G.Adj b x ∧ ¬G.Adj a x) := by
      by_contra h
      apply nt
      intro z za zb
      rcases cover za zb with zm|zm
      · exact iff_of_true (common z zm).1 (common z zm).2
      constructor
      · intro az
        by_contra bz
        exact h ⟨z,zm,.inl ⟨az,bz⟩⟩
      · intro bz
        by_contra az
        exact h ⟨z,zm,.inr ⟨bz,az⟩⟩
    exact traceable_of_adjacent_four_nine_oriented hc ab even conn degree cd cover c4 d9
      (.inl ⟨common,e⟩)
  rcases e with aq|bq
  · exact traceable_of_adjacent_four_nine_oriented hc ab even conn degree cd cover c4 d9
      (.inr ⟨q,qm,aq,fun h=>nonc ⟨aq,h⟩,other⟩)
  have shC := shore_swapCut C
  have shD := shore_swapCut D
  exact traceable_of_adjacent_four_nine_oriented hc ab.symm even conn degree
    (fun h=>cd (swapCut.injective h)) (fun zb za=>by rw [shC,shD]; exact cover za zb)
    (shC.symm ▸ c4) (shD.symm ▸ d9)
    (.inr ⟨q,shC.symm ▸ qm,bq,fun h=>nonc ⟨h,bq⟩,
      fun z zm zq=>(other z (shC ▸ zm) zq).symm⟩)

#print axioms mixed_four_exclusive_profile
#print axioms traceable_of_adjacent_four_nine_oriented
#print axioms traceable_of_adjacent_four_nine_non_twin
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
