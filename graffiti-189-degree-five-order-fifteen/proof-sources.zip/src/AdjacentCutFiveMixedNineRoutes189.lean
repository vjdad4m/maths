import AdjacentCutFiveMixedFourRoutes189
import AdjacentCutFiveMixedSlack189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset ArticulationPair
open private CutGraph Shore shore_closed shore_off shore_disjoint from AdjacentCutFiveActual189
open private Vis positive_cap foreign_pos_even from AdjacentCutFiveComponents189
open private d2 mem_positive from AdjacentCutFiveBound189
open private lift_side_path from DegreeFiveSmallSides189
open private four_common_exclusive_univ four_common_sees_visible from AdjacentCutFiveMixedFourRoutes189
open private MixedRootCases from AdjacentCutFiveMixedSevenEight189
open private inside_neighbor_of_nonsingle degree_two_if_nonadjacent from AdjacentCutFiveMixedTwoAugment189
open private augment_both_one_or_two from AdjacentCutFiveMixedBothTerminals189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev RouteCmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

private theorem near_universal_route_of_nine_shore
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    {D : RouteCmp G a b} (d9 : (Shore D).card=9)
    (k4 : 4≤(Vis D).card)
    (low : (∀ u∈Shore D,5≤G.degree u) ∨
      ∃ x∈Vis D,∀ w∈Shore D,w=x ∨ G.Adj x w)
    (near : ∀ w∈Vis D,(Shore D).card≤(inside G (Shore D) w).card+2) :
    ∃ x∈Vis D,∃ t,RouteOn G (Shore D) x t := by
  classical
  let S := Shore D
  let U := ↑(↑S : Set V)
  let J := G.induce (↑S : Set V)
  let K : Finset U := univ.filter (fun x=>x.val∈Vis D)
  let high (x : U) := 5≤G.degree x.val
  have sc : Fintype.card U=9 := (show Fintype.card U=S.card from Fintype.card_coe S).trans d9
  have kc : K.card=(Vis D).card := by
    apply card_bij (fun u _=>u.val)
    · exact fun u h=>(mem_filter.mp h).2
    · exact fun u _ v _ h=>Subtype.ext h
    · intro u h
      exact ⟨⟨u,(mem_filter.mp h).1⟩,mem_filter.mpr ⟨mem_univ _,h⟩,rfl⟩
  have kh : 4≤K.card := kc.symm ▸ k4
  have near' (u : U) (uk : u∈K) : 7≤J.degree u := by
    have h := near u.val (mem_filter.mp uk).2
    rw [inside_card_eq_degree_induce (G:=G) S u,d9] at h
    change 7≤(G.induce (↑S : Set V)).degree u
    omega
  have hk (u : U) (uk : u∈K) : high u := by
    have sub : inside G S u.val ⊆ G.neighborFinset u.val :=
      fun z h=>(mem_neighborFinset G u.val z).mpr (mem_filter.mp h).2
    have h := card_le_card sub
    rw [inside_card_eq_degree_induce (G:=G) S u,card_neighborFinset_eq_degree] at h
    have p := near' u uk
    change 7≤(G.induce (↑S : Set V)).degree u at p
    change 5≤G.degree u.val
    omega
  have dark (u : U) (uk : u∉K) : ¬G.Adj a u.val ∧ ¬G.Adj b u.val := by
    constructor
    · exact fun e=>uk (mem_filter.mpr ⟨mem_univ _,mem_filter.mpr ⟨u.property,.inl e⟩⟩)
    · exact fun e=>uk (mem_filter.mpr ⟨mem_univ _,mem_filter.mpr ⟨u.property,.inr e⟩⟩)
  have allN (u : U) (uk : u∉K) : G.neighborFinset u.val ⊆ S := by
    intro z zm
    have adj := (mem_neighborFinset G u.val z).mp zm
    rcases shore_closed D u.val u.property z adj with rfl|rfl|h
    · exact ((dark u uk).1 adj.symm).elim
    · exact ((dark u uk).2 adj.symm).elim
    exact h
  have dh (u : U) (uh : high u) : 5≤J.degree u := by
    by_cases k : u∈K
    · exact (by omega : 5≤7).trans (near' u k)
    have inc : G.neighborFinset u.val⊆inside G S u.val :=
      fun _ m=>mem_filter.mpr ⟨allN u k m,(mem_neighborFinset G _ _).mp m⟩
    have q := card_le_card inc
    rw [card_neighborFinset_eq_degree,inside_card_eq_degree_induce (G:=G) S u] at q
    exact uh.trans q
  let H : SimpleGraph U :=
    ⟨fun u v=>J.Adj u v ∨ (u≠v ∧ high u ∧ high v ∧ (u∈K ∨ v∈K)),
      by
        intro u v
        rintro (e|⟨ne,uH,vH,k⟩)
        · exact .inl e.symm
        exact .inr ⟨ne.symm,vH,uH,k.symm⟩,
      by intro u; rintro (e|⟨n,_,_,_⟩); exact J.loopless u e; exact n rfl⟩
  letI : DecidableRel H.Adj := Classical.decRel H.Adj
  have sub : J≤H := fun _ _ h=>.inl h
  have ore (u v : U) (uv : H.Adj u v) (notJ : ¬J.Adj u v) :
      Fintype.card U≤J.degree u+J.degree v := by
    change J.Adj u v ∨ (u≠v ∧ high u ∧ high v ∧ (u∈K ∨ v∈K)) at uv
    obtain ⟨_,uH,vH,h⟩ := uv.resolve_left notJ
    rcases h with uk|vk
    · have p := near' u uk
      have q := dh v vH
      omega
    have p := near' v vk
    have q := dh u uH
    omega
  have lift {x t : U} (xK : x∈K) (p : RouteOn H univ x t) :
      ∃ x∈Vis D,∃ t,RouteOn G S x t := by
    obtain ⟨q,qp,qs⟩ := p
    obtain ⟨w,r,rp,rs⟩ := Graffiti189Ore.rooted_closure sub x ore
      ⟨t,q,qp,fun u=>(qs u).mpr (mem_univ _)⟩
    exact ⟨x.val,(mem_filter.mp xK).2,w.val,lift_side_path S r rp rs⟩
  have dark_deg (u : U) (uk : u∉K) (uh : high u) : 5≤J.degree u := by
    have inc : G.neighborFinset u.val⊆inside G S u.val :=
      fun _ m=>mem_filter.mpr ⟨allN u uk m,(mem_neighborFinset G _ _).mp m⟩
    have q := card_le_card inc
    rw [card_neighborFinset_eq_degree,inside_card_eq_degree_induce (G:=G) S u] at q
    exact uh.trans q
  by_cases n : ∀ u : U, high u
  · let R := (univ : Finset U) \ K
    have part : K∪R=(univ : Finset U) := union_sdiff_of_subset (subset_univ _)
    have dis : Disjoint K R := disjoint_left.mpr (fun _ hm hr=>(mem_sdiff.mp hr).2 hm)
    have rc : R.card+K.card=9 := by
      have p := card_sdiff_add_card_eq_card (subset_univ K)
      rw [card_univ,sc] at p
      exact p
    have join : ∀ x∈K,∀ y∈K∪R,x≠y → H.Adj x y :=
      fun x xk y _ xy=>Or.inr ⟨xy,hk x xk,n y,.inl xk⟩
    have save (e : R.card=K.card+1) : ∃ u∈R,∃ v∈R,H.Adj u v := by
      obtain ⟨w,wm⟩ := card_pos.mp (show 0<R.card by omega)
      have wk := (mem_sdiff.mp wm).2
      have deg := dark_deg w wk (n w)
      have ed : ∃ z∈R,J.Adj w z := by
        by_contra h
        have s : J.neighborFinset w⊆K := by
          intro z zm
          by_cases zk : z∈K
          · exact zk
          exact (h ⟨z,mem_sdiff.mpr ⟨mem_univ _,zk⟩,(mem_neighborFinset J _ _).mp zm⟩).elim
        have t := card_le_card s
        rw [card_neighborFinset_eq_degree] at t
        omega
      obtain ⟨z,zm,wz⟩ := ed
      exact ⟨w,wm,z,zm,sub wz⟩
    obtain ⟨x,xk⟩ := card_pos.mp (show 0<K.card by omega)
    obtain ⟨t,p⟩ := universal_route_from_singletons_or_one_edge K R xk dis join (by omega) save
    exact lift xk (part ▸ p)
  push_neg at n
  obtain ⟨l,nl⟩ := n
  have h' (u : U) (ne : u≠l) : high u := (degree u.val l.val
    (fun e=>ne (Subtype.ext e))).resolve_right nl
  have lk : l∉K := fun h=>nl (hk l h)
  obtain ⟨v,vv,vall⟩ := low.resolve_left (fun z=>nl (z l.val l.property))
  let w : U := ⟨v,(mem_filter.mp vv).1⟩
  have wk : w∈K := mem_filter.mpr ⟨mem_univ _,vv⟩
  have wl : J.Adj w l := (vall l.val l.property).resolve_left
    (fun e=>lk ((congrArg (fun z : U => z∈K) (show w=l from (Subtype.ext e).symm)).mp wk))
  let R := ((univ : Finset U).erase l) \ K
  let K' := K.erase w
  have sub' : K⊆(univ : Finset U).erase l := by
    intro u um
    exact mem_erase.mpr ⟨fun e=>lk (e ▸ um),mem_univ _⟩
  have ru : K∪R=(univ : Finset U).erase l := union_sdiff_of_subset sub'
  have dis : Disjoint K R := disjoint_left.mpr (fun _ hm hr=>(mem_sdiff.mp hr).2 hm)
  have rc : R.card+K.card=8 := by
    have p := card_sdiff_add_card_eq_card sub'
    rw [card_erase_of_mem (mem_univ _),card_univ,sc] at p
    exact p
  have kc' : K'.card=K.card-1 := card_erase_of_mem wk
  have join : ∀ x∈K,∀ y∈K∪R,x≠y → H.Adj x y := by
    intro x xk y ym ne
    rw [ru] at ym
    exact .inr ⟨ne,hk x xk,h' y (mem_erase.mp ym).1,.inl xk⟩
  have save (e : R.card=K'.card+1) : ∃ u∈R,∃ v∈R,H.Adj u v := by
    by_contra bad
    have k : K.card=4 := by omega
    have r : R.card=4 := by omega
    have all (u : U) (um : u∈R) : J.Adj u l := by
      by_contra no
      obtain ⟨uh,rk⟩ := mem_sdiff.mp um
      have deg := dark_deg u rk (h' u (mem_erase.mp uh).1)
      have s : J.neighborFinset u⊆K := by
        intro z zm
        by_cases zk : z∈K
        · exact zk
        have uz := (mem_neighborFinset J _ _).mp zm
        have zl : z≠l := fun h=>no (h ▸ uz)
        exact (bad ⟨u,um,z,mem_sdiff.mpr ⟨mem_erase.mpr ⟨zl,mem_univ _⟩,zk⟩,sub uz⟩).elim
      have c := card_le_card s
      rw [card_neighborFinset_eq_degree] at c
      omega
    have rs : insert w R⊆J.neighborFinset l := by
      intro z zm
      rcases mem_insert.mp zm with rfl|h
      · exact (mem_neighborFinset J _ _).mpr wl.symm
      · exact (mem_neighborFinset J _ _).mpr (all _ h).symm
    have woff : w∉R := fun wr=>disjoint_left.mp dis wk wr
    have q := card_le_card rs
    rw [card_insert_of_not_mem woff,r,card_neighborFinset_eq_degree] at q
    have subN : inside G S l.val⊆G.neighborFinset l.val := by
      intro z zm
      exact (mem_neighborFinset G _ _).mpr (mem_filter.mp zm).2
    have grd := card_le_card subN
    rw [inside_card_eq_degree_induce (G:=G) S l,card_neighborFinset_eq_degree] at grd
    have t : 5≤G.degree l.val := by
      change 5≤(G.induce (↑S : Set V)).degree l at q
      omega
    exact nl t
  obtain ⟨x,xm⟩ := card_pos.mp (show 0<K'.card by omega)
  have subK : K'⊆K := erase_subset _ _
  obtain ⟨t,p⟩ := universal_route_from_singletons_or_one_edge K' R xm
    (dis.mono_left subK)
    (fun u um v vm uv=>join u (subK um) v (union_subset_union subK (Subset.rfl) vm) uv)
    (by omega) save
  have tm : t∈K'∪R := by
    obtain ⟨s,_,hs⟩ := p
    exact (hs t).mp s.end_mem_support
  have wo : w∉K'∪R := fun f=>(mem_union.mp f).elim
    (fun h=>(mem_erase.mp h).1 rfl)
    (fun h=>disjoint_left.mp dis wk h)
  have wt := join w wk t (union_subset_union subK (Subset.rfl) tm) (fun e=>wo (e.symm ▸ tm))
  have f : insert w (K'∪R)=K∪R := by rw [←insert_union,insert_erase wk]
  have p' : RouteOn H (K∪R) x w := f ▸ p.suffix wt.symm wo
  have eq : insert l (K∪R)=(univ : Finset U) := by rw [ru,insert_erase (mem_univ _)]
  exact lift (subK xm) (eq ▸ p'.suffix (sub wl) (by simp [ru]))

#print axioms near_universal_route_of_nine_shore
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
