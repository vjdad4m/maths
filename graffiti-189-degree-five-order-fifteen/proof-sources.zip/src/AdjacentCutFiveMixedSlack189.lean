import UniversalRouteSingletons189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph Finset
variable {W : Type*} {H : SimpleGraph W} [Fintype W] [DecidableEq W] [DecidableRel H.Adj]
set_option linter.unusedSectionVars false

theorem universal_route_from_singletons_or_one_edge
    (K R : Finset W) {x : W} (xk : x∈K)
    (apart : Disjoint K R)
    (join : ∀ u∈K,∀ v∈K∪R,u≠v → H.Adj u v)
    (room : R.card≤K.card+1)
    (saving : R.card=K.card+1 → ∃ u∈R,∃ v∈R,H.Adj u v) :
    ∃ t,RouteOn H (K∪R) x t := by
  classical
  by_cases h : R.card≤K.card
  · obtain ⟨t,p,_⟩ := universal_route_from_singletons K R xk apart join h
    exact ⟨t,p⟩
  obtain ⟨u,um,v,vm,uv⟩ := saving (by omega)
  let P : Finset W := {u,v}
  have sub : P⊆R := insert_subset_iff.mpr ⟨um,singleton_subset_iff.mpr vm⟩
  have c := card_sdiff_add_card_eq_card sub
  have p2 : P.card=2 := by simp [P,uv.ne]
  obtain ⟨t,p,_⟩ := universal_route_with_one_block K R P xk
    (by simp [P]) (by simp [P]) apart sub (RouteOn.edge uv) join (by omega)
  exact ⟨t,p⟩

#print axioms universal_route_from_singletons_or_one_edge
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
