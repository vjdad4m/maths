import AdjacentCutFiveTopArithmetic189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent.AdjProfile

set_option maxHeartbeats 1000000 in
theorem compact_sixteen_four (x y : AdjProfile)
    (sx : x.size=4) (sy : y.size=10)
    (lx : x.localOK) (_ly : y.localOK) (cut : x.cutOK y)
    (cx : x.crossOK y) (_cy : y.crossOK x) : x.oc=4 := by
  have c3 := lx.2.2.2.2.2.2 sx
  unfold size at sx sy
  by_contra no
  have c : x.oc=3 := by omega
  by_cases oa : 0<x.oa
  · have r := cx.2.2.2.1 oa
    have q := cut.1
    omega
  by_cases ob : 0<x.ob
  · have r := cx.2.2.2.2.1 ob
    have q := cut.2
    omega
  have ea : x.ea=0 := by have h:=lx.2.2.2.2.1; omega
  have eb : x.eb=0 := by have h:=lx.2.2.2.2.2.1; omega
  have ec : x.ec=1 := by omega
  have yEven := cx.2.2.1 (by omega : 0<x.ec)
  have yOdd := cx.2.2.2.2.2 (by omega : 0<x.oc)
  omega

def fiveA (x y : AdjProfile) : Prop :=
  x.ea=0 ∧ x.eb=0 ∧ x.ec=0 ∧ x.oa=1 ∧ x.ob=0 ∧ x.oc=4 ∧
  y.ea=0 ∧ y.oa=0 ∧ y.ob=y.eb+1 ∧ y.oc=y.ec ∧ y.eb+y.ec=4 ∧ 1≤y.ec

def fiveB (x y : AdjProfile) : Prop :=
  x.ea=0 ∧ x.eb=0 ∧ x.ec=0 ∧ x.oa=0 ∧ x.ob=1 ∧ x.oc=4 ∧
  y.eb=0 ∧ y.ob=0 ∧ y.oa=y.ea+1 ∧ y.oc=y.ec ∧ y.ea+y.ec=4 ∧ 1≤y.ec

set_option maxHeartbeats 1000000 in
theorem compact_sixteen_five (x y : AdjProfile)
    (sx : x.size=5) (sy : y.size=9)
    (lx : x.localOK) (ly : y.localOK) (cut : x.cutOK y)
    (cx : x.crossOK y) (cy : y.crossOK x)
    (asym : 0<x.oa+x.ob+y.oa+y.ob) : fiveA x y ∨ fiveB x y := by
  unfold size at sx sy
  by_cases oa : 0<x.oa
  · left
    have r := cx.2.2.2.1 oa
    have tA := cut.1
    have tB := cut.2
    have zero : x.ea=0 ∧ x.ec=0 ∧ x.ob=0 := by omega
    obtain ⟨xe,xc,xb⟩ := zero
    have yBalA : y.ea+y.ec+y.ob=5 := by omega
    have yBalCross : y.eb+y.oa+y.oc=4 := by omega
    have xeb : x.eb=0 := by have h:=lx.2.2.2.2.2.1; omega
    have xodd : x.oa+x.oc=5 := by omega
    have co : 0<x.oc := by have p:=lx.2.2.2.1; omega
    have yoa : y.oa=0 := by
      by_contra h
      have r' := cy.2.2.2.1 (by omega : 0<y.oa)
      omega
    have yea : y.ea=0 := by have h:=ly.2.2.2.2.1; omega
    have sumOdd := cx.2.2.2.2.2 co
    have realA := ly.2.2.1
    unfold fiveA
    omega
  by_cases ob : 0<x.ob
  · right
    have r := cx.2.2.2.2.1 ob
    have tA := cut.1
    have tB := cut.2
    have zero : x.eb=0 ∧ x.ec=0 ∧ x.oa=0 := by omega
    obtain ⟨xe,xc,xa⟩ := zero
    have yBalB : y.eb+y.ec+y.oa=5 := by omega
    have yBalCross : y.ea+y.ob+y.oc=4 := by omega
    have xea : x.ea=0 := by have h:=lx.2.2.2.2.1; omega
    have xodd : x.ob+x.oc=5 := by omega
    have co : 0<x.oc := by have p:=lx.2.2.1; omega
    have yob : y.ob=0 := by
      by_contra h
      have r' := cy.2.2.2.2.1 (by omega : 0<y.ob)
      omega
    have yeb : y.eb=0 := by have h:=ly.2.2.2.2.2.1; omega
    have sumOdd := cx.2.2.2.2.2 co
    have realB := ly.2.2.2.1
    unfold fiveB
    omega
  have ea : x.ea=0 := by have h:=lx.2.2.2.2.1; omega
  have eb : x.eb=0 := by have h:=lx.2.2.2.2.2.1; omega
  have co : 0<x.oc := by have p:=lx.2.2.1; omega
  have ec : x.ec=0 := by
    by_contra nz
    have xce := cx.2.2.1 (by omega : 0<x.ec)
    have xco := cx.2.2.2.2.2 co
    omega
  have oc : x.oc=5 := by omega
  have ya : y.oa=0 := by
    by_contra h
    have e := cy.2.2.2.1 (by omega : 0<y.oa)
    omega
  have yb : y.ob=0 := by
    by_contra h
    have e := cy.2.2.2.2.1 (by omega : 0<y.ob)
    omega
  omega

#print axioms compact_sixteen_four
#print axioms compact_sixteen_five
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent.AdjProfile
