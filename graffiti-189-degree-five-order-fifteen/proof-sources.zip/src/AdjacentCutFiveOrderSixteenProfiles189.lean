import AdjacentCutFiveTopSeventeen189
import AdjacentCutFiveOrderSixteenArithmetic189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph Shore shore_off shore_connected shore_hit_a shore_hit_b
  from AdjacentCutFiveActual189
open private key classSet prof sa sb pa key_facts profile_size from AdjacentCutFiveTopProfiles189
open private local_profile_conditions cut_profile_budget cross_profile_budget
  all_common_of_four_equal_odd from AdjacentCutFiveTopFlatten189
open private all_common_incidence_of_symmetric_profile from AdjacentCutFiveTopSeventeen189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

theorem all_common_of_adjacent_four_ten_shores
    (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ z,(EvenFrom G z).card≤6)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    {C D : Cmp G a b} (cd : C≠D)
    (four : (Shore C).card=4) (ten : (Shore D).card=10) :
    ∀ z∈Shore C,G.Adj a z ∧ G.Adj b z := by
  apply all_common_of_four_equal_odd hc ab degree four
  exact AdjProfile.compact_sixteen_four (prof C) (prof D)
    (by rwa [profile_size]) (by rwa [profile_size])
    (local_profile_conditions hc ab conn degree (by omega))
    (local_profile_conditions hc ab conn degree (by omega))
    (cut_profile_budget hc ab even cd)
    (cross_profile_budget hc ab even cd)
    (cross_profile_budget hc ab even cd.symm)

private theorem key_card_pos {C : Cmp G a b} {i : Fin 6} {z : V}
    (zc : z∈Shore C) (ki : key G a b z=i) : 0<(classSet C i).card :=
  card_pos.mpr ⟨z,mem_filter.mpr ⟨zc,ki⟩⟩

private theorem depth_one_of_even_classes_empty (hc : G.Connected) (ab : G.Adj a b)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    {C : Cmp G a b}
    (e0 : (classSet C 0).card=0) (e1 : (classSet C 1).card=0) (e2 : (classSet C 2).card=0) :
    ∀ z∈Shore C,depth G a b z=1 := by
  classical
  have odd (z : V) (zc : z∈Shore C) : (depth G a b z)%2=1 := by
    have d := (key_facts hc ab z).2.2
    generalize hk : key G a b z = k
    have forms : k=0 ∨ k=1 ∨ k=2 ∨ k=3 ∨ k=4 ∨ k=5 :=
      (by decide : ∀ i : Fin 6,i=0 ∨ i=1 ∨ i=2 ∨ i=3 ∨ i=4 ∨ i=5) k
    rcases forms with h|h|h|h|h|h
    · have p := key_card_pos zc (hk.trans h); omega
    · have p := key_card_pos zc (hk.trans h); omega
    · have p := key_card_pos zc (hk.trans h); omega
    · simpa [hk,h,pa] using d
    · simpa [hk,h,pa] using d
    · simpa [hk,h,pa] using d
  obtain ⟨p,pc,ap⟩ := shore_hit_a ab.ne conn C
  have pb : p≠b := fun e=>(shore_off C).2 (e ▸ pc)
  have dp : depth G a b p=1 := by
    have bpos := hc.pos_dist_of_ne (u:=b) (v:=p) pb.symm
    unfold depth
    rw [dist_eq_one_iff_adj.mpr ap]
    omega
  let S := (↑(Shore C) : Set V)
  let H := G.induce S
  have run {u v : S} (w : H.Walk u v) (hd : depth G a b u.val=1) : depth G a b v.val=1 := by
    induction w with
    | nil => exact hd
    | @cons u x v e w ih =>
      apply ih
      have step := depth_step (a:=a) (b:=b) hc (show G.Adj x.val u.val from e.symm)
      have p := odd x.val x.property
      omega
  intro z zc
  obtain ⟨w⟩ := (shore_connected C).preconnected ⟨p,pc⟩ ⟨z,zc⟩
  exact run w dp

private theorem neighbors_of_light_classes
    (hc : G.Connected) (ab : G.Adj a b) {z : V} (h : depth G a b z=1) :
    (key G a b z=3 → G.Adj a z ∧ ¬G.Adj b z) ∧
    (key G a b z=4 → ¬G.Adj a z ∧ G.Adj b z) ∧
    (key G a b z=5 → G.Adj a z ∧ G.Adj b z) := by
  have k := key_facts hc ab z
  have no (u : V) (h : G.dist u z=2) : ¬G.Adj u z := by
    intro e
    have a := dist_eq_one_iff_adj.mpr e
    omega
  refine ⟨fun f=>?_,fun f=>?_,fun f=>?_⟩
  · rw [f,h] at k
    exact ⟨dist_eq_one_iff_adj.mp k.1,no _ k.2.1⟩
  · rw [f,h] at k
    exact ⟨no _ k.1,dist_eq_one_iff_adj.mp k.2.1⟩
  · rw [f,h] at k
    exact ⟨dist_eq_one_iff_adj.mp k.1,dist_eq_one_iff_adj.mp k.2.1⟩

private theorem one_exclusive_five_geometry (hc : G.Connected) (ab : G.Adj a b)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    {C : Cmp G a b} (four : (Shore C).card=5)
    (e0 : (classSet C 0).card=0) (e1 : (classSet C 1).card=0) (e2 : (classSet C 2).card=0)
    {i : Fin 6} (light : i=3 ∨ i=4) (one : (classSet C i).card=1)
    (fourCommon : (classSet C 5).card=4) :
    ∃ x∈Shore C,
      ((G.Adj a x ∧ ¬G.Adj b x) ∨ (G.Adj b x ∧ ¬G.Adj a x)) ∧
      ∀ z∈Shore C,z≠x → G.Adj a z ∧ G.Adj b z := by
  classical
  obtain ⟨x,single⟩ := card_eq_one.mp one
  have xm : x∈classSet C i := by simp [single]
  obtain ⟨xc,xi⟩ := mem_filter.mp xm
  have x5 : x∉classSet C 5 := by
    intro h
    have e := (mem_filter.mp h).2
    have ne : i≠5 := by rcases light with h|h <;> simp [h]
    exact ne (xi.symm.trans e)
  have all : insert x (classSet C 5)=Shore C := by
    apply eq_of_subset_of_card_le
    · intro z h
      rcases mem_insert.mp h with rfl|m
      · exact xc
      · exact (mem_filter.mp m).1
    rw [card_insert_of_not_mem x5,fourCommon,four]
  have ds := depth_one_of_even_classes_empty hc ab conn e0 e1 e2
  have rule := neighbors_of_light_classes hc ab (ds x xc)
  refine ⟨x,xc,?_,?_⟩
  · rcases light with k|k
    · exact .inl (rule.1 (xi.trans k))
    · have r := rule.2.1 (xi.trans k)
      exact .inr ⟨r.2,r.1⟩
  · intro z zc ne
    have sel : z∈classSet C 5 := (mem_insert.mp (all.symm ▸ zc)).resolve_left ne
    exact (neighbors_of_light_classes hc ab (ds z zc)).2.2 (mem_filter.mp sel).2

theorem one_exclusive_of_adjacent_five_nine_unequal_shores
    (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ z,(EvenFrom G z).card≤6)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    {C D : Cmp G a b} (cd : C≠D)
    (cover : ∀ {z : V},z≠a → z≠b → z∈Shore C ∨ z∈Shore D)
    (five : (Shore C).card=5) (nine : (Shore D).card=9)
    (notTwin : ¬∀ z,z≠a → z≠b → (G.Adj a z ↔ G.Adj b z)) :
    ∃ x∈Shore C,
      ((G.Adj a x ∧ ¬G.Adj b x) ∨ (G.Adj b x ∧ ¬G.Adj a x)) ∧
      ∀ z∈Shore C,z≠x → G.Adj a z ∧ G.Adj b z := by
  classical
  let P := prof C
  let Q := prof D
  have lc : P.localOK := local_profile_conditions hc ab conn degree (by omega)
  have rc : Q.localOK := local_profile_conditions hc ab conn degree (by omega)
  have asym : 0<P.oa+P.ob+Q.oa+Q.ob := by
    by_contra no
    have p : P.symmetricProfile := by simp only [AdjProfile.symmetricProfile,AdjProfile.localOK] at *; omega
    have q : Q.symmetricProfile := by simp only [AdjProfile.symmetricProfile,AdjProfile.localOK] at *; omega
    apply notTwin
    intro z za zb
    rcases cover za zb with zc|zd
    · exact all_common_incidence_of_symmetric_profile hc ab p z zc
    · exact all_common_incidence_of_symmetric_profile hc ab q z zd
  have l5 : P.size=5 := (profile_size C).trans five
  have r9 : Q.size=9 := (profile_size D).trans nine
  rcases AdjProfile.compact_sixteen_five P Q l5 r9 lc rc
    (cut_profile_budget hc ab even cd) (cross_profile_budget hc ab even cd)
    (cross_profile_budget hc ab even cd.symm) asym with h|h
  · exact one_exclusive_five_geometry hc ab conn five h.1 h.2.1 h.2.2.1
      (.inl rfl) h.2.2.2.1 h.2.2.2.2.2.1
  · exact one_exclusive_five_geometry hc ab conn five h.1 h.2.1 h.2.2.1
      (.inr rfl) h.2.2.2.2.1 h.2.2.2.2.2.1

#print axioms all_common_of_adjacent_four_ten_shores
#print axioms one_exclusive_of_adjacent_five_nine_unequal_shores
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
