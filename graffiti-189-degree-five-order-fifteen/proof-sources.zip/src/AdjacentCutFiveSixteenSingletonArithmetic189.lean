import AdjacentCutFiveTopArithmetic189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent.AdjProfile

set_option maxHeartbeats 1000000 in
theorem compact_sixteen_singleton (y : AdjProfile) (sy : y.size=13)
    (ly : y.localOK) (cut : (⟨0,0,0,0,0,1⟩ : AdjProfile).cutOK y)
    (cx : (⟨0,0,0,0,0,1⟩ : AdjProfile).crossOK y)
    (cy : y.crossOK ⟨0,0,0,0,0,1⟩) :
    y.ea=4 ∧ y.eb=4 ∧ y.ec=0 ∧ y.oa=1 ∧ y.ob=1 ∧ y.oc=3 := by
  simp only [localOK,cutOK,crossOK,size] at *
  omega

#print axioms compact_sixteen_singleton
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent.AdjProfile
