import AdjacentCutFiveTopFlatten189
import AdjacentCutFiveSixteenSingletonArithmetic189
import AdjacentCutFiveProfilePorts189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph Shore shore_off shore_closed shore_hit_a shore_hit_b from AdjacentCutFiveActual189
open private key classSet prof sa sb pa key_facts profile_size from AdjacentCutFiveTopProfiles189
open private local_profile_conditions cut_profile_budget cross_profile_budget key_a_port key_b_port
  from AdjacentCutFiveTopFlatten189
open private d2 from AdjacentCutFiveBound189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

private theorem compact_graph_singleton_profile
    (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ z,(EvenFrom G z).card≤6)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    {C D : Cmp G a b} (cd : C≠D)
    (one : (Shore C).card=1) (big : (Shore D).card=13) :
    ∃ s, Shore C={s} ∧ G.Adj a s ∧ G.Adj b s ∧
      (prof D).ea=4 ∧ (prof D).eb=4 ∧ (prof D).ec=0 ∧
      (prof D).oa=1 ∧ (prof D).ob=1 ∧ (prof D).oc=3 := by
  classical
  obtain ⟨s,eq⟩ := card_eq_one.mp one
  obtain ⟨u,uc,au⟩ := shore_hit_a ab.ne conn C
  obtain ⟨v,vc,bv⟩ := shore_hit_b ab.ne conn C
  have ueq : u=s := by simpa [eq] using uc
  have veq : v=s := by simpa [eq] using vc
  have as' : G.Adj a s := ueq ▸ au
  have bs' : G.Adj b s := veq ▸ bv
  have k : key G a b s=5 := by simp [key,dist_eq_one_iff_adj.mpr as',dist_eq_one_iff_adj.mpr bs']
  have source : prof C=⟨0,0,0,0,0,1⟩ := by simp [prof,classSet,eq,k,Finset.filter_singleton]
  have local' := local_profile_conditions hc ab conn degree (show 4≤(Shore D).card by omega)
  have cc := cut_profile_budget hc ab even cd
  have cr := cross_profile_budget hc ab even cd
  have cl := cross_profile_budget hc ab even cd.symm
  rw [source] at cc cr cl
  exact ⟨s,eq,as',bs',AdjProfile.compact_sixteen_singleton (prof D)
    ((profile_size D).trans big) local' cc cr cl⟩

private theorem predecessor_of_positive_dist (hc : G.Connected) {x t : V}
    (pos : 0<G.dist x t) :
    ∃ y, G.Adj x y ∧ G.dist x t=G.dist y t+1 := by
  obtain ⟨p,pl⟩ := hc.exists_walk_length_eq_dist x t
  cases p with
  | nil =>
    rw [dist_self] at pos
    omega
  | @cons x y t e p =>
    have l := G.dist_le p
    have h := hc.dist_triangle (u:=x) (v:=y) (w:=t)
    rw [dist_eq_one_iff_adj.mpr e] at h
    simp only [Walk.length_cons] at pl
    exact ⟨y,e,by omega⟩

private theorem depth_predecessor_on_shore (hc : G.Connected)
    {D : Cmp G a b} {z : V} (zd : z∈Shore D)
    (big : 2≤depth G a b z) :
    ∃ w∈Shore D,G.Adj z w ∧ depth G a b z=depth G a b w+1 := by
  have A : 2≤G.dist a z := by
    have l := min_le_left (G.dist a z) (G.dist b z)
    change 2≤min _ _ at big
    omega
  have B : 2≤G.dist b z := by
    have l := min_le_right (G.dist a z) (G.dist b z)
    change 2≤min _ _ at big
    omega
  have go {t : V} (tnear : depth G a b z=G.dist t z) :
      ∃ w∈Shore D,G.Adj z w ∧ G.dist z t=G.dist w t+1 := by
    have pos : 0<G.dist z t := by rw [dist_comm]; omega
    obtain ⟨w,zW,hw⟩ := predecessor_of_positive_dist hc pos
    have n : w∈Shore D := by
      rcases shore_closed D z zd w zW with ha|hb|n
      · have e := dist_eq_one_iff_adj.mpr zW.symm
        rw [ha] at e
        omega
      · have e := dist_eq_one_iff_adj.mpr zW.symm
        rw [hb] at e
        omega
      · exact n
    exact ⟨w,n,zW,hw⟩
  unfold depth at big ⊢
  by_cases le : G.dist a z≤G.dist b z
  · obtain ⟨w,wd,zw,hw⟩ := go (t:=a) (min_eq_left le)
    have t := hc.dist_triangle (u:=b) (v:=w) (w:=z)
    rw [dist_eq_one_iff_adj.mpr zw.symm] at t
    rw [dist_comm (G:=G) (u:=z) (v:=a),dist_comm (G:=G) (u:=w) (v:=a)] at hw
    exact ⟨w,wd,zw,by rw [min_eq_left le,min_eq_left (show G.dist a w≤G.dist b w by omega),hw]⟩
  · have le' : G.dist b z≤G.dist a z := by omega
    obtain ⟨w,wd,zw,hw⟩ := go (t:=b) (min_eq_right le')
    have t := hc.dist_triangle (u:=a) (v:=w) (w:=z)
    rw [dist_eq_one_iff_adj.mpr zw.symm] at t
    rw [dist_comm (G:=G) (u:=z) (v:=b),dist_comm (G:=G) (u:=w) (v:=b)] at hw
    exact ⟨w,wd,zw,by rw [min_eq_right le',min_eq_right (show G.dist b w≤G.dist a w by omega),hw]⟩

private theorem left_even_depth_two_with_one_exclusive
    (hc : G.Connected) (ab : G.Adj a b) {D : Cmp G a b}
    (one : (classSet D 3).card=1)
    {z : V} (zd : z∈Shore D) (k : key G a b z=0) :
    G.dist a z=2 := by
  classical
  have za : z≠a := fun e=>(shore_off D).1 (e ▸ zd)
  have zb : z≠b := fun e=>(shore_off D).2 (e ▸ zd)
  have p := hc.pos_dist_of_ne (u:=a) (v:=z) za.symm
  obtain ⟨az,bz,ez⟩ := key_facts hc ab z
  rw [k] at az bz ez
  change _=depth G a b z+0 at az
  change _=depth G a b z+1 at bz
  change _%2=0 at ez
  by_contra not2
  have large : 4≤G.dist a z := by omega
  have zr : 0<G.dist z a := by rwa [dist_comm]
  obtain ⟨w,zw,hw⟩ := predecessor_of_positive_dist hc zr
  have wd : w∈Shore D := by
    rcases shore_closed D z zd w zw with h|h|h
    · have d := dist_eq_one_iff_adj.mpr zw.symm
      rw [h] at d
      omega
    · have d := dist_eq_one_iff_adj.mpr zw.symm
      rw [h] at d
      omega
    · exact h
  rw [dist_comm (G:=G) (u:=z) (v:=a),dist_comm (G:=G) (u:=w) (v:=a)] at hw
  have u := hc.dist_triangle (u:=b) (v:=w) (w:=z)
  rw [dist_eq_one_iff_adj.mpr zw.symm] at u
  have nearer : G.dist a w<G.dist b w := by omega
  have odd : ¬Even (G.dist a w) := by rw [Nat.even_iff]; omega
  have wk : key G a b w=3 := by simp [key,nearer,odd]
  obtain ⟨x,xd,ax,nb⟩ := exclusive_left_port_of_strictly_nearer hc zd (by omega)
  have xk : key G a b x=3 := by
    have xb : x≠b := fun e=>(shore_off D).2 (e ▸ xd)
    have two := (mem_filter.mp (d2 hc xb.symm nb ab.symm ax)).2
    simp [key,dist_eq_one_iff_adj.mpr ax,two]
  have eq := Finset.card_le_one.mp one.le w (mem_filter.mpr ⟨wd,wk⟩) x (mem_filter.mpr ⟨xd,xk⟩)
  have xx := dist_eq_one_iff_adj.mpr ax
  rw [eq,xx] at hw
  omega

private theorem right_even_depth_two_with_one_exclusive
    (hc : G.Connected) (ab : G.Adj a b) {D : Cmp G a b}
    (one : (classSet D 4).card=1)
    {z : V} (zd : z∈Shore D) (k : key G a b z=1) :
    G.dist b z=2 := by
  classical
  have za : z≠a := fun e=>(shore_off D).1 (e ▸ zd)
  have zb : z≠b := fun e=>(shore_off D).2 (e ▸ zd)
  have p := hc.pos_dist_of_ne (u:=b) (v:=z) zb.symm
  obtain ⟨az,bz,ez⟩ := key_facts hc ab z
  rw [k] at az bz ez
  change _=depth G a b z+1 at az
  change _=depth G a b z+0 at bz
  change _%2=0 at ez
  by_contra not2
  have large : 4≤G.dist b z := by omega
  have zr : 0<G.dist z b := by rwa [dist_comm]
  obtain ⟨w,zw,hw⟩ := predecessor_of_positive_dist hc zr
  have wd : w∈Shore D := by
    rcases shore_closed D z zd w zw with h|h|h
    · have d := dist_eq_one_iff_adj.mpr zw.symm
      rw [h] at d
      omega
    · have d := dist_eq_one_iff_adj.mpr zw.symm
      rw [h] at d
      omega
    · exact h
  rw [dist_comm (G:=G) (u:=z) (v:=b),dist_comm (G:=G) (u:=w) (v:=b)] at hw
  have u := hc.dist_triangle (u:=a) (v:=w) (w:=z)
  rw [dist_eq_one_iff_adj.mpr zw.symm] at u
  have nearer : G.dist b w<G.dist a w := by omega
  have nrev : ¬G.dist a w<G.dist b w := by omega
  have odd : ¬Even (G.dist b w) := by rw [Nat.even_iff]; omega
  have wk : key G a b w=4 := by simp [key,nrev,nearer,odd]
  obtain ⟨x,xd,bx,na⟩ := exclusive_right_port_of_strictly_nearer hc zd (by omega)
  have xk : key G a b x=4 := by
    have xa : x≠a := fun e=>(shore_off D).1 (e ▸ xd)
    have two := (mem_filter.mp (d2 hc xa.symm na ab bx)).2
    simp [key,dist_eq_one_iff_adj.mpr bx,two]
  have eq := Finset.card_le_one.mp one.le w (mem_filter.mpr ⟨wd,wk⟩) x (mem_filter.mpr ⟨xd,xk⟩)
  have xx := dist_eq_one_iff_adj.mpr bx
  rw [eq,xx] at hw
  omega


private theorem key_of_known_dist_two_three {z : V}
    (ab : G.dist a z=2 ∧ G.dist b z=3) :
    key G a b z=0 := by classical simp [key,ab.1,ab.2]

private theorem key_of_known_dist_three_two {z : V}
    (ab : G.dist a z=3 ∧ G.dist b z=2) :
    key G a b z=1 := by classical simp [key,ab.1,ab.2]

private theorem no_both_two_of_empty_equal_even
    {D : Cmp G a b} (zero : (classSet D 2).card=0)
    {z : V} (zd : z∈Shore D) (da : G.dist a z=2) (db : G.dist b z=2) : False := by
  classical
  have k : key G a b z=2 := by simp [key,da,db]
  have le := card_pos.mpr (show (classSet D 2).Nonempty from ⟨z,mem_filter.mpr ⟨zd,k⟩⟩)
  omega

private theorem even_min_depth_two_of_singleton_profile
    (hc : G.Connected) (ab : G.Adj a b)
    {D : Cmp G a b} (zero : (classSet D 2).card=0)
    (oa : (classSet D 3).card=1) (ob : (classSet D 4).card=1)
    {z : V} (zd : z∈Shore D) (ev : Even (depth G a b z)) :
    depth G a b z=2 := by
  classical
  obtain ⟨da,db,pa'⟩ := key_facts hc ab z
  generalize kz : key G a b z = k at da db pa'
  have forms := (by decide : ∀ i : Fin 6, i=0 ∨ i=1 ∨ i=2 ∨ i=3 ∨ i=4 ∨ i=5) k
  simp only [Nat.even_iff] at ev
  rcases forms with h|h|h|h|h|h
  · have sol := left_even_depth_two_with_one_exclusive hc ab oa zd (kz.trans h)
    rw [h] at da
    change G.dist a z=depth G a b z+0 at da
    omega
  · have sol := right_even_depth_two_with_one_exclusive hc ab ob zd (kz.trans h)
    rw [h] at db
    change G.dist b z=depth G a b z+0 at db
    omega
  · have pos := card_pos.mpr (show (classSet D 2).Nonempty from ⟨z,mem_filter.mpr ⟨zd,kz.trans h⟩⟩)
    omega
  · rw [h] at pa'
    change _ % 2=1 at pa'
    omega
  · rw [h] at pa'
    change _ % 2=1 at pa'
    omega
  · rw [h] at pa'
    change _ % 2=1 at pa'
    omega

private theorem depth_at_most_three_of_singleton_profile
    (hc : G.Connected) (ab : G.Adj a b)
    {D : Cmp G a b} (zero : (classSet D 2).card=0)
    (oa : (classSet D 3).card=1) (ob : (classSet D 4).card=1)
    {z : V} (zd : z∈Shore D) :
    depth G a b z≤3 := by
  by_contra h
  by_cases ev : Even (depth G a b z)
  · have e := even_min_depth_two_of_singleton_profile hc ab zero oa ob zd ev
    omega
  have big : 5≤depth G a b z := by rw [Nat.even_iff] at ev; omega
  obtain ⟨w,wd,zw,dw⟩ := depth_predecessor_on_shore hc zd (by omega)
  have e : Even (depth G a b w) := by rw [Nat.even_iff] at ev ⊢; omega
  have k := even_min_depth_two_of_singleton_profile hc ab zero oa ob wd e
  omega

private theorem left_even_adjoins_exclusive
    (hc : G.Connected) (ab : G.Adj a b)
    {D : Cmp G a b} {x : V}
    (single : classSet D 3={x})
    {w : V} (wd : w∈Shore D) (da : G.dist a w=2) (db : G.dist b w=3) :
    G.Adj x w := by
  have p : 0<G.dist w a := by rw [dist_comm,da]; decide
  obtain ⟨t,wt,ta⟩ := predecessor_of_positive_dist hc p
  have tda : G.dist a t=1 := by
    rw [dist_comm (G:=G) (u:=w) (v:=a),dist_comm (G:=G) (u:=t) (v:=a),da] at ta
    omega
  have tdb : G.dist b t≥2 := by
    have z := hc.dist_triangle (u:=b) (v:=t) (w:=w)
    rw [db,dist_eq_one_iff_adj.mpr wt.symm] at z
    omega
  have td : t∈Shore D := by
    rcases shore_closed D _ wd _ wt with rfl|rfl|h
    · rw [dist_self] at tda; omega
    · rw [dist_self] at tdb; omega
    · exact h
  have tdb2 : G.dist b t=2 := by
    have z := hc.dist_triangle (u:=b) (v:=a) (w:=t)
    rw [dist_eq_one_iff_adj.mpr ab.symm,tda] at z
    omega
  have k : key G a b t=3 := by classical simp [key,tda,tdb2]
  have tx : t=x := by
    have h : t∈classSet D 3 := mem_filter.mpr ⟨td,k⟩
    simpa [single] using h
  exact tx ▸ wt.symm

private theorem right_even_adjoins_exclusive
    (hc : G.Connected) (ab : G.Adj a b)
    {D : Cmp G a b} {x : V}
    (single : classSet D 4={x})
    {w : V} (wd : w∈Shore D) (da : G.dist a w=3) (db : G.dist b w=2) :
    G.Adj x w := by
  have p : 0<G.dist w b := by rw [dist_comm,db]; decide
  obtain ⟨t,wt,tb⟩ := predecessor_of_positive_dist hc p
  have tdb : G.dist b t=1 := by
    rw [dist_comm (G:=G) (u:=w) (v:=b),dist_comm (G:=G) (u:=t) (v:=b),db] at tb
    omega
  have tda : G.dist a t≥2 := by
    have z := hc.dist_triangle (u:=a) (v:=t) (w:=w)
    rw [da,dist_eq_one_iff_adj.mpr wt.symm] at z
    omega
  have td : t∈Shore D := by
    rcases shore_closed D _ wd _ wt with rfl|rfl|h
    · rw [dist_self] at tda; omega
    · rw [dist_self] at tdb; omega
    · exact h
  have tda2 : G.dist a t=2 := by
    have z := hc.dist_triangle (u:=a) (v:=b) (w:=t)
    rw [dist_eq_one_iff_adj.mpr ab,tdb] at z
    omega
  have k : key G a b t=4 := by classical simp [key,tda2,tdb]
  have tx : t=x := by
    have h : t∈classSet D 4 := mem_filter.mpr ⟨td,k⟩
    simpa [single] using h
  exact tx ▸ wt.symm

end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
