import AdjacentCutFiveSixteenSingletonDepth189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph Shore shore_off shore_closed shore_disjoint from AdjacentCutFiveActual189
open private foreign_pos_even positive_cap from AdjacentCutFiveComponents189
open private key classSet prof sa sb pa key_facts from AdjacentCutFiveTopProfiles189
open private key_a_port key_b_port from AdjacentCutFiveTopFlatten189
open private mem_positive d2 from AdjacentCutFiveBound189
open private compact_graph_singleton_profile left_even_depth_two_with_one_exclusive
  right_even_depth_two_with_one_exclusive left_even_adjoins_exclusive right_even_adjoins_exclusive
  predecessor_of_positive_dist depth_at_most_three_of_singleton_profile no_both_two_of_empty_equal_even
  key_of_known_dist_two_three from AdjacentCutFiveSixteenSingletonDepth189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

private theorem disjoint_profile_sets (D : Cmp G a b) {i j : Fin 6} (ne : i≠j) :
    Disjoint (classSet D i) (classSet D j) :=
  disjoint_left.mpr (fun _ im jm => ne ((mem_filter.mp im).2.symm.trans (mem_filter.mp jm).2))

private theorem restrict_unique_profile {D : Cmp G a b} {i : Fin 6} {x : V}
    (one : (classSet D i).card=1) (xd : x∈Shore D) (kx : key G a b x=i) :
    classSet D i={x} := by
  classical
  obtain ⟨y,hy⟩ := card_eq_one.mp one
  have xx : x∈classSet D i := mem_filter.mpr ⟨xd,kx⟩
  have eq : x=y := by simpa [hy] using xx
  rw [hy,eq]

private theorem even_two_three_info
    (hc : G.Connected) (ab : G.Adj a b)
    {D : Cmp G a b} (o : (classSet D 3).card=1)
    {w : V} (wE : w∈classSet D 0) : G.dist a w=2 ∧ G.dist b w=3 := by
  obtain ⟨wd,kw⟩ := mem_filter.mp wE
  have a2 := left_even_depth_two_with_one_exclusive hc ab o wd kw
  have f := key_facts hc ab w
  rw [kw] at f
  change (G.dist a w=depth G a b w+0) ∧ (G.dist b w=depth G a b w+1) ∧ _ at f
  exact ⟨a2,by omega⟩

private theorem even_three_two_info
    (hc : G.Connected) (ab : G.Adj a b)
    {D : Cmp G a b} (o : (classSet D 4).card=1)
    {w : V} (wE : w∈classSet D 1) : G.dist a w=3 ∧ G.dist b w=2 := by
  obtain ⟨wd,kw⟩ := mem_filter.mp wE
  have b2 := right_even_depth_two_with_one_exclusive hc ab o wd kw
  have f := key_facts hc ab w
  rw [kw] at f
  change (G.dist a w=depth G a b w+1) ∧ (G.dist b w=depth G a b w+0) ∧ _ at f
  exact ⟨by omega,b2⟩

private theorem shore_port_cases
    (hc : G.Connected) (ab : G.Adj a b)
    {D : Cmp G a b} {x y z : V} (zd : z∈Shore D)
    (L : classSet D 3={x}) (R : classSet D 4={y})
    (port : G.Adj a z ∨ G.Adj b z) :
    z=x ∨ z=y ∨ (G.Adj a z ∧ G.Adj b z ∧ z∈classSet D 5) := by
  have a' : z≠a := fun e=>(shore_off D).1 (e ▸ zd)
  have b' : z≠b := fun e=>(shore_off D).2 (e ▸ zd)
  have eq (h : key G a b z=5) : G.dist a z=G.dist b z := by
    obtain ⟨da,db,_⟩ := key_facts hc ab z
    rw [h] at da db
    exact da.trans db.symm
  rcases port with q|q
  · rcases key_a_port hc ab b' q with h|h
    · have t : z∈classSet D 3 := mem_filter.mpr ⟨zd,h⟩
      exact .inl (by simpa [L] using t)
    · exact .inr (.inr ⟨q,dist_eq_one_iff_adj.mp ((eq h).symm.trans (dist_eq_one_iff_adj.mpr q)),mem_filter.mpr ⟨zd,h⟩⟩)
  · rcases key_b_port hc ab a' q with h|h
    · have t : z∈classSet D 4 := mem_filter.mpr ⟨zd,h⟩
      exact .inr (.inl (by simpa [R] using t))
    · exact .inr (.inr ⟨dist_eq_one_iff_adj.mp ((eq h).trans (dist_eq_one_iff_adj.mpr q)),q,mem_filter.mpr ⟨zd,h⟩⟩)

private theorem cannot_fit_four_and_two_more
    (even : ∀ z,(EvenFrom G z).card≤6) {z s t : V} {P : Finset V}
    (four : 4≤P.card) (e : P⊆PositiveEven G z)
    (sf : s∉P) (tf : t∉P) (ne : t≠s)
    (hs : s∈PositiveEven G z) (ht : t∈PositiveEven G z) : False := by
  classical
  have ts : t∉insert s P := by simp [tf,ne]
  have sub : insert t (insert s P)⊆PositiveEven G z := by
    intro v vm
    rcases mem_insert.mp vm with rfl|vm
    · exact ht
    rcases mem_insert.mp vm with rfl|vm
    · exact hs
    · exact e vm
  have c := (card_le_card sub).trans (positive_cap z even)
  rw [card_insert_of_not_mem ts,card_insert_of_not_mem sf] at c
  omega

/-- A common port on the other shore and at least four strict-even vertices force a new nonadjacent separator
when both exclusive odd classes are singletons and the balanced even class is empty. -/
theorem nonadjacent_separator_of_common_other_unique_and_four_even
    (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ z,(EvenFrom G z).card≤6)
    {C D : Cmp G a b} (cd : C≠D) {s : V} (sc : s∈Shore C)
    (as' : G.Adj a s) (bs' : G.Adj b s)
    (ea : 0<(classSet D 0).card) (eb : 0<(classSet D 1).card)
    (ec : (classSet D 2).card=0) (oa : (classSet D 3).card=1) (ob : (classSet D 4).card=1)
    (four : 4≤(classSet D 0).card ∨ 4≤(classSet D 1).card) :
    ∃ x y : V,x≠y ∧ ¬G.Adj x y ∧ ¬(G.induce {z : V | z≠x ∧ z≠y}).Connected := by
  classical
  let A := classSet D 0
  let B := classSet D 1
  have notSD : s∉Shore D := fun h=>disjoint_left.mp (shore_disjoint cd) sc h
  obtain ⟨v,va⟩ : A.Nonempty := card_pos.mp ea
  obtain ⟨w,wb⟩ : B.Nonempty := card_pos.mp eb
  have vrel := even_two_three_info hc ab oa va
  have wrel := even_three_two_info hc ab ob wb
  obtain ⟨x,xd,ax,nx⟩ := exclusive_left_port_of_strictly_nearer hc (mem_filter.mp va).1 (by omega)
  obtain ⟨y,yd,by',ny⟩ := exclusive_right_port_of_strictly_nearer hc (mem_filter.mp wb).1 (by omega)
  have xB : x≠b := fun e=>(shore_off D).2 (e ▸ xd)
  have yA : y≠a := fun e=>(shore_off D).1 (e ▸ yd)
  have dxB := (mem_filter.mp (d2 hc xB.symm nx ab.symm ax)).2
  have dyA := (mem_filter.mp (d2 hc yA.symm ny ab by')).2
  have xk : key G a b x=3 := by simp [key,dist_eq_one_iff_adj.mpr ax,dxB]
  have yk : key G a b y=4 := by simp [key,dist_eq_one_iff_adj.mpr by',dyA]
  have L := restrict_unique_profile oa xd xk
  have R := restrict_unique_profile ob yd yk
  have xy : x≠y := fun e=>ny (e ▸ ax)
  have leftEdge (u : V) (uv : u∈A) : G.Adj x u := by
    have p := even_two_three_info hc ab oa uv
    exact left_even_adjoins_exclusive hc ab L (mem_filter.mp uv).1 p.1 p.2
  have rightEdge (u : V) (uv : u∈B) : G.Adj y u := by
    have p := even_three_two_info hc ab ob uv
    exact right_even_adjoins_exclusive hc ab R (mem_filter.mp uv).1 p.1 p.2
  have xyNo : ¬G.Adj x y := by
    intro edge
    rcases four with f|f
    · have aSee : A⊆PositiveEven G y := by
        intro u um
        have p := even_two_three_info hc ab oa um
        have y1 := dist_eq_one_iff_adj.mpr by'
        have ne : y≠u := fun e=>by rw [e,p.2] at y1; omega
        have no : ¬G.Adj y u := by
          intro h
          have t := hc.dist_triangle (u:=b) (v:=y) (w:=u)
          rw [p.2,y1,dist_eq_one_iff_adj.mpr h] at t
          omega
        have d := (mem_filter.mp (d2 hc ne no edge.symm (leftEdge u um))).2
        exact mem_positive.mpr ⟨ne.symm,by simp [d]⟩
      have aPos : a∈PositiveEven G y := mem_positive.mpr ⟨yA.symm,by rw [dist_comm,dyA]; decide⟩
      have sPos := foreign_pos_even hc cd.symm yd sc by' bs'
      exact cannot_fit_four_and_two_more even f aSee
        (fun h=>notSD (mem_filter.mp h).1) (fun h=>(shore_off D).1 (mem_filter.mp h).1)
        (fun e=>(shore_off C).1 (e.symm ▸ sc)) sPos aPos
    · have bSee : B⊆PositiveEven G x := by
        intro u um
        have p := even_three_two_info hc ab ob um
        have x1 := dist_eq_one_iff_adj.mpr ax
        have ne : x≠u := fun e=>by rw [e,p.1] at x1; omega
        have no : ¬G.Adj x u := by
          intro h
          have t := hc.dist_triangle (u:=a) (v:=x) (w:=u)
          rw [p.1,x1,dist_eq_one_iff_adj.mpr h] at t
          omega
        have d := (mem_filter.mp (d2 hc ne no edge (rightEdge u um))).2
        exact mem_positive.mpr ⟨ne.symm,by simp [d]⟩
      have bPos : b∈PositiveEven G x := mem_positive.mpr ⟨xB.symm,by rw [dist_comm,dxB]; decide⟩
      have sPos := foreign_pos_even hc cd.symm xd sc ax as'
      exact cannot_fit_four_and_two_more even f bSee
        (fun h=>notSD (mem_filter.mp h).1) (fun h=>(shore_off D).2 (mem_filter.mp h).1)
        (fun e=>(shore_off C).2 (e.symm ▸ sc)) sPos bPos
  refine ⟨x,y,xy,xyNo,?_⟩
  intro conn'
  let U : Set V := {z : V | z≠x ∧ z≠y}
  have sx : s≠x := fun e=>notSD (e.symm ▸ xd)
  have sy : s≠y := fun e=>notSD (e.symm ▸ yd)
  have vx : v≠x := fun e=>by have h := (mem_filter.mp va).2; rw [e,xk] at h; exact (by decide : (3:Fin 6)≠0) h
  have vy : v≠y := fun e=>by have h := (mem_filter.mp va).2; rw [e,yk] at h; exact (by decide : (4:Fin 6)≠0) h
  have vaD := (mem_filter.mp va).1
  have av : ¬G.Adj a v := fun h=>by have e := dist_eq_one_iff_adj.mpr h; omega
  have bv : ¬G.Adj b v := fun h=>by have e := dist_eq_one_iff_adj.mpr h; omega
  have stay {u w : U} (p : (G.induce U).Walk u w) :
      (u.val∈Shore D ∧ ¬G.Adj a u.val ∧ ¬G.Adj b u.val) →
      (w.val∈Shore D ∧ ¬G.Adj a w.val ∧ ¬G.Adj b w.val) := by
    induction p with
    | nil => exact id
    | @cons u t w edge p ih =>
      intro ⟨ud,au,bu⟩
      apply ih
      have e : G.Adj u.val t.val := edge
      rcases shore_closed D _ ud _ e with ha|hb|td
      · exact (au (by simpa only [ha] using e.symm)).elim
      · exact (bu (by simpa only [hb] using e.symm)).elim
      refine ⟨td,?_⟩
      have no (port : G.Adj a t.val ∨ G.Adj b t.val) : False := by
        rcases shore_port_cases hc ab td L R port with eq|eq|mode
        · exact t.property.1 eq
        · exact t.property.2 eq
        have ua : u.val≠a := fun f=>(shore_off D).1 (Eq.mp (congrArg (fun h : V => h∈Shore D) f) ud)
        have ub : u.val≠b := fun f=>(shore_off D).2 (Eq.mp (congrArg (fun h : V => h∈Shore D) f) ud)
        have dA := (mem_filter.mp (d2 hc ua.symm au mode.1 e.symm)).2
        have dB := (mem_filter.mp (d2 hc ub.symm bu mode.2.1 e.symm)).2
        exact no_both_two_of_empty_equal_even ec ud dA dB
      exact ⟨fun h=>no (.inl h),fun h=>no (.inr h)⟩
  obtain ⟨p⟩ := conn'.preconnected (⟨v,⟨vx,vy⟩⟩ : U) ⟨s,⟨sx,sy⟩⟩
  exact notSD (stay p ⟨vaD,av,bv⟩).1

theorem nonadjacent_separator_of_adjacent_singleton_thirteen_shores
    (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ z,(EvenFrom G z).card≤6)
    (conn : ∀ T : Finset V,T.card<2 → (G.induce ((↑T : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    {C D : Cmp G a b} (cd : C≠D) (one : (Shore C).card=1) (big : (Shore D).card=13) :
    ∃ x y : V,x≠y ∧ ¬G.Adj x y ∧ ¬(G.induce {z : V | z≠x ∧ z≠y}).Connected := by
  classical
  obtain ⟨s,SC,as',bs',ea,eb,ec,oa,ob,oc⟩ := compact_graph_singleton_profile hc ab even conn degree cd one big
  have sc : s∈Shore C := by simp [SC]
  change (classSet D 0).card=4 at ea
  change (classSet D 1).card=4 at eb
  exact nonadjacent_separator_of_common_other_unique_and_four_even hc ab even cd sc as' bs'
    (by omega) (by omega) ec oa ob (.inl ea.ge)

#print axioms nonadjacent_separator_of_common_other_unique_and_four_even
#print axioms nonadjacent_separator_of_adjacent_singleton_thirteen_shores
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
