import AdjacentCutFiveFifteenSingletonResidual189
import AdjacentCutFiveFourteenSingletonThree189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph Shore shore_off shore_closed shore_disjoint from AdjacentCutFiveActual189
open private key classSet key_facts from AdjacentCutFiveTopProfiles189
open private key_a_port key_b_port from AdjacentCutFiveTopFlatten189
open private even_two_three_info even_three_two_info restrict_unique_profile from AdjacentCutFiveSixteenSingletonGeometry189
open private left_even_adjoins_exclusive right_even_adjoins_exclusive predecessor_of_positive_dist from AdjacentCutFiveSixteenSingletonDepth189
open private d2 from AdjacentCutFiveBound189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

private noncomputable def commonFive (D : Cmp G a b) : Finset V := by
  classical
  exact (classSet D 5).filter (G.Adj a)

private theorem commonFive_ports {D : Cmp G a b}
    (hc : G.Connected) (ab : G.Adj a b) {w : V} (wm : w∈commonFive D) :
    w∈Shore D ∧ G.Adj a w ∧ G.Adj b w := by
  classical
  obtain ⟨c,aw⟩ := mem_filter.mp wm
  obtain ⟨wd,k⟩ := mem_filter.mp c
  obtain ⟨h,j,_⟩ := key_facts hc ab w
  rw [k] at h j
  change _=depth G a b w+0 at h j
  exact ⟨wd,aw,dist_eq_one_iff_adj.mp (j.trans (h.symm.trans (dist_eq_one_iff_adj.mpr aw)))⟩

private theorem commonFive_card_at_least_two
    (hc : G.Connected) (ab : G.Adj a b) {D : Cmp G a b}
    (ona : (classSet D 3).card=1)
    (atleast : 3≤((Shore D).filter (G.Adj a)).card) :
    2≤(commonFive D).card := by
  classical
  have sub : ((Shore D).filter (G.Adj a))⊆classSet D 3∪commonFive D := by
    intro w wm
    obtain ⟨wd,aw⟩ := mem_filter.mp wm
    have wb : w≠b := fun e=>(shore_off D).2 (e ▸ wd)
    rcases key_a_port hc ab wb aw with k|k
    · exact mem_union_left _ (mem_filter.mpr ⟨wd,k⟩)
    · exact mem_union_right _ (mem_filter.mpr ⟨mem_filter.mpr ⟨wd,k⟩,aw⟩)
  have bnd := (card_le_card sub).trans (card_union_le _ _)
  omega

private theorem balanced_dark_odd_dist_three
    (hc : G.Connected) (ab : G.Adj a b) {D : Cmp G a b}
    (oa : (classSet D 3).card=1) (_ob : (classSet D 4).card=1)
    (oc : (classSet D 5).card=3) (two : 2≤(commonFive D).card)
    {w : V} (wm : w∈classSet D 5) (no : w∉commonFive D) :
    G.dist a w=3 ∧ G.dist b w=3 := by
  classical
  obtain ⟨wd,k⟩ := mem_filter.mp wm
  obtain ⟨da,db,ev⟩ := key_facts hc ab w
  rw [k] at da db ev
  change _=depth G a b w+0 at da db
  change depth G a b w % 2=1 at ev
  have gt : 1<G.dist a w := by
    by_contra h
    have wa : w≠a := fun e=>(shore_off D).1 (e ▸ wd)
    have pos := hc.pos_dist_of_ne wa.symm
    have h1 : G.dist a w=1 := by omega
    exact no (mem_filter.mpr ⟨wm,dist_eq_one_iff_adj.mp h1⟩)
  by_contra bad
  have tall : 5≤G.dist a w := by omega
  have pz : 0<G.dist w a := by rw [dist_comm]; omega
  obtain ⟨t,wt,ht⟩ := predecessor_of_positive_dist hc pz
  rw [dist_comm (G:=G) (u:=w) (v:=a),dist_comm (G:=G) (u:=t) (v:=a)] at ht
  have td : t∈Shore D := by
    rcases shore_closed D w wd t wt with h|h|h
    · have d := dist_eq_one_iff_adj.mpr wt
      rw [h,dist_comm] at d
      omega
    · have d := dist_eq_one_iff_adj.mpr wt
      rw [h,dist_comm] at d
      omega
    · exact h
  have tA := hc.dist_triangle (u:=b) (v:=t) (w:=w)
  rw [dist_eq_one_iff_adj.mpr wt.symm] at tA
  have even : Even (G.dist a t) := by rw [Nat.even_iff]; omega
  have le : G.dist a t≤G.dist b t := by omega
  rcases lt_or_eq_of_le le with lt|eq
  · have kt : key G a b t=0 := by simp [key,lt,even]
    have p := even_two_three_info hc ab oa (mem_filter.mpr ⟨td,kt⟩)
    omega
  · have p : 0<G.dist t a := by rw [dist_comm]; omega
    obtain ⟨u,tu,hu⟩ := predecessor_of_positive_dist hc p
    rw [dist_comm (G:=G) (u:=t) (v:=a),dist_comm (G:=G) (u:=u) (v:=a)] at hu
    have ud : u∈Shore D := by
      rcases shore_closed D t td u tu with h|h|h
      · have d := dist_eq_one_iff_adj.mpr tu
        rw [h,dist_comm] at d
        omega
      · have d := dist_eq_one_iff_adj.mpr tu
        rw [h,dist_comm] at d
        omega
      · exact h
    have uA := hc.dist_triangle (u:=b) (v:=u) (w:=t)
    rw [dist_eq_one_iff_adj.mpr tu.symm] at uA
    have uo : ¬Even (G.dist a u) := by rw [Nat.even_iff]; omega
    have ule : G.dist a u≤G.dist b u := by omega
    rcases lt_or_eq_of_le ule with lt|eq_u
    · have ku : key G a b u=3 := by simp [key,lt,uo]
      have yu : G.dist a u<G.dist b u := lt
      obtain ⟨x,xd,ax,nx⟩ := exclusive_left_port_of_strictly_nearer hc ud yu
      have xb : x≠b := fun h=>(shore_off D).2 (h ▸ xd)
      have xb2 := (mem_filter.mp (d2 hc xb.symm nx ab.symm ax)).2
      have kx : key G a b x=3 := by simp [key,dist_eq_one_iff_adj.mpr ax,xb2]
      have eq' := restrict_unique_profile oa xd kx
      have m : u∈classSet D 3 := mem_filter.mpr ⟨ud,ku⟩
      have ux : u=x := by simpa [eq'] using m
      rw [ux,dist_eq_one_iff_adj.mpr ax] at hu
      omega
    · have ku : key G a b u=5 := by simp [key,eq_u,eq_u ▸ uo]
      have um : u∈classSet D 5 := mem_filter.mpr ⟨ud,ku⟩
      have un : u∉commonFive D := by
        intro h
        have u1 := dist_eq_one_iff_adj.mpr (commonFive_ports hc ab h).2.1
        omega
      have uw : u≠w := fun f=>by rw [f] at hu; omega
      have card' : 4≤(insert u (insert w (commonFive D))).card := by
        have h : u∉insert w (commonFive D) := by simp [uw,un]
        rw [card_insert_of_not_mem h,card_insert_of_not_mem no]
        omega
      have sub : insert u (insert w (commonFive D))⊆classSet D 5 :=
        insert_subset_iff.mpr ⟨um,insert_subset_iff.mpr ⟨wm,filter_subset _ _⟩⟩
      have bd := card_le_card sub
      omega

#print axioms commonFive_card_at_least_two
#print axioms balanced_dark_odd_dist_three
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
