import AdjacentCutFiveFifteenSingletonBalancedCommon189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset ArticulationPair
open private CutGraph Shore shore_off shore_closed shore_disjoint from AdjacentCutFiveActual189
open private classSet from AdjacentCutFiveTopProfiles189
open private commonFive commonFive_ports from AdjacentCutFiveFifteenSingletonBalancedBase189
open private common_cannot_hit_both_exclusive balanced_common_neighbor_choices from AdjacentCutFiveFifteenSingletonBalancedCommon189
open private adj_forbidden_by_dist dist_two_positive_even from AdjacentCutFiveFifteenSingletonMixedCore189
open private cannot_fit_four_and_two_more from AdjacentCutFiveSixteenSingletonGeometry189
open private foreign_pos_even from AdjacentCutFiveComponents189
open private degree_at_most_four_from_choices from AdjacentCutFiveFifteenSingletonMixedMap189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

private theorem balanced_common_cannot_miss_another_if_adjacent_exclusive
    (hc : G.Connected) (even : ∀ w,(EvenFrom G w).card≤6)
    {C D : Cmp G a b} (CD : C≠D) {s : V} (sc : s∈Shore C) {l r : V} (ls : G.Adj l s)
    {c d x y : V} (cd : c∈Shore D) (dd : d∈Shore D) (yd : y∈Shore D)
    (ac : G.Adj l c) (bc : G.Adj r c) (ad : G.Adj l d) (bd : G.Adj r d)
    (by' : G.Adj r y) (ny : ¬G.Adj l y)
    {A : Finset V} (sh : A⊆Shore D) (three : A.card=3)
    (dA : ∀ w∈A,G.dist r w=3) (xAll : ∀ w∈A,G.Adj x w)
    (cx : G.Adj c x) (cy : ¬G.Adj c y) (ne : c≠d) : G.Adj c d := by
  classical
  by_contra no
  have c1 := dist_eq_one_iff_adj.mpr bc
  have y1 := dist_eq_one_iff_adj.mpr by'
  have dPos := dist_two_positive_even hc ne no ac.symm ad
  have yNot : y∉A := fun m=>by have h := dA y m; omega
  have dNot : d∉A := by
    intro m
    have h := dA d m
    have p := dist_eq_one_iff_adj.mpr bd
    omega
  have cyNe : c≠y := fun e=>ny (e ▸ ac)
  have dy : d≠y := fun e=>ny (e ▸ ad)
  have path : insert y A⊆PositiveEven G c := by
    intro w wm
    rcases mem_insert.mp wm with rfl|m
    · exact dist_two_positive_even hc cyNe cy bc.symm by'
    · have e := dA w m
      have nw : c≠w := fun p=>by rw [p,e] at c1; omega
      have dp : G.dist r c+1<G.dist r w := by omega
      exact dist_two_positive_even hc nw (adj_forbidden_by_dist hc dp) cx (xAll w m)
  have scPos := dist_two_positive_even hc (show c≠s from fun e=>disjoint_left.mp (shore_disjoint CD) sc (e ▸ cd))
    (fun cs=>by
      rcases shore_closed D _ cd _ cs with eq|eq|m
      · exact (shore_off C).1 (eq ▸ sc)
      · exact (shore_off C).2 (eq ▸ sc)
      · exact disjoint_left.mp (shore_disjoint CD) sc m) ac.symm ls
  have bnd : 4≤(insert y A).card := by rw [card_insert_of_not_mem yNot,three]
  have sh' : insert y A⊆Shore D := insert_subset_iff.mpr ⟨yd,sh⟩
  exact cannot_fit_four_and_two_more even bnd path
    (fun h=>disjoint_left.mp (shore_disjoint CD) sc (sh' h))
    (by simp [dNot,dy]) (fun e=>disjoint_left.mp (shore_disjoint CD) sc (e ▸ dd)) scPos dPos

private theorem balanced_three_common_clique
    {C D : Cmp G a b} (F : BalFrame G a b D)
    (hc : G.Connected) (ab : G.Adj a b) (even : ∀ w,(EvenFrom G w).card≤6)
    (CD : C≠D) {s : V} (sc : s∈Shore C) (as' : G.Adj a s) (bs' : G.Adj b s)
    (three : (commonFive D).card=3) : CompleteOn G (commonFive D) := by
  classical
  intro c cm d dm ne
  obtain ⟨cd,ac,bc⟩ := commonFive_ports hc ab cm
  obtain ⟨dd,ad,bd⟩ := commonFive_ports hc ab dm
  have excl := common_cannot_hit_both_exclusive F hc ab even cm
  by_cases cx : G.Adj c F.x
  · exact balanced_common_cannot_miss_another_if_adjacent_exclusive hc even CD sc as'
      cd dd F.hy ac bc ad bd F.by' F.ny (filter_subset _ _) F.threeA
      (fun w wm=>(F.dA w wm).2) F.xAll cx (fun cy=>excl ⟨cx,cy⟩) ne
  by_cases cy : G.Adj c F.y
  · exact balanced_common_cannot_miss_another_if_adjacent_exclusive hc even CD sc bs' cd dd F.hx bc ac bd ad F.ax F.nx
      (filter_subset _ _) F.threeB (fun w wm=>(F.dB w wm).1) F.yAll cy cx ne
  by_contra no
  have hcd : ((commonFive D).erase c).card=2 := by rw [card_erase_of_mem cm,three]
  have dm' : d∈(commonFive D).erase c := mem_erase.mpr ⟨ne.symm,dm⟩
  have h2 : (((commonFive D).erase c).erase d).card=1 := by rw [card_erase_of_mem dm',hcd]
  obtain ⟨e,es⟩ := card_eq_one.mp h2
  have small : G.degree c≤4 := degree_at_most_four_from_choices (a:=a) (b:=b) (c:=F.v) (d:=e) (by
    intro w cw
    rcases balanced_common_neighbor_choices F hc ab cm cw with eq|eq|eq|eq|eq|wm
    · exact .inl eq
    · exact .inr (.inl eq)
    · exact (cx (eq ▸ cw)).elim
    · exact (cy (eq ▸ cw)).elim
    · exact .inr (.inr (.inl eq))
    · have dw : w≠d := fun eq=>no (eq ▸ cw)
      have ww : w∈((commonFive D).erase c).erase d :=
        mem_erase.mpr ⟨dw,mem_erase.mpr ⟨cw.ne.symm,wm⟩⟩
      exact .inr (.inr (.inr (by simpa [es] using ww))))
  have high := F.high c cd
  omega

#print axioms balanced_three_common_clique
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
