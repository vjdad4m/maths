import AdjacentCutFiveFifteenSingletonBalancedData189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph Shore shore_off shore_closed shore_disjoint from AdjacentCutFiveActual189
open private classSet key_facts from AdjacentCutFiveTopProfiles189
open private commonFive commonFive_ports from AdjacentCutFiveFifteenSingletonBalancedBase189
open private adj_forbidden_by_dist dist_two_positive_even from AdjacentCutFiveFifteenSingletonMixedCore189
open private disjoint_profile_sets cannot_fit_four_and_two_more from AdjacentCutFiveSixteenSingletonGeometry189
open private positive_cap foreign_pos_even from AdjacentCutFiveComponents189
open private local_degree_add_outside from AdjacentCutFiveFifteenSingletonBalancedRoute189
open private degree_at_most_four_from_choices from AdjacentCutFiveFifteenSingletonMixedMap189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

private theorem common_cannot_hit_both_exclusive {D : Cmp G a b} (F : BalFrame G a b D)
    (hc : G.Connected) (ab : G.Adj a b) (even : ∀ w,(EvenFrom G w).card≤6)
    {c : V} (cm : c∈commonFive D) : ¬(G.Adj c F.x ∧ G.Adj c F.y) := by
  classical
  intro ⟨cx,cy⟩
  obtain ⟨_,ac,bc⟩ := commonFive_ports hc ab cm
  have h (w : V) (m : w∈classSet D 0) : w∈PositiveEven G c := by
    have d := (F.dA w m).2
    have one := dist_eq_one_iff_adj.mpr bc
    have ne : c≠w := fun h=>by rw [h,d] at one; omega
    have no := adj_forbidden_by_dist hc (show G.dist b c+1<G.dist b w by omega)
    exact dist_two_positive_even hc ne no cx (F.xAll w m)
  have j (w : V) (m : w∈classSet D 1) : w∈PositiveEven G c := by
    have d := (F.dB w m).1
    have one := dist_eq_one_iff_adj.mpr ac
    have ne : c≠w := fun h=>by rw [h,d] at one; omega
    have no := adj_forbidden_by_dist hc (show G.dist a c+1<G.dist a w by omega)
    exact dist_two_positive_even hc ne no cy (F.yAll w m)
  have sub : classSet D 0∪classSet D 1⊆PositiveEven G c := by
    intro w m
    exact (mem_union.mp m).elim (h w) (j w)
  have s := (card_le_card sub).trans (positive_cap c even)
  rw [card_union_of_disjoint (disjoint_profile_sets D (by decide : (0:Fin 6)≠1)),F.threeA,F.threeB] at s
  omega

private theorem balanced_common_neighbor_choices {D : Cmp G a b} (F : BalFrame G a b D)
    (hc : G.Connected) (ab : G.Adj a b)
    {c : V} (cm : c∈commonFive D) {w : V} (cw : G.Adj c w) :
    w=a ∨ w=b ∨ w=F.x ∨ w=F.y ∨ w=F.v ∨ w∈commonFive D := by
  classical
  obtain ⟨cd,ac,bc⟩ := commonFive_ports hc ab cm
  rcases shore_closed D _ cd _ cw with q|q|wd
  · exact .inl q
  · exact .inr (.inl q)
  rcases BalFrame.exhaust F wd with m|m|q|q|q|m
  · have dist : G.dist b c+1<G.dist b w := by rw [dist_eq_one_iff_adj.mpr bc,(F.dA w m).2]; decide
    exact (adj_forbidden_by_dist hc dist cw).elim
  · have dist : G.dist a c+1<G.dist a w := by rw [dist_eq_one_iff_adj.mpr ac,(F.dB w m).1]; decide
    exact (adj_forbidden_by_dist hc dist cw).elim
  · exact .inr (.inr (.inr (.inr (.inl q))))
  · exact .inr (.inr (.inl q))
  · exact .inr (.inr (.inr (.inl q)))
  · by_cases h : w∈commonFive D
    · exact .inr (.inr (.inr (.inr (.inr h))))
    · have dist : G.dist a c+1<G.dist a w := by rw [dist_eq_one_iff_adj.mpr ac,(BalFrame.odd_dark_dist F hc ab m h).1]; decide
      exact (adj_forbidden_by_dist hc dist cw).elim

private theorem balanced_common_two_geometry {D : Cmp G a b} (F : BalFrame G a b D)
    (hc : G.Connected) (ab : G.Adj a b) (even : ∀ w,(EvenFrom G w).card≤6)
    {c d : V} (eq : commonFive D={c,d}) :
    G.Adj c d ∧ G.Adj c F.v ∧
      ((G.Adj c F.x ∧ ¬G.Adj c F.y) ∨ (G.Adj c F.y ∧ ¬G.Adj c F.x)) := by
  classical
  have cm : c∈commonFive D := by simp [eq]
  have cd := (commonFive_ports hc ab cm).1
  have high := F.high c cd
  have choices : ∀ w,G.Adj c w → w=a ∨ w=b ∨ w=F.x ∨ w=F.y ∨ w=F.v ∨ w=d := by
    intro w cw
    rcases balanced_common_neighbor_choices F hc ab cm cw with q|q|q|q|q|m
    · exact .inl q
    · exact .inr (.inl q)
    · exact .inr (.inr (.inl q))
    · exact .inr (.inr (.inr (.inl q)))
    · exact .inr (.inr (.inr (.inr (.inl q))))
    have h : w=c ∨ w=d := by simpa [eq] using m
    exact .inr (.inr (.inr (.inr (.inr (h.resolve_left cw.ne.symm)))))
  have ex := common_cannot_hit_both_exclusive F hc ab even cm
  have one : G.Adj c F.x ∨ G.Adj c F.y := by
    by_contra no
    have small : G.degree c≤4 := degree_at_most_four_from_choices (a:=a) (b:=b) (c:=F.v) (d:=d) (by
      intro w e
      rcases choices w e with rfl|rfl|rfl|rfl|rfl|rfl
      · exact .inl rfl
      · exact .inr (.inl rfl)
      · exact (no (.inl e)).elim
      · exact (no (.inr e)).elim
      · exact .inr (.inr (.inl rfl))
      · exact .inr (.inr (.inr rfl)))
    omega
  have force {q r : V} (qr : q=F.v ∧ r=d ∨ q=d ∧ r=F.v) : G.Adj c q := by
    by_contra no
    have fv : G.Adj c F.v → F.v=r := by
      rcases qr with ⟨rfl,_⟩|⟨_,e⟩
      · exact fun h=>(no h).elim
      · exact fun _=>e.symm
    have fd : G.Adj c d → d=r := by
      rcases qr with ⟨_,e⟩|⟨rfl,_⟩
      · exact fun _=>e.symm
      · exact fun h=>(no h).elim
    rcases one with x|y
    · have yy : ¬G.Adj c F.y := fun h=>ex ⟨x,h⟩
      have small : G.degree c≤4 := degree_at_most_four_from_choices (a:=a) (b:=b) (c:=F.x) (d:=r) (by
        intro w h
        rcases choices w h with e|e|e|e|e|e
        · exact .inl e
        · exact .inr (.inl e)
        · exact .inr (.inr (.inl e))
        · exact (yy (e ▸ h)).elim
        · exact .inr (.inr (.inr (e.trans (fv (e ▸ h)))))
        · exact .inr (.inr (.inr (e.trans (fd (e ▸ h))))))
      omega
    · have xx : ¬G.Adj c F.x := fun h=>ex ⟨h,y⟩
      have small : G.degree c≤4 := degree_at_most_four_from_choices (a:=a) (b:=b) (c:=F.y) (d:=r) (by
        intro w h
        rcases choices w h with e|e|e|e|e|e
        · exact .inl e
        · exact .inr (.inl e)
        · exact (xx (e ▸ h)).elim
        · exact .inr (.inr (.inl e))
        · exact .inr (.inr (.inr (e.trans (fv (e ▸ h)))))
        · exact .inr (.inr (.inr (e.trans (fd (e ▸ h))))))
      omega
  exact ⟨force (.inr ⟨rfl,rfl⟩),force (.inl ⟨rfl,rfl⟩),
    one.elim (fun x=>.inl ⟨x,fun h=>ex ⟨x,h⟩⟩) (fun y=>.inr ⟨y,fun h=>ex ⟨h,y⟩⟩)⟩

#print axioms common_cannot_hit_both_exclusive
#print axioms balanced_common_two_geometry
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
