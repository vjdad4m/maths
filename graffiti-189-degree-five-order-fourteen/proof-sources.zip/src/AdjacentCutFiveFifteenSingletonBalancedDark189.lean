import AdjacentCutFiveFifteenSingletonBalancedOff189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset ArticulationPair
open private CutGraph Shore shore_off shore_closed shore_disjoint from AdjacentCutFiveActual189
open private classSet from AdjacentCutFiveTopProfiles189
open private key_a_port key_b_port from AdjacentCutFiveTopFlatten189
open private commonFive commonFive_ports from AdjacentCutFiveFifteenSingletonBalancedBase189
open private adj_forbidden_by_dist from AdjacentCutFiveFifteenSingletonMixedCore189
open private disjoint_profile_sets from AdjacentCutFiveSixteenSingletonGeometry189
open private local_degree_add_outside terminal_route_on_seven from AdjacentCutFiveFifteenSingletonBalancedRoute189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

private noncomputable def darkCore (D : Cmp G a b) : Finset V := by
  classical exact classSet D 0∪classSet D 1

private theorem darkCore_card {D : Cmp G a b} (F : BalFrame G a b D) : (darkCore D).card=6 := by
  rw [darkCore,card_union_of_disjoint (disjoint_profile_sets D (by decide : (0:Fin 6)≠1)),F.threeA,F.threeB]

private theorem darkCore_sub (D : Cmp G a b) : darkCore D⊆Shore D := by
  classical
  intro q qd
  rcases mem_union.mp qd with qd|qd <;> exact (mem_filter.mp qd).1

private theorem balanced_even_dark {D : Cmp G a b} (F : BalFrame G a b D) (hc : G.Connected) (ab : G.Adj a b) :
    ¬G.Adj a F.v ∧ ¬G.Adj b F.v := by
  constructor
  · intro h
    have n : F.v≠b := fun eq=>(shore_off D).2 (Eq.mp (congrArg (fun z : V => z∈Shore D) eq) F.hv)
    have z := key_a_port hc ab n h
    rw [F.vk] at z
    exact z.elim (by decide) (by decide)
  · intro h
    have n : F.v≠a := fun eq=>(shore_off D).1 (Eq.mp (congrArg (fun z : V => z∈Shore D) eq) F.hv)
    have z := key_b_port hc ab n h
    rw [F.vk] at z
    exact z.elim (by decide) (by decide)

private theorem dark_neighbor_common_absent {D : Cmp G a b} (F : BalFrame G a b D)
    (hc : G.Connected) (ab : G.Adj a b) {u c : V}
    (um : u∈darkCore D) (cm : c∈commonFive D) : ¬G.Adj u c := by
  obtain ⟨_,aC,bC⟩ := commonFive_ports hc ab cm
  intro uc
  rcases mem_union.mp um with m|m
  · have h := (F.dA _ m).2
    exact adj_forbidden_by_dist hc
      (show G.dist b c+1<G.dist b u by rw [dist_eq_one_iff_adj.mpr bC,h]; decide) uc.symm
  · have h := (F.dB _ m).1
    exact adj_forbidden_by_dist hc
      (show G.dist a c+1<G.dist a u by rw [dist_eq_one_iff_adj.mpr aC,h]; decide) uc.symm

private theorem dark_core_neighbor_classes {D : Cmp G a b} (F : BalFrame G a b D)
    (hc : G.Connected) (ab : G.Adj a b) {u w : V}
    (um : u∈darkCore D) (uw : G.Adj u w) :
    w∈darkCore D ∨ w=F.v ∨
      (w=F.x ∧ u∈classSet D 0) ∨ (w=F.y ∧ u∈classSet D 1) ∨
      w∈classSet D 5 \ commonFive D := by
  classical
  have uD := darkCore_sub D um
  have noA : ¬G.Adj a u := by
    intro au
    have h := dist_eq_one_iff_adj.mpr au
    rcases mem_union.mp um with m|m
    · have f := (F.dA u m).1; omega
    · have f := (F.dB u m).1; omega
  have noB : ¬G.Adj b u := by
    intro bu
    have h := dist_eq_one_iff_adj.mpr bu
    rcases mem_union.mp um with m|m
    · have f := (F.dA u m).2; omega
    · have f := (F.dB u m).2; omega
  rcases shore_closed D _ uD _ uw with rfl|rfl|wD
  · exact (noA uw.symm).elim
  · exact (noB uw.symm).elim
  rcases F.exhaust wD with m|m|m|rfl|rfl|m
  · exact .inl (mem_union_left _ m)
  · exact .inl (mem_union_right _ m)
  · exact .inr (.inl m)
  · refine .inr (.inr (.inl ⟨rfl,?_⟩))
    rcases mem_union.mp um with m|m
    · exact m
    · have one := dist_eq_one_iff_adj.mpr F.ax
      have z := (F.dB u m).1
      exact (adj_forbidden_by_dist hc (show G.dist a F.x+1<G.dist a u by omega) uw.symm).elim
  · refine .inr (.inr (.inr (.inl ⟨rfl,?_⟩)))
    rcases mem_union.mp um with m|m
    · have one := dist_eq_one_iff_adj.mpr F.by'
      have z := (F.dA u m).2
      exact (adj_forbidden_by_dist hc (show G.dist b F.y+1<G.dist b u by omega) uw.symm).elim
    · exact m
  · exact .inr (.inr (.inr (.inr (mem_sdiff.mpr ⟨m,fun h=>dark_neighbor_common_absent F hc ab um h uw⟩))))

private theorem dark_core_one_outside_degree {D : Cmp G a b} (F : BalFrame G a b D)
    (hc : G.Connected) (ab : G.Adj a b)
    {R : Finset V} (sub : darkCore D⊆R)
    (fifth : classSet D 5\commonFive D⊆R)
    {u : V} (um : u∈darkCore D)
    (vCase : G.Adj u F.v → F.v∈R) :
    4≤(G.induce (↑R:Set V)).degree (⟨u,sub um⟩ : ↑(↑R:Set V)) := by
  classical
  have high := F.high u (darkCore_sub D um)
  have run (r : V) (choose : ∀ w,G.Adj u w → w=F.x ∧ u∈classSet D 0 ∨ w=F.y ∧ u∈classSet D 1 → w=r) :
      4≤(G.induce (↑R:Set V)).degree (⟨u,sub um⟩ : ↑(↑R:Set V)) := by
    have h := local_degree_add_outside (G:=G) (sub um) {r} (by
      intro w uw
      rcases dark_core_neighbor_classes F hc ab um uw with m|rfl|m|m|m
      · exact .inl (sub m)
      · exact .inl (vCase uw)
      · exact .inr (mem_singleton.mpr (choose w uw (.inl m)))
      · exact .inr (mem_singleton.mpr (choose w uw (.inr m)))
      · exact .inl (fifth m))
    rw [card_singleton] at h
    omega
  rcases mem_union.mp um with m|m
  · exact run F.x (fun w _ t=>t.elim And.left (fun h=>(disjoint_left.mp
      (disjoint_profile_sets D (by decide : (0:Fin 6)≠1)) m h.2).elim))
  · exact run F.y (fun w _ t=>t.elim (fun h=>(disjoint_left.mp
      (disjoint_profile_sets D (by decide : (0:Fin 6)≠1)) h.2 m).elim) And.left)

#print axioms dark_core_one_outside_degree
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
