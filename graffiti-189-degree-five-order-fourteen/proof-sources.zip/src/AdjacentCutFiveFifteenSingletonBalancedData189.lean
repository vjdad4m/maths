import AdjacentCutFiveFifteenSingletonBalancedRoute189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph Shore shore_off shore_closed shore_disjoint from AdjacentCutFiveActual189
open private key classSet key_facts from AdjacentCutFiveTopProfiles189
open private even_two_three_info even_three_two_info restrict_unique_profile disjoint_profile_sets from AdjacentCutFiveSixteenSingletonGeometry189
open private left_even_adjoins_exclusive right_even_adjoins_exclusive from AdjacentCutFiveSixteenSingletonDepth189
open private commonFive commonFive_ports commonFive_card_at_least_two balanced_dark_odd_dist_three from AdjacentCutFiveFifteenSingletonBalancedBase189
open private adj_forbidden_by_dist dist_two_positive_even from AdjacentCutFiveFifteenSingletonMixedCore189
open private d2 from AdjacentCutFiveBound189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

structure BalFrame (G : SimpleGraph V) (a b : V) [DecidableRel G.Adj] (D : Cmp G a b) where
  x : V
  y : V
  v : V
  hx : x∈Shore D
  hy : y∈Shore D
  hv : v∈Shore D
  ax : G.Adj a x
  nx : ¬G.Adj b x
  by' : G.Adj b y
  ny : ¬G.Adj a y
  nxy : ¬G.Adj x y
  xk : key G a b x=3
  yk : key G a b y=4
  vk : key G a b v=2
  L : classSet D 3={x}
  R : classSet D 4={y}
  E : classSet D 2={v}
  threeA : (classSet D 0).card=3
  threeB : (classSet D 1).card=3
  threeC : (classSet D 5).card=3
  dA : ∀ w∈classSet D 0,G.dist a w=2 ∧ G.dist b w=3
  dB : ∀ w∈classSet D 1,G.dist a w=3 ∧ G.dist b w=2
  xAll : ∀ w∈classSet D 0,G.Adj x w
  yAll : ∀ w∈classSet D 1,G.Adj y w
  high : ∀ w∈Shore D,5≤G.degree w
  commonAtLeast : 2≤(commonFive D).card

private theorem bal_frame_exists
    (hc : G.Connected) (ab : G.Adj a b) (even : ∀ w,(EvenFrom G w).card≤6)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    {C D : Cmp G a b} (CD : C≠D)
    (shoreCover : ∀ {z : V},z≠a → z≠b → z∈Shore C ∨ z∈Shore D)
    {s : V} (sc : s∈Shore C) (single : Shore C={s}) (as' : G.Adj a s) (bs' : G.Adj b s)
    (ea : (classSet D 0).card=3) (eb : (classSet D 1).card=3)
    (ec : (classSet D 2).card=1) (oa : (classSet D 3).card=1)
    (ob : (classSet D 4).card=1) (oc : (classSet D 5).card=3) : Nonempty (BalFrame G a b D) := by
  classical
  have dA : ∀ w∈classSet D 0,G.dist a w=2 ∧ G.dist b w=3 := fun _ m=> even_two_three_info hc ab oa m
  have dB : ∀ w∈classSet D 1,G.dist a w=3 ∧ G.dist b w=2 := fun _ m=> even_three_two_info hc ab ob m
  obtain ⟨u,um⟩ := card_pos.mp (show 0<(classSet D 0).card by omega)
  obtain ⟨t,tm⟩ := card_pos.mp (show 0<(classSet D 1).card by omega)
  obtain ⟨v,vm⟩ := card_pos.mp (show 0<(classSet D 2).card by omega)
  obtain ⟨vd,vk⟩ := mem_filter.mp vm
  have srcA := dA u um
  have srcB := dB t tm
  obtain ⟨x,xd,ax,nx⟩ := exclusive_left_port_of_strictly_nearer hc (mem_filter.mp um).1 (by omega)
  obtain ⟨y,yd,by',ny⟩ := exclusive_right_port_of_strictly_nearer hc (mem_filter.mp tm).1 (by omega)
  have xb : x≠b := fun e=>(shore_off D).2 (e ▸ xd)
  have ya : y≠a := fun e=>(shore_off D).1 (e ▸ yd)
  have xb2 := (mem_filter.mp (d2 hc xb.symm nx ab.symm ax)).2
  have ya2 := (mem_filter.mp (d2 hc ya.symm ny ab by')).2
  have xk : key G a b x=3 := by simp [key,dist_eq_one_iff_adj.mpr ax,xb2]
  have yk : key G a b y=4 := by simp [key,dist_eq_one_iff_adj.mpr by',ya2]
  have L := restrict_unique_profile oa xd xk
  have R := restrict_unique_profile ob yd yk
  have E := restrict_unique_profile ec vd vk
  have nxy := unique_exclusive_ports_nonadjacent_of_three_both hc ab even CD sc as' bs' xd ax nx yd by' ny oa ob ea.ge eb.ge (by omega)
  have xAll : ∀ w∈classSet D 0,G.Adj x w := fun w wm=>
    left_even_adjoins_exclusive hc ab L (mem_filter.mp wm).1 (dA w wm).1 (dA w wm).2
  have yAll : ∀ w∈classSet D 1,G.Adj y w := fun w wm=>
    right_even_adjoins_exclusive hc ab R (mem_filter.mp wm).1 (dB w wm).1 (dB w wm).2
  have terminal := adjacent_singleton_terminal_count ab degree CD shoreCover (show (Shore C).card=1 by simp [single])
  have two := commonFive_card_at_least_two hc ab oa terminal.1
  exact ⟨⟨x,y,v,xd,yd,vd,ax,nx,by',ny,nxy,xk,yk,vk,L,R,E,ea,eb,oc,dA,dB,xAll,yAll,terminal.2.2,two⟩⟩

theorem BalFrame.odd_dark_dist
    {D : Cmp G a b} (F : BalFrame G a b D)
    (hc : G.Connected) (ab : G.Adj a b)
    {w : V} (wm : w∈classSet D 5) (no : w∉commonFive D) :
    G.dist a w=3 ∧ G.dist b w=3 :=
  balanced_dark_odd_dist_three hc ab (by simp [F.L]) (by simp [F.R]) F.threeC F.commonAtLeast wm no

theorem BalFrame.exhaust {D : Cmp G a b} (F : BalFrame G a b D) {w : V} (wd : w∈Shore D) :
    w∈classSet D 0 ∨ w∈classSet D 1 ∨ w=F.v ∨ w=F.x ∨ w=F.y ∨ w∈classSet D 5 := by
  rcases (by decide : ∀ i : Fin 6,i=0 ∨ i=1 ∨ i=2 ∨ i=3 ∨ i=4 ∨ i=5) (key G a b w) with i|i|i|i|i|i
  · exact .inl (mem_filter.mpr ⟨wd,i⟩)
  · exact .inr (.inl (mem_filter.mpr ⟨wd,i⟩))
  · have m : w∈classSet D 2 := mem_filter.mpr ⟨wd,i⟩
    exact .inr (.inr (.inl (by simpa [F.E] using m)))
  · have m : w∈classSet D 3 := mem_filter.mpr ⟨wd,i⟩
    exact .inr (.inr (.inr (.inl (by simpa [F.L] using m))))
  · have m : w∈classSet D 4 := mem_filter.mpr ⟨wd,i⟩
    exact .inr (.inr (.inr (.inr (.inl (by simpa [F.R] using m)))))
  · exact .inr (.inr (.inr (.inr (.inr (mem_filter.mpr ⟨wd,i⟩)))))

#print axioms bal_frame_exists
#print axioms BalFrame.odd_dark_dist
#print axioms BalFrame.exhaust
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
