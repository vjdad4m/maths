import AdjacentCutFiveFifteenSingletonBalancedDark189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph Shore shore_off shore_closed shore_disjoint from AdjacentCutFiveActual189
open private classSet from AdjacentCutFiveTopProfiles189
open private commonFive commonFive_ports from AdjacentCutFiveFifteenSingletonBalancedBase189
open private adj_forbidden_by_dist from AdjacentCutFiveFifteenSingletonMixedCore189
open private disjoint_profile_sets from AdjacentCutFiveSixteenSingletonGeometry189
open private darkCore darkCore_sub from AdjacentCutFiveFifteenSingletonBalancedDark189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

private theorem glue_balanced_mid_and_tail
    {C D : Cmp G a b} (F : BalFrame G a b D) (ab : G.Adj a b)
    (CD : C≠D) {s : V} (sc : s∈Shore C) (single : Shore C={s}) (as' : G.Adj a s) (bs' : G.Adj b s)
    (cover : ∀ {z : V},z≠a → z≠b → z∈Shore C ∨ z∈Shore D)
    {W R : Finset V} (subW : W⊆Shore D) (subR : R⊆Shore D) (dis : Disjoint W R)
    (xW : F.x∉W) (yW : F.y∉W) (xR : F.x∉R) (yR : F.y∉R)
    (parts : ∀ z∈Shore D,z=F.x ∨ z=F.y ∨ z∈W ∨ z∈R)
    {u t p q : V} (mid : RouteOn G W u t) (utA : u∈classSet D 0) (utB : t∈classSet D 1)
    (tail : RouteOn G R p q) (ap : G.Adj a p) :
    ∃ x y,∃ P : G.Walk x y,P.IsPath ∧ ∀ z,z∈P.support := by
  classical
  have aW : a∉W := fun h=>(shore_off D).1 (subW h)
  have bW : b∉W := fun h=>(shore_off D).2 (subW h)
  have sW : s∉W := fun h=>disjoint_left.mp (shore_disjoint CD) sc (subW h)
  have aR : a∉R := fun h=>(shore_off D).1 (subR h)
  have bR : b∉R := fun h=>(shore_off D).2 (subR h)
  have sR : s∉R := fun h=>disjoint_left.mp (shore_disjoint CD) sc (subR h)
  have axN : a≠F.x := F.ax.ne
  have bxN : b≠F.x := fun h=>(shore_off D).2 (Eq.mp (congrArg (fun z : V => z∈Shore D) h.symm) F.hx)
  have ayN : a≠F.y := fun h=>(shore_off D).1 (Eq.mp (congrArg (fun z : V => z∈Shore D) h.symm) F.hy)
  have byN : b≠F.y := F.by'.ne
  have sxN : s≠F.x := fun h=>disjoint_left.mp (shore_disjoint CD) sc (Eq.mp (congrArg (fun z : V => z∈Shore D) h.symm) F.hx)
  have syN : s≠F.y := fun h=>disjoint_left.mp (shore_disjoint CD) sc (Eq.mp (congrArg (fun z : V => z∈Shore D) h.symm) F.hy)
  have yxN : F.y≠F.x := fun h=>F.nx (h ▸ F.by')
  have r₁ := mid.prefix (F.xAll _ utA) xW
  have r₂ := r₁.suffix (F.yAll _ utB).symm (by simp [yxN,yW])
  have r₃ := r₂.suffix F.by'.symm (by simp [byN,bxN,bW])
  have r₄ := r₃.suffix bs' (by simp [bs'.ne.symm,syN,sxN,sW])
  have r₅ := r₄.suffix as'.symm (by simp [as'.ne,ab.ne,ayN,axN,aW])
  have apart : Disjoint (insert a (insert s (insert b (insert F.y (insert F.x W))))) R := by
    apply disjoint_left.mpr
    intro z zm zr
    simp only [mem_insert] at zm
    rcases zm with rfl|rfl|rfl|rfl|rfl|m
    · exact aR zr
    · exact sR zr
    · exact bR zr
    · exact yR zr
    · exact xR zr
    · exact disjoint_left.mp dis m zr
  obtain ⟨P,Pp,Ps⟩ := r₅.join tail apart ap
  refine ⟨_,_,P,Pp,fun z=>(Ps z).mpr ?_⟩
  by_cases za : z=a
  · simp [za]
  by_cases zb : z=b
  · simp [zb]
  rcases cover za zb with zm|zm
  · have e : z=s := by simpa [single] using zm
    simp [e]
  · rcases parts z zm with e|e|m|m
    · simp [e]
    · simp [e]
    · exact mem_union_left _ (by simp [m])
    · exact mem_union_right _ m

#print axioms glue_balanced_mid_and_tail
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
