import AdjacentCutFiveFifteenSingletonBalancedSwap189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph Shore shore_off shore_closed shore_disjoint from AdjacentCutFiveActual189
open private key classSet from AdjacentCutFiveTopProfiles189
open private commonFive commonFive_ports from AdjacentCutFiveFifteenSingletonBalancedBase189
open private balanced_common_two_geometry from AdjacentCutFiveFifteenSingletonBalancedCommon189
open private b_port_selected_by_common_misses_b_even adj_forbidden_by_dist dist_two_positive_even dist_two_from_b_exclusive
  from AdjacentCutFiveFifteenSingletonMixedCore189
open private predecessor_of_positive_dist from AdjacentCutFiveSixteenSingletonDepth189
open private positive_cap foreign_pos_even from AdjacentCutFiveComponents189
open private mem_positive from AdjacentCutFiveBound189
open private cannot_fit_four_and_two_more from AdjacentCutFiveSixteenSingletonGeometry189
open private degree_at_most_four_from_choices from AdjacentCutFiveFifteenSingletonMixedMap189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

private theorem odd_dark_near_b_even_or_balanced {D : Cmp G a b} (F : BalFrame G a b D)
    (hc : G.Connected) (ab : G.Adj a b) {w : V} (wm : w∈classSet D 5) (no : w∉commonFive D) :
    ∃ q,G.Adj w q ∧ (q∈classSet D 1 ∨ q=F.v) := by
  have wd := (mem_filter.mp wm).1
  have ds := F.odd_dark_dist hc ab wm no
  have pos : 0<G.dist w b := by rw [dist_comm,ds.2]; decide
  obtain ⟨q,wq,hq⟩ := predecessor_of_positive_dist hc pos
  rw [dist_comm (G:=G) (u:=w) (v:=b),dist_comm (G:=G) (u:=q) (v:=b),ds.2] at hq
  have qb : G.dist b q=2 := by omega
  have t₁ := hc.dist_triangle (u:=a) (v:=q) (w:=w)
  rw [ds.1,dist_eq_one_iff_adj.mpr wq.symm] at t₁
  have t₂ := hc.dist_triangle (u:=a) (v:=b) (w:=q)
  rw [dist_eq_one_iff_adj.mpr ab,qb] at t₂
  have qm : q∈Shore D := by
    rcases shore_closed D _ wd _ wq with h|h|h
    · rw [h,dist_self] at t₁; omega
    · rw [h,dist_self] at qb; omega
    · exact h
  by_cases h : G.dist a q=2
  · have k : key G a b q=2 := by classical simp [key,qb,h]
    have m : q∈classSet D 2 := mem_filter.mpr ⟨qm,k⟩
    exact ⟨q,wq,.inr (by simpa [F.E] using m)⟩
  · have e : G.dist a q=3 := by omega
    have k : key G a b q=1 := by classical simp [key,qb,e]
    exact ⟨q,wq,.inl (mem_filter.mpr ⟨qm,k⟩)⟩

private theorem v_no_eb_if_common_chooses_x
    {C D : Cmp G a b} (F : BalFrame G a b D)
    (hc : G.Connected) (ab : G.Adj a b) (even : ∀ w,(EvenFrom G w).card≤6)
    (CD : C≠D) {s : V} (sc : s∈Shore C) (as' : G.Adj a s)
    {c : V} (cm : c∈commonFive D) (cx : G.Adj c F.x) (cv : G.Adj c F.v) (cy : ¬G.Adj c F.y) :
    ∀ u∈classSet D 1,¬G.Adj F.v u := by
  obtain ⟨cd,ac,bc⟩ := commonFive_ports hc ab cm
  exact b_port_selected_by_common_misses_b_even hc even CD sc as' cd F.hy ac bc F.by' F.ny
    F.threeA F.dA F.dB F.xAll cx cv cy

private theorem v_no_ea_if_both_common_choose_x
    {C D : Cmp G a b} (F : BalFrame G a b D)
    (hc : G.Connected) (ab : G.Adj a b) (even : ∀ w,(EvenFrom G w).card≤6)
    (CD : C≠D) {s : V} (sc : s∈Shore C) (bs' : G.Adj b s)
    {c d w : V} (eq : commonFive D={c,d}) (diff : c≠d)
    (wm : w∈classSet D 5) (no : w∉commonFive D)
    (fifth : ∀ t∈classSet D 5,t=c ∨ t=d ∨ t=w)
    (cy : ¬G.Adj F.y c) (dy : ¬G.Adj F.y d) :
    ∀ u∈classSet D 0,¬G.Adj F.v u := by
  classical
  have wdist := F.odd_dark_dist hc ab wm no
  have cm : c∈commonFive D := by simp [eq]
  have dm : d∈commonFive D := by simp [eq]
  obtain ⟨cd,ac,bc⟩ := commonFive_ports hc ab cm
  obtain ⟨dd,ad,bd⟩ := commonFive_ports hc ab dm
  have by1 := dist_eq_one_iff_adj.mpr F.by'
  have wNo : ¬G.Adj F.y w := adj_forbidden_by_dist hc (show G.dist b F.y+1<G.dist b w by omega)
  have vHit : G.Adj F.y F.v := by
    by_contra nv
    have sub : G.neighborFinset F.y ⊆ insert b (classSet D 1) := by
      intro q qm
      have yq := (G.mem_neighborFinset F.y q).mp qm
      rcases shore_closed D _ F.hy _ yq with rfl|rfl|qd
      · exact (F.ny yq.symm).elim
      · exact mem_insert_self _ _
      rcases F.exhaust qd with m|m|rfl|rfl|rfl|m
      · have d := (F.dA q m).2
        exact (adj_forbidden_by_dist hc (show G.dist b F.y+1<G.dist b q by omega) yq).elim
      · exact mem_insert_of_mem m
      · exact (nv yq).elim
      · exact (F.nxy yq.symm).elim
      · exact (G.loopless _ yq).elim
      rcases fifth q m with rfl|rfl|rfl
      · exact (cy yq).elim
      · exact (dy yq).elim
      · exact (wNo yq).elim
    have sz := (card_le_card sub).trans (card_insert_le _ _)
    rw [card_neighborFinset_eq_degree,F.threeB] at sz
    have high := F.high _ F.hy
    omega
  obtain ⟨q,wq,qcase⟩ := odd_dark_near_b_even_or_balanced F hc ab wm no
  have yq : G.Adj F.y q := qcase.elim (F.yAll q) (fun e=>by rw [e]; exact vHit)
  have ywNe : F.y≠w := fun f=>by rw [f,wdist.2] at by1; omega
  have wPos := dist_two_positive_even hc ywNe wNo yq wq.symm
  have yr : F.y≠a := fun e=>(shore_off D).1 (Eq.mp (congrArg (fun z : V => z∈Shore D) e) F.hy)
  have aD := dist_two_from_b_exclusive hc ab F.hy F.by' F.ny
  have aPos : a∈PositiveEven G F.y := mem_positive.mpr ⟨yr.symm,by rw [dist_comm,aD]; decide⟩
  have cPos := dist_two_positive_even hc (show F.y≠c from fun e=>F.ny (by rw [e]; exact ac)) cy F.by'.symm bc
  have dPos := dist_two_positive_even hc (show F.y≠d from fun e=>F.ny (by rw [e]; exact ad)) dy F.by'.symm bd
  have sPos := foreign_pos_even hc CD.symm F.hy sc F.by' bs'
  intro u um vu
  have uD := (mem_filter.mp um).1
  have ud := (F.dA u um).2
  have yuNe : F.y≠u := fun f=>by rw [f,ud] at by1; omega
  have yuNo := adj_forbidden_by_dist hc (show G.dist b F.y+1<G.dist b u by omega)
  have uPos := dist_two_positive_even hc yuNe yuNo vHit vu
  have hset : ({a,c,d,w}:Finset V)⊆PositiveEven G F.y := by
    intro q qm
    simp only [mem_insert,mem_singleton] at qm
    rcases qm with rfl|rfl|rfl|rfl <;> assumption
  have wc : w≠c := fun e=>no (e.symm ▸ cm)
  have wd : w≠d := fun e=>no (e.symm ▸ dm)
  have ww := (mem_filter.mp wm).1
  have nc : a≠c := fun e=>(shore_off D).1 (e.symm ▸ cd)
  have nd : a≠d := fun e=>(shore_off D).1 (e.symm ▸ dd)
  have nw : a≠w := fun e=>(shore_off D).1 (e.symm ▸ ww)
  have cnt : 4≤({a,c,d,w}:Finset V).card := by simp [nc,nd,nw,diff,wc.symm,wd.symm]
  have apart (z : V) (zd : z∈Shore D) : s≠z := fun e=>disjoint_left.mp (shore_disjoint CD) sc (e.symm ▸ zd)
  have snot : s∉({a,c,d,w}:Finset V) := by
    have sa : s≠a := fun e=>(shore_off C).1 (e ▸ sc)
    simp [sa,apart c cd,apart d dd,apart w ww]
  have unot : u∉({a,c,d,w}:Finset V) := by
    have ua : u≠a := fun e=>(shore_off D).1 (e ▸ uD)
    have uc : u≠c := fun e=>by rw [e,dist_eq_one_iff_adj.mpr bc] at ud; omega
    have ud' : u≠d := fun e=>by rw [e,dist_eq_one_iff_adj.mpr bd] at ud; omega
    have uw : u≠w := fun e=>by
      have h := (F.dA u um).1
      rw [e,wdist.1] at h
      omega
    simp [ua,uc,ud',uw]
  exact cannot_fit_four_and_two_more even cnt hset snot unot (apart u uD).symm sPos uPos

#print axioms v_no_eb_if_common_chooses_x
#print axioms v_no_ea_if_both_common_choose_x
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
