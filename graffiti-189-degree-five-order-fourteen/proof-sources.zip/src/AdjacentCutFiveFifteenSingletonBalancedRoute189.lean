import AdjacentCutFiveFifteenSingletonBalancedBase189
import AdjacentCutFiveFourteenDarkBridge189
import DegreeFiveRouteBasic189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset ArticulationPair
open private lift_side_path from DegreeFiveSmallSides189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

private theorem local_degree_add_outside {W : Finset V} {v : V}
    (vm : v∈W) (M : Finset V) (bound : ∀ w,G.Adj v w → w∈W ∨ w∈M) :
    G.degree v≤(G.induce (↑W : Set V)).degree (⟨v,vm⟩ : ↑(↑W : Set V)) + M.card := by
  classical
  have sub : G.neighborFinset v ⊆ inside G W v ∪ M := by
    intro w wm
    have e := (G.mem_neighborFinset v w).mp wm
    exact (bound w e).elim (fun h=>mem_union_left _ (mem_filter.mpr ⟨h,e⟩)) (mem_union_right _)
  have h := (card_le_card sub).trans (card_union_le _ _)
  rw [card_neighborFinset_eq_degree,inside_card_eq_degree_induce (G:=G) W (⟨v,vm⟩ : ↑(↑W : Set V))] at h
  exact h

private theorem terminal_route_on_seven (W : Finset V) (n : W.card=7)
    (high : ∀ v (m : v∈W),4≤(G.induce (↑W:Set V)).degree (⟨v,m⟩ : ↑(↑W:Set V)))
    {u v : V} (uw : u∈W) (vw : v∈W) (uv : u≠v) : RouteOn G W u v := by
  classical
  let J := G.induce (↑W : Set V)
  let U := ↑(↑W : Set V)
  have count : Fintype.card U=7 := (Fintype.card_coe W).trans n
  have ore (x y : U) (_ : x≠y) (_ : ¬J.Adj x y) : Fintype.card U+1≤J.degree x+J.degree y := by
    have d := high x.val x.property
    have e := high y.val y.property
    change 4≤J.degree x at d
    change 4≤J.degree y at e
    omega
  have ne : (⟨u,uw⟩ : U)≠⟨v,vw⟩ := fun h=>uv (congrArg Subtype.val h)
  obtain ⟨p,pp,all⟩ := hamilton_connected_of_ore (G:=J) ore ne
  exact lift_side_path W p pp all

private theorem terminal_route_on_small_one_exception
    (A : Finset V) {l x y u v : V} (out : l∉A) (small : A.card≤6)
    (xa : x∈A) (ya : y∈A) (xy : x≠y)
    (ua : u∈A) (va : v∈A) (uv : u≠v)
    (lu : G.Adj l u) (lv : G.Adj l v)
    (notPair : ¬((x=u ∧ y=v) ∨ (x=v ∧ y=u)))
    (high : ∀ w (wm : w∈A),4≤(G.induce (↑(insert l A) : Set V)).degree
      (⟨w,mem_insert_of_mem wm⟩ : ↑(↑(insert l A):Set V))) :
    RouteOn G (insert l A) x y := by
  classical
  let W := insert l A
  let U := ↑(↑W : Set V)
  let J := G.induce (↑W : Set V)
  let low : U := ⟨l,mem_insert_self _ _⟩
  let K : Finset U := univ.filter (fun q=>q.val∈A)
  let x' : U := ⟨x,mem_insert_of_mem xa⟩
  let y' : U := ⟨y,mem_insert_of_mem ya⟩
  let u' : U := ⟨u,mem_insert_of_mem ua⟩
  let v' : U := ⟨v,mem_insert_of_mem va⟩
  have mx : x'∈K := by simp [x',K,xa]
  have my : y'∈K := by simp [y',K,ya]
  have mu : u'∈K := by simp [u',K,ua]
  have mv : v'∈K := by simp [v',K,va]
  have nx : x'≠y' := fun e=>xy (congrArg Subtype.val e)
  have nu : u'≠v' := fun e=>uv (congrArg Subtype.val e)
  have nPair : ¬((x'=u' ∧ y'=v') ∨ (x'=v' ∧ y'=u')) := by
    rintro (⟨h,j⟩|⟨h,j⟩)
    · exact notPair (.inl ⟨congrArg Subtype.val h,congrArg Subtype.val j⟩)
    · exact notPair (.inr ⟨congrArg Subtype.val h,congrArg Subtype.val j⟩)
  have covers : insert low K=(univ : Finset U) := by
    ext q
    simp only [mem_insert,mem_filter,mem_univ,true_and,iff_true,K]
    rcases mem_insert.mp q.property with h|h
    · exact .inl (Subtype.ext h)
    · exact .inr h
  have count : Fintype.card U≤7 := by
    rw [show Fintype.card U=W.card from Fintype.card_coe W,show W.card=A.card+1 from card_insert_of_not_mem out]
    omega
  have hs (q : U) (qm : q∈K) : 4≤J.degree q := high q.val (mem_filter.mp qm).2
  have res := terminal_route_through_one_dark_exception K covers
    (show low∉K from by simpa [K,low] using out) mx my nx mu mv nu
    (show J.Adj low u' from lu) (show J.Adj low v' from lv) nPair
    (fun q qm r rm _ _=>by have g := hs q qm; have h := hs r rm; omega)
  obtain ⟨p,pp,ps⟩ := res
  exact lift_side_path W p pp (fun z=>(ps z).mpr (mem_univ _))

#print axioms local_degree_add_outside
#print axioms terminal_route_on_seven
#print axioms terminal_route_on_small_one_exception
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
