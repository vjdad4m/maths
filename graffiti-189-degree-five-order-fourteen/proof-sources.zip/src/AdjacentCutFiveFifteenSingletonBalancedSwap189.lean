import AdjacentCutFiveFifteenSingletonBalancedClique189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph Shore from AdjacentCutFiveActual189
open private key classSet from AdjacentCutFiveTopProfiles189
open private swapCut from AdjacentCutFiveMixedNineGeom189
open private classSet_swap key_swap_index swapIndex from AdjacentCutFiveFifteenSingletonResidual189
open private commonFive commonFive_ports from AdjacentCutFiveFifteenSingletonBalancedBase189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

private theorem commonFive_swap (hc : G.Connected) (ab : G.Adj a b) (D : Cmp G a b) :
    commonFive (swapCut D)=commonFive D := by
  ext w
  constructor
  · intro wm
    obtain ⟨_,_,aw⟩ := commonFive_ports hc ab.symm wm
    have h := (mem_filter.mp wm).1
    rw [classSet_swap] at h
    exact mem_filter.mpr ⟨h,aw⟩
  · intro wm
    obtain ⟨_,_,bw⟩ := commonFive_ports hc ab wm
    have h : w∈classSet (swapCut D) 5 := by
      rw [classSet_swap]
      exact (mem_filter.mp wm).1
    exact mem_filter.mpr ⟨h,bw⟩

private noncomputable def BalFrame.swap {D : Cmp G a b} (F : BalFrame G a b D)
    (hc : G.Connected) (ab : G.Adj a b) : BalFrame G b a (swapCut D) := by
  refine ⟨F.y,F.x,F.v,?_,?_,?_,F.by',F.ny,F.ax,F.nx,fun e=>F.nxy e.symm,?_,?_,?_,?_,?_,?_,?_,?_,?_,?_,?_,?_,?_,?_,?_⟩
  · simpa only [shore_swapCut] using F.hy
  · simpa only [shore_swapCut] using F.hx
  · simpa only [shore_swapCut] using F.hv
  · rw [key_swap_index (a:=a) (b:=b),F.yk]; decide
  · rw [key_swap_index (a:=a) (b:=b),F.xk]; decide
  · rw [key_swap_index (a:=a) (b:=b),F.vk]; decide
  · rw [classSet_swap]; exact F.R
  · rw [classSet_swap]; exact F.L
  · rw [classSet_swap]; exact F.E
  · rw [classSet_swap]; exact F.threeB
  · rw [classSet_swap]; exact F.threeA
  · rw [classSet_swap]; exact F.threeC
  · intro w wm
    rw [classSet_swap] at wm
    exact (F.dB w wm).symm
  · intro w wm
    rw [classSet_swap] at wm
    exact (F.dA w wm).symm
  · intro w wm
    rw [classSet_swap] at wm
    exact F.yAll w wm
  · intro w wm
    rw [classSet_swap] at wm
    exact F.xAll w wm
  · intro w wm
    rw [shore_swapCut] at wm
    exact F.high w wm
  · rw [commonFive_swap hc ab]
    exact F.commonAtLeast

#print axioms BalFrame.swap
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
