import AdjacentCutFiveFifteenSingletonBalancedTwo189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset ArticulationPair
open private CutGraph Shore shore_off shore_closed shore_disjoint from AdjacentCutFiveActual189
open private key classSet from AdjacentCutFiveTopProfiles189
open private commonFive commonFive_ports from AdjacentCutFiveFifteenSingletonBalancedBase189
open private balanced_three_common_clique from AdjacentCutFiveFifteenSingletonBalancedClique189
open private disjoint_profile_sets from AdjacentCutFiveSixteenSingletonGeometry189
open private darkCore darkCore_card darkCore_sub balanced_even_dark dark_core_neighbor_classes
  dark_core_one_outside_degree from AdjacentCutFiveFifteenSingletonBalancedDark189
open private local_degree_add_outside terminal_route_on_small_one_exception from AdjacentCutFiveFifteenSingletonBalancedRoute189
open private glue_balanced_mid_and_tail from AdjacentCutFiveFifteenSingletonBalancedGlue189
open private lift_side_path from DegreeFiveSmallSides189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

private theorem terminal_route_on_six (W : Finset V) (n : W.card=6)
    (medium : ∀ u (um : u∈W),3≤(G.induce (↑W:Set V)).degree (⟨u,um⟩ : ↑(↑W:Set V)))
    (distinctHigh : ∀ u (um : u∈W) v (vm : v∈W),u≠v →
     4≤(G.induce (↑W:Set V)).degree (⟨u,um⟩ : ↑(↑W:Set V)) ∨
     4≤(G.induce (↑W:Set V)).degree (⟨v,vm⟩ : ↑(↑W:Set V)))
    {u v : V} (uw : u∈W) (vw : v∈W) (uv : u≠v) : RouteOn G W u v := by
  classical
  let J := G.induce (↑W : Set V)
  let U := ↑(↑W : Set V)
  have count : Fintype.card U=6 := (Fintype.card_coe W).trans n
  have ore (x y : U) (ne : x≠y) (_ : ¬J.Adj x y) : Fintype.card U+1≤J.degree x+J.degree y := by
    have d := medium x.val x.property
    have e := medium y.val y.property
    have q := distinctHigh x.val x.property y.val y.property (fun h=>ne (Subtype.ext h))
    change 3≤J.degree x at d
    change 3≤J.degree y at e
    change 4≤J.degree x ∨ 4≤J.degree y at q
    omega
  have ne : (⟨u,uw⟩ : U)≠⟨v,vw⟩ := fun h=>uv (congrArg Subtype.val h)
  obtain ⟨p,pp,all⟩ := hamilton_connected_of_ore (G:=J) ore ne
  exact lift_side_path W p pp all

private theorem balanced_three_common_alt_cut
    {C D : Cmp G a b} (F : BalFrame G a b D)
    (hc : G.Connected) (ab : G.Adj a b)
    (CD : C≠D) {s : V} (sc : s∈Shore C)
    (allCommon : classSet D 5=commonFive D)
    (n : ∀ c∈commonFive D,¬G.Adj F.v c) :
    ∃ x y : V,x≠y ∧ ¬G.Adj x y ∧ ¬(G.induce {z : V | z≠x ∧ z≠y}).Connected := by
  classical
  let S := insert F.v (darkCore D)
  have sub : S⊆Shore D := insert_subset_iff.mpr ⟨F.hv,darkCore_sub D⟩
  have nx : s≠F.x := fun e=>disjoint_left.mp (shore_disjoint CD) sc (e.symm ▸ F.hx)
  have ny : s≠F.y := fun e=>disjoint_left.mp (shore_disjoint CD) sc (e.symm ▸ F.hy)
  have vx : F.v≠F.x := fun e=>by have f := F.vk; rw [e,F.xk] at f; contradiction
  have vy : F.v≠F.y := fun e=>by have f := F.vk; rw [e,F.yk] at f; contradiction
  refine ⟨F.x,F.y,fun e=>F.ny (e ▸ F.ax),F.nxy,?_⟩
  intro co
  let T : Set V := {z | z≠F.x ∧ z≠F.y}
  have closure {u w : V} (um : u∈S) (uw : G.Adj u w) (wx : w≠F.x) (wy : w≠F.y) : w∈S := by
    rcases mem_insert.mp um with rfl|um
    · have z := balanced_even_dark F hc ab
      rcases shore_closed D _ F.hv _ uw with rfl|rfl|wd
      · exact (z.1 uw.symm).elim
      · exact (z.2 uw.symm).elim
      rcases F.exhaust wd with q|q|rfl|rfl|rfl|q
      · exact mem_insert_of_mem (mem_union_left _ q)
      · exact mem_insert_of_mem (mem_union_right _ q)
      · exact mem_insert_self _ _
      · exact (wx rfl).elim
      · exact (wy rfl).elim
      · rw [allCommon] at q
        exact (n _ q uw).elim
    · rcases dark_core_neighbor_classes F hc ab um uw with q|rfl|q|q|q
      · exact mem_insert_of_mem q
      · exact mem_insert_self _ _
      · exact (wx q.1).elim
      · exact (wy q.1).elim
      · obtain ⟨h,k⟩ := mem_sdiff.mp q
        exact (k (allCommon ▸ h)).elim
  have stay {u w : T} (p : (G.induce T).Walk u w) (um : u.val∈S) : w.val∈S := by
    induction p with
    | nil => exact um
    | @cons u t w e p ih => exact ih (closure um e t.property.1 t.property.2)
  obtain ⟨p⟩ := co.preconnected (⟨F.v,vx,vy⟩ : T) ⟨s,nx,ny⟩
  exact disjoint_left.mp (shore_disjoint CD) sc (sub (stay p (mem_insert_self _ _)))

#print axioms terminal_route_on_six
#print axioms balanced_three_common_alt_cut

private theorem balanced_exactly_three_common
    {C D : Cmp G a b} (F : BalFrame G a b D)
    (hc : G.Connected) (ab : G.Adj a b) (even : ∀ w,(EvenFrom G w).card≤6)
    (CD : C≠D) {s : V} (sc : s∈Shore C) (single : Shore C={s}) (as' : G.Adj a s) (bs' : G.Adj b s)
    (cover : ∀ {z : V},z≠a → z≠b → z∈Shore C ∨ z∈Shore D)
    (three : (commonFive D).card=3) :
    (∃ x y : V,x≠y ∧ ¬G.Adj x y ∧ ¬(G.induce {z : V | z≠x ∧ z≠y}).Connected) ∨
    (∃ x y,∃ P : G.Walk x y,P.IsPath ∧ ∀ z,z∈P.support) := by
  classical
  let K := commonFive D
  let W := darkCore D
  have kSub : K⊆classSet D 5 := filter_subset _ _
  have allCommon : classSet D 5=K := (eq_of_subset_of_card_le kSub (by rw [three,F.threeC])).symm
  by_cases hit : ∃ r∈K,G.Adj F.v r
  swap
  · exact .inl (balanced_three_common_alt_cut F hc ab CD sc allCommon (fun c cm cv=>hit ⟨c,cm,cv⟩))
  obtain ⟨r,rm,vr⟩ := hit
  have comp := balanced_three_common_clique F hc ab even CD sc as' bs' three
  obtain ⟨q,p,pp,ps⟩ := rooted_path_in_clique K comp rm
  have qK := (ps q).mp p.end_mem_support
  have tail : RouteOn G K q r := (show RouteOn G K r q from ⟨p,pp,ps⟩).reverse
  have aq := (commonFive_ports hc ab qK).2.1
  have subW : W⊆Shore D := darkCore_sub D
  have subK : K⊆Shore D := fun _ m=>(commonFive_ports hc ab m).1
  have dis : Disjoint W K := by
    apply disjoint_left.mpr
    intro t tm tk
    have k := (mem_filter.mp (kSub tk)).2
    rcases mem_union.mp tm with m|m
    · rw [(mem_filter.mp m).2] at k
      exact (by decide : (0:Fin 6)≠5) k
    · rw [(mem_filter.mp m).2] at k
      exact (by decide : (1:Fin 6)≠5) k
  have darkOutside {z : V} (h : key G a b z=2 ∨ key G a b z=3 ∨ key G a b z=4) : z∉W := by
    intro zm
    rcases mem_union.mp zm with m|m
    · rw [(mem_filter.mp m).2] at h
      exact (by decide : ¬_) h
    · rw [(mem_filter.mp m).2] at h
      exact (by decide : ¬_) h
  have neKey {u v : V} (h : key G a b u≠key G a b v) : u≠v := fun e=>h (congrArg (key G a b) e)
  have vrOut : F.v∉K := fun h=>by
    have j := (mem_filter.mp (kSub h)).2
    rw [F.vk] at j
    exact (by decide : (2:Fin 6)≠5) j
  have xK : F.x∉K := fun h=>by
    have j := (mem_filter.mp (kSub h)).2
    rw [F.xk] at j
    exact (by decide : (3:Fin 6)≠5) j
  have yK : F.y∉K := fun h=>by
    have j := (mem_filter.mp (kSub h)).2
    rw [F.yk] at j
    exact (by decide : (4:Fin 6)≠5) j
  have xW := darkOutside (.inr (.inl F.xk))
  have yW := darkOutside (.inr (.inr F.yk))
  have vW := darkOutside (.inl F.vk)
  have xv : F.x≠F.v := neKey (by rw [F.xk,F.vk]; decide)
  have yv : F.y≠F.v := neKey (by rw [F.yk,F.vk]; decide)
  have fifth {A : Finset V} : classSet D 5\commonFive D⊆A := by
    intro t tm
    obtain ⟨g,h⟩ := mem_sdiff.mp tm
    have gg : t∈K := allCommon ▸ g
    exact (h gg).elim
  have parts : ∀ z∈Shore D,z=F.x ∨ z=F.y ∨ z=F.v ∨ z∈W ∨ z∈K := by
    intro z zm
    rcases F.exhaust zm with m|m|m|m|m|m
    · exact .inr (.inr (.inr (.inl (mem_union_left _ m))))
    · exact .inr (.inr (.inr (.inl (mem_union_right _ m))))
    · exact .inr (.inr (.inl m))
    · exact .inl m
    · exact .inr (.inl m)
    · exact .inr (.inr (.inr (.inr (allCommon ▸ m))))
  by_cases many : ∃ u∈W,∃ v∈W,u≠v ∧ G.Adj F.v u ∧ G.Adj F.v v
  · obtain ⟨u,um,v,vm,uv,vu,vv⟩ := many
    have sep := disjoint_profile_sets D (by decide : (0:Fin 6)≠1)
    obtain ⟨x,xm,y,ym,xy,pair⟩ := choose_opposite_endpoints_away_from_pair
      (classSet D 0) (classSet D 1) sep (card_pos.mp (show 0<(classSet D 0).card by rw [F.threeA]; decide))
      (card_pos.mp (show 0<(classSet D 1).card by rw [F.threeB]; decide))
      (.inl (show 2≤(classSet D 0).card by rw [F.threeA]; decide)) (u:=u) (v:=v)
    let W' := insert F.v W
    have hi : ∀ t (tm : t∈W),4≤(G.induce (↑W':Set V)).degree
        (⟨t,mem_insert_of_mem tm⟩ : ↑(↑W':Set V)) := by
      intro t tm
      exact dark_core_one_outside_degree F hc ab (subset_insert _ _) fifth tm (fun _=>mem_insert_self _ _)
    have small : W.card≤6 := (darkCore_card F).le
    have mid := terminal_route_on_small_one_exception W vW small (mem_union_left _ xm) (mem_union_right _ ym) xy um vm uv vu vv pair hi
    have dis' : Disjoint W' K := disjoint_insert_left.mpr ⟨vrOut,dis⟩
    refine .inr (glue_balanced_mid_and_tail F ab CD sc single as' bs' cover
      (insert_subset_iff.mpr ⟨F.hv,subW⟩) subK dis' (by simp [W',xv,xW]) (by simp [W',yv,yW]) xK yK ?_ mid xm ym tail aq)
    intro z zd
    rcases parts z zd with m|m|rfl|m|m
    · exact .inl m
    · exact .inr (.inl m)
    · exact .inr (.inr (.inl (mem_insert_self _ _)))
    · exact .inr (.inr (.inl (mem_insert_of_mem m)))
    · exact .inr (.inr (.inr m))
  · have one : ∀ u∈W,∀ v∈W,u≠v → ¬(G.Adj F.v u ∧ G.Adj F.v v) :=
      fun u um v vm ne ⟨vu,vv⟩=>many ⟨u,um,v,vm,ne,vu,vv⟩
    have med (u : V) (um : u∈W) : 3≤(G.induce (↑W:Set V)).degree (⟨u,um⟩ : ↑(↑W:Set V)) := by
      have hi := F.high u (subW um)
      have run (r : V) (choose : ∀ w,w=F.x ∧ u∈classSet D 0 ∨ w=F.y ∧ u∈classSet D 1 → w=r) :
          3≤(G.induce (↑W:Set V)).degree (⟨u,um⟩ : ↑(↑W:Set V)) := by
        have bnd := local_degree_add_outside (G:=G) um {r,F.v} (by
          intro z uz
          rcases dark_core_neighbor_classes F hc ab um uz with z|rfl|z|z|z
          · exact .inl z
          · exact .inr (by simp)
          · exact .inr (by simp [choose _ (.inl z)])
          · exact .inr (by simp [choose _ (.inr z)])
          · exact .inl (fifth z))
        have k := card_insert_le r ({F.v}:Finset V)
        rw [card_singleton] at k
        omega
      have sep := disjoint_profile_sets D (by decide : (0:Fin 6)≠1)
      rcases mem_union.mp um with m|m
      · exact run F.x (fun w h=>h.elim And.left (fun h=>(disjoint_left.mp sep m h.2).elim))
      · exact run F.y (fun w h=>h.elim (fun h=>(disjoint_left.mp sep h.2 m).elim) And.left)
    have highPair (u : V) (um : u∈W) (v : V) (vm : v∈W) (ne : u≠v) :
        4≤(G.induce (↑W:Set V)).degree (⟨u,um⟩ : ↑(↑W:Set V)) ∨
        4≤(G.induce (↑W:Set V)).degree (⟨v,vm⟩ : ↑(↑W:Set V)) := by
      have run (t : V) (tm : t∈W) (tb : ¬G.Adj F.v t) :
          4≤(G.induce (↑W:Set V)).degree (⟨t,tm⟩ : ↑(↑W:Set V)) :=
        dark_core_one_outside_degree F hc ab (subset_refl W) fifth tm (fun e=>(tb e.symm).elim)
      by_cases e : G.Adj F.v u
      · exact .inr (run v vm (fun f=>one u um v vm ne ⟨e,f⟩))
      · exact .inl (run u um e)
    obtain ⟨x,xm⟩ := card_pos.mp (show 0<(classSet D 0).card by rw [F.threeA]; decide)
    obtain ⟨y,ym⟩ := card_pos.mp (show 0<(classSet D 1).card by rw [F.threeB]; decide)
    have ne : x≠y := fun e=>disjoint_left.mp
      (disjoint_profile_sets D (by decide : (0:Fin 6)≠1)) xm (e.symm ▸ ym)
    have mid := terminal_route_on_six W (darkCore_card F) med highPair
      (mem_union_left _ xm) (mem_union_right _ ym) ne
    let K' := insert F.v K
    have tail' := tail.suffix vr.symm vrOut
    have dis' : Disjoint W K' := disjoint_insert_right.mpr ⟨vW,dis⟩
    refine .inr (glue_balanced_mid_and_tail F ab CD sc single as' bs' cover
      subW (insert_subset_iff.mpr ⟨F.hv,subK⟩) dis' xW yW (by simp [K',xv,xK]) (by simp [K',yv,yK]) ?_ mid xm ym tail' aq)
    intro z zd
    rcases parts z zd with m|m|rfl|m|m
    · exact .inl m
    · exact .inr (.inl m)
    · exact .inr (.inr (.inr (mem_insert_self _ _)))
    · exact .inr (.inr (.inl m))
    · exact .inr (.inr (.inr (mem_insert_of_mem m)))

#print axioms balanced_exactly_three_common
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
