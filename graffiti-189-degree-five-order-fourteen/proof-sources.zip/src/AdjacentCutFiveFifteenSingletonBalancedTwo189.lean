import AdjacentCutFiveFifteenSingletonBalancedTwoRoute189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph Shore shore_off shore_closed shore_disjoint from AdjacentCutFiveActual189
open private key classSet from AdjacentCutFiveTopProfiles189
open private commonFive from AdjacentCutFiveFifteenSingletonBalancedBase189
open private classSet_swap from AdjacentCutFiveFifteenSingletonResidual189
open private BalFrame.swap commonFive_swap from AdjacentCutFiveFifteenSingletonBalancedSwap189
open private swapCut from AdjacentCutFiveMixedNineGeom189
open private balanced_common_two_geometry from AdjacentCutFiveFifteenSingletonBalancedCommon189
open private v_no_eb_if_common_chooses_x v_no_ea_if_both_common_choose_x from AdjacentCutFiveFifteenSingletonBalancedOff189
open private darkCore from AdjacentCutFiveFifteenSingletonBalancedDark189
open private traceable_of_balanced_two_common_and_v_no_polar from AdjacentCutFiveFifteenSingletonBalancedTwoRoute189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

private theorem traceable_balanced_exactly_two_common
    {C D : Cmp G a b} (F : BalFrame G a b D)
    (hc : G.Connected) (ab : G.Adj a b) (even : ∀ w,(EvenFrom G w).card≤6)
    (CD : C≠D) {s : V} (sc : s∈Shore C) (single : Shore C={s}) (as' : G.Adj a s) (bs' : G.Adj b s)
    (cover : ∀ {z : V},z≠a → z≠b → z∈Shore C ∨ z∈Shore D)
    (two : (commonFive D).card=2) :
    ∃ x y,∃ P : G.Walk x y,P.IsPath ∧ ∀ z,z∈P.support := by
  classical
  obtain ⟨c,d,ne,eq⟩ := card_eq_two.mp two
  have sub : commonFive D⊆classSet D 5 := filter_subset _ _
  have diff : (classSet D 5\commonFive D).card=1 := by
    have h := card_sdiff_add_card_eq_card sub
    rw [F.threeC,two] at h
    omega
  obtain ⟨w,ws⟩ := card_eq_one.mp diff
  have wm' : w∈classSet D 5\commonFive D := by simp [ws]
  obtain ⟨wm,no⟩ := mem_sdiff.mp wm'
  have fifth : ∀ t∈classSet D 5,t=c ∨ t=d ∨ t=w := by
    intro t tm
    by_cases cmt : t∈commonFive D
    · have g : t=c ∨ t=d := by simpa [eq] using cmt
      exact g.elim .inl (fun e=>.inr (.inl e))
    · have g : t∈classSet D 5\commonFive D := mem_sdiff.mpr ⟨tm,cmt⟩
      exact .inr (.inr (by simpa [ws] using g))
  have cm : c∈commonFive D := by simp [eq]
  have dm : d∈commonFive D := by simp [eq]
  have cg := balanced_common_two_geometry F hc ab even eq
  have dg := balanced_common_two_geometry F hc ab even (show commonFive D={d,c} by rw [eq,pair_comm])
  let Fs := BalFrame.swap F hc ab
  have CD' : swapCut C≠swapCut D := fun e=>CD (swapCut.injective e)
  have sc' : s∈Shore (swapCut C) := by rw [shore_swapCut C]; exact sc
  have common' : commonFive (swapCut D)={c,d} := (commonFive_swap hc ab D).trans eq
  have cM : c∈commonFive (swapCut D) := by rw [common']; simp
  have dM : d∈commonFive (swapCut D) := by rw [common']; simp
  have leftMiss {k : V} (km : k∈commonFive (swapCut D)) (ky : G.Adj k F.y)
      (kv : G.Adj k F.v) (kx : ¬G.Adj k F.x) :
      ∀ u∈classSet D 0,¬G.Adj F.v u := by
    intro u um
    have um' : u∈classSet (swapCut D) 1 := by rw [classSet_swap]; exact um
    exact v_no_eb_if_common_chooses_x Fs hc ab.symm even CD' sc' bs' km ky kv kx u um'
  have rightMiss {k : V} (km : k∈commonFive D) (kx : G.Adj k F.x)
      (kv : G.Adj k F.v) (ky : ¬G.Adj k F.y) :
      ∀ u∈classSet D 1,¬G.Adj F.v u :=
    v_no_eb_if_common_chooses_x F hc ab even CD sc as' km kx kv ky
  have bothLeft (cy : ¬G.Adj c F.y) (dy : ¬G.Adj d F.y) :
      ∀ u∈classSet D 0,¬G.Adj F.v u :=
    v_no_ea_if_both_common_choose_x F hc ab even CD sc bs' eq ne wm no fifth
      (fun h=>cy h.symm) (fun h=>dy h.symm)
  have bothRight (cx : ¬G.Adj c F.x) (dx : ¬G.Adj d F.x) :
      ∀ u∈classSet D 1,¬G.Adj F.v u := by
    intro u um
    have wm' : w∈classSet (swapCut D) 5 := by rw [classSet_swap]; exact wm
    have no' : w∉commonFive (swapCut D) := by rw [commonFive_swap hc ab]; exact no
    have f : ∀ t∈classSet (swapCut D) 5,t=c ∨ t=d ∨ t=w := by
      intro t tm
      rw [classSet_swap] at tm
      exact fifth t tm
    have um' : u∈classSet (swapCut D) 0 := by rw [classSet_swap]; exact um
    exact v_no_ea_if_both_common_choose_x Fs hc ab.symm even CD' sc' as' common' ne wm' no' f
      (fun h=>cx h.symm) (fun h=>dx h.symm) u um'
  have missCuts : (∀ u∈classSet D 0,¬G.Adj F.v u) ∧ (∀ u∈classSet D 1,¬G.Adj F.v u) := by
    rcases cg.2.2 with ⟨cx,cy⟩|⟨cy,cx⟩ <;> rcases dg.2.2 with ⟨dx,dy⟩|⟨dy,dx⟩
    · exact ⟨bothLeft cy dy,rightMiss cm cx cg.2.1 cy⟩
    · exact ⟨leftMiss dM dy dg.2.1 dx,rightMiss cm cx cg.2.1 cy⟩
    · exact ⟨leftMiss cM cy cg.2.1 cx,rightMiss dm dx dg.2.1 dy⟩
    · exact ⟨leftMiss cM cy cg.2.1 cx,bothRight cx dx⟩
  exact traceable_of_balanced_two_common_and_v_no_polar F hc ab even CD sc single as' bs' cover eq wm no fifth
    (fun u um=>(mem_union.mp um).elim (missCuts.1 u) (missCuts.2 u))

#print axioms traceable_balanced_exactly_two_common
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
