import AdjacentCutFiveFifteenSingletonBalancedGlue189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph Shore shore_off shore_closed shore_disjoint from AdjacentCutFiveActual189
open private key classSet from AdjacentCutFiveTopProfiles189
open private commonFive commonFive_ports from AdjacentCutFiveFifteenSingletonBalancedBase189
open private balanced_common_two_geometry from AdjacentCutFiveFifteenSingletonBalancedCommon189
open private adj_forbidden_by_dist from AdjacentCutFiveFifteenSingletonMixedCore189
open private disjoint_profile_sets from AdjacentCutFiveSixteenSingletonGeometry189
open private darkCore darkCore_card darkCore_sub dark_core_one_outside_degree from AdjacentCutFiveFifteenSingletonBalancedDark189
open private local_degree_add_outside terminal_route_on_seven from AdjacentCutFiveFifteenSingletonBalancedRoute189
open private glue_balanced_mid_and_tail from AdjacentCutFiveFifteenSingletonBalancedGlue189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

private theorem traceable_of_balanced_two_common_and_v_no_polar
    {C D : Cmp G a b} (F : BalFrame G a b D)
    (hc : G.Connected) (ab : G.Adj a b) (even : ∀ w,(EvenFrom G w).card≤6)
    (CD : C≠D) {s : V} (sc : s∈Shore C) (single : Shore C={s}) (as' : G.Adj a s) (bs' : G.Adj b s)
    (cover : ∀ {z : V},z≠a → z≠b → z∈Shore C ∨ z∈Shore D)
    {c d w : V} (eq : commonFive D={c,d})
    (wm : w∈classSet D 5) (no : w∉commonFive D)
    (fifth : ∀ t∈classSet D 5,t=c ∨ t=d ∨ t=w)
    (miss : ∀ u∈darkCore D,¬G.Adj F.v u) :
    ∃ x y,∃ P : G.Walk x y,P.IsPath ∧ ∀ z,z∈P.support := by
  classical
  let W := insert w (darkCore D)
  let R : Finset V := {c,d,F.v}
  have cm : c∈commonFive D := by simp [eq]
  have dm : d∈commonFive D := by simp [eq]
  have ⟨cd,ac,bc⟩ := commonFive_ports hc ab cm
  have ⟨dd,ad,bd⟩ := commonFive_ports hc ab dm
  have wk := (mem_filter.mp wm).2
  have ck := (mem_filter.mp (mem_filter.mp cm).1).2
  have dk := (mem_filter.mp (mem_filter.mp dm).1).2
  have wd := (mem_filter.mp wm).1
  have darkkey (z : V) (m : z∈darkCore D) : key G a b z=0 ∨ key G a b z=1 := by
    rcases mem_union.mp m with h|h
    · exact .inl (mem_filter.mp h).2
    · exact .inr (mem_filter.mp h).2
  have outside {z : V} (h : key G a b z=2 ∨ key G a b z=3 ∨ key G a b z=4 ∨ key G a b z=5) :
      z∉darkCore D := by
    intro m
    rcases darkkey z m with j|j <;> rw [j] at h <;> exact (by decide : ¬_) h
  have wOut := outside (.inr (.inr (.inr wk)))
  have xOut := outside (.inr (.inl F.xk))
  have yOut := outside (.inr (.inr (.inl F.yk)))
  have vOut := outside (.inl F.vk)
  have cOut := outside (.inr (.inr (.inr ck)))
  have dOut := outside (.inr (.inr (.inr dk)))
  have neKey {u v : V} (h : key G a b u≠key G a b v) : u≠v := fun e=>h (congrArg (key G a b) e)
  have xw : F.x≠w := neKey (by rw [F.xk,wk]; decide)
  have yw : F.y≠w := neKey (by rw [F.yk,wk]; decide)
  have vx : F.x≠F.v := neKey (by rw [F.xk,F.vk]; decide)
  have vy : F.y≠F.v := neKey (by rw [F.yk,F.vk]; decide)
  have wc : w≠c := fun e=>no (e.symm ▸ cm)
  have wd' : w≠d := fun e=>no (e.symm ▸ dm)
  have wv : w≠F.v := neKey (by rw [wk,F.vk]; decide)
  have subW : W⊆Shore D := insert_subset_iff.mpr ⟨wd,darkCore_sub D⟩
  have subR : R⊆Shore D := by simp [R,insert_subset_iff,cd,dd,F.hv]
  have dis : Disjoint W R := by
    apply disjoint_left.mpr
    intro z zw zr
    have rr : z=c ∨ z=d ∨ z=F.v := by simpa [R] using zr
    rcases mem_insert.mp zw with rfl|m
    · exact rr.elim wc (fun h=>h.elim wd' wv)
    · rcases rr with rfl|rfl|rfl
      · exact cOut m
      · exact dOut m
      · exact vOut m
  have xD : F.x∉R := by
    have c' : F.x≠c := neKey (by rw [F.xk,ck]; decide)
    have d' : F.x≠d := neKey (by rw [F.xk,dk]; decide)
    simp [R,c',d',vx]
  have yD : F.y∉R := by
    have c' : F.y≠c := neKey (by rw [F.yk,ck]; decide)
    have d' : F.y≠d := neKey (by rw [F.yk,dk]; decide)
    simp [R,c',d',vy]
  have wDist := F.odd_dark_dist hc ab wm no
  have highW : ∀ u (um : u∈W),4≤(G.induce (↑W:Set V)).degree (⟨u,um⟩ : ↑(↑W:Set V)) := by
    intro u um
    rcases mem_insert.mp um with rfl|um'
    · have fact := local_degree_add_outside (G:=G) um {F.v} (by
        intro z wz
        have no' {t : V} (one : G.Adj a t) : ¬G.Adj t u := adj_forbidden_by_dist hc
          (show G.dist a t+1<G.dist a u by rw [dist_eq_one_iff_adj.mpr one,wDist.1]; decide)
        have no'' {t : V} (one : G.Adj b t) : ¬G.Adj t u := adj_forbidden_by_dist hc
          (show G.dist b t+1<G.dist b u by rw [dist_eq_one_iff_adj.mpr one,wDist.2]; decide)
        rcases shore_closed D _ wd _ wz with rfl|rfl|zd
        · have h := dist_eq_one_iff_adj.mpr wz.symm
          omega
        · have h := dist_eq_one_iff_adj.mpr wz.symm
          omega
        rcases F.exhaust zd with m|m|rfl|rfl|rfl|m
        · exact .inl (mem_insert_of_mem (mem_union_left _ m))
        · exact .inl (mem_insert_of_mem (mem_union_right _ m))
        · exact .inr (mem_singleton_self _)
        · exact (no' F.ax wz.symm).elim
        · exact (no'' F.by' wz.symm).elim
        rcases fifth z m with rfl|rfl|rfl
        · exact (no' ac wz.symm).elim
        · exact (no' ad wz.symm).elim
        · exact (G.loopless _ wz).elim)
      rw [card_singleton] at fact
      have hi := F.high _ wd
      omega
    · have sub : darkCore D⊆W := subset_insert _ _
      have fifth' : classSet D 5\commonFive D⊆W := by
        intro z zm
        obtain ⟨zm,nz⟩ := mem_sdiff.mp zm
        rcases fifth z zm with rfl|rfl|rfl
        · exact (nz cm).elim
        · exact (nz dm).elim
        · exact mem_insert_self _ _
      exact dark_core_one_outside_degree F hc ab sub fifth' um' (fun uv=>(miss _ um' uv.symm).elim)
  have size : W.card=7 := by rw [card_insert_of_not_mem wOut,darkCore_card F]
  obtain ⟨u,ua⟩ := card_pos.mp (show 0<(classSet D 0).card by rw [F.threeA]; decide)
  obtain ⟨t,tb⟩ := card_pos.mp (show 0<(classSet D 1).card by rw [F.threeB]; decide)
  have distinct : u≠t := by
    apply neKey
    rw [(mem_filter.mp ua).2,(mem_filter.mp tb).2]
    decide
  have mid := terminal_route_on_seven W size highW
    (mem_insert_of_mem (mem_union_left _ ua)) (mem_insert_of_mem (mem_union_right _ tb)) distinct
  have cdG := balanced_common_two_geometry F hc ab even eq
  have dcG := balanced_common_two_geometry F hc ab even (show commonFive D={d,c} by rw [eq,pair_comm])
  have cvN : c≠F.v := neKey (by rw [ck,F.vk]; decide)
  have tail : RouteOn G R c F.v := RouteOn.three cdG.1 dcG.2.1 cvN
  refine glue_balanced_mid_and_tail F ab CD sc single as' bs' cover subW subR dis
    (by simp [W,xw,xOut]) (by simp [W,yw,yOut]) xD yD ?_ mid ua tb tail ac
  intro z zd
  rcases F.exhaust zd with e|e|rfl|rfl|rfl|e
  · exact .inr (.inr (.inl (mem_insert_of_mem (mem_union_left _ e))))
  · exact .inr (.inr (.inl (mem_insert_of_mem (mem_union_right _ e))))
  · exact .inr (.inr (.inr (by simp [R])))
  · exact .inl rfl
  · exact .inr (.inl rfl)
  rcases fifth z e with rfl|rfl|rfl
  · exact .inr (.inr (.inr (by simp [R])))
  · exact .inr (.inr (.inr (by simp [R])))
  · exact .inr (.inr (.inl (mem_insert_self _ _)))

#print axioms traceable_of_balanced_two_common_and_v_no_polar
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
