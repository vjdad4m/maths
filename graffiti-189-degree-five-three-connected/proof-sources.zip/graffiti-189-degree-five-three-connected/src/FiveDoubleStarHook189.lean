import FiveSingleStarHook189

namespace Graffiti189LongestPath.FiveThreeHook
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.FanRoutable
open scoped BigOperators
set_option linter.unusedSectionVars false
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem five_double_star_three_hook_impossible {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    {A B : Finset V} {x : V} (S : StarCutData G A B x)
    (ao : ∀ z∈A,z∉p.support) (F : HookFamily p A 3)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (minDegree : ∀ v : V,3≤G.degree v) (b3 : B.card=3)
    (ord : Fintype.card V≤A.card+16) : False := by
  classical
  have upper := star_path_order_bound hp ao S.dis
  by_cases fork : StarFork G A x
  · have low := three_hook_star_score_lower hp ao F
      (fun i j k ij ik jk=>S.star.fork_scores fork
        (F.firstIn i) (F.firstIn j) (F.firstIn k)
        (hook_roots_distinct F ij) (hook_roots_distinct F ik) (hook_roots_distinct F jk))
    omega
  obtain ⟨u,ua,v,va,ux,vx,uv,uh,vh⟩ := choose_two_high_wings S.star degree
  have impossible_iso {t : V} (ta : t∈A) (ti : ¬WingNeighbor G A x t)
      (hi : 5≤G.degree t) : False := by
    have cap := (S.high_isolate_universal ta ti hi).1
    omega
  have l : StarLink G A x := by
    have some : WingNeighbor G A x u := Classical.byContradiction (fun h=>impossible_iso ua h uh)
    obtain ⟨w,wa,wx,uw⟩ := some
    exact ⟨u,ua,w,wa,ux,wx,uw⟩
  by_cases nil : ∀ i,(F.path i).length=0
  · obtain ⟨z,za,zx,zu,zv⟩ := S.star.other_excluding_three u v
    have zHit := S.min_three_no_fork_has_boundary_neighbor za zx fork (minDegree z)
    have uFull := S.no_fork_high_three_port_universal ua ux fork b3 uh
    have vFull := S.no_fork_high_three_port_universal va vx fork b3 vh
    obtain ⟨F',outside⟩ := exact_three_nil_hook_reanchor hp S ao F b3 nil ua va za uv
      zu.symm zv.symm ux vx zx uFull vFull zHit
    obtain ⟨r,ra,s,sa,rx,sx,rs⟩ := l
    have low := three_hook_star_score_lower hp ao F' (show
        ∀ i j k : Fin 3,i≠j → i≠k → j≠k →
          ThreeScore G A (F'.root i) (F'.root j) (F'.root k) 14 from by
      intro i j k ij ik jk
      exact ⟨4,3,3,4,by decide,
        S.star.nonroot_start_four (F'.firstIn i) (outside i) ra sa rx sx rs,
        S.star.distinct_nonroot_terminals (F'.firstIn i) (F'.firstIn j)
          (outside i) (outside j) (hook_roots_distinct F' ij),
        S.star.distinct_nonroot_terminals (F'.firstIn j) (F'.firstIn k)
          (outside j) (outside k) (hook_roots_distinct F' jk),
        S.star.nonroot_start_four (F'.firstIn k) (outside k) ra sa rx sx rs⟩)
    omega
  have pos := positive_sum_of_non_nil_hook F nil
  have noIso (r : V) (ra : r∈A) (s : V) (sa : s∈A) (rs : r≠s) (_ : r≠x) (_ : s≠x)
      (ri : ¬WingNeighbor G A x r) (si : ¬WingNeighbor G A x s) : 13≤12 :=
    ((degree r s rs).elim (impossible_iso ra ri) (impossible_iso sa si)).elim
  have low := three_hook_star_score_lower hp ao F
    (fun i j k ij ik jk=>S.star.edge_scores l 13 (by decide) noIso
      (F.firstIn i) (F.firstIn j) (F.firstIn k)
      (hook_roots_distinct F ij) (hook_roots_distinct F ik) (hook_roots_distinct F jk))
  omega

#print axioms five_double_star_three_hook_impossible
end Graffiti189LongestPath.FiveThreeHook
