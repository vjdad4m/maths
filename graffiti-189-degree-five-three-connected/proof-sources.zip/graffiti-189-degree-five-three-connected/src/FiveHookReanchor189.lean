import FiveStarCut189
import Mathlib.Data.Fin.VecNotation
import Mathlib.Tactic.FinCases

namespace Graffiti189LongestPath.FiveThreeHook
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.FanRoutable
set_option linter.unusedSectionVars false
set_option maxHeartbeats 3000000
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem hooked_dest_injective {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    {A : Finset V} (F : HookFamily p A 3) :
    Function.Injective (fun i=>p.getVert (F.idx i)) := by
  intro i j h
  exact F.idx.injective (hp.1.getVert_injOn (Nat.le_of_lt (F.idxLt i)) (Nat.le_of_lt (F.idxLt j)) h)

theorem nil_hook_touches_boundary {a b : V} {p : G.Walk a b} {A B : Finset V}
    {x : V} (S : StarCutData G A B x)
    (ao : ∀ z∈A,z∉p.support) (F : HookFamily p A 3)
    {i : Fin 3} (nil : (F.path i).length=0) : p.getVert (F.idx i)∈B := by
  have end_eq {u v : V} (q : G.Walk u v) (n : q.length=0) : v=u := by
    cases q with
    | nil => rfl
    | cons e q => simp at n
  have e : F.last i=F.root i := end_eq _ nil
  exact S.closed _ (F.firstIn i) _ (fun h=>ao _ h (p.getVert_mem_support _)) (e ▸ F.adjLast i)

theorem not_all_hooks_nil_of_two_visible_ports {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    {A B : Finset V} {x : V} (S : StarCutData G A B x)
    (ao : ∀ z∈A,z∉p.support) (F : HookFamily p A 3)
    (small : (B∩p.support.toFinset).card≤2) :
    ¬∀ i,(F.path i).length=0 := by
  intro hn
  let D : Fin 3 ↪ V := ⟨fun i=>p.getVert (F.idx i),hooked_dest_injective hp F⟩
  have sub : univ.map D⊆B∩p.support.toFinset := by
    intro z zz
    obtain ⟨i,_,rfl⟩ := mem_map.mp zz
    exact mem_inter.mpr ⟨nil_hook_touches_boundary S ao F (hn i),List.mem_toFinset.mpr (p.getVert_mem_support _)⟩
  have n := card_le_card sub
  have c : (univ.map D).card=3 := by simp
  omega

theorem exact_three_nil_hook_reanchor {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    {A B : Finset V} {x g h z : V} (S : StarCutData G A B x)
    (ao : ∀ z∈A,z∉p.support) (F : HookFamily p A 3)
    (b3 : B.card=3) (allNil : ∀ i,(F.path i).length=0)
    (ga : g∈A) (ha : h∈A) (za : z∈A) (gh : g≠h) (gz : g≠z) (hz : h≠z)
    (gx : g≠x) (hx : h≠x) (zx : z≠x)
    (gFull : ∀ v∈B,G.Adj g v) (hFull : ∀ v∈B,G.Adj h v)
    (zHit : ∃ v∈B,G.Adj z v) :
    ∃ F' : HookFamily p A 3,∀ i,F'.root i≠x := by
  classical
  let D : Fin 3 ↪ V := ⟨fun i=>p.getVert (F.idx i),hooked_dest_injective hp F⟩
  have sub : univ.map D⊆B := by
    intro v vv
    obtain ⟨i,_,rfl⟩ := mem_map.mp vv
    exact nil_hook_touches_boundary S ao F (allNil i)
  have eq : univ.map D=B := eq_of_subset_of_card_le sub (by simp [b3])
  obtain ⟨v,vB,zv⟩ := zHit
  obtain ⟨pivot,_,pv⟩ := mem_map.mp (eq.symm ▸ vB)
  change p.getVert (F.idx pivot) = v at pv
  have hit : G.Adj z (p.getVert (F.idx pivot)) := pv.symm ▸ zv
  have make (r : Fin 3 → V) (injective : Function.Injective r)
      (ra : ∀ i,r i∈A) (rx : ∀ i,r i≠x)
      (re : ∀ i,G.Adj (r i) (p.getVert (F.idx i))) :
      ∃ F' : HookFamily p A 3,∀ i,F'.root i≠x := by
    let Q : HookFamily p A 3 :=
      ⟨F.idx,r,r,(fun _=>Walk.nil),(by intro i; simp),F.idxLt,re,ra,
        (by intro i w m _; simpa using m),
        (by
          intro i w m
          have e : w=r i := by simpa using m
          rw [e]
          exact ao _ (ra i)),
        (by intro i j n w hi hj
            have i' : w=r i := by simpa using hi
            have j' : w=r j := by simpa using hj
            exact n (injective (i'.symm.trans j')))⟩
    exact ⟨Q,rx⟩
  have gE (i : Fin 3) : G.Adj g (p.getVert (F.idx i)) :=
    gFull _ (nil_hook_touches_boundary S ao F (allNil i))
  have hE (i : Fin 3) : G.Adj h (p.getVert (F.idx i)) :=
    hFull _ (nil_hook_touches_boundary S ao F (allNil i))
  fin_cases pivot
  · exact make ![z,g,h]
      (by intro i j e; fin_cases i <;> fin_cases j <;> simp_all [Ne.symm gz,Ne.symm hz,Ne.symm gh])
      (by intro i; fin_cases i <;> simp_all)
      (by intro i; fin_cases i <;> simp_all)
      (by intro i; fin_cases i; exact hit; exact gE 1; exact hE 2)
  · exact make ![g,z,h]
      (by intro i j e; fin_cases i <;> fin_cases j <;> simp_all [Ne.symm gz,Ne.symm hz,Ne.symm gh])
      (by intro i; fin_cases i <;> simp_all)
      (by intro i; fin_cases i <;> simp_all)
      (by intro i; fin_cases i; exact gE 0; exact hit; exact hE 2)
  exact make ![g,h,z]
    (by intro i j e; fin_cases i <;> fin_cases j <;> simp_all [Ne.symm gz,Ne.symm hz,Ne.symm gh])
    (by intro i; fin_cases i <;> simp_all)
    (by intro i; fin_cases i <;> simp_all)
    (by intro i; fin_cases i; exact gE 0; exact hE 1; exact hit)

#print axioms exact_three_nil_hook_reanchor
end Graffiti189LongestPath.FiveThreeHook
