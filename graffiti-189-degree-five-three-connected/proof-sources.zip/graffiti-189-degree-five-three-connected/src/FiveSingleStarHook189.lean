import FiveHookReanchor189

namespace Graffiti189LongestPath.FiveThreeHook
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.FanRoutable
open scoped BigOperators
set_option linter.unusedSectionVars false
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem choose_two_high_wings {A : Finset V} {x : V}
    (S : StarRouteData G A x) (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v) :
    ∃ u∈A,∃ v∈A,u≠x ∧ v≠x ∧ u≠v ∧ 5≤G.degree u ∧ 5≤G.degree v := by
  classical
  let J := A.erase x
  let H := J.filter (fun z=>5≤G.degree z)
  have j3 : 3≤J.card := by
    change 3≤(A.erase x).card
    rw [card_erase_of_mem S.inStar]
    have h := S.large
    omega
  have sub : H⊆J := filter_subset _ _
  have high : 1<H.card := by
    apply Classical.byContradiction
    intro few
    obtain ⟨u,um,v,vm,uv⟩ := one_lt_card.mp (show 1<(J\H).card by rw [card_sdiff sub]; omega)
    obtain ⟨uj,uh⟩ := mem_sdiff.mp um
    obtain ⟨vj,vh⟩ := mem_sdiff.mp vm
    exact (degree u v uv).elim (fun h=>uh (mem_filter.mpr ⟨uj,h⟩))
      (fun h=>vh (mem_filter.mpr ⟨vj,h⟩))
  obtain ⟨u,uu,v,vv,uv⟩ := one_lt_card.mp high
  obtain ⟨uj,uh⟩ := mem_filter.mp uu
  obtain ⟨vj,vh⟩ := mem_filter.mp vv
  obtain ⟨ux,ua⟩ := mem_erase.mp uj
  obtain ⟨vx,va⟩ := mem_erase.mp vj
  exact ⟨u,ua,v,va,ux,vx,uv,uh,vh⟩

theorem star_path_order_bound {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    {A B : Finset V} (ao : ∀ z∈A,z∉p.support) (ab : Disjoint A B) :
    A.card+(p.length+1)+(B\p.support.toFinset).card≤Fintype.card V := by
  classical
  have d : Disjoint A p.support.toFinset :=
    disjoint_left.mpr (fun z za zp=>ao z za (List.mem_toFinset.mp zp))
  have d' : Disjoint (A∪p.support.toFinset) (B\p.support.toFinset) := by
    apply disjoint_left.mpr
    intro z z1 z2
    obtain ⟨zb,zp⟩ := mem_sdiff.mp z2
    exact (mem_union.mp z1).elim (fun za=>disjoint_left.mp ab za zb) zp
  have n := card_le_univ ((A∪p.support.toFinset)∪(B\p.support.toFinset))
  rw [card_union_of_disjoint d',card_union_of_disjoint d,
    List.toFinset_card_of_nodup hp.1.support_nodup,length_support] at n
  exact n

theorem three_hook_star_score_lower {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    {A : Finset V} (ao : ∀ z∈A,z∉p.support) (F : HookFamily p A 3) {s : ℕ}
    (route : ∀ i j k : Fin 3,i≠j → i≠k → j≠k →
      ThreeScore G A (F.root i) (F.root j) (F.root k) s) :
    s+3+2*(∑ i : Fin 3,(F.path i).length)≤p.length+1 := by
  classical
  obtain ⟨i,j,k,ij,jk⟩ := hook_indices_in_order F
  have ni : i≠j := fun h=>(Nat.lt_irrefl _) (h ▸ ij)
  have nk : i≠k := fun h=>(Nat.lt_irrefl _) (h ▸ ij.trans jk)
  have nj : j≠k := fun h=>(Nat.lt_irrefl _) (h ▸ jk)
  obtain ⟨l,m,n,r,tot,left,first,second,right⟩ := route i j k ni nk nj
  have lower := ordered_three_hook_room hp ao F ij jk left right first second
  have measure : (∑ t : Fin 3,(F.path t).length) =
      (F.path i).length+(F.path j).length+(F.path k).length := by
    have all : (univ : Finset (Fin 3))={i,j,k} := by
      apply (eq_of_subset_of_card_le (subset_univ ({i,j,k} : Finset (Fin 3))) _).symm
      simp [ni,nk,nj]
    rw [all, sum_insert (show i∉({j,k} : Finset (Fin 3)) by simp [ni,nk]),
      sum_insert (show j∉({k} : Finset (Fin 3)) by simp [nj]),sum_singleton]
    omega
  rw [measure]
  omega

theorem positive_sum_of_non_nil_hook {a b : V} {p : G.Walk a b}
    {A : Finset V} (F : HookFamily p A 3) (no : ¬∀ i,(F.path i).length=0) :
    1≤∑ i : Fin 3,(F.path i).length := by
  classical
  have ex : ∃ i,0<(F.path i).length := by
    apply Classical.byContradiction
    intro none
    exact no (fun i=>Nat.eq_zero_of_not_pos (fun h=>none ⟨i,h⟩))
  obtain ⟨i,ip⟩ := ex
  exact ip.trans_le (Finset.single_le_sum (f:=fun i=>(F.path i).length) (fun _ _=>Nat.zero_le _) (mem_univ i))

theorem five_single_star_three_hook_impossible {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    {A B : Finset V} {x : V} (S : StarCutData G A B x)
    (ao : ∀ z∈A,z∉p.support) (F : HookFamily p A 3)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (ports : ∀ z∈A,(∀ y∈B,G.Adj z y) → (B∩p.support.toFinset).card≤2)
    (ord : Fintype.card V≤A.card+15) : False := by
  classical
  have upper := star_path_order_bound hp ao S.dis
  have short (b4 : B.card=4) (vis : (B∩p.support.toFinset).card≤2) :
      p.length+1≤13 := by
    have sub : B∩p.support.toFinset⊆B := inter_subset_left
    have cnt := card_sdiff_add_card_eq_card sub
    have e : B\(B∩p.support.toFinset)=B\p.support.toFinset := by ext z; simp [and_assoc]
    rw [e] at cnt
    omega
  by_cases link : StarLink G A x
  · by_cases isolatedPair : ∃ u∈A,∃ v∈A,u≠v ∧ u≠x ∧ v≠x ∧
        ¬WingNeighbor G A x u ∧ ¬WingNeighbor G A x v
    · obtain ⟨u,ua,v,va,uv,ux,vx,ui,vi⟩ := isolatedPair
      have bounds : B.card=4 ∧ (B∩p.support.toFinset).card≤2 := by
        rcases degree u v uv with h|h
        · obtain ⟨b,full⟩ := S.high_isolate_universal ua ui h
          exact ⟨b,ports u ua full⟩
        obtain ⟨b,full⟩ := S.high_isolate_universal va vi h
        exact ⟨b,ports v va full⟩
      have low := three_hook_star_score_lower hp ao F
        (fun i j k ij ik jk=>S.star.edge_scores link 12 (by decide) (fun _ _ _ _ _ _ _ _ _=>by decide)
          (F.firstIn i) (F.firstIn j) (F.firstIn k)
          (hook_roots_distinct F ij) (hook_roots_distinct F ik) (hook_roots_distinct F jk))
      have h := short bounds.1 bounds.2
      omega
    have low := three_hook_star_score_lower hp ao F
      (fun i j k ij ik jk=>S.star.edge_scores link 13 (by decide)
        (fun u ua v va uv ux vx ui vi=>(isolatedPair ⟨u,ua,v,va,uv,ux,vx,ui,vi⟩).elim)
        (F.firstIn i) (F.firstIn j) (F.firstIn k)
        (hook_roots_distinct F ij) (hook_roots_distinct F ik) (hook_roots_distinct F jk))
    omega
  obtain ⟨u,ua,v,va,ux,vx,uv,uh,vh⟩ := choose_two_high_wings S.star degree
  have ui : ¬WingNeighbor G A x u := by
    rintro ⟨z,za,zx,uz⟩
    exact link ⟨u,ua,z,za,ux,zx,uz⟩
  obtain ⟨b4,full⟩ := S.high_isolate_universal ua ui uh
  have vis := ports u ua full
  have pos := positive_sum_of_non_nil_hook F (not_all_hooks_nil_of_two_visible_ports hp S ao F vis)
  have low := three_hook_star_score_lower hp ao F
    (fun i j k ij ik jk=>S.star.edgeless_baseline_scores
      (F.firstIn i) (F.firstIn j) (F.firstIn k)
      (hook_roots_distinct F ij) (hook_roots_distinct F ik) (hook_roots_distinct F jk))
  have h := short b4 vis
  omega

#print axioms five_single_star_three_hook_impossible
end Graffiti189LongestPath.FiveThreeHook
