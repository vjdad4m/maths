import FiveStarScores189
import FanPorts189

namespace Graffiti189LongestPath.FiveThreeHook
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.FanRoutable
set_option linter.unusedSectionVars false
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

structure StarCutData (G : SimpleGraph V) (A B : Finset V) (x : V) : Prop where
  star : StarRouteData G A x
  dis : Disjoint A B
  closed : ∀ u∈A,∀ v∉A,G.Adj u v → v∈B
  small : B.card≤4

theorem StarCutData.high_isolate_universal {A B : Finset V} {x v : V}
    (S : StarCutData G A B x) (va : v∈A)
    (iso : ¬WingNeighbor G A x v) (hi : 5≤G.degree v) :
    B.card=4 ∧ ∀ z∈B,G.Adj v z := by
  classical
  have sub : G.neighborFinset v⊆insert x B := by
    intro z zz
    have vz := (mem_neighborFinset G v z).mp zz
    by_cases zx : z=x
    · exact mem_insert.mpr (.inl zx)
    have za : z∉A := fun za=>iso ⟨z,za,zx,vz⟩
    exact mem_insert_of_mem (S.closed v va z za vz)
  have n := (card_le_card sub).trans (card_insert_le x B)
  rw [card_neighborFinset_eq_degree] at n
  have cap := S.small
  have b4 : B.card=4 := by omega
  have eq := eq_of_subset_of_card_le sub (by
    rw [card_neighborFinset_eq_degree]
    have b := card_insert_le x B
    omega)
  exact ⟨b4,fun z zb=>(mem_neighborFinset G v z).mp (eq.symm ▸ mem_insert_of_mem zb)⟩

theorem no_fork_wing_neighbors_le_one {A : Finset V} {x v : V}
    (va : v∈A) (vx : v≠x) (no : ¬StarFork G A x) :
    ((A.erase x).filter (G.Adj v)).card≤1 := by
  classical
  apply Classical.byContradiction
  intro h
  obtain ⟨u,uu,w,ww,uw⟩ := one_lt_card.mp (show 1<((A.erase x).filter (G.Adj v)).card by omega)
  obtain ⟨ue,vu⟩ := mem_filter.mp uu
  obtain ⟨we,vw⟩ := mem_filter.mp ww
  obtain ⟨ux,ua⟩ := mem_erase.mp ue
  obtain ⟨wx,wa⟩ := mem_erase.mp we
  exact no ⟨u,ua,v,va,w,wa,ux,vx,wx,vu.symm,vw,uw⟩

theorem StarCutData.no_fork_neighbor_bound {A B : Finset V} {x v : V}
    (S : StarCutData G A B x) (va : v∈A) :
    G.neighborFinset v⊆insert x (B∪((A.erase x).filter (G.Adj v))) := by
  intro z hz
  have vz := (mem_neighborFinset G v z).mp hz
  by_cases zx : z=x
  · exact mem_insert.mpr (.inl zx)
  apply mem_insert_of_mem
  by_cases za : z∈A
  · exact mem_union_right _ (mem_filter.mpr ⟨mem_erase.mpr ⟨zx,za⟩,vz⟩)
  exact mem_union_left _ (S.closed v va z za vz)

theorem StarCutData.no_fork_high_three_port_universal {A B : Finset V} {x v : V}
    (S : StarCutData G A B x) (va : v∈A) (vx : v≠x)
    (no : ¬StarFork G A x) (b3 : B.card=3) (hi : 5≤G.degree v) :
    ∀ z∈B,G.Adj v z := by
  classical
  have sub := S.no_fork_neighbor_bound va
  have m := card_insert_le x (B∪((A.erase x).filter (G.Adj v)))
  have n := card_union_le B ((A.erase x).filter (G.Adj v))
  have q := no_fork_wing_neighbors_le_one va vx no
  have eq := eq_of_subset_of_card_le sub (by rw [card_neighborFinset_eq_degree]; omega)
  exact fun z zb=>(mem_neighborFinset G v z).mp (eq.symm ▸ mem_insert_of_mem (mem_union_left _ zb))

theorem StarCutData.min_three_no_fork_has_boundary_neighbor {A B : Finset V} {x v : V}
    (S : StarCutData G A B x) (va : v∈A) (vx : v≠x)
    (no : ¬StarFork G A x) (d : 3≤G.degree v) : ∃ z∈B,G.Adj v z := by
  classical
  apply Classical.byContradiction
  intro hh
  have sub : G.neighborFinset v⊆insert x ((A.erase x).filter (G.Adj v)) := by
    intro z zz
    rcases mem_insert.mp (S.no_fork_neighbor_bound va zz) with e|h
    · exact mem_insert.mpr (.inl e)
    exact (mem_union.mp h).elim
      (fun h=>(hh ⟨z,h,(mem_neighborFinset G v z).mp zz⟩).elim)
      (fun h=>mem_insert_of_mem h)
  have n := (card_le_card sub).trans (card_insert_le x _)
  rw [card_neighborFinset_eq_degree] at n
  have m := no_fork_wing_neighbors_le_one va vx no
  omega

theorem min_three_degree_of_small_deletion (conn : ∀ R : Finset V,R.card<3 →
      (G.induce ((↑R : Set V)ᶜ)).Connected) (big : 4≤Fintype.card V) (v : V) :
    3≤G.degree v := by
  classical
  apply Classical.byContradiction
  intro small
  let R := G.neighborFinset v
  have vR : v∉R := fun m=>G.loopless v ((mem_neighborFinset G v v).mp m)
  have rc : R.card<3 := by change (G.neighborFinset v).card<3; rw [card_neighborFinset_eq_degree]; omega
  have other : ∃ w : V,w≠v ∧ w∉R := by
    apply Classical.byContradiction
    intro none
    have inc : (univ : Finset V)⊆insert v R := by
      intro w _
      by_cases h : w=v
      · exact mem_insert.mpr (.inl h)
      exact mem_insert_of_mem (Classical.byContradiction (fun nr=>none ⟨w,h,nr⟩))
    have n := (card_le_card inc).trans (card_insert_le v R)
    rw [card_univ] at n
    omega
  obtain ⟨w,ne,wR⟩ := other
  let U : Set V := (↑R : Set V)ᶜ
  let x : U := ⟨v,vR⟩
  let y : U := ⟨w,wR⟩
  obtain ⟨p⟩ := (conn R rc).preconnected x y
  have first {a b : U} (q : (G.induce U).Walk a b) (ab : a ≠ b) :
      ∃ z : U, G.Adj a.val z.val := by
    cases q with
    | nil => exact (ab rfl).elim
    | cons ed q => exact ⟨_,ed⟩
  have xy : x ≠ y := fun h => ne (congrArg Subtype.val h).symm
  obtain ⟨z,e⟩ := first p xy
  exact z.property ((mem_neighborFinset G v z.val).mpr e)

#print axioms StarCutData.high_isolate_universal
#print axioms min_three_degree_of_small_deletion
end Graffiti189LongestPath.FiveThreeHook
