import FiveStarRouting189

namespace Graffiti189LongestPath.FiveThreeHook
open SimpleGraph SimpleGraph.Walk Finset Graffiti189LongestPath.CrossSaturation
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

theorem five_inside {A : Finset V} {u v w z t : V}
    (ua : u∈A) (va : v∈A) (wa : w∈A) (za : z∈A) (ta : t∈A)
    (uv : G.Adj u v) (vw : G.Adj v w) (wz : G.Adj w z) (zt : G.Adj z t)
    (uw : u≠w) (uz : u≠z) (ut : u≠t) (vz : v≠z) (vt : v≠t) (wt : w≠t) :
    LongInside G A u t 5 := by
  have q := (ShortRouteOn.three uv vw uw).suffix wz (by simp [uz.symm,vz.symm,wz.ne.symm])
  have p := ShortRouteOn.suffix q zt (by simp [ut.symm,vt.symm,wt.symm,zt.ne.symm])
  obtain ⟨p,pp,ps⟩ := p
  have card := List.toFinset_card_of_nodup pp.support_nodup
  rw [length_support] at card
  have sub : (insert t (insert z ({u,v,w} : Finset V)))⊆p.support.toFinset :=
    fun i m=>List.mem_toFinset.mpr ((ps i).mpr m)
  have n := card_le_card sub
  have c : (insert t (insert z ({u,v,w} : Finset V))).card=5 := by
    simp [ut.symm,vt.symm,wt.symm,zt.ne.symm,uz.symm,vz.symm,wz.ne.symm,uv.ne,vw.ne,uw]
  refine ⟨p,pp,?_,by omega⟩
  intro i hi
  have h := (ps i).mp hi
  simp only [mem_insert,mem_singleton] at h
  rcases h with h|h|h|h|h
  · exact h.symm ▸ ta
  · exact h.symm ▸ za
  · exact h.symm ▸ ua
  · exact h.symm ▸ va
  exact h.symm ▸ wa

def StarLink (G : SimpleGraph V) (A : Finset V) (x : V) : Prop :=
  ∃ y∈A,∃ z∈A,y≠x ∧ z≠x ∧ G.Adj y z

def StarFork (G : SimpleGraph V) (A : Finset V) (x : V) : Prop :=
  ∃ y∈A,∃ z∈A,∃ w∈A,y≠x ∧ z≠x ∧ w≠x ∧ G.Adj y z ∧ G.Adj z w ∧ y≠w

theorem StarFork.link {A : Finset V} {x : V} (h : StarFork G A x) : StarLink G A x := by
  obtain ⟨y,ya,z,za,w,wa,yx,zx,wx,yz,zw,yw⟩ := h
  exact ⟨y,ya,z,za,yx,zx,yz⟩

theorem StarRouteData.isolate_start_five {A : Finset V} {x u : V}
    (S : StarRouteData G A x) (ua : u∈A) (ux : u≠x)
    (iso : ¬WingNeighbor G A x u) (f : StarFork G A x) : LongFrom G A u 5 := by
  obtain ⟨y,ya,z,za,w,wa,yx,zx,wx,yz,zw,yw⟩ := f
  have uy : u≠y := fun e=>iso ⟨z,za,zx,(show G.Adj u z from e.symm ▸ yz)⟩
  have uz : u≠z := fun e=>iso ⟨y,ya,yx,(show G.Adj u y from e.symm ▸ yz.symm)⟩
  have uw : u≠w := fun e=>iso ⟨z,za,zx,(show G.Adj u z from e.symm ▸ zw.symm)⟩
  exact ⟨w,five_inside ua S.inStar ya za wa (S.allAdj u ua ux).symm
    (S.allAdj y ya yx) yz zw uy uz uw zx.symm wx.symm yw⟩

#print axioms StarRouteData.isolate_start_five
end Graffiti189LongestPath.FiveThreeHook
