import FiveThreeHookRooms189

namespace Graffiti189LongestPath.FiveThreeHook
open SimpleGraph Finset
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

def WingNeighbor (G : SimpleGraph V) (A : Finset V) (x v : V) : Prop :=
  ∃ w∈A,w≠x ∧ G.Adj v w

structure StarRouteData (G : SimpleGraph V) (A : Finset V) (x : V) : Prop where
  inStar : x∈A
  allAdj : ∀ v∈A,v≠x → G.Adj x v
  large : 4≤A.card

theorem StarRouteData.other_excluding_three {A : Finset V} {x : V}
    (S : StarRouteData G A x) (u v : V) :
    ∃ w∈A,w≠x ∧ w≠u ∧ w≠v := by
  classical
  let C := ({x,u,v} : Finset V)
  have n : C.card≤3 := by
    have m := card_insert_le x ({u,v} : Finset V)
    have p := card_insert_le u ({v} : Finset V)
    rw [card_singleton] at p
    change C.card≤_ at m
    omega
  have non : (A\C).Nonempty := by
    apply card_pos.mp
    have eq := card_sdiff_add_card_eq_card (inter_subset_left : A∩C⊆A)
    have e : A\(A∩C)=A\C := by ext w; simp [and_assoc]
    rw [e] at eq
    have m := card_le_card (inter_subset_right : A∩C⊆C)
    have h := S.large
    omega
  obtain ⟨w,ww⟩ := non
  obtain ⟨wa,wc⟩ := mem_sdiff.mp ww
  exact ⟨w,wa,fun e=>wc (mem_insert.mpr (.inl e)),fun e=>wc (mem_insert.mpr (.inr (mem_insert.mpr (.inl e)))),
    fun e=>wc (mem_insert_of_mem (mem_insert_of_mem (mem_singleton.mpr e)))⟩

theorem StarRouteData.nonroot_start_four {A : Finset V} {x v : V}
    (S : StarRouteData G A x) (va : v∈A) (vx : v≠x)
    {y z : V} (ya : y∈A) (za : z∈A) (yx : y≠x) (zx : z≠x) (yz : G.Adj y z) :
    LongFrom G A v 4 := by
  by_cases e : v=y
  · subst y
    obtain ⟨w,wa,wx,wv,wz⟩ := S.other_excluding_three v z
    exact ⟨w,four_inside va za S.inStar wa yz (S.allAdj z za zx).symm (S.allAdj w wa wx)
      vx wv.symm wz.symm⟩
  by_cases ee : v=z
  · subst z
    obtain ⟨w,wa,wx,wv,wy⟩ := S.other_excluding_three v y
    exact ⟨w,four_inside va ya S.inStar wa yz.symm (S.allAdj y ya yx).symm (S.allAdj w wa wx)
      vx wv.symm wy.symm⟩
  exact ⟨z,four_inside va S.inStar ya za (S.allAdj v va vx).symm (S.allAdj y ya yx) yz e ee zx.symm⟩

theorem StarRouteData.root_start_three {A : Finset V} {x y z : V}
    (S : StarRouteData G A x) (ya : y∈A) (za : z∈A) (yx : y≠x) (zx : z≠x)
    (yz : G.Adj y z) : LongFrom G A x 3 :=
  ⟨z,three_inside S.inStar ya za (S.allAdj y ya yx) yz zx.symm⟩

theorem StarRouteData.root_start_four {A : Finset V} {x u v w : V}
    (S : StarRouteData G A x) (ua : u∈A) (va : v∈A) (wa : w∈A)
    (ux : u≠x) (vx : v≠x) (wx : w≠x)
    (uv : G.Adj u v) (vw : G.Adj v w) (uw : u≠w) : LongFrom G A x 4 :=
  ⟨w,four_inside S.inStar ua va wa (S.allAdj u ua ux) uv vw vx.symm wx.symm uw⟩

theorem StarRouteData.distinct_nonroot_terminals {A : Finset V} {x u v : V}
    (S : StarRouteData G A x) (ua : u∈A) (va : v∈A) (ux : u≠x) (vx : v≠x) (uv : u≠v) :
    LongInside G A u v 3 :=
  three_inside ua S.inStar va (S.allAdj u ua ux).symm (S.allAdj v va vx) uv

theorem StarRouteData.root_to_wing_three {A : Finset V} {x v : V}
    (S : StarRouteData G A x) (va : v∈A) (vx : v≠x) (w : WingNeighbor G A x v) :
    LongInside G A x v 3 := by
  obtain ⟨z,za,zx,vz⟩ := w
  exact three_inside S.inStar za va (S.allAdj z za zx) vz.symm vx.symm

theorem StarRouteData.root_to_wing_two {A : Finset V} {x v : V}
    (S : StarRouteData G A x) (va : v∈A) (vx : v≠x) : LongInside G A x v 2 :=
  two_inside S.inStar va (S.allAdj v va vx)

theorem StarRouteData.isolate_to_wing_four {A : Finset V} {x u v : V}
    (S : StarRouteData G A x) (ua : u∈A) (va : v∈A) (ux : u≠x) (vx : v≠x) (uv : u≠v)
    (iso : ¬WingNeighbor G A x u) (w : WingNeighbor G A x v) :
    LongInside G A u v 4 := by
  obtain ⟨z,za,zx,vz⟩ := w
  have uz : u≠z := fun e=>iso ⟨v,va,vx,(show G.Adj u v from e.symm ▸ vz.symm)⟩
  exact four_inside ua S.inStar za va (S.allAdj u ua ux).symm (S.allAdj z za zx) vz.symm
    uz uv vx.symm

theorem StarRouteData.nonroot_start_three {A : Finset V} {x v : V}
    (S : StarRouteData G A x) (va : v∈A) (vx : v≠x) : LongFrom G A v 3 := by
  obtain ⟨w,wa,wx,wv,_⟩ := S.other_excluding_three v x
  exact ⟨w,S.distinct_nonroot_terminals va wa vx wx wv.symm⟩

#print axioms StarRouteData.nonroot_start_four
#print axioms StarRouteData.isolate_to_wing_four
end Graffiti189LongestPath.FiveThreeHook
