import FiveStarFork189

namespace Graffiti189LongestPath.FiveThreeHook
open SimpleGraph Finset
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

def ThreeScore (G : SimpleGraph V) (A : Finset V) (u v w : V) (s : ℕ) : Prop :=
  ∃ l m n r : ℕ,s≤l+m+n+r ∧ LongFrom G A u l ∧
    LongInside G A u v m ∧ LongInside G A v w n ∧ LongFrom G A w r

theorem ThreeScore.reverse {A : Finset V} {u v w : V} {s : ℕ}
    (h : ThreeScore G A u v w s) : ThreeScore G A w v u s := by
  obtain ⟨l,m,n,r,h,p,q,t,k⟩ := h
  exact ⟨r,n,m,l,by omega,k,t.reverse,q.reverse,p⟩

theorem StarRouteData.edge_scores {A : Finset V} {x : V}
    (S : StarRouteData G A x) (link : StarLink G A x) (s : ℕ) (small : s≤13)
    (isos : ∀ u∈A,∀ v∈A,u≠v → u≠x → v≠x →
      ¬WingNeighbor G A x u → ¬WingNeighbor G A x v → s≤12)
    {u v w : V} (ua : u∈A) (va : v∈A) (wa : w∈A)
    (uv : u≠v) (uw : u≠w) (vw : v≠w) : ThreeScore G A u v w s := by
  classical
  obtain ⟨b,ba,c,ca,bx,cx,bc⟩ := link
  have four (y : V) (ya : y∈A) (yx : y≠x) : LongFrom G A y 4 :=
    S.nonroot_start_four ya yx ba ca bx cx bc
  have root := S.root_start_three ba ca bx cx bc
  have extreme (v w : V) (va : v∈A) (wa : w∈A)
      (vx : v≠x) (wx : w≠x) (vw : v≠w) : ThreeScore G A x v w s := by
    by_cases vi : WingNeighbor G A x v
    · exact ⟨3,3,3,4,by omega,root,S.root_to_wing_three va vx vi,
        S.distinct_nonroot_terminals va wa vx wx vw,four w wa wx⟩
    by_cases wi : WingNeighbor G A x w
    · exact ⟨3,2,4,4,by omega,root,S.root_to_wing_two va vx,
        S.isolate_to_wing_four va wa vx wx vw vi wi,four w wa wx⟩
    exact ⟨3,2,3,4,isos v va w wa vw vx wx vi wi,root,S.root_to_wing_two va vx,
      S.distinct_nonroot_terminals va wa vx wx vw,four w wa wx⟩
  by_cases ux : u=x
  · subst u
    exact extreme v w va wa (Ne.symm uv) (Ne.symm uw) vw
  by_cases wx : w=x
  · subst w
    exact (extreme v u va ua vw ux uv.symm).reverse
  by_cases vx : v=x
  · subst v
    by_cases ui : WingNeighbor G A x u
    · by_cases wi : WingNeighbor G A x w
      · exact ⟨4,3,3,4,by omega,four u ua ux,(S.root_to_wing_three ua ux ui).reverse,
          S.root_to_wing_three wa wx wi,four w wa wx⟩
      exact ⟨4,3,2,4,by omega,four u ua ux,(S.root_to_wing_three ua ux ui).reverse,
        S.root_to_wing_two wa wx,four w wa wx⟩
    by_cases wi : WingNeighbor G A x w
    · exact ⟨4,2,3,4,by omega,four u ua ux,(S.root_to_wing_two ua ux).reverse,
        S.root_to_wing_three wa wx wi,four w wa wx⟩
    exact ⟨4,2,2,4,isos u ua w wa uw ux wx ui wi,four u ua ux,
      (S.root_to_wing_two ua ux).reverse,S.root_to_wing_two wa wx,four w wa wx⟩
  exact ⟨4,3,3,4,by omega,four u ua ux,S.distinct_nonroot_terminals ua va ux vx uv,
    S.distinct_nonroot_terminals va wa vx wx vw,four w wa wx⟩

theorem StarRouteData.fork_scores {A : Finset V} {x : V}
    (S : StarRouteData G A x) (fork : StarFork G A x)
    {u v w : V} (ua : u∈A) (va : v∈A) (wa : w∈A)
    (uv : u≠v) (uw : u≠w) (vw : v≠w) : ThreeScore G A u v w 14 := by
  classical
  obtain ⟨b,ba,c,ca,d,da,bx,cx,dx,bc,cd,bd⟩ := fork
  have f : StarFork G A x := ⟨b,ba,c,ca,d,da,bx,cx,dx,bc,cd,bd⟩
  have four (y : V) (ya : y∈A) (yx : y≠x) : LongFrom G A y 4 :=
    S.nonroot_start_four ya yx ba ca bx cx bc
  have root := S.root_start_four ba ca da bx cx dx bc cd bd
  have extreme (v w : V) (va : v∈A) (wa : w∈A)
      (vx : v≠x) (wx : w≠x) (vw : v≠w) : ThreeScore G A x v w 14 := by
    by_cases vi : WingNeighbor G A x v
    · exact ⟨4,3,3,4,by decide,root,S.root_to_wing_three va vx vi,
        S.distinct_nonroot_terminals va wa vx wx vw,four w wa wx⟩
    by_cases wi : WingNeighbor G A x w
    · exact ⟨4,2,4,4,by decide,root,S.root_to_wing_two va vx,
        S.isolate_to_wing_four va wa vx wx vw vi wi,four w wa wx⟩
    exact ⟨4,2,3,5,by decide,root,S.root_to_wing_two va vx,
      S.distinct_nonroot_terminals va wa vx wx vw,S.isolate_start_five wa wx wi f⟩
  by_cases ux : u=x
  · subst u
    exact extreme v w va wa (Ne.symm uv) (Ne.symm uw) vw
  by_cases wx : w=x
  · subst w
    exact (extreme v u va ua vw ux uv.symm).reverse
  by_cases vx : v=x
  · subst v
    by_cases ui : WingNeighbor G A x u
    · by_cases wi : WingNeighbor G A x w
      · exact ⟨4,3,3,4,by decide,four u ua ux,(S.root_to_wing_three ua ux ui).reverse,
          S.root_to_wing_three wa wx wi,four w wa wx⟩
      exact ⟨4,3,2,5,by decide,four u ua ux,(S.root_to_wing_three ua ux ui).reverse,
        S.root_to_wing_two wa wx,S.isolate_start_five wa wx wi f⟩
    by_cases wi : WingNeighbor G A x w
    · exact ⟨5,2,3,4,by decide,S.isolate_start_five ua ux ui f,(S.root_to_wing_two ua ux).reverse,
        S.root_to_wing_three wa wx wi,four w wa wx⟩
    exact ⟨5,2,2,5,by decide,S.isolate_start_five ua ux ui f,
      (S.root_to_wing_two ua ux).reverse,S.root_to_wing_two wa wx,S.isolate_start_five wa wx wi f⟩
  exact ⟨4,3,3,4,by decide,four u ua ux,S.distinct_nonroot_terminals ua va ux vx uv,
    S.distinct_nonroot_terminals va wa vx wx vw,four w wa wx⟩

theorem StarRouteData.edgeless_baseline_scores {A : Finset V} {x : V}
    (S : StarRouteData G A x)
    {u v w : V} (ua : u∈A) (va : v∈A) (wa : w∈A)
    (uv : u≠v) (uw : u≠w) (vw : v≠w) : ThreeScore G A u v w 10 := by
  classical
  obtain ⟨y,ya,yx,_,_⟩ := S.other_excluding_three x x
  have root : LongFrom G A x 2 := ⟨y,S.root_to_wing_two ya yx⟩
  have extreme (v w : V) (va : v∈A) (wa : w∈A)
      (vx : v≠x) (wx : w≠x) (vw : v≠w) : ThreeScore G A x v w 10 :=
    ⟨2,2,3,3,by decide,root,S.root_to_wing_two va vx,
      S.distinct_nonroot_terminals va wa vx wx vw,S.nonroot_start_three wa wx⟩
  by_cases ux : u=x
  · subst u
    exact extreme v w va wa (Ne.symm uv) (Ne.symm uw) vw
  by_cases wx : w=x
  · subst w
    exact (extreme v u va ua vw ux uv.symm).reverse
  by_cases vx : v=x
  · subst v
    exact ⟨3,2,2,3,by decide,S.nonroot_start_three ua ux,(S.root_to_wing_two ua ux).reverse,
      S.root_to_wing_two wa wx,S.nonroot_start_three wa wx⟩
  exact ⟨3,3,3,3,by decide,S.nonroot_start_three ua ux,S.distinct_nonroot_terminals ua va ux vx uv,
    S.distinct_nonroot_terminals va wa vx wx vw,S.nonroot_start_three wa wx⟩

#print axioms StarRouteData.edge_scores
#print axioms StarRouteData.fork_scores
#print axioms StarRouteData.edgeless_baseline_scores
end Graffiti189LongestPath.FiveThreeHook
