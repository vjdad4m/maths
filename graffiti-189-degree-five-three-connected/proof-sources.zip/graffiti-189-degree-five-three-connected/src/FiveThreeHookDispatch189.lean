import FiveDoubleStarHook189
import HighDichotomy189
import SingleStar189
import MengerRoutable189
import ActiveStarHeight189

namespace Graffiti189LongestPath.FiveThreeHook
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack
open Graffiti189LongestPath.FanRoutable Graffiti189LongestPath.PinRun
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
open private Graffiti189LongestPath.OneSlack.pin_of_neighbor_mem Graffiti189LongestPath.OneSlack.card_pinVertices from OneSlack189
set_option linter.unusedSectionVars false
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem degree_five_even_two_four_cap (x : V) (cap : (EvenFrom G x).card≤6) :
    (DistanceTwo G x).card+(Shell G x 4).card≤5 := by
  classical
  let D := DistanceTwo G x
  let F := Shell G x 4
  have dis : Disjoint D F := by
    apply disjoint_left.mpr
    intro z zd zf
    have e : G.dist x z=2 := by simpa [D,DistanceTwo] using zd
    have f : G.dist x z=4 := by simpa [F,Shell] using zf
    omega
  have off : x∉D∪F := by simp [D,F,DistanceTwo,Shell,dist_self]
  have sub : insert x (D∪F)⊆EvenFrom G x := by
    intro z hz
    apply mem_filter.mpr
    refine ⟨mem_univ _,?_⟩
    rcases mem_insert.mp hz with rfl|h
    · rw [SimpleGraph.dist_self]; decide
    rcases mem_union.mp h with h|h
    · have e : G.dist x z=2 := by simpa [D,DistanceTwo] using h
      rw [e]
      decide
    have e : G.dist x z=4 := by simpa [F,Shell] using h
    rw [e]
    decide
  have n := (card_le_card sub).trans cap
  rw [card_insert_of_not_mem off,card_union_of_disjoint dis] at n
  change D.card+F.card≤5
  omega

theorem order_of_degree_five_radius_anchor (hc : G.Connected) (x : V)
    (cap : (EvenFrom G x).card≤6) (h3 : (Shell G x 3).card≤9)
    (rad : ∀ z,G.dist x z≤4) : Fintype.card V≤1+G.degree x+14 := by
  classical
  let A := G.neighborFinset x
  let B := DistanceTwo G x
  let C := Shell G x 3
  let D := Shell G x 4
  have sub : (univ : Finset V)⊆insert x (A∪B∪C∪D) := by
    intro z _
    by_cases e : z=x
    · exact mem_insert.mpr (.inl e)
    have no : G.dist x z≠0 := fun q=>e ((hc.dist_eq_zero_iff.mp q).symm)
    have r := rad z
    have ds : G.dist x z=1 ∨ G.dist x z=2 ∨ G.dist x z=3 ∨ G.dist x z=4 := by omega
    apply mem_insert_of_mem
    rcases ds with d|d|d|d
    · exact mem_union_left _ (mem_union_left _ (mem_union_left _
        ((mem_neighborFinset G x z).mpr (dist_eq_one_iff_adj.mp d))))
    · exact mem_union_left _ (mem_union_left _ (mem_union_right _ (by simp [B,DistanceTwo,d])))
    · exact mem_union_left _ (mem_union_right _ (by simp [C,Shell,d]))
    exact mem_union_right _ (by simp [D,Shell,d])
  have n := card_le_card sub
  rw [card_univ] at n
  have m := card_insert_le x (A∪B∪C∪D)
  have w := card_union_le (A∪B∪C) D
  have y := card_union_le (A∪B) C
  have z := card_union_le A B
  have e := degree_five_even_two_four_cap x cap
  have count : A.card=G.degree x := card_neighborFinset_eq_degree G x
  change C.card≤9 at h3
  change B.card+D.card≤5 at e
  omega

theorem traceable_degree_five_three_connected_of_shell_three
    (hc : G.Connected) (cap : ∀ x,(EvenFrom G x).card≤6)
    (conn : ∀ R : Finset V,R.card<3 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (d3 : ∀ x,(Shell G x 3).card≤9) :
    ∃ a b,∃ p : G.Walk a b,p.IsPath ∧ ∀ z,z∈p.support := by
  classical
  apply Classical.byContradiction
  intro fail
  obtain ⟨a,b,p,x,hp,hx,hi,cases'⟩ :=
    HighDichotomy.normalized_attachment_dichotomy hc 3 (by decide) cap conn degree fail
  have lp := hp.1.1
  let A := OmittedStar p x
  let B := External G A
  have eq := ActiveStarHeight.star_card_degree_and_pins lp hx
  change A.card+(Pins p x).card=G.degree x+1 at eq
  have large : 4≤A.card := by
    rcases cases' with h|h
    · omega
    omega
  have ao : ∀ z∈A,z∉p.support := fun _ h=>(Graffiti189LongestPath.Rigidity.mem_omittedStar.mp h).1
  have data : StarRouteData G A x :=
    ⟨Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,.inl rfl⟩,fun z hz ne=>(Graffiti189LongestPath.Rigidity.mem_omittedStar.mp hz).2.resolve_left ne,large⟩
  have dis : Disjoint A B := disjoint_left.mpr (fun _ ha hb=>(Graffiti189LongestPath.Rigidity.mem_external.mp hb).1 ha)
  have cl : ∀ u∈A,∀ v∉A,G.Adj u v → v∈B :=
    fun u ua v va uv=>Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨va,u,ua,uv⟩
  obtain ⟨F⟩ := hooks_of_small_deletion_connectivity A 3 lp ao (by omega)
    (MengerRoutable.support_large 3 conn lp hx) conn
  have d2Cap : ∀ v,(DistanceTwo G v).card≤5 := fun v=>distanceTwo_le_of_even 5 v (cap v)
  rcases cases' with ⟨one,_,rad⟩|⟨two,_,_,b3,rad⟩
  · have ord := order_of_degree_five_radius_anchor hc x (cap x) (d3 x) rad
    have small := (SingleStar.singleton_star_budget hc 3 conn lp hx one (cap x)).2.1
    have visible : ∀ z∈A,(∀ w∈B,G.Adj z w) → (B∩p.support.toFinset).card≤2 := by
      intro z za all
      have hz := ao z za
      have bound : (Pins p z).card ≤ 2 := by
        by_cases zx : z = x
        · rw [zx,one]
          decide
        exact at_most_two_pins_with_omitted_neighbor hc 3 lp hz (d2Cap z) conn hx
          (data.allAdj z za zx).symm
      have sub : B∩p.support.toFinset⊆PinVertices p z := by
        intro w wm
        obtain ⟨wb,wp⟩ := mem_inter.mp wm
        obtain ⟨i,ip,e⟩ := Graffiti189LongestPath.OneSlack.pin_of_neighbor_mem lp hz (List.mem_toFinset.mp wp) (all w wb)
        exact mem_image.mpr ⟨i,ip,e⟩
      have k := card_le_card sub
      rw [Graffiti189LongestPath.OneSlack.card_pinVertices lp] at k
      omega
    exact five_single_star_three_hook_impossible lp ⟨data,dis,cl,small⟩ ao F degree visible (by omega)
  have ord := order_of_degree_five_radius_anchor hc x (cap x) (d3 x) (fun z=>(rad z).trans (by decide))
  have n4 := large.trans (card_le_univ A)
  change B.card = 3 at b3
  exact five_double_star_three_hook_impossible lp ⟨data,dis,cl,by omega⟩ ao F degree
    (min_three_degree_of_small_deletion conn n4) b3 (by omega)

#print axioms traceable_degree_five_three_connected_of_shell_three
end Graffiti189LongestPath.FiveThreeHook
