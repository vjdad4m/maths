import FiveThreeHookSmall189

namespace Graffiti189LongestPath.FiveThreeHook
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.FanRoutable
open Graffiti189LongestPath.EndpointSplice Graffiti189LongestPath.WideWing
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

private lemma path_append_separated {u v w : V} {p : G.Walk u v} {q : G.Walk v w}
    (hp : p.IsPath) (hq : q.IsPath)
    (only : ∀ z∈p.support, z∈q.support → z=v) :
    (p.append q).IsPath := by
  rw [isPath_def,support_append,List.nodup_append]
  refine ⟨hp.support_nodup,hq.support_nodup.tail,?_⟩
  intro z zp zq
  have e := only z zp (List.mem_of_mem_tail zq)
  subst z
  cases q with
  | nil => simp at zq
  | cons edge q => exact ((cons_isPath_iff edge q).mp hq).2 zq

theorem hook_roots_distinct {a b : V} {p : G.Walk a b} {A : Finset V}
    (F : HookFamily p A 3) {i j : Fin 3} (ne : i≠j) : F.root i≠F.root j := by
  intro e
  exact F.disj ne (F.path i).start_mem_support (e.symm ▸ (F.path j).start_mem_support)

theorem hook_indices_in_order {a b : V} {p : G.Walk a b} {A : Finset V}
    (F : HookFamily p A 3) : ∃ i j k : Fin 3,F.idx i<F.idx j ∧ F.idx j<F.idx k := by
  have h01 : F.idx 0≠F.idx 1 := fun e=>(by decide : (0 : Fin 3)≠1) (F.idx.injective e)
  have h02 : F.idx 0≠F.idx 2 := fun e=>(by decide : (0 : Fin 3)≠2) (F.idx.injective e)
  have h12 : F.idx 1≠F.idx 2 := fun e=>(by decide : (1 : Fin 3)≠2) (F.idx.injective e)
  by_cases h : F.idx 0<F.idx 1
  · by_cases i : F.idx 1<F.idx 2
    · exact ⟨0,1,2,h,i⟩
    by_cases j : F.idx 0<F.idx 2
    · exact ⟨0,2,1,j,by omega⟩
    exact ⟨2,0,1,by omega,h⟩
  by_cases i : F.idx 0<F.idx 2
  · exact ⟨1,0,2,by omega,i⟩
  by_cases j : F.idx 1<F.idx 2
  · exact ⟨1,2,0,j,by omega⟩
  exact ⟨2,1,0,by omega,by omega⟩

theorem hook_end_room {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    {A : Finset V} (ao : ∀ z∈A,z∉p.support) (F : HookFamily p A 3)
    {i : Fin 3} {H : ℕ} (r : LongFrom G A (F.root i) H) :
    H+(F.path i).length≤F.idx i ∧ F.idx i+H+(F.path i).length≤p.length := by
  obtain ⟨v,q,hq,qs,ql⟩ := r
  let w := (F.path i).reverse.append q
  have wp : w.IsPath := path_append_separated (F.simple i).reverse hq (by
    intro z hz zq
    exact F.single i z (by simpa only [support_reverse,List.mem_reverse] using hz) (qs z zq))
  have wo : ∀ z∈w.support,z∉p.support := by
    intro z hz
    rw [show w=(F.path i).reverse.append q from rfl,support_append,List.mem_append] at hz
    exact hz.elim (fun l => F.off i z (by simpa only [support_reverse,List.mem_reverse] using l))
      (fun r => ao z (qs z (List.mem_of_mem_tail r)))
  have d := endpoint_room hp w wp wo (Nat.le_of_lt (F.idxLt i)) (F.adjLast i).symm
  simp only [w,length_append,length_reverse] at d
  omega

theorem hook_gap_room {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    {A : Finset V} (ao : ∀ z∈A,z∉p.support) (F : HookFamily p A 3)
    {i j : Fin 3} (lt : F.idx i<F.idx j) {H : ℕ}
    (r : LongInside G A (F.root i) (F.root j) H) :
    F.idx i+H+1+(F.path i).length+(F.path j).length≤F.idx j := by
  have ij : i≠j := fun eq => (Nat.lt_irrefl _) (eq ▸ lt)
  obtain ⟨q,hq,qs,ql⟩ := r
  let l := (F.path i).reverse.append q
  have lp : l.IsPath := path_append_separated (F.simple i).reverse hq (by
    intro z hz qz
    exact F.single i z (by simpa only [support_reverse,List.mem_reverse] using hz) (qs z qz))
  let w := l.append (F.path j)
  have wp : w.IsPath := path_append_separated lp (F.simple j) (by
    intro z zl zj
    rw [show l=(F.path i).reverse.append q from rfl,support_append,List.mem_append] at zl
    rcases zl with ll|rr
    · exact (F.disj ij (by simpa only [support_reverse,List.mem_reverse] using ll) zj).elim
    · exact F.single j z zj (qs z (List.mem_of_mem_tail rr)))
  have wo : ∀ z∈w.support,z∉p.support := by
    intro z hz
    rw [show w=l.append (F.path j) from rfl,support_append,List.mem_append] at hz
    rcases hz with hl|hj
    · rw [show l=(F.path i).reverse.append q from rfl,support_append,List.mem_append] at hl
      exact hl.elim (fun l => F.off i z (by simpa only [support_reverse,List.mem_reverse] using l))
        (fun r => ao z (qs z (List.mem_of_mem_tail r)))
    · exact F.off j z (List.mem_of_mem_tail hj)
  have pi : F.idx i∈Pins p (F.last i) := mem_filter.mpr ⟨mem_range.mpr (F.idxLt i),F.adjLast i⟩
  have pj : F.idx j∈Pins p (F.last j) := mem_filter.mpr ⟨mem_range.mpr (F.idxLt j),F.adjLast j⟩
  have q := terminal_length_le_gap hp pi pj lt w wp wo
  simp only [w,l,length_append,length_reverse] at q
  omega

theorem ordered_three_hook_room {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    {A : Finset V} (ao : ∀ z∈A,z∉p.support) (F : HookFamily p A 3)
    {i j k : Fin 3} (ij : F.idx i<F.idx j) (jk : F.idx j<F.idx k)
    {l m n r : ℕ}
    (left : LongFrom G A (F.root i) l) (end' : LongFrom G A (F.root k) r)
    (first : LongInside G A (F.root i) (F.root j) m)
    (second : LongInside G A (F.root j) (F.root k) n) :
    l+m+n+r+3+2*((F.path i).length+(F.path j).length+(F.path k).length)≤p.length+1 := by
  have e := (hook_end_room hp ao F left).1
  have f := (hook_end_room hp ao F end').2
  have g := hook_gap_room hp ao F ij first
  have h := hook_gap_room hp ao F jk second
  omega

#print axioms ordered_three_hook_room
end Graffiti189LongestPath.FiveThreeHook
