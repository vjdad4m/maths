import FanGain189

namespace Graffiti189LongestPath.FiveThreeHook
open SimpleGraph SimpleGraph.Walk Finset Graffiti189LongestPath.CrossSaturation
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

def ShortRouteOn (G : SimpleGraph V) (A : Finset V) (x y : V) : Prop :=
  ∃ p : G.Walk x y,p.IsPath ∧ ∀ z,z∈p.support ↔ z∈A

theorem ShortRouteOn.edge {x y : V} (xy : G.Adj x y) : ShortRouteOn G {x,y} x y := by
  have h : (Walk.cons xy (.nil : G.Walk y y)).IsPath := IsPath.cons (by simp) (by simpa using xy.ne)
  exact ⟨.cons xy .nil,h,by intro z; simp [support_cons]⟩

theorem ShortRouteOn.singleton {x : V} : ShortRouteOn G {x} x x :=
  ⟨.nil,by simp,by intro z; simp⟩

theorem ShortRouteOn.three {x y z : V} (xy : G.Adj x y) (yz : G.Adj y z) (xz : x≠z) :
    ShortRouteOn G {x,y,z} x z := by
  obtain ⟨q,h,s⟩ := ShortRouteOn.edge yz
  have off : x∉q.support := fun h=>by
    have v := (s x).mp h
    simp [xy.ne,xz] at v
  exact ⟨.cons xy q,h.cons off,by intro w; simp only [support_cons,List.mem_cons,mem_insert,s]⟩

theorem ShortRouteOn.suffix {A : Finset V} {x y z : V}
    (p : ShortRouteOn G A x y) (yz : G.Adj y z) (off : z∉A) : ShortRouteOn G (insert z A) x z := by
  obtain ⟨q,qp,qs⟩ := p
  refine ⟨q.concat yz,path_concat_new q qp yz (fun h=>off ((qs _).mp h)),?_⟩
  intro u
  simp only [support_concat,List.concat_eq_append,List.mem_append,qs,List.mem_singleton,mem_insert,or_comm]

def LongInside (G : SimpleGraph V) (A : Finset V) (u v : V) (n : ℕ) : Prop :=
  ∃ p : G.Walk u v,p.IsPath ∧ (∀ w∈p.support,w∈A) ∧ n≤p.length+1

def LongFrom (G : SimpleGraph V) (A : Finset V) (u : V) (n : ℕ) : Prop :=
  ∃ v,LongInside G A u v n

theorem LongInside.relax {A : Finset V} {u v : V} {n m : ℕ}
    (p : LongInside G A u v n) (h : m≤n) : LongInside G A u v m := by
  obtain ⟨p,pp,ps,pn⟩ := p
  exact ⟨p,pp,ps,h.trans pn⟩

theorem LongInside.reverse {A : Finset V} {u v : V} {n : ℕ}
    (p : LongInside G A u v n) : LongInside G A v u n := by
  obtain ⟨p,pp,ps,pn⟩ := p
  exact ⟨p.reverse,pp.reverse,fun u h=>ps u (by simpa using h),by simpa using pn⟩

theorem two_inside {A : Finset V} {u v : V} (ua : u∈A) (va : v∈A) (uv : G.Adj u v) :
    LongInside G A u v 2 := by
  refine ⟨Walk.cons uv .nil,?_,?_,by simp⟩
  · exact Walk.IsPath.cons (by simp) (by simpa using uv.ne)
  intro w hw
  simp only [support_cons,support_nil,List.mem_cons,List.mem_singleton,List.not_mem_nil,or_false,false_or] at hw
  exact hw.elim (fun e=>e.symm ▸ ua) (fun e=>e.symm ▸ va)

theorem three_inside {A : Finset V} {u v w : V} (ua : u∈A) (va : v∈A) (wa : w∈A)
    (uv : G.Adj u v) (vw : G.Adj v w) (uw : u≠w) : LongInside G A u w 3 := by
  obtain ⟨p,pp,ps⟩ := ShortRouteOn.three uv vw uw
  have card := List.toFinset_card_of_nodup pp.support_nodup
  rw [length_support] at card
  have sub : ({u,v,w} : Finset V)⊆p.support.toFinset :=
    fun z m=>List.mem_toFinset.mpr ((ps z).mpr m)
  have n := card_le_card sub
  have c : ({u,v,w} : Finset V).card=3 := by simp [uv.ne,vw.ne,uw]
  refine ⟨p,pp,?_,by omega⟩
  intro z hz
  have h := (ps z).mp hz
  simp only [mem_insert,mem_singleton] at h
  exact h.elim (fun e=>e.symm ▸ ua) (fun h=>h.elim (fun e=>e.symm ▸ va) (fun e=>e.symm ▸ wa))

theorem four_inside {A : Finset V} {u v w z : V}
    (ua : u∈A) (va : v∈A) (wa : w∈A) (za : z∈A)
    (uv : G.Adj u v) (vw : G.Adj v w) (wz : G.Adj w z)
    (uw : u≠w) (uz : u≠z) (vz : v≠z) : LongInside G A u z 4 := by
  have p := (ShortRouteOn.three uv vw uw).suffix wz (by simp [uz.symm,vz.symm,wz.ne.symm])
  obtain ⟨p,pp,ps⟩ := p
  have card := List.toFinset_card_of_nodup pp.support_nodup
  rw [length_support] at card
  have sub : (insert z ({u,v,w} : Finset V))⊆p.support.toFinset :=
    fun i m=>List.mem_toFinset.mpr ((ps i).mpr m)
  have n := card_le_card sub
  have c : (insert z ({u,v,w} : Finset V)).card=4 := by
    simp [uz.symm,vz.symm,wz.ne.symm,uv.ne,vw.ne,uw]
  refine ⟨p,pp,?_,by omega⟩
  intro i hi
  have h := (ps i).mp hi
  simp only [mem_insert,mem_singleton] at h
  exact h.elim (fun e=>e.symm ▸ za)
    (fun h=>h.elim (fun e=>e.symm ▸ ua) (fun h=>h.elim (fun e=>e.symm ▸ va) (fun e=>e.symm ▸ wa)))

#print axioms four_inside
end Graffiti189LongestPath.FiveThreeHook
