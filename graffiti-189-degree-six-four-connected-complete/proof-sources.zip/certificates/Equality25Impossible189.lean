import Equality25Frame34Cert189
import Equality25Frame35Cert189
import Equality25Frame36Cert189
import Equality25Frame44Cert189
import Equality25Frame45Cert189
import Equality25Frame46Cert189

open SimpleGraph Graffiti189LongestPath
open Graffiti189LongestPath.Equality25Profile
namespace Graffiti189LongestPath.Equality25Count

/-- No labelled profile with the equality conditions exists. -/
theorem model_impossible {G : SimpleGraph Vert} [DecidableRel G.Adj] {t b : ℕ}
    (ht : t=3 ∨ t=4) (hb : 4≤b ∧ b≤6) (M : Model G t b) : False := by
  have q : b=4 ∨ b=5 ∨ b=6 := by omega
  rcases ht with rfl|rfl <;> rcases q with rfl|rfl|rfl
  · exact Frame34.impossible M
  · exact Frame35.impossible M
  · exact Frame36.impossible M
  · exact Frame44.impossible M
  · exact Frame45.impossible M
  · exact Frame46.impossible M

#print axioms model_impossible
end Graffiti189LongestPath.Equality25Count
