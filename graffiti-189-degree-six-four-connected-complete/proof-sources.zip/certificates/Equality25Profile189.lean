import ModelFromGraph189
import WideWing189

open Finset SimpleGraph Graffiti189LongestPath
namespace Graffiti189LongestPath.Equality25Profile

abbrev Vert := Fin 25

def vertex (i : ℕ) : Vert := ⟨i % 25,Nat.mod_lt _ (by decide)⟩

def inA (i : Vert) : Bool := decide (1≤i.val ∧ i.val≤6)
def inB (b : ℕ) (i : Vert) : Bool := decide (7≤i.val ∧ i.val<7+b)
def inC (b : ℕ) (i : Vert) : Bool := decide (7+b≤i.val ∧ i.val<19+b)
def selected (t : ℕ) (i : Vert) : Bool := decide (1≤i.val ∧ i.val≤t)
def marked (t : ℕ) (i : Vert) : Bool := decide (7≤i.val ∧ i.val<7+t)
def layer (b : ℕ) (i : Vert) : ℕ :=
  if i=0 then 0 else if inA i then 1 else if inB b i then 2 else if inC b i then 3 else 4

def group (t b : ℕ) (i : Vert) : ℕ := (i.val-(7+b))/(7-t)
def markedOf (i : Vert) : Vert := vertex (i.val+6)

def forcedAdj (t b : ℕ) (i j : Vert) : Option Bool :=
  if i.val≥j.val then none
  else if i=0 then some (inA j)
  else if layer b i + 1 < layer b j then some false
  else if selected t i && inA j && !(selected t j) then some true
  else if selected t i && marked t j then some (decide (j=markedOf i))
  else if marked t i && inC b j then
    if group t b j≠i.val-7 then some false
    else if (j.val-(7+b))%(7-t)=0 then some true else none
  else none

def forcedD2 (t b : ℕ) (i j : Vert) : Option Bool :=
  if i=0 ∧ inB b j then some true
  else if selected t i then
    if inC b j then some (decide (group t b j=i.val-1))
    else if (selected t j && decide (j≠i)) || (marked t j && decide (j≠markedOf i))
      then none
      else some false
  else none

def TwoStep (G : SimpleGraph Vert) (i j : Vert) : Prop :=
  i≠j ∧ ¬G.Adj i j ∧ ∃ k,G.Adj i k ∧ G.Adj k j

instance decTwoStep (G : SimpleGraph Vert) [DecidableRel G.Adj] :
    DecidableRel (TwoStep G) := fun i j => by
  unfold TwoStep
  infer_instance

def Shadow (G : SimpleGraph Vert) [DecidableRel G.Adj] (i : Vert) : Finset Vert :=
  univ.filter (TwoStep G i)

def highRole (t b : ℕ) (i : Vert) : Bool := marked t i || inC b i

/-- Finite labelled data needed to contradict equality in the order
bound. In particular, the cap need only be checked at private B witnesses. -/
structure Model (G : SimpleGraph Vert) [DecidableRel G.Adj] (t b : ℕ) : Prop where
  forcedEdge : ∀ i j q, forcedAdj t b i j=some q → (G.Adj i j ↔ q=true)
  forcedShadow : ∀ i j q, forcedD2 t b i j=some q → (TwoStep G i j ↔ q=true)
  cross : ∀ i j, selected t i=true → selected t j=true → i≠j →
    TwoStep G i (markedOf j) → G.Adj i j
  cap : ∀ i, marked t i=true → (Shadow G i).card≤6
  pair : ∀ i j, highRole t b i=true → highRole t b j=true → i≠j →
    6≤G.degree i ∨ 6≤G.degree j

theorem twoStep_symm {G : SimpleGraph Vert} {i j : Vert} :
    TwoStep G i j ↔ TwoStep G j i := by
  constructor <;> rintro ⟨ne,no,k,e₁,e₂⟩
  · exact ⟨ne.symm,(fun e => no e.symm),k,e₂.symm,e₁.symm⟩
  · exact ⟨ne.symm,(fun e => no e.symm),k,e₂.symm,e₁.symm⟩

end Graffiti189LongestPath.Equality25Profile
