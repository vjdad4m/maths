# Graffiti.pc #189: the 25-vertex equality profile is impossible

This package refutes all six normalized layer profiles that can arise
at equality in the degree-six, four-connected order bound. It is a
finite-profile exclusion, not on its own an arbitrary-graph dispatcher.
The labeling and equality extraction for actual graphs belong to
the surrounding degree-six proof.

The six cases have 3 or 4 selected first-layer parents and 4 through 6
second-layer vertices. The trusted graph premises are stated in
`Equality25Profile.Model`. Only the marked second-layer witnesses
need the distance-two cap; the pairwise degree condition is needed
only at those witnesses and the 12 third-layer vertices.

`Equality25CNF` interprets every atom as graph adjacency, exact
distance two, an explicit common neighbor, or a degree/size threshold.
`Equality25Count` proves the size-counter recurrence by adding one
vertex to a finite filtered set, and checks all individual clause
families. Each DIMACS formula is definitionally equal to its list
of checked rule clauses. Each LRAT trace is elaborated to ordinary
kernel proof terms; no external solver or native computation is
trusted on replay.

Main: `Graffiti189LongestPath.Equality25Count.model_impossible`.
