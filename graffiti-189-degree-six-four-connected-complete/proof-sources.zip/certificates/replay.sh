#!/bin/bash
set -euo pipefail
root=$(cd "$(dirname "$0")" && pwd)
cd "$root"
sha256sum -c SOURCES.sha256
out=$(mktemp -d)
trap 'rm -rf "$out"' EXIT
export LEAN_PATH="$out${LEAN_PATH:+:$LEAN_PATH}"
for m in Equality25Profile189 Equality25CNF189 Equality25Count189 Equality25Frame44Cert189 Equality25Frame45Cert189 Equality25Frame46Cert189 Equality25Frame34Cert189 Equality25Frame35Cert189 Equality25Frame36Cert189 Equality25Impossible189; do
  lean -j1 -s32768 -DElab.async=false -DwarningAsError=true --root="$root" -o "$out/$m.olean" "$root/$m.lean"
done
