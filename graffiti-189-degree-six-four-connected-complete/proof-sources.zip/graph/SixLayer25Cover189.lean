import SixFourFiniteOrder189
import Mathlib.Tactic.NormNum

namespace Graffiti189LongestPath
open SimpleGraph SimpleGraph.Walk Finset
open private distance_on_geodesic mem_distanceTwo dist_two from SmallSeparator189

variable {V : Type*} {G : SimpleGraph V}
    [Fintype V] [DecidableEq V] [DecidableRel G.Adj]

noncomputable def Layer25Group (G : SimpleGraph V) (x a : V) : Finset V :=
  Shell G x 3 ∩ DistanceTwo G a

structure Layer25Cover (G : SimpleGraph V) (x : V) [DecidableRel G.Adj] where
  T : Finset V
  rep : V → V
  selected : T ⊆ Shell G x 1
  tSize : T.card = 3 ∨ T.card = 4
  firstSize : (Shell G x 1).card = 6
  thirdSize : (Shell G x 3).card = 12
  secondMin : 4 ≤ (Shell G x 2).card
  secondMax : (Shell G x 2).card ≤ 6
  evenSize : (Shell G x 2).card + (Shell G x 4).card = 6
  radius : ∀ y, G.dist x y ≤ 4
  groupSize : ∀ a ∈ T, (Layer25Group G x a).card = 7 - T.card
  groupCover : Shell G x 3 ⊆ T.biUnion (Layer25Group G x)
  groupDisjoint : ∀ a ∈ T, ∀ b ∈ T, a ≠ b → Disjoint (Layer25Group G x a) (Layer25Group G x b)
  repDepth : ∀ a ∈ T, G.dist x (rep a) = 2
  repAdj : ∀ a ∈ T, G.Adj a (rep a)
  repPrivate : ∀ a ∈ T, ∀ b ∈ T, b ≠ a → ¬ G.Adj b (rep a)
  repWitness : ∀ a ∈ T, ∃ c ∈ Layer25Group G x a, G.Adj (rep a) c
  d2Exact : ∀ a ∈ T, DistanceTwo G a =
    Layer25Group G x a ∪ (T.erase a).image (fun b => if G.Adj a b then rep b else b)
  joinRest : ∀ a ∈ T, ∀ b ∈ Shell G x 1, b ∉ T → G.Adj a b

theorem layer_cover_at_order_twenty_five_with_radius_frame
    (hc : G.Connected) (cap : ∀ v, (EvenFrom G v).card ≤ 7)
    (x : V) (dx : G.degree x ≤ 6) (n : Fintype.card V = 25)
    (diam : ∀ y, G.dist x y ≤ 4) (p2lower : 4 ≤ (Shell G x 2).card) :
    Nonempty (Layer25Cover G x) := by
  classical
  let A := Shell G x 1
  let C := Shell G x 3
  let f := Layer25Group G x
  have eqA : A = G.neighborFinset x := by
    ext a
    rw [mem_shell,G.mem_neighborFinset,dist_eq_one_iff_adj]
  have cA : A.card ≤ 6 := by
    rw [eqA,G.card_neighborFinset_eq_degree]
    exact dx
  have bd (u : V) : (DistanceTwo G u).card ≤ 6 :=
    distanceTwo_le_of_even 6 u (cap u)
  have aDepth {a : V} (am : a ∈ A) : G.dist x a = 1 := mem_shell.mp am
  have cDepth {c : V} (cm : c ∈ C) : G.dist x c = 3 := mem_shell.mp cm
  have d2_of_middle {a b c : V} (da : G.dist x a = 1) (dc : G.dist x c = 3)
      (ab : G.Adj a b) (bc : G.Adj b c) : G.dist a c = 2 := by
    have ne : a ≠ c := by intro e; rw [e] at da; omega
    have na : ¬ G.Adj a c := by
      intro ac
      have e := dist_eq_one_iff_adj.mpr ac
      have t := hc.dist_triangle (u:=x) (v:=a) (w:=c)
      omega
    exact dist_two hc ne na ab bc
  have coverA : C ⊆ A.biUnion f := by
    intro c cm
    obtain ⟨p,hp⟩ := hc.exists_walk_length_eq_dist x c
    have len : p.length = 3 := hp.trans (cDepth cm)
    let a := p.getVert 1
    let b := p.getVert 2
    have ap : G.dist x a = 1 := distance_on_geodesic hc p hp 1 (by omega)
    have ab : G.Adj a b := p.adj_getVert_succ (i:=1) (by omega)
    have bc : G.Adj b c := by
      have e := p.adj_getVert_succ (i:=2) (by omega)
      have e3 : p.getVert 3 = c := by rw [← len,getVert_length]
      simpa only [e3] using e
    exact mem_biUnion.mpr ⟨a,mem_shell.mpr ap,mem_inter.mpr
      ⟨cm,mem_distanceTwo.mpr (d2_of_middle ap (cDepth cm) ab bc)⟩⟩
  let fam := A.powerset.filter (fun T : Finset V => C ⊆ T.biUnion f)
  have fn : fam.Nonempty := ⟨A,mem_filter.mpr ⟨mem_powerset.mpr (Subset.rfl),coverA⟩⟩
  obtain ⟨T, Tfam, minT⟩ := exists_min_image fam (fun S : Finset V => S.card) fn
  have TA : T ⊆ A := mem_powerset.mp (mem_filter.mp Tfam).1
  have cover : C ⊆ T.biUnion f := (mem_filter.mp Tfam).2
  have ts : T.card ≤ 6 := (card_le_card TA).trans cA
  have uniqueMiddle (a : V) (ha : a ∈ T) :
      ∃ b : V, G.dist x b = 2 ∧ G.Adj a b ∧
      (∀ z ∈ T, z ≠ a → ¬ G.Adj z b) ∧ ∃ c ∈ f a, G.Adj b c := by
    have lost : ¬ C ⊆ (T.erase a).biUnion f := by
      intro hs
      have m : T.erase a ∈ fam := mem_filter.mpr ⟨mem_powerset.mpr
        ((erase_subset a T).trans TA),hs⟩
      have e := minT (T.erase a) m
      have cd := card_erase_add_one ha
      omega
    obtain ⟨c, cm, miss⟩ := not_subset.mp lost
    have ac : c ∈ f a := by
      obtain ⟨z,zm,zc⟩ := mem_biUnion.mp (cover cm)
      by_cases za : z = a
      · exact za ▸ zc
      · exact (miss (mem_biUnion.mpr ⟨z,mem_erase.mpr ⟨za,zm⟩,zc⟩)).elim
    have d2 := mem_distanceTwo.mp (mem_inter.mp ac).2
    obtain ⟨p,hp⟩ := hc.exists_walk_length_eq_dist a c
    have len : p.length = 2 := hp.trans d2
    let b := p.getVert 1
    have ab : G.Adj a b := by simpa [b] using p.adj_getVert_succ (i:=0) (by omega)
    have bc : G.Adj b c := by
      have e := p.adj_getVert_succ (i:=1) (by omega)
      have e2 : p.getVert 2 = c := by rw [← len,getVert_length]
      simpa only [e2] using e
    have da := aDepth (TA ha)
    have dc := cDepth cm
    have d_ab := dist_eq_one_iff_adj.mpr ab
    have d_bc := dist_eq_one_iff_adj.mpr bc
    have t1 := hc.dist_triangle (u:=x) (v:=a) (w:=b)
    have t2 := hc.dist_triangle (u:=x) (v:=b) (w:=c)
    have db : G.dist x b = 2 := by omega
    refine ⟨b, db, ab, ?_, ⟨c,ac,bc⟩⟩
    intro z zT ne zb
    have zc : c ∈ f z := mem_inter.mpr ⟨cm,mem_distanceTwo.mpr
      (d2_of_middle (aDepth (TA zT)) dc zb bc)⟩
    exact miss (mem_biUnion.mpr ⟨z,mem_erase.mpr ⟨ne,zT⟩,zc⟩)
  let rep (a : V) := if h : a ∈ T then Classical.choose (uniqueMiddle a h) else x
  have prop {a : V} (ha : a ∈ T) :
      G.dist x (rep a) = 2 ∧ G.Adj a (rep a) ∧
      (∀ z ∈ T, z ≠ a → ¬ G.Adj z (rep a)) ∧ ∃ c ∈ f a, G.Adj (rep a) c := by
    simpa [rep, dif_pos ha] using Classical.choose_spec (uniqueMiddle a ha)
  have fData (a : V) (ha : a ∈ T) :
      (f a).card ≤ 7 - T.card ∧
      ∃ R : Finset V, R = (T.erase a).image (fun b => if G.Adj a b then rep b else b) ∧
        R.card + 1 = T.card ∧ Disjoint (f a) R ∧ f a ∪ R ⊆ DistanceTwo G a := by
    let U := T.erase a
    let ch (b : V) := if G.Adj a b then rep b else b
    have good (b : V) (hb : b ∈ U) : ch b ∈ DistanceTwo G a ∧ G.dist x (ch b) ≤ 2 := by
      obtain ⟨ba,bm⟩ := mem_erase.mp hb
      have pr := prop bm
      have bd := aDepth (TA bm)
      by_cases ab : G.Adj a b
      · have ne : a ≠ rep b := by
          intro h
          have d := aDepth (TA ha)
          rw [h] at d
          have e := pr.1
          omega
        simp only [ch,if_pos ab,mem_distanceTwo]
        exact ⟨dist_two hc ne (pr.2.2.1 a ha ba.symm) ab pr.2.1,pr.1.le⟩
      · have ax : G.Adj a x := (dist_eq_one_iff_adj.mp (aDepth (TA ha))).symm
        have xb : G.Adj x b := dist_eq_one_iff_adj.mp bd
        simp only [ch,if_neg ab,mem_distanceTwo]
        exact ⟨dist_two hc ba.symm ab ax xb,bd.le.trans (by decide)⟩
    have inj : ∀ b ∈ U, ∀ c ∈ U, ch b = ch c → b = c := by
      intro b hb c hc' eq
      have bm := (mem_erase.mp hb).2
      have cm := (mem_erase.mp hc').2
      have bp := prop bm
      have cp := prop cm
      have b1 := aDepth (TA bm)
      have c1 := aDepth (TA cm)
      by_cases ab : G.Adj a b <;> by_cases ac : G.Adj a c
      · simp only [ch,if_pos ab,if_pos ac] at eq
        apply Classical.byContradiction
        intro ne
        exact cp.2.2.1 b bm ne (eq ▸ bp.2.1)
      · simp only [ch,if_pos ab,if_neg ac] at eq
        have d := bp.1
        rw [eq] at d
        omega
      · simp only [ch,if_neg ab,if_pos ac] at eq
        have d := cp.1
        rw [← eq] at d
        omega
      · simpa [ch,ab,ac] using eq
    have dis : Disjoint (f a) (U.image ch) := by
      apply disjoint_left.mpr
      intro z zf zi
      obtain ⟨b,hb,rfl⟩ := mem_image.mp zi
      have d := cDepth (mem_inter.mp zf).1
      have e := (good b hb).2
      omega
    have sub : f a ∪ U.image ch ⊆ DistanceTwo G a := by
      apply union_subset (fun z hz => (mem_inter.mp hz).2)
      intro z zz
      obtain ⟨b,hb,rfl⟩ := mem_image.mp zz
      exact (good b hb).1
    have n := (card_le_card sub).trans (bd a)
    rw [card_union_of_disjoint dis,card_image_of_injOn inj] at n
    have er := card_erase_add_one ha
    dsimp [U] at n
    refine ⟨by omega,U.image ch,rfl,?_,dis,sub⟩
    rw [card_image_of_injOn inj]
    exact er
  have fbound (a : V) (ha : a ∈ T) := (fData a ha).1
  have w := (card_le_card cover).trans (card_biUnion_le_card_mul T f (7-T.card) fbound)
  have ar (t : ℕ) (h : t ≤ 6) : t*(7-t) ≤ 12 := by
    have e : t=0 ∨ t=1 ∨ t=2 ∨ t=3 ∨ t=4 ∨ t=5 ∨ t=6 := by omega
    rcases e with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> decide
  have cC : C.card ≤ 12 := w.trans (ar T.card ts)
  have cov : (Finset.univ : Finset V) ⊆ (EvenFrom G x ∪ A) ∪ C := by
    intro y _
    have d : G.dist x y ≤ 4 := diam y
    by_cases e : Even (G.dist x y)
    · exact mem_union.mpr (.inl (mem_union.mpr (.inl (mem_filter.mpr ⟨mem_univ _,e⟩))))
    by_cases o : G.dist x y = 1
    · exact mem_union.mpr (.inl (mem_union.mpr (.inr (mem_shell.mpr o))))
    exact mem_union.mpr (.inr (mem_shell.mpr (by simp only [Nat.even_iff] at e; omega)))
  have h := card_le_card cov
  rw [card_univ] at h
  have u := card_union_le (EvenFrom G x ∪ A) C
  have v := card_union_le (EvenFrom G x) A
  have xc := cap x
  have c12 : C.card = 12 := by omega
  have a6 : A.card = 6 := by omega
  have e7 : (EvenFrom G x).card = 7 := by omega
  have tCases : T.card = 3 ∨ T.card = 4 := by
    have e : T.card=0 ∨ T.card=1 ∨ T.card=2 ∨ T.card=3 ∨
        T.card=4 ∨ T.card=5 ∨ T.card=6 := by omega
    have w' : 12 ≤ T.card * (7 - T.card) := by simpa only [c12] using w
    rcases e with e|e|e|e|e|e|e
    · rw [e] at w'; norm_num at w'
    · rw [e] at w'; norm_num at w'
    · rw [e] at w'; norm_num at w'
    · exact .inl e
    · exact .inr e
    · rw [e] at w'; norm_num at w'
    · rw [e] at w'; norm_num at w'
  have e24 : (Shell G x 2).card + (Shell G x 4).card = 6 := by
    have s24 := shell_two_four_le_of_even (cap x)
    have coverEven : EvenFrom G x ⊆ insert x (Shell G x 2 ∪ Shell G x 4) := by
      intro y ym
      have ey := (mem_filter.mp ym).2
      have dd := diam y
      by_cases same : x = y
      · exact mem_insert.mpr (.inl same.symm)
      have d0 : G.dist x y ≠ 0 :=
        fun z => same ((dist_eq_zero_iff_eq_or_not_reachable.mp z).resolve_right
          (not_not.mpr (hc x y)))
      have hh : G.dist x y = 2 ∨ G.dist x y = 4 := by
        simp only [Nat.even_iff] at ey
        omega
      exact mem_insert.mpr (.inr (mem_union.mpr (hh.imp mem_shell.mpr mem_shell.mpr)))
    have ce := card_le_card coverEven
    have ci := card_insert_le x (Shell G x 2 ∪ Shell G x 4)
    have cu := card_union_le (Shell G x 2) (Shell G x 4)
    omega
  have eqF (a : V) (ha : a ∈ T) : (f a).card = 7 - T.card := by
    have incl : C ⊆ f a ∪ (T.erase a).biUnion f := by
      intro z hz
      obtain ⟨b,bT,bz⟩ := mem_biUnion.mp (cover hz)
      by_cases ba : b=a
      · exact mem_union.mpr (.inl (ba ▸ bz))
      exact mem_union.mpr (.inr (mem_biUnion.mpr ⟨b,mem_erase.mpr ⟨ba,bT⟩,bz⟩))
    have c := card_le_card incl
    have bu := card_union_le (f a) ((T.erase a).biUnion f)
    have bv := card_biUnion_le_card_mul (T.erase a) f (7-T.card)
      (fun z hz => fbound z (mem_erase.mp hz).2)
    have er := card_erase_add_one ha
    have b := fbound a ha
    rcases tCases with t|t <;> rw [t] at bv b er ⊢ <;> norm_num at bv b ⊢ <;> omega
  have disF (a : V) (ha : a∈T) (b : V) (hb : b∈T) (ne : a≠b) :
      Disjoint (f a) (f b) := by
    apply disjoint_left.mpr
    intro z za zb
    let R := (T.erase a).erase b
    have incl : C ⊆ (f a ∪ f b) ∪ R.biUnion f := by
      intro y yy
      obtain ⟨q,qt,qy⟩ := mem_biUnion.mp (cover yy)
      by_cases qa : q=a
      · exact mem_union.mpr (.inl (mem_union.mpr (.inl (qa ▸ qy))))
      by_cases qb : q=b
      · exact mem_union.mpr (.inl (mem_union.mpr (.inr (qb ▸ qy))))
      exact mem_union.mpr (.inr (mem_biUnion.mpr
        ⟨q,mem_erase.mpr ⟨qb,mem_erase.mpr ⟨qa,qt⟩⟩,qy⟩))
    have sum := card_union_add_card_inter (f a) (f b)
    have ci : 0 < (f a ∩ f b).card := card_pos.mpr ⟨z,mem_inter.mpr ⟨za,zb⟩⟩
    have fr := card_biUnion_le_card_mul R f (7-T.card)
      (fun j jR=> fbound j (mem_erase.mp (mem_erase.mp jR).2).2)
    have ctr : R.card + 2 = T.card := by
      have ea := card_erase_add_one ha
      have eb := card_erase_add_one (mem_erase.mpr ⟨ne.symm,hb⟩ : b ∈ T.erase a)
      dsimp [R]
      omega
    have eu := card_union_le (f a ∪ f b) (R.biUnion f)
    have cu := card_le_card incl
    have qa := eqF a ha
    have qb := eqF b hb
    rcases tCases with t|t <;> rw [t] at fr ctr qa qb <;> norm_num at fr qa qb <;> omega
  have exactD (a : V) (ha : a∈T) :
      DistanceTwo G a = f a ∪ (T.erase a).image (fun b => if G.Adj a b then rep b else b) := by
    obtain ⟨_,R,rfl,cs,ds,sub⟩ := fData a ha
    apply (eq_of_subset_of_card_le sub ?_).symm
    have h := bd a
    rw [card_union_of_disjoint ds,eqF a ha]
    omega
  have joinR (a : V) (ha : a∈T) (b : V) (hb : b∈A) (bt : b∉T) : G.Adj a b := by
    apply Classical.byContradiction
    intro e
    have n : a≠b := fun q=>bt (q ▸ ha)
    have ax := (dist_eq_one_iff_adj.mp (aDepth (TA ha))).symm
    have xb := dist_eq_one_iff_adj.mp (aDepth hb)
    have bb : b ∈ DistanceTwo G a := mem_distanceTwo.mpr (dist_two hc n e ax xb)
    rw [exactD a ha] at bb
    rcases mem_union.mp bb with c|m
    · have q := cDepth (mem_inter.mp c).1
      have r := aDepth hb
      omega
    obtain ⟨i,im,ie⟩ := mem_image.mp m
    have it := (mem_erase.mp im).2
    by_cases ai : G.Adj a i
    · simp only [if_pos ai] at ie
      have z := (prop it).1
      rw [ie] at z
      have w := aDepth hb
      omega
    · simp only [if_neg ai] at ie
      exact bt (ie ▸ it)
  exact ⟨⟨T,rep,TA,tCases,a6,c12,p2lower,by omega,e24,diam,
    eqF,cover,disF,fun a ha => (prop ha).1,fun a ha => (prop ha).2.1,
    fun a ha => (prop ha).2.2.1,fun a ha => (prop ha).2.2.2,exactD,joinR⟩⟩

theorem layer_cover_at_order_twenty_five
    (hc : G.Connected) (cap : ∀ v, (EvenFrom G v).card ≤ 7)
    (conn : ∀ S : Finset V, S.card < 4 → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (x : V) (dx : G.degree x ≤ 6) (n : Fintype.card V = 25) :
    Nonempty (Layer25Cover G x) := by
  classical
  have diam := diameter_bound_from_inner_even_layers hc 6 4 1 cap conn (by decide)
  have exists_three : (Shell G x 3).Nonempty := by
    apply Classical.byContradiction
    intro h
    have h0 := not_nonempty_iff_eq_empty.mp h
    have cov : (Finset.univ : Finset V) ⊆ EvenFrom G x ∪ G.neighborFinset x := by
      intro y _
      have d := diam x y
      by_cases ev : Even (G.dist x y)
      · exact mem_union.mpr (.inl (mem_filter.mpr ⟨mem_univ _,ev⟩))
      by_cases one : G.dist x y=1
      · exact mem_union.mpr (.inr ((G.mem_neighborFinset x y).mpr (dist_eq_one_iff_adj.mp one)))
      have d3 : G.dist x y=3 := by simp only [Nat.even_iff] at ev; omega
      have m := mem_shell.mpr d3
      rw [h0] at m
      have f : False := by simp at m
      exact f.elim
    have q := card_le_card cov
    rw [card_univ] at q
    have r := card_union_le (EvenFrom G x) (G.neighborFinset x)
    rw [G.card_neighborFinset_eq_degree] at r
    have e := cap x
    omega
  obtain ⟨y,ym⟩ := exists_three
  have far : G.dist x y=3 := mem_shell.mp ym
  exact layer_cover_at_order_twenty_five_with_radius_frame hc cap x dx n (diam x)
    (shell_card_of_far hc 4 conn (x:=x) (y:=y) (i:=2) (by decide) (by omega))

#print axioms layer_cover_at_order_twenty_five_with_radius_frame
#print axioms layer_cover_at_order_twenty_five
end Graffiti189LongestPath
