import SixLayer25Cover189
import Mathlib.Logic.Equiv.Fin.Basic
import Mathlib.Data.Fintype.EquivFin

namespace Graffiti189LongestPath
open SimpleGraph Finset
set_option linter.unusedSectionVars false
set_option maxHeartbeats 1100000
variable {V : Type*} {G : SimpleGraph V}
  [Fintype V] [DecidableEq V] [DecidableRel G.Adj]

private noncomputable def indexSet (S : Finset V) (m : ℕ) (h : S.card = m) :
    Fin m ≃ (↑S : Set V) :=
  (Fintype.equivFinOfCardEq ((Fintype.card_coe S).trans h)).symm

private noncomputable def indexPoint (S : Finset V) (m : ℕ) (h : S.card = m)
    (g : 0 < m) (a : V) (ha : a ∈ S) : Fin m ≃ (↑S : Set V) :=
  let e := indexSet S m h
  e.trans (Equiv.swap (e ⟨0,g⟩) ⟨a,ha⟩)

private theorem indexPoint_zero (S : Finset V) (m : ℕ) (h : S.card = m)
    (g : 0 < m) (a : V) (ha : a ∈ S) : (indexPoint S m h g a ha ⟨0,g⟩).val = a := by
  classical
  simp [indexPoint]

private def onChild {α : Type*} (F : α ≃ Fin 12) (h : α → V) (i : Fin 12) : V :=
  h (F.symm i)

private theorem onChild_at {α : Type*} (F : α ≃ Fin 12) (h : α → V) (q : α) (k : ℕ) :
    onChild F h ⟨k+(F q).val-k,by have := (F q).isLt; omega⟩ = h q := by
  have e : (⟨k+(F q).val-k,by have := (F q).isLt; omega⟩ : Fin 12) = F q := by
    apply Fin.ext
    simp
  simp only [onChild,e,Equiv.symm_apply_apply]

/-- Graph-independent numbering of the equality layers, with the
selected vertices, representatives and private witnesses listed first. -/
theorem exists_layer_twenty_five_label (hc : G.Connected) (x : V)
    (n : Fintype.card V = 25) (L : Layer25Cover G x) :
    ∃ e : Fin 25 ≃ V, e 0 = x ∧
    (∀ i, G.dist x (e i) =
      if i.val = 0 then 0 else if i.val < 7 then 1 else
      if i.val < 7+(Shell G x 2).card then 2 else
      if i.val < 19+(Shell G x 2).card then 3 else 4) ∧
    (∀ i, e i ∈ L.T ↔ 1 ≤ i.val ∧ i.val ≤ L.T.card) ∧
    (∀ i j : Fin 25, 1 ≤ i.val → i.val ≤ L.T.card →
        j.val = 6+i.val → e j = L.rep (e i)) ∧
    (∀ i j : Fin 25, 1 ≤ i.val → i.val ≤ L.T.card →
      7+(Shell G x 2).card ≤ j.val → j.val < 19+(Shell G x 2).card →
      (e j ∈ Layer25Group G x (e i) ↔
        (j.val-(7+(Shell G x 2).card))/(7-L.T.card) = i.val-1)) ∧
    (∀ i j : Fin 25, 1 ≤ i.val → i.val ≤ L.T.card →
      j.val = 7+(Shell G x 2).card + (7-L.T.card)*(i.val-1) →
      G.Adj (L.rep (e i)) (e j)) := by
  classical
  let A := Shell G x 1
  let B := Shell G x 2
  let C := Shell G x 3
  let D := Shell G x 4
  let t := L.T.card
  let b := B.card
  let g := 7-t
  have tc : t=3 ∨ t=4 := L.tSize
  have b4 : 4≤b := L.secondMin
  have b6 : b≤6 := L.secondMax
  have t4 : t≤4 := by omega
  have gt : 0<g := by dsimp [g]; omega
  have tg : t*g=12 := by rcases tc with h|h <;> simp [g,h]
  have dZ : D.card=6-b := by have h := L.evenSize; dsimp [b,B,D]; omega
  let aE := indexSet L.T t rfl
  have ac : (A \ L.T).card = 6-t := by
    have s := card_sdiff_add_card_eq_card L.selected
    have h := L.firstSize
    change (A \ L.T).card + L.T.card = A.card at s
    change A.card = 6 at h
    dsimp [t]
    omega
  let aO := indexSet (A \ L.T) (6-t) ac
  let used := L.T.image L.rep
  have um : used ⊆ B := by
    intro v vm
    obtain ⟨a,at',rfl⟩ := mem_image.mp vm
    exact mem_shell.mpr (L.repDepth a at')
  have ui : ∀ a∈L.T, ∀ a'∈L.T, L.rep a = L.rep a' → a=a' := by
    intro a am a' am' eq
    apply Classical.byContradiction
    intro ne
    have h := L.repAdj a am
    rw [eq] at h
    exact L.repPrivate a' am' a am ne h
  have uc : used.card = t := card_image_of_injOn ui
  have bc : (B \ used).card = b-t := by
    have h := card_sdiff_add_card_eq_card um
    dsimp [b]
    omega
  let bO := indexSet (B \ used) (b-t) bc
  let dE := indexSet D (6-b) dZ
  let a (j : Fin t) := (aE j).val
  have am (j : Fin t) : a j ∈ L.T := (aE j).property
  choose wit wit_mem wit_adj using L.repWitness
  let cE (j : Fin t) :=
    indexPoint (Layer25Group G x (a j)) g (L.groupSize (a j) (am j)) gt
      (wit (a j) (am j)) (wit_mem (a j) (am j))
  let flat : Fin t × Fin g ≃ Fin 12 := finProdFinEquiv.trans (finCongr tg)
  have flatVal (j : Fin t) (k : Fin g) : (flat (j,k)).val = k.val+g*j.val := by
    simp [flat,finProdFinEquiv]
  let f (i : Fin 25) : V :=
    if h0 : i.val = 0 then x else
    if h1 : i.val < 1+t then a ⟨i.val-1,by omega⟩ else
    if h2 : i.val < 7 then (aO ⟨i.val-(1+t),by omega⟩).val else
    if h3 : i.val < 7+t then L.rep (a ⟨i.val-7,by omega⟩) else
    if h4 : i.val < 7+b then (bO ⟨i.val-(7+t),by omega⟩).val else
    if h5 : i.val < 19+b then
      onChild flat (fun p => (cE p.1 p.2).val) ⟨i.val-(7+b),by omega⟩
    else (dE ⟨i.val-(19+b),by omega⟩).val
  have atZero : f 0 = x := by simp [f]
  have atA (j : Fin t) : f ⟨1+j.val,by omega⟩ = a j := by
    have k : (⟨1+j.val-1,by omega⟩ : Fin t) = j := by apply Fin.ext; simp only [Fin.val_mk]; omega
    simp only [f,Fin.val_mk,dif_neg (show 1+j.val≠0 by omega),
      dif_pos (show 1+j.val<1+t by omega),k]
  have atAO (j : Fin (6-t)) : f ⟨1+t+j.val,by omega⟩ = (aO j).val := by
    have h := j.isLt
    have k : (⟨1+t+j.val-(1+t),by omega⟩ : Fin (6-t)) = j := by apply Fin.ext; simp only [Fin.val_mk]; omega
    simp only [f,Fin.val_mk,dif_neg (show 1+t+j.val≠0 by omega),
      dif_neg (show ¬ 1+t+j.val<1+t by omega),dif_pos (show 1+t+j.val<7 by omega),k]
  have atB (j : Fin t) : f ⟨7+j.val,by omega⟩ = L.rep (a j) := by
    have h := j.isLt
    have k : (⟨7+j.val-7,by omega⟩ : Fin t) = j := by apply Fin.ext; simp only [Fin.val_mk]; omega
    simp only [f,Fin.val_mk,dif_neg (show 7+j.val≠0 by omega),
      dif_neg (show ¬ 7+j.val<1+t by omega),dif_neg (show ¬ 7+j.val<7 by omega),
      dif_pos (show 7+j.val<7+t by omega),k]
  have atBO (j : Fin (b-t)) : f ⟨7+t+j.val,by omega⟩ = (bO j).val := by
    have h := j.isLt
    have k : (⟨7+t+j.val-(7+t),by omega⟩ : Fin (b-t)) = j := by apply Fin.ext; simp only [Fin.val_mk]; omega
    simp only [f,Fin.val_mk,dif_neg (show 7+t+j.val≠0 by omega),
      dif_neg (show ¬ 7+t+j.val<1+t by omega),dif_neg (show ¬ 7+t+j.val<7 by omega),
      dif_neg (show ¬ 7+t+j.val<7+t by omega),dif_pos (show 7+t+j.val<7+b by omega),k]
  have atC (j : Fin t) (k : Fin g) :
      f ⟨7+b+(flat (j,k)).val,by have h := (flat (j,k)).isLt; omega⟩ = (cE j k).val := by
    let p := (flat (j,k)).val
    have i : p<12 := (flat (j,k)).isLt
    change f ⟨7+b+p,_⟩ = _
    simp only [f,Fin.val_mk,dif_neg (show 7+b+p≠0 by omega),
      dif_neg (show ¬ 7+b+p<1+t by omega), dif_neg (show ¬ 7+b+p<7 by omega),
      dif_neg (show ¬ 7+b+p<7+t by omega),dif_neg (show ¬ 7+b+p<7+b by omega),
      dif_pos (show 7+b+p<19+b by omega)]
    apply onChild_at flat (fun p => (cE p.1 p.2).val) (j,k) (7+b)
  have atD (j : Fin (6-b)) : f ⟨19+b+j.val,by omega⟩ = (dE j).val := by
    have k : (⟨19+b+j.val-(19+b),by omega⟩ : Fin (6-b)) = j := by apply Fin.ext; simp only [Fin.val_mk]; omega
    simp only [f,Fin.val_mk,dif_neg (show 19+b+j.val≠0 by omega),
      dif_neg (show ¬ 19+b+j.val<1+t by omega),dif_neg (show ¬ 19+b+j.val<7 by omega),
      dif_neg (show ¬ 19+b+j.val<7+t by omega),dif_neg (show ¬ 19+b+j.val<7+b by omega),
      dif_neg (show ¬ 19+b+j.val<19+b by omega),k]
  have sur : Function.Surjective f := by
    intro y
    have r := L.radius y
    have eq : G.dist x y=0 ∨ G.dist x y=1 ∨ G.dist x y=2 ∨
      G.dist x y=3 ∨ G.dist x y=4 := by omega
    rcases eq with h|h|h|h|h
    · have e : x=y := (dist_eq_zero_iff_eq_or_not_reachable.mp h).resolve_right
        (not_not.mpr (hc x y))
      exact ⟨0,atZero.trans e⟩
    · have ym : y ∈ A := mem_shell.mpr h
      by_cases yt : y ∈ L.T
      · obtain ⟨j,hj⟩ := aE.surjective ⟨y,yt⟩
        refine ⟨⟨1+j.val,by omega⟩, (atA j).trans ?_⟩
        exact congrArg Subtype.val hj
      have yy : y ∈ A \ L.T := mem_sdiff.mpr ⟨ym,yt⟩
      obtain ⟨j,hj⟩ := aO.surjective ⟨y,yy⟩
      exact ⟨⟨1+t+j.val,by have := j.isLt; omega⟩, (atAO j).trans (congrArg Subtype.val hj)⟩
    · have ym : y ∈ B := mem_shell.mpr h
      by_cases yu : y ∈ used
      · obtain ⟨z,zt,zy⟩ := mem_image.mp yu
        obtain ⟨j,hj⟩ := aE.surjective ⟨z,zt⟩
        have e : a j = z := congrArg Subtype.val hj
        exact ⟨⟨7+j.val,by omega⟩, (atB j).trans (e.symm ▸ zy)⟩
      have yy : y ∈ B \ used := mem_sdiff.mpr ⟨ym,yu⟩
      obtain ⟨j,hj⟩ := bO.surjective ⟨y,yy⟩
      exact ⟨⟨7+t+j.val,by have := j.isLt; omega⟩, (atBO j).trans (congrArg Subtype.val hj)⟩
    · have ym : y ∈ C := mem_shell.mpr h
      obtain ⟨z,zt,zy⟩ := mem_biUnion.mp (L.groupCover ym)
      obtain ⟨j,hj⟩ := aE.surjective ⟨z,zt⟩
      have e : a j = z := congrArg Subtype.val hj
      obtain ⟨k,hk⟩ := (cE j).surjective ⟨y,e.symm ▸ zy⟩
      exact ⟨⟨7+b+(flat (j,k)).val,by have := (flat (j,k)).isLt; omega⟩,
        (atC j k).trans (congrArg Subtype.val hk)⟩
    have ym : y ∈ D := mem_shell.mpr h
    obtain ⟨j,hj⟩ := dE.surjective ⟨y,ym⟩
    exact ⟨⟨19+b+j.val,by have := j.isLt; omega⟩, (atD j).trans (congrArg Subtype.val hj)⟩
  let e : Fin 25 ≃ V := Equiv.ofBijective f
    ((Fintype.bijective_iff_surjective_and_card f).mpr ⟨sur,by simp [n]⟩)
  have depth (i : Fin 25) : G.dist x (e i) =
      if i.val=0 then 0 else if i.val<7 then 1 else if i.val<7+b then 2 else
      if i.val<19+b then 3 else 4 := by
    change G.dist x (f i) = _
    by_cases hi : i.val=0
    · have z : i=0 := Fin.ext hi
      subst i
      simp [atZero,dist_self]
    by_cases h1 : i.val<1+t
    · simp only [f,dif_neg hi,dif_pos h1,if_neg hi,if_pos (show i.val<7 by omega)]
      exact mem_shell.mp (L.selected (am _))
    by_cases h2 : i.val<7
    · simp only [f,dif_neg hi,dif_neg h1,dif_pos h2,if_neg hi,if_pos h2]
      exact mem_shell.mp (mem_sdiff.mp ((aO _).property)).1
    by_cases h3 : i.val<7+t
    · simp only [f,dif_neg hi,dif_neg h1,dif_neg h2,dif_pos h3,if_neg hi,if_neg h2,
        if_pos (show i.val<7+b by omega)]
      exact L.repDepth _ (am _)
    by_cases h4 : i.val<7+b
    · simp only [f,dif_neg hi,dif_neg h1,dif_neg h2,dif_neg h3,dif_pos h4,if_neg hi,if_neg h2,if_pos h4]
      exact mem_shell.mp (mem_sdiff.mp ((bO _).property)).1
    by_cases h5 : i.val<19+b
    · simp only [f,dif_neg hi,dif_neg h1,dif_neg h2,dif_neg h3,dif_neg h4,dif_pos h5,
        if_neg hi,if_neg h2,if_neg h4,if_pos h5,onChild]
      exact mem_shell.mp (mem_inter.mp ((cE _ _).property)).1
    simp only [f,dif_neg hi,dif_neg h1,dif_neg h2,dif_neg h3,dif_neg h4,dif_neg h5,
      if_neg hi,if_neg h2,if_neg h4,if_neg h5]
    exact mem_shell.mp (dE _).property
  have chooseA (i : Fin 25) (p : 1≤i.val) (q : i.val≤t) :
      e i = a ⟨i.val-1,by omega⟩ := by
    change f i = _
    simp only [f,dif_neg (show i.val≠0 by omega),dif_pos (show i.val<1+t by omega)]
  have chooseB (i j : Fin 25) (p : 1≤i.val) (q : i.val≤t) (r : j.val=6+i.val) :
      e j = L.rep (e i) := by
    rw [chooseA i p q]
    change f j = _
    have hi : (⟨j.val-7,by omega⟩ : Fin t) = ⟨i.val-1,by omega⟩ := by apply Fin.ext; simp only [Fin.val_mk]; omega
    simp only [f,dif_neg (show j.val≠0 by omega),dif_neg (show ¬j.val<1+t by omega),
      dif_neg (show ¬j.val<7 by omega),dif_pos (show j.val<7+t by omega)]
    exact congrArg (L.rep ∘ a) hi
  have cAt (j : Fin 25) (p : 7+b≤j.val) (q : j.val<19+b) :
      e j = (cE (flat.symm ⟨j.val-(7+b),by omega⟩).1
        (flat.symm ⟨j.val-(7+b),by omega⟩).2).val := by
    change f j = _
    simp only [f,dif_neg (show j.val≠0 by omega),dif_neg (show ¬j.val<1+t by omega),
      dif_neg (show ¬j.val<7 by omega),dif_neg (show ¬j.val<7+t by omega),
      dif_neg (show ¬j.val<7+b by omega),dif_pos q,onChild]
  have indexC (h : Fin 12) : (flat.symm h).1.val = h.val/g := by
    simp [flat,Fin.coe_divNat,finProdFinEquiv]
  refine ⟨e,atZero,depth,?_,chooseB,?_,?_⟩
  · intro i
    constructor
    · intro hi
      have h := mem_shell.mp (L.selected hi)
      have dep := depth i
      have range : 1≤i.val ∧ i.val<7 := by
        split at dep
        · omega
        split at dep
        · omega
        split at dep
        · omega
        split at dep <;> omega
      apply Classical.byContradiction
      intro no
      change ¬ (1≤i.val ∧ i.val≤t) at no
      have hz : ¬i.val=0 := by omega
      have hl : ¬i.val<1+t := by omega
      change f i ∈ L.T at hi
      simp only [f,dif_neg hz,dif_neg hl,dif_pos range.2] at hi
      exact (mem_sdiff.mp (aO _).property).2 hi
    · rintro ⟨p,q⟩
      rw [chooseA i p q]
      exact am _
  · intro i j pi qi pj qj
    change 7+b≤j.val at pj
    change j.val<19+b at qj
    let ix : Fin t := ⟨i.val-1,by omega⟩
    let h : Fin 12 := ⟨j.val-(7+b),by omega⟩
    let ck := flat.symm h
    have cp : e j ∈ Layer25Group G x (a ck.1) := by
      rw [cAt j pj qj]
      exact (cE ck.1 ck.2).property
    rw [chooseA i pi qi]
    change (e j ∈ Layer25Group G x (a ix) ↔ h.val/g = ix.val)
    rw [← indexC h]
    constructor
    · intro cp'
      apply Classical.byContradiction
      intro neq
      have an : a ix ≠ a ck.1 := by
        intro ae
        apply neq
        have aa : aE ix = aE ck.1 := Subtype.ext ae
        exact congrArg Fin.val (aE.injective aa).symm
      exact disjoint_left.mp (L.groupDisjoint _ (am _) _ (am _) an) cp' cp
    · intro eq
      have eix : ck.1=ix := Fin.ext eq
      exact eix ▸ cp
  · intro i j pi qi pos
    let ix : Fin t := ⟨i.val-1,by omega⟩
    let k : Fin g := ⟨0,gt⟩
    have pj : 7+b+(flat (ix,k)).val < 25 := by have := (flat (ix,k)).isLt; omega
    have ej : j = ⟨7+b+(flat (ix,k)).val,pj⟩ := by
      apply Fin.ext
      change j.val=7+b+(flat (ix,k)).val
      rw [flatVal]
      simpa only [ix,k,Fin.val_mk,Nat.zero_add] using pos
    rw [chooseA i pi qi,ej]
    change G.Adj (L.rep (a ix)) (f _)
    rw [atC]
    simpa only [cE,k,indexPoint_zero] using wit_adj (a ix) (am ix)

#print axioms exists_layer_twenty_five_label
end Graffiti189LongestPath
