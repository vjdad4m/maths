import SixLayer25Cover189
import Equality25Profile189

namespace Graffiti189LongestPath.Equality25Profile
open SimpleGraph SimpleGraph.Walk Finset
open private mem_distanceTwo dist_two distance_on_geodesic from SmallSeparator189
set_option linter.unusedSectionVars false
set_option maxHeartbeats 3500000

variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]

/-- Transfer the exact equality geometry to the finite certificate's
model, without assuming any non-geometric assertion about a graph. -/
theorem model_of_layer_cover
    (hc : G.Connected) (cap : ∀ v, (EvenFrom G v).card ≤ 7)
    (high : ∀ x y : V, x ≠ y → 6 ≤ G.degree x ∨ 6 ≤ G.degree y)
    (x : V) (L : Layer25Cover G x)
    (label : ∀ L : Layer25Cover G x,
    ∃ e : Fin 25 ≃ V, e 0 = x ∧
    (∀ i, G.dist x (e i) =
      if i.val = 0 then 0 else if i.val < 7 then 1 else
      if i.val < 7+(Shell G x 2).card then 2 else
      if i.val < 19+(Shell G x 2).card then 3 else 4) ∧
    (∀ i, e i ∈ L.T ↔ 1 ≤ i.val ∧ i.val ≤ L.T.card) ∧
    (∀ i j : Fin 25, 1 ≤ i.val → i.val ≤ L.T.card →
        j.val = 6+i.val → e j = L.rep (e i)) ∧
    (∀ i j : Fin 25, 1 ≤ i.val → i.val ≤ L.T.card →
      7+(Shell G x 2).card ≤ j.val → j.val < 19+(Shell G x 2).card →
      (e j ∈ Layer25Group G x (e i) ↔
        (j.val-(7+(Shell G x 2).card))/(7-L.T.card) = i.val-1)) ∧
    (∀ i j : Fin 25, 1 ≤ i.val → i.val ≤ L.T.card →
      j.val = 7+(Shell G x 2).card + (7-L.T.card)*(i.val-1) →
      G.Adj (L.rep (e i)) (e j))) :
    ∃ e : Vert ≃ V, ∃ t b : ℕ,
      (t=3 ∨ t=4) ∧ (b=4 ∨ b=5 ∨ b=6) ∧ Model (G.comap e) t b := by
  classical
  obtain ⟨e,e0,depth,sel,reps,groups,witness⟩ := label L
  let t := L.T.card
  let b := (Shell G x 2).card
  have tcase : t=3 ∨ t=4 := L.tSize
  have bmin : 4≤b := L.secondMin
  have bmax : b≤6 := L.secondMax
  have tmax : t≤4 := by omega
  have bcase : b=4 ∨ b=5 ∨ b=6 := by omega
  have sr (i : Vert) : selected t i=true ↔ 1≤i.val ∧ i.val≤t := by simp [selected]
  have mr (i : Vert) : marked t i=true ↔ 7≤i.val ∧ i.val<7+t := by simp [marked]
  have aa (i : Vert) : inA i=true ↔ 1≤i.val ∧ i.val≤6 := by simp [inA]
  have bb (i : Vert) : inB b i=true ↔ 7≤i.val ∧ i.val<7+b := by simp [inB]
  have cc (i : Vert) : inC b i=true ↔ 7+b≤i.val ∧ i.val<19+b := by simp [inC]
  have claimLayer (i : Vert) : G.dist x (e i) = layer b i := by
    rw [depth]
    change (if i.val=0 then 0 else if i.val<7 then 1 else
      if i.val<7+b then 2 else if i.val<19+b then 3 else 4) = layer b i
    simp only [layer,inA,inB,inC,decide_eq_true_eq]
    by_cases h0 : i.val=0
    · exact by simp only [if_pos h0,if_pos (show i=0 by exact Fin.ext h0)]
    have hn : i≠0 := fun h=> h0 (congrArg Fin.val h)
    by_cases a : i.val<7
    · have ar : 1≤i.val ∧ i.val≤6 := by omega
      simp only [if_neg h0,if_neg hn,if_pos a,if_pos ar]
    have an : ¬ (1 ≤ i.val ∧ i.val ≤ 6) := by omega
    by_cases bv : i.val < 7+b
    · have br : 7≤i.val ∧ i.val<7+b := by omega
      simp only [if_neg h0,if_neg hn,if_neg a,if_neg an,if_pos bv,if_pos br]
    have bn : ¬ (7≤i.val ∧ i.val<7+b) := by omega
    by_cases c : i.val<19+b
    · have cr : 7+b≤i.val ∧ i.val<19+b := by omega
      simp only [if_neg h0,if_neg hn,if_neg a,if_neg an,if_neg bv,if_neg bn,if_pos c,if_pos cr]
    have cn : ¬ (7+b≤i.val ∧ i.val<19+b) := by omega
    simp only [if_neg h0,if_neg hn,if_neg a,if_neg an,if_neg bv,if_neg bn,if_neg c,if_neg cn]
  have getSel {i : Vert} (hi : selected t i=true) : e i ∈ L.T :=
    (sel i).mpr ((sr i).mp hi)
  have getMark {i : Vert} (hi : selected t i=true) :
      marked t (markedOf i)=true ∧ e (markedOf i)=L.rep (e i) := by
    obtain ⟨h1,h2⟩ := (sr i).mp hi
    have v : (markedOf i).val = i.val+6 := Nat.mod_eq_of_lt (by omega)
    exact ⟨(mr _).mpr (by omega),reps i _ h1 h2 (by omega)⟩
  have invMark {i : Vert} (hi : marked t i=true) :
      ∃ p : Vert, selected t p=true ∧ p.val=i.val-6 ∧ markedOf p=i := by
    obtain ⟨h1,h2⟩ := (mr i).mp hi
    have v : (vertex (i.val-6)).val=i.val-6 := Nat.mod_eq_of_lt (by omega)
    refine ⟨vertex (i.val-6),(sr _).mpr (by omega),v,?_⟩
    apply Fin.ext
    change ((vertex (i.val-6)).val+6)%25=i.val
    rw [v,Nat.mod_eq_of_lt (by omega)]
    omega
  have atA {i : Vert} (hi : inA i=true) : G.dist x (e i)=1 := by
    obtain ⟨a,d⟩ := (aa i).mp hi
    rw [claimLayer]
    simp only [layer,if_pos hi,if_neg (show i≠0 by intro z; subst i; simp at a)]
  have atB {i : Vert} (hi : inB b i=true) : G.dist x (e i)=2 := by
    obtain ⟨a,d⟩ := (bb i).mp hi
    have na : ¬inA i=true := fun h=>by have := (aa i).mp h; omega
    rw [claimLayer]
    simp only [layer,if_pos hi,if_neg na,if_neg (show i≠0 by intro z; subst i; simp at a)]
  have atC {i : Vert} (hi : inC b i=true) : G.dist x (e i)=3 := by
    obtain ⟨a,d⟩ := (cc i).mp hi
    have na : ¬inA i=true := fun h=>by have := (aa i).mp h; omega
    have nb : ¬inB b i=true := fun h=>by have := (bb i).mp h; omega
    rw [claimLayer]
    simp only [layer,if_pos hi,if_neg na,if_neg nb,if_neg (show i≠0 by
      intro z; subst i; have iz : (0 : Vert).val=0 := rfl; omega)]
  have groupI {i j : Vert} (hi : selected t i=true) (hj : inC b j=true) :
      (e j ∈ Layer25Group G x (e i) ↔ group t b j=i.val-1) := by
    obtain ⟨a,d⟩ := (sr i).mp hi
    obtain ⟨c,f⟩ := (cc j).mp hj
    exact groups i j a d c f
  let H := G.comap e
  have step {i j : Vert} : TwoStep H i j ↔ G.dist (e i) (e j)=2 := by
    constructor
    · rintro ⟨ne,no,k,ik,kj⟩
      exact dist_two hc (fun h => ne (e.injective h)) no ik kj
    · intro d
      have ne : i≠j := by intro eq; rw [eq,dist_self] at d; omega
      have no : ¬ H.Adj i j := by
        intro a
        have h : G.dist (e i) (e j)=1 := dist_eq_one_iff_adj.mpr a
        omega
      obtain ⟨w,hw⟩ := hc.exists_walk_length_eq_dist (e i) (e j)
      have wl : w.length=2 := hw.trans d
      let k := e.symm (w.getVert 1)
      have ek : e k = w.getVert 1 := e.apply_symm_apply _
      have first : G.Adj (e i) (e k) := by
        rw [ek]
        simpa using w.adj_getVert_succ (i:=0) (by omega)
      have second : G.Adj (e k) (e j) := by
        rw [ek]
        have z := w.adj_getVert_succ (i:=1) (by omega)
        have q : w.getVert 2 = e j := by rw [← wl,getVert_length]
        simpa only [q] using z
      exact ⟨ne,no,k,first,second⟩
  have atCrossI {i j : Vert} (hi : selected t i=true) (hj : selected t j=true) :
      e (markedOf j) ∈ DistanceTwo G (e i) → G.Adj (e i) (e j) := by
    intro hm
    have jd := L.repDepth _ (getSel hj)
    rw [(getMark hj).2] at hm
    rw [L.d2Exact _ (getSel hi)] at hm
    rcases mem_union.mp hm with a|a
    · have d : G.dist x (L.rep (e j))=3 := mem_shell.mp (mem_inter.mp a).1
      omega
    obtain ⟨k,km,ke⟩ := mem_image.mp a
    have kt := (mem_erase.mp km).2
    by_cases adj : G.Adj (e i) k
    · simp only [if_pos adj] at ke
      have ek : k=e j := by
        apply Classical.byContradiction
        intro ne
        have q := L.repAdj k kt
        rw [ke] at q
        exact L.repPrivate _ (getSel hj) k kt ne q
      exact ek ▸ adj
    have dd : G.dist x k=1 := mem_shell.mp (L.selected kt)
    simp only [if_neg adj] at ke
    rw [ke] at dd
    omega
  refine ⟨e,t,b,tcase,bcase,?_⟩
  refine ⟨?_,?_,?_,?_,?_⟩
  · intro i j q eq
    unfold forcedAdj at eq
    split at eq
    · simp at eq
    split at eq
    · rename_i iz
      subst i
      have z : inA j=q := Option.some.inj eq
      change G.Adj (e 0) (e j) ↔ q=true
      rw [e0,← dist_eq_one_iff_adj,← z]
      constructor
      · intro d
        have d' := depth j
        have rr : 1≤j.val ∧ j.val≤6 := by
          split at d'
          · omega
          split at d'
          · omega
          split at d'
          · omega
          split at d' <;> omega
        exact (aa j).mpr rr
      · exact atA
    split at eq
    · rename_i far
      have z : false=q := Option.some.inj eq
      rw [← z]
      constructor
      · intro a
        have a' : G.Adj (e i) (e j) := a
        have h := hc.dist_triangle (u:=x) (v:=e i) (w:=e j)
        have d := dist_eq_one_iff_adj.mpr a'
        rw [claimLayer i,claimLayer j,d] at h
        omega
      · intro h
        cases h
    split at eq
    · rename_i yes
      have yy : (selected t i && inA j && !selected t j)=true := by simpa using yes
      have h0 := Bool.and_eq_true_iff.mp yy
      have h1 := Bool.and_eq_true_iff.mp h0.1
      have qj : selected t j≠true := by simpa using h0.2
      have z : true=q := Option.some.inj eq
      rw [←z]
      constructor
      · intro _
        rfl
      · intro _
        exact L.joinRest _ (getSel h1.1) _ (mem_shell.mpr (atA h1.2))
          (fun h => qj ((sr j).mpr ((sel j).mp h)))
    split at eq
    · rename_i yes
      have yy : (selected t i && marked t j)=true := by simpa using yes
      have hy := Bool.and_eq_true_iff.mp yy
      obtain ⟨p,ps,_,rfl⟩ := invMark hy.2
      have z : decide (markedOf p=markedOf i)=q := Option.some.inj eq
      rw [← z,decide_eq_true_eq]
      change G.Adj (e i) (e (markedOf p)) ↔ markedOf p=markedOf i
      rw [(getMark ps).2]
      constructor
      · intro a
        by_cases ip : i=p
        · exact (congrArg markedOf ip).symm
        exact (L.repPrivate _ (getSel ps) _ (getSel hy.1)
          (fun h => ip (e.injective h)) a).elim
      · intro ip
        have v (i : Vert) (h : selected t i=true) :
            (markedOf i).val=i.val+6 := Nat.mod_eq_of_lt (by have := (sr i).mp h; omega)
        have vv := congrArg Fin.val ip
        rw [v _ ps,v _ hy.1] at vv
        have h : p=i := Fin.ext (by omega)
        exact h ▸ L.repAdj _ (getSel ps)
    split at eq
    · rename_i yes
      have yy : (marked t i && inC b j)=true := by simpa using yes
      have hy := Bool.and_eq_true_iff.mp yy
      obtain ⟨p,ps,pv,pi⟩ := invMark hy.1
      have ime : e i=L.rep (e p) := pi ▸ (getMark ps).2
      have pos := (sr p).mp ps
      have val : i.val-7=p.val-1 := by omega
      split at eq
      · rename_i foreign
        have z : false=q := Option.some.inj eq
        rw [← z]
        constructor
        · intro h
          have hp : G.Adj (e p) (e i) := ime.symm ▸ L.repAdj _ (getSel ps)
          have c3 := atC hy.2
          have p1 := mem_shell.mp (L.selected (getSel ps))
          have d : G.dist (e p) (e j)=2 := by
            apply dist_two hc
            · intro ex
              rw [ex] at p1
              omega
            · intro adj
              have ed := dist_eq_one_iff_adj.mpr adj
              have ti := hc.dist_triangle (u:=x) (v:=e p) (w:=e j)
              omega
            · exact hp
            · exact h
          have gm := (groupI ps hy.2).mp
            (mem_inter.mpr ⟨mem_shell.mpr c3,mem_distanceTwo.mpr d⟩)
          exact (foreign (gm.trans val.symm)).elim
        · intro h
          cases h
      rename_i same
      split at eq
      · rename_i pos0
        have z : true=q := Option.some.inj eq
        rw [← z]
        constructor
        · intro _
          rfl
        intro _
        have jp := (cc j).mp hy.2
        have g : group t b j=p.val-1 := (not_not.mp same).trans val
        unfold group at g
        have qd := Nat.mod_add_div (j.val-(7+b)) (7-t)
        rw [pos0,g] at qd
        have jd : j.val=7+b+(7-t)*(p.val-1) := by omega
        change G.Adj (e i) (e j)
        rw [ime]
        exact witness p j pos.1 pos.2 jd
      simp at eq
    simp at eq
  · intro i j q eq
    unfold forcedD2 at eq
    split at eq
    · rename_i h
      have hi : i=0 ∧ inB b j=true := by simpa using h
      have z : true=q := Option.some.inj eq
      rw [←z]
      constructor
      · intro _
        rfl
      · intro _
        apply step.mpr
        rw [hi.1,e0]
        exact atB hi.2
    split at eq
    · rename_i yes
      have hi : selected t i=true := by simpa using yes
      split at eq
      · rename_i cy
        have hj : inC b j=true := by simpa using cy
        have z : decide (group t b j=i.val-1)=q := Option.some.inj eq
        rw [← z,decide_eq_true_eq,step,← groupI hi hj]
        exact ⟨fun h => mem_inter.mpr ⟨mem_shell.mpr (atC hj),mem_distanceTwo.mpr h⟩,
          fun h => mem_distanceTwo.mp (mem_inter.mp h).2⟩
      rename_i cn
      split at eq
      · simp at eq
      rename_i no
      have z : false=q := Option.some.inj eq
      rw [←z]
      constructor
      · intro h
        have d := mem_distanceTwo.mpr (step.mp h)
        rw [L.d2Exact _ (getSel hi)] at d
        rcases mem_union.mp d with a|a
        · have dd : G.dist x (e j)=3 := mem_shell.mp (mem_inter.mp a).1
          have xj : inC b j=true := (cc j).mpr (by
            have dep := depth j
            split at dep
            · omega
            split at dep
            · omega
            split at dep
            · omega
            split at dep <;> omega)
          exact (cn xj).elim
        obtain ⟨p,pm,pe⟩ := mem_image.mp a
        obtain ⟨k,rfl⟩ := e.surjective p
        have kt := (mem_erase.mp pm).2
        have ks : selected t k=true := (sr k).mpr ((sel k).mp kt)
        have ki : k≠i := fun h => (mem_erase.mp pm).1 (congrArg e h)
        by_cases ik : G.Adj (e i) (e k)
        · simp only [if_pos ik] at pe
          have kj : markedOf k=j := e.injective ((getMark ks).2.trans pe)
          have jm : marked t j=true := kj ▸ (getMark ks).1
          have ji : j≠markedOf i := by
            intro ej
            have f := congrArg Fin.val (kj.trans ej)
            have m (a : Vert) (s : selected t a=true) :
                (markedOf a).val=a.val+6 := Nat.mod_eq_of_lt (by have := (sr a).mp s; omega)
            rw [m k ks,m i hi] at f
            exact ki (Fin.ext (by omega))
          have qq : ((selected t j && decide (j≠i)) ||
              (marked t j && decide (j≠markedOf i)))=true := by simp [jm,ji]
          exact (no qq).elim
        simp only [if_neg ik] at pe
        have kj : k=j := e.injective pe
        have js : selected t j=true := kj ▸ ks
        have ji : j≠i := kj ▸ ki
        have rr : ((selected t j && decide (j≠i)) ||
            (marked t j && decide (j≠markedOf i)))=true := by simp [js,ji]
        exact (no rr).elim
      · intro h
        cases h
    simp at eq
  · intro i j hi hj _ d
    exact atCrossI hi hj (mem_distanceTwo.mpr (step.mp d))
  · intro i _
    have c : (Shadow H i).card = (DistanceTwo G (e i)).card := by
      apply card_bij (fun j _ => e j)
      · intro j jm
        exact mem_distanceTwo.mpr (step.mp (mem_filter.mp jm).2)
      · intro a _ b _ ab
        exact e.injective ab
      · intro v vm
        obtain ⟨j,rfl⟩ := e.surjective v
        exact ⟨j,mem_filter.mpr ⟨mem_univ _,step.mpr (mem_distanceTwo.mp vm)⟩,rfl⟩
    rw [c]
    exact distanceTwo_le_of_even 6 _ (cap _)
  · intro i j _ _ ne
    have deg (v : Vert) : H.degree v = G.degree (e v) := by
      rw [← H.card_neighborFinset_eq_degree,← G.card_neighborFinset_eq_degree]
      apply card_bij (fun j _ => e j)
      · intro j jm
        exact (G.mem_neighborFinset _ _).mpr ((H.mem_neighborFinset _ _).mp jm)
      · intro a _ b _ ab
        exact e.injective ab
      · intro v' vm
        obtain ⟨j,rfl⟩ := e.surjective v'
        exact ⟨j,(H.mem_neighborFinset _ _).mpr ((G.mem_neighborFinset _ _).mp vm),rfl⟩
    change 6≤H.degree i ∨ 6≤H.degree j
    rw [deg,deg]
    exact high _ _ (fun h => ne (e.injective h))

theorem model_at_order_twenty_five_with_radius_frame
    (hc : G.Connected) (cap : ∀ v, (EvenFrom G v).card ≤ 7)
    (high : ∀ x y : V, x ≠ y → 6 ≤ G.degree x ∨ 6 ≤ G.degree y)
    (x : V) (dx : G.degree x ≤ 6) (n : Fintype.card V = 25)
    (radius : ∀ y, G.dist x y ≤ 4) (b4 : 4 ≤ (Shell G x 2).card)
    (label : ∀ L : Layer25Cover G x,
    ∃ e : Fin 25 ≃ V, e 0 = x ∧
    (∀ i, G.dist x (e i) =
      if i.val = 0 then 0 else if i.val < 7 then 1 else
      if i.val < 7+(Shell G x 2).card then 2 else
      if i.val < 19+(Shell G x 2).card then 3 else 4) ∧
    (∀ i, e i ∈ L.T ↔ 1 ≤ i.val ∧ i.val ≤ L.T.card) ∧
    (∀ i j : Fin 25, 1 ≤ i.val → i.val ≤ L.T.card →
        j.val = 6+i.val → e j = L.rep (e i)) ∧
    (∀ i j : Fin 25, 1 ≤ i.val → i.val ≤ L.T.card →
      7+(Shell G x 2).card ≤ j.val → j.val < 19+(Shell G x 2).card →
      (e j ∈ Layer25Group G x (e i) ↔
        (j.val-(7+(Shell G x 2).card))/(7-L.T.card) = i.val-1)) ∧
    (∀ i j : Fin 25, 1 ≤ i.val → i.val ≤ L.T.card →
      j.val = 7+(Shell G x 2).card + (7-L.T.card)*(i.val-1) →
      G.Adj (L.rep (e i)) (e j))) :
    ∃ e : Vert ≃ V, ∃ t b : ℕ,
      (t=3 ∨ t=4) ∧ (b=4 ∨ b=5 ∨ b=6) ∧ Model (G.comap e) t b := by
  obtain ⟨L⟩ := layer_cover_at_order_twenty_five_with_radius_frame hc cap x dx n radius b4
  exact model_of_layer_cover hc cap high x L label

theorem model_at_order_twenty_five_of_label
    (hc : G.Connected) (cap : ∀ v, (EvenFrom G v).card ≤ 7)
    (conn : ∀ S : Finset V, S.card < 4 → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (high : ∀ x y : V, x ≠ y → 6 ≤ G.degree x ∨ 6 ≤ G.degree y)
    (x : V) (dx : G.degree x ≤ 6) (n : Fintype.card V = 25)
    (label : ∀ L : Layer25Cover G x,
    ∃ e : Fin 25 ≃ V, e 0 = x ∧
    (∀ i, G.dist x (e i) =
      if i.val = 0 then 0 else if i.val < 7 then 1 else
      if i.val < 7+(Shell G x 2).card then 2 else
      if i.val < 19+(Shell G x 2).card then 3 else 4) ∧
    (∀ i, e i ∈ L.T ↔ 1 ≤ i.val ∧ i.val ≤ L.T.card) ∧
    (∀ i j : Fin 25, 1 ≤ i.val → i.val ≤ L.T.card →
        j.val = 6+i.val → e j = L.rep (e i)) ∧
    (∀ i j : Fin 25, 1 ≤ i.val → i.val ≤ L.T.card →
      7+(Shell G x 2).card ≤ j.val → j.val < 19+(Shell G x 2).card →
      (e j ∈ Layer25Group G x (e i) ↔
        (j.val-(7+(Shell G x 2).card))/(7-L.T.card) = i.val-1)) ∧
    (∀ i j : Fin 25, 1 ≤ i.val → i.val ≤ L.T.card →
      j.val = 7+(Shell G x 2).card + (7-L.T.card)*(i.val-1) →
      G.Adj (L.rep (e i)) (e j))) :
    ∃ e : Vert ≃ V, ∃ t b : ℕ,
      (t=3 ∨ t=4) ∧ (b=4 ∨ b=5 ∨ b=6) ∧ Model (G.comap e) t b := by
  obtain ⟨L⟩ := layer_cover_at_order_twenty_five hc cap conn x dx n
  exact model_of_layer_cover hc cap high x L label

#print axioms model_at_order_twenty_five_with_radius_frame
#print axioms model_at_order_twenty_five_of_label
end Graffiti189LongestPath.Equality25Profile
