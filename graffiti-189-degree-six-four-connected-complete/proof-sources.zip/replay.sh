#!/usr/bin/env bash
set -euo pipefail
r="$(cd "$(dirname "$0")" && pwd)"
cd "$r"
sha256sum -c SOURCES.sha256
export LEAN_PATH="${LEAN_PATH:-}"
out="$(mktemp -d)"
trap 'rm -rf "$out"' EXIT
export LEAN_PATH="$out:$LEAN_PATH"
opts=(-j1 -s65536 -DElab.async=false -DwarningAsError=true)
while IFS= read -r mod; do
  (cd certificates && lean "${opts[@]}" --root="$r/certificates" -o "$out/$mod.olean" "$mod.lean")
done < certificates/MODULES.txt
for mod in SixLayer25Cover189 SixLayer25Label189 SixLayer25Model189 SixFourComplete189; do
  (cd graph && lean "${opts[@]}" --root="$r/graph" -o "$out/$mod.olean" "$mod.lean")
done
