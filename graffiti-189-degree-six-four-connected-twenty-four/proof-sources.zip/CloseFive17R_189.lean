import FivePinLayout17R_189
import FiveEdgeLayout17R_189
import FiveMidSplice17R_189

open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack
open Graffiti189LongestPath.Normalize Graffiti189LongestPath.FiveCheapBudget17R
set_option linter.unusedSectionVars false
set_option maxHeartbeats 30000000
namespace Graffiti189LongestPath.CloseFive17R
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem no_five (hc : G.Connected) (k : ℕ) (hk : k=4)
    (cap : ∀ v,(EvenFrom G v).card≤k+3)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S:Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → k+2≤G.degree u ∨ k+2≤G.degree v)
    {a b : V} {p : G.Walk a b} (hp : IsLongest p) (hMin : EdgeMinAvoid (k+2) p)
    (C : OmittedComponent p) (h5 : C.vertices.card=5) (plen : p.length=17)
    (da : k+2≤G.degree a) (db : k+2≤G.degree b)
    (few : ∀ z∈C.vertices,(Pins p z).card≤2)
    (low : ∀ z∈C.vertices,k+2-2≤G.degree z) : False := by
  classical
  obtain ⟨z,w,i,j,s,t,A,pins⟩ := FivePinLayout17R.exists_layout hc k hk cap conn deg hp hMin C h5 plen few low
  have c6 : ∀ v, (DistanceTwo G v).card≤6 := by
    intro v
    exact (distanceTwo_le_of_even (k+2) v (cap v)).trans (by omega)
  have d6 : ∀ u v : V,u≠v → 6≤G.degree u ∨ 6≤G.degree v := by
    intro u v uv
    simpa only [hk] using deg u v uv
  rcases A.shape with ⟨rfl,rfl,rfl,rfl⟩|⟨rfl,rfl,rfl,rfl⟩|⟨rfl,rfl,rfl,rfl⟩
  · exact (Nat.not_le_of_lt (show 5<G.degree a by omega)) (FiveEdgeLayout17R.left A hc hp c6)
  · have noH : ∀ i∈({6,8,9,11}:Finset ℕ),∀ z∈C.vertices,¬G.Adj (p.getVert i) z := by
      intro m mm z zh ed
      have hml : m<17 := by simp at mm; omega
      have pin : m∈Pins p z := mem_filter.mpr ⟨mem_range.mpr (by omega),ed.symm⟩
      have can := pins z zh m pin
      simp only [mem_insert,mem_singleton] at mm can
      omega
    exact (d6 _ _ (distinct_get A hp (show 7≤17 by decide) (show 10≤17 by decide) (by decide))).elim
      (FiveMidSplice17R.left A hc hp c6 noH d6) (FiveMidSplice17R.right A hc hp c6 noH d6)
  · exact (Nat.not_le_of_lt (show 5<G.degree b by omega)) (FiveEdgeLayout17R.right A hc hp c6)

#print axioms no_five
end Graffiti189LongestPath.CloseFive17R
