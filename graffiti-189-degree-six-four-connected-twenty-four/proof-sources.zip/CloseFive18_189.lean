import FivePinLayout18_189
import FiveEdgeLayout18_189
import FiveMidSplice18L4_189
import FiveMidSplice18L5_189
import FiveMidSplice18L7_189
import FiveMidSplice18L10_189
import FiveMidSplice18L12_189
import FiveMidSplice18L13_189
import FiveGapFour18_189

open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack
open Graffiti189LongestPath.Normalize Graffiti189LongestPath.FiveCheapBudget18
set_option linter.unusedSectionVars false
set_option maxHeartbeats 30000000
namespace Graffiti189LongestPath.CloseFive18
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem no_five (hc : G.Connected) (k : ℕ) (hk : k=4)
    (cap : ∀ v,(EvenFrom G v).card≤k+3)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S:Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → k+2≤G.degree u ∨ k+2≤G.degree v)
    {a b : V} {p : G.Walk a b} (hp : IsLongest p) (hMin : EdgeMinAvoid (k+2) p)
    (C : OmittedComponent p) (h5 : C.vertices.card=5) (plen : p.length=18)
    (da : k+2≤G.degree a) (db : k+2≤G.degree b)
    (few : ∀ z∈C.vertices,(Pins p z).card≤2)
    (low : ∀ z∈C.vertices,k+2-2≤G.degree z) : False := by
  classical
  obtain ⟨z,w,i,j,s,t,A,pins⟩ := FivePinLayout18.exists_layout hc k hk cap conn deg hp hMin C h5 plen few low
  have c6 : ∀ v, (DistanceTwo G v).card≤6 := by
    intro v
    exact (distanceTwo_le_of_even (k+2) v (cap v)).trans (by omega)
  have d6 : ∀ u v : V,u≠v → 6≤G.degree u ∨ 6≤G.degree v := by
    intro u v uv
    simpa only [hk] using deg u v uv
  rcases A.shape with ⟨rfl,rfl,rfl,rfl⟩|⟨rfl,rfl,rfl,rfl⟩|⟨rfl,rfl,rfl,rfl⟩|⟨rfl,rfl,rfl,rfl⟩|⟨rfl,rfl,rfl,rfl⟩|⟨rfl,rfl,rfl,rfl⟩|⟨rfl,rfl,rfl,rfl⟩|⟨rfl,rfl,rfl,rfl⟩|⟨rfl,rfl,rfl,rfl⟩|⟨rfl,rfl,rfl,rfl⟩|⟨rfl,rfl,rfl,rfl⟩|⟨rfl,rfl,rfl,rfl⟩|⟨rfl,rfl,rfl,rfl⟩|⟨rfl,rfl,rfl,rfl⟩|⟨rfl,rfl,rfl,rfl⟩
  · exact (Nat.not_le_of_lt (show 5<G.degree a by omega)) (FiveEdgeLayout18.layout_0 A hc hp c6)
  · exact (Nat.not_le_of_lt (show 5<G.degree a by omega)) (FiveEdgeLayout18.layout_1 A hc hp c6)
  · exact (Nat.not_le_of_lt (show 5<G.degree a by omega)) (FiveEdgeLayout18.layout_2 A hc hp c6)
  · exact (Nat.not_le_of_lt (show 5<G.degree a by omega)) (FiveEdgeLayout18.layout_3 A hc hp c6)
  · have noH : ∀ i∈({6,8,9,11}:Finset ℕ),∀ z∈C.vertices,¬G.Adj (p.getVert i) z := by
      intro m mm z zh ed
      have hml : m<18 := by simp at mm; omega
      have pin : m∈Pins p z := mem_filter.mpr ⟨mem_range.mpr (by omega),ed.symm⟩
      have can := pins z zh m pin
      simp only [mem_insert,mem_singleton] at mm can
      omega
    exact (d6 _ _ (distinct_get A hp (show 7≤18 by decide) (show 10≤18 by decide) (by decide))).elim
      (FiveMidSplice18L4.left A hc hp c6 noH d6) (FiveMidSplice18L4.right A hc hp c6 noH d6)
  · have noH : ∀ i∈({6,8,9,11}:Finset ℕ),∀ z∈C.vertices,¬G.Adj (p.getVert i) z := by
      intro m mm z zh ed
      have hml : m<18 := by simp at mm; omega
      have pin : m∈Pins p z := mem_filter.mpr ⟨mem_range.mpr (by omega),ed.symm⟩
      have can := pins z zh m pin
      simp only [mem_insert,mem_singleton] at mm can
      omega
    exact (d6 _ _ (distinct_get A hp (show 7≤18 by decide) (show 10≤18 by decide) (by decide))).elim
      (FiveMidSplice18L5.left A hc hp c6 noH d6) (FiveMidSplice18L5.right A hc hp c6 noH d6)
  · exact FiveGapFour18.no_gap_four A hc hp c6 d6
  · have noH : ∀ i∈({12,14,15,17}:Finset ℕ),∀ z∈C.vertices,¬G.Adj (p.getVert i) z := by
      intro m mm z zh ed
      have hml : m<18 := by simp at mm; omega
      have pin : m∈Pins p z := mem_filter.mpr ⟨mem_range.mpr (by omega),ed.symm⟩
      have can := pins z zh m pin
      simp only [mem_insert,mem_singleton] at mm can
      omega
    exact (d6 _ _ (distinct_get A hp (show 13≤18 by decide) (show 16≤18 by decide) (by decide))).elim
      (FiveMidSplice18L7.left A hc hp c6 noH d6) (FiveMidSplice18L7.right A hc hp c6 noH d6)
  · exact (Nat.not_le_of_lt (show 5<G.degree b by omega)) (FiveEdgeLayout18.layout_8 A hc hp c6)
  · exact (Nat.not_le_of_lt (show 5<G.degree b by omega)) (FiveEdgeLayout18.layout_9 A hc hp c6)
  · have noH : ∀ i∈({7,9,10,12}:Finset ℕ),∀ z∈C.vertices,¬G.Adj (p.getVert i) z := by
      intro m mm z zh ed
      have hml : m<18 := by simp at mm; omega
      have pin : m∈Pins p z := mem_filter.mpr ⟨mem_range.mpr (by omega),ed.symm⟩
      have can := pins z zh m pin
      simp only [mem_insert,mem_singleton] at mm can
      omega
    exact (d6 _ _ (distinct_get A hp (show 8≤18 by decide) (show 11≤18 by decide) (by decide))).elim
      (FiveMidSplice18L10.left A hc hp c6 noH d6) (FiveMidSplice18L10.right A hc hp c6 noH d6)
  · exact (Nat.not_le_of_lt (show 5<G.degree b by omega)) (FiveEdgeLayout18.layout_11 A hc hp c6)
  · have noH : ∀ i∈({1,3,4,6}:Finset ℕ),∀ z∈C.vertices,¬G.Adj (p.getVert i) z := by
      intro m mm z zh ed
      have hml : m<18 := by simp at mm; omega
      have pin : m∈Pins p z := mem_filter.mpr ⟨mem_range.mpr (by omega),ed.symm⟩
      have can := pins z zh m pin
      simp only [mem_insert,mem_singleton] at mm can
      omega
    exact (d6 _ _ (distinct_get A hp (show 2≤18 by decide) (show 5≤18 by decide) (by decide))).elim
      (FiveMidSplice18L12.left A hc hp c6 noH d6) (FiveMidSplice18L12.right A hc hp c6 noH d6)
  · have noH : ∀ i∈({7,9,10,12}:Finset ℕ),∀ z∈C.vertices,¬G.Adj (p.getVert i) z := by
      intro m mm z zh ed
      have hml : m<18 := by simp at mm; omega
      have pin : m∈Pins p z := mem_filter.mpr ⟨mem_range.mpr (by omega),ed.symm⟩
      have can := pins z zh m pin
      simp only [mem_insert,mem_singleton] at mm can
      omega
    exact (d6 _ _ (distinct_get A hp (show 8≤18 by decide) (show 11≤18 by decide) (by decide))).elim
      (FiveMidSplice18L13.left A hc hp c6 noH d6) (FiveMidSplice18L13.right A hc hp c6 noH d6)
  · exact (Nat.not_le_of_lt (show 5<G.degree b by omega)) (FiveEdgeLayout18.layout_14 A hc hp c6)

#print axioms no_five
end Graffiti189LongestPath.CloseFive18
