import DenseInsideCharges189

open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack Graffiti189LongestPath.DenseInsideCharges
open private Graffiti189LongestPath.mem_distanceTwo Graffiti189LongestPath.dist_two from SmallSeparator189
set_option linter.unusedSectionVars false
set_option maxHeartbeats 15000000
namespace Graffiti189LongestPath.DenseEndpointBudget
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem endpoint (hc : G.Connected) (H F U : Finset V) (x m e : V)
    (xh : x∈H) (xm : G.Adj x m) (mh : m∉H) (me : G.Adj m e)
    (owns : ∀ v∈H,G.Adj m v → v=x)
    (eH : ∀ v∈H, ¬G.Adj e v)
    (fm : F⊆DistanceTwo G x) (fd : Disjoint F H) (fc : F.card=4)
    (mu : m∈U) (uc : U.card≤3)
    (known : ∀ v,G.Adj e v → G.Adj m v → (G.Adj x v ∨ v∈F) → v∈U)
    (cap : ∀ v,(DistanceTwo G v).card≤6)
    (inside : 6≤(inner G H x).card+(DistanceTwo G x∩H).card) :
    G.degree e≤5 := by
  classical
  let R := DistanceTwo G m\H
  let T := DistanceTwo G x∩H
  let J := DistanceTwo G x\(H∪F)
  let N := inner G H x
  have n2 : N⊆DistanceTwo G m := by
    intro v hv
    obtain ⟨vh,xv⟩ := mem_filter.mp hv
    exact Graffiti189LongestPath.mem_distanceTwo.mpr
      (Graffiti189LongestPath.dist_two hc (fun e => mh (e.symm ▸ vh))
        (fun h => xv.ne (owns v vh h).symm) xm.symm xv)
  have jd : Disjoint F T :=
    disjoint_left.mpr (fun _ ff tt => disjoint_left.mp fd ff (mem_inter.mp tt).2)
  have jk : Disjoint (F∪T) J := by
    refine disjoint_left.mpr (fun _ a b => (mem_sdiff.mp b).2 ?_)
    exact (mem_union.mp a).elim (mem_union_right _) (fun q => mem_union_left _ (mem_inter.mp q).2)
  have s : (F∪T)∪J⊆DistanceTwo G x :=
    union_subset (union_subset fm inter_subset_left) sdiff_subset
  have c := (card_le_card s).trans (cap x)
  rw [card_union_of_disjoint jk,card_union_of_disjoint jd,fc] at c
  have rn : Disjoint N R := disjoint_left.mpr (fun _ nn rr =>
    (mem_sdiff.mp rr).2 (mem_filter.mp nn).1)
  have sub : N∪R⊆DistanceTwo G m := union_subset n2 sdiff_subset
  have bb := (card_le_card sub).trans (cap m)
  rw [card_union_of_disjoint rn] at bb
  have sum : J.card+R.card≤2 := by
    change 6≤N.card+T.card at inside
    omega
  have cover : G.neighborFinset e⊆U∪(J∪R) := by
    intro v hv
    have ev := (G.mem_neighborFinset e v).mp hv
    by_cases eq : v=m
    · exact mem_union_left _ (eq.symm ▸ mu)
    by_cases mv : G.Adj m v
    · by_cases k : G.Adj x v ∨ v∈F
      · exact mem_union_left _ (known v ev mv k)
      · have ne : x≠v := fun eq => eH x xh (eq.symm ▸ ev)
        have dt := Graffiti189LongestPath.mem_distanceTwo.mpr
          (Graffiti189LongestPath.dist_two hc ne (fun h => k (Or.inl h)) xm mv)
        exact mem_union_right _ (mem_union_left _
          (mem_sdiff.mpr ⟨dt,fun e => (mem_union.mp e).elim
            (fun h => eH v h ev) (fun h => k (Or.inr h))⟩))
    · have dt := Graffiti189LongestPath.mem_distanceTwo.mpr
        (Graffiti189LongestPath.dist_two hc (fun e => eq e.symm) mv me ev)
      exact mem_union_right _ (mem_union_right _ (mem_sdiff.mpr ⟨dt,fun h => eH v h ev⟩))
  have q := (card_le_card cover).trans (card_union_le U (J∪R))
  rw [G.card_neighborFinset_eq_degree] at q
  have q2 := card_union_le J R
  omega

#print axioms endpoint
end Graffiti189LongestPath.DenseEndpointBudget
