import DenseEndpointBudget189

open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack
open Graffiti189LongestPath.DenseInsideCharges Graffiti189LongestPath.DenseEndpointBudget
open private Graffiti189LongestPath.pin_data Graffiti189LongestPath.no_endpoints from SmallSeparator189
open private Graffiti189LongestPath.OneSlack.pin_of_neighbor_mem from OneSlack189
set_option linter.unusedSectionVars false
set_option maxHeartbeats 15000000
namespace Graffiti189LongestPath.DenseEndpointLayout
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

private theorem outer {a b x e : V} {p : G.Walk a b} {H : Finset V}
    (hc : G.Connected) (hp : IsLongest p) (off : ∀ v∈H,v∉p.support) (xh : x∈H)
    (cap : ∀ v,(DistanceTwo G v).card≤6)
    (inside : 6≤(inner G H x).card+(DistanceTwo G x∩H).card)
    (ends : e=a ∨ e=b) {m n f₁ f₂ f₃ f₄ : ℕ}
    (pins : Pins p x={m,n})
    (own : ∀ v∈H,m∈Pins p v → v=x)
    (adj : G.Adj (p.getVert m) e)
    (f : FlankVertices p x={p.getVert f₁,p.getVert f₂,p.getVert f₃,p.getVert f₄})
    (size : (FlankVertices p x).card=4)
    (a₁ : p.getVert f₁=e)
    (a₂ : ¬G.Adj e (p.getVert f₂))
    (a₄ : ¬G.Adj e (p.getVert f₄)) :
    G.degree e≤5 := by
  classical
  let U : Finset V := {p.getVert m,p.getVert n,p.getVert f₃}
  have xm : m∈Pins p x := pins.symm ▸ mem_insert_self _ _
  have owns : ∀ v∈H,G.Adj (p.getVert m) v → v=x := by
    intro v vh vv
    exact own v vh (mem_filter.mpr ⟨mem_range.mpr (Graffiti189LongestPath.pin_data xm).1,vv.symm⟩)
  have eOff {v : V} (vo : v∉p.support) : ¬G.Adj e v := fun h =>
    ends.elim (fun ea => (Graffiti189LongestPath.no_endpoints hp vo).1 (ea ▸ h).symm)
      (fun eb => (Graffiti189LongestPath.no_endpoints hp vo).2 (eb ▸ h).symm)
  refine endpoint hc H (FlankVertices p x) U x (p.getVert m) e xh (Graffiti189LongestPath.pin_data xm).2
    (fun h => off _ h (p.getVert_mem_support _)) adj owns (fun v hv => eOff (off v hv)) ?_ ?_ size
    (by simp [U]) ?_ ?_ cap inside
  · intro v vh
    exact (mem_sdiff.mp (flanks_outside_boundary hc hp (off x xh) vh)).1
  · refine disjoint_left.mpr (fun v vf vh => off _ vh ?_)
    obtain ⟨i,_,rfl⟩ := mem_image.mp vf
    exact p.getVert_mem_support i
  · have h := card_insert_le (p.getVert m) ({p.getVert n,p.getVert f₃}:Finset V)
    have q := card_insert_le (p.getVert n) ({p.getVert f₃}:Finset V)
    rw [card_singleton] at q
    dsimp [U]
    omega
  · intro v ev _ h
    rcases h with xv|vf
    · have vp : v∈p.support := Classical.byContradiction (fun no => eOff no ev)
      obtain ⟨i,ip,eq⟩ := Graffiti189LongestPath.OneSlack.pin_of_neighbor_mem hp (off x xh) vp xv
      rw [pins] at ip
      simp only [mem_insert,mem_singleton] at ip
      rcases ip with rfl|rfl
      · exact eq ▸ mem_insert_self _ _
      · exact eq ▸ mem_insert_of_mem (mem_insert_self _ _)
    · rw [f] at vf
      simp only [mem_insert,mem_singleton] at vf
      rcases vf with rfl|rfl|rfl|rfl
      · exact (G.irrefl (a₁ ▸ ev)).elim
      · exact (a₂ ev).elim
      · exact mem_insert_of_mem (mem_insert_of_mem (mem_singleton_self _))
      · exact (a₄ ev).elim

theorem left15 {a b x : V} {p : G.Walk a b} {H : Finset V}
    (hc : G.Connected) (hp : IsLongest p) (off : ∀ v∈H,v∉p.support) (xh : x∈H)
    (cap : ∀ v,(DistanceTwo G v).card≤6)
    (inside : 6≤(inner G H x).card+(DistanceTwo G x∩H).card)
    (plen : p.length=15) (pins : Pins p x={1,4})
    (own : ∀ v∈H,1∈Pins p v → v=x) : G.degree a≤5 := by
  have af : p.getVert 0=a := by simp
  have adj : G.Adj (p.getVert 1) a := by
    have p₀ := (p.adj_getVert_succ (i:=0) (by omega)).symm
    simpa only [af] using p₀
  have mP : 1∈Pins p x := pins.symm ▸ mem_insert_self _ _
  have nP : 4∈Pins p x := pins.symm ▸ mem_insert_of_mem (mem_singleton_self _)
  have fl : FlankVertices p x={p.getVert 0,p.getVert 2,p.getVert 3,p.getVert 5} := by
    ext z
    simp only [FlankVertices, FlankIndices, pins, Finset.image_union, Finset.image_insert, Finset.image_singleton, mem_union, mem_insert, mem_singleton]
    change (z=p.getVert 0 ∨ z=p.getVert 3) ∨ (z=p.getVert 2 ∨ z=p.getVert 5) ↔ _
    tauto
  have ne (i j : ℕ) (hi : i≤15) (hj : j≤15) (ij : i≠j) : p.getVert i≠p.getVert j :=
    fun e => ij (hp.1.getVert_injOn (plen.symm ▸ hi) (plen.symm ▸ hj) e)
  have na : p.getVert 0∉({p.getVert 2,p.getVert 3,p.getVert 5}:Finset V) := by
    simp only [mem_insert,mem_singleton,not_or]
    exact ⟨ne _ _ (by decide) (by decide) (by decide),
      ne _ _ (by decide) (by decide) (by decide),
      ne _ _ (by decide) (by decide) (by decide)⟩
  have nb : p.getVert 2∉({p.getVert 3,p.getVert 5}:Finset V) := by
    simp only [mem_insert,mem_singleton,not_or]
    exact ⟨ne _ _ (by decide) (by decide) (by decide), ne _ _ (by decide) (by decide) (by decide)⟩
  have nc : p.getVert 3∉({p.getVert 5}:Finset V) := by
    simpa only [mem_singleton] using ne 3 5 (by decide) (by decide) (by decide)
  have fc : (FlankVertices p x).card=4 := by
    rw [fl,card_insert_of_not_mem na,card_insert_of_not_mem nb,card_insert_of_not_mem nc,card_singleton]
  exact outer hc hp off xh cap inside (Or.inl rfl) pins own adj fl fc af
    (start_not_adj_pin_successor hp (off _ xh) mP) (start_not_adj_pin_successor hp (off _ xh) nP)

#print axioms left15
theorem right15 {a b x : V} {p : G.Walk a b} {H : Finset V}
    (hc : G.Connected) (hp : IsLongest p) (off : ∀ v∈H,v∉p.support) (xh : x∈H)
    (cap : ∀ v,(DistanceTwo G v).card≤6)
    (inside : 6≤(inner G H x).card+(DistanceTwo G x∩H).card)
    (plen : p.length=15) (pins : Pins p x={14,11})
    (own : ∀ v∈H,14∈Pins p v → v=x) : G.degree b≤5 := by
  have af : p.getVert 15=b := by rw [←plen,Walk.getVert_length]
  have adj : G.Adj (p.getVert 14) b := by
    have p₀ := (p.adj_getVert_succ (i:=14) (by omega))
    simpa only [af] using p₀
  have mP : 14∈Pins p x := pins.symm ▸ mem_insert_self _ _
  have nP : 11∈Pins p x := pins.symm ▸ mem_insert_of_mem (mem_singleton_self _)
  have fl : FlankVertices p x={p.getVert 15,p.getVert 13,p.getVert 12,p.getVert 10} := by
    ext z
    simp only [FlankVertices, FlankIndices, pins, Finset.image_union, Finset.image_insert, Finset.image_singleton, mem_union, mem_insert, mem_singleton]
    change (z=p.getVert 13 ∨ z=p.getVert 10) ∨ (z=p.getVert 15 ∨ z=p.getVert 12) ↔ _
    tauto
  have ne (i j : ℕ) (hi : i≤15) (hj : j≤15) (ij : i≠j) : p.getVert i≠p.getVert j :=
    fun e => ij (hp.1.getVert_injOn (plen.symm ▸ hi) (plen.symm ▸ hj) e)
  have na : p.getVert 15∉({p.getVert 13,p.getVert 12,p.getVert 10}:Finset V) := by
    simp only [mem_insert,mem_singleton,not_or]
    exact ⟨ne _ _ (by decide) (by decide) (by decide),
      ne _ _ (by decide) (by decide) (by decide),
      ne _ _ (by decide) (by decide) (by decide)⟩
  have nb : p.getVert 13∉({p.getVert 12,p.getVert 10}:Finset V) := by
    simp only [mem_insert,mem_singleton,not_or]
    exact ⟨ne _ _ (by decide) (by decide) (by decide), ne _ _ (by decide) (by decide) (by decide)⟩
  have nc : p.getVert 12∉({p.getVert 10}:Finset V) := by
    simpa only [mem_singleton] using ne 12 10 (by decide) (by decide) (by decide)
  have fc : (FlankVertices p x).card=4 := by
    rw [fl,card_insert_of_not_mem na,card_insert_of_not_mem nb,card_insert_of_not_mem nc,card_singleton]
  exact outer hc hp off xh cap inside (Or.inr rfl) pins own adj fl fc af
    (end_not_adj_pin_predecessor hp (off _ xh) mP) (end_not_adj_pin_predecessor hp (off _ xh) nP)

#print axioms right15
theorem left16 {a b x : V} {p : G.Walk a b} {H : Finset V}
    (hc : G.Connected) (hp : IsLongest p) (off : ∀ v∈H,v∉p.support) (xh : x∈H)
    (cap : ∀ v,(DistanceTwo G v).card≤6)
    (inside : 6≤(inner G H x).card+(DistanceTwo G x∩H).card)
    (plen : p.length=16) (pins : Pins p x={1,4})
    (own : ∀ v∈H,1∈Pins p v → v=x) : G.degree a≤5 := by
  have af : p.getVert 0=a := by simp
  have adj : G.Adj (p.getVert 1) a := by
    have p₀ := (p.adj_getVert_succ (i:=0) (by omega)).symm
    simpa only [af] using p₀
  have mP : 1∈Pins p x := pins.symm ▸ mem_insert_self _ _
  have nP : 4∈Pins p x := pins.symm ▸ mem_insert_of_mem (mem_singleton_self _)
  have fl : FlankVertices p x={p.getVert 0,p.getVert 2,p.getVert 3,p.getVert 5} := by
    ext z
    simp only [FlankVertices, FlankIndices, pins, Finset.image_union, Finset.image_insert, Finset.image_singleton, mem_union, mem_insert, mem_singleton]
    change (z=p.getVert 0 ∨ z=p.getVert 3) ∨ (z=p.getVert 2 ∨ z=p.getVert 5) ↔ _
    tauto
  have ne (i j : ℕ) (hi : i≤16) (hj : j≤16) (ij : i≠j) : p.getVert i≠p.getVert j :=
    fun e => ij (hp.1.getVert_injOn (plen.symm ▸ hi) (plen.symm ▸ hj) e)
  have na : p.getVert 0∉({p.getVert 2,p.getVert 3,p.getVert 5}:Finset V) := by
    simp only [mem_insert,mem_singleton,not_or]
    exact ⟨ne _ _ (by decide) (by decide) (by decide),
      ne _ _ (by decide) (by decide) (by decide),
      ne _ _ (by decide) (by decide) (by decide)⟩
  have nb : p.getVert 2∉({p.getVert 3,p.getVert 5}:Finset V) := by
    simp only [mem_insert,mem_singleton,not_or]
    exact ⟨ne _ _ (by decide) (by decide) (by decide), ne _ _ (by decide) (by decide) (by decide)⟩
  have nc : p.getVert 3∉({p.getVert 5}:Finset V) := by
    simpa only [mem_singleton] using ne 3 5 (by decide) (by decide) (by decide)
  have fc : (FlankVertices p x).card=4 := by
    rw [fl,card_insert_of_not_mem na,card_insert_of_not_mem nb,card_insert_of_not_mem nc,card_singleton]
  exact outer hc hp off xh cap inside (Or.inl rfl) pins own adj fl fc af
    (start_not_adj_pin_successor hp (off _ xh) mP) (start_not_adj_pin_successor hp (off _ xh) nP)

#print axioms left16
theorem right16 {a b x : V} {p : G.Walk a b} {H : Finset V}
    (hc : G.Connected) (hp : IsLongest p) (off : ∀ v∈H,v∉p.support) (xh : x∈H)
    (cap : ∀ v,(DistanceTwo G v).card≤6)
    (inside : 6≤(inner G H x).card+(DistanceTwo G x∩H).card)
    (plen : p.length=16) (pins : Pins p x={15,12})
    (own : ∀ v∈H,15∈Pins p v → v=x) : G.degree b≤5 := by
  have af : p.getVert 16=b := by rw [←plen,Walk.getVert_length]
  have adj : G.Adj (p.getVert 15) b := by
    have p₀ := (p.adj_getVert_succ (i:=15) (by omega))
    simpa only [af] using p₀
  have mP : 15∈Pins p x := pins.symm ▸ mem_insert_self _ _
  have nP : 12∈Pins p x := pins.symm ▸ mem_insert_of_mem (mem_singleton_self _)
  have fl : FlankVertices p x={p.getVert 16,p.getVert 14,p.getVert 13,p.getVert 11} := by
    ext z
    simp only [FlankVertices, FlankIndices, pins, Finset.image_union, Finset.image_insert, Finset.image_singleton, mem_union, mem_insert, mem_singleton]
    change (z=p.getVert 14 ∨ z=p.getVert 11) ∨ (z=p.getVert 16 ∨ z=p.getVert 13) ↔ _
    tauto
  have ne (i j : ℕ) (hi : i≤16) (hj : j≤16) (ij : i≠j) : p.getVert i≠p.getVert j :=
    fun e => ij (hp.1.getVert_injOn (plen.symm ▸ hi) (plen.symm ▸ hj) e)
  have na : p.getVert 16∉({p.getVert 14,p.getVert 13,p.getVert 11}:Finset V) := by
    simp only [mem_insert,mem_singleton,not_or]
    exact ⟨ne _ _ (by decide) (by decide) (by decide),
      ne _ _ (by decide) (by decide) (by decide),
      ne _ _ (by decide) (by decide) (by decide)⟩
  have nb : p.getVert 14∉({p.getVert 13,p.getVert 11}:Finset V) := by
    simp only [mem_insert,mem_singleton,not_or]
    exact ⟨ne _ _ (by decide) (by decide) (by decide), ne _ _ (by decide) (by decide) (by decide)⟩
  have nc : p.getVert 13∉({p.getVert 11}:Finset V) := by
    simpa only [mem_singleton] using ne 13 11 (by decide) (by decide) (by decide)
  have fc : (FlankVertices p x).card=4 := by
    rw [fl,card_insert_of_not_mem na,card_insert_of_not_mem nb,card_insert_of_not_mem nc,card_singleton]
  exact outer hc hp off xh cap inside (Or.inr rfl) pins own adj fl fc af
    (end_not_adj_pin_predecessor hp (off _ xh) mP) (end_not_adj_pin_predecessor hp (off _ xh) nP)

#print axioms right16
end Graffiti189LongestPath.DenseEndpointLayout
