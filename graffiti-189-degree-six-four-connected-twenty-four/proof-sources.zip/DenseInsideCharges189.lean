import WideWing189

open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open private Graffiti189LongestPath.mem_distanceTwo Graffiti189LongestPath.dist_two from SmallSeparator189
set_option linter.unusedSectionVars false
set_option maxHeartbeats 15000000
namespace Graffiti189LongestPath.DenseInsideCharges
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

def inner (G : SimpleGraph V) [DecidableRel G.Adj] (H : Finset V) (x : V) := H.filter (G.Adj x)

theorem inside (hc : G.Connected) (H : Finset V) (x y z : V) (xh : x∈H)
    (hh : H.card=7 ∨ H.card=8) (hx : 4≤(inner G H x).card)
    (hd : ∀ v∈H,v≠z → 4≤(inner G H v).card)
    (dense : ∀ v∈H,v≠x → v≠y → v≠z → 6≤(inner G H v).card) :
    6≤(inner G H x).card+(DistanceTwo G x∩H).card := by
  classical
  let X := inner G H x
  let T := DistanceTwo G x∩H
  change 6≤X.card+T.card
  by_cases h7 : H.card=7
  · have size : ({x,y,z}:Finset V).card≤3 := by
      have a := card_insert_le x ({y,z}:Finset V)
      have b := card_insert_le y ({z}:Finset V)
      rw [card_singleton] at b
      omega
    have u : ∃ u∈H,u∉({x,y,z}:Finset V) := by
      by_contra! zz
      have q := card_le_card (show H⊆({x,y,z}:Finset V) from zz)
      omega
    obtain ⟨u,uh,uu⟩ := u
    simp only [mem_insert,mem_singleton,not_or] at uu
    have q := dense u uh uu.1 uu.2.1 uu.2.2
    have sub : inner G H u⊆H.erase u := by
      intro v vv
      have e := mem_filter.mp vv
      exact mem_erase.mpr ⟨e.2.ne.symm,e.1⟩
    have eq := eq_of_subset_of_card_le sub (by rw [card_erase_of_mem uh,h7]; omega)
    have univU (v : V) (vh : v∈H) (vu : v≠u) : G.Adj u v := by
      have h : v∈inner G H u := eq.symm ▸ mem_erase.mpr ⟨vu,vh⟩
      exact (mem_filter.mp h).2
    have cover : H⊆insert x (X∪T) := by
      intro v vh
      by_cases vx : v=x
      · exact mem_insert.mpr (Or.inl vx)
      by_cases xv : G.Adj x v
      · exact mem_insert_of_mem (mem_union_left _ (mem_filter.mpr ⟨vh,xv⟩))
      have vu : v≠u := fun e => xv (e.symm ▸ (univU x xh (fun e => uu.1 e.symm)).symm)
      have d := Graffiti189LongestPath.mem_distanceTwo.mpr
        (Graffiti189LongestPath.dist_two hc (fun e => vx e.symm) xv (univU x xh (fun e => uu.1 e.symm)).symm (univU v vh vu))
      exact mem_insert_of_mem (mem_union_right X (mem_inter.mpr ⟨d,vh⟩))
    have h := card_le_card cover
    have ins := card_insert_le x (X∪T)
    have un := card_union_le X T
    rw [h7] at h
    omega
  have h8 := hh.resolve_left h7
  have common (v : V) (vh : v∈H) (vx : v≠x) (vz : v≠z) (no : ¬G.Adj x v) :
      ∃ u∈X,u∈inner G H v := by
    let Y := inner G H v
    apply Classical.byContradiction
    intro h
    have dis : Disjoint X Y := disjoint_left.mpr (fun u xu yu => h ⟨u,xu,yu⟩)
    have sub : X∪Y⊆(H.erase x).erase v := by
      intro u uu
      rcases mem_union.mp uu with ux|uy
      · obtain ⟨uh,xu⟩ := mem_filter.mp ux
        exact mem_erase.mpr ⟨fun e => no (e ▸ xu),mem_erase.mpr ⟨xu.ne.symm,uh⟩⟩
      · obtain ⟨uh,vu⟩ := mem_filter.mp uy
        exact mem_erase.mpr ⟨vu.ne.symm,mem_erase.mpr ⟨fun e => no ((e ▸ vu).symm),uh⟩⟩
    have bound := card_le_card sub
    rw [card_union_of_disjoint dis,card_erase_of_mem (mem_erase.mpr ⟨vx,vh⟩),card_erase_of_mem xh,h8] at bound
    have d := hd v vh vz
    change 4≤X.card at hx
    change 4≤Y.card at d
    omega
  have cover : H⊆insert x (insert z (X∪T)) := by
    intro v vh
    by_cases vx : v=x
    · exact mem_insert.mpr (Or.inl vx)
    by_cases vz : v=z
    · exact mem_insert_of_mem (mem_insert.mpr (Or.inl vz))
    by_cases xv : G.Adj x v
    · exact mem_insert_of_mem (mem_insert_of_mem (mem_union_left _ (mem_filter.mpr ⟨vh,xv⟩)))
    obtain ⟨u,ux,uv⟩ := common v vh vx vz xv
    have d := Graffiti189LongestPath.mem_distanceTwo.mpr
      (Graffiti189LongestPath.dist_two hc (fun e => vx e.symm) xv (mem_filter.mp ux).2 (mem_filter.mp uv).2.symm)
    exact mem_insert_of_mem (mem_insert_of_mem (mem_union_right X (mem_inter.mpr ⟨d,vh⟩)))
  have h := card_le_card cover
  have ins := card_insert_le x (insert z (X∪T))
  have ins' := card_insert_le z (X∪T)
  have un := card_union_le X T
  rw [h8] at h
  omega

#print axioms inside
end Graffiti189LongestPath.DenseInsideCharges
