import DenseOwnerRoute189
import WideWing189
import SixCoreMarkedPath189

open Finset SimpleGraph SimpleGraph.Walk
open Graffiti189LongestPath
open private Graffiti189LongestPath.WideWing.CompleteOn from WideWing189
namespace Graffiti189LongestPath.DenseOwnerRouteNine
variable {U : Type*} [Fintype U] [DecidableEq U] {D : SimpleGraph U} [DecidableRel D.Adj]

open private Graffiti189LongestPath.DenseOwnerRoute.degree_bound Graffiti189LongestPath.DenseOwnerRoute.contacts Graffiti189LongestPath.DenseOwnerRoute.bracket from DenseOwnerRoute189
theorem route_nine (hc : Fintype.card U=9)
    (x y z : U) (xy : x≠y) (lo : ∀ v,2≤D.degree v) (hi : ∀ v,v≠z → 4≤D.degree v)
    (dense : ∀ v,v≠x → v≠y → v≠z → 6≤D.degree v) :
    ∃ q : D.Walk x y,q.IsPath ∧ 5≤q.length := by
  classical
  let R := (((univ:Finset U).erase x).erase y).erase z
  have R5 : 6≤R.card := by
    have a := Finset.card_erase_le (s:=((univ:Finset U).erase x).erase y) (a:=z)
    by_cases h : z∈((univ:Finset U).erase x).erase y
    · have ez := card_erase_add_one h
      rw [card_erase_of_mem (mem_erase.mpr ⟨Ne.symm xy,mem_univ y⟩),
        card_erase_of_mem (mem_univ x),card_univ,hc] at ez
      exact Nat.le_of_eq (by change R.card+1=7 at ez; omega)
    · rw [show R=((univ:Finset U).erase x).erase y from erase_eq_of_not_mem h,
        card_erase_of_mem (mem_erase.mpr ⟨Ne.symm xy,mem_univ y⟩),
        card_erase_of_mem (mem_univ x),card_univ,hc]
      decide
  have out (w : U) (wo : w∉R) : w=x ∨ w=y ∨ w=z := by
    by_cases wx : w=x
    · exact Or.inl wx
    · by_cases wy : w=y
      · exact Or.inr (Or.inl wy)
      · by_cases wz : w=z
        · exact Or.inr (Or.inr wz)
        · exact (wo (mem_erase.mpr ⟨wz,mem_erase.mpr ⟨wy,mem_erase.mpr ⟨wx,mem_univ _⟩⟩⟩)).elim
  obtain ⟨a,aa,b,bb,ab,xa,byy⟩ := Graffiti189LongestPath.DenseOwnerRoute.contacts x y z xy R out lo hi
  have abR : ({a,b}:Finset U)⊆R := fun w ww =>
    (mem_insert.mp ww).elim (fun e => e.symm ▸ aa) (fun e => (mem_singleton.mp e).symm ▸ bb)
  let K := R\({a,b}:Finset U)
  have k3 : 4≤K.card := by
    have cs := card_sdiff_add_card_eq_card abR
    rw [show ({a,b}:Finset U).card=2 by simp [ab]] at cs
    change K.card+2=R.card at cs
    omega
  obtain ⟨T,tK,tc⟩ := exists_subset_card_eq k3
  let A := ({a,b}:Finset U)∪T
  have ac : A.card=6 := by
    have d : Disjoint ({a,b}:Finset U) T := disjoint_left.mpr (fun _ e et =>
      (mem_sdiff.mp (tK et)).2 e)
    rw [card_union_of_disjoint d,show ({a,b}:Finset U).card=2 by simp [ab],tc]
  have ar : A⊆R := union_subset abR (tK.trans sdiff_subset)
  let J := D.induce (A:Set U)
  let s : ↥(A:Set U) := ⟨a,by simp [A]⟩
  let t : ↥(A:Set U) := ⟨b,by simp [A]⟩
  have minD (v : ↥(A:Set U)) : 3≤J.degree v := by
    have q := ar v.property
    have vd := dense v.val (mem_erase.mp (mem_erase.mp (mem_erase.mp q).2).2).1
      (mem_erase.mp (mem_erase.mp q).2).1 (mem_erase.mp q).1
    have re := Graffiti189LongestPath.DenseOwnerRoute.degree_bound (D:=D) A (univ\A) v.val (fun w _ wo => mem_sdiff.mpr ⟨mem_univ _,wo⟩)
    have cs := card_sdiff_add_card_eq_card (subset_univ A)
    rw [ac,card_univ,hc] at cs
    have e : (A.filter (D.Adj v.val)).card=J.degree v := by
      rw [←J.card_neighborFinset_eq_degree]
      refine card_bij' (s:=A.filter (D.Adj v.val)) (t:=J.neighborFinset v)
        (fun w ww => (⟨w,(mem_filter.mp ww).1⟩ : ↥(A:Set U)))
        (fun (w : ↥(A:Set U)) _ => w.val) ?_ ?_ ?_ ?_
      · intro w ww; exact (J.mem_neighborFinset _ _).mpr (mem_filter.mp ww).2
      · intro w ww; exact mem_filter.mpr ⟨w.property,(J.mem_neighborFinset _ _).mp ww⟩
      · intro w hw; rfl
      · intro w hw; exact Subtype.ext rfl
    rw [e] at re
    omega
  have q := Graffiti189SixCore.six_core_marked_path J
    ((Fintype.card_coe A).trans ac) (fun v => by have := minD v; omega)
    (fun v w _ => Or.inl (minD v)) (show s≠t from fun e => ab (congrArg Subtype.val e))
  have n1 : J.neighborFinset s≠{t} := by
    intro e
    have c := minD s
    rw [←J.card_neighborFinset_eq_degree,e,card_singleton] at c
    omega
  have n2 : J.neighborFinset t≠{s} := by
    intro e
    have c := minD t
    rw [←J.card_neighborFinset_eq_degree,e,card_singleton] at c
    omega
  obtain ⟨p,pp,pl⟩ := q.resolve_right (fun d => d.elim n1 n2)
  let f : J→g D := ⟨Subtype.val,fun e => e⟩
  have supported (u : U) (up : u∈(p.map f).support) : u∈R := by
    rw [support_map] at up
    obtain ⟨v,_,rfl⟩ := List.mem_map.mp up
    exact ar v.property
  have xo : x∉(p.map f).support := fun e =>
    (mem_erase.mp (mem_erase.mp (mem_erase.mp (supported x e)).2).2).1 rfl
  have yo : y∉(p.map f).support := fun e =>
    (mem_erase.mp (mem_erase.mp (supported y e)).2).1 rfl
  obtain ⟨ppp,pP,lp⟩ := Graffiti189LongestPath.DenseOwnerRoute.bracket xy xa byy.symm (p.map f)
    (map_isPath_of_injective Subtype.val_injective pp) xo yo
  have ll : 3≤(p.map f).length := by simpa using pl
  exact ⟨ppp,pP,by omega⟩

#print axioms route_nine
end Graffiti189LongestPath.DenseOwnerRouteNine
