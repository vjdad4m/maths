import FiveSharedCharges18_189

open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack
open Graffiti189LongestPath.FiveCheapBudget18 Graffiti189LongestPath.FiveSharedCharges18
set_option linter.unusedSectionVars false
set_option maxHeartbeats 15000000
namespace Graffiti189LongestPath.FiveGapFour18
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]
variable {a b x y : V} {p : G.Walk a b} {H : Finset V}
variable (A : PairData p H x y 7 11 1 17) (hc : G.Connected)
variable (hp : IsLongest p) (cap : ∀ v,(DistanceTwo G v).card≤6)
include A hc hp cap

theorem outer_left : p.getVert 5∈residual G H (p.getVert 7) :=
  charge_on_spine A hc (distinct_get A hp (by decide) (by decide) (by decide))
    (adjacency_on_spine A 6 (by decide)).symm (adjacency_on_spine A 5 (by decide)).symm
    (not_adj_outside_allowed A hc hp cap (Or.inl rfl) (by decide) (by decide))

theorem outer_right : p.getVert 13∈residual G H (p.getVert 11) :=
  charge_on_spine A hc (distinct_get A hp (by decide) (by decide) (by decide))
    (adjacency_on_spine A 11 (by decide)) (adjacency_on_spine A 12 (by decide))
    (not_adj_outside_allowed A hc hp cap (Or.inr rfl) (by decide) (by decide))

theorem no_shared {m k : ℕ} (hm : m=7 ∨ m=11) (hk : k=1 ∨ k=17) :
    ¬G.Adj (p.getVert m) (p.getVert k) := by
  intro ed
  have e := exhaust_shared A hc hp cap hm hk ed
  rcases hm with rfl|rfl
  · have q := outer_left A hc hp cap
    rw [e] at q
    rcases hk with rfl|rfl <;> rcases mem_insert.mp q with q|q
    all_goals first
      | exact distinct_get A hp (by decide) (by decide) (by decide) q
      | exact distinct_get A hp (by decide) (by decide) (by decide) (mem_singleton.mp q)
  · have q := outer_right A hc hp cap
    rw [e] at q
    rcases hk with rfl|rfl <;> rcases mem_insert.mp q with q|q
    all_goals first
      | exact distinct_get A hp (by decide) (by decide) (by decide) q
      | exact distinct_get A hp (by decide) (by decide) (by decide) (mem_singleton.mp q)

def chunk : Finset ℕ := {6,7,8,10,11,12}

theorem cheap_cover {m : ℕ} (hm : m=7 ∨ m=11) {v : V}
    (ed : G.Adj (p.getVert m) v) : v∈insert x ((chunk.erase m).image p.getVert) := by
  rcases cheap_neighbors A hc hp cap hm ed with e|ok
  · exact mem_insert.mpr (Or.inl e)
  obtain ⟨i,ii,rfl⟩ := mem_image.mp ok
  have ne : i≠m := fun e => G.irrefl (e ▸ ed)
  have ic : i∈chunk := by
    simp only [allowed,targets,flanks,mem_insert,mem_singleton] at ii
    rcases ii with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
    all_goals first | decide | exact (no_shared A hc hp cap hm (Or.inl rfl) ed).elim |
      exact (no_shared A hc hp cap hm (Or.inr rfl) ed).elim
  exact mem_insert_of_mem (mem_image.mpr ⟨i,mem_erase.mpr ⟨ne,ic⟩,rfl⟩)

theorem cheap_high_all {m : ℕ} (hm : m=7 ∨ m=11) (high : 6≤G.degree (p.getVert m))
    {j : ℕ} (hj : j∈chunk) (jn : j≠m) : G.Adj (p.getVert m) (p.getVert j) := by
  classical
  let B := insert x ((chunk.erase m).image p.getVert)
  have sub : G.neighborFinset (p.getVert m)⊆B := fun u hu =>
    cheap_cover A hc hp cap hm ((G.mem_neighborFinset _ _).mp hu)
  have cub : (chunk.erase m).card=5 := by rcases hm with rfl|rfl <;> decide
  have bo : B.card≤6 := by
    have h := card_insert_le x ((chunk.erase m).image p.getVert)
    have k : ((chunk.erase m).image p.getVert).card≤5 := card_image_le.trans (by rw [cub])
    dsimp [B]
    omega
  have eql := eq_of_subset_of_card_le sub (bo.trans (by rwa [G.card_neighborFinset_eq_degree]))
  exact (G.mem_neighborFinset _ _).mp (eql.symm ▸ mem_insert_of_mem (mem_image.mpr
    ⟨j,mem_erase.mpr ⟨jn,hj⟩,rfl⟩))

theorem no_gap_four (deg : ∀ u v : V,u≠v → 6≤G.degree u ∨ 6≤G.degree v) : False := by
  have hi := deg (p.getVert 7) (p.getVert 11) (distinct_get A hp (by decide) (by decide) (by decide))
  have three {m : ℕ} (hm : m=7 ∨ m=11)
      (s : p.getVert 5∈residual G H (p.getVert m))
      (t : p.getVert 9∈residual G H (p.getVert m))
      (u : p.getVert 13∈residual G H (p.getVert m)) : False := by
    have contradiction := two_lt_card.mpr
      ⟨_,s,_,t,_,u,distinct_get A hp (by decide) (by decide) (by decide),
        distinct_get A hp (by decide) (by decide) (by decide),
        distinct_get A hp (by decide) (by decide) (by decide)⟩
    exact (Nat.not_le_of_lt contradiction) (residual_cap A hc hp cap hm)
  rcases hi with left|right
  · apply three (Or.inl rfl) (outer_left A hc hp cap)
    · exact charge_on_spine A hc (distinct_get A hp (by decide) (by decide) (by decide))
        (adjacency_on_spine A 7 (by decide)) (adjacency_on_spine A 8 (by decide))
        (not_adj_outside_allowed A hc hp cap (Or.inl rfl) (by decide) (by decide))
    · exact charge_on_spine A hc (distinct_get A hp (by decide) (by decide) (by decide))
        (cheap_high_all A hc hp cap (Or.inl rfl) left (j:=12) (by decide) (by decide))
        (adjacency_on_spine A 12 (by decide))
        (not_adj_outside_allowed A hc hp cap (Or.inl rfl) (by decide) (by decide))
  · apply three (Or.inr rfl) _ _ (outer_right A hc hp cap)
    · exact charge_on_spine A hc (distinct_get A hp (by decide) (by decide) (by decide))
        (cheap_high_all A hc hp cap (Or.inr rfl) right (j:=6) (by decide) (by decide))
        (adjacency_on_spine A 5 (by decide)).symm
        (not_adj_outside_allowed A hc hp cap (Or.inr rfl) (by decide) (by decide))
    · exact charge_on_spine A hc (distinct_get A hp (by decide) (by decide) (by decide))
        (adjacency_on_spine A 10 (by decide)).symm (adjacency_on_spine A 9 (by decide)).symm
        (not_adj_outside_allowed A hc hp cap (Or.inr rfl) (by decide) (by decide))

#print axioms no_gap_four
end Graffiti189LongestPath.FiveGapFour18
