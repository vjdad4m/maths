import WingSixHamiltonPath189
import FiveCheapBudget189
import WideWing189
import DenseOwnerRoute189
import MarkedWingPath189
import Interior189
import GapStrong189
open private Graffiti189LongestPath.WideWing.inside_deg Graffiti189LongestPath.WideWing.two_per_block from WideWing189
open SimpleGraph SimpleGraph.Walk Finset Graffiti189LongestPath
open Graffiti189LongestPath.Normalize Graffiti189LongestPath.GapTwin
open Graffiti189LongestPath.OneSlack Graffiti189LongestPath.Rigidity
open Graffiti189LongestPath.GapStrong Graffiti189LongestPath.WideWing
open Graffiti189LongestPath.Interior Graffiti189LongestPath.HighDichotomy
open private Graffiti189LongestPath.pin_data Graffiti189LongestPath.no_endpoints
  Graffiti189LongestPath.boundary_card_of_connectivity from SmallSeparator189
open private Graffiti189LongestPath.Rigidity.pin_pos
  Graffiti189LongestPath.Rigidity.LeftMarks Graffiti189LongestPath.Rigidity.RightMarks
  Graffiti189LongestPath.Rigidity.card_leftMarks Graffiti189LongestPath.Rigidity.card_rightMarks from Rigidity189
open private Graffiti189LongestPath.OneSlack.pin_of_neighbor_mem
  Graffiti189LongestPath.OneSlack.pin_vertices_subset_boundary
  Graffiti189LongestPath.OneSlack.card_pinVertices from OneSlack189
set_option warningAsError true
set_option linter.unusedSectionVars false
set_option maxHeartbeats 15000000
namespace Graffiti189LongestPath.SixWingFrontier
open Graffiti189LongestPath.FiveCheapBudget
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem no_six (hc : G.Connected) (k : ℕ) (hk : k=4)
    (cap : ∀ v,(EvenFrom G v).card≤k+3)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S:Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → k+2≤G.degree u ∨ k+2≤G.degree v)
    {a b : V} {p : G.Walk a b} (hp : IsLongest p) (hMin : EdgeMinAvoid (k+2) p)
    (C : OmittedComponent p) (h : C.vertices.card=6) (plen : p.length=17)
    (few : ∀ z∈C.vertices,(Pins p z).card≤2)
    (low : ∀ z∈C.vertices,k+2-2≤G.degree z) :
    False := by
  classical
  let H := C.vertices
  have hO : ∀ v∈H,v∉p.support := C.off
  have hsize : H.card=6 := h
  let Q := G.induce (H:Set V)
  have qcard : Fintype.card ↥(H:Set V) = 6 := (Fintype.card_coe H).trans hsize
  have inner (v : ↥(H:Set V)) :
      G.degree v.val ≤ (Pins p v.val).card+Q.degree v :=
    Graffiti189LongestPath.WideWing.inside_deg hp C v
  have hi_pins (v : V) (vh : v∈H) (high : k+2≤G.degree v) :
      0<(Pins p v).card := by
    let z : ↥(H:Set V) := ⟨v,vh⟩
    have e := inner z
    have q := Q.degree_lt_card_verts z
    change G.degree v≤(Pins p v).card+Q.degree z at e
    omega
  have lo2 (v : ↥(H:Set V)) : 2≤Q.degree v := by
    have e := inner v
    have f := few v.val v.property
    have g := low v.val v.property
    omega
  have hh4 (v : ↥(H:Set V)) (vv : k+2≤G.degree v.val) : 4≤Q.degree v := by
    have e := inner v
    have f := few v.val v.property
    omega
  have hihi (u v : ↥(H:Set V)) (ne : u≠v) : 4≤Q.degree u ∨ 4≤Q.degree v :=
    (deg u.val v.val (fun e => ne (Subtype.ext e))).imp (hh4 u) (hh4 v)
  have extend {u v : ↥(H:Set V)} {m n : ℕ} (hm : m∈Pins p u.val) (hn : n∈Pins p v.val)
      (hh : m<n) (q : Q.Walk u v) (qp : q.IsPath) : m+q.length+2≤n := by
    let f : Q→g G := ⟨Subtype.val,fun e => e⟩
    have t := terminal_length_le_gap hp hm hn hh (q.map f)
      (map_isPath_of_injective Subtype.val_injective qp) (by
        intro w ww
        rw [support_map] at ww
        obtain ⟨v,_,rfl⟩ := List.mem_map.mp ww
        exact hO _ v.property)
    rw [length_map] at t
    omega
  let I := (range p.length).filter (fun j => ∃ z∈H, (4≤k ∨ k+2≤G.degree z) ∧ j∈Pins p z)
  have Idata {j : ℕ} (hj : j ∈ I) : ∃ z∈H, (4≤k ∨ k+2≤G.degree z) ∧ j∈Pins p z :=
    (mem_filter.mp hj).2
  have atLeast : k≤I.card := by
    have ck := componentPins_card hp C k conn
    have sub : componentPins C ⊆ I.image p.getVert := by
      intro u hu
      obtain ⟨hu,z,hz,ez⟩ := mem_filter.mp hu
      obtain ⟨j,hj,he⟩ := Graffiti189LongestPath.OneSlack.pin_of_neighbor_mem hp
        (hO z hz) (List.mem_toFinset.mp hu) ez
      exact mem_image.mpr ⟨j,mem_filter.mpr ⟨(mem_filter.mp hj).1,z,hz,Or.inl (by omega),hj⟩,he⟩
    exact ck.trans ((card_le_card sub).trans card_image_le)
  have sep {i j : Nat} (hi : i∈I) (hj : j∈I) (e : i<j) : i+2≤j := by
    obtain ⟨u,hu,du,hi⟩ := Idata hi
    obtain ⟨v,hv,dv,hj⟩ := Idata hj
    by_cases eq : u=v
    · subst v
      apply Classical.byContradiction
      intro nLe
      have eLt : j < i+2 := Nat.lt_of_not_ge nLe
      have ij : i+1=j := by omega
      have fl : p.getVert j ∈ FlankVertices p u := mem_image.mpr
        ⟨j,mem_union.mpr (Or.inr (mem_image.mpr ⟨i,hi,ij⟩)),rfl⟩
      have pB := Graffiti189LongestPath.OneSlack.pin_vertices_subset_boundary (hO u hu)
        (mem_image.mpr ⟨j,hj,rfl⟩)
      exact (mem_sdiff.mp (flanks_outside_boundary hc hp (hO u hu) fl)).2 pB
    · obtain ⟨q,hq,hS⟩ := C.joined u hu v hv
      have pos : 0 < q.length := by
        cases q with
        | nil => exact (eq rfl).elim
        | cons e q => simp
      have hd := gap_three_of_linked_pins hp hi hj e q hq pos (fun z hz => hO z (hS z hz))
      omega
  have allI {v : V} (hv : v∈H) {m : Nat} (hm : m∈Pins p v) : m∈I :=
    mem_filter.mpr ⟨(mem_filter.mp hm).1,v,hv,Or.inl (by omega),hm⟩
  have coreGap {u v : V} (hu : u∈H) (hv : v∈H) (ne : u≠v)
      {m n : Nat} (hm : m∈Pins p u) (hn : n∈Pins p v) (hh : m<n) : m+6≤n := by
    let u' : ↥(H:Set V) := ⟨u,hu⟩
    let v' : ↥(H:Set V) := ⟨v,hv⟩
    obtain ⟨q,qp,ql⟩ := MarkedWingPath.long_marked_path (D:=Q)
      (show 6≤Fintype.card ↥(H:Set V) ∧ Fintype.card ↥(H:Set V)≤8 by omega)
      lo2 hihi (show u'≠v' from fun e => ne (congrArg Subtype.val e))
    have t := extend (u:=u') (v:=v') hm hn hh q qp
    omega
  have cheap {m n : Nat} (hm : m∈I) (hn : n∈I) (mn : m<n) (short : n<m+6) :
      ∃ u∈H, m∈Pins p u ∧ n∈Pins p u ∧ ∀ v∈H, (m∈Pins p v ∨ n∈Pins p v) → v=u := by
    obtain ⟨u,hu,_,hmu⟩ := Idata hm
    obtain ⟨v,hv,_,hnv⟩ := Idata hn
    have e : u=v := Classical.byContradiction (fun h => (Nat.not_le_of_lt short) (coreGap hu hv h hmu hnv mn))
    subst v
    exact ⟨u,hu,hmu,hnv,fun v hv h => Classical.byContradiction (fun ne => (Nat.not_le_of_lt short)
      (h.elim (fun h => coreGap hv hu ne h hnv mn) (fun h => coreGap hu hv (Ne.symm ne) hmu h mn)))⟩
  have dist {m n : Nat} (hm : m∈I) (hn : n∈I) (mn : m<n) : m+3≤n := by
    have h2 := sep hm hn mn
    apply Nat.le_of_not_gt
    intro ns
    obtain ⟨v,hv,hmv,hnv,_⟩ := cheap hm hn mn (by omega)
    have eq : Pins p v = {m,m+2} := by
      have sub : ({m,m+2}:Finset Nat) ⊆ Pins p v := by
        intro r h
        simp only [mem_insert,mem_singleton] at h
        rcases h with rfl|rfl
        · exact hmv
        · rwa [show m+2=n by omega]
      have ff := few v hv
      exact (eq_of_subset_of_card_le sub (by simpa using ff)).symm
    have vd := low v hv
    have vo := hO v hv
    have ne : v ≠ p.getVert (m+1) := fun e => vo (e.symm ▸ p.getVert_mem_support _)
    have dd := deg v (p.getVert (m+1)) ne
    have se := sum_degree_gap_exchange hc (k+2) cap hMin.1 vo m eq
    by_cases dh : k+2≤G.degree v
    · have bb := (normalized_high_omission hc (k+2) k (by omega) le_rfl cap conn hMin vo dh m hmv).2
      exact bb (by rwa [show m+2=n by omega])
    · have ss := se.2 (by omega)
      omega
  have bounds {m : Nat} (hm : m∈I) : 1≤m ∧ m+1≤p.length := by
    obtain ⟨v,hv,_,hh⟩ := Idata hm
    have h := (Graffiti189LongestPath.pin_data hh).1
    have hh₁ := Graffiti189LongestPath.Rigidity.pin_pos hp (hO v hv) hh
    omega
  have sorted : ∃ a' b' c' d' : Nat,
      a'∈I ∧ b'∈I ∧ c'∈I ∧ d'∈I ∧ a'<b' ∧ b'<c' ∧ c'<d' := by
    have cn : 4≤I.card := by omega
    let a' := I.min' (by apply card_pos.mp; omega)
    have aI : a'∈I := min'_mem _ _
    let I₁ := I.erase a'
    have c₁ : I₁.card+1=I.card := card_erase_add_one aI
    let b' := I₁.min' (by apply card_pos.mp; omega)
    have bI : b'∈I₁ := min'_mem _ _
    let I₂ := I₁.erase b'
    have c₂ : I₂.card+1=I₁.card := card_erase_add_one bI
    let c' := I₂.min' (by apply card_pos.mp; omega)
    have dI : c'∈I₂ := min'_mem _ _
    let I₃ := I₂.erase c'
    have c₃ : I₃.card+1=I₂.card := card_erase_add_one dI
    let d' := I₃.min' (by apply card_pos.mp; omega)
    have eI : d'∈I₃ := min'_mem _ _
    have h₁ := min'_le I b' (mem_erase.mp bI).2
    have h₂ := min'_le I₁ c' (mem_erase.mp dI).2
    have h₃ := min'_le I₂ d' (mem_erase.mp eI).2
    have ne₁ := (mem_erase.mp bI).1
    have ne₂ := (mem_erase.mp dI).1
    have ne₃ := (mem_erase.mp eI).1
    exact ⟨a',b',c',d',aI,(mem_erase.mp bI).2,
      (mem_erase.mp (mem_erase.mp dI).2).2,(mem_erase.mp (mem_erase.mp (mem_erase.mp eI).2).2).2,
      by omega,by omega,by omega⟩
  obtain ⟨r,s,t,u,hr,hs,ht,hu,rs,st,tu⟩ := sorted
  have no_double {a' b' c' : Nat} (ha : a'∈I) (hb : b'∈I) (hc' : c'∈I)
      (ab : a'<b') (bc : b'<c') (s1 : b'<a'+6) (s2 : c'<b'+6) : False := by
    obtain ⟨x₁,hx₁,ha',hb',unique₁⟩ := cheap ha hb ab s1
    obtain ⟨x₂,hx₂,hb'',hc'',_⟩ := cheap hb hc' bc s2
    have eq := unique₁ x₂ hx₂ (Or.inr hb'')
    subst x₂
    have sub : ({a',b',c'}:Finset Nat) ⊆ Pins p x₁ := by
      intro m hm
      simp only [mem_insert,mem_singleton] at hm
      rcases hm with rfl|rfl|rfl
      · exact ha'
      · exact hb'
      · exact hc''
    have cnt := card_le_card sub
    have e : ({a',b',c'}:Finset Nat).card=3 := by
      simp [show a'≠b' by omega,show a'≠c' by omega,show b'≠c' by omega]
    have f := few x₁ hx₁
    omega
  have dr := dist hr hs rs
  have ds := dist hs ht st
  have dt := dist ht hu tu
  have br := (bounds hr).1
  have bu := (bounds hu).2
  have totalI : I.card≤4 := by
    have q := Graffiti189LongestPath.WideWing.two_per_block I 9 2 (by decide)
      (by intro i ii; have q := (bounds ii).2; omega)
      (by intro i ii j jj l ll ij jl
          have t := dist ii jj ij
          have s := dist jj ll jl
          by_contra! e
          exact no_double ii jj ll ij jl (by omega) (by omega))
    omega
  have all : I={r,s,t,u} := by
    apply (eq_of_subset_of_card_le _ _).symm
    · intro m hm
      simp only [mem_insert,mem_singleton] at hm
      rcases hm with rfl|rfl|rfl|rfl <;> assumption
    · rw [show ({r,s,t,u}:Finset Nat).card=4 by
        simp [show r≠s by omega,show r≠t by omega,show r≠u by omega,
          show s≠t by omega,show s≠u by omega,show t≠u by omega]]
      exact totalI
  have exists_high_excluding (v w : V) :
      ∃ z∈H,z≠v ∧ z≠w ∧ k+2≤G.degree z := by
    have some (F : Finset V) (fc : F.card≤3) : ∃ z∈H,z∉F := by
      by_contra! na
      have cl := card_le_card (show H⊆F from na)
      omega
    obtain ⟨z,zh,r⟩ := some {v,w} (by
      have q := card_insert_le v ({w}:Finset V)
      rw [card_singleton] at q
      omega)
    obtain ⟨z',zh',r'⟩ := some {v,w,z} (by
      have q := card_insert_le v ({w,z}:Finset V)
      have l := card_insert_le w ({z}:Finset V)
      rw [card_singleton] at l
      omega)
    simp only [mem_insert,mem_singleton,not_or] at r r'
    exact (deg z z' (fun e => r'.2.2 e.symm)).elim
      (fun dz => ⟨z,zh,r.1,r.2,dz⟩) (fun dz => ⟨z',zh',r'.1,r'.2.1,dz⟩)
  have occurs {v : V} (vh : v∈H) {m : ℕ} (mm : m∈Pins p v) :
      m=r ∨ m=s ∨ m=t ∨ m=u := by
    have z := allI vh mm
    rw [all] at z
    simpa only [mem_insert,mem_singleton] using z
  have not_both (rs' : s<r+6) (tu' : u<t+6) : False := by
    obtain ⟨x,xh,_,_,xo⟩ := cheap hr hs rs rs'
    obtain ⟨y,yh,_,_,yo⟩ := cheap ht hu tu tu'
    obtain ⟨v,vh,vx,vy,vd⟩ := exists_high_excluding x y
    have c := hi_pins v vh vd
    obtain ⟨m,mm⟩ := card_pos.mp (show 0<(Pins p v).card by omega)
    rcases occurs vh mm with e|e|e|e
    · exact vx (xo v vh (Or.inl (e ▸ mm)))
    · exact vx (xo v vh (Or.inr (e ▸ mm)))
    · exact vy (yo v vh (Or.inl (e ▸ mm)))
    · exact vy (yo v vh (Or.inr (e ▸ mm)))
  have terminalBad {u v : ↥(H:Set V)} {m n : ℕ}
      (hm : m∈Pins p u.val) (hn : n∈Pins p v.val) (gap : n=m+6) :
      ¬WingSixHamiltonPath.Good Q u v := by
    rintro ⟨q,qp,ql⟩
    have s := extend hm hn (by omega) q qp
    omega
  have no_alt_pair {x y z w : V} (xh : x∈H) (yh : y∈H) (zh : z∈H) (wh : w∈H)
      (xy : x≠y) (zw : z≠w) (zx : z≠x) (zy : z≠y)
      {i j m n : ℕ} (xp : i∈Pins p x) (yp : j∈Pins p y) (gap₁ : j=i+6)
      (zp : m∈Pins p z) (wp : n∈Pins p w) (gap₂ : n=m+6 ∨ m=n+6) : False := by
    let X : ↥(H:Set V) := ⟨x,xh⟩
    let Y : ↥(H:Set V) := ⟨y,yh⟩
    let Z : ↥(H:Set V) := ⟨z,zh⟩
    let W : ↥(H:Set V) := ⟨w,wh⟩
    have b₁ := terminalBad (u:=X) (v:=Y) xp yp gap₁
    have b₂ : ¬WingSixHamiltonPath.Good Q Z W := by
      rcases gap₂ with g|g
      · exact terminalBad zp wp g
      · rintro ⟨p,pp,pl⟩
        exact terminalBad (u:=W) (v:=Z) wp zp g ⟨p.reverse,pp.reverse,by simpa using pl⟩
    have eq := WingSixHamiltonPath.unique_exception (D:=Q) qcard lo2 hihi X Y Z W
      (fun e => xy (congrArg Subtype.val e)) (fun e => zw (congrArg Subtype.val e)) b₁ b₂
    have zi : Z∈({X,Y}:Finset ↥(H:Set V)) := eq.symm ▸ mem_insert_self _ _
    rcases mem_insert.mp zi with q|q
    · exact zx (congrArg Subtype.val q)
    · exact zy (congrArg Subtype.val (mem_singleton.mp q))
  by_cases short1 : s<r+6
  · have q1 : t=s+6 := by
      have q1 : t≥s+6 := Nat.le_of_not_gt (fun e => no_double hr hs ht rs st short1 e)
      have q2 : u≥t+6 := Nat.le_of_not_gt (not_both short1)
      omega
    have q2 : u=t+6 := by have qq:=Nat.le_of_not_gt (not_both short1); omega
    obtain ⟨x,xh,xr,xs,xo⟩ := cheap hr hs rs short1
    obtain ⟨y,yh,_,yt⟩ := Idata ht
    have yx : y≠x := by
      intro e
      have p := Finset.two_lt_card.mpr ⟨r,xr,s,xs,t,e ▸ yt,by omega,by omega,by omega⟩
      have f := few x xh
      omega
    obtain ⟨z,zh,zx,zy,zd⟩ := exists_high_excluding x y
    obtain ⟨m,mp⟩ := card_pos.mp (hi_pins z zh zd)
    rcases occurs zh mp with e|e|e|e
    · exact zx (xo z zh (Or.inl (e ▸ mp)))
    · exact zx (xo z zh (Or.inr (e ▸ mp)))
    · exact no_alt_pair xh yh zh xh yx.symm zx zx zy xs yt q1 (e ▸ mp) xs (Or.inr (by omega))
    · exact no_alt_pair xh yh zh yh yx.symm zy zx zy xs yt q1 (e ▸ mp) yt (Or.inr (by omega))
  by_cases short2 : t<s+6
  · have q1 : s=r+6 := by
      have q1 : s≥r+6 := Nat.le_of_not_gt short1
      have q2 : u≥t+6 := Nat.le_of_not_gt (fun e => no_double hs ht hu st tu short2 e)
      omega
    have q2 : u=t+6 := by have zz:=Nat.le_of_not_gt (fun e => no_double hs ht hu st tu short2 e); omega
    obtain ⟨x,xh,xs,xt,xo⟩ := cheap hs ht st short2
    obtain ⟨y,yh,_,yr⟩ := Idata hr
    have yx : y≠x := by
      intro e
      have p := Finset.two_lt_card.mpr ⟨s,xs,t,xt,r,e ▸ yr,by omega,by omega,by omega⟩
      have f := few x xh
      omega
    obtain ⟨z,zh,zx,zy,zd⟩ := exists_high_excluding x y
    obtain ⟨m,mp⟩ := card_pos.mp (hi_pins z zh zd)
    rcases occurs zh mp with e|e|e|e
    · exact no_alt_pair yh xh zh xh yx zx zy zx yr xs q1 (e ▸ mp) xs (Or.inl (by omega))
    · exact zx (xo z zh (Or.inl (e ▸ mp)))
    · exact zx (xo z zh (Or.inr (e ▸ mp)))
    · exact no_alt_pair yh xh zh xh yx zx zy zx yr xs q1 (e ▸ mp) xt (Or.inr (by omega))
  have short3 : u<t+6 := by omega
  have q1 : s=r+6 := by omega
  have q2 : t=s+6 := by omega
  obtain ⟨x,xh,xt,xu,xo⟩ := cheap ht hu tu short3
  obtain ⟨y,yh,_,ys⟩ := Idata hs
  have yx : y≠x := by
    intro e
    have p := Finset.two_lt_card.mpr ⟨t,xt,u,xu,s,e ▸ ys,by omega,by omega,by omega⟩
    have f := few x xh
    omega
  obtain ⟨z,zh,zx,zy,zd⟩ := exists_high_excluding x y
  obtain ⟨m,mp⟩ := card_pos.mp (hi_pins z zh zd)
  rcases occurs zh mp with e|e|e|e
  · exact no_alt_pair yh xh zh yh yx zy zy zx ys xt q2 (e ▸ mp) ys (Or.inl (by omega))
  · exact no_alt_pair yh xh zh xh yx zx zy zx ys xt q2 (e ▸ mp) xt (Or.inl (by omega))
  · exact zx (xo z zh (Or.inl (e ▸ mp)))
  · exact zx (xo z zh (Or.inr (e ▸ mp)))

#print axioms no_six
end Graffiti189LongestPath.SixWingFrontier
