import MarkedWingPath189
import WingHamilton60Cert189
import WingHamilton62Cert189
open Finset SimpleGraph SimpleGraph.Walk
open private Graffiti189LongestPath.MarkedWingPath.labels from MarkedWingPath189
namespace Graffiti189LongestPath.WingSixHamiltonPath
variable {W : Type*} [Fintype W] [DecidableEq W] {D : SimpleGraph W} [DecidableRel D.Adj]

private theorem with_exception (card : Fintype.card W=6)
    (z x y : W) (xy : x≠y) (zy : z≠y)
    (lo : 2≤D.degree z) (hi : ∀ u,u≠z→4≤D.degree u)
    (ex : ∃ u,D.Adj z u ∧ u≠x ∧ u≠y) :
    ∃ p : D.Walk x y,p.IsPath ∧ 5≤p.length := by
  classical
  obtain ⟨f,j,x0,y1,jz,jn⟩ := Graffiti189LongestPath.MarkedWingPath.labels x y z xy (by decide : 6≤6) (Fintype.equivFinOfCardEq card).symm zy
  let G : SimpleGraph (Fin 6) := D.comap f
  letI : DecidableRel G.Adj := fun u v => inferInstanceAs (Decidable (D.Adj (f u) (f v)))
  have deg (i : Fin 6) : G.degree i=D.degree (f i) := by
    rw [←G.card_neighborFinset_eq_degree,←D.card_neighborFinset_eq_degree]
    apply card_bij' (fun a _ => f a) (fun b _ => f.symm b)
    · intro a aa
      exact (D.mem_neighborFinset _ _).mpr ((G.mem_neighborFinset _ _).mp aa)
    · intro a aa
      exact (G.mem_neighborFinset _ _).mpr (by
        change D.Adj (f i) (f (f.symm a))
        rw [f.apply_symm_apply]
        exact (D.mem_neighborFinset _ _).mp aa)
    · intro u hu; exact f.symm_apply_apply u
    · intro u hu; exact f.apply_symm_apply u
  have d (i : Fin 6) : (if i=j then 2 else 4)≤G.degree i := by
    rw [deg]
    by_cases h : i=j
    · subst i
      rw [if_pos rfl,jz]
      exact lo
    · rw [if_neg h]
      exact hi _ (fun e => h (f.injective (e.trans jz.symm)))
  have ex' : ∃ u,G.Adj j u ∧ u≠0 ∧ u≠1 := by
    obtain ⟨u,adj,ux,uy⟩ := ex
    refine ⟨f.symm u,?_,fun e => ux ?_,fun e => uy ?_⟩
    · change D.Adj (f j) (f (f.symm u))
      rwa [jz,f.apply_symm_apply]
    · exact (f.apply_symm_apply u).symm.trans ((congrArg f e).trans x0)
    · exact (f.apply_symm_apply u).symm.trans ((congrArg f e).trans y1)
  have route : ∃ q : G.Walk 0 1,q.IsPath ∧ 5≤q.length := by
    rcases jn with rfl|rfl
    · exact WingSixHamiltonSat.Core60.fixed d ex'
    · exact WingSixHamiltonSat.Core62.fixed d ex'
  obtain ⟨q,qp,ql⟩ := route
  let h : G →g D := ⟨f,fun e => e⟩
  let p := q.map h
  have pp := map_isPath_of_injective (show Function.Injective h from f.injective) qp
  have pl : 5≤p.length := by simpa [p] using ql
  exact ⟨p.copy x0 y1,by simpa [p] using pp,by simpa [p] using pl⟩

def Good (D : SimpleGraph W) (u v : W) : Prop :=
    ∃ p : D.Walk u v,p.IsPath ∧ 5≤p.length

theorem endpoint_exception (card : Fintype.card W=6)
    (lo : 2≤D.degree z) (hi : ∀ u,u≠z→4≤D.degree u) {x y : W} (xy : x≠y)
    (bad : ¬ Good D x y) : D.neighborFinset z={x,y} := by
  classical
  have sub : D.neighborFinset z⊆{x,y} := by
    intro v vv
    by_contra! vn
    have vx : v≠x := fun e => vn (mem_insert.mpr (Or.inl e))
    have vy : v≠y := fun e => vn (mem_insert.mpr (Or.inr (mem_singleton.mpr e)))
    have ze := (D.mem_neighborFinset _ _).mp vv
    by_cases zy : z=y
    · obtain ⟨p,ph,pl⟩ := with_exception card z y x xy.symm
        (fun zx => xy (zx.symm.trans zy)) lo hi ⟨v,ze,vy,vx⟩
      exact bad ⟨p.reverse,ph.reverse,by simpa using pl⟩
    · exact bad (with_exception card z x y xy zy lo hi ⟨v,ze,vx,vy⟩)
  apply eq_of_subset_of_card_le sub
  rw [D.card_neighborFinset_eq_degree]
  simpa [xy] using lo

theorem unique_exception (card : Fintype.card W=6)
    (lo : ∀ u,2≤D.degree u)
    (pair : ∀ u v,u≠v→4≤D.degree u ∨ 4≤D.degree v) :
    ∀ x y u v, x≠y → u≠v → ¬Good D x y → ¬Good D u v →
      ({x,y}:Finset W)={u,v} := by
  intro x y u v xy uv bad1 bad2
  by_cases low : ∃ z,D.degree z<4
  · obtain ⟨z,lz⟩ := low
    have hi (w : W) (wz : w≠z) := (pair w z wz).resolve_right (Nat.not_le_of_lt lz)
    exact (endpoint_exception card (lo z) hi xy bad1).symm.trans
      (endpoint_exception card (lo z) hi uv bad2)
  · have hi (w : W) (_ : w≠x) : 4≤D.degree w :=
      Nat.le_of_not_gt (fun h => low ⟨w,h⟩)
    have e := endpoint_exception card (lo x) hi xy bad1
    exact (D.irrefl : ¬D.Adj x x) ((D.mem_neighborFinset x x).mp
      (e.symm ▸ mem_insert_self x ({y}:Finset W))) |>.elim

#print axioms unique_exception
end Graffiti189LongestPath.WingSixHamiltonPath
