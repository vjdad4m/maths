#!/bin/bash
set -euo pipefail
root=$(cd "$(dirname "$0")" && pwd)
cd "$root"
sha256sum -c SOURCES.sha256
out=$(mktemp -d)
trap 'rm -rf "$out"' EXIT
export LEAN_PATH="$out${LEAN_PATH:+:$LEAN_PATH}"
for m in MarkedWingSat189 MarkedWing60Cert189 MarkedWing62Cert189 MarkedWing70Cert189 MarkedWing72Cert189 MarkedWing80Cert189 MarkedWing82Cert189 MarkedWingPath189 DenseOwnerRoute189 WingSixHamiltonSat189 WingHamilton60Cert189 WingHamilton62Cert189 WingSixHamiltonPath189 SixWingFrontier189 FiveCheapBudget17R_189 FiveSharedCharges17R_189 FiveEdgeBudget17R_189 FiveEdgeLayout17R_189 FiveLongerWord17R_189 FiveMidBudget17R_189 FiveMidSplice17R_189 FivePinLayout17R_189 CloseFive17R_189 FiveCheapBudget18_189 FiveSharedCharges18_189 FiveEdgeBudget18_189 FiveEdgeLayout18_189 FiveLongerWord18_189 FiveMidBudget18L4_189 FiveMidSplice18L4_189 FiveMidBudget18L5_189 FiveMidSplice18L5_189 FiveMidBudget18L7_189 FiveMidSplice18L7_189 FiveMidBudget18L10_189 FiveMidSplice18L10_189 FiveMidBudget18L12_189 FiveMidSplice18L12_189 FiveMidBudget18L13_189 FiveMidSplice18L13_189 FiveGapFour18_189 FivePinLayout18_189 CloseFive18_189 DenseOwnerNine189 ShortWing90Cert189 ShortWing92Cert189 MarkedWingPathNine189 DenseInsideCharges189 DenseEndpointBudget189 DenseEndpointLayout189 SixFourOrderTwentyFour189; do
  lean -j1 -s32768 -DElab.async=false -DwarningAsError=true --root="$root" -o "$out/$m.olean" "$root/$m.lean"
done
