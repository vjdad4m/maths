import Mathlib.Tactic.Sat.FromLRAT
/- Adapted from the checked Mathlib proof builder by the #384b team. -/

/-! The Mathlib LRAT proof-step builder, with each used clause checked as
a separate kernel theorem. This shares learned clauses by theorem
constants rather than substituting a large proof expression DAG.
Modeled on Mathlib.Tactic.Sat.FromLRAT.buildProof (Apache-2.0).
-/
open Lean Elab Meta
open Mathlib.Tactic.Sat

namespace Graffiti189LongestPath.GraphSat

private def buildModularRup (cnf trace : String) (name : Name) : MetaM Unit := do
  let .success _ (_,arr) := Parser.parseDimacs cnf.mkIterator
    | throwError "parse CNF failed"
  if arr.isEmpty then throwError "empty CNF"
  let .success _ steps := Parser.parseLRAT trace.mkIterator
    | throwError "parse LRAT failed"
  let ctx := name ++ `formula
  let ctx' := buildConj arr 0 arr.size
  let c := mkConst ctx
  addDecl <| .defnDecl {
    name := ctx, levelParams := [], type := mkConst ``_root_.Sat.Fmla,
    value := ctx', hints := .regular 0, safety := .safe }
  let p := mkApp (mkConst ``_root_.Sat.Fmla.subsumes_self) c
  let mut db := (buildClauses arr c 0 arr.size ctx' p default).2
  let mut closed : Std.HashSet Nat := {}
  for step in steps do
    match step with
    | .del ds => db := ds.foldl (·.erase ·) db
    | .add i ls hints =>
      for id in hints do
        let id := id.natAbs
        if !closed.contains id then
          let some row := db[id]? | throwError "unknown hint {id}"
          let fact := .num (name ++ `row) id
          addDecl <| .thmDecl {
            name := fact, levelParams := [],
            type := mkApp2 (mkConst ``_root_.Sat.Fmla.proof) c row.expr,
            value := row.proof }
          db := db.insert id {row with proof := mkConst fact}
          closed := closed.insert id
      let e := buildClause ls
      let .ok proof := buildProofStep db ls hints c e
        | throwError "invalid RUP addition {i}"
      let fact := if ls.isEmpty then name else .num (name ++ `row) i
      addDecl <| .thmDecl {
        name := fact, levelParams := [],
        type := mkApp2 (mkConst ``_root_.Sat.Fmla.proof) c e,
        value := proof }
      if ls.isEmpty then return ()
      db := db.insert i {lits := ls, expr := e, proof := mkConst fact}
      closed := closed.insert i
  throwError "proof never derived the empty clause"

elab "graph_rup " n:ident ppSpace cnf:term:max ppSpace trace:term:max : command => do
  let name := (← getCurrNamespace) ++ n.getId
  Command.liftTermElabM do
    let c ← unsafe Term.evalTerm String (mkConst ``String) cnf
    let t ← unsafe Term.evalTerm String (mkConst ``String) trace
    buildModularRup c t name

end Graffiti189LongestPath.GraphSat
