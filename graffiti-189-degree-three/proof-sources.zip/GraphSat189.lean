import Mathlib.Tactic.Sat.FromLRAT
import Mathlib.Data.Finset.Card
import Mathlib.Data.List.Chain
import Mathlib.Data.List.FinRange
import Lean.Elab.Tactic.Omega
open Finset

namespace Graffiti189LongestPath.GraphSat

def allowed {n : ℕ} (layer : Fin n→ℕ) (i j : Fin n) : Prop :=
  i≠j ∧ layer i≤layer j+1 ∧ layer j≤layer i+1

instance {n : ℕ} (layer : Fin n→ℕ) (i j : Fin n) : Decidable (allowed layer i j) := by
  unfold allowed
  infer_instance

def edgeId {n : ℕ} (i j : Fin n) : ℕ :=
  n * min i.val j.val + max i.val j.val

def nearId {n : ℕ} (i j : Fin n) : ℕ := n*n+edgeId i j

inductive Rule (n : ℕ) where
  | forbid (i j : Fin n)
  | pred (i : Fin n)
  | degree (i a b : Fin n)
  | two (i m j : Fin n)
  | cap (i a b c d : Fin n)
  | route (p : List (Fin n))

def pathEdges {n : ℕ} : List (Fin n)→List (Fin n×Fin n)
  | i::j::xs => (i,j)::pathEdges (j::xs)
  | _ => []

def Rule.clause {n : ℕ} (layer : Fin n→ℕ) : Rule n→Sat.Clause
  | .forbid i j => [.neg (edgeId i j)]
  | .pred i => ((List.finRange n).filter (fun j => layer j+1=layer i)).map
      (fun j => .pos (edgeId i j))
  | .degree i a b => ((List.finRange n).filter (fun j => allowed layer i j ∧ j≠a ∧ j≠b)).map
      (fun j => .pos (edgeId i j))
  | .two i m j => [.neg (edgeId i m),.neg (edgeId m j),.pos (edgeId i j),.pos (nearId i j)]
  | .cap i a b c d => [.neg (nearId i a),.neg (nearId i b),.neg (nearId i c),.neg (nearId i d)]
  | .route p => (pathEdges p).map (fun (i,j) => .neg (edgeId i j))

def Rule.WF {n : ℕ} (layer : Fin n→ℕ) (high : Fin n→Bool) (routed : Bool) : Rule n→Prop
  | .forbid i j => ¬allowed layer i j
  | .pred i => 1≤layer i
  | .degree i _ _ => high i=true
  | .two i _ j => i≠j
  | .cap _ a b c d => [a,b,c,d].Nodup
  | .route p => routed=true ∧ p.Nodup ∧ ∀ i,i∈p

instance {n : ℕ} (layer : Fin n→ℕ) (high : Fin n→Bool) (routed : Bool) (r : Rule n) :
    Decidable (r.WF layer high routed) := by
  cases r <;> simp only [Rule.WF] <;> infer_instance

structure Model {n : ℕ} (layer : Fin n→ℕ) (high : Fin n→Bool) (routed : Bool)
    (A D : Fin n→Fin n→Prop) : Prop where
  symA : Symmetric A
  symD : Symmetric D
  edges : ∀ i j,A i j → allowed layer i j
  pred : ∀ i,1≤layer i → ∃ j,layer j+1=layer i ∧ A i j
  three : ∀ i,high i=true → ∀ a b,∃ j,j≠a ∧ j≠b ∧ A i j
  near : ∀ i m j,i≠j → A i m → A m j → ¬A i j → D i j
  cap : ∀ i a b c d,[a,b,c,d].Nodup → D i a → D i b → D i c → D i d → False
  noPath : routed=true → ∀ p : List (Fin n),p.Nodup → (∀ i,i∈p) →
    (∀ i j,(i,j)∈pathEdges p → A i j) → False

private def valuation {n : ℕ} (positive : 0<n) (A D : Fin n→Fin n→Prop) : Sat.Valuation :=
  fun k =>
    let t := if k<n*n then k else k-n*n
    let a : Fin n := ⟨(t/n)%n,Nat.mod_lt _ positive⟩
    let b : Fin n := ⟨t%n,Nat.mod_lt _ positive⟩
    if k<n*n then A a b else D a b

private theorem code_lt {n : ℕ} (i j : Fin n) : n*i.val+j.val<n*n := by
  have u := Nat.mul_le_mul_left n (show i.val+1≤n by omega)
  rw [Nat.mul_add,Nat.mul_one] at u
  omega

private theorem val_ordered_edge {n : ℕ} (pos : 0<n) (A D : Fin n→Fin n→Prop)
    (i j : Fin n) (ij : i.val≤j.val) : valuation pos A D (edgeId i j) ↔ A i j := by
  have ii : (n*i.val+j.val)/n=i.val := by
    rw [Nat.mul_add_div pos,Nat.div_eq_of_lt j.isLt,Nat.add_zero]
  have jj : (n*i.val+j.val)%n=j.val := by rw [Nat.mul_add_mod,Nat.mod_eq_of_lt j.isLt]
  have lo := code_lt i j
  simp only [valuation,edgeId,min_eq_left ij,max_eq_right ij,if_pos lo,ii,jj,Nat.mod_eq_of_lt i.isLt]

private theorem val_ordered_near {n : ℕ} (pos : 0<n) (A D : Fin n→Fin n→Prop)
    (i j : Fin n) (ij : i.val≤j.val) : valuation pos A D (nearId i j) ↔ D i j := by
  have ii : (n*i.val+j.val)/n=i.val := by
    rw [Nat.mul_add_div pos,Nat.div_eq_of_lt j.isLt,Nat.add_zero]
  have jj : (n*i.val+j.val)%n=j.val := by rw [Nat.mul_add_mod,Nat.mod_eq_of_lt j.isLt]
  have hi : ¬n*n+(n*i.val+j.val)<n*n := by omega
  simp only [valuation,nearId,edgeId,min_eq_left ij,max_eq_right ij,if_neg hi,Nat.add_sub_cancel_left,
    ii,jj,Nat.mod_eq_of_lt i.isLt]

private theorem val_edge {n : ℕ} (pos : 0<n) (A D : Fin n→Fin n→Prop)
    (symm : Symmetric A) (i j : Fin n) : valuation pos A D (edgeId i j) ↔ A i j := by
  rcases le_total i.val j.val with iz|iz
  · exact val_ordered_edge pos A D i j iz
  · have e : edgeId i j=edgeId j i := by simp [edgeId,min_comm,max_comm]
    rw [e,val_ordered_edge pos A D j i iz]
    exact ⟨fun h => symm h,fun h => symm h⟩

private theorem val_near {n : ℕ} (pos : 0<n) (A D : Fin n→Fin n→Prop)
    (symm : Symmetric D) (i j : Fin n) : valuation pos A D (nearId i j) ↔ D i j := by
  rcases le_total i.val j.val with iz|iz
  · exact val_ordered_near pos A D i j iz
  · have e : nearId i j=nearId j i := by simp [nearId,edgeId,min_comm,max_comm]
    rw [e,val_ordered_near pos A D j i iz]
    exact ⟨fun h => symm h,fun h => symm h⟩

private theorem sat_of_true_literal (v : Sat.Valuation) (s : List Sat.Literal)
    (l : Sat.Literal) (ls : l∈s) (notFalse : ¬v.neg l) : v.satisfies s := by
  induction s with
  | nil => simp at ls
  | cons a s ih =>
    rcases List.mem_cons.mp ls with e|r
    · subst a
      exact fun x => (notFalse x).elim
    · exact fun _ => ih r

private theorem all_false_of_not_sat (v : Sat.Valuation) (s : List Sat.Literal) (no : ¬v.satisfies s)
    (l : Sat.Literal) (ls : l∈s) : v.neg l :=
  Classical.byContradiction (fun h => no (sat_of_true_literal v s l ls h))

/-- Every signed clause has the promised graph semantics. -/
theorem proof_impossible {n : ℕ} (pos : 0<n) {layer : Fin n→ℕ} {high : Fin n→Bool}
    {routed : Bool} {A D : Fin n→Fin n→Prop} (M : Model layer high routed A D)
    (rules : List (Rule n)) (ok : ∀ r∈rules,r.WF layer high routed)
    (q : Sat.Fmla.proof (rules.map (Rule.clause layer)) []) : False := by
  classical
  let v := valuation pos A D
  have a (u w : Fin n) : v (edgeId u w) ↔ A u w := val_edge pos A D M.symA u w
  have d (u w : Fin n) : v (nearId u w) ↔ D u w := val_near pos A D M.symD u w
  apply q v
  constructor
  intro C hC
  obtain ⟨r,rr,rfl⟩ := List.mem_map.mp hC
  have hr := ok r rr
  cases r with
  | forbid i j =>
    change v (edgeId i j)→False
    exact fun h => hr (M.edges i j ((a i j).mp h))
  | pred i =>
    obtain ⟨j,hj,hA⟩ := M.pred i hr
    apply sat_of_true_literal v _ (.pos (edgeId i j))
    · apply List.mem_map.mpr
      exact ⟨j,by simp [hj],rfl⟩
    · exact fun b => b ((a i j).mpr hA)
  | degree i x y =>
    obtain ⟨j,xj,yj,hA⟩ := M.three i hr x y
    apply sat_of_true_literal v _ (.pos (edgeId i j))
    · apply List.mem_map.mpr
      exact ⟨j,by simp [M.edges i j hA,xj,yj],rfl⟩
    · exact fun b => b ((a i j).mpr hA)
  | two i m j =>
    change v (edgeId i m)→v (edgeId m j)→¬v (edgeId i j)→¬v (nearId i j)→False
    intro p q r w
    exact w ((d i j).mpr (M.near i m j hr ((a i m).mp p) ((a m j).mp q)
      (fun h => r ((a i j).mpr h))))
  | cap i p q r s =>
    change v (nearId i p)→v (nearId i q)→v (nearId i r)→v (nearId i s)→False
    exact fun x y z w => M.cap i p q r s hr ((d i p).mp x) ((d i q).mp y)
      ((d i r).mp z) ((d i s).mp w)
  | route p =>
    apply Classical.byContradiction
    intro no
    exact M.noPath hr.1 p hr.2.1 hr.2.2 (fun i j hij =>
      (a i j).mp (all_false_of_not_sat v _ no (.neg (edgeId i j))
        (List.mem_map.mpr ⟨(i,j),hij,rfl⟩)))

#print axioms proof_impossible
end Graffiti189LongestPath.GraphSat
