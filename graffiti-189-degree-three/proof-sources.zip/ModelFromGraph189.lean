import ShellLayout189
import OreClosure189

open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open private Graffiti189LongestPath.mem_distanceTwo Graffiti189LongestPath.dist_two from SmallSeparator189

namespace Graffiti189LongestPath.GraphSat

variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

omit [Fintype V] [DecidableEq V] [DecidableRel G.Adj] in
private theorem walk_of_chain (a : V) (L : List V)
    (cl : List.Chain' G.Adj (a::L)) : ∃ b,∃ q : G.Walk a b,q.support=a::L := by
  induction L generalizing a with
  | nil => exact ⟨a,.nil,rfl⟩
  | cons b L ih =>
    obtain ⟨c,q,eq⟩ := ih b cl.tail
    exact ⟨c,.cons cl.rel_head q,by simp [eq]⟩

omit [Fintype V] [DecidableEq V] [DecidableRel G.Adj] in
private theorem chain_of_pathEdges {n : ℕ} (f : Fin n→V) (p : List (Fin n))
    (adj : ∀ i j,(i,j)∈pathEdges p → G.Adj (f i) (f j)) :
    (p.map f).Chain' G.Adj := by
  induction p with
  | nil => simp
  | cons i p ih =>
    cases p with
    | nil => simp
    | cons j p =>
      simp only [List.map_cons,List.chain'_cons]
      exact ⟨adj i j (by simp [pathEdges]),ih (fun a b ab => adj a b (by
        simp only [pathEdges,List.mem_cons]; exact Or.inr ab))⟩

/-- Give the SAT abstraction its actual graph interpretation. No Boolean
approximations are trusted: two-step charges and candidate route clauses
are semantic consequences of the graph assumptions. -/
theorem model_of_graph {n : ℕ} (hc : G.Connected) (r : V) (f : Fin n ↪ V)
    (layer : Fin n→ℕ) (high : Fin n→Bool) (routed : Bool)
    (lab : ∀ i,G.dist r (f i)=layer i)
    (pred : ∀ i z,G.dist r z+1=layer i → ∃ j,f j=z)
    (highDegree : ∀ i,high i=true → 3≤G.degree (f i))
    (highCover : ∀ i,high i=true → ∀ z,G.Adj (f i) z → ∃ j,f j=z)
    (cap : ∀ u,(DistanceTwo G u).card≤3)
    (all : routed=true → ∀ z,∃ i,f i=z)
    (noPath : ¬Graffiti189Ore.Traceable G) :
    Model layer high routed (fun i j => G.Adj (f i) (f j))
      (fun i j => G.dist (f i) (f j)=2) := by
  classical
  refine ⟨(fun {_ _} h => h.symm),(fun {i j} eq => by rwa [dist_comm]),?_,?_,?_,?_,?_,?_⟩
  · intro i j adj
    have ij := dist_eq_one_iff_adj.mpr adj
    have ji := dist_eq_one_iff_adj.mpr adj.symm
    have t := hc.dist_triangle (u:=r) (v:=f i) (w:=f j)
    have u := hc.dist_triangle (u:=r) (v:=f j) (w:=f i)
    rw [ij,lab i,lab j] at t
    rw [ji,lab i,lab j] at u
    exact ⟨fun e => adj.ne (congrArg f e),u,t⟩
  · intro i pos
    have eq : G.dist r (f i)=(layer i-1)+1 := by rw [lab]; omega
    obtain ⟨x,xl,xa⟩ := LowDegreeOrders.predecessor hc eq
    obtain ⟨j,e⟩ := pred i x (by omega)
    exact ⟨j,by rw [←lab j,e,xl]; omega,e.symm ▸ xa.symm⟩
  · intro i hi a b
    apply Classical.byContradiction
    intro no
    have s : G.neighborFinset (f i)⊆({f a,f b}:Finset V) := by
      intro z zn
      have zz := (G.mem_neighborFinset _ _).mp zn
      obtain ⟨j,e⟩ := highCover i hi z zz
      rw [←e] at zz ⊢
      by_cases ja : j=a
      · simp [ja]
      · by_cases jb : j=b
        · simp [jb]
        · exact (no ⟨j,ja,jb,zz⟩).elim
    have c := card_le_card s
    rw [G.card_neighborFinset_eq_degree] at c
    have p := card_insert_le (f a) ({f b}:Finset V)
    rw [card_singleton] at p
    have g := highDegree i hi
    omega
  · intro i m j ne im mj ij
    exact Graffiti189LongestPath.dist_two hc (fun e => ne (f.injective e)) ij im mj
  · intro i a b c d hn aa bb cc dd
    let L := [a,b,c,d].map f
    have nL : L.Nodup := hn.map f.injective
    have cnt : L.toFinset.card=4 := by rw [List.toFinset_card_of_nodup nL]; rfl
    have sub : L.toFinset⊆DistanceTwo G (f i) := by
      intro z hz
      obtain ⟨j,jm,e⟩ := List.mem_map.mp (List.mem_toFinset.mp hz)
      subst z
      simp only [List.mem_cons,List.not_mem_nil,or_false] at jm
      apply Graffiti189LongestPath.mem_distanceTwo.mpr
      rcases jm with rfl|rfl|rfl|rfl <;> assumption
    have z := (card_le_card sub).trans (cap (f i))
    omega
  · intro on p pn ps adj
    let L := p.map f
    have np : L.Nodup := pn.map f.injective
    have cp : L.Chain' G.Adj := chain_of_pathEdges f p adj
    have every (z : V) : z∈L := by
      obtain ⟨i,ie⟩ := all on z
      exact List.mem_map.mpr ⟨i,ps i,ie⟩
    apply noPath
    cases e : L with
    | nil =>
      have h := every r
      simp [e] at h
    | cons u s =>
      have pth := walk_of_chain u s (e ▸ cp)
      obtain ⟨v,q,sup⟩ := pth
      refine ⟨u,v,q,?_,?_⟩
      · rw [isPath_def,sup,←e]
        exact np
      · intro z
        rw [sup,←e]
        exact every z

#print axioms model_of_graph
end Graffiti189LongestPath.GraphSat
