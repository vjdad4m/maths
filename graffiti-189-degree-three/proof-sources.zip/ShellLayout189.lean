import GraphSat189
import LowDegreeOrders189

open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open private Graffiti189LongestPath.mem_distanceTwo Graffiti189LongestPath.dist_two from SmallSeparator189

namespace Graffiti189LongestPath.GraphSat

def layerOf (a b c d : ℕ) (i : Fin (1+a+b+c+d)) : ℕ :=
  if i.val=0 then 0 else if i.val<1+a then 1 else if i.val<1+a+b then 2 else
    if i.val<1+a+b+c then 3 else 4

variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

omit [DecidableEq V] [DecidableRel G.Adj] in
private theorem shellLists_disjoint (r : V) (S T : Finset V) (i j : ℕ) (ij : i≠j)
    (si : S⊆Shell G r i) (tj : T⊆Shell G r j) :
    ∀ v∈S.toList,v∉T.toList := by
  intro v vs vt
  exact ij ((mem_shell.mp (si (Finset.mem_toList.mp vs))).symm.trans
    (mem_shell.mp (tj (Finset.mem_toList.mp vt))))

omit [DecidableEq V] [DecidableRel G.Adj] in
/-- Concatenate the root and chosen parts of four successive shells to
obtain the fixed finite indexing used by the graph-native certificates. -/
theorem exists_shell_layout (r : V) (A B C D : Finset V)
    (sA : A⊆Shell G r 1) (sB : B⊆Shell G r 2)
    (sC : C⊆Shell G r 3) (sD : D⊆Shell G r 4)
    (a b c d : ℕ) (cA : A.card=a) (cB : B.card=b) (cC : C.card=c) (cD : D.card=d) :
    ∃ f : Fin (1+a+b+c+d) ↪ V,
      (∀ i,G.dist r (f i)=layerOf a b c d i) ∧
      (∀ v, (∃ i,f i=v) ↔ v=r ∨ v∈A ∨ v∈B ∨ v∈C ∨ v∈D) := by
  classical
  let L0 := [r]
  let L1 := L0++A.toList
  let L2 := L1++B.toList
  let L3 := L2++C.toList
  let L4 := L3++D.toList
  have h1 : L1.length=1+a := by simp [L1,L0,cA,Nat.add_comm]
  have h2 : L2.length=1+a+b := by simp [L2,h1,cB]
  have h3 : L3.length=1+a+b+c := by simp [L3,h2,cC]
  have h4 : L4.length=1+a+b+c+d := by simp [L4,h3,cD]
  have root_not (S : Finset V) (i : ℕ) (ne : i≠0) (s : S⊆Shell G r i) : r∉S.toList := by
    intro h
    have e := mem_shell.mp (s (Finset.mem_toList.mp h))
    exact ne (e.symm.trans (SimpleGraph.dist_self))
  have n1 : L1.Nodup := by
    rw [List.nodup_append]
    refine ⟨by simp [L0],Finset.nodup_toList _,?_⟩
    intro z zl
    have e : z=r := by simpa [L0] using zl
    subst z; exact root_not A 1 (by decide) sA
  have leftApart (S : Finset V) (i : ℕ) (hi : 1<i) (hs : S⊆Shell G r i) :
      ∀ z∈L1,z∉S.toList := by
    intro z zz
    rcases List.mem_append.mp zz with e|e
    · have a : z=r := by simpa [L0] using e
      subst z; exact root_not S i (by omega) hs
    · exact shellLists_disjoint r A S 1 i (by omega) sA hs z e
  have n2 : L2.Nodup := by
    rw [List.nodup_append]
    exact ⟨n1,Finset.nodup_toList _,leftApart B 2 (by decide) sB⟩
  have n3 : L3.Nodup := by
    rw [List.nodup_append]
    refine ⟨n2,Finset.nodup_toList _,?_⟩
    intro z zz
    rcases List.mem_append.mp zz with h|h
    · exact leftApart C 3 (by decide) sC z h
    · exact shellLists_disjoint r B C 2 3 (by decide) sB sC z h
  have n4 : L4.Nodup := by
    rw [List.nodup_append]
    refine ⟨n3,Finset.nodup_toList _,?_⟩
    intro z zz
    rcases List.mem_append.mp zz with zz|h
    · rcases List.mem_append.mp zz with h|h
      · exact leftApart D 4 (by decide) sD z h
      · exact shellLists_disjoint r B D 2 4 (by decide) sB sD z h
    · exact shellLists_disjoint r C D 3 4 (by decide) sC sD z h
  let f : Fin (1+a+b+c+d) ↪ V :=
    ⟨fun i => L4[i.val]'(by rw [h4]; exact i.isLt),
      fun i j e => Fin.ext (n4.getElem_inj_iff.mp e)⟩
  refine ⟨f,?_,?_⟩
  · intro i
    have ib := i.isLt
    have i4 : i.val<L4.length := by rwa [h4]
    change G.dist r (L4[i.val]'(i4)) = layerOf a b c d i
    unfold layerOf
    by_cases hd : i.val<L3.length
    · change G.dist r ((L3++D.toList)[i.val]'(i4)) = _
      rw [List.getElem_append_left hd]
      by_cases hc : i.val<L2.length
      · change G.dist r (L2++C.toList)[i.val] = _
        rw [List.getElem_append_left hc]
        by_cases hb : i.val<L1.length
        · change G.dist r (L1++B.toList)[i.val] = _
          rw [List.getElem_append_left hb]
          by_cases za : i.val=0
          · have e : L1[i.val] = r := by simp [L1,L0,za]
            rw [e,SimpleGraph.dist_self]
            simp [za]
          · have hn : L0.length≤i.val := by simp [L0]; omega
            change G.dist r (L0++A.toList)[i.val] = _
            rw [List.getElem_append_right hn]
            have ii : i.val-L0.length<A.toList.length := by
              simp [L0,cA]
              rw [h1] at hb
              omega
            have m := Finset.mem_toList.mp (List.getElem_mem ii)
            have e := mem_shell.mp (sA m)
            rw [e]
            simp [za,(show i.val<1+a by omega)]
        · have nn : L1.length≤i.val := by omega
          change G.dist r (L1++B.toList)[i.val] = _
          rw [List.getElem_append_right nn]
          have ii : i.val-L1.length<B.toList.length := by simp [cB,h1]; omega
          have m := Finset.mem_toList.mp (List.getElem_mem ii)
          rw [mem_shell.mp (sB m)]
          simp [show i.val≠0 by omega,show ¬i.val<1+a by omega,show i.val<1+a+b by omega]
      · have nn : L2.length≤i.val := by omega
        change G.dist r (L2++C.toList)[i.val] = _
        rw [List.getElem_append_right nn]
        have ii : i.val-L2.length<C.toList.length := by simp [cC,h2]; omega
        have m := Finset.mem_toList.mp (List.getElem_mem ii)
        rw [mem_shell.mp (sC m)]
        simp [show i.val≠0 by omega,show ¬i.val<1+a by omega,
          show ¬i.val<1+a+b by omega,show i.val<1+a+b+c by omega]
    · have nn : L3.length≤i.val := by omega
      change G.dist r ((L3++D.toList)[i.val]'(i4)) = _
      rw [List.getElem_append_right nn]
      have ii : i.val-L3.length<D.toList.length := by simp [cD,h3]; omega
      have m := Finset.mem_toList.mp (List.getElem_mem ii)
      rw [mem_shell.mp (sD m)]
      simp [show i.val≠0 by omega,show ¬i.val<1+a by omega,
        show ¬i.val<1+a+b by omega,show ¬i.val<1+a+b+c by omega]
  · intro v
    have e : (∃ i,f i=v) ↔ v∈L4 := by
      constructor
      · rintro ⟨i,hi⟩
        exact hi ▸ List.getElem_mem _
      · intro h
        obtain ⟨i,ib,e⟩ := List.mem_iff_getElem.mp h
        exact ⟨⟨i,by rwa [h4] at ib⟩,e⟩
    rw [e]
    simp [L0,L1,L2,L3,L4,or_assoc]

#print axioms exists_shell_layout
end Graffiti189LongestPath.GraphSat
