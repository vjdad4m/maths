import ModelFromGraph189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath

namespace Graffiti189LongestPath.GraphSat

def profileHigh (a b c d : ℕ) (routed : Bool) (i : Fin (1+a+b+c+d)) : Bool :=
  if routed then decide (i.val≠0) else decide (layerOf a b c d i=1)

variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem exists_shell_model (hc : G.Connected) (r : V) (C D : Finset V)
    (subC : C⊆Shell G r 3) (subD : D⊆Shell G r 4)
    (a b c d : ℕ) (ca : (Shell G r 1).card=a) (cb : (Shell G r 2).card=b)
    (cc : C.card=c) (cd : D.card=d)
    (routed : Bool) (d0 : routed=false → d=0)
    (full : routed=true → ∀ z : V,z=r ∨ z∈Shell G r 1 ∨ z∈Shell G r 2 ∨ z∈C ∨ z∈D)
    (high : ∀ z≠r,3≤G.degree z)
    (cap : ∀ z,(DistanceTwo G z).card≤3)
    (noPath : ¬Graffiti189Ore.Traceable G) :
    ∃ f : Fin (1+a+b+c+d) ↪ V,
      Model (layerOf a b c d) (profileHigh a b c d routed) routed
        (fun i j => G.Adj (f i) (f j)) (fun i j => G.dist (f i) (f j)=2) := by
  obtain ⟨f,lab,cover⟩ := exists_shell_layout r (Shell G r 1) (Shell G r 2) C D
    Subset.rfl Subset.rfl subC subD a b c d ca cb cc cd
  have cover2 (z : V) (h : G.dist r z≤2) : ∃ i,f i=z := by
    apply (cover z).mpr
    have e : G.dist r z=0 ∨ G.dist r z=1 ∨ G.dist r z=2 := by omega
    rcases e with e|e|e
    · exact Or.inl (hc.dist_eq_zero_iff.mp e).symm
    · exact Or.inr (Or.inl (mem_shell.mpr e))
    · exact Or.inr (Or.inr (Or.inl (mem_shell.mpr e)))
  have coverAll (on : routed=true) (z : V) : ∃ i,f i=z := (cover z).mpr (full on z)
  have layer3 (off : routed=false) (i : Fin (1+a+b+c+d)) : layerOf a b c d i≤3 := by
    have h := i.isLt
    have dd := d0 off
    have k : i.val<1+a+b+c := by omega
    unfold layerOf
    split <;> try omega
    split <;> try omega
    split <;> try omega
  refine ⟨f,model_of_graph hc r f (layerOf a b c d) (profileHigh a b c d routed) routed
    lab ?_ ?_ ?_ cap coverAll noPath⟩
  · intro i z e
    cases h : routed
    · have l := layer3 h i
      exact cover2 z (by omega)
    · exact coverAll h z
  · intro i hi
    have fi : f i≠r := by
      intro e
      have l := lab i
      rw [e,SimpleGraph.dist_self] at l
      cases h : routed
      · simp [profileHigh,h,←l] at hi
      · have nz : i.val≠0 := by simpa [profileHigh,h] using hi
        unfold layerOf at l
        simp only [if_neg nz] at l
        split at l <;> try omega
        split at l <;> try omega
        split at l <;> omega
    exact high (f i) fi
  · intro i hi z iz
    cases h : routed
    · have e : layerOf a b c d i=1 := by simpa [profileHigh,h] using hi
      have tri := hc.dist_triangle (u:=r) (v:=f i) (w:=z)
      rw [lab i,e,dist_eq_one_iff_adj.mpr iz] at tri
      exact cover2 z tri
    · exact coverAll h z

#print axioms exists_shell_model
end Graffiti189LongestPath.GraphSat
