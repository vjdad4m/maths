from pathlib import Path
from itertools import combinations
import os, sys, subprocess, json, shutil

here=Path(__file__).resolve().parent
solver=Path(os.environ.get("CADICAL", shutil.which("cadical") or "cadical"))

def build(A,B,C,D,prefix):
    lev=[0]+[1]*A+[2]*B+[3]*C+[4]*D
    n=len(lev)
    name=('prefix' if prefix else 'route')+f'{A}{B}{C}{D}'
    v=list(range(n))
    def edge(i,j): return min(i,j)*n+max(i,j)+1
    def near(i,j): return n*n+edge(i,j)
    def allow(i,j):return i!=j and abs(lev[i]-lev[j])<=1
    opt=[[j for j in v if allow(i,j)] for i in v]
    poss=[[z for z in v if z!=u and any(allow(u,m) and allow(m,z) for m in v)] for u in v]
    reasons=[]; clauses=[]
    def add(kind, pars, clause):
        reasons.append((kind,*pars));clauses.append(clause)
    for i,j in combinations(v,2):
        if not allow(i,j):
            add('forbid',[i,j],[-edge(i,j)])
    for i in v[1:]:
        pre=[j for j in v if lev[j]+1==lev[i]]
        add('pred',[i],[edge(i,j) for j in pre])
    degree_atoms=[i for i in v if (lev[i]==1 if prefix else i!=0)]
    for i in degree_atoms:
        for a,b in combinations(opt[i],2):
            add('degree',[i,a,b],[edge(i,j) for j in opt[i] if j not in (a,b)])
    pivots=[i for i in v if (lev[i]==1 if prefix else True)]
    pairs={tuple(sorted((u,z))) for u in pivots for z in poss[u]}
    for u,z in sorted(pairs):
        for m in v:
            if allow(u,m) and allow(m,z):
                add('two',[u,m,z],[-edge(u,m),-edge(m,z),edge(u,z),near(u,z)])
    for u in pivots:
        for q in combinations(poss[u],4):
            add('cap',[u,*q],[-near(u,z) for z in q])
    cnf=here/f'{name}.cnf'; lrat=here/f'{name}.lrat'
    def put():
        cnf.write_text(f'p cnf {2*n*n} {len(clauses)}\n'+''.join(' '.join(map(str,c))+' 0\n' for c in clauses))
    def route(edges):
        adj=[0]*n
        for i,j in combinations(v,2):
            if edge(i,j) in edges:
                adj[i]|=1<<j
                adj[j]|=1<<i
        memo=set()
        def dfs(u, mask):
            if not mask:return [u]
            if (u,mask) in memo:return None
            nex=mask&adj[u]
            while nex:
                bit=nex&-nex;nex^=bit
                r=dfs(bit.bit_length()-1,mask^bit)
                if r is not None:return [u]+r
            memo.add((u,mask));return None
        return next((r for u in v if (r:=dfs(u,((1<<n)-1)^(1<<u))) is not None),None)
    while True:
        put()
        out=subprocess.run([str(solver),'-q',str(cnf)],capture_output=True,text=True)
        if out.returncode==20: break
        if out.returncode!=10: raise ValueError(out)
        if prefix: raise ValueError(f'Prefix unexpectedly SAT: {name}')
        true={int(x) for l in out.stdout.splitlines() if l.startswith('v ') for x in l[2:].split() if int(x)>0}
        p=route(true)
        if p is None:
            raise ValueError(f'Nontraceable abstract assignment {name}: {sorted(true)}')
        add('route',[p],[-edge(i,j) for i,j in zip(p,p[1:])])
    out=subprocess.run([str(solver),'-q','--lrat','--no-binary',str(cnf),str(lrat)],capture_output=True,text=True)
    if out.returncode!=20:raise ValueError(out)
    (here/f'{name}.json').write_text(json.dumps(dict(A=A,B=B,C=C,D=D,n=n,prefix=prefix,levels=lev,reasons=reasons)))
    steps=sum(1 for l in lrat.open() if ' d ' not in l)
    print(name,n,'clauses',len(clauses),'paths',sum(r[0]=='route' for r in reasons),'RUP',steps,flush=True)

for a in (2,3):
    for b in (2,3):build(a,b,5,0,True)
for p in [(2,3,4,0),(2,2,4,1),(3,3,3,0),(3,2,4,0),(3,2,3,1),(3,3,4,0),(3,2,4,1)]:build(*p,False)
