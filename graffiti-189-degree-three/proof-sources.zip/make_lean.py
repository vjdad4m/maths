from pathlib import Path
import json
p=Path(__file__).resolve().parent
for j in p.glob('*.json'):
  d=json.loads(j.read_text()); n=d['n']; a=d['A']; b=d['B']; c=d['C']; routed=str(not d['prefix']).lower(); base=j.stem
  ns=base.title()
  lines=['import GraphSat189','import GraphRup189','',
         'set_option maxHeartbeats 50000000','set_option maxRecDepth 30000',
         'namespace Graffiti189LongestPath.GraphSat.'+ns,'',
         f'def layer (i : Fin {n}) : ℕ :=',
         f'  if i.val=0 then 0 else if i.val<{1+a} then 1 else if i.val<{1+a+b} then 2 else',
         f'    if i.val<{1+a+b+c} then 3 else 4',
         f'def high (i : Fin {n}) : Bool := '+('decide (layer i=1)' if d['prefix'] else 'decide (i.val≠0)'),'',
         f'def rules : List (Rule {n}) := [']
  for typ,*pars in d['reasons']:
    if typ=='route':
      args='['+','.join(map(str,pars[0]))+']'
    else:args=' '.join(map(str,pars))
    lines.append(f'  .{typ} {args},')
  lines[-1]=lines[-1][:-1]
  lines.extend([']','',
    f'graph_rup certificate (include_str "{base}.cnf") (include_str "{base}.lrat")',
    'theorem same_formula : certificate.formula = rules.map (Rule.clause layer) := rfl',
    f'theorem valid_rules : rules.all (fun r => decide (r.WF layer high {routed})) = true := by decide',
    '',
    f'theorem impossible {{A D : Fin {n}→Fin {n}→Prop}}',
    f'    (M : Model layer high {routed} A D) : False := by',
    '  have p := certificate',
    '  rw [same_formula] at p',
    '  apply proof_impossible (by decide) M rules _ p',
    '  intro r rmem',
    '  exact of_decide_eq_true (List.all_eq_true.mp valid_rules r rmem)',
    '',
    '#print axioms impossible',
    f'end Graffiti189LongestPath.GraphSat.{ns}',''])
  (p/f'Cert{ns}189.lean').write_text('\n'.join(lines))
