#!/usr/bin/env bash
set -euo pipefail
src="$(cd "$(dirname "$0")" && pwd)"
obj="$(mktemp -d)"
trap 'rm -rf "$obj"' EXIT
export LEAN_PATH="$obj${LEAN_PATH:+:$LEAN_PATH}"
for module in GraphSat189 GraphRup189 ShellLayout189 ModelFromGraph189 ShellModel189 \
  CertPrefix2250189 CertPrefix2350189 CertPrefix3250189 CertPrefix3350189 \
  CertRoute2340189 CertRoute2241189 CertRoute3330189 CertRoute3240189 CertRoute3231189 \
  CertRoute3340189 CertRoute3241189 DegreeThreeComplete189; do
  printf '== %s ==\n' "$module"
  lean --root="$src" -j1 -s32768 -DElab.async=false -DwarningAsError=true \
    -o "$obj/$module.olean" "$src/$module.lean"
done
