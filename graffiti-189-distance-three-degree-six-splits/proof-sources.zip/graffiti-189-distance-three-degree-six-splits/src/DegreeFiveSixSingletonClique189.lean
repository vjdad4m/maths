import DegreeFiveSixSingletonBridge189
import DegreeFiveSevenNoBridgeClose189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph Finset
open private left_boundary from AdjacentCut189
open private d2 from CrossSaturation189
open private not_common secondA_right_and_left_le_five from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem singleton_four_five_clique (hc : G.Connected)
    (far : 3≤G.dist a b) (even : ∀ z,(EvenFrom G z).card≤6)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (right4 : (S.R.filter (G.Adj b)).card=4)
    (local3 : S.localA.card=3) (a3 : S.foreignA.card=3)
    (rightConnected : (G.induce (↑S.R : Set V)).Connected)
    (rightA : ∃ x∈S.R,G.Adj a x) (rightB : ∃ x∈S.R,G.Adj b x)
    {y : V} (yl : y∈S.L) (by' : G.Adj b y)
    (high : 5≤G.degree y) (only : ∀ z∈S.L,G.Adj b z → z=y) :
    S.L.card=5 ∧
      (∀ u∈S.L,∀ v∈S.L,u≠v → G.Adj u v) ∧
      (∀ z∈S.R,5≤G.degree z) ∧ (secondA G S.R b).card=1 := by
  classical
  have far' : 3≤G.dist b a := by rwa [dist_comm]
  obtain ⟨q,ql,p,pl,bq,qp,ap⟩ :=
    singleton_opposite_four_forces_bridge S hc far even right4 a3 yl by' high only
  change q∈S.L at ql
  have eq := only q ql bq
  subst q
  have univY := bridge_four_forces_universal S.flip hc far' even right4 yl by' qp ap
  let T := switch S.flip rightConnected rightB rightA
  have nonempty : (secondA G S.R b).Nonempty :=
    four_ports_have_second_neighbor T hc far' degree right4
  have pos := card_pos.mpr nonempty
  have localN : S.L.erase y⊆secondA G S.L b := by
    intro z hz
    obtain ⟨ne,zl⟩ := mem_erase.mp hz
    have bz : ¬G.Adj b z := fun e=>ne (only z zl e)
    have bn : b≠z := fun e=>S.leftOff.2 (e.symm ▸ zl)
    have yz := (univY z zl).resolve_left ne
    exact mem_inter.mpr ⟨zl,d2 hc bn bz by' yz⟩
  have lo := card_le_card localN
  rw [card_erase_of_mem yl] at lo
  have sub : G.neighborFinset y⊆insert b (S.L.erase y) := by
    intro z hz
    have yz := (mem_neighborFinset G y z).mp hz
    rcases left_boundary S y yl z yz with rfl|rfl|zl
    · exact (not_common far yz.symm by').elim
    · exact mem_insert_self _ _
    exact mem_insert_of_mem (mem_erase.mpr ⟨yz.ne.symm,zl⟩)
  have up := (card_le_card sub).trans (card_insert_le b (S.L.erase y))
  rw [card_neighborFinset_eq_degree,card_erase_of_mem yl] at up
  have budget := secondA_right_and_left_le_five S.flip even
  change (secondA G S.L b).card+(secondA G S.R b).card≤5 at budget
  have size : S.L.card=5 := by omega
  have bEq : S.L.filter (G.Adj b)={y} := by
    ext z
    simp only [mem_filter,mem_singleton]
    exact ⟨fun h=>only z h.1 h.2,fun e=>e.symm ▸ ⟨yl,by'⟩⟩
  have part := left_port_count S far
  rw [local3,bEq,card_singleton,size] at part
  obtain ⟨w,hw⟩ := card_pos.mp (show 0<(farNonports S.L a b G).card by omega)
  obtain ⟨wl,wa,wb⟩ := mem_filter.mp hw
  have subw : G.neighborFinset w⊆S.L.erase w := by
    intro z hz
    have wz := (mem_neighborFinset G w z).mp hz
    rcases left_boundary S w wl z wz with rfl|rfl|zl
    · exact (wa wz.symm).elim
    · exact (wb wz.symm).elim
    exact mem_erase.mpr ⟨wz.ne.symm,zl⟩
  have low := card_le_card subw
  rw [card_neighborFinset_eq_degree,card_erase_of_mem wl,size] at low
  have others (z : V) (ne : z≠w) : 5≤G.degree z :=
    (degree z w ne).resolve_right (by omega)
  obtain ⟨t,te⟩ := card_eq_one.mp (show (farNonports S.L a b G).card=1 by omega)
  have wt : w=t := mem_singleton.mp (te ▸ hw)
  have all : farNonports S.L a b G={w} := wt.symm ▸ te
  refine ⟨size,?_,?_,by omega⟩
  · intro u ul v vl ne
    by_cases uw : u=w
    · have vw : v≠w := fun e=>ne (uw.trans e.symm)
      have port : G.Adj a v ∨ G.Adj b v := by
        by_contra h
        have m : v∈farNonports S.L a b G :=
          mem_filter.mpr ⟨vl,fun e=>h (.inl e),fun e=>h (.inr e)⟩
        exact vw (mem_singleton.mp (all ▸ m))
      exact (high_far_port_shore_universal_at_five S far size vl (others v vw) port u ul
        ne.symm).symm
    have port : G.Adj a u ∨ G.Adj b u := by
      by_contra h
      have m : u∈farNonports S.L a b G :=
        mem_filter.mpr ⟨ul,fun e=>h (.inl e),fun e=>h (.inr e)⟩
      exact uw (mem_singleton.mp (all ▸ m))
    exact high_far_port_shore_universal_at_five S far size ul (others u uw) port v vl ne
  · intro z zr
    exact others z (fun e=>disjoint_left.mp S.dis wl (e ▸ zr))

#print axioms singleton_four_five_clique
end Graffiti189LongestPath.CrossSaturation.Split.Five
