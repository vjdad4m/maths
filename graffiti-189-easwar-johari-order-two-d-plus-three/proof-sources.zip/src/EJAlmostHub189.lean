import EJIndexedFourRuns189

namespace Graffiti189Ore
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath.CrossSaturation
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

/-- Split a path before its final hub into two indexed intervals and
reinsert the hub between either orientation of the two intervals. -/
theorem last_hub_insert_routes {a h : V} (p : G.Walk a h) (hp : p.IsPath)
    {i : ℕ} (iL : i+1 < p.length) :
    (G.Adj h a → G.Adj h (p.getVert (i+1)) →
      ∃ v,RouteOn G p.support.toFinset (p.getVert i) v) ∧
    (G.Adj h (p.getVert i) → G.Adj h (p.getVert (p.length-1)) →
      ∃ v,RouteOn G p.support.toFinset (p.getVert (i+1)) v) := by
  classical
  obtain ⟨l,hl,ls⟩ := indexed_walk_segment p hp (i:=0) (j:=i) (by omega) (by omega)
  obtain ⟨r,hr,rs⟩ := indexed_walk_segment p hp (i:=i+1) (j:=p.length-1) (by omega) (by omega)
  let L := l.support.toFinset
  let R := r.support.toFinset
  have both : Disjoint L R := by
    apply disjoint_left.mpr
    intro w wl wr
    obtain ⟨u,_,ui,ue⟩ := (ls w).mp (List.mem_toFinset.mp wl)
    obtain ⟨v,iv,vl,ve⟩ := (rs w).mp (List.mem_toFinset.mp wr)
    have eq := hp.getVert_injOn (by omega : u ≤ p.length) (by omega : v ≤ p.length) (ue.trans ve.symm)
    omega
  have lo : h∉L := by
    intro hm
    obtain ⟨u,_,ui,ue⟩ := (ls h).mp (List.mem_toFinset.mp hm)
    have eq := hp.getVert_injOn (by omega : u ≤ p.length) (by rfl : p.length ≤ p.length)
      (ue.trans (p.getVert_length).symm)
    omega
  have ro : h∉R := by
    intro hm
    obtain ⟨u,_,ui,ue⟩ := (rs h).mp (List.mem_toFinset.mp hm)
    have eq := hp.getVert_injOn (by omega : u ≤ p.length) (by rfl : p.length ≤ p.length)
      (ue.trans (p.getVert_length).symm)
    omega
  have sep : Disjoint (insert h L) R :=
    disjoint_left.mpr (fun v vm vr=>(mem_insert.mp vm).elim
      (fun e=>ro (e ▸ vr)) (fun e=>disjoint_left.mp both e vr))
  have key : insert h L∪R=p.support.toFinset := by
    ext w
    constructor
    · intro wm
      apply List.mem_toFinset.mpr
      rcases mem_union.mp wm with hm|rm
      · rcases mem_insert.mp hm with rfl|lm
        · exact p.end_mem_support
        obtain ⟨j,j0,ji,e⟩ := (ls w).mp (List.mem_toFinset.mp lm)
        exact e ▸ p.getVert_mem_support j
      obtain ⟨j,ji,jl,e⟩ := (rs w).mp (List.mem_toFinset.mp rm)
      exact e ▸ p.getVert_mem_support j
    intro wm
    obtain ⟨j,e,jl⟩ := mem_support_iff_exists_getVert.mp (List.mem_toFinset.mp wm)
    by_cases full : j=p.length
    · have wh : w=h := by simpa [full] using e.symm
      exact mem_union_left _ (mem_insert.mpr (.inl wh))
    by_cases jl' : j ≤ i
    · exact mem_union_left _ (mem_insert_of_mem (List.mem_toFinset.mpr ((ls w).mpr ⟨j,by omega,jl',e⟩)))
    exact mem_union_right _ (List.mem_toFinset.mpr ((rs w).mpr ⟨j,by omega,by omega,e⟩))
  have lpath := walk_as_route l hl
  have rpath := walk_as_route r hr
  constructor
  · intro ha hc
    have ha' : G.Adj h (p.getVert 0) := by simpa using ha
    have q := (lpath.reverse.suffix ha'.symm lo).join rpath sep hc
    exact ⟨_,key ▸ q⟩
  intro hu he
  have q := (lpath.suffix hu.symm lo).join rpath.reverse sep he
  exact ⟨_,key ▸ q.reverse⟩

theorem last_hub_almost_universal_routes {a h miss : V} (p : G.Walk a h) (hp : p.IsPath)
    (nontrivial : a≠h)
    (hub : ∀ v,v∈p.support → v≠h → v≠miss → G.Adj h v) :
    ∀ t,t∈p.support → (miss=a → t≠p.snd) →
      ∃ z,RouteOn G p.support.toFinset t z := by
  classical
  intro t tm permitted
  obtain ⟨j,e,jl⟩ := mem_support_iff_exists_getVert.mp tm
  subst t
  have p0 : 0 < p.length := not_nil_iff_lt_length.mp (Walk.not_nil_of_ne nontrivial)
  by_cases left : j=0
  · exact ⟨h,by simpa [left] using walk_as_route p hp⟩
  by_cases right : j=p.length
  · exact ⟨a,by simpa [right] using (walk_as_route p hp).reverse⟩
  have before : j < p.length := by omega
  have tail : G.Adj h (p.getVert (p.length-1)) := by
    have step := p.adj_getVert_succ (show p.length-1 < p.length by omega)
    have add : p.length-1+1=p.length := by omega
    rw [add,getVert_length] at step
    exact step.symm
  by_cases firstMiss : miss=a
  · have j1 : j≠1 := fun e=>permitted firstMiss (by simp [e,snd])
    have ij : j-1+1 < p.length := by omega
    have prev : G.Adj h (p.getVert (j-1)) := by
      apply hub _ (p.getVert_mem_support _)
      · intro e
        have e' : p.getVert (j-1)=p.getVert p.length := e.trans p.getVert_length.symm
        have r := hp.getVert_injOn (by omega : j-1 ≤ p.length) (le_rfl : p.length ≤ p.length) e'
        omega
      rw [firstMiss]
      intro e
      have e' : p.getVert (j-1)=p.getVert 0 := by simpa using e
      have r := hp.getVert_injOn (by omega : j-1 ≤ p.length) (Nat.zero_le p.length) e'
      omega
    obtain ⟨z,zp⟩ := (last_hub_insert_routes p hp ij).2 prev tail
    have id : j-1+1=j := by omega
    exact ⟨z,by simpa only [id] using zp⟩
  have ha : G.Adj h a := hub a p.start_mem_support nontrivial (Ne.symm firstMiss)
  by_cases lastStep : j+1=p.length
  · obtain ⟨q,qp,qs⟩ := indexed_walk_segment p hp (i:=0) (j:=j) (by omega) (by omega)
    have off : h∉q.support.toFinset := by
      intro hm
      obtain ⟨i,_,ij,ih⟩ := (qs h).mp (List.mem_toFinset.mp hm)
      have e := hp.getVert_injOn (by omega : i ≤ p.length) (le_rfl : p.length ≤ p.length) (ih.trans p.getVert_length.symm)
      omega
    have a' : G.Adj (p.getVert 0) h := by simpa using ha.symm
    have path := (walk_as_route q qp).reverse.suffix a' off
    have set : insert h q.support.toFinset=p.support.toFinset := by
      ext v
      constructor
      · intro vm
        apply List.mem_toFinset.mpr
        rcases mem_insert.mp vm with rfl|vv
        · exact p.end_mem_support
        obtain ⟨i,_,_,iv⟩ := (qs v).mp (List.mem_toFinset.mp vv)
        exact iv ▸ p.getVert_mem_support i
      intro vm
      obtain ⟨i,iv,il⟩ := mem_support_iff_exists_getVert.mp (List.mem_toFinset.mp vm)
      by_cases full : i=p.length
      · exact mem_insert.mpr (.inl (by simpa [full] using iv.symm))
      exact mem_insert_of_mem (List.mem_toFinset.mpr ((qs v).mpr ⟨i,by omega,by omega,iv⟩))
    exact ⟨h,set ▸ path⟩
  have mu : j+1 < p.length := by omega
  by_cases next : p.getVert (j+1)=miss
  · have sj : j-1+1 < p.length := by omega
    have ne : p.getVert (j-1)≠h := by
      intro e
      have h' : p.getVert (j-1)=p.getVert p.length := e.trans p.getVert_length.symm
      have r := hp.getVert_injOn (by omega : j-1 ≤ p.length) (le_rfl : p.length ≤ p.length) h'
      omega
    have nm : p.getVert (j-1)≠miss := by
      intro e
      have h' := e.trans next.symm
      have r := hp.getVert_injOn (by omega : j-1 ≤ p.length) (by omega : j+1 ≤ p.length) h'
      omega
    have prev := hub _ (p.getVert_mem_support _) ne nm
    obtain ⟨z,zp⟩ := (last_hub_insert_routes p hp sj).2 prev tail
    have id : j-1+1=j := by omega
    exact ⟨z,by simpa only [id] using zp⟩
  have nEnd : p.getVert (j+1)≠h := by
    intro e
    have h' : p.getVert (j+1)=p.getVert p.length := e.trans p.getVert_length.symm
    have r := hp.getVert_injOn (by omega : j+1 ≤ p.length) (le_rfl : p.length ≤ p.length) h'
    omega
  exact (last_hub_insert_routes p hp mu).1 ha
    (hub _ (p.getVert_mem_support _) nEnd next)

#print axioms last_hub_almost_universal_routes
end Graffiti189Ore
