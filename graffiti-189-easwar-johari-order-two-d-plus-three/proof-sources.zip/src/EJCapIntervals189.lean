import EJFourRunsMiddle189

namespace Graffiti189Ore
open Finset SimpleGraph SimpleGraph.Walk
open private unliftCap from OreClosure189
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

def CapInterval {a b : Option V} (p : (cap G (fun _=>True)).Walk a b)
    (i j : ℕ) {u v : V} (q : G.Walk u v) : Prop :=
  ∀ x,x∈q.support ↔ ∃ k : ℕ, i ≤ k ∧ k ≤ j ∧ p.getVert k=some x

theorem cap_interval_path {a b : Option V} (p : (cap G (fun _=>True)).Walk a b)
    (hp : p.IsPath) {k i j : ℕ} (kl : k ≤ p.length) (pv : p.getVert k=none)
    (ij : i ≤ j) (jl : j ≤ p.length) (off : j < k ∨ k < i) :
    ∃ u v : V,p.getVert i=some u ∧ p.getVert j=some v ∧
      ∃ q : G.Walk u v,q.IsPath ∧ CapInterval p i j q := by
  classical
  obtain ⟨q,hq,qs⟩ := indexed_walk_segment p hp ij jl
  have hn : none∉q.support := by
    intro e
    obtain ⟨r,ir,rj,he⟩ := (qs none).mp e
    have rk := hp.getVert_injOn (by omega : r ≤ p.length) kl (he.trans pv.symm)
    omega
  have start : ∃ u : V,p.getVert i=some u := by
    cases h : p.getVert i with
    | none => exact (hn (h ▸ q.start_mem_support)).elim
    | some u => exact ⟨u,rfl⟩
  obtain ⟨u,ue⟩ := start
  let r : (cap G (fun _=>True)).Walk (some u) (p.getVert j) := q.copy ue rfl
  have rs : r.support=q.support := by simp [r]
  obtain ⟨v,ve,w,ws⟩ := unliftCap r (rs.symm ▸ hn)
  have eq : q.support=w.support.map some := rs.symm.trans ws
  have wp := Walk.IsPath.mk' (List.Nodup.of_map _ (eq ▸ hq.support_nodup))
  refine ⟨u,v,ue,ve,w,wp,?_⟩
  intro x
  constructor
  · intro m
    exact (qs _).mp (eq.symm ▸ List.mem_map.mpr ⟨x,m,rfl⟩)
  intro h
  obtain ⟨y,ym,e⟩ := List.mem_map.mp (eq ▸ (qs _).mpr h)
  exact Option.some.inj e ▸ ym

theorem cap_intervals_disjoint {a b : Option V} {p : (cap G (fun _=>True)).Walk a b}
    (hp : p.IsPath) {i j r s : ℕ} (_jl : j ≤ p.length) (sl : s ≤ p.length) (off : j < r)
    {u v w z : V} {q : G.Walk u v} {t : G.Walk w z}
    (qa : CapInterval p i j q) (ta : CapInterval p r s t) :
    List.Disjoint q.support t.support := by
  intro x xm xt
  obtain ⟨a,ia,aj,ax⟩ := (qa x).mp xm
  obtain ⟨b,rb,bs,bx⟩ := (ta x).mp xt
  have eq := hp.getVert_injOn (by omega : a ≤ p.length) (by omega : b ≤ p.length) (ax.trans bx.symm)
  omega

theorem cap_consecutive_of_some {a b : Option V} {p : (cap G (fun _=>True)).Walk a b}
    {i : ℕ} (il : i < p.length) {u v : V}
    (ue : p.getVert i=some u) (ve : p.getVert (i+1)=some v) :
    G.Adj u v := by
  have h := p.adj_getVert_succ il
  rw [ue,ve] at h
  exact h

#print axioms cap_interval_path
end Graffiti189Ore
