import EJFourRunsNoMiddle189

namespace Graffiti189Ore
open SimpleGraph SimpleGraph.Walk Finset Graffiti189LongestPath.CrossSaturation
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

/-- Four-run splice with a nonempty middle B block, covering both a
second common neighbor and a single hole at the final A-block boundary. -/
theorem traceable_four_runs_with_middle
    {x l u t q0 qc w y : V}
    (L : G.Walk x l) (U : G.Walk u t) (Q : G.Walk q0 qc) (R : G.Walk w y)
    (lp : L.IsPath) (up : U.IsPath) (qp : Q.IsPath) (rp : R.IsPath)
    (qHub : ∀ v,v∈Q.support → v≠q0 → G.Adj x v)
    (nontrivial : q0≠qc) (ut : G.Adj t q0) (uy : G.Adj u y) (qr : G.Adj qc w)
    (lu : List.Disjoint L.support U.support)
    (lq : List.Disjoint L.support Q.support)
    (lr : List.Disjoint L.support R.support)
    (uq : List.Disjoint U.support Q.support)
    (ur : List.Disjoint U.support R.support)
    (qr' : List.Disjoint Q.support R.support)
    (cover : ∀ v,v∈L.support ∨ v∈U.support ∨ v∈Q.support ∨ v∈R.support) :
    Traceable G := by
  classical
  cases Q with
  | nil => exact (nontrivial rfl).elim
  | @cons _ q1 _ e tail =>
    let LS := L.support.toFinset
    let US := U.support.toFinset
    let RS := R.support.toFinset
    let QS := (Walk.cons e tail).support.toFinset
    let H := ({q0,q1} : Finset V)
    have sub : H⊆QS := by
      intro v vm
      apply List.mem_toFinset.mpr
      change v∈({q0,q1}:Finset V) at vm
      simp only [mem_insert,mem_singleton] at vm
      rcases vm with rfl|rfl
      · exact (Walk.cons e tail).start_mem_support
      exact List.mem_cons_of_mem _ tail.start_mem_support
    have LQ := list_disjoint_finsets lq
    have UQ := list_disjoint_finsets uq
    have QR := list_disjoint_finsets qr'
    have UL := (list_disjoint_finsets lu).symm
    have LR := list_disjoint_finsets lr
    have UR := list_disjoint_finsets ur
    have step : G.Adj x q1 :=
      qHub q1 (List.mem_cons_of_mem _ tail.start_mem_support) e.ne.symm
    have head : RouteOn G (LS∪H) l q0 :=
      (walk_as_route L lp).reverse.join
        (show RouteOn G H q1 q0 from (RouteOn.edge e).reverse)
        (LQ.mono_right sub) step
    have arm : RouteOn G (US∪RS) t w :=
      (walk_as_route U up).reverse.join (walk_as_route R rp).reverse UR uy
    have off : Disjoint (LS∪H) (US∪RS) := by
      apply disjoint_union_left.mpr
      exact ⟨disjoint_union_right.mpr ⟨UL.symm,LR⟩,
        disjoint_union_right.mpr ⟨UQ.symm.mono_left sub,QR.mono_left sub⟩⟩
    have main : RouteOn G ((LS∪H)∪(US∪RS)) l w := head.join arm off ut.symm
    cases tail with
    | nil =>
      apply traceable_of_route_cover main
      intro v
      rcases cover v with lm|um|qm|rm
      · exact mem_union_left _ (mem_union_left _ (List.mem_toFinset.mpr lm))
      · exact mem_union_right _ (mem_union_left _ (List.mem_toFinset.mpr um))
      · exact mem_union_left _ (mem_union_right _ (by simpa [H,support_cons] using qm))
      exact mem_union_right _ (mem_union_right _ (List.mem_toFinset.mpr rm))
    | @cons _ q2 _ e' rest =>
      let T := rest.support.toFinset
      have eq : QS=H∪T := by
        ext v
        simp [QS,H,T,support_cons,or_assoc]
      have hr : Disjoint H T := by
        have nd : (q0::q1::rest.support).Nodup := qp.support_nodup
        simp only [List.nodup_cons] at nd
        apply disjoint_left.mpr
        intro v hm vm
        rcases mem_insert.mp hm with e0|e1
        · exact nd.1 (List.mem_cons_of_mem _ (e0 ▸ List.mem_toFinset.mp vm))
        exact nd.2.1 ((mem_singleton.mp e1) ▸ List.mem_toFinset.mp vm)
      have incl : T⊆QS := eq.symm ▸ subset_union_right
      have sep : Disjoint ((LS∪H)∪(US∪RS)) T :=
        disjoint_union_left.mpr ⟨disjoint_union_left.mpr ⟨LQ.mono_right incl,hr⟩,
          disjoint_union_left.mpr ⟨UQ.mono_right incl,QR.symm.mono_right incl⟩⟩
      have restPath : rest.IsPath := by
        have nd : (q0::q1::rest.support).Nodup := qp.support_nodup
        exact Walk.IsPath.mk' (List.nodup_cons.mp (List.nodup_cons.mp nd).2).2
      have path := main.join (walk_as_route rest restPath).reverse sep qr.symm
      apply traceable_of_route_cover path
      intro v
      rcases cover v with lm|um|qm|rm
      · exact mem_union_left _ (mem_union_left _ (mem_union_left _ (List.mem_toFinset.mpr lm)))
      · exact mem_union_left _ (mem_union_right _ (mem_union_left _ (List.mem_toFinset.mpr um)))
      · have vm : v∈H∪T := eq ▸ List.mem_toFinset.mpr qm
        exact (mem_union.mp vm).elim
          (fun h=>mem_union_left _ (mem_union_left _ (mem_union_right _ h)))
          (fun h=>mem_union_right _ h)
      exact mem_union_left _ (mem_union_right _ (mem_union_right _ (List.mem_toFinset.mpr rm)))

#print axioms traceable_four_runs_with_middle
end Graffiti189Ore
