import EJRouteShortcuts189

namespace Graffiti189Ore
open SimpleGraph SimpleGraph.Walk Finset Graffiti189LongestPath.CrossSaturation
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

theorem traceable_of_three_joined_routes {A B C : Finset V} {a x y z w b : V}
    (p : RouteOn G A a x) (q : RouteOn G B y z) (r : RouteOn G C w b)
    (pq : G.Adj x y) (qr : G.Adj z w)
    (ab : Disjoint A B) (ac : Disjoint A C) (bc : Disjoint B C)
    (cover : ∀ v,v∈A ∨ v∈B ∨ v∈C) : Traceable G := by
  exact traceable_of_route_cover ((p.join q ab pq).join r (disjoint_union_left.mpr ⟨ac,bc⟩) qr)
    (fun v=>mem_union.mpr ((cover v).elim (fun h=>.inl (mem_union_left _ h))
      (fun h=>h.elim (fun h=>.inl (mem_union_right _ h)) .inr)))

/-- The four-run splice when the B run after the apex contributes no
actual vertex before the nontrivial A block. A spare neighbor of q0
can hit any of the other three path blocks. -/
theorem traceable_four_runs_no_middle
    {x l q0 qc w y z : V}
    (L : G.Walk x l) (Q : G.Walk q0 qc) (R : G.Walk w y)
    (lp : L.IsPath) (qp : Q.IsPath) (rp : R.IsPath)
    (lHub : ∀ v,v∈L.support → v≠x → G.Adj x v)
    (qHub : ∀ v,v∈Q.support → v≠q0 → G.Adj x v)
    (rHub : ∀ v,v∈R.support → v≠y → G.Adj y v)
    (nontrivial : q0≠qc) (qr : G.Adj qc w)
    (lq : List.Disjoint L.support Q.support)
    (lr : List.Disjoint L.support R.support)
    (qr' : List.Disjoint Q.support R.support)
    (cover : ∀ v,v∈L.support ∨ v∈Q.support ∨ v∈R.support)
    (qHit : G.Adj q0 z) (zNotNext : z≠Q.snd) :
    Traceable G := by
  have D1 := list_disjoint_finsets lq
  have D2 := list_disjoint_finsets lr
  have D3 := list_disjoint_finsets qr'
  have all : ∀ v,v∈L.support.toFinset ∨ v∈Q.support.toFinset ∨ v∈R.support.toFinset :=
    fun v=>by simpa only [List.mem_toFinset] using cover v
  have PL := walk_as_route L lp
  have PQ := walk_as_route Q qp
  have PR := walk_as_route R rp
  rcases cover z with Lz|Qz|Rz
  · obtain ⟨t,p⟩ := reroot_hub_route L lp lHub Lz
    exact traceable_of_three_joined_routes p.reverse PQ PR qHit.symm qr D1 D2 D3 all
  · obtain ⟨t,tm,nt,p⟩ := reverse_jump_route Q qp Qz qHit zNotNext
    exact traceable_of_three_joined_routes PL.reverse p PR (qHub t tm nt) qr D1 D2 D3 all
  have rHz : ∀ v,v∈R.reverse.support → v≠y → G.Adj y v :=
    fun v vm=>rHub _ (by simpa using vm)
  obtain ⟨t,p⟩ := reroot_hub_route R.reverse rp.reverse rHz (by simpa using Rz)
  have e : R.reverse.support.toFinset=R.support.toFinset := by ext v; simp
  have p' : RouteOn G R.support.toFinset z t := e ▸ p
  exact traceable_of_three_joined_routes PL.reverse PQ.reverse p'
    (qHub qc Q.end_mem_support nontrivial.symm) qHit D1 D2 D3 all

#print axioms traceable_four_runs_no_middle
end Graffiti189Ore
