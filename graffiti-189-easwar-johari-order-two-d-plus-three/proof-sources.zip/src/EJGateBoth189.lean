import EJGateRight189

namespace Graffiti189Ore
open SimpleGraph SimpleGraph.Walk Graffiti189LongestPath.SmallOrder
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

theorem traceable_of_mark_gate (conn : DeletionTwoConnected G)
    {x y : V} (p : (cap G (fun _=>True)).Walk (some x) (some y))
    (hp : p.IsPath) (all : ∀ v,v∈p.support) {k t : ℕ}
    (kk : 0 < k) (kl : k < p.length) (tl : t < p.length) (tk : t≠k)
    (apex : p.getVert k=none)
    (cover : ∀ i : ℕ, i < p.length → i≠t →
      (cap G (fun _=>True)).Adj (some x) (p.getVert (i+1)) ∨
      (cap G (fun _=>True)).Adj (some y) (p.getVert i))
    (dis : ∀ i : ℕ, i < p.length → ¬((cap G (fun _=>True)).Adj (some x) (p.getVert (i+1)) ∧
      (cap G (fun _=>True)).Adj (some y) (p.getVert i)))
    (gate :
      ((∀ i : ℕ, i < p.length →
          (cap G (fun _=>True)).Adj (some x) (p.getVert (i+1)) ∨
          (cap G (fun _=>True)).Adj (some y) (p.getVert i)) ∧
        (∀ i : ℕ, i+1 < p.length → (cap G (fun _=>True)).Adj (some x) (p.getVert (i+1)) →
          (cap G (fun _=>True)).Adj (some y) (p.getVert (i+1)) → i+1=k ∨ i+1=t) ∧ 0 < t) ∨
      (t+1≠k ∧
        (∀ i : ℕ, i+1 < p.length → (cap G (fun _=>True)).Adj (some x) (p.getVert (i+1)) →
          (cap G (fun _=>True)).Adj (some y) (p.getVert (i+1)) → i+1=k))) :
    Traceable G := by
  by_cases kt : k < t
  · apply traceable_of_mark_gate_right conn p hp all kk kt tl apex cover dis
    intro i hi A B
    exact gate.elim (fun h=>h.2.1 i hi A B) (fun h=>.inl (h.2 i hi A B))
  have all' : ∀ v,v∈p.reverse.support := fun v=>by simpa using all v
  have kk' : 0 < p.length-k := by omega
  have ap' : p.reverse.getVert (p.length-k)=none := by
    rw [p.getVert_reverse,show p.length-(p.length-k)=k by omega,apex]
  have dis' (i : ℕ) (hi : i < p.reverse.length)
      (h : (cap G (fun _=>True)).Adj (some y) (p.reverse.getVert (i+1)) ∧
        (cap G (fun _=>True)).Adj (some x) (p.reverse.getVert i)) : False := by
    simp only [length_reverse] at hi
    rw [p.getVert_reverse,p.getVert_reverse] at h
    apply dis (p.length-(i+1)) (by omega)
    rw [show p.length-(i+1)+1=p.length-i by omega]
    exact h.symm
  have reflCover (i : ℕ) (hi : i < p.reverse.length)
      (orig : (cap G (fun _=>True)).Adj (some x) (p.getVert (p.length-(i+1)+1)) ∨
        (cap G (fun _=>True)).Adj (some y) (p.getVert (p.length-(i+1)))) :
      (cap G (fun _=>True)).Adj (some y) (p.reverse.getVert (i+1)) ∨
        (cap G (fun _=>True)).Adj (some x) (p.reverse.getVert i) := by
    simp only [length_reverse] at hi
    rw [p.getVert_reverse,p.getVert_reverse,←show p.length-(i+1)+1=p.length-i by omega]
    exact orig.symm
  rcases gate with ⟨full,switch,pos⟩ | ⟨notPrev,switch⟩
  · apply traceable_of_mark_gate_right conn p.reverse hp.reverse all' kk' (t:=p.length-t)
      (by omega) (by simp; omega) ap' (fun i hi _=>reflCover i hi (full _ (by simp only [length_reverse] at hi; omega))) dis'
    intro i hi B A
    simp only [length_reverse] at hi
    rw [p.getVert_reverse] at B A
    have A' : (cap G (fun _=>True)).Adj (some x) (p.getVert (p.length-(i+1)-1+1)) := by
      rw [show p.length-(i+1)-1+1=p.length-(i+1) by omega]
      exact A
    obtain e|e := switch (p.length-(i+1)-1) (by omega) A' (by simpa only [show p.length-(i+1)-1+1=p.length-(i+1) by omega] using B)
    · left; omega
    right; omega
  · apply traceable_of_mark_gate_right conn p.reverse hp.reverse all' kk' (t:=p.length-(t+1))
      (by omega) (by simp; omega) ap' (fun i hi ht=>reflCover i hi (cover _
        (by simp only [length_reverse] at hi; omega) (by simp only [length_reverse] at hi; omega))) dis'
    intro i hi B A
    simp only [length_reverse] at hi
    rw [p.getVert_reverse] at B A
    have eq : p.length-(i+1)-1+1=p.length-(i+1) := by omega
    have e := switch (p.length-(i+1)-1) (by omega) (by rw [eq]; exact A)
      (by rw [eq]; exact B)
    left; omega
end Graffiti189Ore
