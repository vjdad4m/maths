import EJMarkRuns189
import EJOneHoleRuns189

namespace Graffiti189Ore
open SimpleGraph SimpleGraph.Walk Graffiti189LongestPath.SmallOrder
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

theorem traceable_of_mark_gate_right (conn : DeletionTwoConnected G)
    {x y : V} (p : (cap G (fun _=>True)).Walk (some x) (some y))
    (hp : p.IsPath) (all : ∀ v,v∈p.support) {k t : ℕ}
    (kk : 0 < k) (kt : k < t) (tl : t < p.length) (apex : p.getVert k=none)
    (cover : ∀ i : ℕ, i < p.length → i≠t →
      (cap G (fun _=>True)).Adj (some x) (p.getVert (i+1)) ∨
      (cap G (fun _=>True)).Adj (some y) (p.getVert i))
    (dis : ∀ i : ℕ, i < p.length → ¬((cap G (fun _=>True)).Adj (some x) (p.getVert (i+1)) ∧
      (cap G (fun _=>True)).Adj (some y) (p.getVert i)))
    (switch : ∀ i : ℕ, i+1 < p.length → (cap G (fun _=>True)).Adj (some x) (p.getVert (i+1)) →
      (cap G (fun _=>True)).Adj (some y) (p.getVert (i+1)) → i+1=k ∨ i+1=t) :
    Traceable G := by
  let K := cap G (fun _=>True)
  let A := fun i : ℕ=> K.Adj (some x) (p.getVert (i+1))
  let B := fun i : ℕ=> K.Adj (some y) (p.getVert i)
  have first : A 0 := by simpa [A,K] using (p.adj_getVert_succ (i:=0) (by omega))
  have midpoint : B k := by simp [B,K,apex,cap]
  have final : B (p.length-1) := by
    have e := p.adj_getVert_succ (i:=p.length-1) (by omega)
    have h : p.length-1+1=p.length := by omega
    rw [h,p.getVert_length] at e
    exact K.symm e
  obtain ⟨l,r,inner⟩ := marks_after_apex_first A B p.length k t
    ⟨kk,kt,tl⟩ cover dis switch first midpoint final
  rcases inner with h | ⟨s,ks,st,u,q⟩
  · apply traceable_of_indexed_one_hole_two_runs conn p hp all kk kt tl apex l
    intro j kj jl jt
    exact if e : j < t then h j (by omega) e else r j (by omega) jl
  exact traceable_of_indexed_four_runs conn p hp all kk ks st tl apex l u q r

end Graffiti189Ore
