import EJCapIntervals189

namespace Graffiti189Ore
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath.SmallOrder
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

theorem another_neighbor_after_single_deletion (conn : DeletionTwoConnected G)
    {v w x : V} (vw : v≠w) (xv : x≠v) (xw : x≠w) :
    ∃ z,G.Adj v z ∧ z≠w := by
  classical
  let U : Set V := ((↑({w} : Finset V) : Set V)ᶜ)
  let a : U := ⟨v,by simpa [U] using vw⟩
  let b : U := ⟨x,by simpa [U] using xw⟩
  have ne : a≠b := fun e=>xv (congrArg Subtype.val e).symm
  obtain ⟨q⟩ := (conn {w} (by simp)).preconnected a b
  have pos : 0 < q.length := not_nil_iff_lt_length.mp (fun h => ne (Walk.Nil.eq h))
  have e := q.adj_getVert_succ pos
  rw [Walk.getVert_zero, Nat.zero_add] at e
  let z := q.getVert 1
  exact ⟨z.val,e,by simpa [U] using z.property⟩

theorem traceable_of_indexed_four_runs (conn : DeletionTwoConnected G)
    {x y : V} (p : (cap G (fun _=>True)).Walk (some x) (some y))
    (hp : p.IsPath) (all : ∀ v,v∈p.support)
    {k s t : ℕ} (kk : 0 < k) (ks : k < s) (st : s < t) (tl : t < p.length)
    (apex : p.getVert k=none)
    (lMarks : ∀ j : ℕ, j < k → (cap G (fun _=>True)).Adj (some x) (p.getVert (j+1)))
    (uMarks : ∀ j : ℕ, k ≤ j → j < s → (cap G (fun _=>True)).Adj (some y) (p.getVert j))
    (qMarks : ∀ j : ℕ, s ≤ j → j < t → (cap G (fun _=>True)).Adj (some x) (p.getVert (j+1)))
    (rMarks : ∀ j : ℕ, t < j → j < p.length → (cap G (fun _=>True)).Adj (some y) (p.getVert j)) :
    Traceable G := by
  classical
  have kl : k ≤ p.length := by omega
  obtain ⟨x',l,xe,le,L,hL,LS⟩ := cap_interval_path p hp kl apex
    (i:=0) (j:=k-1) (by omega) (by omega) (.inl (by omega))
  have xx : x=x' := by simpa using xe
  subst x'
  obtain ⟨q,c,qe,ce,Q,hQ,QS⟩ := cap_interval_path p hp kl apex
    (i:=s) (j:=t) (by omega) (by omega) (.inr ks)
  obtain ⟨r,y',re,ye,R,hR,RS⟩ := cap_interval_path p hp kl apex
    (i:=t+1) (j:=p.length) (by omega) le_rfl (.inr (by omega))
  have yy : y=y' := by simpa using ye
  subst y'
  have qc : q≠c := by
    intro e
    have hh := hp.getVert_injOn (by omega : s ≤ p.length) (by omega : t ≤ p.length)
      (qe.trans (e.symm ▸ ce.symm))
    omega
  have lHub (v : V) (vl : v∈L.support) (vx : v≠x) : G.Adj x v := by
    obtain ⟨i,_,ik,hi⟩ := (LS v).mp vl
    have i0 : i≠0 := by intro e; subst i; exact vx (Option.some.inj (by simpa using hi)).symm
    have h := lMarks (i-1) (by omega)
    rw [show i-1+1=i by omega,hi] at h
    exact h
  have qHub (v : V) (vq : v∈Q.support) (vn : v≠q) : G.Adj x v := by
    obtain ⟨i,si,it,hi⟩ := (QS v).mp vq
    have ni : i≠s := fun e=>vn (Option.some.inj (hi.symm.trans (e.symm ▸ qe)))
    have h := qMarks (i-1) (by omega) (by omega)
    rw [show i-1+1=i by omega,hi] at h
    exact h
  have rHub (v : V) (vr : v∈R.support) (vy : v≠y) : G.Adj y v := by
    obtain ⟨i,ti,il,hi⟩ := (RS v).mp vr
    have ni : i≠p.length := by intro e; subst i; exact vy (Option.some.inj (by simpa using hi)).symm
    have h := rMarks i (by omega) (by omega)
    rw [hi] at h
    exact h
  have join : G.Adj c r := cap_consecutive_of_some tl ce re
  have dLQ := cap_intervals_disjoint hp (by omega) (by omega) (by omega) LS QS
  have dLR := cap_intervals_disjoint hp (by omega) (by omega) (by omega) LS RS
  have dQR := cap_intervals_disjoint hp (by omega) (by omega) (by omega) QS RS
  have partialCover (v : V) :
      v∈L.support ∨ v∈Q.support ∨ v∈R.support ∨
        ∃ i,k+1 ≤ i ∧ i < s ∧ p.getVert i=some v := by
    obtain ⟨i,vi,il⟩ := mem_support_iff_exists_getVert.mp (all (some v))
    have ni : i≠k := by intro e; subst i; exact Option.some_ne_none _ (vi.symm.trans apex)
    by_cases ik : i < k
    · exact .inl ((LS v).mpr ⟨i,by omega,by omega,vi⟩)
    by_cases ti : t < i
    · exact .inr (.inr (.inl ((RS v).mpr ⟨i,by omega,il,vi⟩)))
    by_cases si : s ≤ i
    · exact .inr (.inl ((QS v).mpr ⟨i,si,by omega,vi⟩))
    exact .inr (.inr (.inr ⟨i,by omega,by omega,vi⟩))
  by_cases noMiddle : s=k+1
  · have all' (v : V) : v∈L.support ∨ v∈Q.support ∨ v∈R.support := by
      rcases partialCover v with a|a|a|⟨i,ik,si,_⟩
      · exact .inl a
      · exact .inr (.inl a)
      · exact .inr (.inr a)
      omega
    have first := Q.adj_snd (Walk.not_nil_of_ne qc)
    have xq : x≠q := fun e=>dLQ L.start_mem_support (e.symm ▸ Q.start_mem_support)
    have xs : x≠Q.snd := fun e=>dLQ L.start_mem_support (e.symm ▸ Q.getVert_mem_support 1)
    obtain ⟨z,qz,zn⟩ := another_neighbor_after_single_deletion conn first.ne xq xs
    exact traceable_four_runs_no_middle L Q R hL hQ hR lHub qHub rHub qc join dLQ dLR dQR all' qz zn
  obtain ⟨u,v,ue,ve,U,hU,US⟩ := cap_interval_path p hp kl apex
    (i:=k+1) (j:=s-1) (by omega) (by omega) (.inr (by omega))
  have prev : s-1+1=s := by omega
  have vq : G.Adj v q := cap_consecutive_of_some (by omega) ve (prev.symm ▸ qe)
  have yu : G.Adj y u := by
    have p' := uMarks (k+1) (by omega) (by omega)
    rw [ue] at p'
    exact p'
  have dLU := cap_intervals_disjoint hp (by omega) (by omega) (by omega) LS US
  have dUQ := cap_intervals_disjoint hp (by omega) (by omega) (by omega) US QS
  have dUR := cap_intervals_disjoint hp (by omega) (by omega) (by omega) US RS
  have all' (w : V) : w∈L.support ∨ w∈U.support ∨ w∈Q.support ∨ w∈R.support := by
    rcases partialCover w with a|a|a|⟨i,ik,si,iw⟩
    · exact .inl a
    · exact .inr (.inr (.inl a))
    · exact .inr (.inr (.inr a))
    exact .inr (.inl ((US w).mpr ⟨i,ik,by omega,iw⟩))
  exact traceable_four_runs_with_middle L U Q R hL hU hQ hR qHub qc vq yu.symm join
    dLU dLQ dLR dUQ dUR dQR all'

#print axioms traceable_of_indexed_four_runs
end Graffiti189Ore
