import EJOrderThreeConditional189

namespace Graffiti189Ore
open Finset SimpleGraph SimpleGraph.Walk
variable {V : Type*} {G : SimpleGraph V}
set_option linter.unusedSectionVars false

/-- Extract an exact interval of a simple indexed walk. This form is
convenient for the multi-run splices in Easwar–Johari Lemma 3.3. -/
theorem indexed_walk_segment {a b : V} (p : G.Walk a b) (hp : p.IsPath)
    {i j : ℕ} (ij : i≤j) (jl : j≤p.length) :
    ∃ q : G.Walk (p.getVert i) (p.getVert j), q.IsPath ∧
      ∀ v,v∈q.support ↔ ∃ k,i≤k ∧ k≤j ∧ p.getVert k=v := by
  induction h : j-i using Nat.strong_induction_on generalizing i with
  | h n ih =>
    by_cases e : i=j
    · subst i
      refine ⟨Walk.nil,by simp,?_⟩
      intro v
      constructor
      · intro vm
        exact ⟨j,le_rfl,le_rfl,(mem_support_nil_iff.mp vm).symm⟩
      rintro ⟨k,kj,jk,kv⟩
      have eq : k=j := by omega
      subst k
      exact mem_support_nil_iff.mpr kv.symm
    have il : i<p.length := by omega
    have small : j-(i+1)<n := by omega
    obtain ⟨q,hq,qs⟩ := ih _ small (i:=i+1) (by omega) rfl
    have off : p.getVert i∉q.support := by
      intro vm
      obtain ⟨k,ik,kj,kv⟩ := (qs _).mp vm
      have eq := hp.getVert_injOn (by omega : k≤p.length) (by omega : i≤p.length) kv
      omega
    refine ⟨Walk.cons (p.adj_getVert_succ il) q,hq.cons off,?_⟩
    intro v
    rw [support_cons,List.mem_cons]
    constructor
    · rintro (vi|tail)
      · exact ⟨i,le_rfl,ij,vi.symm⟩
      obtain ⟨k,ik,kj,kv⟩ := (qs _).mp tail
      exact ⟨k,by omega,kj,kv⟩
    rintro ⟨k,ik,kj,kv⟩
    by_cases eq : k=i
    · exact .inl (eq ▸ kv.symm)
    exact .inr ((qs _).mpr ⟨k,by omega,kj,kv⟩)

#print axioms indexed_walk_segment
end Graffiti189Ore
