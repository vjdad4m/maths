import EJIndexedSegments189

namespace Graffiti189Ore
set_option linter.unusedSectionVars false

/-- On an interval having no A→B switch, the A labels (if any) form a
terminal run. One designated hole or second switch may border the interval,
but not lie inside it. -/
theorem no_switch_interval_tail (A B : ℕ→Prop) (s t : ℕ)
    (cover : ∀ i : ℕ, s ≤ i → i < t → A i ∨ B i)
    (no : ∀ i : ℕ, s ≤ i → i+1 < t → A i → ¬B (i+1))
    {i : ℕ} (si : s ≤ i) (ai : A i) :
    ∀ j : ℕ, i ≤ j → j < t → A j := by
  intro j
  induction j with
  | zero =>
    intro ij _
    have h : i=0 := by omega
    exact h ▸ ai
  | succ j ih =>
    intro ij jt
    by_cases eq : i=j+1
    · exact eq ▸ ai
    have old := ih (by omega) (by omega)
    exact (cover (j+1) (by omega) jt).resolve_right (no j (by omega) jt old)

theorem no_switch_interval_head (A B : ℕ→Prop) (s t : ℕ) (st : s < t)
    (cover : ∀ i : ℕ, s ≤ i → i < t → A i ∨ B i)
    (dis : ∀ i : ℕ, s ≤ i → i < t → ¬(A i ∧ B i))
    (no : ∀ i : ℕ, s ≤ i → i+1 < t → A i → ¬B (i+1))
    (last : B (t-1)) :
    ∀ i : ℕ, s ≤ i → i < t → B i := by
  intro i si it
  apply Classical.byContradiction
  intro bi
  have ai := (cover i si it).resolve_right bi
  exact dis (t-1) (by omega) (by omega)
    ⟨no_switch_interval_tail A B s t cover no si ai (t-1) (by omega) (by omega),last⟩

/-- Normalize the label profile when the apex switch is first. At t there
may be a single hole or the second common neighbor, and no edge is assumed
there by this numeric classification. -/
theorem marks_after_apex_first (A B : ℕ→Prop) (n k t : ℕ)
    (inrange : 0 < k ∧ k < t ∧ t < n)
    (cover : ∀ i : ℕ, i < n → i≠t → A i ∨ B i)
    (dis : ∀ i : ℕ, i < n → ¬(A i ∧ B i))
    (switch : ∀ i : ℕ, i+1 < n → A i → B (i+1) → i+1=k ∨ i+1=t)
    (first : A 0) (apex : B k) (last : B (n-1)) :
    (∀ i : ℕ, i < k → A i) ∧ (∀ i : ℕ, t < i → i < n → B i) ∧
    ((∀ i : ℕ, k ≤ i → i < t → B i) ∨
      ∃ s : ℕ, k < s ∧ s < t ∧ (∀ i : ℕ, k ≤ i → i < s → B i) ∧ (∀ i : ℕ, s ≤ i → i < t → A i)) := by
  classical
  have first' : ∀ i : ℕ, i < k → A i := by
    intro i hi
    exact no_switch_interval_tail A B 0 k
      (fun i _ il=>cover i (by omega) (by omega))
      (fun i _ il a b=>by have r := switch i (by omega) a b; omega)
      (Nat.zero_le 0) first i (Nat.zero_le _) hi
  have last' : ∀ i : ℕ, t < i → i < n → B i := by
    intro i ti il
    exact no_switch_interval_head A B (t+1) n (by omega)
      (fun i si il=>cover i il (by omega))
      (fun i _ il=>dis i il)
      (fun i il hi a b=>by have r := switch i hi a b; omega)
      last i (by omega) il
  refine ⟨first',last',?_⟩
  by_cases a : ∃ s : ℕ, k ≤ s ∧ s < t ∧ A s
  · right
    let s := Nat.find a
    have hs : k ≤ s ∧ s < t ∧ A s := Nat.find_spec a
    have ne : s≠k := fun e=>dis k (by omega) ⟨e ▸ hs.2.2,apex⟩
    refine ⟨s,by omega,hs.2.1,?_,?_⟩
    · intro i ki is
      exact (cover i (by omega) (by omega)).resolve_left (fun ai=>by
        have e := Nat.find_min' a ⟨ki,by omega,ai⟩
        change s ≤ i at e
        omega)
    exact no_switch_interval_tail A B k t
      (fun i _ il=>cover i (by omega) (by omega))
      (fun i ki il ai bi=>by have r:=switch i (by omega) ai bi; omega)
      hs.1 hs.2.2
  exact .inl (fun i ki it=>(cover i (by omega) (by omega)).resolve_left
    (fun ai=>a ⟨i,ki,it,ai⟩))

#print axioms marks_after_apex_first
end Graffiti189Ore
