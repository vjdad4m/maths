import EJAlmostHub189

namespace Graffiti189Ore
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath.CrossSaturation Graffiti189LongestPath.SmallOrder
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

theorem two_hub_paths_with_one_miss (conn : DeletionTwoConnected G)
    {x l r y miss : V} (L : G.Walk x l) (R : G.Walk r y)
    (lp : L.IsPath) (rp : R.IsPath) (ry : r≠y)
    (lh : ∀ v,v∈L.support → v≠x → G.Adj x v)
    (rh : ∀ v,v∈R.support → v≠y → v≠miss → G.Adj y v)
    (dis : List.Disjoint L.support R.support)
    (cover : ∀ v,v∈L.support ∨ v∈R.support) :
    Traceable G := by
  classical
  let bad := R.snd
  have badR : bad∈R.support := R.getVert_mem_support 1
  have rb : r≠bad := (R.adj_snd (Walk.not_nil_of_ne ry)).ne
  have xb : x≠bad := fun e=>dis L.start_mem_support (e.symm ▸ badR)
  let T : Set V := ((↑({bad} : Finset V) : Set V)ᶜ)
  let I := G.induce T
  let xx : T := ⟨x,by simpa [T] using xb⟩
  let rr : T := ⟨r,by simpa [T] using rb⟩
  have crossing : ∃ a∈L.support,∃ b∈R.support,b≠bad ∧ G.Adj a b := by
    apply Classical.byContradiction
    intro no
    have stay {a b : T} (p : I.Walk a b) : a.val∈L.support → b.val∈L.support := by
      induction p with
      | nil => exact id
      | @cons a b c e q ih =>
        intro am
        apply ih
        rcases cover b.val with bl|br
        · exact bl
        have bne : b.val≠bad := fun eq=>
          (show b.val∉(↑({bad}:Finset V) : Set V) from b.property)
            (Finset.mem_coe.mpr (Finset.mem_singleton.mpr eq))
        exact (no ⟨a.val,am,b.val,br,bne,e⟩).elim
    obtain ⟨p⟩ := (conn {bad} (by simp)).preconnected xx rr
    exact dis (stay p L.start_mem_support) R.start_mem_support
  obtain ⟨a,am,b,bm,bb,ab⟩ := crossing
  obtain ⟨z,lPath⟩ := reroot_hub_route L lp lh am
  obtain ⟨w,rPath⟩ := last_hub_almost_universal_routes R rp ry rh b bm (fun _=>bb)
  exact traceable_of_route_cover (lPath.reverse.join rPath (list_disjoint_finsets dis) ab)
    (fun v=>mem_union.mpr ((cover v).imp List.mem_toFinset.mpr List.mem_toFinset.mpr))

theorem traceable_of_indexed_one_hole_two_runs (conn : DeletionTwoConnected G)
    {x y : V} (p : (cap G (fun _=>True)).Walk (some x) (some y))
    (hp : p.IsPath) (all : ∀ v,v∈p.support)
    {k t : ℕ} (kk : 0 < k) (kt : k < t) (tl : t < p.length)
    (apex : p.getVert k=none)
    (lMarks : ∀ j : ℕ, j < k → (cap G (fun _=>True)).Adj (some x) (p.getVert (j+1)))
    (rMarks : ∀ j : ℕ, k < j → j < p.length → j≠t → (cap G (fun _=>True)).Adj (some y) (p.getVert j)) :
    Traceable G := by
  classical
  have kl : k ≤ p.length := by omega
  obtain ⟨x',l,xe,le,L,hL,LS⟩ := cap_interval_path p hp kl apex
    (i:=0) (j:=k-1) (by omega) (by omega) (.inl (by omega))
  have xx : x=x' := by simpa using xe
  subst x'
  obtain ⟨r,y',re,ye,R,hR,RS⟩ := cap_interval_path p hp kl apex
    (i:=k+1) (j:=p.length) (by omega) le_rfl (.inr (by omega))
  have yy : y=y' := by simpa using ye
  subst y'
  obtain ⟨miss,_,me,_,_,_,_⟩ := cap_interval_path p hp kl apex
    (i:=t) (j:=t) le_rfl (by omega) (.inr kt)
  have ry : r≠y := by
    intro eq
    have e : p.getVert (k+1)=p.getVert p.length := by simpa [eq] using re
    have f := hp.getVert_injOn (by omega : k+1 ≤ p.length) (le_rfl : p.length ≤ p.length) e
    omega
  have lHub (v : V) (vl : v∈L.support) (vx : v≠x) : G.Adj x v := by
    obtain ⟨i,_,ik,hi⟩ := (LS v).mp vl
    have i0 : i≠0 := by intro e; subst i; exact vx (Option.some.inj (by simpa using hi)).symm
    have h := lMarks (i-1) (by omega)
    rw [show i-1+1=i by omega,hi] at h
    exact h
  have rHub (v : V) (vr : v∈R.support) (vy : v≠y) (vm : v≠miss) : G.Adj y v := by
    obtain ⟨i,ti,il,hi⟩ := (RS v).mp vr
    have ni : i≠p.length := by intro e; subst i; exact vy (Option.some.inj (by simpa using hi)).symm
    have mi : i≠t := fun e=>vm (Option.some.inj (hi.symm.trans (e.symm ▸ me)))
    have h := rMarks i (by omega) (by omega) mi
    rw [hi] at h
    exact h
  have sep := cap_intervals_disjoint hp (by omega) (by omega) (by omega) LS RS
  have cover (v : V) : v∈L.support ∨ v∈R.support := by
    obtain ⟨i,vi,il⟩ := mem_support_iff_exists_getVert.mp (all (some v))
    have ni : i≠k := by intro e; subst i; exact Option.some_ne_none _ (vi.symm.trans apex)
    by_cases ik : i < k
    · exact .inl ((LS v).mpr ⟨i,by omega,by omega,vi⟩)
    exact .inr ((RS v).mpr ⟨i,by omega,il,vi⟩)
  exact two_hub_paths_with_one_miss conn L R hL hR ry lHub rHub sep cover

#print axioms traceable_of_indexed_one_hole_two_runs
end Graffiti189Ore
