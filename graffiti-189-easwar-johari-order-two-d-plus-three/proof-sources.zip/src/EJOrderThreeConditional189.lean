import EJTerminalOrderThree189

namespace Graffiti189LongestPath.SmallOrder
open SimpleGraph SimpleGraph.Walk Finset Graffiti189Ore Graffiti189LongestPath
open private Graffiti189Ore.graphSize_lt Graffiti189Ore.graphSize_le from OreClosure189
universe u
variable {V : Type u} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

def DeletionTwoConnected (G : SimpleGraph V) : Prop :=
  ∀ R : Finset V,R.card<2 → (G.induce ((↑R : Set V)ᶜ)).Connected

theorem deletion_two_connected_of_supergraph {H : SimpleGraph V} (sub : G≤H)
    (hc : DeletionTwoConnected G) : DeletionTwoConnected H :=
  fun R r=>SimpleGraph.Connected.mono (fun _ _ h=>sub h) (hc R r)

/-- The missing subproof is exactly the slack edge-closure step of the paper,
not any additional degree or distance hypothesis. -/
def SafeThreeEdgeClosure : Prop :=
  ∀ {W : Type u} [Fintype W] [DecidableEq W] {J K : SimpleGraph W}
      [DecidableRel J.Adj] [DecidableRel K.Adj], J.Connected → DeletionTwoConnected J →
      ∀ {x y : W},x≠y → ¬J.Adj x y →
      (∀ u v,K.Adj u v → J.Adj u v ∨ s(u,v)=s(x,y)) →
      EdgeReady23 J x y → Graffiti189Ore.Traceable K → Graffiti189Ore.Traceable J

theorem exists_terminal_three_completion (safe : SafeThreeEdgeClosure.{u})
    (hc : G.Connected) (conn : DeletionTwoConnected G)
    (no : ¬Graffiti189Ore.Traceable G) :
    ∃ (H : SimpleGraph V) (inst : DecidableRel H.Adj),
      G≤H ∧ ¬Graffiti189Ore.Traceable H ∧
      ∀ x y : V,x≠y → ¬H.Adj x y → ¬(letI : DecidableRel H.Adj := inst; EdgeReady23 H x y) := by
  classical
  induction hn : graphSize (⊤ : SimpleGraph V)-graphSize G using Nat.strong_induction_on
      generalizing G with
  | h n ih =>
    by_cases terminal : ∀ x y : V,x≠y → ¬G.Adj x y → ¬EdgeReady23 G x y
    · exact ⟨G,_,le_rfl,no,terminal⟩
    have new : ∃ x y : V,x≠y ∧ ¬G.Adj x y ∧ EdgeReady23 G x y := by
      apply Classical.byContradiction
      intro never
      exact terminal (fun x y xy h r=>never ⟨x,y,xy,h,r⟩)
    obtain ⟨x,y,xy,notAdj,ready⟩ := new
    let K := G ⊔ fromEdgeSet ({s(x,y)} : Set (Sym2 V))
    letI : DecidableRel K.Adj := Classical.decRel _
    have sub : G≤K := le_sup_left
    have e : K.Adj x y := (sup_adj _ _ _ _).mpr (.inr ((fromEdgeSet_adj _).mpr ⟨rfl,xy⟩))
    have only (a b : V) (h : K.Adj a b) : G.Adj a b ∨ s(a,b)=s(x,y) := by
      rcases (sup_adj _ _ _ _).mp h with e|e
      · exact Or.inl e
      · exact Or.inr ((fromEdgeSet_adj _).mp e).1
    have nk : ¬Graffiti189Ore.Traceable K := fun p=>no (safe hc conn xy notAdj only ready p)
    have glt : G<K := lt_of_le_of_ne sub (fun h=>notAdj (h.symm ▸ e))
    have smaller : graphSize (⊤ : SimpleGraph V)-graphSize K<n := by
      have p := Graffiti189Ore.graphSize_lt glt
      have q := Graffiti189Ore.graphSize_le (le_top : K≤(⊤ : SimpleGraph V))
      omega
    obtain ⟨H,inst,h,nt,done⟩ := ih _ smaller (G:=K) (connected_of_supergraph sub hc)
      (deletion_two_connected_of_supergraph sub conn) nk rfl
    exact ⟨H,inst,sub.trans h,nt,done⟩

theorem traceable_at_order_le_two_d_add_three_of_edge_closure (safe : SafeThreeEdgeClosure.{u})
    (hc : G.Connected) (conn : DeletionTwoConnected G) (d : ℕ)
    (cap : ∀ v,(EvenFrom G v).card≤d+1)
    (degree : ∀ u v : V,u≠v → d≤G.degree u ∨ d≤G.degree v)
    (bound : Fintype.card V≤2*d+3) : Graffiti189Ore.Traceable G := by
  classical
  by_cases low : Fintype.card V≤2*d+2
  · exact traceable_at_order_le_two_d_add_two hc d cap degree low
  have order : Fintype.card V=2*d+3 := by omega
  apply Classical.byContradiction
  intro no
  obtain ⟨H,inst,sub,nt,terminal⟩ := exists_terminal_three_completion safe hc conn no
  letI : DecidableRel H.Adj := inst
  exact nt (traceable_terminal_order_three_add hc d order sub cap degree terminal)

#print axioms traceable_at_order_le_two_d_add_three_of_edge_closure
end Graffiti189LongestPath.SmallOrder
