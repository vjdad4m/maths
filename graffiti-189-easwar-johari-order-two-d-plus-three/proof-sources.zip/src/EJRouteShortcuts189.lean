import EJMarkRuns189

namespace Graffiti189Ore
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath.CrossSaturation
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

theorem walk_as_route {a b : V} (p : G.Walk a b) (hp : p.IsPath) :
    RouteOn G p.support.toFinset a b :=
  ⟨p,hp,fun _=>List.mem_toFinset.symm⟩

theorem reroot_hub_route {a b w : V} (p : G.Walk a b) (hp : p.IsPath)
    (hub : ∀ v,v∈p.support → v≠a → G.Adj a v) (wm : w∈p.support) :
    ∃ t,RouteOn G p.support.toFinset w t := by
  obtain ⟨t,q,hq,hs⟩ := route_from_hub_path p hp hub wm
  exact ⟨t,q,hq,fun v=>(hs v).trans List.mem_toFinset.symm⟩

theorem reverse_jump_route {a b t : V} (p : G.Walk a b) (hp : p.IsPath)
    (tm : t∈p.support) (aT : G.Adj a t) (notFirst : t≠p.snd) :
    ∃ w∈p.support,w≠a ∧ RouteOn G p.support.toFinset w b := by
  obtain ⟨j,e,jl⟩ := mem_support_iff_exists_getVert.mp tm
  have j0 : j≠0 := by intro h; subst j; exact aT.ne (by simpa using e)
  have j1 : j≠1 := by intro h; subst j; exact notFirst e.symm
  let i := p.length-j
  have il : i<p.reverse.length := by change p.length-j<p.reverse.length; rw [length_reverse]; omega
  have iPlus : i+1<p.reverse.length := by change p.length-j+1<p.reverse.length; rw [length_reverse]; omega
  have e' : p.reverse.getVert i=t := by
    rw [getVert_reverse]
    have e' : p.length-i=j := by dsimp only [i]; omega
    rwa [e']
  have step : G.Adj a (p.reverse.getVert i) := e'.symm ▸ aT
  obtain ⟨q,hq,hs⟩ := ore_spliced_path p.reverse hp.reverse i il step
  let w := p.reverse.getVert (i+1)
  have no : w≠a := by
    intro h
    have h' : p.reverse.getVert (i+1)=p.reverse.getVert p.reverse.length := by simpa only [w,getVert_length] using h
    have r := hp.reverse.getVert_injOn (Nat.le_of_lt iPlus) (Nat.le_refl _) h'
    omega
  have wm : w∈p.support := by
    have r := p.reverse.getVert_mem_support (i+1)
    simpa [w] using r
  refine ⟨w,wm,no,q.reverse,hq.reverse,?_⟩
  intro v
  simpa only [support_reverse,List.mem_reverse,List.mem_toFinset] using hs v

theorem list_disjoint_finsets {A B : List V} (dis : List.Disjoint A B) :
    Disjoint A.toFinset B.toFinset :=
  disjoint_left.mpr (fun _ ha hb=>dis (List.mem_toFinset.mp ha) (List.mem_toFinset.mp hb))

theorem traceable_of_route_cover {A : Finset V} {a b : V}
    (route : RouteOn G A a b) (cover : ∀ v,v∈A) : Traceable G := by
  obtain ⟨p,hp,hs⟩ := route
  exact ⟨a,b,p,hp,fun v=>(hs v).mpr (cover v)⟩

#print axioms reverse_jump_route
end Graffiti189Ore
