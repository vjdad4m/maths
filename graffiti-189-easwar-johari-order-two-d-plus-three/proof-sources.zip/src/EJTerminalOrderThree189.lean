import EJOrderTwoClose189

namespace Graffiti189LongestPath.SmallOrder
open Finset SimpleGraph SimpleGraph.Walk Graffiti189Ore Graffiti189LongestPath
open private Graffiti189Ore.degree_increasing from OreClosure189
variable {V : Type*} [Fintype V] [DecidableEq V] {G H : SimpleGraph V}
    [DecidableRel G.Adj] [DecidableRel H.Adj]
set_option linter.unusedSectionVars false

def CommonNeighbors (G : SimpleGraph V) [DecidableRel G.Adj] (u v : V) : Finset V :=
  G.neighborFinset u∩G.neighborFinset v

def EdgeReady23 (G : SimpleGraph V) [DecidableRel G.Adj] (u v : V) : Prop :=
  Fintype.card V≤G.degree u+G.degree v+1 ∨
    (Fintype.card V≤G.degree u+G.degree v+2 ∧ (CommonNeighbors G u v).card≤1) ∨
    (Fintype.card V≤G.degree u+G.degree v+3 ∧ (CommonNeighbors G u v).card=0)

theorem initial_far_high_at_exact_degree_small_order (hc : G.Connected)
    (d : ℕ) (size : Fintype.card V=2*d+3)
    (cap : ∀ v,(EvenFrom G v).card≤d+1)
    (degree : ∀ u v : V,u≠v → d≤G.degree u ∨ d≤G.degree v)
    {v : V} (vd : G.degree v=d) :
    ∃ u,3≤G.dist v u ∧ d≤G.degree u := by
  classical
  let B := insert v (G.neighborFinset v∪DistanceTwo G v)
  let R := (univ : Finset V)\B
  have upper : B.card≤2*d+1 := by
    have p := card_insert_le v (G.neighborFinset v∪DistanceTwo G v)
    have q := card_union_le (G.neighborFinset v) (DistanceTwo G v)
    have r := distanceTwo_le_of_even d v (cap v)
    rw [card_neighborFinset_eq_degree,vd] at q
    change B.card≤_ at p
    omega
  have lc : 1<R.card := by
    change 1<((univ : Finset V)\B).card
    rw [card_sdiff (subset_univ _),card_univ,size]
    omega
  have far (u : V) (ur : u∈R) : 3≤G.dist v u := by
    have out := (mem_sdiff.mp ur).2
    have d0 : G.dist v u≠0 := by
      intro h
      exact out (mem_insert.mpr (.inl ((hc.dist_eq_zero_iff).mp h).symm))
    have d1 : G.dist v u≠1 := by
      intro h
      exact out (mem_insert_of_mem (mem_union_left _ ((mem_neighborFinset G v u).mpr
        (dist_eq_one_iff_adj.mp h))))
    have d2 : G.dist v u≠2 := by
      intro h
      have m : u∈DistanceTwo G v := by simp [DistanceTwo,h]
      exact out (mem_insert_of_mem (mem_union_right _ m))
    omega
  obtain ⟨u,ur,w,wr,uw⟩ := one_lt_card.mp lc
  exact (degree u w uw).elim (fun h=>⟨u,far u ur,h⟩) (fun h=>⟨w,far w wr,h⟩)

theorem common_new_edges_when_unchanged (_hc : G.Connected) (sub : G≤H)
    {v u : V} (vEq : G.degree v=H.degree v) (far : 3≤G.dist v u) :
    (CommonNeighbors H v u).card≤H.degree u-G.degree u := by
  classical
  have sub' : CommonNeighbors H v u⊆H.neighborFinset u\G.neighborFinset u := by
    intro w ww
    obtain ⟨vw,uw⟩ := mem_inter.mp ww
    have vw' := neighbors_unchanged_of_degree_unchanged sub vEq w ((mem_neighborFinset H v w).mp vw)
    refine mem_sdiff.mpr ⟨uw,?_⟩
    intro uw'
    have q := G.dist_le (Walk.cons vw' (Walk.cons ((mem_neighborFinset G u w).mp uw').symm .nil))
    change G.dist v u≤2 at q
    omega
  have m : G.neighborFinset u⊆H.neighborFinset u := fun x hx=>
    (mem_neighborFinset H u x).mpr (sub ((mem_neighborFinset G u x).mp hx))
  have de := card_le_card sub'
  rwa [card_sdiff m,card_neighborFinset_eq_degree,card_neighborFinset_eq_degree] at de

/-- The degree-boosting part of Easwar–Johari, Theorem 4.2.
No degree sequence theorem is needed after the boost. -/
theorem traceable_terminal_order_three_add (hc : G.Connected)
    (d : ℕ) (size : Fintype.card V=2*d+3) (sub : G≤H)
    (cap : ∀ v,(EvenFrom G v).card≤d+1)
    (degree : ∀ u v : V,u≠v → d≤G.degree u ∨ d≤G.degree v)
    (terminal : ∀ u v : V,u≠v → ¬H.Adj u v → ¬EdgeReady23 H u v) :
    Graffiti189Ore.Traceable H := by
  classical
  have boosted (v : V) (hi : d≤G.degree v) : d+1≤H.degree v := by
    have mono := Graffiti189Ore.degree_increasing sub v
    have vd : H.degree v≠d := by
      intro eq
      have gEq : G.degree v=d := by omega
      have vEq : G.degree v=H.degree v := gEq.trans eq.symm
      obtain ⟨u,far,uh⟩ := initial_far_high_at_exact_degree_small_order hc d size cap degree gEq
      have vu : v≠u := by intro e; rw [e,dist_self] at far; omega
      have noG : ¬G.Adj v u := by
        intro h
        have e := dist_eq_one_iff_adj.mpr h
        omega
      have noH : ¬H.Adj v u := fun h=>noG (neighbors_unchanged_of_degree_unchanged sub vEq u h)
      have common := common_new_edges_when_unchanged hc sub vEq far
      have um := Graffiti189Ore.degree_increasing sub u
      apply terminal v u vu noH
      by_cases big : d+2≤H.degree u
      · exact .inl (by omega)
      by_cases med : H.degree u=d+1
      · exact .inr (.inl ⟨by omega,by omega⟩)
      exact .inr (.inr ⟨by omega,by omega⟩)
    omega
  exact traceable_all_but_one_by_order (connected_of_supergraph sub hc) (d+1)
    (fun u v ne=>(degree u v ne).imp (boosted u) (boosted v)) (by omega)

#print axioms traceable_terminal_order_three_add
end Graffiti189LongestPath.SmallOrder
