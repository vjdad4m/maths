import ScaledDeficitAll189
import Mathlib.Tactic.Linarith
import PosaOneLow189
import FanWeighted189
import MengerRoutable189
import SingleHeight189
import StarCycleClosure189
import Mathlib.Tactic.Ring

-- SOURCE DonorQuadratic189.lean
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.OneSlack Graffiti189LongestPath.Rigidity Graffiti189LongestPath.DeficitThirdShell
open private Graffiti189LongestPath.mem_distanceTwo Graffiti189LongestPath.dist_two from SmallSeparator189
open private Graffiti189LongestPath.Rigidity.mem_external Graffiti189LongestPath.Rigidity.mem_omittedStar from Rigidity189
open private Graffiti189LongestPath.OneSlack.boundary_except_pins_two Graffiti189LongestPath.OneSlack.card_pinVertices from OneSlack189
set_option warningAsError true
set_option maxHeartbeats 6500000
namespace Graffiti189LongestPath.DonorQuadratic
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

omit [Fintype V] [DecidableRel G.Adj] in
/-- A minimum donor set has a distinct private gate for each donor. -/
theorem exists_private_donor_cover (A C : Finset V)
    (initial : ∀ b∈C,∃ a∈A,G.Adj a b) :
    ∃ D⊆A, (∀ b∈C,∃ a∈D,G.Adj a b) ∧
      (∀ a∈D,∃ b∈C,G.Adj a b ∧ ∀ u∈D,u≠a → ¬G.Adj u b) := by
  classical
  let isCover (D : Finset V) : Prop := ∀ b∈C,∃ a∈D,G.Adj a b
  letI decCover : DecidablePred isCover := fun _ => Classical.propDecidable _
  let F := A.powerset.filter isCover
  have fm (D : Finset V) : D∈F ↔ D⊆A ∧ isCover D := by simp [F]
  have ne : F.Nonempty := ⟨A,(fm A).mpr ⟨Subset.rfl,initial⟩⟩
  obtain ⟨D,dm,mn⟩ := exists_min_image F Finset.card ne
  obtain ⟨DA,cover⟩ := (fm D).mp dm
  refine ⟨D,DA,cover,?_⟩
  intro a ad
  apply Classical.byContradiction
  intro no
  have cc (b : V) (bc : b∈C) : ∃ u∈D.erase a,G.Adj u b := by
    obtain ⟨u,ud,edge⟩ := cover b bc
    by_cases ua : u=a
    · subst u
      apply Classical.byContradiction
      intro fail
      apply no
      refine ⟨b,bc,edge,?_⟩
      intro u ud na ed
      exact fail ⟨u,mem_erase.mpr ⟨na,ud⟩,ed⟩
    · exact ⟨u,mem_erase.mpr ⟨ua,ud⟩,edge⟩
  have sm : D.erase a∈F := (fm _).mpr ⟨(erase_subset _ _).trans DA,cc⟩
  have h := mn (D.erase a) sm
  have c := card_erase_add_one ad
  omega

/-- Every other selected donor pays a distinct parity slot: use its
private gate if adjacent, or the donor itself otherwise. -/
theorem shell_bound_of_donor_pair_charging (hc : G.Connected) (d sl : Nat)
    (cap : ∀ v,(DistanceTwo G v).card≤d)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
    (few : (Pins p x).card≤sl) :
    4*(Shell G x 3).card≤(d+1)*(d+1)+4*(sl*d) := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let P := PinVertices p x
  let C := B\P
  let H := Shell G x 3
  let HP := P.biUnion (fun t => H∩DistanceTwo G t)
  have cw : C⊆DistanceTwo G x := Graffiti189LongestPath.OneSlack.boundary_except_pins_two hc hp hx
  have ck : C.card≤d := (card_le_card cw).trans (cap x)
  have pk : P.card≤sl := by
    have e := Graffiti189LongestPath.OneSlack.card_pinVertices hp (x:=x)
    change P.card=(Pins p x).card at e
    omega
  have pk' : HP.card≤P.card*d := card_biUnion_le_card_mul P _ d
    (fun t _ => (card_le_card inter_subset_right).trans (cap t))
  have pins : HP.card≤sl*d := pk'.trans (Nat.mul_le_mul_right d pk)
  have initial (v : V) (vc : v∈C) : ∃ u∈A,G.Adj u v := by
    obtain ⟨_,u,ua,e⟩ := Graffiti189LongestPath.Rigidity.mem_external.mp (mem_sdiff.mp vc).1
    exact ⟨u,ua,e⟩
  obtain ⟨D,DA,DC,priv⟩ := exists_private_donor_cover A C initial
  have rep₀ (v : V) : ∃ b,v∈D → b∈C ∧ G.Adj v b ∧ ∀ u∈D,u≠v → ¬G.Adj u b := by
    by_cases vd : v∈D
    · obtain ⟨b,bc,e,safe⟩ := priv v vd
      exact ⟨b,fun _ => ⟨bc,e,safe⟩⟩
    · exact ⟨x,fun q => (vd q).elim⟩
  choose rep repP using rep₀
  have repInj : Set.InjOn rep (↑D : Set V) := by
    intro v vd w wd eq
    by_contra ne
    have e : G.Adj v (rep w) := eq ▸ (repP v vd).2.1
    exact (repP w wd).2.2 v vd ne e
  have rc : (D.image rep).card=D.card := card_image_of_injOn repInj
  have rsub : D.image rep⊆C := by
    intro z hz
    obtain ⟨v,vd,rfl⟩ := mem_image.mp hz
    exact (repP v vd).1
  have dm : D.card≤d := (rc ▸ card_le_card rsub).trans ck
  have choice₀ (v : V) : ∃ a,v∈C → a∈D ∧ G.Adj a v := by
    by_cases vc : v∈C
    · obtain ⟨a,ad,e⟩ := DC v vc
      exact ⟨a,fun _ => ⟨ad,e⟩⟩
    · exact ⟨x,fun q => (vc q).elim⟩
  choose f fp using choice₀
  have fA (v : V) (vc : v∈C) : f v∈A ∧ G.Adj (f v) v :=
    ⟨DA (fp v vc).1,(fp v vc).2⟩
  let HD := D.biUnion (gateThird G x C)
  have all : H⊆HD∪HP := by
    intro z hz
    have w := shell_three_donor_cover hc hp hx f fA hz
    change z∈(C.image f).biUnion (gateThird G x C)∪HP at w
    rcases mem_union.mp w with h|h
    · obtain ⟨v,vf,zv⟩ := mem_biUnion.mp h
      obtain ⟨u,uc,rfl⟩ := mem_image.mp vf
      exact mem_union.mpr (Or.inl (mem_biUnion.mpr ⟨f u,(fp u uc).1,zv⟩))
    · exact mem_union.mpr (Or.inr h)
  have noA {u : V} (uc : u∈C) : u∉A :=
    (Graffiti189LongestPath.Rigidity.mem_external.mp (mem_sdiff.mp uc).1).1
  have roots {u : V} (ua : u∈A) : u=x ∨ G.Adj x u :=
    (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp ua).2
  have near {u : V} (ua : u∈A) : G.dist x u≤1 := by
    rcases roots ua with rfl|e
    · rw [dist_self]; omega
    · rw [dist_eq_one_iff_adj.mpr e]
  let m := D.card
  let bound := d+1
  have diet (v : V) (vd : v∈D) : (gateThird G x C v).card≤bound-m := by
    let E := D.erase v
    let pay (u : V) := if G.Adj v u then rep u else u
    let W := E.image pay
    have pinj : Set.InjOn pay (↑E : Set V) := by
      intro u uE w wE eq
      have ud := (mem_erase.mp uE).2
      have wd := (mem_erase.mp wE).2
      by_cases vu : G.Adj v u <;> by_cases vw : G.Adj v w
      · exact repInj ud wd (by simpa [pay,vu,vw] using eq)
      · have e : rep u=w := by simpa [pay,vu,vw] using eq
        exact (noA (repP u ud).1 (e.symm ▸ DA wd)).elim
      · have e : u=rep w := by simpa [pay,vu,vw] using eq
        exact (noA (repP w wd).1 (e ▸ DA ud)).elim
      · simpa [pay,vu,vw] using eq
    have wc : W.card=E.card := card_image_of_injOn pinj
    have ec : E.card+1=m := card_erase_add_one vd
    have spend : W⊆DistanceTwo G v := by
      intro z hz
      obtain ⟨u,ue,rfl⟩ := mem_image.mp hz
      obtain ⟨uv,ud⟩ := mem_erase.mp ue
      by_cases ad : G.Adj v u
      · have gp := repP u ud
        have no := gp.2.2 v vd uv.symm
        have ne : v≠rep u := fun e => noA gp.1 (e ▸ DA vd)
        have c := Graffiti189LongestPath.mem_distanceTwo.mpr
          (Graffiti189LongestPath.dist_two hc ne no ad gp.2.1)
        simpa [pay,ad] using c
      · have nv : v≠x := by
          intro e
          subst v
          exact ad ((roots (DA ud)).resolve_left uv)
        have vx := (roots (DA vd)).resolve_left nv
        have nu : u≠x := by
          intro e
          subst u
          exact ad vx.symm
        have ux := (roots (DA ud)).resolve_left nu
        have c := Graffiti189LongestPath.mem_distanceTwo.mpr
          (Graffiti189LongestPath.dist_two hc uv.symm ad vx.symm ux)
        simpa [pay,ad] using c
    have dis : Disjoint W (gateThird G x C v) := disjoint_left.mpr (by
      intro z zw zh
      obtain ⟨u,ue,rfl⟩ := mem_image.mp zw
      have ud := (mem_erase.mp ue).2
      have high := mem_shell.mp (mem_gateThird.mp zh).1
      by_cases e : G.Adj v u
      · have dt := Graffiti189LongestPath.mem_distanceTwo.mp (cw (repP u ud).1)
        simp only [pay,if_pos e] at high
        omega
      · have l := near (DA ud)
        simp only [pay,if_neg e] at high
        omega)
    have c := card_le_card (union_subset spend (gate_third_subset hc (DA vd) C))
    rw [card_union_of_disjoint dis] at c
    have cb := cap v
    dsimp only [bound]
    omega
  have HDc : HD.card≤m*(bound-m) := card_biUnion_le_card_mul D _ (bound-m) diet
  have allc := (card_le_card all).trans (card_union_le HD HP)
  have a : H.card≤m*(bound-m)+sl*d := by omega
  have mm : m≤bound := by dsimp [m,bound]; omega
  let rem := bound-m
  have eq : m+rem=bound := by dsimp [rem]; omega
  have quad : 4*(m*rem)≤bound*bound := by
    have q : 4*(m*rem)≤(m+rem)*(m+rem) := by
      have w : 4*((m:ℤ)*(rem:ℤ))≤((m:ℤ)+(rem:ℤ))*((m:ℤ)+(rem:ℤ)) := by
        nlinarith [sq_nonneg ((m:ℤ)-(rem:ℤ))]
      exact_mod_cast w
    rwa [eq] at q
  have a' := Nat.mul_le_mul_left 4 a
  change 4*H.card≤4*(m*rem+sl*d) at a'
  rw [Nat.mul_add] at a'
  change 4*H.card≤bound*bound+4*(sl*d)
  omega

#print axioms exists_private_donor_cover
#print axioms shell_bound_of_donor_pair_charging
end Graffiti189LongestPath.DonorQuadratic

-- SOURCE WideRatioShore189.lean
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack Graffiti189LongestPath.ActiveStarHeight
open Graffiti189LongestPath.ExactStarShore Graffiti189LongestPath.ShoreConnectivity Graffiti189LongestPath.ShoreDegrees
open Graffiti189LongestPath.ScaledCharge Graffiti189LongestPath.ScaledConnectivity Graffiti189LongestPath.StarCycleClosure
open Graffiti189LongestPath.Normalize Graffiti189LongestPath.PosaOneLow Graffiti189LongestPath.MengerRoutable Graffiti189LongestPath.FanWeighted
open Graffiti189LongestPath.CycleHallSplice Graffiti189LongestPath.UltraOrder Graffiti189LongestPath.SingleHeight
open private Graffiti189LongestPath.Rigidity.mem_external Graffiti189LongestPath.Rigidity.mem_omittedStar from Rigidity189
open private Graffiti189LongestPath.boundary_card_of_connectivity Graffiti189LongestPath.no_endpoints from SmallSeparator189
set_option warningAsError true
set_option linter.unusedVariables false
set_option maxHeartbeats 4500000
namespace Graffiti189LongestPath.WideRatioShore
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem wide_ratio_star_stays_connected (hc : G.Connected) (k sl : Nat) (hk : 4*sl+6≤k) (positive : 1≤sl)
    (cap : ∀ v,(EvenFrom G v).card≤k+sl+1)
    (conn : ∀ D : Finset V,D.card<k → (G.induce ((↑D : Set V)ᶜ)).Connected)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p)
    (hx : x∉p.support)
    (sat : (External G (OmittedStar p x)).card≤k+(sl-1))
    (far : k≤((univ:Finset V)\(OmittedStar p x∪External G (OmittedStar p x))).card)
    (X : Finset V) (inside : X⊆OmittedStar p x)
    (small : 3*X.card+4*sl<(OmittedStar p x).card) :
    (G.induce ((↑((OmittedStar p x)\X)):Set V)).Connected := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let U := univ\(A∪B)
  change B.card≤k+(sl-1) at sat
  have large : k≤U.card := far
  have rA {z : V} (hz : z∈U) : z∉A := fun h =>
    (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inl h))
  have rB {z : V} (hz : z∈U) : z∉B := fun h =>
    (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inr h))
  have ul : ∀ u∈U,∀ v∉U,G.Adj u v → v∈B := by
    intro u hu v hv ed
    have cov : v∈A∪B := Classical.byContradiction
      (fun h => hv (mem_sdiff.mpr ⟨mem_univ _,h⟩))
    exact (mem_union.mp cov).elim (fun h => (rB hu
      (Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨rA hu,v,h,ed.symm⟩)).elim) id
  have ub : Disjoint U B := disjoint_left.mpr (fun _ h h' => rB h h')
  have au : Disjoint A U := disjoint_left.mpr (fun _ h h' => rA h' h)
  have ab : Disjoint A B := disjoint_left.mpr (fun _ h h' =>
    (Graffiti189LongestPath.Rigidity.mem_external.mp h').1 h)
  have cA : ∀ y∈A,∀ z∉A,G.Adj y z → z∈B := fun _ hy _ hz e =>
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨hz,_,hy,e⟩
  have r : ∀ z∈A,z=x ∨ G.Adj x z := fun _ h =>
    (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp h).2
  exact scaled_shore_stays_connected hc k sl positive A B U X x conn (by omega) ab ub au large
    (by omega) cA ul (fun v => distanceTwo_le_of_even (k+sl) v (cap v)) r inside small


theorem wide_ratio_induced_floor (hc : G.Connected) (k sl : Nat) (hk : 4*sl+6≤k) (positive : 1≤sl)
    (cap : ∀ v,(EvenFrom G v).card≤k+sl+1)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
   
    (sat : (External G (OmittedStar p x)).card≤k+(sl-1))
    (far : k≤((univ:Finset V)\(OmittedStar p x∪External G (OmittedStar p x))).card)
    (v : ↥((OmittedStar p x : Finset V) : Set V)) :
    (OmittedStar p x).card≤2*(G.induce (OmittedStar p x : Set V)).degree v+2*sl := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let U := univ\(A∪B)
  let I := G.induce (A : Set V)
  change B.card≤k+(sl-1) at sat
  have large : k≤U.card := far
  have rA {z : V} (hz : z∈U) : z∉A := fun h => (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inl h))
  have rB {z : V} (hz : z∈U) : z∉B := fun h => (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inr h))
  have ul : ∀ u∈U,∀ v∉U,G.Adj u v → v∈B := by
    intro u hu v hv ed
    have cov : v∈A∪B := Classical.byContradiction (fun h => hv (mem_sdiff.mpr ⟨mem_univ _,h⟩))
    exact (mem_union.mp cov).elim (fun h => (rB hu
      (Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨rA hu,v,h,ed.symm⟩)).elim) id
  have ub : Disjoint U B := disjoint_left.mpr (fun _ h h' => rB h h')
  have au : Disjoint A U := disjoint_left.mpr (fun _ h h' => rA h' h)
  have ab : Disjoint A B := disjoint_left.mpr (fun _ h h' =>
    (Graffiti189LongestPath.Rigidity.mem_external.mp h').1 h)
  have cA : ∀ y∈A,∀ z∉A,G.Adj y z → z∈B := fun _ hy _ hz e =>
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨hz,_,hy,e⟩
  have root : ∀ z∈A,z=x ∨ G.Adj x z := fun _ h =>
    (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp h).2
  have va : v.val∈A := v.property
  have vo : v.val∉p.support := (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp va).1
  have low : k≤G.degree v.val := by
    have av : a≠v.val := fun e => vo (e ▸ p.start_mem_support)
    rw [←G.card_neighborFinset_eq_degree]
    apply Graffiti189LongestPath.boundary_card_of_connectivity k conn (A:={v.val}) (a:=a)
    · exact mem_singleton_self _
    · exact fun h => av (mem_singleton.mp h)
    · exact fun h => (Graffiti189LongestPath.no_endpoints hp vo).1 ((G.mem_neighborFinset _ _).mp h)
    · exact disjoint_left.mpr (fun _ h e => ((G.mem_neighborFinset v.val _).mp e).ne (mem_singleton.mp h).symm)
    · exact fun _ h _ _ e => (G.mem_neighborFinset _ _).mpr ((mem_singleton.mp h) ▸ e)
  have ineq := shore_charge_with_cut_deficit hc (k+sl) k (sl-1) A U B conn (by omega) ab ub au large
    cA ul (fun v => distanceTwo_le_of_even (k+sl) v (cap v)) root v
  change A.card+G.degree v.val+_≤2*I.degree v+(k+sl)+(sl-1)+1 at ineq
  change A.card≤2*I.degree v+2*sl
  omega

theorem wide_ratio_root_deleted_degrees (hc : G.Connected) (k sl : Nat) (hk : 4*sl+6≤k) (positive : 1≤sl)
    (cap : ∀ v,(EvenFrom G v).card≤k+sl+1)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
   
    (sat : (External G (OmittedStar p x)).card≤k+(sl-1))
    (far : k≤((univ:Finset V)\(OmittedStar p x∪External G (OmittedStar p x))).card)
    (v : ↥(((OmittedStar p x).erase x : Finset V) : Set V)) :
    (OmittedStar p x).card≤2*(G.induce (((OmittedStar p x).erase x : Finset V) : Set V)).degree v+2*sl+2 ∧
      (k+sl≤G.degree v.val →
       (OmittedStar p x).card≤2*(G.induce (((OmittedStar p x).erase x : Finset V) : Set V)).degree v+sl+2) := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let U := univ\(A∪B)
  let T := A.erase x
  let J := G.induce (T : Set V)
  let I := G.induce (A : Set V)
  change B.card≤k+(sl-1) at sat
  have large : k≤U.card := far
  have rA {z : V} (hz : z∈U) : z∉A := fun h => (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inl h))
  have rB {z : V} (hz : z∈U) : z∉B := fun h => (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inr h))
  have ul : ∀ u∈U,∀ v∉U,G.Adj u v → v∈B := by
    intro u hu v hv ed
    have cov : v∈A∪B := Classical.byContradiction (fun h => hv (mem_sdiff.mpr ⟨mem_univ _,h⟩))
    exact (mem_union.mp cov).elim (fun h => (rB hu
      (Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨rA hu,v,h,ed.symm⟩)).elim) id
  have ub : Disjoint U B := disjoint_left.mpr (fun _ h h' => rB h h')
  have au : Disjoint A U := disjoint_left.mpr (fun _ h h' => rA h' h)
  have ab : Disjoint A B := disjoint_left.mpr (fun _ h h' =>
    (Graffiti189LongestPath.Rigidity.mem_external.mp h').1 h)
  have cA : ∀ y∈A,∀ z∉A,G.Adj y z → z∈B := fun _ hy _ hz e =>
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨hz,_,hy,e⟩
  have root : ∀ z∈A,z=x ∨ G.Adj x z := fun _ h =>
    (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp h).2
  have va : v.val∈A := (mem_erase.mp v.property).2
  have vo : v.val∉p.support := (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp va).1
  have vx : G.Adj v.val x := ((root _ va).resolve_left (mem_erase.mp v.property).1).symm
  have xa : x∈A := Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
  have low : k≤G.degree v.val := by
    have av : a≠v.val := fun e => vo (e ▸ p.start_mem_support)
    rw [←G.card_neighborFinset_eq_degree]
    apply Graffiti189LongestPath.boundary_card_of_connectivity k conn (A:={v.val}) (a:=a)
    · exact mem_singleton_self _
    · exact fun h => av (mem_singleton.mp h)
    · exact fun h => (Graffiti189LongestPath.no_endpoints hp vo).1 ((G.mem_neighborFinset _ _).mp h)
    · exact disjoint_left.mpr (fun _ h e => ((G.mem_neighborFinset v.val _).mp e).ne (mem_singleton.mp h).symm)
    · exact fun _ h _ _ e => (G.mem_neighborFinset _ _).mpr ((mem_singleton.mp h) ▸ e)
  let av : ↥(A : Set V) := ⟨v.val,va⟩
  have ineq := shore_charge_with_cut_deficit hc (k+sl) k (sl-1) A U B conn (by omega) ab ub au large
    cA ul (fun v => distanceTwo_le_of_even (k+sl) v (cap v)) root av
  change A.card+G.degree v.val+_≤2*I.degree av+(k+sl)+(sl-1)+1 at ineq
  have id := universal_root_degree_drop A x xa v vx
  change J.degree v+1=I.degree av at id
  change A.card≤2*J.degree v+2*sl+2 ∧ (k+sl≤G.degree v.val → A.card≤2*J.degree v+sl+2)
  omega

#print axioms universal_root_degree_drop

theorem wide_ratio_root_deleted_long_cycle
    (hc : G.Connected) (k sl : Nat) (hk : 4*sl+6≤k) (positive : 1≤sl)
    (cap : ∀ v,(EvenFrom G v).card≤k+sl+1)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
    (sat : (External G (OmittedStar p x)).card≤k+(sl-1))
    (far : k≤((univ:Finset V)\(OmittedStar p x∪External G (OmittedStar p x))).card)
    (height : k+1≤(OmittedStar p x).card)
    (deg : ∀ u v : V,u≠v → k+sl≤G.degree u ∨ k+sl≤G.degree v) :
    ∃ a, ∃ c : (G.induce (((OmittedStar p x).erase x : Finset V) : Set V)).Walk a a,
      c.IsCycle ∧ 2*(((OmittedStar p x).card-sl-2)/2)≤c.length := by
  classical
  let A := OmittedStar p x
  let T := A.erase x
  let W := ↥(T : Set V)
  let J := G.induce (T : Set V)
  let m := (A.card-sl-2)/2
  have xt : x∈A := Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
  have h : k+1≤A.card := height
  have wc : Fintype.card W=A.card-1 := by
    change Fintype.card ↥T=A.card-1
    exact (Fintype.card_coe T).trans (card_erase_of_mem xt)
  have del (S : Finset W) (sc : S.card<2) :
      (J.induce ((↑S : Set W)ᶜ)).Connected := by
    let e : W ↪ V := ⟨Subtype.val,Subtype.val_injective⟩
    let X := insert x (S.map e)
    have xs : X⊆A := by
      intro v vx
      rcases mem_insert.mp vx with rfl|h
      · exact xt
      · obtain ⟨w,_,rfl⟩ := mem_map.mp h
        exact (mem_erase.mp w.property).2
    have xl := (card_insert_le x (S.map e)).trans (by rw [card_map])
    change X.card≤S.card+1 at xl
    have sz : 3*X.card+4*sl<(OmittedStar p x).card := by change 3*X.card+4*sl<A.card; omega
    have con := wide_ratio_star_stays_connected hc k sl hk positive cap conn
      hp hx sat far X xs sz
    exact (erase_root_and_set_iso (G:=G) A x S).connected_iff.mp con
  have low (v : W) : 2≤J.degree v := by
    have dg := (wide_ratio_root_deleted_degrees hc k sl hk positive cap conn hp
      hx sat far v).1
    change A.card≤2*J.degree v+2*sl+2 at dg
    omega
  have highJ (v : W) (vh : k+sl≤G.degree v.val) : m≤J.degree v := by
    have dg := (wide_ratio_root_deleted_degrees hc k sl hk positive cap conn hp
      hx sat far v).2 vh
    change A.card≤2*J.degree v+sl+2 at dg
    dsimp [m]
    omega
  have pair (u v : W) (ne : u≠v) : m≤J.degree u ∨ m≤J.degree v :=
    (deg u.val v.val (fun e => ne (Subtype.ext e))).imp (highJ u) (highJ v)
  have mc : 2≤m := by dsimp [m]; omega
  obtain ⟨r,c,cc,cl⟩ := proved_one_low_circumference W J m mc (by omega) del low pair
  have mm : 2*m≤Fintype.card W := by dsimp [m]; omega
  rw [min_eq_right mm] at cl
  exact ⟨r,c,cc,cl⟩


theorem wide_ratio_no_long_shore_cycle (hc : G.Connected) (k sl : Nat) (hk : 4*sl+6≤k) (positive : 1≤sl)
    (cap : ∀ v,(EvenFrom G v).card≤k+sl+1)
    (conn : ∀ D : Finset V,D.card<k → (G.induce ((↑D : Set V)ᶜ)).Connected)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p)
    (hx : x∉p.support)
    (sat : (External G (OmittedStar p x)).card≤k+(sl-1))
    (far : k≤((univ:Finset V)\(OmittedStar p x∪External G (OmittedStar p x))).card)
    (large : 6+4*sl<(OmittedStar p x).card)
    (len : Nat)
    (ash : k≤(OmittedStar p x).card)
    (long : Fintype.card V < (OmittedStar p x).card+k+(k+1)*(len+1))
    (cyc : ∃ z, ∃ c : (G.induce (((OmittedStar p x).erase x : Finset V) : Set V)).Walk z z,
      c.IsCycle ∧ max 2 len≤c.length) : False := by
  classical
  let A := OmittedStar p x
  change k≤A.card at ash
  change 6+4*sl<A.card at large
  let Z : Set V := ((A.erase x : Finset V) : Set V)
  let J := G.induce Z
  have sepConn (S : Finset Z) (sc : S.card<2) :
      (J.induce ((↑S : Set Z)ᶜ)).Connected := by
    let e : Z ↪ V := ⟨Subtype.val,Subtype.val_injective⟩
    let X := insert x (S.map e)
    have xs : X⊆A := by
      intro v vx
      rcases mem_insert.mp vx with rfl|h
      · exact Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
      · obtain ⟨w,_,rfl⟩ := mem_map.mp h
        exact (mem_erase.mp w.property).2
    have xl := (card_insert_le x (S.map e)).trans (by rw [card_map])
    change X.card≤S.card+1 at xl
    have con := wide_ratio_star_stays_connected hc k sl hk positive cap conn hp
      hx sat far X xs (show 3*X.card+4*sl<A.card by omega)
    exact (erase_root_and_set_iso (G:=G) A x S).connected_iff.mp con
  let f : J →g G := ⟨Subtype.val, fun e => e⟩
  have fi : Function.Injective f := Subtype.val_injective
  have off (z : Z) : x≠f z := fun e => (mem_erase.mp z.property).1 e.symm
  have adj (z : Z) : G.Adj x (f z) := by
    have zz := (mem_erase.mp z.property).2
    exact (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp zz).2.resolve_left (fun ne => off z ne.symm)
  obtain ⟨a,c,hc',cl⟩ := cyc
  have big : 2≤c.support.toFinset.card := by
    rw [cycle_card_support c hc']
    exact (le_max_left _ _).trans cl
  have L : len≤c.length := (le_max_right _ _).trans cl
  have route : ∀ u∈A,∀ v∈A,u≠v →
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈A) ∧ len+1≤q.length+1 := by
    intro u ua v va uv
    have rA {z : V} (e : z=x ∨ ∃ w : Z,f w=z) : z∈A := by
      rcases e with rfl|⟨w,rfl⟩
      · exact Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
      · exact (mem_erase.mp w.property).2
    by_cases hu : u=x
    · subst u
      let t : Z := ⟨v,mem_erase.mpr ⟨uv.symm,va⟩⟩
      obtain ⟨q,qp,ql,qs⟩ := cycle_to_prescribed_root_route f fi off adj c hc'
        (t:=t) (fun s h => sepConn s (by omega))
      exact ⟨q,qp,fun z hz => rA (qs z hz),by omega⟩
    by_cases hv : v=x
    · subst v
      let t : Z := ⟨u,mem_erase.mpr ⟨hu,ua⟩⟩
      obtain ⟨q,qp,ql,qs⟩ := cycle_to_prescribed_root_route f fi off adj c hc'
        (t:=t) (fun s h => sepConn s (by omega))
      exact ⟨q.reverse,qp.reverse,fun z hz => rA (qs z (by
        simpa only [support_reverse,List.mem_reverse] using hz)),by simpa using (by omega : len+1≤q.length+1)⟩
    let s : Z := ⟨u,mem_erase.mpr ⟨hu,ua⟩⟩
    let t : Z := ⟨v,mem_erase.mpr ⟨hv,va⟩⟩
    have ne : s≠t := fun e => uv (congrArg Subtype.val e)
    obtain ⟨q,qp,ql,qs⟩ := cycle_to_prescribed_route f fi ne off adj c hc' big sepConn
    exact ⟨q,qp,fun z hz => rA (qs z hz),by omega⟩
  have ao : ∀ z∈A,z∉p.support := fun _ z => (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp z).1
  obtain ⟨F⟩ := hooks_of_small_deletion_connectivity A k hp ao ash (support_large k conn hp hx) conn
  have low := weighted_hooked_lower k (by omega) hp (len+1) A ao (by omega) route F
  change Fintype.card V<A.card+k+(k+1)*(len+1) at long
  omega

#print axioms erase_root_and_set_iso

#print axioms wide_ratio_root_deleted_long_cycle
#print axioms wide_ratio_no_long_shore_cycle
end Graffiti189LongestPath.WideRatioShore

-- SOURCE WideRatioDeficit189.lean
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack Graffiti189LongestPath.PinRun
open Graffiti189LongestPath.DeficitActive Graffiti189LongestPath.ScaledActive Graffiti189LongestPath.DeficitLongest
open Graffiti189LongestPath.WideRatioShore Graffiti189LongestPath.DeficitThirdShell
open Graffiti189LongestPath.DonorQuadratic Graffiti189LongestPath.ActiveStarHeight
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
open private Graffiti189LongestPath.pin_data from SmallSeparator189
open private Graffiti189LongestPath.OneSlack.boundary_except_pins_two Graffiti189LongestPath.OneSlack.card_pinVertices
  Graffiti189LongestPath.OneSlack.pin_vertices_subset_boundary Graffiti189LongestPath.OneSlack.first_pins_nonempty from OneSlack189
set_option warningAsError true
set_option maxHeartbeats 7000000
namespace Graffiti189LongestPath.WideRatioDeficit
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- #189 for every positive slack s=d−k with k ≥ 4s+6.
No normalized attachment or separator geometry is assumed. -/
theorem traceable_of_wide_ratio_connectivity (hc : G.Connected) (k sl : Nat) (hk : 4*sl+6≤k) (positive : 1≤sl)
    (cap : ∀ v,(EvenFrom G v).card≤k+sl+1)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → k+sl≤G.degree u ∨ k+sl≤G.degree v) :
    ∃ (u v : V) (q : G.Walk u v),q.IsPath ∧ ∀ z,z∈q.support := by
  classical
  apply Classical.byContradiction
  intro fail
  obtain ⟨a,b,p,hp⟩ := Rigidity.exists_longest hc
  have no : ∃ x,x∉p.support := Classical.byContradiction (fun h =>
    fail ⟨a,b,p,hp.1,fun z => Classical.byContradiction (fun e => h ⟨z,e⟩)⟩)
  obtain ⟨x,hx,xh,i,hi⟩ := scaled_deficit_has_high_active hc k sl (by omega) (by omega) cap conn deg hp no
  let d := k+sl
  let A := OmittedStar p x
  let B := External G A
  let P := PinVertices p x
  let C := B\P
  let H := Shell G x 3
  let W := Shell G x 4
  let U := (univ:Finset V)\(A∪B)
  have cap₂ (v : V) : (DistanceTwo G v).card≤d := distanceTwo_le_of_even d v (cap v)
  have pack := high_omitted_pin_budget hc d k cap conn hp hx (Graffiti189LongestPath.pin_data hi).2 xh
  have p3 : (Pins p x).card≤sl := by dsimp [d] at pack; omega
  have w3 : W.card≤sl := by change k+(Pins p x).card+W.card≤d at pack; dsimp [d] at pack; omega
  have rad (z : V) : G.dist x z≤4 := by
    by_contra! far
    have c := shell_card_of_far hc k conn (x:=x) (y:=z) (i:=4) (by decide) (by omega)
    change k≤W.card at c
    omega
  have height : k+1≤A.card := by
    have e := star_card_degree_and_pins hp hx
    change A.card+(Pins p x).card=G.degree x+1 at e
    omega
  have cc : C.card≤d := (card_le_card
    (Graffiti189LongestPath.OneSlack.boundary_except_pins_two hc hp hx)).trans (cap₂ x)
  have pp : P.card≤sl := by
    have e := Graffiti189LongestPath.OneSlack.card_pinVertices hp (x:=x)
    change P.card=(Pins p x).card at e
    omega
  have bc : C.card+P.card=B.card :=
    card_sdiff_add_card_eq_card (Graffiti189LongestPath.OneSlack.pin_vertices_subset_boundary hx)
  have bk : B.card≤k+(sl-1) := by
    have f := boundary_flank_count hc hp hx
    rw [flank_count_exact hp hx] at f
    have q := card_pos.mpr (Graffiti189LongestPath.OneSlack.first_pins_nonempty ⟨i,hi⟩)
    have c := cap₂ x
    change B.card+((Pins p x).card+(FirstPins p x).card)≤
      (DistanceTwo G x).card+(Pins p x).card at f
    dsimp [d] at c
    omega
  have floor (z : V) : 2≤G.degree z := by
    have ne : a≠x := fun e => hx (e ▸ p.start_mem_support)
    have n := enough_vertices_of_degree (k+sl) deg ne
    have kdeg := degree_floor_when_enough_vertices k conn (by omega) z
    omega
  have largeP := longest_length_ge_twice_of_not_traceable hc d (by omega) floor deg fail hp
  have far : k≤U.card := by
    have cover : p.support.toFinset⊆B∪U := by
      intro z hz
      by_cases zb : z∈B
      · exact mem_union.mpr (Or.inl zb)
      have za : z∉A := fun e => (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp e).1 (List.mem_toFinset.mp hz)
      exact mem_union.mpr (Or.inr (mem_sdiff.mpr ⟨mem_univ z,fun e => (mem_union.mp e).elim za zb⟩))
    have h := (card_le_card cover).trans (card_union_le B U)
    rw [List.toFinset_card_of_nodup hp.1.support_nodup,length_support] at h
    dsimp [d] at largeP
    omega
  have order := order_le_star_cut_two_three_four hc hx rad
  change Fintype.card V≤A.card+B.card+(DistanceTwo G x).card+H.card+W.card at order
  have base : Fintype.card V≤A.card+2*k+3*sl+H.card := by
    have cx := cap₂ x
    dsimp [d] at cx
    omega
  have bd : Fintype.card V<A.card+k+(k+1)*(A.card-sl-2) := by
    have shell := shell_bound_of_donor_pair_charging hc d sl cap₂ hp hx p3
    change 4*H.card≤(d+1)*(d+1)+4*(sl*d) at shell
    have numeric : 10*(sl*k)+5*(sl*sl)+6*k+18*sl+5<3*(k*k) := by
      let t := k-(4*sl+6)
      have kt : k=4*sl+6+t := by dsimp [t]; omega
      have id : 3*(k*k) = 10*(sl*k)+5*(sl*sl)+6*k+18*sl+5 +
          3*(sl*sl)+42*sl+67+(14*sl+30)*t+3*(t*t) := by
        rw [kt]
        ring
      omega
    have gap : 4*(2*k+3*sl)+(d+1)*(d+1)+4*(sl*d)
        <4*(k+(k+1)*(k-sl-1)) := by
      have a : 4*(2*k+3*sl)+(d+1)*(d+1)+4*(sl*d) =
          k*k+6*(sl*k)+5*(sl*sl)+10*k+14*sl+1 := by dsimp [d]; ring
      have l : (k+1)*(k-sl-1)+(k+1)*(sl+1)=(k+1)*k := by
        rw [←Nat.mul_add,show k-sl-1+(sl+1)=k by omega]
      have r : (k+1)*(sl+1)=sl*k+k+sl+1 := by ring
      have q : (k+1)*k=k*k+k := by ring
      rw [a,Nat.mul_add]
      omega
    have prod := Nat.mul_le_mul_left (k+1) (show k-sl-1≤A.card-sl-2 by omega)
    have gap' : 4*(2*k+3*sl)+4*H.card<4*(k+(k+1)*(k-sl-1)) :=
      (Nat.add_le_add_left shell _).trans_lt (by simpa only [Nat.add_assoc] using gap)
    have sp : 4*Fintype.card V<4*(A.card+k+(k+1)*(A.card-sl-2)) := by
      calc
        _ ≤ 4*(A.card+2*k+3*sl+H.card) := Nat.mul_le_mul_left 4 base
        _ = 4*A.card+(4*(2*k+3*sl)+4*H.card) := by ring
        _ < 4*A.card+4*(k+(k+1)*(k-sl-1)) := Nat.add_lt_add_left gap' _
        _ ≤ 4*A.card+4*(k+(k+1)*(A.card-sl-2)) :=
          Nat.add_le_add_left (Nat.mul_le_mul_left 4 (Nat.add_le_add_left prod _)) _
        _ = _ := by ring
    omega
  obtain ⟨z,c,cyc,cl⟩ := wide_ratio_root_deleted_long_cycle hc k sl hk positive cap conn hp hx bk far height deg
  have len : A.card-sl-3+1=A.card-sl-2 := by omega
  have lim : Fintype.card V<A.card+k+(k+1)*(A.card-sl-3+1) := by rwa [len]
  change 2*((A.card-sl-2)/2)≤c.length at cl
  exact wide_ratio_no_long_shore_cycle hc k sl hk positive cap conn hp hx bk far (show 6+4*sl<A.card by omega)
    (A.card-sl-3) (show k≤A.card by omega) lim ⟨z,c,cyc,by omega⟩

/-- Direct proportional statement: connectivity at least k with
5k≥4d+6 is enough at second-degree threshold d. -/
theorem traceable_of_eighty_percent_connectivity (hc : G.Connected) (d k : Nat)
    (ratio : 4*d+6≤5*k)
    (cap : ∀ v,(EvenFrom G v).card≤d+1)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → d≤G.degree u ∨ d≤G.degree v) :
    ∃ (u v : V) (q : G.Walk u v),q.IsPath ∧ ∀ z,z∈q.support := by
  by_cases hk : d≤k
  · exact traceable_of_even_and_connectivity hc d cap (fun S sc => conn S (sc.trans_le hk))
  have eq : k+(d-k)=d := by omega
  exact traceable_of_wide_ratio_connectivity hc k (d-k) (by omega) (by omega)
    (by simpa only [eq] using cap) conn (by simpa only [eq] using deg)

#print axioms traceable_of_wide_ratio_connectivity
#print axioms traceable_of_eighty_percent_connectivity
end Graffiti189LongestPath.WideRatioDeficit
