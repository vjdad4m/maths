import ScaledDeficitAll189
import Mathlib.Tactic.Linarith
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.OneSlack Graffiti189LongestPath.Rigidity Graffiti189LongestPath.DeficitThirdShell
open private Graffiti189LongestPath.mem_distanceTwo Graffiti189LongestPath.dist_two from SmallSeparator189
open private Graffiti189LongestPath.Rigidity.mem_external Graffiti189LongestPath.Rigidity.mem_omittedStar from Rigidity189
open private Graffiti189LongestPath.OneSlack.boundary_except_pins_two Graffiti189LongestPath.OneSlack.card_pinVertices from OneSlack189
set_option warningAsError true
set_option maxHeartbeats 6500000
namespace Graffiti189LongestPath.DonorQuadratic
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

omit [Fintype V] [DecidableRel G.Adj] in
/-- A minimum donor set has a distinct private gate for each donor. -/
theorem exists_private_donor_cover (A C : Finset V)
    (initial : ∀ b∈C,∃ a∈A,G.Adj a b) :
    ∃ D⊆A, (∀ b∈C,∃ a∈D,G.Adj a b) ∧
      (∀ a∈D,∃ b∈C,G.Adj a b ∧ ∀ u∈D,u≠a → ¬G.Adj u b) := by
  classical
  let isCover (D : Finset V) : Prop := ∀ b∈C,∃ a∈D,G.Adj a b
  letI decCover : DecidablePred isCover := fun _ => Classical.propDecidable _
  let F := A.powerset.filter isCover
  have fm (D : Finset V) : D∈F ↔ D⊆A ∧ isCover D := by simp [F]
  have ne : F.Nonempty := ⟨A,(fm A).mpr ⟨Subset.rfl,initial⟩⟩
  obtain ⟨D,dm,mn⟩ := exists_min_image F Finset.card ne
  obtain ⟨DA,cover⟩ := (fm D).mp dm
  refine ⟨D,DA,cover,?_⟩
  intro a ad
  apply Classical.byContradiction
  intro no
  have cc (b : V) (bc : b∈C) : ∃ u∈D.erase a,G.Adj u b := by
    obtain ⟨u,ud,edge⟩ := cover b bc
    by_cases ua : u=a
    · subst u
      apply Classical.byContradiction
      intro fail
      apply no
      refine ⟨b,bc,edge,?_⟩
      intro u ud na ed
      exact fail ⟨u,mem_erase.mpr ⟨na,ud⟩,ed⟩
    · exact ⟨u,mem_erase.mpr ⟨ua,ud⟩,edge⟩
  have sm : D.erase a∈F := (fm _).mpr ⟨(erase_subset _ _).trans DA,cc⟩
  have h := mn (D.erase a) sm
  have c := card_erase_add_one ad
  omega

/-- Every other selected donor pays a distinct parity slot: use its
private gate if adjacent, or the donor itself otherwise. -/
theorem shell_bound_of_donor_pair_charging (hc : G.Connected) (d sl : Nat)
    (cap : ∀ v,(DistanceTwo G v).card≤d)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
    (few : (Pins p x).card≤sl) :
    4*(Shell G x 3).card≤(d+1)*(d+1)+4*(sl*d) := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let P := PinVertices p x
  let C := B\P
  let H := Shell G x 3
  let HP := P.biUnion (fun t => H∩DistanceTwo G t)
  have cw : C⊆DistanceTwo G x := Graffiti189LongestPath.OneSlack.boundary_except_pins_two hc hp hx
  have ck : C.card≤d := (card_le_card cw).trans (cap x)
  have pk : P.card≤sl := by
    have e := Graffiti189LongestPath.OneSlack.card_pinVertices hp (x:=x)
    change P.card=(Pins p x).card at e
    omega
  have pk' : HP.card≤P.card*d := card_biUnion_le_card_mul P _ d
    (fun t _ => (card_le_card inter_subset_right).trans (cap t))
  have pins : HP.card≤sl*d := pk'.trans (Nat.mul_le_mul_right d pk)
  have initial (v : V) (vc : v∈C) : ∃ u∈A,G.Adj u v := by
    obtain ⟨_,u,ua,e⟩ := Graffiti189LongestPath.Rigidity.mem_external.mp (mem_sdiff.mp vc).1
    exact ⟨u,ua,e⟩
  obtain ⟨D,DA,DC,priv⟩ := exists_private_donor_cover A C initial
  have rep₀ (v : V) : ∃ b,v∈D → b∈C ∧ G.Adj v b ∧ ∀ u∈D,u≠v → ¬G.Adj u b := by
    by_cases vd : v∈D
    · obtain ⟨b,bc,e,safe⟩ := priv v vd
      exact ⟨b,fun _ => ⟨bc,e,safe⟩⟩
    · exact ⟨x,fun q => (vd q).elim⟩
  choose rep repP using rep₀
  have repInj : Set.InjOn rep (↑D : Set V) := by
    intro v vd w wd eq
    by_contra ne
    have e : G.Adj v (rep w) := eq ▸ (repP v vd).2.1
    exact (repP w wd).2.2 v vd ne e
  have rc : (D.image rep).card=D.card := card_image_of_injOn repInj
  have rsub : D.image rep⊆C := by
    intro z hz
    obtain ⟨v,vd,rfl⟩ := mem_image.mp hz
    exact (repP v vd).1
  have dm : D.card≤d := (rc ▸ card_le_card rsub).trans ck
  have choice₀ (v : V) : ∃ a,v∈C → a∈D ∧ G.Adj a v := by
    by_cases vc : v∈C
    · obtain ⟨a,ad,e⟩ := DC v vc
      exact ⟨a,fun _ => ⟨ad,e⟩⟩
    · exact ⟨x,fun q => (vc q).elim⟩
  choose f fp using choice₀
  have fA (v : V) (vc : v∈C) : f v∈A ∧ G.Adj (f v) v :=
    ⟨DA (fp v vc).1,(fp v vc).2⟩
  let HD := D.biUnion (gateThird G x C)
  have all : H⊆HD∪HP := by
    intro z hz
    have w := shell_three_donor_cover hc hp hx f fA hz
    change z∈(C.image f).biUnion (gateThird G x C)∪HP at w
    rcases mem_union.mp w with h|h
    · obtain ⟨v,vf,zv⟩ := mem_biUnion.mp h
      obtain ⟨u,uc,rfl⟩ := mem_image.mp vf
      exact mem_union.mpr (Or.inl (mem_biUnion.mpr ⟨f u,(fp u uc).1,zv⟩))
    · exact mem_union.mpr (Or.inr h)
  have noA {u : V} (uc : u∈C) : u∉A :=
    (Graffiti189LongestPath.Rigidity.mem_external.mp (mem_sdiff.mp uc).1).1
  have roots {u : V} (ua : u∈A) : u=x ∨ G.Adj x u :=
    (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp ua).2
  have near {u : V} (ua : u∈A) : G.dist x u≤1 := by
    rcases roots ua with rfl|e
    · rw [dist_self]; omega
    · rw [dist_eq_one_iff_adj.mpr e]
  let m := D.card
  let bound := d+1
  have diet (v : V) (vd : v∈D) : (gateThird G x C v).card≤bound-m := by
    let E := D.erase v
    let pay (u : V) := if G.Adj v u then rep u else u
    let W := E.image pay
    have pinj : Set.InjOn pay (↑E : Set V) := by
      intro u uE w wE eq
      have ud := (mem_erase.mp uE).2
      have wd := (mem_erase.mp wE).2
      by_cases vu : G.Adj v u <;> by_cases vw : G.Adj v w
      · exact repInj ud wd (by simpa [pay,vu,vw] using eq)
      · have e : rep u=w := by simpa [pay,vu,vw] using eq
        exact (noA (repP u ud).1 (e.symm ▸ DA wd)).elim
      · have e : u=rep w := by simpa [pay,vu,vw] using eq
        exact (noA (repP w wd).1 (e ▸ DA ud)).elim
      · simpa [pay,vu,vw] using eq
    have wc : W.card=E.card := card_image_of_injOn pinj
    have ec : E.card+1=m := card_erase_add_one vd
    have spend : W⊆DistanceTwo G v := by
      intro z hz
      obtain ⟨u,ue,rfl⟩ := mem_image.mp hz
      obtain ⟨uv,ud⟩ := mem_erase.mp ue
      by_cases ad : G.Adj v u
      · have gp := repP u ud
        have no := gp.2.2 v vd uv.symm
        have ne : v≠rep u := fun e => noA gp.1 (e ▸ DA vd)
        have c := Graffiti189LongestPath.mem_distanceTwo.mpr
          (Graffiti189LongestPath.dist_two hc ne no ad gp.2.1)
        simpa [pay,ad] using c
      · have nv : v≠x := by
          intro e
          subst v
          exact ad ((roots (DA ud)).resolve_left uv)
        have vx := (roots (DA vd)).resolve_left nv
        have nu : u≠x := by
          intro e
          subst u
          exact ad vx.symm
        have ux := (roots (DA ud)).resolve_left nu
        have c := Graffiti189LongestPath.mem_distanceTwo.mpr
          (Graffiti189LongestPath.dist_two hc uv.symm ad vx.symm ux)
        simpa [pay,ad] using c
    have dis : Disjoint W (gateThird G x C v) := disjoint_left.mpr (by
      intro z zw zh
      obtain ⟨u,ue,rfl⟩ := mem_image.mp zw
      have ud := (mem_erase.mp ue).2
      have high := mem_shell.mp (mem_gateThird.mp zh).1
      by_cases e : G.Adj v u
      · have dt := Graffiti189LongestPath.mem_distanceTwo.mp (cw (repP u ud).1)
        simp only [pay,if_pos e] at high
        omega
      · have l := near (DA ud)
        simp only [pay,if_neg e] at high
        omega)
    have c := card_le_card (union_subset spend (gate_third_subset hc (DA vd) C))
    rw [card_union_of_disjoint dis] at c
    have cb := cap v
    dsimp only [bound]
    omega
  have HDc : HD.card≤m*(bound-m) := card_biUnion_le_card_mul D _ (bound-m) diet
  have allc := (card_le_card all).trans (card_union_le HD HP)
  have a : H.card≤m*(bound-m)+sl*d := by omega
  have mm : m≤bound := by dsimp [m,bound]; omega
  let rem := bound-m
  have eq : m+rem=bound := by dsimp [rem]; omega
  have quad : 4*(m*rem)≤bound*bound := by
    have q : 4*(m*rem)≤(m+rem)*(m+rem) := by
      have w : 4*((m:ℤ)*(rem:ℤ))≤((m:ℤ)+(rem:ℤ))*((m:ℤ)+(rem:ℤ)) := by
        nlinarith [sq_nonneg ((m:ℤ)-(rem:ℤ))]
      exact_mod_cast w
    rwa [eq] at q
  have a' := Nat.mul_le_mul_left 4 a
  change 4*H.card≤4*(m*rem+sl*d) at a'
  rw [Nat.mul_add] at a'
  change 4*H.card≤bound*bound+4*(sl*d)
  omega

#print axioms exists_private_donor_cover
#print axioms shell_bound_of_donor_pair_charging
end Graffiti189LongestPath.DonorQuadratic
