import WideRatioShore189
import DonorQuadratic189
import Mathlib.Tactic.Ring
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack Graffiti189LongestPath.PinRun
open Graffiti189LongestPath.DeficitActive Graffiti189LongestPath.ScaledActive Graffiti189LongestPath.DeficitLongest
open Graffiti189LongestPath.WideRatioShore Graffiti189LongestPath.DeficitThirdShell
open Graffiti189LongestPath.DonorQuadratic Graffiti189LongestPath.ActiveStarHeight
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
open private Graffiti189LongestPath.pin_data from SmallSeparator189
open private Graffiti189LongestPath.OneSlack.boundary_except_pins_two Graffiti189LongestPath.OneSlack.card_pinVertices
  Graffiti189LongestPath.OneSlack.pin_vertices_subset_boundary Graffiti189LongestPath.OneSlack.first_pins_nonempty from OneSlack189
set_option warningAsError true
set_option maxHeartbeats 7000000
namespace Graffiti189LongestPath.WideRatioDeficit
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- #189 for every positive slack s=d−k with k ≥ 4s+6.
No normalized attachment or separator geometry is assumed. -/
theorem traceable_of_wide_ratio_connectivity (hc : G.Connected) (k sl : Nat) (hk : 4*sl+6≤k) (positive : 1≤sl)
    (cap : ∀ v,(EvenFrom G v).card≤k+sl+1)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → k+sl≤G.degree u ∨ k+sl≤G.degree v) :
    ∃ (u v : V) (q : G.Walk u v),q.IsPath ∧ ∀ z,z∈q.support := by
  classical
  apply Classical.byContradiction
  intro fail
  obtain ⟨a,b,p,hp⟩ := Rigidity.exists_longest hc
  have no : ∃ x,x∉p.support := Classical.byContradiction (fun h =>
    fail ⟨a,b,p,hp.1,fun z => Classical.byContradiction (fun e => h ⟨z,e⟩)⟩)
  obtain ⟨x,hx,xh,i,hi⟩ := scaled_deficit_has_high_active hc k sl (by omega) (by omega) cap conn deg hp no
  let d := k+sl
  let A := OmittedStar p x
  let B := External G A
  let P := PinVertices p x
  let C := B\P
  let H := Shell G x 3
  let W := Shell G x 4
  let U := (univ:Finset V)\(A∪B)
  have cap₂ (v : V) : (DistanceTwo G v).card≤d := distanceTwo_le_of_even d v (cap v)
  have pack := high_omitted_pin_budget hc d k cap conn hp hx (Graffiti189LongestPath.pin_data hi).2 xh
  have p3 : (Pins p x).card≤sl := by dsimp [d] at pack; omega
  have w3 : W.card≤sl := by change k+(Pins p x).card+W.card≤d at pack; dsimp [d] at pack; omega
  have rad (z : V) : G.dist x z≤4 := by
    by_contra! far
    have c := shell_card_of_far hc k conn (x:=x) (y:=z) (i:=4) (by decide) (by omega)
    change k≤W.card at c
    omega
  have height : k+1≤A.card := by
    have e := star_card_degree_and_pins hp hx
    change A.card+(Pins p x).card=G.degree x+1 at e
    omega
  have cc : C.card≤d := (card_le_card
    (Graffiti189LongestPath.OneSlack.boundary_except_pins_two hc hp hx)).trans (cap₂ x)
  have pp : P.card≤sl := by
    have e := Graffiti189LongestPath.OneSlack.card_pinVertices hp (x:=x)
    change P.card=(Pins p x).card at e
    omega
  have bc : C.card+P.card=B.card :=
    card_sdiff_add_card_eq_card (Graffiti189LongestPath.OneSlack.pin_vertices_subset_boundary hx)
  have bk : B.card≤k+(sl-1) := by
    have f := boundary_flank_count hc hp hx
    rw [flank_count_exact hp hx] at f
    have q := card_pos.mpr (Graffiti189LongestPath.OneSlack.first_pins_nonempty ⟨i,hi⟩)
    have c := cap₂ x
    change B.card+((Pins p x).card+(FirstPins p x).card)≤
      (DistanceTwo G x).card+(Pins p x).card at f
    dsimp [d] at c
    omega
  have floor (z : V) : 2≤G.degree z := by
    have ne : a≠x := fun e => hx (e ▸ p.start_mem_support)
    have n := enough_vertices_of_degree (k+sl) deg ne
    have kdeg := degree_floor_when_enough_vertices k conn (by omega) z
    omega
  have largeP := longest_length_ge_twice_of_not_traceable hc d (by omega) floor deg fail hp
  have far : k≤U.card := by
    have cover : p.support.toFinset⊆B∪U := by
      intro z hz
      by_cases zb : z∈B
      · exact mem_union.mpr (Or.inl zb)
      have za : z∉A := fun e => (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp e).1 (List.mem_toFinset.mp hz)
      exact mem_union.mpr (Or.inr (mem_sdiff.mpr ⟨mem_univ z,fun e => (mem_union.mp e).elim za zb⟩))
    have h := (card_le_card cover).trans (card_union_le B U)
    rw [List.toFinset_card_of_nodup hp.1.support_nodup,length_support] at h
    dsimp [d] at largeP
    omega
  have order := order_le_star_cut_two_three_four hc hx rad
  change Fintype.card V≤A.card+B.card+(DistanceTwo G x).card+H.card+W.card at order
  have base : Fintype.card V≤A.card+2*k+3*sl+H.card := by
    have cx := cap₂ x
    dsimp [d] at cx
    omega
  have bd : Fintype.card V<A.card+k+(k+1)*(A.card-sl-2) := by
    have shell := shell_bound_of_donor_pair_charging hc d sl cap₂ hp hx p3
    change 4*H.card≤(d+1)*(d+1)+4*(sl*d) at shell
    have numeric : 10*(sl*k)+5*(sl*sl)+6*k+18*sl+5<3*(k*k) := by
      let t := k-(4*sl+6)
      have kt : k=4*sl+6+t := by dsimp [t]; omega
      have id : 3*(k*k) = 10*(sl*k)+5*(sl*sl)+6*k+18*sl+5 +
          3*(sl*sl)+42*sl+67+(14*sl+30)*t+3*(t*t) := by
        rw [kt]
        ring
      omega
    have gap : 4*(2*k+3*sl)+(d+1)*(d+1)+4*(sl*d)
        <4*(k+(k+1)*(k-sl-1)) := by
      have a : 4*(2*k+3*sl)+(d+1)*(d+1)+4*(sl*d) =
          k*k+6*(sl*k)+5*(sl*sl)+10*k+14*sl+1 := by dsimp [d]; ring
      have l : (k+1)*(k-sl-1)+(k+1)*(sl+1)=(k+1)*k := by
        rw [←Nat.mul_add,show k-sl-1+(sl+1)=k by omega]
      have r : (k+1)*(sl+1)=sl*k+k+sl+1 := by ring
      have q : (k+1)*k=k*k+k := by ring
      rw [a,Nat.mul_add]
      omega
    have prod := Nat.mul_le_mul_left (k+1) (show k-sl-1≤A.card-sl-2 by omega)
    have gap' : 4*(2*k+3*sl)+4*H.card<4*(k+(k+1)*(k-sl-1)) :=
      (Nat.add_le_add_left shell _).trans_lt (by simpa only [Nat.add_assoc] using gap)
    have sp : 4*Fintype.card V<4*(A.card+k+(k+1)*(A.card-sl-2)) := by
      calc
        _ ≤ 4*(A.card+2*k+3*sl+H.card) := Nat.mul_le_mul_left 4 base
        _ = 4*A.card+(4*(2*k+3*sl)+4*H.card) := by ring
        _ < 4*A.card+4*(k+(k+1)*(k-sl-1)) := Nat.add_lt_add_left gap' _
        _ ≤ 4*A.card+4*(k+(k+1)*(A.card-sl-2)) :=
          Nat.add_le_add_left (Nat.mul_le_mul_left 4 (Nat.add_le_add_left prod _)) _
        _ = _ := by ring
    omega
  obtain ⟨z,c,cyc,cl⟩ := wide_ratio_root_deleted_long_cycle hc k sl hk positive cap conn hp hx bk far height deg
  have len : A.card-sl-3+1=A.card-sl-2 := by omega
  have lim : Fintype.card V<A.card+k+(k+1)*(A.card-sl-3+1) := by rwa [len]
  change 2*((A.card-sl-2)/2)≤c.length at cl
  exact wide_ratio_no_long_shore_cycle hc k sl hk positive cap conn hp hx bk far (show 6+4*sl<A.card by omega)
    (A.card-sl-3) (show k≤A.card by omega) lim ⟨z,c,cyc,by omega⟩

/-- Direct proportional statement: connectivity at least k with
5k≥4d+6 is enough at second-degree threshold d. -/
theorem traceable_of_eighty_percent_connectivity (hc : G.Connected) (d k : Nat)
    (ratio : 4*d+6≤5*k)
    (cap : ∀ v,(EvenFrom G v).card≤d+1)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → d≤G.degree u ∨ d≤G.degree v) :
    ∃ (u v : V) (q : G.Walk u v),q.IsPath ∧ ∀ z,z∈q.support := by
  by_cases hk : d≤k
  · exact traceable_of_even_and_connectivity hc d cap (fun S sc => conn S (sc.trans_le hk))
  have eq : k+(d-k)=d := by omega
  exact traceable_of_wide_ratio_connectivity hc k (d-k) (by omega) (by omega)
    (by simpa only [eq] using cap) conn (by simpa only [eq] using deg)

#print axioms traceable_of_wide_ratio_connectivity
#print axioms traceable_of_eighty_percent_connectivity
end Graffiti189LongestPath.WideRatioDeficit
