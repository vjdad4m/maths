#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")" && pwd)
obj=$(mktemp -d)
trap 'rm -rf "$obj"' EXIT
echo '== WideRatioDeficitAll189 =='
lean -j1 -DElab.async=false -DwarningAsError=true --root="$root" \
  -o "$obj/WideRatioDeficitAll189.olean" "$root/WideRatioDeficitAll189.lean"
