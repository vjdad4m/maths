import FourSeventhsCombined189
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import StrongDonorDegree189
import FlexibleShellArithmetic189
import FlexSplitShell189
import ThreeFifthsDeficit189


/- source: FiveNinthsReserve189 -/

namespace Graffiti189LongestPath.FiveNinthsReserve

theorem individual_missed_port_shell_bound
    (a b c e h k s p t jC jE qC qE f : ℤ)
    (an : 0≤a) (bn : 0≤b) (tn : 0≤t) (tp : t≤p) (ps : p≤s)
    (sn : s≤k) (fu : f≤k) (don : a+b+t≤k+s)
    (jnC : 0≤jC) (jnE : 0≤jE)
    (reachC : a+p+qC≤c+3) (reachE : b+p+qE≤e+3)
    (missC : qC+p≤s+3) (missE : qE+p≤s+3) (missing : k≤f+qC+qE)
    (mass : h+a*a+b*b+(a+b)*(p+t)+t*t+(a*e+b*c+a*jC+b*jE)
      ≤ (k+s+2)*(a+b)+(k+s+1)*t+2*(k+s)) :
    4*(h-10*(k+s))≤(max 0 (2*s-4*p+f))^2+4*p*(k+s-p) := by
  have c0 : a+k-s+2*p-f-6≤c := by omega
  have e0 : b+k-s+2*p-f-6≤e := by omega
  let u := a+b
  let d := k+s
  have raw : h-10*d≤u*(2*s-3*p-t+f)-u^2+t*(d-t) := by
    have cterm := mul_nonneg bn (show 0≤c-(a+k-s+2*p-f-6) by omega)
    have eterm := mul_nonneg an (show 0≤e-(b+k-s+2*p-f-6) by omega)
    have jc := mul_nonneg an jnC
    have je := mul_nonneg bn jnE
    have slack : 8*(a+b)+t+2*(k+s)≤10*(k+s) := by omega
    dsimp [u,d]
    nlinarith only [mass,cterm,eterm,jc,je,slack]
  let q := max 0 (2*s-4*p+f)
  let r := max 0 (2*s-3*p-t+f)
  have qr : q≤r := max_le_max_left 0 (by omega)
  have q0 : 0≤q := le_max_left _ _
  have r0 : 0≤r := le_max_left _ _
  have rq : r≤q+(p-t) := by
    have e : 2*s-4*p+f≤q := le_max_right _ _
    apply max_le
    · omega
    · omega
  have est : 4*(h-10*d)≤r^2+4*t*(d-t) := by
    have e : 2*s-3*p-t+f≤r := le_max_right _ _
    have a0 : 0≤u := add_nonneg an bn
    nlinarith only [raw, sq_nonneg (2*u-r), mul_nonneg a0 (show 0≤r-(2*s-3*p-t+f) by omega)]
  have qs : r^2≤(q+(p-t))^2 := by
    nlinarith only [mul_nonneg (show 0≤q+(p-t)-r by omega) (show 0≤q+(p-t)+r by omega)]
  have bound : 2*q+p-t≤4*(d-p-t) := by
    by_cases hq : 0≤2*s-4*p+f
    · dsimp [q,d]
      rw [max_eq_right hq]
      omega
    · dsimp [q,d]
      rw [max_eq_left (by omega : 2*s-4*p+f≤0)]
      omega
  have gain := mul_nonneg (show 0≤p-t by omega) (show 0≤4*(d-p-t)-(2*q+p-t) by omega)
  change 4*(h-10*d)≤q^2+4*p*(d-p)
  nlinarith only [est,qs,gain]

#print axioms individual_missed_port_shell_bound
end Graffiti189LongestPath.FiveNinthsReserve

/- source: FiveNinthsOneNumeric189 -/

namespace Graffiti189LongestPath.FiveNinthsOneNumeric

theorem one_side_contradiction
    (k s p c m f h : ℤ) (hk : 100000≤k) (hsL : 2*k≤3*s) (hsU : 5*s≤4*k)
    (hcL : k-3≤2*c) (hcU : 5*c≤4*k)
    (hmL : k-3≤2*m) (hmU : 2*m≤k)
    (hf0 : 0≤f) (hfU : f≤k) (hf : k-s-c+2*p-6≤f)
    (hflex : (k+1)*(m+1)+f*(m-2)≤h+2*s+2*(m-2))
    (hcap : 4*h≤(k+s+2-c)^2+4*c*p+8*(k+s)) : False := by
  have low : k^2-1+f*(k-7)≤2*h+4*s+2*k := by
    nlinarith only [hflex, hmU,
      mul_nonneg (show 0≤k+1 by omega) (show 0≤2*m-k+3 by omega),
      mul_nonneg hf0 (show 0≤2*m-k+3 by omega)]
  have pterm : 4*c*p≤2*c*(f+s+c-k+6) := by
    nlinarith only [mul_nonneg (show 0≤c by omega) (show 0≤f+s+c-k+6-2*p by omega)]
  have flow : 5*c*f≤4*k*f := by
    nlinarith only [mul_nonneg hf0 (show 0≤4*k-5*c by omega)]
  have cs : 5*c*s≤4*k*c := by
    nlinarith only [mul_nonneg (show 0≤c by omega) (show 0≤4*k-5*s by omega)]
  have square0 : 25*(k+s+2-c)^2≤(9*k+10-5*c)^2 := by
    nlinarith only [mul_nonneg (show 0≤4*k-5*s by omega)
      (show 0≤14*k+5*s+20-10*c by omega)]
  have quad : 324*k^2-400*k*c+300*c^2≤199*k^2+375*k-450*c := by
    nlinarith only [mul_nonneg (show 0≤2*c-k+3 by omega)
      (show 0≤5*k-6*c by omega)]
  have kf : 0≤k*f := mul_nonneg (by omega) hf0
  have margin := mul_nonneg (show 0≤k by omega) (show 0≤k-100000 by omega)
  nlinarith only [low,pterm,flow,cs,square0,quad,kf,margin,hk,hfU,hcU,hcL,hcap,hsU]

#print axioms one_side_contradiction
end Graffiti189LongestPath.FiveNinthsOneNumeric

/- source: FiveNinthsMixedNumeric189 -/

namespace Graffiti189LongestPath.FiveNinthsMixedNumeric

theorem spacing_lower (k s m f h : ℤ) (hk : 1≤k) (hs : 5*s≤4*k)
    (hmL : k-3≤2*m) (hmU : 2*m≤k) (hf0 : 0≤f) (hfU : f≤k)
    (hflex : (k+1)*(m+1)+f*(m-2)≤h+2*s+2*(m-2)) :
    k^2+k*f-14*k≤2*h := by
  nlinarith only [hflex,hk,hs,hmU,hfU,
    mul_nonneg (show 0≤k+1 by omega) (show 0≤2*m-k+3 by omega),
    mul_nonneg hf0 (show 0≤2*m-k+3 by omega)]

theorem mixed_contradiction (k s p t f h : ℤ) (hk : 100000≤k)
    (hsL : 2*k≤3*s) (hsU : 5*s≤4*k)
    (hp : 0≤p) (hpU : p≤s) (ht : 0≤t) (tp : t≤p)
    (hf : 0≤f) (_hfU : f≤k) (flow : 10*p-3*k-30≤5*f)
    (lower : k^2+k*f-14*k≤2*h)
    (ordinary : 6*(h-7*(k+s))≤(k+s)^2+3*p^2)
    (exclusive : 224*(h-7*(k+s))≤(8*(k+s-2*p-t)-6*(k-f))^2+28*(k-f)^2+224*t*(k+s-t))
    (individual : 4*(h-10*(k+s))≤(max 0 (2*s-4*p+f))^2+4*p*(k+s-p)) :
    False := by
  have ks := mul_nonneg (show 0≤k by omega) (show 0≤k-100000 by omega)
  have kf : 0≤k*f := mul_nonneg (by omega) hf
  have db : 25*(k+s)^2≤81*k^2 := by
    nlinarith only [mul_nonneg (show 0≤4*k-5*s by omega) (show 0≤14*k+5*s by omega)]
  have flex := mul_nonneg (show 0≤k by omega) (show 0≤5*f-10*p+3*k+30 by omega)
  by_cases small : 40*p≤7*k
  · by_cases fbig : k≤8*f
    · have pp : 1600*p^2≤49*k^2 := by
        nlinarith only [mul_nonneg (show 0≤7*k-40*p by omega) (show 0≤7*k+40*p by omega)]
      have ff := mul_nonneg (show 0≤k by omega) (show 0≤8*f-k by omega)
      nlinarith only [lower,ordinary,pp,ff,ks,db,hsU,hk]
    · let z := 8*(k+s-2*p-t)-6*(k-f)
      let w := 42*k+30*f-120*t
      have bs : 25*z^2≤w^2 := by
        have z0 : 0≤z := by dsimp [z]; omega
        have zs : 5*z≤w := by dsimp [z,w]; omega
        nlinarith only [mul_nonneg (show 0≤w-5*z by omega) (show 0≤w+5*z by omega)]
      have fs : (k-f)^2≤k^2 := by
        nlinarith only [mul_nonneg hf (show 0≤2*k-f by omega)]
      have ts : 5*t*(k+s)≤9*k*t := by
        nlinarith only [mul_nonneg ht (show 0≤4*k-5*s by omega)]
      have tt : 1600*t^2≤49*k^2 := by
        nlinarith only [mul_nonneg (show 0≤7*k-40*t by omega) (show 0≤7*k+40*t by omega)]
      have ff : 8*f^2≤k*f := by
        nlinarith only [mul_nonneg hf (show 0≤k-8*f by omega)]
      have ft : 0≤f*t := mul_nonneg hf ht
      change 224*(h-7*(k+s))≤z^2+28*(k-f)^2+224*t*(k+s-t) at exclusive
      dsimp [w] at bs
      nlinarith only [exclusive,bs,fs,ts,tt,ff,ft,lower,ks,kf,hk,hsU]
  · by_cases high : 9*k≤20*p
    · have pp : 21*k^2≤2400*k*p-1200*p^2-816*k^2 := by
        nlinarith only [mul_nonneg (show 0≤20*p-9*k by omega) (show 0≤31*k-20*p by omega)]
      nlinarith only [lower,ordinary,pp,flex,db,ks,hk,hsU]
    · by_cases fbig : 3*k≤10*f
      · have pp : 400*p^2≤81*k^2 := by
          nlinarith only [mul_nonneg (show 0≤9*k-20*p by omega) (show 0≤9*k+20*p by omega)]
        have ff := mul_nonneg (show 0≤k by omega) (show 0≤10*f-3*k by omega)
        nlinarith only [lower,ordinary,pp,ff,db,ks,hk,hsU]
      · let q := max 0 (2*s-4*p+f)
        let v := 8*k-20*p+5*f
        have q0 : 0≤q := le_max_left _ _
        have vf : 0≤v := by dsimp [v]; omega
        have qv : 5*q≤v := by
          by_cases hh : 0≤2*s-4*p+f
          · dsimp [q,v]; rw [max_eq_right hh]; omega
          · dsimp [q,v]; rw [max_eq_left (by omega : 2*s-4*p+f≤0)]; omega
        have qsq : 25*q^2≤v^2 := by
          nlinarith only [mul_nonneg (show 0≤v-5*q by omega) (show 0≤v+5*q by omega)]
        have pt : 5*p*(k+s)≤9*k*p := by
          nlinarith only [mul_nonneg hp (show 0≤4*k-5*s by omega)]
        have ff : 10*f^2≤3*k*f := by
          nlinarith only [mul_nonneg hf (show 0≤3*k-10*f by omega)]
        change 4*(h-10*(k+s))≤q^2+4*p*(k+s-p) at individual
        dsimp [v] at qsq
        have upper :
            200*h≤128*k^2-280*k*p+600*p^2+(175*k-400*p)*f+2000*(k+s) := by
          nlinarith only [individual,qsq,pt,ff]
        -- Subtract 100 times the spacing lower bound: the residual
        -- coefficient of f is 75k−400p.
        by_cases sign : 0≤75*k-400*p
        · have bound := mul_nonneg sign (show 0≤3*k-10*f by omega)
          have pp : 160*(300*p^2-200*k*p)+4130*k^2≤0 := by
            nlinarith only [mul_nonneg (show 0≤40*p-7*k by omega)
              (show 0≤590*k-1200*p by omega)]
          nlinarith only [upper,lower,bound,pp,ks,hk,hsU]
        · by_cases med : 10*p≤3*k
          · have bound := mul_nonneg hf (show 0≤400*p-75*k by omega)
            have pp : 14*k^2-140*k*p+300*p^2≤-k^2 := by
              nlinarith only [mul_nonneg (show 0≤3*k-10*p by omega)
                (show 0≤30*p-5*k by omega)]
            nlinarith only [upper,lower,bound,pp,ks,hk,hsU]
          · have bound := mul_nonneg (show 0≤400*p-75*k by omega)
              (show 0≤5*f-10*p+3*k+30 by omega)
            have pp : -17*k^2+110*k*p-200*p^2≤-2*k^2 := by
              nlinarith only [mul_nonneg (show 0≤10*p-3*k by omega)
                (show 0≤20*p-5*k by omega)]
            nlinarith only [upper,lower,bound,pp,ks,hk,hsU,high]

#print axioms mixed_contradiction
end Graffiti189LongestPath.FiveNinthsMixedNumeric

/- source: SmallShoreNumeric189 -/

namespace Graffiti189LongestPath.SmallShoreNumeric

/-- The two-small-shore regime's strengthened Ore spacing beats the
complementary donor shell upper bound. Constants leave ample room for
the bounded cut, parity overlap and finite normalization losses. -/
theorem two_small_contradiction (k d c e u f p h : ℤ)
    (hk : 1000000≤k) (hd : 5*k≤3*d)
    (cFloor : k-3≤2*c) (ce : c≤e) (eTop : e≤k)
    (highShore : d≤c+e+p+6)
    (un : 0≤u) (fn : 0≤f) (pn : 0≤p) (pTop : p≤k)
    (donor : u+2*p≤c+f+10)
    (mass : 2*h≤2*u*(e-p)-u^2+2*p*(2*k-p)+100*k)
    (spacing : k*c+e*f-100*k≤h) : False := by
  let T := u+2*p
  let L := 2*u*p+u^2+2*p^2
  have l0 : 0≤L := by
    dsimp [L]
    nlinarith only [sq_nonneg u,sq_nonneg p,mul_nonneg un pn]
  have ls : T^2≤2*L := by
    dsimp [T,L]
    nlinarith only [sq_nonneg u]
  have et := mul_nonneg fn (show 0≤e by omega)
  have margin := mul_nonneg (show 0≤k by omega) (show 0≤k-1000000 by omega)
  by_cases low : T≤c
  · have mul0 := mul_nonneg un (show 0≤k-e by omega)
    have top : 2*h≤2*k*T-L+100*k := by
      dsimp [T,L]
      nlinarith only [mass,mul0]
    by_cases small : 4*T≤k
    · have sz := mul_nonneg (show 0≤k by omega) (show 0≤k-4*T by omega)
      have cc := mul_nonneg (show 0≤k by omega) (show 0≤2*c-k+3 by omega)
      nlinarith only [top,spacing,sz,cc,et,margin,hk,l0]
    · have t2 : k^2≤16*T^2 := by
        nlinarith only [mul_nonneg (show 0≤4*T-k by omega) (show 0≤4*T+k by omega)]
      have d0 := mul_nonneg (show 0≤k by omega) (show 0≤c-T by omega)
      nlinarith only [top,spacing,d0,t2,ls,et,margin,hk]
  · have ed : e*(T-c-10)≤e*f := by
      have z : 0≤f-(T-c-10) := by dsimp [T]; omega
      nlinarith only [mul_nonneg (show 0≤e by omega) z]
    have top : 2*h-2*(k*c+e*f)≤2*(k-e)*(2*p-c)-L+120*k := by
      dsimp [T,L] at ed ⊢
      nlinarith only [mass,ed,eTop]
    by_cases psmall : 2*p≤c
    · have pr := mul_nonneg (show 0≤k-e by omega) (show 0≤c-2*p by omega)
      have t2 : (k-3)^2≤4*T^2 := by
        nlinarith only [mul_nonneg (show 0≤2*T-k+3 by omega) (show 0≤2*T+k-3 by omega)]
      nlinarith only [top,spacing,pr,t2,ls,margin,hk]
    · have lp : 2*p^2≤L := by
        dsimp [L]
        nlinarith only [sq_nonneg u,mul_nonneg un pn]
      by_cases wide : 11*k≤20*e
      · have pr := mul_nonneg (show 0≤20*e-11*k by omega) (show 0≤2*p-c by omega)
        have cc := mul_nonneg (show 0≤k by omega) (show 0≤2*c-k+3 by omega)
        have quad := sq_nonneg (20*p-9*k)
        nlinarith only [top,spacing,lp,pr,cc,quad,margin,hk]
      · have near : 14*k≤25*p := by omega
        have pr := mul_nonneg (show 0≤2*e-k+3 by omega) (show 0≤2*p-c by omega)
        have cc := mul_nonneg (show 0≤k by omega) (show 0≤2*c-k+3 by omega)
        have quad : 9*k^2≤25^2*(2*p-k)^2 := by
          nlinarith only [mul_nonneg (show 0≤50*p-28*k by omega) (show 0≤50*p-22*k by omega)]
        have cl : 0≤c := by omega
        nlinarith only [top,spacing,lp,pr,cc,quad,margin,hk,pTop,cl]

#print axioms two_small_contradiction
end Graffiti189LongestPath.SmallShoreNumeric

/- source: ThreeShoreMass189 -/

namespace Graffiti189LongestPath.ThreeShoreMass

/-- For three disjoint donor sides, the worst size distribution at
fixed total and common size floor has all excess in one side. -/
theorem three_shore_shell_cap
    (k ell p t h m c₁ c₂ c₃ a₁ a₂ a₃ H : ℤ)
    (hk : 1000000≤k) (p0 : 0≤p) (tk : 0≤t) (tp : t≤p) (el : ell+p≤k)
    (hL : k+ell≤h) (hU : h≤3*ell+20)
    (mL : h-ell-8≤2*m) (mU : 2*m≤h-ell)
    (c : c₁+c₂+c₃≤h) (c₁m : m≤c₁) (c₂m : m≤c₂) (c₃m : m≤c₃)
    (a₁n : 0≤a₁) (a₂n : 0≤a₂) (a₃n : 0≤a₃)
    (raw : H≤t*(2*k-t)+
      a₁*(k+ell-h+c₁-t-a₁)+a₂*(k+ell-h+c₂-t-a₂)+
      a₃*(k+ell-h+c₃-t-a₃)+16*k) :
    8*H≤2*(k-p-t)^2+(k-2*t)^2+8*t*(2*k-t)+500*k := by
  let x := k+ell-h-t+m+14
  let y₁ := c₁-m
  let y₂ := c₂-m
  let y₃ := c₃-m
  let Y := h-3*m
  have x0 : 0≤x := by dsimp [x]; omega
  have y₁0 : 0≤y₁ := by dsimp [y₁]; omega
  have y₂0 : 0≤y₂ := by dsimp [y₂]; omega
  have y₃0 : 0≤y₃ := by dsimp [y₃]; omega
  have y : y₁+y₂+y₃≤Y := by dsimp [y₁,y₂,y₃,Y]; omega
  have Y0 : 0≤Y := by omega
  have mass : 4*H≤4*t*(2*k-t)+(x+y₁)^2+(x+y₂)^2+(x+y₃)^2+64*k := by
    have s₁ := sq_nonneg (2*a₁-x-y₁)
    have s₂ := sq_nonneg (2*a₂-x-y₂)
    have s₃ := sq_nonneg (2*a₃-x-y₃)
    dsimp [x,y₁,y₂,y₃] at s₁ s₂ s₃ ⊢
    nlinarith only [raw,s₁,s₂,s₃,a₁n,a₂n,a₃n]
  have moment : (x+y₁)^2+(x+y₂)^2+(x+y₃)^2≤(x+Y)^2+2*x^2 := by
    nlinarith only [mul_nonneg (show 0≤Y-y₁-y₂-y₃ by omega)
      (show 0≤2*x+Y+y₁+y₂+y₃ by omega),
      mul_nonneg y₁0 y₂0,mul_nonneg y₁0 y₃0,mul_nonneg y₂0 y₃0]
  have big : x+Y≤k-p-t+22 := by dsimp [x,Y]; omega
  have small : 2*x≤k-2*t+28 := by dsimp [x]; omega
  have q1 : (x+Y)^2≤(k-p-t+22)^2 := by
    nlinarith only [mul_nonneg (show 0≤k-p-t+22-(x+Y) by omega)
      (show 0≤k-p-t+22+(x+Y) by omega)]
  have q2 : 4*x^2≤(k-2*t+28)^2 := by
    nlinarith only [mul_nonneg (show 0≤k-2*t+28-2*x by omega)
      (show 0≤k-2*t+28+2*x by omega)]
  nlinarith only [mass,moment,q1,q2,p0,tk,hk]

#print axioms three_shore_shell_cap
end Graffiti189LongestPath.ThreeShoreMass

/- source: ThreeShoreNumeric189 -/

namespace Graffiti189LongestPath.ThreeShoreNumeric

/-- Three mutually nonadjacent split shores cannot attain the shell
mass demanded by their two-color-compatible hooks. The graph-side
estimates have already absorbed bounded additive normalization losses. -/
theorem three_side_contradiction (k ell p t h m f H : ℤ)
    (hk : 1000000≤k) (p0 : 0≤p) (pK : p≤k) (_t0 : 0≤t) (tp : t≤p)
    (el : ell+p≤k) (hL : k+ell≤h) (hU : h≤3*ell+20) (h0 : 0≤h)
    (mL : h-ell-8≤2*m) (f0 : 0≤f) (fL : 2*k-h+3*p-18≤2*f)
    (space : m*(k+f)-100*k≤H)
    (shell : 8*H≤2*(k-p-t)^2+(k-2*t)^2+8*t*(2*k-t)+500*k) : False := by
  have rise := mul_nonneg (show 0≤p-t by omega) (show 0≤8*k+2*p-2*t by omega)
  have upper : 8*H≤3*k^2+4*k*p+4*p^2+500*k := by
    nlinarith only [shell,rise]
  have margin := mul_nonneg (show 0≤k by omega) (show 0≤k-1000000 by omega)
  by_cases small : 6*p≤k
  · have kp := mul_nonneg (show 0≤k by omega) (show 0≤k-6*p by omega)
    have pp : 36*p^2≤k^2 := by
      nlinarith only [mul_nonneg (show 0≤k-6*p by omega) (show 0≤k+6*p by omega)]
    have m0 : 0≤m := by omega
    have a := mul_nonneg m0 f0
    have b := mul_nonneg (show 0≤k by omega) (show 0≤2*m-k+8 by omega)
    nlinarith only [upper,space,kp,pp,a,b,margin,hk]
  · have z0 : 0≤h-ell-8 := by omega
    have n := mul_nonneg z0 (show 0≤2*f+2*k-(4*k-h+3*p-18) by omega)
    have u := mul_nonneg (show 0≤2*m-(h-ell-8) by omega) (show 0≤2*f+2*k by omega)
    have prod : (h-ell-8)*(4*k-h+3*p-18)≤4*m*(k+f) := by
      nlinarith only [n,u]
    have diff := mul_nonneg (show 0≤h-k-ell by omega) (show 0≤3*k+3*p-h by omega)
    have ed := mul_nonneg (show 0≤k by omega) (show 0≤k-ell-p by omega)
    have pq := mul_nonneg p0 (show 0≤k-p by omega)
    nlinarith only [upper,space,prod,diff,ed,pq,margin,hk,hU,el,h0,pK,p0]

#print axioms three_side_contradiction
end Graffiti189LongestPath.ThreeShoreNumeric
/- source: FiveNinthsShell189 -/

open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack Graffiti189LongestPath.PinRun
open Graffiti189LongestPath.ShellDonorFull Graffiti189LongestPath.StrongDonorDegree
open Graffiti189LongestPath.StrongDonorCharge Graffiti189LongestPath.MixedReserve
open Graffiti189LongestPath.FlexibleShellArithmetic
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
open private Graffiti189LongestPath.pin_data Graffiti189LongestPath.mem_distanceTwo from SmallSeparator189
open private Graffiti189LongestPath.OneSlack.card_pinVertices from OneSlack189
open private Graffiti189LongestPath.FlexSplitShell.count_group from FlexSplitShell189
set_option maxHeartbeats 9000000

namespace Graffiti189LongestPath.FiveNinthsShell

variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]
variable {a b x : V} {p : G.Walk a b}

/-- The old third-shell dichotomy, with the stronger pin and missed-port
charges in the case where both split sides have high donors. -/
theorem stronger_split_shell_three (hc : G.Connected) (d k s f mF : Nat)
    (dEq : d=k+s) (sk : s≤k) (fk : f≤k)
    (hp : IsLongest p) (hx : x∉p.support)
    (gap : (Pins p x).card≤(FirstPins p x).card+1)
    (cap : ∀ v,(DistanceTwo G v).card≤d) (C E W X : Finset V)
    (shore : OmittedStar p x=C∪E∪X)
    (partition : C∪E∪(PinVertices p x)∪W=G.neighborFinset x)
    (deg : ∀ u v : V,u≠v → d≤G.degree u ∨ d≤G.degree v)
    (ce : Disjoint C E) (dcx : Disjoint C X) (dex : Disjoint E X)
    (cp : Disjoint C (PinVertices p x)) (ep : Disjoint E (PinVertices p x))
    (no : ∀ u∈C,∀ v∈E,¬G.Adj u v)
    (cs : mF≤C.card) (es : mF≤E.card) (md : mF≤d+2)
    (ws : W.card≤1) (xs : X.card≤2) (xx : x∈X)
    (bk : (External G (OmittedStar p x)).card+(Pins p x).card≤d+1)
    (ps : (Pins p x).card≤s)
    (mcs : ((External G (OmittedStar p x)).filter (fun z => ¬∃ u∈C,G.Adj u z)).card+(Pins p x).card≤s+3)
    (mes : ((External G (OmittedStar p x)).filter (fun z => ¬∃ u∈E,G.Adj u z)).card+(Pins p x).card≤s+3)
    (reaches : k≤f+
      ((External G (OmittedStar p x)).filter (fun z => ¬∃ u∈C,G.Adj u z)).card+
      ((External G (OmittedStar p x)).filter (fun z => ¬∃ u∈E,G.Adj u z)).card) :
    let h := (Shell G x 3).card
    let pp := (Pins p x).card
    (4*h≤(d+2-mF)*(d+2-mF)+4*(mF*pp)+8*d) ∨
      ∃ t : Nat, t≤pp ∧
        (6*((h:ℤ)-7*(d:ℤ))≤(d:ℤ)^2+3*(pp:ℤ)^2) ∧
        (6*((h:ℤ)-7*(d:ℤ))≤(d:ℤ)^2-2*(d:ℤ)*(pp:ℤ)+13*(pp:ℤ)^2) ∧
        (224*((h:ℤ)-7*(d:ℤ))≤(8*((d:ℤ)-2*(pp:ℤ)-(t:ℤ))-6*((k:ℤ)-(f:ℤ)))^2+
          28*((k:ℤ)-(f:ℤ))^2+224*(t:ℤ)*((d:ℤ)-(t:ℤ))) ∧
        (4*((h:ℤ)-10*(d:ℤ))≤(max 0 (2*(s:ℤ)-4*(pp:ℤ)+(f:ℤ)))^2+4*(pp:ℤ)*((d:ℤ)-(pp:ℤ))) := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let P := PinVertices p x
  let pp := (Pins p x).card
  let H := Shell G x 3
  let F := gateThird G x (DistanceTwo G x)
  obtain ⟨D,DA,cover,privateGate,every⟩ := exists_shell_donors_with_private_charges hc d cap x
  let C' := (D∩C).filter (fun v => d≤G.degree v)
  let E' := (D∩E).filter (fun v => d≤G.degree v)
  let P' := D∩P
  let D₀ := C'∪E'
  let R := D\(D₀∪P')
  let nC := C'.card
  let nE := E'.card
  let t := P'.card
  let jC := nC+nE+2*pp-(C.card+3)
  let jE := nC+nE+2*pp-(E.card+3)
  let mC := (B.filter (fun z => ¬∃ u∈C,G.Adj u z)).card
  let mE := (B.filter (fun z => ¬∃ u∈E,G.Adj u z)).card
  have cD (z : V) (hz : z∈C') : z∈D ∧ z∈C ∧ d≤G.degree z := by
    obtain ⟨both,high⟩ := mem_filter.mp hz
    obtain ⟨hD,hC⟩ := mem_inter.mp both
    exact ⟨hD,hC,high⟩
  have eD (z : V) (hz : z∈E') : z∈D ∧ z∈E ∧ d≤G.degree z := by
    obtain ⟨both,high⟩ := mem_filter.mp hz
    obtain ⟨hD,hE⟩ := mem_inter.mp both
    exact ⟨hD,hE,high⟩
  have cc' : C'⊆C := fun z h => (cD z h).2.1
  have ee' : E'⊆E := fun z h => (eD z h).2.1
  have cA : C⊆A := by
    intro u h
    change u∈OmittedStar p x
    rw [shore]
    exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inl h)))
  have eA : E⊆A := by
    intro u h
    change u∈OmittedStar p x
    rw [shore]
    exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inr h)))
  have dA : D₀⊆A := union_subset (cc'.trans cA) (ee'.trans eA)
  have dD : D₀⊆D := union_subset (fun z h => (cD z h).1) (fun z h => (eD z h).1)
  have ce' : Disjoint C' E' := disjoint_left.mpr (fun _ u v => disjoint_left.mp ce (cc' u) (ee' v))
  have cardD₀ : D₀.card=nC+nE := card_union_of_disjoint ce'
  have xD₀ : x∉D₀ := fun h => (mem_union.mp h).elim
    (fun e => disjoint_left.mp dcx (cc' e) xx) (fun e => disjoint_left.mp dex (ee' e) xx)
  have dP' : Disjoint D₀ P' := disjoint_left.mpr (fun _ dz pz => (mem_union.mp dz).elim
    (fun q => disjoint_left.mp cp (cc' q) (mem_inter.mp pz).2)
    (fun q => disjoint_left.mp ep (ee' q) (mem_inter.mp pz).2))
  have dsub : D₀∪P'⊆D := union_subset dD inter_subset_left
  have cardD := card_sdiff_add_card_eq_card dsub
  rw [card_union_of_disjoint dP',cardD₀] at cardD
  change R.card+(nC+nE+t)=D.card at cardD
  have tn : t≤pp := (card_le_card (inter_subset_right : P'⊆P)).trans
    (le_of_eq (Graffiti189LongestPath.OneSlack.card_pinVertices hp (x:=x)))
  have closed (u : V) (ua : u∈A) (z : V) (za : z∉A) (uz : G.Adj u z) : z∈B :=
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨za,u,ua,uz⟩
  have rep₀ (u : V) : ∃ g,u∈D → g∈DistanceTwo G x ∧ G.Adj u g ∧
      ∀ w∈D,w≠u → ¬G.Adj w g := by
    by_cases h : u∈D
    · obtain ⟨g,gg,ug,bad⟩ := privateGate u h
      exact ⟨g,fun _ => ⟨gg,ug,bad⟩⟩
    · exact ⟨x,fun e => (h e).elim⟩
  choose rep priv using rep₀
  have repr (u : V) (ud : u∈D₀) : rep u∈B := by
    have rd := Graffiti189LongestPath.mem_distanceTwo.mp (priv u (dD ud)).1
    have na : rep u∉A := by
      intro e
      rcases (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp e).2 with h|h
      · rw [h,dist_self] at rd; omega
      · have h' := dist_eq_one_iff_adj.mpr h; omega
    exact closed u (dA ud) (rep u) na (priv u (dD ud)).2.1
  have inj : Set.InjOn rep (↑D:Set V) := by
    intro u ud v vd e
    apply Classical.byContradiction
    intro ne
    exact (priv v vd).2.2 u ud ne (e ▸ (priv u ud).2.1)
  have allD : (D.image rep)⊆DistanceTwo G x := by
    intro z zz
    obtain ⟨u,ud,rfl⟩ := mem_image.mp zz
    exact (priv u ud).1
  have cardDon : D.card≤d := by
    have e := (card_le_card allD).trans (cap x)
    rw [card_image_of_injOn inj] at e
    exact e
  have vp : ∀ u∈D₀,rep u∈DistanceTwo G x ∧ G.Adj u (rep u) ∧
      ∀ w∈D₀,w≠u → ¬G.Adj w (rep u) := by
    intro u ud
    obtain ⟨a,b,c⟩ := priv u (dD ud)
    exact ⟨a,b,fun w wd ne => c w (dD wd) ne⟩
  have remainder : R.card≤2 := by
    let L := univ.filter (fun z : V => G.degree z<d)
    have rsub : R⊆W∪L := by
      intro z rz
      obtain ⟨zd,r⟩ := mem_sdiff.mp rz
      have zo : z∈C∪E∪P∪W := partition.symm ▸ DA zd
      rcases mem_union.mp zo with zce|zw
      · rcases mem_union.mp zce with zz|zp
        · by_cases zhigh : d≤G.degree z
          · exfalso
            apply r
            apply mem_union.mpr
            left
            rcases mem_union.mp zz with zc|ze
            · exact mem_union.mpr (Or.inl (mem_filter.mpr ⟨mem_inter.mpr ⟨zd,zc⟩,zhigh⟩))
            · exact mem_union.mpr (Or.inr (mem_filter.mpr ⟨mem_inter.mpr ⟨zd,ze⟩,zhigh⟩))
          · exact mem_union.mpr (Or.inr (mem_filter.mpr ⟨mem_univ _,by omega⟩))
        · exact (r (mem_union.mpr (Or.inr (mem_inter.mpr ⟨zd,zp⟩)))).elim
      exact mem_union.mpr (Or.inl zw)
    have sl : L.card≤1 := by
      apply Nat.le_of_not_gt
      intro h
      obtain ⟨u,uu,v,vv,ne⟩ := one_lt_card.mp (show 1<L.card from h)
      have uo := (mem_filter.mp uu).2
      have vo := (mem_filter.mp vv).2
      exact (deg u v ne).elim (Nat.not_le_of_lt uo) (Nat.not_le_of_lt vo)
    have eq := (card_le_card rsub).trans (card_union_le W L)
    omega
  have shoreE : A=E∪C∪X := by rw [union_comm E C]; exact shore
  have noE (v : V) (ve : v∈E) (u : V) (uc : u∈C) : ¬G.Adj v u := fun z => no u uc v ve z.symm
  have HB_C (v : V) (vv : v∈C') :
      (F v).card+nC+E.card+pp+jC≤d+2 := by
    have vd : v∈D₀ := mem_union.mpr (Or.inl vv)
    have uc := donor_degree_all_private_and_missing_pins d hp hx C E X D₀
      shore xs cA dA no bk v ((cD v vv).2.1) vd (cD v vv).2.2 rep vp
    have sc := omitted_donor_strong_charge hc d cap hp hx gap D₀ (E\D₀) dA xD₀
      (fun _ e => eA (mem_sdiff.mp e).1)
      (fun e => disjoint_left.mp dex (mem_sdiff.mp e).1 xx)
      (disjoint_left.mpr (fun _ z h => (mem_sdiff.mp h).2 z)) v vd
      (fun z zq => no v ((cD v vv).2.1) z (mem_sdiff.mp zq).1) rep vp
    have is : E∩D₀=E' := by
      ext z
      constructor
      · intro e
        obtain ⟨hR,hd⟩ := mem_inter.mp e
        rcases mem_union.mp hd with hC|hE
        · exact (disjoint_left.mp ce (cc' hC) hR).elim
        · exact hE
      · intro e
        exact mem_inter.mpr ⟨ee' e, mem_union.mpr (Or.inr e)⟩
    have e := card_sdiff_add_card_inter E D₀
    rw [is] at e
    change (E\D₀).card+nE=E.card at e
    let j := ((Pins p x).filter (fun i => G.Adj v (p.getVert i))).card
    change D₀.card+2*pp≤C.card+j+3 at uc
    change (F v).card+D₀.card+(E\D₀).card+pp+j≤d+2 at sc
    have jj : jC≤j := by dsimp [jC]; omega
    omega
  have HB_E (v : V) (vv : v∈E') :
      (F v).card+nE+C.card+pp+jE≤d+2 := by
    have vd : v∈D₀ := mem_union.mpr (Or.inr vv)
    have uc := donor_degree_all_private_and_missing_pins d hp hx E C X D₀
      shoreE xs eA dA noE bk v ((eD v vv).2.1) vd (eD v vv).2.2 rep vp
    have sc := omitted_donor_strong_charge hc d cap hp hx gap D₀ (C\D₀) dA xD₀
      (fun _ e => cA (mem_sdiff.mp e).1)
      (fun e => disjoint_left.mp dcx (mem_sdiff.mp e).1 xx)
      (disjoint_left.mpr (fun _ z h => (mem_sdiff.mp h).2 z)) v vd
      (fun z zq => noE v ((eD v vv).2.1) z (mem_sdiff.mp zq).1) rep vp
    have is : C∩D₀=C' := by
      ext z
      constructor
      · intro e
        obtain ⟨hR,hd⟩ := mem_inter.mp e
        rcases mem_union.mp hd with hC|hE
        · exact hC
        · exact (disjoint_left.mp ce hR (ee' hE)).elim
      · intro e
        exact mem_inter.mpr ⟨cc' e, mem_union.mpr (Or.inl e)⟩
    have e := card_sdiff_add_card_inter C D₀
    rw [is] at e
    change (C\D₀).card+nC=C.card at e
    let j := ((Pins p x).filter (fun i => G.Adj v (p.getVert i))).card
    change D₀.card+2*pp≤E.card+j+3 at uc
    change (F v).card+D₀.card+(C\D₀).card+pp+j≤d+2 at sc
    have jj : jE≤j := by dsimp [jE]; omega
    omega
  have hpin (v : V) (vp : v∈P') : (F v).card+nC+nE+t≤d+1 := by
    have h := every v (mem_inter.mp vp).1 (∅:Finset V) (empty_subset _) (by simp)
    rw [empty_sdiff,card_empty,add_zero] at h
    have e : 0<D.card := card_pos.mpr ⟨v,(mem_inter.mp vp).1⟩
    change (F v).card+(D.card-1)≤d at h
    omega
  have hr (v : V) (vr : v∈R) : (F v).card≤d := by
    have h := every v (mem_sdiff.mp vr).1 (∅:Finset V) (empty_subset _) (by simp)
    rw [empty_sdiff,card_empty,add_zero] at h
    exact le_trans (Nat.le_add_right _ _) h
  let GC := C'.biUnion F
  let GE := E'.biUnion F
  let GP := P'.biUnion F
  let GR := R.biUnion F
  have sC : GC.card+nC*(nC+E.card+pp+jC)≤nC*(d+2) :=
    Graffiti189LongestPath.FlexSplitShell.count_group C' F _ _ (fun v vv => by have vbound := HB_C v vv; omega)
  have sE : GE.card+nE*(nE+C.card+pp+jE)≤nE*(d+2) :=
    Graffiti189LongestPath.FlexSplitShell.count_group E' F _ _ (fun v vv => by have vbound := HB_E v vv; omega)
  have sP : GP.card+t*(nC+nE+t)≤t*(d+1) :=
    Graffiti189LongestPath.FlexSplitShell.count_group P' F _ _ (by
      intro v vP
      have q := hpin v vP
      omega)
  have sR : GR.card≤2*d :=
    (card_biUnion_le_card_mul R F d hr).trans (Nat.mul_le_mul_right _ remainder)
  have hcover : H⊆GC∪GE∪GP∪GR := by
    intro z zh
    obtain ⟨v,vd,vz⟩ := mem_biUnion.mp (cover zh)
    by_cases dr : v∈D₀∪P'
    · rcases mem_union.mp dr with d0|pi
      · rcases mem_union.mp d0 with vc|ve
        · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inl (mem_union.mpr (Or.inl
            (mem_biUnion.mpr ⟨v,vc,vz⟩))))))
        · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inl (mem_union.mpr (Or.inr
            (mem_biUnion.mpr ⟨v,ve,vz⟩))))))
      · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inr (mem_biUnion.mpr ⟨v,pi,vz⟩))))
    · exact mem_union.mpr (Or.inr (mem_biUnion.mpr ⟨v,mem_sdiff.mpr ⟨vd,dr⟩,vz⟩))
  have total := card_le_card hcover
  have cg := card_union_le GC GE
  have pg := card_union_le (GC∪GE) GP
  have rg := card_union_le (GC∪GE∪GP) GR
  have sumN :
      H.card+nC*nC+nE*nE+(nC+nE)*(pp+t)+t*t+
        (nC*E.card+nE*C.card+nC*jC+nE*jE)≤(d+2)*(nC+nE)+(d+1)*t+2*d := by
    have e1 : nC*(nC+E.card+pp+jC)+nE*(nE+C.card+pp+jE)+t*(nC+nE+t)=
        nC*nC+nE*nE+(nC+nE)*(pp+t)+t*t+
          (nC*E.card+nE*C.card+nC*jC+nE*jE) := by ring
    have e2 : nC*(d+2)+nE*(d+2)+t*(d+1)=(d+2)*(nC+nE)+(d+1)*t := by ring
    omega
  have oneside (b c j : Nat) (c_le : mF≤c)
      (s : H.card+b*b+b*(pp+t)+t*t+(b*c+b*j)≤(d+2)*b+(d+1)*t+2*d) :
      4*H.card≤(d+2-mF)*(d+2-mF)+4*(mF*pp)+8*d := by
    let q := d+2-mF
    have qe : q+mF=d+2 := Nat.sub_add_cancel md
    have cos := Nat.mul_le_mul_left b c_le
    have bb := Nat.mul_le_mul_left b tn
    have td : (d+1)*t≤t*(d+2) := by
      rw [Nat.mul_comm (d+1) t]
      exact Nat.mul_le_mul_left t (by omega)
    have e1 : (b+t)*(b+t)=b*b+2*(b*t)+t*t := by ring
    have e2 : b*(pp+t)=b*pp+b*t := by ring
    have e3 : (b+t)*(q+mF)=(b+t)*q+b*mF+mF*t := by ring
    have e4 : (b+t)*(d+2)=(d+2)*b+t*(d+2) := by ring
    have eq : (b+t)*(q+mF)=(b+t)*(d+2) := congrArg (fun z => (b+t)*z) qe
    rw [e3,e4] at eq
    have mass : H.card+(b+t)*(b+t)≤(b+t)*q+mF*t+2*d := by omega
    exact one_shell_numeric H.card b t q mF pp d tn mass
  by_cases cempty : nC=0
  · left
    apply oneside nE C.card jE cs
    simpa [cempty, add_assoc] using sumN
  by_cases eempty : nE=0
  · left
    apply oneside nC E.card jC es
    simpa [eempty, add_assoc] using sumN
  right
  obtain ⟨u,uC⟩ := card_pos.mp (show 0<C'.card from Nat.pos_of_ne_zero cempty)
  obtain ⟨v,vE⟩ := card_pos.mp (show 0<E'.card from Nat.pos_of_ne_zero eempty)
  have mdC := donor_degree_all_private_and_missing_pins d hp hx C E X D₀
    shore xs cA dA no bk u ((cD u uC).2.1) (mem_union.mpr (Or.inl uC)) (cD u uC).2.2 rep vp
  have mdE := donor_degree_all_private_and_missing_pins d hp hx E C X D₀
    shoreE xs eA dA noE bk v ((eD v vE).2.1) (mem_union.mpr (Or.inr vE)) (eD v vE).2.2 rep vp
  have jpC : jC≤pp := by
    let j := ((Pins p x).filter (fun i => G.Adj u (p.getVert i))).card
    change D₀.card+2*pp≤C.card+j+3 at mdC
    have jb : j≤pp := card_filter_le _ _
    dsimp [jC]
    omega
  have jpE : jE≤pp := by
    let j := ((Pins p x).filter (fun i => G.Adj v (p.getVert i))).card
    change D₀.card+2*pp≤E.card+j+3 at mdE
    have jb : j≤pp := card_filter_le _ _
    dsimp [jE]
    omega
  have dc : nC+nE+2*pp≤C.card+jC+3 := by dsimp [jC]; omega
  have de : nC+nE+2*pp≤E.card+jE+3 := by dsimp [jE]; omega
  have rc := side_bound_with_missing_reach_and_private_ports d A B C E X C' shore xs cA no
    closed pp bk u ((cD u uC).2.1) uC (cD u uC).2.2 rep cc'
    (fun z zc => ⟨repr z (mem_union.mpr (Or.inl zc)),(priv z (cD z zc).1).2.1,
      fun w wc ne => (priv z (cD z zc).1).2.2 w (cD w wc).1 ne⟩)
  have re := side_bound_with_missing_reach_and_private_ports d A B E C X E' shoreE xs eA noE
    closed pp bk v ((eD v vE).2.1) vE (eD v vE).2.2 rep ee'
    (fun z ze => ⟨repr z (mem_union.mpr (Or.inr ze)),(priv z (eD z ze).1).2.1,
      fun w we ne => (priv z (eD z ze).1).2.2 w (eD w we).1 ne⟩)
  change nC+pp+mC≤C.card+3 at rc
  change nE+pp+mE≤E.card+3 at re
  change k≤f+mC+mE at reaches
  change B.card+pp≤d+1 at bk
  have pd : pp≤d := by
    have n : 0<B.card ∨ pp=0 := by
      rcases Nat.eq_zero_or_pos pp with z|z
      · exact Or.inr z
      · obtain ⟨i,ii⟩ := card_pos.mp z
        exact Or.inl (card_pos.mpr ⟨p.getVert i,
          (closed x (Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩) _
            (fun va => (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp va).1 (p.getVert_mem_support i))
            (Graffiti189LongestPath.pin_data ii).2)⟩)
    omega
  have donor : nC+nE+t≤d := by omega
  refine ⟨t,tn,?_⟩
  have bounds := combined_mixed_bounds (nC:ℤ) (nE:ℤ) (C.card:ℤ) (E.card:ℤ) (H.card:ℤ)
    (d:ℤ) (pp:ℤ) (t:ℤ) (jC:ℤ) (jE:ℤ) (mC:ℤ) (mE:ℤ) (k:ℤ) (f:ℤ)
    (by omega) (by omega) (by omega) (by omega) (by omega)
    (by omega) (by omega) (by omega) (by omega) (by omega)
    (by omega) (by omega) (by omega) (by omega) (by omega)
    (by exact_mod_cast sumN)
  change mC+pp≤s+3 at mcs
  change mE+pp≤s+3 at mes
  have donor' : nC+nE+t≤k+s := by omega
  have sumN' :
      H.card+nC*nC+nE*nE+(nC+nE)*(pp+t)+t*t+
        (nC*E.card+nE*C.card+nC*jC+nE*jE)≤(k+s+2)*(nC+nE)+(k+s+1)*t+2*(k+s) := by
    rw [←dEq]
    exact sumN
  have stronger := Graffiti189LongestPath.FiveNinthsReserve.individual_missed_port_shell_bound
    (nC:ℤ) (nE:ℤ) (C.card:ℤ) (E.card:ℤ) (H.card:ℤ)
    (k:ℤ) (s:ℤ) (pp:ℤ) (t:ℤ) (jC:ℤ) (jE:ℤ) (mC:ℤ) (mE:ℤ) (f:ℤ)
    (by omega) (by omega) (by omega) (by omega) (by omega)
    (by omega) (by omega) (by omega) (by omega) (by omega)
    (by omega) (by omega) (by omega) (by omega) (by omega)
    (by exact_mod_cast sumN')
  have dI : (d:ℤ)=(k:ℤ)+(s:ℤ) := by omega
  exact ⟨bounds.1,bounds.2.1,bounds.2.2,by simpa only [dI] using stronger⟩


#print axioms stronger_split_shell_three
end Graffiti189LongestPath.FiveNinthsShell

/- source: FiveNinthsDeficit189 -/
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack Graffiti189LongestPath.PinRun
open Graffiti189LongestPath.DeficitActive Graffiti189LongestPath.ScaledActive Graffiti189LongestPath.DeficitLongest
open Graffiti189LongestPath.QuadraticShore
open Graffiti189LongestPath.GeneralGapMidpoint Graffiti189LongestPath.Normalize Graffiti189LongestPath.DeficitThirdShell
open Graffiti189LongestPath.StandaloneShellQuadratic Graffiti189LongestPath.RadialOrder
open Graffiti189LongestPath.GreedyTerminal Graffiti189LongestPath.FanWeighted Graffiti189LongestPath.MengerRoutable
open Graffiti189LongestPath.ShoreSplit Graffiti189LongestPath.ExplicitShoreCycle
open Graffiti189LongestPath.SplitShellCharge Graffiti189LongestPath.StarCycleClosure Graffiti189LongestPath.PosaOneLow Graffiti189LongestPath.ActiveStarHeight
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
open private Graffiti189LongestPath.pin_data from SmallSeparator189
open private Graffiti189LongestPath.OneSlack.boundary_except_pins_two Graffiti189LongestPath.OneSlack.card_pinVertices
  Graffiti189LongestPath.OneSlack.pin_vertices_subset_boundary Graffiti189LongestPath.OneSlack.first_eq_if_no_pair
  Graffiti189LongestPath.OneSlack.pin_of_neighbor_mem from OneSlack189
open private Graffiti189LongestPath.PortReachCount.side_ports_bound from PortReachCount189
set_option warningAsError true
set_option maxHeartbeats 7000000
namespace Graffiti189LongestPath.FiveNinthsDeficit
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- #189 in an explicit quadratic connectivity range, without needing
2-connectivity of the omitted shore.
No normalized attachment or separator geometry is assumed. -/
theorem traceable_of_five_ninths_gap (hc : G.Connected) (k sl : Nat) (large : 100000≤k) (ratio : 5*sl≤4*k) (positive : 2*k≤3*sl)
    (cap : ∀ v,(EvenFrom G v).card≤k+sl+1)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → k+sl≤G.degree u ∨ k+sl≤G.degree v) :
    ∃ (u v : V) (q : G.Walk u v),q.IsPath ∧ ∀ z,z∈q.support := by
  classical
  apply Classical.byContradiction
  intro fail
  obtain ⟨a,b,p,hmin⟩ := exists_edgeMinAvoid hc (k+sl) deg
  have hp := hmin.1.1
  have no : ∃ x,x∉p.support := Classical.byContradiction (fun h =>
    fail ⟨a,b,p,hp.1,fun z => Classical.byContradiction (fun e => h ⟨z,e⟩)⟩)
  obtain ⟨x,hx,xh,i,hi⟩ := scaled_deficit_has_high_active hc k sl (by omega) (by omega) cap conn deg hp no
  let d := k+sl
  let A := OmittedStar p x
  let B := External G A
  let H := Shell G x 3
  let W := Shell G x 4
  let U := (univ:Finset V)\(A∪B)
  have cap₂ (v : V) : (DistanceTwo G v).card≤d := distanceTwo_le_of_even d v (cap v)
  have pack := high_omitted_pin_budget hc d k cap conn hp hx (Graffiti189LongestPath.pin_data hi).2 xh
  have p3 : (Pins p x).card≤sl := by dsimp [d] at pack; omega
  have w3 : W.card≤sl := by change k+(Pins p x).card+W.card≤d at pack; dsimp [d] at pack; omega
  have rad (z : V) : G.dist x z≤4 := by
    by_contra! far
    have c := shell_card_of_far hc k conn (x:=x) (y:=z) (i:=4) (by decide) (by omega)
    change k≤W.card at c
    omega
  let loss := sl+1-(Pins p x).card
  have height : k+loss≤A.card := by
    have e := star_card_degree_and_pins hp hx
    change A.card+(Pins p x).card=G.degree x+1 at e
    dsimp [loss,d] at *
    omega
  have first := GapOne.first_pins_at_least_pins_sub_one hc d cap deg hmin.1 hx xh (by dsimp [d]; omega)
  have bp : B.card+(Pins p x).card≤d+1 := by
    have f := boundary_flank_count hc hp hx
    rw [flank_count_exact hp hx] at f
    have c := cap₂ x
    change B.card+((Pins p x).card+(FirstPins p x).card)≤
      (DistanceTwo G x).card+(Pins p x).card at f
    omega
  have bk : B.card≤k+loss := by
    dsimp [d] at bp
    dsimp [loss]
    omega
  have floor (z : V) : 2≤G.degree z := by
    have ne : a≠x := fun e => hx (e ▸ p.start_mem_support)
    have n := enough_vertices_of_degree (k+sl) deg ne
    have kdeg := degree_floor_when_enough_vertices k conn (by omega) z
    omega
  have largeP := longest_length_ge_twice_of_not_traceable hc d (by omega) floor deg fail hp
  have far : k≤U.card := by
    have cover : p.support.toFinset⊆B∪U := by
      intro z hz
      by_cases zb : z∈B
      · exact mem_union.mpr (Or.inl zb)
      have za : z∉A := fun e => (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp e).1 (List.mem_toFinset.mp hz)
      exact mem_union.mpr (Or.inr (mem_sdiff.mpr ⟨mem_univ z,fun e => (mem_union.mp e).elim za zb⟩))
    have h := (card_le_card cover).trans (card_union_le B U)
    rw [List.toFinset_card_of_nodup hp.1.support_nodup,length_support] at h
    dsimp [d] at largeP
    omega
  let T := A.erase x
  let J := G.induce (T:Set V)
  let L := T.filter (fun v => G.degree v<d)
  let m := (k-2)/2
  have xA : x∈A := Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
  have L1 : L.card≤1 := by
    apply Nat.le_of_not_gt
    intro e
    obtain ⟨u,uu,v,vv,ne⟩ := one_lt_card.mp (show 1<L.card from e)
    have e₁ := (mem_filter.mp uu).2
    have e₂ := (mem_filter.mp vv).2
    exact (deg u v ne).elim (Nat.not_le_of_lt e₁) (Nat.not_le_of_lt e₂)
  have highJ (v : V) (vt : v∈T) (vl : v∉L) : m≤(T.filter (G.Adj v)).card := by
    let v' : ↥(T:Set V) := ⟨v,vt⟩
    have vh : d≤G.degree v := Nat.le_of_not_gt (fun h => vl (mem_filter.mpr ⟨vt,h⟩))
    have b := (quadratic_root_deleted_degrees hc k sl loss cap conn hp hx bk far v').2 vh
    change A.card≤2*J.degree v'+loss+3 at b
    have id := induced_degree_count (G:=G) T v'
    change (T.filter (G.Adj v)).card=J.degree v' at id
    dsimp [m]
    omega
  have floorJ (v : ↥(T:Set V)) : 2≤J.degree v := by
    have b := (quadratic_root_deleted_degrees hc k sl loss cap conn hp hx bk far v).1
    change A.card≤2*J.degree v+sl+loss+3 at b
    omega
  have lowJ (v : V) (vt : v∈T) (_vl : v∈L) : 1≤(T.filter (G.Adj v)).card := by
    let v' : ↥(T:Set V) := ⟨v,vt⟩
    have b := floorJ v'
    have id := induced_degree_count (G:=G) T v'
    change (T.filter (G.Adj v)).card=J.degree v' at id
    omega
  have highDegree (v : ↥(T:Set V)) (vh : d≤G.degree v.val) : m≤J.degree v := by
    have u := highJ v.val v.property (fun e => (Nat.not_lt_of_ge vh) (mem_filter.mp e).2)
    have eq := induced_degree_count (G:=G) T v
    change (T.filter (G.Adj v.val)).card=J.degree v at eq
    omega
  have root (v : V) (va : v∈A) (ne : v≠x) : G.Adj x v :=
    ((Graffiti189LongestPath.Rigidity.mem_omittedStar.mp va).2).resolve_left ne
  have routes := one_low_universal_uniform_routes A L x xA root L1 m highJ lowJ
  have ao : ∀ v∈A,v∉p.support := fun _ va =>
    (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp va).1
  obtain ⟨F⟩ := hooks_of_small_deletion_connectivity A k hp ao (by omega) (support_large k conn hp hx) conn
  have bound := weighted_hooked_lower k (by omega) hp (m+1) A ao (by omega) routes F
  have low : A.card+k+(k+1)*(m+1)≤Fintype.card V := by omega
  have order := order_le_radius_four_layers hc x rad
  change Fintype.card V≤G.degree x+1+(DistanceTwo G x).card+H.card+W.card at order
  have base : Fintype.card V≤A.card+k+2*sl+H.card := by
    have d₂ := cap₂ x
    have degX := star_card_degree_and_pins hp hx
    change A.card+(Pins p x).card=G.degree x+1 at degX
    change k+(Pins p x).card+W.card≤d at pack
    dsimp [d] at d₂ pack
    omega
  by_cases robust : ∀ S : Finset ↥(T:Set V), S.card<2 →
      (J.induce ((↑S:Set _)ᶜ)).Connected
  · have vc : Fintype.card ↥(T:Set V)=A.card-1 := by
      change Fintype.card ↥T=A.card-1
      exact (Fintype.card_coe T).trans (card_erase_of_mem xA)
    have md : 2≤m := by dsimp [m]; omega
    have pair (u v : ↥(T:Set V)) (ne : u≠v) : m≤J.degree u ∨ m≤J.degree v :=
      (deg u.val v.val (fun e => ne (Subtype.ext e))).imp (highDegree u) (highDegree v)
    obtain ⟨r,c,cc,cl⟩ := proved_one_low_circumference _ J m md (by omega) robust floorJ pair
    have lim : k-3≤c.length := by
      have bm : 2*m≤A.card-1 := by dsimp [m]; omega
      have bm' : 2*m≤Fintype.card ↥(T:Set V) := by rw [vc]; exact bm
      rw [min_eq_right bm'] at cl
      dsimp [m] at cl
      omega
    have routesLong := routes_of_explicit_root_deleted_cycle hx robust (k-3)
      ⟨r,c,cc,by omega⟩
    have lowLong := weighted_hooked_lower k (by omega) hp (k-3+1) A ao (by omega) routesLong F
    have lowLong' : A.card+k+(k+1)*(k-2)≤Fintype.card V := by
      rw [show k-3+1=k-2 by omega] at lowLong
      omega
    have shell := universal_shell_three_quadratic hc d cap₂ x
    change 4*H.card≤(d+1)*(d+1) at shell
    have small : (d+1)*(d+1)+8*sl<4*((k+1)*(k-2)) := by
      have v : d+1≤2*k-6 := by dsimp [d]; omega
      have sq := Nat.mul_le_mul v v
      have eq : (2*k-6)*(2*k-6)+24*k=4*(k*k)+36 := by
        let t := k-3
        have kt : k=t+3 := by dsimp [t]; omega
        rw [show 2*k-6=2*t by dsimp [t]; omega]
        rw [kt]
        ring
      have ev : (k+1)*(k-2)+k+2=k*k := by
        let t := k-2
        have kt : k=t+2 := by dsimp [t]; omega
        rw [show k-2=t from rfl,kt]
        ring
      omega
    have um : 4*Fintype.card V<4*(A.card+k+(k+1)*(k-2)) := by
      calc
        _ ≤ 4*(A.card+k+2*sl+H.card) := Nat.mul_le_mul_left 4 base
        _ = 4*(A.card+k)+(4*H.card+8*sl) := by ring
        _ ≤ 4*(A.card+k)+((d+1)*(d+1)+8*sl) :=
          Nat.add_le_add_left (Nat.add_le_add_right shell _) _
        _ < 4*(A.card+k)+4*((k+1)*(k-2)) := Nat.add_lt_add_left small _
        _ = _ := by ring
    omega
  obtain ⟨S,sm,failS⟩ : ∃ S : Finset ↥(T:Set V),S.card<2 ∧ ¬(J.induce ((↑S:Set _)ᶜ)).Connected := by
    apply Classical.byContradiction
    intro neg
    apply robust
    intro S sm
    exact Classical.byContradiction (fun bad => neg ⟨S,sm,bad⟩)
  let emb : ↥(T:Set V) ↪ V := ⟨Subtype.val,Subtype.val_injective⟩
  let X := insert x (S.map emb)
  have xx : x∈X := mem_insert_self _ _
  have xsub : X⊆A := by
    intro z zz
    rcases mem_insert.mp zz with rfl|zz
    · exact xA
    · obtain ⟨v,_,rfl⟩ := mem_map.mp zz
      exact (mem_erase.mp v.property).2
  have xs : X.card≤2 := by
    have h := card_insert_le x (S.map emb)
    rw [card_map] at h
    change X.card≤S.card+1 at h
    omega
  have iso := erase_root_and_set_iso (G:=G) A x S
  have bad : ¬(G.induce (↑(A\X):Set V)).Connected := fun h => failS (iso.connected_iff.mp h)
  have nAX : (A\X).Nonempty := card_pos.mp (by
    have e := card_sdiff_add_card_eq_card xsub
    omega)
  obtain ⟨C,E,part,ce,no,cn,en,smaller⟩ : ∃ C E : Finset V,
      C∪E=A\X ∧ Disjoint C E ∧ (∀ u∈C,∀ v∈E,¬G.Adj u v) ∧
      C.Nonempty ∧ E.Nonempty ∧ C.card≤E.card := by
    obtain ⟨C,E,part,ce,no,cn,en⟩ := partition_of_not_connected (A\X) nAX bad
    by_cases smaller : C.card≤E.card
    · exact ⟨C,E,part,ce,no,cn,en,smaller⟩
    · exact ⟨E,C,(union_comm E C).trans part,ce.symm,
        fun v ve u uc ed => no u uc v ve ed.symm,en,cn,by omega⟩
  have lc := side_order_at_least_half A C E X x d (k-1) xx xsub xs part ce cn no deg floorJ highDegree
  let P := PinVertices p x
  let W' := X.erase x
  have ec : C⊆A\X := fun _ h => part ▸ mem_union.mpr (Or.inl h)
  have ee : E⊆A\X := fun _ h => part ▸ mem_union.mpr (Or.inr h)
  have pinOff : Disjoint A P := disjoint_left.mpr (by
    intro z za zp
    obtain ⟨i,_,rfl⟩ := mem_image.mp zp
    exact ao _ za (p.getVert_mem_support i))
  have cp : Disjoint C P := disjoint_left.mpr (fun _ h h' => disjoint_left.mp pinOff (mem_sdiff.mp (ec h)).1 h')
  have ep : Disjoint E P := disjoint_left.mpr (fun _ h h' => disjoint_left.mp pinOff (mem_sdiff.mp (ee h)).1 h')
  have cw : Disjoint C W' := disjoint_left.mpr (fun _ h h' => (mem_sdiff.mp (ec h)).2 (mem_erase.mp h').2)
  have ew : Disjoint E W' := disjoint_left.mpr (fun _ h h' => (mem_sdiff.mp (ee h)).2 (mem_erase.mp h').2)
  have pw : Disjoint P W' := disjoint_left.mpr (fun _ h h' => disjoint_left.mp pinOff (xsub (mem_erase.mp h').2) h)
  have pp : P.card≤sl := by
    have h := Graffiti189LongestPath.OneSlack.card_pinVertices hp (x:=x)
    change P.card=(Pins p x).card at h
    omega
  have wc : W'.card≤1 := by
    have h := card_erase_add_one xx
    change W'.card+1=X.card at h
    omega
  have nbh : G.neighborFinset x=T∪P := by
    ext z
    rw [G.mem_neighborFinset,mem_union]
    constructor
    · intro adj
      by_cases zp : z∈p.support
      · obtain ⟨j,jp,e⟩ := Graffiti189LongestPath.OneSlack.pin_of_neighbor_mem hp hx zp adj
        exact Or.inr (mem_image.mpr ⟨j,jp,e⟩)
      exact Or.inl (mem_erase.mpr ⟨adj.ne.symm,
        Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨zp,Or.inr adj⟩⟩)
    · rintro (zt|zp)
      · exact root z (mem_erase.mp zt).2 (mem_erase.mp zt).1
      · obtain ⟨j,jp,rfl⟩ := mem_image.mp zp
        exact (Graffiti189LongestPath.pin_data jp).2
  have rest : (C∪E)∪W'=T := by
    rw [part]
    ext z
    simp only [mem_union,mem_sdiff,mem_erase,T,W']
    constructor
    · intro h
      rcases h with ⟨za,zx⟩|⟨zx,ze⟩
      · exact ⟨fun e => zx (e.symm ▸ xx),za⟩
      · exact ⟨zx,xsub ze⟩
    · rintro ⟨zx,za⟩
      by_cases zX : z∈X
      · exact Or.inr ⟨zx,zX⟩
      · exact Or.inl ⟨za,zX⟩
  have partition : C∪E∪P∪W'=G.neighborFinset x := by
    rw [nbh,←rest]
    ac_rfl
  have cA : C⊆A := fun _ z => (mem_sdiff.mp (ec z)).1
  have eA : E⊆A := fun _ z => (mem_sdiff.mp (ee z)).1
  have cX : Disjoint C X := disjoint_left.mpr (fun _ z w => (mem_sdiff.mp (ec z)).2 w)
  have eX : Disjoint E X := disjoint_left.mpr (fun _ z w => (mem_sdiff.mp (ee z)).2 w)
  have shore : A=C∪E∪X := by
    rw [part]
    exact (sdiff_union_of_subset xsub).symm
  have ab : Disjoint A B := disjoint_left.mpr (fun _ z w =>
    (Graffiti189LongestPath.Rigidity.mem_external.mp w).1 z)
  have closed (u : V) (ua : u∈A) (v : V) (va : v∉A) (ed : G.Adj u v) : v∈B :=
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨va,u,ua,ed⟩
  have gain (C E : Finset V) (part : C∪E=A\X) (no : ∀ u∈C,∀ v∈E,¬G.Adj u v)
      (v : V) (vc : v∈C) :
      (T.filter (G.Adj v)).card≤(C.filter (G.Adj v)).card+1 := by
    have cover : T.filter (G.Adj v)⊆(C.filter (G.Adj v))∪W' := by
      intro z h
      obtain ⟨zt,ed⟩ := mem_filter.mp h
      by_cases zx : z∈X
      · exact mem_union.mpr (Or.inr (mem_erase.mpr ⟨(mem_erase.mp zt).1,zx⟩))
      have zCE : z∈C∪E := part.symm ▸ mem_sdiff.mpr ⟨(mem_erase.mp zt).2,zx⟩
      rcases mem_union.mp zCE with zc|ze
      · exact mem_union.mpr (Or.inl (mem_filter.mpr ⟨zc,ed⟩))
      · exact (no v vc z ze ed).elim
    have hc' := (card_le_card cover).trans (card_union_le (C.filter (G.Adj v)) W')
    omega
  have ceB := fun v vc => gain C E part no v vc
  have ecB := fun v ve => gain E C ((union_comm E C).trans part)
    (fun u ue v vc adj => no v vc u ue adj.symm) v ve
  have cT (v : V) (vc : v∈C) : v∈T :=
    mem_erase.mpr ⟨fun h => (mem_sdiff.mp (ec vc)).2 (h.symm ▸ xx),cA vc⟩
  have eT (v : V) (ve : v∈E) : v∈T :=
    mem_erase.mpr ⟨fun h => (mem_sdiff.mp (ee ve)).2 (h.symm ▸ xx),eA ve⟩
  have lowerTwo (v : V) (vt : v∈T) : 2≤(T.filter (G.Adj v)).card := by
    let v' : ↥(T:Set V) := ⟨v,vt⟩
    have eq := induced_degree_count (G:=G) T v'
    change (T.filter (G.Adj v)).card=J.degree v' at eq
    rw [eq]
    exact floorJ v'
  have cross := SplitGreedy.greedy_cross_shore_route A C E L m L1 (by dsimp [m]; omega)
    x xA (fun h => (mem_sdiff.mp (ec h)).2 xx) (fun h => (mem_sdiff.mp (ee h)).2 xx)
    cA eA ce root (fun v vc vl => by have b := highJ v (cT v vc) vl; have e := ceB v vc; omega)
    (fun v ve vl => by have b := highJ v (eT v ve) vl; have e := ecB v ve; omega)
    (fun v vc _ => by have b := lowerTwo v (cT v vc); have e := ceB v vc; omega)
    (fun v ve _ => by have b := lowerTwo v (eT v ve); have e := ecB v ve; omega)
  have flex := FlexibleFan.flexible_hooked_lower k (m+1) (m-2) (by omega) hp A C E X ao
    (by omega) cA eA ce cn en shore routes cross F
  let ff := ((univ : Finset (Fin k)).filter (fun i =>
      (∃ u∈C,G.Adj u (HookRetarget.fromFamily F i).firstPort) ∧
        ∃ v∈E,G.Adj v (HookRetarget.fromFamily F i).firstPort)).card
  change A.card+k+(k+1)*(m+1)+ff*(m-2)≤Fintype.card V+X.card*(m-2) at flex
  have flex' : (k+1)*(m+1)+ff*(m-2)≤H.card+2*sl+2*(m-2) := by
    have z := Nat.mul_le_mul_right (m-2) xs
    omega
  have mi : 2≤m := by dsimp [m]; omega
  have flexI : ((k:ℤ)+1)*((m:ℤ)+1)+(ff:ℤ)*((m:ℤ)-2)≤
      (H.card:ℤ)+2*(sl:ℤ)+2*((m:ℤ)-2) := by
    have z : ((k:ℤ)+1)*((m:ℤ)+1)+(ff:ℤ)*((m-2:ℕ):ℤ)≤
      (H.card:ℤ)+2*(sl:ℤ)+2*((m-2:ℕ):ℤ) := by exact_mod_cast flex'
    rw [Int.ofNat_sub mi] at z
    simpa using z
  have fbound : ff≤k := by
    have h := card_filter_le (s:=(univ : Finset (Fin k))) (fun i =>
      (∃ u∈C,G.Adj u (HookRetarget.fromFamily F i).firstPort) ∧
        ∃ v∈E,G.Adj v (HookRetarget.fromFamily F i).firstPort)
    simpa [ff] using h
  let mF := min C.card sl
  have m0 : m≤mF := le_min (by dsimp [m]; omega) (by dsimp [m]; omega)
  have mfl : k-3≤2*mF := by dsimp [m] at m0; omega
  have mfc : mF≤C.card := min_le_left _ _
  have mfe : mF≤E.card := mfc.trans smaller
  have mfs : mF≤sl := min_le_right _ _
  let qC := B.filter (fun z => ¬∃ u∈C,G.Adj u z)
  let qE := B.filter (fun z => ¬∃ u∈E,G.Adj u z)
  have many := FlexMissTwice.ports_missing_or_flexible k hp A B C E closed ao F
  change k≤ff+qC.card+qE.card at many
  have reach (D : Finset V) :
      (B.filter (fun z => ∃ u∈D,G.Adj u z)).card+
      (B.filter (fun z => ¬∃ u∈D,G.Adj u z)).card=B.card := by
    have j : B\(B.filter (fun z => ∃ u∈D,G.Adj u z))=
        B.filter (fun z => ¬∃ u∈D,G.Adj u z) := by
      ext z
      simp only [mem_sdiff,mem_filter]
      exact ⟨fun h => ⟨h.1,fun e => h.2 ⟨h.1,e⟩⟩, fun h => ⟨h.1,fun e => h.2 e.2⟩⟩
    have q := card_sdiff_add_card_eq_card (filter_subset (fun z => ∃ u∈D,G.Adj u z) B)
    rw [j] at q
    omega
  have gc := Graffiti189LongestPath.PortReachCount.side_ports_bound k A B C E X
    conn shore ab ce cX eX cn en no closed
  have ge := Graffiti189LongestPath.PortReachCount.side_ports_bound k A B E C X
    conn (shore.trans (by rw [union_comm E C])) ab ce.symm eX cX en cn
      (fun u ue v vc ed => no v vc u ue ed.symm) closed
  have qc : qC.card+(Pins p x).card≤sl+3 := by
    have q := reach C
    change (B.filter (fun z => ∃ u∈C,G.Adj u z)).card+qC.card=B.card at q
    have b := bp
    dsimp [d] at b
    omega
  have qe : qE.card+(Pins p x).card≤sl+3 := by
    have q := reach E
    change (B.filter (fun z => ∃ u∈E,G.Adj u z)).card+qE.card=B.card at q
    have b := bp
    dsimp [d] at b
    omega
  have highC : ∃ v∈C,d≤G.degree v := by
    obtain ⟨u,uu,v,vv,ne⟩ := one_lt_card.mp (show 1<C.card from by omega)
    exact (deg u v ne).elim (fun h => ⟨u,uu,h⟩) (fun h => ⟨v,vv,h⟩)
  obtain ⟨v,vc,vh⟩ := highC
  have sharp := StrongDonorDegree.missing_ports_bound_by_side_order d A B C E X
    shore xs closed cA no (Pins p x).card bp v vc vh
  change qC.card+(Pins p x).card≤C.card+2 at sharp
  have qc' : qC.card+(Pins p x).card≤mF+3 := by
    by_cases h : C.card≤sl
    · rw [show mF=C.card from min_eq_left h]; omega
    · rw [show mF=sl from min_eq_right (by omega)]; omega
  have shell := FiveNinthsShell.stronger_split_shell_three hc d k sl ff mF rfl (by omega) fbound hp hx first
    cap₂ C E W' X shore partition deg ce cX eX cp ep no mfc mfe (by dsimp [d]; omega)
    wc xs xx bp p3 qc qe many
  rcases shell with one | ⟨t,tt,ordinary,_flank,exclusive,individual⟩
  · have hcsub : mF≤d+2 := by dsimp [d]; omega
    have oneI : (4:ℤ)*(H.card:ℤ)≤((d+2-mF:ℕ):ℤ)^2+4*(mF:ℤ)*((Pins p x).card:ℤ)+8*(d:ℤ) := by
      exact_mod_cast (by simpa only [pow_two,mul_assoc] using one)
    rw [Int.ofNat_sub hcsub] at oneI
    push_cast at oneI
    have oneC : (4:ℤ)*(H.card:ℤ)≤((k:ℤ)+(sl:ℤ)+2-(mF:ℤ))^2+4*(mF:ℤ)*((Pins p x).card:ℤ)+8*((k:ℤ)+(sl:ℤ)) := by
      dsimp [d] at oneI
      push_cast at oneI
      exact oneI
    exact FiveNinthsOneNumeric.one_side_contradiction (k:ℤ) (sl:ℤ) ((Pins p x).card:ℤ)
      (mF:ℤ) (m:ℤ) (ff:ℤ) (H.card:ℤ) (by omega) (by omega) (by omega)
      (by omega) (by omega) (by dsimp [m]; omega) (by dsimp [m]; omega)
      (by omega) (by omega) (by omega) flexI oneC
  · have lower := FiveNinthsMixedNumeric.spacing_lower (k:ℤ) (sl:ℤ) (m:ℤ)
      (ff:ℤ) (H.card:ℤ) (by omega) (by omega) (by dsimp [m]; omega) (by dsimp [m]; omega)
      (by omega) (by omega) flexI
    exact FiveNinthsMixedNumeric.mixed_contradiction (k:ℤ) (sl:ℤ) ((Pins p x).card:ℤ)
      (t:ℤ) (ff:ℤ) (H.card:ℤ) (by omega) (by omega) (by omega)
      (by omega) (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
      lower (by simpa [d] using ordinary) (by simpa [d] using exclusive) (by simpa [d] using individual)

/-- High-connectivity range of Graffiti.pc #189, asymptotically five ninths of the degree threshold. -/
theorem traceable_of_five_ninths_connectivity (hc : G.Connected) (d k : Nat)
    (large : 100000≤k) (ratio : 5*d≤9*k)
    (cap : ∀ v,(EvenFrom G v).card≤d+1)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → d≤G.degree u ∨ d≤G.degree v) :
    ∃ (u v : V) (q : G.Walk u v),q.IsPath ∧ ∀ z,z∈q.support := by
  by_cases hk : 3*d≤5*k
  · exact Graffiti189LongestPath.ThreeFifthsDeficit.traceable_of_three_fifths_connectivity hc d k
      (by omega) hk cap conn deg
  have eq : k+(d-k)=d := by omega
  exact traceable_of_five_ninths_gap hc k (d-k) large (by omega) (by omega)
    (by simpa only [eq] using cap) conn (by simpa only [eq] using deg)

#print axioms traceable_of_five_ninths_gap
#print axioms traceable_of_five_ninths_connectivity
end Graffiti189LongestPath.FiveNinthsDeficit
