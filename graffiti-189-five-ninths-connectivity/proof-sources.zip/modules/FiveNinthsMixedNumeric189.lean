import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

namespace Graffiti189LongestPath.FiveNinthsMixedNumeric

theorem spacing_lower (k s m f h : ℤ) (hk : 1≤k) (hs : 5*s≤4*k)
    (hmL : k-3≤2*m) (hmU : 2*m≤k) (hf0 : 0≤f) (hfU : f≤k)
    (hflex : (k+1)*(m+1)+f*(m-2)≤h+2*s+2*(m-2)) :
    k^2+k*f-14*k≤2*h := by
  nlinarith only [hflex,hk,hs,hmU,hfU,
    mul_nonneg (show 0≤k+1 by omega) (show 0≤2*m-k+3 by omega),
    mul_nonneg hf0 (show 0≤2*m-k+3 by omega)]

theorem mixed_contradiction (k s p t f h : ℤ) (hk : 100000≤k)
    (hsL : 2*k≤3*s) (hsU : 5*s≤4*k)
    (hp : 0≤p) (hpU : p≤s) (ht : 0≤t) (tp : t≤p)
    (hf : 0≤f) (_hfU : f≤k) (flow : 10*p-3*k-30≤5*f)
    (lower : k^2+k*f-14*k≤2*h)
    (ordinary : 6*(h-7*(k+s))≤(k+s)^2+3*p^2)
    (exclusive : 224*(h-7*(k+s))≤(8*(k+s-2*p-t)-6*(k-f))^2+28*(k-f)^2+224*t*(k+s-t))
    (individual : 4*(h-10*(k+s))≤(max 0 (2*s-4*p+f))^2+4*p*(k+s-p)) :
    False := by
  have ks := mul_nonneg (show 0≤k by omega) (show 0≤k-100000 by omega)
  have kf : 0≤k*f := mul_nonneg (by omega) hf
  have db : 25*(k+s)^2≤81*k^2 := by
    nlinarith only [mul_nonneg (show 0≤4*k-5*s by omega) (show 0≤14*k+5*s by omega)]
  have flex := mul_nonneg (show 0≤k by omega) (show 0≤5*f-10*p+3*k+30 by omega)
  by_cases small : 40*p≤7*k
  · by_cases fbig : k≤8*f
    · have pp : 1600*p^2≤49*k^2 := by
        nlinarith only [mul_nonneg (show 0≤7*k-40*p by omega) (show 0≤7*k+40*p by omega)]
      have ff := mul_nonneg (show 0≤k by omega) (show 0≤8*f-k by omega)
      nlinarith only [lower,ordinary,pp,ff,ks,db,hsU,hk]
    · let z := 8*(k+s-2*p-t)-6*(k-f)
      let w := 42*k+30*f-120*t
      have bs : 25*z^2≤w^2 := by
        have z0 : 0≤z := by dsimp [z]; omega
        have zs : 5*z≤w := by dsimp [z,w]; omega
        nlinarith only [mul_nonneg (show 0≤w-5*z by omega) (show 0≤w+5*z by omega)]
      have fs : (k-f)^2≤k^2 := by
        nlinarith only [mul_nonneg hf (show 0≤2*k-f by omega)]
      have ts : 5*t*(k+s)≤9*k*t := by
        nlinarith only [mul_nonneg ht (show 0≤4*k-5*s by omega)]
      have tt : 1600*t^2≤49*k^2 := by
        nlinarith only [mul_nonneg (show 0≤7*k-40*t by omega) (show 0≤7*k+40*t by omega)]
      have ff : 8*f^2≤k*f := by
        nlinarith only [mul_nonneg hf (show 0≤k-8*f by omega)]
      have ft : 0≤f*t := mul_nonneg hf ht
      change 224*(h-7*(k+s))≤z^2+28*(k-f)^2+224*t*(k+s-t) at exclusive
      dsimp [w] at bs
      nlinarith only [exclusive,bs,fs,ts,tt,ff,ft,lower,ks,kf,hk,hsU]
  · by_cases high : 9*k≤20*p
    · have pp : 21*k^2≤2400*k*p-1200*p^2-816*k^2 := by
        nlinarith only [mul_nonneg (show 0≤20*p-9*k by omega) (show 0≤31*k-20*p by omega)]
      nlinarith only [lower,ordinary,pp,flex,db,ks,hk,hsU]
    · by_cases fbig : 3*k≤10*f
      · have pp : 400*p^2≤81*k^2 := by
          nlinarith only [mul_nonneg (show 0≤9*k-20*p by omega) (show 0≤9*k+20*p by omega)]
        have ff := mul_nonneg (show 0≤k by omega) (show 0≤10*f-3*k by omega)
        nlinarith only [lower,ordinary,pp,ff,db,ks,hk,hsU]
      · let q := max 0 (2*s-4*p+f)
        let v := 8*k-20*p+5*f
        have q0 : 0≤q := le_max_left _ _
        have vf : 0≤v := by dsimp [v]; omega
        have qv : 5*q≤v := by
          by_cases hh : 0≤2*s-4*p+f
          · dsimp [q,v]; rw [max_eq_right hh]; omega
          · dsimp [q,v]; rw [max_eq_left (by omega : 2*s-4*p+f≤0)]; omega
        have qsq : 25*q^2≤v^2 := by
          nlinarith only [mul_nonneg (show 0≤v-5*q by omega) (show 0≤v+5*q by omega)]
        have pt : 5*p*(k+s)≤9*k*p := by
          nlinarith only [mul_nonneg hp (show 0≤4*k-5*s by omega)]
        have ff : 10*f^2≤3*k*f := by
          nlinarith only [mul_nonneg hf (show 0≤3*k-10*f by omega)]
        change 4*(h-10*(k+s))≤q^2+4*p*(k+s-p) at individual
        dsimp [v] at qsq
        have upper :
            200*h≤128*k^2-280*k*p+600*p^2+(175*k-400*p)*f+2000*(k+s) := by
          nlinarith only [individual,qsq,pt,ff]
        -- Subtract 100 times the spacing lower bound: the residual
        -- coefficient of f is 75k−400p.
        by_cases sign : 0≤75*k-400*p
        · have bound := mul_nonneg sign (show 0≤3*k-10*f by omega)
          have pp : 160*(300*p^2-200*k*p)+4130*k^2≤0 := by
            nlinarith only [mul_nonneg (show 0≤40*p-7*k by omega)
              (show 0≤590*k-1200*p by omega)]
          nlinarith only [upper,lower,bound,pp,ks,hk,hsU]
        · by_cases med : 10*p≤3*k
          · have bound := mul_nonneg hf (show 0≤400*p-75*k by omega)
            have pp : 14*k^2-140*k*p+300*p^2≤-k^2 := by
              nlinarith only [mul_nonneg (show 0≤3*k-10*p by omega)
                (show 0≤30*p-5*k by omega)]
            nlinarith only [upper,lower,bound,pp,ks,hk,hsU]
          · have bound := mul_nonneg (show 0≤400*p-75*k by omega)
              (show 0≤5*f-10*p+3*k+30 by omega)
            have pp : -17*k^2+110*k*p-200*p^2≤-2*k^2 := by
              nlinarith only [mul_nonneg (show 0≤10*p-3*k by omega)
                (show 0≤20*p-5*k by omega)]
            nlinarith only [upper,lower,bound,pp,ks,hk,hsU,high]

#print axioms mixed_contradiction
end Graffiti189LongestPath.FiveNinthsMixedNumeric
