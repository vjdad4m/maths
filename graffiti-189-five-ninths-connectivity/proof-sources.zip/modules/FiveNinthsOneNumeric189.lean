import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

namespace Graffiti189LongestPath.FiveNinthsOneNumeric

theorem one_side_contradiction
    (k s p c m f h : ℤ) (hk : 100000≤k) (hsL : 2*k≤3*s) (hsU : 5*s≤4*k)
    (hcL : k-3≤2*c) (hcU : 5*c≤4*k)
    (hmL : k-3≤2*m) (hmU : 2*m≤k)
    (hf0 : 0≤f) (hfU : f≤k) (hf : k-s-c+2*p-6≤f)
    (hflex : (k+1)*(m+1)+f*(m-2)≤h+2*s+2*(m-2))
    (hcap : 4*h≤(k+s+2-c)^2+4*c*p+8*(k+s)) : False := by
  have low : k^2-1+f*(k-7)≤2*h+4*s+2*k := by
    nlinarith only [hflex, hmU,
      mul_nonneg (show 0≤k+1 by omega) (show 0≤2*m-k+3 by omega),
      mul_nonneg hf0 (show 0≤2*m-k+3 by omega)]
  have pterm : 4*c*p≤2*c*(f+s+c-k+6) := by
    nlinarith only [mul_nonneg (show 0≤c by omega) (show 0≤f+s+c-k+6-2*p by omega)]
  have flow : 5*c*f≤4*k*f := by
    nlinarith only [mul_nonneg hf0 (show 0≤4*k-5*c by omega)]
  have cs : 5*c*s≤4*k*c := by
    nlinarith only [mul_nonneg (show 0≤c by omega) (show 0≤4*k-5*s by omega)]
  have square0 : 25*(k+s+2-c)^2≤(9*k+10-5*c)^2 := by
    nlinarith only [mul_nonneg (show 0≤4*k-5*s by omega)
      (show 0≤14*k+5*s+20-10*c by omega)]
  have quad : 324*k^2-400*k*c+300*c^2≤199*k^2+375*k-450*c := by
    nlinarith only [mul_nonneg (show 0≤2*c-k+3 by omega)
      (show 0≤5*k-6*c by omega)]
  have kf : 0≤k*f := mul_nonneg (by omega) hf0
  have margin := mul_nonneg (show 0≤k by omega) (show 0≤k-100000 by omega)
  nlinarith only [low,pterm,flow,cs,square0,quad,kf,margin,hk,hfU,hcU,hcL,hcap,hsU]

#print axioms one_side_contradiction
end Graffiti189LongestPath.FiveNinthsOneNumeric
