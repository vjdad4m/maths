import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

namespace Graffiti189LongestPath.FiveNinthsReserve

theorem individual_missed_port_shell_bound
    (a b c e h k s p t jC jE qC qE f : ℤ)
    (an : 0≤a) (bn : 0≤b) (tn : 0≤t) (tp : t≤p) (ps : p≤s)
    (sn : s≤k) (fu : f≤k) (don : a+b+t≤k+s)
    (jnC : 0≤jC) (jnE : 0≤jE)
    (reachC : a+p+qC≤c+3) (reachE : b+p+qE≤e+3)
    (missC : qC+p≤s+3) (missE : qE+p≤s+3) (missing : k≤f+qC+qE)
    (mass : h+a*a+b*b+(a+b)*(p+t)+t*t+(a*e+b*c+a*jC+b*jE)
      ≤ (k+s+2)*(a+b)+(k+s+1)*t+2*(k+s)) :
    4*(h-10*(k+s))≤(max 0 (2*s-4*p+f))^2+4*p*(k+s-p) := by
  have c0 : a+k-s+2*p-f-6≤c := by omega
  have e0 : b+k-s+2*p-f-6≤e := by omega
  let u := a+b
  let d := k+s
  have raw : h-10*d≤u*(2*s-3*p-t+f)-u^2+t*(d-t) := by
    have cterm := mul_nonneg bn (show 0≤c-(a+k-s+2*p-f-6) by omega)
    have eterm := mul_nonneg an (show 0≤e-(b+k-s+2*p-f-6) by omega)
    have jc := mul_nonneg an jnC
    have je := mul_nonneg bn jnE
    have slack : 8*(a+b)+t+2*(k+s)≤10*(k+s) := by omega
    dsimp [u,d]
    nlinarith only [mass,cterm,eterm,jc,je,slack]
  let q := max 0 (2*s-4*p+f)
  let r := max 0 (2*s-3*p-t+f)
  have qr : q≤r := max_le_max_left 0 (by omega)
  have q0 : 0≤q := le_max_left _ _
  have r0 : 0≤r := le_max_left _ _
  have rq : r≤q+(p-t) := by
    have e : 2*s-4*p+f≤q := le_max_right _ _
    apply max_le
    · omega
    · omega
  have est : 4*(h-10*d)≤r^2+4*t*(d-t) := by
    have e : 2*s-3*p-t+f≤r := le_max_right _ _
    have a0 : 0≤u := add_nonneg an bn
    nlinarith only [raw, sq_nonneg (2*u-r), mul_nonneg a0 (show 0≤r-(2*s-3*p-t+f) by omega)]
  have qs : r^2≤(q+(p-t))^2 := by
    nlinarith only [mul_nonneg (show 0≤q+(p-t)-r by omega) (show 0≤q+(p-t)+r by omega)]
  have bound : 2*q+p-t≤4*(d-p-t) := by
    by_cases hq : 0≤2*s-4*p+f
    · dsimp [q,d]
      rw [max_eq_right hq]
      omega
    · dsimp [q,d]
      rw [max_eq_left (by omega : 2*s-4*p+f≤0)]
      omega
  have gain := mul_nonneg (show 0≤p-t by omega) (show 0≤4*(d-p-t)-(2*q+p-t) by omega)
  change 4*(h-10*d)≤q^2+4*p*(d-p)
  nlinarith only [est,qs,gain]

#print axioms individual_missed_port_shell_bound
end Graffiti189LongestPath.FiveNinthsReserve
