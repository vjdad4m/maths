#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")" && pwd)"
obj="$(mktemp -d)"
trap 'rm -rf "$obj"' EXIT
echo '== FiveNinthsCombined189 =='
lean -j1 -DElab.async=false -DwarningAsError=true --root="$root" -o "$obj/FiveNinthsCombined189.olean" "$root/FiveNinthsCombined189.lean"
