import HookRetarget189
import QuadraticDeficitAll189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.HookRetarget Graffiti189LongestPath.FanRoutable Graffiti189LongestPath.Rigidity
open private Graffiti189LongestPath.boundary_card_of_connectivity from SmallSeparator189
set_option warningAsError true
set_option maxHeartbeats 4700000
namespace Graffiti189LongestPath.FlexMissTwice
variable {V : Type*} [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem ports_missing_or_flexible (k : Nat) {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    (A B C E : Finset V)
    (closed : ∀ u∈A,∀ v∉A,G.Adj u v → v∈B)
    (ao : ∀ z∈A,z∉p.support)
    (F : HookFamily p A k) :
    let flex := (univ : Finset (Fin k)).filter (fun i =>
      (∃ u∈C,G.Adj u (fromFamily F i).firstPort) ∧
        ∃ v∈E,G.Adj v (fromFamily F i).firstPort)
    k≤flex.card+(B.filter (fun z => ¬∃ u∈C,G.Adj u z)).card+
      (B.filter (fun z => ¬∃ v∈E,G.Adj v z)).card := by
  classical
  let U := B.filter (fun b => ∃ u∈C,G.Adj u b)
  let V' := B.filter (fun b => ∃ v∈E,G.Adj v b)
  let miss := (B\U)∪(B\V')
  have mc : B\U=B.filter (fun z => ¬∃ u∈C,G.Adj u z) := by
    ext z
    simp only [mem_sdiff,mem_filter,U]
    exact ⟨fun h => ⟨h.1,fun e => h.2 ⟨h.1,e⟩⟩, fun h => ⟨h.1,fun e => h.2 e.2⟩⟩
  have me : B\V'=B.filter (fun z => ¬∃ v∈E,G.Adj v z) := by
    ext z
    simp only [mem_sdiff,mem_filter,V']
    exact ⟨fun h => ⟨h.1,fun e => h.2 ⟨h.1,e⟩⟩, fun h => ⟨h.1,fun e => h.2 e.2⟩⟩
  have bound : miss.card≤(B\U).card+(B\V').card := card_union_le _ _
  let f (i : Fin k) := (fromFamily F i).firstPort
  let good (i : Fin k) := (∃ u∈C,G.Adj u (f i))∧(∃ v∈E,G.Adj v (f i))
  let ok := (univ:Finset (Fin k)).filter good
  let bad := (univ:Finset (Fin k))\ok
  have bridge : bad.image f⊆miss := by
    intro v hv
    obtain ⟨i,hi,rfl⟩ := mem_image.mp hv
    have fb : f i∈B := first_port_mem_boundary (fromFamily F i) ao closed
    have noG : ¬good i := fun e => (mem_sdiff.mp hi).2 (mem_filter.mpr ⟨mem_univ _,e⟩)
    by_cases fu : f i∈U
    · exact mem_union.mpr (Or.inr (mem_sdiff.mpr ⟨fb,fun e =>
        noG ⟨(mem_filter.mp fu).2,(mem_filter.mp e).2⟩⟩))
    · exact mem_union.mpr (Or.inl (mem_sdiff.mpr ⟨fb,fu⟩))
  have bb := card_le_card bridge
  have fi : Function.Injective f := family_first_ports_injective hp F
  rw [card_image_of_injective _ fi] at bb
  have add := card_sdiff_add_card_eq_card (subset_univ ok)
  rw [card_univ,Fintype.card_fin] at add
  change bad.card+ok.card=k at add
  change k≤ok.card+_+_
  rw [←mc,←me]
  omega

#print axioms ports_missing_or_flexible
end Graffiti189LongestPath.FlexMissTwice
