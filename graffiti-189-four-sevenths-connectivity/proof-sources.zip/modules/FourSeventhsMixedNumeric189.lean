import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

namespace Graffiti189LongestPath.FourSeventhsMixedNumeric

theorem spacing_lower (k s m f h : ℤ) (hk : 1≤k) (hs : 4*s≤3*k)
    (hmL : k-3≤2*m) (hmU : 2*m≤k) (hf0 : 0≤f) (hfU : f≤k)
    (hflex : (k+1)*(m+1)+f*(m-2)≤h+2*s+2*(m-2)) :
    k^2+k*f-13*k≤2*h := by
  nlinarith only [hflex,hk,hs,hmU,hfU,
    mul_nonneg (show 0≤k+1 by omega) (show 0≤2*m-k+3 by omega),
    mul_nonneg hf0 (show 0≤2*m-k+3 by omega)]

theorem mixed_contradiction (k d p t f h : ℤ) (hk : 10000≤k)
    (hdL : 5*k≤3*d) (hdU : 4*d+4000≤7*k)
    (_hp : 0≤p) (hpU : 4*p≤3*k) (ht : 0≤t) (tp : t≤p)
    (hf : 0≤f) (_hfU : f≤k) (flow : 4*p-k-12≤2*f)
    (lower : k^2+k*f-13*k≤2*h)
    (ordinary : 6*(h-7*d)≤d^2+3*p^2)
    (flank : 6*(h-7*d)≤d^2-2*d*p+13*p^2)
    (exclusive : 224*(h-7*d)≤(8*(d-2*p-t)-6*(k-f))^2+28*(k-f)^2+224*t*(d-t)) :
    False := by
  have ks := mul_nonneg (show 0≤k by omega) (show 0≤k-10000 by omega)
  have kf : 0≤k*f := mul_nonneg (by omega) hf
  have db : 16*d^2≤49*k^2 := by
    nlinarith only [mul_nonneg (show 0≤7*k-4*d by omega) (show 0≤7*k+4*d by omega)]
  have flex := mul_nonneg (show 0≤k by omega) (show 0≤2*f-4*p+k+12 by omega)
  by_cases small : 32*p≤k
  · by_cases fbig : k≤20*f
    · have pp : 48*p^2≤k^2 := by
        nlinarith only [mul_nonneg (show 0≤k-32*p by omega) (show 0≤k+32*p by omega),
          sq_nonneg p]
      have ff := mul_nonneg (show 0≤k by omega) (show 0≤20*f-k by omega)
      nlinarith only [lower,ordinary,pp,ff,ks,db,hdU,hk]
    · let b := 8*(d-2*p-t)-6*(k-f)
      have bs : 100*b^2≤6889*k^2 := by
        have bpos : 0≤b := by dsimp [b]; omega
        have bsmall : 10*b≤83*k := by dsimp [b]; omega
        nlinarith only [mul_nonneg (show 0≤83*k-10*b by omega) (show 0≤83*k+10*b by omega)]
      have fs : (k-f)^2≤k^2 := by
        nlinarith only [mul_nonneg hf (show 0≤2*k-f by omega)]
      have ts : 224*t*(d-t)≤13*k^2 := by
        have v1 := mul_nonneg ht (show 0≤7*k-4*d by omega)
        have v2 := mul_nonneg (show 0≤k by omega) (show 0≤k-32*t by omega)
        nlinarith only [v1,v2,sq_nonneg t,sq_nonneg k]
      change 224*(h-7*d)≤b^2+28*(k-f)^2+224*t*(d-t) at exclusive
      nlinarith only [exclusive,bs,fs,ts,lower,ks,kf,hk,hdU]
  · have reduction : 16*(d^2-2*d*p+13*p^2)+16000*k≤49*k^2-56*k*p+208*p^2 := by
      have e := mul_nonneg (show 0≤7*k-4*d-4000 by omega)
        (show 0≤7*k+4*d-8*p by omega)
      have q : 4*k≤7*k+4*d-8*p := by omega
      nlinarith only [e,q]
    by_cases mid : 4*p≤k
    · have pp : 49*k^2-56*k*p+208*p^2≤48*k^2 := by
        nlinarith only [mul_nonneg (show 0≤k-4*p by omega) (show 0≤52*p-k by omega)]
      nlinarith only [lower,flank,reduction,pp,kf,hk,hdU]
    · by_cases hi : 3*p≤k
      · have pp : 49*k^2-56*k*p+208*p^2≤24*k^2+96*k*p := by
          nlinarith only [mul_nonneg (show 0≤4*p-k by omega) (show 0≤25*k-52*p by omega)]
        nlinarith only [lower,flank,reduction,pp,flex,hk,hdU]
      · have pp : 3*(24*k^2+96*k*p-(49*k^2+48*p^2))≥5*k^2 := by
          nlinarith only [mul_nonneg (show 0≤3*p-k by omega) (show 0≤5*k-3*p by omega)]
        nlinarith only [lower,ordinary,pp,flex,db,ks,hk,hdU]

#print axioms mixed_contradiction
end Graffiti189LongestPath.FourSeventhsMixedNumeric
