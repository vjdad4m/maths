import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

namespace Graffiti189LongestPath.FourSeventhsOneNumeric

/-- The smaller-side missing-port estimate eliminates both one-sided donor
branches, including the regime where the generic hook estimate is weak. -/
theorem one_side_contradiction
    (k s p c m f h : ℤ) (hk : 10000≤k) (hsL : 2*k≤3*s) (hsU : 4*s≤3*k)
    (hcL : k-3≤2*c) (hcU : 4*c≤3*k)
    (hmL : k-3≤2*m) (hmU : 2*m≤k)
    (hf0 : 0≤f) (hfU : f≤k) (hf : k-s-c+2*p-6≤f)
    (hflex : (k+1)*(m+1)+f*(m-2)≤h+2*s+2*(m-2))
    (hcap : 4*h≤(k+s+2-c)^2+4*c*p+8*(k+s)) : False := by
  have low : k^2-1+f*(k-7)≤2*h+4*s+2*k := by
    nlinarith only [hflex, hmU,
      mul_nonneg (show 0≤k+1 by omega) (show 0≤2*m-k+3 by omega),
      mul_nonneg hf0 (show 0≤2*m-k+3 by omega)]
  have pterm : 4*c*p≤2*c*(f+s+c-k+6) := by
    nlinarith only [mul_nonneg (show 0≤c by omega) (show 0≤f+s+c-k+6-2*p by omega)]
  have flow : 4*c*f≤3*k*f := by
    nlinarith only [mul_nonneg hf0 (show 0≤3*k-4*c by omega)]
  have cs : 4*c*(s+c-k)≤3*k*(s+c-k) := by
    nlinarith only [mul_nonneg (show 0≤s+c-k by omega) (show 0≤3*k-4*c by omega)]
  have square0 : 16*(k+s+2-c)^2≤(7*k+8-4*c)^2 := by
    nlinarith only [mul_nonneg (show 0≤3*k-4*s by omega)
      (show 0≤11*k+4*s+16-8*c by omega)]
  have sq1 : 4*(k-c)^2≤(k+3)^2 := by
    nlinarith only [mul_nonneg (show 0≤2*c-k+3 by omega)
      (show 0≤3*k-2*c+3 by omega)]
  have ks : 4*k*s≤3*k^2 := by
    nlinarith only [mul_nonneg (show 0≤k by omega) (show 0≤3*k-4*s by omega)]
  have kf : 0≤k*f := mul_nonneg (by omega) hf0
  have margin := mul_nonneg (show 0≤k by omega) (show 0≤k-10000 by omega)
  nlinarith only [low,pterm,flow,cs,square0,sq1,ks,kf,margin,hk,hfU,hcU,hcap,hsU]

#print axioms one_side_contradiction
end Graffiti189LongestPath.FourSeventhsOneNumeric
