import StrongDonorDegree189
import MixedReserve189
import FlexibleShellArithmetic189
import FlexSplitShell189

open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack Graffiti189LongestPath.PinRun
open Graffiti189LongestPath.ShellDonorFull Graffiti189LongestPath.StrongDonorDegree
open Graffiti189LongestPath.StrongDonorCharge Graffiti189LongestPath.MixedReserve
open Graffiti189LongestPath.FlexibleShellArithmetic
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
open private Graffiti189LongestPath.pin_data Graffiti189LongestPath.mem_distanceTwo from SmallSeparator189
open private Graffiti189LongestPath.OneSlack.card_pinVertices from OneSlack189
open private Graffiti189LongestPath.FlexSplitShell.count_group from FlexSplitShell189
set_option maxHeartbeats 9000000

namespace Graffiti189LongestPath.FourSeventhsShell

variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]
variable {a b x : V} {p : G.Walk a b}

/-- The old third-shell dichotomy, with the stronger pin and missed-port
charges in the case where both split sides have high donors. -/
theorem stronger_split_shell_three (hc : G.Connected) (d k f mF : Nat)
    (hp : IsLongest p) (hx : x∉p.support)
    (gap : (Pins p x).card≤(FirstPins p x).card+1)
    (cap : ∀ v,(DistanceTwo G v).card≤d) (C E W X : Finset V)
    (shore : OmittedStar p x=C∪E∪X)
    (partition : C∪E∪(PinVertices p x)∪W=G.neighborFinset x)
    (deg : ∀ u v : V,u≠v → d≤G.degree u ∨ d≤G.degree v)
    (ce : Disjoint C E) (dcx : Disjoint C X) (dex : Disjoint E X)
    (cp : Disjoint C (PinVertices p x)) (ep : Disjoint E (PinVertices p x))
    (no : ∀ u∈C,∀ v∈E,¬G.Adj u v)
    (cs : mF≤C.card) (es : mF≤E.card) (md : mF≤d+2)
    (ws : W.card≤1) (xs : X.card≤2) (xx : x∈X)
    (bk : (External G (OmittedStar p x)).card+(Pins p x).card≤d+1)
    (reaches : k≤f+
      ((External G (OmittedStar p x)).filter (fun z => ¬∃ u∈C,G.Adj u z)).card+
      ((External G (OmittedStar p x)).filter (fun z => ¬∃ u∈E,G.Adj u z)).card) :
    let h := (Shell G x 3).card
    let pp := (Pins p x).card
    (4*h≤(d+2-mF)*(d+2-mF)+4*(mF*pp)+8*d) ∨
      ∃ t : Nat, t≤pp ∧
        (6*((h:ℤ)-7*(d:ℤ))≤(d:ℤ)^2+3*(pp:ℤ)^2) ∧
        (6*((h:ℤ)-7*(d:ℤ))≤(d:ℤ)^2-2*(d:ℤ)*(pp:ℤ)+13*(pp:ℤ)^2) ∧
        (224*((h:ℤ)-7*(d:ℤ))≤(8*((d:ℤ)-2*(pp:ℤ)-(t:ℤ))-6*((k:ℤ)-(f:ℤ)))^2+
          28*((k:ℤ)-(f:ℤ))^2+224*(t:ℤ)*((d:ℤ)-(t:ℤ))) := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let P := PinVertices p x
  let pp := (Pins p x).card
  let H := Shell G x 3
  let F := gateThird G x (DistanceTwo G x)
  obtain ⟨D,DA,cover,privateGate,every⟩ := exists_shell_donors_with_private_charges hc d cap x
  let C' := (D∩C).filter (fun v => d≤G.degree v)
  let E' := (D∩E).filter (fun v => d≤G.degree v)
  let P' := D∩P
  let D₀ := C'∪E'
  let R := D\(D₀∪P')
  let nC := C'.card
  let nE := E'.card
  let t := P'.card
  let jC := nC+nE+2*pp-(C.card+3)
  let jE := nC+nE+2*pp-(E.card+3)
  let mC := (B.filter (fun z => ¬∃ u∈C,G.Adj u z)).card
  let mE := (B.filter (fun z => ¬∃ u∈E,G.Adj u z)).card
  have cD (z : V) (hz : z∈C') : z∈D ∧ z∈C ∧ d≤G.degree z := by
    obtain ⟨both,high⟩ := mem_filter.mp hz
    obtain ⟨hD,hC⟩ := mem_inter.mp both
    exact ⟨hD,hC,high⟩
  have eD (z : V) (hz : z∈E') : z∈D ∧ z∈E ∧ d≤G.degree z := by
    obtain ⟨both,high⟩ := mem_filter.mp hz
    obtain ⟨hD,hE⟩ := mem_inter.mp both
    exact ⟨hD,hE,high⟩
  have cc' : C'⊆C := fun z h => (cD z h).2.1
  have ee' : E'⊆E := fun z h => (eD z h).2.1
  have cA : C⊆A := by
    intro u h
    change u∈OmittedStar p x
    rw [shore]
    exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inl h)))
  have eA : E⊆A := by
    intro u h
    change u∈OmittedStar p x
    rw [shore]
    exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inr h)))
  have dA : D₀⊆A := union_subset (cc'.trans cA) (ee'.trans eA)
  have dD : D₀⊆D := union_subset (fun z h => (cD z h).1) (fun z h => (eD z h).1)
  have ce' : Disjoint C' E' := disjoint_left.mpr (fun _ u v => disjoint_left.mp ce (cc' u) (ee' v))
  have cardD₀ : D₀.card=nC+nE := card_union_of_disjoint ce'
  have xD₀ : x∉D₀ := fun h => (mem_union.mp h).elim
    (fun e => disjoint_left.mp dcx (cc' e) xx) (fun e => disjoint_left.mp dex (ee' e) xx)
  have dP' : Disjoint D₀ P' := disjoint_left.mpr (fun _ dz pz => (mem_union.mp dz).elim
    (fun q => disjoint_left.mp cp (cc' q) (mem_inter.mp pz).2)
    (fun q => disjoint_left.mp ep (ee' q) (mem_inter.mp pz).2))
  have dsub : D₀∪P'⊆D := union_subset dD inter_subset_left
  have cardD := card_sdiff_add_card_eq_card dsub
  rw [card_union_of_disjoint dP',cardD₀] at cardD
  change R.card+(nC+nE+t)=D.card at cardD
  have tn : t≤pp := (card_le_card (inter_subset_right : P'⊆P)).trans
    (le_of_eq (Graffiti189LongestPath.OneSlack.card_pinVertices hp (x:=x)))
  have closed (u : V) (ua : u∈A) (z : V) (za : z∉A) (uz : G.Adj u z) : z∈B :=
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨za,u,ua,uz⟩
  have rep₀ (u : V) : ∃ g,u∈D → g∈DistanceTwo G x ∧ G.Adj u g ∧
      ∀ w∈D,w≠u → ¬G.Adj w g := by
    by_cases h : u∈D
    · obtain ⟨g,gg,ug,bad⟩ := privateGate u h
      exact ⟨g,fun _ => ⟨gg,ug,bad⟩⟩
    · exact ⟨x,fun e => (h e).elim⟩
  choose rep priv using rep₀
  have repr (u : V) (ud : u∈D₀) : rep u∈B := by
    have rd := Graffiti189LongestPath.mem_distanceTwo.mp (priv u (dD ud)).1
    have na : rep u∉A := by
      intro e
      rcases (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp e).2 with h|h
      · rw [h,dist_self] at rd; omega
      · have h' := dist_eq_one_iff_adj.mpr h; omega
    exact closed u (dA ud) (rep u) na (priv u (dD ud)).2.1
  have inj : Set.InjOn rep (↑D:Set V) := by
    intro u ud v vd e
    apply Classical.byContradiction
    intro ne
    exact (priv v vd).2.2 u ud ne (e ▸ (priv u ud).2.1)
  have allD : (D.image rep)⊆DistanceTwo G x := by
    intro z zz
    obtain ⟨u,ud,rfl⟩ := mem_image.mp zz
    exact (priv u ud).1
  have cardDon : D.card≤d := by
    have e := (card_le_card allD).trans (cap x)
    rw [card_image_of_injOn inj] at e
    exact e
  have vp : ∀ u∈D₀,rep u∈DistanceTwo G x ∧ G.Adj u (rep u) ∧
      ∀ w∈D₀,w≠u → ¬G.Adj w (rep u) := by
    intro u ud
    obtain ⟨a,b,c⟩ := priv u (dD ud)
    exact ⟨a,b,fun w wd ne => c w (dD wd) ne⟩
  have remainder : R.card≤2 := by
    let L := univ.filter (fun z : V => G.degree z<d)
    have rsub : R⊆W∪L := by
      intro z rz
      obtain ⟨zd,r⟩ := mem_sdiff.mp rz
      have zo : z∈C∪E∪P∪W := partition.symm ▸ DA zd
      rcases mem_union.mp zo with zce|zw
      · rcases mem_union.mp zce with zz|zp
        · by_cases zhigh : d≤G.degree z
          · exfalso
            apply r
            apply mem_union.mpr
            left
            rcases mem_union.mp zz with zc|ze
            · exact mem_union.mpr (Or.inl (mem_filter.mpr ⟨mem_inter.mpr ⟨zd,zc⟩,zhigh⟩))
            · exact mem_union.mpr (Or.inr (mem_filter.mpr ⟨mem_inter.mpr ⟨zd,ze⟩,zhigh⟩))
          · exact mem_union.mpr (Or.inr (mem_filter.mpr ⟨mem_univ _,by omega⟩))
        · exact (r (mem_union.mpr (Or.inr (mem_inter.mpr ⟨zd,zp⟩)))).elim
      exact mem_union.mpr (Or.inl zw)
    have sl : L.card≤1 := by
      apply Nat.le_of_not_gt
      intro h
      obtain ⟨u,uu,v,vv,ne⟩ := one_lt_card.mp (show 1<L.card from h)
      have uo := (mem_filter.mp uu).2
      have vo := (mem_filter.mp vv).2
      exact (deg u v ne).elim (Nat.not_le_of_lt uo) (Nat.not_le_of_lt vo)
    have eq := (card_le_card rsub).trans (card_union_le W L)
    omega
  have shoreE : A=E∪C∪X := by rw [union_comm E C]; exact shore
  have noE (v : V) (ve : v∈E) (u : V) (uc : u∈C) : ¬G.Adj v u := fun z => no u uc v ve z.symm
  have HB_C (v : V) (vv : v∈C') :
      (F v).card+nC+E.card+pp+jC≤d+2 := by
    have vd : v∈D₀ := mem_union.mpr (Or.inl vv)
    have uc := donor_degree_all_private_and_missing_pins d hp hx C E X D₀
      shore xs cA dA no bk v ((cD v vv).2.1) vd (cD v vv).2.2 rep vp
    have sc := omitted_donor_strong_charge hc d cap hp hx gap D₀ (E\D₀) dA xD₀
      (fun _ e => eA (mem_sdiff.mp e).1)
      (fun e => disjoint_left.mp dex (mem_sdiff.mp e).1 xx)
      (disjoint_left.mpr (fun _ z h => (mem_sdiff.mp h).2 z)) v vd
      (fun z zq => no v ((cD v vv).2.1) z (mem_sdiff.mp zq).1) rep vp
    have is : E∩D₀=E' := by
      ext z
      constructor
      · intro e
        obtain ⟨hR,hd⟩ := mem_inter.mp e
        rcases mem_union.mp hd with hC|hE
        · exact (disjoint_left.mp ce (cc' hC) hR).elim
        · exact hE
      · intro e
        exact mem_inter.mpr ⟨ee' e, mem_union.mpr (Or.inr e)⟩
    have e := card_sdiff_add_card_inter E D₀
    rw [is] at e
    change (E\D₀).card+nE=E.card at e
    let j := ((Pins p x).filter (fun i => G.Adj v (p.getVert i))).card
    change D₀.card+2*pp≤C.card+j+3 at uc
    change (F v).card+D₀.card+(E\D₀).card+pp+j≤d+2 at sc
    have jj : jC≤j := by dsimp [jC]; omega
    omega
  have HB_E (v : V) (vv : v∈E') :
      (F v).card+nE+C.card+pp+jE≤d+2 := by
    have vd : v∈D₀ := mem_union.mpr (Or.inr vv)
    have uc := donor_degree_all_private_and_missing_pins d hp hx E C X D₀
      shoreE xs eA dA noE bk v ((eD v vv).2.1) vd (eD v vv).2.2 rep vp
    have sc := omitted_donor_strong_charge hc d cap hp hx gap D₀ (C\D₀) dA xD₀
      (fun _ e => cA (mem_sdiff.mp e).1)
      (fun e => disjoint_left.mp dcx (mem_sdiff.mp e).1 xx)
      (disjoint_left.mpr (fun _ z h => (mem_sdiff.mp h).2 z)) v vd
      (fun z zq => noE v ((eD v vv).2.1) z (mem_sdiff.mp zq).1) rep vp
    have is : C∩D₀=C' := by
      ext z
      constructor
      · intro e
        obtain ⟨hR,hd⟩ := mem_inter.mp e
        rcases mem_union.mp hd with hC|hE
        · exact hC
        · exact (disjoint_left.mp ce hR (ee' hE)).elim
      · intro e
        exact mem_inter.mpr ⟨cc' e, mem_union.mpr (Or.inl e)⟩
    have e := card_sdiff_add_card_inter C D₀
    rw [is] at e
    change (C\D₀).card+nC=C.card at e
    let j := ((Pins p x).filter (fun i => G.Adj v (p.getVert i))).card
    change D₀.card+2*pp≤E.card+j+3 at uc
    change (F v).card+D₀.card+(C\D₀).card+pp+j≤d+2 at sc
    have jj : jE≤j := by dsimp [jE]; omega
    omega
  have hpin (v : V) (vp : v∈P') : (F v).card+nC+nE+t≤d+1 := by
    have h := every v (mem_inter.mp vp).1 (∅:Finset V) (empty_subset _) (by simp)
    rw [empty_sdiff,card_empty,add_zero] at h
    have e : 0<D.card := card_pos.mpr ⟨v,(mem_inter.mp vp).1⟩
    change (F v).card+(D.card-1)≤d at h
    omega
  have hr (v : V) (vr : v∈R) : (F v).card≤d := by
    have h := every v (mem_sdiff.mp vr).1 (∅:Finset V) (empty_subset _) (by simp)
    rw [empty_sdiff,card_empty,add_zero] at h
    exact le_trans (Nat.le_add_right _ _) h
  let GC := C'.biUnion F
  let GE := E'.biUnion F
  let GP := P'.biUnion F
  let GR := R.biUnion F
  have sC : GC.card+nC*(nC+E.card+pp+jC)≤nC*(d+2) :=
    Graffiti189LongestPath.FlexSplitShell.count_group C' F _ _ (fun v vv => by have vbound := HB_C v vv; omega)
  have sE : GE.card+nE*(nE+C.card+pp+jE)≤nE*(d+2) :=
    Graffiti189LongestPath.FlexSplitShell.count_group E' F _ _ (fun v vv => by have vbound := HB_E v vv; omega)
  have sP : GP.card+t*(nC+nE+t)≤t*(d+1) :=
    Graffiti189LongestPath.FlexSplitShell.count_group P' F _ _ (by
      intro v vP
      have q := hpin v vP
      omega)
  have sR : GR.card≤2*d :=
    (card_biUnion_le_card_mul R F d hr).trans (Nat.mul_le_mul_right _ remainder)
  have hcover : H⊆GC∪GE∪GP∪GR := by
    intro z zh
    obtain ⟨v,vd,vz⟩ := mem_biUnion.mp (cover zh)
    by_cases dr : v∈D₀∪P'
    · rcases mem_union.mp dr with d0|pi
      · rcases mem_union.mp d0 with vc|ve
        · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inl (mem_union.mpr (Or.inl
            (mem_biUnion.mpr ⟨v,vc,vz⟩))))))
        · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inl (mem_union.mpr (Or.inr
            (mem_biUnion.mpr ⟨v,ve,vz⟩))))))
      · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inr (mem_biUnion.mpr ⟨v,pi,vz⟩))))
    · exact mem_union.mpr (Or.inr (mem_biUnion.mpr ⟨v,mem_sdiff.mpr ⟨vd,dr⟩,vz⟩))
  have total := card_le_card hcover
  have cg := card_union_le GC GE
  have pg := card_union_le (GC∪GE) GP
  have rg := card_union_le (GC∪GE∪GP) GR
  have sumN :
      H.card+nC*nC+nE*nE+(nC+nE)*(pp+t)+t*t+
        (nC*E.card+nE*C.card+nC*jC+nE*jE)≤(d+2)*(nC+nE)+(d+1)*t+2*d := by
    have e1 : nC*(nC+E.card+pp+jC)+nE*(nE+C.card+pp+jE)+t*(nC+nE+t)=
        nC*nC+nE*nE+(nC+nE)*(pp+t)+t*t+
          (nC*E.card+nE*C.card+nC*jC+nE*jE) := by ring
    have e2 : nC*(d+2)+nE*(d+2)+t*(d+1)=(d+2)*(nC+nE)+(d+1)*t := by ring
    omega
  have oneside (b c j : Nat) (c_le : mF≤c)
      (s : H.card+b*b+b*(pp+t)+t*t+(b*c+b*j)≤(d+2)*b+(d+1)*t+2*d) :
      4*H.card≤(d+2-mF)*(d+2-mF)+4*(mF*pp)+8*d := by
    let q := d+2-mF
    have qe : q+mF=d+2 := Nat.sub_add_cancel md
    have cos := Nat.mul_le_mul_left b c_le
    have bb := Nat.mul_le_mul_left b tn
    have td : (d+1)*t≤t*(d+2) := by
      rw [Nat.mul_comm (d+1) t]
      exact Nat.mul_le_mul_left t (by omega)
    have e1 : (b+t)*(b+t)=b*b+2*(b*t)+t*t := by ring
    have e2 : b*(pp+t)=b*pp+b*t := by ring
    have e3 : (b+t)*(q+mF)=(b+t)*q+b*mF+mF*t := by ring
    have e4 : (b+t)*(d+2)=(d+2)*b+t*(d+2) := by ring
    have eq : (b+t)*(q+mF)=(b+t)*(d+2) := congrArg (fun z => (b+t)*z) qe
    rw [e3,e4] at eq
    have mass : H.card+(b+t)*(b+t)≤(b+t)*q+mF*t+2*d := by omega
    exact one_shell_numeric H.card b t q mF pp d tn mass
  by_cases cempty : nC=0
  · left
    apply oneside nE C.card jE cs
    simpa [cempty, add_assoc] using sumN
  by_cases eempty : nE=0
  · left
    apply oneside nC E.card jC es
    simpa [eempty, add_assoc] using sumN
  right
  obtain ⟨u,uC⟩ := card_pos.mp (show 0<C'.card from Nat.pos_of_ne_zero cempty)
  obtain ⟨v,vE⟩ := card_pos.mp (show 0<E'.card from Nat.pos_of_ne_zero eempty)
  have mdC := donor_degree_all_private_and_missing_pins d hp hx C E X D₀
    shore xs cA dA no bk u ((cD u uC).2.1) (mem_union.mpr (Or.inl uC)) (cD u uC).2.2 rep vp
  have mdE := donor_degree_all_private_and_missing_pins d hp hx E C X D₀
    shoreE xs eA dA noE bk v ((eD v vE).2.1) (mem_union.mpr (Or.inr vE)) (eD v vE).2.2 rep vp
  have jpC : jC≤pp := by
    let j := ((Pins p x).filter (fun i => G.Adj u (p.getVert i))).card
    change D₀.card+2*pp≤C.card+j+3 at mdC
    have jb : j≤pp := card_filter_le _ _
    dsimp [jC]
    omega
  have jpE : jE≤pp := by
    let j := ((Pins p x).filter (fun i => G.Adj v (p.getVert i))).card
    change D₀.card+2*pp≤E.card+j+3 at mdE
    have jb : j≤pp := card_filter_le _ _
    dsimp [jE]
    omega
  have dc : nC+nE+2*pp≤C.card+jC+3 := by dsimp [jC]; omega
  have de : nC+nE+2*pp≤E.card+jE+3 := by dsimp [jE]; omega
  have rc := side_bound_with_missing_reach_and_private_ports d A B C E X C' shore xs cA no
    closed pp bk u ((cD u uC).2.1) uC (cD u uC).2.2 rep cc'
    (fun z zc => ⟨repr z (mem_union.mpr (Or.inl zc)),(priv z (cD z zc).1).2.1,
      fun w wc ne => (priv z (cD z zc).1).2.2 w (cD w wc).1 ne⟩)
  have re := side_bound_with_missing_reach_and_private_ports d A B E C X E' shoreE xs eA noE
    closed pp bk v ((eD v vE).2.1) vE (eD v vE).2.2 rep ee'
    (fun z ze => ⟨repr z (mem_union.mpr (Or.inr ze)),(priv z (eD z ze).1).2.1,
      fun w we ne => (priv z (eD z ze).1).2.2 w (eD w we).1 ne⟩)
  change nC+pp+mC≤C.card+3 at rc
  change nE+pp+mE≤E.card+3 at re
  change k≤f+mC+mE at reaches
  change B.card+pp≤d+1 at bk
  have pd : pp≤d := by
    have n : 0<B.card ∨ pp=0 := by
      rcases Nat.eq_zero_or_pos pp with z|z
      · exact Or.inr z
      · obtain ⟨i,ii⟩ := card_pos.mp z
        exact Or.inl (card_pos.mpr ⟨p.getVert i,
          (closed x (Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩) _
            (fun va => (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp va).1 (p.getVert_mem_support i))
            (Graffiti189LongestPath.pin_data ii).2)⟩)
    omega
  have donor : nC+nE+t≤d := by omega
  refine ⟨t,tn,?_⟩
  exact combined_mixed_bounds (nC:ℤ) (nE:ℤ) (C.card:ℤ) (E.card:ℤ) (H.card:ℤ)
    (d:ℤ) (pp:ℤ) (t:ℤ) (jC:ℤ) (jE:ℤ) (mC:ℤ) (mE:ℤ) (k:ℤ) (f:ℤ)
    (by omega) (by omega) (by omega) (by omega) (by omega)
    (by omega) (by omega) (by omega) (by omega) (by omega)
    (by omega) (by omega) (by omega) (by omega) (by omega)
    (by exact_mod_cast sumN)

#print axioms stronger_split_shell_three
end Graffiti189LongestPath.FourSeventhsShell
