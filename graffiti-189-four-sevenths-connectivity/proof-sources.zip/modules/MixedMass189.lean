import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

namespace Graffiti189LongestPath.MixedMass

theorem flank_bound (h d p t u v : ℤ) (pt : t≤p) (pd : p≤d)
    (mass : h≤u*(d-2*p-t)-2*u^2+t*(d-t)+2*v*(u-p)-2*v^2+7*d) :
    6*(h-7*d)≤d^2-2*d*p+13*p^2 := by
  have tcap : 6*(h-7*d)≤(d-3*p-t)^2+3*p^2+6*t*(d-t) := by
    nlinarith only [mass, sq_nonneg (2*v-u+p), sq_nonneg (3*u-d+3*p+t)]
  have dif := mul_nonneg (show 0≤p-t by omega) (show 0≤4*d-4*p+5*(p-t) by omega)
  nlinarith only [tcap,dif]

theorem exclusive_bound (h d p t u v k f : ℤ)
    (mass : h≤u*(d-2*p-t)-2*u^2+t*(d-t)+v*(3*u-k+f)-2*v^2+7*d) :
    224*(h-7*d)≤(8*(d-2*p-t)-6*(k-f))^2+28*(k-f)^2+224*t*(d-t) := by
  nlinarith only [mass,sq_nonneg (4*v-(3*u-k+f)),
    sq_nonneg (14*u-(8*(d-2*p-t)-6*(k-f)))]

theorem ordinary_bound (h d p t u v : ℤ) (pt : t≤p) (hd : 0≤d)
    (mass : h≤u*(d-p-2*t)-2*u^2+t*(d-t)+2*v*u-2*v^2+7*d) :
    6*(h-7*d)≤d^2+3*p^2 := by
  have tcap : 6*(h-7*d)≤(d-p-2*t)^2+6*t*(d-t) := by
    nlinarith only [mass, sq_nonneg (2*v-u), sq_nonneg (3*u-d+p+2*t)]
  have dif := mul_nonneg (show 0≤p-t by omega) (show 0≤2*d+2*(p-t) by omega)
  nlinarith only [tcap,dif]

#print axioms flank_bound
#print axioms exclusive_bound
#print axioms ordinary_bound
end Graffiti189LongestPath.MixedMass
