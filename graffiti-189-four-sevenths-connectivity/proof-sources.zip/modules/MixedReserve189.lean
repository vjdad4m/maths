import MixedMass189

namespace Graffiti189LongestPath.MixedReserve
open Graffiti189LongestPath.MixedMass

theorem combined_mixed_bounds
    (a b c e h d p t jC jE qC qE k f : ℤ)
    (an : 0≤a) (bn : 0≤b) (tn : 0≤t) (tp : t≤p) (pd : p≤d)
    (jnC : 0≤jC) (jpC : jC≤p) (jnE : 0≤jE) (jpE : jE≤p)
    (don : a+b+t≤d)
    (dc : a+b+2*p≤c+jC+3) (de : a+b+2*p≤e+jE+3)
    (reachC : a+p+qC≤c+3) (reachE : b+p+qE≤e+3) (missing : k≤f+qC+qE)
    (mass : h+a*a+b*b+(a+b)*(p+t)+t*t+(a*e+b*c+a*jC+b*jE)
      ≤ (d+2)*(a+b)+(d+1)*t+2*d) :
    (6*(h-7*d)≤d^2+3*p^2) ∧
    (6*(h-7*d)≤d^2-2*d*p+13*p^2) ∧
    (224*(h-7*d)≤(8*(d-2*p-t)-6*(k-f))^2+28*(k-f)^2+224*t*(d-t)) := by
  let u := a+b
  let v := min a b
  have vn : 0≤v := le_min an bn
  have va : v≤a := min_le_left _ _
  have vb : v≤b := min_le_right _ _
  have sq : a*a+b*b=u^2-2*v*u+2*v^2 := by
    dsimp [u,v]
    by_cases h : a≤b
    · rw [min_eq_left h]; ring
    · rw [min_eq_right (by omega : b≤a)]; ring
  have r₁ : u^2+u*p+2*v*p-3*u≤a*e+b*c+a*jC+b*jE := by
    have C := mul_nonneg bn (show 0≤c+jC+3-(a+b+2*p) by omega)
    have E := mul_nonneg an (show 0≤e+jE+3-(a+b+2*p) by omega)
    dsimp [u,v]
    by_cases hh : a≤b
    · rw [min_eq_left hh]
      have q := mul_nonneg (show 0≤b-a by omega) (show 0≤p-jC+jE by omega)
      nlinarith only [C,E,q]
    · rw [min_eq_right (by omega : b≤a)]
      have q := mul_nonneg (show 0≤a-b by omega) (show 0≤p-jE+jC by omega)
      nlinarith only [C,E,q]
  let xc := c+3-u-p
  let xe := e+3-u-p
  have xc0 : 0≤xc := by dsimp [xc,u]; omega
  have xe0 : 0≤xe := by dsimp [xe,u]; omega
  have nonj₁ := mul_nonneg an jnC
  have nonj₂ := mul_nonneg bn jnE
  have r₀ : u^2+u*p-3*u≤a*e+b*c+a*jC+b*jE := by
    have w := mul_nonneg vn (show 0≤p by omega)
    nlinarith only [w,r₁]
  have r₂ : u^2+u*p-3*u+v*(k-f-u)≤a*e+b*c+a*jC+b*jE := by
    have wc := mul_nonneg xc0 (show 0≤b-v by omega)
    have we := mul_nonneg xe0 (show 0≤a-v by omega)
    have w := mul_nonneg vn (show 0≤xc+xe-(k-f-u) by dsimp [xc,xe,u]; omega)
    dsimp [xc,xe,u] at wc we w ⊢
    nlinarith only [wc,we,w,nonj₁,nonj₂]
  have du : u+t≤d := don
  have un : 0≤u := add_nonneg an bn
  have z : 5*u+t+2*d≤7*d := by omega
  change h+a*a+b*b+u*(p+t)+t*t+(a*e+b*c+a*jC+b*jE)
    ≤ (d+2)*u+(d+1)*t+2*d at mass
  have base : h≤u*(d-p-2*t)-2*u^2+t*(d-t)+2*v*u-2*v^2+7*d := by
    have extra := mul_nonneg un (show 0≤p-t by omega)
    nlinarith only [mass,r₀,sq,z,extra]
  have mf : h≤u*(d-2*p-t)-2*u^2+t*(d-t)+2*v*(u-p)-2*v^2+7*d := by
    nlinarith only [mass,r₁,sq,z]
  have me : h≤u*(d-2*p-t)-2*u^2+t*(d-t)+v*(3*u-k+f)-2*v^2+7*d := by
    nlinarith only [mass,r₂,sq,z]
  exact ⟨ordinary_bound h d p t u v tp (by omega) base,
    flank_bound h d p t u v tp pd mf,
    exclusive_bound h d p t u v k f me⟩

#print axioms combined_mixed_bounds
end Graffiti189LongestPath.MixedReserve
