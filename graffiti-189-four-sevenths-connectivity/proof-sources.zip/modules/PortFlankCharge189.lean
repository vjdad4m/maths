import TwoThirdsDeficitAll189
import GapOne189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack Graffiti189LongestPath.PinRun
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
open private Graffiti189LongestPath.pin_data Graffiti189LongestPath.mem_distanceTwo Graffiti189LongestPath.dist_two from SmallSeparator189
open private Graffiti189LongestPath.OneSlack.cardinal_flankVertices from OneSlack189
set_option maxHeartbeats 4000000
namespace Graffiti189LongestPath.PortFlankCharge

variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]
variable {a b x : V} {p : G.Walk a b}

/-- Left and right flank vertices of a specified subset of pin positions. -/
def restrictedFlanks (p : G.Walk a b) (Q : Finset Nat) : Finset V :=
  (Q.image (fun i => p.getVert (i-1))) ∪ (Q.image (fun i => p.getVert (i+1)))

omit [Fintype V] in
private theorem flank_sub {Q : Finset Nat} (qx : Q⊆Pins p x) :
    restrictedFlanks p Q⊆FlankVertices p x := by
  intro z zq
  rcases mem_union.mp zq with ll|rr
  · obtain ⟨i,iq,rfl⟩ := mem_image.mp ll
    exact mem_image.mpr ⟨i-1,mem_union.mpr (Or.inl (mem_image.mpr ⟨i,qx iq,rfl⟩)),rfl⟩
  · obtain ⟨i,iq,rfl⟩ := mem_image.mp rr
    exact mem_image.mpr ⟨i+1,mem_union.mpr (Or.inr (mem_image.mpr ⟨i,qx iq,rfl⟩)),rfl⟩

omit [Fintype V] in
private theorem flank_cover (Q : Finset Nat) :
    FlankVertices p x⊆restrictedFlanks p Q∪restrictedFlanks p ((Pins p x)\Q) := by
  intro z zz
  obtain ⟨j,jj,rfl⟩ := mem_image.mp zz
  rcases mem_union.mp jj with l|r
  · obtain ⟨i,ip,rfl⟩ := mem_image.mp l
    by_cases iq : i∈Q
    · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inl (mem_image.mpr ⟨i,iq,rfl⟩))))
    · exact mem_union.mpr (Or.inr (mem_union.mpr (Or.inl
        (mem_image.mpr ⟨i,mem_sdiff.mpr ⟨ip,iq⟩,rfl⟩))))
  · obtain ⟨i,ip,rfl⟩ := mem_image.mp r
    by_cases iq : i∈Q
    · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inr (mem_image.mpr ⟨i,iq,rfl⟩))))
    · exact mem_union.mpr (Or.inr (mem_union.mpr (Or.inr
        (mem_image.mpr ⟨i,mem_sdiff.mpr ⟨ip,iq⟩,rfl⟩))))

omit [Fintype V] [DecidableRel G.Adj] in
private theorem restriction_le (Q : Finset Nat) : (restrictedFlanks p Q).card≤2*Q.card := by
  unfold restrictedFlanks
  have l : (Q.image (fun i => p.getVert (i-1))).card≤Q.card := card_image_le
  have r : (Q.image (fun i => p.getVert (i+1))).card≤Q.card := card_image_le
  have u := card_union_le (Q.image (fun i => p.getVert (i-1))) (Q.image (fun i => p.getVert (i+1)))
  omega

private theorem restriction_many (hp : IsLongest p) (hx : x∉p.support)
    (gap : (Pins p x).card≤(FirstPins p x).card+1)
    {Q : Finset Nat} (sub : Q⊆Pins p x) :
    2*Q.card≤(restrictedFlanks p Q).card+1 := by
  have f := flank_count_exact hp hx
  have cv := Graffiti189LongestPath.OneSlack.cardinal_flankVertices hp (x:=x)
  have c := (card_le_card (flank_cover (p:=p) (x:=x) Q)).trans
    (card_union_le (restrictedFlanks p Q) (restrictedFlanks p ((Pins p x)\Q)))
  have t := restriction_le (p:=p) ((Pins p x)\Q)
  have s := card_sdiff_add_card_eq_card sub
  omega

theorem exists_even_pin_flank_charges (hc : G.Connected) (hp : IsLongest p)
    (hx : x∉p.support) (gap : (Pins p x).card≤(FirstPins p x).card+1)
    (v : V) (va : v∈OmittedStar p x) (vx : v≠x) :
    let J := (Pins p x).filter (fun i => G.Adj v (p.getVert i))
    ∃ Z : Finset V, Z⊆DistanceTwo G v ∧
      (Pins p x).card+J.card≤Z.card+1 ∧
      Disjoint Z (OmittedStar p x) ∧
      Disjoint Z (External G (OmittedStar p x)∩DistanceTwo G x) ∧
      Disjoint Z (Shell G x 3) := by
  classical
  let I := Pins p x
  let J := I.filter (fun i => G.Adj v (p.getVert i))
  let K := I\J
  let U := K.image p.getVert
  let F := restrictedFlanks p J
  let Z := U∪F
  let A := OmittedStar p x
  let B := External G A
  have JI : J⊆I := filter_subset _ _
  have KI : K⊆I := sdiff_subset
  have ub : U⊆B := by
    intro z zz
    obtain ⟨i,ik,rfl⟩ := mem_image.mp zz
    have xx : x∈A := Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
    exact Graffiti189LongestPath.Rigidity.mem_external.mpr
      ⟨fun e => (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp e).1 (p.getVert_mem_support i),
        x,xx,(Graffiti189LongestPath.pin_data (KI ik)).2⟩
  have uone (z : V) (zu : z∈U) : G.dist x z=1 := by
    obtain ⟨i,ik,rfl⟩ := mem_image.mp zu
    exact dist_eq_one_iff_adj.mpr (Graffiti189LongestPath.pin_data (KI ik)).2
  have fs : F⊆DistanceTwo G x\B := (flank_sub JI).trans (flanks_outside_boundary hc hp hx)
  have uf : Disjoint U F := disjoint_left.mpr (fun _ zu zf => (mem_sdiff.mp (fs zf)).2 (ub zu))
  have uk : U.card=K.card := card_image_of_injOn (fun _ hi _ hj e =>
    hp.1.getVert_injOn (Graffiti189LongestPath.pin_data (KI hi)).1.le
      (Graffiti189LongestPath.pin_data (KI hj)).1.le e)
  have zcard : Z.card=U.card+F.card := card_union_of_disjoint uf
  have kc : K.card+J.card=I.card := card_sdiff_add_card_eq_card JI
  have fc : 2*J.card≤F.card+1 := restriction_many hp hx gap JI
  have vP : v∉p.support := (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp va).1
  have ex (z : V) (i : Nat) (hi : i∈J) (zp : z∈F)
      (ed : G.Adj (p.getVert i) z) (zs : z∈p.support) : z∈DistanceTwo G v := by
    have ve : G.Adj v (p.getVert i) := (mem_filter.mp hi).2
    have no : ¬G.Adj v z := fun h => (mem_sdiff.mp (fs zp)).2
      (Graffiti189LongestPath.Rigidity.mem_external.mpr
        ⟨fun zi => (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp zi).1 zs,v,va,h⟩)
    exact Graffiti189LongestPath.mem_distanceTwo.mpr
      (Graffiti189LongestPath.dist_two hc (fun e => vP (e.symm ▸ zs)) no ve ed)
  refine ⟨Z,?_,by change I.card+J.card≤Z.card+1; omega,?_,?_,?_⟩
  · intro z zz
    rcases mem_union.mp zz with zu|zf
    · obtain ⟨i,ik,rfl⟩ := mem_image.mp zu
      have iv := (Graffiti189LongestPath.pin_data (KI ik)).2
      have vnx : G.Adj v x := (((Graffiti189LongestPath.Rigidity.mem_omittedStar.mp va).2).resolve_left vx).symm
      have no : ¬G.Adj v (p.getVert i) := fun h => (mem_sdiff.mp ik).2 (mem_filter.mpr ⟨KI ik,h⟩)
      exact Graffiti189LongestPath.mem_distanceTwo.mpr
        (Graffiti189LongestPath.dist_two hc (fun e => vP (e.symm ▸ p.getVert_mem_support i)) no vnx iv)
    · rcases mem_union.mp zf with ll|rr
      · obtain ⟨i,ij,rfl⟩ := mem_image.mp ll
        have hi := (Graffiti189LongestPath.pin_data (JI ij)).1
        have ne : i≠0 := by
          intro e
          have w := (Graffiti189LongestPath.pin_data (JI ij)).2
          rw [e,getVert_zero] at w
          have longer := hp.2 x b (.cons w p) (hp.1.cons hx)
          simp at longer
        have ed := p.adj_getVert_succ (i:=i-1) (by omega)
        rw [show i-1+1=i by omega] at ed
        exact ex _ i ij zf ed.symm (p.getVert_mem_support _)
      · obtain ⟨i,ij,rfl⟩ := mem_image.mp rr
        exact ex _ i ij zf (p.adj_getVert_succ (Graffiti189LongestPath.pin_data (JI ij)).1)
          (p.getVert_mem_support _)
  · apply disjoint_left.mpr
    intro z zz za
    rcases mem_union.mp zz with zu|zf
    · exact (Graffiti189LongestPath.Rigidity.mem_external.mp (ub zu)).1 za
    · obtain ⟨i,_,rfl⟩ := mem_image.mp (flank_sub JI zf)
      exact (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp za).1 (p.getVert_mem_support i)
  · apply disjoint_left.mpr
    intro z zz zc
    obtain ⟨zb,zt⟩ := mem_inter.mp zc
    rcases mem_union.mp zz with zu|zf
    · have d₁ := uone _ zu
      have d₂ := Graffiti189LongestPath.mem_distanceTwo.mp zt
      omega
    · exact (mem_sdiff.mp (fs zf)).2 zb
  · apply disjoint_left.mpr
    intro z zz zc
    have d₃ := mem_shell.mp zc
    rcases mem_union.mp zz with zu|zf
    · have d₁ := uone _ zu
      omega
    · have d₂ := Graffiti189LongestPath.mem_distanceTwo.mp (mem_sdiff.mp (fs zf)).1
      omega

#print axioms exists_even_pin_flank_charges
end Graffiti189LongestPath.PortFlankCharge
