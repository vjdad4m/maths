import PortFlankCharge189
import ShellDonorFull189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack Graffiti189LongestPath.PinRun
open Graffiti189LongestPath.PortFlankCharge Graffiti189LongestPath.ShellDonorFull
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
open private Graffiti189LongestPath.pin_data Graffiti189LongestPath.mem_distanceTwo Graffiti189LongestPath.dist_two from SmallSeparator189
set_option maxHeartbeats 5000000
namespace Graffiti189LongestPath.StrongDonorCharge

variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]
variable {a b x : V} {p : G.Walk a b}

theorem omitted_donor_strong_charge (hc : G.Connected) (d : Nat)
    (cap : ∀ v,(DistanceTwo G v).card≤d) (hp : IsLongest p) (hx : x∉p.support)
    (gap : (Pins p x).card≤(FirstPins p x).card+1)
    (D Q : Finset V) (DA : D⊆OmittedStar p x) (xD : x∉D) (QA : Q⊆OmittedStar p x)
    (xQ : x∉Q) (DQ : Disjoint D Q) (v : V) (vd : v∈D)
    (qn : ∀ z∈Q,¬G.Adj v z)
    (rep : V→V)
    (privateGate : ∀ u∈D,rep u∈DistanceTwo G x ∧ G.Adj u (rep u) ∧
      ∀ w∈D,w≠u → ¬G.Adj w (rep u)) :
    let J := (Pins p x).filter (fun i => G.Adj v (p.getVert i))
    (gateThird G x (DistanceTwo G x) v).card+D.card+Q.card+(Pins p x).card+J.card≤d+2 := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let H := Shell G x 3
  let F := gateThird G x (DistanceTwo G x) v
  let J := (Pins p x).filter (fun i => G.Adj v (p.getVert i))
  have root (u : V) (ua : u∈A) (ux : u≠x) : G.Adj x u :=
    ((Graffiti189LongestPath.Rigidity.mem_omittedStar.mp ua).2).resolve_left ux
  have vn : v≠x := fun h => xD (h ▸ vd)
  have vx := (root v (DA vd) vn).symm
  have Adist (u : V) (ua : u∈A) : G.dist x u≤1 := by
    rcases (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp ua).2 with rfl|e
    · rw [dist_self]; omega
    · rw [dist_eq_one_iff_adj.mpr e]
  have enear (u : V) (ud : u∈D) : rep u∈B∩DistanceTwo G x := by
    have rt := (privateGate u ud).1
    have rd := Graffiti189LongestPath.mem_distanceTwo.mp rt
    exact mem_inter.mpr ⟨Graffiti189LongestPath.Rigidity.mem_external.mpr
      ⟨fun e => by have b := Adist (rep u) e; omega,u,DA ud,(privateGate u ud).2.1⟩,rt⟩
  have inj : Set.InjOn rep (↑D:Set V) := by
    intro u ud w wd eq
    apply Classical.byContradiction
    intro ne
    exact (privateGate w wd).2.2 u ud ne (eq ▸ (privateGate u ud).2.1)
  let E := D.erase v
  let pay (u : V) := if G.Adj v u then rep u else u
  let K := E.image pay
  have kcard : K.card=E.card := by
    apply card_image_of_injOn
    intro u uu w ww eq
    have ud := (mem_erase.mp uu).2
    have wd := (mem_erase.mp ww).2
    by_cases vu : G.Adj v u <;> by_cases vw : G.Adj v w
    · exact inj ud wd (by simpa [pay,vu,vw] using eq)
    · have e : rep u=w := by simpa [pay,vu,vw] using eq
      exact ((Graffiti189LongestPath.Rigidity.mem_external.mp (mem_inter.mp (enear u ud)).1).1 (e.symm ▸ DA wd)).elim
    · have e : u=rep w := by simpa [pay,vu,vw] using eq
      exact ((Graffiti189LongestPath.Rigidity.mem_external.mp (mem_inter.mp (enear w wd)).1).1 (e ▸ DA ud)).elim
    · simpa [pay,vu,vw] using eq
  have ks : K⊆A∪(B∩DistanceTwo G x) := by
    intro z zk
    obtain ⟨u,ue,rfl⟩ := mem_image.mp zk
    have ud := (mem_erase.mp ue).2
    by_cases e : G.Adj v u
    · simpa [pay,e] using (mem_union.mpr (Or.inr (enear u ud)) : rep u∈A∪(B∩DistanceTwo G x))
    · simpa [pay,e] using (mem_union.mpr (Or.inl (DA ud)) : u∈A∪(B∩DistanceTwo G x))
  have kd : K⊆DistanceTwo G v := by
    intro z zk
    obtain ⟨u,ue,rfl⟩ := mem_image.mp zk
    obtain ⟨uv,ud⟩ := mem_erase.mp ue
    by_cases e : G.Adj v u
    · have wp := privateGate u ud
      have no := wp.2.2 v vd uv.symm
      have ne : v≠rep u := fun h => (Graffiti189LongestPath.Rigidity.mem_external.mp
        (mem_inter.mp (enear u ud)).1).1 (h ▸ DA vd)
      have c := Graffiti189LongestPath.mem_distanceTwo.mpr
        (Graffiti189LongestPath.dist_two hc ne no e wp.2.1)
      simpa [pay,e] using c
    · have xu := root u (DA ud) (fun h => xD (h ▸ ud))
      have c := Graffiti189LongestPath.mem_distanceTwo.mpr
        (Graffiti189LongestPath.dist_two hc uv.symm e vx xu)
      simpa [pay,e] using c
  have qd : Q⊆DistanceTwo G v := by
    intro z zq
    have ne : v≠z := fun e => disjoint_left.mp DQ vd (e.symm ▸ zq)
    exact Graffiti189LongestPath.mem_distanceTwo.mpr (Graffiti189LongestPath.dist_two hc ne
      (qn z zq) vx (root z (QA zq) (fun e => xQ (e ▸ zq))))
  have kq : Disjoint K Q := by
    apply disjoint_left.mpr
    intro z zk zq
    obtain ⟨u,ue,rfl⟩ := mem_image.mp zk
    have ud := (mem_erase.mp ue).2
    by_cases e : G.Adj v u
    · have zq' : rep u∈Q := by simpa [pay,e] using zq
      exact (Graffiti189LongestPath.Rigidity.mem_external.mp (mem_inter.mp (enear u ud)).1).1 (QA zq')
    · exact disjoint_left.mp DQ ud (by simpa [pay,e] using zq)
  have fs : F⊆H := fun _ z => (mem_gateThird.mp z).1
  have fd : F⊆DistanceTwo G v := by
    intro z zz
    obtain ⟨zs,w,_,vw,wz⟩ := mem_gateThird.mp zz
    have d₃ := mem_shell.mp zs
    have d₁ := dist_eq_one_iff_adj.mpr vx.symm
    have ne : v≠z := by intro e; rw [e] at d₁; omega
    have no : ¬G.Adj v z := by
      intro e
      have h := hc.dist_triangle (u:=x) (v:=v) (w:=z)
      rw [dist_eq_one_iff_adj.mpr e] at h
      omega
    exact Graffiti189LongestPath.mem_distanceTwo.mpr (Graffiti189LongestPath.dist_two hc ne no vw wz)
  have fk : Disjoint F K := disjoint_left.mpr (by
    intro z zf zk
    have d₃ := mem_shell.mp (fs zf)
    rcases mem_union.mp (ks zk) with za|zb
    · have d₁ := Adist z za
      omega
    · have d₂ := Graffiti189LongestPath.mem_distanceTwo.mp (mem_inter.mp zb).2
      omega)
  have fq : Disjoint F Q := disjoint_left.mpr (fun z zf zq => by
    have d₃ := mem_shell.mp (fs zf)
    have d₁ := Adist z (QA zq)
    omega)
  obtain ⟨Z,Zs,Zc,Za,Zb,Zh⟩ := exists_even_pin_flank_charges hc hp hx gap v (DA vd) vn
  have zq : Disjoint Z Q := disjoint_left.mpr (fun _ zZ zQ => disjoint_left.mp Za zZ (QA zQ))
  have zf : Disjoint Z F := disjoint_left.mpr (fun _ zZ zF => disjoint_left.mp Zh zZ (fs zF))
  have zk : Disjoint Z K := disjoint_left.mpr (fun _ zZ zK => (mem_union.mp (ks zK)).elim
    (fun za => disjoint_left.mp Za zZ za) (fun zb => disjoint_left.mp Zb zZ zb))
  have all : F∪K∪Q∪Z⊆DistanceTwo G v := union_subset (union_subset (union_subset fd kd) qd) Zs
  have h := (card_le_card all).trans (cap v)
  rw [card_union_of_disjoint (disjoint_union_left.mpr
    ⟨disjoint_union_left.mpr ⟨zf.symm,zk.symm⟩,zq.symm⟩),
    card_union_of_disjoint (disjoint_union_left.mpr ⟨fq,kq⟩),card_union_of_disjoint fk,kcard] at h
  have ecard : E.card+1=D.card := card_erase_add_one vd
  change (Pins p x).card+J.card≤Z.card+1 at Zc
  change F.card+D.card+Q.card+(Pins p x).card+J.card≤d+2
  omega

#print axioms omitted_donor_strong_charge

end Graffiti189LongestPath.StrongDonorCharge
