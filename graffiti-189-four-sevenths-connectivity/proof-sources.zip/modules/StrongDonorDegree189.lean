import StrongDonorCharge189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack Graffiti189LongestPath.PinRun
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
open private Graffiti189LongestPath.pin_data Graffiti189LongestPath.mem_distanceTwo from SmallSeparator189
open private Graffiti189LongestPath.OneSlack.card_pinVertices Graffiti189LongestPath.OneSlack.pin_vertices_subset_boundary from OneSlack189
set_option maxHeartbeats 5000000
namespace Graffiti189LongestPath.StrongDonorDegree

variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]
variable {a b x : V} {p : G.Walk a b}

theorem degree_upper_with_forbidden_ports (A B C E X S : Finset V)
    (part : A=C∪E∪X) (nA : ∀ u∈A,∀ v∉A, G.Adj u v→v∈B)
    (cs : C⊆A) (no : ∀ u∈C,∀ v∈E,¬G.Adj u v)
    (v : V) (vc : v∈C) (sb : S⊆B) (bad : ∀ z∈S,¬G.Adj v z) :
    G.degree v+S.card+1≤C.card+X.card+B.card := by
  classical
  have ns : G.neighborFinset v⊆(C.erase v)∪X∪(B\S) := by
    intro z hz
    have vz := (G.mem_neighborFinset _ _).mp hz
    by_cases za : z∈A
    · rcases mem_union.mp (part ▸ za) with zc|zx
      · rcases mem_union.mp zc with zc|ze
        · exact mem_union.mpr (Or.inl (mem_union.mpr
            (Or.inl (mem_erase.mpr ⟨vz.ne.symm,zc⟩))))
        · exact (no v vc z ze vz).elim
      · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inr zx)))
    · exact mem_union.mpr (Or.inr (mem_sdiff.mpr ⟨nA v (cs vc) z za vz,fun zs => bad z zs vz⟩))
  have e := card_le_card ns
  rw [G.card_neighborFinset_eq_degree] at e
  have i := card_union_le (C.erase v) X
  have j := card_union_le ((C.erase v)∪X) (B\S)
  have ce := card_erase_add_one vc
  have se := card_sdiff_add_card_eq_card sb
  omega

theorem donor_degree_all_private_and_missing_pins (d : Nat) (hp : IsLongest p) (hx : x∉p.support)
    (C E X D : Finset V) (part : OmittedStar p x=C∪E∪X) (xs : X.card≤2)
    (cs : C⊆OmittedStar p x) (ds : D⊆OmittedStar p x)
    (no : ∀ u∈C,∀ w∈E,¬G.Adj u w)
    (bk : (External G (OmittedStar p x)).card+(Pins p x).card≤d+1)
    (v : V) (vc : v∈C) (vd : v∈D) (hv : d≤G.degree v)
    (rep : V→V)
    (priv : ∀ u∈D,rep u∈DistanceTwo G x ∧ G.Adj u (rep u) ∧
      ∀ w∈D,w≠u → ¬G.Adj w (rep u)) :
    let J := (Pins p x).filter (fun i => G.Adj v (p.getVert i))
    D.card+2*(Pins p x).card≤C.card+J.card+3 := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let I := Pins p x
  let J := I.filter (fun i => G.Adj v (p.getVert i))
  let P := (I\J).image p.getVert
  let R := (D.erase v).image rep
  have closed (u : V) (ua : u∈A) (t : V) (ta : t∉A) (ut : G.Adj u t) : t∈B :=
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨ta,u,ua,ut⟩
  have rs : R⊆B := by
    intro z zr
    obtain ⟨u,ue,rfl⟩ := mem_image.mp zr
    have ud := (mem_erase.mp ue).2
    have dist := Graffiti189LongestPath.mem_distanceTwo.mp (priv u ud).1
    have na : rep u∉A := by
      intro e
      rcases (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp e).2 with h|h
      · rw [h,dist_self] at dist; omega
      · have h' := dist_eq_one_iff_adj.mpr h; omega
    exact closed u (ds ud) (rep u) na (priv u ud).2.1
  have ps : P⊆B := by
    intro z zp
    obtain ⟨i,iz,rfl⟩ := mem_image.mp zp
    exact Graffiti189LongestPath.OneSlack.pin_vertices_subset_boundary hx
      (mem_image.mpr ⟨i,(mem_sdiff.mp iz).1,rfl⟩)
  have rp : Disjoint R P := disjoint_left.mpr (by
    intro z zr zp
    obtain ⟨u,ue,he⟩ := mem_image.mp zr
    obtain ⟨i,ij,rfl⟩ := mem_image.mp zp
    have d₂ := Graffiti189LongestPath.mem_distanceTwo.mp (priv u (mem_erase.mp ue).2).1
    rw [he] at d₂
    have d₁ := dist_eq_one_iff_adj.mpr (Graffiti189LongestPath.pin_data (mem_sdiff.mp ij).1).2
    omega)
  have rc : R.card=(D.erase v).card := by
    apply card_image_of_injOn
    intro u uu w ww eq
    obtain ⟨_,ud⟩ := mem_erase.mp uu
    obtain ⟨_,wd⟩ := mem_erase.mp ww
    apply Classical.byContradiction
    intro ne
    exact (priv w wd).2.2 u ud ne (eq ▸ (priv u ud).2.1)
  have pc : P.card=(I\J).card := by
    apply card_image_of_injOn
    intro u uu w ww eq
    exact hp.1.getVert_injOn (Graffiti189LongestPath.pin_data (mem_sdiff.mp uu).1).1.le
      (Graffiti189LongestPath.pin_data (mem_sdiff.mp ww).1).1.le eq
  have bad : ∀ z∈R∪P,¬G.Adj v z := by
    intro z zz vz
    rcases mem_union.mp zz with h|h
    · obtain ⟨u,ue,rfl⟩ := mem_image.mp h
      obtain ⟨uv,ud⟩ := mem_erase.mp ue
      exact (priv u ud).2.2 v vd uv.symm vz
    · obtain ⟨i,ij,rfl⟩ := mem_image.mp h
      obtain ⟨ii,ij⟩ := mem_sdiff.mp ij
      exact ij (mem_filter.mpr ⟨ii,vz⟩)
  have q := degree_upper_with_forbidden_ports A B C E X (R∪P) part closed cs no v vc
    (union_subset rs ps) bad
  rw [card_union_of_disjoint rp,rc,pc] at q
  have e := card_erase_add_one vd
  have pp : (I\J).card+J.card=I.card := card_sdiff_add_card_eq_card (filter_subset _ _)
  change B.card+I.card≤d+1 at bk
  change D.card+2*I.card≤C.card+J.card+3
  omega

theorem side_bound_with_missing_reach_and_private_ports (d : Nat)
    (A B C E X D : Finset V) (part : A=C∪E∪X) (xs : X.card≤2) (cs : C⊆A)
    (no : ∀ u∈C,∀ w∈E,¬G.Adj u w) (closed : ∀ u∈A,∀ w∉A,G.Adj u w→w∈B)
    (penalty : Nat) (bk : B.card+penalty≤d+1)
    (v : V) (vc : v∈C) (vd : v∈D) (hv : d≤G.degree v)
    (rep : V→V) (dc : D⊆C)
    (priv : ∀ u∈D,rep u∈B ∧ G.Adj u (rep u) ∧ ∀ w∈D,w≠u → ¬G.Adj w (rep u)) :
    let M := B.filter (fun z => ¬∃ u∈C,G.Adj u z)
    D.card+penalty+M.card≤C.card+3 := by
  classical
  let M := B.filter (fun z => ¬∃ u∈C,G.Adj u z)
  let R := (D.erase v).image rep
  have rc : R.card=(D.erase v).card := by
    apply card_image_of_injOn
    intro u uu w ww eq
    obtain ⟨_,ud⟩ := mem_erase.mp uu
    obtain ⟨_,wd⟩ := mem_erase.mp ww
    apply Classical.byContradiction
    intro ne
    exact (priv w wd).2.2 u ud ne (eq ▸ (priv u ud).2.1)
  have rs : R⊆B := by
    intro z zr
    obtain ⟨u,ud,rfl⟩ := mem_image.mp zr
    exact (priv u (mem_erase.mp ud).2).1
  have rm : Disjoint R M := disjoint_left.mpr (by
    intro z zr zm
    obtain ⟨u,ue,rfl⟩ := mem_image.mp zr
    have ud := (mem_erase.mp ue).2
    exact (mem_filter.mp zm).2 ⟨u,dc ud,(priv u ud).2.1⟩)
  have ms : M⊆B := filter_subset _ _
  have bad : ∀ z∈R∪M,¬G.Adj v z := by
    intro z zz vz
    rcases mem_union.mp zz with r|m
    · obtain ⟨u,ue,rfl⟩ := mem_image.mp r
      obtain ⟨uv,ud⟩ := mem_erase.mp ue
      exact (priv u ud).2.2 v vd uv.symm vz
    · exact (mem_filter.mp m).2 ⟨v,vc,vz⟩
  have b := degree_upper_with_forbidden_ports A B C E X (R∪M) part closed cs no v vc
    (union_subset rs ms) bad
  rw [card_union_of_disjoint rm,rc] at b
  have er := card_erase_add_one vd
  change D.card+penalty+M.card≤C.card+3
  omega

theorem missing_ports_bound_by_side_order (d : Nat) (A B C E X : Finset V)
    (part : A=C∪E∪X) (xs : X.card≤2)
    (nA : ∀ u∈A,∀ v∉A,G.Adj u v→v∈B)
    (cs : C⊆A) (no : ∀ u∈C,∀ w∈E,¬G.Adj u w)
    (penalty : Nat) (bk : B.card+penalty≤d+1)
    (v : V) (vc : v∈C) (vh : d≤G.degree v) :
    let M := B.filter (fun z => ¬∃ u∈C,G.Adj u z)
    M.card+penalty≤C.card+2 := by
  classical
  let M := B.filter (fun z => ¬∃ u∈C,G.Adj u z)
  have e := degree_upper_with_forbidden_ports A B C E X M part nA cs no v vc
    (filter_subset _ _) (fun z zm ed => (mem_filter.mp zm).2 ⟨v,vc,ed⟩)
  change M.card+penalty≤C.card+2
  omega

#print axioms missing_ports_bound_by_side_order

#print axioms donor_degree_all_private_and_missing_pins
#print axioms side_bound_with_missing_reach_and_private_ports
end Graffiti189LongestPath.StrongDonorDegree
