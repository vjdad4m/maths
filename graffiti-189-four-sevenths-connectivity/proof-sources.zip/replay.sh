#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")" && pwd)"
obj="$(mktemp -d)"
trap 'rm -rf "$obj"' EXIT
export LEAN_PATH="$obj:${LEAN_PATH:-}"
for mod in PortFlankCharge189 StrongDonorCharge189 StrongDonorDegree189; do
  echo "== $mod =="
  lean -j1 -DElab.async=false -DwarningAsError=true --root="$root/modules" -o "$obj/$mod.olean" "$root/modules/$mod.lean"
done
echo '== FourSeventhsCombined189 =='
lean -j1 -DElab.async=false -DwarningAsError=true --root="$root" -o "$obj/FourSeventhsCombined189.olean" "$root/FourSeventhsCombined189.lean"
