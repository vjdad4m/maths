#!/usr/bin/env bash
set -euo pipefail
p=$(cd "$(dirname "$0")" && pwd)
: "${LEAN_PATH:?Run in a prepared Mathlib checkout with the pinned prior packages on LEAN_PATH.}"
lean --version | grep -q '4.19.0.*6caaee842e94'
(cd "$p" && sha256sum -c SOURCE-SHA256.txt)
out="$(mktemp -d)"
export LEAN_PATH="$out:$LEAN_PATH"
while IFS= read -r mod; do
  n=${mod//./\/}
  IFS=: read -r -a dirs <<< "$LEAN_PATH"
  found=0
  for d in "${dirs[@]}"; do if [ -f "$d/$n.olean" ]; then found=1; break; fi; done
  if [ "$found" = 0 ]; then echo "Missing prerequisite: $mod" >&2; exit 2; fi
done < "$p/external.txt"
while IFS= read -r mod; do
  lean --root="$p/src" -j1 -s65536 -DElab.async=false -DwarningAsError=true -o "$out/$mod.olean" "$p/src/$mod.lean"
  printf 'PASS %s\n' "$mod"
done < "$p/order.txt"
