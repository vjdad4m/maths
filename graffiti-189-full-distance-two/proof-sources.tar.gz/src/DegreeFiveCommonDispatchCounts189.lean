import DegreeFiveActualCut189

namespace Graffiti189
/-- Unordered positive cut-port counts, at most five on each shore and at least five in total. -/
theorem two_common_shore_count_dispatch {P : Prop} {c d : ℕ}
    (c1 : 1≤c) (d1 : 1≤d) (c5 : c≤5) (d5 : d≤5) (total : 5≤c+d)
    (ordered : ∀ u v : ℕ,(u=c ∧ v=d) ∨ (u=d ∧ v=c) →
      (u=1 ∧ (v=4 ∨ v=5)) ∨
      (u=2 ∧ (v=3 ∨ v=4 ∨ v=5)) ∨
      (u=3 ∧ (v=3 ∨ v=4 ∨ v=5)) ∨
      (u=4 ∧ 4≤v) ∨ (u=5 ∧ v=5) → P) : P := by
  by_cases h : c≤d
  · exact ordered c d (.inl ⟨rfl,rfl⟩) (by omega)
  exact ordered d c (.inr ⟨rfl,rfl⟩) (by omega)

#print axioms two_common_shore_count_dispatch
end Graffiti189
