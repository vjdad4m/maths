import DegreeFiveOneFourClose189
import DegreeFiveCommonDispatchCounts189
import DegreeFiveThreeThreeFullClose189
import DegreeFiveOneFiveFarSeven189
import DegreeFiveBothFourOrFiveUnsat189
import DegreeFiveBothFiveAll189
import DegreeFiveThreeFiveAll189
import DegreeFiveTwoFiveAll189

namespace Graffiti189LongestPath.CrossSaturation.FiveActualCut
open SimpleGraph SimpleGraph.Walk Finset
open private Shore shore_off shore_closed shore_disjoint from DegreeFiveActualCut189
open private Cmp from DegreeFiveThreeForeignImpossible189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false

/-- Both-shores-common distance-two two-cuts are traceable under degree-five #189 hypotheses. -/
theorem traceable_of_actual_five_distance_two_both_common_shores
    (hc : G.Connected) (two : G.dist a b=2) (even : ∀ x,(EvenFrom G x).card≤6)
    (conn : ∀ R : Finset V,R.card<2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    {C D : Cmp (G:=G) (a:=a) (b:=b)} (cd : C≠D)
    (cover : ∀ z : V,z=a ∨ z=b ∨ z∈Shore C ∨ z∈Shore D)
    {x y : V} (xc : x∈Shore C) (ax : G.Adj a x) (bx : G.Adj b x)
    (yd : y∈Shore D) (ay : G.Adj a y) (by' : G.Adj b y) :
    ∃ r t,∃ p : G.Walk r t,p.IsPath ∧ ∀ z,z∈p.support := by
  classical
  have limits (X Y : Cmp (G:=G) (a:=a) (b:=b)) (ne : X≠Y) {z : V}
      (zs : z∈Shore X) (az : G.Adj a z) (bz : G.Adj b z) :
      1≤(cutPorts X).card ∧ (cutPorts Y).card≤5 := by
    have point : z∈cutPorts X := mem_filter.mpr ⟨zs,.inl az⟩
    have k := foreign_ports_le_five_at_common hc even zs az bz
      (T:=({Y} : Finset (Cmp (G:=G) (a:=a) (b:=b)))) (by simpa using ne)
    rw [sum_singleton] at k
    exact ⟨card_pos.mpr ⟨z,point⟩,k⟩
  obtain ⟨c1,d5⟩ := limits C D cd xc ax bx
  obtain ⟨d1,c5⟩ := limits D C cd.symm yd ay by'
  have ab : a≠b := by intro e; rw [e,dist_self] at two; omega
  have nab : ¬G.Adj a b := by
    intro e
    have w := SimpleGraph.dist_eq_one_iff_adj.mpr e
    rw [two] at w
    omega
  have cutBound (z : V) (za : z=a ∨ z=b) :
      G.degree z≤(cutPorts C).card+(cutPorts D).card := by
    have sub : G.neighborFinset z ⊆ cutPorts C ∪ cutPorts D := by
      intro v vm
      have e := (G.mem_neighborFinset z v).mp vm
      have ev : G.Adj a v ∨ G.Adj b v :=
        za.elim (fun h => Or.inl (h ▸ e)) (fun h => Or.inr (h ▸ e))
      obtain rfl|rfl|vc|vd := cover v
      · rcases ev with h|h
        · exact (G.loopless _ h).elim
        · exact (nab h.symm).elim
      · rcases ev with h|h
        · exact (nab h).elim
        · exact (G.loopless _ h).elim
      · exact mem_union_left _ (mem_filter.mpr ⟨vc,ev⟩)
      · exact mem_union_right _ (mem_filter.mpr ⟨vd,ev⟩)
    have c := (card_le_card sub).trans (card_union_le _ _)
    rwa [G.card_neighborFinset_eq_degree] at c
  have total : 5≤(cutPorts C).card+(cutPorts D).card :=
    (degree a b ab).elim (fun h => h.trans (cutBound a (.inl rfl)))
      (fun h => h.trans (cutBound b (.inr rfl)))
  have ordered (X Y : Cmp (G:=G) (a:=a) (b:=b)) (ne : X≠Y)
      (cv : ∀ z : V,z=a ∨ z=b ∨ z∈Shore X ∨ z∈Shore Y)
      {u v : V} (us : u∈Shore X) (au : G.Adj a u) (bu : G.Adj b u)
      (vs : v∈Shore Y) (av : G.Adj a v) (bv : G.Adj b v)
      (prof : ((cutPorts X).card=1 ∧ ((cutPorts Y).card=4 ∨ (cutPorts Y).card=5)) ∨
        ((cutPorts X).card=2 ∧ ((cutPorts Y).card=3 ∨ (cutPorts Y).card=4 ∨ (cutPorts Y).card=5)) ∨
        ((cutPorts X).card=3 ∧ ((cutPorts Y).card=3 ∨ (cutPorts Y).card=4 ∨ (cutPorts Y).card=5)) ∨
        ((cutPorts X).card=4 ∧ 4≤(cutPorts Y).card) ∨ ((cutPorts X).card=5 ∧ (cutPorts Y).card=5)) :
      ∃ r t,∃ p : G.Walk r t,p.IsPath ∧ ∀ z,z∈p.support := by
    rcases prof with ⟨x1,y4|y5⟩|⟨x2,y3|y4|y5⟩|⟨x3,y3|y4|y5⟩|⟨x4,y4⟩|⟨x5,y5⟩
    · exact traceable_of_actual_five_one_four_ports hc two even conn degree ne cv x1 y4
    · exact traceable_of_actual_five_one_five_ports hc two even conn degree ne cv x1 y5
    · exact (impossible_actual_five_two_three_ports hc two even conn degree ne cv x2 y3).elim
    · exact traceable_of_actual_five_two_four_ports hc two even conn degree ne cv x2 y4 us au bu
    · exact traceable_of_actual_five_two_five_ports hc two even degree ne cv x2 y5 us au bu vs av bv
    · exact traceable_of_actual_five_three_three_ports hc two even conn degree ne cv x3 y3
    · exact traceable_of_actual_five_three_four_ports hc two even conn degree ne cv x3 y4 us au bu
    · exact traceable_of_actual_five_three_five_ports hc two even conn degree ne cv x3 y5 us au bu vs av bv
    · exact traceable_of_both_common_four_or_five_ports_one_four hc two even conn degree ne cv
        x4 y4 us au bu vs av bv
    exact traceable_at_both_five_port_shores hc two even degree ne cv x5 y5 us au bu vs av bv
  apply Graffiti189.two_common_shore_count_dispatch c1 d1 c5 d5 total
  intro u v where' prof
  rcases where' with ⟨rfl,rfl⟩|⟨rfl,rfl⟩
  · exact ordered C D cd cover xc ax bx yd ay by' prof
  exact ordered D C cd.symm (fun z=>(cover z).imp id (fun h=>h.imp id Or.symm))
    yd ay by' xc ax bx prof

#print axioms traceable_of_actual_five_distance_two_both_common_shores
end Graffiti189LongestPath.CrossSaturation.FiveActualCut
