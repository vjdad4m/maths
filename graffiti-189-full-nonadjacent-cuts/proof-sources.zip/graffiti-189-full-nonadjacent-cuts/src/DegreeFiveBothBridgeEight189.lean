import DegreeFiveBothBridgeFacts189
import DegreeFiveSixTerminalFill189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset ArticulationPair
open private left_boundary from AdjacentCut189
open private not_common from DegreeFiveFourPort189
open private restrict_walk_support from DegreeFiveSixTerminalFill189
open private lift_side_path from DegreeFiveSmallSides189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

noncomputable def attachComplete (G : SimpleGraph V) (I : Finset V) : SimpleGraph V where
  Adj u v := G.Adj u v ∨ (u≠v ∧ (u∈I ∨ v∈I))
  symm := fun _ _ h => h.elim (fun h=>.inl h.symm) (fun h=>.inr ⟨h.1.symm,h.2.symm⟩)
  loopless u h := h.elim (G.loopless u) (fun h=>h.1 rfl)

theorem transfer_terminal_completed_inner (eight : S.L.card=8)
    (far : 3≤G.dist a b)
    (high : ∀ u∈S.L, 5≤G.degree u)
    {x y : V} (xl : x∈S.L) (yl : y∈S.L)
    (hroute : RouteOn (attachComplete G (farNonports S.L a b G)) S.L x y) :
    RouteOn G S.L x y := by
  classical
  let I := farNonports S.L a b G
  let H := attachComplete G I
  let U := (↑S.L : Set V)
  let J := G.induce U
  let K := H.induce U
  letI : DecidableRel K.Adj := Classical.decRel _
  obtain ⟨p,pp,ps⟩ := hroute
  obtain ⟨q,hq⟩ := restrict_walk_support p xl yl (fun v h=>(ps v).mp h)
  have qp : q.IsPath := IsPath.mk' (List.Nodup.of_map _ (hq.symm ▸ pp.support_nodup))
  have qa : ∀ v : U,v∈q.support := by
    intro v
    have h : v.val∈p.support := (ps _).mpr v.property
    obtain ⟨w,wm,eq⟩ := List.mem_map.mp (hq.symm ▸ h)
    exact (Subtype.ext eq : w=v) ▸ wm
  have sub : J≤K := fun _ _ e => Or.inl e
  have hi (u : U) (hu : u.val∈I) : 5≤J.degree u := by
    obtain ⟨ul,au,bu⟩ := mem_filter.mp hu
    have hs : G.neighborFinset u.val ⊆ inside G S.L u.val := by
      intro v vv
      have uv := (mem_neighborFinset G _ _).mp vv
      rcases left_boundary S u.val ul v uv with rfl|rfl|vl
      · exact (au uv.symm).elim
      · exact (bu uv.symm).elim
      exact mem_filter.mpr ⟨vl,uv⟩
    have hdeg := card_le_card hs
    rw [card_neighborFinset_eq_degree,inside_card_eq_degree_induce (G:=G) S.L u] at hdeg
    exact (high u.val ul).trans hdeg
  have hp (u : U) : 4≤J.degree u := by
    have h := high_shore_internal_four S far u.property (high _ u.property)
    rwa [show S.L.filter (G.Adj u.val)=inside G S.L u.val from rfl,
      inside_card_eq_degree_induce (G:=G) S.L u] at h
  have bound (u v : U) (uv : K.Adj u v) (nuv : ¬J.Adj u v) :
      Fintype.card U+1≤J.degree u+J.degree v := by
    obtain ⟨_,h|h⟩ := (show G.Adj u.val v.val ∨ _ from uv).resolve_left nuv
    · have hd := hi u h
      have hk := hp v
      have hc : Fintype.card U=8 := (Fintype.card_coe S.L).trans eight
      omega
    have hd := hi v h
    have hk := hp u
    have hc : Fintype.card U=8 := (Fintype.card_coe S.L).trans eight
    omega
  obtain ⟨r,rp,rs⟩ := terminal_ore_closure sub bound q qp qa
  exact lift_side_path S.L r rp rs

#print axioms transfer_terminal_completed_inner

theorem terminal_high_eight_one_b (far : 3≤G.dist a b)
    (eight : S.L.card=8)
    (high : ∀ u∈S.L, 5≤G.degree u)
    (a3 : S.localA.card=3) (b1 : (S.L.filter (G.Adj b)).card=1) :
    ∃ p q,G.Adj a p ∧ G.Adj b q ∧ RouteOn G S.L p q := by
  classical
  let A := S.localA
  let B := S.L.filter (G.Adj b)
  let I := farNonports S.L a b G
  let H := attachComplete G I
  have cnt : A.card+B.card+I.card=S.L.card := left_port_count S far
  have ha : A.card=3 := a3
  have hb : B.card=1 := b1
  have i4 : I.card=4 := by omega
  obtain ⟨x,y,z,xy,xz,yz,ae⟩ := card_eq_three.mp ha
  obtain ⟨q,be⟩ := card_eq_one.mp hb
  obtain ⟨r,ri⟩ := card_pos.mp (show 0<I.card by omega)
  have n3 : (I.erase r).card=3 := by rw [card_erase_of_mem ri,i4]
  obtain ⟨s,t,u,st,su,tu,ie⟩ := card_eq_three.mp n3
  have ie' : I={r,s,t,u} := by
    rw [←ie,insert_erase ri]
  have radi : r∉I.erase r := by simp
  have se : s∈I.erase r := by rw [ie]; simp
  have rs : r≠s := fun e=>radi (e.symm ▸ se)
  have te : t∈I.erase r := by rw [ie]; simp
  have rt : r≠t := fun e=>radi (e.symm ▸ te)
  have ue : u∈I.erase r := by rw [ie]; simp
  have ru : r≠u := fun e=>radi (e.symm ▸ ue)
  have xa : x∈A := by simp [ae]
  have ya : y∈A := by simp [ae]
  have za : z∈A := by simp [ae]
  have qb : q∈B := by simp [be]
  have si : s∈I := by simp [ie']
  have ti : t∈I := by simp [ie']
  have ui : u∈I := by simp [ie']
  have aoff {v : V} (va : v∈A) : v∉I := fun h=>(mem_filter.mp h).2.1 (mem_filter.mp va).2
  have boff {v : V} (vb : v∈B) : v∉I := fun h=>(mem_filter.mp h).2.2 (mem_filter.mp vb).2
  have non {v w : V} (vo : v∉I) (wi : w∈I) : v≠w := fun e=>vo (e.symm ▸ wi)
  have aq {v : V} (va : v∈A) : v≠q :=
    fun e=>not_common far (e ▸ (mem_filter.mp va).2) (mem_filter.mp qb).2
  have rq : r≠q := (non (boff qb) ri).symm
  have sq : s≠q := (non (boff qb) si).symm
  have tq : t≠q := (non (boff qb) ti).symm
  have uq : u≠q := (non (boff qb) ui).symm
  have h1 : H.Adj x r := .inr ⟨non (aoff xa) ri,.inr ri⟩
  have h2 : H.Adj r y := .inr ⟨(non (aoff ya) ri).symm,.inl ri⟩
  have h3 : H.Adj y s := .inr ⟨non (aoff ya) si,.inr si⟩
  have h4 : H.Adj s z := .inr ⟨(non (aoff za) si).symm,.inl si⟩
  have h5 : H.Adj z t := .inr ⟨non (aoff za) ti,.inr ti⟩
  have h6 : H.Adj t u := .inr ⟨tu,.inr ui⟩
  have h7 : H.Adj u q := .inr ⟨uq,.inl ui⟩
  have pe : RouteOn H {x,r,y,s,z,t,u,q} x q := by
    apply (RouteOn.edge h7).prefix h6 (by simp [tu,tq]) |>.prefix h5 _
      |>.prefix h4 _ |>.prefix h3 _ |>.prefix h2 _ |>.prefix h1 _
    · simp [non (aoff za) ti,non (aoff za) ui,aq za]
    · simp [non (aoff za) si,st,su,sq,Ne.symm (non (aoff za) si)]
    · simp [non (aoff ya) si,yz,non (aoff ya) ti,non (aoff ya) ui,aq ya]
    · simp [Ne.symm (non (aoff ya) ri),Ne.symm (non (aoff za) ri),rs,rt,ru,rq]
    · simp [non (aoff xa) ri,xy,non (aoff xa) si,xz,non (aoff xa) ti,non (aoff xa) ui,aq xa]
  have es : ({x,r,y,s,z,t,u,q}:Finset V)=S.L := by
    rw [←left_port_partition S far]
    change _=A∪B∪I
    rw [ae,be,ie']
    ext w
    simp [or_comm,or_left_comm,or_assoc]
  have pe' : RouteOn H S.L x q := by rw [←es]; exact pe
  exact ⟨x,q,(mem_filter.mp xa).2,(mem_filter.mp qb).2,
    transfer_terminal_completed_inner S eight far high (mem_filter.mp xa).1 (mem_filter.mp qb).1 pe'⟩

#print axioms terminal_high_eight_one_b
end Graffiti189LongestPath.CrossSaturation.Split.Five
