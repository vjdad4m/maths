import DegreeFiveBothBridgeVisibility189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset ArticulationPair
open private left_boundary from AdjacentCut189
open private not_common from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false
set_option maxHeartbeats 100000
set_option maxRecDepth 1000

theorem high_shore_internal_four (far : 3≤G.dist a b) {u : V} (ul : u∈S.L)
    (hu : 5≤G.degree u) : 4≤(S.L.filter (G.Adj u)).card := by
  classical
  let I := S.L.filter (G.Adj u)
  have step (c : V) (sub : G.neighborFinset u⊆insert c I) : 4≤I.card := by
    have h := (card_le_card sub).trans (card_insert_le c I)
    rw [card_neighborFinset_eq_degree] at h
    omega
  by_cases bu : G.Adj b u
  · apply step b
    intro w wm
    have uw := (mem_neighborFinset G u w).mp wm
    rcases left_boundary S u ul w uw with e|e|wl
    · exact (not_common far (e ▸ uw.symm) bu).elim
    · exact mem_insert.mpr (.inl e)
    exact mem_insert_of_mem (mem_filter.mpr ⟨wl,uw⟩)
  apply step a
  intro w wm
  have uw := (mem_neighborFinset G u w).mp wm
  rcases left_boundary S u ul w uw with e|e|wl
  · exact mem_insert.mpr (.inl e)
  · exact (bu (e ▸ uw.symm)).elim
  exact mem_insert_of_mem (mem_filter.mpr ⟨wl,uw⟩)

#print axioms high_shore_internal_four
end Graffiti189LongestPath.CrossSaturation.Split.Five
