import DegreeFiveBothBridgeLargeProfile189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset ArticulationPair
open private left_boundary from AdjacentCut189
open private d2 from CrossSaturation189
open private not_common secondA_right_and_left_le_five from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem five_a_ports_b_visible (hc : G.Connected) (far : 3≤G.dist a b)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (five : S.L.card=5) :
    S.localA⊆secondA G S.L b := by
  intro u uA
  obtain ⟨uL,au⟩ := mem_filter.mp uA
  obtain ⟨q,qL,bq⟩ := S.leftB
  have uq : u≠q := fun e=>not_common far (e ▸ au) bq
  have qu : G.Adj q u := by
    rcases degree u q uq with hi|hi
    · exact (high_far_port_shore_universal_at_five S far five uL hi (.inl au) q qL uq).symm
    · exact high_far_port_shore_universal_at_five S far five qL hi (.inr bq) u uL uq.symm
  have ne : b≠u := fun e=>S.leftOff.2 (e.symm ▸ uL)
  exact mem_inter.mpr ⟨uL,d2 hc ne (fun h=>not_common far au h) bq qu⟩

/-- With exactly three left b-ports and three b-visible opposite a-ports,
there are exactly two left outsiders to the b-class and the class is a
clique. Every high b-port sees both outsiders. -/
theorem large_shore_b_geometry (hc : G.Connected) (far : 3≤G.dist a b)
    (even : ∀ v,(EvenFrom G v).card≤6)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (foreign3 : S.foreignA.card=3)
    (b3 : (S.L.filter (G.Adj b)).card=3)
    (rfive : S.R.card=5)
    (rc : (G.induce (↑S.R : Set V)).Connected)
    (ra : ∃ x∈S.R,G.Adj a x) (rb : ∃ x∈S.R,G.Adj b x) :
    (secondA G S.L b).card=2 ∧ CompleteOn G (S.L.filter (G.Adj b)) ∧
      ∀ u∈S.L.filter (G.Adj b),5≤G.degree u →
        ∀ v∈secondA G S.L b,G.Adj u v := by
  classical
  let T := switch S rc ra rb
  let B := S.L.filter (G.Adj b)
  let W := secondA G S.L b
  have cb : B.card=3 := b3
  have td := card_le_card (five_a_ports_b_visible T hc far degree rfive)
  change S.foreignA.card≤(secondA G S.R b).card at td
  have tot := secondA_right_and_left_le_five S.flip even
  change W.card+(secondA G S.R b).card≤5 at tot
  have wc : W.card≤2 := by omega
  have dis : Disjoint B W := by
    apply disjoint_left.mpr
    intro u ub uw
    have h1 := dist_eq_one_iff_adj.mpr (mem_filter.mp ub).2
    have h2 : G.dist b u=2 := by simpa [DistanceTwo] using (mem_inter.mp uw).2
    omega
  have ne {u v : V} (ub : u∈B) (vw : v∈W) : u≠v :=
    fun e=>disjoint_left.mp dis ub (e.symm ▸ vw)
  have candid {u : V} (ub : u∈B) :
      G.neighborFinset u⊆insert b ((B.erase u)∪W) := by
    intro v vm
    obtain ⟨ul,bu⟩ := mem_filter.mp ub
    have uv := (mem_neighborFinset G u v).mp vm
    rcases left_boundary S u ul v uv with e|e|vl
    · exact (not_common far (e ▸ uv.symm) bu).elim
    · exact mem_insert.mpr (.inl e)
    by_cases bv : G.Adj b v
    · exact mem_insert_of_mem (mem_union.mpr (.inl (mem_erase.mpr
        ⟨uv.ne.symm,mem_filter.mpr ⟨vl,bv⟩⟩)))
    have bv' : b≠v := fun e=>S.leftOff.2 (e.symm ▸ vl)
    exact mem_insert_of_mem (mem_union.mpr (.inr (mem_inter.mpr ⟨vl,d2 hc bv' bv bu uv⟩)))
  have hBound {u : V} (ub : u∈B) : (insert b ((B.erase u)∪W)).card≤W.card+3 := by
    have c := card_insert_le b ((B.erase u)∪W)
    have k := card_union_le (B.erase u) W
    rw [card_erase_of_mem ub,cb] at k
    omega
  have completeCand {u : V} (ub : u∈B) (hi : 5≤G.degree u) :
      G.neighborFinset u=insert b ((B.erase u)∪W) := by
    apply eq_of_subset_of_card_le (candid ub)
    rw [card_neighborFinset_eq_degree]
    have bound := hBound ub
    omega
  obtain ⟨u,ub,_,_,_,hi,_⟩ := two_high_points cb degree
  have hc' := (card_le_card (candid ub)).trans (hBound ub)
  rw [card_neighborFinset_eq_degree] at hc'
  have w2 : W.card=2 := by omega
  have toB {u v : V} (ub : u∈B) (vb : v∈B) (uv : u≠v) (hi : 5≤G.degree u) :
      G.Adj u v := by
    apply (mem_neighborFinset G _ _).mp
    rw [completeCand ub hi]
    exact mem_insert_of_mem (mem_union.mpr (.inl (mem_erase.mpr ⟨uv.symm,vb⟩)))
  have cl : CompleteOn G B := by
    intro x xb y yb ne
    exact (degree x y ne).elim (toB xb yb ne) (fun h=>(toB yb xb ne.symm h).symm)
  refine ⟨w2,cl,?_⟩
  intro u ub hi v vw
  apply (mem_neighborFinset G _ _).mp
  rw [completeCand ub hi]
  exact mem_insert_of_mem (mem_union.mpr (.inr vw))

#print axioms large_shore_b_geometry
end Graffiti189LongestPath.CrossSaturation.Split.Five
