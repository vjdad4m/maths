import DegreeFiveBothBridgeFacts189
import DegreeFiveRouteBasic189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph Finset
open private left_boundary from AdjacentCut189
open private d2 from CrossSaturation189
open private not_common secondA_right_and_left_le_five from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem a_port_degree_bound_visible (hc : G.Connected) (far : 3≤G.dist a b)
    {x : V} (xa : x∈S.localA) :
    G.degree x≤S.localA.card+(secondA G S.L a).card := by
  classical
  obtain ⟨xl,ax⟩ := mem_filter.mp xa
  have nx : ¬G.Adj b x := fun h=>not_common far ax h
  have sub : G.neighborFinset x⊆insert a ((S.localA.erase x)∪secondA G S.L a) := by
    intro y hy
    have xy := (mem_neighborFinset G x y).mp hy
    rcases left_boundary S x xl y xy with e|e|yl
    · exact mem_insert.mpr (.inl e)
    · exact (nx (e ▸ xy.symm)).elim
    by_cases ay : G.Adj a y
    · exact mem_insert_of_mem (mem_union.mpr (.inl (mem_erase.mpr
        ⟨xy.ne.symm,mem_filter.mpr ⟨yl,ay⟩⟩)))
    have ne : a≠y := fun e=>S.leftOff.1 (e.symm ▸ yl)
    exact mem_insert_of_mem (mem_union.mpr (.inr (mem_inter.mpr ⟨yl,d2 hc ne ay ax xy⟩)))
  have h₁ := (card_le_card sub).trans (card_insert_le a ((S.localA.erase x)∪secondA G S.L a))
  have h₂ := card_union_le (S.localA.erase x) (secondA G S.L a)
  rw [card_neighborFinset_eq_degree] at h₁
  rw [card_erase_of_mem (show x∈S.localA from mem_filter.mpr ⟨xl,ax⟩)] at h₂
  have h₃ := card_pos.mpr ⟨x,show x∈S.localA from mem_filter.mpr ⟨xl,ax⟩⟩
  omega

theorem three_a_shore_at_least_five (far : 3≤G.dist a b)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (a3 : S.localA.card=3) : 5≤S.L.card := by
  have ⟨p,pa,q,qa,_,pHi,_⟩ := two_high_points a3 degree
  have hp := high_shore_internal_four S far (mem_filter.mp pa).1 pHi
  have sub : S.L.filter (G.Adj p) ⊆ S.L.erase p := by
    intro x xx
    obtain ⟨xl,px⟩ := mem_filter.mp xx
    exact mem_erase.mpr ⟨px.ne.symm,xl⟩
  have h := hp.trans (card_le_card sub)
  rw [card_erase_of_mem (mem_filter.mp pa).1] at h
  omega

theorem large_shore_invisible_exact (hc : G.Connected) (far : 3≤G.dist a b)
    (even : ∀ v,(EvenFrom G v).card≤6)
    (conn : ∀ R : Finset V,R.card<2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (local3 : S.localA.card=3) (foreign3 : S.foreignA.card=3)
    (b3 : (S.L.filter (G.Adj b)).card≤3)
    (rc : (G.induce (↑S.R : Set V)).Connected)
    (ra : ∃ x∈S.R,G.Adj a x) (rb : ∃ x∈S.R,G.Adj b x)
    (bl : portBridge S) (br : portBridge (switch S rc ra rb))
    (big : 9≤S.L.card) :
    S.L.card=9 ∧ S.R.card=5 ∧ (S.L.filter (G.Adj b)).card=3 ∧
    (farNonports S.L a b G).card=3 ∧
    ((farNonports S.L a b G) \ secondA G S.L a).card=1 := by
  classical
  let T := switch S rc ra rb
  let I := farNonports S.L a b G
  let L2 := secondA G S.L a
  let R2 := secondA G S.R a
  let B := S.L.filter (G.Adj b)
  have ta3 : T.localA.card=3 := foreign3
  have tb3 : T.foreignA.card=3 := local3
  have ⟨tot,vis,dark⟩ := both_bridge_nonport_cap S hc far even conn local3 foreign3 rc ra rb bl br
  have cnt : S.localA.card+B.card+I.card=S.L.card := left_port_count S far
  change B.card≤3 at b3
  have i3 : 3≤I.card := by omega
  obtain ⟨z,z2,zn⟩ := bridge_visible_bport S hc far bl
  have z₂ : z∈L2 := z2
  have counts : (I∩L2).card+1≤L2.card := by
    have n : z∉I∩L2 := fun h=>zn (mem_inter.mp h).1
    have c := card_le_card (show insert z (I∩L2)⊆L2 from fun u uI=>
      (mem_insert.mp uI).elim (fun h=>h.symm ▸ z₂) (fun h=>(mem_inter.mp h).2))
    rwa [card_insert_of_not_mem n] at c
  have dPos : 0<(I\L2).card := by
    by_contra h
    have ne : I\L2=∅ := card_eq_zero.mp (by omega)
    have c := card_sdiff_add_card_inter I L2
    rw [ne,card_empty,zero_add] at c
    have hsum := secondA_right_and_left_le_five S even
    change L2.card+R2.card≤5 at hsum
    have small : R2.card≤1 := by omega
    obtain ⟨p,pa,_,_,_,pHi,_⟩ := two_high_points ta3 degree
    have pBound := a_port_degree_bound_visible T hc far pa
    change G.degree p≤T.localA.card+R2.card at pBound
    omega
  change (I\L2).card+_≤1 at dark
  have deq : (I\L2).card=1 := by omega
  obtain ⟨p,pl,q,_,ap,pq,bq⟩ := br
  have universal : ∀ w∈T.L,p≠w → G.Adj p w := by
    intro w wl ne
    by_contra n
    have v := nonuniversal_bridge_opposite_visible T hc far even conn tb3 pl ap pq bq wl ne n
    have e : I\L2=∅ := sdiff_eq_empty_iff_subset.mpr v
    rw [e,card_empty] at deq
    omega
  let P := T.L\T.localA
  have pSub : P⊆R2 := by
    intro w hw
    obtain ⟨wl,wa⟩ := mem_sdiff.mp hw
    have aw : ¬G.Adj a w := fun h=>wa (mem_filter.mpr ⟨wl,h⟩)
    have pw : p≠w := fun h=>aw (h ▸ ap)
    have ne : a≠w := fun h=>T.leftOff.1 (h.symm ▸ wl)
    exact mem_inter.mpr ⟨wl,d2 hc ne aw ap (universal w wl pw)⟩
  have per := card_le_card pSub
  have psum := card_sdiff_add_card_eq_card (filter_subset (G.Adj a) T.L)
  change P.card+T.localA.card=S.R.card at psum
  have hR5 : 5≤S.R.card := three_a_shore_at_least_five T far degree ta3
  have cv := card_sdiff_add_card_inter I L2
  have hs := secondA_right_and_left_le_five S even
  change L2.card+R2.card≤5 at hs
  have right5 : S.R.card=5 := by omega
  have ieq : I.card=3 := by omega
  have left9 : S.L.card=9 := by omega
  have beq : B.card=3 := by omega
  exact ⟨left9,right5,beq,ieq,deq⟩

#print axioms large_shore_invisible_exact
end Graffiti189LongestPath.CrossSaturation.Split.Five
