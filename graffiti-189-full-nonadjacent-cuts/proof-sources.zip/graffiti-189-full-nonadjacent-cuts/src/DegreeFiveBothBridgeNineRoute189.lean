import DegreeFiveBothBridgeNineTools189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset ArticulationPair
open private d2 from CrossSaturation189
open private not_common from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem terminal_large_both_bridge_shore (hc : G.Connected) (far : 3≤G.dist a b)
    (even : ∀ v,(EvenFrom G v).card≤6)
    (conn : ∀ R : Finset V,R.card<2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (a3 : S.localA.card=3) (f3 : S.foreignA.card=3)
    (bcap : (S.L.filter (G.Adj b)).card≤3)
    (rc : (G.induce (↑S.R : Set V)).Connected)
    (ra : ∃ x∈S.R,G.Adj a x) (rb : ∃ x∈S.R,G.Adj b x)
    (bl : portBridge S) (br : portBridge (switch S rc ra rb))
    (big : 9≤S.L.card) :
    ∃ x y,G.Adj a x ∧ G.Adj b y ∧ RouteOn G S.L x y := by
  classical
  let A := S.localA
  let B := S.L.filter (G.Adj b)
  let I := farNonports S.L a b G
  let W := secondA G S.L b
  let D := I\secondA G S.L a
  have ac : A.card=3 := a3
  obtain ⟨_,r5,b3,i3,d1⟩ := large_shore_invisible_exact S hc far even conn degree
    a3 f3 bcap rc ra rb bl br big
  have bc : B.card=3 := b3
  have ic : I.card=3 := i3
  have dc : D.card=1 := d1
  have ⟨wc,bClique,seeW⟩ := large_shore_b_geometry S hc far even degree f3 b3 r5 rc ra rb
  change W.card=2 at wc
  obtain ⟨t,tdEq⟩ := card_eq_one.mp dc
  have td : t∈D := by simp [tdEq]
  have ti : t∈I := (mem_sdiff.mp td).1
  have tl : t∈S.L := (mem_filter.mp ti).1
  have vis (u : V) (ui : u∈I) (ut : u≠t) : u∈I∩secondA G S.L a := by
    refine mem_inter.mpr ⟨ui,?_⟩
    by_contra no
    exact ut (by simpa [tdEq] using (show u∈D from mem_sdiff.mpr ⟨ui,no⟩))
  obtain ⟨p,pl,v,vl,ap,pv,bv⟩ := bl
  have pa : p∈A := mem_filter.mpr ⟨pl,ap⟩
  have pw : p∈W := left_b_contact_in_second S hc pl (not_common far ap) bv pv.symm
  have noIW {x y : V} (xa : x∈A) (yi : y∈I) : x≠y :=
    fun e=>(mem_filter.mp yi).2.1 (e ▸ (mem_filter.mp xa).2)
  have disAB : Disjoint A B := disjoint_left.mpr
    (fun _ u v=>not_common far (mem_filter.mp u).2 (mem_filter.mp v).2)
  have disIB : Disjoint I B := disjoint_left.mpr (fun _ u v=>(mem_filter.mp u).2.2 (mem_filter.mp v).2)
  have wNotB {x : V} (xw : x∈W) : x∉B := by
    intro xb
    have h := dist_eq_one_iff_adj.mpr (mem_filter.mp xb).2
    have k : G.dist b x=2 := by simpa [DistanceTwo] using (mem_inter.mp xw).2
    omega
  have Wpair {x : V} (xw : x∈W) (px : p≠x) : W={p,x} := by
    symm
    apply eq_of_subset_of_card_le (insert_subset pw (singleton_subset_iff.mpr xw))
    simp [wc,px]
  have setAll : (A∪I)∪B=S.L := by
    rw [union_right_comm]
    exact left_port_partition S far
  have joinB {x y : V} (xa : x∈A) (yw : y∈W) (pre : RouteOn G (A∪I) x y) :
      ∃ x y,G.Adj a x ∧ G.Adj b y ∧ RouteOn G S.L x y := by
    obtain ⟨r,rb,_,_,_,hi,_⟩ := two_high_points bc degree
    obtain ⟨s,q,qp,qs⟩ := rooted_path_in_clique B bClique rb
    have qr : RouteOn G B r s := ⟨q,qp,qs⟩
    have gg := pre.join qr (disjoint_union_left.mpr ⟨disAB,disIB⟩) (seeW r rb hi y yw).symm
    exact ⟨x,s,(mem_filter.mp xa).2,(mem_filter.mp ((qs _).mp q.end_mem_support)).2,setAll ▸ gg⟩
  have pairI : (I.erase t).card=2 := by rw [card_erase_of_mem ti,ic]
  obtain ⟨r,s,rs,ie⟩ := card_eq_two.mp pairI
  have ri' : r∈I.erase t := by simp [ie]
  have si' : s∈I.erase t := by simp [ie]
  obtain ⟨rt,ri⟩ := mem_erase.mp ri'
  obtain ⟨st,si⟩ := mem_erase.mp si'
  have inner : I={t,r,s} := by rw [←ie,insert_erase ti]
  have pairA : (A.erase p).card=2 := by rw [card_erase_of_mem pa,ac]
  obtain ⟨u,z,uz,ae⟩ := card_eq_two.mp pairA
  have ua' : u∈A.erase p := by simp [ae]
  have za' : z∈A.erase p := by simp [ae]
  obtain ⟨up,ua⟩ := mem_erase.mp ua'
  obtain ⟨zp,za⟩ := mem_erase.mp za'
  have outer : A={p,u,z} := by rw [←ae,insert_erase pa]
  have pz := zp.symm
  have pu := up.symm
  have pt : p≠t := noIW pa ti
  have pr : p≠r := noIW pa ri
  have ps : p≠s := noIW pa si
  have ur : u≠r := noIW ua ri
  have us : u≠s := noIW ua si
  have ut : u≠t := noIW ua ti
  have zr : z≠r := noIW za ri
  have zs : z≠s := noIW za si
  have zt : z≠t := noIW za ti
  have finish {x1 x2 x3 x4 x5 x6 : V} (start : x1∈A) (last : x6∈W)
      (eq : ({x1,x2,x3,x4,x5,x6}:Finset V)=A∪I)
      (n1 : x1∉({x2,x3,x4,x5,x6}:Finset V))
      (n2 : x2∉({x3,x4,x5,x6}:Finset V))
      (n3 : x3∉({x4,x5,x6}:Finset V))
      (n4 : x4≠x6)
      (e1 : G.Adj x1 x2) (e2 : G.Adj x2 x3) (e3 : G.Adj x3 x4)
      (e4 : G.Adj x4 x5) (e5 : G.Adj x5 x6) :
      ∃ x y,G.Adj a x ∧ G.Adj b y ∧ RouteOn G S.L x y :=
    joinB start last (eq ▸ ((RouteOn.three e4 e5 n4).prefix e3 n3 |>.prefix e2 n2 |>.prefix e1 n1))
  have innerFull {x : V} (xi : x∈I) (xw : x∉W) (xh : 5≤G.degree x) :
      (∀ y∈A,G.Adj x y) ∧ (∀ y∈I,y≠x → G.Adj x y) := by
    have fe := nonport_outside_b_full S hc far a3 i3 xi xw xh
    constructor
    · intro y ya
      exact (mem_neighborFinset G _ _).mp (fe.symm ▸ mem_union_left _ ya)
    · intro y yi yx
      exact (mem_neighborFinset G _ _).mp (fe.symm ▸ mem_union_right _ (mem_erase.mpr ⟨yx,yi⟩))
  have outerFull {x : V} (xa : x∈A) (xw : x∉W) (xh : 5≤G.degree x) :
      (∀ y∈A,y≠x → G.Adj x y) ∧ (∀ y∈I,y≠t → G.Adj x y) := by
    have fe := high_a_without_b_contact_full S hc far a3 i3 td xa xw xh
    constructor
    · intro y ya yx
      exact (mem_neighborFinset G _ _).mp (fe.symm ▸ mem_insert_of_mem (mem_union_left _ (mem_erase.mpr ⟨yx,ya⟩)))
    · intro y yi yt
      exact (mem_neighborFinset G _ _).mp (fe.symm ▸ mem_insert_of_mem (mem_union_right _ (mem_erase.mpr ⟨yt,yi⟩)))
  have htwo (rt' : G.Adj p r) (rto : G.Adj r t) :
      (∀ q∈A,p≠q → G.Adj p q) ∧ (∀ q∈I∩secondA G S.L a,G.Adj p q) :=
    a_bridge_saturated_by_dark S hc far even f3 pa pw td
      (d2 hc pt (dark_nonport_no_a S hc td p pa) rt' rto)
  by_cases tw : t∈W
  · have we := Wpair tw pt
    have ro : r∉W := by simp [we,pr.symm,rt]
    have so : s∉W := by simp [we,ps.symm,st]
    have uo : u∉W := by simp [we,up,ut]
    have zo : z∉W := by simp [we,zp,zt]
    have branch {r' s' u' z' : V}
        (hr : r'∈I) (hs : s'∈I) (hu : u'∈A) (hz : z'∈A)
        (hrw : r'∉W) (huw : u'∉W) (rhi : 5≤G.degree r') (uhi : 5≤G.degree u')
        (hrt : r'≠t) (hst : s'≠t) (hrsn : r'≠s') (hup : u'≠p) (hzp : z'≠p) (huz : u'≠z')
        (htot : ({z',p,s',u',r',t}:Finset V)=A∪I) :
        ∃ x y,G.Adj a x ∧ G.Adj b y ∧ RouteOn G S.L x y := by
      have rFull := innerFull hr hrw rhi
      have uFull := outerFull hu huw uhi
      have psat := a_bridge_saturated_by_dark S hc far even f3 pa pw td
        (d2 hc pt (dark_nonport_no_a S hc td p pa) (rFull.1 p pa).symm (rFull.2 t ti hrt.symm))
      exact finish hz tw htot
        (by simp [hzp,huz.symm,noIW hz hs,noIW hz hr,noIW hz ti])
        (by simp [hup.symm,noIW pa hs,noIW pa hr,noIW pa ti])
        (by simp [(noIW hu hs).symm,hrsn.symm,hst])
        (noIW hu ti)
        (psat.1 z' hz hzp.symm).symm (psat.2 s' (vis _ hs hst))
        (uFull.2 s' hs hst).symm (uFull.2 r' hr hrt) (rFull.2 t ti hrt.symm)
    rcases degree r s rs with rh|sh <;> rcases degree u z uz with uh|zh
    · apply branch ri si ua za ro uo rh uh rt st rs up zp uz
      rw [outer,inner]; ext v; simp [or_comm,or_left_comm,or_assoc]
    · apply branch ri si za ua ro zo rh zh rt st rs zp up uz.symm
      rw [outer,inner]; ext v; simp [or_comm,or_left_comm,or_assoc]
    · apply branch si ri ua za so uo sh uh st rt rs.symm up zp uz
      rw [outer,inner]; ext v; simp [or_comm,or_left_comm,or_assoc]
    · apply branch si ri za ua so zo sh zh st rt rs.symm zp up uz.symm
      rw [outer,inner]; ext v; simp [or_comm,or_left_comm,or_assoc]
  have ⟨tNe,tlow⟩ := dark_nonport_outside_b_full S hc far conn i3 td tw
  have tHigh (v : V) (ne : v≠t) : 5≤G.degree v := (degree v t ne).resolve_right (by omega)
  have tr : G.Adj t r := (mem_neighborFinset G _ _).mp (tNe.symm ▸ ri')
  have ts : G.Adj t s := (mem_neighborFinset G _ _).mp (tNe.symm ▸ si')
  obtain ⟨w,wm⟩ := card_pos.mp (show 0<(W.erase p).card by rw [card_erase_of_mem pw,wc]; decide)
  obtain ⟨wp,ww⟩ := mem_erase.mp wm
  have we := Wpair ww wp.symm
  have wl := (mem_inter.mp ww).1
  have wcolor : w∈A ∨ w∈I := by
    have all : w∈A∪B∪I := (left_port_partition S far).symm ▸ wl
    rcases mem_union.mp all with h|h
    · exact .inl ((mem_union.mp h).resolve_right (wNotB ww))
    · exact .inr h
  rcases wcolor with wa|wi
  · have riw : r∉W := by simp [we,pr.symm,(noIW wa ri).symm]
    have siw : s∉W := by simp [we,ps.symm,(noIW wa si).symm]
    have rfull := innerFull ri riw (tHigh r rt)
    have sfull := innerFull si siw (tHigh s st)
    have sat := htwo (rfull.1 p pa).symm tr.symm
    have wCase : w=u ∨ w=z := by have m : w∈A.erase p := mem_erase.mpr ⟨wp,wa⟩; simpa [ae] using m
    rcases wCase with e|e
    · have uw : u∈W := e ▸ ww
      apply finish (x2:=r) (x3:=t) (x4:=s) (x5:=p) za uw (by rw [outer,inner]; ext v; simp [or_comm,or_left_comm,or_assoc])
      · simp [zr,zt,zs,zp,uz.symm]
      · simp [rt,rs,pr.symm,ur.symm]
      · simp [st.symm,pt.symm,ut.symm]
      · exact us.symm
      · exact (rfull.1 z za).symm
      · exact tr.symm
      · exact ts
      · exact sfull.1 p pa
      · exact sat.1 u ua pu
    · have zw : z∈W := e ▸ ww
      apply finish (x2:=r) (x3:=t) (x4:=s) (x5:=p) ua zw (by rw [outer,inner]; ext v; simp [or_comm,or_left_comm,or_assoc])
      · simp [ur,ut,us,up,uz]
      · simp [rt,rs,pr.symm,zr.symm]
      · simp [st.symm,pt.symm,zt.symm]
      · exact zs.symm
      · exact (rfull.1 u ua).symm
      · exact tr.symm
      · exact ts
      · exact sfull.1 p pa
      · exact sat.1 z za pz
  have wt : w≠t := fun e=>tw (e ▸ ww)
  have wCase : w=r ∨ w=s := by have m : w∈I.erase t := mem_erase.mpr ⟨wt,wi⟩; simpa [ie] using m
  have uo : u∉W := by simp [we,up,noIW ua wi]
  have zo : z∉W := by simp [we,zp,noIW za wi]
  have ufull := outerFull ua uo (tHigh u ut)
  have zfull := outerFull za zo (tHigh z zt)
  rcases wCase with e|e
  · have rw' : r∈W := e ▸ ww
    apply finish (x2:=u) (x3:=z) (x4:=s) (x5:=t) pa rw' (by rw [outer,inner]; ext v; simp [or_comm,or_left_comm,or_assoc])
    · simp [pu,pz,ps,pt,pr]
    · simp [uz,us,ut,ur]
    · simp [zs,zt,zr]
    · exact rs.symm
    · exact (ufull.1 p pa pu).symm
    · exact (zfull.1 u ua uz).symm
    · exact zfull.2 s si st
    · exact ts.symm
    · exact tr
  · have sw' : s∈W := e ▸ ww
    apply finish (x2:=u) (x3:=z) (x4:=r) (x5:=t) pa sw' (by rw [outer,inner]; ext v; simp [or_comm,or_left_comm,or_assoc])
    · simp [pu,pz,pr,pt,ps]
    · simp [uz,ur,ut,us]
    · simp [zr,zt,zs]
    · exact rs
    · exact (ufull.1 p pa pu).symm
    · exact (zfull.1 u ua uz).symm
    · exact zfull.2 r ri rt
    · exact tr.symm
    · exact ts

#print axioms terminal_large_both_bridge_shore
end Graffiti189LongestPath.CrossSaturation.Split.Five
