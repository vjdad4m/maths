import DegreeFiveBothBridgeLargeBudget189
import DegreeFiveThreeFiveAll189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset ArticulationPair
open private left_boundary from AdjacentCut189
open private d2 from CrossSaturation189
open private not_common from DegreeFiveFourPort189
open private pair_deletion_min_degree_two from DegreeFiveThreeFiveAll189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem left_b_contact_in_second (hc : G.Connected) {u v : V} (ul : u∈S.L)
    (bu : ¬G.Adj b u) (bv : G.Adj b v) (vu : G.Adj v u) :
    u∈secondA G S.L b :=
  mem_inter.mpr ⟨ul,d2 hc (fun h=>S.leftOff.2 (h.symm ▸ ul)) bu bv vu⟩

theorem left_a_contact_in_second (hc : G.Connected) {u v : V} (ul : u∈S.L)
    (au : ¬G.Adj a u) (av : G.Adj a v) (vu : G.Adj v u) :
    u∈secondA G S.L a :=
  mem_inter.mpr ⟨ul,d2 hc (fun h=>S.leftOff.1 (h.symm ▸ ul)) au av vu⟩

theorem dark_nonport_no_a (hc : G.Connected) {t : V}
    (td : t∈farNonports S.L a b G\secondA G S.L a) :
    ∀ u∈S.localA,¬G.Adj u t := by
  obtain ⟨ti,no⟩ := mem_sdiff.mp td
  obtain ⟨tl,at',_⟩ := mem_filter.mp ti
  intro u ua ut
  exact no (left_a_contact_in_second S hc tl at' (mem_filter.mp ua).2 ut)

theorem nonport_outside_b_neighbors (hc : G.Connected) (_far : 3≤G.dist a b)
    {u : V} (ui : u∈farNonports S.L a b G) (uw : u∉secondA G S.L b) :
    G.neighborFinset u⊆S.localA∪(farNonports S.L a b G).erase u := by
  obtain ⟨ul,au,bu⟩ := mem_filter.mp ui
  intro v vn
  have uv := (mem_neighborFinset G u v).mp vn
  rcases left_boundary S u ul v uv with e|e|vl
  · exact (au (e ▸ uv.symm)).elim
  · exact (bu (e ▸ uv.symm)).elim
  have bv : ¬G.Adj b v := fun e=>uw (left_b_contact_in_second S hc ul bu e uv.symm)
  by_cases av : G.Adj a v
  · exact mem_union_left _ (mem_filter.mpr ⟨vl,av⟩)
  exact mem_union_right _ (mem_erase.mpr ⟨uv.ne.symm,mem_filter.mpr ⟨vl,av,bv⟩⟩)

theorem nonport_outside_b_full (hc : G.Connected) (far : 3≤G.dist a b)
    (a3 : S.localA.card=3) (i3 : (farNonports S.L a b G).card=3)
    {u : V} (ui : u∈farNonports S.L a b G) (uw : u∉secondA G S.L b)
    (hi : 5≤G.degree u) :
    G.neighborFinset u=S.localA∪(farNonports S.L a b G).erase u := by
  have sub := nonport_outside_b_neighbors S hc far ui uw
  have cnt := card_union_le S.localA ((farNonports S.L a b G).erase u)
  rw [a3,card_erase_of_mem ui,i3] at cnt
  apply eq_of_subset_of_card_le sub
  rw [card_neighborFinset_eq_degree]
  omega

theorem dark_nonport_outside_b_neighbors (hc : G.Connected) (far : 3≤G.dist a b)
    {t : V} (td : t∈farNonports S.L a b G\secondA G S.L a)
    (tw : t∉secondA G S.L b) :
    G.neighborFinset t⊆(farNonports S.L a b G).erase t := by
  intro z hz
  rcases mem_union.mp (nonport_outside_b_neighbors S hc far (mem_sdiff.mp td).1 tw hz) with za|zi
  · exact (dark_nonport_no_a S hc td z za ((mem_neighborFinset G _ _).mp hz).symm).elim
  exact zi

theorem dark_nonport_outside_b_full (hc : G.Connected) (far : 3≤G.dist a b)
    (conn : ∀ R : Finset V,R.card<2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (i3 : (farNonports S.L a b G).card=3)
    {t : V} (td : t∈farNonports S.L a b G\secondA G S.L a)
    (tw : t∉secondA G S.L b) :
    G.neighborFinset t=(farNonports S.L a b G).erase t ∧ G.degree t≤2 := by
  have hsub := dark_nonport_outside_b_neighbors S hc far td tw
  have cnt := card_erase_of_mem (mem_sdiff.mp td).1
  rw [i3] at cnt
  have hN : 3≤Fintype.card V := by
    have h := card_le_card (subset_univ (farNonports S.L a b G))
    rwa [i3,card_univ] at h
  have min2 := pair_deletion_min_degree_two hN conn t
  have hi := card_le_card hsub
  rw [card_neighborFinset_eq_degree,cnt] at hi
  exact ⟨eq_of_subset_of_card_le hsub (by rw [card_neighborFinset_eq_degree,cnt]; omega),hi⟩

theorem high_a_without_b_contact_full (hc : G.Connected) (far : 3≤G.dist a b)
    (a3 : S.localA.card=3) (i3 : (farNonports S.L a b G).card=3)
    {t u : V} (td : t∈farNonports S.L a b G\secondA G S.L a)
    (ua : u∈S.localA) (uw : u∉secondA G S.L b) (high : 5≤G.degree u) :
    G.neighborFinset u=insert a ((S.localA.erase u)∪((farNonports S.L a b G).erase t)) := by
  obtain ⟨ul,au⟩ := mem_filter.mp ua
  have bu : ¬G.Adj b u := not_common far au
  have sub : G.neighborFinset u⊆insert a ((S.localA.erase u)∪((farNonports S.L a b G).erase t)) := by
    intro v vn
    have uv := (mem_neighborFinset G u v).mp vn
    rcases left_boundary S u ul v uv with e|e|vl
    · exact mem_insert.mpr (.inl e)
    · exact (bu (e ▸ uv.symm)).elim
    have bv : ¬G.Adj b v := fun e=>uw (left_b_contact_in_second S hc ul bu e uv.symm)
    by_cases av : G.Adj a v
    · exact mem_insert_of_mem (mem_union_left _ (mem_erase.mpr
        ⟨uv.ne.symm,mem_filter.mpr ⟨vl,av⟩⟩))
    have nt : v≠t := fun e=>dark_nonport_no_a S hc td u (mem_filter.mpr ⟨ul,au⟩) (e ▸ uv)
    exact mem_insert_of_mem (mem_union_right _ (mem_erase.mpr ⟨nt,mem_filter.mpr ⟨vl,av,bv⟩⟩))
  apply eq_of_subset_of_card_le sub
  have h₁ := card_insert_le a ((S.localA.erase u)∪((farNonports S.L a b G).erase t))
  have h₂ := card_union_le (S.localA.erase u) ((farNonports S.L a b G).erase t)
  rw [card_erase_of_mem (show u∈S.localA from mem_filter.mpr ⟨ul,au⟩),a3,
    card_erase_of_mem (mem_sdiff.mp td).1,i3] at h₂
  rw [card_neighborFinset_eq_degree]
  omega

theorem a_bridge_saturated_by_dark (hc : G.Connected) (far : 3≤G.dist a b)
    (even : ∀ v,(EvenFrom G v).card≤6) (f3 : S.foreignA.card=3)
    {p t : V} (pa : p∈S.localA) (pw : p∈secondA G S.L b)
    (td : t∈farNonports S.L a b G\secondA G S.L a)
    (t2 : t∈DistanceTwo G p) :
    (∀ q∈S.localA,p≠q → G.Adj p q) ∧
    (∀ q∈farNonports S.L a b G∩secondA G S.L a,G.Adj p q) := by
  classical
  obtain ⟨pl,ap⟩ := mem_filter.mp pa
  have b2 : b∈DistanceTwo G p := by
    simpa [DistanceTwo,dist_comm] using (mem_inter.mp pw).2
  have tl := (mem_filter.mp (mem_sdiff.mp td).1).1
  have tb : t≠b := fun e=>S.leftOff.2 (e ▸ tl)
  have fresh {u : V} (ul : u∈S.L) (ut : u≠t) (u2 : u∈DistanceTwo G p) : False := by
    have ub : u≠b := fun e=>S.leftOff.2 (e ▸ ul)
    have ss : ({u,b,t}:Finset V)⊆insert b S.L := by
      intro v vv
      have c : v=u ∨ v=b ∨ v=t := by simpa using vv
      exact c.elim (fun h=>h.symm ▸ mem_insert_of_mem ul)
        (fun q=>q.elim (fun h=>h.symm ▸ mem_insert_self _ _)
          (fun h=>h.symm ▸ mem_insert_of_mem tl))
    have tt : ({u,b,t}:Finset V)⊆DistanceTwo G p := by
      intro v vv
      have c : v=u ∨ v=b ∨ v=t := by simpa using vv
      exact c.elim (fun h=>h.symm ▸ u2)
        (fun q=>q.elim (fun h=>h.symm ▸ b2) (fun h=>h.symm ▸ t2))
    have n := local_distance_two_at_foreign_three S hc even f3 pl ap ss tt
    rw [show ({u,b,t}:Finset V).card=3 from card_eq_three.mpr ⟨u,b,t,ub,ut,tb.symm,rfl⟩] at n
    omega
  have peers (u : V) (ua : u∈S.localA) (pu : p≠u) : G.Adj p u := by
    obtain ⟨ul,au⟩ := mem_filter.mp ua
    have at' := (mem_filter.mp (mem_sdiff.mp td).1).2.1
    have ut : u≠t := fun e=>at' (e ▸ au)
    by_contra n
    exact fresh ul ut (d2 hc pu n ap.symm au)
  refine ⟨peers,?_⟩
  intro q hi
  obtain ⟨qi,qv⟩ := mem_inter.mp hi
  obtain ⟨ql,aq,_⟩ := mem_filter.mp qi
  have pq : p≠q := fun e=>aq (e ▸ ap)
  have qt : q≠t := fun e=>(mem_sdiff.mp td).2 (e ▸ qv)
  obtain ⟨r,ra,rq⟩ := nonport_a_neighbor S hc far ql (mem_inter.mp qv).2
  by_contra n
  have pr : p≠r := fun e=>n (e.symm ▸ rq)
  exact fresh ql qt (d2 hc pq n (peers r ra pr) rq)

#print axioms dark_nonport_outside_b_full
#print axioms a_bridge_saturated_by_dark
end Graffiti189LongestPath.CrossSaturation.Split.Five
