import DegreeFiveBothBridgeFacts189
import DegreeFiveSevenNoBridgeClose189
import SmallDenseRoute189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset ArticulationPair
open private left_boundary from AdjacentCut189
open private not_common from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false
set_option maxHeartbeats 100000
set_option maxRecDepth 1000

theorem terminal_high_at_most_seven (far : 3≤G.dist a b)
    (small : S.L.card≤7) (high : ∀ u∈S.L, 5≤G.degree u) :
    ∃ p q,G.Adj a p ∧ G.Adj b q ∧ RouteOn G S.L p q := by
  obtain ⟨p,pl,ap⟩ := S.leftA
  obtain ⟨q,ql,bq⟩ := S.leftB
  have pq : p≠q := fun h=>not_common far (h ▸ ap) bq
  refine ⟨p,q,ap,bq,terminal_route_of_dense_finset S.L pl ql pq ?_⟩
  intro u ul
  have m := high_shore_internal_four S far ul (high u ul)
  omega

theorem traceable_both_shores_at_most_seven (far : 3≤G.dist a b)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (local3 : S.localA.card=3) (foreign3 : S.foreignA.card=3)
    (rc : (G.induce (↑S.R : Set V)).Connected)
    (ra : ∃ x∈S.R,G.Adj a x) (rb : ∃ x∈S.R,G.Adj b x)
    (smallL : S.L.card≤7) (smallR : S.R.card≤7)
    :
    ∃ x y,∃ p : G.Walk x y,p.IsPath ∧ ∀ v,v∈p.support := by
  classical
  let T := switch S rc ra rb
  have ta3 : T.localA.card=3 := foreign3
  have tfree := free_route_small_far_shore T far degree (show T.L.card≤8 from smallR.trans (by decide)) (by omega : 2≤T.localA.card)
  have sfree := free_route_small_far_shore S far degree (by omega) (by omega : 2≤S.localA.card)
  by_cases h : ∀ u∈S.L, 5≤G.degree u
  · exact traceable_from_far_terminal_and_free S far (terminal_high_at_most_seven S far smallL h) (.inl tfree)
  push_neg at h
  obtain ⟨u,ul,low⟩ := h
  have hR : ∀ v∈T.L, 5≤G.degree v := by
    intro v vr
    have ne : u≠v := fun e=>disjoint_left.mp S.dis ul (e.symm ▸ vr)
    exact (degree u v ne).resolve_left (by omega)
  exact traceable_from_far_terminal_and_free T far (terminal_high_at_most_seven T far smallR hR) (.inl sfree)

#print axioms terminal_high_at_most_seven
#print axioms traceable_both_shores_at_most_seven
end Graffiti189LongestPath.CrossSaturation.Split.Five
