import DegreeFiveBothBridgeSmall189
import DegreeFiveSmallFarFree189
import DegreeFiveEightTerminalShore189
import SmallDenseRoute189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset ArticulationPair
open private left_boundary from AdjacentCut189
open private not_common from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem terminal_high_eight_two_b_three_a (far : 3≤G.dist a b)
    (small : S.L.card=8) (high : ∀ u∈S.L, 5≤G.degree u)
    (a3 : S.localA.card=3) (b2 : (S.L.filter (G.Adj b)).card=2) :
    ∃ p q,G.Adj a p ∧ G.Adj b q ∧ RouteOn G S.L p q := by
  have none : ∀ v∈S.flip.L,¬(G.Adj b v ∧ G.Adj a v) :=
    fun v _ h=>not_common far h.2 h.1
  obtain ⟨u,_,v,_,bu,av,r⟩ :=
    terminal_route_of_eight_balanced_exclusive_shore S.flip small b2 a3 high none
  exact ⟨v,u,av,bu,r.reverse⟩

/-- Gluing whenever both shores are small and any eight-vertex shore that
could be used as a terminal has exactly two b-ports. The remaining
one- and three-b-porter eight-vertex terminal shapes are not assumed here. -/
theorem traceable_two_bridge_small_two_b_ok (far : 3≤G.dist a b)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (local3 : S.localA.card=3) (foreign3 : S.foreignA.card=3)
    (rc : (G.induce (↑S.R : Set V)).Connected)
    (ra : ∃ x∈S.R,G.Adj a x) (rb : ∃ x∈S.R,G.Adj b x)
    (smallL : S.L.card≤8) (smallR : S.R.card≤8)
    (shapeL : S.L.card=8 → (S.L.filter (G.Adj b)).card=2)
    (shapeR : S.R.card=8 → (S.R.filter (G.Adj b)).card=2) :
    ∃ x y,∃ p : G.Walk x y,p.IsPath ∧ ∀ v,v∈p.support := by
  classical
  let T := switch S rc ra rb
  have ta3 : T.localA.card=3 := foreign3
  have tfree := free_route_small_far_shore T far degree smallR (by omega : 2≤T.localA.card)
  have sfree := free_route_small_far_shore S far degree smallL (by omega : 2≤S.localA.card)
  have term (Q : Split G a b) (high : ∀ u∈Q.L, 5≤G.degree u)
      (hs : Q.L.card≤8) (ha : Q.localA.card=3)
      (shape : Q.L.card=8 → (Q.L.filter (G.Adj b)).card=2) :
      ∃ p q,G.Adj a p ∧ G.Adj b q ∧ RouteOn G Q.L p q := by
    by_cases e : Q.L.card=8
    · exact terminal_high_eight_two_b_three_a Q far e high ha (shape e)
    · exact terminal_high_at_most_seven Q far (by omega) high
  by_cases h : ∀ u∈S.L, 5≤G.degree u
  · exact traceable_from_far_terminal_and_free S far (term S h smallL local3 shapeL) (.inl tfree)
  push_neg at h
  obtain ⟨u,ul,low⟩ := h
  have hR : ∀ v∈T.L, 5≤G.degree v := by
    intro v vr
    have ne : u≠v := fun e=>disjoint_left.mp S.dis ul (e.symm ▸ vr)
    exact (degree u v ne).resolve_left (by omega)
  exact traceable_from_far_terminal_and_free T far (term T hR smallR ta3 shapeR) (.inl sfree)

#print axioms terminal_high_at_most_seven
#print axioms terminal_high_eight_two_b_three_a
#print axioms traceable_two_bridge_small_two_b_ok
end Graffiti189LongestPath.CrossSaturation.Split.Five
