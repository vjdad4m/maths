import DegreeFiveSixInvisibleCap189
import DegreeFiveFarSideSlots189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph Finset
open private left_boundary from AdjacentCut189
open private d2 foreign_subset from CrossSaturation189
open private not_common secondA_right_and_left_le_five from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

/-- A connected shore with a nonuniversal root contains an internal two-step
walk from that root to a non-neighbor. -/
private theorem step_outside_clique {K : SimpleGraph V} {x u v : V}
    (p : K.Walk u v) (hu : u=x ∨ K.Adj x u) (hv : v≠x ∧ ¬K.Adj x v) :
    ∃ y z, K.Adj x y ∧ K.Adj y z ∧ z≠x ∧ ¬K.Adj x z := by
  induction p with
  | nil => exact (hu.elim hv.1 hv.2).elim
  | @cons u w v h p ih =>
    by_cases hw : w=x ∨ K.Adj x w
    · exact ih hw hv
    push_neg at hw
    rcases hu with rfl|hu
    · exact (hw.2 h).elim
    · exact ⟨u,w,hu,h,hw.1,hw.2⟩

theorem nonuniversal_bridge_opposite_visible (hc : G.Connected)
    (far : 3≤G.dist a b) (even : ∀ v,(EvenFrom G v).card≤6)
    (conn : ∀ R : Finset V,R.card<2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (three : S.foreignA.card=3)
    {x y w : V} (xl : x∈S.L) (ax : G.Adj a x) (xy : G.Adj x y) (by' : G.Adj b y)
    (wl : w∈S.L) (xw : x≠w) (n : ¬G.Adj x w) :
    farNonports S.R a b G ⊆ secondA G S.R a := by
  classical
  let X : (↑S.L : Set V) := ⟨x,xl⟩
  let W : (↑S.L : Set V) := ⟨w,wl⟩
  obtain ⟨p⟩ := S.leftConnected.preconnected X W
  obtain ⟨_,⟨z,zl⟩,xj,jz,zx,xz⟩ := step_outside_clique p (.inl rfl)
    ⟨(fun e=>xw (congrArg Subtype.val e).symm),n⟩
  have zd : z∈DistanceTwo G x := d2 hc (fun e=>zx (Subtype.ext e.symm)) xz xj jz
  have no : ¬G.Adj b x := fun h=>not_common far ax h
  have bx : x≠b := fun e=>S.leftOff.2 (e ▸ xl)
  have bd : b∈DistanceTwo G x := d2 hc bx (fun h=>no h.symm) xy by'.symm
  have sub : insert z (insert b S.foreignA)⊆DistanceTwo G x := by
    intro u hu
    rcases mem_insert.mp hu with rfl|hu
    · exact zd
    exact (mem_insert.mp hu).elim (fun e=>e.symm ▸ bd)
      (fun h=>foreign_subset S hc xl ax h)
  have out : b∉S.foreignA := fun h=>S.rightOff.2 (mem_filter.mp h).1
  have zout : z∉insert b S.foreignA := by
    intro h
    rcases mem_insert.mp h with e|e
    · exact S.leftOff.2 (e ▸ zl)
    exact disjoint_left.mp S.dis zl (mem_filter.mp e).1
  have low := card_le_card sub
  rw [card_insert_of_not_mem zout,card_insert_of_not_mem out,three] at low
  have cap := FiveActualCut.four_layer_add_distance_two_le_five even x
  have ecc (u : V) : G.dist x u≤4 := by
    by_contra h
    have high : 2≤(univ.filter (fun w=>G.dist x w=4)).card :=
      layer_card_of_connectivity hc 2 conn (x:=x) (y:=u) 4
        (by decide) (by omega) (inferInstance)
    omega
  intro u hu
  by_contra inv
  obtain ⟨ur,au,bu⟩ := mem_filter.mp hu
  have an : a≠u := fun h=>S.rightOff.1 (h.symm ▸ ur)
  have bn : b≠u := fun h=>S.rightOff.2 (h.symm ▸ ur)
  have la := hc.one_lt_dist_of_ne_of_not_adj an au
  have lb := hc.one_lt_dist_of_ne_of_not_adj bn bu
  have na : G.dist a u≠2 := by
    intro eq
    exact inv (mem_inter.mpr ⟨ur,by simp [DistanceTwo,eq]⟩)
  have eq := cross_metric S.L hc xl (fun h=>disjoint_left.mp S.dis h ur) (left_boundary S)
  have x1 := dist_eq_one_iff_adj.mpr ax.symm
  have x2 : G.dist x b=2 := by simpa [DistanceTwo] using bd
  rw [x1,x2] at eq
  have top := ecc u
  have um : u∈(univ.filter (fun w=>G.dist x w=4)) :=
    mem_filter.mpr ⟨mem_univ u,by omega⟩
  have pos := card_pos.mpr ⟨u,um⟩
  omega

#print axioms nonuniversal_bridge_opposite_visible

theorem bridge_visible_bport (hc : G.Connected) (far : 3≤G.dist a b)
    (bridge : portBridge S) :
    ∃ y∈secondA G S.L a, y∉farNonports S.L a b G := by
  obtain ⟨x,xl,y,yl,ax,xy,by'⟩ := bridge
  have ne : a≠y := fun e=>S.leftOff.1 (e.symm ▸ yl)
  have ayn : ¬G.Adj a y := fun h=>not_common far h by'
  exact ⟨y,mem_inter.mpr ⟨yl,d2 hc ne ayn ax xy⟩,
    fun h=>(mem_filter.mp h).2.2 by'⟩

theorem both_bridge_nonport_cap (hc : G.Connected) (far : 3≤G.dist a b)
    (even : ∀ v,(EvenFrom G v).card≤6)
    (conn : ∀ R : Finset V,R.card<2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (local3 : S.localA.card=3) (foreign3 : S.foreignA.card=3)
    (rc : (G.induce (↑S.R : Set V)).Connected)
    (ra : ∃ x∈S.R,G.Adj a x) (rb : ∃ x∈S.R,G.Adj b x)
    (bl : portBridge S) (br : portBridge (switch S rc ra rb)) :
    (farNonports S.L a b G).card+(farNonports S.R a b G).card≤4 ∧
    ((farNonports S.L a b G)∩secondA G S.L a).card+
      ((farNonports S.R a b G)∩secondA G S.R a).card≤3 ∧
    ((farNonports S.L a b G) \ secondA G S.L a).card+
      ((farNonports S.R a b G) \ secondA G S.R a).card≤1 := by
  classical
  let T := switch S rc ra rb
  let IL := farNonports S.L a b G
  let IR := farNonports S.R a b G
  let AL := secondA G S.L a
  let AR := secondA G S.R a
  obtain ⟨yl,yla,yli⟩ := bridge_visible_bport S hc far bl
  obtain ⟨yr,yra,yri⟩ := bridge_visible_bport T hc far br
  have visible (I A : Finset V) {z : V} (za : z∈A) (zi : z∉I) :
      (I∩A).card+1≤A.card := by
    have n : z∉I∩A := fun h=>zi (mem_inter.mp h).1
    have c := card_le_card (show insert z (I∩A)⊆A from fun u uI=>
      (mem_insert.mp uI).elim (fun h=>h.symm ▸ za) (fun h=>(mem_inter.mp h).2))
    rwa [card_insert_of_not_mem n] at c
  have vl := visible IL AL yla yli
  have vr := visible IR AR yra yri
  have vTot := secondA_right_and_left_le_five S even
  change AL.card+AR.card≤5 at vTot
  obtain ⟨x,xl,y,_,ax,xy,by'⟩ := bl
  obtain ⟨q,qr,p,_,aq,qp,bp⟩ := br
  have dR : (IR\AR).card≤1 :=
    bridge_three_foreign_invisible_cap S hc even conn foreign3 xl ax xy by'
      (fun h=>not_common far ax h)
  have dL : (IL\AL).card≤1 :=
    bridge_three_foreign_invisible_cap T hc even conn local3 qr aq qp bp
      (fun h=>not_common far aq h)
  have dTot : (IL\AL).card+(IR\AR).card≤1 := by
    by_cases H : ∃ w∈S.L, x≠w ∧ ¬G.Adj x w
    · obtain ⟨w,wl,xw,n⟩ := H
      have inn := nonuniversal_bridge_opposite_visible S hc far even conn foreign3 xl ax xy by' wl xw n
      have dz : IR\AR=∅ := sdiff_eq_empty_iff_subset.mpr inn
      rw [dz,card_empty,add_zero]
      exact dL
    have inn : IL⊆AL := by
      intro u hu
      obtain ⟨ul,au,_⟩ := mem_filter.mp hu
      have xu : x≠u := fun e=>au (e ▸ ax)
      have adj : G.Adj x u := by by_contra n; exact H ⟨u,ul,xu,n⟩
      have ne : a≠u := fun e=>S.leftOff.1 (e.symm ▸ ul)
      exact mem_inter.mpr ⟨ul,d2 hc ne au ax adj⟩
    have dz : IL\AL=∅ := sdiff_eq_empty_iff_subset.mpr inn
    rw [dz,card_empty,zero_add]
    exact dR
  have lc : (IL\AL).card+(IL∩AL).card=IL.card := card_sdiff_add_card_inter _ _
  have rc' : (IR\AR).card+(IR∩AR).card=IR.card := card_sdiff_add_card_inter _ _
  refine ⟨?_,?_,dTot⟩
  · change IL.card+IR.card≤4
    omega
  · change (IL∩AL).card+(IR∩AR).card≤3
    omega

#print axioms both_bridge_nonport_cap
end Graffiti189LongestPath.CrossSaturation.Split.Five
