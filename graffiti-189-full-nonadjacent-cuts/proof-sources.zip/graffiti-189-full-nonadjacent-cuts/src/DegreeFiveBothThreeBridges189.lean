import DegreeFiveBothBridgeSmallMixed189
import DegreeFiveSixPortCompleted189
import DegreeFiveBothBridgeNineRoute189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset ArticulationPair
open private not_common from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem terminal_high_eight_three_b (far : 3≤G.dist a b)
    (eight : S.L.card=8) (high : ∀ u∈S.L,5≤G.degree u)
    (a3 : S.localA.card=3) (b3 : (S.L.filter (G.Adj b)).card=3) :
    ∃ p q,G.Adj a p ∧ G.Adj b q ∧ RouteOn G S.L p q := by
  classical
  let A := S.localA
  let B := S.L.filter (G.Adj b)
  let I := farNonports S.L a b G
  let P := A∪B
  have ab : Disjoint A B := disjoint_left.mpr
    (fun v av bv=>not_common far (mem_filter.mp av).2 (mem_filter.mp bv).2)
  have ai : Disjoint A I := disjoint_left.mpr
    (fun v av iv=>(mem_filter.mp iv).2.1 (mem_filter.mp av).2)
  have bi : Disjoint B I := disjoint_left.mpr
    (fun v bv iv=>(mem_filter.mp iv).2.2 (mem_filter.mp bv).2)
  have set : P∪I=S.L := left_port_partition S far
  have psub : P⊆S.L := fun v h=>set ▸ mem_union_left I h
  have i2 : I.card=2 := by
    have h := left_port_count S far
    rw [a3,b3,eight] at h
    change 3+3+I.card=8 at h
    omega
  have mn : ∀ u∈P,2≤(P.filter (G.Adj u)).card := by
    intro u up
    have m := high_shore_internal_four S far (psub up) (high _ (psub up))
    have sub : S.L.filter (G.Adj u)⊆P.filter (G.Adj u)∪I := by
      intro v vm
      obtain ⟨vl,uv⟩ := mem_filter.mp vm
      rcases mem_union.mp (set.symm ▸ vl) with vp|vi
      · exact mem_union_left _ (mem_filter.mpr ⟨vp,uv⟩)
      exact mem_union_right _ vi
    have n := (card_le_card sub).trans (card_union_le _ _)
    omega
  obtain ⟨p,pa,q,qb,h⟩ := three_three_completed_route (G:=G) A B I a3 b3 i2 ab ai bi mn
  have hh : RouteOn (attachComplete G I) S.L p q := by rw [←set]; exact h
  exact ⟨p,q,(mem_filter.mp pa).2,(mem_filter.mp qb).2,
    transfer_terminal_completed_inner S eight far high (mem_filter.mp pa).1 (mem_filter.mp qb).1 hh⟩

theorem terminal_high_small_b_at_most_three (far : 3≤G.dist a b)
    (small : S.L.card≤8) (high : ∀ u∈S.L,5≤G.degree u)
    (a3 : S.localA.card=3) (bc : (S.L.filter (G.Adj b)).card≤3) :
    ∃ p q,G.Adj a p ∧ G.Adj b q ∧ RouteOn G S.L p q := by
  by_cases e : S.L.card=8
  · obtain ⟨q,ql,qb⟩ := S.leftB
    have lo : 0<(S.L.filter (G.Adj b)).card := card_pos.mpr ⟨q,mem_filter.mpr ⟨ql,qb⟩⟩
    by_cases b1 : (S.L.filter (G.Adj b)).card=1
    · exact terminal_high_eight_one_b S far e high a3 b1
    by_cases b2 : (S.L.filter (G.Adj b)).card=2
    · exact terminal_high_eight_two_b_three_a S far e high a3 b2
    exact terminal_high_eight_three_b S far e high a3 (by omega)
  exact terminal_high_at_most_seven S far (by omega) high

/-- At distance at least three, the six a-contacts split three-and-three.
Both shores have an a–b bridge and at most three b-contacts. Then the
original graph has a spanning path. -/
theorem traceable_of_both_three_bridges (hc : G.Connected) (far : 3≤G.dist a b)
    (even : ∀ v,(EvenFrom G v).card≤6)
    (conn : ∀ R : Finset V,R.card<2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (l3 : S.localA.card=3) (r3 : S.foreignA.card=3)
    (lc : (S.L.filter (G.Adj b)).card≤3) (bc : (S.R.filter (G.Adj b)).card≤3)
    (rc : (G.induce (↑S.R : Set V)).Connected)
    (ra : ∃ x∈S.R,G.Adj a x) (rb : ∃ x∈S.R,G.Adj b x)
    (bl : portBridge S) (br : portBridge (switch S rc ra rb)) :
    ∃ x y,∃ p : G.Walk x y,p.IsPath ∧ ∀ z,z∈p.support := by
  classical
  let T := switch S rc ra rb
  have tl3 : T.localA.card=3 := r3
  have tr3 : T.foreignA.card=3 := l3
  have tlc : (T.L.filter (G.Adj b)).card≤3 := bc
  by_cases lsmall : S.L.card≤8
  · by_cases rsmall : S.R.card≤8
    · have smT : T.L.card≤8 := rsmall
      by_cases h : ∀ u∈S.L,5≤G.degree u
      · have term := terminal_high_small_b_at_most_three S far lsmall h l3 lc
        have free := free_route_small_far_shore T far degree smT (by omega : 2≤T.localA.card)
        exact traceable_from_far_terminal_and_free S far term (.inl free)
      push_neg at h
      obtain ⟨u,ul,low⟩ := h
      have tHi : ∀ v∈T.L,5≤G.degree v := by
        intro v vr
        have ne : u≠v := fun e=>disjoint_left.mp S.dis ul (e.symm ▸ vr)
        exact (degree u v ne).resolve_left (by omega)
      have term := terminal_high_small_b_at_most_three T far smT tHi tl3 tlc
      have free := free_route_small_far_shore S far degree lsmall (by omega : 2≤S.localA.card)
      exact traceable_from_far_terminal_and_free T far term (.inl free)
    have stb : portBridge (switch T S.leftConnected S.leftA S.leftB) := bl
    have big : 9≤T.L.card := by change 9≤S.R.card; omega
    have term := terminal_large_both_bridge_shore T hc far even conn degree tl3 tr3 tlc
      S.leftConnected S.leftA S.leftB br stb big
    have free := free_route_small_far_shore S far degree lsmall (by omega : 2≤S.localA.card)
    exact traceable_from_far_terminal_and_free T far term (.inl free)
  · have big : 9≤S.L.card := by omega
    have rn := (large_shore_invisible_exact S hc far even conn degree l3 r3 lc rc ra rb bl br big).2.1
    have tsmall : T.L.card≤8 := show S.R.card≤8 by omega
    have term := terminal_large_both_bridge_shore S hc far even conn degree l3 r3 lc rc ra rb bl br big
    have free := free_route_small_far_shore T far degree tsmall (by omega : 2≤T.localA.card)
    exact traceable_from_far_terminal_and_free S far term (.inl free)

#print axioms traceable_of_both_three_bridges
end Graffiti189LongestPath.CrossSaturation.Split.Five
