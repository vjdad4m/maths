import DegreeFiveDistanceTwoAll189
import DegreeFiveFarCutDispatch189

namespace Graffiti189LongestPath.CrossSaturation.FiveActualCut
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph order_ge_three_from_dist from DegreeFiveActualCut189

variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

theorem traceable_at_actual_five_nonadjacent_cut_of_degree_six
    (six : ∀ {a b : V}, G.Connected → G.dist a b = 3 →
      (∀ x, (EvenFrom G x).card ≤ 6) →
      (∀ R : Finset V, R.card < 2 → (G.induce ((↑R : Set V)ᶜ)).Connected) →
      (∀ u v : V, u ≠ v → 5 ≤ G.degree u ∨ 5 ≤ G.degree v) →
      ¬(G.induce {z : V | z ≠ a ∧ z ≠ b}).Connected →
      G.degree a = 6 →
      ∃ r t, ∃ p : G.Walk r t, p.IsPath ∧ ∀ z, z ∈ p.support)
    {a b : V} (hc : G.Connected) (ne : a ≠ b) (nonedge : ¬ G.Adj a b)
    (even : ∀ x, (EvenFrom G x).card ≤ 6)
    (conn : ∀ R : Finset V, R.card < 2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V, u ≠ v → 5 ≤ G.degree u ∨ 5 ≤ G.degree v)
    (cut : ¬ (G.induce {z : V | z ≠ a ∧ z ≠ b}).Connected) :
    ∃ r t, ∃ p : G.Walk r t, p.IsPath ∧ ∀ z, z ∈ p.support := by
  classical
  have gt := hc.one_lt_dist_of_ne_of_not_adj ne nonedge
  by_cases two : G.dist a b = 2
  · have order : 3 ≤ Fintype.card V := by
      have hd := degree a b ne
      have da := G.degree_lt_card_verts a
      have db := G.degree_lt_card_verts b
      omega
    have c : 1 < Nat.card (CutGraph (G := G) a b).ConnectedComponent :=
      component_card_gt_one_of_disconnected a b order cut
    exact traceable_of_actual_five_distance_two_cut hc two even conn degree c
  exact traceable_at_actual_five_far_cut_of_degree_six six hc (by omega) even conn degree cut

#print axioms traceable_at_actual_five_nonadjacent_cut_of_degree_six
end Graffiti189LongestPath.CrossSaturation.FiveActualCut
