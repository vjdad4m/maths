import DegreeFiveBothBridgeVisibility189
import DegreeFiveRouteBasic189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset ArticulationPair
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

/-- On six ports of internal minimum degree two, either four ports form a
path or the six ports split into two complete triangles. -/
theorem six_port_blocks (P : Finset V) (p6 : P.card=6)
    (mn : ∀ x∈P,2≤(P.filter (G.Adj x)).card) :
    (∃ x y z t : V,x∈P ∧ y∈P ∧ z∈P ∧ t∈P ∧
      x≠y ∧ x≠z ∧ x≠t ∧ y≠z ∧ y≠t ∧ z≠t ∧
      G.Adj x y ∧ G.Adj y z ∧ G.Adj z t) ∨
    (∃ C D : Finset V, C.card=3 ∧ D.card=3 ∧ Disjoint C D ∧
      C∪D=P ∧ CompleteOn G C ∧ CompleteOn G D) := by
  classical
  by_cases h : ∃ x y z t : V,x∈P ∧ y∈P ∧ z∈P ∧ t∈P ∧
      x≠y ∧ x≠z ∧ x≠t ∧ y≠z ∧ y≠t ∧ z≠t ∧
      G.Adj x y ∧ G.Adj y z ∧ G.Adj z t
  · exact .inl h
  refine .inr ?_
  obtain ⟨x,xp⟩ := card_pos.mp (show 0<P.card by omega)
  obtain ⟨y,hy,z,hz,yz⟩ := one_lt_card.mp (show 1<(P.filter (G.Adj x)).card by
    have w := mn x xp; omega)
  obtain ⟨yp,xy⟩ := mem_filter.mp hy
  obtain ⟨zp,xz⟩ := mem_filter.mp hz
  have e : G.Adj y z := by
    by_contra no
    have cnt := mn z zp
    have there : ∃ t∈P.filter (G.Adj z), t≠x := by
      have q := card_erase_of_mem (mem_filter.mpr ⟨xp,xz.symm⟩ : x∈P.filter (G.Adj z))
      obtain ⟨t,ht⟩ := card_pos.mp (show 0<((P.filter (G.Adj z)).erase x).card by omega)
      exact ⟨t,(mem_erase.mp ht).2,(mem_erase.mp ht).1⟩
    obtain ⟨t,ht,tx⟩ := there
    obtain ⟨tp,zt⟩ := mem_filter.mp ht
    exact h ⟨y,x,z,t,yp,xp,zp,tp,xy.ne.symm,yz,
      fun w=>no (w.symm ▸ zt.symm),xz.ne,tx.symm,zt.ne,xy.symm,xz,zt⟩
  let C : Finset V := {x,y,z}
  let D := P\C
  have cP : C⊆P := by
    intro u hu
    have eq : u=x ∨ u=y ∨ u=z := by simpa [C] using hu
    exact eq.elim (fun eq=>eq.symm ▸ xp)
      (fun eq=>eq.elim (fun eq=>eq.symm ▸ yp) (fun eq=>eq.symm ▸ zp))
  have c3 : C.card=3 := card_eq_three.mpr ⟨x,y,z,xy.ne,xz.ne,yz,rfl⟩
  have d3 : D.card=3 := by
    change (P\C).card=3
    rw [card_sdiff cP,p6,c3]
  have cd : Disjoint C D := disjoint_left.mpr (fun u uc ud=>(mem_sdiff.mp ud).2 uc)
  have cut : ∀ u∈C,∀ v∈D,¬G.Adj u v := by
    intro u uc v vd uv
    obtain ⟨vp,vnc⟩ := mem_sdiff.mp vd
    have vx : v≠x := fun s=>vnc (by simp [C,s])
    have vy : v≠y := fun s=>vnc (by simp [C,s])
    have vz : v≠z := fun s=>vnc (by simp [C,s])
    have all : u=x ∨ u=y ∨ u=z := by simpa [C] using uc
    rcases all with ex|ey|ez
    · rw [ex] at uv
      exact h ⟨z,y,x,v,zp,yp,xp,vp,yz.symm,xz.ne.symm,vz.symm,xy.ne.symm,vy.symm,vx.symm,e.symm,xy.symm,uv⟩
    · rw [ey] at uv
      exact h ⟨z,x,y,v,zp,xp,yp,vp,xz.ne.symm,yz.symm,vz.symm,xy.ne,vx.symm,vy.symm,xz.symm,xy,uv⟩
    · rw [ez] at uv
      exact h ⟨x,y,z,v,xp,yp,zp,vp,xy.ne,xz.ne,vx.symm,yz,vy.symm,vz.symm,xy,e,uv⟩
  have comp : CompleteOn G C := by
    intro u uc v vc ne
    have uu : u=x ∨ u=y ∨ u=z := by simpa [C] using uc
    have vv : v=x ∨ v=y ∨ v=z := by simpa [C] using vc
    rcases uu with rfl|rfl|rfl <;> rcases vv with rfl|rfl|rfl
    all_goals first | exact (ne rfl).elim | exact xy | exact xz | exact xy.symm | exact e | exact xz.symm | exact e.symm
  have compD : CompleteOn G D := by
    intro u ud v vd uv
    have sub : P.filter (G.Adj u)⊆D.erase u := by
      intro w hw
      obtain ⟨wp,uw⟩ := mem_filter.mp hw
      have woff : w∉C := fun wc=>cut w wc u ud uw.symm
      exact mem_erase.mpr ⟨uw.ne.symm,mem_sdiff.mpr ⟨wp,woff⟩⟩
    have eq : P.filter (G.Adj u)=D.erase u := by
      apply eq_of_subset_of_card_le sub
      rw [card_erase_of_mem ud,d3]
      exact mn u (mem_sdiff.mp ud).1
    have hv : v∈P.filter (G.Adj u) := eq.symm ▸ (mem_erase.mpr ⟨uv.symm,vd⟩)
    exact (mem_filter.mp hv).2
  have ce : C∪D=P := union_sdiff_of_subset cP
  exact ⟨C,D,c3,d3,cd,ce,comp,compD⟩

#print axioms six_port_blocks
end Graffiti189LongestPath.CrossSaturation.Split.Five
