import DegreeFiveSixThreeChargeFull189
import DegreeFiveSevenMixedDrop24189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private d2 from CrossSaturation189
open private not_common from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem four_a_bridge_one_inner_free_foreign_two (hc : G.Connected) (far : 3≤G.dist a b)
    (even : ∀ z,(EvenFrom G z).card≤6)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (a4 : S.localA.card=4) (b4 : (S.L.filter (G.Adj b)).card=4)
    (i1 : (farNonports S.L a b G).card=1)
    (w1 : (visibleBPorts S.L a b G).card≤1) (foreign : S.foreignA.card=2)
    (showI : farNonports S.L a b G⊆secondA G S.L a) (bridge : portBridge S) :
    ∃ u v,G.Adj a u ∧ RouteOn G S.L u v := by
  classical
  let A := S.localA
  let B := S.L.filter (G.Adj b)
  let I := farNonports S.L a b G
  let W := visibleBPorts S.L a b G
  let T := B\W
  let H := T.filter (fun x=>5≤G.degree x)
  change A.card=4 at a4
  change B.card=4 at b4
  change I.card=1 at i1
  change W.card≤1 at w1
  have wb : W⊆B := fun _ hw=>mem_filter.mpr ⟨(mem_filter.mp hw).1,(mem_filter.mp hw).2.1⟩
  have tb : T⊆B := sdiff_subset
  have ht : H⊆T := filter_subset _ _
  have bL : B⊆S.L := filter_subset _ _
  have sep : Disjoint A B := disjoint_left.mpr
    (fun x xa xb=>not_common far (mem_filter.mp xa).2 (mem_filter.mp xb).2)
  obtain ⟨p,pl,v,vl,ap,pv,bv⟩ := bridge
  have pa : p∈A := mem_filter.mpr ⟨pl,ap⟩
  have vv : v∈W := mem_filter.mpr ⟨vl,bv,p,pl,ap,pv⟩
  have vb := wb vv
  have wEq : W={v} := (eq_of_subset_of_card_le (singleton_subset_iff.mpr vv)
    (by rw [card_singleton]; exact w1)).symm
  have t3 : T.card=3 := by change (B\W).card=3; rw [card_sdiff wb,b4,wEq,card_singleton]
  have c := count_high_subset_of_one_low degree T
  change T.card≤H.card+1 at c
  have hFull (h : V) (hh : h∈H) :
      (∀ r∈B,h≠r → G.Adj h r) ∧ (∀ r∈I,G.Adj h r) := by
    obtain ⟨ht,h5⟩ := mem_filter.mp hh
    have cand := far_dark_b_port_candidates S far (mem_sdiff.mp ht).1 (mem_sdiff.mp ht).2
    change G.neighborFinset h⊆insert b ((B.erase h)∪I) at cand
    exact far_port_full_at_tight_pool (tb ht) cand (by omega) h5
  have darkNo (q : V) (qt : q∈T) (p : V) (pa : p∈A) : ¬G.Adj p q := by
    obtain ⟨qb,nt⟩ := mem_sdiff.mp qt
    obtain ⟨ql,bq⟩ := mem_filter.mp qb
    obtain ⟨pl,ap⟩ := mem_filter.mp pa
    exact fun h=>nt (mem_filter.mpr ⟨ql,bq,p,pl,ap,h⟩)
  have bOff : b∉H := fun e=>S.leftOff.2 (bL (tb (ht e)))
  have localPool : insert b H⊆insert b B :=
    insert_subset_iff.mpr ⟨mem_insert_self _ _,fun _ rh=>mem_insert_of_mem (tb (ht rh))⟩
  have charges {s : V} (sa : s∈A) (sv : G.Adj s v) : insert b H⊆DistanceTwo G s := by
    have sl := (mem_filter.mp sa).1
    have as' := (mem_filter.mp sa).2
    have ne : s≠b := fun e=>S.leftOff.2 (e ▸ sl)
    apply insert_subset_iff.mpr
    refine ⟨d2 hc ne (fun e=>not_common far as' e.symm) sv bv.symm,?_⟩
    intro j jh
    have jt := ht jh
    have jv : j≠v := fun e=>(mem_sdiff.mp jt).2 (e.symm ▸ vv)
    exact d2 hc (fun e=>disjoint_left.mp sep (e ▸ sa) (tb jt))
      (darkNo j jt s sa) sv ((hFull j jh).1 v vb jv).symm
  have d := local_distance_two_at_foreign_two S hc even foreign pl ap
    (localPool.trans (fun _ hm=>(mem_insert.mp hm).elim (fun e=>mem_insert.mpr (.inl e))
      (fun h=>mem_insert_of_mem (bL h)))) (charges pa pv)
  rw [card_insert_of_not_mem bOff] at d
  have h2 : H.card=2 := by omega
  have one : (T\H).card=1 := by rw [card_sdiff ht,t3,h2]
  obtain ⟨ell,ellm⟩ := card_pos.mp (show 0<(T\H).card by omega)
  obtain ⟨ellT,ellH⟩ := mem_sdiff.mp ellm
  have ellB := tb ellT
  have ellLow : ¬5≤G.degree ell := fun h=>ellH (mem_filter.mpr ⟨ellT,h⟩)
  have each (s : V) (sa : s∈A) :
      (∀ t∈A,s≠t → G.Adj s t) ∧ ∀ t∈I,G.Adj s t := by
    by_cases yes : ∃ t∈B,G.Adj s t
    · obtain ⟨t,tt,st⟩ := yes
      have tm : t∈W :=
        mem_filter.mpr ⟨(mem_filter.mp tt).1,(mem_filter.mp tt).2,s,(mem_filter.mp sa).1,(mem_filter.mp sa).2,st⟩
      have tv : t=v := mem_singleton.mp (wEq ▸ tm)
      exact three_charges_force_full_on_a_and_nonports S hc far even foreign showI sa
        (by rw [card_insert_of_not_mem bOff,h2]) localPool (charges sa (tv ▸ st))
    have hi := (degree s ell (fun e=>disjoint_left.mp sep (e ▸ sa) ellB)).resolve_right ellLow
    have sub := bounds_of_local_color_port S far sa (fun q qb sq=>yes ⟨q,qb,sq⟩)
    change G.neighborFinset s⊆insert a ((A.erase s)∪I) at sub
    exact far_port_full_at_tight_pool sa sub (by omega) hi
  let U := A∪I
  have Ucl : CompleteOn G U := by
    intro x xu y yu ne
    rcases mem_union.mp xu with xa|xi
    · exact (mem_union.mp yu).elim (fun ya=>(each x xa).1 y ya ne) (fun yi=>(each x xa).2 y yi)
    rcases mem_union.mp yu with ya|yi
    · exact ((each y ya).2 x xi).symm
    have z := one_lt_card.mpr ⟨x,xi,y,yi,ne⟩
    omega
  obtain ⟨h,hh,k,kk,hk⟩ := one_lt_card.mp (show 1<H.card by omega)
  have hb := tb (ht hh)
  have kb := tb (ht kk)
  have hv : h≠v := fun e=>(mem_sdiff.mp (ht hh)).2 (e.symm ▸ vv)
  have kv : k≠v := fun e=>(mem_sdiff.mp (ht kk)).2 (e.symm ▸ vv)
  have ellv : ell≠v := fun e=>(mem_sdiff.mp ellT).2 (e.symm ▸ vv)
  have ellh : ell≠h := fun e=>ellH (e.symm ▸ hh)
  have ellk : ell≠k := fun e=>ellH (e.symm ▸ kk)
  have vh := ((hFull h hh).1 v vb hv).symm
  have hl := (hFull h hh).1 ell ellB ellh.symm
  have lk := ((hFull k kk).1 ell ellB ellk.symm).symm
  have Btail := (RouteOn.three vh hl ellv.symm).suffix lk (by simp [kv,Ne.symm hk,ellk.symm])
  have beq : insert k ({v,h,ell} : Finset V)=B := by
    apply eq_of_subset_of_card_le
    · exact insert_subset_iff.mpr ⟨kb,insert_subset_iff.mpr ⟨vb,insert_subset_iff.mpr ⟨hb,singleton_subset_iff.mpr ellB⟩⟩⟩
    rw [b4]
    simp [kv,Ne.symm hk,ellk.symm,hv.symm,ellv.symm,ellh.symm]
  have Bpath : RouteOn G B v k := beq ▸ Btail
  have pd : ∃ q∈A,q≠p := by
    obtain ⟨q,qq⟩ := card_pos.mp (show 0<(A.erase p).card by rw [card_erase_of_mem pa,a4]; decide)
    exact ⟨q,(mem_erase.mp qq).2,(mem_erase.mp qq).1⟩
  obtain ⟨q,qa,qp⟩ := pd
  obtain ⟨r,rp,rs⟩ := path_between_in_clique U Ucl (mem_union_left _ qa) (mem_union_left _ pa) qp
  have Apath : RouteOn G U q p := ⟨r,rp,rs⟩
  have dis : Disjoint U B := disjoint_union_left.mpr ⟨sep,
    disjoint_left.mpr (fun x xi xb=>(mem_filter.mp xi).2.2 (mem_filter.mp xb).2)⟩
  have cover : U∪B=S.L := by
    change (A∪I)∪B=S.L
    rw [union_right_comm]
    exact left_port_partition S far
  exact ⟨q,k,(mem_filter.mp qa).2,cover ▸ Apath.join Bpath dis pv⟩

#print axioms four_a_bridge_one_inner_free_foreign_two
end Graffiti189LongestPath.CrossSaturation.Split.Five
