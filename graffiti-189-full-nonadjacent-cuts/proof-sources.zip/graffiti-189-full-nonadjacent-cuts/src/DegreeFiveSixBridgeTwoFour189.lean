import DegreeFiveSixTwoPeripheral189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private d2 from CrossSaturation189
open private left_boundary from AdjacentCut189
open private not_common from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Graffiti189LongestPath.CrossSaturation.Split G a b)
set_option linter.unusedSectionVars false

theorem bridge_route_at_two_four (hc : G.Connected) (far : 3≤G.dist a b)
    (even : ∀ x,(EvenFrom G x).card≤6)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (localTwo : S.localA.card=2)
    (foreignFour : S.foreignA.card=4)
    (rightConnected : (G.induce (↑S.R : Set V)).Connected)
    (rightA : ∃ x∈S.R,G.Adj a x) (rightB : ∃ x∈S.R,G.Adj b x)
    (bridge : portBridge S) :
    ∃ p,∃ q,G.Adj a p ∧ G.Adj b q ∧ RouteOn G S.L p q := by
  classical
  let A := S.localA
  let E := S.L\A
  obtain ⟨x,xl,y,yl,ax,xy,by'⟩ := bridge
  have xA : x∈A := mem_filter.mpr ⟨xl,ax⟩
  have yA : y∉A := fun h=>not_common far (mem_filter.mp h).2 by'
  have yE : y∈E := mem_sdiff.mpr ⟨yl,yA⟩
  have aSub : A⊆S.L := filter_subset _ _
  have sep : Disjoint A E := disjoint_left.mpr (fun z za ze=>(mem_sdiff.mp ze).2 za)
  have univ := bridge_four_forces_universal S hc far even foreignFour xl ax xy by'
  have adj (p : V) (pA : p∈A) (z : V) (zl : z∈S.L) (pz : p≠z) (zy : z≠y) :
      G.Adj p z := by
    have pL := aSub pA
    have ap := (mem_filter.mp pA).2
    by_cases px : p=x
    · subst p
      exact (univ z zl).resolve_left (fun e=>pz e.symm)
    have xp := (univ p pL).resolve_left px
    by_cases hit : ∃ w∈S.L,G.Adj b w ∧ G.Adj p w
    · obtain ⟨w,_,bw,pw⟩ := hit
      exact (bridge_four_forces_universal S hc far even foreignFour pL ap pw bw z zl).resolve_left
        (fun e=>pz e.symm)
    have py : p≠y := fun h=>yA (h ▸ pA)
    have pyn : ¬G.Adj p y := fun h=>hit ⟨y,yl,by',h⟩
    have y2 := d2 hc py pyn xp.symm xy
    apply Classical.byContradiction
    intro pzn
    have zx : z≠x := fun e=>pzn (e.symm ▸ xp.symm)
    have xz := (univ z zl).resolve_left zx
    have z2 := d2 hc pz pzn xp.symm xz
    exact zy (singleton_local_distance_two_at_opposite_four S hc even foreignFour pL ap zl yl z2 y2)
  have cap : E.card≤4 := by
    have h := bound_bridge_side_of_opposite_four S hc far even rightConnected rightA rightB
      foreignFour ⟨x,xl,y,yl,ax,xy,by'⟩
    have q : E.card+A.card=S.L.card := card_sdiff_add_card_eq_card aSub
    change A.card=2 at localTwo
    change S.L.card≤A.card+4 at h
    omega
  have cross (p : V) (pA : p∈A) (z : V) (ze : z∈E) (zy : z≠y) : G.Adj p z :=
    adj p pA z (mem_sdiff.mp ze).1 (fun e=>(mem_sdiff.mp ze).2 (e ▸ pA)) zy
  have key : A∪E=S.L := union_sdiff_of_subset aSub
  have low : 3≤E.card := peripheral_card_at_least_three S far degree localTwo
  have wide (u : V) (ue : u∈E) (v : V) (ve : v∈E) (ne : u≠v) :
      2≤(E.filter (G.Adj u)).card ∨ 2≤(E.filter (G.Adj v)).card :=
    (degree u v ne).imp (two_ports_internal_peripheral_degree S localTwo ue)
      (two_ports_internal_peripheral_degree S localTwo ve)
  have blocks : ∃ P Q : Finset V,∃ u v w : V, Disjoint P Q ∧ P∪Q=E ∧
      RouteOn G P u v ∧ RouteOn G Q w y := by
    by_cases h : E.card=4
    · exact four_peripheral_blocks h yE wide
    have e3 : E.card=3 := by omega
    have cl := clique_of_three_internal_high e3 wide
    obtain ⟨u,uu⟩ := card_pos.mp (show 0<(E.erase y).card by rw [card_erase_of_mem yE,e3]; decide)
    have ue := (mem_erase.mp uu).2
    have ne := (mem_erase.mp uu).1
    let Q := E.erase u
    have q2 : Q.card=2 := by change (E.erase u).card=2; rw [card_erase_of_mem ue,e3]
    obtain ⟨v,vq⟩ := card_pos.mp (show 0<(Q.erase y).card by
      rw [card_erase_of_mem (show y∈Q from mem_erase.mpr ⟨ne.symm,yE⟩),q2]
      decide)
    have vy := (mem_erase.mp vq).1
    have ve := (mem_erase.mp (mem_erase.mp vq).2).2
    have qEq : ({v,y} : Finset V)=Q := by
      apply eq_of_subset_of_card_le
      · exact insert_subset (mem_erase.mp vq).2
          (singleton_subset_iff.mpr (mem_erase.mpr ⟨ne.symm,yE⟩))
      simpa [vy] using q2.le
    refine ⟨{u},Q,u,u,v,?_,?_,RouteOn.singleton,qEq ▸ RouteOn.edge (cl v ve y yE vy)⟩
    · exact disjoint_left.mpr (fun z zu zq=>(mem_erase.mp zq).1 (mem_singleton.mp zu))
    rw [←insert_erase ue]
    ext z
    simp [Q]
  obtain ⟨P,Q,u,v,w,dis,cov,p,q⟩ := blocks
  have ps : P⊆E := fun z hz=>cov ▸ mem_union_left _ hz
  have qs : Q⊆E := fun z hz=>cov ▸ mem_union_right _ hz
  have uv : u∈P ∧ v∈P := by
    obtain ⟨r,hr,sup⟩ := p
    exact ⟨(sup _).mp r.start_mem_support,(sup _).mp r.end_mem_support⟩
  have ww : w∈Q := by
    obtain ⟨r,hr,sup⟩ := q
    exact (sup _).mp r.start_mem_support
  have yQ : y∈Q := by
    obtain ⟨r,hr,sup⟩ := q
    exact (sup _).mp r.end_mem_support
  have ca : A.card=2 := localTwo
  obtain ⟨t,ta⟩ := card_pos.mp (show 0<(A.erase x).card by rw [card_erase_of_mem xA,ca]; decide)
  have tx := (mem_erase.mp ta).1
  have tA := (mem_erase.mp ta).2
  have aEq : ({t,x} : Finset V)=A := by
    apply eq_of_subset_of_card_le
    · exact insert_subset tA (singleton_subset_iff.mpr xA)
    simpa [tx] using ca.le
  have tu : G.Adj t u := cross t tA u (ps uv.1) (fun h=>disjoint_left.mp dis uv.1 (h.symm ▸ yQ))
  have tOff : t∉P := fun m=>disjoint_left.mp sep tA (ps m)
  have s := p.prefix tu tOff
  have xOff : x∉insert t P := fun m=>(mem_insert.mp m).elim (fun h=>tx h.symm)
    (fun m=>disjoint_left.mp sep xA (ps m))
  have vx : G.Adj v x := ((univ v (mem_sdiff.mp (ps uv.2)).1).resolve_left
    (fun h=>disjoint_left.mp sep xA (h ▸ ps uv.2))).symm
  have f := s.suffix vx xOff
  have fw : G.Adj x w := (univ w (mem_sdiff.mp (qs ww)).1).resolve_left
    (fun h=>disjoint_left.mp sep xA (h ▸ qs ww))
  have disF : Disjoint (insert x (insert t P)) Q := by
    apply disjoint_left.mpr
    intro z zf zq
    rcases mem_insert.mp zf with rfl|rest
    · exact disjoint_left.mp sep xA (qs zq)
    rcases mem_insert.mp rest with rfl|rest
    · exact disjoint_left.mp sep tA (qs zq)
    exact disjoint_left.mp dis rest zq
  have e : insert x (insert t P)∪Q=S.L := by
    rw [←key,←cov,←aEq]
    ext z
    simp [or_comm,or_left_comm,or_assoc]
  exact ⟨t,y,(mem_filter.mp tA).2,by',e ▸ f.join q disF fw⟩

#print axioms bridge_route_at_two_four
end Graffiti189LongestPath.CrossSaturation.Split.Five
