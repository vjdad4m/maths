import DegreeFiveSixSingletonClose189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph Finset
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

/-- Four vertices, all but one of internal degree at least two, split into
two path blocks with a prescribed last vertex. -/
theorem four_peripheral_blocks {E : Finset V} (four : E.card=4)
    {y : V} (ye : y∈E)
    (wide : ∀ x∈E,∀ z∈E,x≠z →
      2≤(E.filter (G.Adj x)).card ∨ 2≤(E.filter (G.Adj z)).card) :
    ∃ P Q : Finset V,∃ u v w : V, Disjoint P Q ∧ P∪Q=E ∧
      RouteOn G P u v ∧ RouteOn G Q w y := by
  classical
  let T := E.erase y
  have t3 : T.card=3 := by change (E.erase y).card=3; rw [card_erase_of_mem ye,four]
  have off : y∉T := by simp [T]
  have te : T⊆E := erase_subset _ _
  have key : insert y T=E := insert_erase ye
  have ex : ∃ u∈T,∃ v∈T,G.Adj u v := by
    apply Classical.byContradiction
    intro no
    have low (u : V) (ut : u∈T) : (E.filter (G.Adj u)).card≤1 := by
      have sub : E.filter (G.Adj u)⊆{y} := by
        intro w wm
        obtain ⟨we,uw⟩ := mem_filter.mp wm
        by_cases wy : w=y
        · exact mem_singleton.mpr wy
        exact (no ⟨u,ut,w,mem_erase.mpr ⟨wy,we⟩,uw⟩).elim
      have n := card_le_card sub
      simpa using n
    obtain ⟨p,pt,q,qt,pq⟩ := one_lt_card.mp (show 1<T.card by omega)
    have p1 := low p pt
    have q1 := low q qt
    exact (wide p (te pt) q (te qt) pq).elim (fun h=>by omega) (fun h=>by omega)
  obtain ⟨u,ut,v,vt,uv⟩ := ex
  let R := ({u,v} : Finset V)
  have rt : R⊆T := insert_subset ut (singleton_subset_iff.mpr vt)
  have r2 : R.card=2 := by simp [R,uv.ne]
  have c : (T\R).card=1 := by rw [card_sdiff rt,t3,r2]
  obtain ⟨w,wEq⟩ := card_eq_one.mp c
  have wm : w∈T\R := wEq.symm ▸ mem_singleton_self w
  obtain ⟨wt,wn⟩ := mem_sdiff.mp wm
  have wu : w≠u := fun h=>wn (mem_insert.mpr (.inl h))
  have wv : w≠v := fun h=>wn (mem_insert.mpr (.inr (mem_singleton.mpr h)))
  have wy : w≠y := (mem_erase.mp wt).1
  have yu : y≠u := Ne.symm (mem_erase.mp ut).1
  have yv : y≠v := Ne.symm (mem_erase.mp vt).1
  have tf : ({u,v,w} : Finset V)=T := by
    have n := sdiff_union_of_subset rt
    rw [wEq] at n
    rw [←n]
    ext z
    simp [R,or_comm,or_left_comm,or_assoc]
  have ef : ({u,v,w,y} : Finset V)=E := by
    rw [←key,←tf]
    ext z
    simp [or_comm,or_left_comm,or_assoc]
  have first (p q : V) (wp : G.Adj w p) (pq : G.Adj p q)
      (wq : w≠q) (eq : ({w,p,q} : Finset V)=T) :
      ∃ P Q : Finset V,∃ i j k : V,Disjoint P Q ∧ P∪Q=E ∧
        RouteOn G P i j ∧ RouteOn G Q k y := by
    have step : RouteOn G T w q := eq ▸ RouteOn.three wp pq wq
    refine ⟨T,{y},w,q,y,?_,?_,step,RouteOn.singleton⟩
    · exact disjoint_left.mpr (fun z zt zy=>off ((mem_singleton.mp zy) ▸ zt))
    rw [←key]
    ext z
    simp [or_comm]
  by_cases wue : G.Adj w u
  · exact first u v wue uv wv (by rw [←tf]; ext z; simp [or_comm,or_left_comm,or_assoc])
  by_cases wve : G.Adj w v
  · exact first v u wve uv.symm wu (by rw [←tf]; ext z; simp [or_comm,or_left_comm,or_assoc])
  have hit : G.Adj u y ∨ G.Adj v y := by
    apply Classical.byContradiction
    intro h
    have low (p q : V) (pw : ¬G.Adj p w) (py : ¬G.Adj p y)
        (eq : ({p,q,w,y} : Finset V)=E) : (E.filter (G.Adj p)).card≤1 := by
      have sub : E.filter (G.Adj p)⊆{q} := by
        intro z zm
        obtain ⟨ze,pz⟩ := mem_filter.mp zm
        have d : z=p ∨ z=q ∨ z=w ∨ z=y := by simpa [←eq] using ze
        rcases d with rfl|rfl|rfl|rfl
        · exact (pz.ne rfl).elim
        · exact mem_singleton_self _
        · exact (pw pz).elim
        exact (py pz).elim
      simpa using card_le_card sub
    have u1 := low u v (fun e=>wue e.symm) (fun e=>h (.inl e)) ef
    have v1 := low v u (fun e=>wve e.symm) (fun e=>h (.inr e))
      (by rw [←ef]; ext z; simp [or_comm,or_left_comm,or_assoc])
    exact (wide u (te ut) v (te vt) uv.ne).elim (fun h=>by omega) (fun h=>by omega)
  have second (p q : V) (pq : G.Adj p q) (qy : G.Adj q y) (py : p≠y)
      (wp : w≠p) (wq : w≠q) (cover : ({w,p,q,y} : Finset V)=E) :
      ∃ P Q : Finset V,∃ i j k : V,Disjoint P Q ∧ P∪Q=E ∧
        RouteOn G P i j ∧ RouteOn G Q k y := by
    refine ⟨{w},{p,q,y},w,w,p,?_,?_,RouteOn.singleton,RouteOn.three pq qy py⟩
    · simp [disjoint_singleton_left,wp,wq,wy,wp.symm,wq.symm,wy.symm]
    rw [←cover]
    ext z
    simp [or_comm,or_left_comm,or_assoc]
  rcases hit with uy|vy
  · exact second v u uv.symm uy yv.symm wv wu (by rw [←ef]; ext z; simp [or_comm,or_left_comm,or_assoc])
  exact second u v uv vy yu.symm wu wv (by rw [←ef]; ext z; simp [or_comm,or_left_comm,or_assoc])

#print axioms four_peripheral_blocks
end Graffiti189LongestPath.CrossSaturation.Split.Five
