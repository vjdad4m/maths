import DegreeFiveSixTwoInnerPrescribed189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph Finset
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

theorem four_internal_wide_spanning_path {E : Finset V} (four : E.card=4)
    (noiso : ∀ x∈E,∃ y∈E,G.Adj x y)
    (wide : ∀ x∈E,∀ z∈E,x≠z →
      2≤(E.filter (G.Adj x)).card ∨ 2≤(E.filter (G.Adj z)).card) :
    ∃ x∈E,∃ y∈E,x≠y ∧ RouteOn G E x y := by
  classical
  obtain ⟨x,xe,y,ye,xy⟩ := one_lt_card.mp (show 1<E.card by omega)
  have center : ∃ q∈E,2≤(E.filter (G.Adj q)).card :=
    (wide x xe y ye xy).elim (fun h=>⟨x,xe,h⟩) (fun h=>⟨y,ye,h⟩)
  obtain ⟨q,qe,hq⟩ := center
  obtain ⟨p,pm,r,rm,pr⟩ := one_lt_card.mp (show 1<(E.filter (G.Adj q)).card by omega)
  obtain ⟨pe,qp⟩ := mem_filter.mp pm
  obtain ⟨re,qr⟩ := mem_filter.mp rm
  let A := ({p,q,r} : Finset V)
  have ae : A⊆E := insert_subset pe (insert_subset qe (singleton_subset_iff.mpr re))
  have a3 : A.card=3 := by simp [A,qp.ne.symm,pr,qr.ne]
  have one : (E\A).card=1 := by rw [card_sdiff ae,four,a3]
  obtain ⟨s,sEq⟩ := card_eq_one.mp one
  have sm : s∈E\A := sEq.symm ▸ mem_singleton_self s
  obtain ⟨se,sa⟩ := mem_sdiff.mp sm
  have sp : s≠p := fun e=>sa (mem_insert.mpr (.inl e))
  have sq : s≠q := fun e=>sa (mem_insert_of_mem (mem_insert.mpr (.inl e)))
  have sr : s≠r := fun e=>sa (mem_insert_of_mem (mem_insert_of_mem (mem_singleton.mpr e)))
  have key : insert s A=E := by
    have m := sdiff_union_of_subset ae
    rw [sEq] at m
    ext z
    simpa [mem_insert,mem_union,mem_singleton] using (Finset.ext_iff.mp m z)
  have tail : RouteOn G A p r := RouteOn.three qp.symm qr pr
  by_cases rsp : G.Adj s p
  · exact ⟨s,se,r,re,sr,key ▸ tail.prefix rsp sa⟩
  by_cases rsr : G.Adj s r
  · have h := tail.reverse.prefix rsr sa
    exact ⟨s,se,p,pe,sp,key ▸ h⟩
  obtain ⟨u,ue,su⟩ := noiso s se
  have suq : G.Adj s q := by
    rw [←key] at ue
    rcases mem_insert.mp ue with rfl|ua
    · exact (su.ne rfl).elim
    have hit : u=p ∨ u=q ∨ u=r := by simpa [A] using ua
    rcases hit with rfl|rfl|rfl
    · exact (rsp su).elim
    · exact su
    exact (rsr su).elim
  have rp : G.Adj p r := by
    apply Classical.byContradiction
    intro nr
    have low (v w : V) (vs : ¬G.Adj v s) (vw : ¬G.Adj v w)
        (cover : ({s,v,q,w} : Finset V)=E) : (E.filter (G.Adj v)).card≤1 := by
      have incl : E.filter (G.Adj v)⊆{q} := by
        intro z ze
        have ⟨zE,vz⟩ := mem_filter.mp ze
        rw [←cover] at zE
        have opts : z=s ∨ z=v ∨ z=q ∨ z=w := by simpa using zE
        rcases opts with rfl|rfl|rfl|rfl
        · exact (vs vz).elim
        · exact (G.loopless _ vz).elim
        · exact mem_singleton_self _
        exact (vw vz).elim
      simpa using card_le_card incl
    have pl := low p r (fun h=>rsp h.symm) nr key
    have rl := low r p (fun h=>rsr h.symm) (fun h=>nr h.symm)
      (by rw [←key]; ext z; simp [A,or_comm,or_left_comm,or_assoc])
    exact (wide p pe r re pr).elim (fun h=>by omega) (fun h=>by omega)
  have step : RouteOn G ({q,p,r} : Finset V) q r := RouteOn.three qp rp qr.ne
  have h := step.prefix suq (by simp [sp,sq,sr])
  have e : insert s ({q,p,r} : Finset V)=E := by
    rw [←key]
    ext z
    simp [A,or_comm,or_left_comm,or_assoc]
  exact ⟨s,se,r,re,sr,e ▸ h⟩

#print axioms four_internal_wide_spanning_path
end Graffiti189LongestPath.CrossSaturation.Split.Five
