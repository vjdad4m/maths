import DegreeFiveSevenSmallInner189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph Finset
open private left_boundary from AdjacentCut189
open private not_common from DegreeFiveFourPort189
open private d2 from CrossSaturation189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem high_four_port_has_local_outside (hc : G.Connected) (far : 3≤G.dist a b)
    (b4 : S.localA.card=4) {u : V} (uA : u∈S.localA) (high : 5≤G.degree u) :
    (secondA G S.L a).Nonempty := by
  classical
  obtain ⟨ul,au⟩ := mem_filter.mp uA
  by_contra h
  have sub : G.neighborFinset u⊆insert a (S.localA.erase u) := by
    intro v hv
    have uv := (mem_neighborFinset G u v).mp hv
    rcases left_boundary S u ul v uv with e|e|vl
    · exact mem_insert.mpr (.inl e)
    · exact (not_common far au (e ▸ uv.symm)).elim
    by_cases av : G.Adj a v
    · exact mem_insert_of_mem (mem_erase.mpr ⟨uv.ne.symm,mem_filter.mpr ⟨vl,av⟩⟩)
    have av' : a≠v := fun e=>S.leftOff.1 (e.symm ▸ vl)
    exact (h ⟨v,mem_inter.mpr ⟨vl,d2 hc av' av au uv⟩⟩).elim
  have n := (card_le_card sub).trans (card_insert_le a (S.localA.erase u))
  rw [card_neighborFinset_eq_degree,card_erase_of_mem uA,b4] at n
  omega

theorem four_ports_have_second_neighbor (hc : G.Connected) (far : 3≤G.dist a b)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (b4 : S.localA.card=4) : (secondA G S.L a).Nonempty := by
  obtain ⟨u,hu,v,hv,uv⟩ := one_lt_card.mp (show 1<S.localA.card by omega)
  exact (degree u v uv).elim (high_four_port_has_local_outside S hc far b4 hu)
    (high_four_port_has_local_outside S hc far b4 hv)

#print axioms four_ports_have_second_neighbor
end Graffiti189LongestPath.CrossSaturation.Split.Five
