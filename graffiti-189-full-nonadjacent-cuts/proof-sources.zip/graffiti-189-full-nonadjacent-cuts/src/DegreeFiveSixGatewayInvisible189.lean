import DegreeFiveSixInvisibleCap189
import DegreeFiveSixSingleGateway189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph Finset
open private left_boundary from AdjacentCut189
open private d2 foreign_subset from CrossSaturation189
open private two_walk_middle from DistanceTwoCut189
open private not_common secondA_right_and_left_le_five from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem singleton_four_opposite_gateway_invisible (hc : G.Connected)
    (far : 3≤G.dist a b) (even : ∀ z,(EvenFrom G z).card≤6)
    (right4 : (S.R.filter (G.Adj b)).card=4)
    (l3 : S.localA.card=3)
    (left5 : S.L.card=5) (clique : ∀ u∈S.L,∀ v∈S.L,u≠v → G.Adj u v)
    (rc : (G.induce (↑S.R : Set V)).Connected)
    (ra : ∃ x∈S.R,G.Adj a x) (rb : ∃ x∈S.R,G.Adj b x)
    {z : V} (zr : z∈S.R) (join : ∀ q∈S.R.filter (G.Adj b),G.Adj q z)
    (only : ∀ q∈S.R.filter (G.Adj b),∀ v∈S.R,¬G.Adj b v → G.Adj q v → v=z) :
    ¬G.Adj a z ∧ z∉secondA G S.R a ∧ 2≤(secondA G S.L a).card := by
  classical
  let P := S.L\S.localA
  let B := S.R.filter (G.Adj b)
  have p2 : P.card=2 := by
    have e : P.card+S.localA.card=S.L.card := card_sdiff_add_card_eq_card (filter_subset _ _)
    omega
  obtain ⟨s,ss⟩ := card_pos.mp (show 0<S.localA.card by omega)
  obtain ⟨sl,as'⟩ := mem_filter.mp ss
  have lSub : P⊆secondA G S.L a := by
    intro q qq
    obtain ⟨ql,qn⟩ := mem_sdiff.mp qq
    have aq : ¬G.Adj a q := fun h=>qn (mem_filter.mpr ⟨ql,h⟩)
    have ne : a≠q := fun h=>S.leftOff.1 (h.symm ▸ ql)
    exact mem_inter.mpr ⟨ql,d2 hc ne aq as' (clique s sl q ql (fun h=>aq (h ▸ as')))⟩
  have lc := card_le_card lSub
  have sum := secondA_right_and_left_le_five S even
  have no : ¬G.Adj a z := by
    intro az
    have sub : B⊆secondA G S.R a := by
      intro q qq
      obtain ⟨qr,bq⟩ := mem_filter.mp qq
      have ne : a≠q := fun h=>S.rightOff.1 (h.symm ▸ qr)
      exact mem_inter.mpr ⟨qr,d2 hc ne (not_common far · bq) az (join q qq).symm⟩
    have n := card_le_card sub
    change (S.R.filter (G.Adj b)).card≤_ at n
    omega
  have invisible : z∉secondA G S.R a := by
    intro h
    have h2 : G.dist a z=2 := by simpa [DistanceTwo] using (mem_inter.mp h).2
    obtain ⟨p,pp⟩ := hc.exists_walk_length_eq_dist a z
    obtain ⟨u,au,uz⟩ := two_walk_middle p (pp.trans h2)
    have ur : u∈S.R := by
      rcases S.cover u with e|e|ul|ur
      · exact (G.loopless a (e ▸ au)).elim
      · have d := dist_eq_one_iff_adj.mpr (e ▸ au : G.Adj a b)
        omega
      · exact (S.cross u ul z zr uz).elim
      exact ur
    let T := switch S rc ra rb
    have extra : B⊆DistanceTwo G u := by
      intro q qq
      obtain ⟨qr,bq⟩ := mem_filter.mp qq
      have uq : u≠q := fun e=>not_common far (e ▸ au) bq
      have nq : ¬G.Adj u q := by
        intro uq'
        exact uz.ne (only q qq u ur (not_common far au) uq'.symm)
      exact d2 hc uq nq uz (join q qq).symm
    have foreign : S.localA⊆DistanceTwo G u := fun _ h=>foreign_subset T hc ur au h
    have dis : Disjoint S.localA B := S.dis.mono (filter_subset _ _) (filter_subset _ _)
    have n := (card_le_card (union_subset foreign extra)).trans (distanceTwo_le_of_even 5 u (even u))
    rw [card_union_of_disjoint dis,l3] at n
    change 3+(S.R.filter (G.Adj b)).card≤5 at n
    omega
  exact ⟨no,invisible,by omega⟩

#print axioms singleton_four_opposite_gateway_invisible
end Graffiti189LongestPath.CrossSaturation.Split.Five
