import DegreeFiveSevenBridgeContext189
import DegreeFiveFourForeignGeom189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph Finset
open private left_boundary from AdjacentCut189
open private d2 foreign_subset from CrossSaturation189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

/-- Three foreign a-ports and a local a–b bridge leave at most one invisible
opposite nonport. Even shells are taken in the original graph. -/
theorem bridge_three_foreign_invisible_cap (hc : G.Connected)
    (even : ∀ v,(EvenFrom G v).card≤6)
    (conn : ∀ R : Finset V,R.card<2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (three : S.foreignA.card=3)
    {x y : V} (xl : x∈S.L) (ax : G.Adj a x) (xy : G.Adj x y) (by' : G.Adj b y)
    (no : ¬G.Adj b x) :
    ((farNonports S.R a b G) \ secondA G S.R a).card≤1 := by
  classical
  have bx : x≠b := fun e=>S.leftOff.2 (e ▸ xl)
  have bd : b∈DistanceTwo G x := d2 hc bx (fun h=>no h.symm) xy by'.symm
  have sub : insert b S.foreignA⊆DistanceTwo G x := by
    intro z hz
    exact (mem_insert.mp hz).elim (fun e=>e.symm ▸ bd)
      (fun h=>foreign_subset S hc xl ax h)
  have out : b∉S.foreignA := fun h=>S.rightOff.2 (mem_filter.mp h).1
  have low := card_le_card sub
  rw [card_insert_of_not_mem out,three] at low
  have cap := FiveActualCut.four_layer_add_distance_two_le_five even x
  have ecc (z : V) : G.dist x z≤4 := by
    by_contra h
    have high : 2≤(univ.filter (fun w=>G.dist x w=4)).card :=
      layer_card_of_connectivity hc 2 conn (x:=x) (y:=z) 4
        (by decide) (by omega) (inferInstance)
    omega
  have shell : (farNonports S.R a b G) \ secondA G S.R a ⊆
      univ.filter (fun z=>G.dist x z=4) := by
    intro z hz
    obtain ⟨hp,inv⟩ := mem_sdiff.mp hz
    obtain ⟨zr,az,bz⟩ := mem_filter.mp hp
    have an : a≠z := fun h=>S.rightOff.1 (h.symm ▸ zr)
    have bn : b≠z := fun h=>S.rightOff.2 (h.symm ▸ zr)
    have la := hc.one_lt_dist_of_ne_of_not_adj an az
    have lb := hc.one_lt_dist_of_ne_of_not_adj bn bz
    have na : G.dist a z≠2 := by
      intro eq
      exact inv (mem_inter.mpr ⟨zr,by simp [DistanceTwo,eq]⟩)
    have eq := cross_metric S.L hc xl (fun h=>disjoint_left.mp S.dis h zr) (left_boundary S)
    have x1 := dist_eq_one_iff_adj.mpr ax.symm
    have x2 : G.dist x b=2 := by simpa [DistanceTwo] using bd
    rw [x1,x2] at eq
    have top := ecc z
    exact mem_filter.mpr ⟨mem_univ _,by omega⟩
  have count := card_le_card shell
  omega

#print axioms bridge_three_foreign_invisible_cap
end Graffiti189LongestPath.CrossSaturation.Split.Five
