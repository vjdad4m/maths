import DegreeFiveSixTwoInnerBPath189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph Finset
open private d2 from CrossSaturation189
open private left_boundary from AdjacentCut189
open private not_common from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem lonely_inner_geometry (hc : G.Connected) (far : 3≤G.dist a b)
    (even : ∀ v,(EvenFrom G v).card≤6)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (a4 : S.localA.card=4) (b4 : (S.L.filter (G.Adj b)).card≤4)
    (foreign : S.foreignA.card=2) (nb : ¬portBridge S)
    {s t p : V} (st : s≠t) (inner : farNonports S.L a b G={s,t})
    (no : ¬G.Adj s t) (pA : p∈S.localA)
    (one : S.localA.filter (G.Adj s)={p}) :
    ¬5≤G.degree s ∧ CompleteOn G S.localA ∧
      (∀ q∈S.localA,q≠p → G.Adj q t) ∧
      ∀ v∈S.L.filter (G.Adj b),5≤G.degree v ∧ (G.Adj v s ∨ G.Adj v t) := by
  classical
  let A := S.localA
  let B := S.L.filter (G.Adj b)
  let I := farNonports S.L a b G
  change A.card=4 at a4
  change B.card≤4 at b4
  have si : s∈I := by change s∈farNonports S.L a b G; simp [inner]
  have ps : G.Adj p s := ((mem_filter.mp (one.symm ▸ mem_singleton_self p)).2).symm
  have sq (q : V) (qa : q∈A) (qp : q≠p) : ¬G.Adj q s := by
    intro h
    exact qp (mem_singleton.mp (one ▸ mem_filter.mpr ⟨qa,h.symm⟩))
  obtain ⟨sl,as',bs⟩ := mem_filter.mp si
  have cutBound : G.neighborFinset s⊆insert p (B.filter (G.Adj s)) := by
    intro q qq
    have e := (mem_neighborFinset G s q).mp qq
    rcases left_boundary S s sl q e with rfl|rfl|ql
    · exact (as' e.symm).elim
    · exact (bs e.symm).elim
    by_cases aq : G.Adj a q
    · exact mem_insert.mpr (.inl (mem_singleton.mp (one ▸ mem_filter.mpr ⟨mem_filter.mpr ⟨ql,aq⟩,e⟩)))
    by_cases bq : G.Adj b q
    · exact mem_insert_of_mem (mem_filter.mpr ⟨mem_filter.mpr ⟨ql,bq⟩,e⟩)
    have qi : q∈farNonports S.L a b G := mem_filter.mpr ⟨ql,aq,bq⟩
    rw [inner,mem_insert,mem_singleton] at qi
    exact qi.elim (fun h=>(e.ne h.symm).elim) (fun h=>(no (h ▸ e)).elim)
  have low : ¬5≤G.degree s := by
    intro hi
    have m := (card_le_card cutBound).trans (card_insert_le p _)
    have allB : B.filter (G.Adj s)⊆B := filter_subset _ _
    have mm := card_le_card allB
    rw [card_neighborFinset_eq_degree] at m
    have bEq := eq_of_subset_of_card_le allB (by omega)
    have sub : B⊆DistanceTwo G p := by
      intro q qb
      have qs := (mem_filter.mp (bEq.symm ▸ qb)).2
      have neq : p≠q := fun e=>not_common far (e ▸ (mem_filter.mp pA).2) (mem_filter.mp qb).2
      exact d2 hc neq (distance_two_charge_from_no_bridge S pA qb nb) ps qs
    have cap := local_distance_two_at_foreign_two S hc even foreign (mem_filter.mp pA).1
      (mem_filter.mp pA).2 (fun _ h=>mem_insert_of_mem (mem_filter.mp h).1) sub
    change B.card ≤ 3 at cap
    omega
  have high (q : V) (qs : q≠s) : 5≤G.degree q :=
    (degree q s qs).resolve_right low
  have highA (q : V) (qa : q∈A) : 5≤G.degree q :=
    high q (fun e=>as' (e ▸ (mem_filter.mp qa).2))
  have hiB (q : V) (qb : q∈B) : 5≤G.degree q :=
    high q (fun e=>bs (e ▸ (mem_filter.mp qb).2))
  have aPool (q : V) (qa : q∈A) : G.neighborFinset q⊆insert a ((A.erase q)∪I) :=
    bounds_of_local_color_port S far qa (fun r rb=>distance_two_charge_from_no_bridge S qa rb nb)
  have cl : CompleteOn G A := by
    intro q qa r ra qr
    apply Classical.byContradiction
    intro bad
    have detect (u v : V) (ua : u∈A) (va : v∈A) (uv : u≠v) (no : ¬G.Adj u v) : u=p := by
      have n := far_port_nonport_degree_lower_of_missing_peer ua va uv.symm no (aPool u ua)
      have hi := highA u ua
      have i2 : I.card=2 := by change (farNonports S.L a b G).card=2; simp [inner,st]
      have eq : I.filter (G.Adj u)=I := by
        apply eq_of_subset_of_card_le (filter_subset _ _)
        omega
      have us := (mem_filter.mp (eq.symm ▸ si)).2
      exact mem_singleton.mp (one ▸ mem_filter.mpr ⟨ua,us.symm⟩)
    exact qr ((detect q r qa ra qr bad).trans (detect r q ra qa qr.symm (fun e=>bad e.symm)).symm)
  have ar (q : V) (qa : q∈A) (qp : q≠p) : G.Adj q t := by
    have m := far_port_nonport_degree_lower qa (aPool q qa)
    have hi := highA q qa
    obtain ⟨u,ui⟩ := card_pos.mp (show 0<(I.filter (G.Adj q)).card by omega)
    obtain ⟨uI,qu⟩ := mem_filter.mp ui
    change u∈farNonports S.L a b G at uI
    rw [inner,mem_insert,mem_singleton] at uI
    exact uI.elim (fun e=>(sq q qa qp (e ▸ qu)).elim) (fun e=>e ▸ qu)
  have bHit (q : V) (qb : q∈B) : 5≤G.degree q ∧ (G.Adj q s ∨ G.Adj q t) := by
    have hi := hiB q qb
    have dark : q∉visibleBPorts S.L a b G := by
      intro h
      obtain ⟨ql,bq,w,wl,aw,wq⟩ := mem_filter.mp h
      exact nb ⟨w,wl,q,ql,aw,wq,bq⟩
    have m := far_port_nonport_degree_lower qb (far_dark_b_port_candidates S far qb dark)
    change G.degree q ≤ B.card + (I.filter (G.Adj q)).card at m
    obtain ⟨u,ui⟩ := card_pos.mp (show 0<(I.filter (G.Adj q)).card by omega)
    obtain ⟨uI,qu⟩ := mem_filter.mp ui
    change u∈farNonports S.L a b G at uI
    rw [inner,mem_insert,mem_singleton] at uI
    rcases uI with rfl|rfl
    · exact ⟨hi,.inl qu⟩
    exact ⟨hi,.inr qu⟩
  exact ⟨low,cl,ar,bHit⟩

#print axioms lonely_inner_geometry
end Graffiti189LongestPath.CrossSaturation.Split.Five
