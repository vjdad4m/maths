import DegreeFiveSixLonelyInner189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private d2 from CrossSaturation189
open private not_common from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem lonely_inner_b_rooted (hc : G.Connected) (far : 3≤G.dist a b)
    (even : ∀ v,(EvenFrom G v).card≤6)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (a4 : S.localA.card=4) (b3 : 3≤(S.L.filter (G.Adj b)).card)
    (b4 : (S.L.filter (G.Adj b)).card≤4)
    (foreign : S.foreignA.card=2) (nb : ¬portBridge S)
    {s t p : V} (st : s≠t) (inner : farNonports S.L a b G={s,t})
    (no : ¬G.Adj s t) (pA : p∈S.localA)
    (one : S.localA.filter (G.Adj s)={p}) :
    ∃ u v,G.Adj b u ∧ RouteOn G S.L u v := by
  classical
  let A := S.localA
  let B := S.L.filter (G.Adj b)
  let I := farNonports S.L a b G
  let C := B.filter (G.Adj s)
  let D := B.filter (G.Adj t)
  change A.card=4 at a4
  change 3≤B.card at b3
  change B.card≤4 at b4
  obtain ⟨_,ac,at',bh⟩ := lonely_inner_geometry S hc far even degree a4 b4 foreign nb st inner no pA one
  have sq (q : V) (qa : q∈A) (qp : q≠p) : ¬G.Adj q s := by
    intro h
    exact qp (mem_singleton.mp (one ▸ mem_filter.mpr ⟨qa,h.symm⟩))
  have ps : G.Adj p s := ((mem_filter.mp (one.symm ▸ mem_singleton_self p)).2).symm
  obtain ⟨q,qq⟩ := card_pos.mp (show 0<(A.erase p).card by rw [card_erase_of_mem pA,a4]; decide)
  obtain ⟨qp,qa⟩ := mem_erase.mp qq
  have qt := at' q qa qp
  have si : s∈I := by change s∈farNonports S.L a b G; simp [inner]
  have ti : t∈I := by change t∈farNonports S.L a b G; simp [inner]
  have i2 : I.card=2 := by change (farNonports S.L a b G).card=2; simp [inner,st]
  have union : C∪D=B := by
    ext v
    constructor
    · intro m
      exact (mem_union.mp m).elim (fun h=>(mem_filter.mp h).1) (fun h=>(mem_filter.mp h).1)
    intro h
    exact ((bh v h).2).elim
      (fun e=>mem_union_left _ (mem_filter.mpr ⟨h,e.symm⟩))
      (fun e=>mem_union_right _ (mem_filter.mpr ⟨h,e.symm⟩))
  have reach (x : V) (xa : x∈A) (i : V) (xi : G.Adj x i) :
      B.filter (G.Adj i)⊆DistanceTwo G x := by
    intro v vm
    obtain ⟨vb,iv⟩ := mem_filter.mp vm
    have ne : x≠v := fun e=>not_common far (e ▸ (mem_filter.mp xa).2) (mem_filter.mp vb).2
    exact d2 hc ne (distance_two_charge_from_no_bridge S xa vb nb) xi iv
  have pNo : ¬G.Adj p t := by
    intro pt
    have cSub := reach p pA s ps
    have dSub := reach p pA t pt
    have n : B.card ≤ 3 := local_distance_two_at_foreign_two S hc even foreign (mem_filter.mp pA).1
      (mem_filter.mp pA).2 (fun v vb=>mem_insert_of_mem ((mem_filter.mp vb).1))
      (show B⊆DistanceTwo G p from union ▸ union_subset cSub dSub)
    have bIs4 : B.card=4 := by
      apply Classical.byContradiction
      intro nee
      have bEq : B.card=3 := by omega
      have dark (v : V) (vb : v∈B) : v∉visibleBPorts S.L a b G := by
        intro h
        obtain ⟨vl,bv,w,wl,aw,wv⟩ := mem_filter.mp h
        exact nb ⟨w,wl,v,vl,aw,wv,bv⟩
      have dEq : D=B := by
        apply eq_of_subset_of_card_le (filter_subset _ _)
        have incl : B⊆D := by
          intro v vb
          obtain ⟨_,every⟩ := far_port_full_at_tight_pool vb
            (far_dark_b_port_candidates S far vb (dark v vb)) (by change B.card + I.card = 5; omega) (bh v vb).1
          exact mem_filter.mpr ⟨vb,(every t ti).symm⟩
        exact card_le_card incl
      have s2 := d2 hc (show q ≠ s from fun e => (mem_filter.mp si).2.1 (e ▸ (mem_filter.mp qa).2))
        (sq q qa qp) (ac q qa p pA qp) ps
      have sNo : s∉B := fun m=>(mem_filter.mp si).2.2 (mem_filter.mp m).2
      have qs' := local_distance_two_at_foreign_two S hc even foreign (mem_filter.mp qa).1
        (mem_filter.mp qa).2 (insert_subset_iff.mpr
          ⟨mem_insert_of_mem (mem_filter.mp si).1,fun _ m=>mem_insert_of_mem (mem_filter.mp m).1⟩)
        (insert_subset_iff.mpr ⟨s2,(show B⊆DistanceTwo G q from dEq ▸ reach q qa t qt)⟩)
      rw [card_insert_of_not_mem sNo] at qs'
      omega
    omega
  have cs : C.card≤2 := by
    have z2 := d2 hc (show p ≠ t from fun e => (mem_filter.mp ti).2.1 (e ▸ (mem_filter.mp pA).2))
      pNo (ac p pA q qa qp.symm) qt
    have notC : t∉C := fun h=>(mem_filter.mp ti).2.2 (mem_filter.mp (mem_filter.mp h).1).2
    have n := local_distance_two_at_foreign_two S hc even foreign (mem_filter.mp pA).1
      (mem_filter.mp pA).2 (insert_subset_iff.mpr ⟨mem_insert_of_mem (mem_filter.mp ti).1,
        fun v hv=>mem_insert_of_mem (mem_filter.mp (mem_filter.mp hv).1).1⟩)
      (insert_subset_iff.mpr ⟨z2,reach p pA s ps⟩)
    rw [card_insert_of_not_mem notC] at n
    omega
  have ds : D.card≤2 := by
    have z2 := d2 hc (show q ≠ s from fun e => (mem_filter.mp si).2.1 (e ▸ (mem_filter.mp qa).2))
      (sq q qa qp) (ac q qa p pA qp) ps
    have notD : s∉D := fun h=>(mem_filter.mp si).2.2 (mem_filter.mp (mem_filter.mp h).1).2
    have n := local_distance_two_at_foreign_two S hc even foreign (mem_filter.mp qa).1
      (mem_filter.mp qa).2 (insert_subset_iff.mpr ⟨mem_insert_of_mem (mem_filter.mp si).1,
        fun v hv=>mem_insert_of_mem (mem_filter.mp (mem_filter.mp hv).1).1⟩)
      (insert_subset_iff.mpr ⟨z2,reach q qa t qt⟩)
    rw [card_insert_of_not_mem notD] at n
    omega
  have bIs4 : B.card=4 := by
    apply Classical.byContradiction
    intro nee
    have bEq : B.card=3 := by omega
    have incl : B⊆D := by
      intro v vb
      have dark : v∉visibleBPorts S.L a b G := by
        intro h
        obtain ⟨vl,bv,w,wl,aw,wv⟩ := mem_filter.mp h
        exact nb ⟨w,wl,v,vl,aw,wv,bv⟩
      obtain ⟨_,every⟩ := far_port_full_at_tight_pool vb
        (far_dark_b_port_candidates S far vb dark) (by change B.card + I.card = 5; omega) (bh v vb).1
      exact mem_filter.mpr ⟨vb,(every t ti).symm⟩
    have m := card_le_card incl
    omega
  have total := card_union_le C D
  rw [union,bIs4] at total
  have c2 : C.card=2 := by omega
  have d2' : D.card=2 := by omega
  have disCD : Disjoint C D := by
    have cd := card_union_add_card_inter C D
    rw [union,bIs4,c2,d2'] at cd
    exact disjoint_iff_inter_eq_empty.mpr (card_eq_zero.mp (by omega))
  have bc : CompleteOn G B := by
    intro u ub v vb ne
    apply Classical.byContradiction
    intro bad
    have dark : u∉visibleBPorts S.L a b G := by
      intro h
      obtain ⟨ul,bu,w,wl,aw,wu⟩ := mem_filter.mp h
      exact nb ⟨w,wl,u,ul,aw,wu,bu⟩
    have n := far_port_nonport_degree_lower_of_missing_peer ub vb ne.symm bad
      (far_dark_b_port_candidates S far ub dark)
    change G.degree u+1 ≤ B.card+(I.filter (G.Adj u)).card at n
    have uhi := (bh u ub).1
    have eq : I.filter (G.Adj u)=I :=
      eq_of_subset_of_card_le (filter_subset _ _) (by omega)
    have us := (mem_filter.mp (eq.symm ▸ si)).2
    have ut := (mem_filter.mp (eq.symm ▸ ti)).2
    exact disjoint_left.mp disCD (mem_filter.mpr ⟨ub,us.symm⟩) (mem_filter.mpr ⟨ub,ut.symm⟩)
  obtain ⟨v,vd⟩ := card_pos.mp (show 0<D.card by omega)
  obtain ⟨vb,tv⟩ := mem_filter.mp vd
  obtain ⟨u,uu⟩ := card_pos.mp (show 0<(B.erase v).card by rw [card_erase_of_mem vb,bIs4]; decide)
  obtain ⟨uv,ub⟩ := mem_erase.mp uu
  obtain ⟨w,wp,ws⟩ := path_between_in_clique B bc ub vb uv
  have leftPath : RouteOn G B u v := ⟨w,wp,ws⟩
  have tOff : t∉B := fun h=>(mem_filter.mp ti).2.2 (mem_filter.mp h).2
  have extended := leftPath.suffix tv.symm tOff
  obtain ⟨j,jp,js⟩ := path_between_in_clique A ac qa pA qp
  have rightPath : RouteOn G A q p := ⟨j,jp,js⟩
  have sOff : s∉A := fun h=>(mem_filter.mp si).2.1 (mem_filter.mp h).2
  have extra := rightPath.suffix ps sOff
  have dis : Disjoint (insert t B) (insert s A) := by
    apply disjoint_left.mpr
    intro x xa xb
    rcases mem_insert.mp xa with e|e
    · rcases mem_insert.mp xb with f|f
      · exact st (f.symm.trans e)
      exact (mem_filter.mp ti).2.1 (e ▸ (mem_filter.mp f).2)
    rcases mem_insert.mp xb with f|f
    · exact (mem_filter.mp si).2.2 (f ▸ (mem_filter.mp e).2)
    exact not_common far (mem_filter.mp f).2 (mem_filter.mp e).2
  have key : insert t B∪insert s A=S.L := by
    rw [←left_port_partition S far]
    change insert t B∪insert s A=A∪B∪farNonports S.L a b G
    rw [inner]
    ext z
    simp [or_comm,or_left_comm,or_assoc]
  exact ⟨u,s,(mem_filter.mp ub).2,key ▸ extended.join extra dis qt.symm⟩

#print axioms lonely_inner_b_rooted
end Graffiti189LongestPath.CrossSaturation.Split.Five
