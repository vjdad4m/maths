import DegreeFiveSixBridgeOneInner189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private not_common from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem no_bridge_one_inner_free (far : 3≤G.dist a b)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (a4 : S.localA.card=4) (b4 : (S.L.filter (G.Adj b)).card=4)
    (i1 : (farNonports S.L a b G).card=1) (no : ¬portBridge S) :
    ∃ u v,G.Adj a u ∧ RouteOn G S.L u v := by
  classical
  let A := S.localA
  let B := S.L.filter (G.Adj b)
  let I := farNonports S.L a b G
  change A.card=4 at a4
  change B.card=4 at b4
  change I.card=1 at i1
  obtain ⟨r,rEq⟩ := card_eq_one.mp i1
  have ri : r∈I := rEq.symm ▸ mem_singleton_self r
  have noAB (p : V) (pa : p∈A) (q : V) (qb : q∈B) : ¬G.Adj p q := by
    intro e
    exact no ⟨p,(mem_filter.mp pa).1,q,(mem_filter.mp qb).1,(mem_filter.mp pa).2,e,(mem_filter.mp qb).2⟩
  have aFull (p : V) (pa : p∈A) (h : 5≤G.degree p) :
      (∀ q∈A,p≠q → G.Adj p q) ∧ ∀ q∈I,G.Adj p q :=
    far_port_full_at_tight_pool pa (bounds_of_local_color_port S far pa (fun q qb=>noAB p pa q qb))
      (by omega) h
  have nVis (q : V) (qb : q∈B) : q∉visibleBPorts S.L a b G := by
    intro h
    obtain ⟨_,_,p,pl,ap,pq⟩ := mem_filter.mp h
    exact noAB p (mem_filter.mpr ⟨pl,ap⟩) q qb pq
  have bFull (p : V) (pb : p∈B) (h : 5≤G.degree p) :
      (∀ q∈B,p≠q → G.Adj p q) ∧ ∀ q∈I,G.Adj p q :=
    far_port_full_at_tight_pool pb (far_dark_b_port_candidates S far pb (nVis p pb)) (by omega) h
  have ac : CompleteOn G A := fun p pa q qa ne=>(degree p q ne).elim
    (fun hi=>(aFull p pa hi).1 q qa ne) (fun hi=>((aFull q qa hi).1 p pa ne.symm).symm)
  have bc : CompleteOn G B := fun p pa q qa ne=>(degree p q ne).elim
    (fun hi=>(bFull p pa hi).1 q qa ne) (fun hi=>((bFull q qa hi).1 p pa ne.symm).symm)
  have pick (F : Finset V) (h : 1<F.card) : ∃ p∈F,5≤G.degree p := by
    obtain ⟨p,pm,q,qm,pq⟩ := one_lt_card.mp h
    exact (degree p q pq).elim (fun e=>⟨p,pm,e⟩) (fun e=>⟨q,qm,e⟩)
  obtain ⟨p,pa,ph⟩ := pick A (by omega)
  obtain ⟨q,qb,qh⟩ := pick B (by omega)
  have pickOther (F : Finset V) (x : V) (xm : x∈F) (h : 1<F.card) : ∃ y∈F,y≠x := by
    obtain ⟨v,vm⟩ := card_pos.mp (show 0<(F.erase x).card by
      rw [card_erase_of_mem xm]
      omega)
    exact ⟨v,(mem_erase.mp vm).2,(mem_erase.mp vm).1⟩
  obtain ⟨u,ua,up⟩ := pickOther A p pa (by omega)
  obtain ⟨v,vb,vq⟩ := pickOther B q qb (by omega)
  obtain ⟨l,lp,ls⟩ := path_between_in_clique A ac ua pa up
  obtain ⟨m,mp,ms⟩ := path_between_in_clique B bc qb vb vq.symm
  have lp' : RouteOn G A u p := ⟨l,lp,ls⟩
  have rp' : RouteOn G B q v := ⟨m,mp,ms⟩
  have br : r∉B := fun h=>(mem_filter.mp ri).2.2 (mem_filter.mp h).2
  have tail := rp'.prefix ((bFull q qb qh).2 r ri).symm br
  have dis : Disjoint A (insert r B) := by
    apply disjoint_left.mpr
    intro t ta tb
    rcases mem_insert.mp tb with e|tb
    · exact (mem_filter.mp ri).2.1 (e ▸ (mem_filter.mp ta).2)
    exact not_common far (mem_filter.mp ta).2 (mem_filter.mp tb).2
  have cover : A∪insert r B=S.L := by
    rw [←left_port_partition S far]
    change A∪insert r B=A∪B∪I
    rw [rEq]
    ext z
    simp [or_comm,or_left_comm,or_assoc]
  exact ⟨u,v,(mem_filter.mp ua).2,cover ▸ lp'.join tail dis ((aFull p pa ph).2 r ri)⟩

#print axioms no_bridge_one_inner_free
end Graffiti189LongestPath.CrossSaturation.Split.Five
