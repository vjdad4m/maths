import DegreeFiveSixOneBridgeTwoInnerClose189
import DegreeFiveSixThreeInnerTwoB189
import DegreeFiveBridgeSize189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private count_cut_a from DegreeFiveBridgeSize189

variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem exact_three_three_one_bridge_of_three_inner_three_b
    (hc : G.Connected) (far : 3 ≤ G.dist a b)
    (even : ∀ v,(EvenFrom G v).card ≤ 6)
    (conn : ∀ R : Finset V, R.card < 2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V, u ≠ v → 5 ≤ G.degree u ∨ 5 ≤ G.degree v)
    (bHigh : 5 ≤ G.degree b)
    (local3 : S.localA.card = 3) (foreign3 : S.foreignA.card = 3)
    (lc : (S.L.filter (G.Adj b)).card ≤ 3) (bc : (S.R.filter (G.Adj b)).card ≤ 3)
    (br : portBridge S)
    (rc : (G.induce (↑S.R : Set V)).Connected)
    (ra : ∃ x∈S.R, G.Adj a x) (rb : ∃ x∈S.R, G.Adj b x)
    (nb : ¬portBridge (switch S rc ra rb))
    (last : (farNonports S.R a b G).card = 3 → (S.R.filter (G.Adj b)).card = 3 →
      ∃ x y,∃ p : G.Walk x y,p.IsPath ∧ ∀ z,z∈p.support) :
    ∃ x y,∃ p : G.Walk x y,p.IsPath ∧ ∀ z,z∈p.support := by
  classical
  let T := switch S rc ra rb
  have far' : 3≤G.dist b a := by rwa [dist_comm]
  have counts := count_cut_a S.flip far'
  change G.degree b = (S.L.filter (G.Adj b)).card + (S.R.filter (G.Adj b)).card at counts
  have lowB : 2 ≤ (S.R.filter (G.Adj b)).card := by omega
  have iMax := opposite_nonport_le_four_at_three_bridge S hc far even conn degree local3 foreign3 br
  by_cases e2 : (farNonports S.R a b G).card ≤ 2
  · exact exact_three_three_no_bridge_two_inners T hc far even conn degree foreign3 local3
      lowB bc e2 nb S.leftConnected S.leftA S.leftB
  by_cases e4 : (farNonports S.R a b G).card = 4
  · exact exact_one_bridge_with_four_opposite_nonports S hc far even conn degree local3 foreign3
      br e4 bc rc ra rb nb
  have e3 : (farNonports S.R a b G).card = 3 := by omega
  by_cases b2 : (S.R.filter (G.Adj b)).card = 2
  · exact three_inner_nonbridge_two_b S hc far even conn degree local3 foreign3
      (by omega) b2 e3 br rc ra rb nb
  exact last e3 (by omega)

#print axioms exact_three_three_one_bridge_of_three_inner_three_b
end Graffiti189LongestPath.CrossSaturation.Split.Five
