import DegreeFiveSixOneBridgeFourThree189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private not_common secondA_right_and_left_le_five from DegreeFiveFourPort189

variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem exact_one_bridge_with_four_opposite_nonports
    (hc : G.Connected) (far : 3 ≤ G.dist a b)
    (even : ∀ v,(EvenFrom G v).card ≤ 6)
    (conn : ∀ R : Finset V, R.card < 2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V, u ≠ v → 5 ≤ G.degree u ∨ 5 ≤ G.degree v)
    (left3 : S.localA.card = 3) (right3 : S.foreignA.card = 3)
    (bridge : portBridge S) (right4 : (farNonports S.R a b G).card = 4)
    (bcap : (S.R.filter (G.Adj b)).card ≤ 3)
    (rc : (G.induce (↑S.R : Set V)).Connected)
    (ra : ∃ x ∈ S.R, G.Adj a x) (rb : ∃ x ∈ S.R, G.Adj b x)
    (no : ¬portBridge (switch S rc ra rb)) :
    ∃ x y, ∃ p : G.Walk x y, p.IsPath ∧ ∀ v, v ∈ p.support := by
  classical
  by_cases few : (S.R.filter (G.Adj b)).card ≤ 2
  · exact exact_one_bridge_with_four_nonports_and_few_b S hc far even conn degree
      left3 right3 bridge right4 few rc ra rb no
  let T := switch S rc ra rb
  let I := farNonports S.R a b G
  let Q := secondA G S.R a
  have bc : (T.L.filter (G.Adj b)).card = 3 := by
    change (S.R.filter (G.Adj b)).card = 3
    omega
  obtain ⟨x,xl,y,yl,ax,xy,by'⟩ := bridge
  have B : portBridge S := ⟨x,xl,y,yl,ax,xy,by'⟩
  have ⟨_,sB⟩ := four_nonports_opposite_bridge_forces_five_shore S hc far even conn degree
    left3 right3 B right4
  have atMost := bridge_three_foreign_invisible_cap S hc even conn right3 xl ax xy by' (not_common far ax)
  change (I \ Q).card ≤ 1 at atMost
  have local2 := second_shell_at_least_two_at_three_ports S hc far left3 degree
  have sum := secondA_right_and_left_le_five S even
  change (secondA G S.L a).card + Q.card ≤ 5 at sum
  have split : (I \ Q).card + (I ∩ Q).card = I.card := by
    have p := card_sdiff_add_card_eq_card (inter_subset_left : I ∩ Q ⊆ I)
    have identity : I \ (I ∩ Q) = I \ Q := by ext; simp [and_assoc]
    rwa [identity] at p
  have iq : (I ∩ Q).card ≤ Q.card := card_le_card inter_subset_right
  change I.card = 4 at right4
  have n : (I \ Q).card = 1 := by omega
  obtain ⟨t,ts⟩ := card_eq_one.mp n
  obtain ⟨ti,tq⟩ := mem_sdiff.mp (ts.symm ▸ mem_singleton_self t)
  have only : ∀ z∈I, z ≠ t → z ∈ Q := by
    intro z zi ne
    by_contra zq
    exact ne (mem_singleton.mp (ts ▸ mem_sdiff.mpr ⟨zi,zq⟩))
  have c3 : T.foreignA.card = 3 := left3
  exact (no_four_inner_nonbridge_at_three_three T hc far even degree c3 bc sB no ti tq only).elim

#print axioms exact_one_bridge_with_four_opposite_nonports
end Graffiti189LongestPath.CrossSaturation.Split.Five
