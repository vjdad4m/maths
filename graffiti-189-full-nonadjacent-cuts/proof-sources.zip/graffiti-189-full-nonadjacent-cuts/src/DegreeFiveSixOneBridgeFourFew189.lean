import DegreeFiveSixVisibleFull189
import DegreeFiveSevenMixedDrop24189
import DegreeFiveSevenNoBridgeClose189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private d2 from CrossSaturation189
open private not_common from DegreeFiveFourPort189

variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

/-- In the nonbridge shore, all neighbors in nonports of a b-porter are
charged to b's distance-two budget. -/
theorem no_bridge_b_port_degree_charged_to_second
    (hc : G.Connected) (far : 3 ≤ G.dist a b) (no : ¬portBridge S)
    {p : V} (pb : p ∈ S.L.filter (G.Adj b)) :
    G.degree p ≤ (S.L.filter (G.Adj b)).card + (secondA G S.L b).card := by
  classical
  let B := S.L.filter (G.Adj b)
  let I := farNonports S.L a b G
  have nv : p ∉ visibleBPorts S.L a b G := by
    intro m
    obtain ⟨zl,bz,w,wl,aw,wz⟩ := mem_filter.mp m
    exact no ⟨w,wl,p,zl,aw,wz,bz⟩
  have h := far_port_nonport_degree_lower pb (far_dark_b_port_candidates S far pb nv)
  change G.degree p ≤ B.card + (I.filter (G.Adj p)).card at h
  have sb : I.filter (G.Adj p) ⊆ secondA G S.L b := by
    intro q qm
    obtain ⟨qi,pq⟩ := mem_filter.mp qm
    obtain ⟨ql,_,bq⟩ := mem_filter.mp qi
    have bn : b ≠ q := fun eq => S.leftOff.2 (eq.symm ▸ ql)
    exact mem_inter.mpr ⟨ql,d2 hc bn bq (mem_filter.mp pb).2 pq⟩
  exact h.trans (Nat.add_le_add_left (card_le_card sb) _)

theorem exact_one_bridge_with_four_nonports_and_few_b
    (hc : G.Connected) (far : 3 ≤ G.dist a b)
    (even : ∀ v,(EvenFrom G v).card ≤ 6)
    (conn : ∀ R : Finset V, R.card < 2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V, u ≠ v → 5 ≤ G.degree u ∨ 5 ≤ G.degree v)
    (left3 : S.localA.card = 3) (right3 : S.foreignA.card = 3)
    (bridge : portBridge S) (right4 : (farNonports S.R a b G).card = 4)
    (few : (S.R.filter (G.Adj b)).card ≤ 2)
    (rc : (G.induce (↑S.R : Set V)).Connected)
    (ra : ∃ x ∈ S.R, G.Adj a x) (rb : ∃ x ∈ S.R, G.Adj b x)
    (no : ¬portBridge (switch S rc ra rb)) :
    ∃ x y, ∃ p : G.Walk x y, p.IsPath ∧ ∀ v, v ∈ p.support := by
  classical
  let T := switch S rc ra rb
  let B := S.R.filter (G.Adj b)
  have ⟨size, shell⟩ := four_nonports_opposite_bridge_forces_five_shore S hc far even conn degree
    left3 right3 bridge right4
  have low (v : V) (vb : v ∈ B) : ¬5 ≤ G.degree v := by
    have n := no_bridge_b_port_degree_charged_to_second T hc far no vb
    change G.degree v ≤ B.card + (secondA G S.R b).card at n
    change B.card ≤ 2 at few
    omega
  have b1 : B.card ≤ 1 := by
    by_contra! h
    obtain ⟨x,xb,y,yb,xy⟩ := one_lt_card.mp h
    exact (degree x y xy).elim (low x xb) (low y yb)
  have rs : S.R.card ≤ 8 := by
    have q := left_port_count T far
    change S.foreignA.card + B.card + (farNonports S.R a b G).card = S.R.card at q
    omega
  have hit := rb
  obtain ⟨p,pr,bp⟩ := hit
  have pb : p ∈ B := mem_filter.mpr ⟨pr,bp⟩
  have leftHigh (v : V) (vl : v ∈ S.L) : 5 ≤ G.degree v :=
    (degree v p (fun eq => disjoint_left.mp S.dis vl (eq.symm ▸ pr))).resolve_right (low p pb)
  exact traceable_of_small_sides S far degree (by omega) rs leftHigh rc ra rb

#print axioms no_bridge_b_port_degree_charged_to_second
#print axioms exact_one_bridge_with_four_nonports_and_few_b
end Graffiti189LongestPath.CrossSaturation.Split.Five
