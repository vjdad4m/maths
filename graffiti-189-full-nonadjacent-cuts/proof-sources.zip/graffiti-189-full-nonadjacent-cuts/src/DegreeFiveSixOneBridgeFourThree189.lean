import DegreeFiveSixOneBridgeFourFew189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private d2 from CrossSaturation189
open private left_boundary from AdjacentCut189
open private not_common from DegreeFiveFourPort189

variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

/-- A nonbridge shore with three ports of each color cannot have
four nonports in this one-bridge geometry. -/
theorem no_four_inner_nonbridge_at_three_three
    (hc : G.Connected) (far : 3 ≤ G.dist a b)
    (even : ∀ v,(EvenFrom G v).card ≤ 6)
    (degree : ∀ u v : V, u ≠ v → 5 ≤ G.degree u ∨ 5 ≤ G.degree v)
    (foreign : S.foreignA.card = 3)
    (b3 : (S.L.filter (G.Adj b)).card = 3)
    (bBudget : (secondA G S.L b).card ≤ 2)
    (no : ¬portBridge S)
    {t : V} (tin : t ∈ farNonports S.L a b G)
    (tinv : t ∉ secondA G S.L a)
    (only : ∀ z ∈ farNonports S.L a b G, z ≠ t → z ∈ secondA G S.L a) :
    False := by
  classical
  let A := S.localA
  let B := S.L.filter (G.Adj b)
  let I := farNonports S.L a b G
  let K := I.filter (fun z => ∃ q∈B, G.Adj q z)
  have bs : B.card = 3 := b3
  have tl := (mem_filter.mp tin).1
  have at' := (mem_filter.mp tin).2.1
  have bt := (mem_filter.mp tin).2.2
  have tA (p : V) (pa : p ∈ A) : ¬G.Adj p t := by
    intro pt
    have d := d2 hc (show a ≠ t from fun h => S.leftOff.1 (h.symm ▸ tl)) at'
      (mem_filter.mp pa).2 pt
    exact tinv (mem_inter.mpr ⟨tl,d⟩)
  have ksub : K ⊆ secondA G S.L b := by
    intro z zm
    obtain ⟨zi,q,qb,qz⟩ := mem_filter.mp zm
    obtain ⟨zl,_,bz⟩ := mem_filter.mp zi
    have bne : b ≠ z := fun h => S.leftOff.2 (h.symm ▸ zl)
    exact mem_inter.mpr ⟨zl,d2 hc bne bz (mem_filter.mp qb).2 qz⟩
  have k2 : K.card ≤ 2 := (card_le_card ksub).trans bBudget
  have full (q : V) (qb : q ∈ B) (qh : 5 ≤ G.degree q) :
      ∀ z ∈ K, G.Adj q z := by
    have invis : q ∉ visibleBPorts S.L a b G := by
      intro h
      obtain ⟨ql,bq,p,pl,ap,pq⟩ := mem_filter.mp h
      exact no ⟨p,pl,q,ql,ap,pq,bq⟩
    have bound := far_port_nonport_degree_lower qb (far_dark_b_port_candidates S far qb invis)
    change G.degree q ≤ B.card + (I.filter (G.Adj q)).card at bound
    have ss : I.filter (G.Adj q) ⊆ K := by
      intro z zm
      obtain ⟨zi,qz⟩ := mem_filter.mp zm
      exact mem_filter.mpr ⟨zi,q,qb,qz⟩
    have cc : K.card ≤ (I.filter (G.Adj q)).card := by omega
    have kk := eq_of_subset_of_card_le ss cc
    intro z zk
    exact (mem_filter.mp (kk.symm ▸ zk)).2
  have two_high : ∃ u∈B, ∃ v∈B, u ≠ v ∧ 5 ≤ G.degree u ∧ 5 ≤ G.degree v := by
    by_cases all : ∀ q∈B, 5 ≤ G.degree q
    · obtain ⟨u,ub,v,vb,uv⟩ := one_lt_card.mp (show 1 < B.card by omega)
      exact ⟨u,ub,v,vb,uv,all u ub,all v vb⟩
    push_neg at all
    obtain ⟨w,wb,wh⟩ := all
    have n : (B.erase w).card = 2 := by rw [card_erase_of_mem wb,bs]
    obtain ⟨u,um,v,vm,uv⟩ := one_lt_card.mp (show 1 < (B.erase w).card by omega)
    obtain ⟨uw,ub⟩ := mem_erase.mp um
    obtain ⟨vw,vb⟩ := mem_erase.mp vm
    exact ⟨u,ub,v,vb,uv,(degree u w uw).resolve_right (by omega),
      (degree v w vw).resolve_right (by omega)⟩
  obtain ⟨u,ub,v,vb,uv,uh,vh⟩ := two_high
  have uk : I.filter (G.Adj u) ⊆ K := by
    intro z zm
    obtain ⟨zi,uz⟩ := mem_filter.mp zm
    exact mem_filter.mpr ⟨zi,u,ub,uz⟩
  have us : G.degree u ≤ B.card + (I.filter (G.Adj u)).card := by
    have invis : u ∉ visibleBPorts S.L a b G := by
      intro h
      obtain ⟨ul,bu,p,pl,ap,pu⟩ := mem_filter.mp h
      exact no ⟨p,pl,u,ul,ap,pu,bu⟩
    exact far_port_nonport_degree_lower ub (far_dark_b_port_candidates S far ub invis)
  have n := card_le_card uk
  have kn : 1 < K.card := by omega
  obtain ⟨r,rk,rt⟩ : ∃ r∈K, r ≠ t := by
    obtain ⟨p,pk,q,qk,pq⟩ := one_lt_card.mp kn
    by_cases pt : p = t
    · exact ⟨q,qk,fun qt => pq (pt.trans qt.symm)⟩
    exact ⟨p,pk,pt⟩
  have ri : r ∈ I := (mem_filter.mp rk).1
  have rl := (mem_filter.mp ri).1
  obtain ⟨p,pa,pr⟩ := nonport_a_neighbor S hc far rl (mem_inter.mp (only r ri rt)).2
  obtain ⟨pl,ap⟩ := mem_filter.mp pa
  have near (q : V) (qb : q ∈ B) (qr : G.Adj q r) : q ∈ DistanceTwo G p := by
    have pq : p ≠ q := fun e => not_common far (e ▸ ap) (mem_filter.mp qb).2
    exact d2 hc pq (distance_two_charge_from_no_bridge S pa qb no) pr qr.symm
  have pair := (show ({u,v} : Finset V) ⊆ DistanceTwo G p from
    insert_subset_iff.mpr ⟨near u ub (full u ub uh r rk),
      singleton_subset_iff.mpr (near v vb (full v vb vh r rk))⟩)
  have wg : ({u,v} : Finset V) ⊆ insert b B :=
    insert_subset (mem_insert_of_mem ub) (singleton_subset_iff.mpr (mem_insert_of_mem vb))
  have cuv : ({u,v} : Finset V).card = 2 := by simp [uv]
  have vis := two_charges_force_full_on_visible S hc far even foreign pa cuv wg pair
  have ti (z : V) (zi : z ∈ I) : ¬G.Adj t z := by
    intro tz
    have zt : z ≠ t := tz.ne.symm
    have pt : p ≠ t := fun h => at' (h ▸ ap)
    have d := d2 hc pt (tA p pa) (vis.2 z zi (only z zi zt)) tz.symm
    have bs' : ({u,v} : Finset V) ⊆ S.L :=
      insert_subset (mem_filter.mp ub).1 (singleton_subset_iff.mpr (mem_filter.mp vb).1)
    have geom := local_distance_two_at_foreign_three S hc even foreign pl ap
      (insert_subset_iff.mpr ⟨mem_insert_of_mem tl,bs'.trans (subset_insert _ _)⟩)
      (insert_subset_iff.mpr ⟨d,pair⟩)
    have tn : t ∉ ({u,v} : Finset V) := by
      intro tm
      rcases mem_insert.mp tm with e|e
      · exact bt (e.symm ▸ (mem_filter.mp ub).2)
      exact bt ((mem_singleton.mp e).symm ▸ (mem_filter.mp vb).2)
    rw [card_insert_of_not_mem tn,cuv] at geom
    omega
  have ts : G.neighborFinset t ⊆ B := by
    intro z zm
    have tz := (mem_neighborFinset G t z).mp zm
    rcases left_boundary S t tl z tz with e|e|zl
    · exact (at' (e ▸ tz.symm)).elim
    · exact (bt (e ▸ tz.symm)).elim
    by_cases bz : G.Adj b z
    · exact mem_filter.mpr ⟨zl,bz⟩
    by_cases az : G.Adj a z
    · exact (tA z (mem_filter.mpr ⟨zl,az⟩) tz.symm).elim
    exact (ti z (mem_filter.mpr ⟨zl,az,bz⟩) tz).elim
  have td := card_le_card ts
  rw [card_neighborFinset_eq_degree] at td
  have take : B ⊆ DistanceTwo G p := by
    intro q qb
    have qt : q ≠ t := fun h => bt (h ▸ (mem_filter.mp qb).2)
    have qh := (degree q t qt).resolve_right (by omega)
    exact near q qb (full q qb qh r rk)
  have cnt := local_distance_two_at_foreign_three S hc even foreign pl ap
    (show B ⊆ insert b S.L from (filter_subset _ _).trans (subset_insert _ _)) take
  omega

#print axioms no_four_inner_nonbridge_at_three_three
end Graffiti189LongestPath.CrossSaturation.Split.Five
