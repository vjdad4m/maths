import DegreeFiveSixInvisibleCap189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private d2 foreign_subset from CrossSaturation189
open private left_boundary from AdjacentCut189
open private not_common side_universal_if_no_local_d2 secondA_right_and_left_le_five from DegreeFiveFourPort189

variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem second_shell_at_least_two_at_three_ports (hc : G.Connected)
    (far : 3 ≤ G.dist a b) (three : S.localA.card = 3)
    (degree : ∀ u v : V, u ≠ v → 5 ≤ G.degree u ∨ 5 ≤ G.degree v) :
    2 ≤ (secondA G S.L a).card := by
  classical
  obtain ⟨u,ua,v,va,uv⟩ := one_lt_card.mp (show 1 < S.localA.card by omega)
  wlog hi : 5 ≤ G.degree u generalizing u v
  · exact this v va u ua uv.symm ((degree u v uv).resolve_left hi)
  obtain ⟨ul,au⟩ := mem_filter.mp ua
  let P := insert a (S.localA.erase u)
  have sub : G.neighborFinset u ⊆ P ∪ secondA G S.L a := by
    intro z zn
    have uz := (mem_neighborFinset G u z).mp zn
    rcases left_boundary S u ul z uz with e|e|zl
    · exact mem_union_left _ (mem_insert.mpr (.inl e))
    · exact (not_common far au (e ▸ uz.symm)).elim
    by_cases az : G.Adj a z
    · exact mem_union_left _ (mem_insert_of_mem (mem_erase.mpr ⟨uz.ne.symm, mem_filter.mpr ⟨zl,az⟩⟩))
    exact mem_union_right _ (mem_inter.mpr ⟨zl,d2 hc
      (fun e => S.leftOff.1 (e.symm ▸ zl)) az au uz⟩)
  have ctr := (card_le_card sub).trans (card_union_le P _)
  rw [card_neighborFinset_eq_degree] at ctr
  have pc := card_insert_le a (S.localA.erase u)
  rw [card_erase_of_mem ua, three] at pc
  change P.card ≤ 3 at pc
  omega

theorem bridge_universal_with_invisible_opposite (hc : G.Connected) (far : 3 ≤ G.dist a b)
    (even : ∀ v, (EvenFrom G v).card ≤ 6)
    (conn : ∀ R : Finset V, R.card < 2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (three : S.foreignA.card = 3) {x y : V}
    (xl : x ∈ S.L) (ax : G.Adj a x) (xy : G.Adj x y) (by' : G.Adj b y)
    {z : V} (zi : z ∈ farNonports S.R a b G \ secondA G S.R a) :
    ∀ w ∈ S.L, w = x ∨ G.Adj x w := by
  classical
  have bx : x ≠ b := fun e => S.leftOff.2 (e ▸ xl)
  have bd : b ∈ DistanceTwo G x := d2 hc bx (fun h => not_common far ax h.symm) xy by'.symm
  have sub : insert b S.foreignA ⊆ DistanceTwo G x := by
    intro t ht
    exact (mem_insert.mp ht).elim (fun e => e.symm ▸ bd)
      (fun h => foreign_subset S hc xl ax h)
  have out : b ∉ S.foreignA := fun h => S.rightOff.2 (mem_filter.mp h).1
  have low := card_le_card sub
  rw [card_insert_of_not_mem out, three] at low
  have cap := FiveActualCut.four_layer_add_distance_two_le_five even x
  have ecc : G.dist x z ≤ 4 := by
    by_contra h
    have high : 2 ≤ (univ.filter (fun w => G.dist x w = 4)).card :=
      layer_card_of_connectivity hc 2 conn (x:=x) (y:=z) 4 (by decide) (by omega) (inferInstance)
    omega
  obtain ⟨hp,inv⟩ := mem_sdiff.mp zi
  obtain ⟨zr,az,bz⟩ := mem_filter.mp hp
  have la := hc.one_lt_dist_of_ne_of_not_adj (show a ≠ z from fun h => S.rightOff.1 (h.symm ▸ zr)) az
  have lb := hc.one_lt_dist_of_ne_of_not_adj (show b ≠ z from fun h => S.rightOff.2 (h.symm ▸ zr)) bz
  have na : G.dist a z ≠ 2 := by
    intro eq
    exact inv (mem_inter.mpr ⟨zr,by simp [DistanceTwo,eq]⟩)
  have eq := cross_metric S.L hc xl (fun h => disjoint_left.mp S.dis h zr) (left_boundary S)
  have dxa := dist_eq_one_iff_adj.mpr ax.symm
  have dxb : G.dist x b = 2 := by simpa [DistanceTwo] using bd
  rw [dxa,dxb] at eq
  have z4 : G.dist x z = 4 := by omega
  have pos : 1 ≤ (univ.filter (fun w => G.dist x w = 4)).card :=
    card_pos.mpr ⟨z, mem_filter.mpr ⟨mem_univ _,z4⟩⟩
  apply side_universal_if_no_local_d2 S hc xl
  intro t tl td
  have notMem : t ∉ insert b S.foreignA := by
    intro tm
    rcases mem_insert.mp tm with e|tm
    · exact S.leftOff.2 (e ▸ tl)
    exact disjoint_left.mp S.dis tl (mem_filter.mp tm).1
  have n := card_le_card (insert_subset_iff.mpr ⟨td,sub⟩)
  rw [card_insert_of_not_mem notMem,card_insert_of_not_mem out,three] at n
  omega

theorem opposite_nonport_le_four_at_three_bridge (hc : G.Connected) (far : 3 ≤ G.dist a b)
    (even : ∀ v,(EvenFrom G v).card ≤ 6)
    (conn : ∀ R : Finset V,R.card < 2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u ≠ v → 5 ≤ G.degree u ∨ 5 ≤ G.degree v)
    (local3 : S.localA.card = 3) (foreign3 : S.foreignA.card = 3)
    (bridge : portBridge S) : (farNonports S.R a b G).card ≤ 4 := by
  classical
  obtain ⟨x,xl,y,_,ax,xy,by'⟩ := bridge
  have h1 := second_shell_at_least_two_at_three_ports S hc far local3 degree
  have h2 := secondA_right_and_left_le_five S even
  have h3 := bridge_three_foreign_invisible_cap S hc even conn foreign3 xl ax xy by' (not_common far ax)
  have h4 := card_sdiff_add_card_eq_card (inter_subset_left :
    farNonports S.R a b G ∩ secondA G S.R a ⊆ farNonports S.R a b G)
  have iden : farNonports S.R a b G \ (farNonports S.R a b G ∩ secondA G S.R a) =
      farNonports S.R a b G \ secondA G S.R a := by ext; simp [and_assoc]
  rw [iden] at h4
  have h5 := card_le_card (inter_subset_right :
    farNonports S.R a b G ∩ secondA G S.R a ⊆ secondA G S.R a)
  omega

#print axioms second_shell_at_least_two_at_three_ports
#print axioms bridge_universal_with_invisible_opposite
#print axioms opposite_nonport_le_four_at_three_bridge
end Graffiti189LongestPath.CrossSaturation.Split.Five
