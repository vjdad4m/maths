import DegreeFiveSixOneBridgeGeometry189
import DegreeFiveFarSideSlots189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private d2 from CrossSaturation189
open private not_common secondA_right_and_left_le_five from DegreeFiveFourPort189

variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem three_ports_in_five_shore_visible_to_b (hc : G.Connected)
    (far : 3 ≤ G.dist a b) (size : S.L.card = 5)
    (degree : ∀ u v : V, u ≠ v → 5 ≤ G.degree u ∨ 5 ≤ G.degree v) :
    S.localA ⊆ secondA G S.L b := by
  classical
  obtain ⟨y,yl,by'⟩ := S.leftB
  intro p pp
  obtain ⟨pl,ap⟩ := mem_filter.mp pp
  have ne : p ≠ y := fun h => not_common far (h ▸ ap) by'
  have py : G.Adj p y := (degree p y ne).elim
    (fun h => high_far_port_shore_universal_at_five S far size pl h (.inl ap) y yl ne)
    (fun h => (high_far_port_shore_universal_at_five S far size yl h (.inr by') p pl ne.symm).symm)
  have bp : b ≠ p := fun h => S.leftOff.2 (h.symm ▸ pl)
  exact mem_inter.mpr ⟨pl, d2 hc bp (not_common far ap) by' py.symm⟩

theorem left_shore_small_when_opposite_invisible
    (hc : G.Connected) (far : 3 ≤ G.dist a b)
    (even : ∀ v,(EvenFrom G v).card ≤ 6)
    (conn : ∀ R : Finset V, R.card < 2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V, u ≠ v → 5 ≤ G.degree u ∨ 5 ≤ G.degree v)
    (left3 : S.localA.card = 3) (right3 : S.foreignA.card = 3)
    (bridge : portBridge S)
    (invis : ((farNonports S.R a b G) \ secondA G S.R a).Nonempty) :
    S.L.card + (secondA G S.R a).card ≤ 8 ∧ 5 ≤ S.L.card := by
  classical
  obtain ⟨x,xl,y,_,ax,xy,by'⟩ := bridge
  obtain ⟨z,zi⟩ := invis
  have full := bridge_universal_with_invisible_opposite S hc far even conn right3 xl ax xy by' zi
  let P := S.L \ S.localA
  have ps : P ⊆ secondA G S.L a := by
    intro v vv
    obtain ⟨vl,va⟩ := mem_sdiff.mp vv
    have av : ¬G.Adj a v := fun e => va (mem_filter.mpr ⟨vl,e⟩)
    have xv := (full v vl).resolve_left (fun h => av (h.symm ▸ ax))
    have ne : a ≠ v := fun h => S.leftOff.1 (h.symm ▸ vl)
    exact mem_inter.mpr ⟨vl,d2 hc ne av ax xv⟩
  have pc := card_le_card ps
  have part : P.card + S.localA.card = S.L.card := card_sdiff_add_card_eq_card (filter_subset _ _)
  have budget := secondA_right_and_left_le_five S even
  have low := second_shell_at_least_two_at_three_ports S hc far left3 degree
  have incl : secondA G S.L a ⊆ P := by
    intro v vv
    obtain ⟨vl,h⟩ := mem_inter.mp vv
    have d : G.dist a v = 2 := by simpa [DistanceTwo] using h
    refine mem_sdiff.mpr ⟨vl, ?_⟩
    intro q
    have h1 := dist_eq_one_iff_adj.mpr (mem_filter.mp q).2
    omega
  have ll := card_le_card incl
  omega

theorem four_nonports_opposite_bridge_forces_five_shore
    (hc : G.Connected) (far : 3 ≤ G.dist a b)
    (even : ∀ v,(EvenFrom G v).card ≤ 6)
    (conn : ∀ R : Finset V, R.card < 2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V, u ≠ v → 5 ≤ G.degree u ∨ 5 ≤ G.degree v)
    (left3 : S.localA.card = 3) (right3 : S.foreignA.card = 3)
    (bridge : portBridge S) (right4 : (farNonports S.R a b G).card = 4) :
    S.L.card = 5 ∧ (secondA G S.R b).card ≤ 2 := by
  classical
  obtain ⟨x,xl,y,yl,ax,xy,by'⟩ := bridge
  have B : portBridge S := ⟨x,xl,y,yl,ax,xy,by'⟩
  let I := farNonports S.R a b G
  let Q := secondA G S.R a
  have split : (I \ Q).card + (I ∩ Q).card = I.card := by
    have p := card_sdiff_add_card_eq_card (inter_subset_left : I ∩ Q ⊆ I)
    have identity : I \ (I ∩ Q) = I \ Q := by ext; simp [and_assoc]
    rwa [identity] at p
  have three := bridge_three_foreign_invisible_cap S hc even conn right3 xl ax xy by' (not_common far ax)
  change (I \ Q).card ≤ 1 at three
  have inside : (I ∩ Q).card ≤ Q.card := card_le_card inter_subset_right
  have left := second_shell_at_least_two_at_three_ports S hc far left3 degree
  have budget := secondA_right_and_left_le_five S even
  change (secondA G S.L a).card + Q.card ≤ 5 at budget
  change I.card = 4 at right4
  have hi : 0 < (I \ Q).card := by omega
  have ⟨first,second⟩ := left_shore_small_when_opposite_invisible S hc far even conn degree
    left3 right3 B (card_pos.mp hi)
  change S.L.card + Q.card ≤ 8 at first
  have size : S.L.card = 5 := by omega
  have cover := three_ports_in_five_shore_visible_to_b S hc far size degree
  have cnt := card_le_card cover
  have sc := secondA_right_and_left_le_five S.flip even
  change (secondA G S.L b).card + (secondA G S.R b).card ≤ 5 at sc
  exact ⟨size, by omega⟩

#print axioms three_ports_in_five_shore_visible_to_b
#print axioms left_shore_small_when_opposite_invisible
#print axioms four_nonports_opposite_bridge_forces_five_shore
end Graffiti189LongestPath.CrossSaturation.Split.Five
