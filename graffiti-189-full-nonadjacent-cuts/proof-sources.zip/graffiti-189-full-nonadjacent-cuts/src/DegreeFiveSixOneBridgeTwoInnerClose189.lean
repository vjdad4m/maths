import DegreeFiveSixOneBridgeTwoInnerMetric189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private d2 foreign_subset from CrossSaturation189
open private not_common secondA_right_and_left_le_five from DegreeFiveFourPort189

variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem exact_three_three_no_bridge_two_inners
    (hc : G.Connected) (far : 3 ≤ G.dist a b)
    (even : ∀ v, (EvenFrom G v).card ≤ 6)
    (conn : ∀ R : Finset V, R.card < 2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V, u ≠ v → 5 ≤ G.degree u ∨ 5 ≤ G.degree v)
    (aa : S.localA.card = 3) (aa' : S.foreignA.card = 3)
    (bb : 2 ≤ (S.L.filter (G.Adj b)).card) (bb' : (S.L.filter (G.Adj b)).card ≤ 3)
    (ii : (farNonports S.L a b G).card ≤ 2) (no : ¬portBridge S)
    (rc : (G.induce (↑S.R : Set V)).Connected)
    (ra : ∃ x ∈ S.R, G.Adj a x) (rb : ∃ x ∈ S.R, G.Adj b x) :
    ∃ x y, ∃ p : G.Walk x y, p.IsPath ∧ ∀ v, v ∈ p.support := by
  classical
  let A := S.localA
  let B := S.L.filter (G.Adj b)
  let I := farNonports S.L a b G
  have a3 : A.card = 3 := aa
  have b2 : 2 ≤ B.card := bb
  have bmax : B.card ≤ 3 := bb'
  have iMax : I.card ≤ 2 := ii
  have highA : ∃ u∈A, 5 ≤ G.degree u := by
    obtain ⟨u,ua,v,va,uv⟩ := one_lt_card.mp (show 1 < A.card by omega)
    exact (degree u v uv).elim (fun uh => ⟨u,ua,uh⟩) (fun vh => ⟨v,va,vh⟩)
  obtain ⟨p,pa,ph⟩ := highA
  obtain ⟨pl,ap⟩ := mem_filter.mp pa
  have poolA := bounds_of_local_color_port S far pa
    (fun q qb => distance_two_charge_from_no_bridge S pa qb no)
  have nA := far_port_nonport_degree_lower pa poolA
  change G.degree p ≤ A.card + (I.filter (G.Adj p)).card at nA
  have ia := card_le_card (filter_subset (G.Adj p) I)
  have i2 : I.card = 2 := by omega
  have fullA : ∀ q∈I, G.Adj p q :=
    (far_port_full_at_tight_pool pa poolA (by change A.card + I.card = 5; omega) ph).2
  have bPool (q : V) (qb : q∈B) := by
    have invis : q ∉ visibleBPorts S.L a b G := by
      intro h
      obtain ⟨ql,bq,u,ul,au,uq⟩ := mem_filter.mp h
      exact no ⟨u,ul,q,ql,au,uq,bq⟩
    exact far_dark_b_port_candidates S far qb invis
  have b3 : B.card = 3 := by
    apply Classical.byContradiction
    intro h
    obtain ⟨u,ub,v,vb,uv⟩ := one_lt_card.mp (show 1 < B.card by omega)
    have low (q : V) (qb : q∈B) : ¬5 ≤ G.degree q := by
      have nq := far_port_nonport_degree_lower qb (bPool q qb)
      change G.degree q ≤ B.card + (I.filter (G.Adj q)).card at nq
      have cq := card_le_card (filter_subset (G.Adj q) I)
      omega
    exact (degree u v uv).elim (low u ub) (low v vb)
  have highB : ∃ u∈B, ∃ v∈B, u ≠ v ∧ 5 ≤ G.degree u ∧ 5 ≤ G.degree v := by
    by_cases all : ∀ q∈B, 5 ≤ G.degree q
    · obtain ⟨u,ub,v,vb,uv⟩ := one_lt_card.mp (show 1<B.card by omega)
      exact ⟨u,ub,v,vb,uv,all u ub,all v vb⟩
    push_neg at all
    obtain ⟨w,wb,wh⟩ := all
    have c : (B.erase w).card = 2 := by rw [card_erase_of_mem wb,b3]
    obtain ⟨u,ub,v,vb,uv⟩ := one_lt_card.mp (show 1<(B.erase w).card by omega)
    obtain ⟨uw,ub⟩ := mem_erase.mp ub
    obtain ⟨vw,vb⟩ := mem_erase.mp vb
    exact ⟨u,ub,v,vb,uv,(degree u w uw).resolve_right (by omega),
      (degree v w vw).resolve_right (by omega)⟩
  obtain ⟨u,ub,v,vb,uv,uh,vh⟩ := highB
  obtain ⟨z,zi⟩ := card_pos.mp (show 0 < I.card by omega)
  have seen (q : V) (qb : q∈B) (qh : 5 ≤ G.degree q) : q ∈ DistanceTwo G p := by
    have pq : p ≠ q := fun h => not_common far (h ▸ ap) (mem_filter.mp qb).2
    have qz := (far_port_full_at_tight_pool qb (bPool q qb) (by change B.card + I.card = 5; omega) qh).2 z zi
    exact d2 hc pq (distance_two_charge_from_no_bridge S pa qb no) (fullA z zi) qz.symm
  have two : ({u,v} : Finset V) ⊆ DistanceTwo G p :=
    insert_subset (seen u ub uh) (singleton_subset_iff.mpr (seen v vb vh))
  have foreign : S.foreignA ⊆ DistanceTwo G p := fun _ q => foreign_subset S hc pl ap q
  have sep : Disjoint S.foreignA ({u,v} : Finset V) := by
    apply disjoint_left.mpr
    intro q qr ql
    have rr := (mem_filter.mp qr).1
    rcases mem_insert.mp ql with e|e
    · exact disjoint_left.mp S.dis (e.symm ▸ (mem_filter.mp ub).1) rr
    exact disjoint_left.mp S.dis ((mem_singleton.mp e).symm ▸ (mem_filter.mp vb).1) rr
  have sat := card_le_card (union_subset foreign two)
  rw [card_union_of_disjoint sep,aa',show ({u,v} : Finset V).card = 2 by simp [uv]] at sat
  have vis := opposite_periphery_visible_of_saturated_nonbridge S hc far no even conn pl ap (by omega)
  have pc := card_le_card vis
  have total : (S.R \ S.foreignA).card + S.foreignA.card = S.R.card :=
    card_sdiff_add_card_eq_card (filter_subset _ _)
  have iVis : I ⊆ secondA G S.L a := by
    intro q qi
    obtain ⟨ql,aq,_⟩ := mem_filter.mp qi
    exact mem_inter.mpr ⟨ql,d2 hc
      (show a ≠ q from fun h => S.leftOff.1 (h.symm ▸ ql)) aq ap (fullA q qi)⟩
  have l2 := card_le_card iVis
  have budget := secondA_right_and_left_le_five S even
  have size : S.R.card ≤ 6 := by omega
  let T := switch S rc ra rb
  have tsize : T.L.card ≤ 8 := by change S.R.card ≤ 8; omega
  have ta : 2 ≤ T.localA.card := by change 2 ≤ S.foreignA.card; omega
  have free := free_route_small_far_shore T far degree tsize ta
  exact traceable_from_far_terminal_and_free S far
    (three_three_two_inner_terminal S far degree aa b3 i2 no) (.inl free)

#print axioms exact_three_three_no_bridge_two_inners
end Graffiti189LongestPath.CrossSaturation.Split.Five
