import DegreeFiveSixOneBridgeTwoInnerRoute189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private d2 foreign_subset from CrossSaturation189
open private left_boundary from AdjacentCut189
open private two_walk_middle from DistanceTwoCut189
open private not_common cut_not_adj secondA_right_and_left_le_five from DegreeFiveFourPort189

variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

/-- A nonbridge a-port with a full distance-two shell forces every
opposite non-a-port to be in the distance-two shell of a. -/
theorem opposite_periphery_visible_of_saturated_nonbridge
    (hc : G.Connected) (far : 3 ≤ G.dist a b) (no : ¬portBridge S)
    (even : ∀ v,(EvenFrom G v).card ≤ 6)
    (conn : ∀ R : Finset V, R.card < 2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    {x : V} (xl : x∈S.L) (ax : G.Adj a x)
    (sat : 5 ≤ (DistanceTwo G x).card) :
    S.R \ S.foreignA ⊆ secondA G S.R a := by
  classical
  have xb : x ≠ b := fun eq => S.leftOff.2 (eq ▸ xl)
  have e1 := hc.one_lt_dist_of_ne_of_not_adj xb (fun e=>not_common far ax e.symm)
  have e2 : G.dist x b ≠ 2 := by
    intro h
    obtain ⟨w,len⟩ := hc.exists_walk_length_eq_dist x b
    obtain ⟨y,xy,yb⟩ := two_walk_middle w (len.trans h)
    rcases left_boundary S x xl y xy with ea|eb|yl
    · exact cut_not_adj far (ea ▸ yb)
    · exact yb.ne eb
    exact no ⟨x,xl,y,yl,ax,xy,yb.symm⟩
  have farb : 3 ≤ G.dist x b := by omega
  have no4 (z : V) : G.dist x z ≠ 4 := by
    intro h
    have all := FiveActualCut.four_layer_add_distance_two_le_five even x
    have pos : 0 < (univ.filter (fun z=>G.dist x z=4)).card :=
      card_pos.mpr ⟨z,mem_filter.mpr ⟨mem_univ _,h⟩⟩
    omega
  have ecc (z : V) : G.dist x z ≤ 3 := by
    by_contra! h
    have higher : 4 < G.dist x z := by have hn := no4 z; omega
    have lower : 2 ≤ (univ.filter (fun w => G.dist x w = 4)).card :=
      layer_card_of_connectivity hc 2 conn (x:=x) (y:=z) 4 (by decide) higher (inferInstance)
    have all := FiveActualCut.four_layer_add_distance_two_le_five even x
    omega
  intro z zm
  obtain ⟨zr,notA⟩ := mem_sdiff.mp zm
  have ne : a ≠ z := fun h => S.rightOff.1 (h.symm ▸ zr)
  have noAz : ¬G.Adj a z := fun e=>notA (mem_filter.mpr ⟨zr,e⟩)
  have dA := hc.one_lt_dist_of_ne_of_not_adj ne noAz
  have dB : 0 < G.dist b z := Nat.pos_of_ne_zero (fun hz =>
    S.rightOff.2 (((hc.dist_eq_zero_iff).mp hz).symm ▸ zr))
  have mx := cross_metric S.L hc xl (fun h => disjoint_left.mp S.dis h zr) (left_boundary S)
  rw [dist_eq_one_iff_adj.mpr ax.symm] at mx
  have t := ecc z
  have dep : G.dist a z = 2 := by omega
  exact mem_inter.mpr ⟨zr,by simp [DistanceTwo,dep]⟩

#print axioms opposite_periphery_visible_of_saturated_nonbridge
end Graffiti189LongestPath.CrossSaturation.Split.Five
