import DegreeFiveSixOneBridgeFourClose189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private d2 from CrossSaturation189
open private not_common from DegreeFiveFourPort189

variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

/-- Both high ports in a three-element color class must join both
nonports once no edge bridges the two colors. -/
theorem three_three_two_inner_terminal
    (far : 3 ≤ G.dist a b)
    (degree : ∀ u v : V,u ≠ v → 5 ≤ G.degree u ∨ 5 ≤ G.degree v)
    (a3 : S.localA.card = 3) (b3 : (S.L.filter (G.Adj b)).card = 3)
    (i2 : (farNonports S.L a b G).card = 2) (no : ¬portBridge S) :
    ∃ p q, G.Adj a p ∧ G.Adj b q ∧ RouteOn G S.L p q := by
  classical
  let A := S.localA
  let B := S.L.filter (G.Adj b)
  let I := farNonports S.L a b G
  have asz : A.card = 3 := a3
  have bsz : B.card = 3 := b3
  have isz : I.card = 2 := i2
  have fullA (p : V) (pa : p ∈ A) (hi : 5 ≤ G.degree p) :
      (∀ q∈A, p ≠ q → G.Adj p q) ∧ ∀ q∈I, G.Adj p q :=
    far_port_full_at_tight_pool pa
      (bounds_of_local_color_port S far pa (fun q qb => distance_two_charge_from_no_bridge S pa qb no))
      (by omega) hi
  have fullB (p : V) (pb : p ∈ B) (hi : 5 ≤ G.degree p) :
      (∀ q∈B, p ≠ q → G.Adj p q) ∧ ∀ q∈I, G.Adj p q := by
    have invis : p ∉ visibleBPorts S.L a b G := by
      intro h
      obtain ⟨pl,bp,q,ql,aq,qp⟩ := mem_filter.mp h
      exact no ⟨q,ql,p,pl,aq,qp,bp⟩
    exact far_port_full_at_tight_pool pb (far_dark_b_port_candidates S far pb invis)
      (by omega) hi
  have getTwo (K : Finset V) (k3 : K.card = 3) :
      ∃ u∈K, ∃ v∈K, u ≠ v ∧ 5 ≤ G.degree u ∧ 5 ≤ G.degree v := by
    by_cases all : ∀ q∈K, 5 ≤ G.degree q
    · obtain ⟨u,ub,v,vb,uv⟩ := one_lt_card.mp (show 1<K.card by omega)
      exact ⟨u,ub,v,vb,uv,all u ub,all v vb⟩
    push_neg at all
    obtain ⟨w,wb,wh⟩ := all
    have n : (K.erase w).card = 2 := by rw [card_erase_of_mem wb,k3]
    obtain ⟨u,um,v,vm,uv⟩ := one_lt_card.mp (show 1<(K.erase w).card by omega)
    obtain ⟨uw,ub⟩ := mem_erase.mp um
    obtain ⟨vw,vb⟩ := mem_erase.mp vm
    exact ⟨u,ub,v,vb,uv,(degree u w uw).resolve_right (by omega),
      (degree v w vw).resolve_right (by omega)⟩
  obtain ⟨u,ua,v,va,uv,uh,vh⟩ := getTwo A asz
  obtain ⟨r,ri,s,si,rs⟩ := one_lt_card.mp (show 1<I.card by omega)
  have iEq : ({r,s} : Finset V) = I := by
    apply eq_of_subset_of_card_le (insert_subset ri (singleton_subset_iff.mpr si))
    simp [rs,isz]
  have uvsub : ({u,v} : Finset V) ⊆ A := insert_subset ua (singleton_subset_iff.mpr va)
  have c : (A \ {u,v}).card = 1 := by
    rw [card_sdiff uvsub,asz]
    simp [uv]
  obtain ⟨w,we⟩ := card_eq_one.mp c
  have wm : w ∈ A \ {u,v} := we.symm ▸ mem_singleton_self w
  obtain ⟨wa,wn⟩ := mem_sdiff.mp wm
  have wu : w ≠ u := fun h => wn (mem_insert.mpr (.inl h))
  have wv : w ≠ v := fun h => wn (mem_insert.mpr (.inr (mem_singleton.mpr h)))
  have aEq : ({w,u,v} : Finset V) = A := by
    have hu := sdiff_union_of_subset uvsub
    rw [we] at hu
    rw [←hu]
    ext z
    simp [or_comm,or_left_comm,or_assoc]
  have ai (p : V) (pa : p∈A) (q : V) (qi : q∈I) : p ≠ q :=
    fun e => (mem_filter.mp qi).2.1 (e ▸ (mem_filter.mp pa).2)
  have q0 : RouteOn G {r,v,s} r s :=
    RouteOn.three ((fullA v va vh).2 r ri).symm ((fullA v va vh).2 s si) rs
  have q1 : RouteOn G {u,r,v,s} u s :=
    q0.prefix ((fullA u ua uh).2 r ri) (by simp [ai u ua r ri,uv,ai u ua s si])
  have q2 : RouteOn G {w,u,r,v,s} w s :=
    q1.prefix ((fullA u ua uh).1 w wa wu.symm).symm
      (by simp [wu,ai w wa r ri,wv,ai w wa s si])
  have own : ({w,u,r,v,s} : Finset V) = A ∪ I := by
    rw [←aEq,←iEq]
    ext z
    simp [or_comm,or_left_comm,or_assoc]
  have bc : CompleteOn G B := fun p pb q qb ne => (degree p q ne).elim
    (fun h => (fullB p pb h).1 q qb ne) (fun h => ((fullB q qb h).1 p pb ne.symm).symm)
  obtain ⟨x,xb,y,yb,xy,xh,_⟩ := getTwo B bsz
  obtain ⟨p,pp,ps⟩ := path_between_in_clique B bc xb yb xy
  have dis : Disjoint (A ∪ I) B := by
    apply disjoint_left.mpr
    intro z hz zb
    exact (mem_union.mp hz).elim
      (fun za => not_common far (mem_filter.mp za).2 (mem_filter.mp zb).2)
      (fun zi => (mem_filter.mp zi).2.2 (mem_filter.mp zb).2)
  have joined := (own ▸ q2 : RouteOn G (A ∪ I) w s).join
    (show RouteOn G B x y from ⟨p,pp,ps⟩) dis ((fullB x xb xh).2 s si).symm
  have covers : (A ∪ I) ∪ B = S.L := by
    have h := left_port_partition S far
    change A ∪ B ∪ I = S.L at h
    rwa [union_assoc,union_comm B I,←union_assoc] at h
  exact ⟨w,y,(mem_filter.mp wa).2,(mem_filter.mp yb).2,covers ▸ joined⟩

#print axioms three_three_two_inner_terminal
end Graffiti189LongestPath.CrossSaturation.Split.Five
