import DegreeFiveSixTerminalFill189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph Finset
open private d2 from CrossSaturation189
open private not_common from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem four_a_two_inner_ore_pairs (hc : G.Connected) (far : 3≤G.dist a b)
    (even : ∀ z,(EvenFrom G z).card≤6)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (a4 : S.localA.card=4) (b3 : 3≤(S.L.filter (G.Adj b)).card)
    (b4 : (S.L.filter (G.Adj b)).card≤4)
    (i2 : (farNonports S.L a b G).card=2) (foreign : S.foreignA.card=2)
    (no : ¬portBridge S) :
    ∀ p∈S.localA,∀ q∈S.localA,p≠q → ¬G.Adj p q →
      5≤G.degree p ∧ 5≤G.degree q := by
  classical
  let A := S.localA
  let B := S.L.filter (G.Adj b)
  let I := farNonports S.L a b G
  have acard : A.card = 4 := a4
  have icard : I.card = 2 := i2
  have bSub : B⊆S.L := filter_subset _ _
  have cap {p q : V} (pa : p∈A) (qa : q∈A) (pq : p≠q) (npq : ¬G.Adj p q)
      (ph : 5≤G.degree p) (qh : ¬5≤G.degree q) : False := by
    have sub := bounds_of_local_color_port S far pa
      (fun v bv=>distance_two_charge_from_no_bridge S pa bv no)
    have n := far_port_nonport_degree_lower_of_missing_peer pa qa pq.symm npq sub
    have eq : I.filter (G.Adj p)=I := by
      apply eq_of_subset_of_card_le (filter_subset _ _)
      change G.degree p+1≤A.card+(I.filter (G.Adj p)).card at n
      omega
    have bp (z : V) (zb : z∈B) : z∈DistanceTwo G p := by
      have hi := (degree z q (fun h=>not_common far (h.symm ▸ (mem_filter.mp qa).2)
        (mem_filter.mp zb).2)).resolve_right qh
      have invis : z∉visibleBPorts S.L a b G := by
        intro h
        obtain ⟨zl,bz,w,wl,aw,wz⟩ := mem_filter.mp h
        exact no ⟨w,wl,z,zl,aw,wz,bz⟩
      have n' := far_port_nonport_degree_lower zb (far_dark_b_port_candidates S far zb invis)
      change G.degree z≤B.card+(I.filter (G.Adj z)).card at n'
      change B.card≤4 at b4
      obtain ⟨r,rm⟩ := card_pos.mp (show 0<(I.filter (G.Adj z)).card by omega)
      obtain ⟨ri,zr⟩ := mem_filter.mp rm
      have pz : p≠z := fun e=>not_common far (e ▸ (mem_filter.mp pa).2) (mem_filter.mp zb).2
      have pr : G.Adj p r := (mem_filter.mp (eq.symm ▸ ri)).2
      exact d2 hc pz (distance_two_charge_from_no_bridge S pa zb no) pr zr.symm
    have q2 := d2 hc pq npq (mem_filter.mp pa).2.symm (mem_filter.mp qa).2
    have qNo : q∉B := fun h=>not_common far (mem_filter.mp qa).2 (mem_filter.mp h).2
    have pool : insert q B⊆insert b S.L := insert_subset_iff.mpr
      ⟨mem_insert_of_mem (mem_filter.mp qa).1, fun _ m=>mem_insert_of_mem (bSub m)⟩
    have slots := local_distance_two_at_foreign_two S hc even foreign (mem_filter.mp pa).1
      (mem_filter.mp pa).2 pool (insert_subset_iff.mpr ⟨q2,bp⟩)
    rw [card_insert_of_not_mem qNo] at slots
    change 3≤B.card at b3
    omega
  intro p pa q qa pq npq
  rcases degree p q pq with ph|qh
  · exact ⟨ph,Classical.byContradiction (cap pa qa pq npq ph)⟩
  refine ⟨?_,qh⟩
  exact Classical.byContradiction (cap qa pa pq.symm (fun e=>npq e.symm) qh)

#print axioms four_a_two_inner_ore_pairs
end Graffiti189LongestPath.CrossSaturation.Split.Five
