import DegreeFivePortSixBlocks189
import DegreeFiveBothBridgeEight189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset ArticulationPair
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

/-- With an 8-vertex shore's two nonports completed to universal neighbors,
the six ports admit a spanning opposite-color terminal route. -/
theorem three_three_completed_route (A B I : Finset V)
    (a3 : A.card=3) (b3 : B.card=3) (i2 : I.card=2)
    (ab : Disjoint A B) (ai : Disjoint A I) (bi : Disjoint B I)
    (mn : ∀ x∈A∪B,2≤((A∪B).filter (G.Adj x)).card) :
    ∃ x∈A,∃ y∈B,RouteOn (attachComplete G I) ((A∪B)∪I) x y := by
  classical
  let P := A∪B
  let H := attachComplete G I
  have pi : Disjoint P I := disjoint_union_left.mpr ⟨ai,bi⟩
  have p6 : P.card=6 := by rw [show P=A∪B from rfl,card_union_of_disjoint ab,a3,b3]
  obtain ⟨i,j,ij,ie⟩ := card_eq_two.mp i2
  have ii : i∈I := by simp [ie]
  have ji : j∈I := by simp [ie]
  have neq {u v : V} (up : u∈P) (vi : v∈I) : u≠v := fun h=>disjoint_left.mp pi up (h.symm ▸ vi)
  have piAdj {u v : V} (up : u∈P) (vi : v∈I) : H.Adj u v := .inr ⟨neq up vi,.inr vi⟩
  have ijAdj : H.Adj i j := .inr ⟨ij,.inl ii⟩
  have finish {u v : V} (h : (u∈A ∧ v∈B) ∨ (v∈A ∧ u∈B))
      (p : RouteOn H (P∪I) u v) : ∃ x∈A,∃ y∈B,RouteOn H (P∪I) x y := by
    rcases h with h|h
    · exact ⟨u,h.1,v,h.2,p⟩
    exact ⟨v,h.1,u,h.2,p.reverse⟩
  have color (x : V) (xp : x∈P) : x∈A ∨ x∈B := mem_union.mp xp
  have cross (x y : V) (xp : x∈P) (yp : y∈P) :
      (x∈A ∧ y∈B) ∨ (y∈A ∧ x∈B) ∨ (x∈A ∧ y∈A) ∨ (x∈B ∧ y∈B) := by
    rcases color x xp with xa|xb <;> rcases color y yp with ya|yb
    · exact .inr (.inr (.inl ⟨xa,ya⟩))
    · exact .inl ⟨xa,yb⟩
    · exact .inr (.inl ⟨ya,xb⟩)
    · exact .inr (.inr (.inr ⟨xb,yb⟩))
  rcases six_port_blocks (G:=G) P p6 mn with four|tri
  · obtain ⟨x,y,z,t,xp,yp,zp,tp,xyn,xzn,xtn,yzn,ytn,ztn,xy,yz,zt⟩ := four
    let C : Finset V := {x,y,z,t}
    let D := P\C
    have sub : C⊆P := by
      intro q h
      have e : q=x ∨ q=y ∨ q=z ∨ q=t := by simpa [C] using h
      rcases e with e|e|e|e <;> rwa [e]
    have ct : C.card=4 := by
      simp [C,xyn,xzn,xtn,yzn,ytn,ztn]
    have dd : D.card=2 := by
      change (P\C).card=2
      rw [card_sdiff sub,p6,ct]
    obtain ⟨u,v,uv,de⟩ := card_eq_two.mp dd
    have ud : u∈D := by simp [de]
    have vd : v∈D := by simp [de]
    obtain ⟨up,un⟩ := mem_sdiff.mp ud
    obtain ⟨vp,vn⟩ := mem_sdiff.mp vd
    have eP : C∪({u,v}:Finset V)=P := de ▸ union_sdiff_of_subset sub
    have road : RouteOn H C x t := by
      exact (RouteOn.three (show H.Adj y z from Or.inl yz) (show H.Adj z t from Or.inl zt) ytn).prefix (show H.Adj x y from Or.inl xy)
        (by simp [xyn,xzn,xtn])
    have splice {r s : V} (rr : RouteOn H C r s) (rp : r∈P) (sp : s∈P)
        (choose : (u∈A ∧ s∈B) ∨ (s∈A ∧ u∈B)) :
        ∃ x∈A,∃ y∈B,RouteOn H (P∪I) x y := by
      -- u—i—v—j—[r ... s]
      have hj := rr.prefix (piAdj rp ji).symm (fun jC=>disjoint_left.mp pi (sub jC) ji)
      have hv := hj.prefix (piAdj vp ji) (by simpa [neq vp ji] using vn)
      have ii' : i∉insert v (insert j C) := by
        simp [ij,(neq vp ii).symm,show i∉C from fun h=>disjoint_left.mp pi (sub h) ii]
      have hi := hv.prefix (piAdj vp ii).symm ii'
      have hu := hi.prefix (piAdj up ii) (by simpa [uv,neq up ii,neq up ji] using un)
      have set : insert u (insert i (insert v (insert j C)))=P∪I := by
        rw [←eP,ie]
        ext w
        simp [or_comm,or_left_comm,or_assoc]
      have rr' : RouteOn H (P∪I) u s := by rw [←set]; exact hu
      exact finish choose rr'
    rcases cross u v up vp with h|h|h|h
    · -- The two singleton ports have opposite colors.
      have hi := road.prefix (piAdj xp ii).symm (fun h=>disjoint_left.mp pi (sub h) ii)
      have hu := hi.prefix (piAdj up ii) (by simpa [neq up ii] using un)
      have hj := hu.suffix (piAdj tp ji) (by
        simp [(neq up ji).symm,ij.symm,show j∉C from fun h=>disjoint_left.mp pi (sub h) ji])
      have hv := hj.suffix (piAdj vp ji).symm (by simpa [uv.symm,neq vp ii,neq vp ji] using vn)
      have set : insert v (insert j (insert u (insert i C)))=P∪I := by
        rw [←eP,ie]
        ext w
        simp [or_comm,or_left_comm,or_assoc]
      have rr' : RouteOn H (P∪I) u v := by rw [←set]; exact hv
      exact finish (.inl h) rr'
    · -- Same route with reversed terminal colors.
      have hi := road.prefix (piAdj xp ii).symm (fun h=>disjoint_left.mp pi (sub h) ii)
      have hu := hi.prefix (piAdj up ii) (by simpa [neq up ii] using un)
      have hj := hu.suffix (piAdj tp ji) (by
        simp [(neq up ji).symm,ij.symm,show j∉C from fun h=>disjoint_left.mp pi (sub h) ji])
      have hv := hj.suffix (piAdj vp ji).symm (by simpa [uv.symm,neq vp ii,neq vp ji] using vn)
      have set : insert v (insert j (insert u (insert i C)))=P∪I := by
        rw [←eP,ie]
        ext w
        simp [or_comm,or_left_comm,or_assoc]
      have rr' : RouteOn H (P∪I) u v := by rw [←set]; exact hv
      exact finish (.inr h) rr'
    · by_cases tb : t∈B
      · exact splice road xp tp (.inl ⟨h.1,tb⟩)
      by_cases xb : x∈B
      · exact splice road.reverse tp xp (.inl ⟨h.1,xb⟩)
      have xa := (color x xp).resolve_right xb
      have ta := (color t tp).resolve_right tb
      have xu : x≠u := fun e=>un (by simp [C,←e])
      have xv : x≠v := fun e=>vn (by simp [C,←e])
      have tu : t≠u := fun e=>un (by simp [C,←e])
      have tv : t≠v := fun e=>vn (by simp [C,←e])
      have sub' : ({x,t,u,v}:Finset V)⊆A := by
        intro r h'
        have e : r=x ∨ r=t ∨ r=u ∨ r=v := by simpa using h'
        rcases e with e|e|e|e
        · exact e.symm ▸ xa
        · exact e.symm ▸ ta
        · exact e.symm ▸ h.1
        exact e.symm ▸ h.2
      have hh := card_le_card sub'
      simp [xtn,xu,xv,tu,tv,uv,a3] at hh
    · by_cases ta : t∈A
      · exact splice road xp tp (.inr ⟨ta,h.1⟩)
      by_cases xa : x∈A
      · exact splice road.reverse tp xp (.inr ⟨xa,h.1⟩)
      have xb := (color x xp).resolve_left xa
      have tb := (color t tp).resolve_left ta
      have xu : x≠u := fun e=>un (by simp [C,←e])
      have xv : x≠v := fun e=>vn (by simp [C,←e])
      have tu : t≠u := fun e=>un (by simp [C,←e])
      have tv : t≠v := fun e=>vn (by simp [C,←e])
      have sub' : ({x,t,u,v}:Finset V)⊆B := by
        intro r h'
        have e : r=x ∨ r=t ∨ r=u ∨ r=v := by simpa using h'
        rcases e with e|e|e|e
        · exact e.symm ▸ xb
        · exact e.symm ▸ tb
        · exact e.symm ▸ h.1
        exact e.symm ▸ h.2
      have hh := card_le_card sub'
      simp [xtn,xu,xv,tu,tv,uv,b3] at hh
  · obtain ⟨C,D,c3,d3,cd,eP,clC,clD⟩ := tri
    have cP : C⊆P := fun x hx=>eP ▸ mem_union_left D hx
    have dP : D⊆P := fun x hx=>eP ▸ mem_union_right C hx
    obtain ⟨u,uc⟩ := card_pos.mp (show 0<C.card by omega)
    obtain ⟨v,vd⟩ := card_pos.mp (show 0<D.card by omega)
    have ends : ∃ r∈C,∃ s∈D,(r∈A ∧ s∈B) ∨ (s∈A ∧ r∈B) := by
      apply Classical.byContradiction
      intro no
      rcases color u (cP uc) with ua|ub
      · have da (x : V) (xd : x∈D) : x∈A :=
          (color x (dP xd)).resolve_right (fun xb=>no ⟨u,uc,x,xd,.inl ⟨ua,xb⟩⟩)
        have ca (x : V) (xc : x∈C) : x∈A :=
          (color x (cP xc)).resolve_right (fun xb=>no ⟨x,xc,v,vd,.inr ⟨da v vd,xb⟩⟩)
        have hh := card_le_card (show P⊆A from eP ▸ union_subset ca da)
        omega
      · have db (x : V) (xd : x∈D) : x∈B :=
          (color x (dP xd)).resolve_left (fun xa=>no ⟨u,uc,x,xd,.inr ⟨xa,ub⟩⟩)
        have cb (x : V) (xc : x∈C) : x∈B :=
          (color x (cP xc)).resolve_left (fun xa=>no ⟨x,xc,v,vd,.inl ⟨xa,db v vd⟩⟩)
        have hh := card_le_card (show P⊆B from eP ▸ union_subset cb db)
        omega
    obtain ⟨r,rc,s,sd,choose⟩ := ends
    obtain ⟨z,p,pp,ps⟩ := rooted_path_in_clique C
      (G:=H) (fun x xc y yc ne=>.inl (clC x xc y yc ne)) rc
    obtain ⟨t,q,qp,qs⟩ := rooted_path_in_clique D
      (G:=H) (fun x xd y yd ne=>.inl (clD x xd y yd ne)) sd
    have zP := cP ((ps z).mp p.end_mem_support)
    have tP := dP ((qs t).mp q.end_mem_support)
    have cI := pi.mono cP (Subset.refl _)
    have dI := pi.mono dP (Subset.refl _)
    have pr : RouteOn H C r z := ⟨p,pp,ps⟩
    have qr : RouteOn H D s t := ⟨q,qp,qs⟩
    have mid : RouteOn H I i j := by rw [ie]; exact RouteOn.edge ijAdj
    have finale := (pr.join mid cI (piAdj zP ii)).join qr.reverse
      (disjoint_union_left.mpr ⟨cd,dI.symm⟩) (piAdj tP ji).symm
    have finale' : RouteOn H (P∪I) r s := by
      rw [←eP,union_right_comm]
      exact finale
    exact finish choose finale'

#print axioms three_three_completed_route
end Graffiti189LongestPath.CrossSaturation.Split.Five
