import DegreeFiveSixSingletonClique189
import DegreeFiveFarSlotDegrees189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph Finset
open private left_boundary from AdjacentCut189
open private d2 from CrossSaturation189
open private not_common from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

/-- Four high ports with exactly one local distance-two slot form a clique
with a single shared gateway in their original shore. -/
theorem four_high_single_gateway (hc : G.Connected) (far : 3≤G.dist a b)
    (four : S.localA.card=4) (shell : (secondA G S.L a).card=1)
    (high : ∀ z∈S.localA,5≤G.degree z) :
    ∃ z∈S.L, ¬G.Adj a z ∧
      (∀ q∈S.localA,G.Adj q z) ∧
      (∀ q∈S.localA,∀ r∈S.localA,q≠r → G.Adj q r) ∧
      (∀ q∈S.localA,∀ v∈S.L,¬G.Adj a v → G.Adj q v → v=z) := by
  classical
  obtain ⟨z,ze⟩ := card_eq_one.mp shell
  have zm : z∈secondA G S.L a := ze.symm ▸ mem_singleton_self z
  obtain ⟨zl,z2⟩ := mem_inter.mp zm
  have az2 : G.dist a z=2 := by simpa [DistanceTwo] using z2
  have az : ¬G.Adj a z := by
    intro e
    have n := dist_eq_one_iff_adj.mpr e
    omega
  have only {q v : V} (qq : q∈S.localA) (vl : v∈S.L) (av : ¬G.Adj a v) (qv : G.Adj q v) : v=z := by
    have ne : a≠v := fun e=>S.leftOff.1 (e.symm ▸ vl)
    have m : v∈secondA G S.L a :=
      mem_inter.mpr ⟨vl,d2 hc ne av (mem_filter.mp qq).2 qv⟩
    exact mem_singleton.mp (ze ▸ m)
  have tight {q : V} (qq : q∈S.localA) :
      (∀ r∈S.localA,q≠r → G.Adj q r) ∧ ∀ v∈({z} : Finset V),G.Adj q v := by
    apply far_port_full_at_tight_pool (d := a) qq ?_ (show S.localA.card+({z} : Finset V).card=5 by simp [four]) (high q qq)
    intro v hv
    have qv := (mem_neighborFinset G q v).mp hv
    have ⟨ql,aq⟩ := mem_filter.mp qq
    rcases left_boundary S q ql v qv with rfl|rfl|vl
    · exact mem_insert_self _ _
    · exact (not_common far aq qv.symm).elim
    by_cases av : G.Adj a v
    · exact mem_insert_of_mem (mem_union_left _ (mem_erase.mpr ⟨qv.ne.symm,mem_filter.mpr ⟨vl,av⟩⟩))
    exact mem_insert_of_mem (mem_union_right _ (mem_singleton.mpr (only qq vl av qv)))
  exact ⟨z,zl,az,fun q qq=>(tight qq).2 z (mem_singleton_self z),
    fun _ qq r rr ne=>(tight qq).1 r rr ne,fun _ qq _ vl av qv=>only qq vl av qv⟩

#print axioms four_high_single_gateway
end Graffiti189LongestPath.CrossSaturation.Split.Five
