import DegreeFiveSixFourOutside189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph Finset
open private left_boundary from AdjacentCut189
open private d2 from CrossSaturation189
open private not_common secondA_right_and_left_le_five from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem six_singleton_opposite_four_forces_bridge (hc : G.Connected)
    (far : 3≤G.dist a b) (even : ∀ z,(EvenFrom G z).card≤6)
    (right4 : (S.R.filter (G.Adj b)).card=4)
    (a3 : S.foreignA.card=3) {y : V} (yl : y∈S.L) (by' : G.Adj b y)
    (high : 5≤G.degree y) (only : ∀ z∈S.L,G.Adj b z → z=y) :
    portBridge S.flip := by
  classical
  let N := S.L.filter (G.Adj y)
  have far' : 3≤G.dist b a := by rwa [dist_comm]
  have no : ¬G.Adj a y := fun ay=>not_common far ay by'
  have sub : G.neighborFinset y⊆insert b N := by
    intro z hz
    have e := (mem_neighborFinset G y z).mp hz
    rcases left_boundary S y yl z e with rfl|rfl|zl
    · exact (no e.symm).elim
    · exact mem_insert_self _ _
    exact mem_insert_of_mem (mem_filter.mpr ⟨zl,e⟩)
  have n := (card_le_card sub).trans (card_insert_le b N)
  rw [card_neighborFinset_eq_degree] at n
  have localN : N⊆secondA G S.L b := by
    intro z hz
    obtain ⟨zl,yz⟩ := mem_filter.mp hz
    have ne : b≠z := fun h=>S.leftOff.2 (h.symm ▸ zl)
    have bz : ¬G.Adj b z := fun e=>yz.ne (only z zl e).symm
    exact mem_inter.mpr ⟨zl,d2 hc ne bz by' yz⟩
  by_contra nb
  have cov := no_bridge_four_foreign_cover S.flip hc far' even right4 nb
  have opp : S.foreignA⊆secondA G S.R b := by
    intro z hz
    obtain ⟨zr,az⟩ := mem_filter.mp hz
    have h := cov zr
    exact (mem_union.mp h).resolve_left (fun e=>not_common far az (mem_filter.mp e).2)
  have v := card_le_card localN
  have w := card_le_card opp
  have budget := secondA_right_and_left_le_five S.flip even
  change (secondA G S.L b).card+(secondA G S.R b).card≤5 at budget
  omega

#print axioms six_singleton_opposite_four_forces_bridge
end Graffiti189LongestPath.CrossSaturation.Split.Five
