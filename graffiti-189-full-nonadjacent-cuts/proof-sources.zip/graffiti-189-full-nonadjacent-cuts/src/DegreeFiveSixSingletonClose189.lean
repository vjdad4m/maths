import DegreeFiveSixSingletonFree189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private not_common from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem traceable_singleton_four_at_three_three (hc : G.Connected)
    (far : 3≤G.dist a b) (even : ∀ z,(EvenFrom G z).card≤6)
    (conn : ∀ R : Finset V,R.card<2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (l3 : S.localA.card=3) (r3 : S.foreignA.card=3)
    (b4 : (S.R.filter (G.Adj b)).card=4)
    (rc : (G.induce (↑S.R : Set V)).Connected)
    (ra : ∃ x∈S.R,G.Adj a x) (rb : ∃ x∈S.R,G.Adj b x)
    {y : V} (yl : y∈S.L) (by' : G.Adj b y)
    (high : 5≤G.degree y) (only : ∀ z∈S.L,G.Adj b z → z=y) :
    ∃ x t,∃ p : G.Walk x t,p.IsPath ∧ ∀ z,z∈p.support := by
  classical
  obtain ⟨n,clique,hi,shell⟩ :=
    singleton_four_five_clique S hc far even degree b4 l3 r3 rc ra rb yl by' high only
  have free := singleton_four_opposite_free S hc far even conn l3 r3 b4 n clique hi rc ra rb yl by' shell
  obtain ⟨x,xp⟩ := card_pos.mp (show 0<S.localA.card by omega)
  obtain ⟨xl,ax⟩ := mem_filter.mp xp
  have xy : x≠y := fun e=>not_common far (e ▸ ax) by'
  obtain ⟨p,hp,ps⟩ := path_between_in_clique S.L clique xl yl xy
  exact traceable_from_far_terminal_and_free S far ⟨x,y,ax,by',p,hp,ps⟩ (.inl free)

#print axioms traceable_singleton_four_at_three_three
end Graffiti189LongestPath.CrossSaturation.Split.Five
