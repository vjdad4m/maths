import DegreeFiveSixGatewayInvisible189
import SmallDenseRoute189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private d2 from CrossSaturation189
open private left_boundary from AdjacentCut189
open private not_common secondA_right_and_left_le_five from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem singleton_four_opposite_free (hc : G.Connected)
    (far : 3≤G.dist a b) (even : ∀ v,(EvenFrom G v).card≤6)
    (conn : ∀ R : Finset V,R.card<2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (l3 : S.localA.card=3) (r3 : S.foreignA.card=3)
    (b4 : (S.R.filter (G.Adj b)).card=4)
    (left5 : S.L.card=5) (clique : ∀ u∈S.L,∀ v∈S.L,u≠v → G.Adj u v)
    (high : ∀ v∈S.R,5≤G.degree v)
    (rc : (G.induce (↑S.R : Set V)).Connected)
    (ra : ∃ x∈S.R,G.Adj a x) (rb : ∃ x∈S.R,G.Adj b x)
    {y : V} (yl : y∈S.L) (by' : G.Adj b y)
    (shell : (secondA G S.R b).card=1) :
    ∃ u v,G.Adj a u ∧ RouteOn G S.R u v := by
  classical
  let T := switch S rc ra rb
  let B := S.R.filter (G.Adj b)
  have far' : 3≤G.dist b a := by rwa [dist_comm]
  obtain ⟨z,zr,bz,join,bc,only⟩ :=
    four_high_single_gateway T.flip hc far' b4 shell (fun q qq=>high q (mem_filter.mp qq).1)
  change z∈S.R at zr
  obtain ⟨az,notSeen,lc⟩ :=
    singleton_four_opposite_gateway_invisible S hc far even b4 l3 left5 clique rc ra rb zr join only
  obtain ⟨x,xm⟩ := card_pos.mp (show 0<S.localA.card by omega)
  obtain ⟨xl,ax⟩ := mem_filter.mp xm
  have xy : G.Adj x y := clique x xl y yl (fun h=>not_common far (h ▸ ax) by')
  have invis := bridge_three_foreign_invisible_cap S hc even conn r3 xl ax xy by' (not_common far ax)
  let J := (farNonports S.R a b G)\secondA G S.R a
  have zj : z∈J := mem_sdiff.mpr ⟨mem_filter.mpr ⟨zr,az,bz⟩,notSeen⟩
  have jEq : J={z} := (eq_of_subset_of_card_le (singleton_subset_iff.mpr zj) (by
    rw [card_singleton]
    exact invis)).symm
  let F := insert z B
  let U := S.R\F
  have zF : z∈F := mem_insert_self _ _
  have fSub : F⊆S.R := insert_subset zr (filter_subset _ _)
  have aSub : S.foreignA⊆U := by
    intro w hw
    obtain ⟨wr,aw⟩ := mem_filter.mp hw
    exact mem_sdiff.mpr ⟨wr,fun ff=>(mem_insert.mp ff).elim
      (fun e=>az (e ▸ aw)) (fun h=>not_common far aw (mem_filter.mp h).2)⟩
  have uSub : U⊆S.foreignA ∪ secondA G S.R a := by
    intro w hw
    obtain ⟨wr,nf⟩ := mem_sdiff.mp hw
    by_cases aw : G.Adj a w
    · exact mem_union_left _ (mem_filter.mpr ⟨wr,aw⟩)
    have bw : ¬G.Adj b w := fun h=>nf (mem_insert_of_mem (mem_filter.mpr ⟨wr,h⟩))
    have hw' : w∈secondA G S.R a := by
      apply Classical.byContradiction
      intro absent
      have wj : w∈J := mem_sdiff.mpr ⟨mem_filter.mpr ⟨wr,aw,bw⟩,absent⟩
      exact nf (mem_insert.mpr (.inl (mem_singleton.mp (jEq ▸ wj))))
    exact mem_union_right _ hw'
  have sem := secondA_right_and_left_le_five S even
  have us := (card_le_card uSub).trans (card_union_le _ _)
  have maxU : U.card≤6 := by omega
  have dense : ∀ w∈U,U.card+1≤2*(U.filter (G.Adj w)).card := by
    intro w wu
    obtain ⟨wr,wn⟩ := mem_sdiff.mp wu
    have wb : ¬G.Adj b w := fun h=>wn (mem_insert_of_mem (mem_filter.mpr ⟨wr,h⟩))
    have wz : w≠z := fun h=>wn (mem_insert.mpr (.inl h))
    have sub : G.neighborFinset w⊆insert a (insert z (U.filter (G.Adj w))) := by
      intro t ht
      have wt := (mem_neighborFinset G w t).mp ht
      rcases left_boundary T w wr t wt with rfl|rfl|tr
      · exact mem_insert_self _ _
      · exact (wb wt.symm).elim
      by_cases tt : t∈F
      · rcases mem_insert.mp tt with rfl|tb
        · exact mem_insert_of_mem (mem_insert_self _ _)
        exact (wz (only t tb w wr wb wt.symm)).elim
      exact mem_insert_of_mem (mem_insert_of_mem (mem_filter.mpr ⟨mem_sdiff.mpr ⟨tr,tt⟩,wt⟩))
    by_cases aw : G.Adj a w
    · have nzw : ¬G.Adj w z := by
        intro wz'
        have ne : a≠z := fun e=>S.rightOff.1 (e.symm ▸ zr)
        have dz := d2 hc ne az aw wz'
        exact notSeen (mem_inter.mpr ⟨zr,dz⟩)
      have small : G.neighborFinset w⊆insert a (U.filter (G.Adj w)) := by
        intro t ht
        rcases mem_insert.mp (sub ht) with e|rest
        · exact mem_insert.mpr (.inl e)
        rcases mem_insert.mp rest with e|rest
        · exact (nzw (e ▸ (mem_neighborFinset G w t).mp ht)).elim
        exact mem_insert_of_mem rest
      have m := (card_le_card small).trans (card_insert_le a _)
      rw [card_neighborFinset_eq_degree] at m
      have h := high w wr
      omega
    have small : G.neighborFinset w⊆insert z (U.filter (G.Adj w)) := by
      intro t ht
      rcases mem_insert.mp (sub ht) with e|rest
      · exact (aw (e ▸ ((mem_neighborFinset G w t).mp ht).symm)).elim
      exact rest
    have m := (card_le_card small).trans (card_insert_le z _)
    rw [card_neighborFinset_eq_degree] at m
    have h := high w wr
    omega
  have next : ∃ r∈U,G.Adj z r := by
    apply Classical.byContradiction
    intro nope
    have stay : ∀ {u v : ↑(↑S.R : Set V)}, (G.induce (↑S.R : Set V)).Adj u v →
        u.val∈F → v.val∈F := by
      intro u v uv uf
      apply Classical.byContradiction
      intro vf
      have vU : v.val∈U := mem_sdiff.mpr ⟨v.property,vf⟩
      rcases mem_insert.mp uf with e|ub
      · exact nope ⟨v.val,vU,e ▸ uv⟩
      have vb : ¬G.Adj b v.val := fun e=>vf (mem_insert_of_mem (mem_filter.mpr ⟨v.property,e⟩))
      exact vf (mem_insert.mpr (.inl (only u.val ub v.val v.property vb uv)))
    obtain ⟨q,qr,aq⟩ := ra
    have qu := aSub (mem_filter.mpr ⟨qr,aq⟩)
    obtain ⟨p⟩ := rc.preconnected ⟨z,zr⟩ ⟨q,qr⟩
    have walk : ∀ {u v : ↑(↑S.R : Set V)}, (G.induce (↑S.R : Set V)).Walk u v →
        u.val∈F → v.val∈F := by
      intro u v p
      induction p with
      | nil => exact id
      | cons e w ih => exact fun h=>ih (stay e h)
    exact (mem_sdiff.mp qu).2 (walk p zF)
  obtain ⟨r,ru,zr'⟩ := next
  obtain ⟨u,ua,v,va,uv⟩ := one_lt_card.mp (show 1<S.foreignA.card by omega)
  have root : ∃ q∈S.foreignA,q≠r := by
    by_cases ur : u=r
    · exact ⟨v,va,fun e=>uv (ur.trans e.symm)⟩
    exact ⟨u,ua,ur⟩
  obtain ⟨q,qa,qr⟩ := root
  have p := terminal_route_of_dense_finset U (aSub qa) ru qr dense
  have bPos : 1<B.card := by change 1<(S.R.filter (G.Adj b)).card; omega
  obtain ⟨i,ib,j,jb,ij⟩ := one_lt_card.mp bPos
  obtain ⟨path,pp,ps⟩ := path_between_in_clique B bc ib jb ij
  have hB : RouteOn G B i j := ⟨path,pp,ps⟩
  have notB : z∉B := fun h=>bz (mem_filter.mp h).2
  have tail : RouteOn G F z j := hB.prefix (join i ib).symm notB
  have dis : Disjoint U F := disjoint_left.mpr (fun _ hu hf=>(mem_sdiff.mp hu).2 hf)
  have eq : U∪F=S.R := sdiff_union_of_subset fSub
  exact ⟨q,j,(mem_filter.mp qa).2,eq ▸ p.join tail dis zr'.symm⟩

#print axioms singleton_four_opposite_free
end Graffiti189LongestPath.CrossSaturation.Split.Five
