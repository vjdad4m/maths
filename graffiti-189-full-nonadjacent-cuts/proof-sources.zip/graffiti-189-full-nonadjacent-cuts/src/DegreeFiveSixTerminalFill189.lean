import DegreeFiveSixNoBridgeOneInner189
import SmallDenseRoute189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset ArticulationPair
open private lift_side_path from DegreeFiveSmallSides189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

private theorem restrict_walk_support {K : SimpleGraph V} {U : Finset V}
    {x y : V} (p : K.Walk x y) (xs : x∈U) (ys : y∈U)
    (inside : ∀ v∈p.support,v∈U) :
    ∃ q : (K.induce (↑U : Set V)).Walk ⟨x,xs⟩ ⟨y,ys⟩,
      q.support.map Subtype.val=p.support := by
  induction p with
  | nil => exact ⟨.nil,rfl⟩
  | @cons u v w e p ih =>
    have vs : v∈U := inside v (by simp [support_cons,p.start_mem_support])
    obtain ⟨q,hq⟩ := ih vs ys (fun z hz=>inside z (by simp [support_cons,hz]))
    let f : (K.induce (↑U : Set V)).Adj ⟨u,xs⟩ ⟨v,vs⟩ := e
    exact ⟨.cons f q,by simp [support_cons,hq]⟩

/-- Fill the chosen core to a clique in a shore only, preserving both
specified terminals and transferring all auxiliary edges back. -/
theorem terminal_clique_fill_on_finset
    (U A : Finset V) {x y : V} (xs : x∈U) (ys : y∈U)
    (dense : ∀ u∈A,∀ v∈A,u≠v → ¬G.Adj u v →
      U.card+1≤(U.filter (G.Adj u)).card+(U.filter (G.Adj v)).card)
    (path : RouteOn (completeWith G A) U x y) : RouteOn G U x y := by
  classical
  let T := ↑(↑U : Set V)
  let J := G.induce (↑U : Set V)
  let H := (completeWith G A).induce (↑U : Set V)
  letI : DecidableRel H.Adj := Classical.decRel _
  obtain ⟨p,pp,ps⟩ := path
  obtain ⟨q,hq⟩ := restrict_walk_support p xs ys (fun v h=>(ps v).mp h)
  have qp : q.IsPath := IsPath.mk' (List.Nodup.of_map _ (hq.symm ▸ pp.support_nodup))
  have qa : ∀ v : T,v∈q.support := by
    intro v
    have h : v.val∈p.support := (ps _).mpr v.property
    obtain ⟨w,wm,eq⟩ := List.mem_map.mp (hq.symm ▸ h)
    exact (Subtype.ext eq : w=v) ▸ wm
  have sub : J≤H := fun _ _ e=>completeWith_mono G A e
  have bound (u v : T) (uv : H.Adj u v) (nuv : ¬J.Adj u v) :
      Fintype.card T+1≤J.degree u+J.degree v := by
    have hv : (completeWith G A).Adj u.val v.val := uv
    have hn : ¬G.Adj u.val v.val := nuv
    have he := (show G.Adj u.val v.val ∨
      (u.val∈A ∧ v.val∈A ∧ u.val≠v.val) from hv).resolve_left hn
    have m := dense u.val he.1 v.val he.2.1 he.2.2 hn
    change U.card+1≤(inside G U u.val).card+(inside G U v.val).card at m
    rw [inside_card_eq_degree_induce (G:=G) U u,inside_card_eq_degree_induce (G:=G) U v] at m
    have hT : Fintype.card T = U.card := Fintype.card_coe U
    rw [hT]
    exact m
  obtain ⟨r,rp,rs⟩ := terminal_ore_closure sub bound q qp qa
  exact lift_side_path U r rp rs

#print axioms terminal_clique_fill_on_finset
end Graffiti189LongestPath.CrossSaturation.Split.Five
