import DegreeFiveSixThreeInnerThreeBHidden189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private not_common from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem three_inner_nonbridge_three_b (hc : G.Connected)
    (far : 3≤G.dist a b) (even : ∀ v,(EvenFrom G v).card≤6)
    (conn : ∀ R : Finset V,R.card<2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (l3 : S.localA.card=3) (r3 : S.foreignA.card=3)
    (b3 : (S.R.filter (G.Adj b)).card=3) (i3 : (farNonports S.R a b G).card=3)
    (br : portBridge S)
    (rc : (G.induce (↑S.R : Set V)).Connected)
    (ra : ∃ x∈S.R,G.Adj a x) (rb : ∃ x∈S.R,G.Adj b x)
    (nb : ¬portBridge (switch S rc ra rb)) :
    ∃ x y,∃ p : G.Walk x y,p.IsPath ∧ ∀ v,v∈p.support := by
  classical
  let T := switch S rc ra rb
  let I := farNonports S.R a b G
  let Q := secondA G S.R a
  by_cases vis : I⊆Q
  · obtain ⟨n,cap⟩ := three_inner_three_b_visible_left_five S hc far even conn degree
      l3 b3 i3 rc ra rb nb vis
    obtain ⟨free,z,zr,low⟩ := three_inner_three_b_visible_opposite_free T hc far even degree
      r3 l3 b3 i3 nb vis cap
    have high : ∀ v∈S.L,5≤G.degree v := fun v vl=>
      (degree v z (fun e=>disjoint_left.mp S.dis vl (e.symm ▸ zr))).resolve_right low
    exact traceable_from_far_terminal_and_free S far (all_high_small_terminal_wing S far (by omega) high)
      (.inl free)
  apply False.elim
  have hid : ∃ t∈I,t∉Q := by
    apply Classical.byContradiction
    intro nope
    exact vis (fun u ui=>Classical.byContradiction (fun n=>nope ⟨u,ui,n⟩))
  obtain ⟨t,ti,nt⟩ := hid
  obtain ⟨p,pl,q,ql,ap,pq,bq⟩ := br
  have cap := bridge_three_foreign_invisible_cap S hc even conn r3 pl ap pq bq (not_common far ap)
  change (I\Q).card≤1 at cap
  have rest : I.erase t⊆Q := by
    intro w wm
    apply Classical.byContradiction
    intro n
    obtain ⟨ne,wi⟩ := mem_erase.mp wm
    have h := one_lt_card.mpr ⟨w,mem_sdiff.mpr ⟨wi,n⟩,t,mem_sdiff.mpr ⟨ti,nt⟩,ne⟩
    omega
  exact no_bridge_three_inner_three_b_one_invisible_false T hc far even degree r3 l3 b3 i3 nb ti nt rest

#print axioms three_inner_nonbridge_three_b
end Graffiti189LongestPath.CrossSaturation.Split.Five
