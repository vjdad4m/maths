import DegreeFiveSixThreeInnerThreeBVisibleFree189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph Finset
open private d2 from CrossSaturation189
open private left_boundary from AdjacentCut189
open private not_common from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem no_bridge_three_inner_three_b_one_invisible_false (hc : G.Connected)
    (far : 3≤G.dist a b) (even : ∀ v,(EvenFrom G v).card≤6)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (a3 : S.localA.card=3) (foreign3 : S.foreignA.card=3)
    (b3 : (S.L.filter (G.Adj b)).card=3) (i3 : (farNonports S.L a b G).card=3)
    (nb : ¬portBridge S)
    {t : V} (ti : t∈farNonports S.L a b G)
    (hidden : t∉secondA G S.L a)
    (visible : (farNonports S.L a b G).erase t⊆secondA G S.L a) : False := by
  classical
  let A := S.localA
  let B := S.L.filter (G.Adj b)
  let I := farNonports S.L a b G
  let J := I.erase t
  let H := B.filter (fun p=>5≤G.degree p)
  let K := B.filter (fun p=>∃ r∈J,G.Adj p r)
  change A.card=3 at a3
  change B.card=3 at b3
  change I.card=3 at i3
  have j2 : J.card=2 := by
    change (I.erase t).card=2
    rw [card_erase_of_mem ti,i3]
  obtain ⟨tl,at',bt⟩ := mem_filter.mp ti
  have noAt (x : V) (xa : x∈A) : ¬G.Adj x t := by
    intro h
    have ne : a≠t := fun h=>S.leftOff.1 (h.symm ▸ tl)
    exact hidden (mem_inter.mpr ⟨tl,d2 hc ne at' (mem_filter.mp xa).2 h⟩)
  have tBound : G.neighborFinset t⊆B∪J := by
    intro v vv
    have tv := (mem_neighborFinset G t v).mp vv
    rcases left_boundary S t tl v tv with rfl|rfl|vl
    · exact (at' tv.symm).elim
    · exact (bt tv.symm).elim
    by_cases av : G.Adj a v
    · exact (noAt v (mem_filter.mpr ⟨vl,av⟩) tv.symm).elim
    by_cases bv : G.Adj b v
    · exact mem_union_left _ (mem_filter.mpr ⟨vl,bv⟩)
    exact mem_union_right _ (mem_erase.mpr ⟨tv.ne.symm,mem_filter.mpr ⟨vl,av,bv⟩⟩)
  have ah (x : V) (xa : x∈A) (h : 5≤G.degree x) : ∀ r∈J,G.Adj x r := by
    have raw := bounds_of_local_color_port S far xa
      (fun q qb=>distance_two_charge_from_no_bridge S xa qb nb)
    have sub : G.neighborFinset x⊆insert a ((A.erase x)∪J) := by
      intro r rr
      rcases mem_insert.mp (raw rr) with e|e
      · exact mem_insert.mpr (.inl e)
      exact mem_insert_of_mem ((mem_union.mp e).elim (mem_union_left _) (fun ri=>
        mem_union_right _ (mem_erase.mpr ⟨fun h=>noAt x xa (h ▸ (mem_neighborFinset G x r).mp rr),ri⟩)))
    exact (far_port_full_at_tight_pool xa sub (by omega) h).2
  have bh (p : V) (pb : p∈B) (h : 5≤G.degree p) : p∈K := by
    have n := high_nonbridge_three_b_contacts_two S far nb b3 pb h
    change 2≤(I.filter (G.Adj p)).card at n
    have hit : ∃ r∈J,G.Adj p r := by
      apply Classical.byContradiction
      intro none
      have sub : I.filter (G.Adj p)⊆{t} := by
        intro r rr
        obtain ⟨ri,pr⟩ := mem_filter.mp rr
        by_cases eq : r=t
        · exact mem_singleton.mpr eq
        exact (none ⟨r,mem_erase.mpr ⟨eq,ri⟩,pr⟩).elim
      have m := card_le_card sub
      rw [card_singleton] at m
      omega
    exact mem_filter.mpr ⟨pb,hit⟩
  have HK : H⊆K := fun p pp=>bh p (mem_filter.mp pp).1 (mem_filter.mp pp).2
  have count := count_high_subset_of_one_low degree B
  change B.card≤H.card+1 at count
  have kLow : 2≤K.card := (show 2≤H.card by omega).trans (card_le_card HK)
  have see (x : V) (xa : x∈A) (r : V) (xr : G.Adj x r) :
      B.filter (G.Adj r)⊆DistanceTwo G x := by
    intro p pp
    obtain ⟨pb,rp⟩ := mem_filter.mp pp
    have ne : x≠p := fun e=>not_common far (e ▸ (mem_filter.mp xa).2) (mem_filter.mp pb).2
    exact d2 hc ne (distance_two_charge_from_no_bridge S xa pb nb) xr rp
  have kSee (x : V) (xa : x∈A) (hi : 5≤G.degree x) : K⊆DistanceTwo G x := by
    intro p pp
    obtain ⟨pb,r,rj,pr⟩ := mem_filter.mp pp
    exact see x xa r (ah x xa hi r rj) (mem_filter.mpr ⟨pb,pr.symm⟩)
  by_cases thi : 5≤G.degree t
  · have tFull : G.neighborFinset t=B∪J :=
      eq_of_subset_of_card_le tBound (by
        rw [card_neighborFinset_eq_degree]
        exact (card_union_le B J).trans (by omega))
    have local' (r : V) (rj : r∈J) : (B.filter (G.Adj r)).card≤1 := by
      have rt := (mem_neighborFinset G t r).mp (tFull.symm ▸ mem_union_right _ rj)
      obtain ⟨x,xa,xr⟩ := nonport_a_neighbor S hc far (mem_filter.mp (mem_erase.mp rj).2).1
        (mem_inter.mp (visible rj)).2
      have XT : x≠t := fun e=>at' (e ▸ (mem_filter.mp xa).2)
      have t2 := d2 hc XT (noAt x xa) xr rt.symm
      have tn : t∉B.filter (G.Adj r) := fun h=>bt (mem_filter.mp (mem_filter.mp h).1).2
      have n := local_distance_two_at_foreign_three S hc even foreign3 (mem_filter.mp xa).1
        (mem_filter.mp xa).2 (insert_subset_iff.mpr
          ⟨mem_insert_of_mem tl,fun v hv=>mem_insert_of_mem (mem_filter.mp (mem_filter.mp hv).1).1⟩)
        (insert_subset_iff.mpr ⟨t2,see x xa r xr⟩)
      rw [card_insert_of_not_mem tn] at n
      omega
    obtain ⟨r,s,rs,pair⟩ := card_eq_two.mp j2
    have kCap : K.card≤2 := by
      have sub : K⊆B.filter (G.Adj r)∪B.filter (G.Adj s) := by
        intro p pp
        obtain ⟨pb,w,wj,pw⟩ := mem_filter.mp pp
        rw [pair,mem_insert,mem_singleton] at wj
        rcases wj with rfl|rfl
        · exact mem_union_left _ (mem_filter.mpr ⟨pb,pw.symm⟩)
        exact mem_union_right _ (mem_filter.mpr ⟨pb,pw.symm⟩)
      have m := (card_le_card sub).trans (card_union_le _ _)
      have n := local' r (by simp [pair])
      have p := local' s (by simp [pair])
      omega
    have kb : K⊆B := filter_subset _ _
    obtain ⟨ell,em⟩ := card_pos.mp (show 0<(B\K).card by rw [card_sdiff kb]; omega)
    obtain ⟨ellB,ellK⟩ := mem_sdiff.mp em
    have ellLow : ¬5≤G.degree ell := fun h=>ellK (bh ell ellB h)
    obtain ⟨x,xa⟩ := card_pos.mp (show 0<A.card by omega)
    have xh := (degree x ell (fun e=>not_common far
      (e ▸ (mem_filter.mp xa).2) (mem_filter.mp ellB).2)).resolve_right ellLow
    have rj : r∈J := by simp [pair]
    have xr := ah x xa xh r rj
    have tr := (mem_neighborFinset G t r).mp (tFull.symm ▸ mem_union_right _ rj)
    have t2 := d2 hc (show x ≠ t from fun e=>at' (e ▸ (mem_filter.mp xa).2)) (noAt x xa) xr tr.symm
    have tn : t∉K := fun h=>bt (mem_filter.mp (mem_filter.mp h).1).2
    have n := local_distance_two_at_foreign_three S hc even foreign3 (mem_filter.mp xa).1
      (mem_filter.mp xa).2 (insert_subset_iff.mpr
        ⟨mem_insert_of_mem tl,fun v hv=>mem_insert_of_mem (mem_filter.mp (mem_filter.mp hv).1).1⟩)
      (insert_subset_iff.mpr ⟨t2,kSee x xa xh⟩)
    rw [card_insert_of_not_mem tn] at n
    omega
  obtain ⟨x,xa⟩ := card_pos.mp (show 0<A.card by omega)
  have xh := (degree x t (fun e=>at' (e ▸ (mem_filter.mp xa).2))).resolve_right thi
  have bAll : B⊆K := fun p pb=>bh p pb
    ((degree p t (fun e=>bt (e ▸ (mem_filter.mp pb).2))).resolve_right thi)
  have n : B.card ≤ 2 := local_distance_two_at_foreign_three S hc even foreign3 (mem_filter.mp xa).1
    (mem_filter.mp xa).2 (fun v hv=>mem_insert_of_mem (mem_filter.mp hv).1)
    (bAll.trans (kSee x xa xh))
  omega

#print axioms no_bridge_three_inner_three_b_one_invisible_false
end Graffiti189LongestPath.CrossSaturation.Split.Five
