import DegreeFiveSixOneBridgeTwoInnerMetric189
import DegreeFiveSixThreeInnerTwoB189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph Finset
open private d2 foreign_subset from CrossSaturation189
open private left_boundary from AdjacentCut189
open private not_common secondA_right_and_left_le_five from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem high_nonbridge_three_b_contacts_two
    (far : 3≤G.dist a b) (nb : ¬portBridge S)
    (b3 : (S.L.filter (G.Adj b)).card=3)
    {q : V} (qb : q∈S.L.filter (G.Adj b)) (hi : 5≤G.degree q) :
    2≤((farNonports S.L a b G).filter (G.Adj q)).card := by
  have dark : q∉visibleBPorts S.L a b G := by
    intro h
    obtain ⟨ql,bq,w,wl,aw,wq⟩ := mem_filter.mp h
    exact nb ⟨w,wl,q,ql,aw,wq,bq⟩
  have n := far_port_nonport_degree_lower qb (far_dark_b_port_candidates S far qb dark)
  omega

theorem three_inner_three_b_visible_left_five (hc : G.Connected)
    (far : 3≤G.dist a b) (even : ∀ v,(EvenFrom G v).card≤6)
    (conn : ∀ R : Finset V,R.card<2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (l3 : S.localA.card=3) (b3 : (S.R.filter (G.Adj b)).card=3)
    (i3 : (farNonports S.R a b G).card=3)
    (rc : (G.induce (↑S.R : Set V)).Connected)
    (ra : ∃ x∈S.R,G.Adj a x) (rb : ∃ x∈S.R,G.Adj b x)
    (nb : ¬portBridge (switch S rc ra rb))
    (vis : farNonports S.R a b G⊆secondA G S.R a) :
    S.L.card=5 ∧ (secondA G S.R b).card≤2 := by
  classical
  let T := switch S rc ra rb
  let I := farNonports S.R a b G
  let B := S.R.filter (G.Adj b)
  let H := B.filter (fun x=>5≤G.degree x)
  have cnt := count_high_subset_of_one_low degree B
  change B.card≤H.card+1 at cnt
  change B.card=3 at b3
  change I.card=3 at i3
  obtain ⟨p,pp,q,qq,pq⟩ := one_lt_card.mp (show 1<H.card by omega)
  obtain ⟨pb,ph⟩ := mem_filter.mp pp
  obtain ⟨qb,qh⟩ := mem_filter.mp qq
  have np := high_nonbridge_three_b_contacts_two T far nb b3 pb ph
  have nq := high_nonbridge_three_b_contacts_two T far nb b3 qb qh
  change 2≤(I.filter (G.Adj p)).card at np
  change 2≤(I.filter (G.Adj q)).card at nq
  have both : (I.filter (G.Adj p)∩I.filter (G.Adj q)).Nonempty := by
    apply card_pos.mp
    have sum := card_union_add_card_inter (I.filter (G.Adj p)) (I.filter (G.Adj q))
    have cap := card_le_card (union_subset (filter_subset (G.Adj p) I) (filter_subset (G.Adj q) I))
    omega
  obtain ⟨r,rr⟩ := both
  obtain ⟨pr,qr⟩ := mem_inter.mp rr
  obtain ⟨ri,pr'⟩ := mem_filter.mp pr
  have qr' := (mem_filter.mp qr).2
  obtain ⟨x,xa,xr⟩ := nonport_a_neighbor T hc far (mem_filter.mp ri).1 (mem_inter.mp (vis ri)).2
  have xp : x≠p := fun e=>not_common far (e ▸ (mem_filter.mp xa).2) (mem_filter.mp pb).2
  have xq : x≠q := fun e=>not_common far (e ▸ (mem_filter.mp xa).2) (mem_filter.mp qb).2
  have sat : 5≤(DistanceTwo G x).card := by
    have sub : ({p,q} : Finset V)⊆DistanceTwo G x :=
      insert_subset_iff.mpr ⟨d2 hc xp (distance_two_charge_from_no_bridge T xa pb nb) xr pr'.symm,
        singleton_subset_iff.mpr (d2 hc xq (distance_two_charge_from_no_bridge T xa qb nb) xr qr'.symm)⟩
    have local' : ({p,q} : Finset V)⊆S.R :=
      insert_subset (mem_filter.mp pb).1 (singleton_subset_iff.mpr (mem_filter.mp qb).1)
    have sep : Disjoint ({p,q} : Finset V) S.localA :=
      S.dis.symm.mono local' (filter_subset _ _)
    have foreign : S.localA⊆DistanceTwo G x := fun _ h=>
      foreign_subset T hc (mem_filter.mp xa).1 (mem_filter.mp xa).2 h
    have m := card_le_card (union_subset sub foreign)
    rw [card_union_of_disjoint sep,l3] at m
    simpa [pq] using m
  have cover := opposite_periphery_visible_of_saturated_nonbridge T hc far nb even conn
    (mem_filter.mp xa).1 (mem_filter.mp xa).2 sat
  change S.L\S.localA⊆secondA G S.L a at cover
  have pcard := card_le_card cover
  have z : (S.L\S.localA).card+S.localA.card=S.L.card :=
    card_sdiff_add_card_eq_card (filter_subset _ _)
  have lower := second_shell_at_least_two_at_three_ports S hc far l3 degree
  have ds := secondA_right_and_left_le_five S even
  have vm : I.card ≤ (secondA G S.R a).card := card_le_card vis
  have leftCap : S.L.card≤5 := by omega
  have leftLow : 5≤S.L.card := by
    obtain ⟨u,ua,v,va,uv⟩ := one_lt_card.mp (show 1<S.localA.card by omega)
    have cap (w : V) (wa : w∈S.localA) : G.degree w≤S.L.card := by
      obtain ⟨wl,aw⟩ := mem_filter.mp wa
      have ss : G.neighborFinset w⊆insert a (S.L.erase w) := by
        intro k kk
        have wk := (mem_neighborFinset G w k).mp kk
        rcases left_boundary S w wl k wk with rfl|rfl|kl
        · exact mem_insert_self _ _
        · exact (not_common far aw wk.symm).elim
        exact mem_insert_of_mem (mem_erase.mpr ⟨wk.ne.symm,kl⟩)
      have e := (card_le_card ss).trans (card_insert_le a _)
      rw [card_neighborFinset_eq_degree,card_erase_of_mem wl] at e
      have pos := card_pos.mpr ⟨w,wl⟩
      omega
    exact (degree u v uv).elim (fun h=>h.trans (cap u ua)) (fun h=>h.trans (cap v va))
  have lc : S.L.card=5 := by omega
  have n := card_le_card (three_ports_in_five_shore_visible_to_b S hc far lc degree)
  have m := secondA_right_and_left_le_five S.flip even
  change (secondA G S.L b).card+(secondA G S.R b).card≤5 at m
  exact ⟨lc,by omega⟩

#print axioms high_nonbridge_three_b_contacts_two
#print axioms three_inner_three_b_visible_left_five
end Graffiti189LongestPath.CrossSaturation.Split.Five
