import DegreeFiveSixThreeInnerThreeBVisibleCap189
import DegreeFiveAlternatingBlock189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private d2 from CrossSaturation189
open private not_common from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem three_inner_three_b_visible_opposite_free (hc : G.Connected)
    (far : 3≤G.dist a b) (even : ∀ v,(EvenFrom G v).card≤6)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (a3 : S.localA.card=3) (foreign3 : S.foreignA.card=3)
    (b3 : (S.L.filter (G.Adj b)).card=3)
    (i3 : (farNonports S.L a b G).card=3) (nb : ¬portBridge S)
    (vis : farNonports S.L a b G⊆secondA G S.L a) (cap : (secondA G S.L b).card≤2) :
    (∃ u v,G.Adj a u ∧ RouteOn G S.L u v) ∧
      ∃ q∈S.L,¬5≤G.degree q := by
  classical
  let A := S.localA
  let B := S.L.filter (G.Adj b)
  let I := farNonports S.L a b G
  let K := I.filter (fun r=>∃ q∈B,G.Adj q r)
  let H := B.filter (fun r=>5≤G.degree r)
  change A.card=3 at a3
  change B.card=3 at b3
  change I.card=3 at i3
  have ks : K⊆I := filter_subset _ _
  have kSub : K⊆secondA G S.L b := by
    intro r rr
    obtain ⟨ri,q,qb,qr⟩ := mem_filter.mp rr
    obtain ⟨rl,_,br⟩ := mem_filter.mp ri
    exact mem_inter.mpr ⟨rl,d2 hc (fun e=>S.leftOff.2 (e.symm ▸ rl))
      br (mem_filter.mp qb).2 qr⟩
  have kCap := (card_le_card kSub).trans cap
  have count := count_high_subset_of_one_low degree B
  change B.card≤H.card+1 at count
  obtain ⟨q,qh⟩ := card_pos.mp (show 0<H.card by omega)
  obtain ⟨qb,hi⟩ := mem_filter.mp qh
  have k2 : K.card=2 := by
    have n := high_nonbridge_three_b_contacts_two S far nb b3 qb hi
    change 2≤(I.filter (G.Adj q)).card at n
    have c := card_le_card (show I.filter (G.Adj q)⊆K from fun _ rr=>
      mem_filter.mpr ⟨(mem_filter.mp rr).1,q,qb,(mem_filter.mp rr).2⟩)
    omega
  have bf (p : V) (pb : p∈B) (ph : 5≤G.degree p) :
      (∀ q∈B,p≠q → G.Adj p q) ∧ ∀ r∈K,G.Adj p r := by
    have dark : p∉visibleBPorts S.L a b G := by
      intro h
      obtain ⟨pl,bp,w,wl,aw,wp⟩ := mem_filter.mp h
      exact nb ⟨w,wl,p,pl,aw,wp,bp⟩
    have sub := far_dark_b_port_candidates S far pb dark
    have use : G.neighborFinset p⊆insert b ((B.erase p)∪K) := by
      intro v vv
      rcases mem_insert.mp (sub vv) with h|h
      · exact mem_insert.mpr (.inl h)
      exact mem_insert_of_mem ((mem_union.mp h).elim (mem_union_left _)
        (fun vi=>mem_union_right _ (mem_filter.mpr
          ⟨vi,p,pb,(mem_neighborFinset G p v).mp vv⟩)))
    exact far_port_full_at_tight_pool pb use (by omega) ph
  have charge {x r : V} (xa : x∈A) (ri : r∈K) (xr : G.Adj x r) :
      H⊆DistanceTwo G x := by
    intro p pp
    obtain ⟨pb,ph⟩ := mem_filter.mp pp
    have ne : x≠p := fun e=>not_common far (e ▸ (mem_filter.mp xa).2) (mem_filter.mp pb).2
    exact d2 hc ne (distance_two_charge_from_no_bridge S xa pb nb) xr ((bf p pb ph).2 r ri).symm
  have qK : K.Nonempty := card_pos.mp (by omega)
  obtain ⟨r,rr⟩ := qK
  obtain ⟨x,xa,xr⟩ := nonport_a_neighbor S hc far (mem_filter.mp (ks rr)).1 (mem_inter.mp (vis (ks rr))).2
  have hCap : H.card≤2 := local_distance_two_at_foreign_three S hc even foreign3
    (mem_filter.mp xa).1 (mem_filter.mp xa).2
    (fun _ h=>mem_insert_of_mem (mem_filter.mp (mem_filter.mp h).1).1) (charge xa rr xr)
  have h2 : H.card=2 := by omega
  obtain ⟨ell,em⟩ := card_pos.mp (show 0<(B\H).card by
    rw [card_sdiff (filter_subset _ _),b3,h2]; decide)
  obtain ⟨ellB,ellH⟩ := mem_sdiff.mp em
  have lowE : ¬5≤G.degree ell := fun h=>ellH (mem_filter.mpr ⟨ellB,h⟩)
  have ah (p : V) (pa : p∈A) : 5≤G.degree p :=
    (degree p ell (fun e=>not_common far (e ▸ (mem_filter.mp pa).2) (mem_filter.mp ellB).2)).resolve_right lowE
  have aft (p : V) (pa : p∈A) :
      (∀ q∈A,p≠q → G.Adj p q) ∧ ∀ i∈I,G.Adj p i := by
    have sub := bounds_of_local_color_port S far pa
      (fun q qb=>distance_two_charge_from_no_bridge S pa qb nb)
    have d := far_port_nonport_degree_lower pa sub
    change G.degree p ≤ A.card + (I.filter (G.Adj p)).card at d
    have c := ah p pa
    have some : ∃ i∈K,G.Adj p i := by
      have filters : (I.filter (G.Adj p)).card≥2 := by omega
      apply Classical.byContradiction
      intro n
      have span : I.filter (G.Adj p)⊆I\K := by
        intro w wm
        obtain ⟨wi,pw⟩ := mem_filter.mp wm
        exact mem_sdiff.mpr ⟨wi,fun kw=>n ⟨w,kw,pw⟩⟩
      have m := card_le_card span
      rw [card_sdiff ks,i3,k2] at m
      omega
    obtain ⟨i,ii,pi⟩ := some
    obtain ⟨cl,full⟩ := two_charges_force_full_on_visible S hc far even foreign3 pa h2
      (fun _ h=>mem_insert_of_mem (mem_filter.mp h).1) (charge pa ii pi)
    exact ⟨cl,fun i ii=>full i ii (vis ii)⟩
  have ac : CompleteOn G A := fun p pa=>(aft p pa).1
  have bc : CompleteOn G B := fun p pb q qb ne=>(degree p q ne).elim
    (fun h=>(bf p pb h).1 q qb ne) (fun h=>((bf q qb h).1 p pb ne.symm).symm)
  have ai : Disjoint A I := disjoint_left.mpr
    (fun _ ha hi=>(mem_filter.mp hi).2.1 (mem_filter.mp ha).2)
  have xb : x∈A := xa
  obtain ⟨u,ua,path⟩ := route_clique_join_end_leaf ai ac
    (fun p pa i ii=>(aft p pa).2 i (mem_erase.mp ii).2)
    (by omega) xb (ks rr) xr
  obtain ⟨v,vm⟩ := card_pos.mp (show 0<(B.erase q).card by
    rw [card_erase_of_mem qb,b3]; decide)
  obtain ⟨vq,vb⟩ := mem_erase.mp vm
  obtain ⟨p,pp,ps⟩ := path_between_in_clique B bc qb vb vq.symm
  have tail : RouteOn G B q v := ⟨p,pp,ps⟩
  have dis : Disjoint (A∪I) B := disjoint_union_left.mpr
    ⟨disjoint_left.mpr (fun _ aa bb=>not_common far (mem_filter.mp aa).2 (mem_filter.mp bb).2),
     disjoint_left.mpr (fun _ ii bb=>(mem_filter.mp ii).2.2 (mem_filter.mp bb).2)⟩
  have key : (A∪I)∪B=S.L := by
    rw [union_right_comm]
    exact left_port_partition S far
  exact ⟨⟨u,v,(mem_filter.mp ua).2,key ▸ path.join tail dis ((bf q qb hi).2 r rr).symm⟩,
    ell,(mem_filter.mp ellB).1,lowE⟩

#print axioms three_inner_three_b_visible_opposite_free
end Graffiti189LongestPath.CrossSaturation.Split.Five
