import DegreeFiveSixThreeInnerTwoBHidden189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private d2 from CrossSaturation189
open private left_boundary from AdjacentCut189
open private not_common secondA_right_and_left_le_five from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem high_three_port_full_on_two_shell (hc : G.Connected) (far : 3≤G.dist a b)
    (three : S.localA.card=3) (cap : (secondA G S.L a).card≤2)
    {u : V} (ua : u∈S.localA) (hi : 5≤G.degree u) :
    ∀ z∈secondA G S.L a,G.Adj u z := by
  classical
  obtain ⟨ul,au⟩ := mem_filter.mp ua
  have sub : G.neighborFinset u⊆insert a ((S.localA.erase u)∪secondA G S.L a) := by
    intro z zn
    have uz := (mem_neighborFinset G u z).mp zn
    rcases left_boundary S u ul z uz with e|e|zl
    · exact mem_insert.mpr (.inl e)
    · exact (not_common far au (e ▸ uz.symm)).elim
    apply mem_insert_of_mem
    by_cases az : G.Adj a z
    · exact mem_union_left _ (mem_erase.mpr ⟨uz.ne.symm,mem_filter.mpr ⟨zl,az⟩⟩)
    exact mem_union_right _ (mem_inter.mpr ⟨zl,d2 hc
      (fun e=>S.leftOff.1 (e.symm ▸ zl)) az au uz⟩)
  have n := (card_le_card sub).trans (card_insert_le a _)
  have m := card_union_le (S.localA.erase u) (secondA G S.L a)
  rw [card_neighborFinset_eq_degree] at n
  rw [card_erase_of_mem ua,three] at m
  exact (far_port_full_at_tight_pool ua sub (by omega) hi).2

theorem three_inner_nonbridge_two_b_all_visible_impossible (hc : G.Connected)
    (far : 3≤G.dist a b) (even : ∀ v,(EvenFrom G v).card≤6)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (l3 : S.localA.card=3) (lb3 : (S.L.filter (G.Adj b)).card=3)
    (rb2 : (S.R.filter (G.Adj b)).card=2) (i3 : (farNonports S.R a b G).card=3)
    (br : portBridge S)
    (rc : (G.induce (↑S.R : Set V)).Connected)
    (ra : ∃ x∈S.R,G.Adj a x) (rb : ∃ x∈S.R,G.Adj b x)
    (nb : ¬portBridge (switch S rc ra rb))
    (vis : farNonports S.R a b G⊆secondA G S.R a) : False := by
  classical
  let T := switch S rc ra rb
  let A := S.localA
  let B := S.L.filter (G.Adj b)
  let Q := secondA G S.L a
  let R := secondA G S.L b
  have rcap : R.card≤2 := by
    obtain ⟨p,pp,q,qq,pq⟩ := one_lt_card.mp (show 1<(T.L.filter (G.Adj b)).card by
      change 1<(S.R.filter (G.Adj b)).card; omega)
    have hi : ∃ v∈T.L.filter (G.Adj b),5≤G.degree v :=
      (degree p q pq).elim (fun h=>⟨p,pp,h⟩) (fun h=>⟨q,qq,h⟩)
    obtain ⟨v,vb,vh⟩ := hi
    have n := no_bridge_b_port_degree_charged_to_second T hc far nb vb
    change G.degree v≤(S.R.filter (G.Adj b)).card+(secondA G S.R b).card at n
    have m := secondA_right_and_left_le_five S.flip even
    change R.card+(secondA G S.R b).card≤5 at m
    omega
  have qcap : Q.card≤2 := by
    have m := secondA_right_and_left_le_five S even
    have n := card_le_card vis
    change Q.card+(secondA G S.R a).card≤5 at m
    omega
  have far' : 3≤G.dist b a := by rwa [dist_comm]
  have af (p : V) (pa : p∈A) (hp : 5≤G.degree p) : ∀ q∈Q,G.Adj p q :=
    high_three_port_full_on_two_shell S hc far l3 qcap pa hp
  have bf (p : V) (pb : p∈B) (hp : 5≤G.degree p) : ∀ q∈R,G.Adj p q :=
    high_three_port_full_on_two_shell S.flip hc far' lb3 rcap pb hp
  obtain ⟨x,xl,y,yl,ax,xy,by'⟩ := br
  have xR : x∈R := mem_inter.mpr ⟨xl,d2 hc (fun e=>S.leftOff.2 (e.symm ▸ xl))
    (not_common far ax) by' xy.symm⟩
  have bQ (p : V) (pb : p∈B) (hp : 5≤G.degree p) : p∈Q := by
    obtain ⟨pl,bp⟩ := mem_filter.mp pb
    exact mem_inter.mpr ⟨pl,d2 hc (fun e=>S.leftOff.1 (e.symm ▸ pl))
      (fun ap=>not_common far ap bp) ax (bf p pb hp x xR).symm⟩
  let H := B.filter (fun p=>5≤G.degree p)
  have hg := count_high_subset_of_one_low degree B
  have hsub : H⊆Q := fun _ h=>bQ _ (mem_filter.mp h).1 (mem_filter.mp h).2
  have hq := card_le_card hsub
  change B.card=3 at lb3
  change B.card≤H.card+1 at hg
  have he : H=Q := eq_of_subset_of_card_le hsub (by omega)
  obtain ⟨v,vh⟩ := card_pos.mp (show 0<H.card by omega)
  have vB := (mem_filter.mp vh).1
  have vQ : v∈Q := he ▸ vh
  have aR (p : V) (pa : p∈A) (hi : 5≤G.degree p) : p∈R := by
    obtain ⟨pl,ap⟩ := mem_filter.mp pa
    exact mem_inter.mpr ⟨pl,d2 hc (fun e=>S.leftOff.2 (e.symm ▸ pl))
      (not_common far ap) (mem_filter.mp vB).2 (af p pa hi v vQ).symm⟩
  have low : ∃ p∈A,¬5≤G.degree p := by
    apply Classical.byContradiction
    intro no
    have sub : A⊆R := fun p pa=>aR p pa (Classical.byContradiction (fun ph=>no ⟨p,pa,ph⟩))
    have n := card_le_card sub
    change A.card=3 at l3
    omega
  obtain ⟨p,pa,ph⟩ := low
  have full : B⊆Q := by
    intro q qb
    have ne : q≠p := fun e=>not_common far (e.symm ▸ (mem_filter.mp pa).2) (mem_filter.mp qb).2
    exact bQ q qb ((degree q p ne).resolve_right ph)
  have n := card_le_card full
  omega

theorem three_inner_nonbridge_two_b (hc : G.Connected)
    (far : 3≤G.dist a b) (even : ∀ v,(EvenFrom G v).card≤6)
    (conn : ∀ R : Finset V,R.card<2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (l3 : S.localA.card=3) (r3 : S.foreignA.card=3)
    (lb3 : (S.L.filter (G.Adj b)).card=3) (rb2 : (S.R.filter (G.Adj b)).card=2)
    (i3 : (farNonports S.R a b G).card=3)
    (br : portBridge S)
    (rc : (G.induce (↑S.R : Set V)).Connected)
    (ra : ∃ x∈S.R,G.Adj a x) (rb : ∃ x∈S.R,G.Adj b x)
    (nb : ¬portBridge (switch S rc ra rb)) :
    ∃ x y,∃ p : G.Walk x y,p.IsPath ∧ ∀ v,v∈p.support := by
  classical
  by_cases vis : farNonports S.R a b G⊆secondA G S.R a
  · exact (three_inner_nonbridge_two_b_all_visible_impossible S hc far even degree l3 lb3 rb2 i3 br rc ra rb nb vis).elim
  have hide : ((farNonports S.R a b G)\secondA G S.R a).Nonempty := by
    apply Classical.byContradiction
    intro nope
    exact vis (fun v vi=>Classical.byContradiction (fun n=>nope ⟨v,mem_sdiff.mpr ⟨vi,n⟩⟩))
  exact three_inner_nonbridge_two_b_one_invisible S hc far even conn degree l3 r3 rb2 i3 br rc ra rb nb hide

#print axioms three_inner_nonbridge_two_b_all_visible_impossible
#print axioms three_inner_nonbridge_two_b
end Graffiti189LongestPath.CrossSaturation.Split.Five
