import DegreeFiveSixOneBridgeSmall189
import DegreeFiveSixOneBridgeFourFew189
import SmallDenseRoute189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private d2 from CrossSaturation189
open private left_boundary from AdjacentCut189
open private not_common from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem all_high_small_terminal_wing (far : 3≤G.dist a b)
    (small : S.L.card≤7) (high : ∀ v∈S.L,5≤G.degree v) :
    ∃ p q,G.Adj a p ∧ G.Adj b q ∧ RouteOn G S.L p q := by
  classical
  obtain ⟨p,pl,ap⟩ := S.leftA
  obtain ⟨q,ql,bq⟩ := S.leftB
  have ne : p≠q := fun e=>not_common far (e ▸ ap) bq
  have dense (v : V) (vl : v∈S.L) :
      S.L.card+1≤2*(S.L.filter (G.Adj v)).card := by
    let c := if G.Adj a v then a else b
    have sub : G.neighborFinset v⊆insert c (S.L.filter (G.Adj v)) := by
      intro x xm
      have vx := (mem_neighborFinset G v x).mp xm
      rcases left_boundary S v vl x vx with rfl|rfl|xl
      · exact mem_insert.mpr (.inl (by simp [c,vx.symm]))
      · have av : ¬G.Adj a v := fun h=>not_common far h vx.symm
        exact mem_insert.mpr (.inl (by simp [c,av]))
      exact mem_insert_of_mem (mem_filter.mpr ⟨xl,vx⟩)
    have n := (card_le_card sub).trans (card_insert_le c _)
    rw [card_neighborFinset_eq_degree] at n
    have h := high v vl
    omega
  exact ⟨p,q,ap,bq,terminal_route_of_dense_finset S.L pl ql ne dense⟩

theorem three_inner_nonbridge_two_b_one_invisible (hc : G.Connected)
    (far : 3≤G.dist a b) (even : ∀ v,(EvenFrom G v).card≤6)
    (conn : ∀ R : Finset V,R.card<2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (l3 : S.localA.card=3) (r3 : S.foreignA.card=3)
    (b2 : (S.R.filter (G.Adj b)).card=2) (i3 : (farNonports S.R a b G).card=3)
    (br : portBridge S)
    (rc : (G.induce (↑S.R : Set V)).Connected)
    (ra : ∃ x∈S.R,G.Adj a x) (rb : ∃ x∈S.R,G.Adj b x)
    (nb : ¬portBridge (switch S rc ra rb))
    (has : ((farNonports S.R a b G)\secondA G S.R a).Nonempty) :
    ∃ x y,∃ p : G.Walk x y,p.IsPath ∧ ∀ v,v∈p.support := by
  classical
  let T := switch S rc ra rb
  let A := S.foreignA
  let B := S.R.filter (G.Adj b)
  let I := farNonports S.R a b G
  obtain ⟨t,tt⟩ := has
  obtain ⟨ti,tHidden⟩ := mem_sdiff.mp tt
  obtain ⟨tr,ta,tb⟩ := mem_filter.mp ti
  have noAt (q : V) (qa : q∈A) : ¬G.Adj q t := by
    intro e
    have ne : a≠t := fun e=>S.rightOff.1 (e.symm ▸ tr)
    exact tHidden (mem_inter.mpr ⟨tr,d2 hc ne ta (mem_filter.mp qa).2 e⟩)
  have tBound : G.neighborFinset t⊆B∪I.erase t := by
    intro q qm
    have tq := (mem_neighborFinset G t q).mp qm
    rcases left_boundary T t tr q tq with rfl|rfl|qr
    · exact (ta tq.symm).elim
    · exact (tb tq.symm).elim
    by_cases aq : G.Adj a q
    · exact (noAt q (mem_filter.mpr ⟨qr,aq⟩) tq.symm).elim
    by_cases bq : G.Adj b q
    · exact mem_union_left _ (mem_filter.mpr ⟨qr,bq⟩)
    exact mem_union_right _ (mem_erase.mpr ⟨tq.ne.symm,mem_filter.mpr ⟨qr,aq,bq⟩⟩)
  have low : ¬5≤G.degree t := by
    have n := (card_le_card tBound).trans (card_union_le B (I.erase t))
    rw [card_neighborFinset_eq_degree,card_erase_of_mem ti] at n
    change G.degree t ≤ B.card + (I.card - 1) at n
    change B.card=2 at b2
    change I.card=3 at i3
    omega
  have otherHigh (q : V) (ne : q≠t) : 5≤G.degree q := (degree q t ne).resolve_right low
  have HI : ∀ q∈S.L,5≤G.degree q := fun q ql=>otherHigh q (fun e=>disjoint_left.mp S.dis ql (e.symm ▸ tr))
  have small := (left_shore_small_when_opposite_invisible S hc far even conn degree l3 r3 br ⟨t,tt⟩).1
  have leftSmall : S.L.card≤7 := by
    have ⟨x,xl,y,_,ax,xy,by'⟩ := br
    have cap := bridge_three_foreign_invisible_cap S hc even conn r3 xl ax xy by' (not_common far ax)
    have cnt := card_sdiff_add_card_eq_card (inter_subset_left :
      I∩secondA G S.R a⊆I)
    have eq : I \ (I∩secondA G S.R a)=I\secondA G S.R a := by ext w; simp
    rw [eq] at cnt
    have n := card_le_card (inter_subset_right : I∩secondA G S.R a⊆secondA G S.R a)
    change I.card=3 at i3
    change (I\secondA G S.R a).card≤1 at cap
    omega
  let J := I.erase t
  have ae (q : V) (qa : q∈A) :
      (∀ w∈A,q≠w → G.Adj q w) ∧ ∀ w∈J,G.Adj q w := by
    have hi := otherHigh q (fun e=>ta (e ▸ (mem_filter.mp qa).2))
    have cand := bounds_of_local_color_port T far qa (fun w wb=>distance_two_charge_from_no_bridge T qa wb nb)
    have sub : G.neighborFinset q⊆insert a ((A.erase q)∪J) := by
      intro w wm
      rcases mem_insert.mp (cand wm) with e|m
      · exact mem_insert.mpr (.inl e)
      exact mem_insert_of_mem ((mem_union.mp m).elim (mem_union_left _)
        (fun hi=>mem_union_right _ (mem_erase.mpr ⟨fun e=>noAt q qa
          (e ▸ (mem_neighborFinset G q w).mp wm),hi⟩)))
    exact far_port_full_at_tight_pool qa sub (by
      change A.card=3 at r3
      change I.card=3 at i3
      change A.card+(I.erase t).card=5
      rw [card_erase_of_mem ti,i3,r3]) hi
  have be (q : V) (qb : q∈B) :
      (∀ w∈B,q≠w → G.Adj q w) ∧ ∀ w∈I,G.Adj q w := by
    have hi := otherHigh q (fun e=>tb (e ▸ (mem_filter.mp qb).2))
    have dark : q∉visibleBPorts T.L a b G := by
      intro h
      obtain ⟨ql,bq,w,wl,aw,wq⟩ := mem_filter.mp h
      exact nb ⟨w,wl,q,ql,aw,wq,bq⟩
    exact far_port_full_at_tight_pool qb (far_dark_b_port_candidates T far qb dark) (by
      change B.card=2 at b2
      change I.card=3 at i3
      omega) hi
  have aEq : A.card=3 := r3
  obtain ⟨p,q,w,pq,pw,qw,ac⟩ := card_eq_three.mp aEq
  have bEq : B.card=2 := b2
  obtain ⟨u,v,uv,bc⟩ := card_eq_two.mp bEq
  have jEq : J.card=2 := by change (I.erase t).card=2; rw [card_erase_of_mem ti,i3]
  obtain ⟨r,s,rs,jc⟩ := card_eq_two.mp jEq
  have pa : p∈A := by simp [ac]
  have qa : q∈A := by simp [ac]
  have wa : w∈A := by simp [ac]
  have ub : u∈B := by simp [bc]
  have vb : v∈B := by simp [bc]
  have rj : r∈J := by simp [jc]
  have sj : s∈J := by simp [jc]
  have noAI {x y : V} (xa : x∈A) (yi : y∈I) : x≠y :=
    fun e=>(mem_filter.mp yi).2.1 (e ▸ (mem_filter.mp xa).2)
  have noBI {x y : V} (xb : x∈B) (yi : y∈I) : x≠y :=
    fun e=>(mem_filter.mp yi).2.2 (e ▸ (mem_filter.mp xb).2)
  have noAB {x y : V} (xa : x∈A) (yb : y∈B) : x≠y :=
    fun e=>not_common far (e ▸ (mem_filter.mp xa).2) (mem_filter.mp yb).2
  have ri := (mem_erase.mp rj).2
  have si := (mem_erase.mp sj).2
  have nr := (mem_erase.mp rj).1
  have ns := (mem_erase.mp sj).1
  have block1 := RouteOn.three ((ae p pa).2 r rj) ((ae q qa).2 r rj).symm pq
  have block2 := (((RouteOn.three ((ae w wa).2 s sj) ((be u ub).2 s si).symm (noAB wa ub)).suffix
    ((be u ub).2 t ti) (by simp [(noAI wa ti).symm,ns.symm,(noBI ub ti).symm])).suffix
    ((be v vb).2 t ti).symm (by simp [noBI vb ti,(noAB wa vb).symm,noBI vb si,uv.symm]))
  have dis : Disjoint ({p,r,q} : Finset V) (insert v (insert t {w,s,u})) := by
    simp [disjoint_insert_left,disjoint_singleton_left,pw,qw,pq,(noBI ub ri).symm,(noBI vb ri).symm,nr,rs,
      (noAI wa ri).symm,noAI pa ti,noAI pa si,noAI qa ti,noAI qa si,noAB pa ub,noAB pa vb,noAB qa ub,noAB qa vb,
      pw.symm,qw.symm,rs.symm,nr.symm,noAI wa ri,noBI vb ri,noBI ub ri,
      (noAI pa ti).symm,(noAI pa si).symm,(noAI qa ti).symm,(noAI qa si).symm,
      (noAB pa ub).symm,(noAB pa vb).symm,(noAB qa ub).symm,(noAB qa vb).symm]
  have key : ({p,r,q} : Finset V)∪insert v (insert t {w,s,u})=S.R := by
    have whole := left_port_partition T far
    change A∪B∪I=S.R at whole
    have ie : I=insert t J := (insert_erase ti).symm
    rw [←whole,ac,bc,ie,jc]
    ext x
    simp [or_comm,or_left_comm,or_assoc]
  have wing : RouteOn G S.R p v := key ▸ block1.join block2 dis ((ae q qa).1 w wa qw)
  exact traceable_from_far_terminal_and_free S far (all_high_small_terminal_wing S far leftSmall HI)
    (.inl ⟨p,v,(mem_filter.mp pa).2,wing⟩)

#print axioms all_high_small_terminal_wing
#print axioms three_inner_nonbridge_two_b_one_invisible
end Graffiti189LongestPath.CrossSaturation.Split.Five
