import DegreeFiveSixOneBridgeDispatch189
import DegreeFiveSixActualDispatch189
import DegreeFiveBalancedUniform189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private distance_three_has_bridge from DegreeFiveBalancedUniform189

variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

/-- Only the two-bridge branch and the all-three one-bridge leaf need to be
supplied to glue the general three/three split. -/
theorem exact_three_three_of_two_remaining
    (hc : G.Connected) (three : G.dist a b = 3)
    (even : ∀ v,(EvenFrom G v).card ≤ 6)
    (conn : ∀ R : Finset V, R.card < 2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V, u ≠ v → 5 ≤ G.degree u ∨ 5 ≤ G.degree v)
    (high : 5 ≤ G.degree b)
    (local3 : S.localA.card = 3) (foreign3 : S.foreignA.card = 3)
    (lc : (S.L.filter (G.Adj b)).card ≤ 3) (bc : (S.R.filter (G.Adj b)).card ≤ 3)
    (rc : (G.induce (↑S.R : Set V)).Connected)
    (ra : ∃ x∈S.R, G.Adj a x) (rb : ∃ x∈S.R, G.Adj b x)
    (both : portBridge S → portBridge (switch S rc ra rb) →
      ∃ x y,∃ p : G.Walk x y,p.IsPath ∧ ∀ z,z∈p.support)
    (oneLast : ∀ (U : Split G a b)
      (uR : (G.induce (↑U.R : Set V)).Connected)
      (uA : ∃ x∈U.R,G.Adj a x) (uB : ∃ x∈U.R,G.Adj b x),
      U.localA.card = 3 → U.foreignA.card = 3 → (U.L.filter (G.Adj b)).card ≤ 3 →
      portBridge U → ¬portBridge (switch U uR uA uB) →
      (farNonports U.R a b G).card = 3 → (U.R.filter (G.Adj b)).card = 3 →
      ∃ x y,∃ p : G.Walk x y,p.IsPath ∧ ∀ z,z∈p.support) :
    ∃ x y,∃ p : G.Walk x y,p.IsPath ∧ ∀ z,z∈p.support := by
  classical
  have far : 3 ≤ G.dist a b := by omega
  let T := switch S rc ra rb
  have br := distance_three_has_bridge S hc three rc ra rb
  by_cases lb : portBridge S
  · by_cases tb : portBridge T
    · exact both lb tb
    exact exact_three_three_one_bridge_of_three_inner_three_b S hc far even conn degree high
      local3 foreign3 lc bc lb rc ra rb tb (oneLast S rc ra rb local3 foreign3 lc lb tb)
  have tr : portBridge T := br.resolve_left lb
  have nt : ¬portBridge (switch T S.leftConnected S.leftA S.leftB) := by
    exact lb
  exact exact_three_three_one_bridge_of_three_inner_three_b T hc far even conn degree high
    foreign3 local3 bc lc tr S.leftConnected S.leftA S.leftB nt
    (oneLast T S.leftConnected S.leftA S.leftB foreign3 local3 bc tr nt)

#print axioms exact_three_three_of_two_remaining
end Graffiti189LongestPath.CrossSaturation.Split.Five
