import DegreeFiveSixTwoFourSmall189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private not_common secondA_right_and_left_le_five from DegreeFiveFourPort189
open private d2 from CrossSaturation189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem bridge_two_opposite_shell_cap (hc : G.Connected) (far : 3≤G.dist a b)
    (even : ∀ z,(EvenFrom G z).card≤6)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (local2 : S.localA.card=2) (foreign4 : S.foreignA.card=4)
    (bridge : portBridge S) :
    farNonports S.R a b G⊆secondA G S.R a ∧
      (farNonports S.R a b G).card+(visibleBPorts S.R a b G).card≤2 := by
  classical
  let I := farNonports S.R a b G
  let W := visibleBPorts S.R a b G
  let P := S.L\S.localA
  obtain ⟨x,xl,y,yl,ax,xy,by'⟩ := bridge
  have bridge' : portBridge S := ⟨x,xl,y,yl,ax,xy,by'⟩
  have ub := bridge_four_forces_universal S hc far even foreign4 xl ax xy by'
  have pSub : P⊆secondA G S.L a := by
    intro z zz
    obtain ⟨zl,za⟩ := mem_sdiff.mp zz
    have az : ¬G.Adj a z := fun az=>za (mem_filter.mpr ⟨zl,az⟩)
    have xz := (ub z zl).resolve_left (fun e=>az (e.symm ▸ ax))
    have ne : a≠z := fun e=>S.leftOff.1 (e.symm ▸ zl)
    exact mem_inter.mpr ⟨zl,d2 hc ne az ax xz⟩
  have iSub : I⊆secondA G S.R a := by
    intro z zi
    obtain ⟨zr,az,bz⟩ := mem_filter.mp zi
    have bound := right_cover_of_mixed_opposite_four S hc far even foreign4 bridge' zr
    rcases mem_union.mp bound with pp|p
    · rcases mem_union.mp pp with p|p
      · exact (az (mem_filter.mp p).2).elim
      exact (bz (mem_filter.mp p).2).elim
    exact p
  have wSub : W⊆secondA G S.R a := by
    intro z zw
    obtain ⟨zr,bz,p,pr,ap,pz⟩ := mem_filter.mp zw
    have ne : a≠z := fun h=>S.rightOff.1 (h.symm ▸ zr)
    exact mem_inter.mpr ⟨zr,d2 hc ne (fun az=>not_common far az bz) ap pz⟩
  have dis : Disjoint I W := disjoint_left.mpr (fun v vi vw=>(mem_filter.mp vi).2.2 (mem_filter.mp vw).2.1)
  have iw := card_le_card (union_subset iSub wSub)
  rw [card_union_of_disjoint dis] at iw
  have p3 : 3≤P.card := peripheral_card_at_least_three S far degree local2
  have sem := secondA_right_and_left_le_five S even
  have pm := card_le_card pSub
  refine ⟨iSub,?_⟩
  change I.card+W.card≤2
  omega

#print axioms bridge_two_opposite_shell_cap
end Graffiti189LongestPath.CrossSaturation.Split.Five
