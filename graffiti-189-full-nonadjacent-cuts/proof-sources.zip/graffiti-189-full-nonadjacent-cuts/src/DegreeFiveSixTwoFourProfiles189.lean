import DegreeFiveSixTwoFourCap189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph Finset
open private not_common from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

/-- Precisely the remaining large-side color profiles in the (2,4) split. -/
theorem large_opposite_profiles_at_two_four (hc : G.Connected)
    (far : 3≤G.dist a b) (even : ∀ z,(EvenFrom G z).card≤6)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (l2 : S.localA.card=2) (r4 : S.foreignA.card=4)
    (rc : (G.induce (↑S.R : Set V)).Connected)
    (ra : ∃ x∈S.R,G.Adj a x) (rb : ∃ x∈S.R,G.Adj b x)
    (br : portBridge S) (large : 8<S.R.card) :
    farNonports S.R a b G⊆secondA G S.R a ∧
      ((farNonports S.R a b G).card=1 ∧ (S.R.filter (G.Adj b)).card=4 ∨
       ¬portBridge (switch S rc ra rb) ∧
         (farNonports S.R a b G).card=2 ∧ 3≤(S.R.filter (G.Adj b)).card ∧
         (S.R.filter (G.Adj b)).card≤4) := by
  classical
  let T := switch S rc ra rb
  have far' : 3≤G.dist b a := by rwa [dist_comm]
  have b4 := foreign_a_ports_le_four S.flip hc far' even
  change (S.R.filter (G.Adj b)).card≤4 at b4
  have count := left_port_count T far
  change S.foreignA.card+(S.R.filter (G.Adj b)).card+(farNonports S.R a b G).card=S.R.card at count
  obtain ⟨showI,cap⟩ := bridge_two_opposite_shell_cap S hc far even degree l2 r4 br
  refine ⟨showI,?_⟩
  by_cases i1 : (farNonports S.R a b G).card=1
  · exact .inl ⟨i1,by omega⟩
  have i2 : (farNonports S.R a b G).card=2 := by omega
  have nb : ¬portBridge T := by
    intro co
    obtain ⟨x,xr,y,yr,ax,xy,by'⟩ := co
    have seen : y∈visibleBPorts S.R a b G := mem_filter.mpr ⟨yr,by',x,xr,ax,xy⟩
    have p := card_pos.mpr ⟨y,seen⟩
    omega
  exact .inr ⟨nb,i2,by omega,b4⟩

#print axioms large_opposite_profiles_at_two_four
end Graffiti189LongestPath.CrossSaturation.Split.Five
