import DegreeFiveSixNoBridgeTwoFour189
import DegreeFiveSevenNoBridgeClose189
namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private left_secondA_positive secondA_right_and_left_le_five from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem traceable_six_two_four_small_or_no_bridge (hc : G.Connected)
    (far : 3≤G.dist a b) (even : ∀ z,(EvenFrom G z).card≤6)
    (conn : ∀ R : Finset V,R.card<2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (localTwo : S.localA.card=2) (foreignFour : S.foreignA.card=4)
    (rc : (G.induce (↑S.R : Set V)).Connected)
    (ra : ∃ x∈S.R,G.Adj a x) (rb : ∃ x∈S.R,G.Adj b x)
    (case' : S.R.card≤8 ∨ ¬portBridge S) :
    ∃ x y,∃ p : G.Walk x y,p.IsPath ∧ ∀ v,v∈p.support := by
  classical
  have rightSmall : S.R.card≤8 := by
    rcases case' with small|no
    · exact small
    have sub := no_bridge_four_foreign_cover S hc far even foreignFour no
    have n := (card_le_card sub).trans (card_union_le _ _)
    have pos := left_secondA_positive S hc far
    have sum := secondA_right_and_left_le_five S even
    omega
  have term : ∃ p q,G.Adj a p ∧ G.Adj b q ∧ RouteOn G S.L p q := by
    by_cases bridge : portBridge S
    · exact bridge_route_at_two_four S hc far even degree localTwo foreignFour rc ra rb bridge
    exact no_bridge_terminal_two_four S hc far even conn degree localTwo foreignFour rc ra rb bridge
  let T := switch S rc ra rb
  have t4 : T.localA.card=4 := foreignFour
  have free := free_route_small_far_shore T far degree rightSmall (by omega)
  exact traceable_from_far_terminal_and_free S far term (.inl free)

#print axioms traceable_six_two_four_small_or_no_bridge
end Graffiti189LongestPath.CrossSaturation.Split.Five
