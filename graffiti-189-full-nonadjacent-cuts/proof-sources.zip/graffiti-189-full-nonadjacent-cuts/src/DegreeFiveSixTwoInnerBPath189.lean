import DegreeFiveSixFourInternalPath189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private d2 from CrossSaturation189
open private not_common from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

private theorem neighbor_in_connected_shore {z q : V} (zl : z∈S.L) (ql : q∈S.L)
    (zq : z≠q) : ∃ w∈S.L,G.Adj z w := by
  let W := ↑(↑S.L : Set V)
  obtain ⟨p⟩ := S.leftConnected.preconnected (⟨z,zl⟩ : W) ⟨q,ql⟩
  cases p with
  | nil => exact (zq rfl).elim
  | @cons _ w _ e p => exact ⟨w.val,w.property,e⟩

theorem four_a_two_inner_b_path (hc : G.Connected) (far : 3≤G.dist a b)
    (even : ∀ v,(EvenFrom G v).card≤6)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (b3 : 3≤(S.L.filter (G.Adj b)).card) (b4 : (S.L.filter (G.Adj b)).card≤4)
    (i2 : (farNonports S.L a b G).card=2) (foreign : S.foreignA.card=2)
    (no : ¬portBridge S) (showI : farNonports S.L a b G⊆secondA G S.L a) :
    ∃ t∈farNonports S.L a b G,∃ u v,RouteOn G (S.L.filter (G.Adj b)) u v ∧ G.Adj t u := by
  classical
  let B := S.L.filter (G.Adj b)
  let I := farNonports S.L a b G
  change 3≤B.card at b3
  change B.card≤4 at b4
  change I.card=2 at i2
  have bs : B⊆S.L := filter_subset _ _
  have invisible (q : V) (qb : q∈B) : q∉visibleBPorts S.L a b G := by
    intro h
    obtain ⟨ql,bq,u,ul,au,uq⟩ := mem_filter.mp h
    exact no ⟨u,ul,q,ql,au,uq,bq⟩
  have bounded (q : V) (qb : q∈B) : G.neighborFinset q⊆insert b ((B.erase q)∪I) :=
    far_dark_b_port_candidates S far qb (invisible q qb)
  have internal (q : V) (qb : q∈B) (qh : 5≤G.degree q) : 2≤(B.filter (G.Adj q)).card := by
    have sub : G.neighborFinset q⊆insert b (B.filter (G.Adj q)∪I) := by
      intro v hv
      rcases mem_insert.mp (bounded q qb hv) with e|v'
      · exact mem_insert.mpr (.inl e)
      exact mem_insert_of_mem ((mem_union.mp v').elim
        (fun m=>mem_union_left _ (mem_filter.mpr ⟨(mem_erase.mp m).2,(mem_neighborFinset G q v).mp hv⟩))
        (mem_union_right _))
    have n := (card_le_card sub).trans (card_insert_le b _)
    have m := card_union_le (B.filter (G.Adj q)) I
    rw [card_neighborFinset_eq_degree] at n
    omega
  have wide (q : V) (qb : q∈B) (r : V) (rb : r∈B) (qr : q≠r) :
      2≤(B.filter (G.Adj q)).card ∨ 2≤(B.filter (G.Adj r)).card :=
    (degree q r qr).imp (internal q qb) (internal r rb)
  have hitI (q : V) (qb : q∈B) (high : 5≤G.degree q) : ∃ t∈I,G.Adj t q := by
    have n := far_port_nonport_degree_lower qb (bounded q qb)
    obtain ⟨t,ht⟩ := card_pos.mp (show 0<(I.filter (G.Adj q)).card by omega)
    obtain ⟨ti,qt⟩ := mem_filter.mp ht
    exact ⟨t,ti,qt.symm⟩
  by_cases small : B.card=3
  · have cl := clique_of_three_internal_high small wide
    obtain ⟨u,ub,v,vb,uv⟩ := one_lt_card.mp (show 1<B.card by omega)
    obtain ⟨p,hp,ps⟩ := path_between_in_clique B cl ub vb uv
    have route : RouteOn G B u v := ⟨p,hp,ps⟩
    rcases degree u v uv with hi|hi
    · obtain ⟨t,ti,tu⟩ := hitI u ub hi
      exact ⟨t,ti,u,v,route,tu⟩
    obtain ⟨t,ti,tv⟩ := hitI v vb hi
    exact ⟨t,ti,v,u,route.reverse,tv⟩
  have four : B.card=4 := by omega
  have noiso (z : V) (zb : z∈B) : ∃ v∈B,G.Adj z v := by
    apply Classical.byContradiction
    intro iso
    have nz : (B.filter (G.Adj z)).card=0 := by
      rw [card_eq_zero,eq_empty_iff_forall_not_mem]
      exact fun v h=>iso ⟨v,(mem_filter.mp h).1,(mem_filter.mp h).2⟩
    have zl : z∈S.L := bs zb
    obtain ⟨q,qb,w,wb,qw⟩ := one_lt_card.mp (show 1<B.card by omega)
    have existsOther : ∃ q∈B,q≠z := by
      by_cases a : q=z
      · exact ⟨w,wb,fun e=>qw (a.trans e.symm)⟩
      exact ⟨q,qb,a⟩
    obtain ⟨q,qb,qz⟩ := existsOther
    obtain ⟨t,tl,zt⟩ := neighbor_in_connected_shore S zl (bs qb) qz.symm
    have ti : t∈I := by
      have m := bounded z zb ((mem_neighborFinset G z t).mpr zt)
      rcases mem_insert.mp m with e|e
      · exact (S.leftOff.2 (e ▸ tl)).elim
      exact (mem_union.mp e).resolve_left (fun h=>iso ⟨t,(mem_erase.mp h).2,zt⟩)
    obtain ⟨p,pa,pt⟩ := nonport_a_neighbor S hc far tl (mem_inter.mp (showI ti)).2
    have d2B : B⊆DistanceTwo G p := by
      intro v vb
      have heat : G.Adj v t := by
        by_cases vz : v=z
        · exact vz.symm ▸ zt
        have high : 5≤G.degree v := (degree v z vz).resolve_right (fun zh=>by
          have n := internal z zb zh
          omega)
        have miss : ¬G.Adj v z := fun e=>iso ⟨v,vb,e.symm⟩
        have n := far_port_nonport_degree_lower_of_missing_peer vb zb (Ne.symm vz) miss (bounded v vb)
        have eq : I.filter (G.Adj v)=I := by
          apply eq_of_subset_of_card_le (filter_subset _ _)
          omega
        exact (mem_filter.mp (eq.symm ▸ ti)).2
      have pl := (mem_filter.mp pa).1
      have ap := (mem_filter.mp pa).2
      have bv := (mem_filter.mp vb).2
      have ne : p≠v := fun e=>not_common far (e ▸ ap) bv
      exact d2 hc ne (distance_two_charge_from_no_bridge S pa vb no) pt heat.symm
    have cap := local_distance_two_at_foreign_two S hc even foreign (mem_filter.mp pa).1
      (mem_filter.mp pa).2 (fun _ h=>mem_insert_of_mem (bs h)) d2B
    omega
  obtain ⟨u,ub,v,vb,uv,route⟩ := four_internal_wide_spanning_path four noiso wide
  rcases degree u v uv with hi|hi
  · obtain ⟨t,ti,tu⟩ := hitI u ub hi
    exact ⟨t,ti,u,v,route,tu⟩
  obtain ⟨t,ti,tv⟩ := hitI v vb hi
  exact ⟨t,ti,v,u,route.reverse,tv⟩

#print axioms four_a_two_inner_b_path
end Graffiti189LongestPath.CrossSaturation.Split.Five
