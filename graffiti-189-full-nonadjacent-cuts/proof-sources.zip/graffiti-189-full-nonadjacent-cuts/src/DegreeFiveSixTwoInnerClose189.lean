import DegreeFiveSixLonelyInnerRoute189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private not_common from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem four_a_no_bridge_two_inner_free (hc : G.Connected) (far : 3≤G.dist a b)
    (even : ∀ v,(EvenFrom G v).card≤6)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (a4 : S.localA.card=4) (b3 : 3≤(S.L.filter (G.Adj b)).card)
    (b4 : (S.L.filter (G.Adj b)).card≤4)
    (i2 : (farNonports S.L a b G).card=2) (foreign : S.foreignA.card=2)
    (no : ¬portBridge S) (showI : farNonports S.L a b G⊆secondA G S.L a) :
    (∃ u v,G.Adj a u ∧ RouteOn G S.L u v) ∨
    (∃ u v,G.Adj b u ∧ RouteOn G S.L u v) := by
  classical
  let A := S.localA
  let B := S.L.filter (G.Adj b)
  let I := farNonports S.L a b G
  obtain ⟨t,ti,u,v,path,tb⟩ :=
    four_a_two_inner_b_path S hc far even degree b3 b4 i2 foreign no showI
  have two : I.card=2 := i2
  obtain ⟨s,sm⟩ := card_pos.mp (show 0<(I.erase t).card by rw [card_erase_of_mem ti,two]; decide)
  obtain ⟨st,si⟩ := mem_erase.mp sm
  have inner : I={s,t} := (eq_of_subset_of_card_le (insert_subset si (singleton_subset_iff.mpr ti))
    (by rw [two]; simp [st])).symm
  have assemble (opt : G.Adj s t ∨
      (2≤(A.filter (G.Adj s)).card ∧ 2≤(A.filter (G.Adj t)).card)) :
      ∃ u v,G.Adj a u ∧ RouteOn G S.L u v := by
    obtain ⟨p,pa,pre⟩ :=
      four_a_two_inner_prescribed_end S hc far even degree a4 b3 b4 foreign no st inner showI opt
    have dis : Disjoint (A∪I) B := disjoint_union_left.mpr
      ⟨disjoint_left.mpr (fun q qa qb=>not_common far (mem_filter.mp qa).2 (mem_filter.mp qb).2),
       disjoint_left.mpr (fun q qi qb=>(mem_filter.mp qi).2.2 (mem_filter.mp qb).2)⟩
    have eq : (A∪I)∪B=S.L := by
      rw [union_right_comm]
      exact left_port_partition S far
    exact ⟨p,v,(mem_filter.mp pa).2,eq ▸ pre.join path dis tb⟩
  by_cases hit : G.Adj s t
  · exact .inl (assemble (.inl hit))
  have corner (s t : V) (st : s≠t) (si : s∈I) (inner : I={s,t}) (hit : ¬G.Adj s t)
      (n : ¬2≤(A.filter (G.Adj s)).card) :
      ∃ u v,G.Adj b u ∧ RouteOn G S.L u v := by
    obtain ⟨p,pa,ps⟩ := nonport_a_neighbor S hc far (mem_filter.mp si).1 (mem_inter.mp (showI si)).2
    have pm : p∈A.filter (G.Adj s) := mem_filter.mpr ⟨pa,ps.symm⟩
    have one : A.filter (G.Adj s)={p} :=
      (eq_of_subset_of_card_le (singleton_subset_iff.mpr pm) (by rw [card_singleton]; omega)).symm
    exact lonely_inner_b_rooted S hc far even degree a4 b3 b4 foreign no st inner hit pa one
  by_cases ss : 2≤(A.filter (G.Adj s)).card
  · by_cases tt : 2≤(A.filter (G.Adj t)).card
    · exact .inl (assemble (.inr ⟨ss,tt⟩))
    have swap : I={t,s} := by rw [inner]; ext r; simp [or_comm]
    exact .inr (corner t s st.symm ti swap (fun h=>hit h.symm) tt)
  exact .inr (corner s t st si inner hit ss)

#print axioms four_a_no_bridge_two_inner_free
end Graffiti189LongestPath.CrossSaturation.Split.Five
