import DegreeFiveSixOrePairs189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

theorem two_inners_core_route (A : Finset V) (four : A.card=4)
    (cl : CompleteOn G A) {s t : V} (ns : s∉A) (nt : t∉A) (st : s≠t)
    (options : (G.Adj s t ∧ ∃ p∈A,G.Adj p s) ∨
      ∃ p∈A,∃ q∈A,∃ r∈A,p≠q ∧ p≠r ∧ q≠r ∧
        G.Adj p s ∧ G.Adj s q ∧ G.Adj r t) :
    ∃ x∈A,RouteOn G (A∪{s,t}) x t := by
  classical
  rcases options with ⟨hit,p,pa,ps⟩|⟨p,pa,q,qa,r,ra,pq,pr,qr,ps,sq,rt⟩
  · obtain ⟨x,xm⟩ := card_pos.mp (show 0<(A.erase p).card by rw [card_erase_of_mem pa,four]; decide)
    obtain ⟨xp,xa⟩ := mem_erase.mp xm
    obtain ⟨w,wp,ws⟩ := path_between_in_clique A cl xa pa xp
    have step : RouteOn G A x p := ⟨w,wp,ws⟩
    have a := (step.suffix ps ns).suffix hit (fun h=>(mem_insert.mp h).elim (fun e=>st e.symm) nt)
    have eq : insert t (insert s A)=A∪({s,t} : Finset V) := by
      ext z
      simp [or_comm,or_left_comm,or_assoc]
    exact ⟨x,xa,eq ▸ a⟩
  let P := ({p,q,r} : Finset V)
  have sub : P⊆A := insert_subset pa (insert_subset qa (singleton_subset_iff.mpr ra))
  have c : P.card=3 := by simp [P,pq,pr,qr]
  obtain ⟨x,xs⟩ := card_pos.mp (show 0<(A\P).card by rw [card_sdiff sub,four,c]; decide)
  obtain ⟨xa,xOff⟩ := mem_sdiff.mp xs
  have xp : x≠p := fun e=>xOff (mem_insert.mpr (.inl e))
  have xq : x≠q := fun e=>xOff (mem_insert.mpr (.inr (mem_insert.mpr (.inl e))))
  have xr : x≠r := fun e=>xOff (mem_insert.mpr (.inr (mem_insert_of_mem (mem_singleton.mpr e))))
  have sx : s≠x := fun e=>ns (e.symm ▸ xa)
  have sp : s≠p := fun e=>ns (e.symm ▸ pa)
  have sr : s≠r := fun e=>ns (e.symm ▸ ra)
  have tq : t≠q := fun e=>nt (e.symm ▸ qa)
  have tx : t≠x := fun e=>nt (e.symm ▸ xa)
  have tp : t≠p := fun e=>nt (e.symm ▸ pa)
  have tr : t≠r := fun e=>nt (e.symm ▸ ra)
  have path := (((RouteOn.three (cl x xa p pa xp) ps sx.symm).suffix sq
    (by simp [xq.symm,pq.symm,sq.ne.symm])).suffix (cl q qa r ra qr)
    (by simp [qr.symm,xr.symm,pr.symm,sr.symm])).suffix rt
    (by simp [tq,tx,tp,tr,st.symm])
  have ae : ({x,p,q,r} : Finset V)=A := by
    apply eq_of_subset_of_card_le (insert_subset xa sub)
    rw [four]
    simp [xp,xq,xr,P,pq,pr,qr]
  have eq : insert t (insert r (insert q ({x,p,s} : Finset V)))=A∪{s,t} := by
    rw [←ae]
    ext z
    simp [or_comm,or_left_comm,or_assoc]
  exact ⟨x,xa,eq ▸ path⟩

#print axioms two_inners_core_route
end Graffiti189LongestPath.CrossSaturation.Split.Five
