import DegreeFiveSixTwoPlusOne189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph Finset ArticulationPair
open private not_common from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem four_a_two_inner_prescribed_end (hc : G.Connected) (far : 3≤G.dist a b)
    (even : ∀ v,(EvenFrom G v).card≤6)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (a4 : S.localA.card=4) (b3 : 3≤(S.L.filter (G.Adj b)).card)
    (b4 : (S.L.filter (G.Adj b)).card≤4)
    (foreign : S.foreignA.card=2) (no : ¬portBridge S)
    {s t : V} (st : s≠t) (inner : farNonports S.L a b G={s,t})
    (showI : farNonports S.L a b G⊆secondA G S.L a)
    (opts : G.Adj s t ∨
      (2≤(S.localA.filter (G.Adj s)).card ∧ 2≤(S.localA.filter (G.Adj t)).card)) :
    ∃ x∈S.localA,RouteOn G (S.localA∪farNonports S.L a b G) x t := by
  classical
  let A := S.localA
  let I := farNonports S.L a b G
  let U := A∪I
  let J := completeWith G A
  letI : DecidableRel J.Adj := Classical.decRel _
  have ac : CompleteOn J A := completeWith_of_mem G A
  have i2 : I.card=2 := by change (farNonports S.L a b G).card=2; simp [inner,st]
  have si : s∈I := by change s∈farNonports S.L a b G; simp [inner]
  have ti : t∈I := by change t∈farNonports S.L a b G; simp [inner]
  have ns : s∉A := fun h=>(mem_filter.mp si).2.1 (mem_filter.mp h).2
  have nt : t∉A := fun h=>(mem_filter.mp ti).2.1 (mem_filter.mp h).2
  have uCap : U.card≤6 := (card_union_le A I).trans (by change A.card=4 at a4; omega)
  have constrained (p : V) (pa : p∈A) :
      G.neighborFinset p⊆insert a ((A.erase p)∪I) :=
    bounds_of_local_color_port S far pa (fun q qb=>distance_two_charge_from_no_bridge S pa qb no)
  have hdeg (p : V) (pa : p∈A) (ph : 5≤G.degree p) : 4≤(U.filter (G.Adj p)).card := by
    have sub : G.neighborFinset p⊆insert a (U.filter (G.Adj p)) := by
      intro q qn
      obtain e|m := mem_insert.mp (constrained p pa qn)
      · exact mem_insert.mpr (.inl e)
      have uq : q∈U := (mem_union.mp m).elim (fun ql=>mem_union_left _ (mem_erase.mp ql).2)
        (fun qi=>mem_union_right _ qi)
      exact mem_insert_of_mem (mem_filter.mpr ⟨uq,(mem_neighborFinset G p q).mp qn⟩)
    have n := (card_le_card sub).trans (card_insert_le a _)
    rw [card_neighborFinset_eq_degree] at n
    omega
  have may : (J.Adj s t ∧ ∃ p∈A,J.Adj p s) ∨
      ∃ p∈A,∃ q∈A,∃ r∈A,p≠q ∧ p≠r ∧ q≠r ∧ J.Adj p s ∧ J.Adj s q ∧ J.Adj r t := by
    rcases opts with hit|⟨cs,ct⟩
    · obtain ⟨p,pa,ps⟩ := nonport_a_neighbor S hc far (mem_filter.mp si).1 (mem_inter.mp (showI si)).2
      exact .inl ⟨completeWith_mono G A hit,p,pa,completeWith_mono G A ps⟩
    let X := A.filter (G.Adj s)
    let Y := A.filter (G.Adj t)
    have sub : A.filter (fun p=>5≤G.degree p)⊆X∪Y := by
      intro p pp
      obtain ⟨pa,ph⟩ := mem_filter.mp pp
      have n := far_port_nonport_degree_lower pa (constrained p pa)
      change G.degree p≤A.card+(I.filter (G.Adj p)).card at n
      change A.card=4 at a4
      obtain ⟨w,wm⟩ := card_pos.mp (show 0<(I.filter (G.Adj p)).card by omega)
      obtain ⟨wi,pw⟩ := mem_filter.mp wm
      change w∈farNonports S.L a b G at wi
      rw [inner,mem_insert,mem_singleton] at wi
      rcases wi with rfl|rfl
      · exact mem_union_left _ (mem_filter.mpr ⟨pa,pw.symm⟩)
      exact mem_union_right _ (mem_filter.mpr ⟨pa,pw.symm⟩)
    have cnt := count_high_subset_of_one_low degree A
    have c := card_le_card sub
    change A.card=4 at a4
    obtain ⟨p,px,q,qx,r,ry,pq,pr,qr⟩ := distinct_two_plus_one_contacts X Y cs ct (by omega)
    exact .inr ⟨p,(mem_filter.mp px).1,q,(mem_filter.mp qx).1,r,(mem_filter.mp ry).1,pq,pr,qr,
      completeWith_mono G A (mem_filter.mp px).2.symm,
      completeWith_mono G A (mem_filter.mp qx).2,
      completeWith_mono G A (mem_filter.mp ry).2.symm⟩
  obtain ⟨x,xa,route⟩ := two_inners_core_route (G:=J) A a4 ac ns nt st may
  have eq : A∪({s,t} : Finset V)=U := by change A∪{s,t}=A∪farNonports S.L a b G; rw [inner]
  have lift : RouteOn J U x t := eq ▸ route
  have ans := terminal_clique_fill_on_finset U A (mem_union_left _ xa) (mem_union_right _ ti)
    (fun u ua v va uv noE=>by
      obtain ⟨uh,vh⟩ := four_a_two_inner_ore_pairs S hc far even degree a4 b3 b4 i2 foreign no u ua v va uv noE
      have um := hdeg u ua uh
      have vm := hdeg v va vh
      omega) lift
  exact ⟨x,xa,ans⟩

#print axioms four_a_two_inner_prescribed_end
end Graffiti189LongestPath.CrossSaturation.Split.Five
