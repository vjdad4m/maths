import DegreeFiveSixFourBlocks189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private left_boundary from AdjacentCut189
open private not_common from DegreeFiveFourPort189
open private d2 from CrossSaturation189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem two_ports_internal_peripheral_degree (two : S.localA.card=2)
    {u : V} (ue : u∈S.L\S.localA) (hi : 5≤G.degree u) :
    2≤((S.L\S.localA).filter (G.Adj u)).card := by
  classical
  obtain ⟨ul,ua⟩ := mem_sdiff.mp ue
  have au : ¬G.Adj a u := fun h=>ua (mem_filter.mpr ⟨ul,h⟩)
  have sub : G.neighborFinset u⊆insert b (S.localA∪((S.L\S.localA).filter (G.Adj u))) := by
    intro v vm
    have uv := (mem_neighborFinset G u v).mp vm
    rcases left_boundary S u ul v uv with rfl|rfl|vl
    · exact (au uv.symm).elim
    · exact mem_insert_self _ _
    by_cases vp : v∈S.localA
    · exact mem_insert_of_mem (mem_union_left _ vp)
    exact mem_insert_of_mem (mem_union_right _ (mem_filter.mpr ⟨mem_sdiff.mpr ⟨vl,vp⟩,uv⟩))
  have n := (card_le_card sub).trans (card_insert_le b _)
  have k := card_union_le S.localA ((S.L\S.localA).filter (G.Adj u))
  rw [card_neighborFinset_eq_degree] at n
  omega

theorem peripheral_card_at_least_three (far : 3≤G.dist a b)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    (two : S.localA.card=2) : 3≤(S.L\S.localA).card := by
  classical
  obtain ⟨u,uu,v,vv,uv⟩ := one_lt_card.mp (show 1<S.localA.card by omega)
  have card : (S.L\S.localA).card+S.localA.card=S.L.card :=
    card_sdiff_add_card_eq_card (filter_subset _ _)
  have size {p : V} (pa : p∈S.localA) : G.degree p≤S.L.card := by
    obtain ⟨pl,ap⟩ := mem_filter.mp pa
    have sub : G.neighborFinset p⊆insert a (S.L.erase p) := by
      intro q qq
      have ne := (mem_neighborFinset G p q).mp qq
      rcases left_boundary S p pl q ne with rfl|rfl|ql
      · exact mem_insert_self _ _
      · exact (not_common far ap ne.symm).elim
      exact mem_insert_of_mem (mem_erase.mpr ⟨ne.ne.symm,ql⟩)
    have n := (card_le_card sub).trans (card_insert_le a _)
    rw [card_neighborFinset_eq_degree,card_erase_of_mem pl] at n
    have pos := card_pos.mpr ⟨p,pl⟩
    omega
  have um := size uu
  have vm := size vv
  exact (degree u v uv).elim (fun h=>by omega) (fun h=>by omega)

theorem clique_of_three_internal_high {E : Finset V} (three : E.card=3)
    (wide : ∀ x∈E,∀ y∈E,x≠y → 2≤(E.filter (G.Adj x)).card ∨ 2≤(E.filter (G.Adj y)).card) :
    CompleteOn G E := by
  classical
  intro x xe y ye xy
  have hit (u : V) (ue : u∈E) (hi : 2≤(E.filter (G.Adj u)).card) :
      ∀ v∈E,u≠v → G.Adj u v := by
    have sub : E.filter (G.Adj u)⊆E.erase u := by
      intro w wm
      obtain ⟨we,uw⟩ := mem_filter.mp wm
      exact mem_erase.mpr ⟨uw.ne.symm,we⟩
    have eq := eq_of_subset_of_card_le sub (by rw [card_erase_of_mem ue,three]; omega)
    exact fun v ve ne=>(mem_filter.mp (eq.symm ▸ mem_erase.mpr ⟨ne.symm,ve⟩)).2
  exact (wide x xe y ye xy).elim (fun h=>hit x xe h y ye xy)
    (fun h=>(hit y ye h x xe xy.symm).symm)

#print axioms two_ports_internal_peripheral_degree
#print axioms peripheral_card_at_least_three
#print axioms clique_of_three_internal_high
end Graffiti189LongestPath.CrossSaturation.Split.Five
