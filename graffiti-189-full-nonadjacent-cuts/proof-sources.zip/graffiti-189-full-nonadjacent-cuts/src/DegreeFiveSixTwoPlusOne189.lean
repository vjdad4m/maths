import DegreeFiveSixTwoInnerCoreRoute189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open Finset
variable {V : Type*} [DecidableEq V]

/-- Three distinct contacts can be assigned 2+1 whenever each of two
contact sets has at least two vertices and their union has at least three. -/
theorem distinct_two_plus_one_contacts (X Y : Finset V)
    (x2 : 2≤X.card) (y2 : 2≤Y.card) (union3 : 3≤(X∪Y).card) :
    ∃ p∈X,∃ q∈X,∃ r∈Y,p≠q ∧ p≠r ∧ q≠r := by
  classical
  by_cases h : Y⊆X
  · rw [union_eq_left.mpr h] at union3
    obtain ⟨r,ry⟩ := card_pos.mp (show 0<Y.card by omega)
    have rx := h ry
    have card : 1<(X.erase r).card := by rw [card_erase_of_mem rx]; omega
    obtain ⟨p,pm,q,qm,pq⟩ := one_lt_card.mp card
    obtain ⟨pr,px⟩ := mem_erase.mp pm
    obtain ⟨qr,qx⟩ := mem_erase.mp qm
    exact ⟨p,px,q,qx,r,ry,pq,pr,qr⟩
  have some : ∃ r∈Y,r∉X := by
    apply Classical.byContradiction
    intro nope
    exact h (fun r ry=>Classical.byContradiction (fun nr=>nope ⟨r,ry,nr⟩))
  obtain ⟨r,ry,rx⟩ := some
  obtain ⟨p,px,q,qx,pq⟩ := one_lt_card.mp (show 1<X.card by omega)
  exact ⟨p,px,q,qx,r,ry,pq,(fun e=>rx (e ▸ px)),fun e=>rx (e ▸ qx)⟩

#print axioms distinct_two_plus_one_contacts
end Graffiti189LongestPath.CrossSaturation.Split.Five
