import DegreeFiveSixTwoFourProfiles189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph Finset
open private foreign_subset from CrossSaturation189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem local_distance_two_at_foreign_two (hc : G.Connected)
    (even : ∀ z,(EvenFrom G z).card≤6) (two : S.foreignA.card=2)
    {p : V} (pl : p∈S.L) (ap : G.Adj a p) {W : Finset V}
    (whereW : W⊆insert b S.L) (charge : W⊆DistanceTwo G p) : W.card≤3 := by
  classical
  have dis : Disjoint S.foreignA W := by
    apply disjoint_left.mpr
    intro x xf xw
    have xr := (mem_filter.mp xf).1
    exact (mem_insert.mp (whereW xw)).elim (fun e=>S.rightOff.2 (e ▸ xr))
      (fun xl=>disjoint_left.mp S.dis xl xr)
  have near : S.foreignA⊆DistanceTwo G p := fun _ x=>foreign_subset S hc pl ap x
  have n := (card_le_card (union_subset near charge)).trans (distanceTwo_le_of_even 5 p (even p))
  rw [card_union_of_disjoint dis,two] at n
  omega

#print axioms local_distance_two_at_foreign_two
end Graffiti189LongestPath.CrossSaturation.Split.Five
