import DegreeFiveSixOneBridgeSmall189

namespace Graffiti189LongestPath.CrossSaturation.Split.Five
open SimpleGraph SimpleGraph.Walk Finset
open private d2 from CrossSaturation189
open private not_common from DegreeFiveFourPort189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V} (S : Split G a b)
set_option linter.unusedSectionVars false

theorem two_charges_force_full_on_visible (hc : G.Connected) (far : 3≤G.dist a b)
    (even : ∀ z,(EvenFrom G z).card≤6) (foreign : S.foreignA.card=3)
    {p : V} (pa : p∈S.localA) {W : Finset V} (W2 : W.card=2)
    (wg : W⊆insert b (S.L.filter (G.Adj b))) (charge : W⊆DistanceTwo G p) :
    (∀ q∈S.localA,p≠q → G.Adj p q) ∧ (∀ q∈farNonports S.L a b G, q ∈ secondA G S.L a → G.Adj p q) := by
  obtain ⟨pl,ap⟩ := mem_filter.mp pa
  have fresh (q : V) (ql : q∈S.L) (qb : ¬G.Adj b q) (q2 : q∈DistanceTwo G p) : False := by
    have qw : q∉W := by
      intro qW
      rcases mem_insert.mp (wg qW) with h|h
      · exact S.leftOff.2 (h ▸ ql)
      exact qb (mem_filter.mp h).2
    have wh : W⊆insert b S.L := by
      intro w ww
      rcases mem_insert.mp (wg ww) with e|e
      · exact mem_insert.mpr (.inl e)
      exact mem_insert_of_mem (mem_filter.mp e).1
    have lead := local_distance_two_at_foreign_three S hc even foreign pl ap
      (insert_subset_iff.mpr ⟨mem_insert_of_mem ql,wh⟩) (insert_subset_iff.mpr ⟨q2,charge⟩)
    rw [card_insert_of_not_mem qw,W2] at lead
    omega
  have clique (q : V) (qa : q∈S.localA) (pq : p≠q) : G.Adj p q := by
    obtain ⟨ql,aq⟩ := mem_filter.mp qa
    apply Classical.byContradiction
    intro no
    exact fresh q ql (not_common far aq) (d2 hc pq no ap.symm aq)
  refine ⟨clique,?_⟩
  intro q qi vis
  obtain ⟨ql,aq,bq⟩ := mem_filter.mp qi
  apply Classical.byContradiction
  intro no
  have pq : p≠q := fun eq=>aq (eq ▸ ap)
  obtain ⟨r,ra,rq⟩ := nonport_a_neighbor S hc far ql (mem_inter.mp vis).2
  have pr : p≠r := fun eq=>no (eq.symm ▸ rq)
  exact fresh q ql bq (d2 hc pq no (clique r ra pr) rq)

#print axioms two_charges_force_full_on_visible
end Graffiti189LongestPath.CrossSaturation.Split.Five
