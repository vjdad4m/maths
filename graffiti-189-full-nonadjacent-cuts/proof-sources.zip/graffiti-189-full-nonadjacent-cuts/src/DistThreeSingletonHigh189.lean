import DegreeFiveActualCut189
import DegreeFiveDistanceTwoThreeClose189
import CrossSaturation189

namespace Graffiti189LongestPath.CrossSaturation.FiveActualCut
open SimpleGraph Finset
open private CutGraph Shore shore_off shore_disjoint shore_hit_a shore_closed shore_connected from DegreeFiveActualCut189
open private secondShore from DegreeFiveDistanceTwoThreeClose189
open private d2 from CrossSaturation189
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- A unique b-port facing four foreign b-ports cannot be low. The
bridge and nonbridge cases use the same distance-two budget. -/
theorem singleton_port_high_opposite_four {a b : V}
    (hc : G.Connected) (far : 3≤G.dist a b) (even : ∀ x,(EvenFrom G x).card≤6)
    (conn : ∀ R : Finset V,R.card<2 → (G.induce ((↑R : Set V)ᶜ)).Connected)
    (degree : ∀ u v : V,u≠v → 5≤G.degree u ∨ 5≤G.degree v)
    {C D : (CutGraph (G:=G) a b).ConnectedComponent} (cd : C≠D)
    {q : V} (qc : q∈Shore C) (bq : G.Adj b q)
    (only : ∀ z∈Shore C,G.Adj b z → z=q)
    (four : ((Shore D).filter (G.Adj b)).card=4) :
    5≤G.degree q := by
  classical
  by_contra! low
  let Z := (Shore C).filter (G.Adj q)
  let Dp := (Shore D).filter (G.Adj b)
  let Q := secondShore C q
  have ab : a≠b := by intro e; rw [e,dist_self] at far; omega
  have no_pair {u : V} (au : G.Adj a u) (bu : G.Adj b u) : False := by
    have d := G.dist_le (SimpleGraph.Walk.cons au bu.symm.toWalk)
    change G.dist a b≤2 at d
    omega
  have others (z : V) (zq : z≠q) : 5≤G.degree z :=
    (degree z q zq).resolve_right (by omega)
  obtain ⟨p,pc,ap⟩ := shore_hit_a ab conn C
  have pq : p≠q := fun eq => no_pair (eq ▸ ap) bq
  have qD : q∉Shore D := fun h => disjoint_left.mp (shore_disjoint cd) qc h
  have d2D : Dp⊆DistanceTwo G q := by
    intro u um
    obtain ⟨ud,bu⟩ := mem_filter.mp um
    have une : q≠u := fun e => qD (e.symm ▸ ud)
    have no : ¬G.Adj q u := by
      intro qu
      rcases shore_closed C q qc u qu with e|e|e
      · exact (shore_off D).1 (e ▸ ud)
      · exact (shore_off D).2 (e ▸ ud)
      exact disjoint_left.mp (shore_disjoint cd) e ud
    exact d2 hc une no bq.symm bu
  have subQ : Q⊆DistanceTwo G q := inter_subset_right
  have dis : Disjoint Q Dp :=
    (shore_disjoint cd).mono inter_subset_left (filter_subset _ _)
  have cap := distanceTwo_le_of_even 5 q (even q)
  have budget := card_le_card (union_subset subQ d2D)
  rw [card_union_of_disjoint dis] at budget
  have four' : Dp.card=4 := four
  have one : Q.card≤1 := by omega
  have z3 : Z.card≤3 := by
    have zb : b∉Z := fun h => (shore_off C).2 (mem_filter.mp h).1
    have sub : insert b Z⊆G.neighborFinset q := by
      intro z zm
      rcases mem_insert.mp zm with rfl|zm
      · exact (G.mem_neighborFinset ..).mpr bq.symm
      exact (G.mem_neighborFinset ..).mpr (mem_filter.mp zm).2
    have c := card_le_card sub
    rw [card_insert_of_not_mem zb,G.card_neighborFinset_eq_degree] at c
    omega
  let J := G.induce (↑(Shore C) : Set V)
  by_cases bridge : ∃ s∈Shore C,G.Adj a s ∧ G.Adj q s
  · obtain ⟨s,_,as',qs⟩ := bridge
    have noa : ¬G.Adj q a := fun h => no_pair h.symm bq
    have aq : q≠a := fun h => (shore_off C).1 (h ▸ qc)
    have dqa : a∈DistanceTwo G q := d2 hc aq noa qs as'.symm
    have out : a∉Q∪Dp := by
      intro h
      exact (mem_union.mp h).elim (fun h => (shore_off C).1 (mem_inter.mp h).1)
        (fun h => (shore_off D).1 (mem_filter.mp h).1)
    have t := card_le_card (insert_subset dqa (union_subset subQ d2D))
    rw [card_insert_of_not_mem out,card_union_of_disjoint dis] at t
    have empty : Q=∅ := card_eq_zero.mp (by omega)
    have universal (v : V) (vc : v∈Shore C) (vq : v≠q) : G.Adj q v := by
      have go {x y : ↥(↑(Shore C) : Set V)} (w : J.Walk x y) :
          (x.val=q ∨ G.Adj q x.val) → y.val=q ∨ G.Adj q y.val := by
        induction w with
        | nil => exact id
        | @cons x y z xy w ih =>
          intro xq
          apply ih
          rcases xq with rfl|qx
          · exact .inr xy
          by_cases yq : y.val=q
          · exact .inl yq
          by_cases qy : G.Adj q y.val
          · exact .inr qy
          have m : y.val∈Q := mem_inter.mpr ⟨y.property,d2 hc (Ne.symm yq) qy qx xy⟩
          exact (by rw [empty] at m; exact not_mem_empty _ m : False).elim
      obtain ⟨w⟩ := (shore_connected C).preconnected
        (⟨q,qc⟩ : ↥(↑(Shore C) : Set V)) ⟨v,vc⟩
      exact (go w (.inl rfl)).resolve_left vq
    have zEq : Z=(Shore C).erase q := by
      ext v; constructor
      · intro h; obtain ⟨c,e⟩ := mem_filter.mp h
        exact mem_erase.mpr ⟨e.ne.symm,c⟩
      · intro h; obtain ⟨ne,vc⟩ := mem_erase.mp h
        exact mem_filter.mpr ⟨vc,universal v vc ne⟩
    have cardC : (Shore C).card≤4 := by
      rw [zEq,card_erase_of_mem qc] at z3
      exact by omega
    have sub : G.neighborFinset p⊆insert a ((Shore C).erase p) := by
      intro v m
      have pv := (G.mem_neighborFinset ..).mp m
      rcases shore_closed C p pc v pv with h|h|h
      · exact mem_insert.mpr (.inl h)
      · exact (no_pair ap (h ▸ pv.symm)).elim
      exact mem_insert_of_mem (mem_erase.mpr ⟨pv.ne.symm,h⟩)
    have t := (card_le_card sub).trans (card_insert_le _ _)
    rw [G.card_neighborFinset_eq_degree,card_erase_of_mem pc] at t
    have hi := others p pq
    omega
  · have neigh {x y : ↥(↑(Shore C) : Set V)} (w : J.Walk x y) (ne : x≠y) :
        ∃ z : ↥(↑(Shore C) : Set V),J.Adj x z := by
      cases w with
      | nil => exact (ne rfl).elim
      | cons e _ => exact ⟨_,e⟩
    obtain ⟨w⟩ := (shore_connected C).preconnected
      (⟨q,qc⟩ : ↥(↑(Shore C) : Set V)) ⟨p,pc⟩
    obtain ⟨z,qz⟩ := neigh w (fun e => pq (congrArg Subtype.val e).symm)
    have ez : G.Adj q z.val := qz
    have noaz : ¬G.Adj a z.val := fun h => bridge ⟨z.val,z.property,h,ez⟩
    have nobz : ¬G.Adj b z.val := fun h => ez.ne.symm (only z.val z.property h)
    have zz : z.val∈Z := mem_filter.mpr ⟨z.property,ez⟩
    have sub : G.neighborFinset z.val ⊆ insert q ((Z.erase z.val)∪Q) := by
      intro v vm
      have zv := (G.mem_neighborFinset ..).mp vm
      have vc : v∈Shore C := by
        rcases shore_closed C z.val z.property v zv with h|h|h
        · exact (noaz (h ▸ zv.symm)).elim
        · exact (nobz (h ▸ zv.symm)).elim
        exact h
      by_cases vq : v=q
      · exact mem_insert.mpr (.inl vq)
      apply mem_insert_of_mem
      by_cases qv : G.Adj q v
      · exact mem_union_left _ (mem_erase.mpr ⟨zv.ne.symm,mem_filter.mpr ⟨vc,qv⟩⟩)
      exact mem_union_right _ (mem_inter.mpr ⟨vc,d2 hc (Ne.symm vq) qv ez zv⟩)
    have t := (card_le_card sub).trans (card_insert_le _ _)
    have u := card_union_le (Z.erase z.val) Q
    rw [G.card_neighborFinset_eq_degree] at t
    rw [card_erase_of_mem zz] at u
    have hi := others z.val ez.ne.symm
    omega

#print axioms singleton_port_high_opposite_four
end Graffiti189LongestPath.CrossSaturation.FiveActualCut
