import FourSeventhsCombined189
import TwoThirdsDeficitAll189
import Mathlib.Data.Fintype.EquivFin
import FanLower189
import HookRetarget189
import FlexibleSpacing189
import FanWeighted189
import OneExceptionTerminal189
import StrongDonorDegree189
import Mathlib.Algebra.BigOperators.Ring.Finset
import FlexSplitShell189
import Mathlib.Tactic.FinCases
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import ThreeFifthsDeficit189

/- source: UniversalExtension189 -/
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.FanRoutable Graffiti189LongestPath.CycleHallSplice Graffiti189LongestPath.StarCycleClosure
set_option maxHeartbeats 4000000
namespace Graffiti189LongestPath.UniversalExtension

variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/- Adding one off-spine vertex to the shore invalidates at most one
hook, because all initial hook paths are disjoint. -/
omit [Fintype V] [DecidableRel G.Adj] in
theorem enlarge_hook_shore (R : Finset V) (x : V) (k : Nat)
    {a b : V} {p : G.Walk a b} (F : HookFamily p R k) :
    ∃ j : Nat,k≤j+1 ∧ Nonempty (HookFamily p (insert x R) j) := by
  classical
  let good := (univ : Finset (Fin k)).filter (fun i => x∉(F.path i).support)
  let bad := (univ : Finset (Fin k))\good
  have bad1 : bad.card≤1 := by
    apply Nat.le_of_not_gt
    intro e
    obtain ⟨i,ii,j,jj,ne⟩ := one_lt_card.mp e
    have ip : x∈(F.path i).support := Classical.byContradiction (fun no =>
      (mem_sdiff.mp ii).2 (mem_filter.mpr ⟨mem_univ _,no⟩))
    have jp : x∈(F.path j).support := Classical.byContradiction (fun no =>
      (mem_sdiff.mp jj).2 (mem_filter.mpr ⟨mem_univ _,no⟩))
    exact F.disj ne ip jp
  have add := card_sdiff_add_card_eq_card (subset_univ good)
  rw [card_univ,Fintype.card_fin] at add
  change bad.card+good.card=k at add
  have ec : Fintype.card (Fin good.card)=Fintype.card ↥good := by
    rw [Fintype.card_fin,Fintype.card_coe]
  let e₀ : Fin good.card ≃ ↥good := Fintype.equivOfCardEq ec
  let e : Fin good.card ↪ Fin k := e₀.toEmbedding.trans ⟨Subtype.val,Subtype.val_injective⟩
  have eg (i : Fin good.card) : e i∈good := (e₀ i).property
  refine ⟨good.card,by omega,⟨?_⟩⟩
  exact {
    idx := e.trans F.idx
    root := fun i => F.root (e i)
    last := fun i => F.last (e i)
    path := fun i => F.path (e i)
    simple := fun i => F.simple (e i)
    idxLt := fun i => F.idxLt (e i)
    adjLast := fun i => F.adjLast (e i)
    firstIn := fun i => mem_insert_of_mem (F.firstIn (e i))
    single := fun i z zs za => (mem_insert.mp za).elim
      (fun h => ((mem_filter.mp (eg i)).2 (h ▸ zs)).elim)
      (F.single (e i) z zs)
    off := fun i => F.off (e i)
    disj := by intro i j ne; exact F.disj (fun w => ne (e.injective w)) }

omit [Fintype V] [DecidableRel G.Adj] in
theorem routes_of_cycle_in_universal_extension (R : Finset V) (x : V) (xr : x∉R)
    (adj : ∀ v∈R,G.Adj x v)
    (robust : ∀ S : Finset ↥(R:Set V),S.card<2 →
      ((G.induce (R:Set V)).induce ((↑S:Set _)ᶜ)).Connected)
    (len : Nat)
    (cyc : ∃ z,∃ c : (G.induce (R:Set V)).Walk z z,c.IsCycle ∧ max 2 len≤c.length) :
    ∀ u∈insert x R,∀ v∈insert x R,u≠v →
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈insert x R) ∧ len+1≤q.length+1 := by
  classical
  let Z := (R:Set V)
  let J := G.induce Z
  let f : J →g G := ⟨Subtype.val,fun e => e⟩
  have fi : Function.Injective f := Subtype.val_injective
  have off (z : Z) : x≠f z := fun e => xr (e.symm ▸ z.property)
  have edge (z : Z) : G.Adj x (f z) := adj z z.property
  obtain ⟨a,c,hc,cl⟩ := cyc
  have big : 2≤c.support.toFinset.card := by
    rw [cycle_card_support c hc]
    exact (le_max_left _ _).trans cl
  have L : len≤c.length := (le_max_right _ _).trans cl
  intro u uu v vv ne
  have into (z : V) (e : z=x∨∃ w : Z,f w=z) : z∈insert x R := by
    rcases e with rfl|⟨w,rfl⟩
    · exact mem_insert_self _ _
    · exact mem_insert_of_mem w.property
  by_cases hu : u=x
  · subst u
    have vR := (mem_insert.mp vv).resolve_left ne.symm
    let t : Z := ⟨v,vR⟩
    obtain ⟨q,qp,ql,qs⟩ := cycle_to_prescribed_root_route f fi off edge c hc
      (t:=t) (fun s h => robust s (by omega))
    exact ⟨q,qp,fun z hz => into z (qs z hz),by omega⟩
  have uR := (mem_insert.mp uu).resolve_left hu
  by_cases hv : v=x
  · subst v
    let t : Z := ⟨u,uR⟩
    obtain ⟨q,qp,ql,qs⟩ := cycle_to_prescribed_root_route f fi off edge c hc
      (t:=t) (fun s h => robust s (by omega))
    exact ⟨q.reverse,qp.reverse,fun z hz => into z (qs z (by
      simpa only [support_reverse,List.mem_reverse] using hz)),by simpa using (by omega : len+1≤q.length+1)⟩
  let s : Z := ⟨u,uR⟩
  let t : Z := ⟨v,(mem_insert.mp vv).resolve_left hv⟩
  have uv : s≠t := fun e => ne (congrArg Subtype.val e)
  obtain ⟨q,qp,ql,qs⟩ := cycle_to_prescribed_route f fi uv off edge c hc big robust
  exact ⟨q,qp,fun z hz => into z (qs z hz),by omega⟩

#print axioms enlarge_hook_shore
#print axioms routes_of_cycle_in_universal_extension
end Graffiti189LongestPath.UniversalExtension

/- source: LargeRobustShore189 -/
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.MengerRoutable
open Graffiti189LongestPath.FanWeighted Graffiti189LongestPath.PosaOneLow
open Graffiti189LongestPath.UniversalExtension
set_option maxHeartbeats 6000000
namespace Graffiti189LongestPath.LargeRobustShore

variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- In the normalized high-root regime, a shore of at least k vertices
which is 2-connected after deleting the root and the spare cut vertex
cannot occur in a counterexample. It is enough to route hooks from that
shore itself, discarding the single one that may touch the universal root. -/
theorem robust_large_shore_impossible (k s h loss H : Nat) (hk : 100≤k)
    (margin : k+s+60≤2*k) (lossK : loss+6≤k) (hlarge : k+loss≤h)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p) (xp : x∉p.support)
    (R : Finset V) (xr : x∉R) (rP : ∀ v∈R,v∉p.support)
    (adj : ∀ v∈R,G.Adj x v) (large : k-6≤R.card) (half : h≤2*R.card+2)
    (ambient : ∀ S : Finset V,S.card<k → (G.induce ((↑S:Set V)ᶜ)).Connected)
    (robust : ∀ S : Finset ↥(R:Set V),S.card<2 →
      ((G.induce (R:Set V)).induce ((↑S:Set _)ᶜ)).Connected)
    (spine : k≤p.support.toFinset.card)
    (floor : ∀ v : ↥(R:Set V),2≤(G.induce (R:Set V)).degree v)
    (high : ∀ u v : ↥(R:Set V),u≠v →
      h≤2*(G.induce (R:Set V)).degree u+loss+5 ∨
      h≤2*(G.induce (R:Set V)).degree v+loss+5)
    (radial : Fintype.card V≤h+k+2*s+H) (shell : 4*H≤(k+s+1)*(k+s+1)) :
    False := by
  classical
  let m := (h-loss-5)/2
  have m2 : 2≤m := by dsimp [m]; omega
  let J := G.induce (R:Set V)
  have high' (u v : ↥(R:Set V)) (ne : u≠v) : m≤J.degree u ∨ m≤J.degree v :=
    (high u v ne).imp (by dsimp [m,J]; omega) (by dsimp [m,J]; omega)
  have rc : Fintype.card ↥(R:Set V)=R.card := Fintype.card_coe R
  obtain ⟨z,c,cc,cl⟩ := proved_one_low_circumference _ J m m2 (by omega) robust floor high'
  have kcycle : k-6≤c.length := by
    have l : k-6≤min (Fintype.card ↥(R:Set V)) (2*m) :=
      le_min (by omega) (by dsimp [m]; omega)
    exact l.trans cl
  have hcycle : h≤R.card+c.length+6 := by
    have lb : h-R.card-6≤min (Fintype.card ↥(R:Set V)) (2*m) :=
      le_min (by omega) (by dsimp [m]; omega)
    have d := lb.trans cl
    omega
  have cycle2 : 2≤c.length := by omega
  let T := insert x R
  have ct : T.card=R.card+1 := card_insert_of_not_mem xr
  have toff (v : V) (vt : v∈T) : v∉p.support :=
    (mem_insert.mp vt).elim (fun e => by subst v; exact xp) (rP v)
  obtain ⟨F⟩ := hooks_of_small_deletion_connectivity R (k-6) hp rP large (by omega)
    (fun S sc => ambient S (by omega))
  obtain ⟨j,jk,⟨FF⟩⟩ := enlarge_hook_shore R x (k-6) F
  have rout := routes_of_cycle_in_universal_extension R x xr adj robust c.length
    ⟨z,c,cc,by omega⟩
  have lower := weighted_hooked_lower j (by omega) hp (c.length+1) T toff (by omega) rout FF
  have lo : R.card+(k-6)+(k-6)*(c.length+1)≤Fintype.card V := by
    have mono := Nat.mul_le_mul_right (c.length+1) jk
    omega
  have partBound : (k-6)*(c.length+1)≤c.length+12+2*s+H := by omega
  have split : (k-6)*(c.length+1)=(k-7)*(c.length+1)+(c.length+1) := by
    calc
      _ = (k-7+1)*(c.length+1) := congrArg (fun z : Nat => z*(c.length+1)) (by omega)
      _ = _ := by rw [Nat.add_mul,one_mul]
  have tall := Nat.mul_le_mul_left (k-7) (show k-5≤c.length+1 by omega)
  have lim : (k-7)*(k-5)≤H+2*s+11 := by omega
  have fact : (k-7)*(k-5)+12*k=k*k+35 := by
    let q := k-7
    have eq : k=q+7 := by dsimp [q]; omega
    have nk : k-5=q+2 := by omega
    rw [nk,show k-7=q from rfl,eq]
    ring
  have db : k+s+1≤2*(k-29) := by omega
  have sq := Nat.mul_le_mul db db
  have expand : (2*(k-29))*(2*(k-29))+232*k=4*(k*k)+3364 := by
    let q := k-29
    have eq : k=q+29 := by dsimp [q]; omega
    rw [show k-29=q from rfl,eq]
    ring
  have a := Nat.mul_le_mul_left 4 lim
  have alo : 4*((k-7)*(k-5))+48*k=4*(k*k)+140 := by
    calc
      _ = 4*((k-7)*(k-5)+12*k) := by ring
      _ = 4*(k*k+35) := congrArg (fun n : Nat => 4*n) fact
      _ = _ := by ring
  have blo : 4*(H+2*s+11)=4*H+8*s+44 := by ring
  omega

#print axioms robust_large_shore_impossible
end Graffiti189LongestPath.LargeRobustShore

/- source: FilterRootHooks189 -/
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.FanRoutable Graffiti189LongestPath.Rigidity
set_option maxHeartbeats 4000000
namespace Graffiti189LongestPath.FilterRootHooks

variable {V : Type*} [DecidableEq V] {G : SimpleGraph V}

theorem retain_regular_roots {a b : V} {p : G.Walk a b} (A X : Finset V) (k : Nat)
    (F : HookFamily p A k) :
    ∃ (j : Nat) (F' : HookFamily p A j),j≤k ∧ k≤j+X.card ∧ ∀ i,F'.root i∈A\X := by
  classical
  let regular := (univ : Finset (Fin k)).filter (fun i => F.root i∉X)
  let cut := (univ : Finset (Fin k))\regular
  have inj : Function.Injective F.root := by
    intro i j eq
    apply Classical.byContradiction
    intro ne
    exact F.disj ne (F.path i).start_mem_support (eq.symm ▸ (F.path j).start_mem_support)
  have subset : cut.image F.root⊆X := by
    intro z zz
    obtain ⟨i,ii,rfl⟩ := mem_image.mp zz
    exact Classical.byContradiction (fun h => (mem_sdiff.mp ii).2 (mem_filter.mpr ⟨mem_univ _,h⟩))
  have bad := card_le_card subset
  rw [card_image_of_injective _ inj] at bad
  have add := card_sdiff_add_card_eq_card (subset_univ regular)
  rw [card_univ,Fintype.card_fin] at add
  change cut.card+regular.card=k at add
  have ec : Fintype.card (Fin regular.card)=Fintype.card ↥regular := by
    rw [Fintype.card_fin,Fintype.card_coe]
  let e₀ : Fin regular.card ≃ ↥regular := Fintype.equivOfCardEq ec
  let e : Fin regular.card ↪ Fin k := e₀.toEmbedding.trans ⟨Subtype.val,Subtype.val_injective⟩
  let T : HookFamily p A regular.card := {
    idx := e.trans F.idx
    root := fun i => F.root (e i)
    last := fun i => F.last (e i)
    path := fun i => F.path (e i)
    simple := fun i => F.simple (e i)
    idxLt := fun i => F.idxLt (e i)
    adjLast := fun i => F.adjLast (e i)
    firstIn := fun i => F.firstIn (e i)
    single := fun i => F.single (e i)
    off := fun i => F.off (e i)
    disj := by intro i j ne; exact F.disj (fun w => ne (e.injective w)) }
  refine ⟨regular.card,T,by omega,by omega,?_⟩
  intro i
  have r : e i∈regular := (e₀ i).property
  exact mem_sdiff.mpr ⟨F.firstIn (e i),(mem_filter.mp r).2⟩

#print axioms retain_regular_roots
end Graffiti189LongestPath.FilterRootHooks

/- source: ColoredFan189 -/
open Finset SimpleGraph SimpleGraph.Walk
open Graffiti189LongestPath Graffiti189LongestPath.Rigidity Graffiti189LongestPath.FanRoutable
open Graffiti189LongestPath.HookRetarget Graffiti189LongestPath.FlexibleSpacing
open Graffiti189LongestPath.EndpointSplice Graffiti189LongestPath.WideWing
open private Graffiti189LongestPath.FanRoutable.path_append_separated from FanLower189
open scoped BigOperators
set_option warningAsError true
set_option maxHeartbeats 6500000
namespace Graffiti189LongestPath.ColoredFan
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

omit [DecidableEq V] [DecidableRel G.Adj] in
private theorem hook_room {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    {A : Finset V} (ao : ∀ z∈A,z∉p.support)
    {i : Nat} (ii : i<p.length) (T : SingleHook p A i)
    {v : V} (q : G.Walk T.root v) (qp : q.IsPath) (qs : ∀ z∈q.support,z∈A) :
    q.length+1≤i ∧ i+q.length+1≤p.length := by
  let r := T.tail.reverse.append q
  have rp : r.IsPath := Graffiti189LongestPath.FanRoutable.path_append_separated T.simple.reverse qp (by
    intro z zr zq
    exact T.onlyRoot z (by simpa only [support_reverse,List.mem_reverse] using zr) (qs z zq))
  have ro : ∀ z∈r.support,z∉p.support := by
    intro z hz
    rw [show r=T.tail.reverse.append q from rfl,support_append,List.mem_append] at hz
    exact hz.elim (fun h => T.off z (by simpa only [support_reverse,List.mem_reverse] using h))
      (fun h => ao z (qs z (List.mem_of_mem_tail h)))
  have e := endpoint_room hp r rp ro ii.le T.finish.symm
  simp only [r,length_append,length_reverse] at e
  omega

omit [DecidableEq V] in
private theorem hook_gap {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    {A : Finset V} (ao : ∀ z∈A,z∉p.support)
    {i j : Nat} (lt : i<j) (ii : i<p.length) (jj : j<p.length)
    (L : SingleHook p A i) (R : SingleHook p A j)
    (ds : List.Disjoint L.tail.support R.tail.support)
    (q : G.Walk L.root R.root) (qp : q.IsPath) (qs : ∀ z∈q.support,z∈A) :
    i+q.length+2≤j := by
  let l := L.tail.reverse.append q
  have lp : l.IsPath := Graffiti189LongestPath.FanRoutable.path_append_separated L.simple.reverse qp (by
    intro z zl zq
    exact L.onlyRoot z (by simpa only [support_reverse,List.mem_reverse] using zl) (qs z zq))
  let w := l.append R.tail
  have wp : w.IsPath := Graffiti189LongestPath.FanRoutable.path_append_separated lp R.simple (by
    intro z zl zr
    rw [show l=L.tail.reverse.append q from rfl,support_append,List.mem_append] at zl
    rcases zl with h|h
    · exact (ds (by simpa only [support_reverse,List.mem_reverse] using h) zr).elim
    · exact R.onlyRoot z zr (qs z (List.mem_of_mem_tail h)))
  have wo : ∀ z∈w.support,z∉p.support := by
    intro z hz
    rw [show w=l.append R.tail from rfl,support_append,List.mem_append] at hz
    rcases hz with hl|hr
    · rw [show l=L.tail.reverse.append q from rfl,support_append,List.mem_append] at hl
      exact hl.elim (fun h => L.off z (by simpa only [support_reverse,List.mem_reverse] using h))
        (fun h => ao z (qs z (List.mem_of_mem_tail h)))
    · exact R.off z (List.mem_of_mem_tail hr)
  have pi : i∈Pins p L.last := mem_filter.mpr ⟨mem_range.mpr ii,L.finish⟩
  have pj : j∈Pins p R.last := mem_filter.mpr ⟨mem_range.mpr jj,R.finish⟩
  have g := terminal_length_le_gap hp pi pj lt w wp wo
  simp only [w,l,length_append,length_reverse] at g
  omega

/-- A first port hitting two colors can always retarget to the color
opposite the next hook's root. The paths and the counted shore still
live in A; only their terminal set R is restricted. -/
theorem colored_flexible_hooked_lower (k H M : Nat) (kp : 0<k)
    {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    (A R : Finset V) (ao : ∀ z∈A,z∉p.support)
    (sub : R⊆A) (large : 1<R.card) (label : V→Nat)
    (route : ∀ u∈R,∀ v∈R,u≠v →
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈A) ∧ H≤q.length+1)
    (cross : ∀ u∈R,∀ v∈R,label u≠label v →
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈A) ∧ H+M≤q.length+1)
    (F : HookFamily p A k) (reg : ∀ i,F.root i∈R) :
    let flex := (univ : Finset (Fin k)).filter (fun i =>
      ∃ u∈R,∃ v∈R,G.Adj u (fromFamily F i).firstPort ∧
        G.Adj v (fromFamily F i).firstPort ∧ label u≠label v)
    A.card+k+(k+1)*H+flex.card*M≤Fintype.card V := by
  classical
  let ok (i : Fin k) := ∃ u∈R,∃ v∈R,G.Adj u (fromFamily F i).firstPort ∧
    G.Adj v (fromFamily F i).firstPort ∧ label u≠label v
  let g (i : Fin k) := if ok i then M else 0
  let I := (univ:Finset (Fin k)).map F.idx
  have sz : I.card=k := by simp [I]
  have roots_ne {i j : Fin k} (ne : i≠j) : F.root i≠F.root j := by
    intro e
    exact F.disj ne (F.path i).start_mem_support (e.symm ▸ (F.path j).start_mem_support)
  have retarget_disjoint {i j : Fin k} (ij : i≠j)
      (K : SingleHook p A (F.idx i))
      (ch : ∀ w∉A,w∈K.tail.support ↔ w∈(F.path i).support)
      (ne : K.root≠F.root j) : List.Disjoint K.tail.support (F.path j).support := by
    intro z zi zj
    by_cases za : z∈A
    · exact ne ((K.onlyRoot z zi za).symm.trans (F.single j z zj za))
    exact F.disj ij ((ch z za).mp zi) zj
  have baseline_room (i : Fin k) : H≤F.idx i ∧ F.idx i+H≤p.length := by
    obtain ⟨v,va,ne⟩ := exists_ne_of_one_lt_card large (F.root i)
    obtain ⟨r,rp,rs,rl⟩ := route (F.root i) (reg i) v va ne.symm
    have d := hook_room hp ao (F.idxLt i) (fromFamily F i) r rp rs
    omega
  have long_room (i : Fin k) (h : ok i) : F.idx i+H+M≤p.length := by
    obtain ⟨u,ur,v,vr,ue,_,ne⟩ := h
    obtain ⟨K,kr,_,_⟩ := retarget_first_port (fromFamily F i) ao u (sub ur) ue
    obtain ⟨q,qp,qs,ql⟩ := cross u ur v vr ne
    let s : G.Walk K.root v := q.copy kr.symm rfl
    have sp : s.IsPath := by simpa [s] using qp
    have ss : ∀ z∈s.support,z∈A := by simpa [s] using qs
    have sl : H+M≤s.length+1 := by simpa [s] using ql
    have d := hook_room hp ao (F.idxLt i) K s sp ss
    omega
  have base_gap (i j : Fin k) (ij : F.idx i<F.idx j) : F.idx i+H+1≤F.idx j := by
    have ne : i≠j := fun e => (Nat.lt_irrefl _) (e ▸ ij)
    obtain ⟨q,qp,qs,ql⟩ := route (F.root i) (reg i) (F.root j) (reg j) (roots_ne ne)
    have g := hook_gap hp ao ij (F.idxLt i) (F.idxLt j) (fromFamily F i) (fromFamily F j)
      (F.disj ne) q qp qs
    omega
  have long_gap (i j : Fin k) (ij : F.idx i<F.idx j) (fi : ok i) :
      F.idx i+H+1+M≤F.idx j := by
    have ne : i≠j := fun e => (Nat.lt_irrefl _) (e ▸ ij)
    have find : ∃ u∈A,G.Adj u (fromFamily F i).firstPort ∧ u≠F.root j ∧
        ∃ q : G.Walk u (F.root j),q.IsPath ∧ (∀ z∈q.support,z∈A) ∧ H+M≤q.length+1 := by
      obtain ⟨u,ur,v,vr,ue,ve,diff⟩ := fi
      by_cases same : label u=label (F.root j)
      · have vn : label v≠label (F.root j) := fun eq => diff (same.trans eq.symm)
        exact ⟨v,sub vr,ve,fun e => vn (congrArg label e),cross _ vr _ (reg j) vn⟩
      · exact ⟨u,sub ur,ue,fun e => same (congrArg label e),cross _ ur _ (reg j) same⟩
    obtain ⟨u,ua,ue,uj,q,qp,qs,ql⟩ := find
    obtain ⟨K,kr,_,ch⟩ := retarget_first_port (fromFamily F i) ao u ua ue
    let r : G.Walk K.root (F.root j) := q.copy kr.symm rfl
    have rp : r.IsPath := by simpa [r] using qp
    have rs : ∀ z∈r.support,z∈A := by simpa [r] using qs
    have rl : H+M≤r.length+1 := by simpa [r] using ql
    have g := hook_gap hp ao ij (F.idxLt i) (F.idxLt j) K (fromFamily F j)
      (retarget_disjoint ne K ch (fun e => uj (kr.symm.trans e))) r rp rs
    omega
  let gf (j : Nat) := if hj : ∃ i,F.idx i=j then g (Classical.choose hj) else 0
  let lf (_j : Nat) : Nat := 0
  have ge (i : Fin k) : gf (F.idx i)=g i := by
    have hj : ∃ j,F.idx j=F.idx i := ⟨i,rfl⟩
    dsimp [gf]; rw [dif_pos hj,F.idx.injective (Classical.choose_spec hj)]
  have bas := one_sided_weighted_span H p.length I gf lf (by omega : 0<I.card)
    (by intro i hi; obtain ⟨j,_,rfl⟩ := mem_map.mp hi; exact (baseline_room j).1)
    (by
      intro i hi
      obtain ⟨j,_,rfl⟩ := mem_map.mp hi
      rw [ge]
      by_cases q : ok j
      · simpa [g,q] using long_room j q
      · simpa [g,q] using (baseline_room j).2)
    (by
      intro i hi j hj e
      obtain ⟨u,_,rfl⟩ := mem_map.mp hi
      obtain ⟨v,_,rfl⟩ := mem_map.mp hj
      rw [ge]
      by_cases fi : ok u
      · simpa [g,lf,fi] using long_gap u v e fi
      · have h := base_gap u v e
        simpa [g,lf,fi] using h)
  let U := (univ:Finset (Fin k)).filter ok
  have sg : (∑ i∈I,gf i)=U.card*M := by
    rw [show (∑ i∈I,gf i)=∑ i : Fin k,g i by simp [I,sum_map,ge]]
    change (∑ i ∈ (univ:Finset (Fin k)), if ok i then M else 0)=_
    rw [←Finset.sum_filter]
    exact Finset.sum_const_nat (fun _ _ => rfl)
  rw [sz,sg] at bas
  simp [lf] at bas
  have dj : Disjoint A p.support.toFinset := disjoint_left.mpr (fun _ h g => ao _ h (List.mem_toFinset.mp g))
  have room := card_le_univ (A∪p.support.toFinset)
  rw [card_union_of_disjoint dj,List.toFinset_card_of_nodup hp.1.support_nodup,length_support] at room
  change A.card+k+(k+1)*H+U.card*M≤Fintype.card V
  omega

#print axioms colored_flexible_hooked_lower
end Graffiti189LongestPath.ColoredFan

/- source: SmallShoreOre189 -/
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.OneExceptionTerminal
open private Graffiti189LongestPath.GreedyTerminal.push_end from QuadraticDeficitAll189
open private Graffiti189LongestPath.FanRoutable.path_append_separated from FanLower189
set_option maxHeartbeats 4500000
namespace Graffiti189LongestPath.SmallShoreOre

variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

omit [Fintype V] in
theorem side_ore_paths (R : Finset V) (m : Nat)
    (small : R.card+1≤2*m)
    (floor : ∀ z : ↥(R:Set V),3≤(G.induce (R:Set V)).degree z)
    (pair : ∀ u v : ↥(R:Set V),u≠v →
      m≤(G.induce (R:Set V)).degree u ∨ m≤(G.induce (R:Set V)).degree v) :
    ∀ u∈R,∀ v∈R,u≠v → ∃ q : G.Walk u v,
      q.IsPath ∧ (∀ z∈q.support,z∈R) ∧ q.length+1=R.card := by
  classical
  intro u ur v vr une
  let J := G.induce (R:Set V)
  let a : ↥(R:Set V) := ⟨u,ur⟩
  let b : ↥(R:Set V) := ⟨v,vr⟩
  have ne : a≠b := fun e => une (congrArg Subtype.val e)
  obtain ⟨z,hz⟩ : ∃ z : ↥(R:Set V),∀ v : ↥(R:Set V),v≠z → m≤J.degree v := by
    by_cases bad : ∃ z : ↥(R:Set V),J.degree z<m
    · obtain ⟨z,lz⟩ := bad
      exact ⟨z,fun w wz => (pair w z wz).resolve_right (Nat.not_le_of_lt lz)⟩
    · exact ⟨a,fun w _ => Nat.le_of_not_gt (fun e => bad ⟨w,e⟩)⟩
  have rc : Fintype.card ↥(R:Set V)=R.card := Fintype.card_coe R
  have ore (s t : ↥(R:Set V)) (_ne : s≠t) (sz : s≠z) (tz : t≠z) (_no : ¬J.Adj s t) :
      Fintype.card ↥(R:Set V)+1≤J.degree s+J.degree t := by
    have hs := hz s sz
    have ht := hz t tz
    omega
  obtain ⟨q,hq,all⟩ := terminal_ore_one_exception (G:=J) z (floor z) ore ne
  have full : q.support.toFinset=univ := by
    ext i
    simp [all i]
  have len : q.length+1=R.card := by
    have card := congrArg Finset.card full
    rw [List.toFinset_card_of_nodup hq.support_nodup,length_support,card_univ,rc] at card
    exact card
  let f : J →g G := ⟨Subtype.val,fun e => e⟩
  refine ⟨q.map f,map_isPath_of_injective Subtype.val_injective hq,?_,by simpa only [length_map] using len⟩
  intro w ww
  rw [support_map] at ww
  obtain ⟨z,_,rfl⟩ := List.mem_map.mp ww
  exact z.property

/- Two terminal Ore shores splice into a path spanning both shores and
the universal root, with prescribed endpoints in opposite shores. -/
omit [Fintype V] [DecidableEq V] [DecidableRel G.Adj] in
theorem ore_cross_shore_route (A C E : Finset V)
    (x : V) (xa : x∈A) (xc : x∉C) (xe : x∉E)
    (ca : C⊆A) (ea : E⊆A) (ce : Disjoint C E)
    (root : ∀ z∈A,z≠x → G.Adj x z)
    (cn : 1<C.card) (en : 1<E.card)
    (rC : ∀ u∈C,∀ v∈C,u≠v → ∃ q : G.Walk u v,
      q.IsPath ∧ (∀ z∈q.support,z∈C) ∧ q.length+1=C.card)
    (rE : ∀ u∈E,∀ v∈E,u≠v → ∃ q : G.Walk u v,
      q.IsPath ∧ (∀ z∈q.support,z∈E) ∧ q.length+1=E.card)
    (u : V) (uc : u∈C) (v : V) (ve : v∈E) :
    ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈A) ∧
      C.card+E.card+1=q.length+1 := by
  classical
  obtain ⟨u',ucz,unz⟩ := exists_ne_of_one_lt_card cn u
  obtain ⟨v',vez,vnz⟩ := exists_ne_of_one_lt_card en v
  obtain ⟨l,lp,ls,ll⟩ := rC u uc u' ucz unz.symm
  obtain ⟨r,rp,rs,rl⟩ := rE v ve v' vez vnz.symm
  have uc' := ls _ l.end_mem_support
  have ve' := rs _ r.end_mem_support
  have xu := root u' (ca uc') (fun e => xc (e ▸ uc'))
  have xv := root v' (ea ve') (fun e => xe (e ▸ ve'))
  obtain ⟨l',lp',ll',ls'⟩ := Graffiti189LongestPath.GreedyTerminal.push_end lp xu.symm (fun h => xc (ls _ h))
  obtain ⟨r',rp',rl',rs'⟩ := Graffiti189LongestPath.GreedyTerminal.push_end rp xv.symm (fun h => xe (rs _ h))
  let w := l'.append r'.reverse
  have wp : w.IsPath := Graffiti189LongestPath.FanRoutable.path_append_separated lp' rp'.reverse (by
    intro z zl zr
    have zr' : z∈r'.support := by simpa only [support_reverse,List.mem_reverse] using zr
    rcases (ls' z).mp zl with zx|zl'
    · exact zx
    rcases (rs' z).mp zr' with zx|zr'
    · exact zx
    exact (disjoint_left.mp ce (ls _ zl') (rs _ zr')).elim)
  have ws (z : V) (zt : z∈w.support) : z∈A := by
    rw [show w=l'.append r'.reverse from rfl,support_append,List.mem_append] at zt
    rcases zt with h|h
    · exact ((ls' z).mp h).elim (fun e => e.symm ▸ xa) (fun h => ca (ls _ h))
    have h' : z∈r'.support := by simpa only [support_reverse,List.mem_reverse] using List.mem_of_mem_tail h
    exact ((rs' z).mp h').elim (fun e => e.symm ▸ xa) (fun h => ea (rs _ h))
  refine ⟨w,wp,ws,?_⟩
  simp only [w,length_append,length_reverse]
  omega

#print axioms side_ore_paths
#print axioms ore_cross_shore_route
end Graffiti189LongestPath.SmallShoreOre

/- source: GeneralCutMisses189 -/
open Finset SimpleGraph Graffiti189LongestPath
open Graffiti189LongestPath.StrongDonorDegree
namespace Graffiti189LongestPath.GeneralCutMisses
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- The sharp non-private reach estimate does not require a two-vertex
cut, and incurs exactly its order as the additive term. -/
theorem missed_boundary_of_side_with_high_vertex (d pp : Nat) (A B C E X : Finset V)
    (part : A=C∪E∪X) (cA : C⊆A)
    (no : ∀ u∈C,∀ v∈E,¬G.Adj u v)
    (closed : ∀ u∈A,∀ z∉A,G.Adj u z → z∈B)
    (bk : B.card+pp≤d+1)
    (v : V) (vc : v∈C) (high : d≤G.degree v) :
    (B.filter (fun z => ¬∃ u∈C,G.Adj u z)).card+pp≤C.card+X.card := by
  classical
  let M := B.filter (fun z => ¬∃ u∈C,G.Adj u z)
  have e := degree_upper_with_forbidden_ports A B C E X M part closed cA no v vc
    (filter_subset _ _) (fun z zm ed => (mem_filter.mp zm).2 ⟨v,vc,ed⟩)
  change M.card+pp≤C.card+X.card
  omega

#print axioms missed_boundary_of_side_with_high_vertex
end Graffiti189LongestPath.GeneralCutMisses

/- source: ThreePortCount189 -/
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.HookRetarget Graffiti189LongestPath.FanRoutable Graffiti189LongestPath.Rigidity
set_option maxHeartbeats 5000000
namespace Graffiti189LongestPath.ThreePortCount
variable {V : Type*} [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- Each nonflexible first port misses at least two of three compatible
shore labels. All first ports are distinct in the specified boundary. -/
theorem two_misses_per_nonflexible_hook (k : Nat) {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    (A B C E T : Finset V) (label : V→Nat)
    (c0 : ∀ v∈C,label v=0) (e1 : ∀ v∈E,label v=1) (t2 : ∀ v∈T,label v=2)
    (closed : ∀ u∈A,∀ v∉A,G.Adj u v → v∈B)
    (ao : ∀ z∈A,z∉p.support) (F : HookFamily p A k) :
    let R := C∪E∪T
    let flex := (univ : Finset (Fin k)).filter (fun i =>
      ∃ u∈R,∃ v∈R,G.Adj u (fromFamily F i).firstPort ∧
        G.Adj v (fromFamily F i).firstPort ∧ label u≠label v)
    2*k≤2*flex.card+(B.filter (fun z => ¬∃ u∈C,G.Adj u z)).card+
      (B.filter (fun z => ¬∃ u∈E,G.Adj u z)).card+(B.filter (fun z => ¬∃ u∈T,G.Adj u z)).card := by
  classical
  let R := C∪E∪T
  let g (i : Fin k) := (fromFamily F i).firstPort
  let good (i : Fin k) := ∃ u∈R,∃ v∈R,G.Adj u (g i) ∧
    G.Adj v (g i) ∧ label u≠label v
  let U := (univ : Finset (Fin k)).filter good
  let Bad := (univ : Finset (Fin k))\U
  let L := Bad.image g
  let reaches (D : Finset V) := L.filter (fun z => ∃ u∈D,G.Adj u z)
  have lb : L⊆B := by
    intro z zz
    obtain ⟨i,_,rfl⟩ := mem_image.mp zz
    exact first_port_mem_boundary (fromFamily F i) ao closed
  have gInj : Function.Injective g := family_first_ports_injective hp F
  have ld : L.card=Bad.card := card_image_of_injective _ gInj
  have exactK := card_sdiff_add_card_eq_card (subset_univ U)
  rw [card_univ,Fintype.card_fin] at exactK
  change Bad.card+U.card=k at exactK
  have forbid (D E : Finset V) (ds : D⊆R) (es : E⊆R)
      (different : ∀ u∈D,∀ v∈E,label u≠label v) :
      Disjoint (reaches D) (reaches E) := by
    apply disjoint_left.mpr
    intro z zd ze
    obtain ⟨zl,u,ud,uz⟩ := mem_filter.mp zd
    obtain ⟨_,v,ve,vz⟩ := mem_filter.mp ze
    obtain ⟨i,ii,rfl⟩ := mem_image.mp zl
    exact (mem_sdiff.mp ii).2 (mem_filter.mpr
      ⟨mem_univ _,u,ds ud,v,es ve,uz,vz,different u ud v ve⟩)
  have cR : C⊆R := fun _ z => mem_union.mpr (Or.inl (mem_union.mpr (Or.inl z)))
  have eR : E⊆R := fun _ z => mem_union.mpr (Or.inl (mem_union.mpr (Or.inr z)))
  have tR : T⊆R := fun _ z => mem_union.mpr (Or.inr z)
  have ce := forbid C E cR eR (fun u uu v vv => by simpa only [c0 u uu,e1 v vv] using (by decide : (0:Nat)≠1))
  have ct := forbid C T cR tR (fun u uu v vv => by simpa only [c0 u uu,t2 v vv] using (by decide : (0:Nat)≠2))
  have et := forbid E T eR tR (fun u uu v vv => by simpa only [e1 u uu,t2 v vv] using (by decide : (1:Nat)≠2))
  have overlap : Disjoint (reaches C∪reaches E) (reaches T) := disjoint_union_left.mpr ⟨ct,et⟩
  have subAll : reaches C∪reaches E∪reaches T⊆L :=
    union_subset (union_subset (filter_subset _ _) (filter_subset _ _)) (filter_subset _ _)
  have upper := card_le_card subAll
  rw [card_union_of_disjoint overlap,card_union_of_disjoint ce] at upper
  have lower (D : Finset V) :
      L.card≤(B.filter (fun z => ¬∃ u∈D,G.Adj u z)).card+(reaches D).card := by
    have q : L\reaches D⊆B.filter (fun z => ¬∃ u∈D,G.Adj u z) := by
      intro z zz
      obtain ⟨zl,nd⟩ := mem_sdiff.mp zz
      exact mem_filter.mpr ⟨lb zl,fun ed => nd (mem_filter.mpr ⟨zl,ed⟩)⟩
    have er := card_sdiff_add_card_eq_card (filter_subset (fun z => ∃ u∈D,G.Adj u z) L)
    change (L\reaches D).card+(reaches D).card=L.card at er
    have p := card_le_card q
    omega
  have loC := lower C
  have loE := lower E
  have loT := lower T
  change 2*k≤2*U.card+(B.filter (fun z => ¬∃ u∈C,G.Adj u z)).card+
      (B.filter (fun z => ¬∃ u∈E,G.Adj u z)).card+(B.filter (fun z => ¬∃ u∈T,G.Adj u z)).card
  omega

#print axioms two_misses_per_nonflexible_hook
end Graffiti189LongestPath.ThreePortCount

/- source: SplitShoreThree189 -/
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.ShoreSplit
set_option maxHeartbeats 4500000
namespace Graffiti189LongestPath.SplitShoreThree

variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

omit [Fintype V] [DecidableRel G.Adj] in
def induced_set_delete_iso (E : Finset V) (S : Finset ↥(E:Set V)) :
    G.induce ((E\S.map ⟨Subtype.val,Subtype.val_injective⟩ : Finset V):Set V) ≃g
      (G.induce (E:Set V)).induce ((↑S:Set _)ᶜ) := by
  classical
  let emb : ↥(E:Set V) ↪ V := ⟨Subtype.val,Subtype.val_injective⟩
  let Y := E\S.map emb
  let Z := (↑S:Set ↥(E:Set V))ᶜ
  let forward (v : ↥(Y:Set V)) : Z := by
    have ve := (mem_sdiff.mp v.property).1
    have vo := (mem_sdiff.mp v.property).2
    let w : ↥(E:Set V) := ⟨v,ve⟩
    exact ⟨w,fun ws => vo (mem_map.mpr ⟨w,ws,rfl⟩)⟩
  let inv (v : Z) : ↥(Y:Set V) := by
    refine ⟨v.val.val,mem_sdiff.mpr ⟨v.val.property,?_⟩⟩
    intro h
    obtain ⟨w,ws,e⟩ := mem_map.mp h
    have h : w=v.val := Subtype.val_injective e
    exact v.property (h ▸ ws)
  exact ⟨⟨forward,inv,by intro a; apply Subtype.ext; rfl,
    by intro a; apply Subtype.ext; apply Subtype.ext; rfl⟩,by intro a b; rfl⟩

omit [Fintype V] [DecidableRel G.Adj] in
theorem split_third_shore_after_one_more_deletion (A C E X : Finset V)
    (part : A=C∪E∪X) (ce : Disjoint C E) (cx : Disjoint C X) (ex : Disjoint E X)
    (no : ∀ u∈C,∀ v∈E,¬G.Adj u v) (en : 1<E.card)
    (bad : ¬∀ S : Finset ↥(E:Set V),S.card<2 → ((G.induce (E:Set V)).induce ((↑S:Set _)ᶜ)).Connected) :
    ∃ (D T Y : Finset V), X⊆Y ∧ Y.card≤X.card+1 ∧
      A=C∪D∪T∪Y ∧ D.Nonempty ∧ T.Nonempty ∧
      Disjoint C D ∧ Disjoint C T ∧ Disjoint D T ∧ Disjoint (C∪D∪T) Y ∧
      (∀ u∈C,∀ v∈D,¬G.Adj u v) ∧ (∀ u∈C,∀ v∈T,¬G.Adj u v) ∧
      (∀ u∈D,∀ v∈T,¬G.Adj u v) := by
  classical
  obtain ⟨S,small,fail⟩ : ∃ S : Finset ↥(E:Set V),S.card<2 ∧
      ¬((G.induce (E:Set V)).induce ((↑S:Set _)ᶜ)).Connected := by
    apply Classical.byContradiction
    intro not
    apply bad
    intro T ts
    exact Classical.byContradiction (fun n => not ⟨T,ts,n⟩)
  let emb : ↥(E:Set V) ↪ V := ⟨Subtype.val,Subtype.val_injective⟩
  let Z := S.map emb
  let Y := X∪Z
  have zE : Z⊆E := by
    intro z zz
    obtain ⟨v,_,rfl⟩ := mem_map.mp zz
    exact v.property
  have zs : Z.card≤1 := by
    change (S.map emb).card≤1
    rw [card_map]
    omega
  have yy : Y.card≤X.card+1 := (card_union_le _ _).trans (Nat.add_le_add_left zs _)
  have n : (E\Z).Nonempty := card_pos.mp (by
    have h := card_sdiff_add_card_eq_card zE
    omega)
  have iso := induced_set_delete_iso (G:=G) E S
  have bn : ¬(G.induce ((E\Z : Finset V):Set V)).Connected := fun e => fail (iso.connected_iff.mp e)
  obtain ⟨D,T,se,dt,nt,dd,tt⟩ := partition_of_not_connected (E\Z) n bn
  have all : A=C∪D∪T∪Y := by
    calc
      A=C∪E∪X := part
      _ = C∪((E\Z)∪Z)∪X := by rw [sdiff_union_of_subset zE]
      _ = C∪(D∪T)∪Z∪X := by rw [se]; ac_rfl
      _ = C∪D∪T∪Y := by unfold Y; ac_rfl
  have dE (z : V) (zd : z∈D) : z∈E\Z := se ▸ mem_union.mpr (Or.inl zd)
  have tE (z : V) (zt : z∈T) : z∈E\Z := se ▸ mem_union.mpr (Or.inr zt)
  have cy : Disjoint C Y := disjoint_union_right.mpr ⟨cx,disjoint_left.mpr
    (fun _ zc zz => disjoint_left.mp ce zc (zE zz))⟩
  have dy : Disjoint D Y := disjoint_union_right.mpr ⟨disjoint_left.mpr
    (fun z zd zx => disjoint_left.mp ex (mem_sdiff.mp (dE z zd)).1 zx),
    disjoint_left.mpr (fun z zd zz => (mem_sdiff.mp (dE z zd)).2 zz)⟩
  have ty : Disjoint T Y := disjoint_union_right.mpr ⟨disjoint_left.mpr
    (fun z zt zx => disjoint_left.mp ex (mem_sdiff.mp (tE z zt)).1 zx),
    disjoint_left.mpr (fun z zt zz => (mem_sdiff.mp (tE z zt)).2 zz)⟩
  exact ⟨D,T,Y,subset_union_left,yy,all,dd,tt,
    disjoint_left.mpr (fun z zc zd => disjoint_left.mp ce zc (mem_sdiff.mp (dE z zd)).1),
    disjoint_left.mpr (fun z zc zt => disjoint_left.mp ce zc (mem_sdiff.mp (tE z zt)).1),
    dt,disjoint_union_left.mpr ⟨disjoint_union_left.mpr ⟨cy,dy⟩,ty⟩,
    fun u uc v vd => no u uc v (mem_sdiff.mp (dE v vd)).1,
    fun u uc v vt => no u uc v (mem_sdiff.mp (tE v vt)).1,nt⟩

omit [Fintype V] in
theorem side_degree_loss (A R X : Finset V) (x : V)
    (no : ∀ u∈R,∀ v∈A, v∉R → v∉X → ¬G.Adj u v)
    (u : V) (ur : u∈R) :
    ((A.erase x).filter (G.Adj u)).card≤(R.filter (G.Adj u)).card+(X.erase x).card := by
  classical
  have s : (A.erase x).filter (G.Adj u)⊆(R.filter (G.Adj u))∪(X.erase x) := by
    intro z zz
    obtain ⟨za,adj⟩ := mem_filter.mp zz
    obtain ⟨zn,za⟩ := mem_erase.mp za
    by_cases zr : z∈R
    · exact mem_union.mpr (Or.inl (mem_filter.mpr ⟨zr,adj⟩))
    by_cases zx : z∈X
    · exact mem_union.mpr (Or.inr (mem_erase.mpr ⟨zn,zx⟩))
    exact (no u ur z za zr zx adj).elim
  exact (card_le_card s).trans (card_union_le _ _)

#print axioms split_third_shore_after_one_more_deletion
#print axioms side_degree_loss
end Graffiti189LongestPath.SplitShoreThree

/- source: GroupedShellMass189 -/
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack Graffiti189LongestPath.PinRun
open Graffiti189LongestPath.ShellDonorFull Graffiti189LongestPath.StrongDonorDegree
open Graffiti189LongestPath.StrongDonorCharge
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
open private Graffiti189LongestPath.pin_data Graffiti189LongestPath.mem_distanceTwo from SmallSeparator189
open private Graffiti189LongestPath.OneSlack.card_pinVertices from OneSlack189
open private Graffiti189LongestPath.FlexSplitShell.count_group from FlexSplitShell189
open scoped BigOperators
set_option maxHeartbeats 10000000

namespace Graffiti189LongestPath.GroupedShellMass

variable {V α : Type*} [Fintype V] [DecidableEq V] [Fintype α]
  {G : SimpleGraph V} [DecidableRel G.Adj]
variable {a b x : V} {p : G.Walk a b}

/-- A common shell-mass accounting lemma for arbitrarily many mutually
nonadjacent shores. This gives the plain mass estimate, and optionally
the private-and-missed-port reserve for each side of a two-vertex cut. -/
theorem grouped_shell_mass (hc : G.Connected) (d : Nat)
    (hp : IsLongest p) (hx : x∉p.support)
    (gap : (Pins p x).card≤(FirstPins p x).card+1)
    (cap : ∀ v,(DistanceTwo G v).card≤d) (M : α→Finset V) (W X : Finset V)
    (part : OmittedStar p x=(univ.biUnion M)∪X)
    (partition : (univ.biUnion M)∪(PinVertices p x)∪W=G.neighborFinset x)
    (dx : Disjoint (univ.biUnion M) X) (xx : x∈X)
    (deg : ∀ u v : V,u≠v → d≤G.degree u ∨ d≤G.degree v)
    (dis : Pairwise (fun i j => Disjoint (M i) (M j)))
    (no : ∀ i j,i≠j → ∀ u∈M i,∀ v∈M j,¬G.Adj u v)
    (bk : (External G (OmittedStar p x)).card+(Pins p x).card≤d+1)
    (highSide : ∀ i,∃ v∈M i,d≤G.degree v) :
    let R := univ.biUnion M
    let pp := (Pins p x).card
    ∃ (k : α→Nat) (t : Nat),t≤pp ∧ (∑ i,k i)+t≤d ∧
      ((Shell G x 3).card + (∑ i,k i*(k i+(R\M i).card+pp))+t*((∑ i,k i)+t)
        ≤(d+2)*(∑ i,k i)+(d+1)*t+(W.card+1)*d) ∧
      (X.card≤2 → ∀ i,k i+pp+
        ((External G (OmittedStar p x)).filter (fun z => ¬∃ v∈M i,G.Adj v z)).card≤(M i).card+3) := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let P := PinVertices p x
  let pp := (Pins p x).card
  let H := Shell G x 3
  let R := univ.biUnion M
  let F := gateThird G x (DistanceTwo G x)
  obtain ⟨D,DA,cover,privateGate,every⟩ := exists_shell_donors_with_private_charges hc d cap x
  let K (i : α) := (D∩M i).filter (fun v => d≤G.degree v)
  let D₀ := univ.biUnion K
  let U := D∩P
  let Q := D\(D₀∪U)
  have parts (i : α) (v : V) (hk : v∈K i) : v∈D ∧ v∈M i ∧ d≤G.degree v := by
    obtain ⟨both,he⟩ := mem_filter.mp hk
    obtain ⟨h₁,h₂⟩ := mem_inter.mp both
    exact ⟨h₁,h₂,he⟩
  have mb (i : α) : M i⊆R := fun z hz => mem_biUnion.mpr ⟨i,mem_univ _,hz⟩
  have sb : R⊆A := by
    intro z zr
    change z∈OmittedStar p x
    rw [part]
    exact mem_union.mpr (Or.inl zr)
  have sD : D₀⊆D := by
    intro z zz
    obtain ⟨i,_,zi⟩ := mem_biUnion.mp zz
    exact (parts i z zi).1
  have sR : D₀⊆R := by
    intro z zz
    obtain ⟨i,_,zi⟩ := mem_biUnion.mp zz
    exact mb i (parts i z zi).2.1
  have tR (i : α) : K i⊆M i := fun v z => (parts i v z).2.1
  have dpart : Set.PairwiseDisjoint (↑(univ:Finset α) : Set α) K := by
    intro i _ j _ ne
    exact disjoint_left.mpr (fun _ ui uj => disjoint_left.mp (dis ne) (tR i ui) (tR j uj))
  have counts : D₀.card=∑ i,(K i).card := card_biUnion dpart
  have pinOff : Disjoint D₀ U := disjoint_left.mpr (by
    intro z zD zU
    obtain ⟨i,_,rfl⟩ := mem_image.mp (mem_inter.mp zU).2
    exact (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp (sb (sR zD))).1
      (p.getVert_mem_support i))
  have cd := card_sdiff_add_card_eq_card (union_subset sD (inter_subset_left : U⊆D))
  rw [card_union_of_disjoint pinOff,counts] at cd
  change Q.card+((∑i,(K i).card)+U.card)=D.card at cd
  have tn : U.card≤pp := (card_le_card (inter_subset_right : U⊆P)).trans
    (le_of_eq (Graffiti189LongestPath.OneSlack.card_pinVertices hp (x:=x)))
  have closed (u : V) (ua : u∈A) (z : V) (za : z∉A) (uz : G.Adj u z) : z∈B :=
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨za,u,ua,uz⟩
  have rep₀ (u : V) : ∃ g,u∈D → g∈DistanceTwo G x ∧ G.Adj u g ∧
      ∀ w∈D,w≠u → ¬G.Adj w g := by
    by_cases h : u∈D
    · obtain ⟨g,gg,ug,bad⟩ := privateGate u h
      exact ⟨g,fun _ => ⟨gg,ug,bad⟩⟩
    · exact ⟨x,fun e => (h e).elim⟩
  choose rep priv using rep₀
  have repr (u : V) (ud : u∈D₀) : rep u∈B := by
    have rd := Graffiti189LongestPath.mem_distanceTwo.mp (priv u (sD ud)).1
    have na : rep u∉A := by
      intro e
      rcases (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp e).2 with h|h
      · rw [h,dist_self] at rd; omega
      · have h' := dist_eq_one_iff_adj.mpr h; omega
    exact closed u (sb (sR ud)) (rep u) na (priv u (sD ud)).2.1
  have inj : Set.InjOn rep (↑D:Set V) := by
    intro u ud v vd e
    apply Classical.byContradiction
    intro ne
    exact (priv v vd).2.2 u ud ne (e ▸ (priv u ud).2.1)
  have allD : (D.image rep)⊆DistanceTwo G x := by
    intro z zz
    obtain ⟨u,ud,rfl⟩ := mem_image.mp zz
    exact (priv u ud).1
  have cardDon : D.card≤d := by
    have e := (card_le_card allD).trans (cap x)
    rw [card_image_of_injOn inj] at e
    exact e
  have vp : ∀ u∈D₀,rep u∈DistanceTwo G x ∧ G.Adj u (rep u) ∧
      ∀ w∈D₀,w≠u → ¬G.Adj w (rep u) := by
    intro u ud
    obtain ⟨a,b,c⟩ := priv u (sD ud)
    exact ⟨a,b,fun w wd ne => c w (sD wd) ne⟩
  have exc : Q.card≤W.card+1 := by
    let L := univ.filter (fun z : V => G.degree z<d)
    have qsub : Q⊆W∪L := by
      intro z zq
      obtain ⟨zd,r⟩ := mem_sdiff.mp zq
      have e : z∈R∪P∪W := partition.symm ▸ DA zd
      rcases mem_union.mp e with left|zw
      · rcases mem_union.mp left with zr|zp
        · by_cases hi : d≤G.degree z
          · obtain ⟨i,_,zi⟩ := mem_biUnion.mp zr
            have zD : z∈D₀ := mem_biUnion.mpr ⟨i,mem_univ _,mem_filter.mpr
              ⟨mem_inter.mpr ⟨zd,zi⟩,hi⟩⟩
            exact (r (mem_union.mpr (Or.inl zD))).elim
          · exact mem_union.mpr (Or.inr (mem_filter.mpr ⟨mem_univ _,by omega⟩))
        · exact (r (mem_union.mpr (Or.inr (mem_inter.mpr ⟨zd,zp⟩)))).elim
      exact mem_union.mpr (Or.inl zw)
    have ll : L.card≤1 := by
      apply Nat.le_of_not_gt
      intro e
      obtain ⟨u,uu,v,vv,ne⟩ := one_lt_card.mp (show 1<L.card from e)
      exact (deg u v ne).elim (Nat.not_le_of_lt (mem_filter.mp uu).2)
        (Nat.not_le_of_lt (mem_filter.mp vv).2)
    have l := (card_le_card qsub).trans (card_union_le W L)
    omega
  have cInt (i : α) : D₀∩M i=K i := by
    ext z
    constructor
    · intro h
      obtain ⟨zz,zi⟩ := mem_inter.mp h
      obtain ⟨j,_,zj⟩ := mem_biUnion.mp zz
      have e : j=i := Classical.byContradiction (fun ne =>
        disjoint_left.mp (dis ne) (tR j zj) zi)
      subst j
      exact zj
    · intro h
      exact mem_inter.mpr ⟨mem_biUnion.mpr ⟨i,mem_univ _,h⟩,tR i h⟩
  have hcard (i : α) : ((R\M i)\D₀).card+D₀.card=(R\M i).card+(K i).card := by
    have z : (R\M i)∩D₀=D₀\M i := by
      ext v
      constructor
      · intro e
        obtain ⟨rs,dd⟩ := mem_inter.mp e
        exact mem_sdiff.mpr ⟨dd,(mem_sdiff.mp rs).2⟩
      · intro e
        obtain ⟨dd,ni⟩ := mem_sdiff.mp e
        exact mem_inter.mpr ⟨mem_sdiff.mpr ⟨sR dd,ni⟩,dd⟩
    have q := card_sdiff_add_card_inter (R\M i) D₀
    have v := card_sdiff_add_card_inter D₀ (M i)
    rw [z] at q
    rw [cInt i] at v
    omega
  have xD₀ : x∉D₀ := fun ex => disjoint_left.mp dx (sR ex) xx
  have outside_no (i : α) (v : V) (vi : v∈M i) (w : V) (wn : w∈R\M i) : ¬G.Adj v w := by
    obtain ⟨wr,wno⟩ := mem_sdiff.mp wn
    obtain ⟨j,_,wj⟩ := mem_biUnion.mp wr
    have ij : i≠j := fun e => wno (e.symm ▸ wj)
    exact no i j ij v vi w wj
  have charge (i : α) (v : V) (vk : v∈K i) :
      (F v).card+((K i).card+(R\M i).card+pp)≤d+2 := by
    have vd : v∈D₀ := mem_biUnion.mpr ⟨i,mem_univ _,vk⟩
    let S := (R\M i)\D₀
    have sa : S⊆A := fun _ z => sb ((mem_sdiff.mp (mem_sdiff.mp z).1).1)
    have xn : x∉S := fun e => disjoint_left.mp dx ((mem_sdiff.mp (mem_sdiff.mp e).1).1) xx
    have ds : Disjoint D₀ S := disjoint_left.mpr (fun _ dd ss => (mem_sdiff.mp ss).2 dd)
    have nq : ∀ z∈S,¬G.Adj v z := fun z e => outside_no i v (tR i vk) z (mem_sdiff.mp e).1
    have d := omitted_donor_strong_charge hc d cap hp hx gap D₀ S (sR.trans sb) xD₀ sa xn ds v vd nq rep vp
    have c := hcard i
    change S.card+D₀.card=(R\M i).card+(K i).card at c
    change (F v).card+D₀.card+S.card+pp+_≤_ at d
    omega
  have hpin (v : V) (vu : v∈U) : (F v).card+((∑i,(K i).card)+U.card)≤d+1 := by
    have h := every v (mem_inter.mp vu).1 (∅:Finset V) (empty_subset _) (by simp)
    rw [empty_sdiff,card_empty,add_zero] at h
    have e : 0<D.card := card_pos.mpr ⟨v,(mem_inter.mp vu).1⟩
    change (F v).card+(D.card-1)≤d at h
    omega
  have hr (v : V) (vq : v∈Q) : (F v).card≤d := by
    have h := every v (mem_sdiff.mp vq).1 (∅:Finset V) (empty_subset _) (by simp)
    rw [empty_sdiff,card_empty,add_zero] at h
    exact le_trans (Nat.le_add_right _ _) h
  let T (i : α) := (K i).biUnion F
  let GT := univ.biUnion T
  let GU := U.biUnion F
  let GQ := Q.biUnion F
  have hcvr : H⊆GT∪GU∪GQ := by
    intro z zh
    obtain ⟨v,vd,vz⟩ := mem_biUnion.mp (cover zh)
    by_cases yes : v∈D₀∪U
    · rcases mem_union.mp yes with d0|u
      · obtain ⟨i,_,vi⟩ := mem_biUnion.mp d0
        exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inl (mem_biUnion.mpr
          ⟨i,mem_univ _,mem_biUnion.mpr ⟨v,vi,vz⟩⟩))))
      · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inr (mem_biUnion.mpr ⟨v,u,vz⟩))))
    · exact mem_union.mpr (Or.inr (mem_biUnion.mpr ⟨v,mem_sdiff.mpr ⟨vd,yes⟩,vz⟩))
  have ord : H.card≤(∑i,(T i).card)+GU.card+GQ.card := by
    have a := card_le_card hcvr
    have b := card_union_le GT GU
    have c := card_union_le (GT∪GU) GQ
    have e : GT.card≤∑i,(T i).card := card_biUnion_le
    omega
  have tBound : (∑ i,(T i).card)+(∑ i,(K i).card*((K i).card+(R\M i).card+pp))
      ≤ (d+2)*(∑ i,(K i).card) := by
    rw [←Finset.sum_add_distrib]
    calc
      _ ≤ ∑ i,(K i).card*(d+2) := by
        apply Finset.sum_le_sum
        intro i _
        exact Graffiti189LongestPath.FlexSplitShell.count_group (K i) F _ _ (charge i)
      _ = _ := by
        rw [Nat.mul_comm (d+2) (∑ i,(K i).card)]
        exact (Finset.sum_mul (univ:Finset α) (fun i => (K i).card) (d+2)).symm
  have uBound : GU.card+U.card*((∑i,(K i).card)+U.card)≤U.card*(d+1) :=
    Graffiti189LongestPath.FlexSplitShell.count_group U F _ _ hpin
  have qBound : GQ.card≤(W.card+1)*d := (card_biUnion_le_card_mul Q F d hr).trans
    (Nat.mul_le_mul_right _ exc)
  have mass : H.card+(∑ i,(K i).card*((K i).card+(R\M i).card+pp))+
      U.card*((∑i,(K i).card)+U.card)≤
      (d+2)*(∑i,(K i).card)+(d+1)*U.card+(W.card+1)*d := by
    rw [Nat.mul_comm (d+1) U.card]
    omega
  refine ⟨fun i => (K i).card,U.card,tn,?_,mass,?_⟩
  · change (∑i,(K i).card)+U.card≤d
    omega
  intro xs i
  have ci : M i⊆A := (mb i).trans sb
  have prt : A=M i∪(R\M i)∪X := by
    rw [union_comm (M i) (R\M i),sdiff_union_of_subset (mb i)]
    exact part
  by_cases emp : (K i).card=0
  · obtain ⟨v,vc,hi⟩ := highSide i
    have b := missing_ports_bound_by_side_order d A B (M i) (R\M i) X
      prt xs closed ci (outside_no i) pp bk v vc hi
    change (B.filter (fun z => ¬∃ v∈M i,G.Adj v z)).card+pp≤(M i).card+2 at b
    change (K i).card+pp+(B.filter (fun z => ¬∃ v∈M i,G.Adj v z)).card≤(M i).card+3
    omega
  · obtain ⟨v,vK⟩ := card_pos.mp (Nat.pos_of_ne_zero emp)
    exact side_bound_with_missing_reach_and_private_ports d A B (M i) (R\M i) X (K i)
      prt xs ci (outside_no i) closed pp bk v (tR i vK) vK (parts i v vK).2.2 rep (tR i)
      (fun w wk => ⟨repr w (mem_biUnion.mpr ⟨i,mem_univ _,wk⟩),(priv w (parts i w wk).1).2.1,
        fun z zk nz => (priv w (parts i w wk).1).2.2 z (parts i z zk).1 nz⟩)

#print axioms grouped_shell_mass
end Graffiti189LongestPath.GroupedShellMass

/- source: FiniteTinySums189 -/
open Finset
open scoped BigOperators
namespace Graffiti189LongestPath.FiniteTinySums
theorem sum_two (F : Fin 2→Nat) : (∑ i,F i)=F 0+F 1 := by
  have e : (univ:Finset (Fin 2))={0,1} := by
    ext i
    fin_cases i <;> simp
  rw [e,Finset.sum_insert (by decide),Finset.sum_singleton]
theorem sum_three (F : Fin 3→Nat) : (∑ i,F i)=F 0+F 1+F 2 := by
  have e : (univ:Finset (Fin 3))={0,1,2} := by
    ext i
    fin_cases i <;> simp
  rw [e,Finset.sum_insert (by decide),Finset.sum_insert (by decide),Finset.sum_singleton]
  omega
end Graffiti189LongestPath.FiniteTinySums

/- source: NormalizedShellMass189 -/

namespace Graffiti189LongestPath.NormalizedShellMass

theorem fine_two_shore_shell_cap
    (k d c e a b t p f H : ℤ)
    (hd : d≤2*k) (ce : c≤e) (eK : e≤k) (fK : f≤k)
    (hRoot : d-p≤c+e+2) (an : 0≤a) (bn : 0≤b) (tn : 0≤t) (tp : t≤p) (pk : p≤k)
    (sz : a+b+t≤d) (reserve : a+b+2*p≤c+f+10)
    (raw : H+a*(a+e+p)+b*(b+c+p)+t*(a+b+t)≤(d+2)*(a+b)+(d+1)*t+2*d) :
    2*H≤2*(a+b)*(e-p)-(a+b)^2+2*p*(2*k-p)+100*k := by
  let u := a+b
  have un : 0≤u := add_nonneg an bn
  have dz := mul_nonneg un (show 0≤c+e+2-(d-p) by omega)
  have en := mul_nonneg an (show 0≤e-c by omega)
  have tz := mul_nonneg tn (show 0≤2*k-d by omega)
  have l : 4*u+t+2*d≤12*k := by dsimp [u]; omega
  have mass : 2*H≤2*u*(e-t)-u^2+2*t*(2*k-t)+24*k := by
    dsimp [u] at dz l ⊢
    nlinarith only [raw,dz,en,tz,l,sq_nonneg (a-b)]
  have inc := mul_nonneg (show 0≤p-t by omega)
    (show 0≤2*k-p-t-u+10 by dsimp [u]; omega)
  have gap : p-t≤k := by omega
  change 2*H≤2*u*(e-p)-u^2+2*p*(2*k-p)+100*k
  nlinarith only [mass,inc,gap,show 0≤k by omega]

theorem fine_three_shore_shell_mass
    (k s p t h x c₁ c₂ c₃ a₁ a₂ a₃ H : ℤ)
    (sk : s≤k) (xs : x≤3) (an₁ : 0≤a₁) (an₂ : 0≤a₂) (an₃ : 0≤a₃) (tn : 0≤t)
    (sz : a₁+a₂+a₃+t≤k+s)
    (raw : H+a₁*(a₁+h-x-c₁+p)+a₂*(a₂+h-x-c₂+p)+a₃*(a₃+h-x-c₃+p)+
      t*(a₁+a₂+a₃+t)≤(k+s+2)*(a₁+a₂+a₃)+(k+s+1)*t+3*(k+s)) :
    H≤t*(2*k-t)+
      a₁*(k+(s-p)-h+c₁-t-a₁)+a₂*(k+(s-p)-h+c₂-t-a₂)+
      a₃*(k+(s-p)-h+c₃-t-a₃)+16*k := by
  have xz := mul_nonneg (show 0≤a₁+a₂+a₃ by omega) (show 0≤3-x by omega)
  have tz := mul_nonneg tn (show 0≤k-s by omega)
  have bound : 5*(a₁+a₂+a₃)+t+3*(k+s)≤16*k := by omega
  nlinarith only [raw,xz,tz,bound]

#print axioms fine_two_shore_shell_cap
#print axioms fine_three_shore_shell_mass
end Graffiti189LongestPath.NormalizedShellMass

/- source: SmallShoreNumeric189 -/

namespace Graffiti189LongestPath.SmallShoreNumeric

/-- The two-small-shore regime's strengthened Ore spacing beats the
complementary donor shell upper bound. Constants leave ample room for
the bounded cut, parity overlap and finite normalization losses. -/
theorem two_small_contradiction (k d c e u f p h : ℤ)
    (hk : 1000000≤k) (hd : 5*k≤3*d)
    (cFloor : k-3≤2*c) (ce : c≤e) (eTop : e≤k)
    (highShore : d≤c+e+p+6)
    (un : 0≤u) (fn : 0≤f) (pn : 0≤p) (pTop : p≤k)
    (donor : u+2*p≤c+f+10)
    (mass : 2*h≤2*u*(e-p)-u^2+2*p*(2*k-p)+100*k)
    (spacing : k*c+e*f-100*k≤h) : False := by
  let T := u+2*p
  let L := 2*u*p+u^2+2*p^2
  have l0 : 0≤L := by
    dsimp [L]
    nlinarith only [sq_nonneg u,sq_nonneg p,mul_nonneg un pn]
  have ls : T^2≤2*L := by
    dsimp [T,L]
    nlinarith only [sq_nonneg u]
  have et := mul_nonneg fn (show 0≤e by omega)
  have margin := mul_nonneg (show 0≤k by omega) (show 0≤k-1000000 by omega)
  by_cases low : T≤c
  · have mul0 := mul_nonneg un (show 0≤k-e by omega)
    have top : 2*h≤2*k*T-L+100*k := by
      dsimp [T,L]
      nlinarith only [mass,mul0]
    by_cases small : 4*T≤k
    · have sz := mul_nonneg (show 0≤k by omega) (show 0≤k-4*T by omega)
      have cc := mul_nonneg (show 0≤k by omega) (show 0≤2*c-k+3 by omega)
      nlinarith only [top,spacing,sz,cc,et,margin,hk,l0]
    · have t2 : k^2≤16*T^2 := by
        nlinarith only [mul_nonneg (show 0≤4*T-k by omega) (show 0≤4*T+k by omega)]
      have d0 := mul_nonneg (show 0≤k by omega) (show 0≤c-T by omega)
      nlinarith only [top,spacing,d0,t2,ls,et,margin,hk]
  · have ed : e*(T-c-10)≤e*f := by
      have z : 0≤f-(T-c-10) := by dsimp [T]; omega
      nlinarith only [mul_nonneg (show 0≤e by omega) z]
    have top : 2*h-2*(k*c+e*f)≤2*(k-e)*(2*p-c)-L+120*k := by
      dsimp [T,L] at ed ⊢
      nlinarith only [mass,ed,eTop]
    by_cases psmall : 2*p≤c
    · have pr := mul_nonneg (show 0≤k-e by omega) (show 0≤c-2*p by omega)
      have t2 : (k-3)^2≤4*T^2 := by
        nlinarith only [mul_nonneg (show 0≤2*T-k+3 by omega) (show 0≤2*T+k-3 by omega)]
      nlinarith only [top,spacing,pr,t2,ls,margin,hk]
    · have lp : 2*p^2≤L := by
        dsimp [L]
        nlinarith only [sq_nonneg u,mul_nonneg un pn]
      by_cases wide : 11*k≤20*e
      · have pr := mul_nonneg (show 0≤20*e-11*k by omega) (show 0≤2*p-c by omega)
        have cc := mul_nonneg (show 0≤k by omega) (show 0≤2*c-k+3 by omega)
        have quad := sq_nonneg (20*p-9*k)
        nlinarith only [top,spacing,lp,pr,cc,quad,margin,hk]
      · have near : 14*k≤25*p := by omega
        have pr := mul_nonneg (show 0≤2*e-k+3 by omega) (show 0≤2*p-c by omega)
        have cc := mul_nonneg (show 0≤k by omega) (show 0≤2*c-k+3 by omega)
        have quad : 9*k^2≤25^2*(2*p-k)^2 := by
          nlinarith only [mul_nonneg (show 0≤50*p-28*k by omega) (show 0≤50*p-22*k by omega)]
        have cl : 0≤c := by omega
        nlinarith only [top,spacing,lp,pr,cc,quad,margin,hk,pTop,cl]

#print axioms two_small_contradiction
end Graffiti189LongestPath.SmallShoreNumeric

/- source: ThreeShoreMass189 -/

namespace Graffiti189LongestPath.ThreeShoreMass

/-- For three disjoint donor sides, the worst size distribution at
fixed total and common size floor has all excess in one side. -/
theorem three_shore_shell_cap
    (k ell p t h m c₁ c₂ c₃ a₁ a₂ a₃ H : ℤ)
    (hk : 1000000≤k) (p0 : 0≤p) (tk : 0≤t) (tp : t≤p) (el : ell+p≤k)
    (hL : k+ell≤h) (hU : h≤3*ell+20)
    (mL : h-ell-8≤2*m) (mU : 2*m≤h-ell)
    (c : c₁+c₂+c₃≤h) (c₁m : m≤c₁) (c₂m : m≤c₂) (c₃m : m≤c₃)
    (a₁n : 0≤a₁) (a₂n : 0≤a₂) (a₃n : 0≤a₃)
    (raw : H≤t*(2*k-t)+
      a₁*(k+ell-h+c₁-t-a₁)+a₂*(k+ell-h+c₂-t-a₂)+
      a₃*(k+ell-h+c₃-t-a₃)+16*k) :
    8*H≤2*(k-p-t)^2+(k-2*t)^2+8*t*(2*k-t)+500*k := by
  let x := k+ell-h-t+m+14
  let y₁ := c₁-m
  let y₂ := c₂-m
  let y₃ := c₃-m
  let Y := h-3*m
  have x0 : 0≤x := by dsimp [x]; omega
  have y₁0 : 0≤y₁ := by dsimp [y₁]; omega
  have y₂0 : 0≤y₂ := by dsimp [y₂]; omega
  have y₃0 : 0≤y₃ := by dsimp [y₃]; omega
  have y : y₁+y₂+y₃≤Y := by dsimp [y₁,y₂,y₃,Y]; omega
  have Y0 : 0≤Y := by omega
  have mass : 4*H≤4*t*(2*k-t)+(x+y₁)^2+(x+y₂)^2+(x+y₃)^2+64*k := by
    have s₁ := sq_nonneg (2*a₁-x-y₁)
    have s₂ := sq_nonneg (2*a₂-x-y₂)
    have s₃ := sq_nonneg (2*a₃-x-y₃)
    dsimp [x,y₁,y₂,y₃] at s₁ s₂ s₃ ⊢
    nlinarith only [raw,s₁,s₂,s₃,a₁n,a₂n,a₃n]
  have moment : (x+y₁)^2+(x+y₂)^2+(x+y₃)^2≤(x+Y)^2+2*x^2 := by
    nlinarith only [mul_nonneg (show 0≤Y-y₁-y₂-y₃ by omega)
      (show 0≤2*x+Y+y₁+y₂+y₃ by omega),
      mul_nonneg y₁0 y₂0,mul_nonneg y₁0 y₃0,mul_nonneg y₂0 y₃0]
  have big : x+Y≤k-p-t+22 := by dsimp [x,Y]; omega
  have small : 2*x≤k-2*t+28 := by dsimp [x]; omega
  have q1 : (x+Y)^2≤(k-p-t+22)^2 := by
    nlinarith only [mul_nonneg (show 0≤k-p-t+22-(x+Y) by omega)
      (show 0≤k-p-t+22+(x+Y) by omega)]
  have q2 : 4*x^2≤(k-2*t+28)^2 := by
    nlinarith only [mul_nonneg (show 0≤k-2*t+28-2*x by omega)
      (show 0≤k-2*t+28+2*x by omega)]
  nlinarith only [mass,moment,q1,q2,p0,tk,hk]

#print axioms three_shore_shell_cap
end Graffiti189LongestPath.ThreeShoreMass

/- source: ThreeShoreNumeric189 -/

namespace Graffiti189LongestPath.ThreeShoreNumeric

/-- Three mutually nonadjacent split shores cannot attain the shell
mass demanded by their two-color-compatible hooks. The graph-side
estimates have already absorbed bounded additive normalization losses. -/
theorem three_side_contradiction (k ell p t h m f H : ℤ)
    (hk : 1000000≤k) (p0 : 0≤p) (pK : p≤k) (_t0 : 0≤t) (tp : t≤p)
    (el : ell+p≤k) (hL : k+ell≤h) (hU : h≤3*ell+20) (h0 : 0≤h)
    (mL : h-ell-8≤2*m) (f0 : 0≤f) (fL : 2*k-h+3*p-18≤2*f)
    (space : m*(k+f)-100*k≤H)
    (shell : 8*H≤2*(k-p-t)^2+(k-2*t)^2+8*t*(2*k-t)+500*k) : False := by
  have rise := mul_nonneg (show 0≤p-t by omega) (show 0≤8*k+2*p-2*t by omega)
  have upper : 8*H≤3*k^2+4*k*p+4*p^2+500*k := by
    nlinarith only [shell,rise]
  have margin := mul_nonneg (show 0≤k by omega) (show 0≤k-1000000 by omega)
  by_cases small : 6*p≤k
  · have kp := mul_nonneg (show 0≤k by omega) (show 0≤k-6*p by omega)
    have pp : 36*p^2≤k^2 := by
      nlinarith only [mul_nonneg (show 0≤k-6*p by omega) (show 0≤k+6*p by omega)]
    have m0 : 0≤m := by omega
    have a := mul_nonneg m0 f0
    have b := mul_nonneg (show 0≤k by omega) (show 0≤2*m-k+8 by omega)
    nlinarith only [upper,space,kp,pp,a,b,margin,hk]
  · have z0 : 0≤h-ell-8 := by omega
    have n := mul_nonneg z0 (show 0≤2*f+2*k-(4*k-h+3*p-18) by omega)
    have u := mul_nonneg (show 0≤2*m-(h-ell-8) by omega) (show 0≤2*f+2*k by omega)
    have prod : (h-ell-8)*(4*k-h+3*p-18)≤4*m*(k+f) := by
      nlinarith only [n,u]
    have diff := mul_nonneg (show 0≤h-k-ell by omega) (show 0≤3*k+3*p-h by omega)
    have ed := mul_nonneg (show 0≤k by omega) (show 0≤k-ell-p by omega)
    have pq := mul_nonneg p0 (show 0≤k-p by omega)
    nlinarith only [upper,space,prod,diff,ed,pq,margin,hk,hU,el,h0,pK,p0]

#print axioms three_side_contradiction
end Graffiti189LongestPath.ThreeShoreNumeric

/- source: TwoSmallNormalized189 -/
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.OneSlack Graffiti189LongestPath.PinRun Graffiti189LongestPath.Rigidity
open Graffiti189LongestPath.MengerRoutable Graffiti189LongestPath.HookRetarget
open Graffiti189LongestPath.SmallShoreOre Graffiti189LongestPath.ColoredFan Graffiti189LongestPath.FilterRootHooks
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
open scoped BigOperators
set_option maxHeartbeats 10000000
namespace Graffiti189LongestPath.TwoSmallNormalized
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem small_split_impossible (hc : G.Connected) (k s : Nat)
    (kl : 1000000≤k) (sl : 2*k≤3*s) (su : s≤k)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
    (gap : (Pins p x).card≤(FirstPins p x).card+1)
    (cap : ∀ v,(DistanceTwo G v).card≤k+s)
    (conn : ∀ D : Finset V,D.card<k → (G.induce ((↑D:Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → k+s≤G.degree u ∨ k+s≤G.degree v)
    (spine : k≤p.support.toFinset.card)
    (C E X W : Finset V)
    (part : OmittedStar p x=C∪E∪X)
    (partition : C∪E∪PinVertices p x∪W=G.neighborFinset x)
    (xx : x∈X) (smallX : X.card≤2) (smallW : W.card≤1)
    (ce : Disjoint C E) (cx : Disjoint C X) (ex : Disjoint E X)
    (no : ∀ u∈C,∀ v∈E,¬G.Adj u v)
    (largeC : k-3≤2*C.card) (smaller : C.card≤E.card) (smallE : E.card≤k-6)
    (floC : ∀ u : ↥(C:Set V),3≤(G.induce (C:Set V)).degree u)
    (floE : ∀ u : ↥(E:Set V),3≤(G.induce (E:Set V)).degree u)
    (hiC : ∀ u : ↥(C:Set V), k+s≤G.degree u.val → k-5≤2*(G.induce (C:Set V)).degree u)
    (hiE : ∀ u : ↥(E:Set V), k+s≤G.degree u.val → k-5≤2*(G.induce (E:Set V)).degree u)
    (hK : k≤(OmittedStar p x).card)
    (hh : k+s≤(OmittedStar p x).card+(Pins p x).card)
    (pins : (Pins p x).card≤k)
    (bk : (External G (OmittedStar p x)).card+(Pins p x).card≤k+s+1)
    (radial : Fintype.card V≤(OmittedStar p x).card+k+2*s+(Shell G x 3).card) :
    False := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let R := C∪E
  let H := Shell G x 3
  let d := k+s
  let pp := (Pins p x).card
  let m := (k-4)/2
  let L (v : V) : Nat := if v∈C then 0 else 1
  have dr : Disjoint R X := disjoint_union_left.mpr ⟨cx,ex⟩
  have rc : R.card=C.card+E.card := card_union_of_disjoint ce
  have hcard : A.card=C.card+E.card+X.card := by
    have q := congrArg Finset.card part
    rw [card_union_of_disjoint dr,rc] at q
    exact q
  have roots : A\X=R := by
    change (OmittedStar p x)\X=R
    rw [part,union_sdiff_right,sdiff_eq_self_of_disjoint dr]
  have rs : R⊆A := by
    intro z zz
    change z∈OmittedStar p x
    rw [part]
    exact mem_union.mpr (Or.inl zz)
  have cA : C⊆A := fun _ z => rs (mem_union.mpr (Or.inl z))
  have eA : E⊆A := fun _ z => rs (mem_union.mpr (Or.inr z))
  have xA : x∈A := Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
  have root (z : V) (za : z∈A) (ne : z≠x) : G.Adj x z :=
    ((Graffiti189LongestPath.Rigidity.mem_omittedStar.mp za).2).resolve_left ne
  have ao (z : V) (za : z∈A) : z∉p.support := (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp za).1
  have closed (u : V) (ua : u∈A) (z : V) (za : z∉A) (ed : G.Adj u z) : z∈B :=
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨za,u,ua,ed⟩
  have lc (z : V) (zc : z∈C) : L z=0 := if_pos zc
  have le (z : V) (ze : z∈E) : L z=1 := if_neg (fun zc => disjoint_left.mp ce zc ze)
  have pc (u v : ↥(C:Set V)) (ne : u≠v) :
      m≤(G.induce (C:Set V)).degree u ∨ m≤(G.induce (C:Set V)).degree v :=
    (deg u.val v.val (fun e => ne (Subtype.ext e))).imp
      (fun e => by have q := hiC u e; dsimp [m]; omega)
      (fun e => by have q := hiC v e; dsimp [m]; omega)
  have pe (u v : ↥(E:Set V)) (ne : u≠v) :
      m≤(G.induce (E:Set V)).degree u ∨ m≤(G.induce (E:Set V)).degree v :=
    (deg u.val v.val (fun e => ne (Subtype.ext e))).imp
      (fun e => by have q := hiE u e; dsimp [m]; omega)
      (fun e => by have q := hiE v e; dsimp [m]; omega)
  have routeC := side_ore_paths C m (by dsimp [m]; omega) floC pc
  have routeE := side_ore_paths E m (by dsimp [m]; omega) floE pe
  have across := ore_cross_shore_route A C E x xA
    (fun e => disjoint_left.mp cx e xx) (fun e => disjoint_left.mp ex e xx) cA eA ce root
    (by omega) (by omega) routeC routeE
  have acrossRev (u : V) (ue : u∈E) (v : V) (vc : v∈C) :
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈A) ∧ C.card+E.card+1=q.length+1 := by
    obtain ⟨q,qp,qs,ql⟩ := across v vc u ue
    exact ⟨q.reverse,qp.reverse,fun z zz => qs z (by
      simpa only [support_reverse,List.mem_reverse] using zz),by simpa using ql⟩
  have weak (u : V) (ur : u∈R) (v : V) (vr : v∈R) (ne : u≠v) :
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈A) ∧ C.card≤q.length+1 := by
    rcases mem_union.mp ur with uc|ue <;> rcases mem_union.mp vr with vc|ve
    · obtain ⟨q,qp,qs,ql⟩ := routeC u uc v vc ne
      exact ⟨q,qp,fun _ h => cA (qs _ h),by omega⟩
    · obtain ⟨q,qp,qs,ql⟩ := across u uc v ve
      exact ⟨q,qp,qs,by omega⟩
    · obtain ⟨q,qp,qs,ql⟩ := acrossRev u ue v vc
      exact ⟨q,qp,qs,by omega⟩
    · obtain ⟨q,qp,qs,ql⟩ := routeE u ue v ve ne
      exact ⟨q,qp,fun _ h => eA (qs _ h),by omega⟩
  have cross (u : V) (ur : u∈R) (v : V) (vr : v∈R) (ne : L u≠L v) :
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈A) ∧ C.card+E.card≤q.length+1 := by
    rcases mem_union.mp ur with uc|ue <;> rcases mem_union.mp vr with vc|ve
    · exact (ne ((lc u uc).trans (lc v vc).symm)).elim
    · obtain ⟨q,qp,qs,ql⟩ := across u uc v ve
      exact ⟨q,qp,qs,by omega⟩
    · obtain ⟨q,qp,qs,ql⟩ := acrossRev u ue v vc
      exact ⟨q,qp,qs,by omega⟩
    · exact (ne ((le u ue).trans (le v ve).symm)).elim
  obtain ⟨F⟩ := hooks_of_small_deletion_connectivity A k hp ao hK spine conn
  obtain ⟨j,F',jk,kj,good⟩ := retain_regular_roots A X k F
  have regular (i : Fin j) : F'.root i∈R := roots ▸ good i
  have fan := colored_flexible_hooked_lower j C.card E.card (by omega) hp A R ao rs
    (by omega) L weak cross F' regular
  let goodC := (univ : Finset (Fin j)).filter (fun i =>
    (∃ u∈C,G.Adj u (fromFamily F' i).firstPort) ∧ ∃ v∈E,G.Adj v (fromFamily F' i).firstPort)
  have eq (i : Fin j) :
      (∃ u∈R,∃ v∈R,G.Adj u (fromFamily F' i).firstPort ∧
        G.Adj v (fromFamily F' i).firstPort ∧ L u≠L v) ↔
      ((∃ u∈C,G.Adj u (fromFamily F' i).firstPort) ∧ ∃ v∈E,G.Adj v (fromFamily F' i).firstPort) := by
    constructor
    · rintro ⟨u,ur,v,vr,hu,hv,neq⟩
      rcases mem_union.mp ur with uc|ue <;> rcases mem_union.mp vr with vc|ve
      · exact (neq ((lc u uc).trans (lc v vc).symm)).elim
      · exact ⟨⟨u,uc,hu⟩,⟨v,ve,hv⟩⟩
      · exact ⟨⟨v,vc,hv⟩,⟨u,ue,hu⟩⟩
      · exact (neq ((le u ue).trans (le v ve).symm)).elim
    · rintro ⟨⟨u,uc,hu⟩,⟨v,ve,hv⟩⟩
      exact ⟨u,mem_union.mpr (Or.inl uc),v,mem_union.mpr (Or.inr ve),hu,hv,
        by simpa only [lc u uc,le v ve] using (by decide : (0:Nat)≠1)⟩
  have fq : (univ : Finset (Fin j)).filter (fun i =>
      ∃ u∈R,∃ v∈R,G.Adj u (fromFamily F' i).firstPort ∧
        G.Adj v (fromFamily F' i).firstPort ∧ L u≠L v)=goodC := by
    ext i
    exact ⟨fun h => mem_filter.mpr ⟨mem_univ _,(eq i).mp (mem_filter.mp h).2⟩,
      fun h => mem_filter.mpr ⟨mem_univ _,(eq i).mpr (mem_filter.mp h).2⟩⟩
  dsimp only at fan
  rw [fq] at fan
  let f := goodC.card
  change A.card+j+(j+1)*C.card+f*E.card≤Fintype.card V at fan
  have fk : f≤k := (by
    have fr := card_le_card (subset_univ goodC)
    rw [card_univ,Fintype.card_fin] at fr
    exact fr.trans jk)
  have spac : k*C.card+E.card*f≤H.card+100*k := by
    have mono := Nat.mul_le_mul_right C.card kj
    have xs : (j+X.card)*C.card=(j+1)*C.card+(X.card-1)*C.card := by
      have Xpos : 0<X.card := card_pos.mpr ⟨x,xx⟩
      rw [←Nat.add_mul]
      congr 1
      omega
    rw [xs] at mono
    have xterm := Nat.mul_le_mul (show X.card-1≤1 by omega) (show C.card≤k by omega)
    have comm : f*E.card=E.card*f := Nat.mul_comm _ _
    change Fintype.card V≤A.card+k+2*s+H.card at radial
    omega
  have miss := FlexMissTwice.ports_missing_or_flexible j hp A B C E closed ao F'
  let qC := (B.filter (fun z => ¬∃ u∈C,G.Adj u z)).card
  let qE := (B.filter (fun z => ¬∃ u∈E,G.Adj u z)).card
  change j≤f+qC+qE at miss
  let M (i : Fin 2) := if i=0 then C else E
  have mz : M 0=C := by simp [M]
  have mo : M 1=E := by simp [M]
  have ri : univ.biUnion M=R := by
    ext z
    constructor
    · intro zz
      obtain ⟨i,_,zi⟩ := mem_biUnion.mp zz
      fin_cases i
      · exact mem_union.mpr (Or.inl (by simpa [M] using zi))
      · exact mem_union.mpr (Or.inr (by simpa [M] using zi))
    · intro zz
      rcases mem_union.mp zz with zc|ze
      · exact mem_biUnion.mpr ⟨0,mem_univ _,by simpa [mz] using zc⟩
      · exact mem_biUnion.mpr ⟨1,mem_univ _,by simpa [mo] using ze⟩
  have dis : Pairwise (fun i j => Disjoint (M i) (M j)) := by
    intro i j ne
    fin_cases i <;> fin_cases j
    · exact (ne rfl).elim
    · simpa [M] using ce
    · simpa [M] using ce.symm
    · exact (ne rfl).elim
  have non (i j : Fin 2) (neq : i≠j) (u : V) (ui : u∈M i) (v : V) (vj : v∈M j) :
      ¬G.Adj u v := by
    fin_cases i <;> fin_cases j
    · exact (neq rfl).elim
    · exact no u (by simpa [M] using ui) v (by simpa [M] using vj)
    · exact fun ed => no v (by simpa [M] using vj) u (by simpa [M] using ui) ed.symm
    · exact (neq rfl).elim
  have hSide (i : Fin 2) : ∃ v∈M i,d≤G.degree v := by
    have big : 1<(M i).card := by
      fin_cases i <;> simp [M] <;> omega
    obtain ⟨u,ui,v,vi,ne⟩ := one_lt_card.mp big
    exact (deg u v ne).elim (fun e => ⟨u,ui,e⟩) (fun e => ⟨v,vi,e⟩)
  obtain ⟨K,t,kt,dt,mass,reach⟩ := GroupedShellMass.grouped_shell_mass hc d hp hx gap cap M W X
    (by rw [ri]; exact part) (by rw [ri]; exact partition) (by rw [ri]; exact dr)
    xx deg dis non bk hSide
  have cS : R\M 0=E := by rw [mz,union_sdiff_left,sdiff_eq_self_of_disjoint ce.symm]
  have eS : R\M 1=C := by rw [mo,union_sdiff_right,sdiff_eq_self_of_disjoint ce]
  have mBound : H.card+K 0*(K 0+E.card+pp)+K 1*(K 1+C.card+pp)+
      t*(K 0+K 1+t)≤(d+2)*(K 0+K 1)+(d+1)*t+2*d := by
    have h : (W.card+1)*d≤2*d := Nat.mul_le_mul_right d (by omega)
    simpa only [ri,FiniteTinySums.sum_two,cS,eS,add_assoc] using
      mass.trans (Nat.add_le_add_left h _)
  have tdon : K 0+K 1+t≤d := by simpa only [FiniteTinySums.sum_two] using dt
  have r0 := reach smallX (0:Fin 2)
  have r1 := reach smallX (1:Fin 2)
  rw [mz] at r0
  rw [mo] at r1
  change K 0+pp+qC≤C.card+3 at r0
  change K 1+pp+qE≤E.card+3 at r1
  have uf : K 0+K 1+2*pp≤C.card+f+10 := by omega
  have tpn : t≤pp := kt
  have rootBound : d≤C.card+E.card+pp+2 := by
    change d≤A.card+pp at hh
    omega
  have massI : (H.card:ℤ)+(K 0:ℤ)*((K 0:ℤ)+(E.card:ℤ)+(pp:ℤ))+
      (K 1:ℤ)*((K 1:ℤ)+(C.card:ℤ)+(pp:ℤ))+(t:ℤ)*((K 0:ℤ)+(K 1:ℤ)+(t:ℤ))≤
        ((d:ℤ)+2)*((K 0:ℤ)+(K 1:ℤ))+((d:ℤ)+1)*(t:ℤ)+2*(d:ℤ) := by exact_mod_cast mBound
  have upper := NormalizedShellMass.fine_two_shore_shell_cap (k:ℤ) (d:ℤ)
    (C.card:ℤ) (E.card:ℤ) (K 0:ℤ) (K 1:ℤ) (t:ℤ) (pp:ℤ) (f:ℤ) (H.card:ℤ)
    (by dsimp [d]; omega) (by omega) (by omega) (by omega) (by omega)
    (by omega) (by omega) (by omega) (by omega) (by omega) (by omega) (by omega) massI
  have spacI : (k:ℤ)*(C.card:ℤ)+(E.card:ℤ)*(f:ℤ)≤(H.card:ℤ)+100*(k:ℤ) := by exact_mod_cast spac
  exact SmallShoreNumeric.two_small_contradiction (k:ℤ) (d:ℤ) (C.card:ℤ) (E.card:ℤ)
    ((K 0:ℤ)+(K 1:ℤ)) (f:ℤ) (pp:ℤ) (H.card:ℤ) (by omega) (by dsimp [d]; omega)
    (by omega) (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
    (by omega) (by omega) upper (by omega)

#print axioms small_split_impossible
end Graffiti189LongestPath.TwoSmallNormalized

/- source: ThreeNormalized189 -/
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.OneSlack Graffiti189LongestPath.PinRun Graffiti189LongestPath.Rigidity
open Graffiti189LongestPath.MengerRoutable Graffiti189LongestPath.HookRetarget Graffiti189LongestPath.SplitGreedy
open Graffiti189LongestPath.ColoredFan Graffiti189LongestPath.FilterRootHooks
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
open scoped BigOperators
set_option maxHeartbeats 10000000
namespace Graffiti189LongestPath.ThreeNormalized
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem three_split_impossible (hc : G.Connected) (k s m : Nat)
    (kl : 1000000≤k) (su : s≤k) (m2 : 2≤m) (mK : m≤2*k)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
    (gap : (Pins p x).card≤(FirstPins p x).card+1)
    (cap : ∀ v,(DistanceTwo G v).card≤k+s)
    (conn : ∀ D : Finset V,D.card<k → (G.induce ((↑D:Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → k+s≤G.degree u ∨ k+s≤G.degree v)
    (spine : k≤p.support.toFinset.card)
    (M : Fin 3→Finset V) (X W : Finset V)
    (part : OmittedStar p x=(univ.biUnion M)∪X)
    (partition : (univ.biUnion M)∪PinVertices p x∪W=G.neighborFinset x)
    (xx : x∈X) (smallX : X.card≤3) (smallW : W.card≤2)
    (dx : Disjoint (univ.biUnion M) X)
    (dis : Pairwise (fun i j => Disjoint (M i) (M j)))
    (no : ∀ i j,i≠j → ∀ u∈M i,∀ v∈M j,¬G.Adj u v)
    (Hsize : ∀ i,m+1≤(M i).card)
    (L : Finset V) (L1 : L.card≤1)
    (high : ∀ i,∀ u∈M i,u∉L → m-1≤((M i).filter (G.Adj u)).card)
    (low : ∀ i,∀ u∈M i,u∈L → 1≤((M i).filter (G.Adj u)).card)
    (weak : ∀ u∈OmittedStar p x,∀ v∈OmittedStar p x,u≠v →
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈OmittedStar p x) ∧ m+1≤q.length+1)
    (hL : k+(s-(Pins p x).card)≤(OmittedStar p x).card)
    (mL : (OmittedStar p x).card≤2*m+(s-(Pins p x).card)+8)
    (mU : 2*m+(s-(Pins p x).card)≤(OmittedStar p x).card)
    (pins : (Pins p x).card≤s)
    (bk : (External G (OmittedStar p x)).card+(Pins p x).card≤k+s+1)
    (radial : Fintype.card V≤(OmittedStar p x).card+k+2*s+(Shell G x 3).card) :
    False := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let R := univ.biUnion M
  let d := k+s
  let h := A.card
  let pp := (Pins p x).card
  let ell := s-pp
  let H := Shell G x 3
  let C := M 0
  let E := M 1
  let T := M 2
  have re : R=C∪E∪T := by
    ext z
    constructor
    · intro zz
      obtain ⟨i,_,zi⟩ := mem_biUnion.mp zz
      fin_cases i
      · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inl zi)))
      · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inr zi)))
      · exact mem_union.mpr (Or.inr zi)
    · intro zz
      rcases mem_union.mp zz with eq|zt
      · rcases mem_union.mp eq with zc|ze
        · exact mem_biUnion.mpr ⟨0,mem_univ _,zc⟩
        · exact mem_biUnion.mpr ⟨1,mem_univ _,ze⟩
      · exact mem_biUnion.mpr ⟨2,mem_univ _,zt⟩
  have cr (i : Fin 3) : M i⊆R := fun _ zd => mem_biUnion.mpr ⟨i,mem_univ _,zd⟩
  have hcR : R.card=(M 0).card+(M 1).card+(M 2).card := by
    rw [re,card_union_of_disjoint (disjoint_union_left.mpr
      ⟨dis (by decide : (0:Fin 3)≠2),dis (by decide : (1:Fin 3)≠2)⟩),
      card_union_of_disjoint (dis (by decide : (0:Fin 3)≠1))]
  have ha : h=(M 0).card+(M 1).card+(M 2).card+X.card := by
    have q := congrArg Finset.card part
    rw [card_union_of_disjoint dx,hcR] at q
    exact q
  have hU : h≤3*ell+20 := by
    have a := Hsize (0:Fin 3)
    have b := Hsize (1:Fin 3)
    have c := Hsize (2:Fin 3)
    change h≤2*m+ell+8 at mL
    omega
  have hs : h=(M 0).card+(M 1).card+(M 2).card+X.card := ha
  have rs : R⊆A := by
    intro z zr
    change z∈OmittedStar p x
    rw [part]
    exact mem_union.mpr (Or.inl zr)
  have roots : A\X=R := by
    change (OmittedStar p x)\X=R
    rw [part,union_sdiff_right,sdiff_eq_self_of_disjoint dx]
  have xA : x∈A := Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
  have clean (i : Fin 3) : x∉M i := fun zx => disjoint_left.mp dx (cr i zx) xx
  have root (z : V) (za : z∈A) (ne : z≠x) : G.Adj x z :=
    ((Graffiti189LongestPath.Rigidity.mem_omittedStar.mp za).2).resolve_left ne
  have ao (z : V) (za : z∈A) : z∉p.support := (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp za).1
  have closed (u : V) (ua : u∈A) (z : V) (za : z∉A) (ed : G.Adj u z) : z∈B :=
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨za,u,ua,ed⟩
  let label (z : V) : Nat := if z∈C then 0 else if z∈E then 1 else 2
  have lc (z : V) (zc : z∈C) : label z=0 := if_pos zc
  have le (z : V) (ze : z∈E) : label z=1 := by
    have nn : z∉C := fun h => disjoint_left.mp (dis (by decide : (0:Fin 3)≠1)) h ze
    simp [label,nn,ze]
  have lt (z : V) (zt : z∈T) : label z=2 := by
    have cnot : z∉C := fun h => disjoint_left.mp (dis (by decide : (0:Fin 3)≠2)) h zt
    have enot : z∉E := fun h => disjoint_left.mp (dis (by decide : (1:Fin 3)≠2)) h zt
    simp [label,cnot,enot]
  have lcI (i : Fin 3) (z : V) (zi : z∈M i) : label z=i.val := by
    fin_cases i
    · exact lc z zi
    · exact le z zi
    · exact lt z zi
  have crRoute (u : V) (ur : u∈R) (v : V) (vr : v∈R) (ne : label u≠label v) :
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈A) ∧ (m+1)+(m-2)≤q.length+1 := by
    obtain ⟨i,_,ui⟩ := mem_biUnion.mp ur
    obtain ⟨j,_,vj⟩ := mem_biUnion.mp vr
    have ij : i≠j := fun eq => ne ((lcI i u ui).trans ((congrArg Fin.val eq).trans (lcI j v vj).symm))
    exact greedy_cross_shore_route A (M i) (M j) L m L1 m2 x xA (clean i) (clean j)
      ((cr i).trans rs) ((cr j).trans rs) (dis ij) root (high i) (high j) (low i) (low j)
      u ui v vj
  have hLarge : k≤A.card := by change k+ell≤h at hL; omega
  obtain ⟨F⟩ := hooks_of_small_deletion_connectivity A k hp ao hLarge spine conn
  obtain ⟨j,F',jk,kj,regon⟩ := retain_regular_roots A X k F
  have reg (i : Fin j) : F'.root i∈R := roots ▸ regon i
  have ff := colored_flexible_hooked_lower j (m+1) (m-2) (by omega) hp A R ao rs
    (by have q := Hsize (0:Fin 3); have e := card_le_card (cr 0); omega)
    label (fun u ur v vr ne => weak u (rs ur) v (rs vr) ne) crRoute F' reg
  let U := (univ : Finset (Fin j)).filter (fun i =>
    ∃ u∈R,∃ v∈R,G.Adj u (fromFamily F' i).firstPort ∧
      G.Adj v (fromFamily F' i).firstPort ∧ label u≠label v)
  let f := U.card
  change h+j+(j+1)*(m+1)+f*(m-2)≤Fintype.card V at ff
  have fk : f≤k := by
    have q := card_le_card (subset_univ U)
    rw [card_univ,Fintype.card_fin] at q
    exact q.trans jk
  have spacing : m*(k+f)≤H.card+100*k := by
    have j3 : k≤(j+1)+2 := by omega
    have z := Nat.mul_le_mul_right m j3
    have zz := Nat.mul_le_mul_left (j+1) (show m≤m+1 by omega)
    have fm : f*(m-2)+2*f=f*m := by
      have q : f*(m-2)+f*2=f*m := by rw [←Nat.mul_add,show m-2+2=m by omega]
      simpa only [Nat.mul_comm f 2] using q
    have alg : m*(k+f)=k*m+f*m := by ring
    have zex : ((j+1)+2)*m=(j+1)*m+2*m := by ring
    change Fintype.card V≤h+k+2*s+H.card at radial
    omega
  let Q (i : Fin 3) := (B.filter (fun z => ¬∃ u∈M i,G.Adj u z)).card
  have misses := ThreePortCount.two_misses_per_nonflexible_hook j hp A B C E T label
    lc le lt closed ao F'
  dsimp only at misses
  rw [←re] at misses
  change 2*j≤2*f+Q 0+Q 1+Q 2 at misses
  have highSide (i : Fin 3) : ∃ v∈M i,d≤G.degree v := by
    have big := Hsize i
    obtain ⟨u,ui,v,vi,ne⟩ := one_lt_card.mp (show 1<(M i).card from by omega)
    exact (deg u v ne).elim (fun e => ⟨u,ui,e⟩) (fun e => ⟨v,vi,e⟩)
  have missSide (i : Fin 3) : Q i+pp≤(M i).card+X.card := by
    have prt : A=M i∪(R\M i)∪X := by
      rw [union_comm (M i) (R\M i),sdiff_union_of_subset (cr i)]
      exact part
    have outside (u : V) (ui : u∈M i) (v : V) (vs : v∈R\M i) : ¬G.Adj u v := by
      obtain ⟨vr,ni⟩ := mem_sdiff.mp vs
      obtain ⟨j,_,vj⟩ := mem_biUnion.mp vr
      have ne : i≠j := fun e => ni (e.symm ▸ vj)
      exact no i j ne u ui v vj
    obtain ⟨z,zi,zd⟩ := highSide i
    exact GeneralCutMisses.missed_boundary_of_side_with_high_vertex d pp A B (M i) (R\M i) X
      prt (cr i |>.trans rs) outside closed bk z zi zd
  have z0 := missSide (0:Fin 3)
  have z1 := missSide (1:Fin 3)
  have z2 := missSide (2:Fin 3)
  have flexN : 2*k+3*pp≤h+2*f+18 := by omega
  obtain ⟨K,t,kt,dt,mass,_reach⟩ := GroupedShellMass.grouped_shell_mass hc d hp hx gap cap M W X
    part partition dx xx deg dis no bk highSide
  have cov (i : Fin 3) : (R\M i).card+(M i).card+X.card=h := by
    have u := card_sdiff_add_card_eq_card (cr i)
    have v := congrArg Finset.card part
    rw [card_union_of_disjoint dx] at v
    change h=R.card+X.card at v
    omega
  let a₁ := K 0
  let a₂ := K 1
  let a₃ := K 2
  let c₁ := (M 0).card
  let c₂ := (M 1).card
  let c₃ := (M 2).card
  have temp : H.card+a₁*(a₁+(R\M 0).card+pp)+a₂*(a₂+(R\M 1).card+pp)+
      a₃*(a₃+(R\M 2).card+pp)+t*(a₁+a₂+a₃+t)≤
        (d+2)*(a₁+a₂+a₃)+(d+1)*t+3*d := by
    have r : (W.card+1)*d≤3*d := Nat.mul_le_mul_right d (by omega)
    simp only [FiniteTinySums.sum_three] at mass
    have q := mass.trans (Nat.add_le_add_left r _)
    simpa only [a₁,a₂,a₃,add_assoc] using q
  have ov₁ : (((R\M 0).card:Nat):ℤ)=(h:ℤ)-(X.card:ℤ)-(c₁:ℤ) := by
    have q := cov (0:Fin 3)
    dsimp [c₁]
    omega
  have ov₂ : (((R\M 1).card:Nat):ℤ)=(h:ℤ)-(X.card:ℤ)-(c₂:ℤ) := by
    have q := cov (1:Fin 3)
    dsimp [c₂]
    omega
  have ov₃ : (((R\M 2).card:Nat):ℤ)=(h:ℤ)-(X.card:ℤ)-(c₃:ℤ) := by
    have q := cov (2:Fin 3)
    dsimp [c₃]
    omega
  have massI : (H.card:ℤ)+(a₁:ℤ)*((a₁:ℤ)+((R\M 0).card:ℤ)+(pp:ℤ))+
      (a₂:ℤ)*((a₂:ℤ)+((R\M 1).card:ℤ)+(pp:ℤ))+
      (a₃:ℤ)*((a₃:ℤ)+((R\M 2).card:ℤ)+(pp:ℤ))+
      (t:ℤ)*((a₁:ℤ)+(a₂:ℤ)+(a₃:ℤ)+(t:ℤ))≤
      ((d:ℤ)+2)*((a₁:ℤ)+(a₂:ℤ)+(a₃:ℤ))+((d:ℤ)+1)*(t:ℤ)+3*(d:ℤ) := by exact_mod_cast temp
  rw [ov₁,ov₂,ov₃] at massI
  have dI : (d:ℤ)=(k:ℤ)+(s:ℤ) := by exact_mod_cast (show d=k+s from rfl)
  rw [dI] at massI
  have aSum : a₁+a₂+a₃+t≤k+s := by
    simpa only [FiniteTinySums.sum_three,a₁,a₂,a₃,d,add_assoc] using dt
  have ellI : (ell:ℤ)=(s:ℤ)-(pp:ℤ) := by
    have e := Nat.sub_add_cancel pins
    change ell+pp=s at e
    omega
  have raw := NormalizedShellMass.fine_three_shore_shell_mass (k:ℤ) (s:ℤ) (pp:ℤ)
    (t:ℤ) (h:ℤ) (X.card:ℤ) (c₁:ℤ) (c₂:ℤ) (c₃:ℤ)
    (a₁:ℤ) (a₂:ℤ) (a₃:ℤ) (H.card:ℤ) (by omega) (by omega)
    (by omega) (by omega) (by omega) (by omega) (by omega) (by
      simpa only [sub_eq_add_neg,add_assoc] using massI)
  rw [←ellI] at raw
  have csum : c₁+c₂+c₃+X.card=h := ha.symm
  have c1 := Hsize (0:Fin 3)
  have c2 := Hsize (1:Fin 3)
  have c3 := Hsize (2:Fin 3)
  change m+1≤c₁ at c1
  change m+1≤c₂ at c2
  change m+1≤c₃ at c3
  change 2*m+ell≤h at mU
  change k+ell≤h at hL
  have capI := ThreeShoreMass.three_shore_shell_cap (k:ℤ) (ell:ℤ) (pp:ℤ) (t:ℤ)
    (h:ℤ) (m:ℤ) (c₁:ℤ) (c₂:ℤ) (c₃:ℤ) (a₁:ℤ) (a₂:ℤ) (a₃:ℤ) (H.card:ℤ)
    (by omega) (by omega) (by omega) (by omega) (by omega)
    (by exact_mod_cast hL) (by exact_mod_cast hU) (by change h≤2*m+ell+8 at mL; omega)
    (by omega) (by omega) (by omega) (by omega) (by omega) (by omega) (by omega) (by omega) raw
  have spaceI : (m:ℤ)*((k:ℤ)+(f:ℤ))≤(H.card:ℤ)+100*(k:ℤ) := by exact_mod_cast spacing
  exact ThreeShoreNumeric.three_side_contradiction (k:ℤ) (ell:ℤ) (pp:ℤ) (t:ℤ)
    (h:ℤ) (m:ℤ) (f:ℤ) (H.card:ℤ) (by omega) (by omega) (by omega)
    (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
    (by change h≤2*m+ell+8 at mL; omega) (by omega) (by omega) (by omega) capI

#print axioms three_split_impossible
end Graffiti189LongestPath.ThreeNormalized

/- source: HalfBandDeficit189 -/
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack Graffiti189LongestPath.PinRun
open Graffiti189LongestPath.DeficitActive Graffiti189LongestPath.ScaledActive Graffiti189LongestPath.DeficitLongest
open Graffiti189LongestPath.QuadraticShore
open Graffiti189LongestPath.GeneralGapMidpoint Graffiti189LongestPath.Normalize Graffiti189LongestPath.DeficitThirdShell
open Graffiti189LongestPath.StandaloneShellQuadratic Graffiti189LongestPath.RadialOrder
open Graffiti189LongestPath.GreedyTerminal Graffiti189LongestPath.FanWeighted Graffiti189LongestPath.MengerRoutable
open Graffiti189LongestPath.ShoreSplit Graffiti189LongestPath.ExplicitShoreCycle
open Graffiti189LongestPath.SplitShellCharge Graffiti189LongestPath.StarCycleClosure Graffiti189LongestPath.PosaOneLow Graffiti189LongestPath.ActiveStarHeight
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
open private Graffiti189LongestPath.pin_data from SmallSeparator189
open private Graffiti189LongestPath.OneSlack.boundary_except_pins_two Graffiti189LongestPath.OneSlack.card_pinVertices
  Graffiti189LongestPath.OneSlack.pin_vertices_subset_boundary Graffiti189LongestPath.OneSlack.first_eq_if_no_pair
  Graffiti189LongestPath.OneSlack.pin_of_neighbor_mem from OneSlack189
open private Graffiti189LongestPath.PortReachCount.side_ports_bound from PortReachCount189
set_option warningAsError true
set_option maxHeartbeats 7000000
namespace Graffiti189LongestPath.HalfBandDeficit
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- #189 in an explicit quadratic connectivity range, without needing
2-connectivity of the omitted shore.
No normalized attachment or separator geometry is assumed. -/
theorem traceable_of_half_gap (hc : G.Connected) (k sl : Nat) (large : 1000000≤k) (ratio : sl+100≤k) (positive : 2*k≤3*sl)
    (cap : ∀ v,(EvenFrom G v).card≤k+sl+1)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → k+sl≤G.degree u ∨ k+sl≤G.degree v) :
    ∃ (u v : V) (q : G.Walk u v),q.IsPath ∧ ∀ z,z∈q.support := by
  classical
  apply Classical.byContradiction
  intro fail
  obtain ⟨a,b,p,hmin⟩ := exists_edgeMinAvoid hc (k+sl) deg
  have hp := hmin.1.1
  have no : ∃ x,x∉p.support := Classical.byContradiction (fun h =>
    fail ⟨a,b,p,hp.1,fun z => Classical.byContradiction (fun e => h ⟨z,e⟩)⟩)
  obtain ⟨x,hx,xh,i,hi⟩ := scaled_deficit_has_high_active hc k sl (by omega) (by omega) cap conn deg hp no
  let d := k+sl
  let A := OmittedStar p x
  let B := External G A
  let H := Shell G x 3
  let W := Shell G x 4
  let U := (univ:Finset V)\(A∪B)
  have cap₂ (v : V) : (DistanceTwo G v).card≤d := distanceTwo_le_of_even d v (cap v)
  have pack := high_omitted_pin_budget hc d k cap conn hp hx (Graffiti189LongestPath.pin_data hi).2 xh
  have p3 : (Pins p x).card≤sl := by dsimp [d] at pack; omega
  have w3 : W.card≤sl := by change k+(Pins p x).card+W.card≤d at pack; dsimp [d] at pack; omega
  have rad (z : V) : G.dist x z≤4 := by
    by_contra! far
    have c := shell_card_of_far hc k conn (x:=x) (y:=z) (i:=4) (by decide) (by omega)
    change k≤W.card at c
    omega
  let loss := sl+1-(Pins p x).card
  have height : k+loss≤A.card := by
    have e := star_card_degree_and_pins hp hx
    change A.card+(Pins p x).card=G.degree x+1 at e
    dsimp [loss,d] at *
    omega
  have first := GapOne.first_pins_at_least_pins_sub_one hc d cap deg hmin.1 hx xh (by dsimp [d]; omega)
  have bp : B.card+(Pins p x).card≤d+1 := by
    have f := boundary_flank_count hc hp hx
    rw [flank_count_exact hp hx] at f
    have c := cap₂ x
    change B.card+((Pins p x).card+(FirstPins p x).card)≤
      (DistanceTwo G x).card+(Pins p x).card at f
    omega
  have bk : B.card≤k+loss := by
    dsimp [d] at bp
    dsimp [loss]
    omega
  have floor (z : V) : 2≤G.degree z := by
    have ne : a≠x := fun e => hx (e ▸ p.start_mem_support)
    have n := enough_vertices_of_degree (k+sl) deg ne
    have kdeg := degree_floor_when_enough_vertices k conn (by omega) z
    omega
  have largeP := longest_length_ge_twice_of_not_traceable hc d (by omega) floor deg fail hp
  have far : k≤U.card := by
    have cover : p.support.toFinset⊆B∪U := by
      intro z hz
      by_cases zb : z∈B
      · exact mem_union.mpr (Or.inl zb)
      have za : z∉A := fun e => (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp e).1 (List.mem_toFinset.mp hz)
      exact mem_union.mpr (Or.inr (mem_sdiff.mpr ⟨mem_univ z,fun e => (mem_union.mp e).elim za zb⟩))
    have h := (card_le_card cover).trans (card_union_le B U)
    rw [List.toFinset_card_of_nodup hp.1.support_nodup,length_support] at h
    dsimp [d] at largeP
    omega
  let T := A.erase x
  let J := G.induce (T:Set V)
  let L := T.filter (fun v => G.degree v<d)
  let m := (k-2)/2
  have xA : x∈A := Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
  have L1 : L.card≤1 := by
    apply Nat.le_of_not_gt
    intro e
    obtain ⟨u,uu,v,vv,ne⟩ := one_lt_card.mp (show 1<L.card from e)
    have e₁ := (mem_filter.mp uu).2
    have e₂ := (mem_filter.mp vv).2
    exact (deg u v ne).elim (Nat.not_le_of_lt e₁) (Nat.not_le_of_lt e₂)
  have highJ (v : V) (vt : v∈T) (vl : v∉L) : m≤(T.filter (G.Adj v)).card := by
    let v' : ↥(T:Set V) := ⟨v,vt⟩
    have vh : d≤G.degree v := Nat.le_of_not_gt (fun h => vl (mem_filter.mpr ⟨vt,h⟩))
    have b := (quadratic_root_deleted_degrees hc k sl loss cap conn hp hx bk far v').2 vh
    change A.card≤2*J.degree v'+loss+3 at b
    have id := induced_degree_count (G:=G) T v'
    change (T.filter (G.Adj v)).card=J.degree v' at id
    dsimp [m]
    omega
  have floorJ (v : ↥(T:Set V)) : 2≤J.degree v := by
    have b := (quadratic_root_deleted_degrees hc k sl loss cap conn hp hx bk far v).1
    change A.card≤2*J.degree v+sl+loss+3 at b
    omega
  have lowJ (v : V) (vt : v∈T) (_vl : v∈L) : 1≤(T.filter (G.Adj v)).card := by
    let v' : ↥(T:Set V) := ⟨v,vt⟩
    have b := floorJ v'
    have id := induced_degree_count (G:=G) T v'
    change (T.filter (G.Adj v)).card=J.degree v' at id
    omega
  have highDegree (v : ↥(T:Set V)) (vh : d≤G.degree v.val) : m≤J.degree v := by
    have u := highJ v.val v.property (fun e => (Nat.not_lt_of_ge vh) (mem_filter.mp e).2)
    have eq := induced_degree_count (G:=G) T v
    change (T.filter (G.Adj v.val)).card=J.degree v at eq
    omega
  have root (v : V) (va : v∈A) (ne : v≠x) : G.Adj x v :=
    ((Graffiti189LongestPath.Rigidity.mem_omittedStar.mp va).2).resolve_left ne
  have routes := one_low_universal_uniform_routes A L x xA root L1 m highJ lowJ
  have ao : ∀ v∈A,v∉p.support := fun _ va =>
    (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp va).1
  obtain ⟨F⟩ := hooks_of_small_deletion_connectivity A k hp ao (by omega) (support_large k conn hp hx) conn
  have bound := weighted_hooked_lower k (by omega) hp (m+1) A ao (by omega) routes F
  have low : A.card+k+(k+1)*(m+1)≤Fintype.card V := by omega
  have order := order_le_radius_four_layers hc x rad
  change Fintype.card V≤G.degree x+1+(DistanceTwo G x).card+H.card+W.card at order
  have base : Fintype.card V≤A.card+k+2*sl+H.card := by
    have d₂ := cap₂ x
    have degX := star_card_degree_and_pins hp hx
    change A.card+(Pins p x).card=G.degree x+1 at degX
    change k+(Pins p x).card+W.card≤d at pack
    dsimp [d] at d₂ pack
    omega
  by_cases robust : ∀ S : Finset ↥(T:Set V), S.card<2 →
      (J.induce ((↑S:Set _)ᶜ)).Connected
  · have vc : Fintype.card ↥(T:Set V)=A.card-1 := by
      change Fintype.card ↥T=A.card-1
      exact (Fintype.card_coe T).trans (card_erase_of_mem xA)
    have md : 2≤m := by dsimp [m]; omega
    have pair (u v : ↥(T:Set V)) (ne : u≠v) : m≤J.degree u ∨ m≤J.degree v :=
      (deg u.val v.val (fun e => ne (Subtype.ext e))).imp (highDegree u) (highDegree v)
    obtain ⟨r,c,cc,cl⟩ := proved_one_low_circumference _ J m md (by omega) robust floorJ pair
    have lim : k-3≤c.length := by
      have bm : 2*m≤A.card-1 := by dsimp [m]; omega
      have bm' : 2*m≤Fintype.card ↥(T:Set V) := by rw [vc]; exact bm
      rw [min_eq_right bm'] at cl
      dsimp [m] at cl
      omega
    have routesLong := routes_of_explicit_root_deleted_cycle hx robust (k-3)
      ⟨r,c,cc,by omega⟩
    have lowLong := weighted_hooked_lower k (by omega) hp (k-3+1) A ao (by omega) routesLong F
    have lowLong' : A.card+k+(k+1)*(k-2)≤Fintype.card V := by
      rw [show k-3+1=k-2 by omega] at lowLong
      omega
    have shell := universal_shell_three_quadratic hc d cap₂ x
    change 4*H.card≤(d+1)*(d+1) at shell
    have small : (d+1)*(d+1)+8*sl<4*((k+1)*(k-2)) := by
      have v : d+1≤2*k-6 := by dsimp [d]; omega
      have sq := Nat.mul_le_mul v v
      have eq : (2*k-6)*(2*k-6)+24*k=4*(k*k)+36 := by
        let t := k-3
        have kt : k=t+3 := by dsimp [t]; omega
        rw [show 2*k-6=2*t by dsimp [t]; omega]
        rw [kt]
        ring
      have ev : (k+1)*(k-2)+k+2=k*k := by
        let t := k-2
        have kt : k=t+2 := by dsimp [t]; omega
        rw [show k-2=t from rfl,kt]
        ring
      omega
    have um : 4*Fintype.card V<4*(A.card+k+(k+1)*(k-2)) := by
      calc
        _ ≤ 4*(A.card+k+2*sl+H.card) := Nat.mul_le_mul_left 4 base
        _ = 4*(A.card+k)+(4*H.card+8*sl) := by ring
        _ ≤ 4*(A.card+k)+((d+1)*(d+1)+8*sl) :=
          Nat.add_le_add_left (Nat.add_le_add_right shell _) _
        _ < 4*(A.card+k)+4*((k+1)*(k-2)) := Nat.add_lt_add_left small _
        _ = _ := by ring
    omega
  obtain ⟨S,sm,failS⟩ : ∃ S : Finset ↥(T:Set V),S.card<2 ∧ ¬(J.induce ((↑S:Set _)ᶜ)).Connected := by
    apply Classical.byContradiction
    intro neg
    apply robust
    intro S sm
    exact Classical.byContradiction (fun bad => neg ⟨S,sm,bad⟩)
  let emb : ↥(T:Set V) ↪ V := ⟨Subtype.val,Subtype.val_injective⟩
  let X := insert x (S.map emb)
  have xx : x∈X := mem_insert_self _ _
  have xsub : X⊆A := by
    intro z zz
    rcases mem_insert.mp zz with rfl|zz
    · exact xA
    · obtain ⟨v,_,rfl⟩ := mem_map.mp zz
      exact (mem_erase.mp v.property).2
  have xs : X.card≤2 := by
    have h := card_insert_le x (S.map emb)
    rw [card_map] at h
    change X.card≤S.card+1 at h
    omega
  have iso := erase_root_and_set_iso (G:=G) A x S
  have bad : ¬(G.induce (↑(A\X):Set V)).Connected := fun h => failS (iso.connected_iff.mp h)
  have nAX : (A\X).Nonempty := card_pos.mp (by
    have e := card_sdiff_add_card_eq_card xsub
    omega)
  obtain ⟨C,E,part,ce,no,cn,en,smaller⟩ : ∃ C E : Finset V,
      C∪E=A\X ∧ Disjoint C E ∧ (∀ u∈C,∀ v∈E,¬G.Adj u v) ∧
      C.Nonempty ∧ E.Nonempty ∧ C.card≤E.card := by
    obtain ⟨C,E,part,ce,no,cn,en⟩ := partition_of_not_connected (A\X) nAX bad
    by_cases smaller : C.card≤E.card
    · exact ⟨C,E,part,ce,no,cn,en,smaller⟩
    · exact ⟨E,C,(union_comm E C).trans part,ce.symm,
        fun v ve u uc ed => no u uc v ve ed.symm,en,cn,by omega⟩
  have lc := side_order_at_least_half A C E X x d (k-1) xx xsub xs part ce cn no deg floorJ highDegree
  let P := PinVertices p x
  let ell := sl-(Pins p x).card
  have lossEq : loss=ell+1 := by dsimp [loss,ell]; omega
  have sP (v : V) (vp : v∈P) : v∈p.support := by
    obtain ⟨j,_,rfl⟩ := mem_image.mp vp
    exact p.getVert_mem_support j
  have cX : Disjoint C X := disjoint_left.mpr (fun v vc vx =>
    (mem_sdiff.mp (part ▸ mem_union.mpr (Or.inl vc) : v∈A\X)).2 vx)
  have eX : Disjoint E X := disjoint_left.mpr (fun v ve vx =>
    (mem_sdiff.mp (part ▸ mem_union.mpr (Or.inr ve) : v∈A\X)).2 vx)
  have hpart : A=C∪E∪X := by rw [part]; exact (sdiff_union_of_subset xsub).symm
  have cA : C⊆A := by
    intro v vv
    have vx : v∈A\X := part ▸ mem_union.mpr (Or.inl vv)
    exact (mem_sdiff.mp vx).1
  have eA : E⊆A := by
    intro v vv
    have vx : v∈A\X := part ▸ mem_union.mpr (Or.inr vv)
    exact (mem_sdiff.mp vx).1
  have cx : x∉C := fun xc => disjoint_left.mp cX xc xx
  have ex : x∉E := fun xe => disjoint_left.mp eX xe xx
  have hcard : A.card=C.card+E.card+X.card := by
    have q := congrArg Finset.card hpart
    rw [card_union_of_disjoint (disjoint_union_left.mpr ⟨cX,eX⟩),card_union_of_disjoint ce] at q
    exact q
  have rootNbr : G.neighborFinset x=T∪P := by
    ext z
    rw [G.mem_neighborFinset,mem_union]
    constructor
    · intro adj
      by_cases zp : z∈p.support
      · obtain ⟨j,jp,e⟩ := Graffiti189LongestPath.OneSlack.pin_of_neighbor_mem hp hx zp adj
        exact Or.inr (mem_image.mpr ⟨j,jp,e⟩)
      exact Or.inl (mem_erase.mpr ⟨adj.ne.symm,
        Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨zp,Or.inr adj⟩⟩)
    · rintro (zt|zp)
      · exact root z (mem_erase.mp zt).2 (mem_erase.mp zt).1
      · obtain ⟨j,jp,rfl⟩ := mem_image.mp zp
        exact (Graffiti189LongestPath.pin_data jp).2
  have removeRoot (R Y : Finset V) (prt : A=R∪Y)
      (dry : Disjoint R Y) (xy : x∈Y) : R∪Y.erase x=T := by
    ext z
    change z∈R∪Y.erase x↔z∈A.erase x
    rw [prt]
    constructor
    · intro h
      rcases mem_union.mp h with hr|hy
      · exact mem_erase.mpr ⟨fun e => disjoint_left.mp dry hr (e.symm ▸ xy),
          mem_union.mpr (Or.inl hr)⟩
      · exact mem_erase.mpr ⟨(mem_erase.mp hy).1,mem_union.mpr (Or.inr (mem_erase.mp hy).2)⟩
    · intro h
      rcases mem_union.mp (mem_erase.mp h).2 with hr|hy
      · exact mem_union.mpr (Or.inl hr)
      · exact mem_union.mpr (Or.inr (mem_erase.mpr ⟨(mem_erase.mp h).1,hy⟩))
  have leafPartition (R Y : Finset V) (prt : A=R∪Y)
      (dry : Disjoint R Y) (xy : x∈Y) : R∪P∪Y.erase x=G.neighborFinset x := by
    rw [rootNbr,←removeRoot R Y prt dry xy]
    ac_rfl
  have boundSide (R Y : Finset V) (rA : R⊆A) (dRY : Disjoint R Y) (xY : x∈Y)
      (small : (Y.erase x).card≤2)
      (nout : ∀ u∈R,∀ v∈A,v∉R → v∉Y → ¬G.Adj u v)
      (v : ↥(R:Set V)) :
      3≤(G.induce (R:Set V)).degree v ∧
      (d≤G.degree v.val →
        A.card≤2*(G.induce (R:Set V)).degree v+loss+3+2*(Y.erase x).card) := by
    have vx : v.val≠x := fun e => disjoint_left.mp dRY v.property (e.symm ▸ xY)
    let u : ↥(T:Set V) := ⟨v.val,mem_erase.mpr ⟨vx,rA v.property⟩⟩
    have y := SplitShoreThree.side_degree_loss A R Y x nout v.val v.property
    have c1 := induced_degree_count (G:=G) T u
    have c2 := induced_degree_count (G:=G) R v
    change (T.filter (G.Adj v.val)).card=J.degree u at c1
    change (T.filter (G.Adj v.val)).card≤(R.filter (G.Adj v.val)).card+(Y.erase x).card at y
    rw [c1,c2] at y
    have f := quadratic_root_deleted_degrees hc k sl loss cap conn hp hx bk far u
    have lo := f.1
    change A.card≤2*J.degree u+sl+loss+3 at lo
    refine ⟨by omega,?_⟩
    intro vh
    have hi := f.2 vh
    change A.card≤2*J.degree u+loss+3 at hi
    omega
  have noutC (u : V) (uc : u∈C) (v : V) (va : v∈A) (vn : v∉C) (vx : v∉X) :
      ¬G.Adj u v := by
    have vcE : v∈C∪E := (mem_union.mp (hpart ▸ va)).resolve_right vx
    exact no u uc v ((mem_union.mp vcE).resolve_left vn)
  have noutE (u : V) (ue : u∈E) (v : V) (va : v∈A) (vn : v∉E) (vx : v∉X) :
      ¬G.Adj u v := by
    have vcE : v∈C∪E := (mem_union.mp (hpart ▸ va)).resolve_right vx
    exact fun ed => no v ((mem_union.mp vcE).resolve_right vn) u ue ed.symm
  have xx1 : (X.erase x).card≤1 := by have a := card_erase_add_one xx; omega
  have cs := boundSide C X cA cX xx (by omega) noutC
  have es := boundSide E X eA eX xx (by omega) noutE
  have sideHiC (v : ↥(C:Set V)) (hv : d≤G.degree v.val) :
      k-5≤2*(G.induce (C:Set V)).degree v := by have sh := (cs v).2 hv; omega
  have sideHiE (v : ↥(E:Set V)) (hv : d≤G.degree v.val) :
      k-5≤2*(G.induce (E:Set V)).degree v := by have sh := (es v).2 hv; omega
  by_cases tiny : E.card≤k-6
  · apply TwoSmallNormalized.small_split_impossible hc k sl large positive (by omega) hp hx first
      cap₂ conn deg (support_large k conn hp hx) C E X (X.erase x) hpart
      (leafPartition (C∪E) X hpart (disjoint_union_left.mpr ⟨cX,eX⟩) xx)
      xx xs xx1 ce cX eX no lc smaller tiny (fun u => (cs u).1) (fun u => (es u).1)
      sideHiC sideHiE (by change k≤A.card; omega)
      (by change d≤A.card+(Pins p x).card; have z := star_card_degree_and_pins hp hx;
          change A.card+(Pins p x).card=G.degree x+1 at z; omega) (by omega) bp base
  by_cases robustE : ∀ S : Finset ↥(E:Set V),S.card<2 →
      ((G.induce (E:Set V)).induce ((↑S:Set _)ᶜ)).Connected
  · have eh (u v : ↥(E:Set V)) (ne : u≠v) :
        A.card≤2*(G.induce (E:Set V)).degree u+loss+5 ∨
        A.card≤2*(G.induce (E:Set V)).degree v+loss+5 :=
      (deg u.val v.val (fun e => ne (Subtype.ext e))).imp
        (fun uhi => by have u := (es u).2 uhi; omega) (fun vhi => by have v := (es v).2 vhi; omega)
    have sh := universal_shell_three_quadratic hc d cap₂ x
    exact LargeRobustShore.robust_large_shore_impossible k sl A.card loss H.card
      (by omega) (by omega) (by dsimp [loss]; omega) height hp hx
      E ex (fun u ue => ao u (eA ue)) (fun u ue => root u (eA ue) (fun e => ex (e ▸ ue)))
      (by omega) (by omega) conn robustE (support_large k conn hp hx) (fun u => (by have e := (es u).1; omega))
      eh base sh
  obtain ⟨D,Q,Y,subY,yc,eqA,dn,qn,cd,cq,dq,ry,nCD,nCQ,nDQ⟩ :=
    SplitShoreThree.split_third_shore_after_one_more_deletion A C E X hpart ce cX eX no
      (by omega) robustE
  have yx : x∈Y := subY xx
  have y3 : Y.card≤3 := by omega
  have y2 : (Y.erase x).card≤2 := by have a := card_erase_add_one yx; omega
  let M (i : Fin 3) := if i=0 then C else if i=1 then D else Q
  let R := univ.biUnion M
  have Rform : R=C∪D∪Q := by
    ext v
    constructor
    · intro h
      obtain ⟨i,_,vv⟩ := mem_biUnion.mp h
      fin_cases i
      · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inl (by simpa [M] using vv))))
      · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inr (by simpa [M] using vv))))
      · exact mem_union.mpr (Or.inr (by simpa [M] using vv))
    · intro h
      rcases mem_union.mp h with h|h
      · rcases mem_union.mp h with h|h
        · exact mem_biUnion.mpr ⟨0,mem_univ _,by simpa [M] using h⟩
        · exact mem_biUnion.mpr ⟨1,mem_univ _,by simpa [M] using h⟩
      · exact mem_biUnion.mpr ⟨2,mem_univ _,by simpa [M] using h⟩
  have prt : A=R∪Y := by rw [Rform]; exact eqA
  have ry' : Disjoint R Y := by rw [Rform]; exact ry
  have mdis : Pairwise (fun i j => Disjoint (M i) (M j)) := by
    intro i j ne
    fin_cases i <;> fin_cases j
    · exact (ne rfl).elim
    · simpa [M] using cd
    · simpa [M] using cq
    · simpa [M] using cd.symm
    · exact (ne rfl).elim
    · simpa [M] using dq
    · simpa [M] using cq.symm
    · simpa [M] using dq.symm
    · exact (ne rfl).elim
  have mno (i j : Fin 3) (ne : i≠j) (u : V) (ui : u∈M i) (v : V) (vj : v∈M j) :
      ¬G.Adj u v := by
    fin_cases i <;> fin_cases j
    · exact (ne rfl).elim
    · exact nCD u (by simpa [M] using ui) v (by simpa [M] using vj)
    · exact nCQ u (by simpa [M] using ui) v (by simpa [M] using vj)
    · exact fun h => nCD v (by simpa [M] using vj) u (by simpa [M] using ui) h.symm
    · exact (ne rfl).elim
    · exact nDQ u (by simpa [M] using ui) v (by simpa [M] using vj)
    · exact fun h => nCQ v (by simpa [M] using vj) u (by simpa [M] using ui) h.symm
    · exact fun h => nDQ v (by simpa [M] using vj) u (by simpa [M] using ui) h.symm
    · exact (ne rfl).elim
  have mR (i : Fin 3) : M i⊆R := fun _ e => mem_biUnion.mpr ⟨i,mem_univ _,e⟩
  have mA (i : Fin 3) : M i⊆A := by
    intro v vv
    rw [prt]
    exact mem_union.mpr (Or.inl (mR i vv))
  have mY (i : Fin 3) : Disjoint (M i) Y := disjoint_left.mpr (fun _ hi hj =>
    disjoint_left.mp ry' (mR i hi) hj)
  have mOut (i : Fin 3) (u : V) (ui : u∈M i) (v : V) (va : v∈A) (vn : v∉M i) (vy : v∉Y) :
      ¬G.Adj u v := by
    have vr : v∈R := (mem_union.mp (prt ▸ va)).resolve_right vy
    obtain ⟨j,_,vj⟩ := mem_biUnion.mp vr
    exact mno i j (fun e => vn (e.symm ▸ vj)) u ui v vj
  have nonemptyM (i : Fin 3) : (M i).Nonempty := by
    fin_cases i
    · simpa [M] using cn
    · simpa [M] using dn
    · simpa [M] using qn
  have bases (i : Fin 3) := boundSide (M i) Y (mA i) (mY i) yx y2 (mOut i)
  let m3 := (A.card-ell-7)/2
  have m3L : A.card≤2*m3+ell+8 := by dsimp [m3]; omega
  have m3U : 2*m3+ell≤A.card := by dsimp [m3]; omega
  have m3pos : 2≤m3 := by dsimp [m3]; omega
  have mdegree (i : Fin 3) (u : ↥(M i:Set V)) (hi : d≤G.degree u.val) :
      m3≤(G.induce (M i:Set V)).degree u := by
    have b := (bases i u).2 hi
    dsimp [m3]
    omega
  have sizes (i : Fin 3) : m3+1≤(M i).card := by
    obtain ⟨v,vi⟩ := nonemptyM i
    let v' : ↥(M i:Set V) := ⟨v,vi⟩
    have c := (bases i v').1
    have eq : Fintype.card ↥(M i:Set V)=(M i).card := Fintype.card_coe (M i)
    have vv := (G.induce (M i:Set V)).degree_lt_card_verts v'
    obtain ⟨u,ui,w,wi,ne⟩ := one_lt_card.mp (show 1<(M i).card by omega)
    have h : ∃ z∈M i,d≤G.degree z :=
      (deg u w ne).elim (fun a => ⟨u,ui,a⟩) (fun a => ⟨w,wi,a⟩)
    obtain ⟨z,zi,zh⟩ := h
    let z' : ↥(M i:Set V) := ⟨z,zi⟩
    have d' := mdegree i z' zh
    have e := (G.induce (M i:Set V)).degree_lt_card_verts z'
    omega
  have sumSize : A.card=C.card+D.card+Q.card+Y.card := by
    have eq := congrArg Finset.card eqA
    rw [card_union_of_disjoint ry,card_union_of_disjoint (disjoint_union_left.mpr ⟨cq,dq⟩),
      card_union_of_disjoint cd] at eq
    exact eq
  have m3k : m3≤2*k := by
    have a := sizes (0:Fin 3)
    have b := sizes (1:Fin 3)
    have c := sizes (2:Fin 3)
    simp [M] at a b c
    have elK : ell≤k := by dsimp [ell]; omega
    omega
  have tSide (i : Fin 3) (u : V) (ui : u∈M i) : u∈T :=
    mem_erase.mpr ⟨fun e => disjoint_left.mp (mY i) ui (e.symm ▸ yx),mA i ui⟩
  have high3 (i : Fin 3) (u : V) (ui : u∈M i) (ul : u∉L) :
      m3-1≤((M i).filter (G.Adj u)).card := by
    have hi : d≤G.degree u := Nat.le_of_not_gt (fun h => ul (mem_filter.mpr ⟨tSide i u ui,h⟩))
    let v : ↥(M i:Set V) := ⟨u,ui⟩
    have d := mdegree i v hi
    have b := induced_degree_count (G:=G) (M i) v
    change ((M i).filter (G.Adj u)).card=(G.induce (M i:Set V)).degree v at b
    omega
  have low3 (i : Fin 3) (u : V) (ui : u∈M i) (_ul : u∈L) :
      1≤((M i).filter (G.Adj u)).card := by
    let v : ↥(M i:Set V) := ⟨u,ui⟩
    have d := (bases i v).1
    have b := induced_degree_count (G:=G) (M i) v
    change ((M i).filter (G.Adj u)).card=(G.induce (M i:Set V)).degree v at b
    omega
  have highJ3 (v : V) (vt : v∈T) (vl : v∉L) : m3≤(T.filter (G.Adj v)).card := by
    let v' : ↥(T:Set V) := ⟨v,vt⟩
    have vh : d≤G.degree v := Nat.le_of_not_gt (fun h => vl (mem_filter.mpr ⟨vt,h⟩))
    have b := (quadratic_root_deleted_degrees hc k sl loss cap conn hp hx bk far v').2 vh
    change A.card≤2*J.degree v'+loss+3 at b
    have id := induced_degree_count (G:=G) T v'
    change (T.filter (G.Adj v)).card=J.degree v' at id
    dsimp [m3]
    omega
  have route3 := one_low_universal_uniform_routes A L x xA root L1 m3 highJ3 lowJ
  exact ThreeNormalized.three_split_impossible hc k sl m3 large (by omega) m3pos m3k hp hx first
    cap₂ conn deg (support_large k conn hp hx) M Y (Y.erase x) prt
    (leafPartition R Y prt ry' yx) yx y3 y2 ry' mdis mno sizes L L1 high3 low3 route3
    (by change k+ell≤A.card; omega) m3L m3U p3 bp base

/-- High-connectivity range of Graffiti.pc #189 asymptotically one half. -/
theorem traceable_of_half_connectivity (hc : G.Connected) (d k : Nat)
    (large : 1000000≤k) (ratio : d+100≤2*k)
    (cap : ∀ v,(EvenFrom G v).card≤d+1)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → d≤G.degree u ∨ d≤G.degree v) :
    ∃ (u v : V) (q : G.Walk u v),q.IsPath ∧ ∀ z,z∈q.support := by
  by_cases hk : 3*d≤5*k
  · exact Graffiti189LongestPath.ThreeFifthsDeficit.traceable_of_three_fifths_connectivity hc d k
      (by omega) hk cap conn deg
  have eq : k+(d-k)=d := by omega
  exact traceable_of_half_gap hc k (d-k) large (by omega) (by omega)
    (by simpa only [eq] using cap) conn (by simpa only [eq] using deg)

#print axioms traceable_of_half_gap
#print axioms traceable_of_half_connectivity
end Graffiti189LongestPath.HalfBandDeficit
