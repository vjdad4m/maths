import HookRetarget189
import FlexibleSpacing189
import FanWeighted189
open Finset SimpleGraph SimpleGraph.Walk
open Graffiti189LongestPath Graffiti189LongestPath.Rigidity Graffiti189LongestPath.FanRoutable
open Graffiti189LongestPath.HookRetarget Graffiti189LongestPath.FlexibleSpacing
open Graffiti189LongestPath.EndpointSplice Graffiti189LongestPath.WideWing
open private Graffiti189LongestPath.FanRoutable.path_append_separated from FanLower189
open scoped BigOperators
set_option warningAsError true
set_option maxHeartbeats 6500000
namespace Graffiti189LongestPath.ColoredFan
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

omit [DecidableEq V] [DecidableRel G.Adj] in
private theorem hook_room {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    {A : Finset V} (ao : ∀ z∈A,z∉p.support)
    {i : Nat} (ii : i<p.length) (T : SingleHook p A i)
    {v : V} (q : G.Walk T.root v) (qp : q.IsPath) (qs : ∀ z∈q.support,z∈A) :
    q.length+1≤i ∧ i+q.length+1≤p.length := by
  let r := T.tail.reverse.append q
  have rp : r.IsPath := Graffiti189LongestPath.FanRoutable.path_append_separated T.simple.reverse qp (by
    intro z zr zq
    exact T.onlyRoot z (by simpa only [support_reverse,List.mem_reverse] using zr) (qs z zq))
  have ro : ∀ z∈r.support,z∉p.support := by
    intro z hz
    rw [show r=T.tail.reverse.append q from rfl,support_append,List.mem_append] at hz
    exact hz.elim (fun h => T.off z (by simpa only [support_reverse,List.mem_reverse] using h))
      (fun h => ao z (qs z (List.mem_of_mem_tail h)))
  have e := endpoint_room hp r rp ro ii.le T.finish.symm
  simp only [r,length_append,length_reverse] at e
  omega

omit [DecidableEq V] in
private theorem hook_gap {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    {A : Finset V} (ao : ∀ z∈A,z∉p.support)
    {i j : Nat} (lt : i<j) (ii : i<p.length) (jj : j<p.length)
    (L : SingleHook p A i) (R : SingleHook p A j)
    (ds : List.Disjoint L.tail.support R.tail.support)
    (q : G.Walk L.root R.root) (qp : q.IsPath) (qs : ∀ z∈q.support,z∈A) :
    i+q.length+2≤j := by
  let l := L.tail.reverse.append q
  have lp : l.IsPath := Graffiti189LongestPath.FanRoutable.path_append_separated L.simple.reverse qp (by
    intro z zl zq
    exact L.onlyRoot z (by simpa only [support_reverse,List.mem_reverse] using zl) (qs z zq))
  let w := l.append R.tail
  have wp : w.IsPath := Graffiti189LongestPath.FanRoutable.path_append_separated lp R.simple (by
    intro z zl zr
    rw [show l=L.tail.reverse.append q from rfl,support_append,List.mem_append] at zl
    rcases zl with h|h
    · exact (ds (by simpa only [support_reverse,List.mem_reverse] using h) zr).elim
    · exact R.onlyRoot z zr (qs z (List.mem_of_mem_tail h)))
  have wo : ∀ z∈w.support,z∉p.support := by
    intro z hz
    rw [show w=l.append R.tail from rfl,support_append,List.mem_append] at hz
    rcases hz with hl|hr
    · rw [show l=L.tail.reverse.append q from rfl,support_append,List.mem_append] at hl
      exact hl.elim (fun h => L.off z (by simpa only [support_reverse,List.mem_reverse] using h))
        (fun h => ao z (qs z (List.mem_of_mem_tail h)))
    · exact R.off z (List.mem_of_mem_tail hr)
  have pi : i∈Pins p L.last := mem_filter.mpr ⟨mem_range.mpr ii,L.finish⟩
  have pj : j∈Pins p R.last := mem_filter.mpr ⟨mem_range.mpr jj,R.finish⟩
  have g := terminal_length_le_gap hp pi pj lt w wp wo
  simp only [w,l,length_append,length_reverse] at g
  omega

/-- A first port hitting two colors can always retarget to the color
opposite the next hook's root. The paths and the counted shore still
live in A; only their terminal set R is restricted. -/
theorem colored_flexible_hooked_lower (k H M : Nat) (kp : 0<k)
    {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    (A R : Finset V) (ao : ∀ z∈A,z∉p.support)
    (sub : R⊆A) (large : 1<R.card) (label : V→Nat)
    (route : ∀ u∈R,∀ v∈R,u≠v →
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈A) ∧ H≤q.length+1)
    (cross : ∀ u∈R,∀ v∈R,label u≠label v →
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈A) ∧ H+M≤q.length+1)
    (F : HookFamily p A k) (reg : ∀ i,F.root i∈R) :
    let flex := (univ : Finset (Fin k)).filter (fun i =>
      ∃ u∈R,∃ v∈R,G.Adj u (fromFamily F i).firstPort ∧
        G.Adj v (fromFamily F i).firstPort ∧ label u≠label v)
    A.card+k+(k+1)*H+flex.card*M≤Fintype.card V := by
  classical
  let ok (i : Fin k) := ∃ u∈R,∃ v∈R,G.Adj u (fromFamily F i).firstPort ∧
    G.Adj v (fromFamily F i).firstPort ∧ label u≠label v
  let g (i : Fin k) := if ok i then M else 0
  let I := (univ:Finset (Fin k)).map F.idx
  have sz : I.card=k := by simp [I]
  have roots_ne {i j : Fin k} (ne : i≠j) : F.root i≠F.root j := by
    intro e
    exact F.disj ne (F.path i).start_mem_support (e.symm ▸ (F.path j).start_mem_support)
  have retarget_disjoint {i j : Fin k} (ij : i≠j)
      (K : SingleHook p A (F.idx i))
      (ch : ∀ w∉A,w∈K.tail.support ↔ w∈(F.path i).support)
      (ne : K.root≠F.root j) : List.Disjoint K.tail.support (F.path j).support := by
    intro z zi zj
    by_cases za : z∈A
    · exact ne ((K.onlyRoot z zi za).symm.trans (F.single j z zj za))
    exact F.disj ij ((ch z za).mp zi) zj
  have baseline_room (i : Fin k) : H≤F.idx i ∧ F.idx i+H≤p.length := by
    obtain ⟨v,va,ne⟩ := exists_ne_of_one_lt_card large (F.root i)
    obtain ⟨r,rp,rs,rl⟩ := route (F.root i) (reg i) v va ne.symm
    have d := hook_room hp ao (F.idxLt i) (fromFamily F i) r rp rs
    omega
  have long_room (i : Fin k) (h : ok i) : F.idx i+H+M≤p.length := by
    obtain ⟨u,ur,v,vr,ue,_,ne⟩ := h
    obtain ⟨K,kr,_,_⟩ := retarget_first_port (fromFamily F i) ao u (sub ur) ue
    obtain ⟨q,qp,qs,ql⟩ := cross u ur v vr ne
    let s : G.Walk K.root v := q.copy kr.symm rfl
    have sp : s.IsPath := by simpa [s] using qp
    have ss : ∀ z∈s.support,z∈A := by simpa [s] using qs
    have sl : H+M≤s.length+1 := by simpa [s] using ql
    have d := hook_room hp ao (F.idxLt i) K s sp ss
    omega
  have base_gap (i j : Fin k) (ij : F.idx i<F.idx j) : F.idx i+H+1≤F.idx j := by
    have ne : i≠j := fun e => (Nat.lt_irrefl _) (e ▸ ij)
    obtain ⟨q,qp,qs,ql⟩ := route (F.root i) (reg i) (F.root j) (reg j) (roots_ne ne)
    have g := hook_gap hp ao ij (F.idxLt i) (F.idxLt j) (fromFamily F i) (fromFamily F j)
      (F.disj ne) q qp qs
    omega
  have long_gap (i j : Fin k) (ij : F.idx i<F.idx j) (fi : ok i) :
      F.idx i+H+1+M≤F.idx j := by
    have ne : i≠j := fun e => (Nat.lt_irrefl _) (e ▸ ij)
    have find : ∃ u∈A,G.Adj u (fromFamily F i).firstPort ∧ u≠F.root j ∧
        ∃ q : G.Walk u (F.root j),q.IsPath ∧ (∀ z∈q.support,z∈A) ∧ H+M≤q.length+1 := by
      obtain ⟨u,ur,v,vr,ue,ve,diff⟩ := fi
      by_cases same : label u=label (F.root j)
      · have vn : label v≠label (F.root j) := fun eq => diff (same.trans eq.symm)
        exact ⟨v,sub vr,ve,fun e => vn (congrArg label e),cross _ vr _ (reg j) vn⟩
      · exact ⟨u,sub ur,ue,fun e => same (congrArg label e),cross _ ur _ (reg j) same⟩
    obtain ⟨u,ua,ue,uj,q,qp,qs,ql⟩ := find
    obtain ⟨K,kr,_,ch⟩ := retarget_first_port (fromFamily F i) ao u ua ue
    let r : G.Walk K.root (F.root j) := q.copy kr.symm rfl
    have rp : r.IsPath := by simpa [r] using qp
    have rs : ∀ z∈r.support,z∈A := by simpa [r] using qs
    have rl : H+M≤r.length+1 := by simpa [r] using ql
    have g := hook_gap hp ao ij (F.idxLt i) (F.idxLt j) K (fromFamily F j)
      (retarget_disjoint ne K ch (fun e => uj (kr.symm.trans e))) r rp rs
    omega
  let gf (j : Nat) := if hj : ∃ i,F.idx i=j then g (Classical.choose hj) else 0
  let lf (_j : Nat) : Nat := 0
  have ge (i : Fin k) : gf (F.idx i)=g i := by
    have hj : ∃ j,F.idx j=F.idx i := ⟨i,rfl⟩
    dsimp [gf]; rw [dif_pos hj,F.idx.injective (Classical.choose_spec hj)]
  have bas := one_sided_weighted_span H p.length I gf lf (by omega : 0<I.card)
    (by intro i hi; obtain ⟨j,_,rfl⟩ := mem_map.mp hi; exact (baseline_room j).1)
    (by
      intro i hi
      obtain ⟨j,_,rfl⟩ := mem_map.mp hi
      rw [ge]
      by_cases q : ok j
      · simpa [g,q] using long_room j q
      · simpa [g,q] using (baseline_room j).2)
    (by
      intro i hi j hj e
      obtain ⟨u,_,rfl⟩ := mem_map.mp hi
      obtain ⟨v,_,rfl⟩ := mem_map.mp hj
      rw [ge]
      by_cases fi : ok u
      · simpa [g,lf,fi] using long_gap u v e fi
      · have h := base_gap u v e
        simpa [g,lf,fi] using h)
  let U := (univ:Finset (Fin k)).filter ok
  have sg : (∑ i∈I,gf i)=U.card*M := by
    rw [show (∑ i∈I,gf i)=∑ i : Fin k,g i by simp [I,sum_map,ge]]
    change (∑ i ∈ (univ:Finset (Fin k)), if ok i then M else 0)=_
    rw [←Finset.sum_filter]
    exact Finset.sum_const_nat (fun _ _ => rfl)
  rw [sz,sg] at bas
  simp [lf] at bas
  have dj : Disjoint A p.support.toFinset := disjoint_left.mpr (fun _ h g => ao _ h (List.mem_toFinset.mp g))
  have room := card_le_univ (A∪p.support.toFinset)
  rw [card_union_of_disjoint dj,List.toFinset_card_of_nodup hp.1.support_nodup,length_support] at room
  change A.card+k+(k+1)*H+U.card*M≤Fintype.card V
  omega

#print axioms colored_flexible_hooked_lower
end Graffiti189LongestPath.ColoredFan
