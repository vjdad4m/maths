import FanLower189
import Mathlib.Data.Fintype.EquivFin
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.FanRoutable Graffiti189LongestPath.Rigidity
set_option maxHeartbeats 4000000
namespace Graffiti189LongestPath.FilterRootHooks

variable {V : Type*} [DecidableEq V] {G : SimpleGraph V}

theorem retain_regular_roots {a b : V} {p : G.Walk a b} (A X : Finset V) (k : Nat)
    (F : HookFamily p A k) :
    ∃ (j : Nat) (F' : HookFamily p A j),j≤k ∧ k≤j+X.card ∧ ∀ i,F'.root i∈A\X := by
  classical
  let regular := (univ : Finset (Fin k)).filter (fun i => F.root i∉X)
  let cut := (univ : Finset (Fin k))\regular
  have inj : Function.Injective F.root := by
    intro i j eq
    apply Classical.byContradiction
    intro ne
    exact F.disj ne (F.path i).start_mem_support (eq.symm ▸ (F.path j).start_mem_support)
  have subset : cut.image F.root⊆X := by
    intro z zz
    obtain ⟨i,ii,rfl⟩ := mem_image.mp zz
    exact Classical.byContradiction (fun h => (mem_sdiff.mp ii).2 (mem_filter.mpr ⟨mem_univ _,h⟩))
  have bad := card_le_card subset
  rw [card_image_of_injective _ inj] at bad
  have add := card_sdiff_add_card_eq_card (subset_univ regular)
  rw [card_univ,Fintype.card_fin] at add
  change cut.card+regular.card=k at add
  have ec : Fintype.card (Fin regular.card)=Fintype.card ↥regular := by
    rw [Fintype.card_fin,Fintype.card_coe]
  let e₀ : Fin regular.card ≃ ↥regular := Fintype.equivOfCardEq ec
  let e : Fin regular.card ↪ Fin k := e₀.toEmbedding.trans ⟨Subtype.val,Subtype.val_injective⟩
  let T : HookFamily p A regular.card := {
    idx := e.trans F.idx
    root := fun i => F.root (e i)
    last := fun i => F.last (e i)
    path := fun i => F.path (e i)
    simple := fun i => F.simple (e i)
    idxLt := fun i => F.idxLt (e i)
    adjLast := fun i => F.adjLast (e i)
    firstIn := fun i => F.firstIn (e i)
    single := fun i => F.single (e i)
    off := fun i => F.off (e i)
    disj := by intro i j ne; exact F.disj (fun w => ne (e.injective w)) }
  refine ⟨regular.card,T,by omega,by omega,?_⟩
  intro i
  have r : e i∈regular := (e₀ i).property
  exact mem_sdiff.mpr ⟨F.firstIn (e i),(mem_filter.mp r).2⟩

#print axioms retain_regular_roots
end Graffiti189LongestPath.FilterRootHooks
