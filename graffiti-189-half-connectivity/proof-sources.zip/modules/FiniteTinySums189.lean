import Mathlib.Tactic.FinCases
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
open Finset
open scoped BigOperators
namespace Graffiti189LongestPath.FiniteTinySums
theorem sum_two (F : Fin 2→Nat) : (∑ i,F i)=F 0+F 1 := by
  have e : (univ:Finset (Fin 2))={0,1} := by
    ext i
    fin_cases i <;> simp
  rw [e,Finset.sum_insert (by decide),Finset.sum_singleton]
theorem sum_three (F : Fin 3→Nat) : (∑ i,F i)=F 0+F 1+F 2 := by
  have e : (univ:Finset (Fin 3))={0,1,2} := by
    ext i
    fin_cases i <;> simp
  rw [e,Finset.sum_insert (by decide),Finset.sum_insert (by decide),Finset.sum_singleton]
  omega
end Graffiti189LongestPath.FiniteTinySums
