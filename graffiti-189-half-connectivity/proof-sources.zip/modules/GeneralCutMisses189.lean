import StrongDonorDegree189
open Finset SimpleGraph Graffiti189LongestPath
open Graffiti189LongestPath.StrongDonorDegree
namespace Graffiti189LongestPath.GeneralCutMisses
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- The sharp non-private reach estimate does not require a two-vertex
cut, and incurs exactly its order as the additive term. -/
theorem missed_boundary_of_side_with_high_vertex (d pp : Nat) (A B C E X : Finset V)
    (part : A=C∪E∪X) (cA : C⊆A)
    (no : ∀ u∈C,∀ v∈E,¬G.Adj u v)
    (closed : ∀ u∈A,∀ z∉A,G.Adj u z → z∈B)
    (bk : B.card+pp≤d+1)
    (v : V) (vc : v∈C) (high : d≤G.degree v) :
    (B.filter (fun z => ¬∃ u∈C,G.Adj u z)).card+pp≤C.card+X.card := by
  classical
  let M := B.filter (fun z => ¬∃ u∈C,G.Adj u z)
  have e := degree_upper_with_forbidden_ports A B C E X M part closed cA no v vc
    (filter_subset _ _) (fun z zm ed => (mem_filter.mp zm).2 ⟨v,vc,ed⟩)
  change M.card+pp≤C.card+X.card
  omega

#print axioms missed_boundary_of_side_with_high_vertex
end Graffiti189LongestPath.GeneralCutMisses
