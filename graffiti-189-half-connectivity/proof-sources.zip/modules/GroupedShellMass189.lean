import Mathlib.Algebra.BigOperators.Ring.Finset
import StrongDonorDegree189
import FlexSplitShell189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack Graffiti189LongestPath.PinRun
open Graffiti189LongestPath.ShellDonorFull Graffiti189LongestPath.StrongDonorDegree
open Graffiti189LongestPath.StrongDonorCharge
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
open private Graffiti189LongestPath.pin_data Graffiti189LongestPath.mem_distanceTwo from SmallSeparator189
open private Graffiti189LongestPath.OneSlack.card_pinVertices from OneSlack189
open private Graffiti189LongestPath.FlexSplitShell.count_group from FlexSplitShell189
open scoped BigOperators
set_option maxHeartbeats 10000000

namespace Graffiti189LongestPath.GroupedShellMass

variable {V α : Type*} [Fintype V] [DecidableEq V] [Fintype α]
  {G : SimpleGraph V} [DecidableRel G.Adj]
variable {a b x : V} {p : G.Walk a b}

/-- A common shell-mass accounting lemma for arbitrarily many mutually
nonadjacent shores. This gives the plain mass estimate, and optionally
the private-and-missed-port reserve for each side of a two-vertex cut. -/
theorem grouped_shell_mass (hc : G.Connected) (d : Nat)
    (hp : IsLongest p) (hx : x∉p.support)
    (gap : (Pins p x).card≤(FirstPins p x).card+1)
    (cap : ∀ v,(DistanceTwo G v).card≤d) (M : α→Finset V) (W X : Finset V)
    (part : OmittedStar p x=(univ.biUnion M)∪X)
    (partition : (univ.biUnion M)∪(PinVertices p x)∪W=G.neighborFinset x)
    (dx : Disjoint (univ.biUnion M) X) (xx : x∈X)
    (deg : ∀ u v : V,u≠v → d≤G.degree u ∨ d≤G.degree v)
    (dis : Pairwise (fun i j => Disjoint (M i) (M j)))
    (no : ∀ i j,i≠j → ∀ u∈M i,∀ v∈M j,¬G.Adj u v)
    (bk : (External G (OmittedStar p x)).card+(Pins p x).card≤d+1)
    (highSide : ∀ i,∃ v∈M i,d≤G.degree v) :
    let R := univ.biUnion M
    let pp := (Pins p x).card
    ∃ (k : α→Nat) (t : Nat),t≤pp ∧ (∑ i,k i)+t≤d ∧
      ((Shell G x 3).card + (∑ i,k i*(k i+(R\M i).card+pp))+t*((∑ i,k i)+t)
        ≤(d+2)*(∑ i,k i)+(d+1)*t+(W.card+1)*d) ∧
      (X.card≤2 → ∀ i,k i+pp+
        ((External G (OmittedStar p x)).filter (fun z => ¬∃ v∈M i,G.Adj v z)).card≤(M i).card+3) := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let P := PinVertices p x
  let pp := (Pins p x).card
  let H := Shell G x 3
  let R := univ.biUnion M
  let F := gateThird G x (DistanceTwo G x)
  obtain ⟨D,DA,cover,privateGate,every⟩ := exists_shell_donors_with_private_charges hc d cap x
  let K (i : α) := (D∩M i).filter (fun v => d≤G.degree v)
  let D₀ := univ.biUnion K
  let U := D∩P
  let Q := D\(D₀∪U)
  have parts (i : α) (v : V) (hk : v∈K i) : v∈D ∧ v∈M i ∧ d≤G.degree v := by
    obtain ⟨both,he⟩ := mem_filter.mp hk
    obtain ⟨h₁,h₂⟩ := mem_inter.mp both
    exact ⟨h₁,h₂,he⟩
  have mb (i : α) : M i⊆R := fun z hz => mem_biUnion.mpr ⟨i,mem_univ _,hz⟩
  have sb : R⊆A := by
    intro z zr
    change z∈OmittedStar p x
    rw [part]
    exact mem_union.mpr (Or.inl zr)
  have sD : D₀⊆D := by
    intro z zz
    obtain ⟨i,_,zi⟩ := mem_biUnion.mp zz
    exact (parts i z zi).1
  have sR : D₀⊆R := by
    intro z zz
    obtain ⟨i,_,zi⟩ := mem_biUnion.mp zz
    exact mb i (parts i z zi).2.1
  have tR (i : α) : K i⊆M i := fun v z => (parts i v z).2.1
  have dpart : Set.PairwiseDisjoint (↑(univ:Finset α) : Set α) K := by
    intro i _ j _ ne
    exact disjoint_left.mpr (fun _ ui uj => disjoint_left.mp (dis ne) (tR i ui) (tR j uj))
  have counts : D₀.card=∑ i,(K i).card := card_biUnion dpart
  have pinOff : Disjoint D₀ U := disjoint_left.mpr (by
    intro z zD zU
    obtain ⟨i,_,rfl⟩ := mem_image.mp (mem_inter.mp zU).2
    exact (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp (sb (sR zD))).1
      (p.getVert_mem_support i))
  have cd := card_sdiff_add_card_eq_card (union_subset sD (inter_subset_left : U⊆D))
  rw [card_union_of_disjoint pinOff,counts] at cd
  change Q.card+((∑i,(K i).card)+U.card)=D.card at cd
  have tn : U.card≤pp := (card_le_card (inter_subset_right : U⊆P)).trans
    (le_of_eq (Graffiti189LongestPath.OneSlack.card_pinVertices hp (x:=x)))
  have closed (u : V) (ua : u∈A) (z : V) (za : z∉A) (uz : G.Adj u z) : z∈B :=
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨za,u,ua,uz⟩
  have rep₀ (u : V) : ∃ g,u∈D → g∈DistanceTwo G x ∧ G.Adj u g ∧
      ∀ w∈D,w≠u → ¬G.Adj w g := by
    by_cases h : u∈D
    · obtain ⟨g,gg,ug,bad⟩ := privateGate u h
      exact ⟨g,fun _ => ⟨gg,ug,bad⟩⟩
    · exact ⟨x,fun e => (h e).elim⟩
  choose rep priv using rep₀
  have repr (u : V) (ud : u∈D₀) : rep u∈B := by
    have rd := Graffiti189LongestPath.mem_distanceTwo.mp (priv u (sD ud)).1
    have na : rep u∉A := by
      intro e
      rcases (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp e).2 with h|h
      · rw [h,dist_self] at rd; omega
      · have h' := dist_eq_one_iff_adj.mpr h; omega
    exact closed u (sb (sR ud)) (rep u) na (priv u (sD ud)).2.1
  have inj : Set.InjOn rep (↑D:Set V) := by
    intro u ud v vd e
    apply Classical.byContradiction
    intro ne
    exact (priv v vd).2.2 u ud ne (e ▸ (priv u ud).2.1)
  have allD : (D.image rep)⊆DistanceTwo G x := by
    intro z zz
    obtain ⟨u,ud,rfl⟩ := mem_image.mp zz
    exact (priv u ud).1
  have cardDon : D.card≤d := by
    have e := (card_le_card allD).trans (cap x)
    rw [card_image_of_injOn inj] at e
    exact e
  have vp : ∀ u∈D₀,rep u∈DistanceTwo G x ∧ G.Adj u (rep u) ∧
      ∀ w∈D₀,w≠u → ¬G.Adj w (rep u) := by
    intro u ud
    obtain ⟨a,b,c⟩ := priv u (sD ud)
    exact ⟨a,b,fun w wd ne => c w (sD wd) ne⟩
  have exc : Q.card≤W.card+1 := by
    let L := univ.filter (fun z : V => G.degree z<d)
    have qsub : Q⊆W∪L := by
      intro z zq
      obtain ⟨zd,r⟩ := mem_sdiff.mp zq
      have e : z∈R∪P∪W := partition.symm ▸ DA zd
      rcases mem_union.mp e with left|zw
      · rcases mem_union.mp left with zr|zp
        · by_cases hi : d≤G.degree z
          · obtain ⟨i,_,zi⟩ := mem_biUnion.mp zr
            have zD : z∈D₀ := mem_biUnion.mpr ⟨i,mem_univ _,mem_filter.mpr
              ⟨mem_inter.mpr ⟨zd,zi⟩,hi⟩⟩
            exact (r (mem_union.mpr (Or.inl zD))).elim
          · exact mem_union.mpr (Or.inr (mem_filter.mpr ⟨mem_univ _,by omega⟩))
        · exact (r (mem_union.mpr (Or.inr (mem_inter.mpr ⟨zd,zp⟩)))).elim
      exact mem_union.mpr (Or.inl zw)
    have ll : L.card≤1 := by
      apply Nat.le_of_not_gt
      intro e
      obtain ⟨u,uu,v,vv,ne⟩ := one_lt_card.mp (show 1<L.card from e)
      exact (deg u v ne).elim (Nat.not_le_of_lt (mem_filter.mp uu).2)
        (Nat.not_le_of_lt (mem_filter.mp vv).2)
    have l := (card_le_card qsub).trans (card_union_le W L)
    omega
  have cInt (i : α) : D₀∩M i=K i := by
    ext z
    constructor
    · intro h
      obtain ⟨zz,zi⟩ := mem_inter.mp h
      obtain ⟨j,_,zj⟩ := mem_biUnion.mp zz
      have e : j=i := Classical.byContradiction (fun ne =>
        disjoint_left.mp (dis ne) (tR j zj) zi)
      subst j
      exact zj
    · intro h
      exact mem_inter.mpr ⟨mem_biUnion.mpr ⟨i,mem_univ _,h⟩,tR i h⟩
  have hcard (i : α) : ((R\M i)\D₀).card+D₀.card=(R\M i).card+(K i).card := by
    have z : (R\M i)∩D₀=D₀\M i := by
      ext v
      constructor
      · intro e
        obtain ⟨rs,dd⟩ := mem_inter.mp e
        exact mem_sdiff.mpr ⟨dd,(mem_sdiff.mp rs).2⟩
      · intro e
        obtain ⟨dd,ni⟩ := mem_sdiff.mp e
        exact mem_inter.mpr ⟨mem_sdiff.mpr ⟨sR dd,ni⟩,dd⟩
    have q := card_sdiff_add_card_inter (R\M i) D₀
    have v := card_sdiff_add_card_inter D₀ (M i)
    rw [z] at q
    rw [cInt i] at v
    omega
  have xD₀ : x∉D₀ := fun ex => disjoint_left.mp dx (sR ex) xx
  have outside_no (i : α) (v : V) (vi : v∈M i) (w : V) (wn : w∈R\M i) : ¬G.Adj v w := by
    obtain ⟨wr,wno⟩ := mem_sdiff.mp wn
    obtain ⟨j,_,wj⟩ := mem_biUnion.mp wr
    have ij : i≠j := fun e => wno (e.symm ▸ wj)
    exact no i j ij v vi w wj
  have charge (i : α) (v : V) (vk : v∈K i) :
      (F v).card+((K i).card+(R\M i).card+pp)≤d+2 := by
    have vd : v∈D₀ := mem_biUnion.mpr ⟨i,mem_univ _,vk⟩
    let S := (R\M i)\D₀
    have sa : S⊆A := fun _ z => sb ((mem_sdiff.mp (mem_sdiff.mp z).1).1)
    have xn : x∉S := fun e => disjoint_left.mp dx ((mem_sdiff.mp (mem_sdiff.mp e).1).1) xx
    have ds : Disjoint D₀ S := disjoint_left.mpr (fun _ dd ss => (mem_sdiff.mp ss).2 dd)
    have nq : ∀ z∈S,¬G.Adj v z := fun z e => outside_no i v (tR i vk) z (mem_sdiff.mp e).1
    have d := omitted_donor_strong_charge hc d cap hp hx gap D₀ S (sR.trans sb) xD₀ sa xn ds v vd nq rep vp
    have c := hcard i
    change S.card+D₀.card=(R\M i).card+(K i).card at c
    change (F v).card+D₀.card+S.card+pp+_≤_ at d
    omega
  have hpin (v : V) (vu : v∈U) : (F v).card+((∑i,(K i).card)+U.card)≤d+1 := by
    have h := every v (mem_inter.mp vu).1 (∅:Finset V) (empty_subset _) (by simp)
    rw [empty_sdiff,card_empty,add_zero] at h
    have e : 0<D.card := card_pos.mpr ⟨v,(mem_inter.mp vu).1⟩
    change (F v).card+(D.card-1)≤d at h
    omega
  have hr (v : V) (vq : v∈Q) : (F v).card≤d := by
    have h := every v (mem_sdiff.mp vq).1 (∅:Finset V) (empty_subset _) (by simp)
    rw [empty_sdiff,card_empty,add_zero] at h
    exact le_trans (Nat.le_add_right _ _) h
  let T (i : α) := (K i).biUnion F
  let GT := univ.biUnion T
  let GU := U.biUnion F
  let GQ := Q.biUnion F
  have hcvr : H⊆GT∪GU∪GQ := by
    intro z zh
    obtain ⟨v,vd,vz⟩ := mem_biUnion.mp (cover zh)
    by_cases yes : v∈D₀∪U
    · rcases mem_union.mp yes with d0|u
      · obtain ⟨i,_,vi⟩ := mem_biUnion.mp d0
        exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inl (mem_biUnion.mpr
          ⟨i,mem_univ _,mem_biUnion.mpr ⟨v,vi,vz⟩⟩))))
      · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inr (mem_biUnion.mpr ⟨v,u,vz⟩))))
    · exact mem_union.mpr (Or.inr (mem_biUnion.mpr ⟨v,mem_sdiff.mpr ⟨vd,yes⟩,vz⟩))
  have ord : H.card≤(∑i,(T i).card)+GU.card+GQ.card := by
    have a := card_le_card hcvr
    have b := card_union_le GT GU
    have c := card_union_le (GT∪GU) GQ
    have e : GT.card≤∑i,(T i).card := card_biUnion_le
    omega
  have tBound : (∑ i,(T i).card)+(∑ i,(K i).card*((K i).card+(R\M i).card+pp))
      ≤ (d+2)*(∑ i,(K i).card) := by
    rw [←Finset.sum_add_distrib]
    calc
      _ ≤ ∑ i,(K i).card*(d+2) := by
        apply Finset.sum_le_sum
        intro i _
        exact Graffiti189LongestPath.FlexSplitShell.count_group (K i) F _ _ (charge i)
      _ = _ := by
        rw [Nat.mul_comm (d+2) (∑ i,(K i).card)]
        exact (Finset.sum_mul (univ:Finset α) (fun i => (K i).card) (d+2)).symm
  have uBound : GU.card+U.card*((∑i,(K i).card)+U.card)≤U.card*(d+1) :=
    Graffiti189LongestPath.FlexSplitShell.count_group U F _ _ hpin
  have qBound : GQ.card≤(W.card+1)*d := (card_biUnion_le_card_mul Q F d hr).trans
    (Nat.mul_le_mul_right _ exc)
  have mass : H.card+(∑ i,(K i).card*((K i).card+(R\M i).card+pp))+
      U.card*((∑i,(K i).card)+U.card)≤
      (d+2)*(∑i,(K i).card)+(d+1)*U.card+(W.card+1)*d := by
    rw [Nat.mul_comm (d+1) U.card]
    omega
  refine ⟨fun i => (K i).card,U.card,tn,?_,mass,?_⟩
  · change (∑i,(K i).card)+U.card≤d
    omega
  intro xs i
  have ci : M i⊆A := (mb i).trans sb
  have prt : A=M i∪(R\M i)∪X := by
    rw [union_comm (M i) (R\M i),sdiff_union_of_subset (mb i)]
    exact part
  by_cases emp : (K i).card=0
  · obtain ⟨v,vc,hi⟩ := highSide i
    have b := missing_ports_bound_by_side_order d A B (M i) (R\M i) X
      prt xs closed ci (outside_no i) pp bk v vc hi
    change (B.filter (fun z => ¬∃ v∈M i,G.Adj v z)).card+pp≤(M i).card+2 at b
    change (K i).card+pp+(B.filter (fun z => ¬∃ v∈M i,G.Adj v z)).card≤(M i).card+3
    omega
  · obtain ⟨v,vK⟩ := card_pos.mp (Nat.pos_of_ne_zero emp)
    exact side_bound_with_missing_reach_and_private_ports d A B (M i) (R\M i) X (K i)
      prt xs ci (outside_no i) closed pp bk v (tR i vK) vK (parts i v vK).2.2 rep (tR i)
      (fun w wk => ⟨repr w (mem_biUnion.mpr ⟨i,mem_univ _,wk⟩),(priv w (parts i w wk).1).2.1,
        fun z zk nz => (priv w (parts i w wk).1).2.2 z (parts i z zk).1 nz⟩)

#print axioms grouped_shell_mass
end Graffiti189LongestPath.GroupedShellMass
