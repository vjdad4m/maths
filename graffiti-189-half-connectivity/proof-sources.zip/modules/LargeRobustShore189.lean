import UniversalExtension189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.MengerRoutable
open Graffiti189LongestPath.FanWeighted Graffiti189LongestPath.PosaOneLow
open Graffiti189LongestPath.UniversalExtension
set_option maxHeartbeats 6000000
namespace Graffiti189LongestPath.LargeRobustShore

variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- In the normalized high-root regime, a shore of at least k vertices
which is 2-connected after deleting the root and the spare cut vertex
cannot occur in a counterexample. It is enough to route hooks from that
shore itself, discarding the single one that may touch the universal root. -/
theorem robust_large_shore_impossible (k s h loss H : Nat) (hk : 100≤k)
    (margin : k+s+60≤2*k) (lossK : loss+6≤k) (hlarge : k+loss≤h)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p) (xp : x∉p.support)
    (R : Finset V) (xr : x∉R) (rP : ∀ v∈R,v∉p.support)
    (adj : ∀ v∈R,G.Adj x v) (large : k-6≤R.card) (half : h≤2*R.card+2)
    (ambient : ∀ S : Finset V,S.card<k → (G.induce ((↑S:Set V)ᶜ)).Connected)
    (robust : ∀ S : Finset ↥(R:Set V),S.card<2 →
      ((G.induce (R:Set V)).induce ((↑S:Set _)ᶜ)).Connected)
    (spine : k≤p.support.toFinset.card)
    (floor : ∀ v : ↥(R:Set V),2≤(G.induce (R:Set V)).degree v)
    (high : ∀ u v : ↥(R:Set V),u≠v →
      h≤2*(G.induce (R:Set V)).degree u+loss+5 ∨
      h≤2*(G.induce (R:Set V)).degree v+loss+5)
    (radial : Fintype.card V≤h+k+2*s+H) (shell : 4*H≤(k+s+1)*(k+s+1)) :
    False := by
  classical
  let m := (h-loss-5)/2
  have m2 : 2≤m := by dsimp [m]; omega
  let J := G.induce (R:Set V)
  have high' (u v : ↥(R:Set V)) (ne : u≠v) : m≤J.degree u ∨ m≤J.degree v :=
    (high u v ne).imp (by dsimp [m,J]; omega) (by dsimp [m,J]; omega)
  have rc : Fintype.card ↥(R:Set V)=R.card := Fintype.card_coe R
  obtain ⟨z,c,cc,cl⟩ := proved_one_low_circumference _ J m m2 (by omega) robust floor high'
  have kcycle : k-6≤c.length := by
    have l : k-6≤min (Fintype.card ↥(R:Set V)) (2*m) :=
      le_min (by omega) (by dsimp [m]; omega)
    exact l.trans cl
  have hcycle : h≤R.card+c.length+6 := by
    have lb : h-R.card-6≤min (Fintype.card ↥(R:Set V)) (2*m) :=
      le_min (by omega) (by dsimp [m]; omega)
    have d := lb.trans cl
    omega
  have cycle2 : 2≤c.length := by omega
  let T := insert x R
  have ct : T.card=R.card+1 := card_insert_of_not_mem xr
  have toff (v : V) (vt : v∈T) : v∉p.support :=
    (mem_insert.mp vt).elim (fun e => by subst v; exact xp) (rP v)
  obtain ⟨F⟩ := hooks_of_small_deletion_connectivity R (k-6) hp rP large (by omega)
    (fun S sc => ambient S (by omega))
  obtain ⟨j,jk,⟨FF⟩⟩ := enlarge_hook_shore R x (k-6) F
  have rout := routes_of_cycle_in_universal_extension R x xr adj robust c.length
    ⟨z,c,cc,by omega⟩
  have lower := weighted_hooked_lower j (by omega) hp (c.length+1) T toff (by omega) rout FF
  have lo : R.card+(k-6)+(k-6)*(c.length+1)≤Fintype.card V := by
    have mono := Nat.mul_le_mul_right (c.length+1) jk
    omega
  have partBound : (k-6)*(c.length+1)≤c.length+12+2*s+H := by omega
  have split : (k-6)*(c.length+1)=(k-7)*(c.length+1)+(c.length+1) := by
    calc
      _ = (k-7+1)*(c.length+1) := congrArg (fun z : Nat => z*(c.length+1)) (by omega)
      _ = _ := by rw [Nat.add_mul,one_mul]
  have tall := Nat.mul_le_mul_left (k-7) (show k-5≤c.length+1 by omega)
  have lim : (k-7)*(k-5)≤H+2*s+11 := by omega
  have fact : (k-7)*(k-5)+12*k=k*k+35 := by
    let q := k-7
    have eq : k=q+7 := by dsimp [q]; omega
    have nk : k-5=q+2 := by omega
    rw [nk,show k-7=q from rfl,eq]
    ring
  have db : k+s+1≤2*(k-29) := by omega
  have sq := Nat.mul_le_mul db db
  have expand : (2*(k-29))*(2*(k-29))+232*k=4*(k*k)+3364 := by
    let q := k-29
    have eq : k=q+29 := by dsimp [q]; omega
    rw [show k-29=q from rfl,eq]
    ring
  have a := Nat.mul_le_mul_left 4 lim
  have alo : 4*((k-7)*(k-5))+48*k=4*(k*k)+140 := by
    calc
      _ = 4*((k-7)*(k-5)+12*k) := by ring
      _ = 4*(k*k+35) := congrArg (fun n : Nat => 4*n) fact
      _ = _ := by ring
  have blo : 4*(H+2*s+11)=4*H+8*s+44 := by ring
  omega

#print axioms robust_large_shore_impossible
end Graffiti189LongestPath.LargeRobustShore
