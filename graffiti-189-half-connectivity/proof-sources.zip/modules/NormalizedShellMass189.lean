import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

namespace Graffiti189LongestPath.NormalizedShellMass

theorem fine_two_shore_shell_cap
    (k d c e a b t p f H : ℤ)
    (hd : d≤2*k) (ce : c≤e) (eK : e≤k) (fK : f≤k)
    (hRoot : d-p≤c+e+2) (an : 0≤a) (bn : 0≤b) (tn : 0≤t) (tp : t≤p) (pk : p≤k)
    (sz : a+b+t≤d) (reserve : a+b+2*p≤c+f+10)
    (raw : H+a*(a+e+p)+b*(b+c+p)+t*(a+b+t)≤(d+2)*(a+b)+(d+1)*t+2*d) :
    2*H≤2*(a+b)*(e-p)-(a+b)^2+2*p*(2*k-p)+100*k := by
  let u := a+b
  have un : 0≤u := add_nonneg an bn
  have dz := mul_nonneg un (show 0≤c+e+2-(d-p) by omega)
  have en := mul_nonneg an (show 0≤e-c by omega)
  have tz := mul_nonneg tn (show 0≤2*k-d by omega)
  have l : 4*u+t+2*d≤12*k := by dsimp [u]; omega
  have mass : 2*H≤2*u*(e-t)-u^2+2*t*(2*k-t)+24*k := by
    dsimp [u] at dz l ⊢
    nlinarith only [raw,dz,en,tz,l,sq_nonneg (a-b)]
  have inc := mul_nonneg (show 0≤p-t by omega)
    (show 0≤2*k-p-t-u+10 by dsimp [u]; omega)
  have gap : p-t≤k := by omega
  change 2*H≤2*u*(e-p)-u^2+2*p*(2*k-p)+100*k
  nlinarith only [mass,inc,gap,show 0≤k by omega]

theorem fine_three_shore_shell_mass
    (k s p t h x c₁ c₂ c₃ a₁ a₂ a₃ H : ℤ)
    (sk : s≤k) (xs : x≤3) (an₁ : 0≤a₁) (an₂ : 0≤a₂) (an₃ : 0≤a₃) (tn : 0≤t)
    (sz : a₁+a₂+a₃+t≤k+s)
    (raw : H+a₁*(a₁+h-x-c₁+p)+a₂*(a₂+h-x-c₂+p)+a₃*(a₃+h-x-c₃+p)+
      t*(a₁+a₂+a₃+t)≤(k+s+2)*(a₁+a₂+a₃)+(k+s+1)*t+3*(k+s)) :
    H≤t*(2*k-t)+
      a₁*(k+(s-p)-h+c₁-t-a₁)+a₂*(k+(s-p)-h+c₂-t-a₂)+
      a₃*(k+(s-p)-h+c₃-t-a₃)+16*k := by
  have xz := mul_nonneg (show 0≤a₁+a₂+a₃ by omega) (show 0≤3-x by omega)
  have tz := mul_nonneg tn (show 0≤k-s by omega)
  have bound : 5*(a₁+a₂+a₃)+t+3*(k+s)≤16*k := by omega
  nlinarith only [raw,xz,tz,bound]

#print axioms fine_two_shore_shell_cap
#print axioms fine_three_shore_shell_mass
end Graffiti189LongestPath.NormalizedShellMass
