import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

namespace Graffiti189LongestPath.SmallShoreNumeric

/-- The two-small-shore regime's strengthened Ore spacing beats the
complementary donor shell upper bound. Constants leave ample room for
the bounded cut, parity overlap and finite normalization losses. -/
theorem two_small_contradiction (k d c e u f p h : ℤ)
    (hk : 1000000≤k) (hd : 5*k≤3*d)
    (cFloor : k-3≤2*c) (ce : c≤e) (eTop : e≤k)
    (highShore : d≤c+e+p+6)
    (un : 0≤u) (fn : 0≤f) (pn : 0≤p) (pTop : p≤k)
    (donor : u+2*p≤c+f+10)
    (mass : 2*h≤2*u*(e-p)-u^2+2*p*(2*k-p)+100*k)
    (spacing : k*c+e*f-100*k≤h) : False := by
  let T := u+2*p
  let L := 2*u*p+u^2+2*p^2
  have l0 : 0≤L := by
    dsimp [L]
    nlinarith only [sq_nonneg u,sq_nonneg p,mul_nonneg un pn]
  have ls : T^2≤2*L := by
    dsimp [T,L]
    nlinarith only [sq_nonneg u]
  have et := mul_nonneg fn (show 0≤e by omega)
  have margin := mul_nonneg (show 0≤k by omega) (show 0≤k-1000000 by omega)
  by_cases low : T≤c
  · have mul0 := mul_nonneg un (show 0≤k-e by omega)
    have top : 2*h≤2*k*T-L+100*k := by
      dsimp [T,L]
      nlinarith only [mass,mul0]
    by_cases small : 4*T≤k
    · have sz := mul_nonneg (show 0≤k by omega) (show 0≤k-4*T by omega)
      have cc := mul_nonneg (show 0≤k by omega) (show 0≤2*c-k+3 by omega)
      nlinarith only [top,spacing,sz,cc,et,margin,hk,l0]
    · have t2 : k^2≤16*T^2 := by
        nlinarith only [mul_nonneg (show 0≤4*T-k by omega) (show 0≤4*T+k by omega)]
      have d0 := mul_nonneg (show 0≤k by omega) (show 0≤c-T by omega)
      nlinarith only [top,spacing,d0,t2,ls,et,margin,hk]
  · have ed : e*(T-c-10)≤e*f := by
      have z : 0≤f-(T-c-10) := by dsimp [T]; omega
      nlinarith only [mul_nonneg (show 0≤e by omega) z]
    have top : 2*h-2*(k*c+e*f)≤2*(k-e)*(2*p-c)-L+120*k := by
      dsimp [T,L] at ed ⊢
      nlinarith only [mass,ed,eTop]
    by_cases psmall : 2*p≤c
    · have pr := mul_nonneg (show 0≤k-e by omega) (show 0≤c-2*p by omega)
      have t2 : (k-3)^2≤4*T^2 := by
        nlinarith only [mul_nonneg (show 0≤2*T-k+3 by omega) (show 0≤2*T+k-3 by omega)]
      nlinarith only [top,spacing,pr,t2,ls,margin,hk]
    · have lp : 2*p^2≤L := by
        dsimp [L]
        nlinarith only [sq_nonneg u,mul_nonneg un pn]
      by_cases wide : 11*k≤20*e
      · have pr := mul_nonneg (show 0≤20*e-11*k by omega) (show 0≤2*p-c by omega)
        have cc := mul_nonneg (show 0≤k by omega) (show 0≤2*c-k+3 by omega)
        have quad := sq_nonneg (20*p-9*k)
        nlinarith only [top,spacing,lp,pr,cc,quad,margin,hk]
      · have near : 14*k≤25*p := by omega
        have pr := mul_nonneg (show 0≤2*e-k+3 by omega) (show 0≤2*p-c by omega)
        have cc := mul_nonneg (show 0≤k by omega) (show 0≤2*c-k+3 by omega)
        have quad : 9*k^2≤25^2*(2*p-k)^2 := by
          nlinarith only [mul_nonneg (show 0≤50*p-28*k by omega) (show 0≤50*p-22*k by omega)]
        have cl : 0≤c := by omega
        nlinarith only [top,spacing,lp,pr,cc,quad,margin,hk,pTop,cl]

#print axioms two_small_contradiction
end Graffiti189LongestPath.SmallShoreNumeric
