import OneExceptionTerminal189
import TwoThirdsDeficitAll189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.OneExceptionTerminal
open private Graffiti189LongestPath.GreedyTerminal.push_end from QuadraticDeficitAll189
open private Graffiti189LongestPath.FanRoutable.path_append_separated from FanLower189
set_option maxHeartbeats 4500000
namespace Graffiti189LongestPath.SmallShoreOre

variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

omit [Fintype V] in
theorem side_ore_paths (R : Finset V) (m : Nat)
    (small : R.card+1≤2*m)
    (floor : ∀ z : ↥(R:Set V),3≤(G.induce (R:Set V)).degree z)
    (pair : ∀ u v : ↥(R:Set V),u≠v →
      m≤(G.induce (R:Set V)).degree u ∨ m≤(G.induce (R:Set V)).degree v) :
    ∀ u∈R,∀ v∈R,u≠v → ∃ q : G.Walk u v,
      q.IsPath ∧ (∀ z∈q.support,z∈R) ∧ q.length+1=R.card := by
  classical
  intro u ur v vr une
  let J := G.induce (R:Set V)
  let a : ↥(R:Set V) := ⟨u,ur⟩
  let b : ↥(R:Set V) := ⟨v,vr⟩
  have ne : a≠b := fun e => une (congrArg Subtype.val e)
  obtain ⟨z,hz⟩ : ∃ z : ↥(R:Set V),∀ v : ↥(R:Set V),v≠z → m≤J.degree v := by
    by_cases bad : ∃ z : ↥(R:Set V),J.degree z<m
    · obtain ⟨z,lz⟩ := bad
      exact ⟨z,fun w wz => (pair w z wz).resolve_right (Nat.not_le_of_lt lz)⟩
    · exact ⟨a,fun w _ => Nat.le_of_not_gt (fun e => bad ⟨w,e⟩)⟩
  have rc : Fintype.card ↥(R:Set V)=R.card := Fintype.card_coe R
  have ore (s t : ↥(R:Set V)) (_ne : s≠t) (sz : s≠z) (tz : t≠z) (_no : ¬J.Adj s t) :
      Fintype.card ↥(R:Set V)+1≤J.degree s+J.degree t := by
    have hs := hz s sz
    have ht := hz t tz
    omega
  obtain ⟨q,hq,all⟩ := terminal_ore_one_exception (G:=J) z (floor z) ore ne
  have full : q.support.toFinset=univ := by
    ext i
    simp [all i]
  have len : q.length+1=R.card := by
    have card := congrArg Finset.card full
    rw [List.toFinset_card_of_nodup hq.support_nodup,length_support,card_univ,rc] at card
    exact card
  let f : J →g G := ⟨Subtype.val,fun e => e⟩
  refine ⟨q.map f,map_isPath_of_injective Subtype.val_injective hq,?_,by simpa only [length_map] using len⟩
  intro w ww
  rw [support_map] at ww
  obtain ⟨z,_,rfl⟩ := List.mem_map.mp ww
  exact z.property

/- Two terminal Ore shores splice into a path spanning both shores and
the universal root, with prescribed endpoints in opposite shores. -/
omit [Fintype V] [DecidableEq V] [DecidableRel G.Adj] in
theorem ore_cross_shore_route (A C E : Finset V)
    (x : V) (xa : x∈A) (xc : x∉C) (xe : x∉E)
    (ca : C⊆A) (ea : E⊆A) (ce : Disjoint C E)
    (root : ∀ z∈A,z≠x → G.Adj x z)
    (cn : 1<C.card) (en : 1<E.card)
    (rC : ∀ u∈C,∀ v∈C,u≠v → ∃ q : G.Walk u v,
      q.IsPath ∧ (∀ z∈q.support,z∈C) ∧ q.length+1=C.card)
    (rE : ∀ u∈E,∀ v∈E,u≠v → ∃ q : G.Walk u v,
      q.IsPath ∧ (∀ z∈q.support,z∈E) ∧ q.length+1=E.card)
    (u : V) (uc : u∈C) (v : V) (ve : v∈E) :
    ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈A) ∧
      C.card+E.card+1=q.length+1 := by
  classical
  obtain ⟨u',ucz,unz⟩ := exists_ne_of_one_lt_card cn u
  obtain ⟨v',vez,vnz⟩ := exists_ne_of_one_lt_card en v
  obtain ⟨l,lp,ls,ll⟩ := rC u uc u' ucz unz.symm
  obtain ⟨r,rp,rs,rl⟩ := rE v ve v' vez vnz.symm
  have uc' := ls _ l.end_mem_support
  have ve' := rs _ r.end_mem_support
  have xu := root u' (ca uc') (fun e => xc (e ▸ uc'))
  have xv := root v' (ea ve') (fun e => xe (e ▸ ve'))
  obtain ⟨l',lp',ll',ls'⟩ := Graffiti189LongestPath.GreedyTerminal.push_end lp xu.symm (fun h => xc (ls _ h))
  obtain ⟨r',rp',rl',rs'⟩ := Graffiti189LongestPath.GreedyTerminal.push_end rp xv.symm (fun h => xe (rs _ h))
  let w := l'.append r'.reverse
  have wp : w.IsPath := Graffiti189LongestPath.FanRoutable.path_append_separated lp' rp'.reverse (by
    intro z zl zr
    have zr' : z∈r'.support := by simpa only [support_reverse,List.mem_reverse] using zr
    rcases (ls' z).mp zl with zx|zl'
    · exact zx
    rcases (rs' z).mp zr' with zx|zr'
    · exact zx
    exact (disjoint_left.mp ce (ls _ zl') (rs _ zr')).elim)
  have ws (z : V) (zt : z∈w.support) : z∈A := by
    rw [show w=l'.append r'.reverse from rfl,support_append,List.mem_append] at zt
    rcases zt with h|h
    · exact ((ls' z).mp h).elim (fun e => e.symm ▸ xa) (fun h => ca (ls _ h))
    have h' : z∈r'.support := by simpa only [support_reverse,List.mem_reverse] using List.mem_of_mem_tail h
    exact ((rs' z).mp h').elim (fun e => e.symm ▸ xa) (fun h => ea (rs _ h))
  refine ⟨w,wp,ws,?_⟩
  simp only [w,length_append,length_reverse]
  omega

#print axioms side_ore_paths
#print axioms ore_cross_shore_route
end Graffiti189LongestPath.SmallShoreOre
