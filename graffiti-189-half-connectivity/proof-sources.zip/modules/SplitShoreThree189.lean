import TwoThirdsDeficitAll189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.ShoreSplit
set_option maxHeartbeats 4500000
namespace Graffiti189LongestPath.SplitShoreThree

variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

omit [Fintype V] [DecidableRel G.Adj] in
def induced_set_delete_iso (E : Finset V) (S : Finset ↥(E:Set V)) :
    G.induce ((E\S.map ⟨Subtype.val,Subtype.val_injective⟩ : Finset V):Set V) ≃g
      (G.induce (E:Set V)).induce ((↑S:Set _)ᶜ) := by
  classical
  let emb : ↥(E:Set V) ↪ V := ⟨Subtype.val,Subtype.val_injective⟩
  let Y := E\S.map emb
  let Z := (↑S:Set ↥(E:Set V))ᶜ
  let forward (v : ↥(Y:Set V)) : Z := by
    have ve := (mem_sdiff.mp v.property).1
    have vo := (mem_sdiff.mp v.property).2
    let w : ↥(E:Set V) := ⟨v,ve⟩
    exact ⟨w,fun ws => vo (mem_map.mpr ⟨w,ws,rfl⟩)⟩
  let inv (v : Z) : ↥(Y:Set V) := by
    refine ⟨v.val.val,mem_sdiff.mpr ⟨v.val.property,?_⟩⟩
    intro h
    obtain ⟨w,ws,e⟩ := mem_map.mp h
    have h : w=v.val := Subtype.val_injective e
    exact v.property (h ▸ ws)
  exact ⟨⟨forward,inv,by intro a; apply Subtype.ext; rfl,
    by intro a; apply Subtype.ext; apply Subtype.ext; rfl⟩,by intro a b; rfl⟩

omit [Fintype V] [DecidableRel G.Adj] in
theorem split_third_shore_after_one_more_deletion (A C E X : Finset V)
    (part : A=C∪E∪X) (ce : Disjoint C E) (cx : Disjoint C X) (ex : Disjoint E X)
    (no : ∀ u∈C,∀ v∈E,¬G.Adj u v) (en : 1<E.card)
    (bad : ¬∀ S : Finset ↥(E:Set V),S.card<2 → ((G.induce (E:Set V)).induce ((↑S:Set _)ᶜ)).Connected) :
    ∃ (D T Y : Finset V), X⊆Y ∧ Y.card≤X.card+1 ∧
      A=C∪D∪T∪Y ∧ D.Nonempty ∧ T.Nonempty ∧
      Disjoint C D ∧ Disjoint C T ∧ Disjoint D T ∧ Disjoint (C∪D∪T) Y ∧
      (∀ u∈C,∀ v∈D,¬G.Adj u v) ∧ (∀ u∈C,∀ v∈T,¬G.Adj u v) ∧
      (∀ u∈D,∀ v∈T,¬G.Adj u v) := by
  classical
  obtain ⟨S,small,fail⟩ : ∃ S : Finset ↥(E:Set V),S.card<2 ∧
      ¬((G.induce (E:Set V)).induce ((↑S:Set _)ᶜ)).Connected := by
    apply Classical.byContradiction
    intro not
    apply bad
    intro T ts
    exact Classical.byContradiction (fun n => not ⟨T,ts,n⟩)
  let emb : ↥(E:Set V) ↪ V := ⟨Subtype.val,Subtype.val_injective⟩
  let Z := S.map emb
  let Y := X∪Z
  have zE : Z⊆E := by
    intro z zz
    obtain ⟨v,_,rfl⟩ := mem_map.mp zz
    exact v.property
  have zs : Z.card≤1 := by
    change (S.map emb).card≤1
    rw [card_map]
    omega
  have yy : Y.card≤X.card+1 := (card_union_le _ _).trans (Nat.add_le_add_left zs _)
  have n : (E\Z).Nonempty := card_pos.mp (by
    have h := card_sdiff_add_card_eq_card zE
    omega)
  have iso := induced_set_delete_iso (G:=G) E S
  have bn : ¬(G.induce ((E\Z : Finset V):Set V)).Connected := fun e => fail (iso.connected_iff.mp e)
  obtain ⟨D,T,se,dt,nt,dd,tt⟩ := partition_of_not_connected (E\Z) n bn
  have all : A=C∪D∪T∪Y := by
    calc
      A=C∪E∪X := part
      _ = C∪((E\Z)∪Z)∪X := by rw [sdiff_union_of_subset zE]
      _ = C∪(D∪T)∪Z∪X := by rw [se]; ac_rfl
      _ = C∪D∪T∪Y := by unfold Y; ac_rfl
  have dE (z : V) (zd : z∈D) : z∈E\Z := se ▸ mem_union.mpr (Or.inl zd)
  have tE (z : V) (zt : z∈T) : z∈E\Z := se ▸ mem_union.mpr (Or.inr zt)
  have cy : Disjoint C Y := disjoint_union_right.mpr ⟨cx,disjoint_left.mpr
    (fun _ zc zz => disjoint_left.mp ce zc (zE zz))⟩
  have dy : Disjoint D Y := disjoint_union_right.mpr ⟨disjoint_left.mpr
    (fun z zd zx => disjoint_left.mp ex (mem_sdiff.mp (dE z zd)).1 zx),
    disjoint_left.mpr (fun z zd zz => (mem_sdiff.mp (dE z zd)).2 zz)⟩
  have ty : Disjoint T Y := disjoint_union_right.mpr ⟨disjoint_left.mpr
    (fun z zt zx => disjoint_left.mp ex (mem_sdiff.mp (tE z zt)).1 zx),
    disjoint_left.mpr (fun z zt zz => (mem_sdiff.mp (tE z zt)).2 zz)⟩
  exact ⟨D,T,Y,subset_union_left,yy,all,dd,tt,
    disjoint_left.mpr (fun z zc zd => disjoint_left.mp ce zc (mem_sdiff.mp (dE z zd)).1),
    disjoint_left.mpr (fun z zc zt => disjoint_left.mp ce zc (mem_sdiff.mp (tE z zt)).1),
    dt,disjoint_union_left.mpr ⟨disjoint_union_left.mpr ⟨cy,dy⟩,ty⟩,
    fun u uc v vd => no u uc v (mem_sdiff.mp (dE v vd)).1,
    fun u uc v vt => no u uc v (mem_sdiff.mp (tE v vt)).1,nt⟩

omit [Fintype V] in
theorem side_degree_loss (A R X : Finset V) (x : V)
    (no : ∀ u∈R,∀ v∈A, v∉R → v∉X → ¬G.Adj u v)
    (u : V) (ur : u∈R) :
    ((A.erase x).filter (G.Adj u)).card≤(R.filter (G.Adj u)).card+(X.erase x).card := by
  classical
  have s : (A.erase x).filter (G.Adj u)⊆(R.filter (G.Adj u))∪(X.erase x) := by
    intro z zz
    obtain ⟨za,adj⟩ := mem_filter.mp zz
    obtain ⟨zn,za⟩ := mem_erase.mp za
    by_cases zr : z∈R
    · exact mem_union.mpr (Or.inl (mem_filter.mpr ⟨zr,adj⟩))
    by_cases zx : z∈X
    · exact mem_union.mpr (Or.inr (mem_erase.mpr ⟨zn,zx⟩))
    exact (no u ur z za zr zx adj).elim
  exact (card_le_card s).trans (card_union_le _ _)

#print axioms split_third_shore_after_one_more_deletion
#print axioms side_degree_loss
end Graffiti189LongestPath.SplitShoreThree
