import FiniteTinySums189
import Mathlib.Tactic.FinCases
import ColoredFan189
import FilterRootHooks189
import GroupedShellMass189
import GeneralCutMisses189
import ThreePortCount189
import NormalizedShellMass189
import ThreeShoreMass189
import ThreeShoreNumeric189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.OneSlack Graffiti189LongestPath.PinRun Graffiti189LongestPath.Rigidity
open Graffiti189LongestPath.MengerRoutable Graffiti189LongestPath.HookRetarget Graffiti189LongestPath.SplitGreedy
open Graffiti189LongestPath.ColoredFan Graffiti189LongestPath.FilterRootHooks
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
open scoped BigOperators
set_option maxHeartbeats 10000000
namespace Graffiti189LongestPath.ThreeNormalized
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem three_split_impossible (hc : G.Connected) (k s m : Nat)
    (kl : 1000000≤k) (su : s≤k) (m2 : 2≤m) (mK : m≤2*k)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
    (gap : (Pins p x).card≤(FirstPins p x).card+1)
    (cap : ∀ v,(DistanceTwo G v).card≤k+s)
    (conn : ∀ D : Finset V,D.card<k → (G.induce ((↑D:Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → k+s≤G.degree u ∨ k+s≤G.degree v)
    (spine : k≤p.support.toFinset.card)
    (M : Fin 3→Finset V) (X W : Finset V)
    (part : OmittedStar p x=(univ.biUnion M)∪X)
    (partition : (univ.biUnion M)∪PinVertices p x∪W=G.neighborFinset x)
    (xx : x∈X) (smallX : X.card≤3) (smallW : W.card≤2)
    (dx : Disjoint (univ.biUnion M) X)
    (dis : Pairwise (fun i j => Disjoint (M i) (M j)))
    (no : ∀ i j,i≠j → ∀ u∈M i,∀ v∈M j,¬G.Adj u v)
    (Hsize : ∀ i,m+1≤(M i).card)
    (L : Finset V) (L1 : L.card≤1)
    (high : ∀ i,∀ u∈M i,u∉L → m-1≤((M i).filter (G.Adj u)).card)
    (low : ∀ i,∀ u∈M i,u∈L → 1≤((M i).filter (G.Adj u)).card)
    (weak : ∀ u∈OmittedStar p x,∀ v∈OmittedStar p x,u≠v →
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈OmittedStar p x) ∧ m+1≤q.length+1)
    (hL : k+(s-(Pins p x).card)≤(OmittedStar p x).card)
    (mL : (OmittedStar p x).card≤2*m+(s-(Pins p x).card)+8)
    (mU : 2*m+(s-(Pins p x).card)≤(OmittedStar p x).card)
    (pins : (Pins p x).card≤s)
    (bk : (External G (OmittedStar p x)).card+(Pins p x).card≤k+s+1)
    (radial : Fintype.card V≤(OmittedStar p x).card+k+2*s+(Shell G x 3).card) :
    False := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let R := univ.biUnion M
  let d := k+s
  let h := A.card
  let pp := (Pins p x).card
  let ell := s-pp
  let H := Shell G x 3
  let C := M 0
  let E := M 1
  let T := M 2
  have re : R=C∪E∪T := by
    ext z
    constructor
    · intro zz
      obtain ⟨i,_,zi⟩ := mem_biUnion.mp zz
      fin_cases i
      · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inl zi)))
      · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inr zi)))
      · exact mem_union.mpr (Or.inr zi)
    · intro zz
      rcases mem_union.mp zz with eq|zt
      · rcases mem_union.mp eq with zc|ze
        · exact mem_biUnion.mpr ⟨0,mem_univ _,zc⟩
        · exact mem_biUnion.mpr ⟨1,mem_univ _,ze⟩
      · exact mem_biUnion.mpr ⟨2,mem_univ _,zt⟩
  have cr (i : Fin 3) : M i⊆R := fun _ zd => mem_biUnion.mpr ⟨i,mem_univ _,zd⟩
  have hcR : R.card=(M 0).card+(M 1).card+(M 2).card := by
    rw [re,card_union_of_disjoint (disjoint_union_left.mpr
      ⟨dis (by decide : (0:Fin 3)≠2),dis (by decide : (1:Fin 3)≠2)⟩),
      card_union_of_disjoint (dis (by decide : (0:Fin 3)≠1))]
  have ha : h=(M 0).card+(M 1).card+(M 2).card+X.card := by
    have q := congrArg Finset.card part
    rw [card_union_of_disjoint dx,hcR] at q
    exact q
  have hU : h≤3*ell+20 := by
    have a := Hsize (0:Fin 3)
    have b := Hsize (1:Fin 3)
    have c := Hsize (2:Fin 3)
    change h≤2*m+ell+8 at mL
    omega
  have hs : h=(M 0).card+(M 1).card+(M 2).card+X.card := ha
  have rs : R⊆A := by
    intro z zr
    change z∈OmittedStar p x
    rw [part]
    exact mem_union.mpr (Or.inl zr)
  have roots : A\X=R := by
    change (OmittedStar p x)\X=R
    rw [part,union_sdiff_right,sdiff_eq_self_of_disjoint dx]
  have xA : x∈A := Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
  have clean (i : Fin 3) : x∉M i := fun zx => disjoint_left.mp dx (cr i zx) xx
  have root (z : V) (za : z∈A) (ne : z≠x) : G.Adj x z :=
    ((Graffiti189LongestPath.Rigidity.mem_omittedStar.mp za).2).resolve_left ne
  have ao (z : V) (za : z∈A) : z∉p.support := (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp za).1
  have closed (u : V) (ua : u∈A) (z : V) (za : z∉A) (ed : G.Adj u z) : z∈B :=
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨za,u,ua,ed⟩
  let label (z : V) : Nat := if z∈C then 0 else if z∈E then 1 else 2
  have lc (z : V) (zc : z∈C) : label z=0 := if_pos zc
  have le (z : V) (ze : z∈E) : label z=1 := by
    have nn : z∉C := fun h => disjoint_left.mp (dis (by decide : (0:Fin 3)≠1)) h ze
    simp [label,nn,ze]
  have lt (z : V) (zt : z∈T) : label z=2 := by
    have cnot : z∉C := fun h => disjoint_left.mp (dis (by decide : (0:Fin 3)≠2)) h zt
    have enot : z∉E := fun h => disjoint_left.mp (dis (by decide : (1:Fin 3)≠2)) h zt
    simp [label,cnot,enot]
  have lcI (i : Fin 3) (z : V) (zi : z∈M i) : label z=i.val := by
    fin_cases i
    · exact lc z zi
    · exact le z zi
    · exact lt z zi
  have crRoute (u : V) (ur : u∈R) (v : V) (vr : v∈R) (ne : label u≠label v) :
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈A) ∧ (m+1)+(m-2)≤q.length+1 := by
    obtain ⟨i,_,ui⟩ := mem_biUnion.mp ur
    obtain ⟨j,_,vj⟩ := mem_biUnion.mp vr
    have ij : i≠j := fun eq => ne ((lcI i u ui).trans ((congrArg Fin.val eq).trans (lcI j v vj).symm))
    exact greedy_cross_shore_route A (M i) (M j) L m L1 m2 x xA (clean i) (clean j)
      ((cr i).trans rs) ((cr j).trans rs) (dis ij) root (high i) (high j) (low i) (low j)
      u ui v vj
  have hLarge : k≤A.card := by change k+ell≤h at hL; omega
  obtain ⟨F⟩ := hooks_of_small_deletion_connectivity A k hp ao hLarge spine conn
  obtain ⟨j,F',jk,kj,regon⟩ := retain_regular_roots A X k F
  have reg (i : Fin j) : F'.root i∈R := roots ▸ regon i
  have ff := colored_flexible_hooked_lower j (m+1) (m-2) (by omega) hp A R ao rs
    (by have q := Hsize (0:Fin 3); have e := card_le_card (cr 0); omega)
    label (fun u ur v vr ne => weak u (rs ur) v (rs vr) ne) crRoute F' reg
  let U := (univ : Finset (Fin j)).filter (fun i =>
    ∃ u∈R,∃ v∈R,G.Adj u (fromFamily F' i).firstPort ∧
      G.Adj v (fromFamily F' i).firstPort ∧ label u≠label v)
  let f := U.card
  change h+j+(j+1)*(m+1)+f*(m-2)≤Fintype.card V at ff
  have fk : f≤k := by
    have q := card_le_card (subset_univ U)
    rw [card_univ,Fintype.card_fin] at q
    exact q.trans jk
  have spacing : m*(k+f)≤H.card+100*k := by
    have j3 : k≤(j+1)+2 := by omega
    have z := Nat.mul_le_mul_right m j3
    have zz := Nat.mul_le_mul_left (j+1) (show m≤m+1 by omega)
    have fm : f*(m-2)+2*f=f*m := by
      have q : f*(m-2)+f*2=f*m := by rw [←Nat.mul_add,show m-2+2=m by omega]
      simpa only [Nat.mul_comm f 2] using q
    have alg : m*(k+f)=k*m+f*m := by ring
    have zex : ((j+1)+2)*m=(j+1)*m+2*m := by ring
    change Fintype.card V≤h+k+2*s+H.card at radial
    omega
  let Q (i : Fin 3) := (B.filter (fun z => ¬∃ u∈M i,G.Adj u z)).card
  have misses := ThreePortCount.two_misses_per_nonflexible_hook j hp A B C E T label
    lc le lt closed ao F'
  dsimp only at misses
  rw [←re] at misses
  change 2*j≤2*f+Q 0+Q 1+Q 2 at misses
  have highSide (i : Fin 3) : ∃ v∈M i,d≤G.degree v := by
    have big := Hsize i
    obtain ⟨u,ui,v,vi,ne⟩ := one_lt_card.mp (show 1<(M i).card from by omega)
    exact (deg u v ne).elim (fun e => ⟨u,ui,e⟩) (fun e => ⟨v,vi,e⟩)
  have missSide (i : Fin 3) : Q i+pp≤(M i).card+X.card := by
    have prt : A=M i∪(R\M i)∪X := by
      rw [union_comm (M i) (R\M i),sdiff_union_of_subset (cr i)]
      exact part
    have outside (u : V) (ui : u∈M i) (v : V) (vs : v∈R\M i) : ¬G.Adj u v := by
      obtain ⟨vr,ni⟩ := mem_sdiff.mp vs
      obtain ⟨j,_,vj⟩ := mem_biUnion.mp vr
      have ne : i≠j := fun e => ni (e.symm ▸ vj)
      exact no i j ne u ui v vj
    obtain ⟨z,zi,zd⟩ := highSide i
    exact GeneralCutMisses.missed_boundary_of_side_with_high_vertex d pp A B (M i) (R\M i) X
      prt (cr i |>.trans rs) outside closed bk z zi zd
  have z0 := missSide (0:Fin 3)
  have z1 := missSide (1:Fin 3)
  have z2 := missSide (2:Fin 3)
  have flexN : 2*k+3*pp≤h+2*f+18 := by omega
  obtain ⟨K,t,kt,dt,mass,_reach⟩ := GroupedShellMass.grouped_shell_mass hc d hp hx gap cap M W X
    part partition dx xx deg dis no bk highSide
  have cov (i : Fin 3) : (R\M i).card+(M i).card+X.card=h := by
    have u := card_sdiff_add_card_eq_card (cr i)
    have v := congrArg Finset.card part
    rw [card_union_of_disjoint dx] at v
    change h=R.card+X.card at v
    omega
  let a₁ := K 0
  let a₂ := K 1
  let a₃ := K 2
  let c₁ := (M 0).card
  let c₂ := (M 1).card
  let c₃ := (M 2).card
  have temp : H.card+a₁*(a₁+(R\M 0).card+pp)+a₂*(a₂+(R\M 1).card+pp)+
      a₃*(a₃+(R\M 2).card+pp)+t*(a₁+a₂+a₃+t)≤
        (d+2)*(a₁+a₂+a₃)+(d+1)*t+3*d := by
    have r : (W.card+1)*d≤3*d := Nat.mul_le_mul_right d (by omega)
    simp only [FiniteTinySums.sum_three] at mass
    have q := mass.trans (Nat.add_le_add_left r _)
    simpa only [a₁,a₂,a₃,add_assoc] using q
  have ov₁ : (((R\M 0).card:Nat):ℤ)=(h:ℤ)-(X.card:ℤ)-(c₁:ℤ) := by
    have q := cov (0:Fin 3)
    dsimp [c₁]
    omega
  have ov₂ : (((R\M 1).card:Nat):ℤ)=(h:ℤ)-(X.card:ℤ)-(c₂:ℤ) := by
    have q := cov (1:Fin 3)
    dsimp [c₂]
    omega
  have ov₃ : (((R\M 2).card:Nat):ℤ)=(h:ℤ)-(X.card:ℤ)-(c₃:ℤ) := by
    have q := cov (2:Fin 3)
    dsimp [c₃]
    omega
  have massI : (H.card:ℤ)+(a₁:ℤ)*((a₁:ℤ)+((R\M 0).card:ℤ)+(pp:ℤ))+
      (a₂:ℤ)*((a₂:ℤ)+((R\M 1).card:ℤ)+(pp:ℤ))+
      (a₃:ℤ)*((a₃:ℤ)+((R\M 2).card:ℤ)+(pp:ℤ))+
      (t:ℤ)*((a₁:ℤ)+(a₂:ℤ)+(a₃:ℤ)+(t:ℤ))≤
      ((d:ℤ)+2)*((a₁:ℤ)+(a₂:ℤ)+(a₃:ℤ))+((d:ℤ)+1)*(t:ℤ)+3*(d:ℤ) := by exact_mod_cast temp
  rw [ov₁,ov₂,ov₃] at massI
  have dI : (d:ℤ)=(k:ℤ)+(s:ℤ) := by exact_mod_cast (show d=k+s from rfl)
  rw [dI] at massI
  have aSum : a₁+a₂+a₃+t≤k+s := by
    simpa only [FiniteTinySums.sum_three,a₁,a₂,a₃,d,add_assoc] using dt
  have ellI : (ell:ℤ)=(s:ℤ)-(pp:ℤ) := by
    have e := Nat.sub_add_cancel pins
    change ell+pp=s at e
    omega
  have raw := NormalizedShellMass.fine_three_shore_shell_mass (k:ℤ) (s:ℤ) (pp:ℤ)
    (t:ℤ) (h:ℤ) (X.card:ℤ) (c₁:ℤ) (c₂:ℤ) (c₃:ℤ)
    (a₁:ℤ) (a₂:ℤ) (a₃:ℤ) (H.card:ℤ) (by omega) (by omega)
    (by omega) (by omega) (by omega) (by omega) (by omega) (by
      simpa only [sub_eq_add_neg,add_assoc] using massI)
  rw [←ellI] at raw
  have csum : c₁+c₂+c₃+X.card=h := ha.symm
  have c1 := Hsize (0:Fin 3)
  have c2 := Hsize (1:Fin 3)
  have c3 := Hsize (2:Fin 3)
  change m+1≤c₁ at c1
  change m+1≤c₂ at c2
  change m+1≤c₃ at c3
  change 2*m+ell≤h at mU
  change k+ell≤h at hL
  have capI := ThreeShoreMass.three_shore_shell_cap (k:ℤ) (ell:ℤ) (pp:ℤ) (t:ℤ)
    (h:ℤ) (m:ℤ) (c₁:ℤ) (c₂:ℤ) (c₃:ℤ) (a₁:ℤ) (a₂:ℤ) (a₃:ℤ) (H.card:ℤ)
    (by omega) (by omega) (by omega) (by omega) (by omega)
    (by exact_mod_cast hL) (by exact_mod_cast hU) (by change h≤2*m+ell+8 at mL; omega)
    (by omega) (by omega) (by omega) (by omega) (by omega) (by omega) (by omega) (by omega) raw
  have spaceI : (m:ℤ)*((k:ℤ)+(f:ℤ))≤(H.card:ℤ)+100*(k:ℤ) := by exact_mod_cast spacing
  exact ThreeShoreNumeric.three_side_contradiction (k:ℤ) (ell:ℤ) (pp:ℤ) (t:ℤ)
    (h:ℤ) (m:ℤ) (f:ℤ) (H.card:ℤ) (by omega) (by omega) (by omega)
    (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
    (by change h≤2*m+ell+8 at mL; omega) (by omega) (by omega) (by omega) capI

#print axioms three_split_impossible
end Graffiti189LongestPath.ThreeNormalized
