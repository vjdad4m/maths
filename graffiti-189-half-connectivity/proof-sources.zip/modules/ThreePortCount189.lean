import HookRetarget189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.HookRetarget Graffiti189LongestPath.FanRoutable Graffiti189LongestPath.Rigidity
set_option maxHeartbeats 5000000
namespace Graffiti189LongestPath.ThreePortCount
variable {V : Type*} [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- Each nonflexible first port misses at least two of three compatible
shore labels. All first ports are distinct in the specified boundary. -/
theorem two_misses_per_nonflexible_hook (k : Nat) {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    (A B C E T : Finset V) (label : V→Nat)
    (c0 : ∀ v∈C,label v=0) (e1 : ∀ v∈E,label v=1) (t2 : ∀ v∈T,label v=2)
    (closed : ∀ u∈A,∀ v∉A,G.Adj u v → v∈B)
    (ao : ∀ z∈A,z∉p.support) (F : HookFamily p A k) :
    let R := C∪E∪T
    let flex := (univ : Finset (Fin k)).filter (fun i =>
      ∃ u∈R,∃ v∈R,G.Adj u (fromFamily F i).firstPort ∧
        G.Adj v (fromFamily F i).firstPort ∧ label u≠label v)
    2*k≤2*flex.card+(B.filter (fun z => ¬∃ u∈C,G.Adj u z)).card+
      (B.filter (fun z => ¬∃ u∈E,G.Adj u z)).card+(B.filter (fun z => ¬∃ u∈T,G.Adj u z)).card := by
  classical
  let R := C∪E∪T
  let g (i : Fin k) := (fromFamily F i).firstPort
  let good (i : Fin k) := ∃ u∈R,∃ v∈R,G.Adj u (g i) ∧
    G.Adj v (g i) ∧ label u≠label v
  let U := (univ : Finset (Fin k)).filter good
  let Bad := (univ : Finset (Fin k))\U
  let L := Bad.image g
  let reaches (D : Finset V) := L.filter (fun z => ∃ u∈D,G.Adj u z)
  have lb : L⊆B := by
    intro z zz
    obtain ⟨i,_,rfl⟩ := mem_image.mp zz
    exact first_port_mem_boundary (fromFamily F i) ao closed
  have gInj : Function.Injective g := family_first_ports_injective hp F
  have ld : L.card=Bad.card := card_image_of_injective _ gInj
  have exactK := card_sdiff_add_card_eq_card (subset_univ U)
  rw [card_univ,Fintype.card_fin] at exactK
  change Bad.card+U.card=k at exactK
  have forbid (D E : Finset V) (ds : D⊆R) (es : E⊆R)
      (different : ∀ u∈D,∀ v∈E,label u≠label v) :
      Disjoint (reaches D) (reaches E) := by
    apply disjoint_left.mpr
    intro z zd ze
    obtain ⟨zl,u,ud,uz⟩ := mem_filter.mp zd
    obtain ⟨_,v,ve,vz⟩ := mem_filter.mp ze
    obtain ⟨i,ii,rfl⟩ := mem_image.mp zl
    exact (mem_sdiff.mp ii).2 (mem_filter.mpr
      ⟨mem_univ _,u,ds ud,v,es ve,uz,vz,different u ud v ve⟩)
  have cR : C⊆R := fun _ z => mem_union.mpr (Or.inl (mem_union.mpr (Or.inl z)))
  have eR : E⊆R := fun _ z => mem_union.mpr (Or.inl (mem_union.mpr (Or.inr z)))
  have tR : T⊆R := fun _ z => mem_union.mpr (Or.inr z)
  have ce := forbid C E cR eR (fun u uu v vv => by simpa only [c0 u uu,e1 v vv] using (by decide : (0:Nat)≠1))
  have ct := forbid C T cR tR (fun u uu v vv => by simpa only [c0 u uu,t2 v vv] using (by decide : (0:Nat)≠2))
  have et := forbid E T eR tR (fun u uu v vv => by simpa only [e1 u uu,t2 v vv] using (by decide : (1:Nat)≠2))
  have overlap : Disjoint (reaches C∪reaches E) (reaches T) := disjoint_union_left.mpr ⟨ct,et⟩
  have subAll : reaches C∪reaches E∪reaches T⊆L :=
    union_subset (union_subset (filter_subset _ _) (filter_subset _ _)) (filter_subset _ _)
  have upper := card_le_card subAll
  rw [card_union_of_disjoint overlap,card_union_of_disjoint ce] at upper
  have lower (D : Finset V) :
      L.card≤(B.filter (fun z => ¬∃ u∈D,G.Adj u z)).card+(reaches D).card := by
    have q : L\reaches D⊆B.filter (fun z => ¬∃ u∈D,G.Adj u z) := by
      intro z zz
      obtain ⟨zl,nd⟩ := mem_sdiff.mp zz
      exact mem_filter.mpr ⟨lb zl,fun ed => nd (mem_filter.mpr ⟨zl,ed⟩)⟩
    have er := card_sdiff_add_card_eq_card (filter_subset (fun z => ∃ u∈D,G.Adj u z) L)
    change (L\reaches D).card+(reaches D).card=L.card at er
    have p := card_le_card q
    omega
  have loC := lower C
  have loE := lower E
  have loT := lower T
  change 2*k≤2*U.card+(B.filter (fun z => ¬∃ u∈C,G.Adj u z)).card+
      (B.filter (fun z => ¬∃ u∈E,G.Adj u z)).card+(B.filter (fun z => ¬∃ u∈T,G.Adj u z)).card
  omega

#print axioms two_misses_per_nonflexible_hook
end Graffiti189LongestPath.ThreePortCount
