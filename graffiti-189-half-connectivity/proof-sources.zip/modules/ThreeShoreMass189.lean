import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

namespace Graffiti189LongestPath.ThreeShoreMass

/-- For three disjoint donor sides, the worst size distribution at
fixed total and common size floor has all excess in one side. -/
theorem three_shore_shell_cap
    (k ell p t h m c₁ c₂ c₃ a₁ a₂ a₃ H : ℤ)
    (hk : 1000000≤k) (p0 : 0≤p) (tk : 0≤t) (tp : t≤p) (el : ell+p≤k)
    (hL : k+ell≤h) (hU : h≤3*ell+20)
    (mL : h-ell-8≤2*m) (mU : 2*m≤h-ell)
    (c : c₁+c₂+c₃≤h) (c₁m : m≤c₁) (c₂m : m≤c₂) (c₃m : m≤c₃)
    (a₁n : 0≤a₁) (a₂n : 0≤a₂) (a₃n : 0≤a₃)
    (raw : H≤t*(2*k-t)+
      a₁*(k+ell-h+c₁-t-a₁)+a₂*(k+ell-h+c₂-t-a₂)+
      a₃*(k+ell-h+c₃-t-a₃)+16*k) :
    8*H≤2*(k-p-t)^2+(k-2*t)^2+8*t*(2*k-t)+500*k := by
  let x := k+ell-h-t+m+14
  let y₁ := c₁-m
  let y₂ := c₂-m
  let y₃ := c₃-m
  let Y := h-3*m
  have x0 : 0≤x := by dsimp [x]; omega
  have y₁0 : 0≤y₁ := by dsimp [y₁]; omega
  have y₂0 : 0≤y₂ := by dsimp [y₂]; omega
  have y₃0 : 0≤y₃ := by dsimp [y₃]; omega
  have y : y₁+y₂+y₃≤Y := by dsimp [y₁,y₂,y₃,Y]; omega
  have Y0 : 0≤Y := by omega
  have mass : 4*H≤4*t*(2*k-t)+(x+y₁)^2+(x+y₂)^2+(x+y₃)^2+64*k := by
    have s₁ := sq_nonneg (2*a₁-x-y₁)
    have s₂ := sq_nonneg (2*a₂-x-y₂)
    have s₃ := sq_nonneg (2*a₃-x-y₃)
    dsimp [x,y₁,y₂,y₃] at s₁ s₂ s₃ ⊢
    nlinarith only [raw,s₁,s₂,s₃,a₁n,a₂n,a₃n]
  have moment : (x+y₁)^2+(x+y₂)^2+(x+y₃)^2≤(x+Y)^2+2*x^2 := by
    nlinarith only [mul_nonneg (show 0≤Y-y₁-y₂-y₃ by omega)
      (show 0≤2*x+Y+y₁+y₂+y₃ by omega),
      mul_nonneg y₁0 y₂0,mul_nonneg y₁0 y₃0,mul_nonneg y₂0 y₃0]
  have big : x+Y≤k-p-t+22 := by dsimp [x,Y]; omega
  have small : 2*x≤k-2*t+28 := by dsimp [x]; omega
  have q1 : (x+Y)^2≤(k-p-t+22)^2 := by
    nlinarith only [mul_nonneg (show 0≤k-p-t+22-(x+Y) by omega)
      (show 0≤k-p-t+22+(x+Y) by omega)]
  have q2 : 4*x^2≤(k-2*t+28)^2 := by
    nlinarith only [mul_nonneg (show 0≤k-2*t+28-2*x by omega)
      (show 0≤k-2*t+28+2*x by omega)]
  nlinarith only [mass,moment,q1,q2,p0,tk,hk]

#print axioms three_shore_shell_cap
end Graffiti189LongestPath.ThreeShoreMass
