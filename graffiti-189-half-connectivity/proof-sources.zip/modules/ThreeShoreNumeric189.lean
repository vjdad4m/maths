import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

namespace Graffiti189LongestPath.ThreeShoreNumeric

/-- Three mutually nonadjacent split shores cannot attain the shell
mass demanded by their two-color-compatible hooks. The graph-side
estimates have already absorbed bounded additive normalization losses. -/
theorem three_side_contradiction (k ell p t h m f H : ℤ)
    (hk : 1000000≤k) (p0 : 0≤p) (pK : p≤k) (_t0 : 0≤t) (tp : t≤p)
    (el : ell+p≤k) (hL : k+ell≤h) (hU : h≤3*ell+20) (h0 : 0≤h)
    (mL : h-ell-8≤2*m) (f0 : 0≤f) (fL : 2*k-h+3*p-18≤2*f)
    (space : m*(k+f)-100*k≤H)
    (shell : 8*H≤2*(k-p-t)^2+(k-2*t)^2+8*t*(2*k-t)+500*k) : False := by
  have rise := mul_nonneg (show 0≤p-t by omega) (show 0≤8*k+2*p-2*t by omega)
  have upper : 8*H≤3*k^2+4*k*p+4*p^2+500*k := by
    nlinarith only [shell,rise]
  have margin := mul_nonneg (show 0≤k by omega) (show 0≤k-1000000 by omega)
  by_cases small : 6*p≤k
  · have kp := mul_nonneg (show 0≤k by omega) (show 0≤k-6*p by omega)
    have pp : 36*p^2≤k^2 := by
      nlinarith only [mul_nonneg (show 0≤k-6*p by omega) (show 0≤k+6*p by omega)]
    have m0 : 0≤m := by omega
    have a := mul_nonneg m0 f0
    have b := mul_nonneg (show 0≤k by omega) (show 0≤2*m-k+8 by omega)
    nlinarith only [upper,space,kp,pp,a,b,margin,hk]
  · have z0 : 0≤h-ell-8 := by omega
    have n := mul_nonneg z0 (show 0≤2*f+2*k-(4*k-h+3*p-18) by omega)
    have u := mul_nonneg (show 0≤2*m-(h-ell-8) by omega) (show 0≤2*f+2*k by omega)
    have prod : (h-ell-8)*(4*k-h+3*p-18)≤4*m*(k+f) := by
      nlinarith only [n,u]
    have diff := mul_nonneg (show 0≤h-k-ell by omega) (show 0≤3*k+3*p-h by omega)
    have ed := mul_nonneg (show 0≤k by omega) (show 0≤k-ell-p by omega)
    have pq := mul_nonneg p0 (show 0≤k-p by omega)
    nlinarith only [upper,space,prod,diff,ed,pq,margin,hk,hU,el,h0,pK,p0]

#print axioms three_side_contradiction
end Graffiti189LongestPath.ThreeShoreNumeric
