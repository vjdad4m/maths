import FiniteTinySums189
import Mathlib.Tactic.FinCases
import SmallShoreOre189
import ColoredFan189
import FilterRootHooks189
import GroupedShellMass189
import SmallShoreNumeric189
import NormalizedShellMass189
import FourSeventhsCombined189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.OneSlack Graffiti189LongestPath.PinRun Graffiti189LongestPath.Rigidity
open Graffiti189LongestPath.MengerRoutable Graffiti189LongestPath.HookRetarget
open Graffiti189LongestPath.SmallShoreOre Graffiti189LongestPath.ColoredFan Graffiti189LongestPath.FilterRootHooks
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
open scoped BigOperators
set_option maxHeartbeats 10000000
namespace Graffiti189LongestPath.TwoSmallNormalized
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem small_split_impossible (hc : G.Connected) (k s : Nat)
    (kl : 1000000≤k) (sl : 2*k≤3*s) (su : s≤k)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
    (gap : (Pins p x).card≤(FirstPins p x).card+1)
    (cap : ∀ v,(DistanceTwo G v).card≤k+s)
    (conn : ∀ D : Finset V,D.card<k → (G.induce ((↑D:Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → k+s≤G.degree u ∨ k+s≤G.degree v)
    (spine : k≤p.support.toFinset.card)
    (C E X W : Finset V)
    (part : OmittedStar p x=C∪E∪X)
    (partition : C∪E∪PinVertices p x∪W=G.neighborFinset x)
    (xx : x∈X) (smallX : X.card≤2) (smallW : W.card≤1)
    (ce : Disjoint C E) (cx : Disjoint C X) (ex : Disjoint E X)
    (no : ∀ u∈C,∀ v∈E,¬G.Adj u v)
    (largeC : k-3≤2*C.card) (smaller : C.card≤E.card) (smallE : E.card≤k-6)
    (floC : ∀ u : ↥(C:Set V),3≤(G.induce (C:Set V)).degree u)
    (floE : ∀ u : ↥(E:Set V),3≤(G.induce (E:Set V)).degree u)
    (hiC : ∀ u : ↥(C:Set V), k+s≤G.degree u.val → k-5≤2*(G.induce (C:Set V)).degree u)
    (hiE : ∀ u : ↥(E:Set V), k+s≤G.degree u.val → k-5≤2*(G.induce (E:Set V)).degree u)
    (hK : k≤(OmittedStar p x).card)
    (hh : k+s≤(OmittedStar p x).card+(Pins p x).card)
    (pins : (Pins p x).card≤k)
    (bk : (External G (OmittedStar p x)).card+(Pins p x).card≤k+s+1)
    (radial : Fintype.card V≤(OmittedStar p x).card+k+2*s+(Shell G x 3).card) :
    False := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let R := C∪E
  let H := Shell G x 3
  let d := k+s
  let pp := (Pins p x).card
  let m := (k-4)/2
  let L (v : V) : Nat := if v∈C then 0 else 1
  have dr : Disjoint R X := disjoint_union_left.mpr ⟨cx,ex⟩
  have rc : R.card=C.card+E.card := card_union_of_disjoint ce
  have hcard : A.card=C.card+E.card+X.card := by
    have q := congrArg Finset.card part
    rw [card_union_of_disjoint dr,rc] at q
    exact q
  have roots : A\X=R := by
    change (OmittedStar p x)\X=R
    rw [part,union_sdiff_right,sdiff_eq_self_of_disjoint dr]
  have rs : R⊆A := by
    intro z zz
    change z∈OmittedStar p x
    rw [part]
    exact mem_union.mpr (Or.inl zz)
  have cA : C⊆A := fun _ z => rs (mem_union.mpr (Or.inl z))
  have eA : E⊆A := fun _ z => rs (mem_union.mpr (Or.inr z))
  have xA : x∈A := Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
  have root (z : V) (za : z∈A) (ne : z≠x) : G.Adj x z :=
    ((Graffiti189LongestPath.Rigidity.mem_omittedStar.mp za).2).resolve_left ne
  have ao (z : V) (za : z∈A) : z∉p.support := (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp za).1
  have closed (u : V) (ua : u∈A) (z : V) (za : z∉A) (ed : G.Adj u z) : z∈B :=
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨za,u,ua,ed⟩
  have lc (z : V) (zc : z∈C) : L z=0 := if_pos zc
  have le (z : V) (ze : z∈E) : L z=1 := if_neg (fun zc => disjoint_left.mp ce zc ze)
  have pc (u v : ↥(C:Set V)) (ne : u≠v) :
      m≤(G.induce (C:Set V)).degree u ∨ m≤(G.induce (C:Set V)).degree v :=
    (deg u.val v.val (fun e => ne (Subtype.ext e))).imp
      (fun e => by have q := hiC u e; dsimp [m]; omega)
      (fun e => by have q := hiC v e; dsimp [m]; omega)
  have pe (u v : ↥(E:Set V)) (ne : u≠v) :
      m≤(G.induce (E:Set V)).degree u ∨ m≤(G.induce (E:Set V)).degree v :=
    (deg u.val v.val (fun e => ne (Subtype.ext e))).imp
      (fun e => by have q := hiE u e; dsimp [m]; omega)
      (fun e => by have q := hiE v e; dsimp [m]; omega)
  have routeC := side_ore_paths C m (by dsimp [m]; omega) floC pc
  have routeE := side_ore_paths E m (by dsimp [m]; omega) floE pe
  have across := ore_cross_shore_route A C E x xA
    (fun e => disjoint_left.mp cx e xx) (fun e => disjoint_left.mp ex e xx) cA eA ce root
    (by omega) (by omega) routeC routeE
  have acrossRev (u : V) (ue : u∈E) (v : V) (vc : v∈C) :
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈A) ∧ C.card+E.card+1=q.length+1 := by
    obtain ⟨q,qp,qs,ql⟩ := across v vc u ue
    exact ⟨q.reverse,qp.reverse,fun z zz => qs z (by
      simpa only [support_reverse,List.mem_reverse] using zz),by simpa using ql⟩
  have weak (u : V) (ur : u∈R) (v : V) (vr : v∈R) (ne : u≠v) :
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈A) ∧ C.card≤q.length+1 := by
    rcases mem_union.mp ur with uc|ue <;> rcases mem_union.mp vr with vc|ve
    · obtain ⟨q,qp,qs,ql⟩ := routeC u uc v vc ne
      exact ⟨q,qp,fun _ h => cA (qs _ h),by omega⟩
    · obtain ⟨q,qp,qs,ql⟩ := across u uc v ve
      exact ⟨q,qp,qs,by omega⟩
    · obtain ⟨q,qp,qs,ql⟩ := acrossRev u ue v vc
      exact ⟨q,qp,qs,by omega⟩
    · obtain ⟨q,qp,qs,ql⟩ := routeE u ue v ve ne
      exact ⟨q,qp,fun _ h => eA (qs _ h),by omega⟩
  have cross (u : V) (ur : u∈R) (v : V) (vr : v∈R) (ne : L u≠L v) :
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈A) ∧ C.card+E.card≤q.length+1 := by
    rcases mem_union.mp ur with uc|ue <;> rcases mem_union.mp vr with vc|ve
    · exact (ne ((lc u uc).trans (lc v vc).symm)).elim
    · obtain ⟨q,qp,qs,ql⟩ := across u uc v ve
      exact ⟨q,qp,qs,by omega⟩
    · obtain ⟨q,qp,qs,ql⟩ := acrossRev u ue v vc
      exact ⟨q,qp,qs,by omega⟩
    · exact (ne ((le u ue).trans (le v ve).symm)).elim
  obtain ⟨F⟩ := hooks_of_small_deletion_connectivity A k hp ao hK spine conn
  obtain ⟨j,F',jk,kj,good⟩ := retain_regular_roots A X k F
  have regular (i : Fin j) : F'.root i∈R := roots ▸ good i
  have fan := colored_flexible_hooked_lower j C.card E.card (by omega) hp A R ao rs
    (by omega) L weak cross F' regular
  let goodC := (univ : Finset (Fin j)).filter (fun i =>
    (∃ u∈C,G.Adj u (fromFamily F' i).firstPort) ∧ ∃ v∈E,G.Adj v (fromFamily F' i).firstPort)
  have eq (i : Fin j) :
      (∃ u∈R,∃ v∈R,G.Adj u (fromFamily F' i).firstPort ∧
        G.Adj v (fromFamily F' i).firstPort ∧ L u≠L v) ↔
      ((∃ u∈C,G.Adj u (fromFamily F' i).firstPort) ∧ ∃ v∈E,G.Adj v (fromFamily F' i).firstPort) := by
    constructor
    · rintro ⟨u,ur,v,vr,hu,hv,neq⟩
      rcases mem_union.mp ur with uc|ue <;> rcases mem_union.mp vr with vc|ve
      · exact (neq ((lc u uc).trans (lc v vc).symm)).elim
      · exact ⟨⟨u,uc,hu⟩,⟨v,ve,hv⟩⟩
      · exact ⟨⟨v,vc,hv⟩,⟨u,ue,hu⟩⟩
      · exact (neq ((le u ue).trans (le v ve).symm)).elim
    · rintro ⟨⟨u,uc,hu⟩,⟨v,ve,hv⟩⟩
      exact ⟨u,mem_union.mpr (Or.inl uc),v,mem_union.mpr (Or.inr ve),hu,hv,
        by simpa only [lc u uc,le v ve] using (by decide : (0:Nat)≠1)⟩
  have fq : (univ : Finset (Fin j)).filter (fun i =>
      ∃ u∈R,∃ v∈R,G.Adj u (fromFamily F' i).firstPort ∧
        G.Adj v (fromFamily F' i).firstPort ∧ L u≠L v)=goodC := by
    ext i
    exact ⟨fun h => mem_filter.mpr ⟨mem_univ _,(eq i).mp (mem_filter.mp h).2⟩,
      fun h => mem_filter.mpr ⟨mem_univ _,(eq i).mpr (mem_filter.mp h).2⟩⟩
  dsimp only at fan
  rw [fq] at fan
  let f := goodC.card
  change A.card+j+(j+1)*C.card+f*E.card≤Fintype.card V at fan
  have fk : f≤k := (by
    have fr := card_le_card (subset_univ goodC)
    rw [card_univ,Fintype.card_fin] at fr
    exact fr.trans jk)
  have spac : k*C.card+E.card*f≤H.card+100*k := by
    have mono := Nat.mul_le_mul_right C.card kj
    have xs : (j+X.card)*C.card=(j+1)*C.card+(X.card-1)*C.card := by
      have Xpos : 0<X.card := card_pos.mpr ⟨x,xx⟩
      rw [←Nat.add_mul]
      congr 1
      omega
    rw [xs] at mono
    have xterm := Nat.mul_le_mul (show X.card-1≤1 by omega) (show C.card≤k by omega)
    have comm : f*E.card=E.card*f := Nat.mul_comm _ _
    change Fintype.card V≤A.card+k+2*s+H.card at radial
    omega
  have miss := FlexMissTwice.ports_missing_or_flexible j hp A B C E closed ao F'
  let qC := (B.filter (fun z => ¬∃ u∈C,G.Adj u z)).card
  let qE := (B.filter (fun z => ¬∃ u∈E,G.Adj u z)).card
  change j≤f+qC+qE at miss
  let M (i : Fin 2) := if i=0 then C else E
  have mz : M 0=C := by simp [M]
  have mo : M 1=E := by simp [M]
  have ri : univ.biUnion M=R := by
    ext z
    constructor
    · intro zz
      obtain ⟨i,_,zi⟩ := mem_biUnion.mp zz
      fin_cases i
      · exact mem_union.mpr (Or.inl (by simpa [M] using zi))
      · exact mem_union.mpr (Or.inr (by simpa [M] using zi))
    · intro zz
      rcases mem_union.mp zz with zc|ze
      · exact mem_biUnion.mpr ⟨0,mem_univ _,by simpa [mz] using zc⟩
      · exact mem_biUnion.mpr ⟨1,mem_univ _,by simpa [mo] using ze⟩
  have dis : Pairwise (fun i j => Disjoint (M i) (M j)) := by
    intro i j ne
    fin_cases i <;> fin_cases j
    · exact (ne rfl).elim
    · simpa [M] using ce
    · simpa [M] using ce.symm
    · exact (ne rfl).elim
  have non (i j : Fin 2) (neq : i≠j) (u : V) (ui : u∈M i) (v : V) (vj : v∈M j) :
      ¬G.Adj u v := by
    fin_cases i <;> fin_cases j
    · exact (neq rfl).elim
    · exact no u (by simpa [M] using ui) v (by simpa [M] using vj)
    · exact fun ed => no v (by simpa [M] using vj) u (by simpa [M] using ui) ed.symm
    · exact (neq rfl).elim
  have hSide (i : Fin 2) : ∃ v∈M i,d≤G.degree v := by
    have big : 1<(M i).card := by
      fin_cases i <;> simp [M] <;> omega
    obtain ⟨u,ui,v,vi,ne⟩ := one_lt_card.mp big
    exact (deg u v ne).elim (fun e => ⟨u,ui,e⟩) (fun e => ⟨v,vi,e⟩)
  obtain ⟨K,t,kt,dt,mass,reach⟩ := GroupedShellMass.grouped_shell_mass hc d hp hx gap cap M W X
    (by rw [ri]; exact part) (by rw [ri]; exact partition) (by rw [ri]; exact dr)
    xx deg dis non bk hSide
  have cS : R\M 0=E := by rw [mz,union_sdiff_left,sdiff_eq_self_of_disjoint ce.symm]
  have eS : R\M 1=C := by rw [mo,union_sdiff_right,sdiff_eq_self_of_disjoint ce]
  have mBound : H.card+K 0*(K 0+E.card+pp)+K 1*(K 1+C.card+pp)+
      t*(K 0+K 1+t)≤(d+2)*(K 0+K 1)+(d+1)*t+2*d := by
    have h : (W.card+1)*d≤2*d := Nat.mul_le_mul_right d (by omega)
    simpa only [ri,FiniteTinySums.sum_two,cS,eS,add_assoc] using
      mass.trans (Nat.add_le_add_left h _)
  have tdon : K 0+K 1+t≤d := by simpa only [FiniteTinySums.sum_two] using dt
  have r0 := reach smallX (0:Fin 2)
  have r1 := reach smallX (1:Fin 2)
  rw [mz] at r0
  rw [mo] at r1
  change K 0+pp+qC≤C.card+3 at r0
  change K 1+pp+qE≤E.card+3 at r1
  have uf : K 0+K 1+2*pp≤C.card+f+10 := by omega
  have tpn : t≤pp := kt
  have rootBound : d≤C.card+E.card+pp+2 := by
    change d≤A.card+pp at hh
    omega
  have massI : (H.card:ℤ)+(K 0:ℤ)*((K 0:ℤ)+(E.card:ℤ)+(pp:ℤ))+
      (K 1:ℤ)*((K 1:ℤ)+(C.card:ℤ)+(pp:ℤ))+(t:ℤ)*((K 0:ℤ)+(K 1:ℤ)+(t:ℤ))≤
        ((d:ℤ)+2)*((K 0:ℤ)+(K 1:ℤ))+((d:ℤ)+1)*(t:ℤ)+2*(d:ℤ) := by exact_mod_cast mBound
  have upper := NormalizedShellMass.fine_two_shore_shell_cap (k:ℤ) (d:ℤ)
    (C.card:ℤ) (E.card:ℤ) (K 0:ℤ) (K 1:ℤ) (t:ℤ) (pp:ℤ) (f:ℤ) (H.card:ℤ)
    (by dsimp [d]; omega) (by omega) (by omega) (by omega) (by omega)
    (by omega) (by omega) (by omega) (by omega) (by omega) (by omega) (by omega) massI
  have spacI : (k:ℤ)*(C.card:ℤ)+(E.card:ℤ)*(f:ℤ)≤(H.card:ℤ)+100*(k:ℤ) := by exact_mod_cast spac
  exact SmallShoreNumeric.two_small_contradiction (k:ℤ) (d:ℤ) (C.card:ℤ) (E.card:ℤ)
    ((K 0:ℤ)+(K 1:ℤ)) (f:ℤ) (pp:ℤ) (H.card:ℤ) (by omega) (by dsimp [d]; omega)
    (by omega) (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
    (by omega) (by omega) upper (by omega)

#print axioms small_split_impossible
end Graffiti189LongestPath.TwoSmallNormalized
