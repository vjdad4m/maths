import TwoThirdsDeficitAll189
import Mathlib.Data.Fintype.EquivFin
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.FanRoutable Graffiti189LongestPath.CycleHallSplice Graffiti189LongestPath.StarCycleClosure
set_option maxHeartbeats 4000000
namespace Graffiti189LongestPath.UniversalExtension

variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/- Adding one off-spine vertex to the shore invalidates at most one
hook, because all initial hook paths are disjoint. -/
omit [Fintype V] [DecidableRel G.Adj] in
theorem enlarge_hook_shore (R : Finset V) (x : V) (k : Nat)
    {a b : V} {p : G.Walk a b} (F : HookFamily p R k) :
    ∃ j : Nat,k≤j+1 ∧ Nonempty (HookFamily p (insert x R) j) := by
  classical
  let good := (univ : Finset (Fin k)).filter (fun i => x∉(F.path i).support)
  let bad := (univ : Finset (Fin k))\good
  have bad1 : bad.card≤1 := by
    apply Nat.le_of_not_gt
    intro e
    obtain ⟨i,ii,j,jj,ne⟩ := one_lt_card.mp e
    have ip : x∈(F.path i).support := Classical.byContradiction (fun no =>
      (mem_sdiff.mp ii).2 (mem_filter.mpr ⟨mem_univ _,no⟩))
    have jp : x∈(F.path j).support := Classical.byContradiction (fun no =>
      (mem_sdiff.mp jj).2 (mem_filter.mpr ⟨mem_univ _,no⟩))
    exact F.disj ne ip jp
  have add := card_sdiff_add_card_eq_card (subset_univ good)
  rw [card_univ,Fintype.card_fin] at add
  change bad.card+good.card=k at add
  have ec : Fintype.card (Fin good.card)=Fintype.card ↥good := by
    rw [Fintype.card_fin,Fintype.card_coe]
  let e₀ : Fin good.card ≃ ↥good := Fintype.equivOfCardEq ec
  let e : Fin good.card ↪ Fin k := e₀.toEmbedding.trans ⟨Subtype.val,Subtype.val_injective⟩
  have eg (i : Fin good.card) : e i∈good := (e₀ i).property
  refine ⟨good.card,by omega,⟨?_⟩⟩
  exact {
    idx := e.trans F.idx
    root := fun i => F.root (e i)
    last := fun i => F.last (e i)
    path := fun i => F.path (e i)
    simple := fun i => F.simple (e i)
    idxLt := fun i => F.idxLt (e i)
    adjLast := fun i => F.adjLast (e i)
    firstIn := fun i => mem_insert_of_mem (F.firstIn (e i))
    single := fun i z zs za => (mem_insert.mp za).elim
      (fun h => ((mem_filter.mp (eg i)).2 (h ▸ zs)).elim)
      (F.single (e i) z zs)
    off := fun i => F.off (e i)
    disj := by intro i j ne; exact F.disj (fun w => ne (e.injective w)) }

omit [Fintype V] [DecidableRel G.Adj] in
theorem routes_of_cycle_in_universal_extension (R : Finset V) (x : V) (xr : x∉R)
    (adj : ∀ v∈R,G.Adj x v)
    (robust : ∀ S : Finset ↥(R:Set V),S.card<2 →
      ((G.induce (R:Set V)).induce ((↑S:Set _)ᶜ)).Connected)
    (len : Nat)
    (cyc : ∃ z,∃ c : (G.induce (R:Set V)).Walk z z,c.IsCycle ∧ max 2 len≤c.length) :
    ∀ u∈insert x R,∀ v∈insert x R,u≠v →
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈insert x R) ∧ len+1≤q.length+1 := by
  classical
  let Z := (R:Set V)
  let J := G.induce Z
  let f : J →g G := ⟨Subtype.val,fun e => e⟩
  have fi : Function.Injective f := Subtype.val_injective
  have off (z : Z) : x≠f z := fun e => xr (e.symm ▸ z.property)
  have edge (z : Z) : G.Adj x (f z) := adj z z.property
  obtain ⟨a,c,hc,cl⟩ := cyc
  have big : 2≤c.support.toFinset.card := by
    rw [cycle_card_support c hc]
    exact (le_max_left _ _).trans cl
  have L : len≤c.length := (le_max_right _ _).trans cl
  intro u uu v vv ne
  have into (z : V) (e : z=x∨∃ w : Z,f w=z) : z∈insert x R := by
    rcases e with rfl|⟨w,rfl⟩
    · exact mem_insert_self _ _
    · exact mem_insert_of_mem w.property
  by_cases hu : u=x
  · subst u
    have vR := (mem_insert.mp vv).resolve_left ne.symm
    let t : Z := ⟨v,vR⟩
    obtain ⟨q,qp,ql,qs⟩ := cycle_to_prescribed_root_route f fi off edge c hc
      (t:=t) (fun s h => robust s (by omega))
    exact ⟨q,qp,fun z hz => into z (qs z hz),by omega⟩
  have uR := (mem_insert.mp uu).resolve_left hu
  by_cases hv : v=x
  · subst v
    let t : Z := ⟨u,uR⟩
    obtain ⟨q,qp,ql,qs⟩ := cycle_to_prescribed_root_route f fi off edge c hc
      (t:=t) (fun s h => robust s (by omega))
    exact ⟨q.reverse,qp.reverse,fun z hz => into z (qs z (by
      simpa only [support_reverse,List.mem_reverse] using hz)),by simpa using (by omega : len+1≤q.length+1)⟩
  let s : Z := ⟨u,uR⟩
  let t : Z := ⟨v,(mem_insert.mp vv).resolve_left hv⟩
  have uv : s≠t := fun e => ne (congrArg Subtype.val e)
  obtain ⟨q,qp,ql,qs⟩ := cycle_to_prescribed_route f fi uv off edge c hc big robust
  exact ⟨q,qp,fun z hz => into z (qs z hz),by omega⟩

#print axioms enlarge_hook_shore
#print axioms routes_of_cycle_in_universal_extension
end Graffiti189LongestPath.UniversalExtension
