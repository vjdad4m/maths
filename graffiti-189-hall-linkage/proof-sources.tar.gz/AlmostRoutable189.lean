import FanPorts189
import DoubleThirdBudget189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.ActiveStarHeight Graffiti189LongestPath.OneSlack
open Graffiti189LongestPath.FanRoutable Graffiti189LongestPath.FanWeighted Graffiti189LongestPath.FanPorts
open Graffiti189LongestPath.DoubleThirdBudget
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
open scoped BigOperators
set_option warningAsError true
namespace Graffiti189LongestPath.AlmostRoutable
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- Terminal paths need not span the star. Their common guaranteed order H
and the count of off-path ports jointly rule out the separated double. -/
theorem almost_routable_double_no_fan (hc : G.Connected) (k : Nat) (hk : 6≤k)
    (cap : ∀ v, (EvenFrom G v).card≤k+3)
    (conn : ∀ S : Finset V, S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    {a b x y : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
    (hy : y∉p.support) (xy : G.Adj x y) (high : k+2≤G.degree x)
    (double : (Pins p x).card=2) (sep : PairedPins p x=∅)
    (H : Nat)
    (routes : ∀ u∈OmittedStar p x,∀ v∈OmittedStar p x,u≠v →
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ w∈q.support,w∈OmittedStar p x) ∧ H≤q.length+1)
    (sat : (External G (OmittedStar p x)).card=k)
    (extra : k*(k+2)<(k+1)*H+2*(External G (OmittedStar p x)\p.support.toFinset).card)
    (F : HookFamily p (OmittedStar p x) k) : False := by
  let A := OmittedStar p x
  let B := External G A
  have ao : ∀ z∈A,z∉p.support := fun _ z =>
    (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp z).1
  have cA : ∀ u∈A,∀ v∉A,G.Adj u v → v∈B := fun u hu v hv ed =>
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨hv,u,hu,ed⟩
  have ab : Disjoint A B := disjoint_left.mpr fun _ hu hv =>
    (Graffiti189LongestPath.Rigidity.mem_external.mp hv).1 hu
  have eq := star_card_degree_and_pins hp hx
  have big : 1<A.card := by
    change A.card+(Pins p x).card=G.degree x+1 at eq
    omega
  have low := weighted_hooked_lower k (by omega) hp H A ao big routes F
  have long := off_path_ports_le_total_hook_length A B k sat ab cA hp F ao
  have up := double_star_order_upper hc k hk cap conn hp hx hy xy high double sep
  change Fintype.card V≤A.card+k+k*(k+2) at up
  change k*(k+2)<(k+1)*H+2*(B\p.support.toFinset).card at extra
  omega

#print axioms almost_routable_double_no_fan
end Graffiti189LongestPath.AlmostRoutable
