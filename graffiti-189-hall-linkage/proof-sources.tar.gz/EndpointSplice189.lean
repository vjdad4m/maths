import Rigidity189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath Graffiti189LongestPath.Rigidity

set_option warningAsError true
namespace Graffiti189LongestPath.EndpointSplice
variable {V : Type*} {G : SimpleGraph V}

private lemma extend_prefix {a b x y : V} (p : G.Walk a b) (hp : p.IsPath)
    (q : G.Walk x y) (hq : q.IsPath) (off : ∀ z∈q.support,z∉p.support)
    (i : Nat) (ip : i≤p.length) (ed : G.Adj (p.getVert i) x) :
    ∃ r : G.Walk a y, r.IsPath ∧ r.length=i+q.length+1 ∧
      ∀ z∈r.support, z∈p.support ∨ z∈q.support := by
  induction p generalizing i with
  | nil =>
    have ie : i=0 := by simpa using ip
    subst i
    refine ⟨.cons ed q,hq.cons (fun e => off _ e (by simp)),by simp,?_⟩
    intro v hv
    rw [support_cons,List.mem_cons] at hv
    exact hv.elim (fun e => Or.inl (by simp [e])) Or.inr
  | @cons a u b au p ih =>
    cases i with
    | zero =>
      refine ⟨.cons ed q,hq.cons (fun e => off _ e (by simp)),by simp,?_⟩
      intro v hv
      rw [support_cons,List.mem_cons] at hv
      exact hv.elim (fun e => Or.inl (by simp [e])) Or.inr
    | succ i =>
      obtain ⟨r,hr,rl,rs⟩ := ih hp.of_cons
        (fun _ hv hp => off _ hv (List.mem_cons_of_mem _ hp)) i (by simpa using ip) ed
      refine ⟨.cons au r,hr.cons ?_,by simp only [length_cons,rl]; omega,?_⟩
      · intro hav
        exact (rs a hav).elim ((cons_isPath_iff _ _).mp hp).2 (fun v => off _ v (by simp))
      · intro v hv
        rw [support_cons,List.mem_cons] at hv
        exact hv.elim (fun e => Or.inl (by simp [e]))
          (fun h => (rs v h).elim (fun e => Or.inl (List.mem_cons_of_mem _ e)) Or.inr)

theorem endpoint_room [Fintype V] {a b x y : V} {p : G.Walk a b} (hp : IsLongest p)
    (q : G.Walk x y) (hq : q.IsPath) (off : ∀ z∈q.support,z∉p.support)
    {i : Nat} (ip : i≤p.length) (ed : G.Adj (p.getVert i) x) :
    q.length+1≤i ∧ i+q.length+1≤p.length := by
  obtain ⟨r,hr,rl,_⟩ := extend_prefix p hp.1 q hq off i ip ed
  have max₁ := hp.2 a y r hr
  let P := p.reverse
  have Pmax : IsLongest P := ⟨hp.1.reverse,fun u v h hq => by simpa [P] using hp.2 u v h hq⟩
  have ip' : p.length-i≤P.length := by simp [P]
  have ed' : G.Adj (P.getVert (p.length-i)) x := by
    unfold P
    rw [getVert_reverse,show p.length-(p.length-i)=i by omega]
    exact ed
  have no : ∀ z∈q.support,z∉P.support := fun z hz h => off z hz (by simpa [P] using h)
  obtain ⟨r',hr',rl',_⟩ := extend_prefix P Pmax.1 q hq no _ ip' ed'
  have max₂ := hp.2 b y r' hr'
  omega

#print axioms endpoint_room
end Graffiti189LongestPath.EndpointSplice
