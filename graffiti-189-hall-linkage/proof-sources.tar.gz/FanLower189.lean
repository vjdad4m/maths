import EndpointSplice189
import WideWing189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack
open Graffiti189LongestPath.WideWing
open Graffiti189LongestPath.EndpointSplice
open private Graffiti189LongestPath.Rigidity.mem_omittedStar from Rigidity189
set_option warningAsError true
set_option maxHeartbeats 2000000
namespace Graffiti189LongestPath.FanRoutable
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- The last edge is represented separately, so the rest of each hook
is entirely off the longest path. Each hook meets the star only at its
starting vertex. -/
structure HookFamily {a b : V} (p : G.Walk a b) (A : Finset V) (k : Nat) where
  idx : Fin k ↪ ℕ
  root : Fin k → V
  last : Fin k → V
  path : ∀ j, G.Walk (root j) (last j)
  simple : ∀ j, (path j).IsPath
  idxLt : ∀ j, idx j<p.length
  adjLast : ∀ j, G.Adj (last j) (p.getVert (idx j))
  firstIn : ∀ j, root j∈A
  single : ∀ j z, z∈(path j).support → z∈A → z=root j
  off : ∀ j z, z∈(path j).support → z∉p.support
  disj : Pairwise (fun i j => List.Disjoint (path i).support (path j).support)

omit [Fintype V] [DecidableEq V] [DecidableRel G.Adj] in
private lemma path_append_separated {u v w : V} {p : G.Walk u v} {q : G.Walk v w}
    (hp : p.IsPath) (hq : q.IsPath)
    (only : ∀ z∈p.support, z∈q.support → z=v) :
    (p.append q).IsPath := by
  rw [isPath_def,support_append,List.nodup_append]
  refine ⟨hp.support_nodup,hq.support_nodup.tail,?_⟩
  intro z zp zq
  have e := only z zp (List.mem_of_mem_tail zq)
  subst z
  cases q with
  | nil => simp at zq
  | cons edge q => exact ((cons_isPath_iff edge q).mp hq).2 zq

theorem fan_count (k h len : Nat) (kpos : 0<k) (I : Finset Nat) (ik : I.card=k)
    (room : ∀ i∈I, h≤i ∧ i+h≤len)
    (gap : ∀ i∈I,∀ j∈I,i<j → i+h+1≤j) :
    k+(k+2)*h≤h+len+1 := by
  classical
  have walk (n : Nat) : ∀ J : Finset Nat, J.card=n → 0<n →
      ∀ L, (∀ i∈J,L≤i) → (∀ i∈J,∀ j∈J,i<j → i+(h+1)≤j) →
        ∃ z∈J,L+(n-1)*(h+1)≤z := by
    induction n with
    | zero => intro J jc pos; omega
    | succ n ih =>
      intro J jc pos L lower spaced
      have ne : J.Nonempty := card_pos.mp (by omega)
      let v := J.min' ne
      have hv : v∈J := min'_mem _ _
      by_cases e : n=0
      · subst n
        exact ⟨v,hv,by simpa using lower v hv⟩
      let S := J.erase v
      have eq : S.card=n := (card_erase_of_mem hv).trans (by omega)
      have sl : ∀ z∈S,L+(h+1)≤z := by
        intro z hz
        obtain ⟨ne,hz⟩ := mem_erase.mp hz
        have vlt : v≤z := min'_le J z hz
        have s := spaced v hv z hz (by omega)
        have low := lower v hv
        omega
      obtain ⟨z,hz,g⟩ := ih S eq (by omega) (L+(h+1)) sl
        (fun i hi j hj e => spaced i (mem_erase.mp hi).2 j (mem_erase.mp hj).2 e)
      have nm : n*(h+1)=(n-1)*(h+1)+(h+1) := by
        calc
          n*(h+1) = (n-1+1)*(h+1) := congrArg (fun b => b*(h+1)) (by omega)
          _ = _ := by rw [Nat.add_mul,one_mul]
      exact ⟨z,(mem_erase.mp hz).2,by simp only [Nat.succ_sub_one]; omega⟩
  obtain ⟨z,hz,f⟩ := walk k I ik kpos h (fun i hi => (room i hi).1)
    (fun i hi j hj e => by have b := gap i hi j hj e; omega)
  have r := (room z hz).2
  have mul : k*h=(k-1)*h+h := by
    calc
      k*h = (k-1+1)*h := congrArg (fun z => z*h) (by omega)
      _ = _ := by rw [Nat.add_mul,one_mul]
  rw [Nat.mul_add,Nat.mul_one] at f
  rw [Nat.add_mul,two_mul]
  omega

theorem hooked_routable_lower (k : Nat) (kpos : 0<k)
    {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    (A : Finset V) (ao : ∀ z∈A,z∉p.support) (big : 1<A.card)
    (routes : ∀ u∈A,∀ v∈A,u≠v →
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈A) ∧ q.length+1=A.card)
    (F : HookFamily p A k) :
    k+(k+2)*A.card≤Fintype.card V := by
  classical
  let I := (univ : Finset (Fin k)).map F.idx
  have kI : I.card=k := by simp [I]
  have room (i : Fin k) : A.card≤F.idx i ∧ F.idx i+A.card≤p.length := by
    obtain ⟨v,hv,ne⟩ := exists_ne_of_one_lt_card big (F.root i)
    obtain ⟨q,hq,qs,ql⟩ := routes (F.root i) (F.firstIn i) v hv ne.symm
    let w := (F.path i).reverse.append q
    have wp : w.IsPath := path_append_separated (F.simple i).reverse hq (by
      intro z hz zq
      exact F.single i z (by simpa only [support_reverse,List.mem_reverse] using hz) (qs z zq))
    have wo : ∀ z∈w.support,z∉p.support := by
      intro z hz
      rw [show w=(F.path i).reverse.append q from rfl,support_append,List.mem_append] at hz
      exact hz.elim (fun l => F.off i z (by simpa only [support_reverse,List.mem_reverse] using l))
        (fun r => ao z (qs z (List.mem_of_mem_tail r)))
    have d := endpoint_room hp w wp wo (Nat.le_of_lt (F.idxLt i)) (F.adjLast i).symm
    simp only [w,length_append,length_reverse] at d
    omega
  have gap (i j : Fin k) (lt : F.idx i<F.idx j) : F.idx i+A.card+1≤F.idx j := by
    have ij : i≠j := fun eq => (Nat.lt_irrefl _) (eq ▸ lt)
    have roots : F.root i≠F.root j := by
      intro e
      exact F.disj ij (F.path i).start_mem_support (e.symm ▸ (F.path j).start_mem_support)
    obtain ⟨q,hq,qs,ql⟩ := routes (F.root i) (F.firstIn i) (F.root j) (F.firstIn j) roots
    let l := (F.path i).reverse.append q
    have lp : l.IsPath := path_append_separated (F.simple i).reverse hq (by
      intro z hz qz
      exact F.single i z (by simpa only [support_reverse,List.mem_reverse] using hz) (qs z qz))
    let w := l.append (F.path j)
    have wp : w.IsPath := path_append_separated lp (F.simple j) (by
      intro z zl zj
      rw [show l=(F.path i).reverse.append q from rfl,support_append,List.mem_append] at zl
      rcases zl with ll|rr
      · exact (F.disj ij (by simpa only [support_reverse,List.mem_reverse] using ll) zj).elim
      · exact F.single j z zj (qs z (List.mem_of_mem_tail rr)))
    have wo : ∀ z∈w.support,z∉p.support := by
      intro z hz
      rw [show w=l.append (F.path j) from rfl,support_append,List.mem_append] at hz
      rcases hz with hl|hj
      · rw [show l=(F.path i).reverse.append q from rfl,support_append,List.mem_append] at hl
        exact hl.elim (fun l => F.off i z (by simpa only [support_reverse,List.mem_reverse] using l))
          (fun r => ao z (qs z (List.mem_of_mem_tail r)))
      · exact F.off j z (List.mem_of_mem_tail hj)
    have pi : F.idx i∈Pins p (F.last i) := mem_filter.mpr ⟨mem_range.mpr (F.idxLt i),F.adjLast i⟩
    have pj : F.idx j∈Pins p (F.last j) := mem_filter.mpr ⟨mem_range.mpr (F.idxLt j),F.adjLast j⟩
    have r := terminal_length_le_gap hp pi pj lt w wp wo
    simp only [w,l,length_append,length_reverse] at r
    omega
  have span := fan_count k A.card p.length kpos I kI
    (by intro i hi; obtain ⟨j,_,rfl⟩ := mem_map.mp hi; exact room j)
    (by
      intro i hi j hj lt
      obtain ⟨u,_,rfl⟩ := mem_map.mp hi
      obtain ⟨v,_,rfl⟩ := mem_map.mp hj
      exact gap u v lt)
  have ds : Disjoint A p.support.toFinset := disjoint_left.mpr (fun _ h s =>
    ao _ h (List.mem_toFinset.mp s))
  have c := card_le_univ (A∪p.support.toFinset)
  rw [card_union_of_disjoint ds,List.toFinset_card_of_nodup hp.1.support_nodup,length_support] at c
  omega

#print axioms fan_count
#print axioms hooked_routable_lower
end Graffiti189LongestPath.FanRoutable
