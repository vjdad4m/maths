import FanLower189
import DoubleThirdBudget189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack
open Graffiti189LongestPath.ActiveStarHeight Graffiti189LongestPath.WideWing
open Graffiti189LongestPath.EndpointSplice Graffiti189LongestPath.DoubleThirdBudget
open private Graffiti189LongestPath.Rigidity.mem_omittedStar from Rigidity189
set_option warningAsError true
set_option maxHeartbeats 2000000
namespace Graffiti189LongestPath.FanRoutable
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- This is unconditional on the number of cut ports on the longest path.
An actual disjoint linkage implies the separated routable branch cannot
exist; the finite Menger bridge must supply the linkage independently. -/
theorem routable_double_no_fan (hc : G.Connected) (k : Nat) (hk : 6≤k)
    (cap : ∀ v, (EvenFrom G v).card≤k+3)
    (conn : ∀ S : Finset V, S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    {a b x y : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
    (hy : y∉p.support) (xy : G.Adj x y) (high : k+2≤G.degree x)
    (double : (Pins p x).card=2) (sep : PairedPins p x=∅)
    (routes : ∀ u∈OmittedStar p x,∀ v∈OmittedStar p x,u≠v →
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ w∈q.support,w∈OmittedStar p x) ∧
        q.length+1=(OmittedStar p x).card)
    (F : HookFamily p (OmittedStar p x) k) : False := by
  let h := (OmittedStar p x).card
  have eq := star_card_degree_and_pins hp hx
  change h+(Pins p x).card=G.degree x+1 at eq
  have hmin : k+1≤h := by omega
  have under := hooked_routable_lower k (by omega) hp (OmittedStar p x)
    (fun _ z => (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp z).1) (by omega) routes F
  have over := double_star_order_upper hc k hk cap conn hp hx hy xy high double sep
  change k+(k+2)*h≤Fintype.card V at under
  change Fintype.card V≤h+k+k*(k+2) at over
  have ht := Nat.mul_le_mul_left (k+1) hmin
  have sq : (k+1)*(k+1)=k*(k+2)+1 := by simp [Nat.mul_add,Nat.add_mul,Nat.mul_comm]; omega
  rw [sq] at ht
  have m : (k+2)*h=(k+1)*h+h := by
    rw [show k+2=(k+1)+1 by omega,Nat.add_mul,one_mul]
  rw [m] at under
  omega
#print axioms routable_double_no_fan
end Graffiti189LongestPath.FanRoutable
