import FanLower189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.FanRoutable
open Graffiti189LongestPath.EndpointSplice Graffiti189LongestPath.WideWing
open private Graffiti189LongestPath.FanRoutable.path_append_separated from FanLower189
open scoped BigOperators
set_option warningAsError true
set_option maxHeartbeats 2000000
namespace Graffiti189LongestPath.FanWeighted

/-- Weighted spacing: every hook length is counted twice, including the
outermost hooks, since the ends of the path provide length constraints. -/
theorem weighted_span (h len : Nat) (I : Finset Nat) (w : Nat → Nat)
    (pos : 0<I.card) (room : ∀ i∈I,h+w i≤i ∧ i+h+w i≤len)
    (gap : ∀ i∈I,∀ j∈I,i<j → i+h+1+w i+w j≤j) :
    I.card+(I.card+1)*h+2*(∑ i ∈ I,w i)≤len+1 := by
  classical
  have walk (J : Finset Nat) (pos : 0<J.card) (L : Nat)
      (lower : ∀ i∈J,L+w i≤i)
      (space : ∀ i∈J,∀ j∈J,i<j → i+h+1+w i+w j≤j) :
      ∃ z∈J,L+(J.card-1)*(h+1)+2*(∑ i ∈ J,w i)≤z+w z := by
    induction J using Finset.strongInductionOn generalizing L with
    | _ J ih =>
      have ne : J.Nonempty := card_pos.mp pos
      let x := J.min' ne
      have hx : x∈J := min'_mem _ _
      have xl := lower x hx
      let S := J.erase x
      have cs := card_erase_of_mem hx
      change S.card=J.card-1 at cs
      have sum : (∑ i ∈ J,w i)=(∑ i ∈ S,w i)+w x := (sum_erase_add _ _ hx).symm
      by_cases e : J.card=1
      · have emp : S=∅ := card_eq_zero.mp (by omega)
        refine ⟨x,hx,?_⟩
        rw [sum,emp,sum_empty,e]
        omega
      have ss : S ⊂ J := erase_ssubset hx
      have sl : ∀ z∈S,L+(h+1)+2*w x+w z≤z := by
        intro z hz
        obtain ⟨ne,hz⟩ := mem_erase.mp hz
        have xz := min'_le J z hz
        have g := space x hx z hz (by omega)
        omega
      obtain ⟨z,hz,bb⟩ := ih S ss (by omega) (L+(h+1)+2*w x) sl
        (fun i hi j hj e => space i (mem_erase.mp hi).2 j (mem_erase.mp hj).2 e)
      have m : (J.card-1)*(h+1)=(S.card-1)*(h+1)+(h+1) := by
        calc
          (J.card-1)*(h+1)=((S.card-1)+1)*(h+1) :=
            congrArg (fun z => z*(h+1)) (by omega)
          _ = _ := by rw [Nat.add_mul,one_mul]
      refine ⟨z,(mem_erase.mp hz).2,?_⟩
      rw [sum,m]
      omega
  obtain ⟨z,hz,ll⟩ := walk I pos h (fun i hi => (room i hi).1) gap
  have r := (room z hz).2
  rw [Nat.mul_add,Nat.mul_one] at ll
  have m : (I.card+1)*h=(I.card-1)*h+2*h := by
    rw [show I.card+1=(I.card-1)+2 by omega,Nat.add_mul]
  rw [m]
  omega
#print axioms weighted_span

variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- For any common lower bound H on lengths of internal terminal paths,
each unit of hook length saves two extra vertices in the spacing bound. -/
theorem weighted_hooked_lower (k : Nat) (kpos : 0<k)
    {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    (H : Nat) (A : Finset V) (ao : ∀ z∈A,z∉p.support) (big : 1<A.card)
    (routes : ∀ u∈A,∀ v∈A,u≠v →
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈A) ∧ H≤q.length+1)
    (F : HookFamily p A k) :
    A.card+k+(k+1)*H+2*(∑ i : Fin k, (F.path i).length)≤Fintype.card V := by
  classical
  let I := (univ : Finset (Fin k)).map F.idx
  have kI : I.card=k := by simp [I]
  have room (i : Fin k) : H+(F.path i).length≤F.idx i ∧ F.idx i+H+(F.path i).length≤p.length := by
    obtain ⟨v,hv,ne⟩ := exists_ne_of_one_lt_card big (F.root i)
    obtain ⟨q,hq,qs,ql⟩ := routes (F.root i) (F.firstIn i) v hv ne.symm
    let w := (F.path i).reverse.append q
    have wp : w.IsPath := Graffiti189LongestPath.FanRoutable.path_append_separated (F.simple i).reverse hq (by
      intro z hz zq
      exact F.single i z (by simpa only [support_reverse,List.mem_reverse] using hz) (qs z zq))
    have wo : ∀ z∈w.support,z∉p.support := by
      intro z hz
      rw [show w=(F.path i).reverse.append q from rfl,support_append,List.mem_append] at hz
      exact hz.elim (fun l => F.off i z (by simpa only [support_reverse,List.mem_reverse] using l))
        (fun r => ao z (qs z (List.mem_of_mem_tail r)))
    have d := endpoint_room hp w wp wo (Nat.le_of_lt (F.idxLt i)) (F.adjLast i).symm
    simp only [w,length_append,length_reverse] at d
    omega
  have gap (i j : Fin k) (lt : F.idx i<F.idx j) : F.idx i+H+1+(F.path i).length+(F.path j).length≤F.idx j := by
    have ij : i≠j := fun eq => (Nat.lt_irrefl _) (eq ▸ lt)
    have roots : F.root i≠F.root j := by
      intro e
      exact F.disj ij (F.path i).start_mem_support (e.symm ▸ (F.path j).start_mem_support)
    obtain ⟨q,hq,qs,ql⟩ := routes (F.root i) (F.firstIn i) (F.root j) (F.firstIn j) roots
    let l := (F.path i).reverse.append q
    have lp : l.IsPath := Graffiti189LongestPath.FanRoutable.path_append_separated (F.simple i).reverse hq (by
      intro z hz qz
      exact F.single i z (by simpa only [support_reverse,List.mem_reverse] using hz) (qs z qz))
    let w := l.append (F.path j)
    have wp : w.IsPath := Graffiti189LongestPath.FanRoutable.path_append_separated lp (F.simple j) (by
      intro z zl zj
      rw [show l=(F.path i).reverse.append q from rfl,support_append,List.mem_append] at zl
      rcases zl with ll|rr
      · exact (F.disj ij (by simpa only [support_reverse,List.mem_reverse] using ll) zj).elim
      · exact F.single j z zj (qs z (List.mem_of_mem_tail rr)))
    have wo : ∀ z∈w.support,z∉p.support := by
      intro z hz
      rw [show w=l.append (F.path j) from rfl,support_append,List.mem_append] at hz
      rcases hz with hl|hj
      · rw [show l=(F.path i).reverse.append q from rfl,support_append,List.mem_append] at hl
        exact hl.elim (fun l => F.off i z (by simpa only [support_reverse,List.mem_reverse] using l))
          (fun r => ao z (qs z (List.mem_of_mem_tail r)))
      · exact F.off j z (List.mem_of_mem_tail hj)
    have pi : F.idx i∈Pins p (F.last i) := mem_filter.mpr ⟨mem_range.mpr (F.idxLt i),F.adjLast i⟩
    have pj : F.idx j∈Pins p (F.last j) := mem_filter.mpr ⟨mem_range.mpr (F.idxLt j),F.adjLast j⟩
    have r := terminal_length_le_gap hp pi pj lt w wp wo
    simp only [w,l,length_append,length_reverse] at r
    omega
  let wt (j : Nat) := if hj : ∃ i, F.idx i=j then (F.path (Classical.choose hj)).length else 0
  have wt_eq (i : Fin k) : wt (F.idx i)=(F.path i).length := by
    have e : ∃ j, F.idx j=F.idx i := ⟨i,rfl⟩
    dsimp only [wt]
    rw [dif_pos e, F.idx.injective (Classical.choose_spec e)]
  have span := weighted_span H p.length I wt (by omega)
    (by intro i hi; obtain ⟨j,_,rfl⟩ := mem_map.mp hi; rw [wt_eq]; exact room j)
    (by
      intro i hi j hj lt
      obtain ⟨u,_,rfl⟩ := mem_map.mp hi
      obtain ⟨v,_,rfl⟩ := mem_map.mp hj
      rw [wt_eq,wt_eq]
      exact gap u v lt)
  have e : (∑ i ∈ I,wt i) = ∑ i : Fin k,(F.path i).length := by
    simp [I,sum_map,wt_eq]
  rw [e,kI] at span
  have ds : Disjoint A p.support.toFinset := disjoint_left.mpr (fun _ h s =>
    ao _ h (List.mem_toFinset.mp s))
  have c := card_le_univ (A∪p.support.toFinset)
  rw [card_union_of_disjoint ds,List.toFinset_card_of_nodup hp.1.support_nodup,length_support] at c
  omega


#print axioms weighted_hooked_lower
end Graffiti189LongestPath.FanWeighted
