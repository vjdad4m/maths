import ExactStarShore189
import TwoShoreDefect189
import OneExceptionTerminal189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.Normalize
open Graffiti189LongestPath.TwoShoreTight Graffiti189LongestPath.TwoShoreDefect
open Graffiti189LongestPath.ExactStarShore Graffiti189LongestPath.ActiveStarHeight
open Graffiti189LongestPath.OneExceptionTerminal
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
open private Graffiti189LongestPath.boundary_card_of_connectivity from SmallSeparator189
set_option warningAsError true
set_option maxHeartbeats 2000000
namespace Graffiti189LongestPath.GeneralRootAlternatives
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- At d≥9 a normalized separated double star has the terminal-routing or
root-replacement alternatives even with one ambient low-degree vertex. -/
theorem star_alternatives_one_exception (hc : G.Connected) (k : Nat) (hk : 7≤k)
    (cap : ∀ v, (EvenFrom G v).card≤k+3)
    (conn : ∀ S : Finset V, S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → k+2≤G.degree u ∨ k+2≤G.degree v)
    (fail : ¬∃ (u v : V) (q : G.Walk u v), q.IsPath ∧ ∀ z,z∈q.support)
    {a b x : V} {p : G.Walk a b} (hp : EdgeMinAvoid (k+2) p) (hx : x∉p.support)
    (double : (Pins p x).card=2) (exactB : (External G (OmittedStar p x)).card=k)
    (rootHigh : k+2≤G.degree x) :
    (∃ z∈OmittedStar p x, k+2≤G.degree z ∧
      (((Pins p z).card=2 ∧ G.degree z≤k+3) ∨
       ((Pins p z).card=1 ∧ G.degree z=k+2 ∧ ∀ y,G.dist z y≤3))) ∨
    (∀ s∈OmittedStar p x, ∀ t∈OmittedStar p x, s≠t →
      ∃ q : G.Walk s t, q.IsPath ∧ (∀ z∈q.support,z∈OmittedStar p x) ∧
        q.length+1=(OmittedStar p x).card) := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let U : Finset V := univ\(A∪B)
  let J := G.induce (A : Set V)
  obtain ⟨i,hi⟩ := card_pos.mp (by omega : 0<(Pins p x).card)
  have large : k≤U.card := opposite_large_of_not_traceable hc k (by omega) cap conn deg hp.1.1 hx
    (by omega) hi exactB fail
  have rA {z : V} (hz : z∈U) : z∉A := fun h => (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inl h))
  have rB {z : V} (hz : z∈U) : z∉B := fun h => (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inr h))
  have ul : ∀ u∈U,∀ v∉U,G.Adj u v → v∈B := by
    intro u hu v hv ed
    have cov : v∈A∪B := Classical.byContradiction (fun h => hv (mem_sdiff.mpr ⟨mem_univ _,h⟩))
    exact (mem_union.mp cov).elim (fun h => (rB hu
      (Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨rA hu,v,h,ed.symm⟩)).elim) id
  have ub : Disjoint U B := disjoint_left.mpr (fun _ h h' => rB h h')
  have au : Disjoint A U := disjoint_left.mpr (fun _ h h' => rA h' h)
  have ab : Disjoint A B := disjoint_left.mpr (fun _ h h' =>
    (Graffiti189LongestPath.Rigidity.mem_external.mp h').1 h)
  have cA : ∀ y∈A,∀ z∉A,G.Adj y z → z∈B := fun _ hy _ hz e =>
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨hz,_,hy,e⟩
  have r : ∀ z∈A,z=x ∨ G.Adj x z := fun _ h =>
    (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp h).2
  let m := A.card/2
  by_cases side : ∃ v : ↥(A : Set V), J.degree v=m ∧ k+2≤G.degree v.val
  · obtain ⟨v,e,vv⟩ := side
    by_cases odd : A.card=2*m+1
    · have tight : A.card=2*J.degree v+1 := by rw [e]; exact odd
      obtain ⟨d,_,pv⟩ := tight_inherits_pins hc k (by omega) conn cap hp hx double exactB U ub au
        large ul v vv tight
      exact Or.inl ⟨v.val,v.property,vv,Or.inl ⟨by rw [pv,double],by omega⟩⟩
    have even : A.card=2*m := by
      dsimp [m] at odd ⊢
      omega
    have vo := (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp v.property).1
    have tight : A.card=2*J.degree v := by rw [e]; exact even
    have missed := even_tight_missed_pin hc k conn hp.1.1 hx exactB U ub au large ul v vv
      (cap v.val) tight
    have bd := missed_pin_defect hc k conn hp.1.1 hx exactB U ub au large ul v
    have ct := distanceTwo_le_of_even (k+2) v.val (cap v.val)
    change A.card+G.degree v.val+((Pins p x)\(Pins p v.val)).card≤
      2*J.degree v+(DistanceTwo G v.val).card+1 at bd
    have mp : ((Pins p x)\(Pins p v.val)).card≤1 := missed.1
    have vp : (Pins p v.val).Nonempty := by
      apply Classical.byContradiction
      intro n
      have empty : Pins p v.val=∅ := not_nonempty_iff_eq_empty.mp n
      simp [empty,double] at mp
    obtain ⟨j,hj⟩ := vp
    have vp0 := card_pos.mpr ⟨j,hj⟩
    have vn := (normalized_high_omission hc (k+2) k (by omega) le_rfl cap conn hp vo vv j hj).1
    refine Or.inl ⟨v.val,v.property,vv,?_⟩
    by_cases ds : (Pins p v.val).card=2
    · exact Or.inl ⟨ds,by omega⟩
    have one : (Pins p v.val).card=1 := by omega
    have miss : 0<((Pins p x)\(Pins p v.val)).card := by
      apply Nat.lt_of_not_ge
      intro n
      have eq : (Pins p x)\(Pins p v.val)=∅ := card_eq_zero.mp (by omega)
      have sub : Pins p x⊆Pins p v.val := by
        intro j hj
        by_contra hn
        have err := mem_sdiff.mpr ⟨hj,hn⟩
        rw [eq] at err
        exact not_mem_empty _ err
      have c := card_le_card sub
      omega
    exact Or.inr ⟨one,(missed.2 miss).1,(missed.2 miss).2⟩
  right
  intro s hs t ht ne
  have h8 : 8≤A.card := by
    have eq := star_card_degree_and_pins hp.1.1 hx
    change A.card+(Pins p x).card=G.degree x+1 at eq
    omega
  have lo (v : V) (va : v∈A) : k+2-2≤G.degree v := by
    obtain ⟨u,hu⟩ := card_pos.mp (by omega : 0<U.card)
    have no : ¬G.Adj v u := fun e => rB hu (cA v va u (rA hu) e)
    have vu : u≠v := fun e => rA hu (e.symm ▸ va)
    simp only [Nat.add_sub_cancel]
    rw [←G.card_neighborFinset_eq_degree]
    apply Graffiti189LongestPath.boundary_card_of_connectivity k conn (A:={v}) (a:=u)
    · exact mem_singleton_self _
    · exact fun h => vu (mem_singleton.mp h)
    · exact fun h => no ((G.mem_neighborFinset v u).mp h)
    · exact disjoint_left.mpr (fun _ h e => ((G.mem_neighborFinset v _).mp e).ne (mem_singleton.mp h).symm)
    · exact fun _ h _ _ e => (G.mem_neighborFinset v _).mpr ((mem_singleton.mp h) ▸ e)
  have notTight (v : ↥(A : Set V)) (vd : k+2≤G.degree v.val) :
      A.card/2<(G.induce (A : Set V)).degree v := by
    have e := (universal_shore_degree hc (k+2) k A U B conn exactB ab ub au large cA
      ul (fun z => distanceTwo_le_of_even (k+2) z (cap z)) r v).1
    change A.card+G.degree v.val≤2*J.degree v+(k+2)+1 at e
    have neq : J.degree v≠m := fun h => side ⟨v,h,vd⟩
    dsimp [m] at neq
    change A.card/2<J.degree v
    omega
  exact universal_shore_routes_one_exception hc (k+2) k A U B conn exactB ab ub au
    large cA ul (fun z => distanceTwo_le_of_even (k+2) z (cap z)) r h8 lo deg notTight hs ht ne
#print axioms star_alternatives_one_exception
end Graffiti189LongestPath.GeneralRootAlternatives
