import SmallSeparator189
import Mathlib.Combinatorics.Hall.Finite
open Finset SimpleGraph Graffiti189LongestPath
open private Graffiti189LongestPath.boundary_card_of_connectivity from SmallSeparator189
set_option warningAsError true
set_option maxHeartbeats 1500000
namespace Graffiti189LongestPath.HallLinkage
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- Turn a graph with no small vertex separator into a permutation on
vertex and slot copies. The slot orbits encode all disjoint linkages. -/
theorem exists_linkage_permutation (A T : Finset V) (k : Nat)
    (al : k≤A.card) (tl : k≤T.card)
    (conn : ∀ S : Finset V, S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected) :
    ∃ f : Fin k ⊕ V → Fin k ⊕ V, Function.Injective f ∧
      (∀ i, ∃ v∈A, f (.inl i)=.inr v) ∧
      (∀ v i, f (.inr v)=.inl i → v∈T) ∧
      (∀ v w, f (.inr v)=.inr w → v=w ∨ (G.Adj v w ∧ v∉T ∧ w∉A)) := by
  classical
  let W := Fin k ⊕ V
  let good : W → W → Prop := fun u w =>
    match u, w with
    | .inl _, .inl _ => False
    | .inl _, .inr v => v∈A
    | .inr v, .inl _ => v∈T
    | .inr v, .inr w => v=w ∨ (G.Adj v w ∧ v∉T ∧ w∉A)
  let R (x : W) : Finset W := univ.filter (good x)
  have hall (S : Finset W) : S.card≤(S.biUnion R).card := by
    let real : Finset V := univ.filter (fun x => (Sum.inr x : W)∈S)
    let left : Finset (Fin k) := univ.filter (fun i => (Sum.inl i : W)∈S)
    let N := S.biUnion R
    have together : S⊆(real.image (Sum.inr : V→W)) ∪ left.image (Sum.inl : Fin k→W) := by
      intro u hu
      cases u with
      | inl j => exact mem_union.mpr (Or.inr (mem_image.mpr ⟨j,mem_filter.mpr ⟨mem_univ _,hu⟩,rfl⟩))
      | inr j => exact mem_union.mpr (Or.inl (mem_image.mpr ⟨j,mem_filter.mpr ⟨mem_univ _,hu⟩,rfl⟩))
    have cnt := (card_le_card together).trans (card_union_le _ _)
    rw [card_image_of_injective _ Sum.inr_injective,card_image_of_injective _ Sum.inl_injective] at cnt
    have lc : left.card≤k := by simpa using card_le_univ left
    have useReal : real.image (Sum.inr : V→W)⊆N := by
      intro u hu
      obtain ⟨v,hv,rfl⟩ := mem_image.mp hu
      exact mem_biUnion.mpr ⟨.inr v,(mem_filter.mp hv).2,mem_filter.mpr ⟨mem_univ _,Or.inl rfl⟩⟩
    have rcard := card_le_card useReal
    rw [card_image_of_injective _ Sum.inr_injective] at rcard
    by_cases ls : left.Nonempty
    swap
    · have empty : left=∅ := not_nonempty_iff_eq_empty.mp ls
      have zero : left.card=0 := card_eq_zero.mpr empty
      exact (show S.card≤real.card by omega).trans rcard
    obtain ⟨j,hj⟩ := ls
    have jS := (mem_filter.mp hj).2
    by_cases hit : ∃ z∈real,z∈T
    · obtain ⟨z,zr,zt⟩ := hit
      have useSlots : (univ : Finset (Fin k)).image (Sum.inl : Fin k→W)⊆N := by
        intro a ha
        obtain ⟨i,_,rfl⟩ := mem_image.mp ha
        exact mem_biUnion.mpr ⟨.inr z,(mem_filter.mp zr).2,mem_filter.mpr ⟨mem_univ _,zt⟩⟩
      have dis : Disjoint (real.image (Sum.inr : V→W))
          ((univ : Finset (Fin k)).image (Sum.inl : Fin k→W)) := disjoint_left.mpr (by
        intro u lr ll
        obtain ⟨v,_,rfl⟩ := mem_image.mp lr
        obtain ⟨i,_,he⟩ := mem_image.mp ll
        cases he)
      have cc := card_le_card (union_subset useReal useSlots)
      rw [card_union_of_disjoint dis,card_image_of_injective _ Sum.inr_injective,
        card_image_of_injective _ Sum.inl_injective,card_univ,Fintype.card_fin] at cc
      exact (show S.card≤real.card+k by omega).trans cc
    let D := (A∪(univ.filter (fun z => ∃ v∈real,G.Adj v z)))\real
    have dlarge : k≤D.card := by
      by_cases re : real.Nonempty
      swap
      · have zero : real=∅ := not_nonempty_iff_eq_empty.mp re
        have sub : A⊆D := by
          intro v va
          exact mem_sdiff.mpr ⟨mem_union.mpr (Or.inl va),by rw [zero]; simp⟩
        exact al.trans (card_le_card sub)
      obtain ⟨x,xr⟩ := re
      apply Nat.le_of_not_gt
      intro sm
      have Tn : (T\D).Nonempty := by
        apply Classical.byContradiction
        intro h
        have sb : T⊆D := by
          intro t ht
          apply Classical.byContradiction
          intro td
          exact h ⟨t,mem_sdiff.mpr ⟨ht,td⟩⟩
        have c := card_le_card sb
        omega
      obtain ⟨y,hy⟩ := Tn
      obtain ⟨yt,yd⟩ := mem_sdiff.mp hy
      have yr : y∉real := fun h => hit ⟨y,h,yt⟩
      have rd : Disjoint real D := disjoint_left.mpr (fun v vr vd => (mem_sdiff.mp vd).2 vr)
      have bd : ∀ u∈real,∀ v∉real,G.Adj u v → v∈D :=
        fun u hu v hv e => mem_sdiff.mpr ⟨mem_union.mpr (Or.inr (mem_filter.mpr ⟨mem_univ _,u,hu,e⟩)),hv⟩
      have k' := Graffiti189LongestPath.boundary_card_of_connectivity k conn xr yr yd rd bd
      omega
    have useD : D.image (Sum.inr : V→W)⊆N := by
      intro u hu
      obtain ⟨w,hw,rfl⟩ := mem_image.mp hu
      obtain ⟨ed,_⟩ := mem_sdiff.mp hw
      rcases mem_union.mp ed with wa|ed
      · exact mem_biUnion.mpr ⟨.inl j,jS,mem_filter.mpr ⟨mem_univ _,wa⟩⟩
      by_cases wa : w∈A
      · exact mem_biUnion.mpr ⟨.inl j,jS,mem_filter.mpr ⟨mem_univ _,wa⟩⟩
      obtain ⟨v,vr,vw⟩ := (mem_filter.mp ed).2
      have vt : v∉T := fun h => hit ⟨v,vr,h⟩
      exact mem_biUnion.mpr ⟨.inr v,(mem_filter.mp vr).2,
        mem_filter.mpr ⟨mem_univ _,Or.inr ⟨vw,vt,wa⟩⟩⟩
    have dis : Disjoint (real.image (Sum.inr : V→W)) (D.image (Sum.inr : V→W)) := disjoint_left.mpr (by
      intro v hv h
      obtain ⟨w,wr,rfl⟩ := mem_image.mp hv
      obtain ⟨z,zd,e⟩ := mem_image.mp h
      exact (mem_sdiff.mp zd).2 ((Sum.inr.inj e).symm ▸ wr))
    have cc := card_le_card (union_subset useReal useD)
    rw [card_union_of_disjoint dis,card_image_of_injective _ Sum.inr_injective,
      card_image_of_injective _ Sum.inr_injective] at cc
    exact (show S.card≤real.card+D.card by omega).trans cc
  obtain ⟨f,fi,fr⟩ := (Finset.all_card_le_biUnion_card_iff_existsInjective' R).mp hall
  have ok (u : W) : good u (f u) := (mem_filter.mp (fr u)).2
  refine ⟨f,fi,?_,?_,?_⟩
  · intro i
    have h := ok (.inl i)
    cases e : f (.inl i) with
    | inl j => rw [e] at h; exact h.elim
    | inr v => exact ⟨v,by simpa only [e,good] using h,rfl⟩
  · intro u i e
    have h := ok (.inr u)
    simpa only [e,good] using h
  · intro u v e
    have h := ok (.inr u)
    simpa only [e,good] using h

#print axioms exists_linkage_permutation
end Graffiti189LongestPath.HallLinkage
