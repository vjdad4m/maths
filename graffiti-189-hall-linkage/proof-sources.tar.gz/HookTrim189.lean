import FanLower189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.FanRoutable
open private Graffiti189LongestPath.no_endpoints from SmallSeparator189
set_option warningAsError true
set_option maxHeartbeats 2000000
namespace Graffiti189LongestPath.HookTrim
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

omit [Fintype V] [DecidableEq V] [DecidableRel G.Adj] in
/-- Splitting the edge into the terminal of a trimmed route leaves one
entirely off-path hook. -/
theorem split_final_edge (A : Finset V) {a b s t : V} (p : G.Walk a b)
    (r : G.Walk s t) (rp : r.IsPath) (sa : s∈A) (tp : t∈p.support)
    (ao : ∀ z∈A,z∉p.support)
    (only : ∀ z∈r.support,z∈p.support → z=t) :
    ∃ (u : V) (q : G.Walk s u), q.IsPath ∧ G.Adj u t ∧
      (∀ z∈q.support,z∈r.support) ∧ (∀ z∈q.support,z∉p.support) := by
  have ne : t≠s := fun e => ao s sa (e ▸ tp)
  generalize re : r.reverse = k at *
  have hh : k.IsPath := re ▸ rp.reverse
  have back : ∀ z∈k.support,z∈r.support := by
    intro z hz
    rw [←re,support_reverse,List.mem_reverse] at hz
    exact hz
  cases k with
  | nil => exact (ne rfl).elim
  | @cons t' u s ed tail =>
    refine ⟨u,tail.reverse,hh.of_cons.reverse,ed.symm,?_,?_⟩
    · intro z hz
      exact back z (List.mem_cons_of_mem _ (by simpa only [support_reverse,List.mem_reverse] using hz))
    · intro z hz zp
      have hz' : z∈tail.support := by simpa only [support_reverse,List.mem_reverse] using hz
      have zt := only z (back z (List.mem_cons_of_mem _ hz')) zp
      exact ((cons_isPath_iff _ _).mp hh).2 (zt ▸ hz')

omit [Fintype V] [DecidableEq V] [DecidableRel G.Adj] in
/-- A trimmed vertex-disjoint set-to-support packing induces a hook family. -/
theorem hooks_of_trimmed_packing (A : Finset V) (k : Nat)
    {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    (ao : ∀ z∈A,z∉p.support)
    (u v : Fin k → V) (q : ∀ i,G.Walk (u i) (v i))
    (qs : ∀ i,(q i).IsPath) (ui : ∀ i,u i∈A) (vi : ∀ i,v i∈p.support)
    (one : ∀ i z,z∈(q i).support → z∈A → z=u i)
    (two : ∀ i z,z∈(q i).support → z∈p.support → z=v i)
    (disj : Pairwise (fun i j => List.Disjoint (q i).support (q j).support)) :
    Nonempty (HookFamily p A k) := by
  classical
  have step (i : Fin k) := split_final_edge A p (q i) (qs i) (ui i) (vi i) ao (two i)
  choose near tail ts ed rsub off using step
  have existsI (i : Fin k) : ∃ n, p.getVert n=v i ∧ n<p.length := by
    obtain ⟨n,e,h⟩ := mem_support_iff_exists_getVert.mp (vi i)
    refine ⟨n,e,Nat.lt_of_not_ge ?_⟩
    intro hi
    have nn : n=p.length := by omega
    rw [nn,getVert_length] at e
    exact (Graffiti189LongestPath.no_endpoints hp
      (off i (near i) (tail i).end_mem_support)).2 (e.symm ▸ ed i)
  choose idx idxEq idxLt using existsI
  have inj : Function.Injective idx := by
    intro i j eq
    apply Classical.byContradiction
    intro ne
    have tt : v i=v j := (idxEq i).symm.trans (eq.symm ▸ idxEq j)
    exact disj ne ((q i).end_mem_support)
      (tt.symm ▸ (q j).end_mem_support)
  refine ⟨⟨⟨idx,inj⟩,u,near,tail,ts,idxLt,?_,ui,?_,off,?_⟩⟩
  · intro i
    change G.Adj (near i) (p.getVert (idx i))
    rw [idxEq i]
    exact ed i
  · intro i z hz za
    exact one i z (rsub i z hz) za
  · intro i j ne z zi zj
    exact disj ne (rsub i z zi) (rsub j z zj)

#print axioms split_final_edge
#print axioms hooks_of_trimmed_packing
end Graffiti189LongestPath.HookTrim
