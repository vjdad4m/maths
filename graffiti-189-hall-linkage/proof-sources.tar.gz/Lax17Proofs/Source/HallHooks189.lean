import Lax17Proofs.Source.HallOrbit189
import HallLinkage189
import HookTrim189

open SimpleGraph

namespace Graffiti189LongestPath

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V} [DecidableRel G.Adj]

theorem hooks_of_small_deletion_connectivity (A : Finset V) (k : ℕ)
    {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    (ao : ∀ z ∈ A, z ∉ p.support)
    (ha : k ≤ A.card) (hpCard : k ≤ p.support.toFinset.card)
    (conn : ∀ S : Finset V, S.card < k → (G.induce ((↑S : Set V)ᶜ)).Connected) :
    Nonempty (FanRoutable.HookFamily p A k) := by
  obtain ⟨f,hf,hs,ht,hh⟩ := HallLinkage.exists_linkage_permutation (G := G)
    A p.support.toFinset k ha hpCard conn
  obtain ⟨P⟩ := MengerHallOrbit189.linkage_of_matching G A p.support.toFinset k f hf hs ht hh
  exact HookTrim.hooks_of_trimmed_packing A k hp ao P.root P.terminal P.path P.simple
    P.root_mem (fun i => List.mem_toFinset.mp (P.terminal_mem i)) P.root_only
    (fun i z hz hpz => P.terminal_only i z hz (List.mem_toFinset.mpr hpz)) P.disjoint

#print axioms hooks_of_small_deletion_connectivity

end Graffiti189LongestPath
