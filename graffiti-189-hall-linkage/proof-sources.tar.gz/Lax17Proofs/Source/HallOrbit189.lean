import Mathlib.Combinatorics.SimpleGraph.Path
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Fintype.Sum
import Mathlib.Logic.Function.Iterate
import Mathlib.Data.Nat.Find

/-! Recover terminal-clean linkage paths from a finite Hall matching as walks. -/
namespace MengerHallOrbit189

open Function

structure Linkage {V : Type*} [DecidableEq V] (G : SimpleGraph V)
    (A T : Finset V) (k : ℕ) where
  root : Fin k → V
  terminal : Fin k → V
  path : ∀ i, G.Walk (root i) (terminal i)
  simple : ∀ i, (path i).IsPath
  root_mem : ∀ i, root i ∈ A
  terminal_mem : ∀ i, terminal i ∈ T
  root_only : ∀ i v, v ∈ (path i).support → v ∈ A → v = root i
  terminal_only : ∀ i v, v ∈ (path i).support → v ∈ T → v = terminal i
  disjoint : Pairwise fun i j => List.Disjoint (path i).support (path j).support

private theorem cancel_iterates {α : Type*} {f : α → α} (hf : Function.Injective f)
    {a b : ℕ} {x y : α} (h : a ≤ b) (he : f^[a] x = f^[b] y) :
    x = f^[b-a] y := by
  apply hf.iterate a
  rwa [← Function.iterate_add_apply, Nat.add_sub_of_le h]

private theorem positive_return {α : Type*} [Fintype α] {f : α → α}
    (hf : Function.Injective f) (x : α) : ∃ d : ℕ, 0 < d ∧ f^[d] x = x := by
  classical
  obtain ⟨i,j,hne,he⟩ := Fintype.exists_ne_map_eq_of_card_lt
    (fun y : Fin (Fintype.card α + 1) => f^[y.val] x) (by simp)
  have hv : i.val ≠ j.val := fun e => hne (Fin.ext e)
  rcases lt_or_gt_of_ne hv with h | h
  · exact ⟨j.val-i.val,by omega,(cancel_iterates hf h.le he).symm⟩
  · exact ⟨i.val-j.val,by omega,(cancel_iterates hf h.le he.symm).symm⟩

private def runWalk {V : Type*} (G : SimpleGraph V) (v : ℕ → V) :
    (n : ℕ) → (∀ i < n, G.Adj (v i) (v (i+1))) → G.Walk (v 0) (v n)
  | 0, _ => .nil
  | n+1, h => (runWalk G v n (fun i hi => h i (by omega))).concat (h n (by omega))

private theorem runWalk_support {V : Type*} (G : SimpleGraph V) (v : ℕ → V)
    (n : ℕ) (h : ∀ i < n, G.Adj (v i) (v (i+1))) :
    (runWalk G v n h).support = (List.range (n+1)).map v := by
  induction n with
  | zero => rfl
  | succ n ih =>
    rw [runWalk, SimpleGraph.Walk.support_concat, ih, List.range_succ (n := n+1)]
    simp only [List.concat_eq_append, List.map_append, List.map_singleton]

theorem linkage_of_matching {V : Type*} [Fintype V] [DecidableEq V]
    (G : SimpleGraph V) (A T : Finset V) (k : ℕ)
    (f : Fin k ⊕ V → Fin k ⊕ V) (hf : Function.Injective f)
    (hstart : ∀ j : Fin k, ∃ v ∈ A, f (Sum.inl j) = Sum.inr v)
    (hstop : ∀ (v : V) (j : Fin k), f (Sum.inr v) = Sum.inl j → v ∈ T)
    (hstep : ∀ v w : V, f (Sum.inr v) = Sum.inr w →
      v = w ∨ (G.Adj v w ∧ v ∉ T ∧ w ∉ A)) : Nonempty (Linkage G A T k) := by
  classical
  have rr (j : Fin k) :
      ∃ d : ℕ, 0 < d ∧ ∃ i : Fin k, f^[d] (Sum.inl j) = Sum.inl i := by
    obtain ⟨d, hd, he⟩ := positive_return hf (Sum.inl j)
    exact ⟨d,hd,j,he⟩
  let n : Fin k → ℕ := fun j => Nat.find (rr j)
  have hn0 (j : Fin k) : 0 < n j := (Nat.find_spec (rr j)).1
  have hlast (j : Fin k) : ∃ i : Fin k, f^[n j] (Sum.inl j) = Sum.inl i :=
    (Nat.find_spec (rr j)).2
  have havoid (j : Fin k) (t : ℕ) (hp : 0 < t) (ht : t < n j) (i : Fin k) :
      f^[t] (Sum.inl j) ≠ Sum.inl i := by
    intro h
    exact Nat.find_min (rr j) ht ⟨hp,i,h⟩
  have hn2 (j : Fin k) : 2 ≤ n j := by
    by_contra h
    have hn1 : n j = 1 := by have := hn0 j; omega
    obtain ⟨i,hi⟩ := hlast j
    obtain ⟨v,_,hv⟩ := hstart j
    rw [hn1] at hi
    have hsame : (Sum.inr v : Fin k ⊕ V) = Sum.inl i := hv.symm.trans hi
    cases hsame
  let d : Fin k → ℕ := fun j => n j - 2
  let v : Fin k → ℕ → V := fun j t =>
    match f^[t+1] (Sum.inl j) with
    | .inl _ => (hstart j).choose
    | .inr a => a
  have hreal (j : Fin k) (t : ℕ) (ht : t ≤ d j) :
      f^[t+1] (Sum.inl j) = Sum.inr (v j t) := by
    have hlt : t+1 < n j := by have := hn2 j; dsimp [d] at ht; omega
    cases he : f^[t+1] (Sum.inl j) with
    | inl i => exact (havoid j (t+1) (by omega) hlt i he).elim
    | inr a =>
      apply congrArg Sum.inr
      change a = (match f^[t+1] (Sum.inl j) with
        | .inl _ => (hstart j).choose
        | .inr x => x)
      rw [he]
  have hdiff (i j : Fin k) (a b : ℕ) (ha : a ≤ d i) (hb : b ≤ d j)
      (he : v i a = v j b) : i = j ∧ a = b := by
    have heq : f^[a+1] (Sum.inl i) = f^[b+1] (Sum.inl j) := by
      rw [hreal i a ha, hreal j b hb, he]
    have hab : ¬ a < b := by
      intro hlt
      have hc := cancel_iterates hf (show a+1 ≤ b+1 by omega) heq
      have hlt' : b+1-(a+1) < n j := by dsimp [d] at hb; have := hn2 j; omega
      exact havoid j _ (by omega) hlt' i hc.symm
    have hba : ¬ b < a := by
      intro hlt
      have hc := cancel_iterates hf (show b+1 ≤ a+1 by omega) heq.symm
      have hlt' : a+1-(b+1) < n i := by dsimp [d] at ha; have := hn2 i; omega
      exact havoid i _ (by omega) hlt' j hc.symm
    have haeq : a = b := by omega
    subst b
    exact ⟨Sum.inl.inj (hf.iterate (a+1) heq),rfl⟩
  have hedges (j : Fin k) (t : ℕ) (h : t < d j) :
      G.Adj (v j t) (v j (t+1)) ∧ v j t ∉ T ∧ v j (t+1) ∉ A := by
    have hnext := hreal j (t+1) (by omega)
    rw [Function.iterate_succ_apply',hreal j t (by omega)] at hnext
    rcases hstep _ _ hnext with he | ht
    · exact (by have hh := (hdiff j j t (t+1) (by omega) (by omega) he).2; omega : False).elim
    · exact ht
  have hroot (j : Fin k) : v j 0 ∈ A := by
    obtain ⟨a,ha,he⟩ := hstart j
    have eq : (Sum.inr a : Fin k ⊕ V) = Sum.inr (v j 0) :=
      he.symm.trans (hreal j 0 (Nat.zero_le _))
    exact (Sum.inr.inj eq) ▸ ha
  have hterminal (j : Fin k) : v j (d j) ∈ T := by
    obtain ⟨i,hi⟩ := hlast j
    have hnd : n j = (d j + 1) + 1 := by have := hn2 j; dsimp [d]; omega
    rw [hnd,Function.iterate_succ_apply',hreal j (d j) le_rfl] at hi
    exact hstop _ _ hi
  let path : ∀ j, G.Walk (v j 0) (v j (d j)) :=
    fun j => runWalk G (v j) (d j) (fun t ht => (hedges j t ht).1)
  have hs (j : Fin k) : (path j).support = (List.range (d j+1)).map (v j) :=
    runWalk_support _ _ _ _
  have hm (j : Fin k) {a : V} (ha : a ∈ (path j).support) :
      ∃ t ≤ d j, v j t = a := by
    rw [hs] at ha
    obtain ⟨t,ht,e⟩ := List.mem_map.mp ha
    exact ⟨t, Nat.le_of_lt_succ (List.mem_range.mp ht),e⟩
  refine ⟨⟨fun j => v j 0, fun j => v j (d j), path, ?_,
    hroot, hterminal, ?_, ?_, ?_⟩⟩
  · intro j
    apply SimpleGraph.Walk.IsPath.mk'
    rw [hs]
    refine (List.nodup_map_iff_inj_on List.nodup_range).mpr ?_
    intro a ha b hb h
    exact (hdiff j j a b (Nat.le_of_lt_succ (List.mem_range.mp ha))
      (Nat.le_of_lt_succ (List.mem_range.mp hb)) h).2
  · intro j a ha hA
    obtain ⟨q,hq,rfl⟩ := hm j ha
    cases q with
    | zero => rfl
    | succ q => exact ((hedges j q (by omega)).2.2 hA).elim
  · intro j a ha hT
    obtain ⟨q,hq,rfl⟩ := hm j ha
    by_cases h : q < d j
    · exact ((hedges j q h).2.1 hT).elim
    · exact congrArg (v j) (by omega)
  · intro i j hij a hai haj
    obtain ⟨s,hs,hsa⟩ := hm i hai
    obtain ⟨t,ht,hta⟩ := hm j haj
    exact hij (hdiff i j s t hs ht (hsa.trans hta.symm)).1

#print axioms linkage_of_matching

end MengerHallOrbit189
