import DoubleThirdBudget189
import FanLower189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack
open Graffiti189LongestPath.ActiveStarHeight Graffiti189LongestPath.PortHall
open Graffiti189LongestPath.DoubleThirdBudget Graffiti189LongestPath.WideWing
open Graffiti189LongestPath.EndpointSplice Graffiti189LongestPath.FanRoutable
open private Graffiti189LongestPath.no_endpoints from SmallSeparator189
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
set_option warningAsError true
set_option maxHeartbeats 2000000
namespace Graffiti189LongestPath.RoutableBoundary
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- A Hamilton-connected star gives each of its path ports a terminal
gap equal to the whole star size, plus one between any two ports. -/
theorem routable_path_ports_lower (k : Nat) (kpos : 0<k)
    (conn : ∀ S : Finset V, S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p)
    (big : k≤(OmittedStar p x).card) (h2 : 1<(OmittedStar p x).card)
    (exactB : (External G (OmittedStar p x)).card=k)
    (allOn : ∀ z∈External G (OmittedStar p x), z∈p.support)
    (routes : ∀ u∈OmittedStar p x,∀ v∈OmittedStar p x,u≠v →
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ w∈q.support,w∈OmittedStar p x) ∧
        q.length+1=(OmittedStar p x).card) :
    k+(k+2)*(OmittedStar p x).card≤Fintype.card V := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let h := A.card
  have ab : Disjoint A B := disjoint_left.mpr (fun _ u v =>
    (Graffiti189LongestPath.Rigidity.mem_external.mp v).1 u)
  have noE (e : V) (en : e=a ∨ e=b) : e∉B := by
    intro he
    obtain ⟨_,v,va,ve⟩ := Graffiti189LongestPath.Rigidity.mem_external.mp he
    have vo := (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp va).1
    rcases en with rfl|rfl
    · exact (Graffiti189LongestPath.no_endpoints hp vo).1 ve
    · exact (Graffiti189LongestPath.no_endpoints hp vo).2 ve
  have aA : a∉A := fun ea =>
    (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp ea).1 p.start_mem_support
  obtain ⟨f,inj,mat⟩ := ports_match_into_shore k A B conn ab exactB big aA
    (noE a (Or.inl rfl)) (fun _ ua _ vb ed =>
      Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨vb,_,ua,ed⟩)
  let I := (range p.length).filter (fun i => p.getVert i∈B)
  have im : I.image p.getVert=B := by
    ext z
    constructor
    · intro h
      obtain ⟨i,hi,rfl⟩ := mem_image.mp h
      exact (mem_filter.mp hi).2
    · intro hz
      obtain ⟨i,eq,il⟩ := mem_support_iff_exists_getVert.mp (allOn z hz)
      have ip : i<p.length := by
        apply Nat.lt_of_not_ge
        intro low
        have e : i=p.length := by omega
        rw [e,getVert_length] at eq
        exact noE b (Or.inr rfl) (eq.symm ▸ hz)
      exact mem_image.mpr ⟨i,mem_filter.mpr ⟨mem_range.mpr ip,eq.symm ▸ hz⟩,eq⟩
  have ik : I.card=k := by
    have ci : (I.image p.getVert).card=I.card := card_image_of_injOn (by
      intro i hi j hj e
      have il := mem_range.mp (mem_filter.mp hi).1
      have jl := mem_range.mp (mem_filter.mp hj).1
      exact hp.1.getVert_injOn (Nat.le_of_lt il) (Nat.le_of_lt jl) e)
    rw [im,exactB] at ci
    exact ci.symm
  have ind {i : Nat} (hi : i∈I) : i<p.length := mem_range.mp (mem_filter.mp hi).1
  let port (i : Nat) (hi : i∈I) : ↥(B : Set V) := ⟨p.getVert i,(mem_filter.mp hi).2⟩
  have pins {i : Nat} (hi : i∈I) : i∈Pins p (f (port i hi)) :=
    mem_filter.mpr ⟨mem_range.mpr (ind hi),(mat _).2.symm⟩
  have off {u v : V} {q : G.Walk u v} (qs : ∀ w∈q.support,w∈A) (z : V)
      (hz : z∈q.support) : z∉p.support :=
    (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp (qs z hz)).1
  have room (i : Nat) (hi : i∈I) : h≤i ∧ i+h≤p.length := by
    let u := f (port i hi)
    obtain ⟨v,hv,ne⟩ := exists_ne_of_one_lt_card h2 u
    obtain ⟨q,hq,qs,ql⟩ := routes u (mat _).1 v hv ne.symm
    have t := endpoint_room hp q hq (off qs) (Nat.le_of_lt (ind hi)) (mat (port i hi)).2
    change q.length+1=h at ql
    omega
  have gap {i j : Nat} (hi : i∈I) (hj : j∈I) (ij : i<j) : i+h+1≤j := by
    have distinct : f (port i hi)≠f (port j hj) := by
      intro e
      have q := congrArg Subtype.val (inj e)
      have r := hp.1.getVert_injOn (Nat.le_of_lt (ind hi)) (Nat.le_of_lt (ind hj)) q
      omega
    obtain ⟨q,hq,qs,ql⟩ := routes _ (mat _).1 _ (mat _).1 distinct
    have gs := terminal_length_le_gap hp (pins hi) (pins hj) ij q hq (off qs)
    change q.length+1=h at ql
    omega
  have nbound := fan_count k h p.length kpos I ik room
    (fun _ hi _ hj lt => gap hi hj lt)
  have count : h+p.length+1≤Fintype.card V := by
    have ds : Disjoint A p.support.toFinset := disjoint_left.mpr (fun _ h s =>
      (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp h).1 (List.mem_toFinset.mp s))
    have c := card_le_univ (A∪p.support.toFinset)
    rw [card_union_of_disjoint ds,List.toFinset_card_of_nodup hp.1.support_nodup,length_support] at c
    exact c
  exact nbound.trans count

/-- If all ports were on the path, a routable separated double star
would exceed its parity upper bound. Hence some cut port is omitted. -/
theorem routable_double_forces_off_path_port (hc : G.Connected) (k : Nat) (hk : 6≤k)
    (cap : ∀ v, (EvenFrom G v).card≤k+3)
    (conn : ∀ S : Finset V, S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    {a b x y : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
    (hy : y∉p.support) (xy : G.Adj x y) (high : k+2≤G.degree x)
    (double : (Pins p x).card=2) (sep : PairedPins p x=∅)
    (routes : ∀ u∈OmittedStar p x,∀ v∈OmittedStar p x,u≠v →
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ w∈q.support,w∈OmittedStar p x) ∧
        q.length+1=(OmittedStar p x).card) :
    ∃ z∈External G (OmittedStar p x),z∉p.support := by
  classical
  apply Classical.byContradiction
  intro fail
  have allOn : ∀ z∈External G (OmittedStar p x),z∈p.support :=
    fun z zb => Classical.byContradiction (fun zo => fail ⟨z,zb,zo⟩)
  obtain ⟨_,_,alt⟩ := double_porter_saturated_one_slack hc k hp hx double (cap x) conn hy xy
  have bk : (External G (OmittedStar p x)).card=k := by
    rcases alt with e|e
    · exact e.2
    · simp [sep] at e
  let h := (OmittedStar p x).card
  have eq := star_card_degree_and_pins hp hx
  change h+(Pins p x).card=G.degree x+1 at eq
  have hmin : k+1≤h := by omega
  have under := routable_path_ports_lower k (by omega) conn hp (by omega) (by omega) bk allOn routes
  have over := double_star_order_upper hc k hk cap conn hp hx hy xy high double sep
  change k+(k+2)*h≤Fintype.card V at under
  change Fintype.card V≤h+k+k*(k+2) at over
  have ht := Nat.mul_le_mul_left (k+1) hmin
  have sq : (k+1)*(k+1)=k*(k+2)+1 := by simp [Nat.mul_add,Nat.add_mul,Nat.mul_comm]; omega
  rw [sq] at ht
  have m : (k+2)*h=(k+1)*h+h := by
    rw [show k+2=(k+1)+1 by omega,Nat.add_mul,one_mul]
  rw [m] at under
  omega

#print axioms routable_path_ports_lower
#print axioms routable_double_forces_off_path_port
end Graffiti189LongestPath.RoutableBoundary
