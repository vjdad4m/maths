#!/usr/bin/env bash
set -euo pipefail
# Run with Lean 4.19, built Mathlib 4.19, and the older #189 objects
# on LEAN_PATH. This script deliberately rebuilds and prioritizes
# all new modules in this staged delta.
root=$(cd "$(dirname "$0")" && pwd)
obj=$(mktemp -d)
trap 'rm -rf "$obj"' EXIT
export LEAN_PATH="$obj:${LEAN_PATH:-}"
for m in EndpointSplice189 GeneralRootAlternatives189 DoubleThirdBudget189 \
  HallLinkage189 FanLower189 HookTrim189 FanRoutable189 RoutableBoundary189 \
  FanWeighted189 FanPorts189 AlmostRoutable189 \
  Lax17Proofs/Source/HallOrbit189 Lax17Proofs/Source/HallHooks189 MengerRoutable189; do
  mkdir -p "$obj/$(dirname "$m")"
  lean -DwarningAsError=true --root="$root" -o "$obj/$m.olean" "$root/$m.lean"
done
