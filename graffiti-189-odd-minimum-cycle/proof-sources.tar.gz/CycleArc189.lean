import CycleRootBridge189
open SimpleGraph SimpleGraph.Walk
open private Graffiti189LongestPath.FanRoutable.path_append_separated from FanLower189
set_option warningAsError true
set_option maxHeartbeats 2500000
namespace Graffiti189LongestPath.CycleArc
variable {V : Type*} [DecidableEq V] {G : SimpleGraph V}

/-- A longer internally exterior path replaces a short directed cycle arc. -/
theorem replace_directed_arc {u v : V} (c : G.Walk u u) (hc : c.IsCycle)
    (hv : v∈c.support) (ne : u≠v) (r : G.Walk u v) (rp : r.IsPath)
    (external : ∀ z∈r.support,z∈c.support → z=u ∨ z=v)
    (gain : (c.takeUntil v hv).length<r.length) :
    ∃ d : G.Walk u u,d.IsCycle ∧ c.length<d.length := by
  let P := c.takeUntil v hv
  let Q := c.dropUntil v hv
  have app : P.append Q=c := take_spec _ hv
  have qp : Q.IsPath := by
    have d := hc
    rw [←app] at d
    exact d.isPath_of_append_right (not_nil_of_ne ne)
  have Qsub : ∀ z∈Q.support,z∈c.support := fun _ z => support_dropUntil_subset _ _ z
  have plen : 0<P.length := not_nil_iff_lt_length.mp (not_nil_of_ne ne)
  have pv : P.length+Q.length=c.length := by rw [←length_append,app]
  cases r with
  | nil => exact (ne rfl).elim
  | @cons u w v e R =>
    have Rlen : 0<R.length := by
      change P.length<R.length+1 at gain
      omega
    have Rnd := ((cons_isPath_iff _ _).mp rp)
    have wv : w≠v := by
      intro ee
      subst v
      have z := (isPath_iff_eq_nil R).mp Rnd.1
      simp [z] at Rlen
    have wout : w∉c.support := by
      intro h
      rcases external w (List.mem_cons_of_mem _ R.start_mem_support) h with d|d
      · exact e.ne d.symm
      · exact wv d
    let L := R.append Q
    have lp : L.IsPath := Graffiti189LongestPath.FanRoutable.path_append_separated Rnd.1 qp (by
      intro z rz qz
      rcases external z (List.mem_cons_of_mem _ rz) (Qsub z qz) with h|h
      · exact ((Rnd.2) (h ▸ rz)).elim
      · exact h)
    have fresh : s(u,w)∉L.edges := by
      intro hn
      rw [show L=R.append Q from rfl,edges_append,List.mem_append] at hn
      exact hn.elim (fun h => Rnd.2 (R.fst_mem_support_of_mem_edges h))
        (fun h => wout (Qsub _ (Q.snd_mem_support_of_mem_edges h)))
    refine ⟨Walk.cons e L,(cons_isCycle_iff _ _).mpr ⟨lp,fresh⟩,?_⟩
    simp only [length_cons,L,length_append]
    change P.length<R.length+1 at gain
    omega

/-- A short indexed prefix of a simple cycle is exactly the arc selected
by `takeUntil`; this is useful after rotating a cycle to start at a chord. -/
theorem prefix_arc_length {u : V} (c : G.Walk u u) (hc : c.IsCycle)
    (i : Nat) (ip : 0<i) (il : i<c.length) :
    (c.takeUntil (c.getVert i) (c.getVert_mem_support i)).length=i := by
  let v := c.getVert i
  have hu : v≠u := by
    intro h
    have e := (hc.getVert_endpoint_iff (by omega : i≤c.length)).mp h
    omega
  let m := (c.takeUntil v (c.getVert_mem_support i)).length
  have ml : m<c.length := length_takeUntil_lt _ hu
  have vq : c.getVert m=v := by
    have b := getVert_takeUntil (c.getVert_mem_support i) (by rfl : m≤m)
    rw [show (c.takeUntil v (c.getVert_mem_support i)).getVert m=v from getVert_length _] at b
    exact b.symm
  exact hc.getVert_injOn' (by change m≤c.length-1; omega)
    (by change i≤c.length-1; omega) vq

#print axioms replace_directed_arc
#print axioms prefix_arc_length
end Graffiti189LongestPath.CycleArc
