import CycleArc189
import Mathlib.Logic.Function.Iterate
open SimpleGraph SimpleGraph.Walk
open Graffiti189LongestPath.CycleArc Graffiti189LongestPath.CycleRootBridge
set_option warningAsError true
set_option maxHeartbeats 2800000
namespace Graffiti189LongestPath.CycleIndex
variable {V : Type*} [DecidableEq V] {G : SimpleGraph V}

theorem rotate_getVert_mod {a : V} (c : G.Walk a a) (hc : c.IsCycle)
    (i j : Nat) (hi : i<c.length) (hj : j<c.length) :
    (c.rotate (c.getVert_mem_support i)).getVert j=c.getVert ((i+j)%c.length) := by
  let z := c.getVert i
  have hz : z∈c.support := c.getVert_mem_support i
  let P := c.takeUntil z hz
  let Q := c.dropUntil z hz
  have app : P.append Q=c := take_spec _ hz
  have ps : P.length=i := by
    by_cases z' : i=0
    · subst i
      have start (w : V) (h : w∈c.support) (eq : w=a) :
          (c.takeUntil w h).length=0 := by
        subst w
        simp only [takeUntil_first,length_nil]
      exact start _ hz (getVert_zero c)
    exact prefix_arc_length c hc i (by omega) hi
  have cp : P.length+Q.length=c.length := by rw [←length_append,app]
  change (Q.append P).getVert j=c.getVert ((i+j)%c.length)
  rw [getVert_append]
  by_cases d : j<Q.length
  · rw [if_pos d,Nat.mod_eq_of_lt (by omega : i+j<c.length)]
    rw [←app,getVert_append,if_neg (by omega : ¬i+j<P.length)]
    rw [show i+j-P.length=j by omega]
  rw [if_neg d]
  have eq : (i+j)%c.length=j-Q.length := by
    rw [Nat.mod_eq_sub_mod (by omega : c.length≤i+j)]
    rw [show i+j-c.length=j-Q.length by omega,Nat.mod_eq_of_lt (by omega)]
  rw [eq]
  exact getVert_takeUntil hz (by change j-Q.length≤P.length; omega)

omit [DecidableEq V] in
theorem cycle_index_injective {a : V} (c : G.Walk a a) (hc : c.IsCycle) :
    Function.Injective (fun i : Fin c.length => c.getVert i.val) := by
  intro i j eq
  apply Fin.ext
  exact hc.getVert_injOn' (by change i.val≤c.length-1; omega)
    (by change j.val≤c.length-1; omega) eq

/-- Cyclic successor on a nonempty finite index set. -/
def succPerm (n : Nat) (np : 0<n) : Fin n ≃ Fin n where
  toFun i := if h : i.val+1<n then ⟨i.val+1,h⟩ else ⟨0,np⟩
  invFun i := if i.val=0 then ⟨n-1,by omega⟩ else ⟨i.val-1,by omega⟩
  left_inv := by
    intro i
    apply Fin.ext
    dsimp only
    split
    · rename_i h
      simp only [Fin.val_mk]
      rw [if_neg (by omega)]
      simp
    · rename_i h
      have e : i.val=n-1 := by omega
      simp [e]
  right_inv := by
    intro i
    apply Fin.ext
    dsimp only
    split
    · rename_i h
      simp only [Fin.val_mk,dif_neg (by omega : ¬n-1+1<n)]
      omega
    · rename_i h
      simp only [Fin.val_mk,dif_pos (by omega : i.val-1+1<n)]
      omega

theorem cycle_succ_formula (n : Nat) (np : 0<n) (i : Fin n) :
    (succPerm n np i).val = (i.val+1)%n := by
  change (if h : i.val+1<n then (⟨i.val+1,h⟩ : Fin n) else ⟨0,np⟩).val=_
  split
  · rename_i h
    exact (Nat.mod_eq_of_lt h).symm
  · rename_i h
    rw [Nat.mod_eq_sub_mod (by omega : n≤i.val+1),show i.val+1-n=0 by omega,Nat.zero_mod]

theorem cycle_succ_iterate_formula (n : Nat) (np : 0<n) (i : Fin n) (r : Nat) :
    ((succPerm n np)^[r] i).val = (i.val+r)%n := by
  induction r with
  | zero => simp [Nat.mod_eq_of_lt i.isLt]
  | succ r ih =>
    rw [Function.iterate_succ_apply',cycle_succ_formula n np,ih,Nat.mod_add_mod]
    rw [Nat.add_assoc]

theorem cycle_succ_no_small_period (n : Nat) (np : 0<n) (large : 7≤n) (i : Fin n)
    (r : Nat) (rp : 0<r) (rl : r≤6) : (succPerm n np)^[r] i≠i := by
  intro eq
  have q := congrArg Fin.val eq
  rw [cycle_succ_iterate_formula n np i r] at q
  by_cases short : i.val+r<n
  · rw [Nat.mod_eq_of_lt short] at q
    omega
  rw [Nat.mod_eq_sub_mod (by omega : n≤i.val+r),Nat.mod_eq_of_lt (by omega)] at q
  omega

/-- An exterior path supplies a longer cycle whenever the directed index
gap from its first attachment to its last is strictly shorter. -/
theorem exterior_index_arc {a : V} (c : G.Walk a a) (hc : c.IsCycle)
    (i : Fin c.length) (g : Nat) (gp : 0<g) (gl : g<c.length)
    (r : G.Walk (c.getVert i.val) (c.getVert ((i.val+g)%c.length))) (rp : r.IsPath)
    (ext : ∀ z∈r.support,z∈c.support →
      z=c.getVert i.val ∨ z=c.getVert ((i.val+g)%c.length))
    (gain : g<r.length) :
    ∃ a', ∃ d : G.Walk a' a',d.IsCycle ∧ c.length<d.length := by
  let d := c.rotate (c.getVert_mem_support i.val)
  have H := rotated_cycle_support_length c hc (c.getVert_mem_support i.val)
  have len : d.length=c.length := H.1
  have hd : d.IsCycle := hc.rotate _
  have y := rotate_getVert_mod c hc i.val g i.isLt gl
  change d.getVert g=c.getVert ((i.val+g)%c.length) at y
  let q := r.copy rfl y.symm
  have qp : q.IsPath := by simpa [q] using rp
  have no : c.getVert i.val≠d.getVert g := by
    intro e
    have h := (hd.getVert_endpoint_iff (by omega : g≤d.length)).mp e.symm
    omega
  obtain ⟨D,DD,DL⟩ := replace_directed_arc d hd (d.getVert_mem_support g) no q qp
    (by
      intro z zq zd
      have rz : z∈r.support := by simpa [q] using zq
      exact (ext z rz ((H.2 z).mp zd)).elim Or.inl (fun e => Or.inr (e.trans y.symm)))
    (by
      rw [prefix_arc_length d hd g gp (by omega)]
      simpa [q] using gain)
  exact ⟨_,D,DD,by omega⟩

#print axioms rotate_getVert_mod
#print axioms cycle_succ_no_small_period
#print axioms exterior_index_arc
end Graffiti189LongestPath.CycleIndex
