import CycleIndex189
import TwoArcSplice189
open SimpleGraph SimpleGraph.Walk
open Graffiti189LongestPath.CycleIndex Graffiti189LongestPath.CycleRootBridge
open Graffiti189LongestPath.TwoArcSplice
set_option warningAsError true
set_option maxHeartbeats 3500000
namespace Graffiti189LongestPath.CycleTwoCuts
variable {V : Type*} [DecidableEq V] {G : SimpleGraph V}

theorem after_takeUntil_index {u v : V} (q : G.Walk u v) (i : Nat)
    (hi : i≤q.length) (qp : q.IsPath) :
    (q.takeUntil (q.getVert i) (q.getVert_mem_support i)).length=i := by
  let r := q.takeUntil (q.getVert i) (q.getVert_mem_support i)
  have rl : r.length≤q.length := length_takeUntil_le _ _
  have h := getVert_takeUntil (q.getVert_mem_support i) (by rfl : r.length≤r.length)
  have h' := (getVert_length r).symm.trans h
  exact (qp.getVert_injOn rl hi h'.symm)

theorem dropUntil_getVert_from_prefix {u v w : V} (q : G.Walk u v)
    (h : w∈q.support) (i : Nat) :
    (q.dropUntil w h).getVert i=q.getVert ((q.takeUntil w h).length+i) := by
  let P := q.takeUntil w h
  let D := q.dropUntil w h
  change D.getVert i=q.getVert (P.length+i)
  calc
    D.getVert i = (P.append D).getVert (P.length+i) := by
      rw [getVert_append,if_neg (by omega),show P.length+i-P.length=i by omega]
    _ = q.getVert (P.length+i) := congrArg (fun W : G.Walk u v => W.getVert (P.length+i)) (take_spec q h)

theorem directed_gap {n : Nat} (np : 0<n) (i j : Fin n)
    (ne : i≠j) (skips : succPerm n np j≠i) :
    ∃ g : Nat, 0<g ∧ g+1<n ∧ (i.val+g)%n=j.val := by
  have iv := i.isLt
  have jv := j.isLt
  have neg : i.val≠j.val := fun e => ne (Fin.ext e)
  have part : ∃ g : Nat,0<g ∧ g<n ∧ (i.val+g)%n=j.val := by
    by_cases e : i.val<j.val
    · refine ⟨j.val-i.val,by omega,by omega,?_⟩
      rw [show i.val+(j.val-i.val)=j.val by omega,Nat.mod_eq_of_lt jv]
    · refine ⟨n-i.val+j.val,by omega,by omega,?_⟩
      rw [show i.val+(n-i.val+j.val)=j.val+n by omega]
      simp [Nat.mod_eq_of_lt jv]
  obtain ⟨g,gp,gl,ge⟩ := part
  refine ⟨g,gp,?_ ,ge⟩
  apply Nat.lt_of_not_ge
  intro v
  have eq : g+1=n := by omega
  apply skips
  apply Fin.ext
  rw [cycle_succ_formula]
  calc
    (j.val+1)%n = (((i.val+g)%n)+1)%n := by rw [ge]
    _ = (i.val+g+1)%n := by rw [Nat.mod_add_mod]
    _ = (i.val+n)%n := by rw [Nat.add_assoc,eq]
    _ = i.val := by simp [Nat.mod_eq_of_lt iv]

/-- Two directed edges in a simple cycle, not sharing their cyclic
join, leave two vertex-disjoint paths with the expected endpoint map. -/
theorem extract_two_arcs {a : V} (c : G.Walk a a) (hc : c.IsCycle)
    (i j : Fin c.length) (np : 0<c.length)
    (ne : i≠j) (skips : succPerm c.length np j≠i) :
    ∃ (P : G.Walk (c.getVert ((i.val+1)%c.length)) (c.getVert j.val))
      (Q : G.Walk (c.getVert ((j.val+1)%c.length)) (c.getVert i.val)),
      P.IsPath ∧ Q.IsPath ∧ List.Disjoint P.support Q.support ∧
      (∀ z∈P.support,z∈c.support) ∧ (∀ z∈Q.support,z∈c.support) ∧
      P.length+Q.length+2=c.length := by
  obtain ⟨g,gp,gl,ge⟩ := directed_gap np i j ne skips
  let d := c.rotate (c.getVert_mem_support i.val)
  have hd : d.IsCycle := hc.rotate _
  obtain ⟨dl,ds⟩ := rotated_cycle_support_length c hc (c.getVert_mem_support i.val)
  change d.length=c.length at dl
  have dnil := hd.not_nil
  let T := d.tail
  have TL : T.length+1=d.length := length_tail_add_one dnil
  have TS : T.support=d.support.tail := support_tail d dnil
  have TP : T.IsPath := by
    rw [isPath_def,TS]
    exact hd.support_nodup
  have one : d.getVert 1=c.getVert ((i.val+1)%c.length) :=
    rotate_getVert_mod c hc i.val 1 i.isLt (by omega)
  have two : d.getVert g=c.getVert j.val := by
    have e := rotate_getVert_mod c hc i.val g i.isLt (by omega)
    simpa only [ge] using e
  have jt : c.getVert j.val∈T.support := by
    have x := T.getVert_mem_support (g-1)
    rw [show T.getVert (g-1)=d.getVert g by
      change d.tail.getVert (g-1)=_
      rw [getVert_tail,show g-1+1=g by omega],two] at x
    exact x
  let P := T.takeUntil (c.getVert j.val) jt
  let S := T.dropUntil (c.getVert j.val) jt
  have app : P.append S=T := take_spec T jt
  have PP : P.IsPath := TP.takeUntil jt
  have SP : S.IsPath := TP.dropUntil jt
  have pl : P.length=g-1 := by
    have eq : T.getVert (g-1)=c.getVert j.val := by
      change d.tail.getVert (g-1)=_
      rw [getVert_tail,show g-1+1=g by omega,two]
    have ww (m : V) (h : m∈T.support) (eq : m=T.getVert (g-1)) :
        (T.takeUntil m h).length=g-1 := by
      subst m
      exact after_takeUntil_index T (g-1) (by omega) TP
    exact ww _ jt eq.symm
  have sl : 0<S.length := by
    have eq := congrArg Walk.length app
    rw [length_append] at eq
    omega
  have sn : ¬S.Nil := not_nil_iff_lt_length.mpr sl
  let Q := S.tail
  have ql : Q.length+1=S.length := length_tail_add_one sn
  have qt : Q.support=S.support.tail := support_tail_of_not_nil S sn
  have QP : Q.IsPath := by
    rw [isPath_def,qt]
    exact SP.support_nodup.tail
  have qq : S.getVert 1=c.getVert ((j.val+1)%c.length) := by
    change (T.dropUntil (c.getVert j.val) jt).getVert 1=_
    rw [dropUntil_getVert_from_prefix]
    change T.getVert (P.length+1)=_
    rw [pl,show g-1+1=g by omega]
    change d.tail.getVert g=_
    rw [getVert_tail]
    have e := rotate_getVert_mod c hc i.val (g+1) i.isLt gl
    change d.getVert (g+1)=_ at e
    rw [e,Nat.add_assoc i.val g 1 |> Eq.symm,←Nat.mod_add_mod,ge]
  have diff : List.Disjoint P.support Q.support := by
    rw [qt]
    have h := TP.support_nodup
    rw [←app,support_append] at h
    exact (List.nodup_append.mp h).2.2
  have Ps : ∀ u∈P.support,u∈c.support := fun u h =>
    (ds u).mp (List.mem_of_mem_tail (TS ▸ support_takeUntil_subset T jt h))
  have Qs : ∀ u∈Q.support,u∈c.support := by
    intro u h
    rw [qt] at h
    exact (ds u).mp (List.mem_of_mem_tail (TS ▸
      support_dropUntil_subset T jt (List.mem_of_mem_tail h)))
  refine ⟨P.copy one rfl,Q.copy qq rfl,?_,?_,?_,?_,?_,?_⟩
  · simpa using PP
  · simpa using QP
  · simpa using diff
  · simpa using Ps
  · simpa using Qs
  · simp only [length_copy]
    have eq := congrArg Walk.length app
    rw [length_append] at eq
    omega

/-- Reconnect the two ends of a pair of parallel directed cuts through
one new vertex on one side and an exterior bridge on the other. -/
theorem extend_two_cuts {a x : V} (c : G.Walk a a) (hc : c.IsCycle)
    (i j : Fin c.length) (np : 0<c.length)
    (ne : i≠j) (skips : succPerm c.length np j≠i)
    (r : G.Walk (c.getVert ((j.val+1)%c.length)) (c.getVert ((i.val+1)%c.length)))
    (rp : r.IsPath) (rl : 0<r.length)
    (rOnly : ∀ v∈r.support,v∈c.support →
      v=c.getVert ((j.val+1)%c.length) ∨ v=c.getVert ((i.val+1)%c.length))
    (xo : x∉c.support) (xr : x∉r.support)
    (xi : G.Adj x (c.getVert i.val)) (xj : G.Adj x (c.getVert j.val)) :
    ∃ d : G.Walk x x,d.IsCycle ∧ c.length<d.length := by
  obtain ⟨P,Q,pp,qp,pq,ps,qs,len⟩ := extract_two_arcs c hc i j np ne skips
  have left : ∀ v∈r.support,v∈Q.support → v=c.getVert ((j.val+1)%c.length) := by
    intro v vr vq
    rcases rOnly v vr (qs v vq) with h|h
    · exact h
    · exact (pq (h.symm ▸ P.start_mem_support) vq).elim
  have right : ∀ v∈r.support,v∈P.support → v=c.getVert ((i.val+1)%c.length) := by
    intro v vr vp
    rcases rOnly v vr (ps v vp) with h|h
    · exact (pq vp (h.symm ▸ Q.start_mem_support)).elim
    · exact h
  obtain ⟨d,dp,dl⟩ := two_arc_splice P Q r pp qp rp pq left right
    (fun h => xo (ps x h)) (fun h => xo (qs x h)) xr xi xj
  exact ⟨d,dp,by omega⟩

#print axioms extract_two_arcs
#print axioms extend_two_cuts
end Graffiti189LongestPath.CycleTwoCuts
