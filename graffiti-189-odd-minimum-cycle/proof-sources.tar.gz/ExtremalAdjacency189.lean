import CycleIndex189
import CyclicSparse189
open Finset SimpleGraph SimpleGraph.Walk
open Graffiti189LongestPath.CycleIndex Graffiti189LongestPath.CyclicSparse
set_option warningAsError true
set_option maxHeartbeats 3500000
namespace Graffiti189LongestPath.ExtremalAdjacency
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

omit [Fintype V] [DecidableRel G.Adj] in
/-- Maximal cycles do not admit any bridge of order three over a
one-edge directed arc. -/
theorem no_consecutive_attachment {a x : V} (c : G.Walk a a) (hc : c.IsCycle)
    (maximal : ∀ b (d : G.Walk b b),d.IsCycle → d.length≤c.length)
    (xo : x∉c.support) (i : Fin c.length)
    (ix : G.Adj x (c.getVert i.val)) :
    ¬G.Adj x (c.getVert ((i.val+1)%c.length)) := by
  intro xj
  have big := hc.three_le_length
  have h : (i.val+1)%c.length<c.length := Nat.mod_lt _ (by omega)
  have ne : c.getVert i.val≠c.getVert ((i.val+1)%c.length) := by
    intro e
    have eq : i=(⟨(i.val+1)%c.length,h⟩:Fin c.length) :=
      cycle_index_injective c hc e
    have q := congrArg Fin.val eq
    change i.val=((i.val+1)%c.length) at q
    by_cases m : i.val+1<c.length
    · rw [Nat.mod_eq_of_lt m] at q; omega
    rw [Nat.mod_eq_sub_mod (by omega : c.length≤i.val+1),Nat.mod_eq_of_lt (by omega)] at q
    omega
  let r := Walk.cons ix.symm (Walk.cons xj Walk.nil)
  have rp : r.IsPath := by
    apply (cons_isPath_iff _ _).2
    constructor
    · exact (cons_isPath_iff _ _).2 ⟨by simp,by simpa using xj.ne⟩
    · simp [ne,ix.ne.symm]
  obtain ⟨b,d,dp,dl⟩ := exterior_index_arc c hc i 1 (by omega) (by omega) r rp
    (by
      intro z zr zc
      simp only [r,support_cons,support_nil,List.mem_cons,List.not_mem_nil,or_false] at zr
      rcases zr with h|r|h
      · exact Or.inl h
      · exact (xo (r ▸ zc)).elim
      · exact Or.inr h)
    (by simp [r])
  exact (not_lt_of_ge (maximal b d dp)) dl

omit [Fintype V] [DecidableRel G.Adj] in
/-- Adjacent omitted vertices may not join two indexed cycle positions
at directed cyclic distance one or two. -/
theorem no_short_cross {a x y : V} (c : G.Walk a a) (hc : c.IsCycle)
    (maximal : ∀ b (d : G.Walk b b),d.IsCycle → d.length≤c.length)
    (xo : x∉c.support) (yo : y∉c.support) (xy : G.Adj x y)
    (i : Fin c.length) (g : Nat) (gp : 0<g) (gt : g≤2)
    (ix : G.Adj x (c.getVert i.val)) :
    ¬G.Adj y (c.getVert ((i.val+g)%c.length)) := by
  intro yj
  have big := hc.three_le_length
  have h : (i.val+g)%c.length<c.length := Nat.mod_lt _ (by omega)
  have ne : c.getVert i.val≠c.getVert ((i.val+g)%c.length) := by
    intro e
    have eq : i=(⟨(i.val+g)%c.length,h⟩:Fin c.length) :=
      cycle_index_injective c hc e
    have q := congrArg Fin.val eq
    change i.val=((i.val+g)%c.length) at q
    by_cases m : i.val+g<c.length
    · rw [Nat.mod_eq_of_lt m] at q; omega
    rw [Nat.mod_eq_sub_mod (by omega : c.length≤i.val+g),Nat.mod_eq_of_lt (by omega)] at q
    omega
  have yi : y≠c.getVert i.val := fun e => yo (e.symm ▸ c.getVert_mem_support _)
  have xj : x≠c.getVert ((i.val+g)%c.length) := fun e => xo (e.symm ▸ c.getVert_mem_support _)
  let r := Walk.cons ix.symm (Walk.cons xy (Walk.cons yj Walk.nil))
  have rp : r.IsPath := by
    apply (cons_isPath_iff _ _).2
    constructor
    · apply (cons_isPath_iff _ _).2
      exact ⟨(cons_isPath_iff _ _).2 ⟨by simp,by simpa using yj.ne⟩,by
        simp [xy.ne,xj]⟩
    · simp [ix.ne.symm,yi.symm,ne]
  obtain ⟨b,d,dp,dl⟩ := exterior_index_arc c hc i g gp (by omega) r rp
    (by
      intro z zr zc
      simp only [r,support_cons,support_nil,List.mem_cons,List.not_mem_nil,or_false] at zr
      rcases zr with h|h|h|h
      · exact Or.inl h
      · exact (xo (h ▸ zc)).elim
      · exact (yo (h ▸ zc)).elim
      · exact Or.inr h)
    (by simp [r]; omega)
  exact (not_lt_of_ge (maximal b d dp)) dl

/-- In an exact extremal even cycle with only two omitted vertices, they
cannot be adjacent when one has the Dirac minimum and the other degree≥3. -/
theorem extremal_omitted_nonadjacent {a x y : V} (c : G.Walk a a) (hc : c.IsCycle)
    (p : Nat) (p4 : 4≤p) (len : c.length=2*p)
    (maximal : ∀ b (d : G.Walk b b),d.IsCycle → d.length≤c.length)
    (xo : x∉c.support) (yo : y∉c.support)
    (covers : ∀ z,z∈c.support ∨ z=x ∨ z=y)
    (xd : p≤G.degree x) (yd : 3≤G.degree y) : ¬G.Adj x y := by
  classical
  intro ed
  have lp : 0<c.length := by omega
  let s := succPerm c.length lp
  let idx : Fin c.length ↪ V :=
    ⟨fun i => c.getVert i.val,cycle_index_injective c hc⟩
  let att (z : V) := (univ : Finset (Fin c.length)).filter (fun i => G.Adj z (idx i))
  have ind (z : V) (zc : z∈c.support) : ∃ i : Fin c.length,idx i=z := by
    obtain ⟨i,eq,hi⟩ := mem_support_iff_exists_getVert.mp zc
    by_cases eqi : i=c.length
    · have e : z=a := by rw [eqi,getVert_length] at eq; exact eq.symm
      refine ⟨⟨0,lp⟩,?_⟩
      exact (c.getVert_zero).trans e.symm
    exact ⟨⟨i,by omega⟩,eq⟩
  have bnd {u v : V} (cover : ∀ z,z∈c.support ∨ z=u ∨ z=v) :
      G.degree u≤(att u).card+1 := by
    have sub : G.neighborFinset u⊆insert v ((att u).map idx) := by
      intro z hz
      have h := (G.mem_neighborFinset _ _).mp hz
      rcases cover z with c'|u'|v'
      · obtain ⟨i,hi⟩ := ind z c'
        exact mem_insert.mpr (Or.inr (mem_map.mpr
          ⟨i,mem_filter.mpr ⟨mem_univ _,hi.symm ▸ h⟩,hi⟩))
      · exact (h.ne u'.symm).elim
      exact mem_insert.mpr (Or.inl v')
    have hh := (card_le_card sub).trans (card_insert_le _ _)
    rw [G.card_neighborFinset_eq_degree,card_map] at hh
    exact hh
  have xB := bnd (u:=x) (v:=y) covers
  have yB := bnd (u:=y) (v:=x) (fun z => (covers z).imp id (fun h => h.elim Or.inr Or.inl))
  obtain ⟨X,XX,Xc⟩ := exists_subset_card_eq (by omega : p-1≤(att x).card)
  let Y := att y
  have XI (i : Fin c.length) (hi : i∈X) : G.Adj x (c.getVert i.val) :=
    (mem_filter.mp (XX hi)).2
  have YI (i : Fin c.length) (hi : i∈Y) : G.Adj y (c.getVert i.val) :=
    (mem_filter.mp hi).2
  have dis : Disjoint X (X.image s) := disjoint_left.mpr (by
    intro j hx hj
    obtain ⟨i,hi,rfl⟩ := mem_image.mp hj
    have h := no_consecutive_attachment c hc maximal xo i (XI i hi)
    exact h (by simpa only [s,cycle_succ_formula] using XI (s i) hx))
  have far (i : Fin c.length) (hi : i∈X) (j : Fin c.length) (hj : j∈Y) (_ : i≠j) :
      s i≠j ∧ s (s i)≠j ∧ s j≠i ∧ s (s j)≠i := by
    have cross (u v : V) (U : u∉c.support) (V : v∉c.support) (e : G.Adj u v)
        (i j : Fin c.length) (g : Nat) (gp : 0<g) (gt : g≤2)
        (ie : G.Adj u (c.getVert i.val)) (je : G.Adj v (c.getVert j.val)) :
        (s^[g]) i≠j := by
      intro eq
      have E := congrArg Fin.val eq
      change ((succPerm c.length lp)^[g] i).val=j.val at E
      rw [cycle_succ_iterate_formula] at E
      exact no_short_cross c hc maximal U V e i g gp gt ie (E.symm ▸ je)
    refine ⟨?_,?_,?_,?_⟩
    · exact cross x y xo yo ed i j 1 (by omega) (by omega) (XI i hi) (YI j hj)
    · exact cross x y xo yo ed i j 2 (by omega) (by omega) (XI i hi) (YI j hj)
    · exact cross y x yo xo ed.symm j i 1 (by omega) (by omega) (YI j hj) (XI i hi)
    · exact cross y x yo xo ed.symm j i 2 (by omega) (by omega) (YI j hj) (XI i hi)
  have ord : Fintype.card (Fin c.length)=2*p := by simpa using len
  have one := sparse_cross_card_le_one s p p4 ord
    (cycle_succ_no_small_period c.length lp (by omega)) X Y Xc dis far
  change Y.card≤1 at one
  change G.degree y≤Y.card+1 at yB
  omega

#print axioms no_consecutive_attachment
#print axioms no_short_cross
#print axioms extremal_omitted_nonadjacent
end Graffiti189LongestPath.ExtremalAdjacency
