import ExtremalAdjacency189
import CycleTwoCuts189
open Finset SimpleGraph SimpleGraph.Walk
open Graffiti189LongestPath.CycleIndex Graffiti189LongestPath.ExtremalAdjacency
open Graffiti189LongestPath.CycleTwoCuts
set_option warningAsError true
set_option maxHeartbeats 5500000
namespace Graffiti189LongestPath.ExtremalBipartition
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

omit [Fintype V] [DecidableEq V] [DecidableRel G.Adj] in
theorem cyclic_adj {a : V} (c : G.Walk a a) (i : Fin c.length) :
    G.Adj (c.getVert i.val) (c.getVert ((i.val+1)%c.length)) := by
  have e := c.adj_getVert_succ i.isLt
  by_cases h : i.val+1<c.length
  · rwa [Nat.mod_eq_of_lt h]
  have k : i.val+1=c.length := by omega
  rw [k,getVert_length] at e
  rwa [k,Nat.mod_self,getVert_zero]

/-- An omitted high vertex fixes the alternating bipartition of an exact
extremal cycle. The other class has no chords, and the second omitted
vertex has at most one neighbor in that class. -/
theorem extremal_bipartition {a x y : V} (c : G.Walk a a) (hc : c.IsCycle)
    (p : Nat) (p4 : 4≤p) (len : c.length=2*p)
    (maximal : ∀ b (d : G.Walk b b),d.IsCycle → d.length≤c.length)
    (xo : x∉c.support) (yo : y∉c.support)
    (covers : ∀ z,z∈c.support ∨ z=x ∨ z=y)
    (xd : p≤G.degree x) (yd : 3≤G.degree y) :
    ∃ X Y : Finset V, X∪Y=c.support.toFinset ∧ Disjoint X Y ∧ X.card=p ∧ Y.card=p ∧
      (∀ z∈X,G.Adj x z) ∧ (∀ z∈Y,¬G.Adj x z) ∧
      (∀ u∈Y,∀ v∈Y,¬G.Adj u v) ∧
      (∀ u∈Y,∀ v∈Y,G.Adj y u → G.Adj y v → u=v) ∧
      (∀ z∈Y,G.Adj y z → 2≤(X.filter (fun v => ¬G.Adj y v)).card) := by
  classical
  have xy := extremal_omitted_nonadjacent c hc p p4 len maximal xo yo covers xd yd
  have np : 0<c.length := by omega
  let s := succPerm c.length np
  let f : Fin c.length ↪ V :=
    ⟨fun i => c.getVert i.val,cycle_index_injective c hc⟩
  let A := (univ : Finset (Fin c.length)).filter (fun i => G.Adj x (f i))
  let B := univ\A
  let X := A.map f
  let Y := B.map f
  have C : (univ.map f)=c.support.toFinset := by
    ext z
    constructor
    · intro h
      obtain ⟨i,_,rfl⟩ := mem_map.mp h
      exact List.mem_toFinset.mpr (c.getVert_mem_support i.val)
    · intro h
      obtain ⟨i,eq,hi⟩ := mem_support_iff_exists_getVert.mp (List.mem_toFinset.mp h)
      by_cases e : i=c.length
      · rw [e,getVert_length] at eq
        exact mem_map.mpr ⟨⟨0,np⟩,mem_univ _,(c.getVert_zero).trans eq⟩
      · exact mem_map.mpr ⟨⟨i,by omega⟩,mem_univ _,eq⟩
  have xc : ∀ z∈X,z∈c.support := by
    intro z h
    apply List.mem_toFinset.mp
    rw [←C]
    exact map_subset_map.mpr (subset_univ A) h
  have yc : ∀ z∈Y,z∈c.support := by
    intro z h
    apply List.mem_toFinset.mp
    rw [←C]
    exact map_subset_map.mpr (subset_univ B) h
  have union : X∪Y=c.support.toFinset := by
    rw [←C,←map_union,union_sdiff_of_subset (subset_univ A)]
  have dis : Disjoint X Y := by
    apply disjoint_left.mpr
    intro z h k
    obtain ⟨i,hi,eqi⟩ := mem_map.mp h
    obtain ⟨j,hj,eqj⟩ := mem_map.mp k
    exact (mem_sdiff.mp hj).2 (f.injective (eqi.trans eqj.symm) ▸ hi)
  have aAdj (i : Fin c.length) (hi : i∈A) : G.Adj x (f i) := (mem_filter.mp hi).2
  have bNo (i : Fin c.length) (hi : i∈B) : ¬G.Adj x (f i) := fun e =>
    (mem_sdiff.mp hi).2 (mem_filter.mpr ⟨mem_univ _,e⟩)
  have xAdj : ∀ z∈X,G.Adj x z := by
    intro z h
    obtain ⟨i,hi,rfl⟩ := mem_map.mp h
    exact aAdj i hi
  have xNo : ∀ z∈Y,¬G.Adj x z := by
    intro z h
    obtain ⟨i,hi,rfl⟩ := mem_map.mp h
    exact bNo i hi
  have succA (i : Fin c.length) (hi : i∈A) : s i∈B := by
    apply mem_sdiff.mpr
    refine ⟨mem_univ _,?_⟩
    intro bad
    have no := no_consecutive_attachment c hc maximal xo i (aAdj i hi)
    have e := aAdj (s i) bad
    change G.Adj x (c.getVert (s i).val) at e
    rw [cycle_succ_formula] at e
    exact no e
  have Sb : A.image s⊆B := by
    intro i h
    obtain ⟨j,hj,rfl⟩ := mem_image.mp h
    exact succA j hj
  have aB := card_le_card Sb
  rw [card_image_of_injective _ s.injective] at aB
  have totals := card_sdiff_add_card_eq_card (subset_univ A)
  change B.card+A.card=(univ : Finset (Fin c.length)).card at totals
  rw [card_univ,Fintype.card_fin] at totals
  have total := totals.trans len
  have cover : G.neighborFinset x⊆X := by
    intro z h
    have edge := (G.mem_neighborFinset _ _).mp h
    rcases covers z with a'|b'|c'
    · have nz : z∈c.support.toFinset := List.mem_toFinset.mpr a'
      rw [←C] at nz
      obtain ⟨i,_,rfl⟩ := mem_map.mp nz
      exact mem_map.mpr ⟨i,mem_filter.mpr ⟨mem_univ _,edge⟩,rfl⟩
    · exact (edge.ne b'.symm).elim
    · exact (xy (c' ▸ edge)).elim
  have small := card_le_card cover
  rw [G.card_neighborFinset_eq_degree,card_map] at small
  have asize : A.card=p := by omega
  have bsize : B.card=p := by omega
  have exactB : A.image s=B := eq_of_subset_of_card_le Sb (by
    rw [card_image_of_injective _ s.injective,asize,bsize])
  have predB (i : Fin c.length) (hi : i∈B) : ∃ j∈A,s j=i := by
    exact mem_image.mp (exactB.symm ▸ hi)
  have succB (i : Fin c.length) (hi : i∈B) : s i∈A := by
    apply Classical.byContradiction
    intro ni
    obtain ⟨j,jA,e⟩ := predB (s i) (mem_sdiff.mpr ⟨mem_univ _,ni⟩)
    exact (mem_sdiff.mp hi).2 (s.injective e ▸ jA)
  have bridged {u v : V} (uy : u∈Y) (vy : v∈Y) (uv : u≠v)
      (r : G.Walk v u) (rp : r.IsPath) (rl : 0<r.length)
      (only : ∀ w∈r.support,w∈c.support → w=v ∨ w=u) (ro : x∉r.support) : False := by
    obtain ⟨iu,hu,eu⟩ := mem_map.mp uy
    obtain ⟨iv,hv,ev⟩ := mem_map.mp vy
    obtain ⟨i,hi,ei⟩ := predB iu hu
    obtain ⟨j,hj,ej⟩ := predB iv hv
    have e1 : c.getVert ((i.val+1)%c.length)=u := by
      calc
        _=f (s i) := (congrArg c.getVert (cycle_succ_formula c.length np i)).symm
        _=u := by rw [ei,eu]
    have e2 : c.getVert ((j.val+1)%c.length)=v := by
      calc
        _=f (s j) := (congrArg c.getVert (cycle_succ_formula c.length np j)).symm
        _=v := by rw [ej,ev]
    have ne : i≠j := by
      intro eq
      apply uv
      rw [eq] at e1
      exact e1.symm.trans e2
    have skip : s j≠i := fun h => (mem_sdiff.mp (succA j hj)).2 (h.symm ▸ hi)
    let Q := r.copy e2.symm e1.symm
    have qp : Q.IsPath := by simpa [Q] using rp
    have ql : 0<Q.length := by simpa [Q] using rl
    have qo : x∉Q.support := by simpa [Q] using ro
    have cond : ∀ w∈Q.support,w∈c.support →
        w=c.getVert ((j.val+1)%c.length) ∨ w=c.getVert ((i.val+1)%c.length) := by
      intro w hw wc
      rw [e2,e1]
      exact only w (by simpa [Q] using hw) wc
    obtain ⟨W,WP,WL⟩ := extend_two_cuts c hc i j np ne skip Q qp ql cond xo qo
      (aAdj i hi) (aAdj j hj)
    exact (not_lt_of_ge (maximal x W WP)) WL
  have independent : ∀ u∈Y,∀ v∈Y,¬G.Adj u v := by
    intro u uy v vy ed
    exact bridged uy vy ed.ne ed.symm.toWalk (IsPath.of_adj ed.symm)
      (by simp) (by intro z zr _; simpa using zr)
      (by intro hz; simp only [Adj.toWalk,support_cons,support_nil,List.mem_cons,List.not_mem_nil,or_false] at hz
          exact hz.elim (fun h => xo (h.symm ▸ yc v vy)) (fun h => xo (h.symm ▸ yc u uy)))
  have yOne : ∀ u∈Y,∀ v∈Y,G.Adj y u → G.Adj y v → u=v := by
    intro u uy v vy yu yv
    apply Classical.byContradiction
    intro ne
    let R := Walk.cons yv.symm (Walk.cons yu Walk.nil)
    have ne' : v≠u := fun e => ne e.symm
    have RP : R.IsPath := (cons_isPath_iff _ _).mpr
      ⟨IsPath.of_adj yu,by simp [yv.ne.symm,ne']⟩
    have out : x∉R.support := by
      intro h
      simp only [R,support_cons,support_nil,List.mem_cons,List.not_mem_nil,or_false] at h
      rcases h with e|e|e
      · exact xo (e.symm ▸ yc v vy)
      · exact xNo u uy (e.symm ▸ yu)
      · exact xo (e.symm ▸ yc u uy)
    exact bridged uy vy ne R RP (by simp [R])
      (by
        intro w wr wc
        simp only [R,support_cons,support_nil,List.mem_cons,List.not_mem_nil,or_false] at wr
        rcases wr with e|e|e
        · exact Or.inl e
        · exact (yo (e ▸ wc)).elim
        · exact Or.inr e) out
  have twice : ∀ z∈Y,G.Adj y z → 2≤(X.filter (fun v => ¬G.Adj y v)).card := by
    intro z zy yz
    obtain ⟨j,jb,eq⟩ := mem_map.mp zy
    obtain ⟨i,ia,sij⟩ := predB j jb
    have t : f i≠f (s j) := by
      intro e
      have ff := f.injective e
      have h : (s^[2]) i=i := by rw [show (s^[2]) i=s (s i) from rfl,sij,←ff]
      exact cycle_succ_no_small_period c.length np (by omega) i 2 (by omega) (by omega) h
    have xx : f i∈X := mem_map.mpr ⟨i,ia,rfl⟩
    have xx' : f (s j)∈X := mem_map.mpr ⟨s j,succB j jb,rfl⟩
    have ed : ¬G.Adj y (f i) := by
      intro edge
      have bad := no_consecutive_attachment c hc maximal yo i edge
      have e2 : c.getVert ((i.val+1)%c.length)=z := by
        calc
          _=f (s i) := (congrArg c.getVert (cycle_succ_formula c.length np i)).symm
          _=z := by rw [sij,eq]
      exact bad (e2.symm ▸ yz)
    have ed' : ¬G.Adj y (f (s j)) := by
      intro edge
      have own : G.Adj y (f j) := eq.symm ▸ yz
      have bad := no_consecutive_attachment c hc maximal yo j own
      change G.Adj y (c.getVert (s j).val) at edge
      rw [cycle_succ_formula] at edge
      exact bad edge
    exact one_lt_card.mpr ⟨_,mem_filter.mpr ⟨xx,ed⟩,_,mem_filter.mpr ⟨xx',ed'⟩,t⟩
  exact ⟨X,Y,union,dis,by rw [card_map,asize],by rw [card_map,bsize],
    xAdj,xNo,independent,yOne,twice⟩

#print axioms extremal_bipartition
end Graffiti189LongestPath.ExtremalBipartition
