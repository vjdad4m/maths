import ExtremalBipartition189
import SplitRoutes189
open Finset SimpleGraph SimpleGraph.Walk
open Graffiti189LongestPath.ExtremalAdjacency Graffiti189LongestPath.ExtremalBipartition
open Graffiti189LongestPath.SplitRoutes
open private Graffiti189LongestPath.FanRoutable.path_append_separated from FanLower189
set_option warningAsError true
set_option maxHeartbeats 6000000
namespace Graffiti189LongestPath.ExtremalSplitShape
variable {V : Type*} [DecidableEq V] {G : SimpleGraph V}

/-- An outside vertex joining the exceptional row and one of its cross
neighbors can be inserted in a cycle spanning a balanced bipartite core. -/
theorem balanced_core_extra_cycle (X Y : Finset V) (dis : Disjoint X Y)
    (eq : X.card=Y.card) {r y a b : V}
    (yr : y∈Y) (ax : a∈X) (bx : b∈X) (ab : a≠b)
    (ro : r∉X∪Y) (ry : G.Adj r y) (ra : G.Adj r a)
    (yb : G.Adj y b)
    (full : ∀ u∈Y,∀ v∈X,u≠y → G.Adj u v) :
    ∃ d : G.Walk y y,d.IsCycle ∧ d.length=X.card+Y.card+1 := by
  classical
  let Z := Y.erase y
  have sub : Z⊆Y := erase_subset _ _
  have Zc : Z.card+1=Y.card := card_erase_add_one yr
  obtain ⟨q,qp,qs,ql⟩ := odd_route Z X
    (disjoint_of_subset_left sub dis.symm)
    (fun u hu v hv => full u (sub hu) v hv (mem_erase.mp hu).1)
    (by omega) ax bx ab
  have yo : y∉q.support := by
    intro h
    exact (mem_union.mp (qs _ h)).elim (fun h => (mem_erase.mp h).1 rfl)
      (fun h => disjoint_left.mp dis h yr)
  have rq : r∉q.support := by
    intro h
    rcases mem_union.mp (qs _ h) with h|h
    · exact ro (mem_union.mpr (Or.inr (sub h)))
    · exact ro (mem_union.mpr (Or.inl h))
  let e := Walk.cons yb.symm Walk.nil
  let L := q.append e
  have lp : L.IsPath := Graffiti189LongestPath.FanRoutable.path_append_separated
    qp (IsPath.of_adj yb.symm) (by
      intro z zq ze
      simp only [e,support_cons,support_nil,List.mem_cons,List.not_mem_nil,or_false] at ze
      exact ze.elim id (fun h => (yo (h ▸ zq)).elim))
  have rl : r∉L.support := by
    intro h
    rw [show L=q.append e from rfl,support_append,List.mem_append] at h
    rcases h with h|h
    · exact rq h
    have l := List.mem_of_mem_tail h
    simp only [e,support_cons,support_nil,List.mem_cons,List.not_mem_nil,or_false] at l
    exact l.elim (fun eq => ro (mem_union.mpr (Or.inl (eq.symm ▸ bx))))
      (fun eq => ro (mem_union.mpr (Or.inr (eq.symm ▸ yr))))
  let R := Walk.cons ra L
  have rp : R.IsPath := (cons_isPath_iff _ _).mpr ⟨lp,rl⟩
  have ne : s(y,r)∉R.edges := by
    intro h
    rcases List.mem_cons.mp h with h|h
    · rcases Sym2.eq_iff.mp h with h|h
      · exact ry.ne h.1.symm
      · exact disjoint_left.mp dis (h.1.symm ▸ ax) yr
    · exact rl (L.snd_mem_support_of_mem_edges h)
  refine ⟨Walk.cons ry.symm R,(cons_isCycle_iff _ _).mpr ⟨rp,ne⟩,?_⟩
  simp only [R,L,e,length_cons,length_nil,length_append]
  omega

variable [Fintype V] [DecidableRel G.Adj]

/-- The only exact Dirac-extremal shape with two omitted vertices and
at most one low degree is an unbalanced split, with crossing edges
complete except possibly at one independent-side vertex. -/
theorem exact_cycle_forces_split {a x y : V} (c : G.Walk a a) (hc : c.IsCycle)
    (p : Nat) (p4 : 4≤p) (len : c.length=2*p)
    (maximal : ∀ b (d : G.Walk b b),d.IsCycle → d.length≤c.length)
    (xo : x∉c.support) (yo : y∉c.support) (xyNe : x≠y)
    (covers : ∀ z,z∈c.support ∨ z=x ∨ z=y)
    (xd : p≤G.degree x) (yd : 3≤G.degree y)
    (degree : ∀ u v : V,u≠v → p≤G.degree u ∨ p≤G.degree v) :
    ∃ X L : Finset V, X∪L=univ ∧ Disjoint X L ∧ X.card=p ∧ L.card=p+2 ∧
      (∀ u∈L,∀ v∈L,¬G.Adj u v) ∧
      (∀ u∈L,p≤G.degree u → ∀ v∈X,G.Adj u v) := by
  classical
  have notxy := extremal_omitted_nonadjacent c hc p p4 len maximal xo yo covers xd yd
  obtain ⟨X,Y,part,dis,xc,yc,xAdj,xNo,yNo,yOne,block⟩ :=
    extremal_bipartition c hc p p4 len maximal xo yo covers xd yd
  let L := insert x (insert y Y)
  have Xc : ∀ v∈X,v∈c.support := by
    intro v h
    exact List.mem_toFinset.mp (part ▸ mem_union.mpr (Or.inl h))
  have Yc : ∀ v∈Y,v∈c.support := by
    intro v h
    exact List.mem_toFinset.mp (part ▸ mem_union.mpr (Or.inr h))
  have cover (v : V) : v∈X ∨ v∈Y ∨ v=x ∨ v=y := by
    rcases covers v with h|h
    · have z : v∈X∪Y := part.symm ▸ List.mem_toFinset.mpr h
      exact (mem_union.mp z).elim Or.inl (fun e => Or.inr (Or.inl e))
    · exact Or.inr (Or.inr h)
  have no : ∀ v∈Y,¬G.Adj y v := by
    intro z zz zz'
    let N := X.filter (G.Adj y)
    let A := X.filter (G.Adj z)
    have bnd : G.neighborFinset y⊆insert z N := by
      intro w hw
      have e := (G.mem_neighborFinset _ _).mp hw
      rcases cover w with h|h|h|h
      · exact mem_insert.mpr (Or.inr (mem_filter.mpr ⟨h,e⟩))
      · exact mem_insert.mpr (Or.inl (yOne w h z zz e zz'))
      · exact (notxy ((h ▸ e).symm)).elim
      · exact (e.ne h.symm).elim
    have ns := (card_le_card bnd).trans (card_insert_le _ _)
    rw [G.card_neighborFinset_eq_degree] at ns
    have omitN := block z zz zz'
    have asize := filter_card_add_filter_neg_card_eq_card (s:=X) (G.Adj y)
    change N.card+(X.filter (fun v => ¬G.Adj y v)).card=X.card at asize
    have yd' : ¬p≤G.degree y := by omega
    have allH (v : V) (vne : v≠y) : p≤G.degree v :=
      (degree v y vne).resolve_right yd'
    have zhi := allH z (fun e => yo (e ▸ Yc z zz))
    have bndZ : G.neighborFinset z⊆insert y A := by
      intro w hw
      have e := (G.mem_neighborFinset _ _).mp hw
      rcases cover w with h|h|h|h
      · exact mem_insert.mpr (Or.inr (mem_filter.mpr ⟨h,e⟩))
      · exact (yNo z zz w h e).elim
      · exact (xNo z zz ((h ▸ e).symm)).elim
      · exact mem_insert.mpr (Or.inl h)
    have bz := (card_le_card bndZ).trans (card_insert_le _ _)
    rw [G.card_neighborFinset_eq_degree] at bz
    have full (u : V) (hu : u∈Y) (un : u≠z) : ∀ v∈X,G.Adj u v := by
      have ue : u≠y := fun e => yo (e ▸ Yc u hu)
      have sub : G.neighborFinset u⊆X := by
        intro w hw
        have e := (G.mem_neighborFinset _ _).mp hw
        rcases cover w with h|h|h|h
        · exact h
        · exact (yNo u hu w h e).elim
        · exact (xNo u hu ((h ▸ e).symm)).elim
        · exact (un (yOne u hu z zz (h ▸ e).symm zz')).elim
      have eq : G.neighborFinset u=X := eq_of_subset_of_card_le sub (by
        rw [G.card_neighborFinset_eq_degree,xc]
        exact allH _ ue)
      intro v hv
      exact (G.mem_neighborFinset _ _).mp (eq.symm ▸ hv)
    have nu : 2≤N.card := by omega
    have aa : 1<A.card := by omega
    have hit : (N∩A).Nonempty := by
      by_contra no
      have disj : Disjoint N A := Finset.disjoint_iff_inter_eq_empty.mpr (not_nonempty_iff_eq_empty.mp no)
      have s := card_le_card (union_subset (filter_subset _ _) (filter_subset _ _) : N∪A⊆X)
      rw [card_union_of_disjoint disj] at s
      omega
    obtain ⟨v,hv⟩ := hit
    obtain ⟨vn,va⟩ := mem_inter.mp hv
    obtain ⟨w,ww,ne⟩ := exists_ne_of_one_lt_card aa v
    obtain ⟨vx,yv⟩ := mem_filter.mp vn
    obtain ⟨wx,zw⟩ := mem_filter.mp ww
    have yo' : y∉X∪Y := fun h =>
      yo (List.mem_toFinset.mp (part ▸ h))
    obtain ⟨D,DP,DL⟩ := balanced_core_extra_cycle X Y dis (by omega) zz vx wx ne.symm
      yo' zz' yv zw (fun u hu v hv hn => full u hu hn v hv)
    have d := maximal z D DP
    omega
  have xn : x∉Y := fun h => xo (Yc x h)
  have yn : y∉Y := fun h => yo (Yc y h)
  have xN : x∉X := fun h => xo (Xc x h)
  have yN : y∉X := fun h => yo (Xc y h)
  have union : X∪L=univ := by
    ext z
    constructor
    · exact fun _ => mem_univ _
    · intro _
      rcases cover z with h|h|h|h
      · exact mem_union.mpr (Or.inl h)
      · exact mem_union.mpr (Or.inr (mem_insert.mpr (Or.inr (mem_insert.mpr (Or.inr h)))))
      · exact mem_union.mpr (Or.inr (mem_insert.mpr (Or.inl h)))
      · exact mem_union.mpr (Or.inr (mem_insert.mpr (Or.inr (mem_insert.mpr (Or.inl h)))))
  have DJ : Disjoint X L := disjoint_left.mpr (by
    intro z zx zl
    rcases mem_insert.mp zl with rfl|zl
    · exact xN zx
    rcases mem_insert.mp zl with rfl|zl
    · exact yN zx
    exact disjoint_left.mp dis zx zl)
  have LC : L.card=p+2 := by
    dsimp only [L]
    rw [card_insert_of_not_mem (fun h => (mem_insert.mp h).elim xyNe xn),
      card_insert_of_not_mem yn,yc]
  have casesL (u : V) (ul : u∈L) : u=x ∨ u=y ∨ u∈Y := by
    rcases mem_insert.mp ul with h|h
    · exact Or.inl h
    exact Or.inr (mem_insert.mp h)
  have LI : ∀ u∈L,∀ v∈L,¬G.Adj u v := by
    intro u ul v vl
    rcases casesL u ul with ux|uy|uY
    · subst u
      rcases casesL v vl with vx|vy|vY
      · subst v
        exact G.loopless x
      · subst v
        exact notxy
      · exact xNo v vY
    · subst u
      rcases casesL v vl with vx|vy|vY
      · subst v
        exact fun e => notxy e.symm
      · subst v
        exact G.loopless y
      · exact no v vY
    · rcases casesL v vl with vx|vy|vY
      · subst v
        exact fun e => xNo u uY e.symm
      · subst v
        exact fun e => no u uY e.symm
      · exact yNo u uY v vY
  have attach : ∀ u∈L,p≤G.degree u → ∀ v∈X,G.Adj u v := by
    intro u ul uh
    have bnd : G.neighborFinset u⊆X := by
      intro v hv
      have uva := (G.mem_neighborFinset _ _).mp hv
      have uv : v∈X∪L := union.symm ▸ mem_univ v
      exact (mem_union.mp uv).elim id (fun h => (LI u ul v h uva).elim)
    have eq : G.neighborFinset u=X := eq_of_subset_of_card_le bnd (by
      rw [G.card_neighborFinset_eq_degree,xc]
      exact uh)
    intro v vx
    exact (G.mem_neighborFinset _ _).mp (eq.symm ▸ vx)
  exact ⟨X,L,union,DJ,xc,LC,LI,attach⟩

#print axioms exact_cycle_forces_split
end Graffiti189LongestPath.ExtremalSplitShape
