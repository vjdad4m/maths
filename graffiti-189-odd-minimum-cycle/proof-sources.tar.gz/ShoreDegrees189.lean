import UniversalCharge189
import StarConnectivity189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack
open Graffiti189LongestPath.ExactStarShore Graffiti189LongestPath.UniversalCharge
open private Graffiti189LongestPath.Rigidity.mem_external Graffiti189LongestPath.Rigidity.mem_omittedStar from Rigidity189
open private Graffiti189LongestPath.boundary_card_of_connectivity Graffiti189LongestPath.no_endpoints from SmallSeparator189
set_option warningAsError true
set_option maxHeartbeats 3500000
namespace Graffiti189LongestPath.ShoreDegrees
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

omit [Fintype V] in
/-- The universal root contributes exactly one neighbor to every other
vertex of its shore. -/
theorem universal_root_degree_drop (A : Finset V) (x : V) (xa : x∈A)
    (v : ↥((A.erase x : Finset V) : Set V)) (edge : G.Adj v.val x) :
    (G.induce ((A.erase x : Finset V) : Set V)).degree v+1=
      (G.induce (A : Set V)).degree ⟨v.val,(mem_erase.mp v.property).2⟩ := by
  classical
  let T := A.erase x
  let I := G.induce (A : Set V)
  let J := G.induce (T : Set V)
  let va : ↥(A : Set V) := ⟨v.val,(mem_erase.mp v.property).2⟩
  let N := (I.neighborFinset va).image Subtype.val
  let M := (J.neighborFinset v).image Subtype.val
  have nc : N.card=I.degree va := by
    rw [←I.card_neighborFinset_eq_degree,card_image_of_injective _ Subtype.val_injective]
  have mc : M.card=J.degree v := by
    rw [←J.card_neighborFinset_eq_degree,card_image_of_injective _ Subtype.val_injective]
  have hN (z : V) : z∈N ↔ z∈A ∧ G.Adj v.val z := by
    constructor
    · intro zn
      obtain ⟨s,sm,rfl⟩ := mem_image.mp zn
      exact ⟨s.property,(I.mem_neighborFinset _ _).mp sm⟩
    · rintro ⟨za,ed⟩
      exact mem_image.mpr ⟨⟨z,za⟩,(I.mem_neighborFinset _ _).mpr ed,rfl⟩
  have hM (z : V) : z∈M ↔ z∈T ∧ G.Adj v.val z := by
    constructor
    · intro zn
      obtain ⟨s,sm,rfl⟩ := mem_image.mp zn
      exact ⟨s.property,(J.mem_neighborFinset _ _).mp sm⟩
    · rintro ⟨za,ed⟩
      exact mem_image.mpr ⟨⟨z,za⟩,(J.mem_neighborFinset _ _).mpr ed,rfl⟩
  have eq : N=insert x M := by
    ext z
    rw [hN,mem_insert,hM]
    constructor
    · rintro ⟨za,ze⟩
      by_cases zx : z=x
      · exact Or.inl zx
      · exact Or.inr ⟨mem_erase.mpr ⟨zx,za⟩,ze⟩
    · intro h
      rcases h with rfl|⟨zt,ed⟩
      · exact ⟨xa,edge⟩
      · exact ⟨(mem_erase.mp zt).2,ed⟩
  have nx : x∉M := fun h => (mem_erase.mp ((hM x).mp h).1).1 rfl
  have cs := congrArg Finset.card eq
  rw [nc,card_insert_of_not_mem nx,mc] at cs
  exact cs.symm

/-- Every vertex in the root-deleted exact shore has the low degree
floor h≤2 deg_J(v)+5; any ambient high vertex gains one more internally. -/
theorem separated_root_deleted_degrees (hc : G.Connected) (k : Nat) (hk : 6≤k)
    (cap : ∀ v,(EvenFrom G v).card≤k+3)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → k+2≤G.degree u ∨ k+2≤G.degree v)
    (fail : ¬∃ (u v : V) (q : G.Walk u v),q.IsPath ∧ ∀ z,z∈q.support)
    {a b x y : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
    (hy : y∉p.support) (xy : G.Adj x y)
    (double : (Pins p x).card=2) (sep : PairedPins p x=∅)
    (v : ↥(((OmittedStar p x).erase x : Finset V) : Set V)) :
    (OmittedStar p x).card≤2*(G.induce (((OmittedStar p x).erase x : Finset V) : Set V)).degree v+5 ∧
      (k+2≤G.degree v.val →
       (OmittedStar p x).card≤2*(G.induce (((OmittedStar p x).erase x : Finset V) : Set V)).degree v+3) := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let U := univ\(A∪B)
  let T := A.erase x
  let J := G.induce (T : Set V)
  let I := G.induce (A : Set V)
  have sat : B.card=k := by
    obtain ⟨_,_,alt⟩ := double_porter_saturated_one_slack hc k hp hx double (cap x) conn hy xy
    rcases alt with h|h
    · exact h.2
    · simp [sep] at h
  obtain ⟨i,hi⟩ := card_pos.mp (by omega : 0<(Pins p x).card)
  have large : k≤U.card := opposite_large_of_not_traceable hc k (by omega) cap conn deg
    hp hx (by omega) hi sat fail
  have rA {z : V} (hz : z∈U) : z∉A := fun h => (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inl h))
  have rB {z : V} (hz : z∈U) : z∉B := fun h => (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inr h))
  have ul : ∀ u∈U,∀ v∉U,G.Adj u v → v∈B := by
    intro u hu v hv ed
    have cov : v∈A∪B := Classical.byContradiction (fun h => hv (mem_sdiff.mpr ⟨mem_univ _,h⟩))
    exact (mem_union.mp cov).elim (fun h => (rB hu
      (Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨rA hu,v,h,ed.symm⟩)).elim) id
  have ub : Disjoint U B := disjoint_left.mpr (fun _ h h' => rB h h')
  have au : Disjoint A U := disjoint_left.mpr (fun _ h h' => rA h' h)
  have ab : Disjoint A B := disjoint_left.mpr (fun _ h h' =>
    (Graffiti189LongestPath.Rigidity.mem_external.mp h').1 h)
  have cA : ∀ y∈A,∀ z∉A,G.Adj y z → z∈B := fun _ hy _ hz e =>
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨hz,_,hy,e⟩
  have root : ∀ z∈A,z=x ∨ G.Adj x z := fun _ h =>
    (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp h).2
  have va : v.val∈A := (mem_erase.mp v.property).2
  have vo : v.val∉p.support := (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp va).1
  have vx : G.Adj v.val x := ((root _ va).resolve_left (mem_erase.mp v.property).1).symm
  have xa : x∈A := Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
  have low : k≤G.degree v.val := by
    have av : a≠v.val := fun e => vo (e ▸ p.start_mem_support)
    rw [←G.card_neighborFinset_eq_degree]
    apply Graffiti189LongestPath.boundary_card_of_connectivity k conn (A:={v.val}) (a:=a)
    · exact mem_singleton_self _
    · exact fun h => av (mem_singleton.mp h)
    · exact fun h => (Graffiti189LongestPath.no_endpoints hp vo).1 ((G.mem_neighborFinset _ _).mp h)
    · exact disjoint_left.mpr (fun _ h e => ((G.mem_neighborFinset v.val _).mp e).ne (mem_singleton.mp h).symm)
    · exact fun _ h _ _ e => (G.mem_neighborFinset _ _).mpr ((mem_singleton.mp h) ▸ e)
  let av : ↥(A : Set V) := ⟨v.val,va⟩
  have ineq := universal_shore_charge hc (k+2) k A U B conn sat ab ub au large
    cA ul (fun v => distanceTwo_le_of_even (k+2) v (cap v)) root av
  change A.card+G.degree v.val+_≤2*I.degree av+(k+2)+1 at ineq
  have id := universal_root_degree_drop A x xa v vx
  change J.degree v+1=I.degree av at id
  change A.card≤2*J.degree v+5 ∧ (k+2≤G.degree v.val → A.card≤2*J.degree v+3)
  omega

#print axioms universal_root_degree_drop
#print axioms separated_root_deleted_degrees
end Graffiti189LongestPath.ShoreDegrees
