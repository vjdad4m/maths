import CycleArc189
open SimpleGraph SimpleGraph.Walk
open private Graffiti189LongestPath.FanRoutable.path_append_separated from FanLower189
set_option warningAsError true
set_option maxHeartbeats 2400000
namespace Graffiti189LongestPath.TwoArcSplice
variable {V : Type*} {G : SimpleGraph V}

/-- The two arcs left after removing two parallel cyclic edges can both
be retained: reverse one arc, bridge the two start vertices externally,
and bridge the two end vertices through a fresh vertex. -/
theorem two_arc_splice {u v s t x : V}
    (P : G.Walk v s) (Q : G.Walk t u) (R : G.Walk t v)
    (pp : P.IsPath) (qp : Q.IsPath) (rp : R.IsPath)
    (PQ : List.Disjoint P.support Q.support)
    (RQ : ∀ z∈R.support,z∈Q.support → z=t)
    (RP : ∀ z∈R.support,z∈P.support → z=v)
    (xp : x∉P.support) (xq : x∉Q.support) (xr : x∉R.support)
    (xu : G.Adj x u) (xs : G.Adj x s) :
    ∃ c : G.Walk x x,c.IsCycle ∧ c.length=P.length+Q.length+R.length+2 := by
  let L := Q.reverse.append R
  have lp : L.IsPath := Graffiti189LongestPath.FanRoutable.path_append_separated qp.reverse rp (by
    intro z zq zr
    exact RQ z zr (by simpa only [support_reverse,List.mem_reverse] using zq))
  let M := L.append P
  have mp : M.IsPath := Graffiti189LongestPath.FanRoutable.path_append_separated lp pp (by
    intro z zl zp
    rw [show L=Q.reverse.append R from rfl,support_append,List.mem_append] at zl
    rcases zl with h|h
    · exact (PQ zp (by simpa only [support_reverse,List.mem_reverse] using h)).elim
    · exact RP z (List.mem_of_mem_tail h) zp)
  have xm : x∉M.support := by
    intro h
    rw [show M=L.append P from rfl,support_append,List.mem_append] at h
    rcases h with h|h
    · rw [show L=Q.reverse.append R from rfl,support_append,List.mem_append] at h
      exact h.elim (fun h => xq (by simpa only [support_reverse,List.mem_reverse] using h))
        (fun h => xr (List.mem_of_mem_tail h))
    · exact xp (List.mem_of_mem_tail h)
  let J := Walk.cons xs.symm Walk.nil
  have jp : J.IsPath := IsPath.of_adj xs.symm
  let K := M.append J
  have kp : K.IsPath := Graffiti189LongestPath.FanRoutable.path_append_separated mp jp (by
    intro z zm zj
    simp only [J,support_cons,support_nil,List.mem_cons,List.not_mem_nil,or_false] at zj
    exact zj.elim id (fun eq => (xm (eq ▸ zm)).elim))
  have ne : u≠s := fun e => PQ (e.symm ▸ P.end_mem_support) Q.end_mem_support
  have fresh : s(x,u)∉K.edges := by
    intro h
    rw [show K=M.append J from rfl,edges_append,List.mem_append] at h
    rcases h with m|j
    · exact xm (M.fst_mem_support_of_mem_edges m)
    simp only [J,edges_cons,edges_nil,List.mem_cons,List.not_mem_nil,or_false] at j
    rcases Sym2.eq_iff.mp j with j|j
    · exact xs.ne j.1
    · exact ne j.2
  refine ⟨Walk.cons xu K,(cons_isCycle_iff _ _).mpr ⟨kp,fresh⟩,?_⟩
  simp only [K,M,L,J,length_cons,length_nil,length_append,length_reverse]
  omega

#print axioms two_arc_splice
end Graffiti189LongestPath.TwoArcSplice
