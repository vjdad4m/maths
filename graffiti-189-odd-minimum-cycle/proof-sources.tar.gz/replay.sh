#!/usr/bin/env bash
set -euo pipefail
# Lean and Mathlib 4.19, prior #189 sources' objects on LEAN_PATH.
root=$(cd "$(dirname "$0")" && pwd)
obj=$(mktemp -d)
trap 'rm -rf "$obj"' EXIT
export LEAN_PATH="$obj:${LEAN_PATH:-}"
for m in CycleArc189 CycleIndex189 ExtremalAdjacency189 TwoArcSplice189 CycleTwoCuts189 \
  ExtremalBipartition189 ExtremalSplitShape189 ShoreDegrees189 OddMinimum189 SeparatedDirac189; do
  lean -DwarningAsError=true --root="$root" -o "$obj/$m.olean" "$root/$m.lean"
done
