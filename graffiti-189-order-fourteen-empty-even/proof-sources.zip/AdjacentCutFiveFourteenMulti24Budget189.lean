import AdjacentCutFiveFourteenMulti24Common189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph Shore shore_off shore_closed shore_disjoint from AdjacentCutFiveActual189
open private classSet from AdjacentCutFiveTopProfiles189
open private class_not_mem b_port_sees_a_and_s capacity_three_plus_two_filled from AdjacentCutFiveFourteenMultiCharge189
open private dist_two_positive_even from AdjacentCutFiveFifteenSingletonMixedCore189
open private cannot_fit_four_and_two_more from AdjacentCutFiveSixteenSingletonGeometry189
open private positive_cap from AdjacentCutFiveComponents189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

private theorem core_two_plus_four_pos_impossible
    (even : ∀ w,(EvenFrom G w).card≤6) {q : V} {A : Finset V}
    (two : A.card=2) (Apos : A⊆PositiveEven G q) {s r w u : V}
    (S : s∉A) (R : r∉A) (W : w∉A) (U : u∉A)
    (sr : s≠r) (sw : s≠w) (su : s≠u) (rw' : r≠w) (ru : r≠u) (wu : w≠u)
    (ps : s∈PositiveEven G q) (pr : r∈PositiveEven G q)
    (pw : w∈PositiveEven G q) (pu : u∈PositiveEven G q) : False := by
  classical
  have rNot : r∉insert s A := by simp [R,sr.symm]
  have four : 4≤(insert r (insert s A)).card := by
    rw [card_insert_of_not_mem rNot,card_insert_of_not_mem S,two]
  exact cannot_fit_four_and_two_more even four (insert_subset_iff.mpr ⟨pr,insert_subset_iff.mpr ⟨ps,Apos⟩⟩)
    (by simp [W,sw.symm,rw'.symm]) (by simp [U,su.symm,ru.symm]) wu.symm pw pu

private theorem two_four_common_missed_by_b_impossible_a_pos
    {C D : Cmp G a b} (F : MultiFrame G a b D) (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ z,(EvenFrom G z).card≤6) (CD : C≠D) {s : V} (sc : s∈Shore C) (bs' : G.Adj b s)
    (ea : (classSet D 0).card=2)
    {z c d : V} (zm : z∈classSet D 4) (cm : c∈classSet D 5) (dm : d∈classSet D 5)
    (cd : c≠d) (zc : ¬G.Adj z c) (zd : ¬G.Adj z d)
    (aPos : classSet D 0⊆PositiveEven G z) : False := by
  have zE := F.b_exclusive hc ab zm
  have cE := F.literalC c cm
  have dE := F.literalC d dm
  have cD := (mem_filter.mp cm).1
  have dD := (mem_filter.mp dm).1
  obtain ⟨aPos',sPos⟩ := b_port_sees_a_and_s F hc ab CD sc bs' zm
  have cPos := dist_two_positive_even hc
    (show z≠c from fun e=>zE.2 (e.symm ▸ cE.1)) zc zE.1.symm cE.2
  have dPos := dist_two_positive_even hc
    (show z≠d from fun e=>zE.2 (e.symm ▸ dE.1)) zd zE.1.symm dE.2
  exact core_two_plus_four_pos_impossible even ea aPos
    (fun m=>disjoint_left.mp (shore_disjoint CD) sc (mem_filter.mp m).1)
    (fun m=>(shore_off D).1 (mem_filter.mp m).1)
    (class_not_mem (by decide : (5:Fin 6)≠0) cm)
    (class_not_mem (by decide : (5:Fin 6)≠0) dm)
    (fun e=>(shore_off C).1 (e ▸ sc))
    (fun e=>disjoint_left.mp (shore_disjoint CD) sc (e.symm ▸ cD))
    (fun e=>disjoint_left.mp (shore_disjoint CD) sc (e.symm ▸ dD))
    (fun e=>(shore_off D).1 (e.symm ▸ cD))
    (fun e=>(shore_off D).1 (e.symm ▸ dD)) cd sPos aPos' cPos dPos

private theorem cover_right_filters_at_least_three
    {D : Cmp G a b} (F : MultiFrame G a b D) {y z : V}
    (Y : classSet D 4={y,z}) (eb : (classSet D 1).card=4)
    (little : ((classSet D 1).filter (G.Adj y)).card≤1) :
    3≤((classSet D 1).filter (G.Adj z)).card := by
  classical
  have sub : classSet D 1⊆ ((classSet D 1).filter (G.Adj y))∪((classSet D 1).filter (G.Adj z)) := by
    intro w wm
    obtain ⟨r,rm,rw'⟩ := (F.bCover w wm).2.2
    rcases (show r=y ∨ r=z by simpa [Y] using rm) with rfl|rfl
    · exact mem_union_left _ (mem_filter.mpr ⟨wm,rw'⟩)
    · exact mem_union_right _ (mem_filter.mpr ⟨wm,rw'⟩)
  have h := (card_le_card sub).trans (card_union_le _ _)
  omega

#print axioms two_four_common_missed_by_b_impossible_a_pos
#print axioms cover_right_filters_at_least_three
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
