import AdjacentCutFiveFourteenMulti33One189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph Shore shore_off shore_closed shore_disjoint from AdjacentCutFiveActual189
open private classSet from AdjacentCutFiveTopProfiles189
open private all_a_pos_via_ports all_b_pos_via_ports class_not_mem from AdjacentCutFiveFourteenMultiCharge189
open private cohort_over_cap from AdjacentCutFiveFourteenMultiFrame189
open private dist_two_positive_even from AdjacentCutFiveFifteenSingletonMixedCore189
open private foreign_pos_even from AdjacentCutFiveComponents189
open private degree_at_most_four_from_choices from AdjacentCutFiveFifteenSingletonMixedMap189
open private cannot_fit_four_and_two_more from AdjacentCutFiveSixteenSingletonGeometry189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

private theorem common_a_and_one_b_in_two_four
    {C D : Cmp G a b} (F : MultiFrame G a b D) (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ z,(EvenFrom G z).card≤6) (CD : C≠D) {s : V} (sc : s∈Shore C) (as' : G.Adj a s)
    (ea : (classSet D 0).card=2) (eb : (classSet D 1).card=4)
    {x y z c d : V} (X : classSet D 3={x}) (Y : classSet D 4={y,z}) (K : classSet D 5={c,d}) :
    G.Adj c x ∧ ((G.Adj c y ∧ ¬G.Adj c z) ∨ (G.Adj c z ∧ ¬G.Adj c y)) := by
  classical
  have xm : x∈classSet D 3 := by simp [X]
  have ym : y∈classSet D 4 := by simp [Y]
  have zm : z∈classSet D 4 := by simp [Y]
  have cm : c∈classSet D 5 := by simp [K]
  have cd := (mem_filter.mp cm).1
  have xd := (mem_filter.mp xm).1
  have cP := F.literalC c cm
  have xP := F.a_exclusive hc ab xm
  have choices : ∀ w,G.Adj c w → w=a ∨ w=b ∨ w=x ∨ w=y ∨ w=z ∨ w=d := by
    intro w cw
    rcases shore_closed D _ cd _ cw with q|q|wd
    · exact .inl q
    · exact .inr (.inl q)
    rcases F.exhaust wd with m|m|m|m|m
    · exact (F.common_not_dark_a hc cm m cw).elim
    · exact (F.common_not_dark_b hc cm m cw).elim
    · exact .inr (.inr (.inl (by simpa [X] using m)))
    · have q : w=y ∨ w=z := by simpa [Y] using m
      exact .inr (.inr (.inr (q.imp id Or.inl)))
    · have q : w=c ∨ w=d := by simpa [K] using m
      exact .inr (.inr (.inr (.inr (.inr (q.resolve_left cw.ne.symm)))))
  have cboth (cy : G.Adj c y) (cz : G.Adj c z) : False := by
    have bpos := all_b_pos_via_ports F hc (fun _ m=>F.common_not_dark_b hc cm m)
      (class_not_mem (by decide : (5:Fin 6)≠1) cm) (by
      intro u um
      rcases (show u=y ∨ u=z by simpa [Y] using um) with rfl|rfl
      · exact cy
      · exact cz)
    by_cases cx : G.Adj c x
    · have apos := all_a_pos_via_ports F hc (fun _ m=>F.common_not_dark_a hc cm m)
        (class_not_mem (by decide : (5:Fin 6)≠0) cm) (by
          intro u um
          have e : u=x := by simpa [X] using um
          exact e.symm ▸ cx)
      exact cohort_over_cap F even apos bpos (by omega)
    · have xPos := dist_two_positive_even hc
        (show c≠x from fun e=>xP.2 (e ▸ cP.2)) cx cP.1.symm xP.1
      have sPos := foreign_pos_even hc CD.symm cd sc cP.1 as'
      exact cannot_fit_four_and_two_more even eb.ge bpos
        (fun m=>disjoint_left.mp (shore_disjoint CD) sc (mem_filter.mp m).1)
        (class_not_mem (by decide : (3:Fin 6)≠1) xm)
        (fun e=>disjoint_left.mp (shore_disjoint CD) sc (e ▸ xd)) sPos xPos
  have cx : G.Adj c x := by
    by_contra xx
    by_cases cy : G.Adj c y
    · have zz : ¬G.Adj c z := cboth cy
      have deg : G.degree c≤4 := degree_at_most_four_from_choices (a:=a) (b:=b) (c:=y) (d:=d) (by
        intro w cw
        rcases choices w cw with e|e|e|e|e|e
        · exact .inl e
        · exact .inr (.inl e)
        · exact (xx (e ▸ cw)).elim
        · exact .inr (.inr (.inl e))
        · exact (zz (e ▸ cw)).elim
        · exact .inr (.inr (.inr e)))
      have hd := F.high c cd
      omega
    · have deg : G.degree c≤4 := degree_at_most_four_from_choices (a:=a) (b:=b) (c:=z) (d:=d) (by
        intro w cw
        rcases choices w cw with e|e|e|e|e|e
        · exact .inl e
        · exact .inr (.inl e)
        · exact (xx (e ▸ cw)).elim
        · exact (cy (e ▸ cw)).elim
        · exact .inr (.inr (.inl e))
        · exact .inr (.inr (.inr e)))
      have hd := F.high c cd
      omega
  refine ⟨cx,?_⟩
  by_cases cy : G.Adj c y
  · exact .inl ⟨cy,cboth cy⟩
  by_cases cz : G.Adj c z
  · exact .inr ⟨cz,cy⟩
  have deg : G.degree c≤4 := degree_at_most_four_from_choices (a:=a) (b:=b) (c:=x) (d:=d) (by
    intro w cw
    rcases choices w cw with e|e|e|e|e|e
    · exact .inl e
    · exact .inr (.inl e)
    · exact .inr (.inr (.inl e))
    · exact (cy (e ▸ cw)).elim
    · exact (cz (e ▸ cw)).elim
    · exact .inr (.inr (.inr e)))
  have hd := F.high c cd
  omega

#print axioms common_a_and_one_b_in_two_four

private theorem common_select_b_at_most_one_even_two_four
    {C D : Cmp G a b} (F : MultiFrame G a b D) (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ z,(EvenFrom G z).card≤6) (CD : C≠D) {s : V} (sc : s∈Shore C) (as' : G.Adj a s)
    (ea : (classSet D 0).card=2)
    {x y z c : V} (X : classSet D 3={x}) (cm : c∈classSet D 5) (zm : z∈classSet D 4)
    (cx : G.Adj c x) (cy : G.Adj c y) (cz : ¬G.Adj c z) :
    ((classSet D 1).filter (G.Adj y)).card≤1 := by
  classical
  have cP := F.literalC c cm
  have zP := F.b_exclusive hc ab zm
  have cd := (mem_filter.mp cm).1
  have zd := (mem_filter.mp zm).1
  have aPos := all_a_pos_via_ports F hc (fun _ m=>F.common_not_dark_a hc cm m)
    (class_not_mem (by decide : (5:Fin 6)≠0) cm) (by
      intro w wm
      have q : w=x := by simpa [X] using wm
      exact q.symm ▸ cx)
  have sPos := foreign_pos_even hc CD.symm cd sc cP.1 as'
  have zPos := dist_two_positive_even hc (show c≠z from fun e=>zP.2 (e ▸ cP.1)) cz cP.2.symm zP.1
  have zs : z≠s := fun e=>disjoint_left.mp (shore_disjoint CD) sc (e ▸ zd)
  have sNot : s∉classSet D 0 := fun m=>disjoint_left.mp (shore_disjoint CD) sc (mem_filter.mp m).1
  have zNot := class_not_mem (by decide : (4:Fin 6)≠0) zm
  by_contra many
  obtain ⟨u,um,v,vm,uv⟩ := one_lt_card.mp (show 1<((classSet D 1).filter (G.Adj y)).card by omega)
  obtain ⟨uE,yu⟩ := mem_filter.mp um
  obtain ⟨vE,yv⟩ := mem_filter.mp vm
  have uPos := dist_two_positive_even hc
    (show c≠u from fun e=>class_not_mem (by decide : (5:Fin 6)≠1) cm (e.symm ▸ uE))
    (F.common_not_dark_b hc cm uE) cy yu
  have vPos := dist_two_positive_even hc
    (show c≠v from fun e=>class_not_mem (by decide : (5:Fin 6)≠1) cm (e.symm ▸ vE))
    (F.common_not_dark_b hc cm vE) cy yv
  have no (w : V) (wm : w∈classSet D 1) : w∉insert z (insert s (classSet D 0)) := by
    have wZ : w≠z := fun e=>class_not_mem (by decide : (4:Fin 6)≠1) zm (e ▸ wm)
    have wS : w≠s := fun e=>disjoint_left.mp (shore_disjoint CD) sc (e ▸ (mem_filter.mp wm).1)
    have wA := class_not_mem (by decide : (1:Fin 6)≠0) wm
    simp [wZ,wS,wA]
  have n : z∉insert s (classSet D 0) := by simp [zs,zNot]
  have four : 4≤(insert z (insert s (classSet D 0))).card := by
    rw [card_insert_of_not_mem n,card_insert_of_not_mem sNot,ea]
  exact cannot_fit_four_and_two_more even four (insert_subset_iff.mpr ⟨zPos,insert_subset_iff.mpr ⟨sPos,aPos⟩⟩)
    (no u uE) (no v vE) uv.symm uPos vPos

#print axioms common_select_b_at_most_one_even_two_four
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
