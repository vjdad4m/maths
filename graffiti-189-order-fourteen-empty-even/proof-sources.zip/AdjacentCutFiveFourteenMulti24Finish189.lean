import AdjacentCutFiveFourteenMulti24Graph189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph Shore shore_off shore_closed shore_disjoint from AdjacentCutFiveActual189
open private classSet from AdjacentCutFiveTopProfiles189
open private class_not_mem all_a_pos_via_ports capacity_three_plus_two_filled b_port_sees_a_and_s from AdjacentCutFiveFourteenMultiCharge189
open private common_a_and_one_b_in_two_four common_select_b_at_most_one_even_two_four from AdjacentCutFiveFourteenMulti24Common189
open private core_two_plus_four_pos_impossible two_four_common_missed_by_b_impossible_a_pos cover_right_filters_at_least_three from AdjacentCutFiveFourteenMulti24Budget189
open private a_even_cannot_avoid_b_even_two_four b_even_neighbor_choices_two_four b_port_neighbor_choices_two_four from AdjacentCutFiveFourteenMulti24Graph189
open private dist_two_positive_even b_ports_no_edge_of_four_even_exhausted from AdjacentCutFiveFifteenSingletonMixedCore189
open private disjoint_profile_sets from AdjacentCutFiveSixteenSingletonGeometry189
open private degree_at_most_four_from_choices from AdjacentCutFiveFifteenSingletonMixedMap189
open private positive_cap from AdjacentCutFiveComponents189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

private theorem no_two_four_both_common_select_y
    {C D : Cmp G a b} (F : MultiFrame G a b D) (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ w,(EvenFrom G w).card≤6) (CD : C≠D) {s : V} (sc : s∈Shore C) (bs' : G.Adj b s)
    (ea : (classSet D 0).card=2) (eb : (classSet D 1).card=4)
    {x y z c d : V} (X : classSet D 3={x}) (Y : classSet D 4={y,z}) (K : classSet D 5={c,d})
    (ne : y≠z) (diff : c≠d) (zc : ¬G.Adj z c) (zd : ¬G.Adj z d)
    (little : ((classSet D 1).filter (G.Adj y)).card≤1) : False := by
  classical
  have xm : x∈classSet D 3 := by simp [X]
  have ym : y∈classSet D 4 := by simp [Y]
  have zm : z∈classSet D 4 := by simp [Y]
  have cm : c∈classSet D 5 := by simp [K]
  have dm : d∈classSet D 5 := by simp [K]
  have zd' := (mem_filter.mp zm).1
  have yd := (mem_filter.mp ym).1
  have yP := F.b_exclusive hc ab ym
  have zP := F.b_exclusive hc ab zm
  have coverB {w : V} (wm : w∈classSet D 1) (miss : ¬G.Adj y w) : G.Adj z w := by
    obtain ⟨t,tm,tw⟩ := (F.bCover w wm).2.2
    rcases (show t=y ∨ t=z by simpa [Y] using tm) with rfl|rfl
    · exact (miss tw).elim
    · exact tw
  have choose {w : V} (e : G.Adj y w) := b_port_neighbor_choices_two_four F hc ab X Y K e
  have yHigh := F.high y yd
  by_cases none : ((classSet D 1).filter (G.Adj y)).card=0
  · have miss : ∀ w∈classSet D 1,¬G.Adj y w := by
      intro w wm yw
      have p := card_pos.mpr (show (((classSet D 1).filter (G.Adj y))).Nonempty from ⟨w,mem_filter.mpr ⟨wm,yw⟩⟩)
      omega
    have zAll : ∀ w∈classSet D 1,G.Adj z w := fun w wm=>coverB wm (miss w wm)
    have yz := b_ports_no_edge_of_four_even_exhausted hc ab even CD sc bs' yd yP.1 yP.2 eb
      (fun w m=>(F.bCover w m).2.1) miss zAll
    have low : G.degree y≤4 := degree_at_most_four_from_choices (a:=b) (b:=x) (c:=c) (d:=d) (by
      intro w yw
      rcases choose yw with rfl|rfl|rfl|rfl|rfl|m
      · exact .inl rfl
      · exact .inr (.inl rfl)
      · exact (yz yw).elim
      · exact .inr (.inr (.inl rfl))
      · exact .inr (.inr (.inr rfl))
      · exact (miss _ m yw).elim)
    omega
  obtain ⟨u,one⟩ := card_eq_one.mp (show ((classSet D 1).filter (G.Adj y)).card=1 by omega)
  have uM : u∈(classSet D 1).filter (G.Adj y) := by simp [one]
  obtain ⟨um,yu⟩ := mem_filter.mp uM
  have yMiss {w : V} (wm : w∈classSet D 1) (wu : w≠u) : ¬G.Adj y w := by
    intro e
    have w' : w∈(classSet D 1).filter (G.Adj y) := mem_filter.mpr ⟨wm,e⟩
    exact wu (by simpa [one] using w')
  have zR : ∀ w∈(classSet D 1).erase u,G.Adj z w := fun w wm=>
    coverB (mem_erase.mp wm).2 (yMiss (mem_erase.mp wm).2 (mem_erase.mp wm).1)
  have br : ((classSet D 1).erase u).card=3 := by rw [card_erase_of_mem um,eb]
  have yAR (yx : G.Adj y x) : classSet D 0⊆PositiveEven G y :=
    all_a_pos_via_ports F hc (fun _ m=>F.b_port_no_dark_a hc ym m)
      (class_not_mem (by decide : (4:Fin 6)≠0) ym) (by
      intro w wm
      have e : w=x := by simpa [X] using wm
      exact e.symm ▸ yx)
  have yBR (yz : G.Adj y z) : (classSet D 1).erase u⊆PositiveEven G y := by
    intro w wm
    obtain ⟨wu,wM⟩ := mem_erase.mp wm
    have ne : y≠w := fun e=>class_not_mem (by decide : (4:Fin 6)≠1) ym (e.symm ▸ wM)
    exact dist_two_positive_even hc ne (yMiss wM wu) yz (zR _ wm)
  obtain ⟨ayPos,syPos⟩ := b_port_sees_a_and_s F hc ab CD sc bs' ym
  have apart {w : V} (wm : w∈Shore D) : s≠w :=
    fun e=>disjoint_left.mp (shore_disjoint CD) sc (e.symm ▸ wm)
  have sa : s≠a := fun e=>(shore_off C).1 (e ▸ sc)
  have aNot (i : Fin 6) : a∉classSet D i := fun m=>(shore_off D).1 (mem_filter.mp m).1
  have sNot (i : Fin 6) : s∉classSet D i := fun m=>apart (mem_filter.mp m).1 rfl
  have yx_yz_impossible (yx : G.Adj y x) (yz : G.Adj y z) : False := by
    let A := classSet D 0
    let B := (classSet D 1).erase u
    have dAB : Disjoint A B := by
      apply disjoint_left.mpr
      intro w wm wn
      exact class_not_mem (by decide : (0:Fin 6)≠1) wm (mem_erase.mp wn).2
    have sOff : s∉A∪B := by
      intro m
      exact (mem_union.mp m).elim (sNot 0) (fun h=>sNot 1 (mem_erase.mp h).2)
    have incl : insert s (A∪B)⊆PositiveEven G y := insert_subset_iff.mpr
      ⟨syPos,union_subset (yAR yx) (yBR yz)⟩
    have count := (card_le_card incl).trans (positive_cap y even)
    rw [card_insert_of_not_mem sOff,card_union_of_disjoint dAB,ea,br] at count
    omega
  by_cases yx : G.Adj y x
  · have yz : ¬G.Adj y z := yx_yz_impossible yx
    have zPos := dist_two_positive_even hc ne yz yP.1.symm zP.1
    have uNo : ∀ w∈(classSet D 1).erase u,¬G.Adj u w := by
      intro w wm uw
      obtain ⟨wu,wM⟩ := mem_erase.mp wm
      have wd := (mem_filter.mp wM).1
      have yNe : y≠w := fun e=>class_not_mem (by decide : (4:Fin 6)≠1) ym (e.symm ▸ wM)
      have wPos := dist_two_positive_even hc yNe (yMiss wM wu) yu uw
      exact core_two_plus_four_pos_impossible even ea (yAR yx)
        (sNot 0) (aNot 0) (class_not_mem (by decide : (4:Fin 6)≠0) zm)
        (class_not_mem (by decide : (1:Fin 6)≠0) wM)
        sa (apart zd') (apart wd) (fun e=>(shore_off D).1 (e.symm ▸ zd'))
        (fun e=>(shore_off D).1 (e.symm ▸ wd))
        (fun e=>class_not_mem (by decide : (4:Fin 6)≠1) zm (e.symm ▸ wM)) syPos ayPos zPos wPos
    have sub : G.neighborFinset u⊆classSet D 0∪classSet D 4 := by
      intro w wm
      have uw := (G.mem_neighborFinset u w).mp wm
      rcases b_even_neighbor_choices_two_four F hc um uw with m|m|m
      · exact mem_union_left _ m
      · exact (uNo _ m uw).elim
      · exact mem_union_right _ m
    have bnd := (card_le_card sub).trans (card_union_le _ _)
    have two : (classSet D 4).card=2 := by rw [Y]; simp [ne]
    rw [card_neighborFinset_eq_degree,ea,two] at bnd
    have high := F.high u (mem_filter.mp um).1
    omega
  · have yz : G.Adj y z := by
      by_contra nyz
      have low : G.degree y≤4 := degree_at_most_four_from_choices (a:=b) (b:=c) (c:=d) (d:=u) (by
        intro w yw
        rcases choose yw with rfl|rfl|rfl|rfl|rfl|m
        · exact .inl rfl
        · exact (yx yw).elim
        · exact (nyz yw).elim
        · exact .inr (.inl rfl)
        · exact .inr (.inr (.inl rfl))
        · have q : w∈(classSet D 1).filter (G.Adj y) := mem_filter.mpr ⟨m,yw⟩
          exact .inr (.inr (.inr (by simpa [one] using q))))
      omega
    have uNo : ∀ w∈classSet D 0,¬G.Adj u w := by
      intro w wm uw
      have wd := (mem_filter.mp wm).1
      have wy : y≠w := fun e=>class_not_mem (by decide : (4:Fin 6)≠0) ym (e.symm ▸ wm)
      have wPos := dist_two_positive_even hc wy (F.b_port_no_dark_a hc ym wm) yu uw
      exact capacity_three_plus_two_filled even br (yBR yz)
        (fun h=>sNot 1 (mem_erase.mp h).2) (fun h=>aNot 1 (mem_erase.mp h).2)
        (fun h=>class_not_mem (by decide : (0:Fin 6)≠1) wm (mem_erase.mp h).2)
        sa (apart wd) (fun e=>(shore_off D).1 (e.symm ▸ wd)) syPos ayPos wPos
    have zu : G.Adj z u := by
      by_contra n
      have sub : G.neighborFinset u⊆insert y ((classSet D 1).erase u) := by
        intro w wm
        have e := (G.mem_neighborFinset u w).mp wm
        rcases b_even_neighbor_choices_two_four F hc um e with m|m|m
        · exact (uNo _ m e).elim
        · exact mem_insert_of_mem m
        · rcases (show w=y ∨ w=z by simpa [Y] using m) with rfl|rfl
          · exact mem_insert_self _ _
          · exact (n e.symm).elim
      have h := (card_le_card sub).trans (card_insert_le _ _)
      rw [card_neighborFinset_eq_degree,br] at h
      have hi := F.high u (mem_filter.mp um).1
      omega
    have allZ : ∀ w∈classSet D 1,G.Adj z w := by
      intro w wm
      by_cases eq : w=u
      · exact eq.symm ▸ zu
      · exact zR w (mem_erase.mpr ⟨eq,wm⟩)
    have aPos : classSet D 0⊆PositiveEven G z := by
      intro w wm
      obtain ⟨v,vm,wv⟩ := a_even_cannot_avoid_b_even_two_four F hc ea X wm
      have ne : z≠w := fun e=>class_not_mem (by decide : (4:Fin 6)≠0) zm (e.symm ▸ wm)
      exact dist_two_positive_even hc ne (F.b_port_no_dark_a hc zm wm) (allZ _ vm) wv.symm
    exact two_four_common_missed_by_b_impossible_a_pos F hc ab even CD sc bs' ea zm cm dm diff zc zd aPos

#print axioms no_two_four_both_common_select_y

private theorem impossible_singleton_multi_two_four_two_frame
    {C D : Cmp G a b} (F : MultiFrame G a b D) (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ z,(EvenFrom G z).card≤6) (CD : C≠D) {s : V} (sc : s∈Shore C)
    (as' : G.Adj a s) (bs' : G.Adj b s)
    (ea : (classSet D 0).card=2) (eb : (classSet D 1).card=4)
    (oa : (classSet D 3).card=1) (ob : (classSet D 4).card=2) (oc : (classSet D 5).card=2) : False := by
  classical
  obtain ⟨x,X⟩ := card_eq_one.mp oa
  obtain ⟨y,z,yz,Y⟩ := card_eq_two.mp ob
  obtain ⟨c,d,cd,K⟩ := card_eq_two.mp oc
  have K' : classSet D 5={d,c} := by rw [K,pair_comm]
  have Y' : classSet D 4={z,y} := by rw [Y,pair_comm]
  have cG := common_a_and_one_b_in_two_four F hc ab even CD sc as' ea eb X Y K
  have dG := common_a_and_one_b_in_two_four F hc ab even CD sc as' ea eb X Y K'
  have cm : c∈classSet D 5 := by simp [K]
  have dm : d∈classSet D 5 := by simp [K]
  have ym : y∈classSet D 4 := by simp [Y]
  have zm : z∈classSet D 4 := by simp [Y]
  rcases cG.2 with ⟨cy,cz⟩|⟨cz,cy⟩ <;> rcases dG.2 with ⟨dy,dz⟩|⟨dz,dy⟩
  · have small := common_select_b_at_most_one_even_two_four F hc ab even CD sc as' ea X cm zm cG.1 cy cz
    exact no_two_four_both_common_select_y F hc ab even CD sc bs' ea eb X Y K yz cd
      (fun e=>cz e.symm) (fun e=>dz e.symm) small
  · have small1 := common_select_b_at_most_one_even_two_four F hc ab even CD sc as' ea X cm zm cG.1 cy cz
    have small2 := common_select_b_at_most_one_even_two_four F hc ab even CD sc as' ea X dm ym dG.1 dz dy
    have large := cover_right_filters_at_least_three F Y eb small1
    omega
  · have small1 := common_select_b_at_most_one_even_two_four F hc ab even CD sc as' ea X dm zm dG.1 dy dz
    have small2 := common_select_b_at_most_one_even_two_four F hc ab even CD sc as' ea X cm ym cG.1 cz cy
    have large := cover_right_filters_at_least_three F Y eb small1
    omega
  · have small := common_select_b_at_most_one_even_two_four F hc ab even CD sc as' ea X cm ym cG.1 cz cy
    exact no_two_four_both_common_select_y F hc ab even CD sc bs' ea eb X Y' K yz.symm cd
      (fun e=>cy e.symm) (fun e=>dy e.symm) small

#print axioms impossible_singleton_multi_two_four_two_frame
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
