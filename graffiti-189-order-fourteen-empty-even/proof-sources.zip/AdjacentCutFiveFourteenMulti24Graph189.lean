import AdjacentCutFiveFourteenMulti24Budget189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph Shore shore_off shore_closed shore_disjoint from AdjacentCutFiveActual189
open private classSet from AdjacentCutFiveTopProfiles189
open private all_a_pos_via_ports class_not_mem from AdjacentCutFiveFourteenMultiCharge189
open private dist_two_positive_even from AdjacentCutFiveFifteenSingletonMixedCore189
open private degree_at_most_four_from_choices from AdjacentCutFiveFifteenSingletonMixedMap189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

private theorem a_even_cannot_avoid_b_even_two_four
    {D : Cmp G a b} (F : MultiFrame G a b D) (hc : G.Connected)
    (ea : (classSet D 0).card=2) {x : V} (X : classSet D 3={x})
    {u : V} (um : u∈classSet D 0) : ∃ w∈classSet D 1,G.Adj u w := by
  classical
  by_contra no
  have ud := (mem_filter.mp um).1
  have ds := F.aCover u um
  have sub : G.neighborFinset u⊆insert x (classSet D 0) := by
    intro w wm
    have e := (G.mem_neighborFinset u w).mp wm
    rcases shore_closed D _ ud _ e with rfl|rfl|wd
    · have h := dist_eq_one_iff_adj.mpr e.symm; omega
    · have h := dist_eq_one_iff_adj.mpr e.symm; omega
    rcases F.exhaust wd with m|m|m|m|m
    · exact mem_insert_of_mem m
    · exact (no ⟨w,m,e⟩).elim
    · exact mem_insert.mpr (.inl (by simpa [X] using m))
    · exact (F.b_port_no_dark_a hc m um e.symm).elim
    · exact (F.common_not_dark_a hc m um e.symm).elim
  have l := (card_le_card sub).trans (card_insert_le _ _)
  rw [card_neighborFinset_eq_degree,ea] at l
  have h := F.high _ ud
  omega

private theorem b_even_neighbor_choices_two_four
    {D : Cmp G a b} (F : MultiFrame G a b D) (hc : G.Connected)
    {u w : V} (um : u∈classSet D 1) (uw : G.Adj u w) :
    w∈classSet D 0 ∨ w∈(classSet D 1).erase u ∨ w∈classSet D 4 := by
  have ud := (mem_filter.mp um).1
  have ds := F.bCover u um
  rcases shore_closed D _ ud _ uw with rfl|rfl|wd
  · have h := dist_eq_one_iff_adj.mpr uw.symm; omega
  · have h := dist_eq_one_iff_adj.mpr uw.symm; omega
  rcases F.exhaust wd with m|m|m|m|m
  · exact .inl m
  · exact .inr (.inl (mem_erase.mpr ⟨uw.ne.symm,m⟩))
  · exact (F.a_port_no_dark_b hc m um uw.symm).elim
  · exact .inr (.inr m)
  · exact (F.common_not_dark_b hc m um uw.symm).elim

private theorem b_port_neighbor_choices_two_four
    {D : Cmp G a b} (F : MultiFrame G a b D) (hc : G.Connected) (ab : G.Adj a b)
    {x y z c d : V} (X : classSet D 3={x}) (Y : classSet D 4={y,z}) (K : classSet D 5={c,d})
    {w : V} (yw : G.Adj y w) :
    w=b ∨ w=x ∨ w=z ∨ w=c ∨ w=d ∨ w∈classSet D 1 := by
  classical
  have ym : y∈classSet D 4 := by simp [Y]
  have ys := (mem_filter.mp ym).1
  have yp := F.b_exclusive hc ab ym
  rcases shore_closed D _ ys _ yw with e|e|wd
  · exact (yp.2 (e ▸ yw.symm)).elim
  · exact .inl e
  rcases F.exhaust wd with m|m|m|m|m
  · exact (F.b_port_no_dark_a hc ym m yw).elim
  · exact .inr (.inr (.inr (.inr (.inr m))))
  · exact .inr (.inl (by simpa [X] using m))
  · have e : w=y ∨ w=z := by simpa [Y] using m
    exact .inr (.inr (.inl (e.resolve_left yw.ne.symm)))
  · have e : w=c ∨ w=d := by simpa [K] using m
    exact .inr (.inr (.inr (e.imp id Or.inl)))

#print axioms a_even_cannot_avoid_b_even_two_four
#print axioms b_even_neighbor_choices_two_four
#print axioms b_port_neighbor_choices_two_four
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
