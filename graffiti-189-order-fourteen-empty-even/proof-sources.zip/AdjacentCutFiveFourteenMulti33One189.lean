import AdjacentCutFiveFourteenMulti33Two189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph Shore shore_off shore_closed shore_disjoint from AdjacentCutFiveActual189
open private classSet from AdjacentCutFiveTopProfiles189
open private all_a_pos_via_ports all_b_pos_via_ports class_not_mem capacity_three_plus_two_filled b_port_sees_a_and_s from AdjacentCutFiveFourteenMultiCharge189
open private cohort_over_cap from AdjacentCutFiveFourteenMultiFrame189
open private dist_two_positive_even from AdjacentCutFiveFifteenSingletonMixedCore189
open private foreign_pos_even from AdjacentCutFiveComponents189
open private degree_at_most_four_from_choices from AdjacentCutFiveFifteenSingletonMixedMap189
open private swapCut from AdjacentCutFiveMixedNineGeom189
open private classSet_swap from AdjacentCutFiveFifteenSingletonResidual189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

private theorem no_common_all_a_one_b_two_two
    {C D : Cmp G a b} (F : MultiFrame G a b D) (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ z,(EvenFrom G z).card≤6) (CD : C≠D) {s : V} (sc : s∈Shore C) (as' : G.Adj a s)
    (ea : (classSet D 0).card=3) (eb : (classSet D 1).card=3)
    {x t y z c : V} (X : classSet D 3={x,t}) (Y : classSet D 4={y,z}) (K : classSet D 5={c})
    (cA : ∀ w∈classSet D 3,G.Adj c w) (cy : G.Adj c y) (cz : ¬G.Adj c z) : False := by
  classical
  have ym : y∈classSet D 4 := by simp [Y]
  have zm : z∈classSet D 4 := by simp [Y]
  have cm : c∈classSet D 5 := by simp [K]
  have yd := (mem_filter.mp ym).1
  have zd := (mem_filter.mp zm).1
  have cd := (mem_filter.mp cm).1
  have yE := F.b_exclusive hc ab ym
  have zE := F.b_exclusive hc ab zm
  have cE := F.literalC c cm
  have sPos := foreign_pos_even hc CD.symm cd sc cE.1 as'
  have aPos := all_a_pos_via_ports F hc (fun u m=>F.common_not_dark_a hc cm m)
    (class_not_mem (by decide : (5:Fin 6)≠0) cm) cA
  have zPos := dist_two_positive_even hc (show c≠z from fun e=>zE.2 (e ▸ cE.1)) cz cE.2.symm zE.1
  have yMiss : ∀ u∈classSet D 1,¬G.Adj y u := by
    intro u um yu
    have ud := (mem_filter.mp um).1
    have uPos := dist_two_positive_even hc
      (show c≠u from fun e=>class_not_mem (by decide : (5:Fin 6)≠1) cm (e.symm ▸ um))
      (F.common_not_dark_b hc cm um) cy yu
    exact capacity_three_plus_two_filled even ea aPos
      (fun m=>disjoint_left.mp (shore_disjoint CD) sc (mem_filter.mp m).1)
      (class_not_mem (by decide : (4:Fin 6)≠0) zm) (class_not_mem (by decide : (1:Fin 6)≠0) um)
      (fun e=>disjoint_left.mp (shore_disjoint CD) sc (e.symm ▸ zd))
      (fun e=>disjoint_left.mp (shore_disjoint CD) sc (e.symm ▸ ud))
      (fun e=>class_not_mem (by decide : (4:Fin 6)≠1) zm (e.symm ▸ um)) sPos zPos uPos
  have zAll : ∀ u∈classSet D 1,G.Adj z u := by
    intro u um
    obtain ⟨r,rm,ru⟩ := (F.bCover u um).2.2
    have h : r=y ∨ r=z := by simpa [Y] using rm
    rcases h with rfl|rfl
    · exact (yMiss u um ru).elim
    · exact ru
  have choices : ∀ w,G.Adj y w → w=b ∨ w=x ∨ w=t ∨ w=z ∨ w=c := by
    intro w yw
    rcases shore_closed D _ yd _ yw with rfl|rfl|wd
    · exact (yE.2 yw.symm).elim
    · exact .inl rfl
    rcases F.exhaust wd with m|m|m|m|m
    · exact (F.b_port_no_dark_a hc ym m yw).elim
    · exact (yMiss w m yw).elim
    · have h : w=x ∨ w=t := by simpa [X] using m
      exact .inr (h.imp id Or.inl)
    · have h : w=y ∨ w=z := by simpa [Y] using m
      exact .inr (.inr (.inr (.inl (h.resolve_left yw.ne.symm))))
    · exact .inr (.inr (.inr (.inr (by simpa [K] using m))))
  have complete : G.neighborFinset y={b,x,t,z,c} := by
    have sub : G.neighborFinset y⊆{b,x,t,z,c} := by
      intro u um
      simpa only [mem_insert,mem_singleton] using choices u ((G.mem_neighborFinset y u).mp um)
    have a₁ := card_insert_le b ({x,t,z,c}:Finset V)
    have a₂ := card_insert_le x ({t,z,c}:Finset V)
    have a₃ := card_insert_le t ({z,c}:Finset V)
    have a₄ := card_insert_le z ({c}:Finset V)
    rw [card_singleton] at a₄
    have big := F.high y yd
    rw [←card_neighborFinset_eq_degree] at big
    exact eq_of_subset_of_card_le sub (by omega)
  have zEdge : G.Adj y z := (G.mem_neighborFinset y z).mp (by simp [complete])
  have leftCover : ∀ u∈classSet D 3,G.Adj y u := by
    intro u um
    have e : u=x ∨ u=t := by simpa [X] using um
    apply (G.mem_neighborFinset y u).mp
    rcases e with rfl|rfl <;> simp [complete]
  have pa := all_a_pos_via_ports F hc (fun _ m=>F.b_port_no_dark_a hc ym m)
    (class_not_mem (by decide : (4:Fin 6)≠0) ym) leftCover
  have pb : classSet D 1⊆PositiveEven G y := by
    intro u um
    have ne : y≠u := fun e=>class_not_mem (by decide : (4:Fin 6)≠1) ym (e.symm ▸ um)
    exact dist_two_positive_even hc ne (yMiss u um) zEdge (zAll u um)
  exact cohort_over_cap F even pa pb (by omega)

#print axioms no_common_all_a_one_b_two_two

private noncomputable def MultiFrame.swap {D : Cmp G a b} (F : MultiFrame G a b D) :
    MultiFrame G b a (swapCut D) := by
  refine ⟨?_,?_,?_,?_,?_,?_,?_⟩
  · rw [classSet_swap]; exact F.emptyE
  · intro t tm
    rw [classSet_swap] at tm
    exact F.literalB _ tm
  · intro t tm
    rw [classSet_swap] at tm
    exact F.literalA _ tm
  · intro t tm
    rw [classSet_swap] at tm
    exact (F.literalC _ tm).symm
  · intro t tm
    rw [classSet_swap] at tm
    obtain ⟨a,b,q,qm,qt⟩ := F.bCover _ tm
    exact ⟨b,a,q,by rw [classSet_swap]; exact qm,qt⟩
  · intro t tm
    rw [classSet_swap] at tm
    obtain ⟨a,b,q,qm,qt⟩ := F.aCover _ tm
    exact ⟨b,a,q,by rw [classSet_swap]; exact qm,qt⟩
  · intro t tm
    rw [shore_swapCut D] at tm
    exact F.high _ tm

private theorem impossible_singleton_multi_three_three_one_frame
    {C D : Cmp G a b} (F : MultiFrame G a b D) (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ z,(EvenFrom G z).card≤6) (CD : C≠D) {s : V} (sc : s∈Shore C)
    (as' : G.Adj a s) (bs' : G.Adj b s)
    (ea : (classSet D 0).card=3) (eb : (classSet D 1).card=3)
    (oa : (classSet D 3).card=2) (ob : (classSet D 4).card=2) (oc : (classSet D 5).card=1) : False := by
  classical
  obtain ⟨x,t,_,X⟩ := card_eq_two.mp oa
  obtain ⟨y,z,_,Y⟩ := card_eq_two.mp ob
  obtain ⟨c,K⟩ := card_eq_one.mp oc
  have cm : c∈classSet D 5 := by simp [K]
  have cd := (mem_filter.mp cm).1
  have choices : ∀ w,G.Adj c w → w=a ∨ w=b ∨ w∈classSet D 3 ∨ w∈classSet D 4 := by
    intro w cw
    rcases shore_closed D _ cd _ cw with p|p|wd
    · exact .inl p
    · exact .inr (.inl p)
    rcases F.exhaust wd with p|p|p|p|p
    · exact (F.common_not_dark_a hc cm p cw).elim
    · exact (F.common_not_dark_b hc cm p cw).elim
    · exact .inr (.inr (.inl p))
    · exact .inr (.inr (.inr p))
    · have e : w=c := by simpa [K] using p
      exact (cw.ne e.symm).elim
  have sides : (∀ w∈classSet D 3,G.Adj c w) ∨ (∀ w∈classSet D 4,G.Adj c w) := by
    by_contra no
    push_neg at no
    obtain ⟨⟨u,um,cu⟩,⟨v,vm,cv⟩⟩ := no
    obtain ⟨i,I⟩ := card_eq_one.mp (show ((classSet D 3).erase u).card=1 by rw [card_erase_of_mem um,oa])
    obtain ⟨j,J⟩ := card_eq_one.mp (show ((classSet D 4).erase v).card=1 by rw [card_erase_of_mem vm,ob])
    have low : G.degree c≤4 := degree_at_most_four_from_choices (a:=a) (b:=b) (c:=i) (d:=j) (by
      intro w cw
      rcases choices w cw with e|e|m|m
      · exact .inl e
      · exact .inr (.inl e)
      · have q : w∈(classSet D 3).erase u := mem_erase.mpr ⟨fun e=>cu (e ▸ cw),m⟩
        exact .inr (.inr (.inl (by simpa [I] using q)))
      · have q : w∈(classSet D 4).erase v := mem_erase.mpr ⟨fun e=>cv (e ▸ cw),m⟩
        exact .inr (.inr (.inr (by simpa [J] using q))))
    have hi := F.high _ cd
    omega
  have one {A B : Finset V} (_both : A⊆classSet D 3 ∪ classSet D 4)
      (op : A={x,t} ∧ B={y,z} ∨ A={y,z} ∧ B={x,t}) : ∃ w∈B,G.Adj c w := by
    by_contra nr
    have sub : G.neighborFinset c⊆insert a (insert b A) := by
      intro w wm
      have cw := (G.mem_neighborFinset c w).mp wm
      rcases choices w cw with e|e|m|m
      · exact mem_insert.mpr (.inl e)
      · exact mem_insert.mpr (.inr (mem_insert.mpr (.inl e)))
      · rcases op with ⟨h,_⟩|⟨_,h⟩
        · exact mem_insert_of_mem (mem_insert_of_mem (by rw [h,←X]; exact m))
        · exact (nr ⟨w,by rw [h,←X]; exact m,cw⟩).elim
      · rcases op with ⟨_,h⟩|⟨h,_⟩
        · exact (nr ⟨w,by rw [h,←Y]; exact m,cw⟩).elim
        · exact mem_insert_of_mem (mem_insert_of_mem (by rw [h,←Y]; exact m))
    have a₁ := card_insert_le a (insert b A)
    have a₂ := card_insert_le b A
    have cA : A.card≤2 := by
      rcases op with ⟨h,_⟩|⟨h,_⟩
      · rw [h,←X,oa]
      · rw [h,←Y,ob]
    have hi := F.high _ cd
    have bd := (card_le_card sub)
    rw [card_neighborFinset_eq_degree] at bd
    omega
  have notBoth (l : ∀ w∈classSet D 3,G.Adj c w) (r : ∀ w∈classSet D 4,G.Adj c w) : False :=
    cohort_over_cap F even
      (all_a_pos_via_ports F hc (fun _ m=>F.common_not_dark_a hc cm m) (class_not_mem (by decide : (5:Fin 6)≠0) cm) l)
      (all_b_pos_via_ports F hc (fun _ m=>F.common_not_dark_b hc cm m) (class_not_mem (by decide : (5:Fin 6)≠1) cm) r) (by omega)
  rcases sides with left|right
  · obtain ⟨r,rm,cr⟩ := one (A:={x,t}) (B:={y,z}) (by rw [←X]; exact subset_union_left) (.inl ⟨rfl,rfl⟩)
    have g : r=y ∨ r=z := by simpa using rm
    rcases g with gy|gz
    · have cr : G.Adj c y := gy ▸ cr
      have cz : ¬G.Adj c z := fun e=>notBoth left (by
        intro w wm
        rcases (show w=y ∨ w=z by simpa [Y] using wm) with rfl|rfl
        · exact cr
        · exact e)
      exact no_common_all_a_one_b_two_two F hc ab even CD sc as' ea eb X Y K left cr cz
    · have cr : G.Adj c z := gz ▸ cr
      have cy : ¬G.Adj c y := fun e=>notBoth left (by
        intro w wm
        rcases (show w=y ∨ w=z by simpa [Y] using wm) with rfl|rfl
        · exact e
        · exact cr)
      exact no_common_all_a_one_b_two_two F hc ab even CD sc as' ea eb X (by rw [Y,pair_comm]) K left cr cy
  · obtain ⟨r,rm,cr⟩ := one (A:={y,z}) (B:={x,t}) (by rw [←Y]; exact subset_union_right) (.inr ⟨rfl,rfl⟩)
    have g : r=x ∨ r=t := by simpa using rm
    let F' := MultiFrame.swap F
    have cd' : swapCut C≠swapCut D := fun e=>CD (swapCut.injective e)
    have sc' : s∈Shore (swapCut C) := by rw [shore_swapCut C]; exact sc
    have ea' : (classSet (swapCut D) 0).card=3 := by rw [classSet_swap]; exact eb
    have eb' : (classSet (swapCut D) 1).card=3 := by rw [classSet_swap]; exact ea
    have X' : classSet (swapCut D) 3={y,z} := by rw [classSet_swap]; exact Y
    have Y' : classSet (swapCut D) 4={x,t} := by rw [classSet_swap]; exact X
    have K' : classSet (swapCut D) 5={c} := by rw [classSet_swap]; exact K
    have a' : ∀ w∈classSet (swapCut D) 3,G.Adj c w := by
      intro w wm
      rw [classSet_swap] at wm
      exact right w wm
    rcases g with gx|gt
    · have cr : G.Adj c x := gx ▸ cr
      have ct : ¬G.Adj c t := fun e=>notBoth (by
        intro w wm
        rcases (show w=x ∨ w=t by simpa [X] using wm) with rfl|rfl
        · exact cr
        · exact e) right
      exact no_common_all_a_one_b_two_two F' hc ab.symm even cd' sc' bs' ea' eb' X' Y' K' a' cr ct
    · have cr : G.Adj c t := gt ▸ cr
      have cx : ¬G.Adj c x := fun e=>notBoth (by
        intro w wm
        rcases (show w=x ∨ w=t by simpa [X] using wm) with rfl|rfl
        · exact e
        · exact cr) right
      exact no_common_all_a_one_b_two_two F' hc ab.symm even cd' sc' bs' ea' eb' X' (by rw [Y',pair_comm]) K' a' cr cx

#print axioms impossible_singleton_multi_three_three_one_frame
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
