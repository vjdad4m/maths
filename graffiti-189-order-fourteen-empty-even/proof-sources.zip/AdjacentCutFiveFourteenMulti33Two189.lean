import AdjacentCutFiveFourteenMultiCharge189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph Shore shore_off shore_closed shore_disjoint from AdjacentCutFiveActual189
open private classSet from AdjacentCutFiveTopProfiles189
open private all_a_pos_via_ports all_b_pos_via_ports class_not_mem capacity_three_plus_two_filled b_port_sees_a_and_s from AdjacentCutFiveFourteenMultiCharge189
open private cohort_over_cap from AdjacentCutFiveFourteenMultiFrame189
open private dist_two_positive_even b_port_selected_by_common_misses_b_even from AdjacentCutFiveFifteenSingletonMixedCore189
open private foreign_pos_even from AdjacentCutFiveComponents189
open private degree_at_most_four_from_choices from AdjacentCutFiveFifteenSingletonMixedMap189
open private cannot_fit_four_and_two_more from AdjacentCutFiveSixteenSingletonGeometry189
open private mem_positive d2 from AdjacentCutFiveBound189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

private theorem no_type_x_common_three_three
    {C D : Cmp G a b} (F : MultiFrame G a b D) (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ z,(EvenFrom G z).card≤6) (CD : C≠D) {s : V} (sc : s∈Shore C) (as' : G.Adj a s)
    (ea : (classSet D 0).card=3) (eb : (classSet D 1).card=3)
    {x y z c d : V} (X : classSet D 3={x}) (Y : classSet D 4={y,z}) (K : classSet D 5={c,d})
    (cx : G.Adj c x) (cy : G.Adj c y) (cz : ¬G.Adj c z) : False := by
  classical
  have xm : x∈classSet D 3 := by simp [X]
  have ym : y∈classSet D 4 := by simp [Y]
  have zm : z∈classSet D 4 := by simp [Y]
  have cm : c∈classSet D 5 := by simp [K]
  have yd := (mem_filter.mp ym).1
  have zd := (mem_filter.mp zm).1
  have cd := (mem_filter.mp cm).1
  have yz := F.b_exclusive hc ab ym
  have zb := F.b_exclusive hc ab zm
  have cb := F.literalC c cm
  have xAll : ∀ w∈classSet D 0,G.Adj x w := by
    intro w wm
    obtain ⟨u,um,uw⟩ := (F.aCover w wm).2.2
    have e : u=x := by simpa [X] using um
    exact e ▸ uw
  have yMiss := b_port_selected_by_common_misses_b_even hc even CD sc as' cd zd cb.1 cb.2 zb.1 zb.2 ea
    (fun w m=>⟨(F.aCover w m).1,(F.aCover w m).2.1⟩)
    (fun w m=>⟨(F.bCover w m).1,(F.bCover w m).2.1⟩) xAll cx cy cz
  have zAll : ∀ w∈classSet D 1,G.Adj z w := by
    intro w wm
    obtain ⟨u,um,uw⟩ := (F.bCover w wm).2.2
    have e : u=y ∨ u=z := by simpa [Y] using um
    rcases e with rfl|rfl
    · exact (yMiss w wm uw).elim
    · exact uw
  have choices : ∀ w,G.Adj y w → w=b ∨ w=x ∨ w=z ∨ w=c ∨ w=d := by
    intro w yw
    rcases shore_closed D _ yd _ yw with rfl|rfl|wd
    · exact (yz.2 yw.symm).elim
    · exact .inl rfl
    rcases F.exhaust wd with m|m|m|m|m
    · exact (F.b_port_no_dark_a hc ym m yw).elim
    · exact (yMiss w m yw).elim
    · exact .inr (.inl (by simpa [X] using m))
    · have h : w=y ∨ w=z := by simpa [Y] using m
      exact .inr (.inr (.inl (h.resolve_left yw.ne.symm)))
    · exact .inr (.inr (.inr (by simpa [K] using m)))
  have force {r t : V} (side : r=x ∧ t=z ∨ r=z ∧ t=x) : G.Adj y r := by
    by_contra no
    have fx : G.Adj y x → x=t := by
      rcases side with ⟨rfl,_⟩|⟨_,e⟩
      · exact fun h=>(no h).elim
      · exact fun _=>e.symm
    have fz : G.Adj y z → z=t := by
      rcases side with ⟨_,e⟩|⟨rfl,_⟩
      · exact fun _=>e.symm
      · exact fun h=>(no h).elim
    have l : G.degree y≤4 := degree_at_most_four_from_choices (a:=b) (b:=t) (c:=c) (d:=d) (by
      intro w e
      rcases choices w e with q|q|q|q|q
      · exact .inl q
      · exact .inr (.inl (q.trans (fx (q ▸ e))))
      · exact .inr (.inl (q.trans (fz (q ▸ e))))
      · exact .inr (.inr (.inl q))
      · exact .inr (.inr (.inr q)))
    have hi := F.high _ yd
    omega
  have yx : G.Adj y x := force (.inl ⟨rfl,rfl⟩)
  have yz' : G.Adj y z := force (.inr ⟨rfl,rfl⟩)
  have aPos := all_a_pos_via_ports F hc (fun _ m=>F.b_port_no_dark_a hc ym m)
    (class_not_mem (by decide : (4:Fin 6)≠0) ym) (by
      intro u um
      have ux : u=x := by simpa [X] using um
      exact ux.symm ▸ yx)
  have bPos : classSet D 1⊆PositiveEven G y := by
    intro u um
    have ne : y≠u := fun e=>class_not_mem (by decide : (4:Fin 6)≠1) ym (e.symm ▸ um)
    exact dist_two_positive_even hc ne (yMiss _ um) yz' (zAll _ um)
  exact cohort_over_cap F even aPos bPos (by omega)

#print axioms no_type_x_common_three_three

private theorem common_misses_unique_a_three_three
    {C D : Cmp G a b} (F : MultiFrame G a b D) (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ z,(EvenFrom G z).card≤6) (CD : C≠D) {s : V} (sc : s∈Shore C) (as' : G.Adj a s)
    (ea : (classSet D 0).card=3) (eb : (classSet D 1).card=3)
    {x y z c d : V} (X : classSet D 3={x}) (Y : classSet D 4={y,z}) (K : classSet D 5={c,d}) :
    ¬G.Adj c x := by
  classical
  intro cx
  have cm : c∈classSet D 5 := by simp [K]
  have cd := (mem_filter.mp cm).1
  have notBoth (cy : G.Adj c y) (cz : G.Adj c z) : False := by
    have aPos := all_a_pos_via_ports F hc (fun w m=>F.common_not_dark_a hc cm m)
      (class_not_mem (by decide : (5:Fin 6)≠0) cm) (by
        intro u um
        have ex : u=x := by simpa [X] using um
        exact ex.symm ▸ cx)
    have bPos := all_b_pos_via_ports F hc (fun w m=>F.common_not_dark_b hc cm m)
      (class_not_mem (by decide : (5:Fin 6)≠1) cm) (by
        intro u um
        have ex : u=y ∨ u=z := by simpa [Y] using um
        rcases ex with rfl|rfl
        · exact cy
        · exact cz)
    exact cohort_over_cap F even aPos bPos (by omega)
  by_cases cy : G.Adj c y
  · exact no_type_x_common_three_three F hc ab even CD sc as' ea eb X Y K cx cy (notBoth cy)
  by_cases cz : G.Adj c z
  · exact no_type_x_common_three_three F hc ab even CD sc as' ea eb X (show classSet D 4={z,y} by rw [Y,pair_comm]) K cx cz cy
  have l : G.degree c≤4 := degree_at_most_four_from_choices (a:=a) (b:=b) (c:=x) (d:=d) (by
    intro w cw
    rcases shore_closed D _ cd _ cw with q|q|wd
    · exact .inl q
    · exact .inr (.inl q)
    rcases F.exhaust wd with q|q|q|q|q
    · exact (F.common_not_dark_a hc cm q cw).elim
    · exact (F.common_not_dark_b hc cm q cw).elim
    · exact .inr (.inr (.inl (by simpa [X] using q)))
    · have eq : w=y ∨ w=z := by simpa [Y] using q
      rcases eq with rfl|rfl
      · exact (cy cw).elim
      · exact (cz cw).elim
    · have eq : w=c ∨ w=d := by simpa [K] using q
      exact .inr (.inr (.inr (eq.resolve_left cw.ne.symm))))
  have hi := F.high _ cd
  omega

private theorem no_three_three_both_common_miss_x
    {C D : Cmp G a b} (F : MultiFrame G a b D) (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ z,(EvenFrom G z).card≤6) (CD : C≠D) {s : V} (sc : s∈Shore C)
    (as' : G.Adj a s) (bs' : G.Adj b s)
    (ea : (classSet D 0).card=3) (eb : (classSet D 1).card=3)
    {x y z c d : V} (X : classSet D 3={x}) (Y : classSet D 4={y,z}) (K : classSet D 5={c,d})
    (ne : y≠z) (diff : c≠d)
    (xc : ¬G.Adj x c) (xd' : ¬G.Adj x d) (xy : G.Adj x y) : False := by
  classical
  have xm : x∈classSet D 3 := by simp [X]
  have ym : y∈classSet D 4 := by simp [Y]
  have zm : z∈classSet D 4 := by simp [Y]
  have cm : c∈classSet D 5 := by simp [K]
  have dm : d∈classSet D 5 := by simp [K]
  have xd := (mem_filter.mp xm).1
  have yd := (mem_filter.mp ym).1
  have zd := (mem_filter.mp zm).1
  have cd := (mem_filter.mp cm).1
  have dd := (mem_filter.mp dm).1
  have xE := F.a_exclusive hc ab xm
  have yE := F.b_exclusive hc ab ym
  have zE := F.b_exclusive hc ab zm
  have ca := (F.literalC c cm).1
  have da := (F.literalC d dm).1
  have aPos := all_a_pos_via_ports F hc (fun _ m=>F.b_port_no_dark_a hc ym m)
    (class_not_mem (by decide : (4:Fin 6)≠0) ym)
    (by
      intro w wm
      have e : w=x := by simpa [X] using wm
      exact e.symm ▸ xy.symm)
  obtain ⟨aPos',sPos'⟩ := b_port_sees_a_and_s F hc ab CD sc bs' ym
  have excess {u : V} (um : u∈Shore D) (uNot : u∉classSet D 0) (pos : u∈PositiveEven G y) : False :=
    capacity_three_plus_two_filled even ea aPos
      (fun m=>disjoint_left.mp (shore_disjoint CD) sc (mem_filter.mp m).1)
      (fun m=>(shore_off D).1 (mem_filter.mp m).1) uNot
      (fun e=>(shore_off C).1 (e ▸ sc))
      (fun e=>disjoint_left.mp (shore_disjoint CD) sc (e.symm ▸ um))
      (fun e=>(shore_off D).1 (e.symm ▸ um)) sPos' aPos' pos
  have yz : G.Adj y z := by
    by_contra hz
    exact excess zd (class_not_mem (by decide : (4:Fin 6)≠0) zm)
      (dist_two_positive_even hc ne hz yE.1.symm zE.1)
  have allY : ∀ u∈classSet D 1,G.Adj y u := by
    intro u um
    by_contra hy
    obtain ⟨v,vm,vu⟩ := (F.bCover u um).2.2
    have eq : v=y ∨ v=z := by simpa [Y] using vm
    rcases eq with rfl|rfl
    · exact hy vu
    · have yn : y≠u := fun e=>class_not_mem (by decide : (4:Fin 6)≠1) ym (e.symm ▸ um)
      exact excess (mem_filter.mp um).1 (class_not_mem (by decide : (1:Fin 6)≠0) um)
        (dist_two_positive_even hc yn hy yz vu)
  have bPos : classSet D 1⊆PositiveEven G x := by
    intro w wm
    have ne : x≠w := fun e=>class_not_mem (by decide : (3:Fin 6)≠1) xm (e.symm ▸ wm)
    exact dist_two_positive_even hc ne (F.a_port_no_dark_b hc xm wm) xy (allY _ wm)
  have cPos := dist_two_positive_even hc
    (show x≠c from fun e=>class_not_mem (by decide : (3:Fin 6)≠5) xm (e.symm ▸ cm)) xc xE.1.symm ca
  have dPos := dist_two_positive_even hc
    (show x≠d from fun e=>class_not_mem (by decide : (3:Fin 6)≠5) xm (e.symm ▸ dm)) xd' xE.1.symm da
  have sPos := foreign_pos_even hc CD.symm xd sc xE.1 as'
  exact capacity_three_plus_two_filled even eb bPos
    (fun m=>disjoint_left.mp (shore_disjoint CD) sc (mem_filter.mp m).1)
    (class_not_mem (by decide : (5:Fin 6)≠1) cm) (class_not_mem (by decide : (5:Fin 6)≠1) dm)
    (fun e=>disjoint_left.mp (shore_disjoint CD) sc (e.symm ▸ cd))
    (fun e=>disjoint_left.mp (shore_disjoint CD) sc (e.symm ▸ dd)) diff sPos cPos dPos

#print axioms common_misses_unique_a_three_three
#print axioms no_three_three_both_common_miss_x

private theorem impossible_singleton_multi_three_three_two_frame
    {C D : Cmp G a b} (F : MultiFrame G a b D) (hc : G.Connected) (ab : G.Adj a b)
    (even : ∀ z,(EvenFrom G z).card≤6) (CD : C≠D) {s : V} (sc : s∈Shore C)
    (as' : G.Adj a s) (bs' : G.Adj b s)
    (ea : (classSet D 0).card=3) (eb : (classSet D 1).card=3)
    (oa : (classSet D 3).card=1) (ob : (classSet D 4).card=2) (oc : (classSet D 5).card=2) : False := by
  classical
  obtain ⟨x,X⟩ := card_eq_one.mp oa
  obtain ⟨y,z,yz,Y⟩ := card_eq_two.mp ob
  obtain ⟨c,d,cd,K⟩ := card_eq_two.mp oc
  have xc : ¬G.Adj x c := fun e=>common_misses_unique_a_three_three F hc ab even CD sc as' ea eb X Y K e.symm
  have xd' : ¬G.Adj x d := fun e=>common_misses_unique_a_three_three F hc ab even CD sc as' ea eb X Y
    (show classSet D 5={d,c} by rw [K,pair_comm]) e.symm
  by_cases xy : G.Adj x y
  · exact no_three_three_both_common_miss_x F hc ab even CD sc as' bs' ea eb X Y K yz cd xc xd' xy
  by_cases xz : G.Adj x z
  · exact no_three_three_both_common_miss_x F hc ab even CD sc as' bs' ea eb X
      (show classSet D 4={z,y} by rw [Y,pair_comm]) K yz.symm cd xc xd' xz
  have xm : x∈classSet D 3 := by simp [X]
  have xd := (mem_filter.mp xm).1
  have xE := F.a_exclusive hc ab xm
  have sub : G.neighborFinset x⊆insert a (classSet D 0) := by
    intro w wm
    have xw := (G.mem_neighborFinset x w).mp wm
    rcases shore_closed D _ xd _ xw with rfl|rfl|wd
    · exact mem_insert_self _ _
    · exact (xE.2 xw.symm).elim
    rcases F.exhaust wd with m|m|m|m|m
    · exact mem_insert_of_mem m
    · exact (F.a_port_no_dark_b hc xm m xw).elim
    · have e : w=x := by simpa [X] using m
      exact (xw.ne e.symm).elim
    · have e : w=y ∨ w=z := by simpa [Y] using m
      exact (e.elim (fun p=>xy (p ▸ xw)) (fun p=>xz (p ▸ xw))).elim
    · have e : w=c ∨ w=d := by simpa [K] using m
      exact (e.elim (fun p=>xc (p ▸ xw)) (fun p=>xd' (p ▸ xw))).elim
  have bnd := (card_le_card sub).trans (card_insert_le _ _)
  rw [card_neighborFinset_eq_degree,ea] at bnd
  have hi := F.high x xd
  omega

#print axioms impossible_singleton_multi_three_three_two_frame
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
