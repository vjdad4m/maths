import AdjacentCutFiveFourteenMultiFrame189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph Shore shore_off shore_closed shore_disjoint from AdjacentCutFiveActual189
open private key classSet from AdjacentCutFiveTopProfiles189
open private disjoint_profile_sets cannot_fit_four_and_two_more from AdjacentCutFiveSixteenSingletonGeometry189
open private dist_two_positive_even adj_forbidden_by_dist dist_two_from_b_exclusive from AdjacentCutFiveFifteenSingletonMixedCore189
open private positive_cap foreign_pos_even from AdjacentCutFiveComponents189
open private mem_positive d2 from AdjacentCutFiveBound189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

private theorem all_a_pos_via_ports {D : Cmp G a b} (F : MultiFrame G a b D)
    (hc : G.Connected) {q : V} (no : ∀ w∈classSet D 0,¬G.Adj q w)
    (ne : q∉classSet D 0) (edges : ∀ x∈classSet D 3,G.Adj q x) :
    classSet D 0⊆PositiveEven G q := by
  intro w wm
  obtain ⟨x,xm,xw⟩ := (F.aCover w wm).2.2
  exact dist_two_positive_even hc (fun e=>ne (e.symm ▸ wm)) (no w wm) (edges x xm) xw

private theorem all_b_pos_via_ports {D : Cmp G a b} (F : MultiFrame G a b D)
    (hc : G.Connected) {q : V} (no : ∀ w∈classSet D 1,¬G.Adj q w)
    (ne : q∉classSet D 1) (edges : ∀ x∈classSet D 4,G.Adj q x) :
    classSet D 1⊆PositiveEven G q := by
  intro w wm
  obtain ⟨x,xm,xw⟩ := (F.bCover w wm).2.2
  exact dist_two_positive_even hc (fun e=>ne (e.symm ▸ wm)) (no w wm) (edges x xm) xw

private theorem class_not_mem {D : Cmp G a b} {i j : Fin 6} (ij : i≠j)
    {w : V} (wm : w∈classSet D i) : w∉classSet D j :=
  fun h=>disjoint_left.mp (disjoint_profile_sets D ij) wm h

private theorem capacity_three_plus_two_filled
    (even : ∀ w,(EvenFrom G w).card≤6) {q : V}
    {A : Finset V} (card : A.card=3) (pos : A⊆PositiveEven G q)
    {s t u : V} (sa : s∉A) (ta : t∉A) (ua : u∉A)
    (st : s≠t) (su : s≠u) (tu : t≠u)
    (ps : s∈PositiveEven G q) (pt : t∈PositiveEven G q) (pu : u∈PositiveEven G q) : False := by
  classical
  have four : 4≤(insert s A).card := by rw [card_insert_of_not_mem sa,card]
  exact cannot_fit_four_and_two_more even four (insert_subset_iff.mpr ⟨ps,pos⟩)
    (by simp [ta,st.symm]) (by simp [ua,su.symm]) tu.symm pt pu

private theorem b_port_sees_a_and_s
    {C D : Cmp G a b} (F : MultiFrame G a b D)
    (hc : G.Connected) (ab : G.Adj a b)
    (CD : C≠D) {s : V} (sc : s∈Shore C) (bs' : G.Adj b s)
    {y : V} (ym : y∈classSet D 4) :
    a∈PositiveEven G y ∧ s∈PositiveEven G y := by
  obtain ⟨by',ny⟩ := F.b_exclusive hc ab ym
  have yd := (mem_filter.mp ym).1
  have ya : y≠a := fun eq=>(shore_off D).1 (eq ▸ yd)
  have two := dist_two_from_b_exclusive hc ab yd by' ny
  exact ⟨mem_positive.mpr ⟨ya.symm,by rw [dist_comm,two]; decide⟩,
    foreign_pos_even hc CD.symm yd sc by' bs'⟩

#print axioms all_a_pos_via_ports
#print axioms all_b_pos_via_ports
#print axioms capacity_three_plus_two_filled
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
