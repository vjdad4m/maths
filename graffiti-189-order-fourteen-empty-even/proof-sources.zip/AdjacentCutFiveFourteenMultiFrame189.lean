import AdjacentCutFiveFourteenMultiPorts189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph Shore shore_off shore_closed shore_disjoint from AdjacentCutFiveActual189
open private key classSet key_facts from AdjacentCutFiveTopProfiles189
open private key_a_port key_b_port from AdjacentCutFiveTopFlatten189
open private disjoint_profile_sets from AdjacentCutFiveSixteenSingletonGeometry189
open private singleton_even_cohort_ports from AdjacentCutFiveFourteenMultiPorts189
open private dist_two_positive_even adj_forbidden_by_dist from AdjacentCutFiveFifteenSingletonMixedCore189
open private positive_cap foreign_pos_even from AdjacentCutFiveComponents189
open private d2 from AdjacentCutFiveBound189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

structure MultiFrame (G : SimpleGraph V) (a b : V) [DecidableRel G.Adj] (D : Cmp G a b) where
  emptyE : (classSet D 2).card=0
  literalA : ∀ w∈classSet D 3,G.Adj a w
  literalB : ∀ w∈classSet D 4,G.Adj b w
  literalC : ∀ w∈classSet D 5,G.Adj a w ∧ G.Adj b w
  aCover : ∀ w∈classSet D 0,G.dist a w=2 ∧ G.dist b w=3 ∧ ∃ x∈classSet D 3,G.Adj x w
  bCover : ∀ w∈classSet D 1,G.dist a w=3 ∧ G.dist b w=2 ∧ ∃ y∈classSet D 4,G.Adj y w
  high : ∀ w∈Shore D,5≤G.degree w

theorem MultiFrame.exhaust {D : Cmp G a b} (F : MultiFrame G a b D) {w : V} (wd : w∈Shore D) :
    w∈classSet D 0 ∨ w∈classSet D 1 ∨ w∈classSet D 3 ∨ w∈classSet D 4 ∨ w∈classSet D 5 := by
  rcases (by decide : ∀ i : Fin 6,i=0 ∨ i=1 ∨ i=2 ∨ i=3 ∨ i=4 ∨ i=5) (key G a b w) with i|i|i|i|i|i
  · exact .inl (mem_filter.mpr ⟨wd,i⟩)
  · exact .inr (.inl (mem_filter.mpr ⟨wd,i⟩))
  · have c := card_pos.mpr (show (classSet D 2).Nonempty from ⟨w,mem_filter.mpr ⟨wd,i⟩⟩)
    have z := F.emptyE
    omega
  · exact .inr (.inr (.inl (mem_filter.mpr ⟨wd,i⟩)))
  · exact .inr (.inr (.inr (.inl (mem_filter.mpr ⟨wd,i⟩))))
  · exact .inr (.inr (.inr (.inr (mem_filter.mpr ⟨wd,i⟩))))

theorem MultiFrame.a_exclusive {D : Cmp G a b} (F : MultiFrame G a b D)
    (_hc : G.Connected) (_ab : G.Adj a b) {w : V} (wm : w∈classSet D 3) :
    G.Adj a w ∧ ¬G.Adj b w := by
  have aw := F.literalA w wm
  refine ⟨aw,fun bw=>?_⟩
  have k := (mem_filter.mp wm).2
  have no : key G a b w=5 := by classical simp [key,dist_eq_one_iff_adj.mpr aw,dist_eq_one_iff_adj.mpr bw]
  rw [no] at k
  contradiction

theorem MultiFrame.b_exclusive {D : Cmp G a b} (F : MultiFrame G a b D)
    (_hc : G.Connected) (_ab : G.Adj a b) {w : V} (wm : w∈classSet D 4) :
    G.Adj b w ∧ ¬G.Adj a w := by
  have bw := F.literalB w wm
  refine ⟨bw,fun aw=>?_⟩
  have k := (mem_filter.mp wm).2
  have no : key G a b w=5 := by classical simp [key,dist_eq_one_iff_adj.mpr aw,dist_eq_one_iff_adj.mpr bw]
  rw [no] at k
  contradiction

theorem MultiFrame.common_not_dark_a {D : Cmp G a b} (F : MultiFrame G a b D)
    (hc : G.Connected) {c u : V} (cm : c∈classSet D 5) (um : u∈classSet D 0) :
    ¬G.Adj c u := by
  have one := dist_eq_one_iff_adj.mpr (F.literalC c cm).2
  have three := (F.aCover u um).2.1
  exact adj_forbidden_by_dist hc (show G.dist b c+1<G.dist b u by omega)

theorem MultiFrame.common_not_dark_b {D : Cmp G a b} (F : MultiFrame G a b D)
    (hc : G.Connected) {c u : V} (cm : c∈classSet D 5) (um : u∈classSet D 1) :
    ¬G.Adj c u := by
  have one := dist_eq_one_iff_adj.mpr (F.literalC c cm).1
  have three := (F.bCover u um).1
  exact adj_forbidden_by_dist hc (show G.dist a c+1<G.dist a u by omega)

theorem MultiFrame.a_port_no_dark_b {D : Cmp G a b} (F : MultiFrame G a b D)
    (hc : G.Connected) {x u : V} (xm : x∈classSet D 3) (um : u∈classSet D 1) :
    ¬G.Adj x u := by
  have one := dist_eq_one_iff_adj.mpr (F.literalA x xm)
  have three := (F.bCover u um).1
  exact adj_forbidden_by_dist hc (show G.dist a x+1<G.dist a u by omega)

theorem MultiFrame.b_port_no_dark_a {D : Cmp G a b} (F : MultiFrame G a b D)
    (hc : G.Connected) {x u : V} (xm : x∈classSet D 4) (um : u∈classSet D 0) :
    ¬G.Adj x u := by
  have one := dist_eq_one_iff_adj.mpr (F.literalB x xm)
  have three := (F.aCover u um).2.1
  exact adj_forbidden_by_dist hc (show G.dist b x+1<G.dist b u by omega)

private theorem cohort_over_cap {D : Cmp G a b} (_F : MultiFrame G a b D)
    (even : ∀ w,(EvenFrom G w).card≤6) {q : V}
    (aPos : classSet D 0⊆PositiveEven G q) (bPos : classSet D 1⊆PositiveEven G q)
    (large : 6≤(classSet D 0).card+(classSet D 1).card) : False := by
  classical
  have sub : classSet D 0∪classSet D 1⊆PositiveEven G q := union_subset aPos bPos
  have c := (card_le_card sub).trans (positive_cap q even)
  rw [card_union_of_disjoint (disjoint_profile_sets D (by decide : (0:Fin 6)≠1))] at c
  omega

#print axioms cohort_over_cap
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
