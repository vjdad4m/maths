import AdjacentCutFiveFourteenMultiDepth189
import AdjacentCutFiveFifteenSingletonResidual189

namespace Graffiti189LongestPath.CrossSaturation.FiveAdjacent
open SimpleGraph SimpleGraph.Walk Finset
open private CutGraph Shore shore_off shore_closed from AdjacentCutFiveActual189
open private key classSet key_facts from AdjacentCutFiveTopProfiles189
open private key_a_port key_b_port from AdjacentCutFiveTopFlatten189
open private restrict_unique_profile from AdjacentCutFiveSixteenSingletonGeometry189
open private d2 from AdjacentCutFiveBound189
open private predecessor_of_positive_dist left_even_depth_two_with_one_exclusive from AdjacentCutFiveSixteenSingletonDepth189
open private all_common_of_adjacent_singleton_profile_two from AdjacentCutFiveFifteenSingletonMixed189
open private right_even_has_actual_b_port from AdjacentCutFiveFifteenSingletonMixed189
open private swapCut from AdjacentCutFiveMixedNineGeom189
open private classSet_swap from AdjacentCutFiveFifteenSingletonResidual189
open private adj_forbidden_by_dist from AdjacentCutFiveFifteenSingletonMixedCore189
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {a b : V}
set_option linter.unusedSectionVars false
private abbrev Cmp (G : SimpleGraph V) (a b : V) := (CutGraph (G:=G) a b).ConnectedComponent

private theorem singleton_multi_all_b_odd_literal
    (hc : G.Connected) (ab : G.Adj a b)
    {D : Cmp G a b}
    (ea : 0<(classSet D 0).card) (eb : (classSet D 1).card≤4)
    (zer : (classSet D 2).card=0) (oa : (classSet D 3).card=1) (ob : (classSet D 4).card=2)
    (high : ∀ w∈Shore D,5≤G.degree w)
    (common : ∀ w∈classSet D 5,G.Adj a w ∧ G.Adj b w) :
    ∀ z∈classSet D 4,G.Adj b z := by
  classical
  obtain ⟨u,um⟩ := card_pos.mp ea
  have ud := (mem_filter.mp um).1
  have uu := (mem_filter.mp um).2
  obtain ⟨aU,bU,_⟩ := key_facts hc ab u
  rw [uu] at aU bU
  change G.dist a u=depth G a b u+0 at aU
  change G.dist b u=depth G a b u+1 at bU
  obtain ⟨x,xd,ax,nx⟩ := exclusive_left_port_of_strictly_nearer hc ud (by omega)
  have xb : x≠b := fun e=>(shore_off D).2 (e ▸ xd)
  have xd2 := (mem_filter.mp (d2 hc xb.symm nx ab.symm ax)).2
  have xk : key G a b x=3 := by simp [key,dist_eq_one_iff_adj.mpr ax,xd2]
  have X := restrict_unique_profile oa xd xk
  intro z zm
  obtain ⟨zd,zk⟩ := mem_filter.mp zm
  obtain ⟨az,bz,ev⟩ := key_facts hc ab z
  rw [zk] at az bz ev
  change G.dist a z=depth G a b z+1 at az
  change G.dist b z=depth G a b z+0 at bz
  change depth G a b z % 2=1 at ev
  by_contra nz
  have n1 : G.dist b z≠1 := fun e=>nz (dist_eq_one_iff_adj.mp e)
  have tall : 3≤G.dist b z := by omega
  obtain ⟨y,yd,by',ny⟩ := exclusive_right_port_of_strictly_nearer hc zd (by omega)
  have ya : y≠a := fun e=>(shore_off D).1 (e ▸ yd)
  have ya2 := (mem_filter.mp (d2 hc ya.symm ny ab by')).2
  have yk : key G a b y=4 := by simp [key,dist_eq_one_iff_adj.mpr by',ya2]
  have ym : y∈classSet D 4 := mem_filter.mpr ⟨yd,yk⟩
  have zy : z≠y := fun e=>nz (e.symm ▸ by')
  have two : classSet D 4={z,y} := by
    have sub : ({z,y}:Finset V)⊆classSet D 4 := by
      intro q qm
      rcases (show q=z ∨ q=y by simpa using qm) with rfl|rfl
      · exact zm
      · exact ym
    exact (eq_of_subset_of_card_le sub (by simp [ob,zy])).symm
  have sub : G.neighborFinset z⊆classSet D 1 := by
    intro w m
    have e := (G.mem_neighborFinset z w).mp m
    have aL := hc.dist_triangle (u:=a) (v:=w) (w:=z)
    have bL := hc.dist_triangle (u:=b) (v:=w) (w:=z)
    rw [dist_eq_one_iff_adj.mpr e.symm] at aL bL
    have wd : w∈Shore D := by
      rcases shore_closed D _ zd _ e with h|h|h
      · rw [h,dist_self] at aL; omega
      · rw [h,dist_self] at bL; omega
      · exact h
    rcases (by decide : ∀ i : Fin 6,i=0 ∨ i=1 ∨ i=2 ∨ i=3 ∨ i=4 ∨ i=5) (key G a b w) with k|k|k|k|k|k
    · have dd := left_even_depth_two_with_one_exclusive hc ab oa wd k
      omega
    · exact mem_filter.mpr ⟨wd,k⟩
    · have h := card_pos.mpr (show (classSet D 2).Nonempty from ⟨w,mem_filter.mpr ⟨wd,k⟩⟩)
      omega
    · have q : w∈classSet D 3 := mem_filter.mpr ⟨wd,k⟩
      have wx : w=x := by simpa [X] using q
      rw [wx,dist_eq_one_iff_adj.mpr ax] at aL
      omega
    · have q : w∈classSet D 4 := mem_filter.mpr ⟨wd,k⟩
      have r : w=z ∨ w=y := by simpa [two] using q
      rcases r with rfl|rfl
      · exact (G.loopless _ e).elim
      · rw [dist_eq_one_iff_adj.mpr by'] at bL
        omega
    · have h := (common w (mem_filter.mpr ⟨wd,k⟩)).2
      rw [dist_eq_one_iff_adj.mpr h] at bL
      omega
  have low := (card_le_card sub).trans eb
  rw [card_neighborFinset_eq_degree] at low
  have hi := high z zd
  omega

#print axioms singleton_multi_all_b_odd_literal

private theorem literal_port_classes_from_terminal_three
    (hc : G.Connected) (ab : G.Adj a b) {D : Cmp G a b}
    (a3 : 3≤((Shore D).filter (G.Adj a)).card)
    (oa : (classSet D 3).card=2) (oc : (classSet D 5).card=1) :
    (∀ z∈classSet D 3,G.Adj a z) ∧ (∀ z∈classSet D 5,G.Adj a z ∧ G.Adj b z) := by
  classical
  let T := (Shore D).filter (G.Adj a)
  have sub : T⊆classSet D 3∪classSet D 5 := by
    intro w wm
    obtain ⟨wd,aw⟩ := mem_filter.mp wm
    have wb : w≠b := fun e=>(shore_off D).2 (e ▸ wd)
    rcases key_a_port hc ab wb aw with k|k
    · exact mem_union_left _ (mem_filter.mpr ⟨wd,k⟩)
    · exact mem_union_right _ (mem_filter.mpr ⟨wd,k⟩)
  have cap := card_union_le (classSet D 3) (classSet D 5)
  rw [oa,oc] at cap
  have eq := eq_of_subset_of_card_le sub (cap.trans a3)
  constructor
  · intro z zm
    have zt : z∈T := eq ▸ mem_union_left _ zm
    exact (mem_filter.mp zt).2
  · intro z zm
    have zt : z∈T := eq ▸ mem_union_right _ zm
    have az := (mem_filter.mp zt).2
    obtain ⟨dA,dB,_⟩ := key_facts hc ab z
    rw [(mem_filter.mp zm).2] at dA dB
    change G.dist a z=depth G a b z+0 at dA
    change G.dist b z=depth G a b z+0 at dB
    exact ⟨az,dist_eq_one_iff_adj.mp (dB.trans (dA.symm.trans (dist_eq_one_iff_adj.mpr az)))⟩

#print axioms literal_port_classes_from_terminal_three
private theorem left_even_depth_two_with_literal_odd
    (hc : G.Connected) (ab : G.Adj a b) {D : Cmp G a b}
    (literal : ∀ w∈classSet D 3,G.Adj a w)
    {z : V} (zd : z∈Shore D) (k : key G a b z=0) :
    G.dist a z=2 := by
  classical
  have za : z≠a := fun e=>(shore_off D).1 (e ▸ zd)
  have zb : z≠b := fun e=>(shore_off D).2 (e ▸ zd)
  have p := hc.pos_dist_of_ne (u:=a) (v:=z) za.symm
  obtain ⟨az,bz,ez⟩ := key_facts hc ab z
  rw [k] at az bz ez
  change _=depth G a b z+0 at az
  change _=depth G a b z+1 at bz
  change _%2=0 at ez
  by_contra not2
  have large : 4≤G.dist a z := by omega
  have zr : 0<G.dist z a := by rwa [dist_comm]
  obtain ⟨w,zw,hw⟩ := predecessor_of_positive_dist hc zr
  have wd : w∈Shore D := by
    rcases shore_closed D z zd w zw with h|h|h
    · have d := dist_eq_one_iff_adj.mpr zw.symm
      rw [h] at d
      omega
    · have d := dist_eq_one_iff_adj.mpr zw.symm
      rw [h] at d
      omega
    · exact h
  rw [dist_comm (G:=G) (u:=z) (v:=a),dist_comm (G:=G) (u:=w) (v:=a)] at hw
  have u := hc.dist_triangle (u:=b) (v:=w) (w:=z)
  rw [dist_eq_one_iff_adj.mpr zw.symm] at u
  have nearer : G.dist a w<G.dist b w := by omega
  have odd : ¬Even (G.dist a w) := by rw [Nat.even_iff]; omega
  have wk : key G a b w=3 := by simp [key,nearer,odd]
  have one := dist_eq_one_iff_adj.mpr (literal w (mem_filter.mpr ⟨wd,wk⟩))
  omega

#print axioms left_even_depth_two_with_literal_odd
private theorem right_even_depth_two_with_literal_odd
    (hc : G.Connected) (ab : G.Adj a b) {D : Cmp G a b}
    (literal : ∀ w∈classSet D 4,G.Adj b w)
    {z : V} (zd : z∈Shore D) (k : key G a b z=1) :
    G.dist b z=2 := by
  classical
  have za : z≠a := fun e=>(shore_off D).1 (e ▸ zd)
  have zb : z≠b := fun e=>(shore_off D).2 (e ▸ zd)
  have p := hc.pos_dist_of_ne (u:=b) (v:=z) zb.symm
  obtain ⟨az,bz,ez⟩ := key_facts hc ab z
  rw [k] at az bz ez
  change _=depth G a b z+1 at az
  change _=depth G a b z+0 at bz
  change _%2=0 at ez
  by_contra not2
  have large : 4≤G.dist b z := by omega
  have zr : 0<G.dist z b := by rwa [dist_comm]
  obtain ⟨w,zw,hw⟩ := predecessor_of_positive_dist hc zr
  have wd : w∈Shore D := by
    rcases shore_closed D z zd w zw with h|h|h
    · have d := dist_eq_one_iff_adj.mpr zw.symm
      rw [h] at d
      omega
    · have d := dist_eq_one_iff_adj.mpr zw.symm
      rw [h] at d
      omega
    · exact h
  rw [dist_comm (G:=G) (u:=z) (v:=b),dist_comm (G:=G) (u:=w) (v:=b)] at hw
  have u := hc.dist_triangle (u:=a) (v:=w) (w:=z)
  rw [dist_eq_one_iff_adj.mpr zw.symm] at u
  have nearer : G.dist b w<G.dist a w := by omega
  have nrev : ¬G.dist a w<G.dist b w := by omega
  have odd : ¬Even (G.dist b w) := by rw [Nat.even_iff]; omega
  have wk : key G a b w=4 := by simp [key,nrev,nearer,odd]
  have one := dist_eq_one_iff_adj.mpr (literal w (mem_filter.mpr ⟨wd,wk⟩))
  omega

#print axioms right_even_depth_two_with_literal_odd

private theorem singleton_even_cohort_ports
    (hc : G.Connected) (ab : G.Adj a b) {D : Cmp G a b}
    (la : ∀ w∈classSet D 3,G.Adj a w)
    (lb : ∀ w∈classSet D 4,G.Adj b w) :
    (∀ w∈classSet D 0,G.dist a w=2 ∧ G.dist b w=3 ∧ ∃ x∈classSet D 3,G.Adj x w) ∧
    (∀ w∈classSet D 1,G.dist a w=3 ∧ G.dist b w=2 ∧ ∃ y∈classSet D 4,G.Adj y w) := by
  classical
  constructor
  · intro w wm
    obtain ⟨wd,k⟩ := mem_filter.mp wm
    have da := left_even_depth_two_with_literal_odd hc ab la wd k
    obtain ⟨p,q,_⟩ := key_facts hc ab w
    rw [k] at p q
    change G.dist a w=depth G a b w+0 at p
    change G.dist b w=depth G a b w+1 at q
    have db : G.dist b w=3 := by omega
    refine ⟨da,db,?_⟩
    have wd' : w∈Shore (swapCut D) := by rw [shore_swapCut D]; exact wd
    obtain ⟨t,tm,_,_,tw⟩ := right_even_has_actual_b_port hc ab.symm wd' db da
    rw [classSet_swap] at tm
    exact ⟨t,tm,tw⟩
  · intro w wm
    obtain ⟨wd,k⟩ := mem_filter.mp wm
    have db := right_even_depth_two_with_literal_odd hc ab lb wd k
    obtain ⟨p,q,_⟩ := key_facts hc ab w
    rw [k] at p q
    change G.dist a w=depth G a b w+1 at p
    change G.dist b w=depth G a b w+0 at q
    have da : G.dist a w=3 := by omega
    obtain ⟨t,tm,_,_,tw⟩ := right_even_has_actual_b_port hc ab wd da db
    exact ⟨da,db,t,tm,tw⟩

#print axioms singleton_even_cohort_ports
end Graffiti189LongestPath.CrossSaturation.FiveAdjacent
