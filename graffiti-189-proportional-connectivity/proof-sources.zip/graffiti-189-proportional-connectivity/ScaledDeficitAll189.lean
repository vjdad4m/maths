import ForeignPorts189
import TwoShoreTight189
import ShoreConnectivity189
import DeficitThreeAll189
import ExactStarShore189
import PosaOneLow189
import FanWeighted189
import MengerRoutable189
import SingleHeight189
import StarCycleClosure189
import Mathlib.Tactic.Ring

-- SOURCE ScaledHall189.lean
open Finset SimpleGraph Graffiti189LongestPath
open Graffiti189LongestPath.ForeignPorts
open private Graffiti189LongestPath.mem_distanceTwo Graffiti189LongestPath.dist_two
  Graffiti189LongestPath.boundary_card_of_connectivity from SmallSeparator189
set_option warningAsError true
namespace Graffiti189LongestPath.ScaledHall
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

omit [Fintype V] in
theorem hall_with_cut_deficit (k loss : Nat) (A B S : Finset V)
    (conn : ∀ T : Finset V, T.card < k → (G.induce ((↑T : Set V)ᶜ)).Connected)
    (dis : Disjoint A B) (exactB : B.card≤k+loss) (ss : S⊆B)
    {z : V} (za : z∉A) (zb : z∉B)
    (boundary : ∀ x∈A,∀ y∉A,G.Adj x y → y∈B) :
    min A.card (S.card-loss) ≤ (shoreNeighbors G A S).card := by
  classical
  let N := shoreNeighbors G A S
  apply Nat.le_of_not_gt
  intro h
  have hA : N.card < A.card := h.trans_le (min_le_left _ _)
  have hS : N.card < S.card-loss := h.trans_le (min_le_right _ _)
  have sub : N⊆A := filter_subset _ _
  have nl : (A\N).Nonempty := card_pos.mp (by have c := card_sdiff_add_card_eq_card sub; omega)
  obtain ⟨u,hu⟩ := nl
  let B' := (B\S)∪N
  have vd : z∉A\N := fun h => za (mem_sdiff.mp h).1
  have vb : z∉B' := fun h => (mem_union.mp h).elim (fun h => zb (mem_sdiff.mp h).1)
    (fun h => za (sub h))
  have d : Disjoint (A\N) B' := disjoint_left.mpr (by
    intro a ha hb
    exact (mem_union.mp hb).elim
      (fun h => disjoint_left.mp dis (mem_sdiff.mp ha).1 (mem_sdiff.mp h).1)
      (mem_sdiff.mp ha).2)
  have bound : ∀ a∈A\N,∀ b∉A\N,G.Adj a b → b∈B' := by
    intro a ha b hb e
    by_cases ba : b∈A
    · exact mem_union.mpr (Or.inr (Classical.byContradiction (fun h => hb (mem_sdiff.mpr ⟨ba,h⟩))))
    have bb := boundary a (mem_sdiff.mp ha).1 b ba e
    have bs : b∉S := fun h => (mem_sdiff.mp ha).2 (mem_filter.mpr ⟨(mem_sdiff.mp ha).1,b,h,e.symm⟩)
    exact mem_union.mpr (Or.inl (mem_sdiff.mpr ⟨bb,bs⟩))
  have lo := Graffiti189LongestPath.boundary_card_of_connectivity k conn hu vd vb d bound
  have hi := card_union_le (B\S) N
  have sz := card_sdiff_add_card_eq_card ss
  change k≤((B\S)∪N).card at lo
  omega


#print axioms hall_with_cut_deficit
end Graffiti189LongestPath.ScaledHall

-- SOURCE ScaledCharge189.lean
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.ScaledHall Graffiti189LongestPath.TruncatedHall Graffiti189LongestPath.ForeignPorts
open private Graffiti189LongestPath.mem_distanceTwo Graffiti189LongestPath.dist_two from SmallSeparator189
set_option warningAsError true
set_option maxHeartbeats 2000000
namespace Graffiti189LongestPath.ScaledCharge
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- All distance-two cut vertices are charged explicitly alongside
the internal nonneighbors and opposite-shore Hall destinations. -/
theorem shore_charge_with_cut_deficit (hc : G.Connected) (d k loss : Nat) (A U B : Finset V)
    (conn : ∀ S : Finset V, S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (exactB : B.card≤k+loss) (ab : Disjoint A B) (ub : Disjoint U B)
    (au : Disjoint A U)
    (large : k≤U.card)
    (closedA : ∀ x∈A,∀ y∉A,G.Adj x y → y∈B)
    (closedU : ∀ x∈U,∀ y∉U,G.Adj x y → y∈B)
    (cap : ∀ v, (DistanceTwo G v).card≤d)
    {r : V} (root : ∀ v∈A, v=r ∨ G.Adj r v)
    (a : ↥(A : Set V)) :
    A.card+G.degree a.val+((DistanceTwo G a.val)∩B).card ≤
      2*(G.induce (A : Set V)).degree a+d+loss+1 := by
  classical
  let J := G.induce (A : Set V)
  let S := B.filter (G.Adj a.val)
  let T := A.filter (fun b => b≠a.val ∧ ¬G.Adj a.val b)
  let NU := shoreNeighbors G U S
  have aB : a.val∉B := fun e => disjoint_left.mp ab a.property e
  have aU : a.val∉U := fun e => disjoint_left.mp au a.property e
  have haveU := hall_with_cut_deficit k loss U B S conn ub exactB (filter_subset _ _) aU aB closedU
  change min U.card (S.card-loss)≤NU.card at haveU
  have spend (C : Finset V) (na : a.val∉C)
      (closed : ∀ x∈C,∀ y∉C,G.Adj x y → y∈B) :
      shoreNeighbors G C S ⊆ DistanceTwo G a.val := by
    intro z hz
    obtain ⟨zc,s,ss,sz⟩ := mem_filter.mp hz
    have ne : a.val≠z := fun e => na (e.symm ▸ zc)
    have no : ¬G.Adj a.val z := fun e => aB (closed z zc a.val na e.symm)
    exact Graffiti189LongestPath.mem_distanceTwo.mpr
      (Graffiti189LongestPath.dist_two hc ne no (mem_filter.mp ss).2 sz)
  have spendT : T ⊆ DistanceTwo G a.val := by
    intro z hz
    obtain ⟨za,zne,no⟩ := mem_filter.mp hz
    rcases root a.val a.property with h|h
    · rcases root z za with eq|e
      · exact (zne (eq.trans h.symm)).elim
      · exact (no (h.symm ▸ e)).elim
    · rcases root z za with eq|e
      · exact (no (eq.symm ▸ h.symm)).elim
      · exact Graffiti189LongestPath.mem_distanceTwo.mpr
          (Graffiti189LongestPath.dist_two hc zne.symm no h.symm e)
  have dst : Disjoint NU T := disjoint_left.mpr (fun _ u t =>
    disjoint_left.mp au (mem_filter.mp t).1 (mem_filter.mp u).1)
  let R := (DistanceTwo G a.val)∩B
  have bn : Disjoint (NU∪T) R := disjoint_left.mpr (by
    intro z h hz
    have zb := (mem_inter.mp hz).2
    exact (mem_union.mp h).elim
      (fun hu => disjoint_left.mp ub (mem_filter.mp hu).1 zb)
      (fun ht => disjoint_left.mp ab (mem_filter.mp ht).1 zb))
  have sub : (NU∪T)∪R ⊆ DistanceTwo G a.val :=
    union_subset (union_subset (spend U aU closedU) spendT) inter_subset_left
  have spent := card_le_card sub
  rw [card_union_of_disjoint bn,card_union_of_disjoint dst] at spent
  have cc := cap a.val
  have sz := card_filter_le B (G.Adj a.val)
  change S.card≤B.card at sz
  rw [min_eq_right (by omega : S.card-loss≤U.card)] at haveU
  let N := A.filter (G.Adj a.val)
  have ncard : N.card=J.degree a := by
    rw [← J.card_neighborFinset_eq_degree]
    refine card_bij' (fun v hv => (⟨v,(mem_filter.mp hv).1⟩ : ↥(A : Set V)))
      (fun v _ => v.val) ?_ ?_ ?_ ?_
    · intro v hv
      exact (J.mem_neighborFinset a _).mpr (mem_filter.mp hv).2
    · intro v hv
      exact mem_filter.mpr ⟨v.property,(J.mem_neighborFinset a v).mp hv⟩
    · intro v hv; rfl
    · intro v hv; exact Subtype.ext rfl
  have outside : G.degree a.val≤J.degree a+S.card := by
    have cover : G.neighborFinset a.val ⊆ N∪S := by
      intro z hz
      have ed := (G.mem_neighborFinset a.val z).mp hz
      by_cases az : z∈A
      · exact mem_union.mpr (Or.inl (mem_filter.mpr ⟨az,ed⟩))
      · exact mem_union.mpr (Or.inr (mem_filter.mpr ⟨closedA a.val a.property z az ed,ed⟩))
    have c := card_le_card cover
    rw [G.card_neighborFinset_eq_degree] at c
    have b := card_union_le N S
    omega
  have inside : A.card≤J.degree a+T.card+1 := by
    have cover : A⊆insert a.val (N∪T) := by
      intro z hz
      by_cases e : z=a.val
      · exact mem_insert.mpr (Or.inl e)
      by_cases ed : G.Adj a.val z
      · exact mem_insert.mpr (Or.inr (mem_union.mpr (Or.inl (mem_filter.mpr ⟨hz,ed⟩))))
      · exact mem_insert.mpr (Or.inr (mem_union.mpr (Or.inr (mem_filter.mpr ⟨hz,e,ed⟩))))
    have c := card_le_card cover
    have b := card_insert_le a.val (N∪T)
    have q := card_union_le N T
    omega
  change A.card+G.degree a.val+R.card≤2*J.degree a+d+loss+1
  have cc' : (DistanceTwo G a.val).card≤d := cc
  omega

#print axioms shore_charge_with_cut_deficit
end Graffiti189LongestPath.ScaledCharge

-- SOURCE ScaledWideCut189.lean
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.ScaledCharge
open private Graffiti189LongestPath.boundary_card_of_connectivity
  Graffiti189LongestPath.mem_distanceTwo Graffiti189LongestPath.dist_two from SmallSeparator189
set_option warningAsError true
set_option maxHeartbeats 3000000
namespace Graffiti189LongestPath.ScaledWideCut
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- For a shore cut X, a side C of size t with no other internal external
edges must be empty when 2|X|+t+2<|A|. Consequently the
smaller side of any shore cut of size s is empty if 3s+4<|A|. -/
theorem scaled_small_shore_side (hc : G.Connected) (k sl : Nat) (positive : 1≤sl)
    (A B U C X : Finset V) (x : V)
    (conn : ∀ D : Finset V,D.card<k → (G.induce ((↑D : Set V)ᶜ)).Connected)
    (exactB : B.card≤k+(sl-1)) (ab : Disjoint A B) (ub : Disjoint U B)
    (au : Disjoint A U) (large : k≤U.card) (_kp : 0<k)
    (closedA : ∀ u∈A,∀ v∉A,G.Adj u v → v∈B)
    (closedU : ∀ u∈U,∀ v∉U,G.Adj u v → v∈B)
    (cap : ∀ v,(DistanceTwo G v).card≤k+sl)
    (root : ∀ v∈A,v=x ∨ G.Adj x v)
    (CA : C⊆A) (XA : X⊆A) (dis : Disjoint C X)
    (inside : ∀ u∈C,∀ v∈A,G.Adj u v → v∈C∪X)
    (small : 2*X.card+C.card+2*sl<A.card) :
    C=∅ := by
  classical
  apply eq_empty_iff_forall_not_mem.mpr
  intro v vc
  let j : ↥(A : Set V) := ⟨v,CA vc⟩
  let J := G.induce (A : Set V)
  let N := (J.neighborFinset j).image Subtype.val
  let Q := C.filter (G.Adj v)
  let Z := (G.neighborFinset v).filter (fun z => z∉A)
  let R := (DistanceTwo G v)∩B
  let W := insert v Q
  let D := ((X∪(C\W))∪Z)∪R
  have f (z : V) : z∈N ↔ z∈A ∧ G.Adj v z := by
    constructor
    · intro hz
      obtain ⟨w,hw,rfl⟩ := mem_image.mp hz
      exact ⟨w.property,(J.mem_neighborFinset _ _).mp hw⟩
    · rintro ⟨za,ed⟩
      exact mem_image.mpr ⟨⟨z,za⟩,(J.mem_neighborFinset _ _).mpr ed,rfl⟩
  have ncard : N.card=J.degree j := by
    rw [←J.card_neighborFinset_eq_degree,card_image_of_injective _ Subtype.val_injective]
  have into : N⊆Q∪X := by
    intro z zn
    obtain ⟨za,ed⟩ := (f z).mp zn
    rcases mem_union.mp (inside v vc z za ed) with zc|zx
    · exact mem_union.mpr (Or.inl (mem_filter.mpr ⟨zc,ed⟩))
    · exact mem_union.mpr (Or.inr zx)
  have nupper := (card_le_card into).trans (card_union_le Q X)
  have nz : N∪Z=G.neighborFinset v := by
    ext z
    rw [mem_union,f,mem_filter,G.mem_neighborFinset]
    by_cases q : z∈A <;> simp [q]
  have nd : Disjoint N Z := disjoint_left.mpr (fun _ h h' => (mem_filter.mp h').2 ((f _).mp h).1)
  have cost := congrArg Finset.card nz
  rw [card_union_of_disjoint nd,ncard,G.card_neighborFinset_eq_degree] at cost
  have ch := shore_charge_with_cut_deficit hc (k+sl) k (sl-1) A U B conn exactB ab ub au large
    closedA closedU cap root j
  change A.card+G.degree v+R.card≤2*J.degree j+(k+sl)+(sl-1)+1 at ch
  have ws : W⊆C := by
    intro z zw
    rcases mem_insert.mp zw with rfl|hz
    · exact vc
    · exact (mem_filter.mp hz).1
  have wSize : W.card=Q.card+1 := card_insert_of_not_mem (fun h => (G.loopless v) (mem_filter.mp h).2)
  have how : (C\W).card+W.card=C.card := card_sdiff_add_card_eq_card ws
  have d1 := card_union_le X (C\W)
  have d2 := card_union_le (X∪(C\W)) Z
  have d3 := card_union_le ((X∪(C\W))∪Z) R
  have dc : D.card<k := by
    dsimp only [D]
    omega
  have nb (z : V) (zb : z∈B) : z∉A := fun h => disjoint_left.mp ab h zb
  have zB (z : V) (zz : z∈Z) : z∈B := by
    obtain ⟨a,b⟩ := mem_filter.mp zz
    exact closedA v (CA vc) z b ((G.mem_neighborFinset _ _).mp a)
  have wd : Disjoint W D := disjoint_left.mpr (by
    intro z zw h
    rw [show D=((X∪(C\W))∪Z)∪R from rfl] at h
    rcases mem_union.mp h with h|h
    · rcases mem_union.mp h with h|h
      · rcases mem_union.mp h with h|h
        · exact disjoint_left.mp dis (ws zw) h
        · exact (mem_sdiff.mp h).2 zw
      · exact nb z (zB z h) (CA (ws zw))
    · exact nb z (mem_inter.mp h).2 (CA (ws zw)))
  obtain ⟨u,uu⟩ := card_pos.mp (by omega : 0<U.card)
  have ua : u∉A := fun h => disjoint_left.mp au h uu
  have ub' : u∉B := fun h => disjoint_left.mp ub uu h
  have uw : u∉W := fun h => ua (CA (ws h))
  have ud : u∉D := by
    intro h
    rcases mem_union.mp h with h|h
    · rcases mem_union.mp h with h|h
      · rcases mem_union.mp h with h|h
        · exact ua (XA h)
        · exact ua (CA (mem_sdiff.mp h).1)
      · exact ub' (zB u h)
    · exact ub' (mem_inter.mp h).2
  have bd : ∀ u∈W,∀ z∉W,G.Adj u z → z∈D := by
    intro w ww z zw ed
    by_cases za : z∈A
    · rcases mem_union.mp (inside w (ws ww) z za ed) with zc|zx
      · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inl
          (mem_union.mpr (Or.inr (mem_sdiff.mpr ⟨zc,zw⟩))))))
      · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inl (mem_union.mpr (Or.inl zx)))))
    have zb := closedA w (CA (ws ww)) z za ed
    by_cases vz : G.Adj v z
    · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inr
        (mem_filter.mpr ⟨(G.mem_neighborFinset _ _).mpr vz,za⟩))))
    rcases mem_insert.mp ww with e|q
    · exact (vz (e ▸ ed)).elim
    · have ve : v≠z := fun e => za (e ▸ CA vc)
      exact mem_union.mpr (Or.inr (mem_inter.mpr ⟨Graffiti189LongestPath.mem_distanceTwo.mpr
        (Graffiti189LongestPath.dist_two hc ve vz (mem_filter.mp q).2 ed),zb⟩))
  have vk := Graffiti189LongestPath.boundary_card_of_connectivity k conn
    (mem_insert_self v Q) uw ud wd bd
  exact (not_lt_of_ge vk) dc

/-- No shore cut of size s with 3s+4<|A| separates any two vertices. -/
theorem scaled_shore_cut_no_split (hc : G.Connected) (k sl : Nat) (positive : 1≤sl)
    (A B U X C E : Finset V) (x : V)
    (conn : ∀ D : Finset V,D.card<k → (G.induce ((↑D : Set V)ᶜ)).Connected)
    (exactB : B.card≤k+(sl-1)) (ab : Disjoint A B) (ub : Disjoint U B)
    (au : Disjoint A U) (large : k≤U.card) (kp : 0<k)
    (closedA : ∀ u∈A,∀ v∉A,G.Adj u v → v∈B)
    (closedU : ∀ u∈U,∀ v∉U,G.Adj u v → v∈B)
    (cap : ∀ v,(DistanceTwo G v).card≤k+sl)
    (root : ∀ v∈A,v=x ∨ G.Adj x v)
    (XA : X⊆A) (part : C∪E=A\X) (dis : Disjoint C E)
    (no : ∀ u∈C,∀ v∈E,¬G.Adj u v)
    (small : 3*X.card+4*sl<A.card) :
    C=∅ ∨ E=∅ := by
  classical
  have cc : C⊆A\X := fun _ h => part ▸ mem_union.mpr (Or.inl h)
  have ec : E⊆A\X := fun _ h => part ▸ mem_union.mpr (Or.inr h)
  have sz := congrArg Finset.card part
  rw [card_union_of_disjoint dis] at sz
  have eq := card_sdiff_add_card_eq_card XA
  by_cases e : C.card≤E.card
  · left
    apply scaled_small_shore_side hc k sl positive A B U C X x conn exactB ab ub au large kp
      closedA closedU cap root (fun _ h => (mem_sdiff.mp (cc h)).1) XA
      (disjoint_left.mpr (fun _ h h' => (mem_sdiff.mp (cc h)).2 h')) ?_ (by omega)
    intro u uc v va uv
    by_cases vx : v∈X
    · exact mem_union.mpr (Or.inr vx)
    have vce : v∈C∪E := part.symm ▸ mem_sdiff.mpr ⟨va,vx⟩
    exact (mem_union.mp vce).elim (fun h => mem_union.mpr (Or.inl h))
      (fun h => (no u uc v h uv).elim)
  · right
    apply scaled_small_shore_side hc k sl positive A B U E X x conn exactB ab ub au large kp
      closedA closedU cap root (fun _ h => (mem_sdiff.mp (ec h)).1) XA
      (disjoint_left.mpr (fun _ h h' => (mem_sdiff.mp (ec h)).2 h')) ?_ (by omega)
    intro u ue v va uv
    by_cases vx : v∈X
    · exact mem_union.mpr (Or.inr vx)
    have vce : v∈C∪E := part.symm ▸ mem_sdiff.mpr ⟨va,vx⟩
    exact (mem_union.mp vce).elim (fun h => (no v h u ue uv.symm).elim)
      (fun h => mem_union.mpr (Or.inl h))

#print axioms scaled_small_shore_side
#print axioms scaled_shore_cut_no_split
end Graffiti189LongestPath.ScaledWideCut

-- SOURCE ScaledConnectivity189.lean
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.ScaledWideCut Graffiti189LongestPath.ShoreConnectivity
set_option warningAsError true
namespace Graffiti189LongestPath.ScaledConnectivity
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem scaled_shore_stays_connected (hc : G.Connected) (k sl : Nat) (positive : 1≤sl)
    (A B U X : Finset V) (x : V)
    (conn : ∀ D : Finset V,D.card<k → (G.induce ((↑D : Set V)ᶜ)).Connected)
    (exactB : B.card≤k+(sl-1)) (ab : Disjoint A B) (ub : Disjoint U B)
    (au : Disjoint A U) (large : k≤U.card) (kp : 0<k)
    (closedA : ∀ u∈A,∀ v∉A,G.Adj u v → v∈B)
    (closedU : ∀ u∈U,∀ v∉U,G.Adj u v → v∈B)
    (cap : ∀ v,(DistanceTwo G v).card≤k+sl)
    (root : ∀ v∈A,v=x ∨ G.Adj x v)
    (xa : X⊆A) (small : 3*X.card+4*sl<A.card) :
    (G.induce ((↑(A\X)):Set V)).Connected := by
  have h := card_sdiff_add_card_eq_card xa
  apply connected_of_no_partition _ (card_pos.mp (by omega))
  exact fun C E part dis no => scaled_shore_cut_no_split hc k sl positive A B U X C E x conn
    exactB ab ub au large kp closedA closedU cap root xa part dis no small

#print axioms scaled_shore_stays_connected
end Graffiti189LongestPath.ScaledConnectivity

-- SOURCE ScaledActive189.lean
open SimpleGraph SimpleGraph.Walk Finset Graffiti189LongestPath
open Graffiti189LongestPath.Normalize Graffiti189LongestPath.OneSlack Graffiti189LongestPath.Rigidity Graffiti189LongestPath.PinRun
open Graffiti189LongestPath.ActiveStarHeight
open private Graffiti189LongestPath.GapTwin.splice_gap_two_allow_midpoint from GapTwin189
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
open private Graffiti189LongestPath.OneSlack.cardinal_flankVertices
  Graffiti189LongestPath.OneSlack.first_eq_if_no_pair from OneSlack189
open private Graffiti189LongestPath.outside_edge Graffiti189LongestPath.boundary_card_of_connectivity
  Graffiti189LongestPath.pin_data Graffiti189LongestPath.no_endpoints from SmallSeparator189
open private Graffiti189LongestPath.OneSlack.pin_of_neighbor_mem from OneSlack189
set_option warningAsError true
set_option linter.unusedSectionVars false

open Graffiti189LongestPath.DeficitActive
namespace Graffiti189LongestPath.ScaledActive
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem scaled_deficit_not_one_omitted (hc : G.Connected) (k sl : Nat) (hk : sl+1≤k) (_kp : 2≤k)
    (cap : ∀ z,(EvenFrom G z).card≤k+sl+1)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → k+sl≤G.degree u ∨ k+sl≤G.degree v)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support) :
    ∃ y,y∉p.support ∧ y≠x := by
  classical
  by_contra no
  have sole (y : V) (hy : y∉p.support) : y=x :=
    Classical.byContradiction (fun e => no ⟨y,hy,e⟩)
  have ne : a≠x := fun e => hx (e ▸ p.start_mem_support)
  have enough := enough_vertices_of_degree (k+sl) deg ne
  have floor := degree_floor_when_enough_vertices k conn (by omega) x
  have high_impossible {u v y : V} {q : G.Walk u v} (hq : IsLongest q) (hy : y∉q.support)
      (other : ∀ z,z∉q.support → z=y) : ¬k+sl≤G.degree y := by
    intro yd
    have eq : OmittedStar q y={y} := by
      ext z
      rw [Graffiti189LongestPath.Rigidity.mem_omittedStar,mem_singleton]
      exact ⟨fun z => other _ z.1,fun e => ⟨e.symm ▸ hy,Or.inl e⟩⟩
    have count := star_card_degree_and_pins hq hy
    rw [eq,card_singleton] at count
    obtain ⟨i,hi⟩ := card_pos.mp (by omega : 0<(Pins q y).card)
    have th := high_omitted_pin_budget hc (k+sl) k cap conn hq hy
      (Graffiti189LongestPath.pin_data hi).2 yd
    omega
  have low := high_impossible hp hx sole
  have st : OmittedStar p x={x} := by
    ext z
    rw [Graffiti189LongestPath.Rigidity.mem_omittedStar,mem_singleton]
    exact ⟨fun z => sole _ z.1,fun e => ⟨e.symm ▸ hx,Or.inl e⟩⟩
  have nPins := star_card_degree_and_pins hp hx
  rw [st,card_singleton] at nPins
  have nonempty : (PairedPins p x).Nonempty := by
    by_contra h
    have e : PairedPins p x=∅ := not_nonempty_iff_eq_empty.mp h
    have f : (FlankVertices p x).card=2*(Pins p x).card := by
      rw [Graffiti189LongestPath.OneSlack.cardinal_flankVertices hp,flank_count_exact hp hx,
        Graffiti189LongestPath.OneSlack.first_eq_if_no_pair (p:=p) e]
      omega
    have s : FlankVertices p x⊆DistanceTwo G x :=
      (flanks_outside_boundary hc hp hx).trans sdiff_subset
    have c := (card_le_card s).trans (distanceTwo_le_of_even (k+sl) x (cap x))
    omega
  obtain ⟨j,hj⟩ := nonempty
  obtain ⟨jp,i,ip,step⟩ := mem_filter.mp hj
  have two : ∃ t∈Pins p x,t+2∈Pins p x := by
    rcases step with step|step
    · exact ⟨i,ip,step.symm ▸ jp⟩
    · exact ⟨j,jp,step.symm ▸ ip⟩
  obtain ⟨t,tp,tq⟩ := two
  have ir := (Graffiti189LongestPath.pin_data tq).1
  have ht : t+1<p.length := by omega
  have h0 := (Graffiti189LongestPath.pin_data tp).2
  have h2 := (Graffiti189LongestPath.pin_data tq).2
  obtain ⟨q,qP,ql,qs⟩ := Graffiti189LongestPath.GapTwin.splice_gap_two_allow_midpoint p hp.1
    (.nil : G.Walk x x) (by simp [isPath_def]) t (fun z hz hp' => by simp at hz; exact (hx (hz ▸ hp')).elim)
    ht h0.symm h2
  let y := p.getVert (t+1)
  have yp : y∈p.support := p.getVert_mem_support _
  have xy : x≠y := fun e => hx (e ▸ yp)
  have yh := (deg x y xy).resolve_left low
  have yq : y∉q.support := fun e => ((qs y).mp e).elim
    (fun h => by simp at h; exact xy h.symm) (fun h => h.2 rfl)
  have so (z : V) (zo : z∉q.support) : z=y := by
    have zx : z≠x := fun e => zo ((qs z).mpr (Or.inl (by simp [e])))
    have zp : z∈p.support := Classical.byContradiction (fun e => zx (sole _ e))
    exact Classical.byContradiction (fun e => zo ((qs z).mpr (Or.inr ⟨zp,e⟩)))
  have ql' : q.length=p.length := by simpa using ql
  have hq : IsLongest q := ⟨qP,fun u v s hs => (hp.2 u v s hs).trans (le_of_eq ql'.symm)⟩
  exact (high_impossible hq yq so yh)

/-- A nonspanning longest path in the first slack regime always has a
high-degree omitted vertex that directly attaches to the path. -/
theorem scaled_deficit_has_high_active (hc : G.Connected) (k sl : Nat) (hk : sl+1≤k) (kp : 2≤k)
    (cap : ∀ v, (EvenFrom G v).card ≤ k+sl+1)
    (conn : ∀ S : Finset V, S.card < k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (deg : ∀ u v : V, u ≠ v → k+sl ≤ G.degree u ∨ k+sl ≤ G.degree v)
    {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    (nonspan : ∃ x, x ∉ p.support) :
    ∃ x, x ∉ p.support ∧ k+sl ≤ G.degree x ∧ (Pins p x).Nonempty := by
  classical
  obtain ⟨x,hx,y,hy,ex⟩ := Graffiti189LongestPath.outside_edge p hc nonspan
  by_contra hNo
  have low {u v : V} (hu : u ∉ p.support) (hv : v ∈ p.support) (e : G.Adj u v) :
      G.degree u < k+sl := by
    by_contra! h
    obtain ⟨i,hi,_⟩ := Graffiti189LongestPath.OneSlack.pin_of_neighbor_mem hp hu hv e
    exact hNo ⟨u,hu,h,i,hi⟩
  have lowx := low hx hy ex
  obtain ⟨z,hz,ne⟩ := scaled_deficit_not_one_omitted hc k sl hk kp cap conn deg hp hx
  let A : Finset V := univ.filter (fun u => u ∉ p.support ∧ u ≠ x)
  have ha (u : V) : u ∈ A ↔ u ∉ p.support ∧ u ≠ x := by simp [A]
  have zal : z ∈ A := (ha z).mpr ⟨hz,ne⟩
  have aa : a ∉ A := fun h => ((ha _).mp h).1 p.start_mem_support
  have ab : a ∉ ({x}:Finset V) := by
    rw [mem_singleton]
    exact fun e => hx (e ▸ p.start_mem_support)
  have dis : Disjoint A ({x}:Finset V) := disjoint_left.mpr (fun u hu hv =>
    ((ha u).mp hu).2 (mem_singleton.mp hv))
  have bnd : ∀ u ∈ A, ∀ v ∉ A, G.Adj u v → v ∈ ({x}:Finset V) := by
    intro u hu v hv e
    by_cases h : v = x
    · exact mem_singleton.mpr h
    have vOn : v ∈ p.support := by
      by_contra hn
      exact hv ((ha v).mpr ⟨hn,h⟩)
    have hLow := low ((ha u).mp hu).1 vOn e
    rcases deg u x ((ha u).mp hu).2 with h|h <;> omega
  have hc' := Graffiti189LongestPath.boundary_card_of_connectivity k conn zal aa ab dis bnd
  simp at hc'
  omega

#print axioms scaled_deficit_has_high_active
end Graffiti189LongestPath.ScaledActive

-- SOURCE ScaledDonors189.lean
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.DeficitThirdShell
open private Graffiti189LongestPath.mem_distanceTwo Graffiti189LongestPath.dist_two from SmallSeparator189
open private Graffiti189LongestPath.Rigidity.mem_external Graffiti189LongestPath.Rigidity.mem_omittedStar from Rigidity189
open private Graffiti189LongestPath.OneSlack.boundary_except_pins_two Graffiti189LongestPath.OneSlack.card_pinVertices from OneSlack189
set_option warningAsError true
set_option maxHeartbeats 6000000
namespace Graffiti189LongestPath.ScaledDonors
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem scaled_donor_shell_upper (hc : G.Connected) (k sl : Nat) (hk : 28*sl+20≤k) (positive : 1≤sl)
    (cap : ∀ v,(DistanceTwo G v).card≤k+sl)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
    (hc3 : (Pins p x).card≤sl)
    (floor : ∀ v : ↥((OmittedStar p x : Finset V) : Set V),
      (OmittedStar p x).card≤2*(G.induce (OmittedStar p x : Set V)).degree v+2*sl)
    (small : (OmittedStar p x).card≤k+4*sl+2) :
    (Shell G x 3).card≤(k-2*sl-3)*(k+sl) ∨
      (Shell G x 3).card≤(k+sl)*(k+sl-(4*sl+3))+sl*(k+sl) := by
  classical
  let d := k+sl
  let A := OmittedStar p x
  let B := External G A
  let P := PinVertices p x
  let C := B\P
  let H := Shell G x 3
  let I := G.induce (A : Set V)
  let HP := P.biUnion (fun t => H∩DistanceTwo G t)
  have cw : C⊆DistanceTwo G x := Graffiti189LongestPath.OneSlack.boundary_except_pins_two hc hp hx
  have ck : C.card≤d := (card_le_card cw).trans (cap x)
  have pk : P.card≤sl := by
    have e := Graffiti189LongestPath.OneSlack.card_pinVertices hp (x:=x)
    change P.card=(Pins p x).card at e
    omega
  have pk' : HP.card≤P.card*d := by
    apply card_biUnion_le_card_mul
    intro t ht
    exact (card_le_card inter_subset_right).trans (cap t)
  have pins : HP.card≤sl*d := pk'.trans (Nat.mul_le_mul_right d pk)
  have xa : x∈A := Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
  have one (v : V) : ∃ u,u∈A ∧ (v∈C → G.Adj u v) := by
    by_cases vc : v∈C
    · obtain ⟨_,w,wa,wv⟩ := Graffiti189LongestPath.Rigidity.mem_external.mp (mem_sdiff.mp vc).1
      exact ⟨w,wa,fun _ => wv⟩
    · exact ⟨x,xa,fun h => (vc h).elim⟩
  choose f property using one
  have fA (v : V) (vc : v∈C) : f v∈A ∧ G.Adj (f v) v := ⟨(property v).1,(property v).2 vc⟩
  have sparse (g : V→V) (gA : ∀ v∈C,g v∈A ∧ G.Adj (g v) v)
      (lim : (C.image g).card≤k-3*sl-3) : H.card≤(k-2*sl-3)*d := by
    let D := C.image g
    let HD := D.biUnion (gateThird G x C)
    have hcvr : H⊆HD∪HP := shell_three_donor_cover hc hp hx g gA
    have each (v : V) (hv : v∈D) : (gateThird G x C v).card≤d := by
      obtain ⟨c,cc,rfl⟩ := mem_image.mp hv
      exact (card_le_card (gate_third_subset hc (gA c cc).1 C)).trans (cap _)
    have total : HD.card≤D.card*d := card_biUnion_le_card_mul D _ d each
    have h := (card_le_card hcvr).trans (card_union_le HD HP)
    have w := Nat.mul_le_mul_right d lim
    have id : (k-2*sl-3)*d=(k-3*sl-3)*d+sl*d := by rw [show k-2*sl-3=(k-3*sl-3)+sl by omega,Nat.add_mul]
    change D.card*d≤(k-3*sl-3)*d at w
    omega
  by_cases heavy : ∃ u∈A,4*sl+4≤(C.filter (G.Adj u)).card
  · obtain ⟨u,ua,hu⟩ := heavy
    let g (v : V) := if G.Adj u v then u else f v
    have f' (v : V) (vc : v∈C) : g v∈A ∧ G.Adj (g v) v := by
      by_cases e : G.Adj u v
      · simpa [g,e] using (show u∈A ∧ G.Adj u v from ⟨ua,e⟩)
      · simpa [g,e] using fA v vc
    let C' := C.filter (fun w => ¬G.Adj u w)
    have comp : C'.card+(C.filter (G.Adj u)).card=C.card := by
      have e : C\(C.filter (G.Adj u))=C' := by ext v; simp [C']; tauto
      exact e ▸ card_sdiff_add_card_eq_card (filter_subset (G.Adj u) C)
    have sub : C.image g⊆insert u (C'.image f) := by
      intro v hv
      obtain ⟨c,cc,rfl⟩ := mem_image.mp hv
      by_cases e : G.Adj u c
      · simp [g,e]
      · exact mem_insert.mpr (Or.inr (by simpa [g,e] using
          (mem_image_of_mem f (show c∈C' from mem_filter.mpr ⟨cc,e⟩))))
    have c := (card_le_card sub).trans (card_insert_le _ _)
    have im : (C'.image f).card≤C'.card := card_image_le
    exact Or.inl (sparse g f' (by omega))
  let D := C.image f
  by_cases few : D.card≤k-3*sl-3
  · exact Or.inl (sparse f fA few)
  right
  have dA (v : V) (vd : v∈D) : v∈A := by
    obtain ⟨b,bc,rfl⟩ := mem_image.mp vd
    exact (fA b bc).1
  have rep₀ (v : V) : ∃ b,v∈D → b∈C ∧ f b=v := by
    by_cases vd : v∈D
    · obtain ⟨b,bc,eq⟩ := mem_image.mp vd
      exact ⟨b,fun _ => ⟨bc,eq⟩⟩
    · exact ⟨x,fun h => (vd h).elim⟩
  choose rep repP using rep₀
  have repInj : Set.InjOn rep (↑D : Set V) := by
    intro v vd w wd h
    exact ((repP v vd).2).symm.trans ((congrArg f h).trans (repP w wd).2)
  have diet (v : V) (vd : v∈D) : (gateThird G x C v).card≤d-(4*sl+3) := by
    let v' : ↥(A : Set V) := ⟨v,dA v vd⟩
    let N := (I.neighborFinset v').image Subtype.val
    have nab : N⊆A := by
      intro z nz
      obtain ⟨z,_,rfl⟩ := mem_image.mp nz
      exact z.property
    have nc : N.card=I.degree v' := by
      rw [←I.card_neighborFinset_eq_degree,card_image_of_injective _ Subtype.val_injective]
    have nd (z : V) (zn : z∈N) : G.Adj v z := by
      obtain ⟨z,zz,rfl⟩ := mem_image.mp zn
      exact (I.mem_neighborFinset v' z).mp zz
    let L := D∩N
    have lsub : L⊆D := inter_subset_left
    have count := card_union_add_card_inter D N
    have total := card_le_card (union_subset dA nab)
    change (D∪N).card≤A.card at total
    have bound := floor v'
    change A.card≤2*I.degree v'+2*sl at bound
    change A.card≤k+4*sl+2 at small
    change (D∪N).card+L.card=D.card+N.card at count
    have many : 8*sl+7≤L.card := by omega
    let R := L.image rep
    have ri : R.card=L.card := card_image_of_injOn (fun _ h _ j e => repInj (lsub h) (lsub j) e)
    let S := C.filter (G.Adj v)
    let W := R\S
    have sc : S.card<4*sl+4 := Nat.lt_of_not_ge (fun bad => heavy ⟨v,dA v vd,bad⟩)
    have wc : 4*sl+3≤W.card := by
      have c := card_sdiff_add_card_inter R S
      have e := card_le_card (inter_subset_right : R∩S⊆S)
      change W.card+(R∩S).card=R.card at c
      omega
    have sub : W⊆DistanceTwo G v := by
      intro t wt
      obtain ⟨u,ul,rfl⟩ := mem_image.mp (mem_sdiff.mp wt).1
      have ud := lsub ul
      have uv := nd u (mem_inter.mp ul).2
      obtain ⟨bc,fb⟩ := repP u ud
      have ed : G.Adj u (rep u) := Eq.mp (congrArg (fun w => G.Adj w (rep u)) fb) (fA _ bc).2
      have no : ¬G.Adj v (rep u) := fun e => (mem_sdiff.mp wt).2 (mem_filter.mpr ⟨bc,e⟩)
      have ne : v≠rep u := fun eq =>
        (Graffiti189LongestPath.Rigidity.mem_external.mp (mem_sdiff.mp bc).1).1 (eq ▸ dA v vd)
      exact Graffiti189LongestPath.mem_distanceTwo.mpr (Graffiti189LongestPath.dist_two hc ne no uv ed)
    have dis : Disjoint W (gateThird G x C v) := disjoint_left.mpr (by
      intro z zw zh
      obtain ⟨u,ul,e⟩ := mem_image.mp (mem_sdiff.mp zw).1
      have bc := (repP u (lsub ul)).1
      have q := Graffiti189LongestPath.mem_distanceTwo.mp (cw (e ▸ bc))
      have q' := mem_shell.mp (mem_gateThird.mp zh).1
      omega)
    have span := card_le_card (union_subset sub (gate_third_subset hc (dA v vd) C))
    rw [card_union_of_disjoint dis] at span
    have cb := cap v
    omega
  let HD := D.biUnion (gateThird G x C)
  have cc : H⊆HD∪HP := shell_three_donor_cover hc hp hx f fA
  have cnt : HD.card≤D.card*(d-(4*sl+3)) := card_biUnion_le_card_mul D _ (d-(4*sl+3)) diet
  have dc : D.card≤d := (show D.card≤C.card from card_image_le).trans ck
  have mt := Nat.mul_le_mul_right (d-(4*sl+3)) dc
  have c := (card_le_card cc).trans (card_union_le HD HP)
  change H.card≤d*(d-(4*sl+3))+sl*d
  omega

#print axioms scaled_donor_shell_upper
end Graffiti189LongestPath.ScaledDonors

-- SOURCE ScaledShore189.lean
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack Graffiti189LongestPath.ActiveStarHeight
open Graffiti189LongestPath.ExactStarShore Graffiti189LongestPath.ShoreConnectivity Graffiti189LongestPath.ShoreDegrees
open Graffiti189LongestPath.ScaledCharge Graffiti189LongestPath.ScaledConnectivity Graffiti189LongestPath.StarCycleClosure
open Graffiti189LongestPath.Normalize Graffiti189LongestPath.PosaOneLow Graffiti189LongestPath.MengerRoutable Graffiti189LongestPath.FanWeighted
open Graffiti189LongestPath.CycleHallSplice Graffiti189LongestPath.UltraOrder Graffiti189LongestPath.SingleHeight
open private Graffiti189LongestPath.Rigidity.mem_external Graffiti189LongestPath.Rigidity.mem_omittedStar from Rigidity189
open private Graffiti189LongestPath.boundary_card_of_connectivity Graffiti189LongestPath.no_endpoints from SmallSeparator189
set_option warningAsError true
set_option linter.unusedVariables false
set_option maxHeartbeats 4500000
namespace Graffiti189LongestPath.ScaledShore
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem scaled_star_stays_connected (hc : G.Connected) (k sl : Nat) (hk : 28*sl+20≤k) (positive : 1≤sl)
    (cap : ∀ v,(EvenFrom G v).card≤k+sl+1)
    (conn : ∀ D : Finset V,D.card<k → (G.induce ((↑D : Set V)ᶜ)).Connected)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p)
    (hx : x∉p.support)
    (sat : (External G (OmittedStar p x)).card≤k+(sl-1))
    (far : k≤((univ:Finset V)\(OmittedStar p x∪External G (OmittedStar p x))).card)
    (X : Finset V) (inside : X⊆OmittedStar p x)
    (small : 3*X.card+4*sl<(OmittedStar p x).card) :
    (G.induce ((↑((OmittedStar p x)\X)):Set V)).Connected := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let U := univ\(A∪B)
  change B.card≤k+(sl-1) at sat
  have large : k≤U.card := far
  have rA {z : V} (hz : z∈U) : z∉A := fun h =>
    (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inl h))
  have rB {z : V} (hz : z∈U) : z∉B := fun h =>
    (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inr h))
  have ul : ∀ u∈U,∀ v∉U,G.Adj u v → v∈B := by
    intro u hu v hv ed
    have cov : v∈A∪B := Classical.byContradiction
      (fun h => hv (mem_sdiff.mpr ⟨mem_univ _,h⟩))
    exact (mem_union.mp cov).elim (fun h => (rB hu
      (Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨rA hu,v,h,ed.symm⟩)).elim) id
  have ub : Disjoint U B := disjoint_left.mpr (fun _ h h' => rB h h')
  have au : Disjoint A U := disjoint_left.mpr (fun _ h h' => rA h' h)
  have ab : Disjoint A B := disjoint_left.mpr (fun _ h h' =>
    (Graffiti189LongestPath.Rigidity.mem_external.mp h').1 h)
  have cA : ∀ y∈A,∀ z∉A,G.Adj y z → z∈B := fun _ hy _ hz e =>
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨hz,_,hy,e⟩
  have r : ∀ z∈A,z=x ∨ G.Adj x z := fun _ h =>
    (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp h).2
  exact scaled_shore_stays_connected hc k sl positive A B U X x conn (by omega) ab ub au large
    (by omega) cA ul (fun v => distanceTwo_le_of_even (k+sl) v (cap v)) r inside small


theorem scaled_induced_floor (hc : G.Connected) (k sl : Nat) (hk : 28*sl+20≤k) (positive : 1≤sl)
    (cap : ∀ v,(EvenFrom G v).card≤k+sl+1)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
   
    (sat : (External G (OmittedStar p x)).card≤k+(sl-1))
    (far : k≤((univ:Finset V)\(OmittedStar p x∪External G (OmittedStar p x))).card)
    (v : ↥((OmittedStar p x : Finset V) : Set V)) :
    (OmittedStar p x).card≤2*(G.induce (OmittedStar p x : Set V)).degree v+2*sl := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let U := univ\(A∪B)
  let I := G.induce (A : Set V)
  change B.card≤k+(sl-1) at sat
  have large : k≤U.card := far
  have rA {z : V} (hz : z∈U) : z∉A := fun h => (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inl h))
  have rB {z : V} (hz : z∈U) : z∉B := fun h => (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inr h))
  have ul : ∀ u∈U,∀ v∉U,G.Adj u v → v∈B := by
    intro u hu v hv ed
    have cov : v∈A∪B := Classical.byContradiction (fun h => hv (mem_sdiff.mpr ⟨mem_univ _,h⟩))
    exact (mem_union.mp cov).elim (fun h => (rB hu
      (Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨rA hu,v,h,ed.symm⟩)).elim) id
  have ub : Disjoint U B := disjoint_left.mpr (fun _ h h' => rB h h')
  have au : Disjoint A U := disjoint_left.mpr (fun _ h h' => rA h' h)
  have ab : Disjoint A B := disjoint_left.mpr (fun _ h h' =>
    (Graffiti189LongestPath.Rigidity.mem_external.mp h').1 h)
  have cA : ∀ y∈A,∀ z∉A,G.Adj y z → z∈B := fun _ hy _ hz e =>
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨hz,_,hy,e⟩
  have root : ∀ z∈A,z=x ∨ G.Adj x z := fun _ h =>
    (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp h).2
  have va : v.val∈A := v.property
  have vo : v.val∉p.support := (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp va).1
  have low : k≤G.degree v.val := by
    have av : a≠v.val := fun e => vo (e ▸ p.start_mem_support)
    rw [←G.card_neighborFinset_eq_degree]
    apply Graffiti189LongestPath.boundary_card_of_connectivity k conn (A:={v.val}) (a:=a)
    · exact mem_singleton_self _
    · exact fun h => av (mem_singleton.mp h)
    · exact fun h => (Graffiti189LongestPath.no_endpoints hp vo).1 ((G.mem_neighborFinset _ _).mp h)
    · exact disjoint_left.mpr (fun _ h e => ((G.mem_neighborFinset v.val _).mp e).ne (mem_singleton.mp h).symm)
    · exact fun _ h _ _ e => (G.mem_neighborFinset _ _).mpr ((mem_singleton.mp h) ▸ e)
  have ineq := shore_charge_with_cut_deficit hc (k+sl) k (sl-1) A U B conn (by omega) ab ub au large
    cA ul (fun v => distanceTwo_le_of_even (k+sl) v (cap v)) root v
  change A.card+G.degree v.val+_≤2*I.degree v+(k+sl)+(sl-1)+1 at ineq
  change A.card≤2*I.degree v+2*sl
  omega

theorem scaled_root_deleted_degrees (hc : G.Connected) (k sl : Nat) (hk : 28*sl+20≤k) (positive : 1≤sl)
    (cap : ∀ v,(EvenFrom G v).card≤k+sl+1)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
   
    (sat : (External G (OmittedStar p x)).card≤k+(sl-1))
    (far : k≤((univ:Finset V)\(OmittedStar p x∪External G (OmittedStar p x))).card)
    (v : ↥(((OmittedStar p x).erase x : Finset V) : Set V)) :
    (OmittedStar p x).card≤2*(G.induce (((OmittedStar p x).erase x : Finset V) : Set V)).degree v+2*sl+2 ∧
      (k+sl≤G.degree v.val →
       (OmittedStar p x).card≤2*(G.induce (((OmittedStar p x).erase x : Finset V) : Set V)).degree v+sl+2) := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let U := univ\(A∪B)
  let T := A.erase x
  let J := G.induce (T : Set V)
  let I := G.induce (A : Set V)
  change B.card≤k+(sl-1) at sat
  have large : k≤U.card := far
  have rA {z : V} (hz : z∈U) : z∉A := fun h => (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inl h))
  have rB {z : V} (hz : z∈U) : z∉B := fun h => (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inr h))
  have ul : ∀ u∈U,∀ v∉U,G.Adj u v → v∈B := by
    intro u hu v hv ed
    have cov : v∈A∪B := Classical.byContradiction (fun h => hv (mem_sdiff.mpr ⟨mem_univ _,h⟩))
    exact (mem_union.mp cov).elim (fun h => (rB hu
      (Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨rA hu,v,h,ed.symm⟩)).elim) id
  have ub : Disjoint U B := disjoint_left.mpr (fun _ h h' => rB h h')
  have au : Disjoint A U := disjoint_left.mpr (fun _ h h' => rA h' h)
  have ab : Disjoint A B := disjoint_left.mpr (fun _ h h' =>
    (Graffiti189LongestPath.Rigidity.mem_external.mp h').1 h)
  have cA : ∀ y∈A,∀ z∉A,G.Adj y z → z∈B := fun _ hy _ hz e =>
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨hz,_,hy,e⟩
  have root : ∀ z∈A,z=x ∨ G.Adj x z := fun _ h =>
    (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp h).2
  have va : v.val∈A := (mem_erase.mp v.property).2
  have vo : v.val∉p.support := (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp va).1
  have vx : G.Adj v.val x := ((root _ va).resolve_left (mem_erase.mp v.property).1).symm
  have xa : x∈A := Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
  have low : k≤G.degree v.val := by
    have av : a≠v.val := fun e => vo (e ▸ p.start_mem_support)
    rw [←G.card_neighborFinset_eq_degree]
    apply Graffiti189LongestPath.boundary_card_of_connectivity k conn (A:={v.val}) (a:=a)
    · exact mem_singleton_self _
    · exact fun h => av (mem_singleton.mp h)
    · exact fun h => (Graffiti189LongestPath.no_endpoints hp vo).1 ((G.mem_neighborFinset _ _).mp h)
    · exact disjoint_left.mpr (fun _ h e => ((G.mem_neighborFinset v.val _).mp e).ne (mem_singleton.mp h).symm)
    · exact fun _ h _ _ e => (G.mem_neighborFinset _ _).mpr ((mem_singleton.mp h) ▸ e)
  let av : ↥(A : Set V) := ⟨v.val,va⟩
  have ineq := shore_charge_with_cut_deficit hc (k+sl) k (sl-1) A U B conn (by omega) ab ub au large
    cA ul (fun v => distanceTwo_le_of_even (k+sl) v (cap v)) root av
  change A.card+G.degree v.val+_≤2*I.degree av+(k+sl)+(sl-1)+1 at ineq
  have id := universal_root_degree_drop A x xa v vx
  change J.degree v+1=I.degree av at id
  change A.card≤2*J.degree v+2*sl+2 ∧ (k+sl≤G.degree v.val → A.card≤2*J.degree v+sl+2)
  omega

#print axioms universal_root_degree_drop

theorem scaled_root_deleted_long_cycle
    (hc : G.Connected) (k sl : Nat) (hk : 28*sl+20≤k) (positive : 1≤sl)
    (cap : ∀ v,(EvenFrom G v).card≤k+sl+1)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
    (sat : (External G (OmittedStar p x)).card≤k+(sl-1))
    (far : k≤((univ:Finset V)\(OmittedStar p x∪External G (OmittedStar p x))).card)
    (height : k+1≤(OmittedStar p x).card)
    (deg : ∀ u v : V,u≠v → k+sl≤G.degree u ∨ k+sl≤G.degree v) :
    ∃ a, ∃ c : (G.induce (((OmittedStar p x).erase x : Finset V) : Set V)).Walk a a,
      c.IsCycle ∧ 2*(((OmittedStar p x).card-sl-2)/2)≤c.length := by
  classical
  let A := OmittedStar p x
  let T := A.erase x
  let W := ↥(T : Set V)
  let J := G.induce (T : Set V)
  let m := (A.card-sl-2)/2
  have xt : x∈A := Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
  have h : k+1≤A.card := height
  have wc : Fintype.card W=A.card-1 := by
    change Fintype.card ↥T=A.card-1
    exact (Fintype.card_coe T).trans (card_erase_of_mem xt)
  have del (S : Finset W) (sc : S.card<2) :
      (J.induce ((↑S : Set W)ᶜ)).Connected := by
    let e : W ↪ V := ⟨Subtype.val,Subtype.val_injective⟩
    let X := insert x (S.map e)
    have xs : X⊆A := by
      intro v vx
      rcases mem_insert.mp vx with rfl|h
      · exact xt
      · obtain ⟨w,_,rfl⟩ := mem_map.mp h
        exact (mem_erase.mp w.property).2
    have xl := (card_insert_le x (S.map e)).trans (by rw [card_map])
    change X.card≤S.card+1 at xl
    have sz : 3*X.card+4*sl<(OmittedStar p x).card := by change 3*X.card+4*sl<A.card; omega
    have con := scaled_star_stays_connected hc k sl hk positive cap conn
      hp hx sat far X xs sz
    exact (erase_root_and_set_iso (G:=G) A x S).connected_iff.mp con
  have low (v : W) : 2≤J.degree v := by
    have dg := (scaled_root_deleted_degrees hc k sl hk positive cap conn hp
      hx sat far v).1
    change A.card≤2*J.degree v+2*sl+2 at dg
    omega
  have highJ (v : W) (vh : k+sl≤G.degree v.val) : m≤J.degree v := by
    have dg := (scaled_root_deleted_degrees hc k sl hk positive cap conn hp
      hx sat far v).2 vh
    change A.card≤2*J.degree v+sl+2 at dg
    dsimp [m]
    omega
  have pair (u v : W) (ne : u≠v) : m≤J.degree u ∨ m≤J.degree v :=
    (deg u.val v.val (fun e => ne (Subtype.ext e))).imp (highJ u) (highJ v)
  have mc : 2≤m := by dsimp [m]; omega
  obtain ⟨r,c,cc,cl⟩ := proved_one_low_circumference W J m mc (by omega) del low pair
  have mm : 2*m≤Fintype.card W := by dsimp [m]; omega
  rw [min_eq_right mm] at cl
  exact ⟨r,c,cc,cl⟩


theorem scaled_no_long_shore_cycle (hc : G.Connected) (k sl : Nat) (hk : 28*sl+20≤k) (positive : 1≤sl)
    (cap : ∀ v,(EvenFrom G v).card≤k+sl+1)
    (conn : ∀ D : Finset V,D.card<k → (G.induce ((↑D : Set V)ᶜ)).Connected)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p)
    (hx : x∉p.support)
    (sat : (External G (OmittedStar p x)).card≤k+(sl-1))
    (far : k≤((univ:Finset V)\(OmittedStar p x∪External G (OmittedStar p x))).card)
    (large : 6+4*sl<(OmittedStar p x).card)
    (len : Nat)
    (ash : k≤(OmittedStar p x).card)
    (long : Fintype.card V < (OmittedStar p x).card+k+(k+1)*(len+1))
    (cyc : ∃ z, ∃ c : (G.induce (((OmittedStar p x).erase x : Finset V) : Set V)).Walk z z,
      c.IsCycle ∧ max 2 len≤c.length) : False := by
  classical
  let A := OmittedStar p x
  change k≤A.card at ash
  change 6+4*sl<A.card at large
  let Z : Set V := ((A.erase x : Finset V) : Set V)
  let J := G.induce Z
  have sepConn (S : Finset Z) (sc : S.card<2) :
      (J.induce ((↑S : Set Z)ᶜ)).Connected := by
    let e : Z ↪ V := ⟨Subtype.val,Subtype.val_injective⟩
    let X := insert x (S.map e)
    have xs : X⊆A := by
      intro v vx
      rcases mem_insert.mp vx with rfl|h
      · exact Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
      · obtain ⟨w,_,rfl⟩ := mem_map.mp h
        exact (mem_erase.mp w.property).2
    have xl := (card_insert_le x (S.map e)).trans (by rw [card_map])
    change X.card≤S.card+1 at xl
    have con := scaled_star_stays_connected hc k sl hk positive cap conn hp
      hx sat far X xs (show 3*X.card+4*sl<A.card by omega)
    exact (erase_root_and_set_iso (G:=G) A x S).connected_iff.mp con
  let f : J →g G := ⟨Subtype.val, fun e => e⟩
  have fi : Function.Injective f := Subtype.val_injective
  have off (z : Z) : x≠f z := fun e => (mem_erase.mp z.property).1 e.symm
  have adj (z : Z) : G.Adj x (f z) := by
    have zz := (mem_erase.mp z.property).2
    exact (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp zz).2.resolve_left (fun ne => off z ne.symm)
  obtain ⟨a,c,hc',cl⟩ := cyc
  have big : 2≤c.support.toFinset.card := by
    rw [cycle_card_support c hc']
    exact (le_max_left _ _).trans cl
  have L : len≤c.length := (le_max_right _ _).trans cl
  have route : ∀ u∈A,∀ v∈A,u≠v →
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈A) ∧ len+1≤q.length+1 := by
    intro u ua v va uv
    have rA {z : V} (e : z=x ∨ ∃ w : Z,f w=z) : z∈A := by
      rcases e with rfl|⟨w,rfl⟩
      · exact Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
      · exact (mem_erase.mp w.property).2
    by_cases hu : u=x
    · subst u
      let t : Z := ⟨v,mem_erase.mpr ⟨uv.symm,va⟩⟩
      obtain ⟨q,qp,ql,qs⟩ := cycle_to_prescribed_root_route f fi off adj c hc'
        (t:=t) (fun s h => sepConn s (by omega))
      exact ⟨q,qp,fun z hz => rA (qs z hz),by omega⟩
    by_cases hv : v=x
    · subst v
      let t : Z := ⟨u,mem_erase.mpr ⟨hu,ua⟩⟩
      obtain ⟨q,qp,ql,qs⟩ := cycle_to_prescribed_root_route f fi off adj c hc'
        (t:=t) (fun s h => sepConn s (by omega))
      exact ⟨q.reverse,qp.reverse,fun z hz => rA (qs z (by
        simpa only [support_reverse,List.mem_reverse] using hz)),by simpa using (by omega : len+1≤q.length+1)⟩
    let s : Z := ⟨u,mem_erase.mpr ⟨hu,ua⟩⟩
    let t : Z := ⟨v,mem_erase.mpr ⟨hv,va⟩⟩
    have ne : s≠t := fun e => uv (congrArg Subtype.val e)
    obtain ⟨q,qp,ql,qs⟩ := cycle_to_prescribed_route f fi ne off adj c hc' big sepConn
    exact ⟨q,qp,fun z hz => rA (qs z hz),by omega⟩
  have ao : ∀ z∈A,z∉p.support := fun _ z => (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp z).1
  obtain ⟨F⟩ := hooks_of_small_deletion_connectivity A k hp ao ash (support_large k conn hp hx) conn
  have low := weighted_hooked_lower k (by omega) hp (len+1) A ao (by omega) route F
  change Fintype.card V<A.card+k+(k+1)*(len+1) at long
  omega

#print axioms erase_root_and_set_iso

#print axioms scaled_root_deleted_long_cycle
#print axioms scaled_no_long_shore_cycle
end Graffiti189LongestPath.ScaledShore

-- SOURCE ScaledDeficit189.lean
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack Graffiti189LongestPath.PinRun
open Graffiti189LongestPath.DeficitActive Graffiti189LongestPath.ScaledActive Graffiti189LongestPath.DeficitLongest
open Graffiti189LongestPath.ScaledShore Graffiti189LongestPath.DeficitThirdShell
open Graffiti189LongestPath.ScaledDonors Graffiti189LongestPath.ActiveStarHeight
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
open private Graffiti189LongestPath.pin_data from SmallSeparator189
open private Graffiti189LongestPath.OneSlack.boundary_except_pins_two Graffiti189LongestPath.OneSlack.card_pinVertices
  Graffiti189LongestPath.OneSlack.pin_vertices_subset_boundary Graffiti189LongestPath.OneSlack.first_pins_nonempty from OneSlack189
set_option warningAsError true
set_option maxHeartbeats 7000000
namespace Graffiti189LongestPath.ScaledDeficit
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- #189 for every positive slack s=d−k with k ≥ 28s+20.
No normalized attachment or separator geometry is assumed. -/
theorem traceable_of_scaled_connectivity (hc : G.Connected) (k sl : Nat) (hk : 28*sl+20≤k) (positive : 1≤sl)
    (cap : ∀ v,(EvenFrom G v).card≤k+sl+1)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → k+sl≤G.degree u ∨ k+sl≤G.degree v) :
    ∃ (u v : V) (q : G.Walk u v),q.IsPath ∧ ∀ z,z∈q.support := by
  classical
  apply Classical.byContradiction
  intro fail
  obtain ⟨a,b,p,hp⟩ := Rigidity.exists_longest hc
  have no : ∃ x,x∉p.support := Classical.byContradiction (fun h =>
    fail ⟨a,b,p,hp.1,fun z => Classical.byContradiction (fun e => h ⟨z,e⟩)⟩)
  obtain ⟨x,hx,xh,i,hi⟩ := scaled_deficit_has_high_active hc k sl (by omega) (by omega) cap conn deg hp no
  let d := k+sl
  let A := OmittedStar p x
  let B := External G A
  let P := PinVertices p x
  let C := B\P
  let H := Shell G x 3
  let W := Shell G x 4
  let U := (univ:Finset V)\(A∪B)
  have cap₂ (v : V) : (DistanceTwo G v).card≤d := distanceTwo_le_of_even d v (cap v)
  have pack := high_omitted_pin_budget hc d k cap conn hp hx (Graffiti189LongestPath.pin_data hi).2 xh
  have p3 : (Pins p x).card≤sl := by dsimp [d] at pack; omega
  have w3 : W.card≤sl := by change k+(Pins p x).card+W.card≤d at pack; dsimp [d] at pack; omega
  have rad (z : V) : G.dist x z≤4 := by
    by_contra! far
    have c := shell_card_of_far hc k conn (x:=x) (y:=z) (i:=4) (by decide) (by omega)
    change k≤W.card at c
    omega
  have height : k+1≤A.card := by
    have e := star_card_degree_and_pins hp hx
    change A.card+(Pins p x).card=G.degree x+1 at e
    omega
  have cc : C.card≤d := (card_le_card
    (Graffiti189LongestPath.OneSlack.boundary_except_pins_two hc hp hx)).trans (cap₂ x)
  have pp : P.card≤sl := by
    have e := Graffiti189LongestPath.OneSlack.card_pinVertices hp (x:=x)
    change P.card=(Pins p x).card at e
    omega
  have bc : C.card+P.card=B.card :=
    card_sdiff_add_card_eq_card (Graffiti189LongestPath.OneSlack.pin_vertices_subset_boundary hx)
  have bk : B.card≤k+(sl-1) := by
    have f := boundary_flank_count hc hp hx
    rw [flank_count_exact hp hx] at f
    have q := card_pos.mpr (Graffiti189LongestPath.OneSlack.first_pins_nonempty ⟨i,hi⟩)
    have c := cap₂ x
    change B.card+((Pins p x).card+(FirstPins p x).card)≤
      (DistanceTwo G x).card+(Pins p x).card at f
    dsimp [d] at c
    omega
  have floor (z : V) : 2≤G.degree z := by
    have ne : a≠x := fun e => hx (e ▸ p.start_mem_support)
    have n := enough_vertices_of_degree (k+sl) deg ne
    have kdeg := degree_floor_when_enough_vertices k conn (by omega) z
    omega
  have largeP := longest_length_ge_twice_of_not_traceable hc d (by omega) floor deg fail hp
  have far : k≤U.card := by
    have cover : p.support.toFinset⊆B∪U := by
      intro z hz
      by_cases zb : z∈B
      · exact mem_union.mpr (Or.inl zb)
      have za : z∉A := fun e => (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp e).1 (List.mem_toFinset.mp hz)
      exact mem_union.mpr (Or.inr (mem_sdiff.mpr ⟨mem_univ z,fun e => (mem_union.mp e).elim za zb⟩))
    have h := (card_le_card cover).trans (card_union_le B U)
    rw [List.toFinset_card_of_nodup hp.1.support_nodup,length_support] at h
    dsimp [d] at largeP
    omega
  have order := order_le_star_cut_two_three_four hc hx rad
  change Fintype.card V≤A.card+B.card+(DistanceTwo G x).card+H.card+W.card at order
  have base : Fintype.card V≤A.card+2*k+3*sl+H.card := by
    have cx := cap₂ x
    dsimp [d] at cx
    omega
  have bd : Fintype.card V<A.card+k+(k+1)*(A.card-sl-2) := by
    by_cases small : A.card≤k+4*sl+2
    · have fl := fun v => scaled_induced_floor hc k sl hk positive cap conn hp hx bk far v
      have hs := scaled_donor_shell_upper hc k sl hk positive cap₂ hp hx p3 fl small
      change H.card≤(k-2*sl-3)*d ∨ H.card≤d*(d-(4*sl+3))+sl*d at hs
      have hs' : H.card≤(k-2*sl-3)*d := by
        rcases hs with h|h
        · exact h
        have id : d*(d-(4*sl+3))+sl*d=(k-2*sl-3)*d := by
          calc
            d*(d-(4*sl+3))+sl*d = (d-(4*sl+3))*d+sl*d := by rw [Nat.mul_comm d (d-(4*sl+3))]
            _ = (d-(4*sl+3)+sl)*d := (Nat.add_mul (d-(4*sl+3)) sl d).symm
            _ = _ := by rw [show d-(4*sl+3)+sl=k-2*sl-3 by dsimp [d]; omega]
        rwa [id] at h
      have gear := Nat.mul_le_mul_left (k+1) (show k-sl-1≤A.card-sl-2 by omega)
      have l : (k+1)*(k-sl-1)+(sl+1)*(k+1)=(k+1)*k := by
        rw [Nat.mul_comm (sl+1),←Nat.mul_add,show k-sl-1+(sl+1)=k by omega]
      have u : (k-2*sl-3)*d+(2*sl+3)*d=k*d := by rw [←Nat.add_mul,show k-2*sl-3+(2*sl+3)=k by omega]
      have i : (k+1)*k=k*k+k := by ring
      have j : k*d=k*k+sl*k := by dsimp [d]; ring
      have j₁ : (2*sl+3)*d=2*(sl*k)+3*k+2*(sl*sl)+3*sl := by dsimp [d]; ring
      have j₂ : (sl+1)*(k+1)=sl*k+k+sl+1 := by ring
      omega
    · have xa : x∈A := Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
      have gate (v : V) : ∃ u,u∈A ∧ (v∈C → G.Adj u v) := by
        by_cases h : v∈C
        · obtain ⟨_,u,ua,e⟩ := Graffiti189LongestPath.Rigidity.mem_external.mp (mem_sdiff.mp h).1
          exact ⟨u,ua,fun _ => e⟩
        · exact ⟨x,xa,fun q => (h q).elim⟩
      choose f ff using gate
      have fa (v : V) (vc : v∈C) : f v∈A ∧ G.Adj (f v) v := ⟨(ff v).1,(ff v).2 vc⟩
      let D := C.image f
      let HD := D.biUnion (gateThird G x C)
      let HP := P.biUnion (fun t => H∩DistanceTwo G t)
      have cov : H⊆HD∪HP := shell_three_donor_cover hc hp hx f fa
      have each (v : V) (vd : v∈D) : (gateThird G x C v).card≤d := by
        obtain ⟨u,uc,rfl⟩ := mem_image.mp vd
        exact (card_le_card (gate_third_subset hc (fa u uc).1 C)).trans (cap₂ _)
      have co : HD.card≤D.card*d := card_biUnion_le_card_mul D _ d each
      have pin : HP.card≤P.card*d := card_biUnion_le_card_mul P _ d
        (fun v _ => (card_le_card inter_subset_right).trans (cap₂ v))
      have dc : D.card≤C.card := card_image_le
      have e := (card_le_card cov).trans (card_union_le HD HP)
      have u := Nat.mul_le_mul_right d (show D.card+P.card≤k+(sl-1) by omega)
      rw [Nat.add_mul] at u
      have b := Nat.mul_le_mul_left (k+1) (show k+3*sl+1≤A.card-sl-2 by omega)
      have j : (k+(sl-1))*d+d=d*d := by
        have de : k+(sl-1)+1=d := by dsimp [d]; omega
        calc
          _ = (k+(sl-1))*d+1*d := by simp
          _ = (k+(sl-1)+1)*d := (Nat.add_mul (k+(sl-1)) 1 d).symm
          _ = _ := congrArg (fun t => t*d) de
      have j' : d*d=k*k+2*(sl*k)+sl*sl := by dsimp [d]; ring
      have l : (k+1)*(k+3*sl+1)=k*k+3*(sl*k)+2*k+3*sl+1 := by ring
      have q : sl*sl≤sl*k := Nat.mul_le_mul_left _ (by omega)
      have dd : d=k+sl := rfl
      omega
  obtain ⟨z,c,cyc,cl⟩ := scaled_root_deleted_long_cycle hc k sl hk positive cap conn hp hx bk far height deg
  have len : A.card-sl-3+1=A.card-sl-2 := by omega
  have lim : Fintype.card V<A.card+k+(k+1)*(A.card-sl-3+1) := by rwa [len]
  change 2*((A.card-sl-2)/2)≤c.length at cl
  exact scaled_no_long_shore_cycle hc k sl hk positive cap conn hp hx bk far (show 6+4*sl<A.card by omega)
    (A.card-sl-3) (show k≤A.card by omega) lim ⟨z,c,cyc,by omega⟩

/-- Direct proportional statement: connectivity at least k with
29k≥28d+20 is enough at second-degree threshold d. -/
theorem traceable_of_proportional_connectivity (hc : G.Connected) (d k : Nat)
    (ratio : 28*d+20≤29*k)
    (cap : ∀ v,(EvenFrom G v).card≤d+1)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → d≤G.degree u ∨ d≤G.degree v) :
    ∃ (u v : V) (q : G.Walk u v),q.IsPath ∧ ∀ z,z∈q.support := by
  by_cases hk : d≤k
  · exact traceable_of_even_and_connectivity hc d cap (fun S sc => conn S (sc.trans_le hk))
  have eq : k+(d-k)=d := by omega
  exact traceable_of_scaled_connectivity hc k (d-k) (by omega) (by omega)
    (by simpa only [eq] using cap) conn (by simpa only [eq] using deg)

#print axioms traceable_of_scaled_connectivity
#print axioms traceable_of_proportional_connectivity
end Graffiti189LongestPath.ScaledDeficit
