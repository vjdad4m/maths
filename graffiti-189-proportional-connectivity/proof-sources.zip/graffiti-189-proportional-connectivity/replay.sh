#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")" && pwd)
obj=$(mktemp -d)
trap 'rm -rf "$obj"' EXIT
echo '== ScaledDeficitAll189 =='
lean -j1 -DElab.async=false -DwarningAsError=true --root="$root" \
  -o "$obj/ScaledDeficitAll189.olean" "$root/ScaledDeficitAll189.lean"
