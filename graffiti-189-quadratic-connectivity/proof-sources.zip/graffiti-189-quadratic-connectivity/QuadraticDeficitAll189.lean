import WideRatioDeficitAll189
import PosaOneLow189
import FanWeighted189
import MengerRoutable189
import SingleHeight189
import StarCycleClosure189
import StandaloneShellQuadratic189
import Mathlib.Tactic.Ring

-- SOURCE GeneralGapMidpoint189.lean
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.Normalize Graffiti189LongestPath.OneSlack
open Graffiti189LongestPath.GapTwin Graffiti189LongestPath.DeficitActive
open private Graffiti189LongestPath.GapTwin.splice_gap_two_allow_midpoint Graffiti189LongestPath.GapTwin.edgeCount from GapTwin189
open private Graffiti189LongestPath.mem_distanceTwo Graffiti189LongestPath.dist_two Graffiti189LongestPath.pin_data Graffiti189LongestPath.splice_gap_two from SmallSeparator189
open private Graffiti189LongestPath.OneSlack.nonconsecutive_boundary Graffiti189LongestPath.OneSlack.pin_vertices_subset_boundary
  Graffiti189LongestPath.OneSlack.card_pinVertices Graffiti189LongestPath.OneSlack.pin_of_neighbor_mem from OneSlack189
set_option warningAsError true
set_option maxHeartbeats 5500000
namespace Graffiti189LongestPath.GeneralGapMidpoint
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- A gap-two midpoint has degree at most twice the total number of pins,
even when the porter has additional attachments. -/
theorem gap_midpoint_degree_le_twice_pins (hc : G.Connected) (d : Nat)
    (cap : ∀ w,(EvenFrom G w).card≤d+1)
    {a b x : V} {p : G.Walk a b} (hmin : EdgeMin p) (hx : x∉p.support)
    (high : d≤G.degree x)
    {i : Nat} (ip : i∈Pins p x) (jp : i+2∈Pins p x) :
    G.degree (p.getVert (i+1))≤2*(Pins p x).card := by
  classical
  have hp := hmin.1
  let l := p.getVert i
  let z := p.getVert (i+1)
  let r := p.getVert (i+2)
  have il := (Graffiti189LongestPath.pin_data ip).1
  have jl := (Graffiti189LongestPath.pin_data jp).1
  have lx : G.Adj x l := (Graffiti189LongestPath.pin_data ip).2
  have rx : G.Adj x r := (Graffiti189LongestPath.pin_data jp).2
  have lz : G.Adj l z := p.adj_getVert_succ (i:=i) (by omega)
  have zr : G.Adj z r := p.adj_getVert_succ (i:=i+1) (by omega)
  have zx : z≠x := fun e => hx (e ▸ p.getVert_mem_support (i+1))
  have zOld : z∈p.support.toFinset := List.mem_toFinset.mpr (p.getVert_mem_support (i+1))
  let S := p.support.toFinset.erase z
  have xS : x∉S := fun h => hx (List.mem_toFinset.mp (mem_erase.mp h).2)
  have zS : z∉S := by simp [S]
  have oldset : p.support.toFinset=insert z S := (insert_erase zOld).symm
  have noxz : ¬G.Adj x z := by
    intro edge
    have j : i+1∈Pins p x := mem_filter.mpr ⟨mem_range.mpr (by omega),edge⟩
    have li : l∈External G (OmittedStar p x) :=
      Graffiti189LongestPath.OneSlack.pin_vertices_subset_boundary hx (mem_image.mpr ⟨i,ip,rfl⟩)
    have zi : z∈External G (OmittedStar p x) :=
      Graffiti189LongestPath.OneSlack.pin_vertices_subset_boundary hx (mem_image.mpr ⟨i+1,j,rfl⟩)
    exact Graffiti189LongestPath.OneSlack.nonconsecutive_boundary hp hx il li zi
  have eraseInt (w : V) (no : ¬G.Adj w z) :
      G.neighborFinset w∩p.support.toFinset=G.neighborFinset w∩S := by
    ext v
    rw [mem_inter,mem_inter]
    constructor
    · rintro ⟨vn,vp⟩
      exact ⟨vn,mem_erase.mpr ⟨fun e => no (e ▸ (G.mem_neighborFinset _ _).mp vn),vp⟩⟩
    · rintro ⟨vn,vs⟩
      exact ⟨vn,(mem_erase.mp vs).2⟩
  have xeq : G.neighborFinset x ∩ p.support.toFinset=PinVertices p x := by
    ext v
    constructor
    · intro h
      obtain ⟨vn,vp⟩ := mem_inter.mp h
      obtain ⟨j,jp,e⟩ := Graffiti189LongestPath.OneSlack.pin_of_neighbor_mem hp hx
        (List.mem_toFinset.mp vp) ((G.mem_neighborFinset _ _).mp vn)
      exact mem_image.mpr ⟨j,jp,e⟩
    · intro h
      obtain ⟨j,jp,rfl⟩ := mem_image.mp h
      exact mem_inter.mpr ⟨(G.mem_neighborFinset _ _).mpr (Graffiti189LongestPath.pin_data jp).2,
        List.mem_toFinset.mpr (p.getVert_mem_support j)⟩
  obtain ⟨q,hq,hLen,hSupp⟩ :=
    Graffiti189LongestPath.splice_gap_two p hp.1 (Walk.nil : G.Walk x x) IsPath.nil
      (by simpa using hx) i (by omega) lx.symm rx
  have len : q.length=p.length := by simpa using hLen
  have qLongest : IsLongest q := ⟨hq,fun a b w hw => len.symm ▸ hp.2 a b w hw⟩
  have qset : q.support.toFinset=insert x S := by
    ext w
    simp only [List.mem_toFinset, hSupp, support_nil, List.mem_singleton, mem_insert, S, mem_erase]
    tauto
  have cn := hmin.2 a b q qLongest
  rw [oldset,qset,Graffiti189LongestPath.GapTwin.edgeCount zS,
    Graffiti189LongestPath.GapTwin.edgeCount xS,←eraseInt x noxz,xeq,
    Graffiti189LongestPath.OneSlack.card_pinVertices hp,
    ←eraseInt z (G.loopless z)] at cn
  let X := G.neighborFinset x\p.support.toFinset
  let Z := G.neighborFinset z\p.support.toFinset
  have xOff {w : V} (hw : w∈X) : w∉p.support :=
    fun e => (mem_sdiff.mp hw).2 (List.mem_toFinset.mpr e)
  have zOff {w : V} (hw : w∈Z) : w∉p.support :=
    fun e => (mem_sdiff.mp hw).2 (List.mem_toFinset.mpr e)
  have noflankX {w : V} (hw : w ∈ X) : ¬G.Adj w l := by
    intro h
    have ed := (G.mem_neighborFinset x w).mp (mem_sdiff.mp hw).1
    obtain ⟨q,hq,hLen,_⟩ := Graffiti189LongestPath.splice_gap_two p hp.1 ed.symm.toWalk
      (IsPath.of_adj _)
      (by simp [xOff hw,hx]) i (by omega) h.symm rx
    have hL := hp.2 a b q hq
    simp at hLen
    omega
  have noflankZ {w : V} (hw : w ∈ Z) : ¬G.Adj w l := by
    intro h
    have ed := (G.mem_neighborFinset z w).mp (mem_sdiff.mp hw).1
    -- Avoid the old midpoint only: the replacement can finish at that midpoint.
    obtain ⟨q,hq,hLen,_⟩ := Graffiti189LongestPath.GapTwin.splice_gap_two_allow_midpoint p hp.1 ed.symm.toWalk
      (IsPath.of_adj _) i (by
        intro t ht tp
        have h' : t = w ∨ t = z := by simpa using ht
        exact h'.elim (fun h => (zOff hw (h ▸ tp)).elim) id)
      (by omega) h.symm zr
    have hL := hp.2 a b q hq
    simp at hLen
    omega
  have dis : Disjoint X Z := disjoint_left.mpr (by
    intro w hX hZ
    have xw := (G.mem_neighborFinset x w).mp (mem_sdiff.mp hX).1
    have wz := (G.mem_neighborFinset z w).mp (mem_sdiff.mp hZ).1 |>.symm
    let t : G.Walk x z := Walk.cons xw (Walk.cons wz Walk.nil)
    have hW : t.IsPath := ((IsPath.of_adj wz).cons (by simp [xw.ne,zx.symm]))
    obtain ⟨q,hq,hLen,_⟩ := Graffiti189LongestPath.GapTwin.splice_gap_two_allow_midpoint p hp.1 t hW i (by
      intro u hu hp'
      have hh : u = x ∨ u = w ∨ u = z := by simpa [t] using hu
      exact hh.elim (fun h => (hx (h ▸ hp')).elim)
        (fun h => h.elim (fun he => (xOff hX (he ▸ hp')).elim) id))
      (by omega) lx.symm zr
    have hL := hp.2 a b q hq
    simp [t] at hLen
    omega)
  have sub : X ∪ Z ⊆ DistanceTwo G l := by
    intro w hw
    have lmem := p.getVert_mem_support i
    apply Graffiti189LongestPath.mem_distanceTwo.mpr
    rcases mem_union.mp hw with h | h
    · exact Graffiti189LongestPath.dist_two hc (fun e => xOff h (e ▸ lmem))
        (fun e => noflankX h e.symm) lx.symm
        ((G.mem_neighborFinset x w).mp (mem_sdiff.mp h).1)
    · exact Graffiti189LongestPath.dist_two hc (fun e => zOff h (e ▸ lmem))
        (fun e => noflankZ h e.symm) lz
        ((G.mem_neighborFinset z w).mp (mem_sdiff.mp h).1)
  have cu := card_le_card sub
  rw [card_union_of_disjoint dis] at cu
  have cx := card_sdiff_add_card_inter (G.neighborFinset x) p.support.toFinset
  have cz := card_sdiff_add_card_inter (G.neighborFinset z) p.support.toFinset
  rw [xeq,Graffiti189LongestPath.OneSlack.card_pinVertices hp,G.card_neighborFinset_eq_degree] at cx
  rw [G.card_neighborFinset_eq_degree] at cz
  change X.card+(Pins p x).card=G.degree x at cx
  change Z.card+(G.neighborFinset z∩p.support.toFinset).card=G.degree z at cz
  have bd := distanceTwo_le_of_even d l (cap l)
  change G.degree z≤2*(Pins p x).card
  omega

/-- If the graph connectivity exceeds twice the pin budget, all pins
are separated by at least three positions on a minimum-edge longest path. -/
theorem no_gap_two_at_connectivity_above_pin_twice (hc : G.Connected) (d k : Nat)
    (cap : ∀ w,(EvenFrom G w).card≤d+1)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (enough : k+1≤Fintype.card V)
    {a b x : V} {p : G.Walk a b} (hmin : EdgeMin p) (hx : x∉p.support)
    (high : d≤G.degree x) (small : 2*(Pins p x).card<k) :
    PairedPins p x=∅ := by
  apply eq_empty_iff_forall_not_mem.mpr
  intro i hi
  obtain ⟨ii,j,jj,paired⟩ := mem_filter.mp hi
  have impossible (t : Nat) (tp : t∈Pins p x) (tn : t+2∈Pins p x) : False := by
    have lo := degree_floor_when_enough_vertices k conn enough (p.getVert (t+1))
    have upper := gap_midpoint_degree_le_twice_pins hc d cap hmin hx high tp tn
    omega
  rcases paired with e|e
  · exact impossible j jj (e.symm ▸ ii)
  · exact impossible i ii (e.symm ▸ jj)

#print axioms gap_midpoint_degree_le_twice_pins
#print axioms no_gap_two_at_connectivity_above_pin_twice
end Graffiti189LongestPath.GeneralGapMidpoint

-- SOURCE GreedyTerminal189.lean
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
set_option warningAsError true
set_option maxHeartbeats 5300000
namespace Graffiti189LongestPath.GreedyTerminal
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- A path from a specified vertex can be greedily extended within a
permitted set. Any unused endpoint neighbor is forbidden by maximality. -/
theorem long_path_from_avoiding (T R : Finset V) (m : Nat) (u : V)
    (ut : u∈T) (ur : u∉R)
    (floor : ∀ v∈T,v∉R → m≤(T.filter (G.Adj v)).card) :
    ∃ v,∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈T ∧ z∉R) ∧
      m≤q.length+R.card := by
  classical
  let L := (range (Fintype.card V)).filter (fun i =>
    ∃ v,∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈T ∧ z∉R) ∧ q.length=i)
  have c : 0<Fintype.card V := Fintype.card_pos_iff.mpr ⟨u⟩
  have nils : ∀ z∈(Walk.nil : G.Walk u u).support,z∈T ∧ z∉R := by
    intro z h
    have zz : z=u := by simpa using h
    exact zz.symm ▸ ⟨ut,ur⟩
  have zero : 0∈L := mem_filter.mpr ⟨mem_range.mpr c,u,.nil,IsPath.nil,nils,rfl⟩
  obtain ⟨v,p,pp,ps,pl⟩ := (mem_filter.mp (L.max'_mem ⟨0,zero⟩)).2
  have maximal (w : V) (q : G.Walk u w) (qp : q.IsPath)
      (qs : ∀ z∈q.support,z∈T ∧ z∉R) : q.length≤p.length := by
    rw [pl]
    exact L.le_max' _ (mem_filter.mpr ⟨mem_range.mpr qp.length_lt,w,q,qp,qs,rfl⟩)
  have nb : T.filter (G.Adj v)⊆R∪p.support.toFinset.erase v := by
    intro z hz
    obtain ⟨zt,ed⟩ := mem_filter.mp hz
    by_cases zr : z∈R
    · exact mem_union.mpr (Or.inl zr)
    apply mem_union.mpr
    right
    refine mem_erase.mpr ⟨ed.ne.symm,List.mem_toFinset.mpr ?_⟩
    apply Classical.byContradiction
    intro no
    let q := (Walk.cons ed.symm p.reverse).reverse
    have qp : q.IsPath := (pp.reverse.cons (by simpa only [support_reverse,List.mem_reverse] using no)).reverse
    have qs (w : V) (h : w∈q.support) : w∈T ∧ w∉R := by
      have r : w=z ∨ w∈p.support := by
        simpa only [q,support_reverse,List.mem_reverse,support_cons,List.mem_cons] using h
      exact r.elim (fun e => e.symm ▸ ⟨zt,zr⟩) (ps w)
    have l := maximal z q qp qs
    simp [q] at l
  have c' := (card_le_card nb).trans (card_union_le _ _)
  rw [card_erase_of_mem (List.mem_toFinset.mpr p.end_mem_support),
    List.toFinset_card_of_nodup pp.support_nodup,length_support,Nat.add_sub_cancel] at c'
  exact ⟨v,p,pp,ps,by have l := floor v (ps v p.end_mem_support).1 (ps v p.end_mem_support).2; omega⟩

omit [Fintype V] [DecidableEq V] [DecidableRel G.Adj] in
private theorem push_end {u v x : V} {q : G.Walk u v} (p : q.IsPath)
    (e : G.Adj v x) (no : x∉q.support) :
    ∃ r : G.Walk u x,r.IsPath ∧ r.length=q.length+1 ∧
      ∀ z,z∈r.support ↔ z=x ∨ z∈q.support := by
  let r := (Walk.cons e.symm q.reverse).reverse
  have rp : r.IsPath := (p.reverse.cons (by simpa only [support_reverse,List.mem_reverse] using no)).reverse
  exact ⟨r,rp,by simp [r],by
    intro z
    simp only [r,support_reverse,List.mem_reverse,support_cons,List.mem_cons]⟩

/-- With an ambient universal root and at most one low exception, a
linear lower bound on prescribed-terminal routes needs no connectivity
of the root-deleted graph. -/
theorem one_low_universal_uniform_routes (A L : Finset V) (x : V) (xa : x∈A)
    (root : ∀ v∈A,v≠x → G.Adj x v)
    (one : L.card≤1)
    (m : Nat)
    (high : ∀ v∈A.erase x,v∉L → m≤((A.erase x).filter (G.Adj v)).card)
    (low : ∀ v∈A.erase x,v∈L → 1≤((A.erase x).filter (G.Adj v)).card) :
    ∀ u∈A,∀ v∈A,u≠v →
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ w∈q.support,w∈A) ∧ m+1≤q.length+1 := by
  classical
  let J := A.erase x
  have starAdj (v : V) (vj : v∈J) : G.Adj x v :=
    root v (mem_erase.mp vj).2 (mem_erase.mp vj).1
  have xNot : x∉J := by simp [J]
  have subJ (v : V) (vj : v∈J) : v∈A := (mem_erase.mp vj).2
  have high_floor (v : V) (vj : v∈J) (vL : v∉L) :
      m≤(J.filter (G.Adj v)).card := high v vj vL
  have toRoot (u : V) (uj : u∈J) :
      ∃ q : G.Walk u x,q.IsPath ∧ (∀ w∈q.support,w∈A) ∧ m+1≤q.length+1 := by
    by_cases ul : u∈L
    · obtain ⟨v,vv⟩ := card_pos.mp (show 0<(J.filter (G.Adj u)).card by
        have h := low u uj ul
        change 1≤(J.filter (G.Adj u)).card at h
        omega)
      obtain ⟨vj,edge⟩ := mem_filter.mp vv
      have vl : v∉L := fun h => edge.ne (card_le_one.mp one u ul v h)
      obtain ⟨z,p,pp,ps,pl⟩ := long_path_from_avoiding J L m v vj vl high_floor
      have pN : u∉p.support := fun h => (ps _ h).2 ul
      let r := Walk.cons edge p
      have rp : r.IsPath := pp.cons pN
      have rs (w : V) (h : w∈r.support) : w∈J := by
        have hh : w=u ∨ w∈p.support := by simpa [r] using h
        exact hh.elim (fun e => e.symm ▸ uj) (fun e => (ps _ e).1)
      obtain ⟨q,qp,ql,qs⟩ := push_end rp (starAdj z (ps _ p.end_mem_support).1).symm
        (fun h => xNot (rs _ h))
      refine ⟨q,qp,fun w mem => ((qs w).mp mem).elim (fun e => e.symm ▸ xa)
        (fun e => subJ w (rs _ e)),?_⟩
      simp [r] at ql
      omega
    · obtain ⟨z,p,pp,ps,pl⟩ := long_path_from_avoiding J L m u uj ul high_floor
      obtain ⟨q,qp,ql,qs⟩ := push_end pp (starAdj z (ps _ p.end_mem_support).1).symm
        (fun h => xNot (ps _ h).1)
      exact ⟨q,qp,fun w mem => ((qs w).mp mem).elim (fun e => e.symm ▸ xa)
        (fun e => subJ w (ps _ e).1),by omega⟩
  have ordered (u v : V) (uj : u∈J) (vj : v∈J) (ne : u≠v) (uL : u∉L) :
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ w∈q.support,w∈A) ∧ m+1≤q.length+1 := by
    let R := insert v L
    have uc : u∉R := fun h => (mem_insert.mp h).elim ne uL
    have rc : R.card≤2 := (card_insert_le _ _).trans (by omega)
    have rf (w : V) (wj : w∈J) (wr : w∉R) : m≤(J.filter (G.Adj w)).card :=
      high_floor w wj (fun e => wr (mem_insert.mpr (Or.inr e)))
    obtain ⟨z,p,pp,ps,pl⟩ := long_path_from_avoiding J R m u uj uc rf
    obtain ⟨q,qp,ql,qs⟩ := push_end pp (starAdj z (ps _ p.end_mem_support).1).symm
      (fun h => xNot (ps _ h).1)
    have vq : v∉q.support := fun h => ((qs v).mp h).elim
      (mem_erase.mp vj).1 (fun e => (ps v e).2 (mem_insert_self _ _))
    obtain ⟨s,sp,sl,ss⟩ := push_end qp (starAdj v vj) vq
    have sup (w : V) (ww : w∈s.support) : w∈A := ((ss w).mp ww).elim
      (fun e => e.symm ▸ subJ v vj) (fun e =>
        ((qs w).mp e).elim (fun e => e.symm ▸ xa) (fun e => subJ w (ps _ e).1))
    exact ⟨s,sp,sup,by omega⟩
  intro u ua v va ne
  have flip {a b : V} (f : ∃ q : G.Walk a b,q.IsPath ∧
      (∀ w∈q.support,w∈A) ∧ m+1≤q.length+1) :
      ∃ q : G.Walk b a,q.IsPath ∧ (∀ w∈q.support,w∈A) ∧ m+1≤q.length+1 := by
    obtain ⟨q,qp,qs,ql⟩ := f
    exact ⟨q.reverse,qp.reverse,fun w h => qs _ (by simpa only [support_reverse,List.mem_reverse] using h),
      by simpa using ql⟩
  by_cases ux : u=x
  · subst u
    exact flip (toRoot v (mem_erase.mpr ⟨ne.symm,va⟩))
  have uj : u∈J := mem_erase.mpr ⟨ux,ua⟩
  by_cases vx : v=x
  · subst v
    exact toRoot u uj
  have vj : v∈J := mem_erase.mpr ⟨vx,va⟩
  by_cases ul : u∈L
  · have vl : v∉L := fun h => ne (card_le_one.mp one u ul v h)
    exact flip (ordered v u vj uj ne.symm vl)
  exact ordered u v uj vj ne ul

#print axioms long_path_from_avoiding
#print axioms one_low_universal_uniform_routes
end Graffiti189LongestPath.GreedyTerminal

-- SOURCE RadialOrder189.lean
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open private Graffiti189LongestPath.mem_distanceTwo from SmallSeparator189
set_option warningAsError true
namespace Graffiti189LongestPath.RadialOrder
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem order_le_radius_four_layers (hc : G.Connected) (x : V)
    (rad : ∀ z,G.dist x z≤4) :
    Fintype.card V≤G.degree x+1+(DistanceTwo G x).card+
      (Shell G x 3).card+(Shell G x 4).card := by
  classical
  let N := G.neighborFinset x
  let F := DistanceTwo G x
  let H := Shell G x 3
  let W := Shell G x 4
  have cov : (univ:Finset V)⊆insert x (N∪F∪H∪W) := by
    intro z _
    by_cases zx : z=x
    · exact mem_insert.mpr (Or.inl zx)
    apply mem_insert.mpr
    right
    by_cases ez : G.dist x z=4
    · exact mem_union.mpr (Or.inr (mem_shell.mpr ez))
    apply mem_union.mpr
    left
    by_cases ez' : G.dist x z=3
    · exact mem_union.mpr (Or.inr (mem_shell.mpr ez'))
    apply mem_union.mpr
    left
    by_cases e₂ : G.dist x z=2
    · exact mem_union.mpr (Or.inr (Graffiti189LongestPath.mem_distanceTwo.mpr e₂))
    have one : G.dist x z=1 := by
      have nn : G.dist x z≠0 := fun e => zx (hc.dist_eq_zero_iff.mp e).symm
      have r := rad z
      omega
    exact mem_union.mpr (Or.inl ((G.mem_neighborFinset _ _).mpr (dist_eq_one_iff_adj.mp one)))
  have q := (card_le_card cov).trans (card_insert_le _ _)
  rw [card_univ] at q
  have a := card_union_le N F
  have b := card_union_le (N∪F) H
  have c := card_union_le (N∪F∪H) W
  have e : N.card=G.degree x := G.card_neighborFinset_eq_degree x
  change Fintype.card V≤G.degree x+1+F.card+H.card+W.card
  omega

omit [Fintype V] [DecidableEq V] in
theorem induced_degree_count (T : Finset V) (v : ↥(T:Set V)) :
    (T.filter (G.Adj v.val)).card=(G.induce (T:Set V)).degree v := by
  classical
  let J := G.induce (T:Set V)
  rw [←J.card_neighborFinset_eq_degree]
  refine card_bij' (fun u hu => (⟨u,(mem_filter.mp hu).1⟩ : ↥(T:Set V)))
    (fun w _ => w.val) ?_ ?_ ?_ ?_
  · intro u hu
    exact (J.mem_neighborFinset _ _).mpr (mem_filter.mp hu).2
  · intro u hu
    exact mem_filter.mpr ⟨u.property,(J.mem_neighborFinset _ _).mp hu⟩
  · intro u hu
    rfl
  · intro u hu
    exact Subtype.ext rfl

#print axioms order_le_radius_four_layers
end Graffiti189LongestPath.RadialOrder

-- SOURCE QuadraticShore189.lean
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack Graffiti189LongestPath.ActiveStarHeight
open Graffiti189LongestPath.ExactStarShore Graffiti189LongestPath.ShoreConnectivity Graffiti189LongestPath.ShoreDegrees
open Graffiti189LongestPath.ScaledCharge Graffiti189LongestPath.ScaledConnectivity Graffiti189LongestPath.StarCycleClosure
open Graffiti189LongestPath.Normalize Graffiti189LongestPath.PosaOneLow Graffiti189LongestPath.MengerRoutable Graffiti189LongestPath.FanWeighted
open Graffiti189LongestPath.CycleHallSplice Graffiti189LongestPath.UltraOrder Graffiti189LongestPath.SingleHeight
open private Graffiti189LongestPath.Rigidity.mem_external Graffiti189LongestPath.Rigidity.mem_omittedStar from Rigidity189
open private Graffiti189LongestPath.boundary_card_of_connectivity Graffiti189LongestPath.no_endpoints from SmallSeparator189
set_option warningAsError true
set_option linter.unusedVariables false
set_option maxHeartbeats 4500000
namespace Graffiti189LongestPath.QuadraticShore
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem quadratic_root_deleted_degrees (hc : G.Connected) (k sl loss : Nat) 
    (cap : ∀ v,(EvenFrom G v).card≤k+sl+1)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
   
    (sat : (External G (OmittedStar p x)).card≤k+loss)
    (far : k≤((univ:Finset V)\(OmittedStar p x∪External G (OmittedStar p x))).card)
    (v : ↥(((OmittedStar p x).erase x : Finset V) : Set V)) :
    (OmittedStar p x).card≤2*(G.induce (((OmittedStar p x).erase x : Finset V) : Set V)).degree v+sl+loss+3 ∧
      (k+sl≤G.degree v.val →
       (OmittedStar p x).card≤2*(G.induce (((OmittedStar p x).erase x : Finset V) : Set V)).degree v+loss+3) := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let U := univ\(A∪B)
  let T := A.erase x
  let J := G.induce (T : Set V)
  let I := G.induce (A : Set V)
  change B.card≤k+loss at sat
  have large : k≤U.card := far
  have rA {z : V} (hz : z∈U) : z∉A := fun h => (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inl h))
  have rB {z : V} (hz : z∈U) : z∉B := fun h => (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inr h))
  have ul : ∀ u∈U,∀ v∉U,G.Adj u v → v∈B := by
    intro u hu v hv ed
    have cov : v∈A∪B := Classical.byContradiction (fun h => hv (mem_sdiff.mpr ⟨mem_univ _,h⟩))
    exact (mem_union.mp cov).elim (fun h => (rB hu
      (Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨rA hu,v,h,ed.symm⟩)).elim) id
  have ub : Disjoint U B := disjoint_left.mpr (fun _ h h' => rB h h')
  have au : Disjoint A U := disjoint_left.mpr (fun _ h h' => rA h' h)
  have ab : Disjoint A B := disjoint_left.mpr (fun _ h h' =>
    (Graffiti189LongestPath.Rigidity.mem_external.mp h').1 h)
  have cA : ∀ y∈A,∀ z∉A,G.Adj y z → z∈B := fun _ hy _ hz e =>
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨hz,_,hy,e⟩
  have root : ∀ z∈A,z=x ∨ G.Adj x z := fun _ h =>
    (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp h).2
  have va : v.val∈A := (mem_erase.mp v.property).2
  have vo : v.val∉p.support := (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp va).1
  have vx : G.Adj v.val x := ((root _ va).resolve_left (mem_erase.mp v.property).1).symm
  have xa : x∈A := Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
  have low : k≤G.degree v.val := by
    have av : a≠v.val := fun e => vo (e ▸ p.start_mem_support)
    rw [←G.card_neighborFinset_eq_degree]
    apply Graffiti189LongestPath.boundary_card_of_connectivity k conn (A:={v.val}) (a:=a)
    · exact mem_singleton_self _
    · exact fun h => av (mem_singleton.mp h)
    · exact fun h => (Graffiti189LongestPath.no_endpoints hp vo).1 ((G.mem_neighborFinset _ _).mp h)
    · exact disjoint_left.mpr (fun _ h e => ((G.mem_neighborFinset v.val _).mp e).ne (mem_singleton.mp h).symm)
    · exact fun _ h _ _ e => (G.mem_neighborFinset _ _).mpr ((mem_singleton.mp h) ▸ e)
  let av : ↥(A : Set V) := ⟨v.val,va⟩
  have ineq := shore_charge_with_cut_deficit hc (k+sl) k loss A U B conn (by omega) ab ub au large
    cA ul (fun v => distanceTwo_le_of_even (k+sl) v (cap v)) root av
  change A.card+G.degree v.val+_≤2*I.degree av+(k+sl)+loss+1 at ineq
  have id := universal_root_degree_drop A x xa v vx
  change J.degree v+1=I.degree av at id
  change A.card≤2*J.degree v+sl+loss+3 ∧ (k+sl≤G.degree v.val → A.card≤2*J.degree v+loss+3)
  omega

#print axioms quadratic_root_deleted_degrees
end Graffiti189LongestPath.QuadraticShore

-- SOURCE QuadraticDeficit189.lean
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack Graffiti189LongestPath.PinRun
open Graffiti189LongestPath.DeficitActive Graffiti189LongestPath.ScaledActive Graffiti189LongestPath.DeficitLongest
open Graffiti189LongestPath.QuadraticShore
open Graffiti189LongestPath.GeneralGapMidpoint Graffiti189LongestPath.Normalize Graffiti189LongestPath.DeficitThirdShell
open Graffiti189LongestPath.StandaloneShellQuadratic Graffiti189LongestPath.RadialOrder
open Graffiti189LongestPath.GreedyTerminal Graffiti189LongestPath.FanWeighted Graffiti189LongestPath.MengerRoutable Graffiti189LongestPath.ActiveStarHeight
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
open private Graffiti189LongestPath.pin_data from SmallSeparator189
open private Graffiti189LongestPath.OneSlack.boundary_except_pins_two Graffiti189LongestPath.OneSlack.card_pinVertices
  Graffiti189LongestPath.OneSlack.pin_vertices_subset_boundary Graffiti189LongestPath.OneSlack.first_eq_if_no_pair from OneSlack189
set_option warningAsError true
set_option maxHeartbeats 7000000
namespace Graffiti189LongestPath.QuadraticDeficit
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- #189 in an explicit quadratic connectivity range, without needing
2-connectivity of the omitted shore.
No normalized attachment or separator geometry is assumed. -/
theorem traceable_of_quadratic_gap (hc : G.Connected) (k sl : Nat) (num : (k+sl+1)*(k+sl+1)+8*sl<2*k*(k+1)) (positive : 1≤sl)
    (cap : ∀ v,(EvenFrom G v).card≤k+sl+1)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → k+sl≤G.degree u ∨ k+sl≤G.degree v) :
    ∃ (u v : V) (q : G.Walk u v),q.IsPath ∧ ∀ z,z∈q.support := by
  classical
  apply Classical.byContradiction
  intro fail
  have kgt : 2*sl<k := by
    apply Nat.lt_of_not_ge
    intro ne
    have hh : 3*k+2≤2*(k+sl+1) := by omega
    have mul := Nat.mul_le_mul hh hh
    have q : (3*k+2)*(3*k+2)=9*(k*k)+12*k+4 := by ring
    have r : (2*(k+sl+1))*(2*(k+sl+1))=4*((k+sl+1)*(k+sl+1)) := by ring
    have e : 2*k*(k+1)=2*(k*k)+2*k := by ring
    omega
  have kmin : sl+3≤k := by
    by_contra! no
    have e : sl=1 ∧ k=3 := by omega
    obtain ⟨rfl,rfl⟩ := e
    norm_num at num
  obtain ⟨a,b,p,hmin⟩ := exists_edgeMinAvoid hc (k+sl) deg
  have hp := hmin.1.1
  have no : ∃ x,x∉p.support := Classical.byContradiction (fun h =>
    fail ⟨a,b,p,hp.1,fun z => Classical.byContradiction (fun e => h ⟨z,e⟩)⟩)
  obtain ⟨x,hx,xh,i,hi⟩ := scaled_deficit_has_high_active hc k sl (by omega) (by omega) cap conn deg hp no
  let d := k+sl
  let A := OmittedStar p x
  let B := External G A
  let P := PinVertices p x
  let C := B\P
  let H := Shell G x 3
  let W := Shell G x 4
  let U := (univ:Finset V)\(A∪B)
  have cap₂ (v : V) : (DistanceTwo G v).card≤d := distanceTwo_le_of_even d v (cap v)
  have pack := high_omitted_pin_budget hc d k cap conn hp hx (Graffiti189LongestPath.pin_data hi).2 xh
  have p3 : (Pins p x).card≤sl := by dsimp [d] at pack; omega
  have w3 : W.card≤sl := by change k+(Pins p x).card+W.card≤d at pack; dsimp [d] at pack; omega
  have rad (z : V) : G.dist x z≤4 := by
    by_contra! far
    have c := shell_card_of_far hc k conn (x:=x) (y:=z) (i:=4) (by decide) (by omega)
    change k≤W.card at c
    omega
  let loss := sl-(Pins p x).card
  have positivePin : 0<(Pins p x).card := card_pos.mpr ⟨i,hi⟩
  have lossSmall : loss+1≤sl := by dsimp [loss]; omega
  have height : k+loss+1≤A.card := by
    have e := star_card_degree_and_pins hp hx
    change A.card+(Pins p x).card=G.degree x+1 at e
    dsimp [loss]
    omega
  have ne : a≠x := fun e => hx (e ▸ p.start_mem_support)
  have enough := enough_vertices_of_degree (k+sl) deg ne
  have none := no_gap_two_at_connectivity_above_pin_twice hc (k+sl) k cap conn
    (by omega) hmin.1 hx xh (by omega)
  have bk : B.card≤k+loss := by
    have f := boundary_flank_count hc hp hx
    rw [flank_count_exact hp hx,Graffiti189LongestPath.OneSlack.first_eq_if_no_pair none] at f
    have c := cap₂ x
    change B.card+((Pins p x).card+(Pins p x).card)≤
      (DistanceTwo G x).card+(Pins p x).card at f
    dsimp [d] at c
    dsimp [loss]
    omega
  have floor (z : V) : 2≤G.degree z := by
    have ne : a≠x := fun e => hx (e ▸ p.start_mem_support)
    have n := enough_vertices_of_degree (k+sl) deg ne
    have kdeg := degree_floor_when_enough_vertices k conn (by omega) z
    omega
  have largeP := longest_length_ge_twice_of_not_traceable hc d (by omega) floor deg fail hp
  have far : k≤U.card := by
    have cover : p.support.toFinset⊆B∪U := by
      intro z hz
      by_cases zb : z∈B
      · exact mem_union.mpr (Or.inl zb)
      have za : z∉A := fun e => (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp e).1 (List.mem_toFinset.mp hz)
      exact mem_union.mpr (Or.inr (mem_sdiff.mpr ⟨mem_univ z,fun e => (mem_union.mp e).elim za zb⟩))
    have h := (card_le_card cover).trans (card_union_le B U)
    rw [List.toFinset_card_of_nodup hp.1.support_nodup,length_support] at h
    dsimp [d] at largeP
    omega
  let T := A.erase x
  let J := G.induce (T:Set V)
  let L := T.filter (fun v => G.degree v<d)
  let m := (k-1)/2
  have xA : x∈A := Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
  have L1 : L.card≤1 := by
    apply Nat.le_of_not_gt
    intro e
    obtain ⟨u,uu,v,vv,ne⟩ := one_lt_card.mp (show 1<L.card from e)
    have e₁ := (mem_filter.mp uu).2
    have e₂ := (mem_filter.mp vv).2
    exact (deg u v ne).elim (Nat.not_le_of_lt e₁) (Nat.not_le_of_lt e₂)
  have highJ (v : V) (vt : v∈T) (vl : v∉L) : m≤(T.filter (G.Adj v)).card := by
    let v' : ↥(T:Set V) := ⟨v,vt⟩
    have vh : d≤G.degree v := Nat.le_of_not_gt (fun h => vl (mem_filter.mpr ⟨vt,h⟩))
    have b := (quadratic_root_deleted_degrees hc k sl loss cap conn hp hx bk far v').2 vh
    change A.card≤2*J.degree v'+loss+3 at b
    have id := induced_degree_count (G:=G) T v'
    change (T.filter (G.Adj v)).card=J.degree v' at id
    dsimp [m]
    omega
  have lowJ (v : V) (vt : v∈T) (_vl : v∈L) : 1≤(T.filter (G.Adj v)).card := by
    let v' : ↥(T:Set V) := ⟨v,vt⟩
    have b := (quadratic_root_deleted_degrees hc k sl loss cap conn hp hx bk far v').1
    change A.card≤2*J.degree v'+sl+loss+3 at b
    have id := induced_degree_count (G:=G) T v'
    change (T.filter (G.Adj v)).card=J.degree v' at id
    omega
  have root (v : V) (va : v∈A) (ne : v≠x) : G.Adj x v :=
    ((Graffiti189LongestPath.Rigidity.mem_omittedStar.mp va).2).resolve_left ne
  have routes := one_low_universal_uniform_routes A L x xA root L1 m highJ lowJ
  have ao : ∀ v∈A,v∉p.support := fun _ va =>
    (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp va).1
  obtain ⟨F⟩ := hooks_of_small_deletion_connectivity A k hp ao (by omega) (support_large k conn hp hx) conn
  have bound := weighted_hooked_lower k (by omega) hp (m+1) A ao (by omega) routes F
  have low : A.card+k+(k+1)*(m+1)≤Fintype.card V := by omega
  have shell := universal_shell_three_quadratic hc d cap₂ x
  change 4*H.card≤(d+1)*(d+1) at shell
  have order := order_le_radius_four_layers hc x rad
  change Fintype.card V≤G.degree x+1+(DistanceTwo G x).card+H.card+W.card at order
  have base : Fintype.card V≤A.card+k+2*sl+H.card := by
    have d₂ := cap₂ x
    have degX := star_card_degree_and_pins hp hx
    change A.card+(Pins p x).card=G.degree x+1 at degX
    change k+(Pins p x).card+W.card≤d at pack
    dsimp [d] at d₂ pack
    omega
  have ratio : 2*k*(k+1)≤4*((k+1)*(m+1)) := by
    have mlarge : k≤2*(m+1) := by dsimp [m]; omega
    calc
      _ = (2*(k+1))*k := by ring
      _ ≤ (2*(k+1))*(2*(m+1)) := Nat.mul_le_mul_left _ mlarge
      _ = _ := by ring
  have b : 4*Fintype.card V<4*(A.card+k+(k+1)*(m+1)) := by
    calc
      _ ≤ 4*(A.card+k+2*sl+H.card) := Nat.mul_le_mul_left 4 base
      _ = 4*(A.card+k)+(4*H.card+8*sl) := by ring
      _ ≤ 4*(A.card+k)+((d+1)*(d+1)+8*sl) :=
        Nat.add_le_add_left (Nat.add_le_add_right shell _) _
      _ < 4*(A.card+k)+2*k*(k+1) := Nat.add_lt_add_left num _
      _ ≤ 4*(A.card+k)+4*((k+1)*(m+1)) := Nat.add_le_add_left ratio _
      _ = _ := by ring
  omega

/-- Explicit degree/connectivity form; the ratio tends to 1/√2. -/
theorem traceable_of_quadratic_connectivity (hc : G.Connected) (d k : Nat)
    (quad : (d+1)*(d+1)+8*(d-k)<2*k*(k+1))
    (cap : ∀ v,(EvenFrom G v).card≤d+1)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → d≤G.degree u ∨ d≤G.degree v) :
    ∃ (u v : V) (q : G.Walk u v),q.IsPath ∧ ∀ z,z∈q.support := by
  by_cases hk : d≤k
  · exact traceable_of_even_and_connectivity hc d cap (fun S sc => conn S (sc.trans_le hk))
  have eq : k+(d-k)=d := by omega
  exact traceable_of_quadratic_gap hc k (d-k) (by simpa only [eq] using quad) (by omega)
    (by simpa only [eq] using cap) conn (by simpa only [eq] using deg)

#print axioms traceable_of_quadratic_gap
#print axioms traceable_of_quadratic_connectivity
end Graffiti189LongestPath.QuadraticDeficit
