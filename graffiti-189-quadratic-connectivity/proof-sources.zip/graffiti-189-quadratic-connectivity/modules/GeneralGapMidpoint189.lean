import WideRatioDeficitAll189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.Normalize Graffiti189LongestPath.OneSlack
open Graffiti189LongestPath.GapTwin Graffiti189LongestPath.DeficitActive
open private Graffiti189LongestPath.GapTwin.splice_gap_two_allow_midpoint Graffiti189LongestPath.GapTwin.edgeCount from GapTwin189
open private Graffiti189LongestPath.mem_distanceTwo Graffiti189LongestPath.dist_two Graffiti189LongestPath.pin_data Graffiti189LongestPath.splice_gap_two from SmallSeparator189
open private Graffiti189LongestPath.OneSlack.nonconsecutive_boundary Graffiti189LongestPath.OneSlack.pin_vertices_subset_boundary
  Graffiti189LongestPath.OneSlack.card_pinVertices Graffiti189LongestPath.OneSlack.pin_of_neighbor_mem from OneSlack189
set_option warningAsError true
set_option maxHeartbeats 5500000
namespace Graffiti189LongestPath.GeneralGapMidpoint
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- A gap-two midpoint has degree at most twice the total number of pins,
even when the porter has additional attachments. -/
theorem gap_midpoint_degree_le_twice_pins (hc : G.Connected) (d : Nat)
    (cap : ∀ w,(EvenFrom G w).card≤d+1)
    {a b x : V} {p : G.Walk a b} (hmin : EdgeMin p) (hx : x∉p.support)
    (high : d≤G.degree x)
    {i : Nat} (ip : i∈Pins p x) (jp : i+2∈Pins p x) :
    G.degree (p.getVert (i+1))≤2*(Pins p x).card := by
  classical
  have hp := hmin.1
  let l := p.getVert i
  let z := p.getVert (i+1)
  let r := p.getVert (i+2)
  have il := (Graffiti189LongestPath.pin_data ip).1
  have jl := (Graffiti189LongestPath.pin_data jp).1
  have lx : G.Adj x l := (Graffiti189LongestPath.pin_data ip).2
  have rx : G.Adj x r := (Graffiti189LongestPath.pin_data jp).2
  have lz : G.Adj l z := p.adj_getVert_succ (i:=i) (by omega)
  have zr : G.Adj z r := p.adj_getVert_succ (i:=i+1) (by omega)
  have zx : z≠x := fun e => hx (e ▸ p.getVert_mem_support (i+1))
  have zOld : z∈p.support.toFinset := List.mem_toFinset.mpr (p.getVert_mem_support (i+1))
  let S := p.support.toFinset.erase z
  have xS : x∉S := fun h => hx (List.mem_toFinset.mp (mem_erase.mp h).2)
  have zS : z∉S := by simp [S]
  have oldset : p.support.toFinset=insert z S := (insert_erase zOld).symm
  have noxz : ¬G.Adj x z := by
    intro edge
    have j : i+1∈Pins p x := mem_filter.mpr ⟨mem_range.mpr (by omega),edge⟩
    have li : l∈External G (OmittedStar p x) :=
      Graffiti189LongestPath.OneSlack.pin_vertices_subset_boundary hx (mem_image.mpr ⟨i,ip,rfl⟩)
    have zi : z∈External G (OmittedStar p x) :=
      Graffiti189LongestPath.OneSlack.pin_vertices_subset_boundary hx (mem_image.mpr ⟨i+1,j,rfl⟩)
    exact Graffiti189LongestPath.OneSlack.nonconsecutive_boundary hp hx il li zi
  have eraseInt (w : V) (no : ¬G.Adj w z) :
      G.neighborFinset w∩p.support.toFinset=G.neighborFinset w∩S := by
    ext v
    rw [mem_inter,mem_inter]
    constructor
    · rintro ⟨vn,vp⟩
      exact ⟨vn,mem_erase.mpr ⟨fun e => no (e ▸ (G.mem_neighborFinset _ _).mp vn),vp⟩⟩
    · rintro ⟨vn,vs⟩
      exact ⟨vn,(mem_erase.mp vs).2⟩
  have xeq : G.neighborFinset x ∩ p.support.toFinset=PinVertices p x := by
    ext v
    constructor
    · intro h
      obtain ⟨vn,vp⟩ := mem_inter.mp h
      obtain ⟨j,jp,e⟩ := Graffiti189LongestPath.OneSlack.pin_of_neighbor_mem hp hx
        (List.mem_toFinset.mp vp) ((G.mem_neighborFinset _ _).mp vn)
      exact mem_image.mpr ⟨j,jp,e⟩
    · intro h
      obtain ⟨j,jp,rfl⟩ := mem_image.mp h
      exact mem_inter.mpr ⟨(G.mem_neighborFinset _ _).mpr (Graffiti189LongestPath.pin_data jp).2,
        List.mem_toFinset.mpr (p.getVert_mem_support j)⟩
  obtain ⟨q,hq,hLen,hSupp⟩ :=
    Graffiti189LongestPath.splice_gap_two p hp.1 (Walk.nil : G.Walk x x) IsPath.nil
      (by simpa using hx) i (by omega) lx.symm rx
  have len : q.length=p.length := by simpa using hLen
  have qLongest : IsLongest q := ⟨hq,fun a b w hw => len.symm ▸ hp.2 a b w hw⟩
  have qset : q.support.toFinset=insert x S := by
    ext w
    simp only [List.mem_toFinset, hSupp, support_nil, List.mem_singleton, mem_insert, S, mem_erase]
    tauto
  have cn := hmin.2 a b q qLongest
  rw [oldset,qset,Graffiti189LongestPath.GapTwin.edgeCount zS,
    Graffiti189LongestPath.GapTwin.edgeCount xS,←eraseInt x noxz,xeq,
    Graffiti189LongestPath.OneSlack.card_pinVertices hp,
    ←eraseInt z (G.loopless z)] at cn
  let X := G.neighborFinset x\p.support.toFinset
  let Z := G.neighborFinset z\p.support.toFinset
  have xOff {w : V} (hw : w∈X) : w∉p.support :=
    fun e => (mem_sdiff.mp hw).2 (List.mem_toFinset.mpr e)
  have zOff {w : V} (hw : w∈Z) : w∉p.support :=
    fun e => (mem_sdiff.mp hw).2 (List.mem_toFinset.mpr e)
  have noflankX {w : V} (hw : w ∈ X) : ¬G.Adj w l := by
    intro h
    have ed := (G.mem_neighborFinset x w).mp (mem_sdiff.mp hw).1
    obtain ⟨q,hq,hLen,_⟩ := Graffiti189LongestPath.splice_gap_two p hp.1 ed.symm.toWalk
      (IsPath.of_adj _)
      (by simp [xOff hw,hx]) i (by omega) h.symm rx
    have hL := hp.2 a b q hq
    simp at hLen
    omega
  have noflankZ {w : V} (hw : w ∈ Z) : ¬G.Adj w l := by
    intro h
    have ed := (G.mem_neighborFinset z w).mp (mem_sdiff.mp hw).1
    -- Avoid the old midpoint only: the replacement can finish at that midpoint.
    obtain ⟨q,hq,hLen,_⟩ := Graffiti189LongestPath.GapTwin.splice_gap_two_allow_midpoint p hp.1 ed.symm.toWalk
      (IsPath.of_adj _) i (by
        intro t ht tp
        have h' : t = w ∨ t = z := by simpa using ht
        exact h'.elim (fun h => (zOff hw (h ▸ tp)).elim) id)
      (by omega) h.symm zr
    have hL := hp.2 a b q hq
    simp at hLen
    omega
  have dis : Disjoint X Z := disjoint_left.mpr (by
    intro w hX hZ
    have xw := (G.mem_neighborFinset x w).mp (mem_sdiff.mp hX).1
    have wz := (G.mem_neighborFinset z w).mp (mem_sdiff.mp hZ).1 |>.symm
    let t : G.Walk x z := Walk.cons xw (Walk.cons wz Walk.nil)
    have hW : t.IsPath := ((IsPath.of_adj wz).cons (by simp [xw.ne,zx.symm]))
    obtain ⟨q,hq,hLen,_⟩ := Graffiti189LongestPath.GapTwin.splice_gap_two_allow_midpoint p hp.1 t hW i (by
      intro u hu hp'
      have hh : u = x ∨ u = w ∨ u = z := by simpa [t] using hu
      exact hh.elim (fun h => (hx (h ▸ hp')).elim)
        (fun h => h.elim (fun he => (xOff hX (he ▸ hp')).elim) id))
      (by omega) lx.symm zr
    have hL := hp.2 a b q hq
    simp [t] at hLen
    omega)
  have sub : X ∪ Z ⊆ DistanceTwo G l := by
    intro w hw
    have lmem := p.getVert_mem_support i
    apply Graffiti189LongestPath.mem_distanceTwo.mpr
    rcases mem_union.mp hw with h | h
    · exact Graffiti189LongestPath.dist_two hc (fun e => xOff h (e ▸ lmem))
        (fun e => noflankX h e.symm) lx.symm
        ((G.mem_neighborFinset x w).mp (mem_sdiff.mp h).1)
    · exact Graffiti189LongestPath.dist_two hc (fun e => zOff h (e ▸ lmem))
        (fun e => noflankZ h e.symm) lz
        ((G.mem_neighborFinset z w).mp (mem_sdiff.mp h).1)
  have cu := card_le_card sub
  rw [card_union_of_disjoint dis] at cu
  have cx := card_sdiff_add_card_inter (G.neighborFinset x) p.support.toFinset
  have cz := card_sdiff_add_card_inter (G.neighborFinset z) p.support.toFinset
  rw [xeq,Graffiti189LongestPath.OneSlack.card_pinVertices hp,G.card_neighborFinset_eq_degree] at cx
  rw [G.card_neighborFinset_eq_degree] at cz
  change X.card+(Pins p x).card=G.degree x at cx
  change Z.card+(G.neighborFinset z∩p.support.toFinset).card=G.degree z at cz
  have bd := distanceTwo_le_of_even d l (cap l)
  change G.degree z≤2*(Pins p x).card
  omega

/-- If the graph connectivity exceeds twice the pin budget, all pins
are separated by at least three positions on a minimum-edge longest path. -/
theorem no_gap_two_at_connectivity_above_pin_twice (hc : G.Connected) (d k : Nat)
    (cap : ∀ w,(EvenFrom G w).card≤d+1)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (enough : k+1≤Fintype.card V)
    {a b x : V} {p : G.Walk a b} (hmin : EdgeMin p) (hx : x∉p.support)
    (high : d≤G.degree x) (small : 2*(Pins p x).card<k) :
    PairedPins p x=∅ := by
  apply eq_empty_iff_forall_not_mem.mpr
  intro i hi
  obtain ⟨ii,j,jj,paired⟩ := mem_filter.mp hi
  have impossible (t : Nat) (tp : t∈Pins p x) (tn : t+2∈Pins p x) : False := by
    have lo := degree_floor_when_enough_vertices k conn enough (p.getVert (t+1))
    have upper := gap_midpoint_degree_le_twice_pins hc d cap hmin hx high tp tn
    omega
  rcases paired with e|e
  · exact impossible j jj (e.symm ▸ ii)
  · exact impossible i ii (e.symm ▸ jj)

#print axioms gap_midpoint_degree_le_twice_pins
#print axioms no_gap_two_at_connectivity_above_pin_twice
end Graffiti189LongestPath.GeneralGapMidpoint
