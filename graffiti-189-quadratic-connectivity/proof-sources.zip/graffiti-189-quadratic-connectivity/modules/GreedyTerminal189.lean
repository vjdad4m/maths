import WideRatioDeficitAll189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
set_option warningAsError true
set_option maxHeartbeats 5300000
namespace Graffiti189LongestPath.GreedyTerminal
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- A path from a specified vertex can be greedily extended within a
permitted set. Any unused endpoint neighbor is forbidden by maximality. -/
theorem long_path_from_avoiding (T R : Finset V) (m : Nat) (u : V)
    (ut : u∈T) (ur : u∉R)
    (floor : ∀ v∈T,v∉R → m≤(T.filter (G.Adj v)).card) :
    ∃ v,∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈T ∧ z∉R) ∧
      m≤q.length+R.card := by
  classical
  let L := (range (Fintype.card V)).filter (fun i =>
    ∃ v,∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈T ∧ z∉R) ∧ q.length=i)
  have c : 0<Fintype.card V := Fintype.card_pos_iff.mpr ⟨u⟩
  have nils : ∀ z∈(Walk.nil : G.Walk u u).support,z∈T ∧ z∉R := by
    intro z h
    have zz : z=u := by simpa using h
    exact zz.symm ▸ ⟨ut,ur⟩
  have zero : 0∈L := mem_filter.mpr ⟨mem_range.mpr c,u,.nil,IsPath.nil,nils,rfl⟩
  obtain ⟨v,p,pp,ps,pl⟩ := (mem_filter.mp (L.max'_mem ⟨0,zero⟩)).2
  have maximal (w : V) (q : G.Walk u w) (qp : q.IsPath)
      (qs : ∀ z∈q.support,z∈T ∧ z∉R) : q.length≤p.length := by
    rw [pl]
    exact L.le_max' _ (mem_filter.mpr ⟨mem_range.mpr qp.length_lt,w,q,qp,qs,rfl⟩)
  have nb : T.filter (G.Adj v)⊆R∪p.support.toFinset.erase v := by
    intro z hz
    obtain ⟨zt,ed⟩ := mem_filter.mp hz
    by_cases zr : z∈R
    · exact mem_union.mpr (Or.inl zr)
    apply mem_union.mpr
    right
    refine mem_erase.mpr ⟨ed.ne.symm,List.mem_toFinset.mpr ?_⟩
    apply Classical.byContradiction
    intro no
    let q := (Walk.cons ed.symm p.reverse).reverse
    have qp : q.IsPath := (pp.reverse.cons (by simpa only [support_reverse,List.mem_reverse] using no)).reverse
    have qs (w : V) (h : w∈q.support) : w∈T ∧ w∉R := by
      have r : w=z ∨ w∈p.support := by
        simpa only [q,support_reverse,List.mem_reverse,support_cons,List.mem_cons] using h
      exact r.elim (fun e => e.symm ▸ ⟨zt,zr⟩) (ps w)
    have l := maximal z q qp qs
    simp [q] at l
  have c' := (card_le_card nb).trans (card_union_le _ _)
  rw [card_erase_of_mem (List.mem_toFinset.mpr p.end_mem_support),
    List.toFinset_card_of_nodup pp.support_nodup,length_support,Nat.add_sub_cancel] at c'
  exact ⟨v,p,pp,ps,by have l := floor v (ps v p.end_mem_support).1 (ps v p.end_mem_support).2; omega⟩

omit [Fintype V] [DecidableEq V] [DecidableRel G.Adj] in
private theorem push_end {u v x : V} {q : G.Walk u v} (p : q.IsPath)
    (e : G.Adj v x) (no : x∉q.support) :
    ∃ r : G.Walk u x,r.IsPath ∧ r.length=q.length+1 ∧
      ∀ z,z∈r.support ↔ z=x ∨ z∈q.support := by
  let r := (Walk.cons e.symm q.reverse).reverse
  have rp : r.IsPath := (p.reverse.cons (by simpa only [support_reverse,List.mem_reverse] using no)).reverse
  exact ⟨r,rp,by simp [r],by
    intro z
    simp only [r,support_reverse,List.mem_reverse,support_cons,List.mem_cons]⟩

/-- With an ambient universal root and at most one low exception, a
linear lower bound on prescribed-terminal routes needs no connectivity
of the root-deleted graph. -/
theorem one_low_universal_uniform_routes (A L : Finset V) (x : V) (xa : x∈A)
    (root : ∀ v∈A,v≠x → G.Adj x v)
    (one : L.card≤1)
    (m : Nat)
    (high : ∀ v∈A.erase x,v∉L → m≤((A.erase x).filter (G.Adj v)).card)
    (low : ∀ v∈A.erase x,v∈L → 1≤((A.erase x).filter (G.Adj v)).card) :
    ∀ u∈A,∀ v∈A,u≠v →
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ w∈q.support,w∈A) ∧ m+1≤q.length+1 := by
  classical
  let J := A.erase x
  have starAdj (v : V) (vj : v∈J) : G.Adj x v :=
    root v (mem_erase.mp vj).2 (mem_erase.mp vj).1
  have xNot : x∉J := by simp [J]
  have subJ (v : V) (vj : v∈J) : v∈A := (mem_erase.mp vj).2
  have high_floor (v : V) (vj : v∈J) (vL : v∉L) :
      m≤(J.filter (G.Adj v)).card := high v vj vL
  have toRoot (u : V) (uj : u∈J) :
      ∃ q : G.Walk u x,q.IsPath ∧ (∀ w∈q.support,w∈A) ∧ m+1≤q.length+1 := by
    by_cases ul : u∈L
    · obtain ⟨v,vv⟩ := card_pos.mp (show 0<(J.filter (G.Adj u)).card by
        have h := low u uj ul
        change 1≤(J.filter (G.Adj u)).card at h
        omega)
      obtain ⟨vj,edge⟩ := mem_filter.mp vv
      have vl : v∉L := fun h => edge.ne (card_le_one.mp one u ul v h)
      obtain ⟨z,p,pp,ps,pl⟩ := long_path_from_avoiding J L m v vj vl high_floor
      have pN : u∉p.support := fun h => (ps _ h).2 ul
      let r := Walk.cons edge p
      have rp : r.IsPath := pp.cons pN
      have rs (w : V) (h : w∈r.support) : w∈J := by
        have hh : w=u ∨ w∈p.support := by simpa [r] using h
        exact hh.elim (fun e => e.symm ▸ uj) (fun e => (ps _ e).1)
      obtain ⟨q,qp,ql,qs⟩ := push_end rp (starAdj z (ps _ p.end_mem_support).1).symm
        (fun h => xNot (rs _ h))
      refine ⟨q,qp,fun w mem => ((qs w).mp mem).elim (fun e => e.symm ▸ xa)
        (fun e => subJ w (rs _ e)),?_⟩
      simp [r] at ql
      omega
    · obtain ⟨z,p,pp,ps,pl⟩ := long_path_from_avoiding J L m u uj ul high_floor
      obtain ⟨q,qp,ql,qs⟩ := push_end pp (starAdj z (ps _ p.end_mem_support).1).symm
        (fun h => xNot (ps _ h).1)
      exact ⟨q,qp,fun w mem => ((qs w).mp mem).elim (fun e => e.symm ▸ xa)
        (fun e => subJ w (ps _ e).1),by omega⟩
  have ordered (u v : V) (uj : u∈J) (vj : v∈J) (ne : u≠v) (uL : u∉L) :
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ w∈q.support,w∈A) ∧ m+1≤q.length+1 := by
    let R := insert v L
    have uc : u∉R := fun h => (mem_insert.mp h).elim ne uL
    have rc : R.card≤2 := (card_insert_le _ _).trans (by omega)
    have rf (w : V) (wj : w∈J) (wr : w∉R) : m≤(J.filter (G.Adj w)).card :=
      high_floor w wj (fun e => wr (mem_insert.mpr (Or.inr e)))
    obtain ⟨z,p,pp,ps,pl⟩ := long_path_from_avoiding J R m u uj uc rf
    obtain ⟨q,qp,ql,qs⟩ := push_end pp (starAdj z (ps _ p.end_mem_support).1).symm
      (fun h => xNot (ps _ h).1)
    have vq : v∉q.support := fun h => ((qs v).mp h).elim
      (mem_erase.mp vj).1 (fun e => (ps v e).2 (mem_insert_self _ _))
    obtain ⟨s,sp,sl,ss⟩ := push_end qp (starAdj v vj) vq
    have sup (w : V) (ww : w∈s.support) : w∈A := ((ss w).mp ww).elim
      (fun e => e.symm ▸ subJ v vj) (fun e =>
        ((qs w).mp e).elim (fun e => e.symm ▸ xa) (fun e => subJ w (ps _ e).1))
    exact ⟨s,sp,sup,by omega⟩
  intro u ua v va ne
  have flip {a b : V} (f : ∃ q : G.Walk a b,q.IsPath ∧
      (∀ w∈q.support,w∈A) ∧ m+1≤q.length+1) :
      ∃ q : G.Walk b a,q.IsPath ∧ (∀ w∈q.support,w∈A) ∧ m+1≤q.length+1 := by
    obtain ⟨q,qp,qs,ql⟩ := f
    exact ⟨q.reverse,qp.reverse,fun w h => qs _ (by simpa only [support_reverse,List.mem_reverse] using h),
      by simpa using ql⟩
  by_cases ux : u=x
  · subst u
    exact flip (toRoot v (mem_erase.mpr ⟨ne.symm,va⟩))
  have uj : u∈J := mem_erase.mpr ⟨ux,ua⟩
  by_cases vx : v=x
  · subst v
    exact toRoot u uj
  have vj : v∈J := mem_erase.mpr ⟨vx,va⟩
  by_cases ul : u∈L
  · have vl : v∉L := fun h => ne (card_le_one.mp one u ul v h)
    exact flip (ordered v u vj uj ne.symm vl)
  exact ordered u v uj vj ne ul

#print axioms long_path_from_avoiding
#print axioms one_low_universal_uniform_routes
end Graffiti189LongestPath.GreedyTerminal
