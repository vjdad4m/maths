import PosaOneLow189
import WideRatioDeficitAll189
import FanWeighted189
import MengerRoutable189
import SingleHeight189
import StarCycleClosure189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack Graffiti189LongestPath.ActiveStarHeight
open Graffiti189LongestPath.ExactStarShore Graffiti189LongestPath.ShoreConnectivity Graffiti189LongestPath.ShoreDegrees
open Graffiti189LongestPath.ScaledCharge Graffiti189LongestPath.ScaledConnectivity Graffiti189LongestPath.StarCycleClosure
open Graffiti189LongestPath.Normalize Graffiti189LongestPath.PosaOneLow Graffiti189LongestPath.MengerRoutable Graffiti189LongestPath.FanWeighted
open Graffiti189LongestPath.CycleHallSplice Graffiti189LongestPath.UltraOrder Graffiti189LongestPath.SingleHeight
open private Graffiti189LongestPath.Rigidity.mem_external Graffiti189LongestPath.Rigidity.mem_omittedStar from Rigidity189
open private Graffiti189LongestPath.boundary_card_of_connectivity Graffiti189LongestPath.no_endpoints from SmallSeparator189
set_option warningAsError true
set_option linter.unusedVariables false
set_option maxHeartbeats 4500000
namespace Graffiti189LongestPath.QuadraticShore
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem quadratic_root_deleted_degrees (hc : G.Connected) (k sl loss : Nat) 
    (cap : ∀ v,(EvenFrom G v).card≤k+sl+1)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    {a b x : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
   
    (sat : (External G (OmittedStar p x)).card≤k+loss)
    (far : k≤((univ:Finset V)\(OmittedStar p x∪External G (OmittedStar p x))).card)
    (v : ↥(((OmittedStar p x).erase x : Finset V) : Set V)) :
    (OmittedStar p x).card≤2*(G.induce (((OmittedStar p x).erase x : Finset V) : Set V)).degree v+sl+loss+3 ∧
      (k+sl≤G.degree v.val →
       (OmittedStar p x).card≤2*(G.induce (((OmittedStar p x).erase x : Finset V) : Set V)).degree v+loss+3) := by
  classical
  let A := OmittedStar p x
  let B := External G A
  let U := univ\(A∪B)
  let T := A.erase x
  let J := G.induce (T : Set V)
  let I := G.induce (A : Set V)
  change B.card≤k+loss at sat
  have large : k≤U.card := far
  have rA {z : V} (hz : z∈U) : z∉A := fun h => (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inl h))
  have rB {z : V} (hz : z∈U) : z∉B := fun h => (mem_sdiff.mp hz).2 (mem_union.mpr (Or.inr h))
  have ul : ∀ u∈U,∀ v∉U,G.Adj u v → v∈B := by
    intro u hu v hv ed
    have cov : v∈A∪B := Classical.byContradiction (fun h => hv (mem_sdiff.mpr ⟨mem_univ _,h⟩))
    exact (mem_union.mp cov).elim (fun h => (rB hu
      (Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨rA hu,v,h,ed.symm⟩)).elim) id
  have ub : Disjoint U B := disjoint_left.mpr (fun _ h h' => rB h h')
  have au : Disjoint A U := disjoint_left.mpr (fun _ h h' => rA h' h)
  have ab : Disjoint A B := disjoint_left.mpr (fun _ h h' =>
    (Graffiti189LongestPath.Rigidity.mem_external.mp h').1 h)
  have cA : ∀ y∈A,∀ z∉A,G.Adj y z → z∈B := fun _ hy _ hz e =>
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨hz,_,hy,e⟩
  have root : ∀ z∈A,z=x ∨ G.Adj x z := fun _ h =>
    (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp h).2
  have va : v.val∈A := (mem_erase.mp v.property).2
  have vo : v.val∉p.support := (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp va).1
  have vx : G.Adj v.val x := ((root _ va).resolve_left (mem_erase.mp v.property).1).symm
  have xa : x∈A := Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
  have low : k≤G.degree v.val := by
    have av : a≠v.val := fun e => vo (e ▸ p.start_mem_support)
    rw [←G.card_neighborFinset_eq_degree]
    apply Graffiti189LongestPath.boundary_card_of_connectivity k conn (A:={v.val}) (a:=a)
    · exact mem_singleton_self _
    · exact fun h => av (mem_singleton.mp h)
    · exact fun h => (Graffiti189LongestPath.no_endpoints hp vo).1 ((G.mem_neighborFinset _ _).mp h)
    · exact disjoint_left.mpr (fun _ h e => ((G.mem_neighborFinset v.val _).mp e).ne (mem_singleton.mp h).symm)
    · exact fun _ h _ _ e => (G.mem_neighborFinset _ _).mpr ((mem_singleton.mp h) ▸ e)
  let av : ↥(A : Set V) := ⟨v.val,va⟩
  have ineq := shore_charge_with_cut_deficit hc (k+sl) k loss A U B conn (by omega) ab ub au large
    cA ul (fun v => distanceTwo_le_of_even (k+sl) v (cap v)) root av
  change A.card+G.degree v.val+_≤2*I.degree av+(k+sl)+loss+1 at ineq
  have id := universal_root_degree_drop A x xa v vx
  change J.degree v+1=I.degree av at id
  change A.card≤2*J.degree v+sl+loss+3 ∧ (k+sl≤G.degree v.val → A.card≤2*J.degree v+loss+3)
  omega

#print axioms quadratic_root_deleted_degrees
end Graffiti189LongestPath.QuadraticShore
