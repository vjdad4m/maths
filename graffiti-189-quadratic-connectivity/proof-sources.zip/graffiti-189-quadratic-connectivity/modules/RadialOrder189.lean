import WideRatioDeficitAll189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open private Graffiti189LongestPath.mem_distanceTwo from SmallSeparator189
set_option warningAsError true
namespace Graffiti189LongestPath.RadialOrder
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem order_le_radius_four_layers (hc : G.Connected) (x : V)
    (rad : ∀ z,G.dist x z≤4) :
    Fintype.card V≤G.degree x+1+(DistanceTwo G x).card+
      (Shell G x 3).card+(Shell G x 4).card := by
  classical
  let N := G.neighborFinset x
  let F := DistanceTwo G x
  let H := Shell G x 3
  let W := Shell G x 4
  have cov : (univ:Finset V)⊆insert x (N∪F∪H∪W) := by
    intro z _
    by_cases zx : z=x
    · exact mem_insert.mpr (Or.inl zx)
    apply mem_insert.mpr
    right
    by_cases ez : G.dist x z=4
    · exact mem_union.mpr (Or.inr (mem_shell.mpr ez))
    apply mem_union.mpr
    left
    by_cases ez' : G.dist x z=3
    · exact mem_union.mpr (Or.inr (mem_shell.mpr ez'))
    apply mem_union.mpr
    left
    by_cases e₂ : G.dist x z=2
    · exact mem_union.mpr (Or.inr (Graffiti189LongestPath.mem_distanceTwo.mpr e₂))
    have one : G.dist x z=1 := by
      have nn : G.dist x z≠0 := fun e => zx (hc.dist_eq_zero_iff.mp e).symm
      have r := rad z
      omega
    exact mem_union.mpr (Or.inl ((G.mem_neighborFinset _ _).mpr (dist_eq_one_iff_adj.mp one)))
  have q := (card_le_card cov).trans (card_insert_le _ _)
  rw [card_univ] at q
  have a := card_union_le N F
  have b := card_union_le (N∪F) H
  have c := card_union_le (N∪F∪H) W
  have e : N.card=G.degree x := G.card_neighborFinset_eq_degree x
  change Fintype.card V≤G.degree x+1+F.card+H.card+W.card
  omega

omit [Fintype V] [DecidableEq V] in
theorem induced_degree_count (T : Finset V) (v : ↥(T:Set V)) :
    (T.filter (G.Adj v.val)).card=(G.induce (T:Set V)).degree v := by
  classical
  let J := G.induce (T:Set V)
  rw [←J.card_neighborFinset_eq_degree]
  refine card_bij' (fun u hu => (⟨u,(mem_filter.mp hu).1⟩ : ↥(T:Set V)))
    (fun w _ => w.val) ?_ ?_ ?_ ?_
  · intro u hu
    exact (J.mem_neighborFinset _ _).mpr (mem_filter.mp hu).2
  · intro u hu
    exact mem_filter.mpr ⟨u.property,(J.mem_neighborFinset _ _).mp hu⟩
  · intro u hu
    rfl
  · intro u hu
    exact Subtype.ext rfl

#print axioms order_le_radius_four_layers
end Graffiti189LongestPath.RadialOrder
