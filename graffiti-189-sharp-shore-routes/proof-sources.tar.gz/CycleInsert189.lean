import Mathlib.Combinatorics.SimpleGraph.Path
open SimpleGraph SimpleGraph.Walk
set_option warningAsError true
namespace Graffiti189LongestPath.CycleInsert
variable {V : Type*} {G : SimpleGraph V}

/-- An outside vertex adjacent to the endpoints of a cycle edge can be
inserted in that edge. We rotate before using this first-edge variant. -/
theorem insert_after_start {a w : V} (c : G.Walk a a) (hc : c.IsCycle)
    (wo : w∉c.support) (adj : ∀ z∈c.support,G.Adj w z) :
    ∃ q : G.Walk a a,q.IsCycle ∧ q.length=c.length+1 ∧
      (∀ z∈q.support,z=w ∨ z∈c.support) := by
  cases c with
  | nil => exact (hc.ne_nil rfl).elim
  | @cons a b a' e p =>
    have pPath := ((cons_isCycle_iff p e).mp hc).1
    have wa := adj a (Walk.cons e p).start_mem_support
    have wb := adj b (List.mem_cons_of_mem _ p.start_mem_support)
    let R := Walk.cons wb p
    have rp : R.IsPath := (cons_isPath_iff _ _).mpr ⟨pPath,fun h => wo (List.mem_cons_of_mem _ h)⟩
    have ne : s(a,w)∉R.edges := by
      intro hz
      rcases List.mem_cons.mp hz with h|h
      · rcases Sym2.eq_iff.mp h with h|h
        · exact wa.ne h.1.symm
        · exact e.ne h.1
      · exact wo (List.mem_cons_of_mem _ (p.snd_mem_support_of_mem_edges h))
    refine ⟨Walk.cons wa.symm R,(cons_isCycle_iff _ _).mpr ⟨rp,ne⟩,?_,?_⟩
    · rfl
    · intro z h
      rcases List.mem_cons.mp h with eq|h
      · exact Or.inr (eq.symm ▸ (Walk.cons e p).start_mem_support)
      rcases List.mem_cons.mp h with e|h
      · exact Or.inl e
      · exact Or.inr (List.mem_cons_of_mem _ h)

#print axioms insert_after_start
end Graffiti189LongestPath.CycleInsert
