import Mathlib.Data.Finset.Card
import Mathlib.Data.Fintype.Card
import Mathlib.Logic.Function.Iterate
open Finset Function
set_option warningAsError true
namespace Graffiti189LongestPath.CyclicSparse

/-- On an even cycle of length 2p≥8, p−1 nonconsecutive positions
leave at most one position which is not within distance two of a
*different* chosen position. The cycle is represented by its successor. -/
theorem sparse_cross_card_le_one {V : Type*} [Fintype V] [DecidableEq V]
    (s : V ≃ V) (p : ℕ) (hp : 4≤p) (ord : Fintype.card V=2*p)
    (aper : ∀ v : V,∀ i : ℕ,0<i → i≤6 → (s^[i]) v≠v)
    (X Y : Finset V) (xc : X.card=p-1) (xd : Disjoint X (X.image s))
    (far : ∀ x∈X,∀ y∈Y,x≠y → s x≠y ∧ s (s x)≠y ∧ s y≠x ∧ s (s y)≠x) :
    Y.card≤1 := by
  classical
  let M := (univ : Finset V)\(X∪X.image s)
  have md : M.card=2 := by
    have sz := card_sdiff_add_card_eq_card (subset_univ (X∪X.image s))
    change M.card+(X∪X.image s).card=(univ : Finset V).card at sz
    rw [card_univ,ord,card_union_of_disjoint xd,card_image_of_injective _ s.injective,xc] at sz
    omega
  have mi (y : V) (hy : y∉X) (ps : s.symm y∉X) : y∈M := by
    refine mem_sdiff.mpr ⟨mem_univ _,?_⟩
    intro ym
    rcases mem_union.mp ym with ym|ym
    · exact hy ym
    · obtain ⟨x,hx,e⟩ := mem_image.mp ym
      exact ps (((s.apply_eq_iff_eq_symm_apply).mp e) ▸ hx)
  have per1 (y : V) : s y≠y := by simpa only [Function.iterate_one] using aper y 1 (by decide) (by decide)
  have per2 (y : V) : s (s y)≠y := by
    simpa only [Function.iterate_succ_apply',Function.iterate_one] using aper y 2 (by decide) (by decide)
  have per3 (y : V) : s (s (s y))≠y := by
    simpa only [Function.iterate_succ_apply',Function.iterate_one] using aper y 3 (by decide) (by decide)
  have per6 (y : V) : s (s (s (s (s (s y)))))≠y := by
    simpa only [Function.iterate_succ_apply',Function.iterate_one] using aper y 6 (by decide) (by decide)
  have yt (y : V) (hy : y∈Y) : y∈X := by
    apply Classical.byContradiction
    intro no
    have n1 : s.symm y∉X := by
      intro hx
      have ne : s.symm y≠y := fun e => per1 y (by simpa [e] using s.apply_symm_apply y)
      exact (far _ hx _ hy ne).1 (s.apply_symm_apply y)
    have n2 : s.symm (s.symm y)∉X := by
      intro hx
      have same : s (s (s.symm (s.symm y)))=y := by simp
      have ne : s.symm (s.symm y)≠y := fun e => per2 y ((congrArg (fun t => s (s t)) e).symm.trans same)
      exact (far _ hx _ hy ne).2.1 same
    have np : s y∉X := by
      intro hx
      exact (far _ hx _ hy (per1 y)).2.2.1 rfl
    have m1 := mi y no n1
    have m2 := mi (s.symm y) n1 n2
    have m3 := mi (s y) np (by simpa using no)
    have en1 : s.symm y≠y := fun e => per1 y (by simpa [e] using s.apply_symm_apply y)
    have en2 : s.symm y≠s y := fun e => per2 y (by simpa [e] using s.apply_symm_apply y)
    have en3 := (per1 y).symm
    have hh : ({s.symm y,y,s y}:Finset V)⊆M := by
      intro x hx
      rcases mem_insert.mp hx with rfl|hx
      · exact m2
      rcases mem_insert.mp hx with rfl|hx
      · exact m1
      exact (mem_singleton.mp hx).symm ▸ m3
    have bound := card_le_card hh
    have c : ({s.symm y,y,s y}:Finset V).card=3 := by
      simp [en1,en2,en3]
    omega
  have eligibility (y : V) (hy : y∈Y) :
      s.symm y∈M ∧ s (s y)∈M := by
    have yx : y∈X := yt y hy
    have no1 : s.symm y∉X := by
      intro hx
      have ne : s.symm y≠y := fun e => per1 y (by simpa [e] using s.apply_symm_apply y)
      exact (far _ hx _ hy ne).1 (s.apply_symm_apply y)
    have no2 : s.symm (s.symm y)∉X := by
      intro hx
      have same : s (s (s.symm (s.symm y)))=y := by simp
      have ne : s.symm (s.symm y)≠y := fun e => per2 y ((congrArg (fun t => s (s t)) e).symm.trans same)
      exact (far _ hx _ hy ne).2.1 same
    have np1 : s y∉X := by
      intro hx
      exact (far _ hx _ hy (per1 y)).2.2.1 rfl
    have np2 : s (s y)∉X := by
      intro hx
      exact (far _ hx _ hy (per2 y)).2.2.2 rfl
    exact ⟨mi _ no1 no2, mi _ np2 (by simpa using np1)⟩
  have hh (y : V) (hy : y∈Y) : ({s.symm y,s (s y)}:Finset V)=M := by
    have hs := eligibility y hy
    have no : s.symm y≠s (s y) := fun e => per3 y (by simpa [e] using s.apply_symm_apply y)
    apply eq_of_subset_of_card_le
    · intro w hw
      rcases mem_insert.mp hw with rfl|hw
      · exact hs.1
      exact (mem_singleton.mp hw).symm ▸ hs.2
    · simp [md,no]
  apply Nat.le_of_not_gt
  intro hy
  obtain ⟨x,hx,y,hy,hne⟩ := one_lt_card.mp hy
  have h := (hh x hx).trans (hh y hy).symm
  have u : s.symm x∈({s.symm y,s (s y)}:Finset V) := h ▸ mem_insert_self _ _
  have v : s (s x)∈({s.symm y,s (s y)}:Finset V) := h ▸ mem_insert.mpr (Or.inr (mem_singleton_self _))
  rcases mem_insert.mp u with e|e
  · exact hne (s.symm.injective e)
  have e' := mem_singleton.mp e
  rcases mem_insert.mp v with f|f
  · have x3 : s (s (s x))=y := by rw [f]; simp
    have y3 : s (s (s y))=x := by rw [←e']; simp
    exact per6 x (by rw [x3,y3])
  · exact hne (s.injective (s.injective (mem_singleton.mp f)))

#print axioms sparse_cross_card_le_one
end Graffiti189LongestPath.CyclicSparse
