import SplitRoutes189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.SplitRoutes
set_option warningAsError true
set_option maxHeartbeats 3000000
namespace Graffiti189LongestPath.ExceptionalSplit
variable {V : Type*} [DecidableEq V] {G : SimpleGraph V}

theorem prepend_two {u v w t : V} (A : Finset V)
    (uv : G.Adj u v) (vw : G.Adj v w) (q : G.Walk w t) (qp : q.IsPath)
    (qs : ∀ z∈q.support,z∈A) (ua : u∉A) (va : v∉A) :
    (Walk.cons uv (Walk.cons vw q)).IsPath ∧
      (∀ z∈(Walk.cons uv (Walk.cons vw q)).support,z∈insert u (insert v A)) := by
  refine ⟨(cons_isPath_iff _ _).mpr ⟨(cons_isPath_iff _ _).mpr ⟨qp,?_⟩,?_⟩,?_⟩
  · exact fun e => va (qs v e)
  · intro h
    rcases List.mem_cons.mp h with e|e
    · exact uv.ne e
    · exact ua (qs u e)
  · intro z hz
    rcases List.mem_cons.mp hz with h|h
    · exact mem_insert.mpr (Or.inl h)
    · rcases List.mem_cons.mp h with e|e
      · exact mem_insert.mpr (Or.inr (mem_insert.mpr (Or.inl e)))
      · exact mem_insert.mpr (Or.inr (mem_insert.mpr (Or.inr (qs z e))))

variable [DecidableRel G.Adj]

/-- Balanced opposite-terminal routes survive one incomplete large-side row. -/
theorem one_exception_even (S L : Finset V) (z : V) (zl : z∈L)
    (dis : Disjoint S L) (eq : L.card=S.card)
    (cross : ∀ s∈S,∀ l∈L,l≠z → G.Adj s l)
    (nz : 3≤(S.filter (G.Adj z)).card)
    {s t : V} (ss : s∈S) (tl : t∈L) :
    ∃ q : G.Walk s t,q.IsPath ∧ (∀ v∈q.support,v∈S∪L) ∧ q.length+1=S.card+L.card := by
  classical
  let N := S.filter (G.Adj z)
  have nl : N.card≤S.card := card_filter_le _ _
  have nz' : 3≤N.card := nz
  by_cases tz : t=z
  · subst t
    obtain ⟨a,an,aS'⟩ := exists_ne_of_one_lt_card (by omega : 1<N.card) s
    have aS := (mem_filter.mp an).1
    have za := (mem_filter.mp an).2
    let S' := S.erase a
    let L' := L.erase z
    have sd : S'⊆S := erase_subset _ _
    have ld : L'⊆L := erase_subset _ _
    have sd' : Disjoint S' L' := disjoint_left.mpr (fun _ l r => disjoint_left.mp dis (sd l) (ld r))
    have e : L'.card=S'.card := by rw [card_erase_of_mem zl,card_erase_of_mem aS,eq]
    obtain ⟨b,bl,bz⟩ := exists_ne_of_one_lt_card (by omega : 1<L.card) z
    obtain ⟨q,qp,qs,ql⟩ := even_route S' L' sd'
      (fun v hv w hw => cross v (sd hv) w (ld hw) (mem_erase.mp hw).1)
      e (mem_erase.mpr ⟨aS'.symm,ss⟩) (mem_erase.mpr ⟨bz,bl⟩)
    let ab := cross a aS b bl bz
    let W := Walk.cons za (Walk.cons ab q.reverse)
    have prep := prepend_two (S'∪L') za ab q.reverse qp.reverse
      (fun v h => qs v (by simpa only [support_reverse,List.mem_reverse] using h))
      (by
        intro h
        exact (mem_union.mp h).elim (fun h => disjoint_left.mp dis (sd h) zl)
          (fun h => (mem_erase.mp h).1 rfl))
      (by
        intro h
        exact (mem_union.mp h).elim (fun h => (mem_erase.mp h).1 rfl)
          (fun h => disjoint_left.mp dis aS (ld h)))
    refine ⟨W.reverse,prep.1.reverse,?_,?_⟩
    · intro v hv
      rw [support_reverse,List.mem_reverse] at hv
      rcases mem_insert.mp (prep.2 v hv) with h|h
      · exact mem_union.mpr (Or.inr (h.symm ▸ zl))
      rcases mem_insert.mp h with h|h
      · exact mem_union.mpr (Or.inl (h.symm ▸ aS))
      exact union_subset_union sd ld h
    · simp only [W,length_reverse,length_cons]
      have l := card_erase_of_mem zl
      have s := card_erase_of_mem aS
      change L'.card=L.card-1 at l
      change S'.card=S.card-1 at s
      omega
  obtain ⟨a,an,aS'⟩ := exists_ne_of_one_lt_card (by omega : 1<N.card) s
  have aS := (mem_filter.mp an).1
  have za := (mem_filter.mp an).2
  let M := N.erase s
  have mc : 1<M.card := by
    by_cases sn : s∈N
    · rw [card_erase_of_mem sn]; omega
    · simpa [M,erase_eq_of_not_mem sn] using (by omega : 1<N.card)
  obtain ⟨b,bm,ba⟩ := exists_ne_of_one_lt_card mc a
  obtain ⟨bs',bn⟩ := mem_erase.mp bm
  have bs := (mem_filter.mp bn).1
  have zb := (mem_filter.mp bn).2
  let K := L.erase z
  have kc : 1<K.card := by rw [card_erase_of_mem zl,eq]; omega
  obtain ⟨g,gk,gt⟩ := exists_ne_of_one_lt_card kc t
  obtain ⟨gz,gl⟩ := mem_erase.mp gk
  let S' := (S.erase s).erase a
  let L' := K.erase g
  have aa : a∈S.erase s := mem_erase.mpr ⟨aS',aS⟩
  have eS : S'.card=S.card-2 := by rw [card_erase_of_mem aa,card_erase_of_mem ss]; omega
  have eL : L'.card=L.card-2 := by rw [card_erase_of_mem gk,card_erase_of_mem zl]; omega
  have sd : S'⊆S := (erase_subset _ _).trans (erase_subset _ _)
  have ld : L'⊆L := (erase_subset _ _).trans (erase_subset _ _)
  have dj : Disjoint S' L' := disjoint_left.mpr (fun _ l r => disjoint_left.mp dis (sd l) (ld r))
  have zb' : b∈S' := mem_erase.mpr ⟨ba,mem_erase.mpr ⟨bs',bs⟩⟩
  have t' : t∈L' := mem_erase.mpr ⟨gt.symm,mem_erase.mpr ⟨tz,tl⟩⟩
  obtain ⟨q,qp,qs,ql⟩ := even_route S' L' dj
    (fun v hv w hw => cross v (sd hv) w (ld hw) (mem_erase.mp (mem_erase.mp hw).2).1)
    (by omega) zb' t'
  have noS (u : V) (us : u∈S) (un : u∉S') : u∉S'∪L' := by
    intro hu
    exact (mem_union.mp hu).elim un (fun h => disjoint_left.mp dis us (ld h))
  have noL (u : V) (ul : u∈L) (un : u∉L') : u∉S'∪L' := by
    intro hu
    exact (mem_union.mp hu).elim (fun h => disjoint_left.mp dis (sd h) ul) un
  let R := Walk.cons za.symm (Walk.cons zb q)
  have Rg := prepend_two (S'∪L') za.symm zb q qp qs
    (noS a aS (fun h => (mem_erase.mp h).1 rfl))
    (noL z zl (fun h => (mem_erase.mp (mem_erase.mp h).2).1 rfl))
  let sg := cross s ss g gl gz
  let ga := (cross a aS g gl gz).symm
  have total := prepend_two (insert a (insert z (S'∪L'))) sg ga R Rg.1 Rg.2
    (by
      intro h
      rcases mem_insert.mp h with x|h
      · exact aS' x.symm
      rcases mem_insert.mp h with x|h
      · exact disjoint_left.mp dis ss (x.symm ▸ zl)
      exact noS s ss (fun h => (mem_erase.mp (mem_erase.mp h).2).1 rfl) h)
    (by
      intro h
      rcases mem_insert.mp h with x|h
      · exact disjoint_left.mp dis aS (x ▸ gl)
      rcases mem_insert.mp h with x|h
      · exact gz x
      exact noL g gl (fun h => (mem_erase.mp h).1 rfl) h)
  refine ⟨Walk.cons sg (Walk.cons ga R),total.1,?_,?_⟩
  · intro v hv
    have hv := total.2 v hv
    rcases mem_insert.mp hv with h|hv
    · exact mem_union.mpr (Or.inl (h.symm ▸ ss))
    rcases mem_insert.mp hv with h|hv
    · exact mem_union.mpr (Or.inr (h.symm ▸ gl))
    rcases mem_insert.mp hv with h|hv
    · exact mem_union.mpr (Or.inl (h.symm ▸ aS))
    rcases mem_insert.mp hv with h|hv
    · exact mem_union.mpr (Or.inr (h.symm ▸ zl))
    exact union_subset_union sd ld hv
  · simp only [R,length_cons]
    omega

/-- Odd alternation keeps both large-side terminals and the one
incomplete row, including when that row is one of the terminals. -/
theorem one_exception_odd (S L : Finset V) (z : V) (zl : z∈L)
    (dis : Disjoint S L) (eq : L.card=S.card+1)
    (cross : ∀ s∈S,∀ l∈L,l≠z → G.Adj s l) (nz : 3≤(S.filter (G.Adj z)).card)
    {u v : V} (ul : u∈L) (vl : v∈L) (ne : u≠v) :
    ∃ q : G.Walk u v,q.IsPath ∧ (∀ a∈q.support,a∈S∪L) ∧ q.length+1=S.card+L.card := by
  classical
  obtain ⟨a,aa⟩ := card_pos.mp (by omega : 0<(S.filter (G.Adj z)).card)
  obtain ⟨aS,za⟩ := mem_filter.mp aa
  have start_bad {w : V} (wl : w∈L) (wz : w≠z) :
      ∃ q : G.Walk z w,q.IsPath ∧ (∀ a∈q.support,a∈S∪L) ∧ q.length+1=S.card+L.card := by
    let T := L.erase z
    have sub : T⊆L := erase_subset _ _
    have ca : T.card=S.card := by rw [card_erase_of_mem zl,eq,Nat.add_sub_cancel]
    obtain ⟨q,qp,qs,ql⟩ := even_route S T (disjoint_of_subset_right sub dis)
      (fun a a' b b' => cross a a' b (sub b') (mem_erase.mp b').1) ca aS (mem_erase.mpr ⟨wz,wl⟩)
    refine ⟨Walk.cons za q,(cons_isPath_iff _ _).mpr ⟨qp,?_⟩,?_,?_⟩
    · intro h
      exact (mem_union.mp (qs _ h)).elim (fun h => disjoint_left.mp dis h zl)
        (fun h => (mem_erase.mp h).1 rfl)
    · intro y h
      rcases List.mem_cons.mp h with h|h
      · exact mem_union.mpr (Or.inr (h.symm ▸ zl))
      · exact union_subset_union subset_rfl sub (qs y h)
    · simp only [length_cons]; omega
  by_cases uz : u=z
  · subst u
    exact start_bad vl ne.symm
  by_cases vz : v=z
  · subst v
    obtain ⟨q,qp,qs,ql⟩ := start_bad ul uz
    exact ⟨q.reverse,qp.reverse,fun a h => qs a (by simpa only [support_reverse,List.mem_reverse] using h),
      by simpa only [length_reverse] using ql⟩
  let L' := L.erase u
  have sub : L'⊆L := erase_subset _ _
  have ca : L'.card=S.card := by rw [card_erase_of_mem ul,eq,Nat.add_sub_cancel]
  obtain ⟨q,qp,qs,ql⟩ := one_exception_even S L' z (mem_erase.mpr ⟨(fun h => uz h.symm),zl⟩)
    (disjoint_of_subset_right sub dis) ca (fun a ha b hb => cross a ha b (sub hb))
    nz aS (mem_erase.mpr ⟨ne.symm,vl⟩)
  let e := (cross a aS u ul uz).symm
  refine ⟨Walk.cons e q,(cons_isPath_iff _ _).mpr ⟨qp,?_⟩,?_,?_⟩
  · intro h
    exact (mem_union.mp (qs _ h)).elim (fun h => disjoint_left.mp dis h ul)
      (fun h => (mem_erase.mp h).1 rfl)
  · intro y h
    rcases List.mem_cons.mp h with h|h
    · exact mem_union.mpr (Or.inr (h.symm ▸ ul))
    · exact union_subset_union subset_rfl sub (qs y h)
  · simp only [length_cons]; omega

theorem one_exception_routes (S L : Finset V) (z : V) (zl : z∈L)
    (dj : Disjoint S L) (eq : L.card=S.card+1)
    (cross : ∀ s∈S,∀ l∈L,l≠z → G.Adj s l) (nz : 3≤(S.filter (G.Adj z)).card)
    {u v : V} (uu : u∈S∪L) (vv : v∈S∪L) (ne : u≠v) :
    ∃ q : G.Walk u v,q.IsPath ∧ (∀ a∈q.support,a∈S∪L) ∧
      (S∪L).card≤q.length+1+(if u∈S then 1 else 0)+(if v∈S then 1 else 0) := by
  classical
  have card := card_union_of_disjoint dj
  have ns : 3≤S.card := nz.trans (card_filter_le _ _)
  have mixed {s t : V} (ss : s∈S) (tl : t∈L) :
      ∃ q : G.Walk s t,q.IsPath ∧ (∀ a∈q.support,a∈S∪L) ∧ q.length+2=(S∪L).card := by
    let T := L.erase z
    have cardT : T.card=S.card := by rw [card_erase_of_mem zl,eq,Nat.add_sub_cancel]
    obtain ⟨b,bt,bt'⟩ := exists_ne_of_one_lt_card (by omega : 1<T.card) t
    obtain ⟨bz,bl⟩ := mem_erase.mp bt
    let M := L.erase b
    have ml : M⊆L := erase_subset _ _
    have mc : M.card=S.card := by rw [card_erase_of_mem bl,eq,Nat.add_sub_cancel]
    obtain ⟨q,qp,qs,ql⟩ := one_exception_even S M z (mem_erase.mpr ⟨bz.symm,zl⟩)
      (disjoint_of_subset_right ml dj) mc (fun a ha b hb => cross a ha b (ml hb))
      nz ss (mem_erase.mpr ⟨bt'.symm,tl⟩)
    exact ⟨q,qp,fun a ha => union_subset_union subset_rfl ml (qs a ha),by omega⟩
  rcases mem_union.mp uu with us|ul <;> rcases mem_union.mp vv with vs|vl
  · let T := L.erase z
    have cardT : T.card=S.card := by rw [card_erase_of_mem zl,eq,Nat.add_sub_cancel]
    obtain ⟨M,MT,mc⟩ := exists_subset_card_eq (by omega : S.card-1≤T.card)
    have ML : M⊆L := MT.trans (erase_subset _ _)
    have ss : S.card=M.card+1 := by omega
    obtain ⟨q,qp,qs,ql⟩ := odd_route M S (disjoint_of_subset_left ML dj.symm)
      (fun m hm s hs => (cross s hs m (ML hm) (mem_erase.mp (MT hm)).1).symm)
      ss us vs ne
    refine ⟨q,qp,?_,?_⟩
    · intro a ha
      exact (mem_union.mp (qs a ha)).elim (fun m => mem_union.mpr (Or.inr (ML m)))
        (fun s => mem_union.mpr (Or.inl s))
    · simp only [if_pos us,if_pos vs]
      omega
  · obtain ⟨q,qp,qs,ql⟩ := mixed us vl
    have vn := fun h => disjoint_left.mp dj h vl
    exact ⟨q,qp,qs,by simp only [if_pos us,if_neg vn,Nat.add_zero]; omega⟩
  · obtain ⟨q,qp,qs,ql⟩ := mixed vs ul
    have un := fun h => disjoint_left.mp dj h ul
    refine ⟨q.reverse,qp.reverse,?_,?_⟩
    · intro a ha
      rw [support_reverse,List.mem_reverse] at ha
      exact qs a ha
    · simp only [if_pos vs,if_neg un,Nat.add_zero,length_reverse]
      omega
  · obtain ⟨q,qp,qs,ql⟩ := one_exception_odd S L z zl dj eq cross nz ul vl ne
    have un := fun h => disjoint_left.mp dj h ul
    have vn := fun h => disjoint_left.mp dj h vl
    exact ⟨q,qp,qs,by simp only [if_neg un,if_neg vn,Nat.add_zero]; omega⟩

theorem one_exception_outer (S L : Finset V) (z : V) (zl : z∈L)
    (dj : Disjoint S L) (eq : L.card=S.card+1)
    (cross : ∀ s∈S,∀ l∈L,l≠z → G.Adj s l) (nz : 3≤(S.filter (G.Adj z)).card)
    {u : V} (uu : u∈S∪L) :
    ∃ v, ∃ q : G.Walk u v,q.IsPath ∧ (∀ a∈q.support,a∈S∪L) ∧
      (S∪L).card≤q.length+1+(if u∈S then 1 else 0) := by
  classical
  have ns : 3≤S.card := nz.trans (card_filter_le _ _)
  obtain ⟨v,vl,vu⟩ := exists_ne_of_one_lt_card (by omega : 1<L.card) u
  obtain ⟨q,qp,qs,ql⟩ := one_exception_routes S L z zl dj eq cross nz uu
    (mem_union.mpr (Or.inr vl)) vu.symm
  have vn := fun h => disjoint_left.mp dj h vl
  exact ⟨v,q,qp,qs,by simpa only [if_neg vn,Nat.add_zero] using ql⟩

#print axioms one_exception_even
#print axioms one_exception_odd
#print axioms one_exception_routes
#print axioms one_exception_outer
end Graffiti189LongestPath.ExceptionalSplit
