import MultiPinRotation189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.OneSlack.MultiRotation Graffiti189LongestPath.Rigidity
open private Graffiti189LongestPath.OneSlack.MultiRotation.card_leftMarks
  Graffiti189LongestPath.OneSlack.MultiRotation.LeftMarks
  Graffiti189LongestPath.OneSlack.MultiRotation.reverse_longest
  from MultiPinRotation189
set_option warningAsError true
set_option maxHeartbeats 2000000
namespace Graffiti189LongestPath.HighEndpoint189
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]
theorem rotate_to_two_high_endpoints_of_min_two (d : ℕ)
    (ming : ∀ v : V,2≤G.degree v)
    (degree : ∀ u v : V, u ≠ v → d ≤ G.degree u ∨ d ≤ G.degree v)
    {a b : V} {p : G.Walk a b} (hp : IsLongest p) :
    ∃ (u v : V) (q : G.Walk u v), IsLongest q ∧
      (∀ z : V, z ∈ p.support ↔ z ∈ q.support) ∧
      d ≤ G.degree u ∧ d ≤ G.degree v := by
  classical
  have step {a b : V} {p : G.Walk a b} (hp : IsLongest p)
      (alo : ¬d ≤ G.degree a) (bhi : d ≤ G.degree b) :
      ∃ (u v : V) (q : G.Walk u v), IsLongest q ∧
        (∀ z : V, z ∈ p.support ↔ z ∈ q.support) ∧
        d ≤ G.degree u ∧ d ≤ G.degree v := by
    have lower := ming a
    have mcard := Graffiti189LongestPath.OneSlack.MultiRotation.card_leftMarks hp
    obtain ⟨j,hj,hne⟩ : ∃ j ∈ Graffiti189LongestPath.OneSlack.MultiRotation.LeftMarks p, j ≠ 0 := by
      by_contra h
      have sub : Graffiti189LongestPath.OneSlack.MultiRotation.LeftMarks p ⊆ {0} := by
        intro j hj
        apply mem_singleton.mpr
        by_contra hn
        exact h ⟨j,hj,hn⟩
      have cnt := card_le_card sub
      simp only [card_singleton] at cnt
      omega
    have data := mem_filter.mp hj
    have jlt := mem_range.mp data.1
    obtain ⟨q,hq,hs,_,_,_⟩ := rotate_start hp j jlt data.2
    have nej : a ≠ p.getVert j := by
      intro eq
      have e := p.getVert_zero.trans eq
      have bad := hp.1.getVert_injOn (show 0 ≤ p.length by omega) jlt.le e
      omega
    exact ⟨_,_,q,hq,hs,(degree a _ nej).resolve_left alo,bhi⟩
  have ab : a ≠ b := by
    intro he
    subst b
    have eq := (isPath_iff_eq_nil p).mp hp.1
    have h := ming a
    have ne : 0<(G.neighborFinset a).card := by rw [G.card_neighborFinset_eq_degree]; omega
    obtain ⟨u,ha⟩ := card_pos.mp ne
    have ed := (G.mem_neighborFinset a u).mp ha
    have pos := hp.2 a u ed.toWalk (IsPath.of_adj ed)
    simp [eq] at pos
  by_cases al : d ≤ G.degree a
  · by_cases bl : d ≤ G.degree b
    · exact ⟨a,b,p,hp,fun _ => Iff.rfl,al,bl⟩
    · obtain ⟨u,v,q,hq,hs,uh,vh⟩ := step (Graffiti189LongestPath.OneSlack.MultiRotation.reverse_longest hp) bl al
      exact ⟨u,v,q,hq,fun z => by simpa only [support_reverse,List.mem_reverse] using hs z,uh,vh⟩
  · exact step hp al ((degree a b ab).resolve_left al)


#print axioms rotate_to_two_high_endpoints_of_min_two
end Graffiti189LongestPath.HighEndpoint189
