import StarCycleClosure189
import MarkedRoutable189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack
open Graffiti189LongestPath.CycleHallSplice Graffiti189LongestPath.StarConnectivity
open Graffiti189LongestPath.StarCycleClosure Graffiti189LongestPath.MarkedRoutable
open private Graffiti189LongestPath.Rigidity.mem_omittedStar from Rigidity189
set_option warningAsError true
set_option maxHeartbeats 4000000
namespace Graffiti189LongestPath.MarkedShoreCycle
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- A long cycle missed a marked cut-neighbor vertex. Its endpoint gain
breaks the equality case of the weighted spacing bound. -/
theorem separated_double_no_marked_shore_cycle (hc : G.Connected) (k : Nat) (hk : 6≤k)
    (cap : ∀ v,(EvenFrom G v).card≤k+3)
    (conn : ∀ D : Finset V,D.card<k → (G.induce ((↑D : Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → k+2≤G.degree u ∨ k+2≤G.degree v)
    (fail : ¬∃ (u v : V) (q : G.Walk u v),q.IsPath ∧ ∀ w,w∈q.support)
    {a b x y : V} {p : G.Walk a b} (hp : IsLongest p)
    (hx : x∉p.support) (hy : y∉p.support) (xy : G.Adj x y)
    (high : k+2≤G.degree x)
    (double : (Pins p x).card=2) (sep : PairedPins p x=∅)
    (large : 10<(OmittedStar p x).card)
    (m : ↥(((OmittedStar p x).erase x : Finset V) : Set V))
    (pay : k≤2*(External G (OmittedStar p x)\p.support.toFinset).card+1)
    {z : V} (zb : z∈External G (OmittedStar p x)) (mz : G.Adj m.val z)
    (cyc : ∃ a, ∃ c : (G.induce (((OmittedStar p x).erase x : Finset V) : Set V)).Walk a a,
      c.IsCycle ∧ max 2 (k-1)≤c.length ∧ m∉c.support) : False := by
  classical
  let A := OmittedStar p x
  have A_large : 10<A.card := large
  let Z : Set V := ((A.erase x : Finset V) : Set V)
  let J := G.induce Z
  have sepConn (S : Finset Z) (sc : S.card<2) :
      (J.induce ((↑S : Set Z)ᶜ)).Connected := by
    let e : Z ↪ V := ⟨Subtype.val,Subtype.val_injective⟩
    let X := insert x (S.map e)
    have xs : X⊆A := by
      intro v vx
      rcases mem_insert.mp vx with rfl|h
      · exact Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
      · obtain ⟨w,_,rfl⟩ := mem_map.mp h
        exact (mem_erase.mp w.property).2
    have xl := (card_insert_le x (S.map e)).trans (by rw [card_map])
    change X.card≤S.card+1 at xl
    have con := separated_double_star_stays_connected hc k hk cap conn deg fail hp
      hx hy xy double sep X xs (by omega)
    exact (erase_root_and_set_iso (G:=G) A x S).connected_iff.mp con
  let f : J →g G := ⟨Subtype.val, fun e => e⟩
  have fi : Function.Injective f := Subtype.val_injective
  have off (z : Z) : x≠f z := fun e => (mem_erase.mp z.property).1 e.symm
  have adj (z : Z) : G.Adj x (f z) := by
    have zz := (mem_erase.mp z.property).2
    exact (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp zz).2.resolve_left (fun ne => off z ne.symm)
  obtain ⟨a,c,hc',cl,miss⟩ := cyc
  have big : 2≤c.support.toFinset.card := by
    rw [cycle_card_support c hc']
    exact (le_max_left _ _).trans cl
  have L : k-1≤c.length := (le_max_right _ _).trans cl
  have mA : m.val∈A := (mem_erase.mp m.property).2
  have mx : m.val≠x := (mem_erase.mp m.property).1
  let e (v : V) := if v=m.val then (1:Nat) else 0
  have e0 : e x=0 := by simp [e,mx.symm]
  have gain (v : Z) : e (f v)≤(if v∈c.support then 0 else 1) := by
    by_cases eq : f v=m.val
    · have vm : v=m := Subtype.ext eq
      have no : v∉c.support := vm ▸ miss
      simp [e,eq,no]
    · simp [e,eq]
  have route : ∀ u∈A,∀ v∈A,u≠v →
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈A) ∧ k+e u+e v≤q.length+1 := by
    intro u ua v va uv
    have rA {z : V} (e : z=x ∨ ∃ w : Z,f w=z) : z∈A := by
      rcases e with rfl|⟨w,rfl⟩
      · exact Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
      · exact (mem_erase.mp w.property).2
    by_cases hu : u=x
    · subst u
      let t : Z := ⟨v,mem_erase.mpr ⟨uv.symm,va⟩⟩
      obtain ⟨q,qp,ql,qs⟩ := cycle_to_prescribed_root_route_bonus f fi off adj c hc'
        (t:=t) (fun s h => sepConn s (by omega))
      have tv := gain t
      change e v≤_ at tv
      exact ⟨q,qp,fun z hz => rA (qs z hz),by rw [e0]; omega⟩
    by_cases hv : v=x
    · subst v
      let t : Z := ⟨u,mem_erase.mpr ⟨hu,ua⟩⟩
      obtain ⟨q,qp,ql,qs⟩ := cycle_to_prescribed_root_route_bonus f fi off adj c hc'
        (t:=t) (fun s h => sepConn s (by omega))
      have tu := gain t
      change e u≤_ at tu
      exact ⟨q.reverse,qp.reverse,fun z hz => rA (qs z (by
        simpa only [support_reverse,List.mem_reverse] using hz)),by rw [length_reverse,e0]; omega⟩
    let s : Z := ⟨u,mem_erase.mpr ⟨hu,ua⟩⟩
    let t : Z := ⟨v,mem_erase.mpr ⟨hv,va⟩⟩
    have ne : s≠t := fun e => uv (congrArg Subtype.val e)
    obtain ⟨q,qp,ql,qs⟩ := cycle_to_prescribed_route_bonus f fi ne off adj c hc' big sepConn
    have su := gain s
    have tv := gain t
    change e u≤_ at su
    change e v≤_ at tv
    exact ⟨q,qp,fun z hz => rA (qs z hz),by omega⟩
  apply marked_route_branch_impossible hc k hk cap conn hp hx hy xy high double sep mA zb mz pay
  · intro u ua
    obtain ⟨v,va,ne⟩ := exists_ne_of_one_lt_card (by omega : 1<A.card) u
    obtain ⟨q,qp,qs,ql⟩ := route u ua v va ne.symm
    exact ⟨v,q,qp,qs,by change k+e u≤q.length+1; omega⟩
  · exact route

#print axioms separated_double_no_marked_shore_cycle
end Graffiti189LongestPath.MarkedShoreCycle
