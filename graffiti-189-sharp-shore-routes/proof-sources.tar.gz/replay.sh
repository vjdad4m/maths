#!/usr/bin/env bash
set -euo pipefail
# Requires Lean/Mathlib 4.19 and the preceding two proof deltas.
root=$(cd "$(dirname "$0")" && pwd)
obj=$(mktemp -d)
trap 'rm -rf "$obj"' EXIT
export LEAN_PATH="$obj:${LEAN_PATH:-}"
for m in MarkedRoutable189 MarkedShoreCycle189 CycleInsert189 NearFullCycle189 \
  CriticalOffPath189 DiracThreshold189 HighEndpoint189 MinimalCycleBound189 CyclicSparse189 \
  ExceptionalSplit189 StarExceptionalSplit189; do
  lean -DwarningAsError=true --root="$root" -o "$obj/$m.olean" "$root/$m.lean"
done
