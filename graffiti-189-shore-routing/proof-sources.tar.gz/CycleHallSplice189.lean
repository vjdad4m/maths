import CycleRootBridge189
import HallLinkage189
import Lax17Proofs.Source.HallOrbit189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.CycleRootBridge
open private Graffiti189LongestPath.FanRoutable.path_append_separated from FanLower189
set_option warningAsError true
set_option maxHeartbeats 3000000
namespace Graffiti189LongestPath.CycleHallSplice

variable {U V : Type*} [Fintype U] [DecidableEq U] [DecidableEq V]
    {H : SimpleGraph U} [DecidableRel H.Adj] {G : SimpleGraph V}

omit [Fintype U] [DecidableRel H.Adj] [DecidableEq U] in
/-- Splice two disjoint, cycle-clean arms through a universal root and a
long cycle, retaining every cycle vertex. -/
theorem splice_arms (f : H →g G) (inj : Function.Injective f)
    {a s t u v : U} {r : V} (off : ∀ z,r≠f z) (all : ∀ z,G.Adj r (f z))
    (c : H.Walk a a) (hc : c.IsCycle)
    (p : H.Walk s u) (q : H.Walk t v) (pp : p.IsPath) (qp : q.IsPath)
    (uc : u∈c.support) (vc : v∈c.support)
    (pc : ∀ z∈p.support,z∈c.support → z=u)
    (qc : ∀ z∈q.support,z∈c.support → z=v)
    (dis : List.Disjoint p.support q.support) :
    ∃ w : G.Walk (f s) (f t), w.IsPath ∧ c.length+p.length+q.length≤w.length ∧
      (∀ z∈w.support,z=r ∨ ∃ w : U,f w=z) := by
  have uv : u≠v := fun e => dis p.end_mem_support (e.symm ▸ q.end_mem_support)
  let C := c.map f
  have cp : C.IsCycle := (map_isCycle_iff_of_injective inj).mpr hc
  let P := p.map f
  let Q := q.map f
  have Pp : P.IsPath := map_isPath_of_injective inj pp
  have Qp : Q.IsPath := map_isPath_of_injective inj qp
  have pre {x y : U} (w : H.Walk x y) (z : V) (hz : z∈(w.map f).support) :
      ∃ w'∈w.support,f w'=z := by simpa only [support_map,List.mem_map] using hz
  have inc {x y : U} (w : H.Walk x y) (z : U) (hz : z∈w.support) :
      f z∈(w.map f).support := by
    rw [support_map]
    exact List.mem_map_of_mem hz
  obtain ⟨R,rp,rl,rs⟩ := route_through_root C cp (inc c u uc) (inc c v vc)
    (fun eq => uv (inj eq))
    (fun z => let ⟨w,_,e⟩ := pre c r z; off w e.symm)
    (fun z hz => let ⟨w,_,e⟩ := pre c z hz; e ▸ all w)
  have pc' : ∀ z∈P.support,z∈R.support → z=f u := by
    intro z pz rz
    obtain ⟨w,hw,rfl⟩ := pre p z pz
    rcases rs _ rz with e|ch
    · exact (off w e.symm).elim
    obtain ⟨b,hb,eq⟩ := pre c _ ch
    exact congrArg f (pc w hw (inj eq ▸ hb))
  have qc' : ∀ z∈Q.support,z∈R.support → z=f v := by
    intro z qz rz
    obtain ⟨w,hw,rfl⟩ := pre q z qz
    rcases rs _ rz with e|ch
    · exact (off w e.symm).elim
    obtain ⟨b,hb,eq⟩ := pre c _ ch
    exact congrArg f (qc w hw (inj eq ▸ hb))
  let M := P.append R
  have mp : M.IsPath := Graffiti189LongestPath.FanRoutable.path_append_separated Pp rp pc'
  have join : ∀ z∈M.support,z∈Q.reverse.support → z=f v := by
    intro z mz qz
    rw [support_reverse,List.mem_reverse] at qz
    rw [show M=P.append R from rfl,support_append,List.mem_append] at mz
    rcases mz with h|h
    · obtain ⟨x,hx,e⟩ := pre p z h
      obtain ⟨y,hy,e'⟩ := pre q z qz
      exact (dis hx (inj (e'.trans e.symm) ▸ hy)).elim
    · exact qc' z qz (List.mem_of_mem_tail h)
  refine ⟨M.append Q.reverse,Graffiti189LongestPath.FanRoutable.path_append_separated
    mp Qp.reverse join,?_,?_⟩
  · simp only [M,length_append,length_reverse,rl,C,P,Q,length_map]
    omega
  · intro z zz
    rw [support_append,List.mem_append] at zz
    rcases zz with mz|qz
    · rw [show M=P.append R from rfl,support_append,List.mem_append] at mz
      rcases mz with pz|rz
      · obtain ⟨w,_,e⟩ := pre p z pz
        exact Or.inr ⟨w,e⟩
      · rcases rs z (List.mem_of_mem_tail rz) with e|cz
        · exact Or.inl e
        · obtain ⟨w,_,e⟩ := pre c z cz
          exact Or.inr ⟨w,e⟩
    · have h := List.mem_of_mem_tail qz
      rw [support_reverse,List.mem_reverse] at h
      obtain ⟨w,_,e⟩ := pre q z h
      exact Or.inr ⟨w,e⟩

/-- Small-deletion connectivity in the root-deleted graph is sufficient to
attach arbitrary distinct terminals to the cycle. The Hall relation admits
overlap with the cycle: such a terminal is simply a zero-edge arm. -/
theorem cycle_to_prescribed_route_bonus (f : H →g G) (inj : Function.Injective f)
    {a s t : U} (ne : s≠t) {r : V} (off : ∀ z,r≠f z) (all : ∀ z,G.Adj r (f z))
    (c : H.Walk a a) (hc : c.IsCycle) (big : 2≤c.support.toFinset.card)
    (conn : ∀ S : Finset U,S.card<2 → (H.induce ((↑S : Set U)ᶜ)).Connected) :
    ∃ w : G.Walk (f s) (f t),w.IsPath ∧
      c.length+(if s∈c.support then 0 else 1)+(if t∈c.support then 0 else 1)≤w.length ∧
      (∀ z∈w.support,z=r ∨ ∃ w : U,f w=z) := by
  classical
  let A : Finset U := {s,t}
  let T := c.support.toFinset
  obtain ⟨b,bi,bs,be,bm⟩ := HallLinkage.exists_linkage_permutation (G:=H)
    A T 2 (by simp [A,ne]) big conn
  obtain ⟨L⟩ := MengerHallOrbit189.linkage_of_matching H A T 2 b bi bs be bm
  have different : L.root 0≠L.root 1 := fun e =>
    L.disjoint (by decide : (0 : Fin 2)≠1) (L.path 0).start_mem_support
      (e.symm ▸ (L.path 1).start_mem_support)
  have split (i : Fin 2) : L.root i=s ∨ L.root i=t := by
    simpa [A] using L.root_mem i
  obtain ⟨w,wp,wl,ws⟩ := splice_arms f inj off all c hc (L.path 0) (L.path 1)
    (L.simple 0) (L.simple 1) (List.mem_toFinset.mp (L.terminal_mem 0))
    (List.mem_toFinset.mp (L.terminal_mem 1))
    (fun z hz cz => L.terminal_only 0 z hz (List.mem_toFinset.mpr cz))
    (fun z hz cz => L.terminal_only 1 z hz (List.mem_toFinset.mpr cz))
    (L.disjoint (by decide : (0 : Fin 2)≠1))
  have gain (i : Fin 2) : (if L.root i∈c.support then 0 else 1)≤(L.path i).length := by
    by_cases occ : L.root i∈c.support
    · simp [occ]
    rw [if_neg occ]
    apply Nat.one_le_iff_ne_zero.mpr
    intro e
    have same : L.root i=L.terminal i := by
      calc
        L.root i = (L.path i).getVert 0 := ((L.path i).getVert_zero).symm
        _ = (L.path i).getVert (L.path i).length := by rw [e]
        _ = L.terminal i := (L.path i).getVert_length
    exact occ (same.symm ▸ List.mem_toFinset.mp (L.terminal_mem i))
  have gains : c.length+(if L.root 0∈c.support then 0 else 1)+
      (if L.root 1∈c.support then 0 else 1)≤w.length := by
    have g0 := gain 0
    have g1 := gain 1
    omega
  rcases split 0 with p|p <;> rcases split 1 with q|q
  · exact (different (p.trans q.symm)).elim
  · refine ⟨w.copy (congrArg f p) (congrArg f q),?_,?_,?_⟩
    · simpa using wp
    · simpa [p,q] using gains
    · simpa using ws
  · refine ⟨w.reverse.copy (congrArg f q) (congrArg f p),?_,?_,?_⟩
    · simpa using wp.reverse
    · simpa [p,q,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using gains
    · intro z hz
      rw [support_copy,support_reverse,List.mem_reverse] at hz
      exact ws z hz
  · exact (different (p.trans q.symm)).elim

/-- Small-deletion connectivity in the root-deleted graph is sufficient to
attach arbitrary distinct terminals to the cycle. The Hall relation admits
overlap with the cycle: such a terminal is simply a zero-edge arm. -/
theorem cycle_to_prescribed_route (f : H →g G) (inj : Function.Injective f)
    {a s t : U} (ne : s≠t) {r : V} (off : ∀ z,r≠f z) (all : ∀ z,G.Adj r (f z))
    (c : H.Walk a a) (hc : c.IsCycle) (big : 2≤c.support.toFinset.card)
    (conn : ∀ S : Finset U,S.card<2 → (H.induce ((↑S : Set U)ᶜ)).Connected) :
    ∃ w : G.Walk (f s) (f t),w.IsPath ∧ c.length≤w.length ∧
      (∀ z∈w.support,z=r ∨ ∃ w : U,f w=z) := by
  obtain ⟨w,wp,wl,ws⟩ := cycle_to_prescribed_route_bonus f inj ne off all c hc big conn
  exact ⟨w,wp,by omega,ws⟩

/-- The same bridge when one endpoint is the universal root. -/
theorem cycle_to_prescribed_root_route_bonus (f : H →g G) (inj : Function.Injective f)
    {a t : U} {r : V} (off : ∀ z,r≠f z) (all : ∀ z,G.Adj r (f z))
    (c : H.Walk a a) (hc : c.IsCycle)
    (conn : ∀ S : Finset U,S.card<1 → (H.induce ((↑S : Set U)ᶜ)).Connected) :
    ∃ w : G.Walk r (f t),w.IsPath ∧ c.length+(if t∈c.support then 0 else 1)≤w.length ∧
      (∀ z∈w.support,z=r ∨ ∃ w : U,f w=z) := by
  classical
  let A : Finset U := {t}
  let T := c.support.toFinset
  have big : 1≤T.card := card_pos.mpr ⟨a,List.mem_toFinset.mpr c.start_mem_support⟩
  obtain ⟨b,bi,bs,be,bm⟩ := HallLinkage.exists_linkage_permutation (G:=H)
    A T 1 (by simp [A]) big conn
  obtain ⟨L⟩ := MengerHallOrbit189.linkage_of_matching H A T 1 b bi bs be bm
  let C := c.map f
  have cp : C.IsCycle := (map_isCycle_iff_of_injective inj).mpr hc
  have pre {x y : U} (w : H.Walk x y) (z : V) (hz : z∈(w.map f).support) :
      ∃ w'∈w.support,f w'=z := by simpa only [support_map,List.mem_map] using hz
  have lt : L.root 0=t := by simpa [A] using L.root_mem 0
  let P := (L.path 0).map f
  have Pp : P.IsPath := map_isPath_of_injective inj (L.simple 0)
  have uc : f (L.terminal 0)∈C.support := by
    rw [show C=c.map f from rfl,support_map]
    exact List.mem_map_of_mem (List.mem_toFinset.mp (L.terminal_mem 0))
  obtain ⟨R,rp,rl,rs⟩ := route_from_root C cp uc
    (fun z => let ⟨w,_,e⟩ := pre c r z; off w e.symm)
    (fun z hz => let ⟨w,_,e⟩ := pre c z hz; e ▸ all w)
  have only : ∀ z∈R.support,z∈P.reverse.support → z=f (L.terminal 0) := by
    intro z rr pp
    rw [support_reverse,List.mem_reverse] at pp
    obtain ⟨q,qp,rfl⟩ := pre (L.path 0) z pp
    rcases rs _ rr with e|cc
    · exact (off q e.symm).elim
    obtain ⟨u,up,eq⟩ := pre c _ cc
    exact congrArg f (L.terminal_only 0 q qp (List.mem_toFinset.mpr (inj eq ▸ up)))
  have gain : (if t∈c.support then 0 else 1)≤(L.path 0).length := by
    by_cases occ : t∈c.support
    · simp [occ]
    rw [if_neg occ]
    apply Nat.one_le_iff_ne_zero.mpr
    intro e
    have same : t=L.terminal 0 := by
      calc
        t = L.root 0 := lt.symm
        _ = (L.path 0).getVert 0 := ((L.path 0).getVert_zero).symm
        _ = (L.path 0).getVert (L.path 0).length := by rw [e]
        _ = L.terminal 0 := (L.path 0).getVert_length
    exact occ (same.symm ▸ List.mem_toFinset.mp (L.terminal_mem 0))
  let W := R.append P.reverse
  have wp : W.IsPath := Graffiti189LongestPath.FanRoutable.path_append_separated rp Pp.reverse only
  refine ⟨W.copy rfl (congrArg f lt),?_,?_,?_⟩
  · simpa using wp
  · simp only [length_copy,W,length_append,length_reverse,rl,C,P,length_map]
    omega
  · intro z hz
    rw [support_copy,show W=R.append P.reverse from rfl,support_append,List.mem_append] at hz
    rcases hz with q|q
    · rcases rs z q with h|h
      · exact Or.inl h
      · obtain ⟨u,_,eq⟩ := pre c z h
        exact Or.inr ⟨u,eq⟩
    · have q' := List.mem_of_mem_tail q
      rw [support_reverse,List.mem_reverse] at q'
      obtain ⟨u,_,eq⟩ := pre (L.path 0) z q'
      exact Or.inr ⟨u,eq⟩

/-- The same bridge when one endpoint is the universal root. -/
theorem cycle_to_prescribed_root_route (f : H →g G) (inj : Function.Injective f)
    {a t : U} {r : V} (off : ∀ z,r≠f z) (all : ∀ z,G.Adj r (f z))
    (c : H.Walk a a) (hc : c.IsCycle)
    (conn : ∀ S : Finset U,S.card<1 → (H.induce ((↑S : Set U)ᶜ)).Connected) :
    ∃ w : G.Walk r (f t),w.IsPath ∧ c.length≤w.length ∧
      (∀ z∈w.support,z=r ∨ ∃ w : U,f w=z) := by
  obtain ⟨w,wp,wl,ws⟩ := cycle_to_prescribed_root_route_bonus f inj off all c hc conn
  exact ⟨w,wp,by omega,ws⟩

#print axioms splice_arms
#print axioms cycle_to_prescribed_route
#print axioms cycle_to_prescribed_route_bonus
#print axioms cycle_to_prescribed_root_route
#print axioms cycle_to_prescribed_root_route_bonus
end Graffiti189LongestPath.CycleHallSplice
