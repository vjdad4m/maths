import FanLower189
open SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open private Graffiti189LongestPath.FanRoutable.path_append_separated from FanLower189
set_option warningAsError true
set_option maxHeartbeats 3000000
namespace Graffiti189LongestPath.CycleRootBridge

variable {V : Type*} {G : SimpleGraph V}

/-- Removing the last edge of a nontrivial path also removes exactly
its final vertex from its support. -/
theorem trim_end {u v : V} (p : G.Walk u v) (hp : p.IsPath) (ne : u≠v) :
    ∃ (a : V) (q : G.Walk u a),q.IsPath ∧ G.Adj a v ∧ q.length+1=p.length ∧
      (∀ z∈q.support,z∈p.support) ∧ v∉q.support := by
  generalize re : p.reverse=k at *
  have kpath : k.IsPath := re ▸ hp.reverse
  have len : k.length=p.length := re ▸ p.length_reverse
  have back : ∀ z∈k.support,z∈p.support := by
    intro z hz
    rw [←re,support_reverse,List.mem_reverse] at hz
    exact hz
  cases k with
  | nil => exact (ne rfl).elim
  | @cons v' a u ed tail =>
    refine ⟨a,tail.reverse,kpath.of_cons.reverse,ed.symm,?_,?_,?_⟩
    · simpa only [length_cons,length_reverse] using len
    · intro z hz
      exact back z (List.mem_cons_of_mem _ (by simpa only [support_reverse,List.mem_reverse] using hz))
    · simpa only [support_reverse,List.mem_reverse] using ((cons_isPath_iff _ _).mp kpath).2

variable [DecidableEq V]

theorem rotated_cycle_support_length {a u : V} (c : G.Walk a a)
    (hc : c.IsCycle) (hu : u∈c.support) :
    (c.rotate hu).length=c.length ∧
      (∀ z,z∈(c.rotate hu).support ↔ z∈c.support) := by
  have hrot := hc.rotate hu
  have pn := support_rotate c hu
  constructor
  · rw [rotate,length_append,add_comm,←length_append,take_spec]
  · intro z
    have h1 : ¬(c.rotate hu).Nil := by simpa only [nil_iff_eq_nil] using hrot.ne_nil
    have h2 : ¬c.Nil := by simpa only [nil_iff_eq_nil] using hc.ne_nil
    have eq1 : z∈(c.rotate hu).support ↔ z∈(c.rotate hu).support.tail := by
      rw [Walk.mem_support_iff]
      exact ⟨(fun v => v.elim (fun e => e.symm ▸ end_mem_tail_support h1) id),Or.inr⟩
    have eq2 : z∈c.support ↔ z∈c.support.tail := by
      rw [Walk.mem_support_iff]
      exact ⟨(fun v => v.elim (fun e => e.symm ▸ end_mem_tail_support h2) id),Or.inr⟩
    rw [eq1,eq2]
    exact pn.perm.mem_iff

/-- A universal external root lets a cycle be opened between any
two prescribed vertices on it without giving up any cycle vertex. -/
theorem route_through_root {a r u v : V} (c : G.Walk a a) (hc : c.IsCycle)
    (hu : u∈c.support) (hv : v∈c.support) (ne : u≠v)
    (off : r∉c.support) (univ : ∀ z∈c.support,G.Adj r z) :
    ∃ q : G.Walk u v,q.IsPath ∧ q.length=c.length ∧
      (∀ z∈q.support,z=r ∨ z∈c.support) := by
  let d := c.rotate hu
  have dp : d.IsCycle := hc.rotate hu
  obtain ⟨de,ds⟩ := rotated_cycle_support_length c hc hu
  change d.length=c.length at de
  have vd : v∈d.support := (ds _).mpr hv
  let P := d.takeUntil v vd
  let Q := d.dropUntil v vd
  have app : P.append Q=d := take_spec d vd
  have pp : P.IsPath := dp.isPath_takeUntil vd
  have qp : Q.IsPath := by
    have e := dp
    rw [←app] at e
    exact e.isPath_of_append_right (not_nil_of_ne ne)
  obtain ⟨i,L,lp,_,ll,ls,lv⟩ := trim_end P pp ne
  obtain ⟨j,R,rp,_,rl,rs,ru⟩ := trim_end Q qp ne.symm
  have Lc : ∀ z∈L.support,z∈c.support := fun z hz =>
    (ds z).mp (support_takeUntil_subset d vd (ls z hz))
  have Rc : ∀ z∈R.support,z∈c.support := fun z hz =>
    (ds z).mp (support_dropUntil_subset d vd (rs z hz))
  have dis : ∀ z∈L.support,z∈R.support → False := by
    intro z l r'
    have nu : z≠u := fun e => ru (e ▸ r')
    have nv : z≠v := fun e => lv (e ▸ l)
    have pt : z∈P.support.tail := ((Walk.mem_support_iff P).mp (ls z l)).resolve_left nu
    have qt : z∈Q.support.tail := ((Walk.mem_support_iff Q).mp (rs z r')).resolve_left nv
    have dn := dp.support_nodup
    rw [←app,tail_support_append] at dn
    exact (List.nodup_append.mp dn).2.2 pt qt
  have ir := (univ i (Lc i L.end_mem_support)).symm
  have rj := univ j (Rc j R.end_mem_support)
  let N := (Walk.cons ir (Walk.cons rj R.reverse))
  have nr : (Walk.cons rj R.reverse).IsPath := by
    apply (cons_isPath_iff _ _).mpr
    refine ⟨rp.reverse,?_⟩
    intro h
    rw [support_reverse,List.mem_reverse] at h
    exact off (Rc r h)
  have np : N.IsPath := by
    apply (cons_isPath_iff _ _).mpr
    refine ⟨nr,?_⟩
    intro h
    rcases List.mem_cons.mp h with he|he
    · exact (G.loopless r) (he ▸ ir)
    · rw [support_reverse,List.mem_reverse] at he
      exact dis i L.end_mem_support he
  have only : ∀ z∈L.support,z∈N.support → z=i := by
    intro z l n
    rcases List.mem_cons.mp n with he|n
    · exact he
    rcases List.mem_cons.mp n with he|n
    · exact (off (he ▸ Lc z l)).elim
    rw [support_reverse,List.mem_reverse] at n
    exact (dis z l n).elim
  refine ⟨L.append N,Graffiti189LongestPath.FanRoutable.path_append_separated lp np only,?_,?_⟩
  · have dl := congrArg Walk.length app
    simp only [length_append] at dl
    change P.length+Q.length=d.length at dl
    simp only [length_append,N,length_cons,length_reverse]
    omega
  · intro z hz
    rw [support_append,List.mem_append] at hz
    rcases hz with h|h
    · exact Or.inr (Lc z h)
    have zn := List.mem_of_mem_tail h
    rcases List.mem_cons.mp zn with he|zn
    · exact Or.inr (he.symm ▸ Lc i L.end_mem_support)
    rcases List.mem_cons.mp zn with he|zn
    · exact Or.inl he
    rw [support_reverse,List.mem_reverse] at zn
    exact Or.inr (Rc z zn)

/-- The root itself may be the first prescribed terminal. -/
theorem route_from_root {a r t : V} (c : G.Walk a a) (hc : c.IsCycle)
    (ht : t∈c.support) (off : r∉c.support)
    (univ : ∀ z∈c.support,G.Adj r z) :
    ∃ q : G.Walk r t,q.IsPath ∧ q.length=c.length ∧
      (∀ z∈q.support,z=r ∨ z∈c.support) := by
  let d := c.rotate ht
  have dp : d.IsCycle := hc.rotate ht
  obtain ⟨de,ds⟩ := rotated_cycle_support_length c hc ht
  change d.length=c.length at de
  have dn : ¬d.Nil := by simpa only [nil_iff_eq_nil] using dp.ne_nil
  have tail : d.tail.IsPath := by
    rw [isPath_def,support_tail d dn]
    exact dp.support_nodup
  have inc : ∀ z∈d.tail.support,z∈c.support := by
    intro z zh
    rw [support_tail d dn] at zh
    exact (ds z).mp (List.mem_of_mem_tail zh)
  have ed := univ _ (inc _ d.tail.start_mem_support)
  refine ⟨Walk.cons ed d.tail,(cons_isPath_iff _ _).mpr ⟨tail,fun h => off (inc r h)⟩,?_,?_⟩
  · rw [length_cons,length_tail_add_one dn]
    exact de
  · intro z hz
    rcases List.mem_cons.mp hz with e|h
    · exact Or.inl e
    · exact Or.inr (inc z h)

#print axioms trim_end
#print axioms route_through_root
#print axioms route_from_root
end Graffiti189LongestPath.CycleRootBridge
