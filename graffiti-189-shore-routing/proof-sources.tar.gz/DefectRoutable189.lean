import FanDefect189
import MengerRoutable189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack Graffiti189LongestPath.ActiveStarHeight
open Graffiti189LongestPath.FanRoutable Graffiti189LongestPath.FanDefect Graffiti189LongestPath.FanPorts
open Graffiti189LongestPath.DoubleThirdBudget Graffiti189LongestPath.MengerRoutable
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
open scoped BigOperators
set_option warningAsError true
set_option maxHeartbeats 2000000
namespace Graffiti189LongestPath.DefectRoutable
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

omit [Fintype V] [DecidableRel G.Adj] in
theorem defects_at_most_card {a b : V} {p : G.Walk a b} (A D : Finset V)
    (k : Nat) (F : HookFamily p A k) :
    (∑ i : Fin k,if F.root i∈D then (1:Nat) else 0)≤D.card := by
  classical
  let T := (univ : Finset (Fin k)).filter (fun i => F.root i∈D)
  have inj : Function.Injective F.root := by
    intro i j e
    apply Classical.byContradiction
    intro ne
    exact F.disj ne (F.path i).start_mem_support (e.symm ▸ (F.path j).start_mem_support)
  have sub : T.image F.root⊆D := by
    intro v hv
    obtain ⟨i,hi,rfl⟩ := mem_image.mp hv
    exact (mem_filter.mp hi).2
  have c := card_le_card sub
  rw [card_image_of_injective _ inj] at c
  calc
    _ = ∑ i∈T,(1:Nat) := by rw [sum_filter]
    _ = T.card := by simp
    _ ≤ D.card := c

/-- A small set D of terminals may lose one vertex per endpoint in a
route. One off-path cut port for each bad terminal absorbs the losses. -/
theorem one_defect_double_branch_impossible (hc : G.Connected) (k : Nat) (hk : 6≤k)
    (cap : ∀ v,(EvenFrom G v).card≤k+3)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    {a b x y : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
    (hy : y∉p.support) (xy : G.Adj x y) (high : k+2≤G.degree x)
    (double : (Pins p x).card=2) (sep : PairedPins p x=∅)
    (D : Finset V)
    (pay : D.card≤(External G (OmittedStar p x)\p.support.toFinset).card)
    (outer : ∀ u∈OmittedStar p x,∃ (v:V) (q:G.Walk u v),q.IsPath ∧
      (∀ z∈q.support,z∈OmittedStar p x) ∧
      (OmittedStar p x).card≤q.length+1+(if u∈D then 1 else 0))
    (between : ∀ u∈OmittedStar p x,∀ v∈OmittedStar p x,u≠v →
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈OmittedStar p x) ∧
      (OmittedStar p x).card≤q.length+1+(if u∈D then 1 else 0)+(if v∈D then 1 else 0)) :
    False := by
  let A := OmittedStar p x
  let B := External G A
  have eq := star_card_degree_and_pins hp hx
  change A.card+(Pins p x).card=G.degree x+1 at eq
  have large : k≤A.card := by omega
  have ao : ∀ z∈A,z∉p.support := fun _ h => (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp h).1
  have sat : B.card=k := by
    obtain ⟨_,_,alt⟩ := double_porter_saturated_one_slack hc k hp hx double (cap x) conn hy xy
    rcases alt with h|h
    · exact h.2
    · simp [sep] at h
  obtain ⟨F⟩ := hooks_of_small_deletion_connectivity A k hp ao large (support_large k conn hp hx) conn
  let e (v : V) := if v∈D then (1:Nat) else 0
  have sm : ∀ v∈A,e v≤1 := by intro v hv; dsimp [e]; split <;> omega
  have low := one_defect_hooked_lower k (by omega) hp A ao (by omega) e sm outer between F
  have up := double_star_order_upper hc k hk cap conn hp hx hy xy high double sep
  change Fintype.card V≤A.card+k+k*(k+2) at up
  have dft := defects_at_most_card A D k F
  change (∑ i : Fin k,e (F.root i))≤D.card at dft
  have ab : Disjoint A B := disjoint_left.mpr fun _ hu hv =>
    (Graffiti189LongestPath.Rigidity.mem_external.mp hv).1 hu
  have cA : ∀ u∈A,∀ v∉A,G.Adj u v → v∈B := fun u hu v hv ed =>
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨hv,u,hu,ed⟩
  have lng := off_path_ports_le_total_hook_length A B k sat ab cA hp F ao
  change D.card≤(B\p.support.toFinset).card at pay
  have hmin : k+1≤A.card := by omega
  have ht := Nat.mul_le_mul_left (k+1) hmin
  have sq : (k+1)*(k+1)=k*(k+2)+1 := by simp [Nat.mul_add,Nat.add_mul,Nat.mul_comm]; omega
  rw [sq] at ht
  have m : (k+2)*A.card=(k+1)*A.card+A.card := by
    rw [show k+2=(k+1)+1 by omega,Nat.add_mul,one_mul]
  rw [m] at low
  omega

#print axioms defects_at_most_card
#print axioms one_defect_double_branch_impossible
end Graffiti189LongestPath.DefectRoutable
