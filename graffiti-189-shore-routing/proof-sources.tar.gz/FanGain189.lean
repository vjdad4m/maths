import FanWeighted189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.FanRoutable
open Graffiti189LongestPath.EndpointSplice Graffiti189LongestPath.WideWing
open private Graffiti189LongestPath.FanRoutable.path_append_separated from FanLower189
open Graffiti189LongestPath.FanWeighted
open scoped BigOperators
set_option warningAsError true
set_option maxHeartbeats 2000000
namespace Graffiti189LongestPath.FanGain

variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- An endpoint-specific path-length gain contributes twice, just like
an extra hook edge, including the two exterior room constraints. -/
theorem endpoint_gain_hooked_lower (k : Nat) (kpos : 0<k)
    {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    (H : Nat) (A : Finset V) (ao : ∀ z∈A,z∉p.support) 
    (e : V → Nat)
    (endRoute : ∀ u∈A,∃ (v : V) (q : G.Walk u v), q.IsPath ∧ (∀ z∈q.support,z∈A)
      ∧ H+e u≤q.length+1)
    (routes : ∀ u∈A,∀ v∈A,u≠v →
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈A) ∧ H+e u+e v≤q.length+1)
    (F : HookFamily p A k) :
    A.card+k+(k+1)*H+2*(∑ i : Fin k, (F.path i).length)+2*(∑ i : Fin k,e (F.root i))≤Fintype.card V := by
  classical
  let W (i : Fin k) := (F.path i).length+e (F.root i)
  let I := (univ : Finset (Fin k)).map F.idx
  have kI : I.card=k := by simp [I]
  have room (i : Fin k) : H+W i≤F.idx i ∧ F.idx i+H+W i≤p.length := by
    obtain ⟨v,q,hq,qs,ql⟩ := endRoute (F.root i) (F.firstIn i)
    let w := (F.path i).reverse.append q
    have wp : w.IsPath := Graffiti189LongestPath.FanRoutable.path_append_separated (F.simple i).reverse hq (by
      intro z hz zq
      exact F.single i z (by simpa only [support_reverse,List.mem_reverse] using hz) (qs z zq))
    have wo : ∀ z∈w.support,z∉p.support := by
      intro z hz
      rw [show w=(F.path i).reverse.append q from rfl,support_append,List.mem_append] at hz
      exact hz.elim (fun l => F.off i z (by simpa only [support_reverse,List.mem_reverse] using l))
        (fun r => ao z (qs z (List.mem_of_mem_tail r)))
    have d := endpoint_room hp w wp wo (Nat.le_of_lt (F.idxLt i)) (F.adjLast i).symm
    simp only [w,length_append,length_reverse] at d
    dsimp only [W]
    omega
  have gap (i j : Fin k) (lt : F.idx i<F.idx j) : F.idx i+H+1+W i+W j≤F.idx j := by
    have ij : i≠j := fun eq => (Nat.lt_irrefl _) (eq ▸ lt)
    have roots : F.root i≠F.root j := by
      intro e
      exact F.disj ij (F.path i).start_mem_support (e.symm ▸ (F.path j).start_mem_support)
    obtain ⟨q,hq,qs,ql⟩ := routes (F.root i) (F.firstIn i) (F.root j) (F.firstIn j) roots
    let l := (F.path i).reverse.append q
    have lp : l.IsPath := Graffiti189LongestPath.FanRoutable.path_append_separated (F.simple i).reverse hq (by
      intro z hz qz
      exact F.single i z (by simpa only [support_reverse,List.mem_reverse] using hz) (qs z qz))
    let w := l.append (F.path j)
    have wp : w.IsPath := Graffiti189LongestPath.FanRoutable.path_append_separated lp (F.simple j) (by
      intro z zl zj
      rw [show l=(F.path i).reverse.append q from rfl,support_append,List.mem_append] at zl
      rcases zl with ll|rr
      · exact (F.disj ij (by simpa only [support_reverse,List.mem_reverse] using ll) zj).elim
      · exact F.single j z zj (qs z (List.mem_of_mem_tail rr)))
    have wo : ∀ z∈w.support,z∉p.support := by
      intro z hz
      rw [show w=l.append (F.path j) from rfl,support_append,List.mem_append] at hz
      rcases hz with hl|hj
      · rw [show l=(F.path i).reverse.append q from rfl,support_append,List.mem_append] at hl
        exact hl.elim (fun l => F.off i z (by simpa only [support_reverse,List.mem_reverse] using l))
          (fun r => ao z (qs z (List.mem_of_mem_tail r)))
      · exact F.off j z (List.mem_of_mem_tail hj)
    have pi : F.idx i∈Pins p (F.last i) := mem_filter.mpr ⟨mem_range.mpr (F.idxLt i),F.adjLast i⟩
    have pj : F.idx j∈Pins p (F.last j) := mem_filter.mpr ⟨mem_range.mpr (F.idxLt j),F.adjLast j⟩
    have r := terminal_length_le_gap hp pi pj lt w wp wo
    simp only [w,l,length_append,length_reverse] at r
    dsimp only [W]
    omega
  let wt (j : Nat) := if hj : ∃ i, F.idx i=j then W (Classical.choose hj) else 0
  have wt_eq (i : Fin k) : wt (F.idx i)=W i := by
    have e : ∃ j, F.idx j=F.idx i := ⟨i,rfl⟩
    dsimp only [wt]
    rw [dif_pos e, F.idx.injective (Classical.choose_spec e)]
  have span := weighted_span H p.length I wt (by omega)
    (by intro i hi; obtain ⟨j,_,rfl⟩ := mem_map.mp hi; rw [wt_eq]; exact room j)
    (by
      intro i hi j hj lt
      obtain ⟨u,_,rfl⟩ := mem_map.mp hi
      obtain ⟨v,_,rfl⟩ := mem_map.mp hj
      rw [wt_eq,wt_eq]
      exact gap u v lt)
  have eqwt : (∑ i ∈ I,wt i) = ∑ i : Fin k,W i := by
    simp [I,sum_map,wt_eq]
  rw [eqwt,kI] at span
  dsimp only [W] at span
  rw [sum_add_distrib] at span
  have ds : Disjoint A p.support.toFinset := disjoint_left.mpr (fun _ h s =>
    ao _ h (List.mem_toFinset.mp s))
  have c := card_le_univ (A∪p.support.toFinset)
  rw [card_union_of_disjoint ds,List.toFinset_card_of_nodup hp.1.support_nodup,length_support] at c
  omega



#print axioms endpoint_gain_hooked_lower
end Graffiti189LongestPath.FanGain
