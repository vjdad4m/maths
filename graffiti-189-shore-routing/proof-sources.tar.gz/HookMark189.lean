import FanPorts189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.FanRoutable
open scoped BigOperators
set_option warningAsError true
namespace Graffiti189LongestPath.HookMark

variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

omit [Fintype V] [DecidableRel G.Adj] in
private theorem walk_hits_boundary (A B : Finset V)
    (closed : ∀ u∈A,∀ v∉A,G.Adj u v → v∈B) {u v : V} (w : G.Walk u v)
    (ua : u∈A) (va : v∉A) : ∃ x∈B,x∈w.support := by
  induction w with
  | nil => exact (va ua).elim
  | @cons a b c e q ih =>
    by_cases hb : b∈A
    · obtain ⟨x,xb,xq⟩ := ih hb va
      exact ⟨x,xb,List.mem_cons_of_mem _ xq⟩
    · exact ⟨b,closed a ua b hb e,List.mem_cons_of_mem _ q.start_mem_support⟩

omit [Fintype V] [DecidableRel G.Adj] in
/-- Every vertex of an exact cut is used by one of the disjoint hooks. -/
theorem boundary_port_used (A B : Finset V) (k : Nat)
    (bc : B.card=k)
    (closed : ∀ u∈A,∀ v∉A,G.Adj u v → v∈B)
    {a b : V} {p : G.Walk a b} (hp : IsLongest p) (F : HookFamily p A k)
    (off : ∀ z∈A,z∉p.support) :
    ∀ z∈B,∃ i : Fin k,z∈(F.path i).support ∨ z=p.getVert (F.idx i) := by
  classical
  let dst (i : Fin k) := p.getVert (F.idx i)
  have dstP (i : Fin k) : dst i∈p.support := p.getVert_mem_support _
  let q (i : Fin k) := (F.path i).append (.cons (F.adjLast i) .nil)
  have term (i : Fin k) :
      ∃ z∈B,z∈(F.path i).support ∨ z=dst i := by
    obtain ⟨z,zb,hz⟩ := walk_hits_boundary A B closed (q i) (F.firstIn i)
      (fun za => off (dst i) za (dstP i))
    refine ⟨z,zb,?_⟩
    have f : z∈(F.path i).support ∨ z=F.last i ∨ z=dst i := by
      simpa [q,dst] using hz
    rcases f with s|eq|eq
    · exact Or.inl s
    · exact Or.inl (eq.symm ▸ (F.path i).end_mem_support)
    · exact Or.inr eq
  choose port pb wherePort using term
  have pinj : Function.Injective port := by
    intro i j e
    apply Classical.byContradiction
    intro ne
    rcases wherePort i with si|hi
    · rcases wherePort j with sj|hj
      · exact F.disj ne si (e.symm ▸ sj)
      · exact F.off i _ si (e.symm ▸ (hj.symm ▸ dstP j))
    · rcases wherePort j with sj|hj
      · exact F.off j _ sj (e ▸ (hi.symm ▸ dstP i))
      · exact ne (F.idx.injective
          (hp.1.getVert_injOn (Nat.le_of_lt (F.idxLt i)) (Nat.le_of_lt (F.idxLt j))
            (hi.symm.trans (e.trans hj))))
  let E : Fin k ↪ V := ⟨port,pinj⟩
  have sur : (univ : Finset (Fin k)).map E=B := by
    apply eq_of_subset_of_card_le
    · intro z hz
      obtain ⟨i,_,rfl⟩ := mem_map.mp hz
      exact pb i
    · simp [bc]
  intro z hz
  rw [←sur] at hz
  obtain ⟨i,_,rfl⟩ := mem_map.mp hz
  exact ⟨i,wherePort i⟩

omit [Fintype V] [DecidableRel G.Adj] [DecidableEq V] in
theorem exchange_hook {a b : V} {p : G.Walk a b} (A : Finset V) (k : Nat)
    (F : HookFamily p A k) (i : Fin k)
    {w l : V} (q : G.Walk w l) (qp : q.IsPath) (wA : w∈A)
    (adj : G.Adj l (p.getVert (F.idx i))) (unused : ∀ j,F.root j≠w)
    (off : ∀ z∈q.support,z∉p.support)
    (only : ∀ z∈q.support,z∈A → z=w)
    (sub : ∀ z∈q.support,z=w ∨ z∈(F.path i).support) :
    ∃ N : HookFamily p A k,N.root i=w := by
  classical
  let root (j : Fin k) := if j=i then w else F.root j
  let last (j : Fin k) := if j=i then l else F.last j
  let path (j : Fin k) : G.Walk (root j) (last j) := by
    by_cases e : j=i
    · exact q.copy (by simp [root,e]) (by simp [last,e])
    · exact (F.path j).copy (by simp [root,e]) (by simp [last,e])
  have supp (j : Fin k) : (path j).support=if j=i then q.support else (F.path j).support := by
    by_cases e : j=i <;> simp [path,e]
  have simple (j : Fin k) : (path j).IsPath := by
    by_cases e : j=i <;> simp [path,e,qp,F.simple]
  have qoff (j : Fin k) : ∀ z∈(path j).support,z∉p.support := by
    rw [supp]
    by_cases e : j=i
    · simpa [e] using off
    · simpa [e] using F.off j
  have old : ∀ j,w∉(F.path j).support := fun j q =>
    unused j (F.single j w q wA).symm
  refine ⟨⟨F.idx,root,last,path,simple,F.idxLt,?_,?_,?_,qoff,?_⟩,by simp [root]⟩
  · intro j
    by_cases e : j=i
    · subst j; simpa [last] using adj
    · simpa [last,e] using F.adjLast j
  · intro j
    by_cases e : j=i
    · simpa [root,e] using wA
    · simpa [root,e] using F.firstIn j
  · intro j z hz za
    rw [supp] at hz
    by_cases e : j=i
    · simpa [root,e] using only z (by simpa [e] using hz) za
    · simpa [root,e] using F.single j z (by simpa [e] using hz) za
  · intro j l' ne z hj hl
    rw [supp] at hj hl
    by_cases je : j=i
    · subst j
      have n : l'≠i := ne.symm
      have hs : z∈q.support := by simpa using hj
      have ht : z∈(F.path l').support := by simpa [n] using hl
      exact (sub z hs).elim (fun e => old l' (e ▸ ht)) (fun h => F.disj ne h ht)
    by_cases le : l'=i
    · subst l'
      have hs : z∈(F.path j).support := by simpa [je] using hj
      have ht : z∈q.support := by simpa using hl
      exact (sub z ht).elim (fun e => old j (e ▸ hs)) (fun h => F.disj ne hs h)
    exact F.disj ne (by simpa [je] using hj) (by simpa [le] using hl)

omit [Fintype V] [DecidableRel G.Adj] in
/-- Any marked shore vertex with a cut neighbor can be selected as a
root of a full hook family for an exact cut. This does not assume that
a Hall linkage from a smaller source set avoids the rest of the shore. -/
theorem marked_hook_family (A B : Finset V) (k : Nat) (bc : B.card=k)
    (ab : Disjoint A B) (closed : ∀ u∈A,∀ v∉A,G.Adj u v → v∈B)
    {a b w z : V} {p : G.Walk a b} (hp : IsLongest p)
    (F : HookFamily p A k) (off : ∀ z∈A,z∉p.support)
    (wa : w∈A) (zb : z∈B) (ed : G.Adj w z) :
    ∃ N : HookFamily p A k, ∃ i,N.root i=w := by
  classical
  by_cases had : ∃ i,F.root i=w
  · exact ⟨F,had⟩
  have unused (i : Fin k) : F.root i≠w := fun e => had ⟨i,e⟩
  obtain ⟨i,ii|ii⟩ := boundary_port_used A B k bc closed hp F off z zb
  · let suff := (F.path i).dropUntil z ii
    have ss : ∀ u∈suff.support,u∈(F.path i).support :=
      fun _ h => support_dropUntil_subset _ _ h
    have wp : w∉suff.support := fun h => unused i (F.single i w (ss w h) wa).symm
    have zA : z∉A := fun h => disjoint_left.mp ab h zb
    have rw : ∀ u∈suff.support,u∉A := by
      intro u hu ua
      have e := F.single i u (ss u hu) ua
      have eq : F.root i=z := by
        apply Classical.byContradiction
        intro ne
        let pre := (F.path i).takeUntil z ii
        have cat : pre.append suff=F.path i := take_spec _ ii
        have nd := (F.simple i).support_nodup
        rw [←cat,support_append] at nd
        have tail : F.root i∈suff.support.tail :=
          (Walk.mem_support_iff suff).mp (e ▸ hu) |>.resolve_left ne
        exact (List.nodup_append.mp nd).2.2 pre.start_mem_support tail
      exact zA (eq ▸ (F.firstIn i))
    let q := Walk.cons ed suff
    obtain ⟨N,hit⟩ := exchange_hook A k F i q
      ((cons_isPath_iff _ _).mpr ⟨(F.simple i).dropUntil ii,wp⟩) wa (F.adjLast i) unused
      (by
        intro u hu
        rcases List.mem_cons.mp hu with e|h
        · exact e.symm ▸ off w wa
        · exact F.off i u (ss u h))
      (by
        intro u hu ua
        exact (List.mem_cons.mp hu).elim id (fun h => (rw u h ua).elim))
      (fun u h => (List.mem_cons.mp h).imp id (ss u))
    exact ⟨N,i,hit⟩
  · obtain ⟨N,hit⟩ := exchange_hook A k F i (Walk.nil : G.Walk w w) (by simp) wa
      (ii ▸ ed) unused (by simpa using off w wa) (by simp) (by simp)
    exact ⟨N,i,hit⟩

#print axioms boundary_port_used
#print axioms exchange_hook
#print axioms marked_hook_family
end Graffiti189LongestPath.HookMark
