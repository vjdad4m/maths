import HookMark189
import FanGain189
import MengerRoutable189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack Graffiti189LongestPath.ActiveStarHeight
open Graffiti189LongestPath.FanRoutable Graffiti189LongestPath.FanGain Graffiti189LongestPath.FanPorts
open Graffiti189LongestPath.HookMark Graffiti189LongestPath.DoubleThirdBudget Graffiti189LongestPath.MengerRoutable
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
open scoped BigOperators
set_option warningAsError true
set_option maxHeartbeats 2000000
namespace Graffiti189LongestPath.MarkedRoutable
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- With at least k/2 cut ports outside P, a base terminal order k is
enough if one mark with a cut neighbor always adds one further vertex
to paths ending at it. That mark can be made one of the fan roots. -/
theorem marked_route_branch_impossible (hc : G.Connected) (k : Nat) (hk : 6≤k)
    (cap : ∀ v,(EvenFrom G v).card≤k+3)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    {a b x y w z : V} {p : G.Walk a b} (hp : IsLongest p) (hx : x∉p.support)
    (hy : y∉p.support) (xy : G.Adj x y) (high : k+2≤G.degree x)
    (double : (Pins p x).card=2) (sep : PairedPins p x=∅)
    (wa : w∈OmittedStar p x) (zb : z∈External G (OmittedStar p x)) (wz : G.Adj w z)
    (pay : k≤2*(External G (OmittedStar p x)\p.support.toFinset).card)
    (outer : ∀ u∈OmittedStar p x,∃ (v:V) (q:G.Walk u v),q.IsPath ∧
      (∀ z∈q.support,z∈OmittedStar p x) ∧ k+(if u=w then 1 else 0)≤q.length+1)
    (between : ∀ u∈OmittedStar p x,∀ v∈OmittedStar p x,u≠v →
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈OmittedStar p x) ∧
        k+(if u=w then 1 else 0)+(if v=w then 1 else 0)≤q.length+1) : False := by
  classical
  let A := OmittedStar p x
  let B := External G A
  have eq := star_card_degree_and_pins hp hx
  change A.card+(Pins p x).card=G.degree x+1 at eq
  have large : k≤A.card := by omega
  have ao : ∀ z∈A,z∉p.support := fun _ h => (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp h).1
  have sat : B.card=k := by
    obtain ⟨_,_,alt⟩ := double_porter_saturated_one_slack hc k hp hx double (cap x) conn hy xy
    rcases alt with h|h
    · exact h.2
    · simp [sep] at h
  obtain ⟨F⟩ := hooks_of_small_deletion_connectivity A k hp ao large (support_large k conn hp hx) conn
  have ab : Disjoint A B := disjoint_left.mpr fun _ hu hv =>
    (Graffiti189LongestPath.Rigidity.mem_external.mp hv).1 hu
  have cA : ∀ u∈A,∀ v∉A,G.Adj u v → v∈B := fun u hu v hv ed =>
    Graffiti189LongestPath.Rigidity.mem_external.mpr ⟨hv,u,hu,ed⟩
  obtain ⟨N,i,mark⟩ := marked_hook_family A B k sat ab cA hp F ao wa zb wz
  let e (v : V) := if v=w then (1:Nat) else 0
  have low := endpoint_gain_hooked_lower k (by omega) hp k A ao e outer between N
  have up := double_star_order_upper hc k hk cap conn hp hx hy xy high double sep
  change Fintype.card V≤A.card+k+k*(k+2) at up
  have lng := off_path_ports_le_total_hook_length A B k sat ab cA hp N ao
  change k≤2*(B\p.support.toFinset).card at pay
  have bg : 1≤∑ j : Fin k,e (N.root j) := by
    have n : e (N.root i)=1 := by simp [e,mark]
    rw [←n]
    exact single_le_sum (fun (a : Fin k) _ => Nat.zero_le (e (N.root a))) (mem_univ i)
  have id : k*(k+2)=(k+1)*k+k := by rw [Nat.mul_add,Nat.add_mul,one_mul]; omega
  rw [id] at up
  omega

#print axioms marked_route_branch_impossible
end Graffiti189LongestPath.MarkedRoutable
