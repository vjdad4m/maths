import OneSlack189

open Finset SimpleGraph Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack
open private Graffiti189LongestPath.OneSlack.pin_of_neighbor_mem
  Graffiti189LongestPath.OneSlack.card_pinVertices from OneSlack189

namespace Graffiti189LongestPath.OffPathBoundaryBudget

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V} [DecidableRel G.Adj]

/-- Internal neighbors, path pins and off-path exterior neighbors are
three separate budgets for a vertex of an omitted shore. -/
theorem degree_le_shore_and_ports {a b : V} {p : G.Walk a b}
    (hp : IsLongest p) (A : Finset V) (x : ↥(A : Set V)) (hx : x.val ∉ p.support) :
    G.degree x.val ≤ (G.induce (A : Set V)).degree x +
      (Pins p x.val).card + (External G A \ p.support.toFinset).card := by
  classical
  let N := G.neighborFinset x.val ∩ A
  let J := G.induce (A : Set V)
  let O := External G A \ p.support.toFinset
  have sub : G.neighborFinset x.val ⊆ (N ∪ PinVertices p x.val) ∪ O := by
    intro y hy
    have ed := (G.mem_neighborFinset x.val y).mp hy
    by_cases ya : y ∈ A
    · exact mem_union_left _ (mem_union_left _ (mem_inter.mpr ⟨hy, ya⟩))
    by_cases yp : y ∈ p.support
    · obtain ⟨i, hi, ei⟩ := Graffiti189LongestPath.OneSlack.pin_of_neighbor_mem hp hx yp ed
      exact mem_union_left _ (mem_union_right _ (mem_image.mpr ⟨i, hi, ei⟩))
    · apply mem_union_right _
      have ext : y ∈ External G A := by
        exact mem_filter.mpr ⟨mem_univ _, ya, x.val, x.property, ed⟩
      exact mem_sdiff.mpr ⟨ext, fun e => yp (List.mem_toFinset.mp e)⟩
  have eq : N.card = J.degree x := by
    rw [← J.card_neighborFinset_eq_degree]
    refine card_bij' (fun y hy => (⟨y, (mem_inter.mp hy).2⟩ : ↥(A : Set V)))
      (fun y _ => y.val) ?_ ?_ ?_ ?_
    · intro y hy
      exact (J.mem_neighborFinset x _).mpr ((G.mem_neighborFinset x.val y).mp (mem_inter.mp hy).1)
    · intro y hy
      exact mem_inter.mpr ⟨(G.mem_neighborFinset x.val y.val).mpr ((J.mem_neighborFinset x y).mp hy), y.property⟩
    · intro y _; rfl
    · intro y _; exact Subtype.ext rfl
  have q := (card_le_card sub).trans (card_union_le _ _)
  have q' := card_union_le N (PinVertices p x.val)
  rw [G.card_neighborFinset_eq_degree] at q
  rw [eq, Graffiti189LongestPath.OneSlack.card_pinVertices hp] at q'
  change G.degree x.val ≤ J.degree x + (Pins p x.val).card + O.card
  omega

#print axioms degree_le_shore_and_ports
end Graffiti189LongestPath.OffPathBoundaryBudget
