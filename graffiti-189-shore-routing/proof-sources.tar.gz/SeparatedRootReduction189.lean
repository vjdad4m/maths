import MengerRoutable189
import GeneralRootAlternatives189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.Normalize Graffiti189LongestPath.OneSlack Graffiti189LongestPath.ActiveStarHeight
open Graffiti189LongestPath.GeneralRootAlternatives Graffiti189LongestPath.MengerRoutable
open private Graffiti189LongestPath.Rigidity.mem_omittedStar from Rigidity189
set_option warningAsError true
namespace Graffiti189LongestPath.SeparatedRootReduction

variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- The Hamilton-connected alternative has been eliminated rather than
assumed false. A normalized separated double can be replaced by a
degree-d or degree-(d+1) double, or a degree-d near-single root. -/
theorem separated_double_root_reduction (hc : G.Connected) (k : Nat) (hk : 7≤k)
    (cap : ∀ v,(EvenFrom G v).card≤k+3)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → k+2≤G.degree u ∨ k+2≤G.degree v)
    (fail : ¬∃ (u v : V) (q : G.Walk u v),q.IsPath ∧ ∀ z,z∈q.support)
    {a b x : V} {p : G.Walk a b} (hp : EdgeMinAvoid (k+2) p) (hx : x∉p.support)
    (double : (Pins p x).card=2) (sep : PairedPins p x=∅)
    (high : k+2≤G.degree x) :
    ∃ z∈OmittedStar p x, k+2≤G.degree z ∧
      (((Pins p z).card=2 ∧ G.degree z≤k+3) ∨
       ((Pins p z).card=1 ∧ G.degree z=k+2 ∧ ∀ y,G.dist z y≤3)) := by
  have eq := star_card_degree_and_pins hp.1.1 hx
  have big : 1<(OmittedStar p x).card := by omega
  obtain ⟨y,ys,yx⟩ := exists_ne_of_one_lt_card big x
  obtain ⟨hy,h⟩ := Graffiti189LongestPath.Rigidity.mem_omittedStar.mp ys
  have xy : G.Adj x y := h.elim (fun e => (yx e).elim) id
  have sat : (External G (OmittedStar p x)).card=k := by
    obtain ⟨_,_,alt⟩ := double_porter_saturated_one_slack hc k hp.1.1 hx
      double (cap x) conn hy xy
    rcases alt with h|h
    · exact h.2
    · simp [sep] at h
  rcases star_alternatives_one_exception hc k hk cap conn deg fail hp hx
    double sat high with root|route
  · exact root
  · exact (routable_double_branch_impossible hc k (by omega) cap conn hp.1.1 hx hy xy
      high double sep route).elim

#print axioms separated_double_root_reduction
end Graffiti189LongestPath.SeparatedRootReduction
