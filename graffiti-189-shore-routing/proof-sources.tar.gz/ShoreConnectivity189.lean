import UniversalWideCut189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.UniversalWideCut
set_option warningAsError true
namespace Graffiti189LongestPath.ShoreConnectivity
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

omit [Fintype V] [DecidableRel G.Adj] in
theorem connected_of_no_partition (S : Finset V) (nonempty : S.Nonempty)
    (part : ∀ A B : Finset V, A∪B=S → Disjoint A B →
      (∀ u∈A,∀ v∈B,¬G.Adj u v) → A=∅ ∨ B=∅) :
    (G.induce (S : Set V)).Connected := by
  classical
  obtain ⟨r,hr⟩ := nonempty
  let J := G.induce (S : Set V)
  let x : ↥(S : Set V) := ⟨r,hr⟩
  refine (connected_iff_exists_forall_reachable J).mpr ⟨x,?_⟩
  intro y
  let A := S.filter (fun v => ∃ h : v∈S,J.Reachable x ⟨v,h⟩)
  let B := S\A
  have union : A∪B=S := union_sdiff_of_subset (filter_subset _ _)
  have dis : Disjoint A B := disjoint_sdiff
  have rx : r∈A := mem_filter.mpr ⟨hr,hr,SimpleGraph.Reachable.refl _⟩
  have empty := part A B union dis (by
    intro u ua v vb ed
    obtain ⟨_,hu,reach⟩ := mem_filter.mp ua
    obtain ⟨hv,no⟩ := mem_sdiff.mp vb
    have ev : J.Adj ⟨u,hu⟩ ⟨v,hv⟩ := ed
    exact no (mem_filter.mpr ⟨hv,hv,reach.trans ev.reachable⟩))
  rcases empty with he|he
  · exact (not_mem_empty _ (he ▸ rx)).elim
  have ya : y.val∈A := by
    by_contra ne
    have yb : y.val∈B := mem_sdiff.mpr ⟨y.property,ne⟩
    exact not_mem_empty _ (he ▸ yb)
  obtain ⟨_,hh,rr⟩ := mem_filter.mp ya
  exact rr

theorem universal_shore_stays_connected (hc : G.Connected) (k : Nat)
    (A B U X : Finset V) (x : V)
    (conn : ∀ D : Finset V,D.card<k → (G.induce ((↑D : Set V)ᶜ)).Connected)
    (exactB : B.card=k) (ab : Disjoint A B) (ub : Disjoint U B)
    (au : Disjoint A U) (large : k≤U.card) (kp : 0<k)
    (closedA : ∀ u∈A,∀ v∉A,G.Adj u v → v∈B)
    (closedU : ∀ u∈U,∀ v∉U,G.Adj u v → v∈B)
    (cap : ∀ v,(DistanceTwo G v).card≤k+2)
    (root : ∀ v∈A,v=x ∨ G.Adj x v)
    (xa : X⊆A) (small : 3*X.card+4<A.card) :
    (G.induce ((↑(A\X)):Set V)).Connected := by
  have h := card_sdiff_add_card_eq_card xa
  apply connected_of_no_partition _ (card_pos.mp (by omega))
  exact fun C E part dis no => shore_cut_no_split hc k A B U X C E x conn
    exactB ab ub au large kp closedA closedU cap root xa part dis no small

#print axioms connected_of_no_partition
#print axioms universal_shore_stays_connected
end Graffiti189LongestPath.ShoreConnectivity
