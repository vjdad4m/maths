import FanDefect189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
set_option warningAsError true
set_option maxHeartbeats 2000000
namespace Graffiti189LongestPath.SplitRoutes
variable {V : Type*} [DecidableEq V] {G : SimpleGraph V}

/-- Spanning alternating route between opposite terminals in balanced shores. -/
theorem even_route (S L : Finset V) (dis : Disjoint S L)
    (cross : ∀ s∈S,∀ l∈L,G.Adj s l) (eq : L.card=S.card)
    {s t : V} (ss : s∈S) (tl : t∈L) :
    ∃ q : G.Walk s t,q.IsPath ∧ (∀ z∈q.support,z∈S∪L) ∧ q.length+1=S.card+L.card := by
  classical
  have go (n : Nat) : ∀ S L : Finset V, S.card=n → L.card=n → Disjoint S L →
      (∀ s∈S,∀ l∈L,G.Adj s l) → ∀ s∈S,∀ t∈L,
        ∃ q : G.Walk s t,q.IsPath ∧ (∀ z∈q.support,z∈S∪L) ∧ q.length+1=S.card+L.card := by
    induction n with
    | zero =>
      intro S L h _ _ _ s hs
      exact (not_mem_empty _ ((card_eq_zero.mp h) ▸ hs)).elim
    | succ n ih =>
      intro S L hs hl dj cr s ss t tl
      by_cases zero : n=0
      · let q := Walk.cons (cr s ss t tl) Walk.nil
        refine ⟨q,?_,?_,?_⟩
        · exact (cons_isPath_iff _ _).mpr ⟨by simp,by
            intro h
            have st : s=t := by simpa using h
            exact disjoint_left.mp dj ss (st.symm ▸ tl)⟩
        · intro z hz
          simp only [q,support_cons,support_nil,List.mem_cons,List.not_mem_nil,or_false] at hz
          exact hz.elim (fun h => mem_union.mpr (Or.inl (h.symm ▸ ss)))
            (fun h => mem_union.mpr (Or.inr (h.symm ▸ tl)))
        · simp [q,hs,hl,zero]
      let S' := S.erase s
      have hn : S'.card=n := by simp [S',card_erase_of_mem ss,hs]
      obtain ⟨l,ll,lt⟩ := exists_ne_of_one_lt_card (by omega : 1<L.card) t
      let L' := L.erase l
      have hm : L'.card=n := by simp [L',card_erase_of_mem ll,hl]
      obtain ⟨s',s's⟩ := card_pos.mp (by omega : 0<S'.card)
      have sl : S'⊆S := erase_subset _ _
      have ls : L'⊆L := erase_subset _ _
      have tl' : t∈L' := mem_erase.mpr ⟨lt.symm,tl⟩
      obtain ⟨q,qp,qs,ql⟩ := ih S' L' hn hm (disjoint_left.mpr (fun _ a b => disjoint_left.mp dj (sl a) (ls b)))
        (fun a ha b hb => cr a (sl ha) b (ls hb)) s' s's t tl'
      have ed := cr s ss l ll
      have ed' := (cr s' (sl s's) l ll).symm
      have q1 : (Walk.cons ed' q).IsPath := by
        apply (cons_isPath_iff _ _).mpr
        refine ⟨qp,?_⟩
        intro hb
        exact (mem_union.mp (qs l hb)).elim (fun ha => disjoint_left.mp dj (sl ha) ll)
          (fun ha => (mem_erase.mp ha).1 rfl)
      refine ⟨Walk.cons ed (Walk.cons ed' q),(cons_isPath_iff _ _).mpr ⟨q1,?_⟩,?_,?_⟩
      · intro hz
        rcases List.mem_cons.mp hz with h|h
        · exact disjoint_left.mp dj ss (h.symm ▸ ll)
        exact (mem_union.mp (qs s h)).elim (fun ha => (mem_erase.mp ha).1 rfl)
          (fun ha => disjoint_left.mp dj ss (ls ha))
      · intro z hz
        rcases List.mem_cons.mp hz with h|h
        · exact mem_union.mpr (Or.inl (h.symm ▸ ss))
        rcases List.mem_cons.mp h with f|f
        · exact mem_union.mpr (Or.inr (f.symm ▸ ll))
        exact (union_subset_union sl ls) (qs z f)
      · simp only [length_cons]
        omega
  exact go S.card S L rfl eq dis cross s ss t tl

/-- Spanning alternating route between two terminals in the larger shore. -/
theorem odd_route (S L : Finset V) (dis : Disjoint S L)
    (cross : ∀ s∈S,∀ l∈L,G.Adj s l) (eq : L.card=S.card+1)
    {u v : V} (ul : u∈L) (vl : v∈L) (ne : u≠v) :
    ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈S∪L) ∧ q.length+1=S.card+L.card := by
  classical
  have two : 1<L.card := one_lt_card.mpr ⟨u,ul,v,vl,ne⟩
  obtain ⟨s,ss⟩ := card_pos.mp (by omega : 0<S.card)
  let L' := L.erase u
  have le : L'⊆L := erase_subset _ _
  have ca : L'.card=S.card := by rw [card_erase_of_mem ul,eq,Nat.add_sub_cancel]
  obtain ⟨q,qp,qs,ql⟩ := even_route S L' (disjoint_of_subset_right le dis)
    (fun a ha b hb => cross a ha b (le hb)) ca ss (mem_erase.mpr ⟨ne.symm,vl⟩)
  let ed := (cross s ss u ul).symm
  refine ⟨Walk.cons ed q,(cons_isPath_iff _ _).mpr ⟨qp,?_⟩,?_,?_⟩
  · intro h
    exact (mem_union.mp (qs u h)).elim (fun b => disjoint_left.mp dis b ul)
      (fun b => (mem_erase.mp b).1 rfl)
  · intro z hz
    rcases List.mem_cons.mp hz with h|h
    · exact mem_union.mpr (Or.inr (h.symm ▸ ul))
    · exact (union_subset_union subset_rfl le) (qs z h)
  · simp only [length_cons]
    omega

/-- With one more large-side vertex than small-side vertices, defects
are counted exactly by the number of prescribed endpoints on the small side. -/
theorem split_routes (S L : Finset V) (dj : Disjoint S L)
    (cross : ∀ s∈S,∀ l∈L,G.Adj s l) (eq : L.card=S.card+1)
    {u v : V} (uu : u∈S∪L) (vv : v∈S∪L) (ne : u≠v) :
    ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈S∪L) ∧
      (S∪L).card≤q.length+1+(if u∈S then 1 else 0)+(if v∈S then 1 else 0) := by
  classical
  have card := card_union_of_disjoint dj
  have mixed {s t : V} (ss : s∈S) (tl : t∈L) :
      ∃ q : G.Walk s t,q.IsPath ∧ (∀ z∈q.support,z∈S∪L) ∧ q.length+2=(S∪L).card := by
    have one : 1<L.card := by have p := card_pos.mpr ⟨s,ss⟩; omega
    obtain ⟨l,ll,lt⟩ := exists_ne_of_one_lt_card one t
    let M := L.erase l
    have sub : M⊆L := erase_subset _ _
    have m : M.card=S.card := by rw [card_erase_of_mem ll,eq,Nat.add_sub_cancel]
    obtain ⟨q,qp,qs,ql⟩ := even_route S M (disjoint_of_subset_right sub dj)
      (fun a ha b hb => cross a ha b (sub hb)) m ss (mem_erase.mpr ⟨lt.symm,tl⟩)
    exact ⟨q,qp,fun z hz => union_subset_union subset_rfl sub (qs z hz),by omega⟩
  rcases mem_union.mp uu with us|ul <;> rcases mem_union.mp vv with vs|vl
  · have h : S.card-1≤L.card := by omega
    obtain ⟨M,ML,mc⟩ := exists_subset_card_eq h
    have p := card_pos.mpr ⟨u,us⟩
    have ss : S.card=M.card+1 := by omega
    obtain ⟨q,qp,qs,ql⟩ := odd_route M S (disjoint_of_subset_left ML dj.symm)
      (fun m hm s hs => (cross s hs m (ML hm)).symm) ss us vs ne
    refine ⟨q,qp,?_,?_⟩
    · intro z hz
      exact (mem_union.mp (qs z hz)).elim (fun m => mem_union.mpr (Or.inr (ML m)))
        (fun s => mem_union.mpr (Or.inl s))
    · simp only [if_pos us,if_pos vs]
      omega
  · obtain ⟨q,qp,qs,ql⟩ := mixed us vl
    have vn := fun h => disjoint_left.mp dj h vl
    exact ⟨q,qp,qs,by simp only [if_pos us,if_neg vn,Nat.add_zero]; omega⟩
  · obtain ⟨q,qp,qs,ql⟩ := mixed vs ul
    have un := fun h => disjoint_left.mp dj h ul
    refine ⟨q.reverse,qp.reverse,?_,?_⟩
    · intro z hz
      rw [support_reverse,List.mem_reverse] at hz
      exact qs z hz
    · simp only [if_pos vs,if_neg un,Nat.add_zero,length_reverse]
      omega
  · obtain ⟨q,qp,qs,ql⟩ := odd_route S L dj cross eq ul vl ne
    have un := fun h => disjoint_left.mp dj h ul
    have vn := fun h => disjoint_left.mp dj h vl
    exact ⟨q,qp,qs,by simp only [if_neg un,if_neg vn,Nat.add_zero]; omega⟩

theorem split_outer (S L : Finset V) (dj : Disjoint S L)
    (cross : ∀ s∈S,∀ l∈L,G.Adj s l) (eq : L.card=S.card+1)
    (pos : 0<S.card) {u : V} (uu : u∈S∪L) :
    ∃ v, ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈S∪L) ∧
      (S∪L).card≤q.length+1+(if u∈S then 1 else 0) := by
  classical
  obtain ⟨v,vl,vu⟩ := exists_ne_of_one_lt_card (by omega : 1<L.card) u
  obtain ⟨q,qp,qs,ql⟩ := split_routes S L dj cross eq uu
    (mem_union.mpr (Or.inr vl)) vu.symm
  have vn := fun h => disjoint_left.mp dj h vl
  exact ⟨v,q,qp,qs,by simpa only [if_neg vn,Nat.add_zero] using ql⟩

#print axioms even_route
#print axioms odd_route
#print axioms split_routes
#print axioms split_outer
end Graffiti189LongestPath.SplitRoutes
