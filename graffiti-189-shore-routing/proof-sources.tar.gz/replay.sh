#!/usr/bin/env bash
set -euo pipefail
# Lean 4.19 with Mathlib and previous proofs (including hall-fan-release)
# on LEAN_PATH. All new modules are recompiled and prioritized here.
root=$(cd "$(dirname "$0")" && pwd)
obj=$(mktemp -d)
trap 'rm -rf "$obj"' EXIT
export LEAN_PATH="$obj:${LEAN_PATH:-}"
for m in SeparatedRootReduction189 UniversalCharge189 UniversalWideCut189 \
  ShoreConnectivity189 StarConnectivity189 CycleRootBridge189 CycleHallSplice189 \
  StarCycleClosure189 FanDefect189 DefectRoutable189 SplitRoutes189 OffPathBoundaryBudget189 \
  StarSplitClosure189 HookMark189 FanGain189 MarkedRoutable189; do
  lean -DwarningAsError=true --root="$root" -o "$obj/$m.olean" "$root/$m.lean"
done
