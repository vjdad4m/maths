import ShellDonorFull189
import FlexibleShellArithmetic189
open Finset SimpleGraph Graffiti189LongestPath
open Graffiti189LongestPath.ShellDonorFull Graffiti189LongestPath.FlexibleShellArithmetic
open private Graffiti189LongestPath.mem_distanceTwo from SmallSeparator189
set_option warningAsError true
set_option maxHeartbeats 6500000
namespace Graffiti189LongestPath.FlexSplitShell
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

omit [Fintype V] [DecidableRel G.Adj] in
private theorem count_group (D : Finset V) (F : V→Finset V) (cost bound : Nat)
    (h : ∀ v∈D,(F v).card+cost≤bound) :
    (D.biUnion F).card+D.card*cost≤D.card*bound := by
  classical
  by_cases ne : D.Nonempty
  · obtain ⟨v,vd⟩ := ne
    have hb := h v vd
    have q : cost≤bound := by omega
    have z := card_biUnion_le_card_mul D F (bound-cost) (fun z hz => by have r := h z hz; omega)
    have e : D.card*(bound-cost)+D.card*cost=D.card*bound := by
      rw [←Nat.mul_add,Nat.sub_add_cancel q]
    omega
  have e : D=∅ := not_nonempty_iff_eq_empty.mp ne
  simp [e]

/-- A large nonedge split among the first-shell donors makes the
third-shell cap even smaller. The pin term is absorbed in the quadratic
when k exceeds twice the degree-connectivity deficit. -/
theorem flex_split_shell_three_bound (hc : G.Connected) (d p mF : Nat) (d5 : 5≤d)
    (cap : ∀ v,(DistanceTwo G v).card≤d) (x : V)
    (A B C E P W X : Finset V)
    (partition : C∪E∪P∪W=G.neighborFinset x)
    (shore : A=C∪E∪X) (root : ∀ v∈A,v=x∨G.Adj x v)
    (closed : ∀ u∈A,∀ v∉A,G.Adj u v → v∈B)
    (deg : ∀ u v : V,u≠v → d≤G.degree u ∨ d≤G.degree v)
    (ce : Disjoint C E) (cp : Disjoint C P) (cw : Disjoint C W)
    (ep : Disjoint E P) (ew : Disjoint E W) (pw : Disjoint P W)
    (nonedge : ∀ u∈C,∀ v∈E,¬G.Adj u v)
    (smaller : C.card≤E.card) (cs : mF≤C.card) (md : mF≤d+1)
    (ps : P.card≤p) (ws : W.card≤1) (xs : X.card≤2) (bk : B.card+p≤d+1) :
    6*(Shell G x 3).card≤(d+4)*(d+4)+3*(p*p)+6*d ∨
      4*(Shell G x 3).card≤(d+1-mF)*(d+1-mF)+4*(mF*p)+8*d := by
  classical
  let F := gateThird G x (DistanceTwo G x)
  let H := Shell G x 3
  obtain ⟨D,DA,cover,privateGate,every⟩ := exists_shell_donors_with_private_charges hc d cap x
  let C' := D∩C
  let E' := D∩E
  let P' := D∩P
  let W' := D∩W
  let a := C'.card
  let b := E'.card
  let t := P'.card
  let r := W'.card
  have decomp : D=C'∪E'∪P'∪W' := by
    ext v
    constructor
    · intro h
      have vc : v∈C∪E∪P∪W := partition.symm ▸ DA h
      change v∈(D∩C)∪(D∩E)∪(D∩P)∪(D∩W)
      simp only [mem_union,mem_inter] at vc ⊢
      tauto
    · simp only [C',E',P',W',mem_union,mem_inter]
      tauto
  have di {X Y : Finset V} (h : Disjoint X Y) : Disjoint (D∩X) (D∩Y) :=
    disjoint_left.mpr (fun _ hx hy => disjoint_left.mp h (mem_inter.mp hx).2 (mem_inter.mp hy).2)
  have de' : Disjoint (C'∪E') P' := disjoint_union_left.mpr ⟨di cp,di ep⟩
  have dw' : Disjoint (C'∪E'∪P') W' :=
    disjoint_union_left.mpr ⟨disjoint_union_left.mpr ⟨di cw,di ew⟩,di pw⟩
  have dc : D.card=a+b+t+r := by
    have h := congrArg Finset.card decomp
    rw [card_union_of_disjoint dw',card_union_of_disjoint de',card_union_of_disjoint (di ce)] at h
    exact h
  have efix : E.card=b+(E\D).card := by
    have h := card_sdiff_add_card_inter E D
    rw [inter_comm E D] at h
    change (E\D).card+b=E.card at h
    omega
  have cfix : C.card=a+(C\D).card := by
    have h := card_sdiff_add_card_inter C D
    rw [inter_comm C D] at h
    change (C\D).card+a=C.card at h
    omega
  have cN : C⊆G.neighborFinset x := by
    rw [←partition]
    exact fun _ hz => mem_union.mpr (Or.inl (mem_union.mpr (Or.inl (mem_union.mpr (Or.inl hz)))))
  have eN : E⊆G.neighborFinset x := by
    rw [←partition]
    exact fun _ hz => mem_union.mpr (Or.inl (mem_union.mpr (Or.inl (mem_union.mpr (Or.inr hz)))))
  have chargeC : ∀ v∈C',(F v).card+(a+t+E.card)≤d+1 := by
    intro v hv
    obtain ⟨vd,vc⟩ := mem_inter.mp hv
    have h := every v vd E eN (fun z ez =>
      ⟨fun e => disjoint_left.mp ce vc (e ▸ ez), nonedge v vc z ez⟩)
    change (F v).card+(D.card-1)+(E\D).card≤d at h
    have dd : 0<D.card := card_pos.mpr ⟨v,vd⟩
    omega
  have chargeE : ∀ v∈E',(F v).card+(b+t+C.card)≤d+1 := by
    intro v hv
    obtain ⟨vd,ve⟩ := mem_inter.mp hv
    have h := every v vd C cN (fun z zc =>
      ⟨fun e => disjoint_left.mp ce zc (e.symm ▸ ve),fun e => nonedge z zc v ve e.symm⟩)
    change (F v).card+(D.card-1)+(C\D).card≤d at h
    have dd : 0<D.card := card_pos.mpr ⟨v,vd⟩
    omega
  have chargeP : ∀ v∈P',(F v).card+(a+b+t)≤d+1 := by
    intro v hv
    have vd := (mem_inter.mp hv).1
    have h := every v vd (∅:Finset V) (empty_subset _) (by simp)
    change (F v).card+(D.card-1)+_≤d at h
    have dd : 0<D.card := card_pos.mpr ⟨v,vd⟩
    omega
  have chargeW : ∀ v∈W',(F v).card≤d := by
    intro v hv
    have h := every v (mem_inter.mp hv).1 (∅:Finset V) (empty_subset _) (by simp)
    change (F v).card+(D.card-1)+_≤d at h
    omega
  let HC := C'.biUnion F
  let HE := E'.biUnion F
  let HP := P'.biUnion F
  let HW := W'.biUnion F
  have hc' : HC.card+a*(a+t+E.card)≤a*(d+1) := count_group C' F (a+t+E.card) (d+1) chargeC
  have he' : HE.card+b*(b+t+C.card)≤b*(d+1) := count_group E' F (b+t+C.card) (d+1) chargeE
  have hp' : HP.card+t*(a+b+t)≤t*(d+1) := count_group P' F (a+b+t) (d+1) chargeP
  have hw' : HW.card≤r*d := card_biUnion_le_card_mul W' F d chargeW
  have r1 : r≤1 := (card_le_card (inter_subset_right : W'⊆W)).trans ws
  have hW : HW.card≤d := by
    have q := Nat.mul_le_mul_right d r1
    rw [one_mul] at q
    exact hw'.trans q
  have hcvr : H⊆HC∪HE∪HP∪HW := by
    intro z hz
    obtain ⟨v,vd,vz⟩ := mem_biUnion.mp (cover hz)
    have vc : v∈C'∪E'∪P'∪W' := decomp ▸ vd
    simp only [mem_union] at vc
    rcases vc with ((hc|he)|hp)|hw
    · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inl (mem_union.mpr (Or.inl
        (mem_biUnion.mpr ⟨v,hc,vz⟩))))))
    · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inl (mem_union.mpr (Or.inr
        (mem_biUnion.mpr ⟨v,he,vz⟩))))))
    · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inr (mem_biUnion.mpr ⟨v,hp,vz⟩))))
    · exact mem_union.mpr (Or.inr (mem_biUnion.mpr ⟨v,hw,vz⟩))
  have all := card_le_card hcvr
  have cav := card_union_le HC HE
  have pav := card_union_le (HC∪HE) HP
  have wav := card_union_le (HC∪HE∪HP) HW
  have tn : t≤p := (card_le_card (inter_subset_right : P'⊆P)).trans ps
  have subC : C⊆A := fun _ h => shore.symm ▸ mem_union.mpr (Or.inl (mem_union.mpr (Or.inl h)))
  have subE : E⊆A := fun _ h => shore.symm ▸ mem_union.mpr (Or.inl (mem_union.mpr (Or.inr h)))
  by_cases high : ∃ v∈C',d≤G.degree v
  · left
    obtain ⟨v,vc,vh⟩ := high
    let Doff := C'∪E'
    have offCard : Doff.card=a+b := card_union_of_disjoint (di ce)
    have vc' := (mem_inter.mp vc).2
    have vo : v∈Doff := mem_union.mpr (Or.inl vc)
    have vD : v∈D := (mem_inter.mp vc).1
    have Doff_in (u : V) (ud : u∈Doff) : u∈D ∧ u∈A := by
      rcases mem_union.mp ud with e|e
      · exact ⟨(mem_inter.mp e).1,subC (mem_inter.mp e).2⟩
      · exact ⟨(mem_inter.mp e).1,subE (mem_inter.mp e).2⟩
    have priv (u : V) : ∃ z,u∈Doff → z∈B ∧ G.Adj u z ∧ ∀ w∈D,w≠u → ¬G.Adj w z := by
      by_cases ud : u∈Doff
      · obtain ⟨z,zd,uz,pr⟩ := privateGate u (Doff_in u ud).1
        have zx := Graffiti189LongestPath.mem_distanceTwo.mp zd
        have zn : z∉A := by
          intro za
          rcases root z za with rfl|h
          · rw [dist_self] at zx; omega
          · have q := dist_eq_one_iff_adj.mpr h; omega
        exact ⟨z,fun _ => ⟨closed u (Doff_in u ud).2 z zn uz,uz,pr⟩⟩
      · exact ⟨x,fun h => (ud h).elim⟩
    choose rep pick using priv
    have inj : Set.InjOn rep (↑Doff:Set V) := by
      intro u uu w ww eq
      apply Classical.byContradiction
      intro ne
      exact (pick w ww).2.2 u (Doff_in u uu).1 ne (eq ▸ (pick u uu).2.1)
    let S := (Doff.erase v).image rep
    have cardS : S.card+1=a+b := by
      have e := card_image_of_injOn (s := Doff.erase v) (fun _ h _ j eq => inj (mem_erase.mp h).2 (mem_erase.mp j).2 eq)
      change S.card=(Doff.erase v).card at e
      have n := card_erase_add_one vo
      omega
    have SB : S⊆B := by
      intro z zs
      obtain ⟨u,hu,rfl⟩ := mem_image.mp zs
      exact (pick u (mem_erase.mp hu).2).1
    have bad : ∀ z∈S,¬G.Adj v z := by
      intro z zs
      obtain ⟨u,hu,rfl⟩ := mem_image.mp zs
      exact (pick u (mem_erase.mp hu).2).2.2 v vD (mem_erase.mp hu).1.symm
    have ns : G.neighborFinset v⊆C.erase v∪X∪(B\S) := by
      intro z hz
      have ed := (G.mem_neighborFinset _ _).mp hz
      by_cases za : z∈A
      · rcases mem_union.mp (shore ▸ za) with h|h
        · rcases mem_union.mp h with h|h
          · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inl (mem_erase.mpr ⟨ed.ne.symm,h⟩))))
          · exact (nonedge v vc' z h ed).elim
        · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inr h)))
      exact mem_union.mpr (Or.inr (mem_sdiff.mpr
        ⟨closed v (subC vc') z za ed,fun e => bad z e ed⟩))
    have nc := card_le_card ns
    rw [G.card_neighborFinset_eq_degree] at nc
    have ca := card_erase_add_one vc'
    have a₁ := card_union_le (C.erase v) X
    have a₂ := card_union_le (C.erase v∪X) (B\S)
    have b₁ := card_sdiff_add_card_eq_card SB
    have u : a+b+p≤C.card+3 := by omega
    have ua := Nat.mul_le_mul_left a (show a+b+p≤E.card+3 by omega)
    have ub := Nat.mul_le_mul_left b u
    simp only [Nat.mul_add] at ua ub
    have mass : H.card+a*a+b*b+2*(a+b)*t+t*t+(a+b)*(a+b)+(a+b)*p≤
        (a+b)*(d+4)+t*(d+1)+d := by
      have i₁ : a*(a+t+E.card)+b*(b+t+C.card)+t*(a+b+t)=
          a*a+b*b+2*(a+b)*t+t*t+a*E.card+b*C.card := by ring
      have i₂ : a*(d+1)+b*(d+1)+3*a+3*b=(a+b)*(d+4) := by ring
      have i₃ : a*a+a*b+a*p+(b*a+b*b+b*p)=(a+b)*(a+b)+(a+b)*p := by ring
      omega
    exact mixed_shell_numeric H.card d a b t p d5 tn mass
  right
  have a1 : a≤1 := by
    apply Nat.le_of_not_gt
    intro h
    obtain ⟨u,uu,v,vv,ne⟩ := one_lt_card.mp (show 1<C'.card from h)
    exact (deg u v ne).elim (fun e => high ⟨u,uu,e⟩) (fun e => high ⟨v,vv,e⟩)
  have hC : HC.card≤d := by
    have s : HC.card≤a*d := card_biUnion_le_card_mul C' F d (fun v vc => by
      have e := chargeC v vc
      have pos : 0<a := card_pos.mpr ⟨v,vc⟩
      omega)
    have q := Nat.mul_le_mul_right d a1
    rw [one_mul] at q
    exact s.trans q
  let q := d+1-mF
  have mass : H.card+(b+t)*(b+t)≤(b+t)*q+mF*t+2*d := by
    have side := Nat.mul_le_mul_left b cs
    have aa := Nat.mul_le_mul_left t (show b+t≤a+b+t by omega)
    have i₁ : b*(b+t+C.card)=b*b+b*t+b*C.card := by ring
    have i₂ : t*(b+t)=t*b+t*t := by ring
    have i₃ : (b+t)*(b+t)=b*b+b*t+t*b+t*t := by ring
    have i₄ : q+mF=d+1 := Nat.sub_add_cancel md
    have e := congrArg (fun z => (b+t)*z) i₄
    have i₅ : (b+t)*(q+mF)=(b+t)*q+b*mF+mF*t := by ring
    have i₆ : (b+t)*(d+1)=b*(d+1)+t*(d+1) := by ring
    change (b+t)*(q+mF)=(b+t)*(d+1) at e
    rw [i₅,i₆] at e
    omega
  exact one_shell_numeric H.card b t q mF p d tn mass

#print axioms flex_split_shell_three_bound
end Graffiti189LongestPath.FlexSplitShell
