import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

namespace Graffiti189LongestPath.FlexibleFinishNumeric

theorem split_contradiction
    (k s p m f h : ℤ) (hk : 2000 ≤ k) (hs0 : 0 ≤ s)
    (hs : 3*s ≤ 2*k) (hp0 : 0 ≤ p) (hp : p ≤ s)
    (hm : 2*m ≤ k) (hm' : k-3 ≤ 2*m)
    (hf : k-2*s+2*p-6 ≤ f)
    (hbase : (k+1)*(m+1) ≤ h+2*s)
    (hflex : (k+1)*(m+1)+f*(m-2) ≤ h+2*s+2*(m-2))
    (hcap : 6*h ≤ (k+s+4)^2+3*p^2+6*(k+s) ∨
      4*h ≤ (k+s+1-m)^2+4*m*p+8*(k+s)) : False := by
  have bk : k^2-1 ≤ 2*(h+2*s) := by
    nlinarith only [hbase, mul_nonneg (show 0 ≤ k+1 by omega)
      (show 0 ≤ 2*m-k+3 by omega)]
  have sqA : 9*(k+s+4)^2 ≤ (5*k+12)^2 := by
    nlinarith only [mul_nonneg (show 0 ≤ 2*k-3*s by omega)
      (show 0 ≤ 8*k+3*s+24 by omega)]
  have sqB : 36*(k+s+1-m)^2 ≤ (7*k+15)^2 := by
    nlinarith only [mul_nonneg (show 0 ≤ k-6*s+6*m+9 by omega)
      (show 0 ≤ 13*k+6*s-6*m+21 by omega)]
  have lsmall := mul_nonneg (show 0 ≤ k by omega) (show 0 ≤ k-2000 by omega)
  have mprod : 4*m*p ≤ 2*k*p := by
    nlinarith only [mul_nonneg hp0 (show 0 ≤ k-2*m by omega)]
  by_cases hlo : 6*p ≤ k
  · have p2 : 36*p^2 ≤ k^2 := by
      nlinarith only [mul_nonneg (show 0 ≤ k-6*p by omega)
        (show 0 ≤ k+6*p by omega)]
    rcases hcap with A | B
    · nlinarith only [A, bk, sqA, p2, lsmall, hk, hs]
    · nlinarith only [B, bk, sqB, mprod, lsmall, hk, hs, hlo,
        mul_nonneg (show 0 ≤ k by omega) (show 0 ≤ k-6*p by omega)]
  · have hfa : 6*p-k-24 ≤ 3*(f-2) := by omega
    have bflex : 2*k^2+6*k*p-60*k ≤ 6*(h+2*s) := by
      by_cases hn : 0 ≤ 6*p-k-24
      · have h1 := mul_nonneg hn (show 0 ≤ 2*m-k+3 by omega)
        have h2 := mul_nonneg (show 0 ≤ 3*(f-2)-(6*p-k-24) by omega)
          (show 0 ≤ m-2 by omega)
        nlinarith only [h1,h2,hflex,hk,
          mul_nonneg (show 0 ≤ k+1 by omega) (show 0 ≤ 2*m-k+3 by omega), hp, hs]
      · have h1 := mul_nonneg (show 0 ≤ k by omega) (show 0 ≤ k+24-6*p by omega)
        nlinarith only [h1,bk,hk]
    rcases hcap with A | B
    · have parab : 11*k^2 ≤ 36*(2*k*p-p^2) := by
        nlinarith only [mul_nonneg (show 0 ≤ 6*p-k by omega)
          (show 0 ≤ 11*k-6*p by omega)]
      nlinarith only [A,bflex,sqA,parab,lsmall,hk,hs]
    · nlinarith only [B,bflex,sqB,mprod,lsmall,hk,hs,
        mul_nonneg (show 0 ≤ k by omega) (show 0 ≤ 6*p-k by omega)]

end Graffiti189LongestPath.FlexibleFinishNumeric
