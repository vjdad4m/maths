import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
set_option warningAsError true
namespace Graffiti189LongestPath.FlexibleShellArithmetic

theorem mixed_shell_numeric (H d a b t p : Nat) (d5 : 5≤d) (tp : t≤p)
    (mass : H+a*a+b*b+2*(a+b)*t+t*t+(a+b)*(a+b)+(a+b)*p ≤
      (a+b)*(d+4)+t*(d+1)+d) :
    6*H≤(d+4)*(d+4)+3*(p*p)+6*d := by
  have mz : (H:ℤ)+(a:ℤ)*a+(b:ℤ)*b+2*((a:ℤ)+b)*t+(t:ℤ)*t+
      ((a:ℤ)+b)*((a:ℤ)+b)+((a:ℤ)+b)*p ≤
      ((a:ℤ)+b)*((d:ℤ)+4)+(t:ℤ)*((d:ℤ)+1)+d := by exact_mod_cast mass
  have g : 6*(H:ℤ)≤((d:ℤ)+4-p-2*(t:ℤ))^2+
      6*(t:ℤ)*((d:ℤ)+1)-6*(t:ℤ)^2+6*(d:ℤ) := by
    nlinarith only [mz,sq_nonneg ((a:ℤ)-(b:ℤ)),
      sq_nonneg (3*((a:ℤ)+b)-((d:ℤ)+4-p-2*(t:ℤ)))]
  have a : 0≤(p:ℤ)-(t:ℤ) := by omega
  have b : 0≤2*(d:ℤ)-10+2*((p:ℤ)-(t:ℤ)) := by omega
  have q := mul_nonneg a b
  have z : 6*(H:ℤ)≤((d:ℤ)+4)*((d:ℤ)+4)+3*((p:ℤ)*(p:ℤ))+6*(d:ℤ) := by
    have non : 0≤(p:ℤ) := Int.ofNat_nonneg _
    nlinarith only [g,q,non]
  exact_mod_cast z

theorem one_shell_numeric (H b t q m p d : Nat) (tp : t≤p)
    (mass : H+(b+t)*(b+t)≤(b+t)*q+m*t+2*d) :
    4*H≤q*q+4*(m*p)+8*d := by
  have mz : (H:ℤ)+((b:ℤ)+t)*((b:ℤ)+t)≤
      ((b:ℤ)+t)*q+(m:ℤ)*t+2*(d:ℤ) := by exact_mod_cast mass
  have m1 : (m:ℤ)*(t:ℤ)≤(m:ℤ)*(p:ℤ) := by exact_mod_cast (Nat.mul_le_mul_left m tp)
  have z : 4*(H:ℤ)≤(q:ℤ)*q+4*((m:ℤ)*p)+8*(d:ℤ) := by
    nlinarith only [mz,m1,sq_nonneg (2*((b:ℤ)+t)-(q:ℤ))]
  exact_mod_cast z

#print axioms mixed_shell_numeric
#print axioms one_shell_numeric
end Graffiti189LongestPath.FlexibleShellArithmetic
