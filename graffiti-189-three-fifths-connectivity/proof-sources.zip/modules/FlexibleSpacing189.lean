import FanWeighted189
open Finset
open scoped BigOperators
set_option warningAsError true
set_option maxHeartbeats 2000000
namespace Graffiti189LongestPath.FlexibleSpacing

/-- An oriented gain on the left terminal need only incur a loss when
the next terminal is exceptional. The last terminal contributes via
the right-end room bound. -/
theorem one_sided_weighted_span (H len : Nat) (I : Finset Nat) (g b : Nat→Nat)
    (pos : 0<I.card)
    (left : ∀ i∈I,H≤i)
    (right : ∀ i∈I,i+H+g i≤len)
    (gap : ∀ i∈I,∀ j∈I,i<j → i+H+1+g i≤j+b j) :
    I.card+(I.card+1)*H+(∑ i∈I,g i)≤len+1+(∑ i∈I,b i) := by
  classical
  have walk (J : Finset Nat) (pos : 0<J.card) (L Q : Nat)
      (lower : ∀ i∈J,L≤i+b i+Q)
      (space : ∀ i∈J,∀ j∈J,i<j → i+H+1+g i≤j+b j) :
      ∃ z∈J,L+(J.card-1)*(H+1)+(∑ i∈J,g i)≤z+g z+(∑ i∈J,b i)+Q := by
    induction J using Finset.strongInductionOn generalizing L Q with
    | _ J ih =>
      have ne : J.Nonempty := card_pos.mp pos
      let x := J.min' ne
      have hx : x∈J := min'_mem _ _
      let S := J.erase x
      have cs : S.card=J.card-1 := card_erase_of_mem hx
      have sg : (∑ i∈J,g i)=(∑ i∈S,g i)+g x := (sum_erase_add _ _ hx).symm
      have sb : (∑ i∈J,b i)=(∑ i∈S,b i)+b x := (sum_erase_add _ _ hx).symm
      by_cases e : J.card=1
      · have no : S=∅ := card_eq_zero.mp (by omega)
        refine ⟨x,hx,?_⟩
        rw [sg,sb,no,sum_empty,sum_empty,e]
        have h := lower x hx
        simp
        omega
      have lower' : ∀ z∈S,L+H+1+g x≤z+b z+(Q+b x) := by
        intro z hz
        obtain ⟨xz,zz⟩ := mem_erase.mp hz
        have xle := min'_le J z zz
        have g' := space x hx z zz (by omega)
        have xh := lower x hx
        omega
      obtain ⟨z,zs,oz⟩ := ih S (erase_ssubset hx) (by omega) (L+H+1+g x) (Q+b x)
        lower' (fun i hi j hj lt => space i (mem_erase.mp hi).2 j (mem_erase.mp hj).2 lt)
      have shift : (J.card-1)*(H+1)=(S.card-1)*(H+1)+(H+1) := by
        rw [show J.card-1=(S.card-1)+1 by omega,Nat.add_mul,one_mul]
      refine ⟨z,(mem_erase.mp zs).2,?_⟩
      rw [sg,sb,shift]
      omega
  obtain ⟨z,zi,step⟩ := walk I pos H 0 (fun i hi => by have g := left i hi; omega) gap
  have h := right z zi
  rw [Nat.mul_add,Nat.mul_one] at step
  have e : (I.card+1)*H=(I.card-1)*H+2*H := by
    rw [show I.card+1=(I.card-1)+2 by omega,Nat.add_mul]
  rw [e]
  omega

#print axioms one_sided_weighted_span
end Graffiti189LongestPath.FlexibleSpacing
