import QuadraticDeficitAll189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack
open Graffiti189LongestPath.GeneralGapMidpoint Graffiti189LongestPath.GapTwin
open private Graffiti189LongestPath.pin_data from SmallSeparator189
set_option warningAsError true
namespace Graffiti189LongestPath.GapOne
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- Below the zero-gap regime, the unique possible low-degree vertex
still permits at most one gap-two link among the pins. -/
theorem first_pins_at_least_pins_sub_one (hc : G.Connected) (d : Nat)
    (cap : ∀ v,(EvenFrom G v).card≤d+1)
    (deg : ∀ u v : V,u≠v → d≤G.degree u ∨ d≤G.degree v)
    {a b x : V} {p : G.Walk a b} (hmin : EdgeMin p) (hx : x∉p.support)
    (high : d≤G.degree x) (few : 2*(Pins p x).card<d) :
    (Pins p x).card≤(FirstPins p x).card+1 := by
  classical
  let I := Pins p x
  let F := FirstPins p x
  let U := I\F
  have sub : F⊆I := filter_subset _ _
  have pred (i : Nat) (iu : i∈U) : ∃ j∈I,j+2=i := by
    apply Classical.byContradiction
    intro h
    have ip := (mem_sdiff.mp iu).1
    have iff : i∈F := mem_filter.mpr ⟨ip,fun j jj eq => h ⟨j,jj,eq⟩⟩
    exact (mem_sdiff.mp iu).2 iff
  have u1 : U.card≤1 := by
    apply Nat.le_of_not_gt
    intro h
    obtain ⟨i,iu,j,ju,ne⟩ := one_lt_card.mp (show 1<U.card from h)
    obtain ⟨r,rI,ri⟩ := pred i iu
    obtain ⟨s,sI,sj⟩ := pred j ju
    have rp : r+2∈I := ri.symm ▸ (mem_sdiff.mp iu).1
    have sp : s+2∈I := sj.symm ▸ (mem_sdiff.mp ju).1
    have dr := gap_midpoint_degree_le_twice_pins hc d cap hmin hx high rI rp
    have ds := gap_midpoint_degree_le_twice_pins hc d cap hmin hx high sI sp
    have rd := (Graffiti189LongestPath.pin_data rp).1
    have sd := (Graffiti189LongestPath.pin_data sp).1
    have uv : p.getVert (r+1)≠p.getVert (s+1) := by
      intro e
      have q := hmin.1.1.getVert_injOn (show r+1≤p.length by omega)
        (show s+1≤p.length by omega) e
      omega
    exact (deg _ _ uv).elim (fun e => by omega) (fun e => by omega)
  have c := card_sdiff_add_card_eq_card sub
  change U.card+F.card=I.card at c
  change I.card≤F.card+1
  omega

#print axioms first_pins_at_least_pins_sub_one
end Graffiti189LongestPath.GapOne
