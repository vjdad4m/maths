import FanLower189
open Finset SimpleGraph SimpleGraph.Walk
open Graffiti189LongestPath Graffiti189LongestPath.Rigidity Graffiti189LongestPath.FanRoutable
set_option warningAsError true
set_option maxHeartbeats 2800000
namespace Graffiti189LongestPath.HookRetarget
variable {V : Type*} {G : SimpleGraph V}

/-- A hook stores a simple walk off the spine and a final edge to a
specified spine vertex. It meets the internal shore only at its root. -/
structure SingleHook {a b : V} (p : G.Walk a b) (A : Finset V) (j : Nat) where
  root : V
  last : V
  tail : G.Walk root last
  simple : tail.IsPath
  firstIn : root∈A
  finish : G.Adj last (p.getVert j)
  onlyRoot : ∀ z∈tail.support,z∈A → z=root
  off : ∀ z∈tail.support,z∉p.support

def SingleHook.firstPort {a b : V} {p : G.Walk a b} {A : Finset V} {j : Nat}
    (H : SingleHook p A j) : V := ((H.tail).concat H.finish).getVert 1

/-- The only possible spine vertex occurring at the first port is the
target itself. Otherwise it is a genuine outside-shore hook vertex. -/
theorem first_port_location {a b : V} {p : G.Walk a b} {A : Finset V} {j : Nat}
    (H : SingleHook p A j) :
    (H.firstPort∈H.tail.support ∧ H.firstPort∉A) ∨ H.firstPort=p.getVert j := by
  rcases H with ⟨u,v,q,qp,ua,finish,only,off⟩
  cases q with
  | nil => exact Or.inr rfl
  | @cons u w v ed q =>
    have wg : w∉A := fun wa => ed.ne (only w (List.mem_cons_of_mem _ q.start_mem_support) wa).symm
    exact Or.inl ⟨by simp [SingleHook.firstPort], by simpa [SingleHook.firstPort] using wg⟩

theorem first_port_mem_boundary {a b : V} {p : G.Walk a b} {A B : Finset V} {j : Nat}
    (H : SingleHook p A j) (ao : ∀ z∈A,z∉p.support)
    (closed : ∀ u∈A,∀ v∉A,G.Adj u v → v∈B) : H.firstPort∈B := by
  rcases H with ⟨u,v,q,qp,ua,finish,only,off⟩
  cases q with
  | nil =>
    have h := closed u ua (p.getVert j) (fun va => ao _ va (p.getVert_mem_support j)) finish
    simpa [SingleHook.firstPort] using h
  | @cons u w v ed q =>
    have wg : w∉A := fun wa => ed.ne (only w (List.mem_cons_of_mem _ q.start_mem_support) wa).symm
    have h := closed u ua w wg ed
    simpa [SingleHook.firstPort] using h

/-- If the first cut port has another allowed root, all outside-shore
hook vertices are unchanged by retargeting. -/
theorem retarget_first_port {a b : V} {p : G.Walk a b} {A : Finset V} {j : Nat}
    (H : SingleHook p A j) (ao : ∀ z∈A,z∉p.support) (z : V) (za : z∈A)
    (ed : G.Adj z H.firstPort) :
    ∃ K : SingleHook p A j,K.root=z ∧ K.tail.length=H.tail.length ∧
      ∀ w∉A,w∈K.tail.support ↔ w∈H.tail.support := by
  rcases H with ⟨u,v,q,qp,ua,finish,only,off⟩
  cases q with
  | nil =>
    have ex : G.Adj z (p.getVert j) := by simpa [SingleHook.firstPort] using ed
    have zoo : ∀ w∈(Walk.nil:G.Walk z z).support,w∉p.support := by
      intro w hw
      have h : w=z := by simpa using hw
      subst w
      exact ao z za
    let K : SingleHook p A j := ⟨z,z,.nil,IsPath.nil,za,ex,by simp,zoo⟩
    refine ⟨K,rfl,rfl,?_⟩
    intro w wa
    have zz : w≠z := fun eq => wa (eq.symm ▸ za)
    have uu : w≠u := fun eq => wa (eq.symm ▸ ua)
    simp [K,zz,uu]
  | @cons u w v first q =>
    have ex : G.Adj z w := by simpa [SingleHook.firstPort] using ed
    have outside (v' : V) (h : v'∈q.support) : v'∉A := by
      intro va
      have e := only v' (List.mem_cons_of_mem _ h) va
      exact (cons_isPath_iff _ _).mp qp |>.2 (e ▸ h)
    let K : SingleHook p A j :=
      ⟨z,v,.cons ex q,qp.of_cons.cons (fun h => outside z h za),za,finish,
        (by
          intro w hw wa
          rcases List.mem_cons.mp hw with e|e
          · exact e
          · exact (outside w e wa).elim),
        (by
          intro w hw
          rcases List.mem_cons.mp hw with e|e
          · exact e.symm ▸ ao z za
          · exact off w (List.mem_cons_of_mem _ e))⟩
    refine ⟨K,rfl,rfl,?_⟩
    intro w wa
    have zz : w≠z := fun eq => wa (eq.symm ▸ za)
    have uu : w≠u := fun eq => wa (eq.symm ▸ ua)
    simp [K,zz,uu]

def fromFamily {a b : V} {p : G.Walk a b} {A : Finset V} {k : Nat}
    (F : HookFamily p A k) (i : Fin k) : SingleHook p A (F.idx i) :=
  ⟨F.root i,F.last i,F.path i,F.simple i,F.firstIn i,F.adjLast i,F.single i,F.off i⟩

theorem family_first_ports_injective {a b : V} {p : G.Walk a b} {A : Finset V} {k : Nat}
    (hp : IsLongest p) (F : HookFamily p A k) :
    Function.Injective (fun i => (fromFamily F i).firstPort) := by
  intro i j eq
  change (fromFamily F i).firstPort=(fromFamily F j).firstPort at eq
  apply Classical.byContradiction
  intro ne
  rcases first_port_location (fromFamily F i) with ⟨u,_⟩|u
  · rcases first_port_location (fromFamily F j) with ⟨v,_⟩|v
    · exact F.disj ne u (by rw [eq]; exact v)
    · exact F.off i _ u (by rw [eq,v]; exact p.getVert_mem_support (F.idx j))
  · rcases first_port_location (fromFamily F j) with ⟨v,_⟩|v
    · exact F.off j _ v (by rw [←eq,u]; exact p.getVert_mem_support (F.idx i))
    · exact ne (F.idx.injective
        (hp.1.getVert_injOn (F.idxLt i).le (F.idxLt j).le (u.symm.trans (eq.trans v))))

#print axioms first_port_mem_boundary
#print axioms retarget_first_port
#print axioms family_first_ports_injective
end Graffiti189LongestPath.HookRetarget
