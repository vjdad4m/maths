import HookRetarget189
import QuadraticDeficitAll189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.HookRetarget Graffiti189LongestPath.FanRoutable Graffiti189LongestPath.Rigidity
open private Graffiti189LongestPath.boundary_card_of_connectivity from SmallSeparator189
set_option warningAsError true
set_option maxHeartbeats 4700000
namespace Graffiti189LongestPath.PortReachCount
variable {V : Type*} [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

private theorem side_ports_bound (k : Nat) (A B C E X : Finset V)
    (conn : ∀ D : Finset V,D.card<k → (G.induce ((↑D : Set V)ᶜ)).Connected)
    (part : A=C∪E∪X) (ab : Disjoint A B) (ce : Disjoint C E)
    (cx : Disjoint C X) (ex : Disjoint E X) (cn : C.Nonempty) (en : E.Nonempty)
    (no : ∀ u∈C,∀ v∈E,¬G.Adj u v)
    (closed : ∀ u∈A,∀ v∉A,G.Adj u v → v∈B) :
    k≤X.card+(B.filter (fun b => ∃ u∈C,G.Adj u b)).card := by
  classical
  let O := B.filter (fun b => ∃ u∈C,G.Adj u b)
  let S := X∪O
  obtain ⟨u,uu⟩ := cn
  obtain ⟨v,vv⟩ := en
  have aC {z : V} (zc : z∈C) : z∈A := part.symm ▸ mem_union.mpr (Or.inl (mem_union.mpr (Or.inl zc)))
  have aE {z : V} (ze : z∈E) : z∈A := part.symm ▸ mem_union.mpr (Or.inl (mem_union.mpr (Or.inr ze)))
  have vc : v∉C := fun e => disjoint_left.mp ce e vv
  have vs : v∉S := fun e => (mem_union.mp e).elim (fun r => disjoint_left.mp ex vv r)
    (fun r => disjoint_left.mp ab (aE vv) (mem_filter.mp r).1)
  have d : Disjoint C S := disjoint_left.mpr (fun _ zc zs =>
    (mem_union.mp zs).elim (fun e => disjoint_left.mp cx zc e)
      (fun e => disjoint_left.mp ab (aC zc) (mem_filter.mp e).1))
  have cl : ∀ w∈C,∀ z∉C,G.Adj w z → z∈S := by
    intro w wc z zc ed
    by_cases za : z∈A
    · have t := mem_union.mp (part ▸ za)
      rcases t with t|t
      · rcases mem_union.mp t with t|t
        · exact (zc t).elim
        · exact (no w wc z t ed).elim
      · exact mem_union.mpr (Or.inl t)
    have zb := closed w (aC wc) z za ed
    exact mem_union.mpr (Or.inr (mem_filter.mpr ⟨zb,w,wc,ed⟩))
  exact (Graffiti189LongestPath.boundary_card_of_connectivity k conn uu vc vs d cl).trans (card_union_le _ _)

/-- Trimmed disjoint hooks use distinct first ports, and only the two
small unmatched boundary sets can miss the opposite-shore neighbour. -/
theorem many_flexible_hooks (k loss : Nat) {a b : V} {p : G.Walk a b} (hp : IsLongest p)
    (A B C E X : Finset V)
    (conn : ∀ D : Finset V,D.card<k → (G.induce ((↑D : Set V)ᶜ)).Connected)
    (part : A=C∪E∪X) (ab : Disjoint A B) (ce : Disjoint C E)
    (cx : Disjoint C X) (ex : Disjoint E X) (cn : C.Nonempty) (en : E.Nonempty)
    (no : ∀ u∈C,∀ v∈E,¬G.Adj u v)
    (closed : ∀ u∈A,∀ v∉A,G.Adj u v → v∈B)
    (ao : ∀ z∈A,z∉p.support) (bk : B.card≤k+loss)
    (F : HookFamily p A k) :
    let flex := (univ : Finset (Fin k)).filter (fun i =>
      (∃ u∈C,G.Adj u (fromFamily F i).firstPort) ∧
        ∃ v∈E,G.Adj v (fromFamily F i).firstPort)
    k≤flex.card+2*loss+2*X.card := by
  classical
  let U := B.filter (fun b => ∃ u∈C,G.Adj u b)
  let V' := B.filter (fun b => ∃ v∈E,G.Adj v b)
  have lbC : k≤X.card+U.card := side_ports_bound k A B C E X conn part ab ce cx ex cn en no closed
  have lbE : k≤X.card+V'.card := side_ports_bound k A B E C X conn
    (part.trans (by rw [union_comm C E])) ab ce.symm ex cx en cn
    (fun v ve u uc ed => no u uc v ve ed.symm) closed
  let miss := (B\U)∪(B\V')
  have cC := card_sdiff_add_card_eq_card (filter_subset (fun b => ∃ u∈C,G.Adj u b) B)
  have cE := card_sdiff_add_card_eq_card (filter_subset (fun b => ∃ v∈E,G.Adj v b) B)
  change (B\U).card+U.card=B.card at cC
  change (B\V').card+V'.card=B.card at cE
  have bound : miss.card≤2*loss+2*X.card := by
    have h : miss.card≤(B\U).card+(B\V').card := card_union_le _ _
    omega
  let f (i : Fin k) := (fromFamily F i).firstPort
  let good (i : Fin k) := (∃ u∈C,G.Adj u (f i))∧(∃ v∈E,G.Adj v (f i))
  let ok := (univ:Finset (Fin k)).filter good
  let bad := (univ:Finset (Fin k))\ok
  have bridge : bad.image f⊆miss := by
    intro v hv
    obtain ⟨i,hi,rfl⟩ := mem_image.mp hv
    have fb : f i∈B := first_port_mem_boundary (fromFamily F i) ao closed
    have noG : ¬good i := fun e => (mem_sdiff.mp hi).2 (mem_filter.mpr ⟨mem_univ _,e⟩)
    by_cases fu : f i∈U
    · exact mem_union.mpr (Or.inr (mem_sdiff.mpr ⟨fb,fun e =>
        noG ⟨(mem_filter.mp fu).2,(mem_filter.mp e).2⟩⟩))
    · exact mem_union.mpr (Or.inl (mem_sdiff.mpr ⟨fb,fu⟩))
  have bb := card_le_card bridge
  have fi : Function.Injective f := family_first_ports_injective hp F
  rw [card_image_of_injective _ fi] at bb
  have add := card_sdiff_add_card_eq_card (subset_univ ok)
  rw [card_univ,Fintype.card_fin] at add
  change bad.card+ok.card=k at add
  change k≤ok.card+2*loss+2*X.card
  omega

#print axioms many_flexible_hooks
end Graffiti189LongestPath.PortReachCount
