import QuadraticDeficitAll189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.GreedyTerminal
open private Graffiti189LongestPath.GreedyTerminal.push_end from QuadraticDeficitAll189
open private Graffiti189LongestPath.FanRoutable.path_append_separated from FanLower189
set_option warningAsError true
set_option maxHeartbeats 4900000
namespace Graffiti189LongestPath.SplitGreedy
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem side_path_from_any_terminal (C L : Finset V) (m : Nat)
    (one : L.card≤1) (high : ∀ v∈C,v∉L → m-1≤(C.filter (G.Adj v)).card)
    (low : ∀ v∈C,v∈L → 1≤(C.filter (G.Adj v)).card)
    (u : V) (uc : u∈C) :
    ∃ v,∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈C) ∧ m-1≤q.length+1 := by
  classical
  by_cases ul : u∈L
  · obtain ⟨v,h⟩ := card_pos.mp (show 0<(C.filter (G.Adj u)).card from low u uc ul)
    obtain ⟨vc,uv⟩ := mem_filter.mp h
    have vl : v∉L := fun r => uv.ne (card_le_one.mp one u ul v r)
    obtain ⟨w,q,qp,qs,ql⟩ := long_path_from_avoiding C L (m-1) v vc vl high
    have un : u∉q.support := fun e => (qs u e).2 ul
    refine ⟨w,.cons uv q,qp.cons un, ?_,?_⟩
    · intro z hz
      rcases List.mem_cons.mp hz with e|e
      · exact e.symm ▸ uc
      · exact (qs _ e).1
    · simp only [length_cons]
      omega
  · obtain ⟨v,q,qp,qs,ql⟩ := long_path_from_avoiding C L (m-1) u uc ul high
    exact ⟨v,q,qp,fun z e => (qs _ e).1,by omega⟩

/-- A route across two shores spends a long path in each and joins
them at the universal root. Connectivity of either induced shore is not
required for the greedy rooted path bound. -/
theorem greedy_cross_shore_route (A C E L : Finset V) (m : Nat)
    (one : L.card≤1) (two : 2≤m)
    (x : V) (xa : x∈A) (xc : x∉C) (xe : x∉E)
    (ca : C⊆A) (ea : E⊆A) (ce : Disjoint C E)
    (root : ∀ z∈A,z≠x → G.Adj x z)
    (highC : ∀ v∈C,v∉L → m-1≤(C.filter (G.Adj v)).card)
    (highE : ∀ v∈E,v∉L → m-1≤(E.filter (G.Adj v)).card)
    (lowC : ∀ v∈C,v∈L → 1≤(C.filter (G.Adj v)).card)
    (lowE : ∀ v∈E,v∈L → 1≤(E.filter (G.Adj v)).card)
    (u : V) (uc : u∈C) (v : V) (ve : v∈E) :
    ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈A) ∧ (m+1)+(m-2)≤q.length+1 := by
  obtain ⟨u',l,lp,ls,ll⟩ := side_path_from_any_terminal C L m one highC lowC u uc
  obtain ⟨v',r,rp,rs,rl⟩ := side_path_from_any_terminal E L m one highE lowE v ve
  have uc' := ls _ l.end_mem_support
  have ve' := rs _ r.end_mem_support
  have xu := root u' (ca uc') (fun e => xc (e ▸ uc'))
  have xv := root v' (ea ve') (fun e => xe (e ▸ ve'))
  obtain ⟨l',lp',ll',ls'⟩ := Graffiti189LongestPath.GreedyTerminal.push_end lp xu.symm (fun h => xc (ls _ h))
  obtain ⟨r',rp',rl',rs'⟩ := Graffiti189LongestPath.GreedyTerminal.push_end rp xv.symm (fun h => xe (rs _ h))
  let w := l'.append r'.reverse
  have wp : w.IsPath := Graffiti189LongestPath.FanRoutable.path_append_separated lp' rp'.reverse (by
    intro z zl zr
    have zr' : z∈r'.support := by simpa only [support_reverse,List.mem_reverse] using zr
    rcases (ls' z).mp zl with zx|zl'
    · exact zx
    rcases (rs' z).mp zr' with zx|zr'
    · exact zx
    exact (disjoint_left.mp ce (ls _ zl') (rs _ zr')).elim)
  have ws (z : V) (zt : z∈w.support) : z∈A := by
    rw [show w=l'.append r'.reverse from rfl,support_append,List.mem_append] at zt
    rcases zt with h|h
    · exact ((ls' z).mp h).elim (fun e => e.symm ▸ xa) (fun h => ca (ls _ h))
    have h' : z∈r'.support := by simpa only [support_reverse,List.mem_reverse] using List.mem_of_mem_tail h
    exact ((rs' z).mp h').elim (fun e => e.symm ▸ xa) (fun h => ea (rs _ h))
  refine ⟨w,wp,ws,?_⟩
  simp only [w,length_append,length_reverse]
  omega

#print axioms side_path_from_any_terminal
#print axioms greedy_cross_shore_route
end Graffiti189LongestPath.SplitGreedy
