#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")" && pwd)"
obj="$(mktemp -d)"
trap 'rm -rf "$obj"' EXIT
export LEAN_PATH="$obj:${LEAN_PATH:-}"
for mod in FlexibleSpacing189 HookRetarget189 GapOne189 SplitGreedy189 FlexibleFan189 PortReachCount189 ShellDonorFull189 FlexibleShellArithmetic189 FlexSplitShell189 FlexibleFinishNumeric189 ThreeFifthsDeficit189; do
  echo "== $mod =="
  lean -j1 -DElab.async=false -DwarningAsError=true --root="$root/modules" -o "$obj/$mod.olean" "$root/modules/$mod.lean"
done
