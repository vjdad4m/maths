import SmallSeparator189
import Mathlib.Data.Finset.Powerset
import Mathlib.Data.Finset.Max
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import QuadraticDeficitAll189
import PosaOneLow189
import FanWeighted189
import MengerRoutable189
import SingleHeight189
import StarCycleClosure189

-- SOURCE ShellDonorCharge189.lean
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open private Graffiti189LongestPath.mem_distanceTwo Graffiti189LongestPath.dist_two
  Graffiti189LongestPath.distance_on_geodesic from SmallSeparator189
set_option warningAsError true
set_option maxHeartbeats 6500000
namespace Graffiti189LongestPath.ShellDonorCharge
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- Third-shell vertices reachable through a nonpin gateway of `u`. -/
noncomputable def gateThird (G : SimpleGraph V) [DecidableRel G.Adj] (x : V) (C : Finset V) (u : V) : Finset V := by
  classical
  exact (Shell G x 3).filter (fun z => ∃ b∈C,G.Adj u b ∧ G.Adj b z)

omit [DecidableEq V] in
theorem mem_gateThird {x u z : V} {C : Finset V} :
    z∈gateThird G x C u ↔ z∈Shell G x 3 ∧ ∃ b∈C,G.Adj u b ∧ G.Adj b z := by
  classical
  simp [gateThird]

omit [Fintype V] [DecidableRel G.Adj] in
/-- A minimum donor set has a distinct private gate for each donor. -/
theorem exists_private_donor_cover (A C : Finset V)
    (initial : ∀ b∈C,∃ a∈A,G.Adj a b) :
    ∃ D⊆A, (∀ b∈C,∃ a∈D,G.Adj a b) ∧
      (∀ a∈D,∃ b∈C,G.Adj a b ∧ ∀ u∈D,u≠a → ¬G.Adj u b) := by
  classical
  let isCover (D : Finset V) : Prop := ∀ b∈C,∃ a∈D,G.Adj a b
  letI decCover : DecidablePred isCover := fun _ => Classical.propDecidable _
  let F := A.powerset.filter isCover
  have fm (D : Finset V) : D∈F ↔ D⊆A ∧ isCover D := by simp [F]
  have ne : F.Nonempty := ⟨A,(fm A).mpr ⟨Subset.rfl,initial⟩⟩
  obtain ⟨D,dm,mn⟩ := exists_min_image F Finset.card ne
  obtain ⟨DA,cover⟩ := (fm D).mp dm
  refine ⟨D,DA,cover,?_⟩
  intro a ad
  apply Classical.byContradiction
  intro no
  have cc (b : V) (bc : b∈C) : ∃ u∈D.erase a,G.Adj u b := by
    obtain ⟨u,ud,edge⟩ := cover b bc
    by_cases ua : u=a
    · subst u
      apply Classical.byContradiction
      intro fail
      apply no
      refine ⟨b,bc,edge,?_⟩
      intro u ud na ed
      exact fail ⟨u,mem_erase.mpr ⟨na,ud⟩,ed⟩
    · exact ⟨u,mem_erase.mpr ⟨ua,ud⟩,edge⟩
  have sm : D.erase a∈F := (fm _).mpr ⟨(erase_subset _ _).trans DA,cc⟩
  have h := mn (D.erase a) sm
  have c := card_erase_add_one ad
  omega

theorem exists_shell_donors_with_extra_charges (hc : G.Connected) (d : Nat)
    (cap : ∀ v,(DistanceTwo G v).card≤d) (x : V) :
    ∃ D⊆G.neighborFinset x, Shell G x 3⊆D.biUnion (gateThird G x (DistanceTwo G x)) ∧
      ∀ v∈D,∀ Z⊆G.neighborFinset x,(∀ u∈Z,u≠v ∧ ¬G.Adj v u) →
        (gateThird G x (DistanceTwo G x) v).card+(D.card-1)+(Z\D).card≤d := by
  classical
  let A := G.neighborFinset x
  let C := DistanceTwo G x
  let H := Shell G x 3
  let pay3 (u : V) := gateThird G x C u
  have getMid (z : V) (dz : G.dist x z=2) : ∃ u∈A,G.Adj u z := by
    obtain ⟨q,ql⟩ := hc.exists_walk_length_eq_dist x z
    have len := ql.trans dz
    let u := q.getVert 1
    have xu : G.Adj x u := by simpa [u] using q.adj_getVert_succ (i:=0) (by omega)
    have uz : G.Adj u z := by
      have e := q.adj_getVert_succ (i:=1) (by omega : 1<q.length)
      rwa [show q.getVert 2=z by rw [←len,getVert_length]] at e
    exact ⟨u,(G.mem_neighborFinset _ _).mpr xu,uz⟩
  have initial (v : V) (vc : v∈C) : ∃ u∈A,G.Adj u v :=
    getMid v (Graffiti189LongestPath.mem_distanceTwo.mp vc)
  have ck : C.card≤d := cap x
  obtain ⟨D,DA,DC,priv⟩ := exists_private_donor_cover A C initial
  have rep₀ (v : V) : ∃ b,v∈D → b∈C ∧ G.Adj v b ∧ ∀ u∈D,u≠v → ¬G.Adj u b := by
    by_cases vd : v∈D
    · obtain ⟨b,bc,e,safe⟩ := priv v vd
      exact ⟨b,fun _ => ⟨bc,e,safe⟩⟩
    · exact ⟨x,fun q => (vd q).elim⟩
  choose rep repP using rep₀
  have repInj : Set.InjOn rep (↑D : Set V) := by
    intro v vd w wd eq
    by_contra ne
    have e : G.Adj v (rep w) := eq ▸ (repP v vd).2.1
    exact (repP w wd).2.2 v vd ne e
  have rc : (D.image rep).card=D.card := card_image_of_injOn repInj
  have rsub : D.image rep⊆C := by
    intro z hz
    obtain ⟨v,vd,rfl⟩ := mem_image.mp hz
    exact (repP v vd).1
  have dm : D.card≤d := (rc ▸ card_le_card rsub).trans ck
  let HD := D.biUnion pay3
  have all : H⊆HD := by
    intro z hz
    have dz := mem_shell.mp hz
    obtain ⟨q,ql⟩ := hc.exists_walk_length_eq_dist x z
    have len := ql.trans dz
    let u := q.getVert 2
    have du : G.dist x u=2 := Graffiti189LongestPath.distance_on_geodesic hc q ql 2 (by omega)
    have uz : G.Adj u z := by
      have e := q.adj_getVert_succ (i:=2) (by omega : 2<q.length)
      rwa [show q.getVert 3=z by rw [←len,getVert_length]] at e
    have uc : u∈C := Graffiti189LongestPath.mem_distanceTwo.mpr du
    obtain ⟨w,wd,wu⟩ := DC u uc
    exact mem_biUnion.mpr ⟨w,wd,mem_gateThird.mpr ⟨hz,u,uc,wu,uz⟩⟩
  have near {u : V} (ua : u∈A) : G.dist x u=1 :=
    dist_eq_one_iff_adj.mpr ((G.mem_neighborFinset _ _).mp ua)
  have noA {u : V} (uc : u∈C) : u∉A := by
    intro ua
    have h := near ua
    have g := Graffiti189LongestPath.mem_distanceTwo.mp uc
    omega
  have third_charge {u : V} (ua : u∈A) : pay3 u⊆DistanceTwo G u := by
    intro z zz
    obtain ⟨zs,b,_,ub,bz⟩ := mem_gateThird.mp zz
    have d₁ := near ua
    have d₃ := mem_shell.mp zs
    have ne : u≠z := by intro e; rw [e] at d₁; omega
    have no : ¬G.Adj u z := by
      intro e
      have d₂ := dist_eq_one_iff_adj.mpr e
      have tr := hc.dist_triangle (u:=x) (v:=u) (w:=z)
      omega
    exact Graffiti189LongestPath.mem_distanceTwo.mpr (Graffiti189LongestPath.dist_two hc ne no ub bz)
  refine ⟨D,DA,all,?_⟩
  intro v vd Z Zs Zag
  change (gateThird G x C v).card+(D.card-1)+(Z\D).card≤d
  let E := D.erase v
  let pay (u : V) := if G.Adj v u then rep u else u
  let W := E.image pay
  have pinj : Set.InjOn pay (↑E : Set V) := by
    intro u uE w wE eq
    have ud := (mem_erase.mp uE).2
    have wd := (mem_erase.mp wE).2
    by_cases vu : G.Adj v u <;> by_cases vw : G.Adj v w
    · exact repInj ud wd (by simpa [pay,vu,vw] using eq)
    · have e : rep u=w := by simpa [pay,vu,vw] using eq
      exact (noA (repP u ud).1 (e.symm ▸ DA wd)).elim
    · have e : u=rep w := by simpa [pay,vu,vw] using eq
      exact (noA (repP w wd).1 (e ▸ DA ud)).elim
    · simpa [pay,vu,vw] using eq
  have wc : W.card=E.card := card_image_of_injOn pinj
  have ec : E.card+1=D.card := card_erase_add_one vd
  have spend : W⊆DistanceTwo G v := by
    intro z hz
    obtain ⟨u,ue,rfl⟩ := mem_image.mp hz
    obtain ⟨uv,ud⟩ := mem_erase.mp ue
    by_cases ad : G.Adj v u
    · have gp := repP u ud
      have no := gp.2.2 v vd uv.symm
      have ne : v≠rep u := fun e => noA gp.1 (e ▸ DA vd)
      have c := Graffiti189LongestPath.mem_distanceTwo.mpr
        (Graffiti189LongestPath.dist_two hc ne no ad gp.2.1)
      simpa [pay,ad] using c
    · have vx := (G.mem_neighborFinset _ _).mp (DA vd)
      have ux := (G.mem_neighborFinset _ _).mp (DA ud)
      have c := Graffiti189LongestPath.mem_distanceTwo.mpr
        (Graffiti189LongestPath.dist_two hc uv.symm ad vx.symm ux)
      simpa [pay,ad] using c
  have dis : Disjoint W (gateThird G x C v) := disjoint_left.mpr (by
    intro z zw zh
    obtain ⟨u,ue,rfl⟩ := mem_image.mp zw
    have ud := (mem_erase.mp ue).2
    have high := mem_shell.mp (mem_gateThird.mp zh).1
    by_cases e : G.Adj v u
    · have dt := Graffiti189LongestPath.mem_distanceTwo.mp (repP u ud).1
      simp only [pay,if_pos e] at high
      omega
    · have l := near (DA ud)
      simp only [pay,if_neg e] at high
      omega)
  let Q := Z\D
  have spendQ : Q⊆DistanceTwo G v := by
    intro u uq
    have uz := (mem_sdiff.mp uq).1
    obtain ⟨ne,no⟩ := Zag u uz
    have vx := (G.mem_neighborFinset _ _).mp (DA vd)
    have ux := (G.mem_neighborFinset _ _).mp (Zs uz)
    exact Graffiti189LongestPath.mem_distanceTwo.mpr
      (Graffiti189LongestPath.dist_two hc ne.symm no vx.symm ux)
  have disWQ : Disjoint W Q := disjoint_left.mpr (by
    intro u uw uq
    have ua := Zs (mem_sdiff.mp uq).1
    obtain ⟨y,ye,rfl⟩ := mem_image.mp uw
    have yd := (mem_erase.mp ye).2
    by_cases ad : G.Adj v y
    · have h : rep y∈A := by
        change pay y∈A at ua
        rwa [show pay y=rep y by simp [pay,ad]] at ua
      exact noA (repP y yd).1 h
    · have h : y∉D := by simpa [pay,ad] using (mem_sdiff.mp uq).2
      exact h yd)
  have disQ : Disjoint Q (gateThird G x C v) := disjoint_left.mpr (by
    intro u uq uh
    have e := near (Zs (mem_sdiff.mp uq).1)
    have h := mem_shell.mp (mem_gateThird.mp uh).1
    omega)
  have disAll : Disjoint (W∪Q) (gateThird G x C v) := disjoint_left.mpr (by
    intro u hu hv
    exact (mem_union.mp hu).elim (fun h => disjoint_left.mp dis h hv)
      (fun h => disjoint_left.mp disQ h hv))
  have c := card_le_card (union_subset (union_subset spend spendQ) (third_charge (DA vd)))
  rw [card_union_of_disjoint disAll,card_union_of_disjoint disWQ] at c
  have cb := cap v
  change (gateThird G x C v).card+(D.card-1)+Q.card≤d
  omega

#print axioms exists_shell_donors_with_extra_charges
end Graffiti189LongestPath.ShellDonorCharge

-- SOURCE SplitShellArithmetic189.lean
set_option warningAsError true
namespace Graffiti189LongestPath.SplitShellArithmetic

/-- Complete squares while keeping the pin term; at the two-thirds
threshold it is absorbed by the negative cross coefficient. -/
theorem split_shell_numeric (k s d a b t H : Nat) (dk : d=k+s)
    (large : 2*s+8≤k) (pins : t≤s)
    (mass : H+a*a+b*b+2*(a+b)*t+t*t≤(a+b)*(k-2)+t*(d+1)+d) :
    2*H≤(k-2)*(k-2)+2*d := by
  let q := k-2
  change H+a*a+b*b+2*(a+b)*t+t*t≤(a+b)*q+t*(d+1)+d at mass
  have coef : 2*(d+1)+2*t≤4*q := by dsimp [q]; omega
  have cof := Nat.mul_le_mul_right t coef
  have castMass : (H:ℤ)+(a:ℤ)*a+(b:ℤ)*b+2*((a:ℤ)+b)*t+(t:ℤ)*t≤
      ((a:ℤ)+b)*q+(t:ℤ)*((d:ℤ)+1)+d := by exact_mod_cast mass
  have castCoef : (2*((d:ℤ)+1)+2*(t:ℤ))*t≤4*(q:ℤ)*t := by exact_mod_cast cof
  have int_bound : 2*(H:ℤ)≤(q:ℤ)*q+2*(d:ℤ) := by
    nlinarith only [castMass,castCoef,sq_nonneg ((a:ℤ)-(b:ℤ)),
      sq_nonneg ((a:ℤ)+b-q+2*(t:ℤ))]
  change 2*H≤q*q+2*d
  exact_mod_cast int_bound

#print axioms split_shell_numeric
end Graffiti189LongestPath.SplitShellArithmetic

-- SOURCE SplitShellCharge189.lean
open Finset SimpleGraph Graffiti189LongestPath
open Graffiti189LongestPath.ShellDonorCharge Graffiti189LongestPath.SplitShellArithmetic
set_option warningAsError true
set_option maxHeartbeats 6500000
namespace Graffiti189LongestPath.SplitShellCharge
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

omit [Fintype V] [DecidableRel G.Adj] in
private theorem count_group (D : Finset V) (F : V→Finset V) (cost bound : Nat)
    (h : ∀ v∈D,(F v).card+cost≤bound) :
    (D.biUnion F).card+D.card*cost≤D.card*bound := by
  classical
  by_cases ne : D.Nonempty
  · obtain ⟨v,vd⟩ := ne
    have hb := h v vd
    have q : cost≤bound := by omega
    have z := card_biUnion_le_card_mul D F (bound-cost) (fun z hz => by have r := h z hz; omega)
    have e : D.card*(bound-cost)+D.card*cost=D.card*bound := by
      rw [←Nat.mul_add,Nat.sub_add_cancel q]
    omega
  have e : D=∅ := not_nonempty_iff_eq_empty.mp ne
  simp [e]

/-- A large nonedge split among the first-shell donors makes the
third-shell cap even smaller. The pin term is absorbed in the quadratic
when k exceeds twice the degree-connectivity deficit. -/
theorem split_shell_three_bound (hc : G.Connected) (k sl : Nat) (large : 2*sl+8≤k)
    (cap : ∀ v,(DistanceTwo G v).card≤k+sl) (x : V)
    (C E P W : Finset V)
    (partition : C∪E∪P∪W=G.neighborFinset x)
    (ce : Disjoint C E) (cp : Disjoint C P) (cw : Disjoint C W)
    (ep : Disjoint E P) (ew : Disjoint E W) (pw : Disjoint P W)
    (nonedge : ∀ u∈C,∀ v∈E,¬G.Adj u v)
    (cs : k-2≤2*C.card) (es : k-2≤2*E.card) (ps : P.card≤sl) (ws : W.card≤1) :
    2*(Shell G x 3).card≤(k-2)*(k-2)+2*(k+sl) := by
  classical
  let d := k+sl
  let q := k-2
  let F := gateThird G x (DistanceTwo G x)
  let H := Shell G x 3
  obtain ⟨D,DA,cover,every⟩ := exists_shell_donors_with_extra_charges hc d cap x
  let C' := D∩C
  let E' := D∩E
  let P' := D∩P
  let W' := D∩W
  let a := C'.card
  let b := E'.card
  let t := P'.card
  let r := W'.card
  have decomp : D=C'∪E'∪P'∪W' := by
    ext v
    constructor
    · intro h
      have vc : v∈C∪E∪P∪W := partition.symm ▸ DA h
      change v∈(D∩C)∪(D∩E)∪(D∩P)∪(D∩W)
      simp only [mem_union,mem_inter] at vc ⊢
      tauto
    · simp only [C',E',P',W',mem_union,mem_inter]
      tauto
  have di {X Y : Finset V} (h : Disjoint X Y) : Disjoint (D∩X) (D∩Y) :=
    disjoint_left.mpr (fun _ hx hy => disjoint_left.mp h (mem_inter.mp hx).2 (mem_inter.mp hy).2)
  have de' : Disjoint (C'∪E') P' := disjoint_union_left.mpr ⟨di cp,di ep⟩
  have dw' : Disjoint (C'∪E'∪P') W' :=
    disjoint_union_left.mpr ⟨disjoint_union_left.mpr ⟨di cw,di ew⟩,di pw⟩
  have dc : D.card=a+b+t+r := by
    have h := congrArg Finset.card decomp
    rw [card_union_of_disjoint dw',card_union_of_disjoint de',card_union_of_disjoint (di ce)] at h
    exact h
  have efix : E.card=b+(E\D).card := by
    have h := card_sdiff_add_card_inter E D
    rw [inter_comm E D] at h
    change (E\D).card+b=E.card at h
    omega
  have cfix : C.card=a+(C\D).card := by
    have h := card_sdiff_add_card_inter C D
    rw [inter_comm C D] at h
    change (C\D).card+a=C.card at h
    omega
  have cN : C⊆G.neighborFinset x := by
    rw [←partition]
    exact fun _ hz => mem_union.mpr (Or.inl (mem_union.mpr (Or.inl (mem_union.mpr (Or.inl hz)))))
  have eN : E⊆G.neighborFinset x := by
    rw [←partition]
    exact fun _ hz => mem_union.mpr (Or.inl (mem_union.mpr (Or.inl (mem_union.mpr (Or.inr hz)))))
  have chargeC : ∀ v∈C',(F v).card+(a+t)≤q := by
    intro v hv
    obtain ⟨vd,vc⟩ := mem_inter.mp hv
    have h := every v vd E eN (fun z ez =>
      ⟨fun e => disjoint_left.mp ce vc (e ▸ ez), nonedge v vc z ez⟩)
    change (F v).card+(D.card-1)+(E\D).card≤d at h
    have dd : 0<D.card := card_pos.mpr ⟨v,vd⟩
    dsimp [q,d]
    omega
  have chargeE : ∀ v∈E',(F v).card+(b+t)≤q := by
    intro v hv
    obtain ⟨vd,ve⟩ := mem_inter.mp hv
    have h := every v vd C cN (fun z zc =>
      ⟨fun e => disjoint_left.mp ce zc (e.symm ▸ ve),fun e => nonedge z zc v ve e.symm⟩)
    change (F v).card+(D.card-1)+(C\D).card≤d at h
    have dd : 0<D.card := card_pos.mpr ⟨v,vd⟩
    dsimp [q,d]
    omega
  have chargeP : ∀ v∈P',(F v).card+(a+b+t)≤d+1 := by
    intro v hv
    have vd := (mem_inter.mp hv).1
    have h := every v vd (∅:Finset V) (empty_subset _) (by simp)
    change (F v).card+(D.card-1)+_≤d at h
    have dd : 0<D.card := card_pos.mpr ⟨v,vd⟩
    omega
  have chargeW : ∀ v∈W',(F v).card≤d := by
    intro v hv
    have h := every v (mem_inter.mp hv).1 (∅:Finset V) (empty_subset _) (by simp)
    change (F v).card+(D.card-1)+_≤d at h
    omega
  let HC := C'.biUnion F
  let HE := E'.biUnion F
  let HP := P'.biUnion F
  let HW := W'.biUnion F
  have hc' : HC.card+a*(a+t)≤a*q := count_group C' F (a+t) q chargeC
  have he' : HE.card+b*(b+t)≤b*q := count_group E' F (b+t) q chargeE
  have hp' : HP.card+t*(a+b+t)≤t*(d+1) := count_group P' F (a+b+t) (d+1) chargeP
  have hw' : HW.card≤r*d := card_biUnion_le_card_mul W' F d chargeW
  have r1 : r≤1 := (card_le_card (inter_subset_right : W'⊆W)).trans ws
  have hW : HW.card≤d := by
    have q := Nat.mul_le_mul_right d r1
    rw [one_mul] at q
    exact hw'.trans q
  have hcvr : H⊆HC∪HE∪HP∪HW := by
    intro z hz
    obtain ⟨v,vd,vz⟩ := mem_biUnion.mp (cover hz)
    have vc : v∈C'∪E'∪P'∪W' := decomp ▸ vd
    simp only [mem_union] at vc
    rcases vc with ((hc|he)|hp)|hw
    · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inl (mem_union.mpr (Or.inl
        (mem_biUnion.mpr ⟨v,hc,vz⟩))))))
    · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inl (mem_union.mpr (Or.inr
        (mem_biUnion.mpr ⟨v,he,vz⟩))))))
    · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inr (mem_biUnion.mpr ⟨v,hp,vz⟩))))
    · exact mem_union.mpr (Or.inr (mem_biUnion.mpr ⟨v,hw,vz⟩))
  have all := card_le_card hcvr
  have cav := card_union_le HC HE
  have pav := card_union_le (HC∪HE) HP
  have wav := card_union_le (HC∪HE∪HP) HW
  have tn : t≤sl := (card_le_card (inter_subset_right : P'⊆P)).trans ps
  have mass : H.card+a*a+b*b+2*(a+b)*t+t*t≤(a+b)*q+t*(d+1)+d := by
    have i₁ : a*(a+t)+b*(b+t)+t*(a+b+t)=a*a+b*b+2*(a+b)*t+t*t := by ring
    have i₂ : a*q+b*q=(a+b)*q := by ring
    omega
  exact split_shell_numeric k sl d a b t H.card rfl large tn mass

#print axioms split_shell_three_bound
end Graffiti189LongestPath.SplitShellCharge

-- SOURCE ShoreSplit189.lean
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.ShoreConnectivity Graffiti189LongestPath.RadialOrder
set_option warningAsError true
set_option maxHeartbeats 5400000
namespace Graffiti189LongestPath.ShoreSplit
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

omit [Fintype V] [DecidableRel G.Adj] in
theorem partition_of_not_connected (S : Finset V) (sn : S.Nonempty)
    (hn : ¬(G.induce (S : Set V)).Connected) :
    ∃ C E : Finset V,C∪E=S ∧ Disjoint C E ∧
      (∀ u∈C,∀ v∈E,¬G.Adj u v) ∧ C.Nonempty ∧ E.Nonempty := by
  apply Classical.byContradiction
  intro no
  apply hn
  refine connected_of_no_partition S sn (fun C E eq d n => ?_)
  by_cases e : C=∅
  · exact Or.inl e
  by_cases e' : E=∅
  · exact Or.inr e'
  exact (no ⟨C,E,eq,d,n,nonempty_iff_ne_empty.mpr e,
    nonempty_iff_ne_empty.mpr e'⟩).elim

/-- A side of the root-deleted shore has at least half the ambient
connectivity, using the induced degree floor for the high vertices. -/
theorem side_order_at_least_half (A C E X : Finset V) (x : V) (d k : Nat)
    (xx : x∈X) (_xa : X⊆A) (xs : X.card≤2)
    (part : C∪E=A\X) (_dis : Disjoint C E) (cn : C.Nonempty)
    (no : ∀ u∈C,∀ v∈E,¬G.Adj u v)
    (deg : ∀ u v : V,u≠v → d≤G.degree u ∨ d≤G.degree v)
    (low : ∀ v : ↥((A.erase x : Finset V) : Set V),
      2≤(G.induce (A.erase x : Set V)).degree v)
    (hi : ∀ v : ↥((A.erase x : Finset V) : Set V),
      d≤G.degree v.val → (k-1)/2≤(G.induce (A.erase x : Set V)).degree v) :
    k-2≤2*C.card := by
  classical
  let Jset := A.erase x
  let J := G.induce (Jset : Set V)
  let W := X.erase x
  have wc : W.card≤1 := by
    have e := card_erase_add_one xx
    change W.card+1=X.card at e
    omega
  have inside {v : V} (vc : v∈C) : v∈Jset := by
    have va : v∈A\X := part ▸ mem_union.mpr (Or.inl vc)
    obtain ⟨vA,vX⟩ := mem_sdiff.mp va
    exact mem_erase.mpr ⟨fun eq => vX (eq.symm ▸ xx),vA⟩
  have upper (v : V) (vc : v∈C) : J.degree ⟨v,inside vc⟩≤C.card := by
    let vv : ↥(Jset : Set V) := ⟨v,inside vc⟩
    have sub : Jset.filter (G.Adj v)⊆C.erase v∪W := by
      intro z hz
      obtain ⟨zj,ed⟩ := mem_filter.mp hz
      obtain ⟨zx,zA⟩ := mem_erase.mp zj
      by_cases zX : z∈X
      · exact mem_union.mpr (Or.inr (mem_erase.mpr ⟨zx,zX⟩))
      have za : z∈C∪E := part.symm ▸ mem_sdiff.mpr ⟨zA,zX⟩
      rcases mem_union.mp za with zc|ze
      · exact mem_union.mpr (Or.inl (mem_erase.mpr ⟨ed.ne.symm,zc⟩))
      · exact (no v vc z ze ed).elim
    have e := (card_le_card sub).trans (card_union_le _ _)
    have n : (Jset.filter (G.Adj v)).card=J.degree vv := induced_degree_count (G:=G) Jset vv
    have cc := card_erase_add_one vc
    change J.degree vv≤C.card
    omega
  obtain ⟨v,vc⟩ := cn
  have cc : 2≤C.card := (low ⟨v,inside vc⟩).trans (upper _ vc)
  obtain ⟨u,uc,w,wc,ne⟩ := one_lt_card.mp (by omega : 1<C.card)
  have h : (k-1)/2≤C.card :=
    (deg u w ne).elim (fun r => (hi ⟨u,inside uc⟩ r).trans (upper _ uc))
      (fun r => (hi ⟨w,inside wc⟩ r).trans (upper _ wc))
  omega

#print axioms partition_of_not_connected
#print axioms side_order_at_least_half
end Graffiti189LongestPath.ShoreSplit

-- SOURCE ExplicitShoreCycle189.lean
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack Graffiti189LongestPath.ActiveStarHeight
open Graffiti189LongestPath.ExactStarShore Graffiti189LongestPath.ShoreConnectivity Graffiti189LongestPath.ShoreDegrees
open Graffiti189LongestPath.ScaledCharge Graffiti189LongestPath.ScaledConnectivity Graffiti189LongestPath.StarCycleClosure
open Graffiti189LongestPath.Normalize Graffiti189LongestPath.PosaOneLow Graffiti189LongestPath.MengerRoutable Graffiti189LongestPath.FanWeighted
open Graffiti189LongestPath.CycleHallSplice Graffiti189LongestPath.UltraOrder Graffiti189LongestPath.SingleHeight
open private Graffiti189LongestPath.Rigidity.mem_external Graffiti189LongestPath.Rigidity.mem_omittedStar from Rigidity189
open private Graffiti189LongestPath.boundary_card_of_connectivity Graffiti189LongestPath.no_endpoints from SmallSeparator189
set_option warningAsError true
set_option linter.unusedVariables false
set_option maxHeartbeats 4500000
namespace Graffiti189LongestPath.ExplicitShoreCycle
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem routes_of_explicit_root_deleted_cycle
    {a b x : V} {p : G.Walk a b} (hx : x∉p.support)
    (sepConn : ∀ S : Finset ↥(((OmittedStar p x).erase x : Finset V) : Set V), S.card<2 →
      ((G.induce (((OmittedStar p x).erase x : Finset V) : Set V)).induce ((↑S : Set _)ᶜ)).Connected)
    (len : Nat)
    (cyc : ∃ z,∃ c : (G.induce (((OmittedStar p x).erase x : Finset V) : Set V)).Walk z z,
      c.IsCycle ∧ max 2 len≤c.length) :
    ∀ u∈OmittedStar p x,∀ v∈OmittedStar p x,u≠v →
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈OmittedStar p x) ∧ len+1≤q.length+1 := by
  classical
  let A := OmittedStar p x
  let Z : Set V := ((A.erase x : Finset V) : Set V)
  let J := G.induce Z
  let f : J →g G := ⟨Subtype.val, fun e => e⟩
  have fi : Function.Injective f := Subtype.val_injective
  have off (z : Z) : x≠f z := fun e => (mem_erase.mp z.property).1 e.symm
  have adj (z : Z) : G.Adj x (f z) := by
    have zz := (mem_erase.mp z.property).2
    exact (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp zz).2.resolve_left (fun ne => off z ne.symm)
  obtain ⟨a,c,hc',cl⟩ := cyc
  have big : 2≤c.support.toFinset.card := by
    rw [cycle_card_support c hc']
    exact (le_max_left _ _).trans cl
  have L : len≤c.length := (le_max_right _ _).trans cl
  have route : ∀ u∈A,∀ v∈A,u≠v →
      ∃ q : G.Walk u v,q.IsPath ∧ (∀ z∈q.support,z∈A) ∧ len+1≤q.length+1 := by
    intro u ua v va uv
    have rA {z : V} (e : z=x ∨ ∃ w : Z,f w=z) : z∈A := by
      rcases e with rfl|⟨w,rfl⟩
      · exact Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
      · exact (mem_erase.mp w.property).2
    by_cases hu : u=x
    · subst u
      let t : Z := ⟨v,mem_erase.mpr ⟨uv.symm,va⟩⟩
      obtain ⟨q,qp,ql,qs⟩ := cycle_to_prescribed_root_route f fi off adj c hc'
        (t:=t) (fun s h => sepConn s (by omega))
      exact ⟨q,qp,fun z hz => rA (qs z hz),by omega⟩
    by_cases hv : v=x
    · subst v
      let t : Z := ⟨u,mem_erase.mpr ⟨hu,ua⟩⟩
      obtain ⟨q,qp,ql,qs⟩ := cycle_to_prescribed_root_route f fi off adj c hc'
        (t:=t) (fun s h => sepConn s (by omega))
      exact ⟨q.reverse,qp.reverse,fun z hz => rA (qs z (by
        simpa only [support_reverse,List.mem_reverse] using hz)),by simpa using (by omega : len+1≤q.length+1)⟩
    let s : Z := ⟨u,mem_erase.mpr ⟨hu,ua⟩⟩
    let t : Z := ⟨v,mem_erase.mpr ⟨hv,va⟩⟩
    have ne : s≠t := fun e => uv (congrArg Subtype.val e)
    obtain ⟨q,qp,ql,qs⟩ := cycle_to_prescribed_route f fi ne off adj c hc' big sepConn
    exact ⟨q,qp,fun z hz => rA (qs z hz),by omega⟩
  exact route

#print axioms routes_of_explicit_root_deleted_cycle
end Graffiti189LongestPath.ExplicitShoreCycle

-- SOURCE TwoThirdsDeficit189.lean
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.Rigidity Graffiti189LongestPath.OneSlack Graffiti189LongestPath.PinRun
open Graffiti189LongestPath.DeficitActive Graffiti189LongestPath.ScaledActive Graffiti189LongestPath.DeficitLongest
open Graffiti189LongestPath.QuadraticShore
open Graffiti189LongestPath.GeneralGapMidpoint Graffiti189LongestPath.Normalize Graffiti189LongestPath.DeficitThirdShell
open Graffiti189LongestPath.StandaloneShellQuadratic Graffiti189LongestPath.RadialOrder
open Graffiti189LongestPath.GreedyTerminal Graffiti189LongestPath.FanWeighted Graffiti189LongestPath.MengerRoutable
open Graffiti189LongestPath.ShoreSplit Graffiti189LongestPath.ExplicitShoreCycle
open Graffiti189LongestPath.SplitShellCharge Graffiti189LongestPath.StarCycleClosure Graffiti189LongestPath.PosaOneLow Graffiti189LongestPath.ActiveStarHeight
open private Graffiti189LongestPath.Rigidity.mem_omittedStar Graffiti189LongestPath.Rigidity.mem_external from Rigidity189
open private Graffiti189LongestPath.pin_data from SmallSeparator189
open private Graffiti189LongestPath.OneSlack.boundary_except_pins_two Graffiti189LongestPath.OneSlack.card_pinVertices
  Graffiti189LongestPath.OneSlack.pin_vertices_subset_boundary Graffiti189LongestPath.OneSlack.first_eq_if_no_pair
  Graffiti189LongestPath.OneSlack.pin_of_neighbor_mem from OneSlack189
set_option warningAsError true
set_option maxHeartbeats 7000000
namespace Graffiti189LongestPath.TwoThirdsDeficit
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- #189 in an explicit quadratic connectivity range, without needing
2-connectivity of the omitted shore.
No normalized attachment or separator geometry is assumed. -/
theorem traceable_of_two_thirds_gap (hc : G.Connected) (k sl : Nat) (large : 2*sl+8≤k) (positive : 1≤sl)
    (cap : ∀ v,(EvenFrom G v).card≤k+sl+1)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → k+sl≤G.degree u ∨ k+sl≤G.degree v) :
    ∃ (u v : V) (q : G.Walk u v),q.IsPath ∧ ∀ z,z∈q.support := by
  classical
  apply Classical.byContradiction
  intro fail
  obtain ⟨a,b,p,hmin⟩ := exists_edgeMinAvoid hc (k+sl) deg
  have hp := hmin.1.1
  have no : ∃ x,x∉p.support := Classical.byContradiction (fun h =>
    fail ⟨a,b,p,hp.1,fun z => Classical.byContradiction (fun e => h ⟨z,e⟩)⟩)
  obtain ⟨x,hx,xh,i,hi⟩ := scaled_deficit_has_high_active hc k sl (by omega) (by omega) cap conn deg hp no
  let d := k+sl
  let A := OmittedStar p x
  let B := External G A
  let P := PinVertices p x
  let C := B\P
  let H := Shell G x 3
  let W := Shell G x 4
  let U := (univ:Finset V)\(A∪B)
  have cap₂ (v : V) : (DistanceTwo G v).card≤d := distanceTwo_le_of_even d v (cap v)
  have pack := high_omitted_pin_budget hc d k cap conn hp hx (Graffiti189LongestPath.pin_data hi).2 xh
  have p3 : (Pins p x).card≤sl := by dsimp [d] at pack; omega
  have w3 : W.card≤sl := by change k+(Pins p x).card+W.card≤d at pack; dsimp [d] at pack; omega
  have rad (z : V) : G.dist x z≤4 := by
    by_contra! far
    have c := shell_card_of_far hc k conn (x:=x) (y:=z) (i:=4) (by decide) (by omega)
    change k≤W.card at c
    omega
  let loss := sl-(Pins p x).card
  have positivePin : 0<(Pins p x).card := card_pos.mpr ⟨i,hi⟩
  have lossSmall : loss+1≤sl := by dsimp [loss]; omega
  have height : k+loss+1≤A.card := by
    have e := star_card_degree_and_pins hp hx
    change A.card+(Pins p x).card=G.degree x+1 at e
    dsimp [loss]
    omega
  have ne : a≠x := fun e => hx (e ▸ p.start_mem_support)
  have enough := enough_vertices_of_degree (k+sl) deg ne
  have none := no_gap_two_at_connectivity_above_pin_twice hc (k+sl) k cap conn
    (by omega) hmin.1 hx xh (by omega)
  have bk : B.card≤k+loss := by
    have f := boundary_flank_count hc hp hx
    rw [flank_count_exact hp hx,Graffiti189LongestPath.OneSlack.first_eq_if_no_pair none] at f
    have c := cap₂ x
    change B.card+((Pins p x).card+(Pins p x).card)≤
      (DistanceTwo G x).card+(Pins p x).card at f
    dsimp [d] at c
    dsimp [loss]
    omega
  have floor (z : V) : 2≤G.degree z := by
    have ne : a≠x := fun e => hx (e ▸ p.start_mem_support)
    have n := enough_vertices_of_degree (k+sl) deg ne
    have kdeg := degree_floor_when_enough_vertices k conn (by omega) z
    omega
  have largeP := longest_length_ge_twice_of_not_traceable hc d (by omega) floor deg fail hp
  have far : k≤U.card := by
    have cover : p.support.toFinset⊆B∪U := by
      intro z hz
      by_cases zb : z∈B
      · exact mem_union.mpr (Or.inl zb)
      have za : z∉A := fun e => (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp e).1 (List.mem_toFinset.mp hz)
      exact mem_union.mpr (Or.inr (mem_sdiff.mpr ⟨mem_univ z,fun e => (mem_union.mp e).elim za zb⟩))
    have h := (card_le_card cover).trans (card_union_le B U)
    rw [List.toFinset_card_of_nodup hp.1.support_nodup,length_support] at h
    dsimp [d] at largeP
    omega
  let T := A.erase x
  let J := G.induce (T:Set V)
  let L := T.filter (fun v => G.degree v<d)
  let m := (k-1)/2
  have xA : x∈A := Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨hx,Or.inl rfl⟩
  have L1 : L.card≤1 := by
    apply Nat.le_of_not_gt
    intro e
    obtain ⟨u,uu,v,vv,ne⟩ := one_lt_card.mp (show 1<L.card from e)
    have e₁ := (mem_filter.mp uu).2
    have e₂ := (mem_filter.mp vv).2
    exact (deg u v ne).elim (Nat.not_le_of_lt e₁) (Nat.not_le_of_lt e₂)
  have highJ (v : V) (vt : v∈T) (vl : v∉L) : m≤(T.filter (G.Adj v)).card := by
    let v' : ↥(T:Set V) := ⟨v,vt⟩
    have vh : d≤G.degree v := Nat.le_of_not_gt (fun h => vl (mem_filter.mpr ⟨vt,h⟩))
    have b := (quadratic_root_deleted_degrees hc k sl loss cap conn hp hx bk far v').2 vh
    change A.card≤2*J.degree v'+loss+3 at b
    have id := induced_degree_count (G:=G) T v'
    change (T.filter (G.Adj v)).card=J.degree v' at id
    dsimp [m]
    omega
  have floorJ (v : ↥(T:Set V)) : 2≤J.degree v := by
    have b := (quadratic_root_deleted_degrees hc k sl loss cap conn hp hx bk far v).1
    change A.card≤2*J.degree v+sl+loss+3 at b
    omega
  have lowJ (v : V) (vt : v∈T) (_vl : v∈L) : 1≤(T.filter (G.Adj v)).card := by
    let v' : ↥(T:Set V) := ⟨v,vt⟩
    have b := floorJ v'
    have id := induced_degree_count (G:=G) T v'
    change (T.filter (G.Adj v)).card=J.degree v' at id
    omega
  have highDegree (v : ↥(T:Set V)) (vh : d≤G.degree v.val) : m≤J.degree v := by
    have u := highJ v.val v.property (fun e => (Nat.not_lt_of_ge vh) (mem_filter.mp e).2)
    have eq := induced_degree_count (G:=G) T v
    change (T.filter (G.Adj v.val)).card=J.degree v at eq
    omega
  have root (v : V) (va : v∈A) (ne : v≠x) : G.Adj x v :=
    ((Graffiti189LongestPath.Rigidity.mem_omittedStar.mp va).2).resolve_left ne
  have routes := one_low_universal_uniform_routes A L x xA root L1 m highJ lowJ
  have ao : ∀ v∈A,v∉p.support := fun _ va =>
    (Graffiti189LongestPath.Rigidity.mem_omittedStar.mp va).1
  obtain ⟨F⟩ := hooks_of_small_deletion_connectivity A k hp ao (by omega) (support_large k conn hp hx) conn
  have bound := weighted_hooked_lower k (by omega) hp (m+1) A ao (by omega) routes F
  have low : A.card+k+(k+1)*(m+1)≤Fintype.card V := by omega
  have order := order_le_radius_four_layers hc x rad
  change Fintype.card V≤G.degree x+1+(DistanceTwo G x).card+H.card+W.card at order
  have base : Fintype.card V≤A.card+k+2*sl+H.card := by
    have d₂ := cap₂ x
    have degX := star_card_degree_and_pins hp hx
    change A.card+(Pins p x).card=G.degree x+1 at degX
    change k+(Pins p x).card+W.card≤d at pack
    dsimp [d] at d₂ pack
    omega
  by_cases robust : ∀ S : Finset ↥(T:Set V), S.card<2 →
      (J.induce ((↑S:Set _)ᶜ)).Connected
  · have vc : Fintype.card ↥(T:Set V)=A.card-1 := by
      change Fintype.card ↥T=A.card-1
      exact (Fintype.card_coe T).trans (card_erase_of_mem xA)
    have md : 2≤m := by dsimp [m]; omega
    have pair (u v : ↥(T:Set V)) (ne : u≠v) : m≤J.degree u ∨ m≤J.degree v :=
      (deg u.val v.val (fun e => ne (Subtype.ext e))).imp (highDegree u) (highDegree v)
    obtain ⟨r,c,cc,cl⟩ := proved_one_low_circumference _ J m md (by omega) robust floorJ pair
    have lim : k-2≤c.length := by
      have bm : 2*m≤A.card-1 := by dsimp [m]; omega
      have bm' : 2*m≤Fintype.card ↥(T:Set V) := by rw [vc]; exact bm
      rw [min_eq_right bm'] at cl
      dsimp [m] at cl
      omega
    have routesLong := routes_of_explicit_root_deleted_cycle hx robust (k-2)
      ⟨r,c,cc,by omega⟩
    have lowLong := weighted_hooked_lower k (by omega) hp (k-2+1) A ao (by omega) routesLong F
    have lowLong' : A.card+k+(k+1)*(k-1)≤Fintype.card V := by
      rw [show k-2+1=k-1 by omega] at lowLong
      omega
    have shell := universal_shell_three_quadratic hc d cap₂ x
    change 4*H.card≤(d+1)*(d+1) at shell
    have small : (d+1)*(d+1)+8*sl<4*((k+1)*(k-1)) := by
      have v : d+1≤2*k-4 := by dsimp [d]; omega
      have sq := Nat.mul_le_mul v v
      have eq : (2*k-4)*(2*k-4)+16*k=4*(k*k)+16 := by
        let t := k-2
        have kt : k=t+2 := by dsimp [t]; omega
        rw [show 2*k-4=2*t by dsimp [t]; omega]
        rw [kt]
        ring
      have ev : (k+1)*(k-1)+1=k*k := by
        let t := k-1
        have kt : k=t+1 := by dsimp [t]; omega
        rw [show k-1=t from rfl,kt]
        ring
      omega
    have um : 4*Fintype.card V<4*(A.card+k+(k+1)*(k-1)) := by
      calc
        _ ≤ 4*(A.card+k+2*sl+H.card) := Nat.mul_le_mul_left 4 base
        _ = 4*(A.card+k)+(4*H.card+8*sl) := by ring
        _ ≤ 4*(A.card+k)+((d+1)*(d+1)+8*sl) :=
          Nat.add_le_add_left (Nat.add_le_add_right shell _) _
        _ < 4*(A.card+k)+4*((k+1)*(k-1)) := Nat.add_lt_add_left small _
        _ = _ := by ring
    omega
  obtain ⟨S,sm,failS⟩ : ∃ S : Finset ↥(T:Set V),S.card<2 ∧ ¬(J.induce ((↑S:Set _)ᶜ)).Connected := by
    apply Classical.byContradiction
    intro neg
    apply robust
    intro S sm
    exact Classical.byContradiction (fun bad => neg ⟨S,sm,bad⟩)
  let emb : ↥(T:Set V) ↪ V := ⟨Subtype.val,Subtype.val_injective⟩
  let X := insert x (S.map emb)
  have xx : x∈X := mem_insert_self _ _
  have xsub : X⊆A := by
    intro z zz
    rcases mem_insert.mp zz with rfl|zz
    · exact xA
    · obtain ⟨v,_,rfl⟩ := mem_map.mp zz
      exact (mem_erase.mp v.property).2
  have xs : X.card≤2 := by
    have h := card_insert_le x (S.map emb)
    rw [card_map] at h
    change X.card≤S.card+1 at h
    omega
  have iso := erase_root_and_set_iso (G:=G) A x S
  have bad : ¬(G.induce (↑(A\X):Set V)).Connected := fun h => failS (iso.connected_iff.mp h)
  have nAX : (A\X).Nonempty := card_pos.mp (by
    have e := card_sdiff_add_card_eq_card xsub
    omega)
  obtain ⟨C,E,part,ce,no,cn,en⟩ := partition_of_not_connected (A\X) nAX bad
  have lc := side_order_at_least_half A C E X x d k xx xsub xs part ce cn no deg floorJ highDegree
  have le := side_order_at_least_half A E C X x d k xx xsub xs
    ((union_comm E C).trans part) ce.symm en (fun u ue v vc adj => no v vc u ue adj.symm)
    deg floorJ highDegree
  let P := PinVertices p x
  let W' := X.erase x
  have ec : C⊆A\X := fun _ h => part ▸ mem_union.mpr (Or.inl h)
  have ee : E⊆A\X := fun _ h => part ▸ mem_union.mpr (Or.inr h)
  have pinOff : Disjoint A P := disjoint_left.mpr (by
    intro z za zp
    obtain ⟨i,_,rfl⟩ := mem_image.mp zp
    exact ao _ za (p.getVert_mem_support i))
  have cp : Disjoint C P := disjoint_left.mpr (fun _ h h' => disjoint_left.mp pinOff (mem_sdiff.mp (ec h)).1 h')
  have ep : Disjoint E P := disjoint_left.mpr (fun _ h h' => disjoint_left.mp pinOff (mem_sdiff.mp (ee h)).1 h')
  have cw : Disjoint C W' := disjoint_left.mpr (fun _ h h' => (mem_sdiff.mp (ec h)).2 (mem_erase.mp h').2)
  have ew : Disjoint E W' := disjoint_left.mpr (fun _ h h' => (mem_sdiff.mp (ee h)).2 (mem_erase.mp h').2)
  have pw : Disjoint P W' := disjoint_left.mpr (fun _ h h' => disjoint_left.mp pinOff (xsub (mem_erase.mp h').2) h)
  have pp : P.card≤sl := by
    have h := Graffiti189LongestPath.OneSlack.card_pinVertices hp (x:=x)
    change P.card=(Pins p x).card at h
    omega
  have wc : W'.card≤1 := by
    have h := card_erase_add_one xx
    change W'.card+1=X.card at h
    omega
  have nbh : G.neighborFinset x=T∪P := by
    ext z
    rw [G.mem_neighborFinset,mem_union]
    constructor
    · intro adj
      by_cases zp : z∈p.support
      · obtain ⟨j,jp,e⟩ := Graffiti189LongestPath.OneSlack.pin_of_neighbor_mem hp hx zp adj
        exact Or.inr (mem_image.mpr ⟨j,jp,e⟩)
      exact Or.inl (mem_erase.mpr ⟨adj.ne.symm,
        Graffiti189LongestPath.Rigidity.mem_omittedStar.mpr ⟨zp,Or.inr adj⟩⟩)
    · rintro (zt|zp)
      · exact root z (mem_erase.mp zt).2 (mem_erase.mp zt).1
      · obtain ⟨j,jp,rfl⟩ := mem_image.mp zp
        exact (Graffiti189LongestPath.pin_data jp).2
  have rest : (C∪E)∪W'=T := by
    rw [part]
    ext z
    simp only [mem_union,mem_sdiff,mem_erase,T,W']
    constructor
    · intro h
      rcases h with ⟨za,zx⟩|⟨zx,ze⟩
      · exact ⟨fun e => zx (e.symm ▸ xx),za⟩
      · exact ⟨zx,xsub ze⟩
    · rintro ⟨zx,za⟩
      by_cases zX : z∈X
      · exact Or.inr ⟨zx,zX⟩
      · exact Or.inl ⟨za,zX⟩
  have partition : C∪E∪P∪W'=G.neighborFinset x := by
    rw [nbh,←rest]
    ac_rfl
  have shell := split_shell_three_bound hc k sl large cap₂ x C E P W' partition ce cp cw ep ew pw no lc le pp wc
  change 2*H.card≤(k-2)*(k-2)+2*d at shell
  have small : (k-2)*(k-2)+2*d+4*sl<k*(k+1) := by
    have e : (k-2)*(k-2)+4*k=k*k+4 := by
      let t := k-2
      have kt : k=t+2 := by dsimp [t]; omega
      rw [show k-2=t from rfl,kt]
      ring
    have q : k*(k+1)=k*k+k := by ring
    dsimp [d]
    omega
  have twice : k*(k+1)≤2*((k+1)*(m+1)) := by
    have h : k≤2*(m+1) := by dsimp [m]; omega
    calc
      _ = (k+1)*k := by ring
      _ ≤ (k+1)*(2*(m+1)) := Nat.mul_le_mul_left _ h
      _ = _ := by ring
  have um : 2*Fintype.card V<2*(A.card+k+(k+1)*(m+1)) := by
    calc
      _ ≤ 2*(A.card+k+2*sl+H.card) := Nat.mul_le_mul_left 2 base
      _ = 2*(A.card+k)+(2*H.card+4*sl) := by ring
      _ ≤ 2*(A.card+k)+((k-2)*(k-2)+2*d+4*sl) :=
        Nat.add_le_add_left (Nat.add_le_add_right shell _) _
      _ < 2*(A.card+k)+k*(k+1) := Nat.add_lt_add_left small _
      _ ≤ 2*(A.card+k)+2*((k+1)*(m+1)) := Nat.add_le_add_left twice _
      _ = _ := by ring
  omega

/-- At least two-thirds connectivity, up to the additive constant. -/
theorem traceable_of_two_thirds_connectivity (hc : G.Connected) (d k : Nat)
    (ratio : 2*d+8≤3*k)
    (cap : ∀ v,(EvenFrom G v).card≤d+1)
    (conn : ∀ S : Finset V,S.card<k → (G.induce ((↑S : Set V)ᶜ)).Connected)
    (deg : ∀ u v : V,u≠v → d≤G.degree u ∨ d≤G.degree v) :
    ∃ (u v : V) (q : G.Walk u v),q.IsPath ∧ ∀ z,z∈q.support := by
  by_cases hk : d≤k
  · exact traceable_of_even_and_connectivity hc d cap (fun S sc => conn S (sc.trans_le hk))
  have eq : k+(d-k)=d := by omega
  exact traceable_of_two_thirds_gap hc k (d-k) (by omega) (by omega)
    (by simpa only [eq] using cap) conn (by simpa only [eq] using deg)

#print axioms traceable_of_two_thirds_gap
#print axioms traceable_of_two_thirds_connectivity
end Graffiti189LongestPath.TwoThirdsDeficit
