import QuadraticDeficitAll189
open Finset SimpleGraph SimpleGraph.Walk Graffiti189LongestPath
open Graffiti189LongestPath.ShoreConnectivity Graffiti189LongestPath.RadialOrder
set_option warningAsError true
set_option maxHeartbeats 5400000
namespace Graffiti189LongestPath.ShoreSplit
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

omit [Fintype V] [DecidableRel G.Adj] in
theorem partition_of_not_connected (S : Finset V) (sn : S.Nonempty)
    (hn : ¬(G.induce (S : Set V)).Connected) :
    ∃ C E : Finset V,C∪E=S ∧ Disjoint C E ∧
      (∀ u∈C,∀ v∈E,¬G.Adj u v) ∧ C.Nonempty ∧ E.Nonempty := by
  apply Classical.byContradiction
  intro no
  apply hn
  refine connected_of_no_partition S sn (fun C E eq d n => ?_)
  by_cases e : C=∅
  · exact Or.inl e
  by_cases e' : E=∅
  · exact Or.inr e'
  exact (no ⟨C,E,eq,d,n,nonempty_iff_ne_empty.mpr e,
    nonempty_iff_ne_empty.mpr e'⟩).elim

/-- A side of the root-deleted shore has at least half the ambient
connectivity, using the induced degree floor for the high vertices. -/
theorem side_order_at_least_half (A C E X : Finset V) (x : V) (d k : Nat)
    (xx : x∈X) (_xa : X⊆A) (xs : X.card≤2)
    (part : C∪E=A\X) (_dis : Disjoint C E) (cn : C.Nonempty)
    (no : ∀ u∈C,∀ v∈E,¬G.Adj u v)
    (deg : ∀ u v : V,u≠v → d≤G.degree u ∨ d≤G.degree v)
    (low : ∀ v : ↥((A.erase x : Finset V) : Set V),
      2≤(G.induce (A.erase x : Set V)).degree v)
    (hi : ∀ v : ↥((A.erase x : Finset V) : Set V),
      d≤G.degree v.val → (k-1)/2≤(G.induce (A.erase x : Set V)).degree v) :
    k-2≤2*C.card := by
  classical
  let Jset := A.erase x
  let J := G.induce (Jset : Set V)
  let W := X.erase x
  have wc : W.card≤1 := by
    have e := card_erase_add_one xx
    change W.card+1=X.card at e
    omega
  have inside {v : V} (vc : v∈C) : v∈Jset := by
    have va : v∈A\X := part ▸ mem_union.mpr (Or.inl vc)
    obtain ⟨vA,vX⟩ := mem_sdiff.mp va
    exact mem_erase.mpr ⟨fun eq => vX (eq.symm ▸ xx),vA⟩
  have upper (v : V) (vc : v∈C) : J.degree ⟨v,inside vc⟩≤C.card := by
    let vv : ↥(Jset : Set V) := ⟨v,inside vc⟩
    have sub : Jset.filter (G.Adj v)⊆C.erase v∪W := by
      intro z hz
      obtain ⟨zj,ed⟩ := mem_filter.mp hz
      obtain ⟨zx,zA⟩ := mem_erase.mp zj
      by_cases zX : z∈X
      · exact mem_union.mpr (Or.inr (mem_erase.mpr ⟨zx,zX⟩))
      have za : z∈C∪E := part.symm ▸ mem_sdiff.mpr ⟨zA,zX⟩
      rcases mem_union.mp za with zc|ze
      · exact mem_union.mpr (Or.inl (mem_erase.mpr ⟨ed.ne.symm,zc⟩))
      · exact (no v vc z ze ed).elim
    have e := (card_le_card sub).trans (card_union_le _ _)
    have n : (Jset.filter (G.Adj v)).card=J.degree vv := induced_degree_count (G:=G) Jset vv
    have cc := card_erase_add_one vc
    change J.degree vv≤C.card
    omega
  obtain ⟨v,vc⟩ := cn
  have cc : 2≤C.card := (low ⟨v,inside vc⟩).trans (upper _ vc)
  obtain ⟨u,uc,w,wc,ne⟩ := one_lt_card.mp (by omega : 1<C.card)
  have h : (k-1)/2≤C.card :=
    (deg u w ne).elim (fun r => (hi ⟨u,inside uc⟩ r).trans (upper _ uc))
      (fun r => (hi ⟨w,inside wc⟩ r).trans (upper _ wc))
  omega

#print axioms partition_of_not_connected
#print axioms side_order_at_least_half
end Graffiti189LongestPath.ShoreSplit
