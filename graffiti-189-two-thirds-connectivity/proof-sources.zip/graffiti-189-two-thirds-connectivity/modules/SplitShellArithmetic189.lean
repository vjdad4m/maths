import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
set_option warningAsError true
namespace Graffiti189LongestPath.SplitShellArithmetic

/-- Complete squares while keeping the pin term; at the two-thirds
threshold it is absorbed by the negative cross coefficient. -/
theorem split_shell_numeric (k s d a b t H : Nat) (dk : d=k+s)
    (large : 2*s+8≤k) (pins : t≤s)
    (mass : H+a*a+b*b+2*(a+b)*t+t*t≤(a+b)*(k-2)+t*(d+1)+d) :
    2*H≤(k-2)*(k-2)+2*d := by
  let q := k-2
  change H+a*a+b*b+2*(a+b)*t+t*t≤(a+b)*q+t*(d+1)+d at mass
  have coef : 2*(d+1)+2*t≤4*q := by dsimp [q]; omega
  have cof := Nat.mul_le_mul_right t coef
  have castMass : (H:ℤ)+(a:ℤ)*a+(b:ℤ)*b+2*((a:ℤ)+b)*t+(t:ℤ)*t≤
      ((a:ℤ)+b)*q+(t:ℤ)*((d:ℤ)+1)+d := by exact_mod_cast mass
  have castCoef : (2*((d:ℤ)+1)+2*(t:ℤ))*t≤4*(q:ℤ)*t := by exact_mod_cast cof
  have int_bound : 2*(H:ℤ)≤(q:ℤ)*q+2*(d:ℤ) := by
    nlinarith only [castMass,castCoef,sq_nonneg ((a:ℤ)-(b:ℤ)),
      sq_nonneg ((a:ℤ)+b-q+2*(t:ℤ))]
  change 2*H≤q*q+2*d
  exact_mod_cast int_bound

#print axioms split_shell_numeric
end Graffiti189LongestPath.SplitShellArithmetic
