import ShellDonorCharge189
import SplitShellArithmetic189
open Finset SimpleGraph Graffiti189LongestPath
open Graffiti189LongestPath.ShellDonorCharge Graffiti189LongestPath.SplitShellArithmetic
set_option warningAsError true
set_option maxHeartbeats 6500000
namespace Graffiti189LongestPath.SplitShellCharge
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

omit [Fintype V] [DecidableRel G.Adj] in
private theorem count_group (D : Finset V) (F : V→Finset V) (cost bound : Nat)
    (h : ∀ v∈D,(F v).card+cost≤bound) :
    (D.biUnion F).card+D.card*cost≤D.card*bound := by
  classical
  by_cases ne : D.Nonempty
  · obtain ⟨v,vd⟩ := ne
    have hb := h v vd
    have q : cost≤bound := by omega
    have z := card_biUnion_le_card_mul D F (bound-cost) (fun z hz => by have r := h z hz; omega)
    have e : D.card*(bound-cost)+D.card*cost=D.card*bound := by
      rw [←Nat.mul_add,Nat.sub_add_cancel q]
    omega
  have e : D=∅ := not_nonempty_iff_eq_empty.mp ne
  simp [e]

/-- A large nonedge split among the first-shell donors makes the
third-shell cap even smaller. The pin term is absorbed in the quadratic
when k exceeds twice the degree-connectivity deficit. -/
theorem split_shell_three_bound (hc : G.Connected) (k sl : Nat) (large : 2*sl+8≤k)
    (cap : ∀ v,(DistanceTwo G v).card≤k+sl) (x : V)
    (C E P W : Finset V)
    (partition : C∪E∪P∪W=G.neighborFinset x)
    (ce : Disjoint C E) (cp : Disjoint C P) (cw : Disjoint C W)
    (ep : Disjoint E P) (ew : Disjoint E W) (pw : Disjoint P W)
    (nonedge : ∀ u∈C,∀ v∈E,¬G.Adj u v)
    (cs : k-2≤2*C.card) (es : k-2≤2*E.card) (ps : P.card≤sl) (ws : W.card≤1) :
    2*(Shell G x 3).card≤(k-2)*(k-2)+2*(k+sl) := by
  classical
  let d := k+sl
  let q := k-2
  let F := gateThird G x (DistanceTwo G x)
  let H := Shell G x 3
  obtain ⟨D,DA,cover,every⟩ := exists_shell_donors_with_extra_charges hc d cap x
  let C' := D∩C
  let E' := D∩E
  let P' := D∩P
  let W' := D∩W
  let a := C'.card
  let b := E'.card
  let t := P'.card
  let r := W'.card
  have decomp : D=C'∪E'∪P'∪W' := by
    ext v
    constructor
    · intro h
      have vc : v∈C∪E∪P∪W := partition.symm ▸ DA h
      change v∈(D∩C)∪(D∩E)∪(D∩P)∪(D∩W)
      simp only [mem_union,mem_inter] at vc ⊢
      tauto
    · simp only [C',E',P',W',mem_union,mem_inter]
      tauto
  have di {X Y : Finset V} (h : Disjoint X Y) : Disjoint (D∩X) (D∩Y) :=
    disjoint_left.mpr (fun _ hx hy => disjoint_left.mp h (mem_inter.mp hx).2 (mem_inter.mp hy).2)
  have de' : Disjoint (C'∪E') P' := disjoint_union_left.mpr ⟨di cp,di ep⟩
  have dw' : Disjoint (C'∪E'∪P') W' :=
    disjoint_union_left.mpr ⟨disjoint_union_left.mpr ⟨di cw,di ew⟩,di pw⟩
  have dc : D.card=a+b+t+r := by
    have h := congrArg Finset.card decomp
    rw [card_union_of_disjoint dw',card_union_of_disjoint de',card_union_of_disjoint (di ce)] at h
    exact h
  have efix : E.card=b+(E\D).card := by
    have h := card_sdiff_add_card_inter E D
    rw [inter_comm E D] at h
    change (E\D).card+b=E.card at h
    omega
  have cfix : C.card=a+(C\D).card := by
    have h := card_sdiff_add_card_inter C D
    rw [inter_comm C D] at h
    change (C\D).card+a=C.card at h
    omega
  have cN : C⊆G.neighborFinset x := by
    rw [←partition]
    exact fun _ hz => mem_union.mpr (Or.inl (mem_union.mpr (Or.inl (mem_union.mpr (Or.inl hz)))))
  have eN : E⊆G.neighborFinset x := by
    rw [←partition]
    exact fun _ hz => mem_union.mpr (Or.inl (mem_union.mpr (Or.inl (mem_union.mpr (Or.inr hz)))))
  have chargeC : ∀ v∈C',(F v).card+(a+t)≤q := by
    intro v hv
    obtain ⟨vd,vc⟩ := mem_inter.mp hv
    have h := every v vd E eN (fun z ez =>
      ⟨fun e => disjoint_left.mp ce vc (e ▸ ez), nonedge v vc z ez⟩)
    change (F v).card+(D.card-1)+(E\D).card≤d at h
    have dd : 0<D.card := card_pos.mpr ⟨v,vd⟩
    dsimp [q,d]
    omega
  have chargeE : ∀ v∈E',(F v).card+(b+t)≤q := by
    intro v hv
    obtain ⟨vd,ve⟩ := mem_inter.mp hv
    have h := every v vd C cN (fun z zc =>
      ⟨fun e => disjoint_left.mp ce zc (e.symm ▸ ve),fun e => nonedge z zc v ve e.symm⟩)
    change (F v).card+(D.card-1)+(C\D).card≤d at h
    have dd : 0<D.card := card_pos.mpr ⟨v,vd⟩
    dsimp [q,d]
    omega
  have chargeP : ∀ v∈P',(F v).card+(a+b+t)≤d+1 := by
    intro v hv
    have vd := (mem_inter.mp hv).1
    have h := every v vd (∅:Finset V) (empty_subset _) (by simp)
    change (F v).card+(D.card-1)+_≤d at h
    have dd : 0<D.card := card_pos.mpr ⟨v,vd⟩
    omega
  have chargeW : ∀ v∈W',(F v).card≤d := by
    intro v hv
    have h := every v (mem_inter.mp hv).1 (∅:Finset V) (empty_subset _) (by simp)
    change (F v).card+(D.card-1)+_≤d at h
    omega
  let HC := C'.biUnion F
  let HE := E'.biUnion F
  let HP := P'.biUnion F
  let HW := W'.biUnion F
  have hc' : HC.card+a*(a+t)≤a*q := count_group C' F (a+t) q chargeC
  have he' : HE.card+b*(b+t)≤b*q := count_group E' F (b+t) q chargeE
  have hp' : HP.card+t*(a+b+t)≤t*(d+1) := count_group P' F (a+b+t) (d+1) chargeP
  have hw' : HW.card≤r*d := card_biUnion_le_card_mul W' F d chargeW
  have r1 : r≤1 := (card_le_card (inter_subset_right : W'⊆W)).trans ws
  have hW : HW.card≤d := by
    have q := Nat.mul_le_mul_right d r1
    rw [one_mul] at q
    exact hw'.trans q
  have hcvr : H⊆HC∪HE∪HP∪HW := by
    intro z hz
    obtain ⟨v,vd,vz⟩ := mem_biUnion.mp (cover hz)
    have vc : v∈C'∪E'∪P'∪W' := decomp ▸ vd
    simp only [mem_union] at vc
    rcases vc with ((hc|he)|hp)|hw
    · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inl (mem_union.mpr (Or.inl
        (mem_biUnion.mpr ⟨v,hc,vz⟩))))))
    · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inl (mem_union.mpr (Or.inr
        (mem_biUnion.mpr ⟨v,he,vz⟩))))))
    · exact mem_union.mpr (Or.inl (mem_union.mpr (Or.inr (mem_biUnion.mpr ⟨v,hp,vz⟩))))
    · exact mem_union.mpr (Or.inr (mem_biUnion.mpr ⟨v,hw,vz⟩))
  have all := card_le_card hcvr
  have cav := card_union_le HC HE
  have pav := card_union_le (HC∪HE) HP
  have wav := card_union_le (HC∪HE∪HP) HW
  have tn : t≤sl := (card_le_card (inter_subset_right : P'⊆P)).trans ps
  have mass : H.card+a*a+b*b+2*(a+b)*t+t*t≤(a+b)*q+t*(d+1)+d := by
    have i₁ : a*(a+t)+b*(b+t)+t*(a+b+t)=a*a+b*b+2*(a+b)*t+t*t := by ring
    have i₂ : a*q+b*q=(a+b)*q := by ring
    omega
  exact split_shell_numeric k sl d a b t H.card rfl large tn mass

#print axioms split_shell_three_bound
end Graffiti189LongestPath.SplitShellCharge
