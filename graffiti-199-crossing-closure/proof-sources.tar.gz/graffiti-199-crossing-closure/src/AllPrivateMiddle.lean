import PrivateMiddle

open private triple_of_card_bound from OppositeComplete

namespace Graffiti199Depleted.Catalogue
open SimpleGraph

variable {V : Type*} {G : SimpleGraph V} [Fintype V] {X : Set V} {r p q : V}

/-- Build the middle interval from all the actual nonprivate components
and the unused neighbors of the port. -/
theorem private_middle_from_all_nonprivate (none : NoRootedFour G X r) (rOff : r ∉ X)
    (c d : (G.induce (Noncontacts G X r)).ConnectedComponent)
    (pc : p ∈ rootedBlockContacts G X r c) (qd : q ∈ rootedBlockContacts G X r d)
    (many : ∀ i : (G.induce (Noncontacts G X r)).ConnectedComponent, i ≠ c → i ≠ d →
      ∃ x ∈ rootedBlockContacts G X r i, ∃ y ∈ rootedBlockContacts G X r i, x ≠ y) :
    ∃ s ∈ insert r {v | v ∈ shoreContacts G X r ∧ v ≠ p ∧ v ≠ q},
      ∃ t ∈ insert r {v | v ∈ shoreContacts G X r ∧ v ≠ p ∧ v ≠ q},
      Traverses G (insert r {v | v ∈ X ∧ v ∉ noncontactComponent G X r c ∧
        v ∉ noncontactComponent G X r d ∧ v ≠ p ∧ v ≠ q}) s t := by
  classical
  let I := (G.induce (Noncontacts G X r)).ConnectedComponent
  letI : Finite I := Quot.finite _
  letI : Fintype I := Fintype.ofFinite I
  let T : Finset I := Finset.univ.filter fun i => i ≠ c ∧ i ≠ d
  let Q (i : I) := rootedBlockContacts G X r i
  let C (i : I) := noncontactComponent G X r i
  let B (i : I) := Q i ∪ C i
  let P₀ : Set V := {x | x ∈ shoreContacts G X r ∧ x ≠ p ∧ x ≠ q ∧ ∀ i ∈ T, x ∉ Q i}
  let Z : Set V := insert r P₀
  have rem (i : I) : i ∈ T ↔ i ≠ c ∧ i ≠ d := by simp [T]
  have subQ {i : I} {x : V} (h : x ∈ Q i) : x ∈ shoreContacts G X r := ⟨h.1,h.2.1⟩
  have subC {i : I} {x : V} (h : x ∈ C i) : x ∈ Noncontacts G X r :=
    noncontactComponent_subset i h
  have QQ {i j : I} (h : i ≠ j) : Disjoint (Q i) (Q j) :=
    none.blockContacts_disjoint rOff h
  have CC {i j : I} (h : i ≠ j) : Disjoint (C i) (C j) := noncontactComponents_apart h
  have QC (i j : I) : Disjoint (Q i) (C j) :=
    Set.disjoint_left.mpr fun _ u v => (subC v).2 (subQ u).2
  have apart (i j : I) (ij : i ≠ j) : Disjoint (B i) (B j) := by
    simp only [B,Set.disjoint_union_left,Set.disjoint_union_right]
    exact ⟨⟨QQ ij,(QC j i).symm⟩,⟨QC i j,CC ij⟩⟩
  have touch (i : I) {x y : V} (hx : x ∈ shoreContacts G X r) (no : x ∉ Q i)
      (hy : y ∈ Q i) : G.Adj x y := by
    obtain ⟨u,hu,yu⟩ := hy.2.2
    exact (none.cross_contacts_complete rOff hy.1 hx.1 (subC hu) hy.2.1 hx.2 yu
      (fun edge => no ⟨hx.1,hx.2,u,hu,edge⟩)).symm
  obtain ⟨base⟩ := route_residual_with_port none (P := P₀) (fun _ h => h.1)
  have first : ∃ s ∈ Z, ∃ t ∈ Z, Traverses G Z s t :=
    ⟨base.first,(base.covers _).mp (List.head_mem base.nonempty),base.last,base.last_mem,base,rfl,rfl⟩
  have each (i : I) (hi : i ∈ T) : ∃ s ∈ Q i, ∃ t ∈ Q i, Traverses G (B i) s t := by
    have two := many i ((rem i).mp hi).1 ((rem i).mp hi).2
    obtain ⟨u,hu,_,_,_⟩ := two
    obtain ⟨v,hv,uv⟩ := hu.2.2
    have cl := none.clique_of_contact rOff i hu.1 hu.2.1 hv uv
    apply nonprivate_block_route (QC i i) (many i ((rem i).mp hi).1 ((rem i).mp hi).2) ⟨v,hv⟩ cl
    · intro x hx y hy
      obtain ⟨u',hu',xu⟩ := hx.2.2
      exact none.contact_common_on_component rOff i hx.1 hx.2.1 hu' hy xu
    · intro x hx y hy z hz xy xz yz
      exact triple_of_card_bound (Y := Q i) (fun S hS ind =>
        none.card_independent_contacts_le_two S (fun w hw => subQ (hS w hw)) ind)
        hx hy hz xy xz yz
  have baseApart (i : I) (hi : i ∈ T) : Disjoint Z (B i) := by
    apply Set.disjoint_left.mpr
    rintro v (rfl|h) (hq|hc)
    · exact rOff (subQ hq).1
    · exact rOff (subC hc).1
    · exact h.2.2.2 i hi hq
    · exact (subC hc).2 h.1.2
  have baseAdj (i : I) (hi : i ∈ T) (s : V) (hs : s ∈ Z) (t : V) (ht : t ∈ Q i) :
      G.Adj s t := by
    rcases hs with rfl|hs
    · exact (subQ ht).2
    · exact touch i hs.1 (hs.2.2.2 i hi) ht
  obtain ⟨s,hs,t,ht,R⟩ := concatenate_contact_intervals T first each baseApart
    (fun _ _ _ _ h => apart _ _ h) baseAdj (fun i _ j _ h _ hx _ hy =>
      touch j (subQ hx) (Set.disjoint_left.mp (QQ h) hx) hy)
  have exclude {i : I} (hi : i ∈ T) {v : V} (hv : v ∈ Q i) : v ≠ p ∧ v ≠ q := by
    exact ⟨fun e => Set.disjoint_left.mp (QQ ((rem i).mp hi).1) hv (show v ∈ Q c from e.symm ▸ pc),
      fun e => Set.disjoint_left.mp (QQ ((rem i).mp hi).2) hv (show v ∈ Q d from e.symm ▸ qd)⟩
  have endpoints (v : V) (h : v ∈ intervalUnion Z Q T) :
      v ∈ insert r {v | v ∈ shoreContacts G X r ∧ v ≠ p ∧ v ≠ q} := by
    rcases h with (eq|hv)|⟨i,hi,hv⟩
    · exact Or.inl eq
    · exact Or.inr ⟨hv.1,hv.2.1,hv.2.2.1⟩
    · exact Or.inr ⟨subQ hv,exclude hi hv⟩
  have full : intervalUnion Z B T = insert r {v | v ∈ X ∧ v ∉ C c ∧ v ∉ C d ∧ v ≠ p ∧ v ≠ q} := by
    ext v
    constructor
    · rintro ((eq|hp)|⟨i,hi,hq|hc⟩)
      · exact Or.inl eq
      · exact Or.inr ⟨hp.1.1,fun h => (subC h).2 hp.1.2,fun h => (subC h).2 hp.1.2,
          hp.2.1,hp.2.2.1⟩
      · exact Or.inr ⟨(subQ hq).1,Set.disjoint_left.mp (QC i c) hq,
          Set.disjoint_left.mp (QC i d) hq,exclude hi hq⟩
      · exact Or.inr ⟨(subC hc).1,Set.disjoint_left.mp (CC ((rem i).mp hi).1) hc,
          Set.disjoint_left.mp (CC ((rem i).mp hi).2) hc,
          fun e => (subC hc).2 (show G.Adj r v from e.symm ▸ pc.2.1),
          fun e => (subC hc).2 (show G.Adj r v from e.symm ▸ qd.2.1)⟩
    · rintro (eq|⟨vx,vc,vd,vp,vq⟩)
      · exact Or.inl (Or.inl eq)
      by_cases rv : G.Adj r v
      · by_cases any : ∃ i ∈ T, v ∈ Q i
        · obtain ⟨i,hi,hv⟩ := any
          exact Or.inr ⟨i,hi,Or.inl hv⟩
        · exact Or.inl (Or.inr ⟨⟨vx,rv⟩,vp,vq,fun i hi hv => any ⟨i,hi,hv⟩⟩)
      let w : Noncontacts G X r := ⟨v,vx,rv⟩
      let i : I := (G.induce (Noncontacts G X r)).connectedComponentMk w
      have hv : v ∈ C i := ⟨w,rfl,rfl⟩
      have hi : i ∈ T := (rem i).mpr ⟨fun e => vc (show v ∈ C c from e ▸ hv),
        fun e => vd (show v ∈ C d from e ▸ hv)⟩
      exact Or.inr ⟨i,hi,Or.inr hv⟩
  exact ⟨s,endpoints s hs,t,endpoints t ht,full ▸ R⟩

#print axioms private_middle_from_all_nonprivate
end Graffiti199Depleted.Catalogue
