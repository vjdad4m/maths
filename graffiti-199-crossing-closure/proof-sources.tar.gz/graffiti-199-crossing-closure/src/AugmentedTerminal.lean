import PrivateTips

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X Y : Set V} {r a b : V}

theorem PrivatePair.other_wide (H : PrivatePair G X r) (F : ShoreCut G X Y r a b)
    (miss : ∃ y ∈ Y, ¬ G.Adj r y) (i : (G.induce (Noncontacts G X r)).ConnectedComponent)
    (ic : i ≠ H.c) (id' : i ≠ H.d) :
    ∃ x ∈ rootedBlockContacts G X r i, ∃ y ∈ rootedBlockContacts G X r i, x ≠ y := by
  classical
  let I := (G.induce (Noncontacts G X r)).ConnectedComponent
  have some : (shoreContacts G X r).Nonempty := ⟨H.p,H.pc.1,H.pc.2.1⟩
  obtain ⟨s,hs⟩ := rootedBlockContacts_nonempty F.connX some i
  by_contra missing
  have unique (y : V) (hy : y ∈ rootedBlockContacts G X r i) : y = s :=
    Classical.byContradiction fun ne => missing ⟨y,hy,s,hs,ne⟩
  let f : Fin 3 ↪ I := ⟨![H.c,H.d,i],by
    intro j k h
    fin_cases j <;> fin_cases k
    · rfl
    · exact (H.different h).elim
    · exact (ic h.symm).elim
    · exact (H.different h.symm).elim
    · rfl
    · exact (id' h.symm).elim
    · exact (ic h).elim
    · exact (id' h).elim
    · rfl⟩
  let g : Fin 3 → V := ![H.p,H.q,s]
  have rg (j : Fin 3) : G.Adj r (g j) := by
    fin_cases j
    · exact H.pc.2.1
    · exact H.qd.2.1
    · exact hs.2.1
  have singles (j : Fin 3) (z : V) (zx : z ∈ X) (rz : G.Adj r z)
      (touch : ∃ u ∈ noncontactComponent G X r (f j), G.Adj u z) : z = g j := by
    obtain ⟨u,hu,uz⟩ := touch
    fin_cases j
    · exact H.oneC _ ⟨zx,rz,u,hu,uz.symm⟩
    · exact H.oneD _ ⟨zx,rz,u,hu,uz.symm⟩
    · exact unique _ ⟨zx,rz,u,hu,uz.symm⟩
  have bound := private_components_le_two F.budget F.conn F.size F.offX F.offY F.boundX F.boundY
    F.apart F.connY (by simp : r ∈ ({r,a,b} : Finset V)) (by simp : a ∈ ({r,a,b} : Finset V))
    (by simp : b ∈ ({r,a,b} : Finset V)) F.ra (fun w hw => by simpa using hw) miss f g rg singles
  omega

/-- Route the augmented shore from a contact of the middle port once the
rooted tree exclusion and the two-private-component bound have been proved. -/
theorem ShoreCut.augmented_terminal_of_structure (F : ShoreCut G X Y r a b)
    (none : NoRootedFour G X r)
    (wideRest : ∀ H : PrivatePair G X r, ∀ i, i ≠ H.c → i ≠ H.d →
      ∃ x ∈ rootedBlockContacts G X r i, ∃ y ∈ rootedBlockContacts G X r i, x ≠ y) :
    ∃ z ∈ X, G.Adj a z ∧ ∃ t, Traverses G (insert r X) z t := by
  classical
  let I := (G.induce (Noncontacts G X r)).ConnectedComponent
  let Q (i : I) := rootedBlockContacts G X r i
  let priv (i : I) := ∃ p ∈ Q i, ∀ s ∈ Q i, s = p
  let wide (i : I) := ∃ x ∈ Q i, ∃ y ∈ Q i, x ≠ y
  have off := F.offX r (by simp)
  obtain ⟨v,vX,rv⟩ := F.contact (by simp : r ∈ ({r,a,b} : Finset V))
  have nonempty (i : I) : (Q i).Nonempty := rootedBlockContacts_nonempty F.connX ⟨v,vX,rv⟩ i
  have either (i : I) (notSmall : ¬ priv i) : wide i := by
    obtain ⟨p,hp⟩ := nonempty i
    by_contra notWide
    exact notSmall ⟨p,hp,fun s hs => Classical.byContradiction fun ne => notWide ⟨s,hs,p,hp,ne⟩⟩
  by_cases any : ∃ i, priv i
  · obtain ⟨c,p,pc,oneC⟩ := any
    obtain ⟨⟨z,zc,az⟩,_⟩ := ports_meet_private_component F.conn F.boundX F.offX c pc oneC
    refine ⟨z,(noncontactComponent_subset c zc).1,az,?_⟩
    by_cases another : ∃ d, d ≠ c ∧ priv d
    · obtain ⟨d,dc,q,qd,oneD⟩ := another
      let H : PrivatePair G X r := ⟨c,d,dc.symm,p,q,pc,qd,oneC,oneD⟩
      obtain ⟨w,hw⟩ := d.nonempty_supp
      exact ⟨w.val,start_double_private H none off (wideRest H) zc ⟨w,hw,rfl⟩⟩
    · exact start_single_private none off c pc oneC (fun i ic => either i (fun h => another ⟨i,ic,h⟩)) zc
  · obtain ⟨z,zx,az⟩ := F.contact (by simp : a ∈ ({r,a,b} : Finset V))
    exact ⟨z,zx,az,route_from_any_of_wide_shore none off (fun i => either i (fun h => any ⟨i,h⟩)) zx⟩

/-- Whenever the root misses a vertex across the cut, its own shore together
with the root has a spanning path starting at a neighbor of the specified
second port. The start lies in the shore itself. -/
theorem ShoreCut.augmented_terminal (F : ShoreCut G X Y r a b) (miss : ∃ y ∈ Y, ¬ G.Adj r y) :
    ∃ z ∈ X, G.Adj a z ∧ ∃ t, Traverses G (insert r X) z t :=
  F.augmented_terminal_of_structure (F.no_four (by simp) miss) (fun H => H.other_wide F miss)

#print axioms PrivatePair.other_wide
#print axioms ShoreCut.augmented_terminal
end Graffiti199Depleted.Catalogue.Incomplete

