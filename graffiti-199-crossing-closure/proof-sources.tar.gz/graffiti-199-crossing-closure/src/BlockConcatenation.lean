import NonprivateRoute

namespace Graffiti199Depleted.Catalogue
open SimpleGraph

variable {V I : Type*} {G : SimpleGraph V} [DecidableEq I]

/-- The union of the initial interval and the blocks indexed by T. -/
def intervalUnion (B₀ : Set V) (B : I → Set V) (T : Finset I) : Set V :=
  {x | x ∈ B₀ ∨ ∃ i ∈ T, x ∈ B i}

private theorem interval_insert (B₀ : Set V) (B : I → Set V) (T : Finset I) (i : I) :
    intervalUnion B₀ B (insert i T) = intervalUnion B₀ B T ∪ B i := by
  ext x
  simp only [intervalUnion,Set.mem_setOf_eq,Finset.mem_insert,Set.mem_union]
  constructor
  · rintro (h|⟨j,hj,h⟩)
    · exact Or.inl (Or.inl h)
    · rcases hj with rfl|hj
      · exact Or.inr h
      · exact Or.inl (Or.inr ⟨j,hj,h⟩)
  · rintro ((h|⟨j,hj,h⟩)|h)
    · exact Or.inl h
    · exact Or.inr ⟨j,Or.inr hj,h⟩
    · exact Or.inr ⟨i,Or.inl rfl,h⟩

/-- Join any finite family of disjoint traversable blocks. Only their
allowed endpoints need to have the cross-edges. -/
theorem concatenate_contact_intervals {B₀ E₀ : Set V} {B E : I → Set V} (T : Finset I)
    (initial : ∃ s ∈ E₀, ∃ t ∈ E₀, Traverses G B₀ s t)
    (routes : ∀ i ∈ T, ∃ s ∈ E i, ∃ t ∈ E i, Traverses G (B i) s t)
    (dis₀ : ∀ i ∈ T, Disjoint B₀ (B i))
    (dis : ∀ i ∈ T, ∀ j ∈ T, i ≠ j → Disjoint (B i) (B j))
    (join₀ : ∀ i ∈ T, ∀ s ∈ E₀, ∀ t ∈ E i, G.Adj s t)
    (cross : ∀ i ∈ T, ∀ j ∈ T, i ≠ j → ∀ s ∈ E i, ∀ t ∈ E j, G.Adj s t) :
    ∃ s ∈ intervalUnion E₀ E T, ∃ t ∈ intervalUnion E₀ E T,
      Traverses G (intervalUnion B₀ B T) s t := by
  induction T using Finset.induction_on with
  | empty => simpa [intervalUnion] using initial
  | @insert i T iT ih =>
    have hsub : T ⊆ insert i T := Finset.subset_insert _ _
    have ii : i ∈ insert i T := Finset.mem_insert_self _ _
    obtain ⟨s,hs,t,ht,first⟩ := ih (fun j hj => routes j (hsub hj))
      (fun j hj => dis₀ j (hsub hj)) (fun j hj k hk => dis j (hsub hj) k (hsub hk))
      (fun j hj => join₀ j (hsub hj)) (fun j hj k hk => cross j (hsub hj) k (hsub hk))
    obtain ⟨u,hu,v,hv,last⟩ := routes i ii
    have apart : Disjoint (intervalUnion B₀ B T) (B i) := by
      apply Set.disjoint_left.mpr
      rintro x (h|⟨j,hj,h⟩) h'
      · exact Set.disjoint_left.mp (dis₀ i ii) h h'
      · exact Set.disjoint_left.mp (dis j (hsub hj) i ii (fun eq => iT (eq ▸ hj))) h h'
    have edge : G.Adj t u := by
      rcases ht with h|⟨j,hj,h⟩
      · exact join₀ i ii _ h _ hu
      · exact cross j (hsub hj) i ii (fun eq => iT (eq ▸ hj)) _ h _ hu
    rw [interval_insert,interval_insert]
    exact ⟨s,Or.inl hs,v,Or.inr hv,first.join last apart edge⟩

#print axioms concatenate_contact_intervals
end Graffiti199Depleted.Catalogue
