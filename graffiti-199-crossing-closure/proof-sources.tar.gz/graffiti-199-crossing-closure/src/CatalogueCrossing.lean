import CrossingClosure

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
universe u
variable {V : Type u} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]

/-- Original minimal-counterexample formulation, allowing smaller connected
graphs at every connectivity covered by the catalogue bound. -/
theorem catalogue_minimum_crossing
    (minimum : ∀ (W : Type u) [Fintype W] (H : SimpleGraph W), Fintype.card W < Fintype.card V →
      H.Connected → 2 ≤ Fintype.card W → treeNumber H ≤ vertexConnectivity H + 2 → Traceable H)
    (conn : ConnectivityAtLeast G 3) (budget : treeNumber G ≤ 5) (order : 5 ≤ Fintype.card V)
    (no : ¬ Traceable G)
    (ind : ∀ a b, G.degree a = 3 → G.degree b = 3 → ¬ G.Adj a b) :
    CrossingBetweenSurvivingEdges G :=
  crossing_of_independent_cubic_minimum (smallerAtThree_of_catalogue_minimum minimum)
    conn budget order no ind

#print axioms catalogue_minimum_crossing
end Graffiti199Depleted.Catalogue.Incomplete
