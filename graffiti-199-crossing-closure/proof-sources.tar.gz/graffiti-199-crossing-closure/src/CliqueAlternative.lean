import FullNonclique

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X Y : Set V} {r a b : V}

def FullClique (G : SimpleGraph V) (U : Set V) (D : Finset V) : Prop :=
  U.Pairwise G.Adj ∧ ∀ i ∈ D, ∀ x ∈ U, G.Adj i x

private theorem force_clique (F : ShoreCut G X Y r a b) (no : ¬ Traceable G)
    (allX : ∀ s ∈ ({r,a,b} : Finset V), ∀ x ∈ X, G.Adj s x) (nc : ¬ X.Pairwise G.Adj) :
    FullClique G Y {r,a,b} := by
  classical
  have wlogRoot (i : V) (hi : i ∈ ({r,a,b} : Finset V)) :
      ∃ j k, ({i,j,k} : Finset V) = {r,a,b} ∧ ShoreCut G X Y i j k := by
    simp only [Finset.mem_insert,Finset.mem_singleton] at hi
    rcases hi with e|e|e <;> subst i
    · exact ⟨a,b,rfl,F⟩
    · have e : ({a,r,b} : Finset V) = {r,a,b} := by ext z; simp only [Finset.mem_insert,Finset.mem_singleton]; tauto
      exact ⟨r,b,e,F.relabel F.ra.symm F.ab F.rb e⟩
    · have e : ({b,a,r} : Finset V) = {r,a,b} := by ext z; simp only [Finset.mem_insert,Finset.mem_singleton]; tauto
      exact ⟨a,r,e,F.relabel F.ab.symm F.rb.symm F.ra.symm e⟩
  have rev {u v w : V} (H : ShoreCut G X Y u v w) :
      ShoreCut G Y X w v u := H.swap.relabel H.ab.symm H.rb.symm H.ra.symm (by
        ext z; simp only [Finset.mem_insert,Finset.mem_singleton]; tauto)
  have allY (i : V) (hi : i ∈ ({r,a,b} : Finset V)) (y : V) (hy : y ∈ Y) : G.Adj i y := by
    by_contra miss
    obtain ⟨j,k,eq,H⟩ := wlogRoot i hi
    obtain ⟨_,_,e,_,p⟩ := H.augmented_terminal ⟨y,hy,miss⟩
    have bk : ({k,j,i} : Finset V) = {i,j,k} := by ext z; simp only [Finset.mem_insert,Finset.mem_singleton]; tauto
    obtain ⟨_,_,e',_,q⟩ := (rev H).terminal_of_full_nonclique ((bk.trans eq).symm ▸ allX) nc
    exact no (H.join_augmented e e' p q)
  refine ⟨?_,allY⟩
  by_contra ncY
  obtain ⟨_,_,e,_,p⟩ := F.terminal_of_full_nonclique allY ncY
  have eq : ({b,a,r} : Finset V) = {r,a,b} := by ext z; simp only [Finset.mem_insert,Finset.mem_singleton]; tauto
  obtain ⟨_,_,e',_,q⟩ := (rev F).terminal_of_full_nonclique (eq.symm ▸ allX) nc
  exact no (F.join_augmented e e' p q)

/-- Every two-component three-cut in a nontraceable graph satisfying the
three-connected tree bound isolates a clique all of whose vertices see
all three cut vertices. -/
theorem ShoreCut.full_clique_shore (F : ShoreCut G X Y r a b) (no : ¬ Traceable G) :
    FullClique G X {r,a,b} ∨ FullClique G Y {r,a,b} := by
  classical
  rcases F.full_shore_of_nontraceable no with full|full
  · by_cases cl : X.Pairwise G.Adj
    · exact Or.inl ⟨cl,full⟩
    · exact Or.inr (force_clique F no full cl)
  · by_cases cl : Y.Pairwise G.Adj
    · exact Or.inr ⟨cl,full⟩
    · exact Or.inl (force_clique F.swap no full cl)

#print axioms ShoreCut.full_clique_shore
end Graffiti199Depleted.Catalogue.Incomplete
