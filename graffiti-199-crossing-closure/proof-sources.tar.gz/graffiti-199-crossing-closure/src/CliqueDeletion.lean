import CliqueAlternative

open private order_after_delete treeNumber_after_delete_le from CubicDeletion

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
universe u
variable {V : Type u} {G : SimpleGraph V} [Fintype V] [DecidableEq V]

/-- It suffices to check the original graph after deletions containing r. The
double-subtype transport is adapted from cubic deletion. -/
private theorem connectivity_after_delete {r : V} (order : 5 ≤ Fintype.card V)
    (pre : ∀ R : Finset V, R.card ≤ 3 → r ∈ R → (DeletionGraph G R).Preconnected) :
    ConnectivityAtLeast (G.induce {x | x ≠ r}) 3 := by
  classical
  let S : Set V := {x | x ≠ r}
  let H := G.induce S
  have sz : Fintype.card S = Fintype.card V - 1 := order_after_delete r
  refine ⟨(by change 3 < Fintype.card S; omega),?_⟩
  intro D small
  let emb : S ↪ V := ⟨Subtype.val,Subtype.val_injective⟩
  let R := insert r (D.map emb)
  have upper := Finset.card_insert_le r (D.map emb)
  rw [Finset.card_map] at upper
  have rsize : R.card ≤ 3 := by change (insert r (D.map emb)).card ≤ 3; omega
  let X := Survives R
  have keep (a : X) : a.val ≠ r := fun eq => a.property (by simp [R,eq])
  have connected := pre R rsize (Finset.mem_insert_self r (D.map emb))
  let T : Set S := {x | x ∉ D}
  let forward : X → T :=
    fun a => ⟨⟨a.val,keep a⟩,fun mem => a.property (Finset.mem_insert_of_mem
      (Finset.mem_map.mpr ⟨⟨a.val,keep a⟩,mem,rfl⟩))⟩
  let back : T → X := fun a =>
    ⟨a.val.val,by
      intro mem
      rcases Finset.mem_insert.mp mem with eq|hm
      · exact a.val.property eq
      · obtain ⟨b,hb,eq⟩ := Finset.mem_map.mp hm
        exact a.property ((show b = a.val from Subtype.ext eq) ▸ hb)⟩
  have right (a : T) : forward (back a) = a := Subtype.ext (Subtype.ext rfl)
  let f : DeletionGraph G R →g H.induce T := ⟨forward,fun e => e⟩
  have reach : (H.induce T).Preconnected := by
    intro a b
    have h := (connected (back a) (back b)).map f
    change (H.induce T).Reachable (forward (back a)) (forward (back b)) at h
    simpa only [right] using h
  have proper : D.card < (Finset.univ : Finset S).card := by rw [Finset.card_univ]; omega
  obtain ⟨a,_,off⟩ := Finset.exists_mem_not_mem_of_card_lt_card proper
  exact @SimpleGraph.Connected.mk _ (H.induce T) reach ⟨⟨a,off⟩⟩

omit [Fintype V] [DecidableEq V] in
private theorem reach_in_component {D : Finset V} {C : (DeletionGraph G D).ConnectedComponent}
    (x y : Survives D) (hx : x.val ∈ componentShore D C) (hy : y.val ∈ componentShore D C) :
    (DeletionGraph G D).Reachable x y := by
  obtain ⟨a,ha,ea⟩ := hx
  obtain ⟨b,hb,eb⟩ := hy
  have ax : a = x := Subtype.ext ea
  have by' : b = y := Subtype.ext eb
  exact ConnectedComponent.exact ((ax ▸ ha : x ∈ C.supp).trans (by' ▸ hb : y ∈ C.supp).symm)

theorem delete_full_clique_preconnected {D R : Finset V} {X : Set V} {v : V}
    (conn : ConnectivityAtLeast G 3) (bound : ShoreBoundary G D X)
    (full : FullClique G X D) (large : 3 ≤ Nat.card X) (vx : v ∈ X)
    (rest : (G.induce Xᶜ).Preconnected) (small : R.card ≤ 3) (del : v ∈ R) :
    (DeletionGraph G R).Preconnected := by
  classical
  by_cases survive : ∃ t ∈ X, t ∉ R
  · obtain ⟨t,tx,tR⟩ := survive
    let T : Survives R := ⟨t,tR⟩
    have toTwin (z : Survives R) : (DeletionGraph G R).Reachable z T := by
      let C := (DeletionGraph G R).connectedComponentMk z
      have own : z.val ∈ componentShore R C := ⟨z,rfl,rfl⟩
      obtain ⟨w,wc,vw⟩ := contact_of_shore conn small (componentShore_off_cut R C)
        (componentShore_boundary R C) ⟨z.val,own⟩ del
      obtain ⟨q,hq,rfl⟩ := wc
      have zq := reach_in_component z q own ⟨q,hq,rfl⟩
      by_cases eq : q.val = t
      · exact (show q = T from Subtype.ext eq) ▸ zq
      have step : G.Adj q.val t := by
        by_cases qX : q.val ∈ X
        · exact full.1 qX tx eq
        · exact full.2 _ (bound _ vx _ qX vw) t tx
      exact zq.trans (show (DeletionGraph G R).Adj q T from step).reachable
    exact fun z w => (toTwin z).trans (toTwin w).symm
  · letI : Fintype X := Fintype.ofFinite X
    have sub : X.toFinset ⊆ R := fun w hw => Classical.byContradiction fun out =>
      survive ⟨w,Set.mem_toFinset.mp hw,out⟩
    have eq : X.toFinset = R := Finset.eq_of_subset_of_card_le sub (by
      rw [Set.toFinset_card,← Nat.card_eq_fintype_card]; omega)
    have sets : {w : V | w ∉ R} = Xᶜ := by ext w; simp [← eq]
    change (G.induce {w : V | w ∉ R}).Preconnected
    rwa [sets]

/-- A fully attached clique of order at least three can be reduced by one
true twin whenever its outside is connected. -/
theorem traceable_of_large_full_clique {D : Finset V} {X : Set V}
    (smaller : SmallerAtThree.{u} (Fintype.card V)) (conn : ConnectivityAtLeast G 3)
    (budget : treeNumber G ≤ 5) (order : 5 ≤ Fintype.card V) (bound : ShoreBoundary G D X)
    (full : FullClique G X D) (large : 3 ≤ Nat.card X) (rest : (G.induce Xᶜ).Preconnected) :
    Traceable G := by
  classical
  letI : Fintype X := Fintype.ofFinite X
  have cx : 1 < Fintype.card X := by rw [← Nat.card_eq_fintype_card]; omega
  obtain ⟨x,y,xy⟩ := Fintype.exists_pair_of_one_lt_card cx
  have distinct : x.val ≠ y.val := fun e => xy (Subtype.ext e)
  have edge := full.1 x.property y.property distinct
  have reduced := connectivity_after_delete (G := G) (r := x.val) order fun R card mem =>
    delete_full_clique_preconnected conn bound full large x.property rest card mem
  have sz := order_after_delete x.val
  have tr := smaller {z : V // z ≠ x.val} (G.induce {z | z ≠ x.val}) (by omega)
    reduced ((treeNumber_after_delete_le (G := G) x.val).trans budget)
  obtain ⟨p⟩ := pathOn_of_traceable_delete tr
  obtain ⟨i,hi⟩ := List.mem_iff_get.mp ((p.covers y.val).mpr distinct.symm)
  by_contra no
  obtain ⟨⟨j,_,edge',miss⟩,_⟩ := path_flanks_of_nontraceable p no i (hi.symm ▸ edge)
  have toY : G.Adj y.val (p.vertices.get j) := hi ▸ edge'
  have off : p.vertices.get j ≠ x.val := (p.covers _).mp (List.get_mem ..)
  by_cases inside : p.vertices.get j ∈ X
  · exact miss (full.1 x.property inside off.symm)
  · exact miss (full.2 _ (bound _ y.property _ inside toY) x.val x.property).symm

#print axioms traceable_of_large_full_clique
end Graffiti199Depleted.Catalogue.Incomplete
