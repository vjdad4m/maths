import CompatibleRoots

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X Y : Set V} {r a b : V}

/-- Use both ends of an ordinary shore path when the two joining ports
are complete to that shore. -/
theorem ShoreCut.traceable_of_supported_path (F : ShoreCut G X Y r a b)
    (rMiss : ∃ x ∈ X, ¬ G.Adj r x) (aAll : ∀ x ∈ X, G.Adj a x)
    (bAll : ∀ x ∈ X, G.Adj b x) (P : PathOn G X) : Traceable G := by
  have bu := bAll _ ((P.covers _).mp (List.head_mem P.nonempty) : P.first ∈ X)
  have av := aAll _ P.last_mem
  have L : Traverses G X P.first P.last := ⟨P,rfl,rfl⟩
  obtain ⟨_,_,as',_,right⟩ := F.swap.augmented_terminal rMiss
  have bX := F.offX b (by simp)
  have aX := F.offX a (by simp)
  have rX := F.offX r (by simp)
  have aY := F.offY a (by simp)
  have bY := F.offY b (by simp)
  have d₁ : Disjoint ({b} : Set V) X := by simpa using bX
  have d₂ : Disjoint (({b} : Set V) ∪ X) ({a} : Set V) := by
    simp [Set.disjoint_union_left,F.ab,aX]
  have d₃ : Disjoint ((({b} : Set V) ∪ X) ∪ {a}) (insert r Y) := by
    simp [Set.disjoint_union_left,Set.disjoint_insert_right,F.apart,F.ra,F.rb,rX,aY,bY]
  have path := ((((Traverses.single b).join L d₁ bu).join (Traverses.single a) d₂ av.symm).join
    right d₃ as')
  obtain ⟨p,_,_⟩ := path
  have full : ((({b} : Set V) ∪ X) ∪ {a}) ∪ insert r Y = Set.univ := by
    apply Set.eq_univ_iff_forall.mpr
    intro z
    simp only [Set.mem_union,Set.mem_singleton_iff,Set.mem_insert_iff]
    have := F.cover z
    tauto
  exact traceable_iff_hamiltonian_walk.mpr (pathOn_univ_iff_hamiltonian_walk.mp ⟨full ▸ p⟩)


/-- A common missed port with the other two complete to both shores
still permits a Hamiltonian path, including when either shore is a clique. -/
theorem ShoreCut.traceable_of_common_miss (F : ShoreCut G X Y r a b)
    (rX : ∃ x ∈ X, ¬ G.Adj r x) (rY : ∃ y ∈ Y, ¬ G.Adj r y)
    (aX : ∀ x ∈ X, G.Adj a x) (aY : ∀ y ∈ Y, G.Adj a y)
    (bX : ∀ x ∈ X, G.Adj b x) (bY : ∀ y ∈ Y, G.Adj b y) : Traceable G := by
  classical
  by_cases cl : X.Pairwise G.Adj
  · obtain ⟨x⟩ := F.connX.nonempty
    obtain ⟨_,_,P,_,_⟩ := Traverses.start_clique cl x.property
    exact F.traceable_of_supported_path rX aX bX P
  · change ¬ (∀ u ∈ X, ∀ v ∈ X, u ≠ v → G.Adj u v) at cl
    push_neg at cl
    obtain ⟨u,uX,v,vX,uv,noEdge⟩ := cl
    obtain ⟨P⟩ := pathOn_opposite_of_complete_port (by simp : a ∈ ({r,a,b} : Finset V)) F.budget
      F.offX F.offY F.boundX F.apart F.connY aY uX vX uv noEdge (aX _ uX) (aX _ vX)
    exact F.swap.traceable_of_supported_path rY aY bY P

#print axioms ShoreCut.traceable_of_common_miss
end Graffiti199Depleted.Catalogue.Incomplete
