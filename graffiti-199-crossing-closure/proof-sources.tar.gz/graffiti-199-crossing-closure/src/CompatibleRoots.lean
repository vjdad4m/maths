import AugmentedTerminal

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X Y : Set V} {r a b : V}

theorem ShoreCut.relabel (F : ShoreCut G X Y r a b) {i j k : V}
    (ij : i ≠ j) (ik : i ≠ k) (jk : j ≠ k)
    (eq : ({i,j,k} : Finset V) = {r,a,b}) : ShoreCut G X Y i j k := by
  refine ⟨F.conn,F.budget,ij,ik,jk,eq.symm ▸ F.offX,eq.symm ▸ F.offY,
    eq.symm ▸ F.boundX,eq.symm ▸ F.boundY,F.apart,?_,F.connX,F.connY⟩
  intro z
  have : z ∈ X ∨ z ∈ Y ∨ z ∈ ({r,a,b} : Finset V) := by simpa using F.cover z
  rw [← eq] at this
  simpa using this

theorem ShoreCut.join_augmented (F : ShoreCut G X Y r a b) {s t x y : V}
    (as' : G.Adj a s) (at' : G.Adj a t)
    (L : Traverses G (insert r X) s x) (R : Traverses G (insert b Y) t y) :
    Traceable G := by
  have aX := F.offX a (by simp)
  have bX := F.offX b (by simp)
  have aY := F.offY a (by simp)
  have rY := F.offY r (by simp)
  have d₁ : Disjoint (insert r X) ({a} : Set V) := by simp [F.ra,F.ra.symm,aX]
  have d₂ : Disjoint ((insert r X) ∪ {a}) (insert b Y) := by
    simp [Set.disjoint_union_left,Set.disjoint_insert_right,Set.disjoint_insert_left,
      F.apart,F.ra,F.rb,F.ab,F.rb.symm,F.ab.symm,aY,bX,rY]
  obtain ⟨p,_,_⟩ := (L.reverse.join (Traverses.single a) d₁ as'.symm).join R d₂ at'
  have full : ((insert r X) ∪ {a}) ∪ insert b Y = Set.univ := by
    apply Set.eq_univ_iff_forall.mpr
    intro z
    simp only [Set.mem_union,Set.mem_singleton_iff,Set.mem_insert_iff]
    have := F.cover z
    tauto
  exact traceable_iff_hamiltonian_walk.mpr (pathOn_univ_iff_hamiltonian_walk.mp ⟨full ▸ p⟩)

/-- If distinct cut vertices miss vertices on opposite shores, a Hamiltonian
path traverses the shores augmented by their respective roots and uses the
third cut vertex to join the two routes. -/
theorem ShoreCut.traceable_of_distinct_misses (F : ShoreCut G X Y r a b)
    (rMiss : ∃ y ∈ Y, ¬ G.Adj r y) (bMiss : ∃ x ∈ X, ¬ G.Adj b x) : Traceable G := by
  have K := F.swap.relabel F.ab.symm F.rb.symm F.ra.symm
    (show ({b,a,r} : Finset V) = {r,a,b} by ext z; simp only [Finset.mem_insert,Finset.mem_singleton]; tauto)
  obtain ⟨s,_,as',_,L⟩ := F.augmented_terminal rMiss
  obtain ⟨t,_,at',_,R⟩ := K.augmented_terminal bMiss
  exact F.join_augmented as' at' L R

#print axioms ShoreCut.traceable_of_distinct_misses
end Graffiti199Depleted.Catalogue.Incomplete

