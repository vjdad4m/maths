import ComponentOutside

open private NoRootedFour.forbids_four from RootedBlocks
open private triple_of_card_bound from OppositeComplete
open private shore_anticomplete from CubicPortThreeShores

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] {D : Finset V}

abbrev OtherSide (D : Finset V) (C : (DeletionGraph G D).ConnectedComponent) : Set V :=
  {v | v ∉ D ∧ v ∉ componentShore D C}

def GoodAt (G : SimpleGraph V) (U : Set V) (r : V) : Prop :=
  U.Pairwise G.Adj ∧ ∀ x ∈ U, G.Adj r x

theorem component_contact (conn : ConnectivityAtLeast G 3) (size : D.card = 3)
    (C : (DeletionGraph G D).ConnectedComponent) {r : V} (hr : r ∈ D) :
    ∃ z ∈ componentShore D C, G.Adj r z := by
  obtain ⟨z⟩ := (componentShore_connected D C).nonempty
  exact contact_of_shore conn size.le (componentShore_off_cut D C) (componentShore_boundary D C)
    ⟨z.val,z.property⟩ hr

theorem pair_of_bad_component (conn : ConnectivityAtLeast G 3) (size : D.card = 3)
    (C : (DeletionGraph G D).ConnectedComponent) {r : V} (hr : r ∈ D)
    (bad : ¬ GoodAt G (componentShore D C) r) :
    ∃ u ∈ componentShore D C, ∃ v ∈ componentShore D C, u ≠ v ∧ G.Adj r u ∧
      ((G.Adj r v ∧ ¬ G.Adj u v) ∨ (¬ G.Adj r v ∧ G.Adj u v)) := by
  classical
  by_cases complete : ∀ z ∈ componentShore D C, G.Adj r z
  · have nc : ¬ (componentShore D C).Pairwise G.Adj := fun cl => bad ⟨cl,complete⟩
    change ¬ (∀ u ∈ componentShore D C, ∀ v ∈ componentShore D C, u ≠ v → G.Adj u v) at nc
    push_neg at nc
    obtain ⟨u,hu,v,hv,uv,non⟩ := nc
    exact ⟨u,hu,v,hv,uv,complete u hu,Or.inl ⟨complete v hv,non⟩⟩
  · push_neg at complete
    obtain ⟨u,hu,v,hv,ru,uv,no⟩ := two_step_into_shore (componentShore_connected D C).preconnected
      (component_contact conn size C hr) complete
    exact ⟨u,hu,v,hv,uv.ne,ru,Or.inr ⟨no,uv⟩⟩

theorem no_four_outside_bad (conn : ConnectivityAtLeast G 3) (size : D.card = 3)
    (budget : treeNumber G ≤ 5) (C : (DeletionGraph G D).ConnectedComponent)
    {r : V} (hr : r ∈ D) (bad : ¬ GoodAt G (componentShore D C) r) :
    NoRootedFour G (OtherSide D C) r := by
  obtain ⟨u,hu,v,hv,dif,ru,shape⟩ := pair_of_bad_component conn size C hr bad
  intro f h0 onU rooted
  have off {w : V} (mem : w ∈ componentShore D C) (i : Fin 4) : w ≠ f i := by
    intro eq
    by_cases h : i = 0
    · subst i
      exact componentShore_off_cut D C r hr ((eq.trans h0) ▸ mem)
    · exact (onU i h).2 (eq ▸ mem)
  have anti {w : V} (mem : w ∈ componentShore D C) (i : Fin 4) (hi : i ≠ 0) :
      ¬ G.Adj (f i) w := fun e => (onU i hi).1 (componentShore_boundary D C _ mem _ (onU i hi).2 e.symm)
  rcases shape with ⟨rv,uv⟩|⟨rv,uv⟩
  · have six := six_of_two_leaves f rooted dif (fun e => uv e.symm) (h0.symm ▸ ru) (h0.symm ▸ rv)
      (off hu) (off hv) (anti hu) (anti hv)
    omega
  · have no (i : Fin 4) : ¬ G.Adj (f i) v := by
      by_cases hi : i = 0
      · subst i
        simpa only [h0] using rv
      · exact anti hv i hi
    have six := six_le_treeNumber_of_rooted_four_and_tail f rooted uv (h0.symm ▸ ru)
      (off hu) (off hv) no (anti hu)
    omega

omit [Fintype V] in
theorem other_of_component {C E : (DeletionGraph G D).ConnectedComponent} {x : V}
    (diff : C ≠ E) (h : x ∈ componentShore D C) : x ∈ OtherSide D E :=
  ⟨fun d => componentShore_off_cut D C x d h,Set.disjoint_left.mp (componentShore_disjoint diff) h⟩

omit [Fintype V] in
theorem distinct_component_vertices {C E : (DeletionGraph G D).ConnectedComponent}
    (ne : C ≠ E) {s t : V} (hs : s ∈ componentShore D C) (ht : t ∈ componentShore D E) :
    s ≠ t ∧ ¬ G.Adj s t :=
  ⟨fun e => Set.disjoint_left.mp (componentShore_disjoint ne) hs (e.symm ▸ ht),
    shore_anticomplete (componentShore_off_cut D E) (componentShore_boundary D C)
      (componentShore_disjoint ne) hs ht⟩

/-- At a common port at most one of three different components can fail
to be a fully attached clique. -/
theorem good_of_two_other_components (conn : ConnectivityAtLeast G 3) (size : D.card = 3)
    (budget : treeNumber G ≤ 5) {C E K : (DeletionGraph G D).ConnectedComponent}
    (ce : C ≠ E) (ck : C ≠ K) (ek : E ≠ K) {r : V} (hr : r ∈ D)
    (bad : ¬ GoodAt G (componentShore D C) r) : GoodAt G (componentShore D E) r := by
  classical
  by_contra other
  have n := no_four_outside_bad conn size budget C hr bad
  obtain ⟨u,hu,v,hv,uv,ru,shape⟩ := pair_of_bad_component conn size E hr other
  obtain ⟨w,hw,rw⟩ := component_contact conn size K hr
  have uw := distinct_component_vertices ek hu hw
  have vw := distinct_component_vertices ek hv hw
  have rvNe : r ≠ v := fun e => componentShore_off_cut D E r hr (e.symm ▸ hv)
  have nd : [r,u,v,w].Nodup := by simp [ru.ne,rvNe,rw.ne,uv,uw.1,vw.1]
  apply NoRootedFour.forbids_four n (other_of_component ce.symm hu) (other_of_component ce.symm hv)
    (other_of_component ck.symm hw) nd ru _ (Or.inl ⟨rw.symm,fun e => uw.2 e.symm,fun e => vw.2 e.symm⟩)
  rcases shape with ⟨rv,miss⟩|⟨miss,hit⟩
  · exact Or.inl ⟨rv.symm,fun e => miss e.symm⟩
  · exact Or.inr ⟨hit.symm,fun e => miss e.symm⟩

/-- A component with a bad port leaves room for at most two others. -/
theorem no_fourth_component (conn : ConnectivityAtLeast G 3) (size : D.card = 3)
    (budget : treeNumber G ≤ 5) {C E K L : (DeletionGraph G D).ConnectedComponent}
    (ce : C ≠ E) (ck : C ≠ K) (cl : C ≠ L) (ek : E ≠ K) (el : E ≠ L) (kl : K ≠ L)
    {r : V} (hr : r ∈ D) (bad : ¬ GoodAt G (componentShore D C) r) : False := by
  classical
  have none := no_four_outside_bad conn size budget C hr bad
  obtain ⟨u,hu,ru⟩ := component_contact conn size E hr
  obtain ⟨v,hv,rv⟩ := component_contact conn size K hr
  obtain ⟨w,hw,rw⟩ := component_contact conn size L hr
  have uv := distinct_component_vertices ek hu hv
  have uw := distinct_component_vertices el hu hw
  have vw := distinct_component_vertices kl hv hw
  have e := triple_of_card_bound (Y := shoreContacts G (OtherSide D C) r) (fun T ht stable =>
    none.card_independent_contacts_le_two T ht stable)
    ⟨other_of_component ce.symm hu,ru⟩ ⟨other_of_component ck.symm hv,rv⟩
    ⟨other_of_component cl.symm hw,rw⟩ uv.1 uw.1 vw.1
  exact e.elim uv.2 (fun h => h.elim uw.2 vw.2)

#print axioms good_of_two_other_components
#print axioms no_fourth_component
end Graffiti199Depleted.Catalogue.Incomplete

