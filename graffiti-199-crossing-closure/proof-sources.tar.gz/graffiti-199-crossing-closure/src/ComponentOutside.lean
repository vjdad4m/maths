import CliqueDeletion

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
universe u
variable {V : Type u} {G : SimpleGraph V} [Fintype V] [DecidableEq V]

/-- After discarding one whole component of a three-cut, the remaining
components all attach to every cut vertex. The outside is connected. -/
theorem outside_component_preconnected (conn : ConnectivityAtLeast G 3)
    {D : Finset V} (size : D.card = 3)
    {A B : (DeletionGraph G D).ConnectedComponent} (ab : A ≠ B) :
    (G.induce (componentShore D A)ᶜ).Preconnected := by
  classical
  let X := componentShore D A
  let O : Set V := Xᶜ
  let H := G.induce O
  obtain ⟨p,hp⟩ := Finset.card_pos.mp (show 0 < D.card by omega)
  let P : O := ⟨p,componentShore_off_cut D A p hp⟩
  have port (z : V) (hz : z ∈ D) : z ∈ O := componentShore_off_cut D A z hz
  have enter (C : (DeletionGraph G D).ConnectedComponent) (ca : C ≠ A)
      (z : V) (hz : z ∈ D) (v : componentShore D C) :
      H.Reachable (⟨v.val,Set.disjoint_left.mp (componentShore_disjoint ca) v.property⟩ : O)
        ⟨z,port z hz⟩ := by
    let inc : G.induce (componentShore D C) →g H :=
      ⟨fun t => ⟨t.val,Set.disjoint_left.mp (componentShore_disjoint ca) t.property⟩,fun e => e⟩
    obtain ⟨w,hw,zw⟩ := contact_of_shore conn size.le (componentShore_off_cut D C)
      (componentShore_boundary D C) ⟨v.val,v.property⟩ hz
    let W : componentShore D C := ⟨w,hw⟩
    exact (((componentShore_connected D C).preconnected v W).map inc).trans
      (show H.Adj (inc W) ⟨z,port z hz⟩ from zw.symm).reachable
  have reach (v : O) : H.Reachable v P := by
    by_cases cut : v.val ∈ D
    · obtain ⟨b⟩ := (componentShore_connected D B).nonempty
      exact (enter B ab.symm v.val cut b).symm.trans (enter B ab.symm p hp b)
    · let t : Survives D := ⟨v.val,cut⟩
      let K := (DeletionGraph G D).connectedComponentMk t
      have mem : v.val ∈ componentShore D K := ⟨t,rfl,rfl⟩
      have ne : K ≠ A := fun eq => v.property (show v.val ∈ componentShore D A by simpa only [eq] using mem)
      exact enter K ne p hp ⟨v.val,mem⟩
  exact fun v w => (reach v).trans (reach w).symm

theorem LargeCrossingFailure.no_full_large (F : LargeCrossingFailure G)
    (smaller : SmallerAtThree.{u} (Fintype.card V)) (conn : ConnectivityAtLeast G 3)
    (budget : treeNumber G ≤ 5) (order : 5 ≤ Fintype.card V) (no : ¬ Traceable G) :
    (¬ FullClique G (componentShore F.cut F.first) F.cut) ∧
    (¬ FullClique G (componentShore F.cut F.second) F.cut) := by
  exact ⟨fun full => no (traceable_of_large_full_clique smaller conn budget order
    (componentShore_boundary F.cut F.first) full F.first_large
    (outside_component_preconnected conn F.size F.different)),
    fun full => no (traceable_of_large_full_clique smaller conn budget order
    (componentShore_boundary F.cut F.second) full F.second_large
    (outside_component_preconnected conn F.size F.different.symm))⟩

/-- For arbitrary order, a genuine crossing failure in a minimal graph must
have a third surviving component. -/
theorem LargeCrossingFailure.third (F : LargeCrossingFailure G)
    (smaller : SmallerAtThree.{u} (Fintype.card V)) (conn : ConnectivityAtLeast G 3)
    (budget : treeNumber G ≤ 5) (order : 5 ≤ Fintype.card V) (no : ¬ Traceable G) :
    ∃ C, C ≠ F.first ∧ C ≠ F.second := by
  classical
  by_contra! two
  let X := componentShore F.cut F.first
  let Y := componentShore F.cut F.second
  obtain ⟨r,a,b,ra,rb,ab,eq⟩ := Finset.card_eq_three.mp F.size
  have cover (v : V) : v ∈ X ∨ v ∈ Y ∨ v = r ∨ v = a ∨ v = b := by
    by_cases hd : v ∈ F.cut
    · right; right; simpa [eq] using hd
    let t : Survives F.cut := ⟨v,hd⟩
    let K := (DeletionGraph G F.cut).connectedComponentMk t
    have mem : v ∈ componentShore F.cut K := ⟨t,rfl,rfl⟩
    by_cases e : K = F.first
    · exact Or.inl (show v ∈ componentShore F.cut F.first by simpa only [e] using mem)
    · exact Or.inr (Or.inl (show v ∈ componentShore F.cut F.second by simpa only [two K e] using mem))
  let H : ShoreCut G X Y r a b := ⟨conn,budget,ra,rb,ab,
    eq ▸ componentShore_off_cut F.cut F.first,eq ▸ componentShore_off_cut F.cut F.second,
    eq ▸ componentShore_boundary F.cut F.first,eq ▸ componentShore_boundary F.cut F.second,
    componentShore_disjoint F.different,cover,componentShore_connected F.cut F.first,
    componentShore_connected F.cut F.second⟩
  have n := LargeCrossingFailure.no_full_large F smaller conn budget order no
  have transport (S : Set V) (h : FullClique G S {r,a,b}) : FullClique G S F.cut := by rwa [eq]
  rcases H.full_clique_shore no with h|h
  · exact n.1 (transport X h)
  · exact n.2 (transport Y h)

#print axioms LargeCrossingFailure.third
end Graffiti199Depleted.Catalogue.Incomplete
