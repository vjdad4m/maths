import PrivateHalfFromGeometry
import Mathlib.Data.Finset.Max

namespace Graffiti199Depleted.Catalogue

open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} {U Y : Set V}

/-- Open a path whose ends coincide or are adjacent at any prescribed vertex. -/
private theorem open_at (p : PathOn G U) (closes : p.last = p.first ∨ G.Adj p.last p.first)
    {z : V} (hz : z ∈ U) : ∃ t, Traverses G U z t := by
  obtain ⟨A,B,eq⟩ := List.append_of_mem ((p.covers z).mpr hz)
  let L := A ++ z :: B
  let R := (z :: B) ++ A
  have perm : L.Perm R := List.perm_append_comm
  have nd : L.Nodup := by simpa only [L,← eq] using p.nodup
  have chain : L.Chain' G.Adj := by simpa only [L,← eq] using p.chain
  have turn : R.Chain' G.Adj := by
    apply (List.chain'_append.mp chain).2.1.append (List.chain'_append.mp chain).1
    intro e he s hs
    have eEnd : e = p.last := by
      have h : e ∈ p.vertices.getLast? := eq.symm ▸ List.mem_getLast?_append_of_mem_getLast? he
      exact (List.mem_getLast?_eq_getLast h).choose_spec
    have sStart : s = p.first := by
      have h : s ∈ p.vertices.head? := eq.symm ▸ List.mem_head?_append_of_mem_head? hs
      rw [List.head?_eq_head p.nonempty] at h
      exact (Option.mem_some.mp h).symm
    rcases closes with same | edge
    · have different := (List.nodup_append.mp nd).2.2
      have sm : s ∈ A := List.mem_of_mem_head? hs
      have em : e ∈ z :: B := List.mem_of_getLast? (Option.mem_def.mp he)
      exact (different sm ((eEnd.trans (same.trans sStart.symm)) ▸ em)).elim
    · exact eEnd.symm ▸ sStart.symm ▸ edge
  let q : PathOn G U := ⟨R,by simp [R],turn,perm.nodup_iff.mp nd,fun v => by
    rw [← p.covers v,eq]
    exact perm.mem_iff.symm⟩
  exact ⟨q.last,q,rfl,rfl⟩

/-- A finite connected induced shore with no independent triple has a spanning path.
The argument uses the first edge leaving a longest path and reopens its cycle there. -/
theorem pathOn_connected_of_no_independent_triple [Fintype V]
    (conn : (G.induce Y).Connected)
    (triple : ∀ x ∈ Y, ∀ y ∈ Y, ∀ z ∈ Y, x ≠ y → x ≠ z → y ≠ z →
      G.Adj x y ∨ G.Adj x z ∨ G.Adj y z) : Nonempty (PathOn G Y) := by
  classical
  let family := (Finset.univ : Finset (Finset V)).filter fun (S : Finset V) =>
    (↑S : Set V) ⊆ Y ∧ Nonempty (PathOn G (↑S : Set V))
  have mem (S : Finset V) : S ∈ family ↔
      (↑S : Set V) ⊆ Y ∧ Nonempty (PathOn G (↑S : Set V)) := by simp [family]
  obtain ⟨seed⟩ := conn.nonempty
  have start := Traverses.single (G := G) seed.val
  obtain ⟨init,_,_⟩ := start
  have existsPath : family.Nonempty := by
    refine ⟨{seed.val},(mem _).mpr ?_⟩
    simpa using (show ({seed.val} : Set V) ⊆ Y ∧ Nonempty (PathOn G {seed.val}) from
      ⟨Set.singleton_subset_iff.mpr seed.property,⟨init⟩⟩)
  obtain ⟨S,hS,maximal⟩ := family.exists_max_image Finset.card existsPath
  obtain ⟨sub,⟨p⟩⟩ := (mem S).mp hS
  by_cases full : (↑S : Set V) = Y
  · exact ⟨full ▸ p⟩
  have outside : ∃ v ∈ Y, v ∉ S := by
    by_contra! missing
    exact full (Set.Subset.antisymm sub missing)
  obtain ⟨v,hv,vS⟩ := outside
  have fst : p.first ∈ S := (p.covers _).mp (List.head_mem p.nonempty)
  have lst : p.last ∈ S := p.last_mem
  obtain ⟨w⟩ := conn.preconnected ⟨p.first,sub fst⟩ ⟨v,hv⟩
  obtain ⟨z,zS,q,qS,zq⟩ := crossingOnWalk (U := {w : Y | w.val ∈ S}) w fst vS
  change q.val ∉ S at qS
  have nodis : Disjoint ({q.val} : Set V) (↑S : Set V) := by simpa using qS
  have extend {e t : V} (path : Traverses G (↑S : Set V) e t) (contact : G.Adj q.val e) : False := by
    obtain ⟨joined,_,_⟩ := (Traverses.single q.val).join path nodis contact
    have next : insert q.val S ∈ family := (mem _).mpr (by
      rw [Finset.coe_insert]
      refine ⟨Set.insert_subset q.property sub,?_⟩
      exact ⟨by simpa using joined⟩)
    have large := maximal _ next
    rw [Finset.card_insert_of_not_mem qS] at large
    omega
  have original : Traverses G (↑S : Set V) p.first p.last := ⟨p,rfl,rfl⟩
  have close : p.last = p.first ∨ G.Adj p.last p.first := by
    by_cases eq : p.last = p.first
    · exact Or.inl eq
    have lq : p.last ≠ q.val := fun eq => qS (eq ▸ lst)
    have fq : p.first ≠ q.val := fun eq => qS (eq ▸ fst)
    rcases triple _ (sub lst) _ (sub fst) _ q.property eq lq fq with e|e|e
    · exact Or.inr e
    · exact (extend original.reverse e.symm).elim
    · exact (extend original e.symm).elim
  obtain ⟨t,path⟩ := open_at p close zS
  exact (extend path zq.symm).elim

#print axioms pathOn_connected_of_no_independent_triple

end Graffiti199Depleted.Catalogue
