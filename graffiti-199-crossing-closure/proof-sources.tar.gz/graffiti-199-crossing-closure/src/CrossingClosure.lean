import ThreeCliqueSplice

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
universe u
variable {V : Type u} {G : SimpleGraph V} [Fintype V] [DecidableEq V]

omit [Fintype V] [DecidableEq V] in
private theorem bad_port_of_not_full {D : Finset V} {X : Set V}
    (size : D.card = 3) (bad : ¬ FullClique G X D) :
    ∃ r ∈ D, ¬ GoodAt G X r := by
  classical
  by_contra! none
  obtain ⟨p,hp⟩ := Finset.card_pos.mp (show 0 < D.card by omega)
  exact bad ⟨(none p hp).1,fun r hr => (none r hr).2⟩

/-- In the minimum-order connectivity-three argument, a three-cut cannot
leave two components of order at least three. The result is independent
of the degrees of the cut vertices and of any independence assumption. -/
theorem traceable_of_two_large_components (F : LargeCrossingFailure G)
    (smaller : SmallerAtThree.{u} (Fintype.card V)) (conn : ConnectivityAtLeast G 3)
    (budget : treeNumber G ≤ 5) (order : 5 ≤ Fintype.card V) : Traceable G := by
  classical
  by_contra no
  obtain ⟨badA,badB⟩ := LargeCrossingFailure.no_full_large F smaller conn budget order no
  obtain ⟨p,hp,pA⟩ := bad_port_of_not_full F.size badA
  obtain ⟨q,hq,qB⟩ := bad_port_of_not_full F.size badB
  obtain ⟨C,ca,cb⟩ := LargeCrossingFailure.third F smaller conn budget order no
  have ab := F.different
  have clB := (good_of_two_other_components conn F.size budget ab ca.symm cb.symm hp pA).1
  have clC := (good_of_two_other_components conn F.size budget ca.symm ab cb hp pA).1
  have clA := (good_of_two_other_components conn F.size budget ab.symm cb.symm ca.symm hq qB).1
  have only (K : (DeletionGraph G F.cut).ConnectedComponent) : K = F.first ∨ K = F.second ∨ K = C := by
    by_contra! other
    exact no_fourth_component conn F.size budget ab ca.symm other.1.symm cb.symm other.2.1.symm
      other.2.2.symm hp pA
  exact no (three_clique_route F conn C ca cb only clA clB clC)

variable [DecidableRel G.Adj]

/-- Arbitrary-order closure of the surviving-edge crossing-failure branch
for independent degree-three vertices. -/
theorem traceable_of_independent_cubic_crossing_failure
    (smaller : SmallerAtThree.{u} (Fintype.card V)) (conn : ConnectivityAtLeast G 3)
    (budget : treeNumber G ≤ 5) (order : 5 ≤ Fintype.card V)
    (ind : ∀ a b, G.degree a = 3 → G.degree b = 3 → ¬ G.Adj a b)
    (fail : ¬ CrossingBetweenSurvivingEdges G) : Traceable G := by
  classical
  by_contra no
  obtain ⟨F⟩ := large_crossing_failure_of_independent_cubics smaller conn budget order no ind fail
  exact no (traceable_of_two_large_components F smaller conn budget order)

/-- Thus the archived crossing law holds in every nontraceable graph in
this reduced minimum-order branch. -/
theorem crossing_of_independent_cubic_minimum
    (smaller : SmallerAtThree.{u} (Fintype.card V)) (conn : ConnectivityAtLeast G 3)
    (budget : treeNumber G ≤ 5) (order : 5 ≤ Fintype.card V) (no : ¬ Traceable G)
    (ind : ∀ a b, G.degree a = 3 → G.degree b = 3 → ¬ G.Adj a b) :
    CrossingBetweenSurvivingEdges G := Classical.byContradiction fun fail =>
  no (traceable_of_independent_cubic_crossing_failure smaller conn budget order ind fail)

#print axioms traceable_of_two_large_components
#print axioms traceable_of_independent_cubic_crossing_failure
#print axioms crossing_of_independent_cubic_minimum
end Graffiti199Depleted.Catalogue.Incomplete

