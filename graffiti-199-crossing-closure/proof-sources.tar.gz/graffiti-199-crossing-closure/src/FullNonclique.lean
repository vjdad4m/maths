import IndependentLeaves

open private triple_of_card_bound from OppositeComplete

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X Y : Set V} {r a b : V}

theorem PrivatePair.other_wide_of_middle (H : PrivatePair G X r) (F : ShoreCut G X Y r a b)
    (none : NoRootedFour G X a) (i : (G.induce (Noncontacts G X r)).ConnectedComponent)
    (ic : i ≠ H.c) (id' : i ≠ H.d) :
    ∃ x ∈ rootedBlockContacts G X r i, ∃ y ∈ rootedBlockContacts G X r i, x ≠ y := by
  classical
  obtain ⟨p,hp⟩ := rootedBlockContacts_nonempty F.connX ⟨H.p,H.pc.1,H.pc.2.1⟩ i
  by_contra missing
  have one (z : V) (hz : z ∈ rootedBlockContacts G X r i) : z = p :=
    Classical.byContradiction fun ne => missing ⟨z,hz,p,hp,ne⟩
  obtain ⟨⟨u,uc,au⟩,_⟩ := ports_meet_private_component F.conn F.boundX F.offX H.c H.pc H.oneC
  obtain ⟨⟨v,vd,av⟩,_⟩ := ports_meet_private_component F.conn F.boundX F.offX H.d H.qd H.oneD
  obtain ⟨⟨w,wi,aw⟩,_⟩ := ports_meet_private_component F.conn F.boundX F.offX i hp one
  have de {C E : (G.induce (Noncontacts G X r)).ConnectedComponent} (diff : C ≠ E)
      {s t : V} (h : s ∈ noncontactComponent G X r C) (m : t ∈ noncontactComponent G X r E) :
      s ≠ t := fun eq => Set.disjoint_left.mp (noncontactComponents_apart diff) h (eq.symm ▸ m)
  have e := triple_of_card_bound (Y := shoreContacts G X a) (fun T hT ind =>
    none.card_independent_contacts_le_two T hT ind)
    ⟨(noncontactComponent_subset H.c uc).1,au⟩ ⟨(noncontactComponent_subset H.d vd).1,av⟩
    ⟨(noncontactComponent_subset i wi).1,aw⟩ (de H.different uc vd)
    (de ic.symm uc wi) (de id'.symm vd wi)
  exact e.elim (noncontactComponents_anticomplete H.different uc vd)
    (fun h => h.elim (noncontactComponents_anticomplete ic.symm uc wi)
      (noncontactComponents_anticomplete id'.symm vd wi))

theorem ShoreCut.terminal_of_full_nonclique (F : ShoreCut G X Y r a b)
    (allY : ∀ s ∈ ({r,a,b} : Finset V), ∀ y ∈ Y, G.Adj s y) (nc : ¬ Y.Pairwise G.Adj) :
    ∃ z ∈ X, G.Adj a z ∧ ∃ t, Traverses G (insert r X) z t := by
  classical
  change ¬ (∀ u ∈ Y, ∀ v ∈ Y, u ≠ v → G.Adj u v) at nc
  push_neg at nc
  obtain ⟨u,hu,v,hv,uv,no⟩ := nc
  have none {s : V} (hs : s ∈ ({r,a,b} : Finset V)) : NoRootedFour G X s :=
    F.no_four_of_leaves hs hu hv uv no (allY s hs u hu) (allY s hs v hv)
  exact F.augmented_terminal_of_structure (none (by simp))
    (fun H => H.other_wide_of_middle F (none (by simp)))

#print axioms ShoreCut.terminal_of_full_nonclique
end Graffiti199Depleted.Catalogue.Incomplete
