import CoincidentRoots

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X Y : Set V} {r a b : V}
local macro "perm_ports" : tactic =>
  `(tactic| (ext u; simp only [Finset.mem_insert,Finset.mem_singleton]; tauto))

private theorem place_two (F : ShoreCut G X Y r a b) {i k : V}
    (hi : i ∈ ({r,a,b} : Finset V)) (hk : k ∈ ({r,a,b} : Finset V)) (dif : i ≠ k) :
    ∃ j, ShoreCut G X Y i j k := by
  simp only [Finset.mem_insert,Finset.mem_singleton] at hi hk
  rcases hi with rfl|rfl|rfl <;> rcases hk with e|e|e <;> subst_vars <;>
    first | exact (dif rfl).elim | exact ⟨_,F⟩ |
      exact ⟨_,F.relabel F.rb F.ra F.ab.symm (by perm_ports)⟩ |
      exact ⟨_,F.relabel F.ra.symm F.ab F.rb (by perm_ports)⟩ |
      exact ⟨_,F.relabel F.ab F.ra.symm F.rb.symm (by perm_ports)⟩ |
      exact ⟨_,F.relabel F.rb.symm F.ab.symm F.ra (by perm_ports)⟩ |
      exact ⟨_,F.relabel F.ab.symm F.rb.symm F.ra.symm (by perm_ports)⟩

private theorem place_one (F : ShoreCut G X Y r a b) {i : V} (hi : i ∈ ({r,a,b} : Finset V)) :
    ∃ j ∈ ({r,a,b} : Finset V), ∃ k ∈ ({r,a,b} : Finset V), ShoreCut G X Y i j k := by
  simp only [Finset.mem_insert,Finset.mem_singleton] at hi
  rcases hi with e|e|e <;> subst i
  · exact ⟨a,by simp,b,by simp,F⟩
  · exact ⟨r,by simp,b,by simp,F.relabel F.ra.symm F.ab F.rb (by perm_ports)⟩
  · exact ⟨a,by simp,r,by simp,F.relabel F.ab.symm F.rb.symm F.ra.symm (by perm_ports)⟩

/-- In a nontraceable graph satisfying the catalogue bound at connectivity
three, every two-component three-cut has a shore complete to the entire cut. -/
theorem ShoreCut.full_shore_of_nontraceable (F : ShoreCut G X Y r a b) (no : ¬ Traceable G) :
    (∀ i ∈ ({r,a,b} : Finset V), ∀ x ∈ X, G.Adj i x) ∨
    (∀ i ∈ ({r,a,b} : Finset V), ∀ y ∈ Y, G.Adj i y) := by
  classical
  by_contra! fail
  obtain ⟨⟨k,hk,x,hx,kx⟩,⟨i,hi,y,hy,iy⟩⟩ := fail
  have same {s t : V} (hs : s ∈ ({r,a,b} : Finset V)) (ht : t ∈ ({r,a,b} : Finset V))
      (sY : ∃ w ∈ Y, ¬ G.Adj s w) (tX : ∃ w ∈ X, ¬ G.Adj t w) : s = t := by
    by_contra dif
    obtain ⟨_,H⟩ := place_two F hs ht dif
    exact no (H.traceable_of_distinct_misses sY tX)
  have eq := same hi hk ⟨y,hy,iy⟩ ⟨x,hx,kx⟩
  subst k
  obtain ⟨j,hj,l,hl,H⟩ := place_one F hi
  have allX {s : V} (hs : s ∈ ({r,a,b} : Finset V)) (dif : i ≠ s) (z : V) (hz : z ∈ X) :
      G.Adj s z := Classical.byContradiction fun missing =>
    dif (same hi hs ⟨y,hy,iy⟩ ⟨z,hz,missing⟩)
  have allY {s : V} (hs : s ∈ ({r,a,b} : Finset V)) (dif : i ≠ s) (z : V) (hz : z ∈ Y) :
      G.Adj s z := Classical.byContradiction fun missing =>
    dif (same hs hi ⟨z,hz,missing⟩ ⟨x,hx,kx⟩).symm
  exact no (H.traceable_of_common_miss ⟨x,hx,kx⟩ ⟨y,hy,iy⟩ (allX hj H.ra) (allY hj H.ra)
    (allX hl H.rb) (allY hl H.rb))

#print axioms ShoreCut.full_shore_of_nontraceable
end Graffiti199Depleted.Catalogue.Incomplete
