import FullShore

open private shore_anticomplete from CubicPortThreeShores

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V]

/-- Extend an ordered rooted four-tree by two independent leaves at its root.
The indexing of the induced six-tree follows RootQuartet.lean. -/
theorem six_of_two_leaves (f : Fin 4 ↪ V) (rooted : RootOrdering G f) {a t : V}
    (dif : a ≠ t) (noEdge : ¬ G.Adj t a) (ra : G.Adj (f 0) a) (rt : G.Adj (f 0) t)
    (offA : ∀ i, a ≠ f i) (offT : ∀ i, t ≠ f i)
    (aOff : ∀ i, i ≠ 0 → ¬ G.Adj (f i) a)
    (tOff : ∀ i, i ≠ 0 → ¬ G.Adj (f i) t) : 6 ≤ treeNumber G := by
  let g : Fin 6 → V := @Fin.addCases 4 2 (fun _ => V) f (![a,t] : Fin 2 → V)
  have left (i : Fin 4) : g (Fin.castAdd 2 i) = f i := by simp [g,Fin.addCases_left]
  have right (i : Fin 2) : g (Fin.natAdd 4 i) = (![a,t] : Fin 2 → V) i := by
    simp [g,Fin.addCases_right]
  have inj : Function.Injective g := by
    intro i
    refine Fin.addCases (m := 4) (n := 2) ?_ ?_ i
    · intro x j
      refine Fin.addCases (m := 4) (n := 2) ?_ ?_ j
      · intro y eq
        rw [left,left] at eq
        exact congrArg (Fin.castAdd 2) (f.injective eq)
      · intro y eq
        rw [left,right] at eq
        fin_cases y
        · exact (offA x eq.symm).elim
        · exact (offT x eq.symm).elim
    · intro x j
      refine Fin.addCases (m := 4) (n := 2) ?_ ?_ j
      · intro y eq
        rw [right,left] at eq
        fin_cases x
        · exact (offA y eq).elim
        · exact (offT y eq).elim
      · intro y eq
        rw [right,right] at eq
        fin_cases x <;> fin_cases y <;> simp_all [dif,dif.symm]
  apply six_le_treeNumber_of_ordering ⟨g,inj⟩
  intro i hi
  revert hi
  refine Fin.addCases (m := 4) (n := 2) ?_ ?_ i
  · intro x hx
    have xn : x.val ≠ 0 := fun h => hx (Fin.ext h)
    obtain ⟨y,xy,ylt,only⟩ := rooted x xn
    refine ⟨Fin.castAdd 2 y,?_,ylt,?_⟩
    · change G.Adj (g (Fin.castAdd 2 x)) (g (Fin.castAdd 2 y))
      simpa only [left] using xy
    · intro k
      refine Fin.addCases (m := 4) (n := 2) ?_ ?_ k
      · intro z edge lt
        change G.Adj (g (Fin.castAdd 2 x)) (g (Fin.castAdd 2 z)) at edge
        rw [left,left] at edge
        exact congrArg (Fin.castAdd 2) (only z edge lt)
      · intro z _ lt
        have za := x.isLt
        change 4 + z.val < x.val at lt
        omega
  · intro x _
    fin_cases x
    · refine ⟨0,?_,by decide,?_⟩
      · change G.Adj (g (Fin.natAdd 4 (0 : Fin 2))) (g (Fin.castAdd 2 (0 : Fin 4)))
        rw [left,right]
        exact ra.symm
      · intro k
        refine Fin.addCases (m := 4) (n := 2) ?_ ?_ k
        · intro z edge _
          by_cases ze : z = 0
          · exact congrArg (Fin.castAdd 2) ze
          · change G.Adj (g (Fin.natAdd 4 (0 : Fin 2))) (g (Fin.castAdd 2 z)) at edge
            rw [right,left] at edge
            exact (aOff z ze edge.symm).elim
        · intro z _ lt
          change 4 + z.val < 4 at lt
          omega
    · refine ⟨0,?_,by decide,?_⟩
      · change G.Adj (g (Fin.natAdd 4 (1 : Fin 2))) (g (Fin.castAdd 2 (0 : Fin 4)))
        rw [left,right]
        exact rt.symm
      · intro k
        refine Fin.addCases (m := 4) (n := 2) ?_ ?_ k
        · intro z edge _
          by_cases ze : z = 0
          · exact congrArg (Fin.castAdd 2) ze
          · change G.Adj (g (Fin.natAdd 4 (1 : Fin 2))) (g (Fin.castAdd 2 z)) at edge
            rw [right,left] at edge
            exact (tOff z ze edge.symm).elim
        · intro z edge lt
          change 4 + z.val < 5 at lt
          have zz : z = 0 := Fin.ext (by omega)
          subst z
          change G.Adj (g (Fin.natAdd 4 (1 : Fin 2))) (g (Fin.natAdd 4 (0 : Fin 2))) at edge
          rw [right,right] at edge
          exact (noEdge edge).elim

variable [DecidableEq V] {X Y : Set V} {r a b : V}

theorem ShoreCut.no_four_of_leaves (F : ShoreCut G X Y r a b) {s : V}
    (hs : s ∈ ({r,a,b} : Finset V)) {u v : V} (uY : u ∈ Y) (vY : v ∈ Y)
    (uv : u ≠ v) (ind : ¬ G.Adj u v) (su : G.Adj s u) (sv : G.Adj s v) :
    NoRootedFour G X s := by
  intro f h0 onX rooted
  have off {w : V} (hw : w ∈ Y) (i : Fin 4) : w ≠ f i := by
    intro eq
    by_cases hi : i = 0
    · subst i
      exact F.offY s hs ((eq.trans h0) ▸ hw)
    · exact Set.disjoint_left.mp F.apart (onX i hi) (eq ▸ hw)
  have anti {w : V} (hw : w ∈ Y) (i : Fin 4) (hi : i ≠ 0) : ¬ G.Adj (f i) w :=
    shore_anticomplete F.offY F.boundX F.apart (onX i hi) hw
  have six := six_of_two_leaves f rooted uv (fun e => ind e.symm) (h0.symm ▸ su) (h0.symm ▸ sv)
    (off uY) (off vY) (anti uY) (anti vY)
  have := F.budget
  omega

#print axioms ShoreCut.no_four_of_leaves
end Graffiti199Depleted.Catalogue.Incomplete
