import OppositeComplete

namespace Graffiti199Depleted.Catalogue

open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V]

/-- Keeping at least one vertex unvisited, maximize a path on Q.
Every two vertices left over must then be adjacent if alpha(Q) is at most two. -/
theorem path_and_nonempty_clique_of_no_independent_triple {Q : Set V}
    (two : ∃ x ∈ Q, ∃ y ∈ Q, x ≠ y)
    (triple : ∀ x ∈ Q, ∀ y ∈ Q, ∀ z ∈ Q, x ≠ y → x ≠ z → y ≠ z →
      G.Adj x y ∨ G.Adj x z ∨ G.Adj y z) :
    ∃ S : Set V, S ⊆ Q ∧ Nonempty (PathOn G S) ∧ (Q \ S).Nonempty ∧
      (Q \ S).Pairwise G.Adj := by
  classical
  let Good (S : Finset V) := (↑S : Set V) ⊆ Q ∧ Nonempty (PathOn G (↑S : Set V)) ∧
    ∃ y ∈ Q, y ∉ S
  let family : Finset (Finset V) := Finset.univ.filter Good
  have mem (S : Finset V) : S ∈ family ↔ Good S := by simp [family]
  obtain ⟨u,hu,v,hv,uv⟩ := two
  obtain ⟨init,_,_⟩ := Traverses.single (G := G) u
  have some : family.Nonempty := by
    refine ⟨{u},(mem _).mpr ?_⟩
    exact ⟨by simpa using hu,⟨by simpa using init⟩,v,hv,by simpa using uv.symm⟩
  obtain ⟨S,hs,maximal⟩ := family.exists_max_image Finset.card some
  obtain ⟨sub,⟨p⟩,y,hy,ys⟩ := (mem _).mp hs
  have fst : p.first ∈ S := (p.covers _).mp (List.head_mem p.nonempty)
  refine ⟨↑S,sub,⟨p⟩,⟨y,hy,ys⟩,?_⟩
  intro x hx y hy xy
  have misses {i j : V} (hi : i ∈ Q \ (↑S : Set V)) (hj : j ∈ Q \ (↑S : Set V))
      (diff : i ≠ j) : ¬ G.Adj p.first i := by
    intro edge
    have old : Traverses G (↑S : Set V) p.first p.last := ⟨p,rfl,rfl⟩
    obtain ⟨larger,_,_⟩ := (Traverses.single i).join old (by simpa using hi.2) edge.symm
    have next : insert i S ∈ family := (mem _).mpr ⟨by
      rw [Finset.coe_insert]
      exact Set.insert_subset hi.1 sub,⟨by simpa using larger⟩,
      j,hj.1,by simpa using And.intro diff.symm hj.2⟩
    have bound := maximal _ next
    rw [Finset.card_insert_of_not_mem hi.2] at bound
    omega
  have fx : p.first ≠ x := fun eq => hx.2 (show x ∈ S from eq ▸ fst)
  have fy : p.first ≠ y := fun eq => hy.2 (show y ∈ S from eq ▸ fst)
  rcases triple _ (sub fst) _ hx.1 _ hy.1 fx fy xy with e|e|e
  · exact (misses hx hy xy e).elim
  · exact (misses hy hx xy.symm e).elim
  · exact e

/-- A clique, complete to a contact set of independence number at most two
and size at least two, can be traversed with both ends among the contacts. -/
theorem nonprivate_block_route {Q C : Set V} (apart : Disjoint Q C)
    (two : ∃ x ∈ Q, ∃ y ∈ Q, x ≠ y) (nonempty : C.Nonempty) (clique : C.Pairwise G.Adj)
    (complete : ∀ x ∈ Q, ∀ y ∈ C, G.Adj x y)
    (triple : ∀ x ∈ Q, ∀ y ∈ Q, ∀ z ∈ Q, x ≠ y → x ≠ z → y ≠ z →
      G.Adj x y ∨ G.Adj x z ∨ G.Adj y z) :
    ∃ s ∈ Q, ∃ t ∈ Q, Traverses G (Q ∪ C) s t := by
  classical
  obtain ⟨S,sub,⟨p⟩,⟨u,hu⟩,cl⟩ := path_and_nonempty_clique_of_no_independent_triple two triple
  obtain ⟨z,zc⟩ := nonempty
  obtain ⟨w,wc,middle⟩ := Traverses.start_clique clique zc
  obtain ⟨t,ht,last⟩ := Traverses.start_clique cl hu
  have first : Traverses G S p.first p.last := ⟨p,rfl,rfl⟩
  have ds : Disjoint (S ∪ C) (Q \ S) := by
    apply Set.disjoint_left.mpr
    rintro x (xs|xc) h
    · exact h.2 xs
    · exact Set.disjoint_left.mp apart h.1 xc
  have route := ((first.join middle (apart.mono_left sub) (complete _ (sub p.last_mem) _ zc)).join
    last ds (complete _ hu.1 _ wc).symm)
  have full : (S ∪ C) ∪ (Q \ S) = Q ∪ C := by
    ext x
    simp only [Set.mem_union,Set.mem_diff]
    have sub' : x ∈ S → x ∈ Q := fun h => sub h
    tauto
  exact ⟨p.first,sub ((p.covers _).mp (List.head_mem p.nonempty)),t,ht.1,full ▸ route⟩

#print axioms path_and_nonempty_clique_of_no_independent_triple
#print axioms nonprivate_block_route

end Graffiti199Depleted.Catalogue
