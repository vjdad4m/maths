import ConnectedAlphaTwo

namespace Graffiti199Depleted.Catalogue

open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V]

omit [Fintype V] in
private theorem triple_of_card_bound {Y : Set V}
    (cap : ∀ T : Finset V, (∀ v ∈ T, v ∈ Y) →
      (∀ v ∈ T, ∀ w ∈ T, ¬ G.Adj v w) → T.card ≤ 2)
    {x y z : V} (hx : x ∈ Y) (hy : y ∈ Y) (hz : z ∈ Y)
    (xy : x ≠ y) (xz : x ≠ z) (yz : y ≠ z) : G.Adj x y ∨ G.Adj x z ∨ G.Adj y z := by
  classical
  by_contra! miss
  let T : Finset V := {x,y,z}
  have side (v : V) (hv : v ∈ T) : v ∈ Y := by
    simp only [T,Finset.mem_insert,Finset.mem_singleton] at hv
    rcases hv with rfl|rfl|rfl <;> assumption
  have ind (v : V) (hv : v ∈ T) (w : V) (hw : w ∈ T) : ¬ G.Adj v w := by
    simp only [T,Finset.mem_insert,Finset.mem_singleton] at hv hw
    rcases hv with rfl|rfl|rfl <;> rcases hw with rfl|rfl|rfl <;>
      first | exact G.loopless _ | exact miss.1 | exact miss.2.1 | exact miss.2.2 |
        exact fun h => miss.1 h.symm | exact fun h => miss.2.1 h.symm |
        exact fun h => miss.2.2 h.symm
  have size : T.card = 3 := by simp [T,xy,xz,yz]
  have := cap T side ind
  omega

/-- The complete port can enter a spanning path on the opposite shore whenever
it meets two independent vertices on the first shore. -/
theorem pathOn_opposite_of_complete_port [DecidableEq V]
    {D : Finset V} {X Y : Set V} {a u v : V} (aD : a ∈ D)
    (budget : treeNumber G ≤ 5) (offX : ∀ w ∈ D, w ∉ X) (offY : ∀ w ∈ D, w ∉ Y)
    (boundX : ShoreBoundary G D X) (apart : Disjoint X Y)
    (connY : (G.induce Y).Connected) (complete : ∀ z ∈ Y, G.Adj a z)
    (uX : u ∈ X) (vX : v ∈ X) (uv : u ≠ v) (noEdge : ¬ G.Adj u v)
    (au : G.Adj a u) (av : G.Adj a v) : Nonempty (PathOn G Y) := by
  classical
  let U : Finset V := {u,v}
  have two : 2 ≤ U.card := by simp [U,uv]
  have contacts (w : V) (hw : w ∈ U) : w ∈ shoreContacts G X a := by
    simp only [U,Finset.mem_insert,Finset.mem_singleton] at hw
    rcases hw with rfl|rfl
    · exact ⟨uX,au⟩
    · exact ⟨vX,av⟩
  have ind (w : V) (hw : w ∈ U) (z : V) (hz : z ∈ U) : ¬ G.Adj w z := by
    simp only [U,Finset.mem_insert,Finset.mem_singleton] at hw hz
    rcases hw with rfl|rfl <;> rcases hz with rfl|rfl <;>
      first | exact G.loopless _ | exact noEdge | exact fun h => noEdge h.symm
  apply pathOn_connected_of_no_independent_triple connY
  intro x hx y hy z hz xy xz yz
  exact triple_of_card_bound (fun T hT hstable =>
    card_independent_other_shore_le_two_of_complete_port aD budget offX offY boundX apart
      complete U T two contacts hT ind hstable) hx hy hz xy xz yz

/-- Arbitrary residual neighbors of the distinguished port can be covered
in one interval together with the port, even when they are disconnected. -/
theorem route_residual_with_port {X P : Set V} {r : V} (none : NoRootedFour G X r)
    (within : P ⊆ shoreContacts G X r) :
    Nonempty (PathOn G (insert r P)) := by
  classical
  let root : (insert r P : Set V) := ⟨r,Set.mem_insert r P⟩
  have toRoot (w : (insert r P : Set V)) : (G.induce (insert r P)).Reachable root w := by
    rcases w.property with h|h
    · exact (Subtype.ext h.symm : root = w) ▸ SimpleGraph.Reachable.refl root
    · exact (show (G.induce (insert r P)).Adj root w from (within h).2).reachable
  have conn : (G.induce (insert r P)).Connected := by
    apply (connected_iff_exists_forall_reachable _).mpr
    exact ⟨root,toRoot⟩
  apply pathOn_connected_of_no_independent_triple conn
  intro x hx y hy z hz xy xz yz
  rcases hx with eq|hx
  · subst x
    rcases hy with eq|hy
    · exact (xy eq.symm).elim
    · exact Or.inl (within hy).2
  rcases hy with eq|hy
  · subst y
    exact Or.inl (within hx).2.symm
  rcases hz with eq|hz
  · subst z
    exact Or.inr (Or.inl (within hx).2.symm)
  exact triple_of_card_bound (fun T hT ind => none.card_independent_contacts_le_two T
    (fun v hv => within (hT v hv)) ind) hx hy hz xy xz yz

#print axioms pathOn_opposite_of_complete_port
#print axioms route_residual_with_port

end Graffiti199Depleted.Catalogue
