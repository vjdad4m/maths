import AllPrivateMiddle

namespace Graffiti199Depleted.Catalogue
open SimpleGraph

variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X Y : Set V} {r a b p q : V}

/-- If two private components occur on one shore and another cut vertex is
complete to the opposite shore, the whole graph has a spanning path.
The number and sizes of all additional components are unrestricted. -/
theorem traceable_of_two_private_components_complete_opposite
    (conn : ConnectivityAtLeast G 3) (budget : treeNumber G ≤ 5)
    (ra : r ≠ a) (rb : r ≠ b) (ab : a ≠ b)
    (offX : ∀ w ∈ ({r,a,b} : Finset V), w ∉ X)
    (offY : ∀ w ∈ ({r,a,b} : Finset V), w ∉ Y)
    (boundX : ShoreBoundary G {r,a,b} X) (boundY : ShoreBoundary G {r,a,b} Y)
    (apart : Disjoint X Y) (cover : ∀ v, v ∈ X ∨ v ∈ Y ∨ v = r ∨ v = a ∨ v = b)
    (connX : (G.induce X).Connected) (connY : (G.induce Y).Connected)
    (aComplete : ∀ z ∈ Y, G.Adj a z) (rMiss : ∃ z ∈ Y, ¬ G.Adj r z)
    (c d : (G.induce (Noncontacts G X r)).ConnectedComponent) (cd : c ≠ d)
    (pc : p ∈ rootedBlockContacts G X r c) (qd : q ∈ rootedBlockContacts G X r d)
    (oneC : ∀ s ∈ rootedBlockContacts G X r c, s = p)
    (oneD : ∀ s ∈ rootedBlockContacts G X r d, s = q) : Traceable G := by
  classical
  let D : Finset V := {r,a,b}
  have size : D.card = 3 := by simp [D,ra,rb,ab]
  have rD : r ∈ D := by simp [D]
  have aD : a ∈ D := by simp [D]
  have bD : b ∈ D := by simp [D]
  let I := (G.induce (Noncontacts G X r)).ConnectedComponent
  let Q (i : I) := rootedBlockContacts G X r i
  have many (i : I) (ic : i ≠ c) (id' : i ≠ d) :
      ∃ x ∈ Q i, ∃ y ∈ Q i, x ≠ y := by
    have some : (shoreContacts G X r).Nonempty := ⟨p,pc.1,pc.2.1⟩
    obtain ⟨s,hs⟩ := rootedBlockContacts_nonempty connX some i
    by_contra missing
    have unique (y : V) (hy : y ∈ Q i) : y = s :=
      Classical.byContradiction fun ne => missing ⟨y,hy,s,hs,ne⟩
    let f : Fin 3 ↪ I := ⟨![c,d,i],by
      intro j k h
      fin_cases j <;> fin_cases k
      · rfl
      · exact (cd h).elim
      · exact (ic h.symm).elim
      · exact (cd h.symm).elim
      · rfl
      · exact (id' h.symm).elim
      · exact (ic h).elim
      · exact (id' h).elim
      · rfl⟩
    let g : Fin 3 → V := ![p,q,s]
    have rg (j : Fin 3) : G.Adj r (g j) := by
      fin_cases j
      · exact pc.2.1
      · exact qd.2.1
      · exact hs.2.1
    have singles (j : Fin 3) (z : V) (zx : z ∈ X) (rz : G.Adj r z)
        (touch : ∃ u ∈ noncontactComponent G X r (f j), G.Adj u z) : z = g j := by
      obtain ⟨u,hu,uz⟩ := touch
      fin_cases j
      · exact oneC _ ⟨zx,rz,u,hu,uz.symm⟩
      · exact oneD _ ⟨zx,rz,u,hu,uz.symm⟩
      · exact unique _ ⟨zx,rz,u,hu,uz.symm⟩
    have bound := private_components_le_two budget conn size offX offY boundX boundY apart
      connY rD aD bD ra (fun w hw => by simpa [D] using hw) rMiss f g rg singles
    omega
  have none := no_rooted_four_across_cut conn budget size offY boundX boundY apart connY rD rMiss
  exact traceable_of_private_middle_interval conn budget ra rb ab offX offY boundX boundY apart
    cover connY aComplete rMiss c d cd pc qd oneC oneD
      (private_middle_from_all_nonprivate none (offX r rD) c d pc qd many)

#print axioms traceable_of_two_private_components_complete_opposite
end Graffiti199Depleted.Catalogue
