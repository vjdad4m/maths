import PointedSplit
open private interval_insert from BlockConcatenation

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V I : Type*} {G : SimpleGraph V} [DecidableEq I]

theorem concatenate_from {B₀ E₀ : Set V} {B E : I → Set V} (T : Finset I) {s : V}
    (initial : ∃ t ∈ E₀, Traverses G B₀ s t)
    (routes : ∀ i ∈ T, ∃ u ∈ E i, ∃ t ∈ E i, Traverses G (B i) u t)
    (dis₀ : ∀ i ∈ T, Disjoint B₀ (B i))
    (dis : ∀ i ∈ T, ∀ j ∈ T, i ≠ j → Disjoint (B i) (B j))
    (join₀ : ∀ i ∈ T, ∀ u ∈ E₀, ∀ t ∈ E i, G.Adj u t)
    (cross : ∀ i ∈ T, ∀ j ∈ T, i ≠ j → ∀ u ∈ E i, ∀ t ∈ E j, G.Adj u t) :
    ∃ t ∈ intervalUnion E₀ E T, Traverses G (intervalUnion B₀ B T) s t := by
  induction T using Finset.induction_on with
  | empty => simpa [intervalUnion] using initial
  | @insert i T iT ih =>
    have sub := Finset.subset_insert i T
    have hi := Finset.mem_insert_self i T
    obtain ⟨t,ht,P⟩ := ih (fun j hj => routes j (sub hj))
      (fun j hj => dis₀ j (sub hj)) (fun j hj k hk => dis j (sub hj) k (sub hk))
      (fun j hj => join₀ j (sub hj)) (fun j hj k hk => cross j (sub hj) k (sub hk))
    obtain ⟨u,hu,v,hv,L⟩ := routes i hi
    have D : Disjoint (intervalUnion B₀ B T) (B i) := by
      apply Set.disjoint_left.mpr
      rintro x (h|⟨j,hj,h⟩) k
      · exact Set.disjoint_left.mp (dis₀ i hi) h k
      · exact Set.disjoint_left.mp (dis j (sub hj) i hi (fun eq => iT (eq ▸ hj))) h k
    have edge : G.Adj t u := by
      rcases ht with h|⟨j,hj,h⟩
      · exact join₀ i hi _ h _ hu
      · exact cross j (sub hj) i hi (fun eq => iT (eq ▸ hj)) _ h _ hu
    rw [interval_insert,interval_insert]
    exact ⟨v,Or.inr hv,P.join L D edge⟩

/-- Route from any prescribed vertex of any block with at least two contacts.
The outside interval separates the pieces when the start lies in the clique. -/
theorem pointed_family [Fintype V] (T : Finset I) (Z : Set V) (Q C : I → Set V)
    (base : ∃ s ∈ Z, ∃ t ∈ Z, Traverses G Z s t)
    (two : ∀ i ∈ T, ∃ x ∈ Q i, ∃ y ∈ Q i, x ≠ y)
    (neC : ∀ i ∈ T, (C i).Nonempty) (cl : ∀ i ∈ T, (C i).Pairwise G.Adj)
    (qc : ∀ i ∈ T, Disjoint (Q i) (C i))
    (complete : ∀ i ∈ T, ∀ x ∈ Q i, ∀ y ∈ C i, G.Adj x y)
    (triple : ∀ i ∈ T, Triple G (Q i))
    (dz : ∀ i ∈ T, Disjoint Z (Q i ∪ C i))
    (db : ∀ i ∈ T, ∀ j ∈ T, i ≠ j → Disjoint (Q i ∪ C i) (Q j ∪ C j))
    (ez : ∀ i ∈ T, ∀ x ∈ Z, ∀ y ∈ Q i, G.Adj x y)
    (eb : ∀ i ∈ T, ∀ j ∈ T, i ≠ j → ∀ x ∈ Q i, ∀ y ∈ Q j, G.Adj x y)
    (z : V) (start : (∃ t ∈ Z, Traverses G Z z t) ∨ ∃ i ∈ T, z ∈ Q i ∪ C i) :
    ∃ t, Traverses G (intervalUnion Z (fun i => Q i ∪ C i) T) z t := by
  let B (i : I) := Q i ∪ C i
  have localRoute (i : I) (hi : i ∈ T) : ∃ x ∈ Q i, ∃ t ∈ Q i, Traverses G (B i) x t :=
    nonprivate_block_route (qc i hi) (two i hi) (neC i hi) (cl i hi) (complete i hi) (triple i hi)
  rcases start with init|⟨i,hi,zi⟩
  · obtain ⟨t,_,path⟩ := concatenate_from T init localRoute dz db ez eb
    exact ⟨t,path⟩
  let U := T.erase i
  have sub : U ⊆ T := Finset.erase_subset i T
  obtain ⟨s,hs,t,ht,M⟩ := concatenate_contact_intervals U base
    (fun j hj => localRoute j (sub hj)) (fun j hj => dz j (sub hj))
    (fun j hj k hk => db j (sub hj) k (sub hk)) (fun j hj => ez j (sub hj))
    (fun j hj k hk => eb j (sub hj) k (sub hk))
  have away : Disjoint (B i) (intervalUnion Z B U) := by
    apply Set.disjoint_left.mpr
    rintro v h (h'|⟨j,hj,h'⟩)
    · exact Set.disjoint_left.mp (dz i hi) h' h
    · exact Set.disjoint_left.mp (db j (sub hj) i hi (Finset.mem_erase.mp hj).1) h' h
  have toBlock {u v : V} (hu : u ∈ intervalUnion Z Q U) (hv : v ∈ Q i) : G.Adj u v := by
    rcases hu with h|⟨j,hj,h⟩
    · exact ez i hi u h v hv
    · exact eb j (sub hj) i hi (Finset.mem_erase.mp hj).1 _ h _ hv
  have full : B i ∪ intervalUnion Z B U = intervalUnion Z B T := by
    rw [Set.union_comm,← interval_insert,Finset.insert_erase hi]
  rcases zi with zq|zc
  · obtain ⟨w,hw,L⟩ := pointed_contact_route zq (qc i hi) (two i hi) (neC i hi) (cl i hi)
      (complete i hi) (triple i hi)
    exact ⟨t,full ▸ (L.join M away (toBlock hs hw).symm)⟩
  · obtain ⟨w,L⟩ := pointed_noncontact_around zc (qc i hi) (two i hi) (cl i hi)
      (complete i hi) (triple i hi) M away (fun _ h => (toBlock hs h).symm) (fun _ h => toBlock ht h)
    exact ⟨w,full ▸ L⟩

#print axioms pointed_family
end Graffiti199Depleted.Catalogue.Incomplete
