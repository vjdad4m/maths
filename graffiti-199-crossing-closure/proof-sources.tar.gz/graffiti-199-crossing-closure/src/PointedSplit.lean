import PrivateCutFrame

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] {Q C : Set V} {z : V}

def Triple (G : SimpleGraph V) (Q : Set V) : Prop :=
  ∀ x ∈ Q, ∀ y ∈ Q, ∀ t ∈ Q, x ≠ y → x ≠ t → y ≠ t → G.Adj x y ∨ G.Adj x t ∨ G.Adj y t

/-- Maximizing a proper path starting at z leaves a nonempty clique. -/
theorem pointed_split (hz : z ∈ Q) (extra : ∃ v ∈ Q, v ≠ z) (triple : Triple G Q) :
    ∃ S ⊆ Q, ∃ e ∈ S, Traverses G S z e ∧ (Q \ S).Nonempty ∧ (Q \ S).Pairwise G.Adj := by
  classical
  let good (S : Finset V) := (↑S : Set V) ⊆ Q ∧ (∃ e, Traverses G (↑S : Set V) z e) ∧
    ∃ i ∈ Q, i ∉ S
  let U := Finset.univ.filter good
  have mem (S : Finset V) : S ∈ U ↔ good S := by simp [U]
  obtain ⟨v,hv,vz⟩ := extra
  have init : U.Nonempty := by
    refine ⟨{z},(mem _).mpr ⟨by simpa using hz,⟨z,?_⟩,v,hv,by simpa using vz⟩⟩
    simpa using (Traverses.single (G := G) z)
  obtain ⟨S,hs,maximal⟩ := U.exists_max_image Finset.card init
  obtain ⟨sub,⟨e,path⟩,v,hv,vS⟩ := (mem _).mp hs
  have eS : e ∈ S := by obtain ⟨p,_,hl⟩ := path; exact hl ▸ p.last_mem
  refine ⟨↑S,sub,e,eS,path,⟨v,hv,vS⟩,?_⟩
  intro u hu v hv uv
  have misses {i j : V} (hi : i ∈ Q \ (↑S : Set V)) (hj : j ∈ Q \ (↑S : Set V))
      (ne : i ≠ j) : ¬ G.Adj e i := by
    intro edge
    have next := path.join (Traverses.single i) (by simpa using hi.2) edge
    have adm : insert i S ∈ U := (mem _).mpr ⟨by rw [Finset.coe_insert]; exact Set.insert_subset hi.1 sub,
      ⟨i,by simpa [Set.union_comm] using next⟩,j,hj.1,by simpa using And.intro ne.symm hj.2⟩
    have bound := maximal _ adm
    rw [Finset.card_insert_of_not_mem hi.2] at bound
    omega
  have eu : e ≠ u := fun h => hu.2 (show u ∈ S from h ▸ eS)
  have ev : e ≠ v := fun h => hv.2 (show v ∈ S from h ▸ eS)
  exact (triple _ (sub eS) _ hu.1 _ hv.1 eu ev uv).resolve_left (misses hu hv uv)
    |>.resolve_left (misses hv hu uv.symm)

omit [Fintype V] in
private theorem has_other {Q : Set V} (two : ∃ x ∈ Q, ∃ y ∈ Q, x ≠ y) (z : V) :
    ∃ w ∈ Q, w ≠ z := by
  obtain ⟨x,hx,y,hy,xy⟩ := two
  by_cases xz : x = z
  · exact ⟨y,hy,fun h => xy (xz.trans h.symm)⟩
  · exact ⟨x,hx,xz⟩

/-- An arbitrary specified vertex of Q can start the block path. -/
theorem pointed_contact_route (zQ : z ∈ Q) (apart : Disjoint Q C)
    (two : ∃ x ∈ Q, ∃ y ∈ Q, x ≠ y) (neC : C.Nonempty) (cl : C.Pairwise G.Adj)
    (complete : ∀ x ∈ Q, ∀ y ∈ C, G.Adj x y) (triple : Triple G Q) :
    ∃ t ∈ Q, Traverses G (Q ∪ C) z t := by
  obtain ⟨S,sub,e,he,L,⟨u,hu⟩,cl'⟩ := pointed_split zQ (has_other two z) triple
  obtain ⟨v,vC⟩ := neC
  obtain ⟨w,wC,M⟩ := Traverses.start_clique cl vC
  obtain ⟨t,ht,R⟩ := Traverses.start_clique cl' hu
  have dis : Disjoint (S ∪ C) (Q \ S) := Set.disjoint_left.mpr (by
    rintro v (h|h) k
    · exact k.2 h
    · exact Set.disjoint_left.mp apart k.1 h)
  have route := (L.join M (apart.mono_left sub) (complete _ (sub he) _ vC)).join R dis
    (complete _ hu.1 _ wC).symm
  have full : (S ∪ C) ∪ (Q \ S) = Q ∪ C := by rw [Set.union_right_comm,Set.union_diff_cancel sub]
  exact ⟨t,ht.1,full ▸ route⟩

/-- With no demands on the far endpoint, a universal root permits any
ordinary vertex to start a residual interval of independence number at most two. -/
theorem pointed_residual {r : V} (zQ : z ∈ Q) (off : r ∉ Q)
    (root : ∀ v ∈ Q, G.Adj r v) (triple : Triple G Q) :
    ∃ t ∈ insert r Q, Traverses G (insert r Q) z t := by
  classical
  by_cases extra : ∃ v ∈ Q, v ≠ z
  · obtain ⟨v,hv,vz⟩ := extra
    obtain ⟨t,ht,L⟩ := pointed_contact_route zQ (C := {r}) (by simpa using off)
      ⟨v,hv,z,zQ,vz⟩ (Set.singleton_nonempty _) (Set.pairwise_singleton ..)
        (fun x hx y hy => (show y = r from hy).symm ▸ (root _ hx).symm) triple
    exact ⟨t,Or.inr ht,by simpa [Set.union_comm] using L⟩
  · have eq : Q = {z} := Set.Subset.antisymm
      (fun v hv => Classical.byContradiction fun h => extra ⟨v,hv,h⟩) (Set.singleton_subset_iff.mpr zQ)
    have dis : Disjoint ({z} : Set V) {r} := by simpa [← eq] using off
    have route := (Traverses.single z).join (Traverses.single r) dis (root _ zQ).symm
    exact ⟨r,Set.mem_insert _ _,by simpa [eq,Set.union_comm] using route⟩

/-- A specified start in C can use an outside interval between two
contact paths even when Q is disconnected. -/
theorem pointed_noncontact_around {M : Set V} {s t : V} (zC : z ∈ C) (apart : Disjoint Q C)
    (two : ∃ x ∈ Q, ∃ y ∈ Q, x ≠ y) (cl : C.Pairwise G.Adj)
    (complete : ∀ x ∈ Q, ∀ y ∈ C, G.Adj x y) (triple : Triple G Q)
    (middle : Traverses G M s t) (disM : Disjoint (Q ∪ C) M)
    (enters : ∀ x ∈ Q, G.Adj x s) (exits : ∀ x ∈ Q, G.Adj t x) :
    ∃ v, Traverses G ((Q ∪ C) ∪ M) z v := by
  obtain ⟨S,sub,⟨P⟩,⟨w,hw⟩,cl'⟩ := path_and_nonempty_clique_of_no_independent_triple two triple
  obtain ⟨u,hu,L⟩ := Traverses.start_clique cl zC
  obtain ⟨v,hv,R⟩ := Traverses.start_clique cl' hw
  have fst : P.first ∈ S := (P.covers _).mp (List.head_mem P.nonempty)
  have d₁ := (apart.mono_left sub).symm
  have d₂ : Disjoint (C ∪ S) M := disM.mono_left (by
    rintro _ (h|h)
    · exact Or.inr h
    · exact Or.inl (sub h))
  have d₃ : Disjoint ((C ∪ S) ∪ M) (Q \ S) := by
    apply Set.disjoint_left.mpr
    rintro x ((h|h)|h) k
    · exact Set.disjoint_left.mp apart k.1 h
    · exact k.2 h
    · exact Set.disjoint_left.mp disM (Or.inl k.1) h
  have path := ((L.join (show Traverses G S P.first P.last from ⟨P,rfl,rfl⟩) d₁
    (complete _ (sub fst) _ hu).symm).join middle d₂ (enters _ (sub P.last_mem))).join R d₃ (exits _ hw.1)
  have eq : ((C ∪ S) ∪ M) ∪ (Q \ S) = (Q ∪ C) ∪ M := by
    rw [Set.union_right_comm (C ∪ S),Set.union_assoc C,Set.union_diff_cancel sub,Set.union_comm C]
  exact ⟨v,eq ▸ path⟩

#print axioms pointed_split
#print axioms pointed_noncontact_around
end Graffiti199Depleted.Catalogue.Incomplete
