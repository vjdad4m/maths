import OppositeComplete

namespace Graffiti199Depleted.Catalogue

open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} {X : Set V} {r : V}

theorem noncontactComponent_subset (c : (G.induce (Noncontacts G X r)).ConnectedComponent) :
    noncontactComponent G X r c ⊆ Noncontacts G X r := by
  rintro _ ⟨w,_,rfl⟩
  exact w.property

theorem noncontactComponents_apart {c d : (G.induce (Noncontacts G X r)).ConnectedComponent}
    (ne : c ≠ d) : Disjoint (noncontactComponent G X r c) (noncontactComponent G X r d) := by
  apply Set.disjoint_left.mpr
  rintro _ ⟨x,hx,rfl⟩ ⟨y,hy,eq⟩
  exact ne (ConnectedComponent.eq_of_common_vertex hx ((Subtype.ext eq : y = x) ▸ hy))

theorem noncontactComponents_anticomplete {c d : (G.induce (Noncontacts G X r)).ConnectedComponent}
    (ne : c ≠ d) {u v : V} (hu : u ∈ noncontactComponent G X r c)
    (hv : v ∈ noncontactComponent G X r d) : ¬ G.Adj u v := by
  obtain ⟨x,hx,rfl⟩ := hu
  obtain ⟨y,hy,rfl⟩ := hv
  intro edge
  have step : (G.induce (Noncontacts G X r)).Adj x y := edge
  exact ne (ConnectedComponent.eq_of_common_vertex ((c.mem_supp_congr_adj step).mp hx) hy)

theorem ports_meet_private_component [Fintype V] [DecidableEq V] {a b p : V}
    (conn : ConnectivityAtLeast G 3) (bound : ShoreBoundary G {r,a,b} X)
    (off : ∀ d ∈ ({r,a,b} : Finset V), d ∉ X)
    (c : (G.induce (Noncontacts G X r)).ConnectedComponent)
    (hp : p ∈ rootedBlockContacts G X r c)
    (unique : ∀ q ∈ rootedBlockContacts G X r c, q = p) :
    (∃ u ∈ noncontactComponent G X r c, G.Adj a u) ∧
    (∃ v ∈ noncontactComponent G X r c, G.Adj b v) := by
  let C := noncontactComponent G X r c
  have inside := noncontactComponent_subset c
  let T : Finset V := {a,b,p}
  have boundary : ShoreBoundary G T C := by
    intro u hu v hv uv
    by_cases vX : v ∈ X
    · by_cases rv : G.Adj r v
      · have eq := unique _ ⟨vX,rv,u,hu,uv.symm⟩
        simp [T,eq]
      obtain ⟨u',us,rfl⟩ := hu
      let v' : Noncontacts G X r := ⟨v,vX,rv⟩
      have edge : (G.induce (Noncontacts G X r)).Adj u' v' := uv
      exact (hv ⟨v',(c.mem_supp_congr_adj edge).mp us,rfl⟩).elim
    have cut := bound _ (inside hu).1 _ vX uv
    simp only [Finset.mem_insert,Finset.mem_singleton] at cut
    rcases cut with rfl|rfl|rfl
    · exact ((inside hu).2 uv.symm).elim
    · simp [T]
    · simp [T]
  have outside (v : V) (hv : v ∈ T) (h : v ∈ C) : False := by
    simp only [T,Finset.mem_insert,Finset.mem_singleton] at hv
    rcases hv with rfl|rfl|rfl
    · exact off _ (by simp) (inside h).1
    · exact off _ (by simp) (inside h).1
    · exact (inside h).2 hp.2.1
  have size : T.card ≤ 3 := by
    have e := Finset.card_insert_le a ({b,p} : Finset V)
    have f := Finset.card_insert_le b ({p} : Finset V)
    simp only [Finset.card_singleton] at f
    unfold T
    omega
  obtain ⟨u,hu⟩ := c.nonempty_supp
  have nonempty : C.Nonempty := ⟨u.val,u,hu,rfl⟩
  exact ⟨contact_of_shore conn size outside boundary nonempty (by simp [T]),
    contact_of_shore conn size outside boundary nonempty (by simp [T])⟩

#print axioms ports_meet_private_component

end Graffiti199Depleted.Catalogue
