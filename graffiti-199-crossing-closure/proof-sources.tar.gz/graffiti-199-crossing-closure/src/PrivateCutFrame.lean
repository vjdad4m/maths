import OppositeCompleteSplice

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph

variable {V : Type*} {G : SimpleGraph V} {X Y : Set V} {r a b : V}

/-- Two distinct components, each with a unique neighbor among the root's contacts. -/
structure PrivatePair (G : SimpleGraph V) (X : Set V) (r : V) where
  c : (G.induce (Noncontacts G X r)).ConnectedComponent
  d : (G.induce (Noncontacts G X r)).ConnectedComponent
  different : c ≠ d
  p : V
  q : V
  pc : p ∈ rootedBlockContacts G X r c
  qd : q ∈ rootedBlockContacts G X r d
  oneC : ∀ s ∈ rootedBlockContacts G X r c, s = p
  oneD : ∀ s ∈ rootedBlockContacts G X r d, s = q

structure ShoreCut (G : SimpleGraph V) [Fintype V] [DecidableEq V] (X Y : Set V) (r a b : V) : Prop where
  conn : ConnectivityAtLeast G 3
  budget : treeNumber G ≤ 5
  ra : r ≠ a
  rb : r ≠ b
  ab : a ≠ b
  offX : ∀ w ∈ ({r,a,b} : Finset V), w ∉ X
  offY : ∀ w ∈ ({r,a,b} : Finset V), w ∉ Y
  boundX : ShoreBoundary G {r,a,b} X
  boundY : ShoreBoundary G {r,a,b} Y
  apart : Disjoint X Y
  cover : ∀ v, v ∈ X ∨ v ∈ Y ∨ v = r ∨ v = a ∨ v = b
  connX : (G.induce X).Connected
  connY : (G.induce Y).Connected

variable [Fintype V] [DecidableEq V]

theorem ShoreCut.size (F : ShoreCut G X Y r a b) : ({r,a,b} : Finset V).card = 3 := by
  simp [F.ra,F.rb,F.ab]

theorem ShoreCut.swap (F : ShoreCut G X Y r a b) : ShoreCut G Y X r a b :=
  ⟨F.conn,F.budget,F.ra,F.rb,F.ab,F.offY,F.offX,F.boundY,F.boundX,F.apart.symm,
    fun v => by have := F.cover v; tauto,F.connY,F.connX⟩

theorem ShoreCut.no_four (F : ShoreCut G X Y r a b) {s : V} (hs : s ∈ ({r,a,b} : Finset V))
    (miss : ∃ y ∈ Y, ¬ G.Adj s y) : NoRootedFour G X s :=
  no_rooted_four_across_cut F.conn F.budget F.size F.offY F.boundX F.boundY F.apart F.connY hs miss

theorem ShoreCut.contact (F : ShoreCut G X Y r a b) {s : V} (hs : s ∈ ({r,a,b} : Finset V)) :
    ∃ x ∈ X, G.Adj s x := by
  obtain ⟨x⟩ := F.connX.nonempty
  exact contact_of_shore F.conn F.size.le F.offX F.boundX ⟨x.val,x.property⟩ hs

omit [Fintype V] [DecidableEq V] in
theorem sole_exit {s p : V} (c : (G.induce (Noncontacts G X s)).ConnectedComponent)
    (one : ∀ w ∈ rootedBlockContacts G X s c, w = p) {u z : V}
    (hu : u ∈ noncontactComponent G X s c) (zx : z ∈ X)
    (out : z ∉ noncontactComponent G X s c) (edge : G.Adj u z) : z = p := by
  by_cases sz : G.Adj s z
  · exact one _ ⟨zx,sz,u,hu,edge.symm⟩
  obtain ⟨w,hw,rfl⟩ := hu
  let z' : Noncontacts G X s := ⟨z,zx,sz⟩
  have adj : (G.induce (Noncontacts G X s)).Adj w z' := edge
  exact (out ⟨z',(c.mem_supp_congr_adj adj).mp hw,rfl⟩).elim

end Graffiti199Depleted.Catalogue.Incomplete
