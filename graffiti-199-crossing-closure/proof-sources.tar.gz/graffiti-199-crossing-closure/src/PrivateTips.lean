import WideShore

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] {X : Set V} {r p q : V}

private theorem tip {c : (G.induce (Noncontacts G X r)).ConnectedComponent}
    (none : NoRootedFour G X r) (off : r ∉ X) (pc : p ∈ rootedBlockContacts G X r c)
    {s : V} (sc : s ∈ noncontactComponent G X r c) :
    Traverses G (insert p (noncontactComponent G X r c)) s p := by
  obtain ⟨w,hw,pw⟩ := pc.2.2
  obtain ⟨t,ht,L⟩ := Traverses.start_clique (none.clique_of_contact off c pc.1 pc.2.1 hw pw) sc
  have out : p ∉ noncontactComponent G X r c := fun h => (noncontactComponent_subset c h).2 pc.2.1
  have R := L.join (Traverses.single p) (by simpa using out)
    (none.contact_common_on_component off c pc.1 pc.2.1 hw ht pw).symm
  simpa [Set.union_comm] using R

omit [Fintype V] in
private theorem exit_edge {c : (G.induce (Noncontacts G X r)).ConnectedComponent}
    (none : NoRootedFour G X r) (off : r ∉ X) (pc : p ∈ rootedBlockContacts G X r c)
    (one : ∀ u ∈ rootedBlockContacts G X r c, u = p)
    {s : V} (hs : s ∈ insert r {v | v ∈ shoreContacts G X r ∧ v ≠ p}) : G.Adj p s := by
  rcases hs with eq|hs
  · exact eq.symm ▸ pc.2.1.symm
  obtain ⟨w,hw,pw⟩ := pc.2.2
  exact none.cross_contacts_complete off pc.1 hs.1.1 (noncontactComponent_subset c hw)
    pc.2.1 hs.1.2 pw (fun sw => hs.2 (one _ ⟨hs.1.1,hs.1.2,w,hw,sw⟩))

theorem start_single_private (none : NoRootedFour G X r) (off : r ∉ X)
    (c : (G.induce (Noncontacts G X r)).ConnectedComponent) (pc : p ∈ rootedBlockContacts G X r c)
    (one : ∀ u ∈ rootedBlockContacts G X r c, u = p)
    (wide : ∀ i : (G.induce (Noncontacts G X r)).ConnectedComponent, i ≠ c →
      ∃ u ∈ rootedBlockContacts G X r i, ∃ v ∈ rootedBlockContacts G X r i, u ≠ v)
    {s : V} (sc : s ∈ noncontactComponent G X r c) : ∃ e, Traverses G (insert r X) s e := by
  let C := noncontactComponent G X r c
  let M : Set V := insert r {v | v ∈ X ∧ v ∉ C ∧ v ∉ C ∧ v ≠ p ∧ v ≠ p}
  obtain ⟨u,hu,v,_,mid⟩ := private_middle_from_all_nonprivate none off c c pc pc (fun i h _ => wide i h)
  have part : Disjoint (insert p C) M := by
    apply Set.disjoint_left.mpr
    rintro z (eq|hc) (er|hz)
    · exact off ((eq.symm.trans er) ▸ pc.1)
    · exact hz.2.2.2.1 eq
    · exact off (er ▸ (noncontactComponent_subset c hc).1)
    · exact hz.2.1 hc
  have edge : G.Adj p u := exit_edge none off pc one (by
    rcases hu with h|h
    · exact Or.inl h
    · exact Or.inr ⟨h.1,h.2.1⟩)
  have route := (tip none off pc sc).join mid part edge
  have eq : insert p C ∪ M = insert r X := by
    ext z
    constructor
    · rintro ((e|hc)|(e|h))
      · exact Or.inr (e.symm ▸ pc.1)
      · exact Or.inr (noncontactComponent_subset c hc).1
      · exact Or.inl e
      · exact Or.inr h.1
    · rintro (eq|zx)
      · exact Or.inr (Or.inl eq)
      by_cases zp : z = p
      · exact Or.inl (Or.inl zp)
      by_cases zc : z ∈ C
      · exact Or.inl (Or.inr zc)
      exact Or.inr (Or.inr ⟨zx,zc,zc,zp,zp⟩)
  exact ⟨v,eq ▸ route⟩

theorem start_double_private (H : PrivatePair G X r) (none : NoRootedFour G X r) (off : r ∉ X)
    (wide : ∀ i : (G.induce (Noncontacts G X r)).ConnectedComponent, i ≠ H.c → i ≠ H.d →
      ∃ u ∈ rootedBlockContacts G X r i, ∃ v ∈ rootedBlockContacts G X r i, u ≠ v)
    {s t : V} (sc : s ∈ noncontactComponent G X r H.c) (td : t ∈ noncontactComponent G X r H.d) :
    Traverses G (insert r X) s t := by
  let C := noncontactComponent G X r H.c
  let E := noncontactComponent G X r H.d
  let M : Set V := insert r {v | v ∈ X ∧ v ∉ C ∧ v ∉ E ∧ v ≠ H.p ∧ v ≠ H.q}
  have pq : H.p ≠ H.q := fun e => Set.disjoint_left.mp (none.blockContacts_disjoint off H.different)
    H.pc (e.symm ▸ H.qd)
  obtain ⟨u,hu,v,hv,mid⟩ := private_middle_from_all_nonprivate none off H.c H.d H.pc H.qd wide
  have dis₁ : Disjoint (insert H.p C) M := by
    apply Set.disjoint_left.mpr
    rintro z (eq|hc) (er|hz)
    · exact off ((eq.symm.trans er) ▸ H.pc.1)
    · exact hz.2.2.2.1 eq
    · exact off (er ▸ (noncontactComponent_subset H.c hc).1)
    · exact hz.2.1 hc
  have ce := noncontactComponents_apart H.different
  have dis₂ : Disjoint (insert H.p C ∪ M) (insert H.q E) := by
    apply Set.disjoint_left.mpr
    rintro z ((e|h)|(er|k)) (eq|hd)
    · exact pq (e.symm.trans eq)
    · exact (noncontactComponent_subset H.d hd).2 (e.symm ▸ H.pc.2.1)
    · exact (noncontactComponent_subset H.c h).2 (eq.symm ▸ H.qd.2.1)
    · exact Set.disjoint_left.mp ce h hd
    · exact off ((eq.symm.trans er) ▸ H.qd.1)
    · exact off (er ▸ (noncontactComponent_subset H.d hd).1)
    · exact k.2.2.2.2 eq
    · exact k.2.2.1 hd
  have edge₁ := exit_edge none off H.pc H.oneC (s := u) (by
    rcases hu with h|h
    · exact Or.inl h
    · exact Or.inr ⟨h.1,h.2.1⟩)
  have edge₂ := exit_edge none off H.qd H.oneD (s := v) (by
    rcases hv with h|h
    · exact Or.inl h
    · exact Or.inr ⟨h.1,h.2.2⟩)
  have route := ((tip none off H.pc sc).join mid dis₁ edge₁).join
    (tip none off H.qd td).reverse dis₂ edge₂.symm
  have eq : (insert H.p C ∪ M) ∪ insert H.q E = insert r X := by
    ext z
    constructor
    · rintro (((e|h)|(er|k))|(e|h))
      · exact Or.inr (e.symm ▸ H.pc.1)
      · exact Or.inr (noncontactComponent_subset H.c h).1
      · exact Or.inl er
      · exact Or.inr k.1
      · exact Or.inr (e.symm ▸ H.qd.1)
      · exact Or.inr (noncontactComponent_subset H.d h).1
    · rintro (er|zx)
      · exact Or.inl (Or.inr (Or.inl er))
      by_cases zp : z = H.p
      · exact Or.inl (Or.inl (Or.inl zp))
      by_cases zq : z = H.q
      · exact Or.inr (Or.inl zq)
      by_cases zc : z ∈ C
      · exact Or.inl (Or.inl (Or.inr zc))
      by_cases zd : z ∈ E
      · exact Or.inr (Or.inr zd)
      exact Or.inl (Or.inr (Or.inr ⟨zx,zc,zd,zp,zq⟩))
  exact eq ▸ route

#print axioms start_single_private
#print axioms start_double_private
end Graffiti199Depleted.Catalogue.Incomplete
