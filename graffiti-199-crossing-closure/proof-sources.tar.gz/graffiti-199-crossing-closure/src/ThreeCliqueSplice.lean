import ComponentBudget

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]

omit [DecidableEq V] in
private theorem through_large_clique {D : Finset V} {X : Set V} (cl : X.Pairwise G.Adj)
    (f : ↥D ↪ X) (e : ∀ p : D, G.Adj p.val (f p).val) {p q : V}
    (hp : p ∈ D) (hq : q ∈ D) (dif : p ≠ q) :
    ∃ s t, G.Adj p s ∧ G.Adj q t ∧ Traverses G X s t := by
  let P : D := ⟨p,hp⟩
  let Q : D := ⟨q,hq⟩
  exact ⟨_,_,e P,e Q,Traverses.clique cl (f P).property (f Q).property
    (fun eq => dif (congrArg Subtype.val (f.injective (Subtype.ext eq))))⟩

/-- Three clique components admit an explicit Hamiltonian path. The first
two components have order at least three, so Hall supplies distinct contacts
for the two ports used at each of their prescribed ends. -/
theorem three_clique_route (F : LargeCrossingFailure G) (conn : ConnectivityAtLeast G 3)
    (C : (DeletionGraph G F.cut).ConnectedComponent) (ca : C ≠ F.first) (cb : C ≠ F.second)
    (only : ∀ J, J = F.first ∨ J = F.second ∨ J = C)
    (clA : (componentShore F.cut F.first).Pairwise G.Adj)
    (clB : (componentShore F.cut F.second).Pairwise G.Adj)
    (clC : (componentShore F.cut C).Pairwise G.Adj) : Traceable G := by
  classical
  let X := componentShore F.cut F.first
  let Y := componentShore F.cut F.second
  let Z := componentShore F.cut C
  obtain ⟨⟨f,ef⟩,⟨g,eg⟩⟩ := F.distinct_attachments conn
  obtain ⟨r,a,b,ra,rb,ab,eq⟩ := Finset.card_eq_three.mp F.size
  have hr : r ∈ F.cut := by rw [eq]; simp
  have ha : a ∈ F.cut := by rw [eq]; simp
  have hb : b ∈ F.cut := by rw [eq]; simp
  obtain ⟨v,vZ,rv⟩ := component_contact conn F.size C hr
  obtain ⟨_,_,L⟩ := Traverses.end_clique clC vZ
  obtain ⟨s,t,rs,at',M⟩ := through_large_clique clA f ef hr ha ra
  obtain ⟨u,w,au,bw,R⟩ := through_large_clique clB g eg ha hb ab
  have offX (p : V) (h : p ∈ F.cut) : p ∉ X := componentShore_off_cut F.cut F.first p h
  have offY (p : V) (h : p ∈ F.cut) : p ∉ Y := componentShore_off_cut F.cut F.second p h
  have offZ (p : V) (h : p ∈ F.cut) : p ∉ Z := componentShore_off_cut F.cut C p h
  have ZX : Disjoint Z X := componentShore_disjoint ca
  have ZY : Disjoint Z Y := componentShore_disjoint cb
  have XY : Disjoint X Y := componentShore_disjoint F.different
  have d₁ : Disjoint Z ({r} : Set V) := by simpa using offZ r hr
  have d₂ : Disjoint (Z ∪ {r}) X := by simp [Set.disjoint_union_left,ZX,offX r hr]
  have d₃ : Disjoint ((Z ∪ {r}) ∪ X) ({a} : Set V) := by
    simp [Set.disjoint_union_left,offZ a ha,offX a ha,ra.symm]
  have d₄ : Disjoint (((Z ∪ {r}) ∪ X) ∪ {a}) Y := by
    simp [Set.disjoint_union_left,ZY,XY,offY r hr,offY a ha]
  have d₅ : Disjoint ((((Z ∪ {r}) ∪ X) ∪ {a}) ∪ Y) ({b} : Set V) := by
    simp [Set.disjoint_union_left,offZ b hb,offX b hb,offY b hb,rb.symm,ab.symm]
  have P := ((((L.join (Traverses.single r) d₁ rv.symm).join M d₂ rs).join (Traverses.single a)
    d₃ at'.symm).join R d₄ au).join (Traverses.single b) d₅ bw.symm
  have cover : (((((Z ∪ {r}) ∪ X) ∪ {a}) ∪ Y) ∪ {b}) = Set.univ := by
    apply Set.eq_univ_iff_forall.mpr
    intro z
    simp only [Set.mem_union,Set.mem_singleton_iff]
    by_cases hd : z ∈ F.cut
    · have he : z = r ∨ z = a ∨ z = b := by simpa [eq] using hd
      tauto
    let z' : Survives F.cut := ⟨z,hd⟩
    let K := (DeletionGraph G F.cut).connectedComponentMk z'
    have mem : z ∈ componentShore F.cut K := ⟨z',rfl,rfl⟩
    rcases only K with e|e|e
    · have h : z ∈ X := by simpa only [X,e] using mem
      tauto
    · have h : z ∈ Y := by simpa only [Y,e] using mem
      tauto
    · have h : z ∈ Z := by simpa only [Z,e] using mem
      tauto
  obtain ⟨p,_,_⟩ := P
  exact traceable_iff_hamiltonian_walk.mpr (pathOn_univ_iff_hamiltonian_walk.mp ⟨cover ▸ p⟩)

#print axioms three_clique_route
end Graffiti199Depleted.Catalogue.Incomplete
