import PointedFamily
open private triple_of_card_bound from OppositeComplete

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] {X : Set V} {r : V}

/-- When every noncontact component has at least two contacts, any ordinary
vertex can be the first vertex of a spanning path of the shore plus its port. -/
theorem route_from_any_of_wide_shore (none : NoRootedFour G X r) (off : r ∉ X)
    (wide : ∀ i : (G.induce (Noncontacts G X r)).ConnectedComponent,
      ∃ u ∈ rootedBlockContacts G X r i, ∃ v ∈ rootedBlockContacts G X r i, u ≠ v)
    {z : V} (zX : z ∈ X) : ∃ t, Traverses G (insert r X) z t := by
  classical
  let I := (G.induce (Noncontacts G X r)).ConnectedComponent
  letI : Finite I := Quot.finite _
  letI : Fintype I := Fintype.ofFinite I
  let Q (i : I) := rootedBlockContacts G X r i
  let C (i : I) := noncontactComponent G X r i
  let B (i : I) := Q i ∪ C i
  let P : Set V := {w | w ∈ shoreContacts G X r ∧ ∀ i, w ∉ Q i}
  let Z : Set V := insert r P
  have hQ {i : I} {v : V} (h : v ∈ Q i) : v ∈ shoreContacts G X r := ⟨h.1,h.2.1⟩
  have hC {i : I} {v : V} (h : v ∈ C i) : v ∈ Noncontacts G X r := noncontactComponent_subset i h
  have qq {i j : I} (ij : i ≠ j) : Disjoint (Q i) (Q j) := none.blockContacts_disjoint off ij
  have qc (i j : I) : Disjoint (Q i) (C j) := Set.disjoint_left.mpr fun _ h k => (hC k).2 (hQ h).2
  have db (i j : I) (ne : i ≠ j) : Disjoint (B i) (B j) := by
    simp only [B,Set.disjoint_union_left,Set.disjoint_union_right]
    exact ⟨⟨qq ne,(qc j i).symm⟩,⟨qc i j,noncontactComponents_apart ne⟩⟩
  have dz (i : I) : Disjoint Z (B i) := by
    apply Set.disjoint_left.mpr
    rintro v (rfl|h) (k|k)
    · exact off (hQ k).1
    · exact off (hC k).1
    · exact h.2 i k
    · exact (hC k).2 h.1.2
  have contact (i : I) {u v : V} (hu : u ∈ shoreContacts G X r) (notQ : u ∉ Q i)
      (hv : v ∈ Q i) : G.Adj u v := by
    obtain ⟨t,ht,vt⟩ := hv.2.2
    exact (none.cross_contacts_complete off hv.1 hu.1 (hC ht) hv.2.1 hu.2 vt
      (fun e => notQ ⟨hu.1,hu.2,t,ht,e⟩)).symm
  have cl (i : I) : (C i).Pairwise G.Adj := by
    obtain ⟨u,hu,_,_,_⟩ := wide i
    obtain ⟨v,hv,uv⟩ := hu.2.2
    exact none.clique_of_contact off i hu.1 hu.2.1 hv uv
  have complete (i : I) (u : V) (hu : u ∈ Q i) (v : V) (hv : v ∈ C i) : G.Adj u v := by
    obtain ⟨t,ht,ut⟩ := hu.2.2
    exact none.contact_common_on_component off i hu.1 hu.2.1 ht hv ut
  have tri {S : Set V} (sub : S ⊆ shoreContacts G X r) : Triple G S := by
    intro x hx y hy t ht xy xt yt
    exact triple_of_card_bound (fun U hU ind => none.card_independent_contacts_le_two U
      (fun v hv => sub (hU v hv)) ind) hx hy ht xy xt yt
  have classify {w : V} (wx : w ∈ X) : w ∈ P ∨ ∃ i, w ∈ B i := by
    by_cases rw : G.Adj r w
    · by_cases any : ∃ i, w ∈ Q i
      · obtain ⟨i,hi⟩ := any
        exact Or.inr ⟨i,Or.inl hi⟩
      · exact Or.inl ⟨⟨wx,rw⟩,fun i hi => any ⟨i,hi⟩⟩
    let w' : Noncontacts G X r := ⟨w,wx,rw⟩
    let i : I := (G.induce (Noncontacts G X r)).connectedComponentMk w'
    exact Or.inr ⟨i,Or.inr ⟨w',rfl,rfl⟩⟩
  have full : intervalUnion Z B Finset.univ = insert r X := by
    ext w
    constructor
    · rintro ((eq|h)|⟨i,_,h|h⟩)
      · exact Or.inl eq
      · exact Or.inr h.1.1
      · exact Or.inr (hQ h).1
      · exact Or.inr (hC h).1
    · rintro (eq|hx)
      · exact Or.inl (Or.inl eq)
      rcases classify hx with h|⟨i,h⟩
      · exact Or.inl (Or.inr h)
      · exact Or.inr ⟨i,Finset.mem_univ _,h⟩
  obtain ⟨base⟩ := route_residual_with_port none (P := P) (fun _ h => h.1)
  have init : (∃ t ∈ Z, Traverses G Z z t) ∨ ∃ i ∈ (Finset.univ : Finset I), z ∈ B i := by
    rcases classify zX with h|⟨i,h⟩
    · exact Or.inl (pointed_residual h (fun k : r ∈ P => off k.1.1) (fun _ k => k.1.2) (tri (fun _ k => k.1)))
    · exact Or.inr ⟨i,Finset.mem_univ _,h⟩
  have neC (i : I) : (C i).Nonempty := by
    obtain ⟨w,hw⟩ := i.nonempty_supp
    exact ⟨w.val,w,hw,rfl⟩
  obtain ⟨t,L⟩ := pointed_family Finset.univ Z Q C
    ⟨base.first,(base.covers _).mp (List.head_mem base.nonempty),base.last,base.last_mem,base,rfl,rfl⟩
    (fun i _ => wide i) (fun i _ => neC i) (fun i _ => cl i) (fun i _ => qc i i)
    (fun i _ => complete i) (fun _ _ => tri (fun _ h => hQ h)) (fun i _ => dz i)
    (fun i _ j _ => db i j) (by
      rintro i _ u (rfl|h) v hv
      · exact (hQ hv).2
      · exact contact i h.1 (h.2 i) hv)
    (fun _ _ j _ ij _ hx _ hy => contact j (hQ hx) (Set.disjoint_left.mp (qq ij) hx) hy) z init
  exact ⟨t,full ▸ L⟩

#print axioms route_from_any_of_wide_shore
end Graffiti199Depleted.Catalogue.Incomplete
