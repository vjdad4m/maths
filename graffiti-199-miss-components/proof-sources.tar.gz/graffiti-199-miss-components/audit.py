import csv
import hashlib
import re
from pathlib import Path

root = Path(__file__).resolve().parent
with (root / "Manifest.tsv").open() as f:
    manifest = list(csv.DictReader(f, delimiter="\t"))
seen = set()
full = (root / "StrictReplay.log").read_text()
baseline = b''.join((root / "Manifest.tsv").read_bytes().splitlines(keepends=True)[:178])
assert hashlib.sha256(baseline).hexdigest() == "27f3d7de23453791f23559387ef18b1cd8a0d683225e9f702d1b747c57a19e3a"
assert full.startswith("Lean (version 4.19.0,")
assert "\nMathlib c44e0c8ee63ca166450922a373c7409c5d26b00b\n" in full
assert full.endswith("Strict clean-source replay passed.\n")
checked = re.findall(r"(?m)^.*?/src/([^/]+\.lean): OK$", full)
assert checked == [row["file"] for row in manifest]
assert len(checked) == len(set(checked)) == 199
assert not re.search(r"(?m)(?:error|warning):|sorryAx", full)

def lean_code(source):
    # Remove nested Lean comments before scanning tokens.
    code, n, i = [], 0, 0
    while i < len(source):
        if source.startswith("/-", i):
            n += 1
            i += 2
        elif n and source.startswith("-/", i):
            n -= 1
            code.append(" ")
            i += 2
        elif n:
            i += 1
        elif source.startswith("--", i):
            i = source.find("\n", i)
            if i < 0:
                break
        else:
            code.append(source[i])
            i += 1
    assert n == 0
    return "".join(code)

allowed = {'propext', 'Classical.choice', 'Quot.sound'}
all_lists = re.findall(r"'[^']+' depends on axioms: \[([^\]]+)\]", full)
for axiom_list in all_lists:
    assert {a.strip() for a in axiom_list.split(',')} <= allowed, axiom_list
assert set(p.name for p in (root / 'src').glob('*.lean')) == set(checked)
for row in manifest:
    path = root / "src" / row["file"]
    body = path.read_bytes()
    assert hashlib.sha256(body).hexdigest() == row["sha256"]
    assert not re.search(r"\b(sorry|admit|native_decide|axiom|sorryAx)\b", lean_code(body.decode())), path
    for line in re.findall(r"^import\s+([^\n]+)", body.decode(), re.M):
        for dep in line.split():
            if dep + ".lean" in checked:
                assert dep in seen, (row["file"], dep)
    seen.add(path.stem)
namespace = "Graffiti199Depleted.Catalogue.Incomplete."
new = [row["file"] for row in manifest[177:]]
reports = {
    name: [s.strip() for s in body.split(",")]
    for name, body in re.findall(r"'([^']+)' depends on axioms: \[([^\]]+)\]", full)
}
shown = set()
for filename in new:
    source = (root / "src" / filename).read_text()
    for name in re.findall(r"(?m)^#print axioms ([\w.]+)", source):
        prefix = namespace + ("NoncliqueExample." if filename == "NoncliqueExample.lean" else "")
        qualified = prefix + name
        assert qualified in reports, qualified
        assert set(reports[qualified]) <= allowed
        shown.add(qualified)
for key in [
    "catalogue_minimum_miss_component_profile", "SingletonCut.nonsingleton_unique",
    "SingletonCut.uniform_pair_unique_cubic",
    "SingletonCut.no_uniform_split", "SingletonCut.route_split_and_isolate",
    "SingletonCut.uniform_nonsingleton_has_cubic_contact", "SingletonCut.double_support_shape",
    "SingletonCut.contacts_disjoint_of_nonclique", "SingletonCut.cubic_contact_absorbs",
    "SingletonCut.nested_cliques",
]:
    assert reports[namespace + key] == ["propext","Classical.choice","Quot.sound"]
for name in sorted(shown):
    print(name, reports[name])
print("Frozen exact-two baseline: 177 byte-identical ordered source records.")
print(f"{len(checked)} sources checked in compilation order, including {len(new)} new modules.")
print("All source hashes, token checks, replay results and printed axiom sets passed.")

