#!/usr/bin/env bash
set -euo pipefail
project="$(cd "$(dirname "$0")" && pwd)"
: "${GRAFF199_MATHLIB:?Set GRAFF199_MATHLIB to Mathlib v4.19.0}"
mathlib="$(cd "$GRAFF199_MATHLIB" && pwd)"
if [[ -n "${GRAFF199_LEAN_BIN:-}" ]]; then export PATH="$GRAFF199_LEAN_BIN:$PATH"; fi
version="$(lean --version)"
printf '%s\n' "$version"
[[ "$version" == *"version 4.19.0,"* ]]
revision="$(git -C "$mathlib" rev-parse HEAD)"
printf 'Mathlib %s\n' "$revision"
[[ "$revision" == c44e0c8ee63ca166450922a373c7409c5d26b00b ]]
out="$(mktemp -d)"
trap 'rm -rf "$out"' EXIT
export LEAN_PATH="$out:$mathlib/.lake/build/lib/lean"
for pkg in "$mathlib"/.lake/packages/*; do
  if [[ -d "$pkg/.lake/build/lib/lean" ]]; then export LEAN_PATH="$LEAN_PATH:$pkg/.lake/build/lib/lean"; fi
done
ham=Mathlib/Combinatorics/SimpleGraph/Hamiltonian
if [[ ! -f "$mathlib/.lake/build/lib/lean/$ham.olean" ]]; then
  cp -as "$mathlib/.lake/build/lib/lean/Mathlib" "$out/Mathlib"
  mkdir -p "$out/$(dirname "$ham")"
  lean --root="$mathlib" -j1 -s 65536 -DElab.async=false -DwarningAsError=true -o "$out/$ham.olean" "$mathlib/$ham.lean"
fi
seen=1
while true; do
  total="$(wc -l < "$project/Manifest.tsv")"
  if (( seen >= total )); then
    if [[ "${GRAFF199_BUILD_OPEN:-0}" = 1 && ! -f "$project/.sealed" ]]; then
      sleep 2
      continue
    fi
    break
  fi
  while IFS=$'\t' read -r name digest provenance; do
  [[ "$name" == file ]] && continue
  src="$project/src/$name"
  printf '%s  %s\n' "$digest" "$src" | sha256sum --check
  lean --root="$project/src" -j1 -s 65536 -DElab.async=false -DwarningAsError=true -o "$out/${name%.lean}.olean" "$src"
  done < <(sed -n "$((seen + 1)),${total}p" "$project/Manifest.tsv")
  seen="$total"
done
printf '%s\n' 'Strict clean-source replay passed.'


