import ConnectorRoute
import MissDegree
import MatchedPath
import Unattached
open private swap_others from TwoMissMatching
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {X : Set V} {z r a b x y : V}

private theorem oriented (F : SingletonCut G X z r a b) (cross : CrossingBetweenSurvivingEdges G)
    (xX : x ∈ X) (yX : y ∈ X) (xy : G.Adj x y) (rx : ¬ G.Adj r x) (ry : ¬ G.Adj r y)
    (on : ∀ t ∈ X \ {x,y}, G.Adj r t) (xa : G.Adj x a)
    (room : ¬ G.Adj y a ∨ 4 ≤ G.degree y) : Traceable G := by
  by_cases yb : G.Adj y b
  · exact F.traceable_of_matched_two_misses xX yX xy rx ry on xa yb
  have two := F.two_ordinary_neighbors (x := x) yX ry yb room
  obtain ⟨u,uh,v,_vh,_uv,yu,_yv⟩ := two
  obtain ⟨C⟩ := F.connector_to_free_port cross xX yX xy.ne yb ⟨u,uh,yu⟩
  exact F.traceable_through_connector xX yX xy ry on xa C ⟨u,uh,v,_vh,_uv,yu,_yv⟩

/-- Every adjacent exact pair of misses closes in the reduced branch. The
only information required from the minimum is a deletion path and crossing
between surviving edges. Independence of cubic vertices prevents both
adjacent misses from having degree three. -/
theorem SingletonCut.traceable_of_adjacent_misses (F : SingletonCut G X z r a b)
    (cross : CrossingBetweenSurvivingEdges G) (P : PathOn G {v | v ≠ z})
    (ind : ∀ u v, G.degree u = 3 → G.degree v = 3 → ¬ G.Adj u v)
    (xX : x ∈ X) (yX : y ∈ X) (xy : G.Adj x y) (rx : ¬ G.Adj r x) (ry : ¬ G.Adj r y)
    (on : ∀ t ∈ X \ {x,y}, G.Adj r t) : Traceable G := by
  classical
  have lo (v : V) := degree_of_small_deletion_preconnected (G := G) (by have := F.conn.1; omega : 4 ≤ Fintype.card V)
    (fun K small => (F.conn.2 K small).preconnected) v
  have large : 4 ≤ G.degree x ∨ 4 ≤ G.degree y := by
    by_contra! bad
    exact ind x y (by have := lo x; omega) (by have := lo y; omega) xy
  have rev : ∀ t ∈ X \ {y,x}, G.Adj r t := (Set.pair_comm x y) ▸ on
  have A := oriented F cross xX yX xy rx ry on
  have B := oriented (swap_others F) cross xX yX xy rx ry on
  have C := oriented F cross yX xX xy.symm ry rx rev
  have D := oriented (swap_others F) cross yX xX xy.symm ry rx rev
  have free : (¬ G.Adj x a) → (¬ G.Adj x b) → (¬ G.Adj y a) → (¬ G.Adj y b) → Traceable G := by
    intro xa xb ya yb
    apply F.traceable_of_two_unattached P xX on
    rintro s (e|e)
    · exact e.symm ▸ ⟨fun h => xa h.symm,fun h => xb h.symm⟩
    · exact (show s=y from e).symm ▸ ⟨fun h => ya h.symm,fun h => yb h.symm⟩
  by_cases xa : G.Adj x a <;> by_cases xb : G.Adj x b <;>
    by_cases ya : G.Adj y a <;> by_cases yb : G.Adj y b <;> rcases large with high|high <;>
    first | exact A xa (Or.inr high) | exact B xb (Or.inr high) | exact C ya (Or.inr high) |
      exact D yb (Or.inr high) | exact A xa (Or.inl ya) | exact B xb (Or.inl yb) |
      exact C ya (Or.inl xa) | exact D yb (Or.inl xb) | exact free xa xb ya yb

#print axioms SingletonCut.traceable_of_adjacent_misses
end Graffiti199Depleted.Catalogue.Incomplete

