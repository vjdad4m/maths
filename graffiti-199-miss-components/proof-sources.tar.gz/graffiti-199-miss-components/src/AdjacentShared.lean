import AdjacentClosed
open private oriented from AdjacentClosed
open private swap_others from TwoMissMatching
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {X : Set V} {z r a b x y : V}

/-- Two adjacent cubic ordinary misses sharing another port have at most
three neighbors outside their pair. Deleting those neighbors separates
the surviving edge xy from the surviving edge zr. -/
theorem SingletonCut.no_shared_port_for_adjacent_cubic (F : SingletonCut G X z r a b)
    (cross : CrossingBetweenSurvivingEdges G) (xX : x ∈ X) (yX : y ∈ X)
    (xy : G.Adj x y) (rx : ¬ G.Adj r x) (ry : ¬ G.Adj r y)
    (xa : G.Adj x a) (ya : G.Adj y a) (dx : G.degree x=3) (dy : G.degree y=3) : False := by
  classical
  let A := (G.neighborFinset x).erase y
  let B := (G.neighborFinset y).erase x
  let D := A ∪ B
  have ax : A.card=2 := by rw [Finset.card_erase_of_mem ((G.mem_neighborFinset _ _).mpr xy),G.card_neighborFinset_eq_degree,dx]
  have by' : B.card=2 := by rw [Finset.card_erase_of_mem ((G.mem_neighborFinset _ _).mpr xy.symm),G.card_neighborFinset_eq_degree,dy]
  have both : a ∈ A ∩ B := Finset.mem_inter.mpr
    ⟨Finset.mem_erase.mpr ⟨ya.ne.symm,(G.mem_neighborFinset _ _).mpr xa⟩,
     Finset.mem_erase.mpr ⟨xa.ne.symm,(G.mem_neighborFinset _ _).mpr ya⟩⟩
  have size : D.card ≤ 3 := by
    have n := Finset.card_union_add_card_inter A B
    have pos := Finset.card_pos.mpr ⟨a,both⟩
    change (A ∪ B).card ≤ 3
    omega
  have cutOff (v : V) (vX : v ∈ X) : ¬ G.Adj v z := fun e => F.offX v ((F.cut.2 v).mp e.symm) vX
  have data (t : V) : t ∈ D ↔ (t ≠ y ∧ G.Adj x t) ∨ (t ≠ x ∧ G.Adj y t) := by simp [D,A,B]
  have xc : x ∉ D := by simp [data]
  have yc : y ∉ D := by simp [data]
  have zc : z ∉ D := by simp [data,cutOff x xX,cutOff y yX]
  have rc : r ∉ D := by simp [data,show ¬ G.Adj x r from fun e => rx e.symm,show ¬ G.Adj y r from fun e => ry e.symm]
  have zo : z ∉ ({x,y}:Set V) := by
    rintro (zx|zy); exact F.zX (zx.symm ▸ xX); exact F.zX ((show z=y from zy).symm ▸ yX)
  have ro : r ∉ ({x,y}:Set V) := by
    rintro (ex|ey); exact F.offX r (by simp) (ex.symm ▸ xX); exact F.offX r (by simp) ((show r=y from ey).symm ▸ yX)
  obtain ⟨p,pm,q,qm,_,qc,pq⟩ := cross D size {x,y} ⟨x,Or.inl rfl,y,Or.inr rfl,xc,yc,xy⟩
    ⟨z,zo,r,ro,zc,rc,(F.cut.2 r).mpr (by simp)⟩
  apply qc ((data q).mpr ?_)
  rcases pm with px|py
  · exact Or.inl ⟨fun eq => qm (Or.inr eq),px ▸ pq⟩
  · exact Or.inr ⟨fun eq => qm (Or.inl eq),(show p=y from py) ▸ pq⟩

theorem SingletonCut.traceable_of_adjacent_with_crossing (F : SingletonCut G X z r a b)
    (cross : CrossingBetweenSurvivingEdges G) (P : PathOn G {v | v ≠ z})
    (xX : x ∈ X) (yX : y ∈ X) (xy : G.Adj x y) (rx : ¬ G.Adj r x) (ry : ¬ G.Adj r y)
    (on : ∀ t ∈ X \ {x,y}, G.Adj r t) : Traceable G := by
  classical
  have rev : ∀ t ∈ X \ {y,x}, G.Adj r t := (Set.pair_comm x y) ▸ on
  have A := oriented F cross xX yX xy rx ry on
  have B := oriented (swap_others F) cross xX yX xy rx ry on
  have C := oriented F cross yX xX xy.symm ry rx rev
  have D := oriented (swap_others F) cross yX xX xy.symm ry rx rev
  have clashA := F.no_shared_port_for_adjacent_cubic cross xX yX xy rx ry
  have clashB := (swap_others F).no_shared_port_for_adjacent_cubic cross xX yX xy rx ry
  have pick (v : V) : 4 ≤ G.degree v ∨ G.degree v=3 := by
    have lo := degree_of_small_deletion_preconnected (G := G) (by have := F.conn.1; omega : 4 ≤ Fintype.card V)
      (fun K small => (F.conn.2 K small).preconnected) v
    omega
  have free : (¬ G.Adj x a) → (¬ G.Adj x b) → (¬ G.Adj y a) → (¬ G.Adj y b) → Traceable G := by
    intro xa xb ya yb
    apply F.traceable_of_two_unattached P xX on
    rintro s (e|e)
    · exact e.symm ▸ ⟨fun h => xa h.symm,fun h => xb h.symm⟩
    · exact (show s=y from e).symm ▸ ⟨fun h => ya h.symm,fun h => yb h.symm⟩
  by_cases xa : G.Adj x a <;> by_cases xb : G.Adj x b <;>
    by_cases ya : G.Adj y a <;> by_cases yb : G.Adj y b <;>
    first | exact free xa xb ya yb | exact A xa (Or.inl ya) | exact B xb (Or.inl yb) |
      exact C ya (Or.inl xa) | exact D yb (Or.inl xb) |
      (rcases pick x with dx|dx <;> rcases pick y with dy|dy <;>
        first | exact A xa (Or.inr dy) | exact B xb (Or.inr dy) |
          exact C ya (Or.inr dx) | exact D yb (Or.inr dx) |
          exact (clashA xa ya dx dy).elim | exact (clashB xb yb dx dy).elim)

#print axioms SingletonCut.no_shared_port_for_adjacent_cubic
#print axioms SingletonCut.traceable_of_adjacent_with_crossing
end Graffiti199Depleted.Catalogue.Incomplete
