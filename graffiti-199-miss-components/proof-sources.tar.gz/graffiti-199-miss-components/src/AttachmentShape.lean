import DoubleAttachment
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph

private theorem star_or_triangle {I : Type*} (R : I → I → Prop)
    (sym : ∀ {i j}, R i j → R j i) (ne : ∀ {i j}, R i j → i ≠ j)
    (meet : ∀ {i j k l}, R i j → R k l → i=k ∨ i=l ∨ j=k ∨ j=l) :
    (∀ i j, ¬ R i j) ∨ (∃ h, ∀ i j, R i j → i=h ∨ j=h) ∨
    ∃ i j k, R i j ∧ R i k ∧ R j k ∧
      ∀ x y, R x y → (x=i ∨ x=j ∨ x=k) ∧ (y=i ∨ y=j ∨ y=k) := by
  classical
  by_cases any : ∃ i j, R i j
  · obtain ⟨i,j,ij⟩ := any
    by_cases one : ∀ x y, R x y → x=i ∨ y=i
    · exact Or.inr (Or.inl ⟨i,one⟩)
    by_cases two : ∀ x y, R x y → x=j ∨ y=j
    · exact Or.inr (Or.inl ⟨j,two⟩)
    have beside {i j : I} (ij : R i j) (no : ¬ ∀ x y, R x y → x=i ∨ y=i) :
        ∃ k, R j k ∧ k ≠ i := by
      push_neg at no
      obtain ⟨x,y,xy,xi,yi⟩ := no
      rcases (meet ij xy).resolve_left xi.symm with iy|jx|jy
      · exact (yi iy.symm).elim
      · exact ⟨y,jx.symm ▸ xy,yi⟩
      · exact ⟨x,jy.symm ▸ sym xy,xi⟩
    obtain ⟨k,jk,ki⟩ := beside ij one
    obtain ⟨l,il,lj⟩ := beside (sym ij) two
    have kl : k=l := by
      rcases meet jk il with h|h|h|h
      · exact ((ne ij) h.symm).elim
      · exact (lj h.symm).elim
      · exact (ki h).elim
      · exact h
    subst l
    have inside {x y : I} (xy : R x y) : x=i ∨ x=j ∨ x=k := by
      by_contra! out
      have A := meet xy ij
      have B := meet xy il
      have C := meet xy jk
      have ij' := ne ij
      have jk' := ne jk
      rcases (A.resolve_left out.1).resolve_left out.2.1 with yi|yj
      · rcases (C.resolve_left out.2.1).resolve_left out.2.2 with yj|yk
        · exact ij' (yi.symm.trans yj)
        · exact ki (yk.symm.trans yi)
      · rcases (B.resolve_left out.1).resolve_left out.2.2 with yi|yk
        · exact ij' (yi.symm.trans yj)
        · exact jk' (yj.symm.trans yk)
    exact Or.inr (Or.inr ⟨i,j,k,ij,il,jk,fun _ _ xy => ⟨inside xy,inside (sym xy)⟩⟩)
  · exact Or.inl (fun i j h => any ⟨i,j,h⟩)

def DoubleSupport (G : SimpleGraph V) (X : Set V) (r : V) (i j : RootComponent G X r) : Prop :=
  i ≠ j ∧ ∃ p ∈ rootedBlockContacts G X r i, p ∈ rootedBlockContacts G X r j

variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] {X : Set V} {z r a b : V}

/-- The size-two attachment supports are empty, all share one component,
or are precisely the three unordered pairs of three fixed components. -/
theorem SingletonCut.double_support_shape (F : SingletonCut G X z r a b) :
    (∀ i j, ¬ DoubleSupport G X r i j) ∨
    (∃ h, ∀ i j, DoubleSupport G X r i j → i=h ∨ j=h) ∨
    ∃ i j k, DoubleSupport G X r i j ∧ DoubleSupport G X r i k ∧ DoubleSupport G X r j k ∧
      ∀ x y, DoubleSupport G X r x y → (x=i ∨ x=j ∨ x=k) ∧ (y=i ∨ y=j ∨ y=k) := by
  apply star_or_triangle
  · rintro _ _ ⟨ij,p,pi,pj⟩
    exact ⟨ij.symm,p,pj,pi⟩
  · exact fun h => h.1
  · rintro _ _ _ _ ⟨ij,p,pi,pj⟩ ⟨kl,q,qk,ql⟩
    exact F.double_contacts_intersect ij kl pi pj qk ql

#print axioms SingletonCut.double_support_shape
end Graffiti199Depleted.Catalogue.Incomplete

