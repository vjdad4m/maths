/- The two private cap-path lemmas are from the published TwoTerminalOre189.lean. -/
import OreClosure189

namespace Graffiti189LongestPath.CrossSaturation
open SimpleGraph SimpleGraph.Walk Finset Graffiti189Ore
open private unliftCap liftCap_support leaf_cap_neighbor leaf_cap_degree_ge from OreClosure189
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]
set_option linter.unusedSectionVars false

/- Reused from ArticulationClique189.lean. -/
theorem path_concat_new {x y z : V} (p : G.Walk x y) (pp : p.IsPath)
    (yz : G.Adj y z) (new : z∉p.support) : (p.concat yz).IsPath := by
  rw [isPath_def,support_concat,List.concat_eq_append,List.nodup_append]
  refine ⟨pp.support_nodup,by simp,?_⟩
  intro w wp wz
  have e : w=z := by simpa using wz
  exact new (e ▸ wp)

private theorem cap_path_known_end {x y : V}
    (p : (cap G (fun v=>v=y)).Walk (some x) none)
    (pp : p.IsPath) (all : ∀ v,v∈p.support) :
    ∃ q : G.Walk x y, q.IsPath ∧ ∀ v,v∈q.support := by
  have qa : ∀ v,v∈p.reverse.support := by simpa only [support_reverse,List.mem_reverse] using all
  generalize e : p.reverse = r at qa ⊢
  have rp : r.IsPath := e ▸ pp.reverse
  cases r with
  | cons h q =>
    have na := leaf_cap_neighbor h
    subst_vars
    have no := ((cons_isPath_iff h q).mp rp).2
    obtain ⟨z,zz,t,ts⟩ := unliftCap q no
    have zx := Option.some.inj zz.symm
    subst z
    have tp : t.IsPath := IsPath.mk' (List.Nodup.of_map some
        (ts ▸ ((cons_isPath_iff h q).mp rp).1.support_nodup))
    refine ⟨t.reverse,tp.reverse,?_⟩
    intro v
    have vm := qa (some v)
    simp only [support_cons,List.mem_cons,reduceCtorEq,false_or,ts,List.mem_map] at vm
    obtain ⟨w,wm,eq⟩ := vm
    have ve : v∈t.support := Option.some.inj eq ▸ wm
    simpa only [support_reverse,List.mem_reverse] using ve

private theorem cap_path_forces_end {x y : V}
    (h : Graffiti189Ore.Rooted (cap G (fun v=>v=y)) (some x)) :
    ∃ q : G.Walk x y,q.IsPath ∧ ∀ v,v∈q.support := by
  obtain ⟨b,p,pp,all⟩ := h
  obtain ⟨i,e,hi⟩ := mem_support_iff_exists_getVert.mp (all none)
  have positive : 0 < i := by
    by_contra bad
    have i0 : i=0 := by omega
    simp [i0] at e
  have last : i=p.length := by
    apply Classical.byContradiction
    intro no
    have near : i < p.length := by omega
    have ep := p.adj_getVert_succ (i:=i-1) (by omega)
    have en := p.adj_getVert_succ near
    rw [show i-1+1=i by omega,e] at ep
    rw [e] at en
    have eq := (leaf_cap_neighbor ep.symm).trans (leaf_cap_neighbor en).symm
    have bad := pp.getVert_injOn (by simp; omega : i-1∈{j | j≤p.length})
      (by simp; omega : i+1∈{j | j≤p.length}) eq
    omega
  have ben : b=none := by simpa [last] using e
  subst b
  exact cap_path_known_end p pp all

end Graffiti189LongestPath.CrossSaturation
