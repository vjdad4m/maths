import SingleException
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
universe u
variable {V : Type u} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]

/-- In the minimum-order nontraceable branch, every port of every
separating three-set misses at least two vertices of the ordinary shore. -/
theorem catalogue_minimum_all_ports_miss_two
    (minimum : ∀ (W : Type u) [Fintype W] (H : SimpleGraph W), Fintype.card W < Fintype.card V →
      H.Connected → 2 ≤ Fintype.card W → treeNumber H ≤ vertexConnectivity H + 2 → Traceable H)
    (k : vertexConnectivity G = 3) (bound : treeNumber G ≤ vertexConnectivity G + 2)
    (order : 5 ≤ Fintype.card V) (no : ¬ Traceable G)
    (ind : ∀ u v, G.degree u = 3 → G.degree v = 3 → ¬ G.Adj u v) :
    (∃ D : Finset V, D.card = 3 ∧ ¬ (DeletionGraph G D).Preconnected) ∧
    ∀ D : Finset V, D.card = 3 → ¬ (DeletionGraph G D).Preconnected →
      ∃ z : V, ∃ X : Set V, ∃ P : PathOn G {v | v ≠ z},
      ∀ r a b : V, r ≠ a → r ≠ b → a ≠ b → D = {r,a,b} →
        SingletonCut G X z r a b ∧ SaturatedPort G X r a b ∧
        (P.terminalQuartet.card = 4 ∧ (∀ v ∈ P.terminalQuartet, v ∈ X) ∧
          (∀ v ∈ P.terminalQuartet, ∀ w ∈ P.terminalQuartet, ¬ G.Adj v w) ∧
          ∀ s ∈ D, ∃ v ∈ P.terminalQuartet, ¬ G.Adj s v) ∧ MissesTwo G X r := by
  obtain ⟨existsCut,every⟩ := catalogue_minimum_port_deficiency minimum k bound order no ind
  refine ⟨existsCut,?_⟩
  intro D size cut
  obtain ⟨z,X,P,all⟩ := every D size cut
  refine ⟨z,X,P,?_⟩
  intro r a b ra rb ab eq
  obtain ⟨F,sat,quart,_,almost⟩ := all r a b ra rb ab eq
  refine ⟨F,sat,quart,?_⟩
  by_contra h
  obtain ⟨_,_,_,_,_,_,one⟩ := almost h
  exact no (F.traceable_of_one_almost_complete P one)

#print axioms catalogue_minimum_all_ports_miss_two
end Graffiti199Depleted.Catalogue.Incomplete
