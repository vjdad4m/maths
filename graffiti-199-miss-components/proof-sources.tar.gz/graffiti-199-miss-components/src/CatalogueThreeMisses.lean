import ExactTwo
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
universe u
variable {V : Type u} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]

/-- Every port of every separating triple has at least three distinct ordinary
nonneighbors in this minimum-order branch of the catalogue conjecture. -/
theorem catalogue_minimum_all_ports_miss_three
    (minimum : ∀ (W : Type u) [Fintype W] (H : SimpleGraph W), Fintype.card W < Fintype.card V →
      H.Connected → 2 ≤ Fintype.card W → treeNumber H ≤ vertexConnectivity H + 2 → Traceable H)
    (k : vertexConnectivity G = 3) (bound : treeNumber G ≤ vertexConnectivity G + 2)
    (order : 5 ≤ Fintype.card V) (no : ¬ Traceable G)
    (ind : ∀ u v, G.degree u = 3 → G.degree v = 3 → ¬ G.Adj u v) :
    (∃ D : Finset V, D.card = 3 ∧ ¬ (DeletionGraph G D).Preconnected) ∧
    ∀ D : Finset V, D.card = 3 → ¬ (DeletionGraph G D).Preconnected →
      ∃ z : V, ∃ X : Set V, ∃ P : PathOn G {v | v ≠ z},
      ∀ r a b : V, r ≠ a → r ≠ b → a ≠ b → D = {r,a,b} →
        SingletonCut G X z r a b ∧ SaturatedPort G X r a b ∧
        (P.terminalQuartet.card = 4 ∧ (∀ v ∈ P.terminalQuartet, v ∈ X) ∧
          (∀ v ∈ P.terminalQuartet, ∀ w ∈ P.terminalQuartet, ¬ G.Adj v w) ∧
          ∀ s ∈ D, ∃ v ∈ P.terminalQuartet, ¬ G.Adj s v) ∧
        ∃ T : Finset V, T.card = 3 ∧ ∀ v ∈ T, v ∈ X ∧ ¬ G.Adj r v := by
  classical
  obtain ⟨existsCut,every⟩ := catalogue_minimum_all_ports_miss_two minimum k bound order no ind
  refine ⟨existsCut,?_⟩
  intro D size cut
  obtain ⟨z,X,P,all⟩ := every D size cut
  refine ⟨z,X,P,?_⟩
  intro r a b ra rb ab eq
  obtain ⟨F,sat,quart,x,xX,y,yX,xy,rx,ry⟩ := all r a b ra rb ab eq
  refine ⟨F,sat,quart,?_⟩
  have cross := catalogue_minimum_crossing minimum F.conn F.budget order no ind
  obtain ⟨w,wm,rw⟩ : ∃ w ∈ X \ {x,y}, ¬ G.Adj r w := by
    by_contra! complete
    exact no (F.traceable_of_exactly_two_misses cross P xX yX xy rx ry complete)
  have wx : w ≠ x := fun e => wm.2 (Or.inl e)
  have wy : w ≠ y := fun e => wm.2 (Or.inr e)
  refine ⟨{x,y,w},by simp [xy,wx.symm,wy.symm],?_⟩
  intro v vm
  rcases (show v=x ∨ v=y ∨ v=w by simpa using vm) with e|e|e
  · exact e.symm ▸ ⟨xX,rx⟩
  · exact e.symm ▸ ⟨yX,ry⟩
  · exact e.symm ▸ ⟨wm.1,rw⟩

#print axioms catalogue_minimum_all_ports_miss_three
end Graffiti199Depleted.Catalogue.Incomplete
