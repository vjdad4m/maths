import ExceptionalComponent
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X : Set V} {z r a b : V} {i : RootComponent G X r}

omit [Fintype V] [DecidableEq V] in
theorem missPart_closed_along_miss_edge {x y : V} (xi : x ∈ MissPart G X r i)
    (yM : y ∈ Noncontacts G X r) (xy : G.Adj x y) : y ∈ MissPart G X r i := by
  obtain ⟨t,ti,rfl⟩ := xi
  let s : Noncontacts G X r := ⟨y,yM⟩
  have ts : (G.induce (Noncontacts G X r)).Adj t s := xy
  exact ⟨s,(i.mem_supp_congr_adj ts).mp ti,rfl⟩

/-- The only possible external neighbors are ordinary contacts and the
two remaining ports. -/
theorem SingletonCut.part_boundary (F : SingletonCut G X z r a b) {x y : V}
    (xi : x ∈ MissPart G X r i) (yi : y ∉ MissPart G X r i) (xy : G.Adj x y) :
    y = a ∨ y = b ∨ y ∈ rootedBlockContacts G X r i := by
  rcases F.cover y with yX|yz|yr|ya|yb
  · by_cases ry : G.Adj r y
    · exact Or.inr (Or.inr ⟨yX,ry,x,xi,xy.symm⟩)
    · exact (yi (missPart_closed_along_miss_edge xi ⟨yX,ry⟩ xy)).elim
  · exact (F.offX x ((F.cut.2 x).mp (yz ▸ xy.symm)) (noncontactComponent_subset i xi).1).elim
  · exact ((noncontactComponent_subset i xi).2 (yr ▸ xy.symm)).elim
  · exact Or.inl ya
  · exact Or.inr (Or.inl yb)

/-- An edge inside a missed component and the surviving edge z-r force
two distinct ordinary contacts, even when both other ports touch the component. -/
theorem SingletonCut.edge_part_wide (F : SingletonCut G X z r a b)
    (cross : CrossingBetweenSurvivingEdges G) {x y : V} (xi : x ∈ MissPart G X r i)
    (yi : y ∈ MissPart G X r i) (xy : G.Adj x y) : Wide G X r i := by
  obtain ⟨t,tX,rt⟩ := F.contact (by simp : r ∈ ({r,a,b} : Finset V))
  obtain ⟨p,pi⟩ := rootedBlockContacts_nonempty F.connX ⟨t,tX,rt⟩ i
  let D : Finset V := {a,b,p}
  have off {u : V} (ui : u ∈ MissPart G X r i) : u ∉ D := by
    have uM := noncontactComponent_subset i ui
    have ua : u ≠ a := fun e => F.offX a (by simp) (e ▸ uM.1)
    have ub : u ≠ b := fun e => F.offX b (by simp) (e ▸ uM.1)
    have up : u ≠ p := fun e => uM.2 (e.symm ▸ pi.2.1)
    simp [D,ua,ub,up]
  have zr := (F.cut.2 r).mpr (by simp)
  have za := (F.cut.2 a).mpr (by simp)
  have zb := (F.cut.2 b).mpr (by simp)
  have zp : z ≠ p := fun e => F.zX (e.symm ▸ pi.1)
  have rX := F.offX r (by simp)
  have res := cross D (card_triple_le ..) (MissPart G X r i)
    ⟨x,xi,y,yi,off xi,off yi,xy⟩
    ⟨z,fun c => F.zX (noncontactComponent_subset i c).1,r,fun c => rX (noncontactComponent_subset i c).1,
      by simp [D,za.ne,zb.ne,zp],by simp [D,F.ra,F.rb,pi.2.1.ne],zr⟩
  obtain ⟨s,si,q,qi,_,qD,sq⟩ := res
  have qa : q ≠ a := fun e => qD (by simp [D,e])
  have qb : q ≠ b := fun e => qD (by simp [D,e])
  have qp : q ≠ p := fun e => qD (by simp [D,e])
  exact ⟨p,pi,q,((F.part_boundary si qi sq).resolve_left qa).resolve_left qb,qp.symm⟩

/-- Ordinary contacts of a uniform clique see the same vertices there.
A private neighbor of one member relative to another can only be an outer port. -/
theorem SingletonCut.difference_in_ports (F : SingletonCut G X z r a b)
    (good : UniformMissPart G X r i) {u v x : V} (ui : u ∈ MissPart G X r i)
    (vi : v ∈ MissPart G X r i) (xv : x ≠ v) (ux : G.Adj u x) (vx : ¬ G.Adj v x) :
    x = a ∨ x = b := by
  have xi : x ∉ MissPart G X r i := fun h => vx (good.1 vi h xv.symm)
  rcases F.part_boundary ui xi ux with e|e|h
  · exact Or.inl e
  · exact Or.inr e
  · exact (vx (good.2 x h v vi).symm).elim

#print axioms SingletonCut.edge_part_wide
#print axioms SingletonCut.difference_in_ports
end Graffiti199Depleted.Catalogue.Incomplete
