import PortConnector
import Mathlib.Data.List.FinRange
import Mathlib.Data.List.OfFn
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X : Set V} {z r a b x y : V}

/-- A port-to-port path through adjacent misses can start at x and use a
chordless connector from y to b. A second ordinary neighbor of y off the
connector gives the extra attachment needed when three cliques remain. -/
theorem SingletonCut.traceable_through_connector (F : SingletonCut G X z r a b)
    (xX : x ∈ X) (yX : y ∈ X) (xy : G.Adj x y) (ry : ¬ G.Adj r y)
    (on : ∀ t ∈ X \ {x,y}, G.Adj r t) (xa : G.Adj x a)
    (C : ChordlessConnector G (X \ {x,y}) y b)
    (two : ∃ u ∈ X \ {x,y}, ∃ v ∈ X \ {x,y}, u ≠ v ∧ G.Adj y u ∧ G.Adj y v) : Traceable G := by
  classical
  let L := List.ofFn C.inside
  let h := C.inside 0
  let S := x :: y :: L
  let M := {t : V | t ∈ S}
  have ne : L ≠ [] := by simp [L]
  have head : L.head ne = h := by simp [L,h,List.head_ofFn]
  have last : L.getLast ne = C.inside (Fin.last C.last) := List.getLast_ofFn_succ _
  have yh : G.Adj y h := (C.from_u 0).mpr rfl
  have tailEdge := ((C.from_v (Fin.last C.last)).mpr rfl).symm
  have inU {t : V} (tl : t ∈ L) : t ∈ X \ {x,y} := by
    obtain ⟨i,eq⟩ := List.mem_ofFn.mp tl
    exact eq ▸ C.kept i
  have xL : x ∉ L := fun m => (inU m).2 (Or.inl rfl)
  have yL : y ∉ L := fun m => (inU m).2 (Or.inr rfl)
  have sub : M ⊆ X := by
    intro t tm
    rcases (show t=x ∨ t=y ∨ t∈L by simpa only [M,S,Set.mem_setOf_eq,List.mem_cons] using tm) with tx|ty|tl; exact tx.symm ▸ xX; exact ty.symm ▸ yX; exact (inU tl).1
  have ch : L.Chain' G.Adj := by
    apply List.chain'_iff_get.mpr
    intro i hi
    simp only [L,List.length_ofFn] at hi
    simp only [L,List.get_eq_getElem,List.getElem_ofFn]
    exact (C.chain _ _).mpr (Or.inl rfl)
  have chain : S.Chain' G.Adj := by
    apply List.chain'_cons.mpr ⟨xy,?_⟩
    apply List.chain'_cons'.mpr ⟨?_,ch⟩
    intro t ht; rw [List.head?_eq_head ne,head] at ht
    exact (Option.mem_some.mp ht) ▸ yh
  let P : PathOn G M := ⟨S,by simp [S],chain,by
    have ndL : L.Nodup := List.nodup_ofFn_ofInjective C.inside.injective
    simpa only [S,List.nodup_cons,List.mem_cons,not_or] using And.intro (And.intro xy.ne xL) (And.intro yL ndL),fun _ => Iff.rfl⟩
  have finish : G.Adj P.last b := by
    have pl : P.last = L.getLast ne := by
      change ([x,y] ++ L).getLast _ = _
      rw [List.getLast_append_of_ne_nil _ ne]
    exact pl.symm ▸ last.symm ▸ tailEdge
  have onH : ∀ v ∈ X \ M, G.Adj r v := by
    intro v hv
    apply on _ ⟨hv.1,?_⟩
    rintro (vx|vy)
    · exact hv.2 (show v ∈ S by simp [S,vx])
    · exact hv.2 (show v ∈ S by simp [S,show v=y from vy])
  apply Classical.byContradiction
  intro no
  obtain ⟨K,edges⟩ := F.cliques_from_reserve_cycle sub onH P xa.symm finish no
  obtain ⟨u,uU,v,vU,uv,yu,yv⟩ := two
  have uniq {w : V} (e : G.Adj y w) (m : w ∈ L) : w = h := by
    obtain ⟨i,eq⟩ := List.mem_ofFn.mp m
    have iz : i = 0 := Fin.ext ((C.from_u i).mp (eq.symm ▸ e))
    exact eq.symm.trans (congrArg C.inside iz)
  obtain ⟨w,wU,yw,notL⟩ : ∃ w ∈ X \ {x,y}, G.Adj y w ∧ w ∉ L := by
    by_cases ul : u ∈ L
    · exact ⟨v,vU,yv,fun vl => uv ((uniq yu ul).trans (uniq yv vl).symm)⟩
    · exact ⟨u,uU,yu,ul⟩
  have wH : w ∈ X \ M := ⟨wU.1,fun m => (show w=x ∨ w=y ∨ w∈L by simpa only [M,S,Set.mem_setOf_eq,List.mem_cons] using m).elim
    (fun e => wU.2 (Or.inl e)) (fun d => d.elim (fun e => wU.2 (Or.inr e)) notL)⟩
  obtain ⟨i,wi⟩ := (K.cover w).mp wH
  have hL : h ∈ L := head ▸ List.head_mem ne
  have hu := inU hL
  obtain ⟨j,hj⟩ := K.hits_of_neighbor F (fun _ t => t.1) onH hu.1
    (fun m => m.2 (show h ∈ S by simp [S,hL])) (on _ hu)
  have split : L = h :: L.tail := by rw [← head,List.head_cons_tail]
  have next := (List.chain'_cons.mp (List.chain'_cons.mp
    (show (x :: y :: h :: L.tail).Chain' (fun s t => ∀ i j, K.hits s i → K.hits t j → i=j) by
      change (x :: y :: L).Chain' _ at edges
      exact (congrArg (fun l => x :: y :: l) split) ▸ edges)).2).1
  have ij := next i j ⟨w,wi,yw⟩ hj
  obtain ⟨k,ki,all⟩ := K.complete_to_another F (fun _ t => t.1) onH yX ry wi yw
  obtain ⟨s,sk⟩ := K.nonempty k
  exact ki ((next k j ⟨s,sk,all _ sk⟩ hj).trans ij.symm)

#print axioms SingletonCut.traceable_through_connector
end Graffiti199Depleted.Catalogue.Incomplete

