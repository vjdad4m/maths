import MissEdgeTypes
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X : Set V} {z r a b : V} {i j : RootComponent G X r}

omit [Fintype V] [DecidableEq V] in
private theorem contact_miss_distinct {p v : V} {k : RootComponent G X r}
    (pi : p ∈ rootedBlockContacts G X r i) (vk : v ∈ MissPart G X r k) : p ≠ v :=
  fun e => (noncontactComponent_subset k vk).2 (e ▸ pi.2.1)

/-- If a cubic contact has precisely the two vertices of its part and the
distinguished port as neighbors, every ordinary contact of another part
also touches this part. -/
theorem SingletonCut.cubic_contact_absorbs (F : SingletonCut G X z r a b)
    (hub : CubicContactPair G X r i) (ne : i ≠ j) {q : V} (qj : q ∈ rootedBlockContacts G X r j) :
    q ∈ rootedBlockContacts G X r i := by
  obtain ⟨p,pi,s,si,t,ti,_,only⟩ := hub
  obtain ⟨w,wj,qw⟩ := qj.2.2
  have sm := noncontactComponent_subset i si
  have wm := noncontactComponent_subset j wj
  have wr : w ≠ r := fun e => F.offX r (by simp) (e ▸ wm.1)
  have pw : ¬ G.Adj p w := by
    intro e
    rcases (only _).mp e with eq|eq|eq
    · exact wr eq
    · exact missPart_different ne si wj eq.symm
    · exact missPart_different ne ti wj eq.symm
  have pq : ¬ G.Adj p q := by
    intro e
    exact ((only _).mp e).elim qj.2.1.ne.symm (fun h =>
      h.elim (contact_miss_distinct qj si) (contact_miss_distinct qj ti))
  have qs : G.Adj q s := by
    by_contra miss
    apply pq
    exact F.exclusive_contacts_complete sm.1 wm.1 (missPart_different ne si wj) sm.2 wm.2
      (noncontactComponents_anticomplete ne si wj) pi.1 qj.1 pi.2.1 qj.2.1
      ((only s).mpr (Or.inr (Or.inl rfl))).symm (fun e => pw e.symm) qw.symm (fun e => miss e.symm)
  exact ⟨qj.1,qj.2.1,s,si,qs⟩

theorem SingletonCut.cubic_contact_forces_uniform (F : SingletonCut G X z r a b)
    (hub : CubicContactPair G X r i) (ne : i ≠ j) : UniformMissPart G X r j := by
  classical
  by_contra bad
  obtain ⟨q,qj,bj⟩ := F.bad_witness bad
  exact bj (F.shared_contact_good ne.symm qj (F.cubic_contact_absorbs hub ne qj))

theorem SingletonCut.cubic_contact_unique (F : SingletonCut G X z r a b)
    (h : CubicContactPair G X r i) (k : CubicContactPair G X r j) : i = j := by
  classical
  by_contra ne
  obtain ⟨q,qj,s,sj,t,tj,_,only⟩ := k
  obtain ⟨w,wi,qw⟩ := (F.cubic_contact_absorbs h ne qj).2.2
  rcases (only w).mp qw with e|e|e
  · exact F.offX r (by simp) (e ▸ (noncontactComponent_subset i wi).1)
  · exact missPart_different ne wi sj e
  · exact missPart_different ne wi tj e

#print axioms SingletonCut.cubic_contact_absorbs
#print axioms SingletonCut.cubic_contact_forces_uniform
#print axioms SingletonCut.cubic_contact_unique
end Graffiti199Depleted.Catalogue.Incomplete
