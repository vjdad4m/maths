import PairContacts
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X : Set V} {z r a b x y : V}

structure ExitTail (G : SimpleGraph V) (O : Set V) (e b : V) where
  tail : List V
  nodup : (e::tail).Nodup
  chain : (e::tail).Chain' G.Adj
  inside : ∀ u ∈ tail, u ∈ O
  finish : G.Adj ((e::tail).getLast (by simp)) b

omit [Fintype V] [DecidableEq V] in
private theorem tail_from_reach {O : Set V} {e w : V} (eb : e ≠ b) (eO : e ∉ O)
    (wU : w ∈ insert b O) (edge : G.Adj e w)
    (reach : (G.induce (insert b O)).Reachable ⟨w,wU⟩ ⟨b,Or.inl rfl⟩) : Nonempty (ExitTail G O e b) := by
  classical
  obtain ⟨p⟩ := reach
  let q := p.toPath
  let L := q.val.support.map Subtype.val
  have nd : L.Nodup := q.property.support_nodup.map Subtype.val_injective
  have ne : L ≠ [] := fun h => q.val.support_ne_nil (List.map_eq_nil_iff.mp h)
  have first : L.head ne = w := by simp only [L,List.head_map,Walk.head_support]
  have last : L.getLast ne = b := by simp only [L,List.getLast_map,Walk.getLast_support]
  let T := L.dropLast
  have split : L = T ++ [b] := last ▸ (List.dropLast_append_getLast ne).symm
  have inU {t : V} (tm : t ∈ L) : t ∈ insert b O := by
    obtain ⟨u,_,eq⟩ := List.mem_map.mp tm; exact eq ▸ u.property
  have eL : e ∉ L := fun em => (inU em).elim eb eO
  have lc : L.Chain' G.Adj := (List.chain'_map _).mpr q.val.chain'_adj_support
  have full : (e :: L).Chain' G.Adj := by
    apply List.chain'_cons'.mpr ⟨?_,lc⟩
    intro u hu; rw [List.head?_eq_head ne,first] at hu; exact (Option.mem_some.mp hu) ▸ edge
  have final : ((e::T) ++ [b]).Chain' G.Adj := by simpa only [List.cons_append,← split] using full
  have n := List.nodup_append.mp (split ▸ nd)
  refine ⟨⟨T,List.nodup_cons.mpr ⟨fun h => eL (split.symm ▸ List.mem_append_left _ h),n.1⟩,
    final.left_of_append,?_,(List.chain'_append.mp final).2.2 _ (by rw [List.getLast?_eq_getLast (by simp)]; rfl) b (by simp)⟩⟩
  intro u um
  exact (inU (split.symm ▸ List.mem_append_left _ um)).resolve_left (fun e => n.2.2 um (by simp [e]))

/-- When the two two-element ordinary neighborhoods differ, deletion of the
common contacts together with r,a leaves an exclusive edge and b-z. Crossing
gives a route to b whose only point in the two neighborhoods is its first. -/
theorem SingletonCut.exclusive_exit (F : SingletonCut G X z r a b) (cross : CrossingBetweenSurvivingEdges G)
    (xX : x ∈ X) (yX : y ∈ X) (distinct : x ≠ y) (rx : ¬ G.Adj r x) (ry : ¬ G.Adj r y)
    (xy : ¬ G.Adj x y) (on : ∀ t ∈ X \ {x,y}, G.Adj r t)
    (A : PairContacts G (X \ {x,y}) a x) (B : PairContacts G (X \ {x,y}) a y)
    (ne : A.set ≠ B.set) :
    ∃ e : V, ((e ∈ A.set ∧ e ∉ B.set) ∨ (e ∈ B.set ∧ e ∉ A.set)) ∧
      Nonempty (ExitTail G {v | v ∈ X \ {x,y} ∧ v ∉ A.set ∧ v ∉ B.set} e b) := by
  classical
  let O := {v : V | v ∈ X \ {x,y} ∧ v ∉ A.set ∧ v ∉ B.set}
  let U := insert b O
  let D := insert a (insert r (A.set ∩ B.set))
  have excl {C E : Finset V} (cs : C.card=2) (es : E.card=2) (ne : C ≠ E) : ∃ v ∈ C, v ∉ E := by
    by_contra! sub; exact ne (Finset.eq_of_subset_of_card_le sub (by omega))
  obtain ⟨p,pa,pb⟩ := excl A.card B.card ne
  obtain ⟨q,qb,qa⟩ := excl B.card A.card ne.symm
  have pU := A.inside _ pa
  have qU := B.inside _ qb
  have pAdj := (A.exactAdj p).mpr (Or.inr pa)
  have qAdj := (B.exactAdj q).mpr (Or.inr qb)
  have off (v : V) (vX : v ∈ X) (s : V) (sm : s ∈ ({r,a,b} : Finset V)) : v ≠ s :=
    fun e => F.offX s sm (e ▸ vX)
  have aD : a ∈ ({r,a,b} : Finset V) := by simp
  have rD : r ∈ ({r,a,b} : Finset V) := by simp
  have bD : b ∈ ({r,a,b} : Finset V) := by simp
  have pq := F.exclusive_contacts_complete xX yX distinct rx ry xy pU.1 qU.1
    (on _ pU) (on _ qU) pAdj (fun e => ((B.exactAdj _).mp e).elim (off _ pU.1 a aD) pb) qAdj
    (fun e => ((A.exactAdj _).mp e).elim (off _ qU.1 a aD) qa)
  have count : D.card ≤ 3 := by
    have small : (A.set ∩ B.set).card < A.set.card := by
      apply Finset.card_lt_card
      exact Finset.ssubset_iff_of_subset Finset.inter_subset_left |>.mpr ⟨p,pa,by simp [pb]⟩
    have h1 := Finset.card_insert_le r (A.set ∩ B.set)
    have h2 := Finset.card_insert_le a (insert r (A.set ∩ B.set))
    change (insert a (insert r (A.set ∩ B.set))).card ≤ 3
    have := A.card
    omega
  let B0 : Set V := {v | ∃ vm : v ∈ U, (G.induce U).Reachable (⟨b,Or.inl rfl⟩ : U) ⟨v,vm⟩}
  let S := insert z B0
  have b0 : b ∈ B0 := ⟨Or.inl rfl,.rfl⟩
  have bp : b ∉ A.set := fun h => F.offX b bD (A.inside _ h).1
  have za0 : z ∉ A.set := fun h => F.zX (A.inside _ h).1
  have zb := (F.cut.2 b).mpr bD
  have za := (F.cut.2 a).mpr aD
  have zr := (F.cut.2 r).mpr rD
  have zc : z ∉ D := by simp [D,za.ne,zr.ne,za0]
  have bc : b ∉ D := by simp [D,F.ab.symm,F.rb.symm,bp]
  have pc : p ∉ D := by simp [D,off _ pU.1 a aD,off _ pU.1 r rD,pb]
  have qc : q ∉ D := by simp [D,off _ qU.1 a aD,off _ qU.1 r rD,qa]
  have outside {v : V} (vU : v ∈ X \ {x,y}) (vk : v ∈ A.set ∨ v ∈ B.set) : v ∉ S := by
    rintro (vz|⟨vm,_⟩)
    · exact F.zX (vz ▸ vU.1)
    · rcases vm with vb|vo
      · exact off _ vU.1 b bD vb
      · exact vk.elim vo.2.1 vo.2.2
  obtain ⟨w,ws,e,es,_wc,ec,we⟩ := cross D count S ⟨z,Or.inl rfl,b,Or.inr b0,zc,bc,zb⟩
    ⟨p,outside pU (Or.inl pa),q,outside qU (Or.inr qb),pc,qc,pq⟩
  have bS : b ∈ S := Or.inr b0
  have eb : e ≠ b := fun eq => es (eq.symm ▸ bS)
  have er : e ≠ r := fun eq => ec (by simp [D,eq])
  have ea : e ≠ a := fun eq => ec (by simp [D,eq])
  have ez : e ≠ z := fun eq => es (Or.inl eq)
  have eX : e ∈ X := (F.cover e).resolve_right (fun h => h.elim ez (fun h => h.elim er (fun h => h.elim ea eb)))
  have wb : w ∈ B0 := ws.resolve_left (fun eq => F.offX e ((F.cut.2 _).mp (eq ▸ we)) eX)
  obtain ⟨wu,reach⟩ := wb
  have eU : e ∉ U := fun vm => es (Or.inr ⟨vm,reach.trans (show (G.induce U).Adj ⟨w,wu⟩ ⟨e,vm⟩ from we).reachable⟩)
  have wfree : w ≠ a ∧ w ∉ A.set ∧ w ∉ B.set := by
    rcases wu with wb|wo
    · exact wb.symm ▸ ⟨F.ab.symm,bp,fun h => F.offX b bD (B.inside _ h).1⟩
    · exact ⟨off _ wo.1.1 a aD,wo.2⟩
  have ex : e ≠ x := fun eq => ((A.exactAdj _).mp (eq ▸ we.symm)).elim wfree.1 wfree.2.1
  have ey : e ≠ y := fun eq => ((B.exactAdj _).mp (eq ▸ we.symm)).elim wfree.1 wfree.2.2
  have either : e ∈ A.set ∨ e ∈ B.set := Classical.byContradiction fun h =>
    eU (Or.inr ⟨⟨eX,fun e => e.elim ex ey⟩,fun m => h (Or.inl m),fun m => h (Or.inr m)⟩)
  have both : ¬ (e ∈ A.set ∧ e ∈ B.set) := fun h => ec (by simp [D,h.1,h.2])
  refine ⟨e,either.elim (fun h => Or.inl ⟨h,fun m => both ⟨h,m⟩⟩) (fun h => Or.inr ⟨h,fun m => both ⟨m,h⟩⟩),?_⟩
  exact tail_from_reach eb (fun h => eU (Or.inr h)) wu we.symm reach.symm

#print axioms SingletonCut.exclusive_exit
end Graffiti199Depleted.Catalogue.Incomplete
