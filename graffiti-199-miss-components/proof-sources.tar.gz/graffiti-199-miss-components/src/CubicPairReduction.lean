import CatalogueMissComponents
open private component_only_vertex from ExactSingleton
open private cubic_three_neighbors from MissEdgeTypes
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
universe u
variable {V : Type u} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {X : Set V} {z r a b : V} {i : RootComponent G X r}

omit [DecidableRel G.Adj] in
private theorem no_two_isolates_with_third (conn : ConnectivityAtLeast G 3) (budget : treeNumber G ≤ 5)
    (no : ¬ Traceable G) {D : Finset V} (size : D.card = 3) (p q z : Survives D)
    (pz : p.val ≠ z.val) (qz : q.val ≠ z.val)
    (ip : ∀ v : Survives D, ¬ G.Adj p.val v.val) (iq : ∀ v : Survives D, ¬ G.Adj q.val v.val) : p.val = q.val := by
  classical
  by_contra pq
  let K := (DeletionGraph G D).ConnectedComponent
  let m := (DeletionGraph G D).connectedComponentMk
  have diff {s t : Survives D} (iso : ∀ v : Survives D, ¬ G.Adj s.val v.val)
      (ne : s.val ≠ t.val) : m s ≠ m t := fun eq => ne (congrArg Subtype.val (component_only_vertex iso t eq.symm))
  letI : Fintype K := Fintype.ofFinite K
  apply no (traceable_of_three_or_more_components conn budget size ?_)
  have count := Finset.card_le_univ ({m p,m q,m z} : Finset K)
  simpa [Nat.card_eq_fintype_card,diff ip pq,diff ip pz,diff iq qz] using count

/-- The surviving uniform edge has high endpoints and precisely one cubic
neighbor at either endpoint. The same cubic vertex is adjacent to both. -/
theorem SingletonCut.uniform_pair_unique_cubic (F : SingletonCut G X z r a b)
    (smaller : SmallerAtThree.{u} (Fintype.card V)) (order : 5 ≤ Fintype.card V)
    (cross : CrossingBetweenSurvivingEdges G) (no : ¬ Traceable G)
    (ind : ∀ u v, G.degree u = 3 → G.degree v = 3 → ¬ G.Adj u v)
    (three : ∃ T : Finset V, T.card = 3 ∧ ∀ v ∈ T, v ∈ Noncontacts G X r)
    (good : UniformMissPart G X r i) (large : 2 ≤ Nat.card (MissPart G X r i)) :
    ∃ x y p : V, x ≠ y ∧ MissPart G X r i = ({x,y} : Set V) ∧ G.Adj x y ∧
      4 ≤ G.degree x ∧ 4 ≤ G.degree y ∧ G.degree p = 3 ∧ G.neighborFinset p = {r,x,y} ∧
      ∀ w ∈ MissPart G X r i, ∀ q, G.Adj w q → (G.degree q = 3 ↔ q = p) := by
  classical
  obtain ⟨size,p,pi,x,xi,y,yi,xy,only⟩ := F.uniform_nonsingleton_has_cubic_contact smaller order cross no ind three good large
  let C := MissPart G X r i
  letI : Fintype C := Fintype.ofFinite C
  have eq : ({x,y} : Finset V) = C.toFinset := Finset.eq_of_subset_of_card_le
    (Finset.insert_subset (Set.mem_toFinset.mpr xi) (Finset.singleton_subset_iff.mpr (Set.mem_toFinset.mpr yi)))
    (by rw [Set.toFinset_card,← Nat.card_eq_fintype_card,Finset.card_pair xy]; exact size.le)
  have setEq : C = ({x,y} : Set V) := by ext v; change v ∈ C ↔ _; rw [← Set.mem_toFinset,← eq]; simp
  have off {v : V} (vi : v ∈ C) : r ≠ v := fun e => F.offX r (by simp) (e.symm ▸ (noncontactComponent_subset i vi).1)
  let D : Finset V := {r,x,y}
  have dcard : D.card = 3 := by simp [D,off xi,off yi,xy]
  have norm {v : V} (nb : ∀ t, G.Adj v t ↔ t=r ∨ t=x ∨ t=y) : G.neighborFinset v = D := by
    ext t
    rw [G.mem_neighborFinset,nb]; simp [D]
  have pd : G.degree p = 3 := by rw [← G.card_neighborFinset_eq_degree,norm only,dcard]
  have high {v : V} (vi : v ∈ C) : 4 ≤ G.degree v := by
    have ne : G.degree v ≠ 3 := fun (h : G.degree v=3) => ind _ _ pd h (good.2 p pi v vi)
    have lo := degree_of_small_deletion_preconnected (G := G) (by omega : 4 ≤ Fintype.card V)
      (fun K hk => (F.conn.2 K hk).preconnected) v
    exact lt_of_le_of_ne lo ne.symm
  refine ⟨x,y,p,xy,setEq,good.1 xi yi xy,high xi,high yi,pd,norm only,?_⟩
  intro w wi q wq
  refine ⟨?_,fun e => e.symm ▸ pd⟩
  intro qd
  have qi : q ∉ C := fun h => (by have := high h; omega : G.degree q ≠ 3) qd
  rcases F.part_boundary wi qi wq with qa|qb|hit
  · exact (F.other_port_high ind (by simp [qa] : q ∈ ({r,a,b} : Finset V)) qd).elim
  · exact (F.other_port_high ind (by simp [qb] : q ∈ ({r,a,b} : Finset V)) qd).elim
  have onlyQ := cubic_three_neighbors qd (off xi) (off yi) xy hit.2.1.symm (good.2 q hit x xi) (good.2 q hit y yi)
  have surv {v : V} (eqN : G.neighborFinset v = D) : v ∉ D := fun h =>
    G.loopless v ((G.mem_neighborFinset _ _).mp (eqN.symm ▸ h))
  have iso {v : V} (eqN : G.neighborFinset v = D) (t : Survives D) : ¬ G.Adj v t.val :=
    fun e => t.property (by simpa only [eqN] using (G.mem_neighborFinset v t.val).mpr e)
  have zz {v : V} (vX : v ∈ X) : z ≠ v := fun e => F.zX (e.symm ▸ vX)
  exact no_two_isolates_with_third F.conn F.budget no dcard
    ⟨q,surv (norm onlyQ)⟩ ⟨p,surv (norm only)⟩
    ⟨z,by simp [D,((F.cut.2 r).mpr (by simp)).ne,zz (noncontactComponent_subset i xi).1,zz (noncontactComponent_subset i yi).1]⟩
    (zz hit.1).symm (zz pi.1).symm (iso (norm onlyQ)) (iso (norm only))

#print axioms SingletonCut.uniform_pair_unique_cubic
end Graffiti199Depleted.Catalogue.Incomplete

