import CubicExit
import FlexibleEdge
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X : Set V} {z r a b x y e : V}

private theorem prefix_exit (F : SingletonCut G X z r a b) (on : ∀ w ∈ X \ {x,y}, G.Adj r w)
    (ry : ¬ G.Adj r y) (ay : G.Adj a y) {O : Set V} (subO : O ⊆ X)
    (E : ExitTail G O e b) (eX : e ∈ X) {h : V} (rh : G.Adj r h) (J : List V)
    (nd : (y::h::J).Nodup) (chain : (y::h::J).Chain' G.Adj)
    (endEdge : G.Adj ((y::h::J).getLast (by simp)) e)
    (cover : ∀ u ∈ y::h::J, u ∈ X ∧ u ≠ e ∧ u ∉ O) (xm : x ∈ y::h::J)
    {q : V} (qX : q ∈ X) (qL : q ∉ y::h::J) (qe : q ≠ e) (qO : q ∉ O) (yq : G.Adj y q) :
    Traceable G := by
  let A := y::h::J
  let B := e::E.tail
  let M := {v : V | v ∈ A ++ B}
  have dis (v : V) (vm : v ∈ A) : v ∉ B := by
    intro vb; rcases List.mem_cons.mp vb with eq|t
    · exact (cover _ vm).2.1 eq
    · exact (cover _ vm).2.2 (E.inside _ t)
  have linked : (A ++ B).Chain' G.Adj := by
    apply chain.append E.chain
    intro u hu v hv
    rw [List.getLast?_eq_getLast (by simp [A])] at hu
    have ve : e=v := by simpa [B] using hv
    exact (Option.mem_some.mp hu) ▸ ve ▸ endEdge
  let P : PathOn G M := ⟨A++B,by simp [A],linked,List.nodup_append.mpr ⟨nd,E.nodup,dis⟩,fun _ => Iff.rfl⟩
  have sub : M ⊆ X := by
    intro v m
    rcases List.mem_append.mp m with va|vb
    · exact (cover _ va).1
    · rcases List.mem_cons.mp vb with ve|t
      · exact ve.symm ▸ eX
      · exact subO (E.inside _ t)
  have xM : x ∈ M := List.mem_append_left B xm
  have yM : y ∈ M := List.mem_append_left B (List.mem_cons_self ..)
  have comp : ∀ v ∈ X \ M, G.Adj r v := by
    intro v m; exact on v ⟨m.1,fun d => m.2 (d.elim (fun t => t.symm ▸ xM) (fun t => (show v=y from t).symm ▸ yM))⟩
  have finish : G.Adj P.last b := by
    have pl : P.last = B.getLast (by simp [B]) := List.getLast_append_of_ne_nil _ (by simp [B])
    exact pl.symm ▸ E.finish
  have free : q ∉ M := fun m => (List.mem_append.mp m).elim qL (fun d =>
    (List.mem_cons.mp d).elim qe (fun t => qO (E.inside _ t)))
  exact F.traceable_of_reserved_edge sub comp P ay finish (A := []) (B := J ++ B) rfl ry
    ⟨q,⟨qX,free⟩,yq⟩ (Or.inl rh)

/-- Once an exit from the exclusive x contacts has been selected, an
explicit route uses the other miss as its initial vertex and preserves an
unused neighbor of that initial vertex. -/
private theorem oriented_exit (F : SingletonCut G X z r a b) (xX : x ∈ X) (yX : y ∈ X)
    (distinct : x ≠ y) (rx : ¬ G.Adj r x) (ry : ¬ G.Adj r y) (xy : ¬ G.Adj x y)
    (on : ∀ t ∈ X \ {x,y}, G.Adj r t) (A : PairContacts G (X \ {x,y}) a x)
    (B : PairContacts G (X \ {x,y}) a y) (ea : e ∈ A.set) (eb : e ∉ B.set)
    (E : ExitTail G {v | v ∈ X \ {x,y} ∧ v ∉ A.set ∧ v ∉ B.set} e b) : Traceable G := by
  classical
  let O := {v : V | v ∈ X \ {x,y} ∧ v ∉ A.set ∧ v ∉ B.set}
  have subO : O ⊆ X := fun _ h => h.1.1
  have xe := (A.exactAdj e).mpr (Or.inr ea)
  have eU := A.inside _ ea
  have ay := ((B.exactAdj a).mpr (Or.inl rfl)).symm
  have yo : y ∉ O := fun h => h.1.2 (Or.inr rfl)
  have xo : x ∉ O := fun h => h.1.2 (Or.inl rfl)
  have ye : y ≠ e := fun h => eU.2 (Or.inr h.symm)
  have qnot (p : V) (pb : p ∈ B.set) : p ≠ e := fun h => eb (h ▸ pb)
  by_cases common : ∃ c ∈ A.set, c ∈ B.set
  · obtain ⟨c,ca,cb⟩ := common
    obtain ⟨q,qb,qc⟩ := Finset.exists_mem_ne (by rw [B.card]; decide) c
    have cU := A.inside _ ca
    have qU := B.inside _ qb
    have yc := (B.exactAdj c).mpr (Or.inr cb)
    have xc := (A.exactAdj c).mpr (Or.inr ca)
    apply prefix_exit F on ry ay subO E eU.1 (on _ cU) [x]
      (by simp [yc.ne,distinct.symm,xc.ne.symm]) (by simp [List.chain'_cons,yc,xc.symm])
      (by simpa using xe) ?_ (by simp) qU.1 ?_ (qnot q qb) (fun h => h.2.2 qb) ((B.exactAdj q).mpr (Or.inr qb))
    · intro u um
      rcases (show u=y ∨ u=c ∨ u=x by simpa using um) with uy|uc|ux
      · exact uy.symm ▸ ⟨yX,ye,yo⟩
      · exact uc.symm ▸ ⟨cU.1,qnot c cb,fun h => h.2.1 ca⟩
      · exact ux.symm ▸ ⟨xX,xe.ne,xo⟩
    · simp [qc,show q≠x from fun h => qU.2 (Or.inl h),show q≠y from fun h => qU.2 (Or.inr h)]
  · obtain ⟨d,da,de⟩ := Finset.exists_mem_ne (by rw [A.card]; decide) e
    obtain ⟨c,cb⟩ := Finset.card_pos.mp (by rw [B.card]; decide)
    obtain ⟨q,qb,qc⟩ := Finset.exists_mem_ne (by rw [B.card]; decide) c
    have dU := A.inside _ da
    have cU := B.inside _ cb
    have qU := B.inside _ qb
    have ca : c ∉ A.set := fun h => common ⟨c,h,cb⟩
    have db : d ∉ B.set := fun h => common ⟨d,da,h⟩
    have yc := (B.exactAdj c).mpr (Or.inr cb)
    have xd := (A.exactAdj d).mpr (Or.inr da)
    have porta {t : V} (h : t ∈ X) : t ≠ a := fun eq => F.offX a (by simp) (eq ▸ h)
    have dc := F.exclusive_contacts_complete xX yX distinct rx ry xy dU.1 cU.1 (on _ dU) (on _ cU)
      xd (fun edge => ((B.exactAdj _).mp edge).elim (porta dU.1) db) yc
      (fun edge => ((A.exactAdj _).mp edge).elim (porta cU.1) ca)
    have yd : y ≠ d := fun e => dU.2 (Or.inr e.symm)
    have cx : c ≠ x := fun e => cU.2 (Or.inl e)
    apply prefix_exit F on ry ay subO E eU.1 (on _ cU) [d,x]
      (by simp [yc.ne,yd,distinct.symm,dc.ne.symm,cx,xd.ne.symm]) (by simp [List.chain'_cons,yc,dc.symm,xd.symm])
      (by simpa using xe) ?_ (by simp) qU.1 ?_ (qnot q qb) (fun h => h.2.2 qb) ((B.exactAdj q).mpr (Or.inr qb))
    · intro u um
      rcases (show u=y ∨ u=c ∨ u=d ∨ u=x by simpa using um) with uy|uc|ud|ux
      · exact uy.symm ▸ ⟨yX,ye,yo⟩
      · exact uc.symm ▸ ⟨cU.1,qnot c cb,fun h => h.2.2 cb⟩
      · exact ud.symm ▸ ⟨dU.1,de,fun h => h.2.1 da⟩
      · exact ux.symm ▸ ⟨xX,xe.ne,xo⟩
    · simp [qc,show q≠d from fun h => db (h ▸ qb),show q≠x from fun h => qU.2 (Or.inl h),
        show q≠y from fun h => qU.2 (Or.inr h)]

theorem SingletonCut.traceable_of_common_port_cubic_pair [DecidableRel G.Adj] (F : SingletonCut G X z r a b)
    (cross : CrossingBetweenSurvivingEdges G) (xX : x ∈ X) (yX : y ∈ X) (distinct : x ≠ y)
    (rx : ¬ G.Adj r x) (ry : ¬ G.Adj r y) (xy : ¬ G.Adj x y) (on : ∀ t ∈ X \ {x,y}, G.Adj r t)
    (xa : G.Adj x a) (ya : G.Adj y a) (xb : ¬ G.Adj x b) (yb : ¬ G.Adj y b)
    (dx : G.degree x=3) (dy : G.degree y=3) : Traceable G := by
  classical
  let U := X \ ({x,y} : Set V)
  let U' := X \ ({y,x} : Set V)
  have flipU : U=U' := congrArg (X \ ·) (Set.pair_comm x y)
  obtain ⟨A⟩ := F.pair_contacts_of_cubic xX rx xa xb xy dx
  obtain ⟨B'⟩ := F.pair_contacts_of_cubic yX ry ya yb (fun e => xy e.symm) dy
  let B : PairContacts G U a y := flipU.symm ▸ B'
  by_cases same : A.set = B.set
  · exact F.traceable_of_equal_pair_contacts xX yX distinct A B same
  obtain ⟨w,ex,⟨tail⟩⟩ := F.exclusive_exit cross xX yX distinct rx ry xy on A B same
  rcases ex with h|h
  · exact oriented_exit F xX yX distinct rx ry xy on A B h.1 h.2 tail
  · let Bs : PairContacts G U' a y := {B with inside := fun v hv => flipU ▸ B.inside v hv}
    let As : PairContacts G U' a x := {A with inside := fun v hv => flipU ▸ A.inside v hv}
    have out : {v : V | v ∈ U ∧ v ∉ A.set ∧ v ∉ B.set} =
        {v : V | v ∈ U' ∧ v ∉ Bs.set ∧ v ∉ As.set} := by ext v; simp [Bs,As,flipU,and_left_comm,and_comm]
    exact oriented_exit F yX xX distinct.symm ry rx (fun e => xy e.symm) ((Set.pair_comm x y) ▸ on) Bs As h.1 h.2 (out ▸ (show ExitTail G {v : V | v ∈ U ∧ v ∉ A.set ∧ v ∉ B.set} w b from tail))

#print axioms SingletonCut.traceable_of_common_port_cubic_pair
end Graffiti199Depleted.Catalogue.Incomplete

