import FlexibleExit
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X : Set V} {z r a b x y : V}

private theorem five_fixed_end (F : SingletonCut G X z r a b) {u v : V} (uX : u ∈ X) (vX : v ∈ X)
    (uv : G.Adj u v) (ua : G.Adj u a) (ub : G.Adj u b) (va : G.Adj v a) (vb : G.Adj v b)
    {t : V} (poss : t = a ∨ t = b ∨ t = v) : Traverses G (insert r (X \ {u,v}))ᶜ u t := by
  let W := insert r (X \ ({u,v} : Set V))
  have za := (F.cut.2 a).mpr (by simp)
  have zb := (F.cut.2 b).mpr (by simp)
  have zu : z ≠ u := fun e => F.zX (e.symm ▸ uX)
  have zv : z ≠ v := fun e => F.zX (e.symm ▸ vX)
  have part (t : V) : t ∈ Wᶜ ↔ t = z ∨ t = a ∨ t = b ∨ t = u ∨ t = v := by
    apply (F.complement_of_cone (M := {u,v}) (by
      rintro w (wu|wv)
      · exact wu.symm ▸ uX
      · exact (show w = v from wv).symm ▸ vX) t).trans
    simp
  rcases poss with e|e|e <;> subst t
  · let L := [u,v,b,z,a]
    let P : PathOn G Wᶜ := ⟨L,by simp [L],by simp [L,List.chain'_cons,za,zb,za.symm,zb.symm,uv,uv.symm,ua,ub,va,vb,ua.symm,ub.symm,va.symm,vb.symm],
      by simp [L,za.ne,zb.ne,zu,zv,F.ab,uv.ne,ua.ne,ub.ne,va.ne,vb.ne,za.ne.symm,zb.ne.symm,zu.symm,zv.symm,F.ab.symm,uv.ne.symm,ua.ne.symm,ub.ne.symm,va.ne.symm,vb.ne.symm],by
        intro t; rw [part]; simp [L,or_left_comm,or_comm,or_assoc]⟩
    exact ⟨P,rfl,rfl⟩
  · let L := [u,v,a,z,b]
    let P : PathOn G Wᶜ := ⟨L,by simp [L],by simp [L,List.chain'_cons,za,zb,za.symm,zb.symm,uv,uv.symm,ua,ub,va,vb,ua.symm,ub.symm,va.symm,vb.symm],
      by simp [L,za.ne,zb.ne,zu,zv,F.ab,uv.ne,ua.ne,ub.ne,va.ne,vb.ne,za.ne.symm,zb.ne.symm,zu.symm,zv.symm,F.ab.symm,uv.ne.symm,ua.ne.symm,ub.ne.symm,va.ne.symm,vb.ne.symm],by
        intro t; rw [part]; simp [L,or_left_comm,or_comm,or_assoc]⟩
    exact ⟨P,rfl,rfl⟩
  · let L := [u,a,z,b,v]
    let P : PathOn G Wᶜ := ⟨L,by simp [L],by simp [L,List.chain'_cons,za,zb,za.symm,zb.symm,uv,uv.symm,ua,ub,va,vb,ua.symm,ub.symm,va.symm,vb.symm],
      by simp [L,za.ne,zb.ne,zu,zv,F.ab,uv.ne,ua.ne,ub.ne,va.ne,vb.ne,za.ne.symm,zb.ne.symm,zu.symm,zv.symm,F.ab.symm,uv.ne.symm,ua.ne.symm,ub.ne.symm,va.ne.symm,vb.ne.symm],by
        intro t; rw [part]; simp [L,or_left_comm,or_comm,or_assoc]⟩
    exact ⟨P,rfl,rfl⟩

private theorem oriented_two_miss (F : SingletonCut G X z r a b)
    (xX : x ∈ X) (yX : y ∈ X) (xy : G.Adj x y)
    (xa : G.Adj x a) (xb : G.Adj x b) (ya : G.Adj y a) (yb : G.Adj y b)
    (rx : ¬ G.Adj r x) (on : ∀ h ∈ X \ {x,y}, G.Adj r h)
    (touch : ∃ h ∈ X \ {x,y}, G.Adj x h) : Traceable G := by
  classical
  let M : Set V := {x,y}
  let H := X \ M
  have sub : M ⊆ X := by
    rintro w (wx|wy)
    · exact wx.symm ▸ xX
    · exact (show w = y from wy).symm ▸ yX
  have path := (Traverses.single x).join (Traverses.single y) (by simpa using xy.ne) xy
  have pair : Traverses G M x y := by simpa [M,Set.pair_comm y x] using path
  obtain ⟨Q,close⟩ := F.cycle_from_missing_path sub pair xa.symm yb.symm
  apply Classical.byContradiction
  intro no
  obtain ⟨C⟩ := F.three_cliques_of_cycle (H := H) (fun _ h => h.1) on
    (by obtain ⟨w,wh,_⟩ := touch; exact ⟨w,wh⟩) Q close no
  apply no (C.traceable_of_flexible_exit F (fun _ h => h.1) on xX rx touch ?_)
  intro t tW tx contact
  obtain ⟨h,hH,th⟩ := contact
  rcases (F.complement_of_cone sub t).mp tW with tz|ta|tb|tm
  · exact (F.offX h ((F.cut.2 h).mp (tz ▸ th)) hH.1).elim
  · exact five_fixed_end F xX yX xy xa xb ya yb (Or.inl ta)
  · exact five_fixed_end F xX yX xy xa xb ya yb (Or.inr (Or.inl tb))
  · have e : t = x ∨ t = y := tm
    exact five_fixed_end F xX yX xy xa xb ya yb (Or.inr (Or.inr (e.resolve_left tx)))

/-- An arbitrary-order part of the all-three-deficient branch. The port r
misses exactly an adjacent pair, and both missed vertices see the other two
ports. The ordinary neighbors of r may be disconnected. -/
theorem SingletonCut.traceable_of_adjacent_two_misses (F : SingletonCut G X z r a b)
    (xX : x ∈ X) (yX : y ∈ X) (xy : G.Adj x y) (rx : ¬ G.Adj r x) (ry : ¬ G.Adj r y)
    (on : ∀ h ∈ X \ {x,y}, G.Adj r h)
    (xa : G.Adj x a) (xb : G.Adj x b) (ya : G.Adj y a) (yb : G.Adj y b) : Traceable G := by
  classical
  let H := X \ ({x,y} : Set V)
  obtain ⟨h,hX,rh⟩ := F.toOneShore.contact (Finset.mem_insert_self r _)
  have hx : h ≠ x := fun e => rx (e ▸ rh)
  have hy : h ≠ y := fun e => ry (e ▸ rh)
  have hH : h ∈ H := ⟨hX,by simp [hx,hy]⟩
  obtain ⟨walk⟩ := F.connX.preconnected (⟨h,hX⟩ : X) ⟨x,xX⟩
  have off : x ∉ H := fun h => h.2 (Or.inl rfl)
  obtain ⟨i,ih,j,jh,edge⟩ := crossingOnWalk (U := {w : X | w.val ∈ H}) walk hH off
  have hits : j.val = x ∨ j.val = y := Classical.byContradiction fun h => jh ⟨j.property,h⟩
  rcases hits with jx|jy
  · exact oriented_two_miss F xX yX xy xa xb ya yb rx on ⟨i.val,ih,jx ▸ edge.symm⟩
  · have eq : ({x,y} : Set V) = {y,x} := Set.pair_comm x y
    exact oriented_two_miss F yX xX xy.symm ya yb xa xb ry (eq ▸ on) ⟨i.val,eq ▸ ih,jy ▸ edge.symm⟩

#print axioms SingletonCut.traceable_of_adjacent_two_misses
end Graffiti199Depleted.Catalogue.Incomplete

