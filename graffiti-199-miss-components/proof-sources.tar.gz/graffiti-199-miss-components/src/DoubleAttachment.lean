import NestedMissStructure
open private NoRootedFour.forbids_four from RootedBlocks
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X : Set V} {z r a b p q : V} {i j k l : RootComponent G X r}

theorem SingletonCut.contact_at_most_two_parts (F : SingletonCut G X z r a b)
    (ij : i ≠ j) (ik : i ≠ k) (jk : j ≠ k)
    (pi : p ∈ rootedBlockContacts G X r i) (pj : p ∈ rootedBlockContacts G X r j)
    (pk : p ∈ rootedBlockContacts G X r k) : False := by
  obtain ⟨u,ui,pu⟩ := pi.2.2
  obtain ⟨v,vj,pv⟩ := pj.2.2
  obtain ⟨w,wk,pw⟩ := pk.2.2
  exact NoRootedFour.forbids_four (F.contact_no_four_on_misses pi.1 pi.2.1)
    (noncontactComponent_subset i ui) (noncontactComponent_subset j vj) (noncontactComponent_subset k wk)
    (by simp [pu.ne,pv.ne,pw.ne,missPart_different ij ui vj,missPart_different ik ui wk,missPart_different jk vj wk]) pu
    (Or.inl ⟨pv.symm,noncontactComponents_anticomplete ij.symm vj ui⟩)
    (Or.inl ⟨pw.symm,noncontactComponents_anticomplete ik.symm wk ui,noncontactComponents_anticomplete jk.symm wk vj⟩)

/-- Two ordinary contacts meeting two missed components apiece must
share a component. Otherwise they and four missed vertices induce
the six-vertex tree having two adjacent vertices of degree three. -/
theorem SingletonCut.double_contacts_intersect (F : SingletonCut G X z r a b)
    (ij : i ≠ j) (kl : k ≠ l)
    (pi : p ∈ rootedBlockContacts G X r i) (pj : p ∈ rootedBlockContacts G X r j)
    (qk : q ∈ rootedBlockContacts G X r k) (ql : q ∈ rootedBlockContacts G X r l) :
    i = k ∨ i = l ∨ j = k ∨ j = l := by
  classical
  by_contra! no
  obtain ⟨ik,il,jk,jl⟩ := no
  obtain ⟨u,ui,pu⟩ := pi.2.2
  obtain ⟨v,vj,pv⟩ := pj.2.2
  obtain ⟨w,wk,qw⟩ := qk.2.2
  obtain ⟨t,tl,qt⟩ := ql.2.2
  have pOff {m : RootComponent G X r} (im : i ≠ m) (jm : j ≠ m) {x : V} (xm : x ∈ MissPart G X r m) : ¬ G.Adj p x :=
    fun e => F.contact_at_most_two_parts ij im jm pi pj ⟨pi.1,pi.2.1,x,xm,e⟩
  have qOff {m : RootComponent G X r} (km : k ≠ m) (lm : l ≠ m) {x : V} (xm : x ∈ MissPart G X r m) : ¬ G.Adj q x :=
    fun e => F.contact_at_most_two_parts kl km lm qk ql ⟨qk.1,qk.2.1,x,xm,e⟩
  have um := noncontactComponent_subset i ui
  have wm := noncontactComponent_subset k wk
  have pq := F.exclusive_contacts_complete um.1 wm.1 (missPart_different ik ui wk) um.2 wm.2
    (noncontactComponents_anticomplete ik ui wk) pi.1 qk.1 pi.2.1 qk.2.1 pu.symm (fun e => pOff ik jk wk e.symm)
    qw.symm (fun e => qOff (Ne.symm ik) (Ne.symm il) ui e.symm)
  have differ {x : V} {m : RootComponent G X r} (xm : x ∈ MissPart G X r m) {v : V} (rv : G.Adj r v) : x ≠ v :=
    fun e => (noncontactComponent_subset m xm).2 (e.symm ▸ rv)
  obtain ⟨f,h0,h1,h2,h3,root⟩ := four_ordering (G := G) (r := p) (x := q) (y := w) (z := t)
    (by simp [pq.ne,(differ wk pi.2.1).symm,(differ tl pi.2.1).symm,qw.ne,qt.ne,missPart_different kl wk tl])
    pq (Or.inr ⟨qw.symm,fun e => pOff ik jk wk e.symm⟩)
    (Or.inr (Or.inl ⟨qt.symm,fun e => pOff il jl tl e.symm,noncontactComponents_anticomplete kl.symm tl wk⟩))
  have off {m : RootComponent G X r} (mk : m ≠ k) (ml : m ≠ l) {x : V} (xm : x ∈ MissPart G X r m)
      (h : Fin 4) : x ≠ f h := by
    fin_cases h
    · exact h0.symm ▸ differ xm pi.2.1
    · exact h1.symm ▸ differ xm qk.2.1
    · exact h2.symm ▸ missPart_different mk xm wk
    · exact h3.symm ▸ missPart_different ml xm tl
  have anti {m : RootComponent G X r} (mk : m ≠ k) (ml : m ≠ l) {x : V} (xm : x ∈ MissPart G X r m)
      (h : Fin 4) (hn : h ≠ 0) : ¬ G.Adj (f h) x := by
    fin_cases h
    · exact (hn rfl).elim
    · exact h1.symm ▸ qOff mk.symm ml.symm xm
    · exact h2.symm ▸ noncontactComponents_anticomplete mk.symm wk xm
    · exact h3.symm ▸ noncontactComponents_anticomplete ml.symm tl xm
  have six := six_of_two_leaves f root (missPart_different ij ui vj) (noncontactComponents_anticomplete ij.symm vj ui)
    (h0.symm ▸ pu) (h0.symm ▸ pv) (off ik il ui) (off jk jl vj) (anti ik il ui) (anti jk jl vj)
  exact (Nat.not_succ_le_self 5) (six.trans F.budget)

#print axioms SingletonCut.contact_at_most_two_parts
#print axioms SingletonCut.double_contacts_intersect
end Graffiti199Depleted.Catalogue.Incomplete
