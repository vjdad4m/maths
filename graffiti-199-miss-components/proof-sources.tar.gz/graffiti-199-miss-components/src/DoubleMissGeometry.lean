import UniqueMissDegree
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {X : Set V} {z r a b x y p q : V}

omit [DecidableRel G.Adj] in
theorem SingletonCut.swap_first_two (F : SingletonCut G X z r a b) : SingletonCut G X z a r b := by
  have eq : ({a,r,b} : Finset V) = {r,a,b} := by ext v; simp [or_left_comm]
  refine ⟨⟨F.conn,F.ra.symm,F.ab,F.rb,eq.symm ▸ F.offX,eq.symm ▸ F.boundX,F.connX⟩,
    F.budget,F.zX,eq.symm ▸ F.cut,?_⟩
  intro v
  rcases F.cover v with h|h|h|h|h <;> tauto

theorem SingletonCut.ordinary_tip (F : SingletonCut G X z r a b)
    (xX : x ∈ X) (rx : ¬ G.Adj r x) (xa : G.Adj x a) (xb : G.Adj x b) (degree : G.degree x = 3) :
    ∃ p ∈ X, G.Adj x p ∧ ∀ t ∈ X, G.Adj x t → t = p := by
  classical
  have more : ({a,b} : Finset V).card < (G.neighborFinset x).card := by
    rw [G.card_neighborFinset_eq_degree,degree,Finset.card_pair F.ab]; decide
  obtain ⟨p,pm,other⟩ := Finset.exists_mem_not_mem_of_card_lt_card more
  have xp := (G.mem_neighborFinset x p).mp pm
  have pa : p ≠ a := fun e => other (by simp [e])
  have pb : p ≠ b := fun e => other (by simp [e])
  have pX : p ∈ X := by
    rcases F.cover p with h|h|h|h|h
    · exact h
    · exact (F.offX x ((F.cut.2 x).mp (h ▸ xp.symm)) xX).elim
    · exact (rx (h ▸ xp.symm)).elim
    · contradiction
    · contradiction
  have setEq : ({p,a,b} : Finset V) = G.neighborFinset x := by
    apply Finset.eq_of_subset_of_card_le
    · intro t ht
      simp only [Finset.mem_insert,Finset.mem_singleton] at ht
      rcases ht with rfl|rfl|rfl <;> apply (G.mem_neighborFinset _ _).mpr <;> assumption
    · simp [G.card_neighborFinset_eq_degree,degree,pa,pb,F.ab]
  refine ⟨p,pX,xp,?_⟩
  intro t tX xt
  have mem := setEq.symm ▸ (G.mem_neighborFinset x t).mpr xt
  simp only [Finset.mem_insert,Finset.mem_singleton] at mem
  rcases mem with e|e|e
  · exact e
  · exact (F.offX a (by simp) (e ▸ tX)).elim
  · exact (F.offX b (by simp) (e ▸ tX)).elim

omit [Fintype V] [DecidableEq V] [DecidableRel G.Adj] in
/-- In a connected shore with two nonadjacent leaves x,y, the neighbor p
of x meets its exterior whenever the exterior is nonempty. -/
theorem exit_between_two_leaves (conn : (G.induce X).Connected) (pX : p ∈ X)
    (one : ∀ t ∈ X, G.Adj x t → t = p) (other : ∀ t ∈ X, G.Adj y t → t = q)
    (outside : ∃ v ∈ X, v ≠ x ∧ v ≠ y ∧ v ≠ p) :
    ∃ t ∈ X, t ≠ x ∧ t ≠ y ∧ t ≠ p ∧ G.Adj p t := by
  obtain ⟨v,hv,vx,vy,vp⟩ := outside
  let K : Set X := {w | w.val = x ∨ w.val = p ∨ (w.val = y ∧ q = p)}
  obtain ⟨walk⟩ := conn.preconnected (⟨p,pX⟩ : X) ⟨v,hv⟩
  obtain ⟨i,hi,j,hj,ij⟩ := crossingOnWalk (U := K) walk (Or.inr (Or.inl rfl))
    (by simp [K,vx,vy,vp])
  have edge : G.Adj i.val j.val := ij
  change i.val = x ∨ i.val = p ∨ i.val = y ∧ q = p at hi
  change ¬ (j.val = x ∨ j.val = p ∨ j.val = y ∧ q = p) at hj
  rcases hi with ix|ip|⟨iy,qp⟩
  · exact (hj (Or.inr (Or.inl (one _ j.property (ix ▸ edge))))).elim
  · have pj : G.Adj p j.val := ip ▸ edge
    refine ⟨j.val,j.property,fun e => hj (Or.inl e),?_,fun e => hj (Or.inr (Or.inl e)),pj⟩
    intro jy
    exact hj (Or.inr (Or.inr ⟨jy,(other _ pX (jy ▸ pj.symm)).symm⟩))
  · exact (hj (Or.inr (Or.inl ((other _ j.property (iy ▸ edge)).trans qp)))).elim

#print axioms exit_between_two_leaves
end Graffiti199Depleted.Catalogue.Incomplete
