import RightArm
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X : Set V} {z r a b x y : V}

omit [Fintype V] [DecidableEq V] in
private theorem ordered_contacts {L : List V} {u v : V} (um : u ∈ L) (vm : v ∈ L) (uv : u ≠ v)
    (xu : G.Adj x u) (xv : G.Adj x v) :
    ∃ (A : List V) (p q : V) (B : List V), L = A ++ q :: B ∧ p ∈ A ∧ G.Adj x p ∧ G.Adj x q := by
  obtain ⟨A,B,eq⟩ := List.append_of_mem um
  by_cases va : v ∈ A
  · exact ⟨A,v,u,B,eq,va,xv,xu⟩
  · have vb : v ∈ B := by simpa [eq,va,uv.symm] using vm
    obtain ⟨C,D,split⟩ := List.append_of_mem vb
    exact ⟨A ++ u :: C,u,v,D,by simp [eq,split,List.append_assoc],by simp,xu,xv⟩

/-- If all ordinary neighbors of x are currently on a right arm, two of
them allow a new arm. Jump from a fresh y-contact to the later x-contact
and retain the suffix, thereby freeing the earlier x-contact. -/
theorem SingletonCut.free_contact_of_two (F : SingletonCut G X z r a b)
    (xX : x ∈ X) (yX : y ∈ X) (distinct : x ≠ y) (rx : ¬ G.Adj r x) (ry : ¬ G.Adj r y)
    (xy : ¬ G.Adj x y) (on : ∀ w ∈ X \ {x,y}, G.Adj r w)
    (R : RightArm G (X \ {x,y}) y b)
    (two : ∃ u ∈ X \ {x,y}, ∃ v ∈ X \ {x,y}, u ≠ v ∧ G.Adj x u ∧ G.Adj x v)
    (many : ∀ i j : V, ∃ w ∈ X \ {x,y}, w ≠ i ∧ w ≠ j ∧ G.Adj y w) :
    ∃ R' : RightArm G (X \ {x,y}) y b, ∃ s ∈ X \ {x,y}, G.Adj x s ∧ s ∉ R'.h :: R'.tail := by
  classical
  let L := R.h :: R.tail
  by_cases ready : ∃ s ∈ X \ {x,y}, G.Adj x s ∧ s ∉ L
  · exact ⟨R,ready⟩
  have all (s : V) (su : s ∈ X \ {x,y}) (xs : G.Adj x s) : s ∈ L :=
    Classical.byContradiction fun sL => ready ⟨s,su,xs,sL⟩
  obtain ⟨u,uU,v,vU,uv,xu,xv⟩ := two
  obtain ⟨A,p,q,B,split,pA,xp,xq⟩ := ordered_contacts (all _ uU xu) (all _ vU xv) uv xu xv
  let T := q :: B
  have subset (w : V) (wm : w ∈ T) : w ∈ L := split.symm ▸ List.mem_append_right A wm
  have qU := R.inside _ (subset _ (List.mem_cons_self ..))
  have pU := R.inside _ (split.symm ▸ List.mem_append_left T pA)
  have nd := List.nodup_append.mp (split ▸ (show L.Nodup from R.nodup))
  have an : A ≠ [] := List.ne_nil_of_mem pA
  have hA : R.h ∈ A := by
    have first := congrArg List.head? split
    have orig : L.head? = some R.h := rfl
    rw [orig,List.head?_append,List.head?_eq_head an] at first
    exact (show R.h = A.head an by simpa using first).symm ▸ List.head_mem an
  have noHead : R.h ∉ T := nd.2.2 hA
  have qy : ¬ G.Adj y q := fun e => noHead ((R.only q (subset _ (List.mem_cons_self ..)) e) ▸ List.mem_cons_self ..)
  obtain ⟨t,tU,th,_,yt⟩ := many R.h R.h
  have off : t ∉ L := fun m => th (R.only _ m yt)
  have xt : ¬ G.Adj x t := fun e => off (all _ tU e)
  have qt := F.exclusive_contacts_complete xX yX distinct rx ry xy qU.1 tU.1
    (on q qU) (on t tU) xq qy yt xt
  have tailEnd : T.getLast (by simp [T]) = L.getLast (by simp [L]) := by
    have ends := congrArg List.getLast? split
    rw [List.getLast?_eq_getLast (by simp [L]),List.getLast?_append_of_ne_nil _ (by simp),
      List.getLast?_eq_getLast (by simp)] at ends
    exact (Option.some.inj ends).symm
  let R' : RightArm G (X \ {x,y}) y b := {
    h := t, tail := T
    nodup := List.nodup_cons.mpr ⟨fun wm => off (subset _ wm),nd.2.1⟩
    chain := List.chain'_cons.mpr ⟨qt.symm,(split ▸ (show L.Chain' G.Adj from R.chain)).right_of_append⟩
    inside := by intro w wm; rcases List.mem_cons.mp wm with wt|wT
                 · exact wt.symm ▸ tU
                 · exact R.inside _ (subset _ wT)
    start := yt
    only := by intro w wm yw; rcases List.mem_cons.mp wm with wt|wt
               · exact wt
               · exact (noHead ((R.only _ (subset _ wt) yw) ▸ wt)).elim
    finish := by change G.Adj (T.getLast _) b; exact tailEnd.symm ▸ R.finish }
  refine ⟨R',p,pU,xp,?_⟩
  intro pm
  rcases List.mem_cons.mp pm with pt|pT
  · exact xt ((show p=t from pt) ▸ xp)
  · exact nd.2.2 pA pT

#print axioms SingletonCut.free_contact_of_two
end Graffiti199Depleted.Catalogue.Incomplete
