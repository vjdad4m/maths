import FourRoutes
import SmallRoot
import CatalogueCrossing

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
universe u
variable {V : Type u} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {D : Finset V}

omit [Fintype V] [DecidableEq V] [DecidableRel G.Adj] in
private theorem component_only_vertex {z : Survives D}
    (isol : ∀ y : Survives D, ¬ G.Adj z.val y.val) (y : Survives D)
    (h : (DeletionGraph G D).connectedComponentMk y = (DeletionGraph G D).connectedComponentMk z) :
    z = y := by
  obtain ⟨p⟩ := ConnectedComponent.exact h.symm
  cases p with
  | nil => rfl
  | cons edge _ => exact (isol _ edge).elim

theorem singleton_frame_of_small_cut (conn : ConnectivityAtLeast G 3) (budget : treeNumber G ≤ 5)
    (order : 5 ≤ Fintype.card V) (no : ¬ Traceable G) (cross : CrossingBetweenSurvivingEdges G)
    (size : D.card = 3) (cut : ¬ (DeletionGraph G D).Preconnected) :
    ∃ z : V, ∃ X : Set V, ∀ r a b : V, r ≠ a → r ≠ b → a ≠ b → D = {r,a,b} →
      SingletonCut G X z r a b := by
  classical
  let H := DeletionGraph G D
  have hasIso : ∃ z : Survives D, ∀ y : Survives D, ¬ G.Adj z.val y.val := by
    by_contra! none
    apply cut
    intro x y
    obtain ⟨u,xu⟩ := none x
    obtain ⟨v,yv⟩ := none y
    exact edgeReach_iff_crossing_between_surviving_edges.mpr cross D size.le x u y v xu yv
  obtain ⟨z,isol⟩ := hasIso
  have sub : G.neighborFinset z.val ⊆ D := by
    intro s hs
    by_contra non
    exact isol ⟨s,non⟩ ((G.mem_neighborFinset _ _).mp hs)
  have low := degree_of_small_deletion_preconnected (G := G) (by omega : 4 ≤ Fintype.card V)
    (fun K hk => (conn.2 K hk).preconnected) z.val
  have neigh : G.neighborFinset z.val = D := Finset.eq_of_subset_of_card_le sub (by
    rw [G.card_neighborFinset_eq_degree,size]; exact low)
  have sing : CutSingleton G D z.val := ⟨z.property,fun s => (G.mem_neighborFinset z.val s).symm.trans
    (congrArg (s ∈ ·) neigh |> Eq.to_iff)⟩
  have another : ∃ w : Survives D, w ≠ z := by
    by_contra! none
    exact cut (fun x y => (show x = y from (none x).trans (none y).symm) ▸ SimpleGraph.Reachable.rfl)
  obtain ⟨w,wz⟩ := another
  let A := H.connectedComponentMk w
  let B := H.connectedComponentMk z
  have ab : A ≠ B := fun eq => wz (component_only_vertex isol w eq).symm
  have only (K : H.ConnectedComponent) : K = A ∨ K = B := by
    by_contra! missing
    letI : Fintype H.ConnectedComponent := Fintype.ofFinite _
    let e : Fin 3 ↪ H.ConnectedComponent := ⟨![A,B,K],by
      intro i j h
      fin_cases i <;> fin_cases j
      · rfl
      · exact (ab h).elim
      · exact (missing.1 h.symm).elim
      · exact (ab h.symm).elim
      · rfl
      · exact (missing.2 h.symm).elim
      · exact (missing.1 h).elim
      · exact (missing.2 h).elim
      · rfl⟩
    have big := Fintype.card_le_of_injective e e.injective
    have many : 3 ≤ Nat.card H.ConnectedComponent := by simpa [Nat.card_eq_fintype_card] using big
    exact no (traceable_of_three_or_more_components conn budget size many)
  let X := componentShore D A
  have zX : z.val ∉ X := by
    rintro ⟨v,hv,eq⟩
    have vZ : v = z := Subtype.ext eq
    exact ab ((vZ ▸ hv : z ∈ A.supp).symm)
  refine ⟨z.val,X,fun r a b ra rb ab' ed => ?_⟩
  have off := componentShore_off_cut D A
  have bd := componentShore_boundary D A
  have form : OneShore G X r a b := ⟨conn,ra,rb,ab',ed ▸ off,ed ▸ bd,componentShore_connected D A⟩
  refine ⟨form,budget,zX,ed ▸ sing,?_⟩
  intro v
  by_cases vd : v ∈ D
  · right; right; simpa [ed] using vd
  let t : Survives D := ⟨v,vd⟩
  rcases only (H.connectedComponentMk t) with eq|eq
  · exact Or.inl ⟨t,eq,rfl⟩
  · exact Or.inr (Or.inl (congrArg Subtype.val (component_only_vertex isol t eq).symm))

/-- Every port of any separating three-cut in this minimum branch supports
an induced four-tree, with the other vertices in the unique ordinary component. -/
theorem all_ports_have_rooted_four (smaller : SmallerAtThree.{u} (Fintype.card V))
    (conn : ConnectivityAtLeast G 3) (budget : treeNumber G ≤ 5)
    (order : 5 ≤ Fintype.card V) (no : ¬ Traceable G)
    (ind : ∀ x y, G.degree x = 3 → G.degree y = 3 → ¬ G.Adj x y)
    (size : D.card = 3) (cut : ¬ (DeletionGraph G D).Preconnected) :
    ∃ z : V, ∃ X : Set V, ∀ r a b : V, r ≠ a → r ≠ b → a ≠ b → D = {r,a,b} →
      SingletonCut G X z r a b ∧ ∃ f : Fin 4 ↪ V, f 0 = r ∧
        (∀ i, i ≠ 0 → f i ∈ X) ∧ RootOrdering G f := by
  classical
  have cross := crossing_of_independent_cubic_minimum smaller conn budget order no ind
  obtain ⟨z,X,frame⟩ := singleton_frame_of_small_cut conn budget order no cross size cut
  refine ⟨z,X,fun r a b ra rb ab ed => ?_⟩
  have F := frame r a b ra rb ab ed
  refine ⟨F,?_⟩
  by_contra! none
  exact no (F.traceable_of_small_root (fun f eq on h => none f eq on h))

#print axioms singleton_frame_of_small_cut
#print axioms all_ports_have_rooted_four
end Graffiti199Depleted.Catalogue.Incomplete

