import CubicRoute
import NonadjacentDegree
import AdjacentShared
open private swap_others from TwoMissMatching
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {X : Set V} {z r a b x y : V}

/-- All patterns on two distinct misses are traceable in the reduced
singleton-cut branch, irrespective of the missing vertices' mutual edge
or their contacts with the two other cut vertices. -/
theorem SingletonCut.traceable_of_exactly_two_misses (F : SingletonCut G X z r a b)
    (cross : CrossingBetweenSurvivingEdges G) (P : PathOn G {v | v ≠ z})
    (xX : x ∈ X) (yX : y ∈ X) (distinct : x ≠ y) (rx : ¬ G.Adj r x) (ry : ¬ G.Adj r y)
    (on : ∀ v ∈ X \ {x,y}, G.Adj r v) : Traceable G := by
  classical
  by_cases xy : G.Adj x y
  · exact F.traceable_of_adjacent_with_crossing cross P xX yX xy rx ry on
  have rev : ∀ t ∈ X \ {y,x}, G.Adj r t := (Set.pair_comm x y) ▸ on
  have lo (v : V) := degree_of_small_deletion_preconnected (G := G) (by have := F.conn.1; omega : 4 ≤ Fintype.card V)
    (fun K small => (F.conn.2 K small).preconnected) v
  have mat := F.traceable_of_two_misses_matching xX yX distinct rx ry on
  have mat' := (swap_others F).traceable_of_two_misses_matching xX yX distinct rx ry on
  have yx : ¬ G.Adj y x := fun e => xy e.symm
  have A := F.traceable_of_nonadjacent_degree cross xX yX distinct rx ry xy on
  have B := (swap_others F).traceable_of_nonadjacent_degree cross xX yX distinct rx ry xy on
  have C := F.traceable_of_nonadjacent_degree cross yX xX distinct.symm ry rx yx rev
  have D := (swap_others F).traceable_of_nonadjacent_degree cross yX xX distinct.symm ry rx yx rev
  have cubicA := F.traceable_of_common_port_cubic_pair cross xX yX distinct rx ry xy on
  have cubicB := (swap_others F).traceable_of_common_port_cubic_pair cross xX yX distinct rx ry xy on
  have pick (v : V) : 4 ≤ G.degree v ∨ G.degree v=3 := by have := lo v; omega
  have free : (¬ G.Adj x a) → (¬ G.Adj x b) → (¬ G.Adj y a) → (¬ G.Adj y b) → Traceable G := by
    intro xa xb ya yb
    apply F.traceable_of_two_unattached P xX on
    rintro s (e|e)
    · exact e.symm ▸ ⟨fun h => xa h.symm,fun h => xb h.symm⟩
    · exact (show s=y from e).symm ▸ ⟨fun h => ya h.symm,fun h => yb h.symm⟩
  by_cases xa : G.Adj x a <;> by_cases xb : G.Adj x b <;>
    by_cases ya : G.Adj y a <;> by_cases yb : G.Adj y b <;>
    first | exact mat xa yb | exact mat' xb ya | exact free xa xb ya yb |
      exact A xa yb (Or.inl ya) | exact B xb ya (Or.inl yb) |
      exact C ya xb (Or.inl xa) | exact D yb xa (Or.inl xb) |
      (rcases pick x with dx|dx <;> rcases pick y with dy|dy <;>
        first | exact A xa yb (Or.inr dy) | exact B xb ya (Or.inr dy) |
          exact C ya xb (Or.inr dx) | exact D yb xa (Or.inr dx) |
          exact cubicA xa ya xb yb dx dy | exact cubicB xb yb xa ya dx dy)

#print axioms SingletonCut.traceable_of_exactly_two_misses
end Graffiti199Depleted.Catalogue.Incomplete
