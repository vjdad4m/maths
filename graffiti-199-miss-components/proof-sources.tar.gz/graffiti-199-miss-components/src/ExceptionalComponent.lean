import MissComponentGeometry
open private NoRootedFour.forbids_four from RootedBlocks
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X : Set V} {z r a b p q : V} {i j : RootComponent G X r}

abbrev ExteriorOfPart (G : SimpleGraph V) (X : Set V) (r : V) (i : RootComponent G X r) : Set V :=
  {v | v ∉ MissPart G X r i ∧ ∀ u ∈ MissPart G X r i, ¬ G.Adj v u}

theorem SingletonCut.bad_contact_exterior (F : SingletonCut G X z r a b)
    (qi : q ∈ rootedBlockContacts G X r i) (bad : ¬ GoodAt G (MissPart G X r i) q) :
    NoRootedFour G (ExteriorOfPart G X r i) q := by
  obtain ⟨u,ui,v,vi,dif,qu,shape⟩ := missPart_bad_pair qi bad
  intro f h0 side tree
  have off {w : V} (wi : w ∈ MissPart G X r i) (k : Fin 4) : w ≠ f k := by
    intro eq
    by_cases h : k = 0
    · exact (noncontactComponent_subset i wi).2 ((eq.trans (h ▸ h0)).symm ▸ qi.2.1)
    · exact (side k h).1 (eq ▸ wi)
  have anti {w : V} (wi : w ∈ MissPart G X r i) (k : Fin 4) (ne : k ≠ 0) :=
    (side k ne).2 w wi
  rcases shape with ⟨qv,uv⟩|⟨qv,uv⟩
  · have six := six_of_two_leaves f tree dif (fun e => uv e.symm) (h0.symm ▸ qu)
      (h0.symm ▸ qv) (off ui) (off vi) (anti ui) (anti vi)
    exact (Nat.not_succ_le_self 5) (six.trans F.budget)
  · have tail (k : Fin 4) : ¬ G.Adj (f k) v := by
      by_cases h : k = 0
      · simpa only [h,h0] using qv
      · exact anti vi k h
    have six := six_le_treeNumber_of_rooted_four_and_tail f tree uv (h0.symm ▸ qu)
      (off ui) (off vi) tail (anti ui)
    exact (Nat.not_succ_le_self 5) (six.trans F.budget)

/-- Two distinct components of the ordinary vertices missed by a port
cannot both fail to be cliques with uniform ordinary attachments. -/
theorem SingletonCut.uniform_of_other_exception (F : SingletonCut G X z r a b)
    (ne : i ≠ j) (bad : ¬ UniformMissPart G X r i) : UniformMissPart G X r j := by
  classical
  by_contra badj
  obtain ⟨p,pi,bi⟩ := F.bad_witness bad
  obtain ⟨q,qj,bj⟩ := F.bad_witness badj
  have outside {k l : RootComponent G X r} (kl : k ≠ l) {s : V}
      (sk : s ∈ rootedBlockContacts G X r k) (bk : ¬ GoodAt G (MissPart G X r k) s) :
      s ∈ ExteriorOfPart G X r l := by
    refine ⟨fun h => (noncontactComponent_subset l h).2 sk.2.1,?_⟩
    intro t tl st
    exact bk (F.shared_contact_good kl sk ⟨sk.1,sk.2.1,t,tl,st⟩)
  have po := outside ne pi bi
  have qo := outside ne.symm qj bj
  obtain ⟨u,ui,v,vi,uv,pu,shape⟩ := missPart_bad_pair pi bi
  obtain ⟨w,wj,qw⟩ := qj.2.2
  have um := noncontactComponent_subset i ui
  have vm := noncontactComponent_subset i vi
  have wm := noncontactComponent_subset j wj
  have pq := F.exclusive_contacts_complete um.1 wm.1 (missPart_different ne ui wj) um.2 wm.2
    (noncontactComponents_anticomplete ne ui wj) pi.1 qj.1 pi.2.1 qj.2.1 pu.symm
    (fun e => po.2 _ wj e.symm) qw.symm (fun e => qo.2 _ ui e.symm)
  have inner {s : V} (si : s ∈ MissPart G X r i) : s ∈ ExteriorOfPart G X r j :=
    ⟨Set.disjoint_left.mp (noncontactComponents_apart ne) si,fun _ t => noncontactComponents_anticomplete ne si t⟩
  have qu : q ≠ u := fun e => um.2 (e ▸ qj.2.1)
  have qv : q ≠ v := fun e => vm.2 (e ▸ qj.2.1)
  have pv : p ≠ v := fun e => vm.2 (e ▸ pi.2.1)
  apply NoRootedFour.forbids_four (F.bad_contact_exterior qj bj) po (inner ui) (inner vi)
    (by simp [pq.ne.symm,qu,qv,pu.ne,pv,uv]) pq.symm (Or.inr ⟨pu.symm,fun e => qo.2 _ ui e.symm⟩)
  rcases shape with ⟨py,xy⟩|⟨py,xy⟩
  · exact Or.inr (Or.inl ⟨py.symm,fun e => qo.2 _ vi e.symm,fun e => xy e.symm⟩)
  · exact Or.inr (Or.inr ⟨xy.symm,fun e => qo.2 _ vi e.symm,fun e => py e.symm⟩)

#print axioms SingletonCut.uniform_of_other_exception
end Graffiti199Depleted.Catalogue.Incomplete
