import AdjacentClosed
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X : Set V} {z r a b x y : V}

/-- For two nonadjacent vertices missed by r, ordinary r-neighbors which
contact opposite misses exclusively must be adjacent. Otherwise z,r and
the two arms through the two exclusive contacts induce a six-vertex tree. -/
theorem SingletonCut.exclusive_contacts_complete (F : SingletonCut G X z r a b)
    (xX : x ∈ X) (yX : y ∈ X) (distinct : x ≠ y) (rx : ¬ G.Adj r x) (ry : ¬ G.Adj r y)
    (xy : ¬ G.Adj x y) {s t : V} (sX : s ∈ X) (tX : t ∈ X) (rs : G.Adj r s) (rt : G.Adj r t)
    (xs : G.Adj x s) (ys : ¬ G.Adj y s) (yt : G.Adj y t) (xt : ¬ G.Adj x t) : G.Adj s t := by
  by_contra st
  have rr := F.offX r (Finset.mem_insert_self r _)
  have xr : x ≠ r := fun e => rr (e ▸ xX)
  have yr : y ≠ r := fun e => rr (e ▸ yX)
  have ts : s ≠ t := fun e => xt (e ▸ xs)
  have tx : t ≠ x := fun e => rx (e ▸ rt)
  have sy : s ≠ y := fun e => ry (e ▸ rs)
  obtain ⟨f,f0,f1,f2,f3,tree⟩ := four_ordering (G := G) (r := r) (x := s) (y := x) (z := t)
    (by simp [rs.ne,xr.symm,rt.ne,xs.ne.symm,ts,tx.symm]) rs (Or.inr ⟨xs,fun e => rx e.symm⟩)
    (Or.inl ⟨rt.symm,fun e => st e.symm,fun e => xt e.symm⟩)
  have side : ∀ i : Fin 4, i ≠ 0 → f i ∈ X := by
    intro i ne; fin_cases i
    · exact (ne rfl).elim
    · exact f1.symm ▸ sX
    · exact f2.symm ▸ xX
    · exact f3.symm ▸ tX
  have off : ∀ i, y ≠ f i := by
    intro i; fin_cases i
    · exact f0.symm ▸ yr
    · exact f1.symm ▸ sy.symm
    · exact f2.symm ▸ distinct.symm
    · exact f3.symm ▸ yt.ne
  obtain ⟨j,j3,adj⟩ := (F.quartet_contacts f f0 side tree).1 y yX off 3 (f3.symm ▸ yt)
  fin_cases j
  · exact ry (f0 ▸ adj.symm)
  · exact ys (f1 ▸ adj)
  · exact xy (f2 ▸ adj.symm)
  · exact j3 rfl

#print axioms SingletonCut.exclusive_contacts_complete
end Graffiti199Depleted.Catalogue.Incomplete
