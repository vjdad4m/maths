import ThreeComponents
import Mathlib.Combinatorics.SimpleGraph.Connectivity.WalkCounting
open private six_le_treeNumber_of_five_independent_neighbors from CubicEdgeCuts

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] {D : Finset V}

omit [DecidableEq V] in
theorem component_count_le_four (conn : ConnectivityAtLeast G 3) (budget : treeNumber G ≤ 5)
    (size : D.card = 3) : Nat.card (DeletionGraph G D).ConnectedComponent ≤ 4 := by
  classical
  let K := (DeletionGraph G D).ConnectedComponent
  letI : Fintype K := Fintype.ofFinite K
  obtain ⟨r,hr⟩ := Finset.card_pos.mp (show 0 < D.card by omega)
  choose f inside contact using fun (C : K) => component_contact conn size C hr
  let e : K ↪ V := ⟨f,fun {C E} eq => Classical.byContradiction fun ne =>
    (distinct_component_vertices ne (inside C) (inside E)).1 eq⟩
  let T := Finset.univ.map e
  have count : T.card = Nat.card K := by simp [T,Nat.card_eq_fintype_card]
  by_contra notSmall
  have five : 5 ≤ T.card := by rw [count]; exact Nat.lt_of_not_ge notSmall
  apply (Nat.not_succ_le_self 5)
  apply Nat.le_trans _ budget
  apply six_le_treeNumber_of_five_independent_neighbors T r five
  · intro x hx
    obtain ⟨i,_,rfl⟩ := Finset.mem_map.mp hx
    exact contact i
  · intro x hx y hy
    obtain ⟨i,_,rfl⟩ := Finset.mem_map.mp hx
    obtain ⟨j,_,rfl⟩ := Finset.mem_map.mp hy
    by_cases h : i = j
    · subst j; exact G.loopless _
    · exact (distinct_component_vertices h (inside i) (inside j)).2


#print axioms component_count_le_four
end Graffiti199Depleted.Catalogue.Incomplete
