import ReserveObstruction
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X M : Set V} {z r a b y h : V}

/-- Open a cycle at a consecutive pair in the ordinary reserved route. A
miss with an unused ordinary contact has two choices among the three
cliques. A port-neighbor in the next position has at least one. -/
theorem SingletonCut.traceable_of_reserved_edge (F : SingletonCut G X z r a b) (sub : M ⊆ X)
    (on : ∀ v ∈ X \ M, G.Adj r v) (P : PathOn G M) (start : G.Adj a P.first) (finish : G.Adj P.last b)
    {A B : List V} (eq : P.vertices = A ++ y :: h :: B) (ry : ¬ G.Adj r y)
    (touch : ∃ w ∈ X \ M, G.Adj y w) (next : G.Adj r h ∨ ∃ w ∈ X \ M, G.Adj h w) : Traceable G := by
  classical
  by_contra no
  obtain ⟨C,edges⟩ := F.cliques_from_reserve_cycle sub on P start finish no
  have same := List.chain'_iff_forall_rel_of_append_cons_cons.mp edges eq
  have yM := (P.covers y).mp (by simp [eq])
  have hM := (P.covers h).mp (by simp [eq])
  obtain ⟨w,wm,yw⟩ := touch
  obtain ⟨i,wi⟩ := (C.cover w).mp wm
  obtain ⟨j,hj⟩ : ∃ j, C.hits h j := by
    rcases next with rh|⟨s,sm,hs⟩
    · exact C.hits_of_neighbor F (fun _ m => m.1) on (sub hM) (fun m => m.2 hM) rh
    · obtain ⟨j,sj⟩ := (C.cover _).mp sm; exact ⟨j,s,sj,hs⟩
  have ij := same i j ⟨w,wi,yw⟩ hj
  obtain ⟨k,ki,full⟩ := C.complete_to_another F (fun _ m => m.1) on (sub yM) ry wi yw
  obtain ⟨v,vk⟩ := C.nonempty k
  exact ki ((same k j ⟨v,vk,full _ vk⟩ hj).trans ij.symm)

#print axioms SingletonCut.traceable_of_reserved_edge
end Graffiti199Depleted.Catalogue.Incomplete
