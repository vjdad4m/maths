import PortMiss

namespace Graffiti199Depleted
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} {X : Set V} {x : V}

/-- Make a specified endpoint internal by reversing the initial interval
before a second neighbor of the endpoint. -/
private theorem internal_of_first (P : PathOn G X) (atFirst : ∃ R, P.vertices = x :: R)
    {u v : V} (uX : u ∈ X) (vX : v ∈ X) (xu : G.Adj x u) (xv : G.Adj x v) (uv : u ≠ v) :
    ∃ Q : PathOn G X, ∃ L : List V, ∃ p q : V, ∃ R : List V, Q.vertices = L ++ p :: x :: q :: R := by
  obtain ⟨R,eq⟩ := atFirst
  have up := (P.covers u).mpr uX
  have vp := (P.covers v).mpr vX
  rcases R with _|⟨s,T⟩
  · simp [eq,xu.ne.symm] at up
  have ch : G.Adj x s := ((List.chain'_cons.mp (eq ▸ P.chain)).1)
  obtain ⟨y,xy,yT⟩ : ∃ y, G.Adj x y ∧ y ∈ T := by
    by_cases e : u = s
    · exact ⟨v,xv,by simpa [eq,xv.ne.symm,e ▸ uv.symm] using vp⟩
    · exact ⟨u,xu,by simpa [eq,xu.ne.symm,e] using up⟩
  obtain ⟨A,B,part⟩ := List.append_of_mem yT
  let U := s :: A
  let W := y :: B
  have split : P.vertices = x :: (U ++ W) := by simp [U,W,eq,part]
  have body : (U ++ W).Chain' G.Adj := (List.chain'_cons.mp (split ▸ P.chain)).2
  have left : U.Chain' G.Adj := body.left_of_append
  have reversed := List.chain'_reverse.mpr (left.imp
    (R := G.Adj) (S := flip G.Adj) fun _ _ h => h.symm)
  have chain : (U.reverse ++ x :: W).Chain' G.Adj := by
    apply reversed.append (List.chain'_cons.mpr ⟨xy,body.right_of_append⟩)
    intro m hm n hn
    have sm : s = m := by simpa [List.getLast?_reverse,U] using hm
    have xn : x = n := by simpa using hn
    exact sm ▸ xn ▸ ch.symm
  have perm : (U.reverse ++ x :: W).Perm P.vertices := by
    rw [split]
    exact ((List.reverse_perm U).append_right (x :: W)).trans List.perm_middle
  let Q : PathOn G X := ⟨U.reverse ++ x :: W,by simp,
    chain,(List.Perm.nodup_iff perm).mpr P.nodup,fun w => perm.mem_iff.trans (P.covers w)⟩
  exact ⟨Q,A.reverse,s,y,B,by simp [Q,U,W,List.reverse_cons,List.append_assoc]⟩

/-- In any traceable induced shore, a vertex with two neighbors in the shore
can occur internally on a spanning path. -/
theorem exists_internal_path (P : PathOn G X) (xX : x ∈ X)
    {u v : V} (uX : u ∈ X) (vX : v ∈ X) (xu : G.Adj x u) (xv : G.Adj x v) (uv : u ≠ v) :
    ∃ Q : PathOn G X, ∃ L : List V, ∃ p q : V, ∃ R : List V, Q.vertices = L ++ p :: x :: q :: R := by
  obtain ⟨L,R,split⟩ := List.append_of_mem ((P.covers x).mpr xX)
  by_cases left : L = []
  · apply internal_of_first P ⟨R,by simpa [left] using split⟩ uX vX xu xv uv
  cases R with
  | nil =>
    let rev : PathOn G X := ⟨P.vertices.reverse,by simpa using P.nonempty,
      List.chain'_reverse.mpr (P.chain.imp (fun _ _ e => e.symm)),
      List.nodup_reverse.mpr P.nodup,fun v => by simpa using P.covers v⟩
    exact internal_of_first rev ⟨L.reverse,by simp [rev,split,List.reverse_append]⟩ uX vX xu xv uv
  | cons q R =>
    refine ⟨P,L.dropLast,L.getLast left,q,R,?_⟩
    calc P.vertices = L ++ x :: q :: R := split
         _ = (L.dropLast ++ [L.getLast left]) ++ x :: q :: R := by rw [List.dropLast_append_getLast]
         _ = _ := by simp

#print axioms exists_internal_path
end Graffiti199Depleted

