import ReserveCycle
namespace Graffiti199Depleted.Catalogue.Incomplete
variable {V I : Type*} (hit : V → I → Prop)
private def Agree (u v : V) := ∀ i j, hit u i → hit v j → i = j

private theorem forward_color {s : V} {L : List V} {i : I} (is : hit s i)
    (chain : (s :: L).Chain' (Agree hit)) (available : ∀ v ∈ L, ∃ j, hit v j) :
    ∀ v ∈ L, ∀ j, hit v j → j = i := by
  induction L generalizing s i with
  | nil => simp
  | cons t T ih =>
    obtain ⟨k,tk⟩ := available t (by simp)
    have localEq := (List.chain'_cons.mp chain).1
    have ki := localEq i k is tk
    intro v hv j hj
    rcases List.mem_cons.mp hv with vt|vm
    · exact (localEq i j is (vt ▸ hj)).symm
    · exact (ih tk (List.chain'_cons.mp chain).2 (fun w hw => available _ (List.mem_cons_of_mem _ hw))
        v vm j hj).trans ki.symm

/-- If the internal vertices of a path all have available labels and there
are two consecutive internal vertices, agreement across every edge forces
every label along the entire path (including any endpoint labels) to be equal. -/
theorem single_color_of_chain {x s t y : V} {T : List V}
    (chain : (x :: s :: t :: (T ++ [y])).Chain' (fun u v => ∀ i j, hit u i → hit v j → i = j))
    (available : ∀ v ∈ s :: t :: T, ∃ j, hit v j) :
    ∃ i, ∀ v ∈ x :: s :: t :: (T ++ [y]), ∀ j, hit v j → j = i := by
  let L := s :: t :: T
  obtain ⟨i,si⟩ := available s (by simp)
  obtain ⟨k,tk⟩ := available t (by simp)
  have mid : (L ++ [y]).Chain' (Agree hit) := (List.chain'_cons.mp chain).2
  have edges := List.chain'_append.mp mid
  have ic := (List.chain'_cons.mp (List.chain'_cons.mp chain).2).1
  have ik := ic i k si tk
  have mono : ∀ v ∈ L, ∀ j, hit v j → j = i := by
    intro v hv j hj
    rcases List.mem_cons.mp hv with vs|vt
    · exact (ic j k (vs ▸ hj) tk).trans ik.symm
    · exact forward_color hit si edges.1 (fun w hw => available _ (List.mem_cons_of_mem _ hw)) v vt j hj
  have near : (L.getLast (by simp [L])) ∈ L := List.getLast_mem _
  obtain ⟨q,hq⟩ := available _ near
  have qi := mono _ near _ hq
  refine ⟨i,?_⟩
  intro v hv j hj
  rcases List.mem_cons.mp hv with vx|vt
  · exact (List.chain'_cons.mp chain).1 j i (vx ▸ hj) si
  · change v ∈ L ++ [y] at vt
    rcases List.mem_append.mp vt with vm|vy
    · exact mono _ vm _ hj
    · have edge := edges.2.2 _ (by rw [List.getLast?_eq_getLast (by simp [L])]; rfl) y (by simp)
      have eq : v = y := by simpa using vy
      exact (edge q j hq (eq ▸ hj)).symm.trans qi

end Graffiti199Depleted.Catalogue.Incomplete
