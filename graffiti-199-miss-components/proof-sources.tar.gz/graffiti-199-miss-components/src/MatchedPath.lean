import ReserveObstruction
import TwinTips

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {X M : Set V} {z r a b x y : V}

omit [DecidableRel G.Adj] in
private theorem short_route (F : SingletonCut G X z r a b) (sub : M ⊆ X)
    (on : ∀ u ∈ X \ M, G.Adj r u) (P : PathOn G M) (start : G.Adj a P.first) (finish : G.Adj P.last b)
    {h : V} (ord : P.vertices = [x,h,y]) (rx : ¬ G.Adj r x) (ry : ¬ G.Adj r y)
    (rh : G.Adj r h) (xy : ¬ G.Adj x y) : Traceable G := by
  classical
  by_contra no
  obtain ⟨C,chain⟩ := F.cliques_from_reserve_cycle sub on P start finish no
  rw [ord] at chain
  have first := (List.chain'_cons.mp chain).1
  have second := (List.chain'_cons.mp (List.chain'_cons.mp chain).2).1
  have mem (u : V) : u ∈ M ↔ u=x ∨ u=h ∨ u=y := by rw [← P.covers u,ord]; simp
  have xM := (mem x).mpr (Or.inl rfl)
  have hM := (mem h).mpr (Or.inr (Or.inl rfl))
  have yM := (mem y).mpr (Or.inr (Or.inr rfl))
  have nd := P.nodup
  rw [ord] at nd
  simp only [List.nodup_cons,List.mem_cons,List.mem_nil_iff,or_false,not_or,
    List.nodup_nil,not_false_eq_true,and_true] at nd
  obtain ⟨j,hj⟩ := C.hits_of_neighbor F (fun _ m => m.1) on (sub hM) (fun s => s.2 hM) rh
  have noTouch {v : V} (vM : v ∈ M) (rv : ¬ G.Adj r v) (only : ∀ i, C.hits v i → i=j)
      {t : V} (te : G.Adj v t) (tX : t ∈ X) : t ∈ M := by
    by_contra tm
    obtain ⟨i,ti⟩ := (C.cover t).mp ⟨tX,tm⟩
    have ij := only i ⟨t,ti,te⟩
    obtain ⟨k,ki,all⟩ := C.complete_to_another F (fun _ v => v.1) on (sub vM) rv ti te
    obtain ⟨w,wk⟩ := C.nonempty k
    exact ki ((only k ⟨w,wk,all _ wk⟩).trans ij.symm)
  have xt {t : V} (tx : t ∈ X) (xt : G.Adj x t) : t = h := by
    rcases (mem t).mp (noTouch xM rx (fun i iv => first i j iv hj) xt tx) with ex|eh|ey
    · exact (xt.ne ex.symm).elim
    · exact eh
    · exact (xy (ey ▸ xt)).elim
  have yt {t : V} (tx : t ∈ X) (yt : G.Adj y t) : t = h := by
    rcases (mem t).mp (noTouch yM ry (fun i iv => (second j i hj iv).symm) yt tx) with ex|eh|ey
    · exact (xy (ex ▸ yt.symm)).elim
    · exact eh
    · exact (yt.ne ey.symm).elim
  exact no (F.traceable_of_shared_tip (sub xM) (sub yM) (sub hM) nd.1.2 nd.1.1 (Ne.symm nd.2)
    (fun e => rx e) (fun e => ry e) (fun _ => xt) (fun _ => yt))

omit [Fintype V] [DecidableEq V] in
private theorem end_list {L : List V} (n : L ≠ []) (ne : L.head n ≠ L.getLast n) :
    ∃ T, L = L.head n :: (T ++ [L.getLast n]) := by
  cases L with
  | nil => contradiction
  | cons u Y =>
    cases Y with
    | nil => exact (ne rfl).elim
    | cons v R => exact ⟨(v::R).dropLast,by simpa using (List.dropLast_append_getLast (l := v :: R) (by simp)).symm⟩

/-- For a port with exactly two distinct misses, a matching to the other two
ports always suffices, for both possible adjacencies between the missed vertices. -/
theorem SingletonCut.traceable_of_two_misses_matching (F : SingletonCut G X z r a b)
    (xX : x ∈ X) (yX : y ∈ X) (distinct : x ≠ y) (rx : ¬ G.Adj r x) (ry : ¬ G.Adj r y)
    (on : ∀ t ∈ X \ {x,y}, G.Adj r t) (xa : G.Adj x a) (yb : G.Adj y b) : Traceable G := by
  classical
  by_cases edge : G.Adj x y
  · exact F.traceable_of_matched_two_misses xX yX edge rx ry on xa yb
  obtain ⟨w⟩ := F.connX.preconnected (⟨x,xX⟩ : X) ⟨y,yX⟩
  let q := w.toPath
  let L := q.val.support.map Subtype.val
  let M := {v : V | v ∈ L}
  let P : PathOn G M := ⟨L,fun e => q.val.support_ne_nil (List.map_eq_nil_iff.mp e),
    (List.chain'_map _).mpr q.val.chain'_adj_support,q.property.support_nodup.map Subtype.val_injective,fun _ => Iff.rfl⟩
  have sub : M ⊆ X := by
    intro v hv; obtain ⟨u,_,e⟩ := List.mem_map.mp hv; exact e ▸ u.property
  have pf : P.first = x := by simp only [P,PathOn.first,L,List.head_map,Walk.head_support]
  have pl : P.last = y := by simp only [P,PathOn.last,L,List.getLast_map,Walk.getLast_support]
  have start : G.Adj a P.first := pf.symm ▸ xa.symm
  have finish : G.Adj P.last b := pl.symm ▸ yb
  have pn : P.first ≠ P.last := fun e => distinct (pf.symm.trans (e.trans pl))
  obtain ⟨T,raw⟩ := end_list P.nonempty pn
  change P.vertices = P.first :: (T ++ [P.last]) at raw
  have ord : P.vertices = x :: (T ++ [y]) := by simpa only [pf,pl] using raw
  have onH : ∀ u ∈ X \ M, G.Adj r u := by
    intro u hu
    apply on _ ⟨hu.1,?_⟩
    rintro (ux|uy)
    · exact hu.2 ((P.covers u).mp (by simp [ord,ux]))
    · exact hu.2 ((P.covers u).mp (by simp [ord,show u=y from uy]))
  have int (u : V) (ut : u ∈ T) : G.Adj r u := by
    have mem : u ∈ P.vertices := ord.symm ▸ List.mem_cons_of_mem x (List.mem_append_left [y] ut)
    have nd := ord ▸ P.nodup
    have xoff := (List.nodup_cons.mp nd).1
    have yoff := (List.nodup_append.mp (List.nodup_cons.mp nd).2).2.2
    apply on _ ⟨sub ((P.covers _).mp mem),?_⟩
    rintro (ux|uy)
    · exact xoff (ux ▸ List.mem_append_left [y] ut)
    · exact yoff ut (by simp [show u=y from uy])
  cases T with
  | nil =>
    have e := P.chain
    simp only [ord,List.nil_append,List.chain'_pair] at e
    exact (edge e).elim
  | cons s T =>
    cases T with
    | nil => exact short_route F sub onH P start finish (by simpa using ord) rx ry (int s (by simp)) edge
    | cons t R =>
      exact F.traceable_of_contacted_internal_path sub onH P start finish ord (fun v vm => Or.inl (int v vm))

#print axioms SingletonCut.traceable_of_two_misses_matching
end Graffiti199Depleted.Catalogue.Incomplete

