import CubicContactGeometry
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
universe u
variable {V : Type u} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {X : Set V} {z r a b : V} {i j : RootComponent G X r}

omit [DecidableRel G.Adj] in
/-- A nonuniform component and a component with the specified cubic contact
occupy the same exceptional slot. -/
theorem SingletonCut.exception_or_cubic_unique (F : SingletonCut G X z r a b)
    (one : ¬ UniformMissPart G X r i ∨ CubicContactPair G X r i)
    (two : ¬ UniformMissPart G X r j ∨ CubicContactPair G X r j) : i = j := by
  classical
  by_contra ne
  rcases one with bi|hi <;> rcases two with bj|hj
  · exact bj (F.uniform_of_other_exception ne bi)
  · exact bi (F.cubic_contact_forces_uniform hj (Ne.symm ne))
  · exact bj (F.cubic_contact_forces_uniform hi ne)
  · exact ne (F.cubic_contact_unique hi hj)

theorem SingletonCut.nonsingleton_part_count (F : SingletonCut G X z r a b)
    (smaller : SmallerAtThree.{u} (Fintype.card V)) (order : 5 ≤ Fintype.card V)
    (cross : CrossingBetweenSurvivingEdges G) (no : ¬ Traceable G)
    (ind : ∀ u v, G.degree u = 3 → G.degree v = 3 → ¬ G.Adj u v)
    (T : Finset (RootComponent G X r)) (many : ∀ i ∈ T, 2 ≤ Nat.card (MissPart G X r i)) :
    T.card ≤ 2 := by
  classical
  by_contra! large
  obtain ⟨U,sub,size⟩ := Finset.exists_subset_card_eq (show 3 ≤ T.card by omega)
  obtain ⟨i,j,k,ij,ik,jk,eq⟩ := Finset.card_eq_three.mp size
  have cls (v : RootComponent G X r) (vU : v ∈ U) :
      SplitMissEdge G X r a b v ∨ (¬ UniformMissPart G X r v ∨ CubicContactPair G X r v) := by
    by_cases g : UniformMissPart G X r v
    · exact (F.uniform_edge_types smaller order cross no ind g (many v (sub vU))).imp_right Or.inr
    · exact Or.inr (Or.inl g)
  have A := cls i (by simp [eq])
  have B := cls j (by simp [eq])
  have C := cls k (by simp [eq])
  rcases A with h|h <;> rcases B with l|l <;> rcases C with m|m <;>
    first | exact ij (F.split_edge_unique h l) | exact ik (F.split_edge_unique h m) |
      exact jk (F.split_edge_unique l m) | exact ij (F.exception_or_cubic_unique h l) |
      exact ik (F.exception_or_cubic_unique h m) | exact jk (F.exception_or_cubic_unique l m)

theorem SingletonCut.large_part_unique (F : SingletonCut G X z r a b)
    (smaller : SmallerAtThree.{u} (Fintype.card V)) (order : 5 ≤ Fintype.card V)
    (cross : CrossingBetweenSurvivingEdges G) (no : ¬ Traceable G)
    (ind : ∀ u v, G.degree u = 3 → G.degree v = 3 → ¬ G.Adj u v)
    (li : 3 ≤ Nat.card (MissPart G X r i)) (lj : 3 ≤ Nat.card (MissPart G X r j)) : i = j := by
  apply F.exception_or_cubic_unique (Or.inl ?_) (Or.inl ?_)
  · intro good
    have := F.uniform_size_le_two smaller order cross no ind good
    omega
  · intro good
    have := F.uniform_size_le_two smaller order cross no ind good
    omega

#print axioms SingletonCut.nonsingleton_part_count
#print axioms SingletonCut.large_part_unique
end Graffiti199Depleted.Catalogue.Incomplete
