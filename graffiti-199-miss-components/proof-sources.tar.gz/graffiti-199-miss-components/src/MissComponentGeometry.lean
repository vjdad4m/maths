import CatalogueThreeMisses

open private NoRootedFour.forbids_four from RootedBlocks

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X : Set V} {z r a b p : V} {i j : RootComponent G X r}

abbrev MissPart (G : SimpleGraph V) (X : Set V) (r : V) (i : RootComponent G X r) :=
  noncontactComponent G X r i

def UniformMissPart (G : SimpleGraph V) (X : Set V) (r : V) (i : RootComponent G X r) : Prop :=
  (MissPart G X r i).Pairwise G.Adj ∧
    ∀ p ∈ rootedBlockContacts G X r i, ∀ x ∈ MissPart G X r i, G.Adj p x

/-- The edge to the distinguished port and the edge on to the separated
singleton form a pendant two-edge path on any such rooted four-tree. -/
theorem SingletonCut.contact_no_four_on_misses (F : SingletonCut G X z r a b)
    (pX : p ∈ X) (rp : G.Adj r p) : NoRootedFour G (Noncontacts G X r) p := by
  intro f h0 side tree
  have fX (k : Fin 4) : f k ∈ X := by
    by_cases h : k = 0
    · simpa only [h,h0] using pX
    · exact (side k h).1
  have zr := (F.cut.2 r).mpr (by simp)
  have six := six_le_treeNumber_of_rooted_four_and_tail f tree zr.symm (h0.symm ▸ rp.symm)
    (fun k e => F.offX r (by simp) (e.symm ▸ fX k))
    (fun k e => F.zX (e.symm ▸ fX k))
    (fun k e => F.offX _ ((F.cut.2 _).mp e.symm) (fX k))
    (fun k ne e => (side k ne).2 e.symm)
  exact (Nat.not_succ_le_self 5) (six.trans F.budget)

omit [Fintype V] [DecidableEq V] in
theorem missPart_bad_pair (hit : p ∈ rootedBlockContacts G X r i)
    (bad : ¬ GoodAt G (MissPart G X r i) p) :
    ∃ u ∈ MissPart G X r i, ∃ v ∈ MissPart G X r i, u ≠ v ∧ G.Adj p u ∧
      ((G.Adj p v ∧ ¬ G.Adj u v) ∨ (¬ G.Adj p v ∧ G.Adj u v)) := by
  classical
  by_cases all : ∀ x ∈ MissPart G X r i, G.Adj p x
  · have nc : ¬ (∀ x ∈ MissPart G X r i, ∀ y ∈ MissPart G X r i, x ≠ y → G.Adj x y) :=
      fun c => bad ⟨c,all⟩
    push_neg at nc
    obtain ⟨u,hu,v,hv,uv,miss⟩ := nc
    exact ⟨u,hu,v,hv,uv,all u hu,Or.inl ⟨all v hv,miss⟩⟩
  · push_neg at all
    obtain ⟨_,⟨s,hs,rfl⟩,ps⟩ := hit.2.2
    obtain ⟨_,⟨t,ht,rfl⟩,pt⟩ := all
    obtain ⟨w⟩ := i.connected_induce_supp.preconnected ⟨s,hs⟩ ⟨t,ht⟩
    obtain ⟨v,yes,u,no,step⟩ := crossingOnWalk (U := {x : i.supp | G.Adj p x.val.val}) w ps pt
    have vu : G.Adj v.val.val u.val.val := step
    exact ⟨_,⟨v.val,v.property,rfl⟩,_,⟨u.val,u.property,rfl⟩,vu.ne,yes,Or.inr ⟨no,vu⟩⟩

omit [Fintype V] [DecidableEq V] in
theorem missPart_different {u v : V} (ne : i ≠ j) (ui : u ∈ MissPart G X r i)
    (vj : v ∈ MissPart G X r j) : u ≠ v :=
  fun eq => Set.disjoint_left.mp (noncontactComponents_apart ne) ui (eq.symm ▸ vj)

theorem SingletonCut.shared_contact_good (F : SingletonCut G X z r a b)
    (ne : i ≠ j) (hit : p ∈ rootedBlockContacts G X r i)
    (other : p ∈ rootedBlockContacts G X r j) : GoodAt G (MissPart G X r i) p := by
  classical
  by_contra bad
  obtain ⟨u,ui,v,vi,uv,pu,shape⟩ := missPart_bad_pair hit bad
  obtain ⟨w,wj,pw⟩ := other.2.2
  have um := noncontactComponent_subset i ui
  have vm := noncontactComponent_subset i vi
  have wm := noncontactComponent_subset j wj
  have pv : p ≠ v := fun e => vm.2 (e ▸ hit.2.1)
  have uw := missPart_different ne ui wj
  have vw := missPart_different ne vi wj
  have nw := noncontactComponents_anticomplete ne ui wj
  have mw := noncontactComponents_anticomplete ne vi wj
  apply NoRootedFour.forbids_four (F.contact_no_four_on_misses hit.1 hit.2.1) um vm wm
    (by simp [pu.ne,pv,pw.ne,uv,uw,vw]) pu _ (Or.inl ⟨pw.symm,fun h => nw h.symm,fun h => mw h.symm⟩)
  rcases shape with ⟨py,xy⟩|⟨py,xy⟩
  · exact Or.inl ⟨py.symm,fun h => xy h.symm⟩
  · exact Or.inr ⟨xy.symm,fun h => py h.symm⟩

theorem SingletonCut.bad_witness (F : SingletonCut G X z r a b)
    (bad : ¬ UniformMissPart G X r i) :
    ∃ p ∈ rootedBlockContacts G X r i, ¬ GoodAt G (MissPart G X r i) p := by
  classical
  by_contra! all
  obtain ⟨x,hx,rx⟩ := F.contact (by simp : r ∈ ({r,a,b} : Finset V))
  obtain ⟨p,hp⟩ := rootedBlockContacts_nonempty F.connX ⟨x,hx,rx⟩ i
  exact bad ⟨(all p hp).1,fun q hq => (all q hq).2⟩

#print axioms SingletonCut.contact_no_four_on_misses
#print axioms SingletonCut.shared_contact_good
end Graffiti199Depleted.Catalogue.Incomplete
