import PortConnector
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {X : Set V} {z r a b x y : V}

theorem SingletonCut.two_ordinary_neighbors (F : SingletonCut G X z r a b)
    (yX : y ∈ X) (ry : ¬ G.Adj r y) (yb : ¬ G.Adj y b)
    (room : ¬ G.Adj y a ∨ 4 ≤ G.degree y) :
    ∃ u ∈ X \ {x,y}, ∃ v ∈ X \ {x,y}, u ≠ v ∧ G.Adj y u ∧ G.Adj y v := by
  classical
  let N := G.neighborFinset y
  let T := (N.erase a).erase x
  have dy := degree_of_small_deletion_preconnected (G := G) (by have := F.conn.1; omega : 4 ≤ Fintype.card V)
    (fun K small => (F.conn.2 K small).preconnected) y
  have card : N.card = G.degree y := G.card_neighborFinset_eq_degree _
  have many : 1 < T.card := by
    have lo := Finset.pred_card_le_card_erase (s := N.erase a) (a := x)
    change 1 < ((N.erase a).erase x).card
    rcases room with ya|large
    · have off : a ∉ N := fun m => ya ((G.mem_neighborFinset y a).mp m)
      rw [Finset.erase_eq_of_not_mem off] at lo ⊢
      omega
    · have lower := Finset.pred_card_le_card_erase (s := N) (a := a)
      omega
  obtain ⟨u,um,v,vm,uv⟩ := Finset.one_lt_card.mp many
  have data (t : V) (tm : t ∈ T) : t ∈ X \ {x,y} ∧ G.Adj y t := by
    obtain ⟨tx,ta,tn⟩ := (Finset.mem_erase.mp tm).imp_right Finset.mem_erase.mp
    have e := (G.mem_neighborFinset y t).mp tn
    have tX : t ∈ X := by
      rcases F.cover t with tX|tz|tr|ea|eb
      · exact tX
      · exact (F.offX y ((F.cut.2 _).mp (tz ▸ e.symm)) yX).elim
      · exact (ry (tr ▸ e.symm)).elim
      · exact (ta ea).elim
      · exact (yb (eb ▸ e)).elim
    exact ⟨⟨tX,fun bad => bad.elim tx e.ne.symm⟩,e⟩
  exact ⟨u,(data _ um).1,v,(data _ vm).1,uv,(data _ um).2,(data _ vm).2⟩

end Graffiti199Depleted.Catalogue.Incomplete
