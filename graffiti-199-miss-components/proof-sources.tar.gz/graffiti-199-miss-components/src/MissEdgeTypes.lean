import UniformCliqueSize
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
universe u
variable {V : Type u} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {X : Set V} {z r a b : V} {i j : RootComponent G X r}

def SplitMissEdge (G : SimpleGraph V) [Fintype V] [DecidableRel G.Adj] (X : Set V)
    (r a b : V) (i : RootComponent G X r) : Prop :=
  ∃ s ∈ MissPart G X r i, ∃ t ∈ MissPart G X r i, G.Adj s t ∧ G.degree s = 3 ∧
    G.Adj t a ∧ G.Adj t b ∧ ¬ G.Adj s a ∧ ¬ G.Adj s b

def CubicContactPair (G : SimpleGraph V) (X : Set V) (r : V) (i : RootComponent G X r) : Prop :=
  ∃ p ∈ rootedBlockContacts G X r i, ∃ s ∈ MissPart G X r i, ∃ t ∈ MissPart G X r i,
    s ≠ t ∧ ∀ w, G.Adj p w ↔ w = r ∨ w = s ∨ w = t

private theorem cubic_three_neighbors {p x y w : V} (d : G.degree p = 3)
    (xy : x ≠ y) (xw : x ≠ w) (yw : y ≠ w) (px : G.Adj p x) (py : G.Adj p y) (pw : G.Adj p w) :
    ∀ v, G.Adj p v ↔ v = x ∨ v = y ∨ v = w := by
  classical
  have sub : ({x,y,w} : Finset V) ⊆ G.neighborFinset p := by
    intro v vm
    rcases (show v=x ∨ v=y ∨ v=w by simpa using vm) with e|e|e
    all_goals subst v; apply (G.mem_neighborFinset _ _).mpr; assumption
  have eq := Finset.eq_of_subset_of_card_le sub (by simp [d,xy,xw,yw])
  intro v
  rw [← G.mem_neighborFinset,← eq]
  simp

omit [DecidableEq V] [DecidableRel G.Adj] in
theorem two_in_miss_part (many : 2 ≤ Nat.card (MissPart G X r i)) :
    ∃ s ∈ MissPart G X r i, ∃ t ∈ MissPart G X r i, s ≠ t := by
  classical
  let C := MissPart G X r i
  letI : Fintype C := Fintype.ofFinite C
  have h : 1 < C.toFinset.card := by
    rw [Set.toFinset_card,← Nat.card_eq_fintype_card]
    exact many
  obtain ⟨s,sm,t,tm,st⟩ := Finset.one_lt_card.mp h
  exact ⟨_,Set.mem_toFinset.mp sm,_,Set.mem_toFinset.mp tm,st⟩

/-- A nonsingleton uniform part either has a cubic member with a forced port
pattern, or has a cubic ordinary contact whose entire neighborhood is explicit. -/
theorem SingletonCut.uniform_edge_types (F : SingletonCut G X z r a b)
    (smaller : SmallerAtThree.{u} (Fintype.card V)) (order : 5 ≤ Fintype.card V)
    (cross : CrossingBetweenSurvivingEdges G) (no : ¬ Traceable G)
    (ind : ∀ u v, G.degree u = 3 → G.degree v = 3 → ¬ G.Adj u v)
    (good : UniformMissPart G X r i) (many : 2 ≤ Nat.card (MissPart G X r i)) :
    SplitMissEdge G X r a b i ∨ CubicContactPair G X r i := by
  classical
  obtain ⟨s,si,t,ti,st⟩ := two_in_miss_part many
  by_cases inner : ∃ v ∈ MissPart G X r i, G.degree v = 3
  · obtain ⟨v,vi,d⟩ := inner
    obtain ⟨u,ui,ne⟩ : ∃ u ∈ MissPart G X r i, v ≠ u := by
      by_cases e : v = s
      · exact ⟨t,ti,e.symm ▸ st⟩
      · exact ⟨s,si,e⟩
    exact Or.inl ⟨v,vi,u,ui,good.1 vi ui ne,d,F.safe_pair_port_pattern smaller order cross no good
      vi ui ne (fun w vw e => ind v w d e vw)⟩
  by_cases outer : ∃ p ∈ rootedBlockContacts G X r i, G.degree p = 3
  · obtain ⟨p,pi,d⟩ := outer
    have off {u : V} (ui : u ∈ MissPart G X r i) : r ≠ u :=
      fun e => F.offX r (by simp) (e.symm ▸ (noncontactComponent_subset i ui).1)
    exact Or.inr ⟨p,pi,s,si,t,ti,st,cubic_three_neighbors d (off si) (off ti) st pi.2.1.symm
      (good.2 p pi s si) (good.2 p pi t ti)⟩
  have safe {v : V} (vi : v ∈ MissPart G X r i) (w : V) (vw : G.Adj v w) : G.degree w ≠ 3 := by
    by_cases wi : w ∈ MissPart G X r i
    · exact fun d => inner ⟨w,wi,d⟩
    rcases F.part_boundary vi wi vw with e|e|h
    · exact e.symm ▸ F.other_port_high ind (by simp : a ∈ ({r,a,b} : Finset V))
    · exact e.symm ▸ F.other_port_high ind (by simp : b ∈ ({r,a,b} : Finset V))
    · exact fun d => outer ⟨w,h,d⟩
  have L := F.safe_pair_port_pattern smaller order cross no good si ti st (safe si)
  have R := F.safe_pair_port_pattern smaller order cross no good ti si st.symm (safe ti)
  exact (L.2.2.1 R.1).elim

/-- Two split edges would give an induced tree on the two edges, the
outer port a, and the singleton. -/
theorem SingletonCut.split_edge_unique (F : SingletonCut G X z r a b)
    (one : SplitMissEdge G X r a b i) (two : SplitMissEdge G X r a b j) : i = j := by
  classical
  by_contra ne
  obtain ⟨s,si,t,ti,st,_,ta,_,sa,_⟩ := one
  obtain ⟨u,uj,v,vj,uv,_,va,_,ua,_⟩ := two
  have e := F.swap_first_two.exclusive_contacts_complete
    (noncontactComponent_subset i si).1 (noncontactComponent_subset j uj).1 (missPart_different ne si uj)
    (fun h => sa h.symm) (fun h => ua h.symm) (noncontactComponents_anticomplete ne si uj)
    (noncontactComponent_subset i ti).1 (noncontactComponent_subset j vj).1 ta.symm va.symm st
    (noncontactComponents_anticomplete (Ne.symm ne) uj ti) uv (noncontactComponents_anticomplete ne si vj)
  exact noncontactComponents_anticomplete ne ti vj e

#print axioms SingletonCut.uniform_edge_types
#print axioms SingletonCut.split_edge_unique
end Graffiti199Depleted.Catalogue.Incomplete
