import ExceptionalComponent
open private NoRootedFour.forbids_four from RootedBlocks
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X : Set V} {z r a b p : V} {i j k : RootComponent G X r}

omit [Fintype V] [DecidableEq V] in
theorem missPart_connected (i : RootComponent G X r) : (G.induce (MissPart G X r i)).Connected := by
  let f : i.supp → MissPart G X r i := fun x => ⟨x.val.val,⟨x.val,x.property,rfl⟩⟩
  have inj : Function.Injective f := fun _ _ e => Subtype.ext (Subtype.ext (congrArg (fun v : MissPart G X r i => v.val) e))
  have onto : Function.Surjective f := by
    rintro ⟨_,y,hy,rfl⟩
    exact ⟨⟨y,hy⟩,rfl⟩
  let e := Equiv.ofBijective f ⟨inj,onto⟩
  let iso : (G.induce (Noncontacts G X r)).induce i.supp ≃g G.induce (MissPart G X r i) :=
    ⟨e,fun {_ _} => Iff.rfl⟩
  exact iso.connected_iff.mp i.connected_induce_supp

/-- Inside even the exceptional component, looking from any one ordinary
contact produces uniform clique components, with disjoint attachment sets. -/
theorem SingletonCut.nested_cliques (F : SingletonCut G X z r a b)
    (pi : p ∈ rootedBlockContacts G X r i) :
    (∀ j : RootComponent G (MissPart G X r i) p, UniformMissPart G (MissPart G X r i) p j) ∧
    (∀ j k : RootComponent G (MissPart G X r i) p, j ≠ k →
      Disjoint (rootedBlockContacts G (MissPart G X r i) p j) (rootedBlockContacts G (MissPart G X r i) p k)) ∧
    (∀ T : Finset V, (∀ v ∈ T, v ∈ shoreContacts G (MissPart G X r i) p) →
      (∀ u ∈ T, ∀ v ∈ T, ¬ G.Adj u v) → T.card ≤ 2) := by
  have none : NoRootedFour G (MissPart G X r i) p := fun f h0 side =>
    F.contact_no_four_on_misses pi.1 pi.2.1 f h0 (fun n h => noncontactComponent_subset i (side n h))
  have off : p ∉ MissPart G X r i := fun e => (noncontactComponent_subset i e).2 pi.2.1
  obtain ⟨s,si,ps⟩ := pi.2.2
  refine ⟨?_,fun j k ne => none.blockContacts_disjoint off ne,none.card_independent_contacts_le_two⟩
  intro j
  refine ⟨none.all_noncontact_blocks_cliques off (missPart_connected i) ⟨s,si,ps⟩ j,?_⟩
  rintro q ⟨qi,pq,u,uj,qu⟩ v vj
  exact none.contact_common_on_component off j qi pq uj vj qu

/-- Any ordinary contact simultaneously meeting two distinct missed
components must meet the exceptional component, if there is one. -/
theorem SingletonCut.double_contact_through_exception (F : SingletonCut G X z r a b)
    (bad : ¬ UniformMissPart G X r i) (jk : j ≠ k)
    (pj : p ∈ rootedBlockContacts G X r j) (pk : p ∈ rootedBlockContacts G X r k) :
    p ∈ rootedBlockContacts G X r i := by
  classical
  by_contra miss
  have ij : i ≠ j := fun e => miss (e.symm ▸ pj)
  have ik : i ≠ k := fun e => miss (e.symm ▸ pk)
  obtain ⟨q,qi,bq⟩ := F.bad_witness bad
  have skip {l : RootComponent G X r} (il : i ≠ l) {v : V} (vl : v ∈ MissPart G X r l) : ¬ G.Adj q v :=
    fun e => bq (F.shared_contact_good il qi ⟨qi.1,qi.2.1,v,vl,e⟩)
  obtain ⟨s,si,qs⟩ := qi.2.2
  obtain ⟨v,vj,pv⟩ := pj.2.2
  obtain ⟨w,wk,pw⟩ := pk.2.2
  have sm := noncontactComponent_subset i si
  have vm := noncontactComponent_subset j vj
  have wm := noncontactComponent_subset k wk
  have outside : p ∈ ExteriorOfPart G X r i :=
    ⟨fun h => (noncontactComponent_subset i h).2 pj.2.1,fun u ui e => miss ⟨pj.1,pj.2.1,u,ui,e⟩⟩
  have other {l : RootComponent G X r} (li : l ≠ i) {t : V} (tl : t ∈ MissPart G X r l) :
      t ∈ ExteriorOfPart G X r i :=
    ⟨Set.disjoint_left.mp (noncontactComponents_apart li) tl,fun _ x => noncontactComponents_anticomplete li tl x⟩
  have qp := F.exclusive_contacts_complete sm.1 vm.1 (missPart_different ij si vj) sm.2 vm.2
    (noncontactComponents_anticomplete ij si vj) qi.1 pj.1 qi.2.1 pj.2.1 qs.symm
    (fun e => skip ij vj e.symm) pv.symm (fun e => outside.2 _ si e.symm)
  have qv : q ≠ v := fun e => vm.2 (e ▸ qi.2.1)
  have qw : q ≠ w := fun e => wm.2 (e ▸ qi.2.1)
  have vw := missPart_different jk vj wk
  exact NoRootedFour.forbids_four (F.bad_contact_exterior qi bq) outside (other ij.symm vj) (other ik.symm wk)
    (by simp [qp.ne,qv,qw,pv.ne,pw.ne,vw]) qp (Or.inr ⟨pv.symm,fun e => skip ij vj e.symm⟩)
    (Or.inr (Or.inl ⟨pw.symm,fun e => skip ik wk e.symm,fun e => noncontactComponents_anticomplete jk vj wk e.symm⟩))

/-- If some missed component is nonclique, no ordinary contact can be
shared by two distinct missed components. -/
theorem SingletonCut.contacts_disjoint_of_nonclique (F : SingletonCut G X z r a b)
    (nc : ¬ (MissPart G X r i).Pairwise G.Adj) (jk : j ≠ k) :
    Disjoint (rootedBlockContacts G X r j) (rootedBlockContacts G X r k) := by
  apply Set.disjoint_left.mpr
  intro p pj pk
  have pi := F.double_contact_through_exception (fun good => nc good.1) jk pj pk
  by_cases ij : i = j
  · exact nc (F.shared_contact_good (ij.symm ▸ jk) pi pk).1
  · exact nc (F.shared_contact_good ij pi pj).1

#print axioms SingletonCut.nested_cliques
#print axioms SingletonCut.double_contact_through_exception
#print axioms SingletonCut.contacts_disjoint_of_nonclique
end Graffiti199Depleted.Catalogue.Incomplete
