import EscapeArm
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {X : Set V} {z r a b x y : V}

private theorem spare_of_degree (F : SingletonCut G X z r a b) (yX : y ∈ X)
    (ry : ¬ G.Adj r y) (xy : ¬ G.Adj x y) (yb : ¬ G.Adj y b) (room : ¬ G.Adj y a ∨ 4 ≤ G.degree y) :
    ∀ i j : V, ∃ w ∈ X \ {x,y}, w ≠ i ∧ w ≠ j ∧ G.Adj y w := by
  classical
  intro i j
  by_contra! no
  let N := G.neighborFinset y
  have bound (w : V) (wn : w ∈ N) : w=a ∨ w=i ∨ w=j := by
    have yw := (G.mem_neighborFinset _ _).mp wn
    rcases F.cover w with wX|wz|wr|wa|wb
    · by_cases wi : w=i
      · exact Or.inr (Or.inl wi)
      by_cases wj : w=j
      · exact Or.inr (Or.inr wj)
      exact (no w ⟨wX,fun h => h.elim (fun e => xy (e ▸ yw.symm)) yw.ne.symm⟩ wi wj yw).elim
    · exact (F.offX y ((F.cut.2 _).mp (wz ▸ yw.symm)) yX).elim
    · exact (ry (wr ▸ yw.symm)).elim
    · exact Or.inl wa
    · exact (yb (wb ▸ yw)).elim
  have dy := degree_of_small_deletion_preconnected (G := G) (by have := F.conn.1; omega : 4 ≤ Fintype.card V)
    (fun K small => (F.conn.2 K small).preconnected) y
  have card : N.card = G.degree y := G.card_neighborFinset_eq_degree _
  have small : ({i,j} : Finset V).card ≤ 2 := by
    calc _ ≤ ({j} : Finset V).card + 1 := Finset.card_insert_le ..
         _ = _ := by simp
  rcases room with ya|high
  · have sub : N ⊆ {i,j} := by
      intro w wm
      have wa : w ≠ a := fun e => ya (e ▸ (G.mem_neighborFinset _ _).mp wm)
      simpa using (bound w wm).resolve_left wa
    have := Finset.card_le_card sub
    omega
  · have sub : N ⊆ {a,i,j} := fun w wm => by simpa using bound w wm
    have := Finset.card_le_card sub
    have cap := Finset.card_insert_le a ({i,j} : Finset V)
    omega

omit [Fintype V] [DecidableEq V] [DecidableRel G.Adj] in
private theorem no_lonely_inside {U : Set V} (R : RightArm G U y b)
    (xy : ¬ G.Adj x y) (noEdge : ∀ t ∈ R.h :: R.tail, ¬ G.Adj x t) : x ∉ R.h :: R.tail := by
  intro m
  obtain ⟨A,B,eq⟩ := List.append_of_mem m
  have aN : A ≠ [] := by
    intro empty
    have e : R.h = x := Option.some.inj (by simpa [empty] using congrArg List.head? eq)
    exact xy (e ▸ R.start.symm)
  let p := A.getLast aN
  have pA : p ∈ A := List.getLast_mem _
  have rel := (List.chain'_append.mp (eq ▸ R.chain)).2.2 p (by rw [List.getLast?_eq_getLast aN]; rfl) x (by simp)
  exact noEdge p (eq.symm ▸ List.mem_append_left _ pA) rel.symm

/-- Excludes the oriented nonadjacent case whenever the second miss has
at least three ordinary contacts. The first miss may be an ordinary leaf. -/
theorem SingletonCut.traceable_of_nonadjacent_degree (F : SingletonCut G X z r a b)
    (cross : CrossingBetweenSurvivingEdges G) (xX : x ∈ X) (yX : y ∈ X) (distinct : x ≠ y)
    (rx : ¬ G.Adj r x) (ry : ¬ G.Adj r y) (xy : ¬ G.Adj x y)
    (on : ∀ w ∈ X \ {x,y}, G.Adj r w) (xa : G.Adj x a) (yb : ¬ G.Adj y b)
    (room : ¬ G.Adj y a ∨ 4 ≤ G.degree y) : Traceable G := by
  classical
  have many := spare_of_degree F yX ry xy yb room
  let U := X \ ({x,y} : Set V)
  have xContact : ∃ s ∈ U, G.Adj x s := by
    obtain ⟨p⟩ := F.connX.preconnected (⟨x,xX⟩ : X) ⟨y,yX⟩
    obtain ⟨i,ix,j,jx,ij⟩ := crossingOnWalk (U := {v : X | v.val=x}) p rfl distinct.symm
    have e : G.Adj x j.val := (show i.val=x from ix) ▸ ij
    exact ⟨j.val,⟨j.property,fun h => h.elim jx (fun jy => xy ((show j.val=y from jy) ▸ e))⟩,e⟩
  obtain ⟨s,sU,xs⟩ := xContact
  obtain ⟨t,tU,ts,_,yt⟩ := many s s
  by_cases extra : ∃ v ∈ U, v ≠ s ∧ G.Adj x v
  · obtain ⟨v,vu,vs,xv⟩ := extra
    obtain ⟨C⟩ := F.connector_to_free_port cross xX yX distinct yb ⟨t,tU,yt⟩
    obtain ⟨R,p,pu,xp,off⟩ := F.free_contact_of_two xX yX distinct rx ry xy on (RightArm.ofConnector C)
      ⟨s,sU,v,vu,vs.symm,xs,xv⟩ many
    exact F.traceable_of_unused_contact xX yX distinct rx ry xy on xa R pu xp off many
  have sy : s ≠ y := fun e => sU.2 (Or.inr e)
  have tSy : t ∈ X \ {s,y} := ⟨tU.1,fun e => e.elim ts (fun e => tU.2 (Or.inr e))⟩
  obtain ⟨C⟩ := F.connector_to_free_port cross sU.1 yX sy yb ⟨t,tSy,yt⟩
  let R := RightArm.ofConnector C
  have all (t : V) (tm : t ∈ R.h :: R.tail) := R.inside _ tm
  have xOff := no_lonely_inside R xy (fun v vm xv => extra ⟨v,⟨(all v vm).1,
    fun e => e.elim xv.ne.symm (fun e => (all v vm).2 (Or.inr e))⟩,fun e => (all v vm).2 (Or.inl e),xv⟩)
  have ins : ∀ v ∈ R.h :: R.tail, v ∈ U := by
    intro v vm; exact ⟨(all v vm).1,fun e => e.elim (fun vx => xOff (vx ▸ vm)) (fun vy => (all v vm).2 (Or.inr vy))⟩
  let A : RightArm G U y b := {R with inside := ins}
  exact F.traceable_of_unused_contact xX yX distinct rx ry xy on xa A sU xs
    (fun m => (all s m).2 (Or.inl rfl)) many

#print axioms SingletonCut.traceable_of_nonadjacent_degree
end Graffiti199Depleted.Catalogue.Incomplete

