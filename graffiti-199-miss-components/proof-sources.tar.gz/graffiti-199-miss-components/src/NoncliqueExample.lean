import MissComponentCount
open private triangle_absurd from CutTorsoBudget

namespace Graffiti199Depleted.Catalogue.Incomplete.NoncliqueExample
open SimpleGraph
abbrev W := Fin 11
private def row : W → Nat := ![14,253,251,247,2030,2014,1982,1918,752,1520,752]

/-- The consecutive sets are a singleton, K3, K4, and P3. Consecutive
sets are completely joined and there are no other inter-set edges. -/
def graph : SimpleGraph W where
  Adj x y := (row x).testBit y.val = true
  symm := by change ∀ x y : W, (row x).testBit y.val = true → (row y).testBit x.val = true; decide +kernel
  loopless := by change ∀ x : W, ¬ (row x).testBit x.val = true; decide +kernel

instance : DecidableRel graph.Adj := fun x y => inferInstanceAs (Decidable ((row x).testBit y.val = true))
abbrev ports : Finset W := {1,2,3}
abbrev hubs : Finset W := {4,5,6,7}
abbrev X : Set W := ↑({4,5,6,7,8,9,10} : Finset W)
abbrev missed : Set W := ↑({8,9,10} : Finset W)

private theorem hub_edges : ∀ h ∈ hubs, ∀ v : W, v ≠ 0 → h ≠ v → graph.Adj h v := by decide +kernel
private theorem zero_edges : ∀ v : W, graph.Adj 0 v ↔ v ∈ ports := by decide +kernel

private theorem to_hub {D : Finset W} {h : W} (hh : h ∈ hubs) (hD : h ∉ D)
    (v : Survives D) (vn : v.val ≠ 0) : (DeletionGraph graph D).Reachable v ⟨h,hD⟩ := by
  by_cases eq : v.val = h
  · exact (show v = ⟨h,hD⟩ from Subtype.ext eq) ▸ .rfl
  · exact (show (DeletionGraph graph D).Adj v ⟨h,hD⟩ from (hub_edges h hh v.val vn (Ne.symm eq)).symm).reachable

theorem connectivity : ConnectivityAtLeast graph 3 := by
  refine ⟨by decide,?_⟩
  intro D small
  obtain ⟨h,hh,hD⟩ := Finset.exists_mem_not_mem_of_card_lt_card
    (show D.card < hubs.card by rw [show hubs.card = 4 by decide]; omega)
  obtain ⟨p,pp,pD⟩ := Finset.exists_mem_not_mem_of_card_lt_card
    (show D.card < ports.card by rw [show ports.card = 3 by decide]; omega)
  let H : Survives D := ⟨h,hD⟩
  have join (v : Survives D) : (DeletionGraph graph D).Reachable v H := by
    by_cases vn : v.val = 0
    · let P : Survives D := ⟨p,pD⟩
      have vp : (DeletionGraph graph D).Adj v P := (show graph.Adj v.val p from vn.symm ▸ (zero_edges p).mpr pp)
      exact vp.reachable.trans (to_hub hh hD P (fun e => (show (0 : W) ∉ ports by decide) (e ▸ pp)))
    · exact to_hub hh hD v vn
  exact @SimpleGraph.Connected.mk _ (DeletionGraph graph D) (fun x y => (join x).trans (join y).symm) ⟨H⟩

theorem crossing : CrossingBetweenSurvivingEdges graph := by
  apply edgeReach_iff_crossing_between_surviving_edges.mp
  intro D small x y v w xy vw
  obtain ⟨h,hh,hD⟩ := Finset.exists_mem_not_mem_of_card_lt_card
    (show D.card < hubs.card by rw [show hubs.card = 4 by decide]; omega)
  have hit {x y : Survives D} (xy : (DeletionGraph graph D).Adj x y) :
      (DeletionGraph graph D).Reachable x ⟨h,hD⟩ := by
    by_cases ne : x.val = 0
    · have yn : y.val ≠ 0 := fun e => (show graph.Adj x.val y.val from xy).ne (ne.trans e.symm)
      exact xy.reachable.trans (to_hub hh hD y yn)
    · exact to_hub hh hD x ne
  exact (hit xy).trans (hit vw).symm

theorem sep : ¬ (DeletionGraph graph ports).Preconnected := by
  intro pc
  let z : Survives ports := ⟨0,by decide⟩
  let h : Survives ports := ⟨4,by decide⟩
  obtain ⟨w⟩ := pc z h
  obtain ⟨x,hx,y,_,xy⟩ := crossingOnWalk (U := {v : Survives ports | v.val = 0}) w
    (show z.val = 0 from rfl) (show h.val ≠ 0 by decide)
  have adj : graph.Adj x.val y.val := xy
  exact y.property ((zero_edges _).mp ((show x.val = 0 from hx) ▸ adj))

theorem kappa : vertexConnectivity graph = 3 := by
  classical
  have ge : 3 ≤ vertexConnectivity graph := Finset.le_sup (f := id)
    (Finset.mem_filter.mpr ⟨Finset.mem_range.mpr (by decide),connectivity⟩)
  apply Nat.le_antisymm _ ge
  by_contra! more
  apply sep
  exact ((connectivityAtLeast_vertexConnectivity (G := graph)).2 ports
    (by rw [show ports.card = 3 by decide]; omega)).preconnected

private def triangles : List (W × W × W) := [(0,1,2),(3,4,5),(6,7,8),(4,9,10),(5,6,9),(1,3,7),(5,7,10),(2,3,6),(1,4,6),(5,8,9),(2,4,7),(0,1,3),(0,2,3),(6,9,10),(5,6,8),(7,8,9),(1,2,3),(1,4,5),(3,4,6),(2,4,6),(4,7,8),(2,4,5)]
private theorem valid : ∀ t ∈ triangles, graph.Adj t.1 t.2.1 ∧ graph.Adj t.1 t.2.2 ∧ graph.Adj t.2.2 t.2.1 := by
  decide +kernel

set_option maxRecDepth 10000 in
set_option maxHeartbeats 5000000 in
private theorem covered : ∀ S : Finset W, 6 ≤ S.card →
    triangles.any (fun t => decide (t.1 ∈ S ∧ t.2.1 ∈ S ∧ t.2.2 ∈ S)) = true := by decide +kernel

theorem budget : treeNumber graph ≤ 5 := by
  classical
  unfold treeNumber
  apply Finset.sup_le
  intro S h
  change S.card ≤ 5
  by_contra! large
  obtain ⟨t,mem,att⟩ := List.any_eq_true.mp (covered S large)
  obtain ⟨s,u,v⟩ := t
  obtain ⟨sm,um,vm⟩ := of_decide_eq_true att
  obtain ⟨su,sv,vu⟩ := valid _ mem
  let H := graph.induce (↑S : Set W)
  have tree : H.IsTree := (Finset.mem_filter.mp h).2
  exact triangle_absurd tree (show H.Adj ⟨s,sm⟩ ⟨u,um⟩ from su)
    (show H.Adj ⟨s,sm⟩ ⟨v,vm⟩ from sv) (show H.Adj ⟨v,vm⟩ ⟨u,um⟩ from vu)

theorem sole_cubic : ∀ v : W, graph.degree v = 3 ↔ v = 0 := by decide +kernel

theorem traceable : Traceable graph := by
  apply traceable_iff_hamiltonian_walk.mpr
  apply pathOn_univ_iff_hamiltonian_walk.mp
  refine ⟨⟨[0,1,2,3,4,5,6,7,8,9,10],by simp,by decide,by decide,?_⟩⟩
  intro v
  change v ∈ ([0,1,2,3,4,5,6,7,8,9,10] : List W) ↔ True
  fin_cases v <;> decide

theorem singleton : SingletonCut graph X 0 1 2 3 := by
  refine ⟨⟨connectivity,by decide,by decide,by decide,?_,?_,?_⟩,budget,by decide,⟨by decide,zero_edges⟩,?_⟩
  · decide +kernel
  · change ∀ v ∈ X, ∀ w ∉ X, graph.Adj v w → w ∈ ports
    decide +kernel
  · let t : X := ⟨4,by decide⟩
    have reach (v : X) : (graph.induce X).Reachable v t := by
      by_cases eq : v.val = 4
      · exact (show v = t from Subtype.ext eq) ▸ .rfl
      · exact (show (graph.induce X).Adj v t from (hub_edges 4 (by decide) _ (fun e =>
          (show (0 : W) ∉ X by decide) (e ▸ v.property)) (Ne.symm eq)).symm).reachable
    exact @SimpleGraph.Connected.mk _ (graph.induce X) (fun v w => (reach v).trans (reach w).symm) ⟨t⟩
  · decide +kernel

theorem each_port_misses_path (p : W) (hp : p ∈ ports) : Noncontacts graph X p = missed := by
  ext v
  exact (show ∀ p ∈ ports, ∀ v : W, (v ∈ X ∧ ¬ graph.Adj p v) ↔ v ∈ missed by decide +kernel) p hp v

theorem actual_nonclique : ∃ i : RootComponent graph X 1,
    MissPart graph X 1 i = missed ∧ ¬ (MissPart graph X 1 i).Pairwise graph.Adj := by
  let M := Noncontacts graph X 1
  let m : M := ⟨9,by decide⟩
  let i := (graph.induce M).connectedComponentMk m
  have all (v : M) : v ∈ i.supp := by
    by_cases e : v.val = 9
    · exact (show v = m from Subtype.ext e) ▸ rfl
    · have reach : (graph.induce M).Adj m v :=
        (show ∀ v : W, v ∈ M → v ≠ 9 → graph.Adj 9 v by decide +kernel) v.val v.property e
      exact (i.mem_supp_congr_adj reach).mp rfl
  have eq : MissPart graph X 1 i = missed := by
    ext v
    rw [← each_port_misses_path 1 (by decide)]
    exact ⟨fun h => noncontactComponent_subset i h,fun h => ⟨⟨v,h⟩,all ⟨v,h⟩,rfl⟩⟩
  refine ⟨i,eq,?_⟩
  rw [eq]
  exact fun c => (show ¬ graph.Adj 8 10 by decide) (c (by decide) (by decide) (by decide))

#print axioms crossing
#print axioms kappa
#print axioms budget
#print axioms sole_cubic
#print axioms traceable
#print axioms singleton
#print axioms each_port_misses_path
#print axioms actual_nonclique
end Graffiti199Depleted.Catalogue.Incomplete.NoncliqueExample


