import Exclusive
open private component_only_vertex from ExactSingleton
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {X : Set V} {z r a b x y : V}

structure PairContacts (G : SimpleGraph V) (U : Set V) (a x : V) where
  set : Finset V
  card : set.card = 2
  inside : ∀ w ∈ set, w ∈ U
  exactAdj : ∀ v, G.Adj x v ↔ v = a ∨ v ∈ set

theorem SingletonCut.pair_contacts_of_cubic (F : SingletonCut G X z r a b) (xX : x ∈ X)
    (rx : ¬ G.Adj r x) (xa : G.Adj x a) (xb : ¬ G.Adj x b) (xy : ¬ G.Adj x y)
    (deg : G.degree x = 3) : Nonempty (PairContacts G (X \ {x,y}) a x) := by
  classical
  let N := (G.neighborFinset x).erase a
  have ax := (G.mem_neighborFinset _ _).mpr xa
  have size : N.card = 2 := by
    rw [Finset.card_erase_of_mem ax,G.card_neighborFinset_eq_degree,deg]
  refine ⟨⟨N,size,?_,?_⟩⟩
  · intro v vm
    obtain ⟨va,vn⟩ := Finset.mem_erase.mp vm
    have xv := (G.mem_neighborFinset _ _).mp vn
    have inX : v ∈ X := by
      rcases F.cover v with h|vz|vr|e|vb
      · exact h
      · exact (F.offX x ((F.cut.2 _).mp (vz ▸ xv.symm)) xX).elim
      · exact (rx (vr ▸ xv.symm)).elim
      · exact (va e).elim
      · exact (xb (vb ▸ xv)).elim
    exact ⟨inX,fun h => h.elim xv.ne.symm (fun e => xy ((show v=y from e) ▸ xv))⟩
  · intro v
    by_cases va : v=a
    · simp [va,xa]
    · simp [N,va]

omit [DecidableRel G.Adj] in
theorem SingletonCut.traceable_of_equal_pair_contacts (F : SingletonCut G X z r a b)
    (xX : x ∈ X) (yX : y ∈ X) (xy : x ≠ y)
    (A : PairContacts G (X \ {x,y}) a x) (B : PairContacts G (X \ {x,y}) a y)
    (eq : A.set=B.set) : Traceable G := by
  classical
  let D := insert a A.set
  have inX {v} (m : v ∈ A.set) := (A.inside _ m).1
  have off (p : V) (pm : p ∈ ({r,a,b} : Finset V)) : p ∉ A.set := fun m => F.offX _ pm (inX m)
  have size : D.card=3 := by simp [D,off a (by simp),A.card]
  have ax : a ≠ x := fun e => F.offX a (by simp) (e.symm ▸ xX)
  have ay : a ≠ y := fun e => F.offX a (by simp) (e.symm ▸ yX)
  let u : Survives D := ⟨x,by simp [D,ax.symm,show x ∉ A.set from fun m => (A.inside _ m).2 (Or.inl rfl)]⟩
  let v : Survives D := ⟨y,by simp [D,ay.symm,show y ∉ A.set from fun m => (A.inside _ m).2 (Or.inr rfl)]⟩
  let w : Survives D := ⟨r,by simp [D,F.ra,off r (by simp)]⟩
  have isoX (t : Survives D) : ¬ G.Adj u.val t.val := fun e => t.property
    (Finset.mem_insert.mpr ((A.exactAdj _).mp e))
  have isoY (t : Survives D) : ¬ G.Adj v.val t.val := fun e => t.property
    (Finset.mem_insert.mpr (eq.symm ▸ (B.exactAdj _).mp e))
  let K := (DeletionGraph G D).ConnectedComponent
  let f := (DeletionGraph G D).connectedComponentMk
  have apart {s t : Survives D} (si : ∀ u : Survives D, ¬ G.Adj s.val u.val)
      (ne : s.val ≠ t.val) : f s ≠ f t := fun e => ne (congrArg Subtype.val (component_only_vertex si t e.symm))
  have uv := apart (s:=u) (t:=v) isoX xy
  have uw := apart (s:=u) (t:=w) isoX (fun e => F.offX r (by simp) ((show x=r from e) ▸ xX))
  have vw := apart (s:=v) (t:=w) isoY (fun e => F.offX r (by simp) ((show y=r from e) ▸ yX))
  letI : Fintype K := Fintype.ofFinite _
  have card := Finset.card_le_univ ({f u,f v,f w} : Finset K)
  exact traceable_of_three_or_more_components F.conn F.budget size
    (by change 3 ≤ Nat.card K; simpa [Nat.card_eq_fintype_card,uv,uw,vw] using card)

#print axioms SingletonCut.traceable_of_equal_pair_contacts
end Graffiti199Depleted.Catalogue.Incomplete
