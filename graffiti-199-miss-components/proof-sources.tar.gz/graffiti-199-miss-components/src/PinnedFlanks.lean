import PinnedSplice
open private split_slot from OmissionFlanks
namespace Graffiti199Depleted.Catalogue.Anchored
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} {U C : Set V} (p : PathOn G U)
abbrev Slot (p : PathOn G U) := Fin (p.vertices.length - 1)
def Touch (G : SimpleGraph V) (C : Set V) (v : V) := ∃ w ∈ C, G.Adj v w
private theorem split_two (i j : Slot p) (gap : i.val + 1 < j.val) :
    ∃ (L M R : List V), p.vertices =
      (L ++ [p.before i]) ++ ((p.after i :: M) ++ [p.before j]) ++ (p.after j :: R) := by
  let D := p.vertices.drop (i.val+2)
  let k := j.val - (i.val+2)
  have add : i.val+2+k = j.val := by dsimp [k]; omega
  have kj : k+1 < D.length := by
    have h := j.isLt
    simp only [D,List.length_drop,k]
    omega
  have s := split_slot D k kj
  have first : D[k]'(by omega) = p.before j := by
    simp only [D,List.getElem_drop,add,PathOn.before]
  have next : D[k+1] = p.after j := by
    simp only [D,List.getElem_drop,← Nat.add_assoc,add,PathOn.after]
  rw [first,next] at s
  refine ⟨p.vertices.take i.val,D.take k,D.drop (k+2),?_⟩
  have eq := split_slot p.vertices i.val (by have := i.isLt; omega)
  change p.vertices =
    (p.vertices.take i.val ++ [p.before i]) ++ p.after i :: D at eq
  rw [s] at eq
  simpa only [List.cons_append,List.append_assoc] using eq


theorem before_off (long : Longest G p) (co : (G.induce C).Preconnected) (off : Disjoint U C)
    (i : Slot p) (hit : Touch G C (p.after i)) : ¬ Touch G C (p.before i) := by
  intro h
  obtain ⟨D⟩ := detour_of_connected co off h hit
  apply consecutive_avoids p long (L := p.vertices.take i.val) (R := p.vertices.drop (i.val+2)) ?_ D
  exact split_slot p.vertices i.val (by have := i.isLt; omega)

theorem before_stable (long : Longest G p) (co : (G.induce C).Preconnected) (off : Disjoint U C)
    (i j : Slot p) (hi : Touch G C (p.after i)) (hj : Touch G C (p.after j)) : ¬ G.Adj (p.before i) (p.before j) := by
  intro e
  have ordered (s t : Slot p) (hs : Touch G C (p.after s)) (ht : Touch G C (p.after t))
      (st : s.val < t.val) (edge : G.Adj (p.before s) (p.before t)) : False := by
    have gap : s.val + 1 < t.val := by
      by_contra! ne
      have eq : s.val+1 = t.val := by omega
      have same : p.after s = p.before t := by simp only [PathOn.after,PathOn.before,eq]
      exact before_off p long co off t ht (same ▸ hs)
    obtain ⟨L,M,R,split⟩ := split_two p s t gap
    obtain ⟨D⟩ := detour_of_connected co off hs ht
    exact predecessor_chord p long split edge D
  rcases lt_trichotomy i.val j.val with h|h|h
  · exact ordered i j hi hj h e
  · exact e.ne (congrArg p.before (Fin.ext h))
  · exact ordered j i hj hi h e.symm

theorem slot_of_contact (long : Longest G p) (off : Disjoint U C) {v : V} (vU : v ∈ U)
    (hit : Touch G C v) : ∃ i : Slot p, p.after i = v := by
  obtain ⟨w,wC,vw⟩ := hit
  obtain ⟨k,hk,eq⟩ := List.mem_iff_getElem.mp ((p.covers v).mpr vU)
  have gt : 0 < k := by
    by_contra! neg
    have h : k = 0 := by omega
    subst k
    have first : p.first = v := (List.head_eq_getElem p.nonempty).trans eq
    exact first_avoids p long (fun hw => Set.disjoint_left.mp off hw wC) (first.symm ▸ vw.symm)
  let i : Slot p := ⟨k-1,by omega⟩
  refine ⟨i,?_⟩
  have id : i.val+1=k := by dsimp [i]; omega
  simpa only [PathOn.after,id] using eq

theorem before_not_end (i : Slot p) : p.before i ≠ p.last := by
  intro eq
  have h := i.isLt
  have last : p.last = p.vertices[p.vertices.length-1]'(by omega) := List.getLast_eq_getElem p.nonempty
  rw [last] at eq
  have e : i.val = p.vertices.length-1 := p.nodup.getElem_inj_iff.mp eq
  omega

#print axioms before_stable
end Graffiti199Depleted.Catalogue.Anchored
