import SingleMissCore

namespace Graffiti199Depleted.Catalogue.Anchored
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} {U C : Set V}

def Longest (G : SimpleGraph V) {U : Set V} (P : PathOn G U) : Prop :=
  ∀ L : List V, L.Nodup → L.Chain' G.Adj → L.getLast? = some P.last → L.length ≤ P.vertices.length

structure Detour (G : SimpleGraph V) (U : Set V) (x y : V) where
  mid : List V
  ne : mid ≠ []
  nd : mid.Nodup
  walk : mid.Chain' G.Adj
  fresh : ∀ v ∈ mid, v ∉ U
  left : G.Adj x (mid.head ne)
  right : G.Adj (mid.getLast ne) y

theorem detour_of_connected (conn : (G.induce C).Preconnected) (off : Disjoint U C)
    {x y : V} (h : ∃ u ∈ C, G.Adj x u) (k : ∃ v ∈ C, G.Adj y v) : Nonempty (Detour G U x y) := by
  classical
  obtain ⟨u,hu,xu⟩ := h
  obtain ⟨v,hv,yv⟩ := k
  obtain ⟨w⟩ := conn (⟨u,hu⟩ : C) ⟨v,hv⟩
  let q := w.toPath
  let N := q.val.support.map (fun t : C => t.val)
  have ne : N ≠ [] := by exact fun e => q.val.support_ne_nil (List.map_eq_nil_iff.mp e)
  refine ⟨⟨N,ne,q.property.support_nodup.map Subtype.val_injective,(List.chain'_map _).mpr q.val.chain'_adj_support,
    ?_,?_,?_⟩⟩
  · intro t ht hU
    obtain ⟨s,_,eq⟩ := List.mem_map.mp ht
    exact Set.disjoint_left.mp off hU (eq ▸ s.property)
  · simpa only [N,List.head_map,Walk.head_support] using xu
  · simpa only [N,List.getLast_map,Walk.getLast_support] using yv.symm

private theorem finish (P : PathOn G U) (long : Longest G P) {L N : List V}
    (extra : N ≠ []) (nd : N.Nodup) (fresh : ∀ v ∈ N, v ∉ U)
    (perm : L.Perm (P.vertices ++ N)) (chain : L.Chain' G.Adj)
    (endEq : L.getLast? = some P.last) : False := by
  have clean := (List.Perm.nodup_iff perm).mpr (List.nodup_append.mpr
    ⟨P.nodup,nd,fun v vp vn => fresh v vn ((P.covers v).mp vp)⟩)
  have len := long L clean chain endEq
  have equal := perm.length_eq
  rw [List.length_append] at equal
  have pos : 0 < N.length := List.length_pos_iff.mpr extra
  omega

private theorem place (P : PathOn G U) (long : Longest G P)
    {A C : List V} {x y : V} (route : (A ++ C).Perm P.vertices)
    (oldA : A.Chain' G.Adj) (oldC : C.Chain' G.Adj) (a : A.getLast? = some x)
    (c : C.head? = some y) (last : C.getLast? = some P.last) (D : Detour G U x y) : False := by
  have cn : C ≠ [] := fun eq => by simp [eq] at c
  have part : (D.mid ++ C).Chain' G.Adj := by
    apply D.walk.append oldC
    intro u hu v hv
    have ueq := (List.mem_getLast?_eq_getLast hu).choose_spec
    have veq : y = v := Option.some.inj (c.symm.trans (Option.mem_def.mp hv))
    exact veq ▸ ueq.symm ▸ D.right
  have chain : (A ++ (D.mid ++ C)).Chain' G.Adj := by
    apply oldA.append part
    intro u hu v hv
    have ueq : x = u := Option.some.inj (a.symm.trans (Option.mem_def.mp hu))
    rw [List.head?_append_of_ne_nil _ D.ne,List.head?_eq_head D.ne] at hv
    exact ueq ▸ (Option.mem_some.mp hv) ▸ D.left
  have order : (A ++ (D.mid ++ C)).Perm (P.vertices ++ D.mid) := by
    exact (((List.perm_append_comm (l₁ := D.mid) (l₂ := C)).append_left A).trans
      (by simpa [List.append_assoc] using route.append_right D.mid))
  apply finish P long D.ne D.nd D.fresh order chain
  rw [← List.append_assoc,List.getLast?_append_of_ne_nil _ cn,last]

theorem first_avoids (P : PathOn G U) (long : Longest G P) {v : V} (off : v ∉ U) :
    ¬ G.Adj v P.first := by
  intro e
  have before : ([v] ++ P.vertices).Chain' G.Adj := by
    apply (List.chain'_singleton (R := G.Adj) v).append P.chain
    intro u hu t ht
    have uv : v = u := by simpa using hu
    rw [List.head?_eq_head P.nonempty] at ht
    exact uv ▸ (Option.mem_some.mp ht) ▸ e
  apply finish P long (N := [v]) (by simp) (by simp) (fun t ht => (List.mem_singleton.mp ht).symm ▸ off)
    (List.perm_append_comm (l₁ := [v]) (l₂ := P.vertices)) before
  exact (List.getLast?_append_of_ne_nil [v] P.nonempty).trans (List.getLast?_eq_getLast P.nonempty)

theorem consecutive_avoids (P : PathOn G U) (long : Longest G P) {L R : List V} {x y : V}
    (split : P.vertices = (L ++ [x]) ++ y :: R) (D : Detour G U x y) : False := by
  have old : ((L ++ [x]) ++ y :: R).Chain' G.Adj := split ▸ P.chain
  apply place P long (A := L ++ [x]) (C := y :: R) (by rw [← split]) old.left_of_append
    old.right_of_append (by simp) (by simp) ?_ D
  rw [← List.getLast?_append_of_ne_nil (L ++ [x]) (by simp : y :: R ≠ []),← split]
  exact List.getLast?_eq_getLast P.nonempty

theorem predecessor_chord (P : PathOn G U) (long : Longest G P) {L M R : List V} {a x b y : V}
    (split : P.vertices = (L ++ [a]) ++ ((x :: M) ++ [b]) ++ (y :: R))
    (edge : G.Adj a b) (D : Detour G U x y) : False := by
  let A := L ++ [a]
  let B := (x :: M) ++ [b]
  let T := y :: R
  have eq : (A ++ B) ++ T = P.vertices := split.symm
  have ch : ((A ++ B) ++ T).Chain' G.Adj := eq.symm ▸ P.chain
  have AB := ch.left_of_append
  have rev := List.chain'_reverse.mpr (AB.right_of_append.imp
    (R := G.Adj) (S := flip G.Adj) (fun _ _ e => e.symm))
  have step : (A ++ B.reverse).Chain' G.Adj := by
    apply AB.left_of_append.append rev
    intro s hs t ht
    have as' : a = s := by simpa [A] using hs
    have bt : b = t := by simpa [B,List.head?_reverse] using ht
    exact as' ▸ bt ▸ edge
  apply place P long (A := A ++ B.reverse) (C := T)
    (eq ▸ (((List.reverse_perm B).append_left A).append_right T)) step ch.right_of_append ?_ (by simp [T]) ?_ D
  · rw [List.getLast?_append_of_ne_nil A (by simp [B]),List.getLast?_reverse]
    simp [B]
  · rw [← List.getLast?_append_of_ne_nil (A ++ B) (by simp [T]),eq]
    exact List.getLast?_eq_getLast P.nonempty

end Graffiti199Depleted.Catalogue.Anchored

