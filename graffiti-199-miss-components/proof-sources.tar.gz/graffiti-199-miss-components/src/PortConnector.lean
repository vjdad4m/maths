import ReserveObstruction
import ChordlessConnector
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X : Set V} {z r a b x y : V}

/-- After deleting x,r,a, a surviving ordinary edge from y must connect
to the surviving edge b-z. Thus a single component away from x and y
meets both y and b and supplies a chordless connector between them. -/
theorem SingletonCut.connector_to_free_port (F : SingletonCut G X z r a b)
    (cross : CrossingBetweenSurvivingEdges G) (xX : x ∈ X) (yX : y ∈ X)
    (distinct : x ≠ y) (yb : ¬ G.Adj y b) (contact : ∃ c ∈ X \ {x,y}, G.Adj y c) :
    Nonempty (ChordlessConnector G (X \ {x,y}) y b) := by
  classical
  let U := X \ ({x,y} : Set V)
  let D := Uᶜ.toFinset
  let K := (DeletionGraph G D).ConnectedComponent
  let B (i : K) := componentShore D i
  have kept {i : K} {v : V} (vm : v ∈ B i) : v ∈ U := by
    obtain ⟨t,_,rfl⟩ := vm
    simpa [D] using t.property
  have own {v : V} (hv : v ∈ U) : ∃ i : K, v ∈ B i := by
    let t : Survives D := ⟨v,by simpa [D] using hv⟩
    exact ⟨(DeletionGraph G D).connectedComponentMk t,t,rfl,rfl⟩
  let S := {v : V | v=y ∨ ∃ i : K, v ∈ B i ∧ ∃ t ∈ B i, G.Adj y t}
  let cut : Finset V := {x,r,a}
  have ssub : S ⊆ X := by
    rintro v (vy|⟨i,vi,_⟩); exact vy.symm ▸ yX; exact (kept vi).1
  have off (v : V) (vx : v ∈ X) (p : V) (pm : p ∈ ({r,a,b} : Finset V)) : v ≠ p :=
    fun eq => F.offX p pm (eq ▸ vx)
  have rD : r ∈ ({r,a,b} : Finset V) := by simp
  have aD : a ∈ ({r,a,b} : Finset V) := by simp
  have bD : b ∈ ({r,a,b} : Finset V) := by simp
  have zr := (F.cut.2 r).mpr rD
  have za := (F.cut.2 a).mpr aD
  have zb := (F.cut.2 b).mpr bD
  have yS : y ∈ S := Or.inl rfl
  obtain ⟨c,cu,yc⟩ := contact
  obtain ⟨k,ck⟩ := own cu
  have cS : c ∈ S := Or.inr ⟨k,ck,c,ck,yc⟩
  have clear {v : V} (vX : v ∈ X) (vx : v ≠ x) : v ∉ cut := by simp [cut,vx,off v vX r rD,off v vX a aD]
  have cclear := clear cu.1 (fun eq => cu.2 (Or.inl eq))
  have zclear : z ∉ cut := by simp [cut,zr.ne,za.ne,show z ≠ x from fun e => F.zX (e.symm ▸ xX)]
  have bclear : b ∉ cut := by simp [cut,(off x xX b bD).symm,F.rb.symm,F.ab.symm]
  obtain ⟨u,us,v,vs,_uc,vc,uv⟩ := cross cut (by simp [cut,off x xX r rD,off x xX a aD,F.ra]) S
    ⟨y,yS,c,cS,clear yX distinct.symm,cclear,yc⟩
    ⟨z,fun h => F.zX (ssub h),b,fun h => F.offX b bD (ssub h),zclear,bclear,zb⟩
  have bEq : v=b := by
    rcases F.cover v with vX|vz|vr|va|vb
    · have vU : v ∈ U := ⟨vX,fun h => h.elim (fun e => vc (by simp [cut,e]))
        (fun e => vs ((show v=y from e).symm ▸ yS))⟩
      apply False.elim
      apply vs; right
      rcases us with uy|⟨i,ui,met⟩
      · obtain ⟨j,vj⟩ := own vU
        exact ⟨j,vj,v,vj,uy ▸ uv⟩
      · refine ⟨i,?_,met⟩
        exact Classical.byContradiction fun outside =>
          (show v ∉ D by simpa [D] using vU) (componentShore_boundary D i u ui v outside uv)
    · exact (F.offX u ((F.cut.2 u).mp (vz ▸ uv.symm)) (ssub us)).elim
    · exact (vc (by simp [cut,vr])).elim
    · exact (vc (by simp [cut,va])).elim
    · exact vb
  rcases us with uy|⟨i,ui,hit⟩
  · exact (yb (uy ▸ bEq ▸ uv)).elim
  obtain ⟨C⟩ := exists_chordless_connector (componentShore_connected D i).preconnected
    (off y yX b bD) yb hit ⟨u,ui,bEq ▸ uv.symm⟩
  exact ⟨{ C with kept := fun j => kept (C.kept j) }⟩

#print axioms SingletonCut.connector_to_free_port
end Graffiti199Depleted.Catalogue.Incomplete
