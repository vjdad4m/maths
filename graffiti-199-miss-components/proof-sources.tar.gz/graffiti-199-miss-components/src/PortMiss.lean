import ExactSingleton
import PredecessorQuartet
open private six_le_treeNumber_of_five_independent_neighbors from CubicEdgeCuts

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
universe u
variable {V : Type u} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {X : Set V} {z r a b : V}

theorem SingletonCut.cubic (F : SingletonCut G X z r a b) : G.degree z = 3 := by
  have he : G.neighborFinset z = {r,a,b} := by
    ext p
    exact (G.mem_neighborFinset z p).trans (F.cut.2 p)
  rw [← G.card_neighborFinset_eq_degree,he]
  simp [F.ra,F.rb,F.ab]

theorem SingletonCut.flanks_in_shore (F : SingletonCut G X z r a b) (no : ¬ Traceable G)
    (P : PathOn G {v | v ≠ z}) : ∀ v ∈ P.terminalQuartet, v ∈ X := by
  intro v hv
  rcases F.cover v with vx|vz|vd
  · exact vx
  · subst v; exact (P.omitted_off_terminalQuartet hv).elim
  · exact (P.no_edge_from_omitted_to_terminalQuartet no v hv ((F.cut.2 v).mpr (by simpa using vd))).elim

theorem SingletonCut.misses_flank (F : SingletonCut G X z r a b) (no : ¬ Traceable G)
    (P : PathOn G {v | v ≠ z}) {s : V} (hs : s ∈ ({r,a,b} : Finset V)) :
    ∃ v ∈ P.terminalQuartet, ¬ G.Adj s v := by
  classical
  by_contra! hits
  let T := insert z P.terminalQuartet
  have count : T.card = 5 := by
    rw [Finset.card_insert_of_not_mem P.omitted_off_terminalQuartet,P.terminalQuartet_card no,F.cubic]
  have contacts : ∀ v ∈ T, G.Adj s v := by
    intro v hv
    rcases Finset.mem_insert.mp hv with rfl|mem
    · exact ((F.cut.2 s).mpr hs).symm
    · exact hits v mem
  have stable : ∀ v ∈ T, ∀ w ∈ T, ¬ G.Adj v w := by
    intro v hv w hw
    rcases Finset.mem_insert.mp hv with rfl|vm <;> rcases Finset.mem_insert.mp hw with rfl|wm
    · exact G.loopless _
    · exact P.no_edge_from_omitted_to_terminalQuartet no _ wm
    · exact fun e => P.no_edge_from_omitted_to_terminalQuartet no _ vm e.symm
    · exact P.terminalQuartet_independent no _ vm _ wm
  exact (Nat.not_succ_le_self 5) ((six_le_treeNumber_of_five_independent_neighbors T s
    count.ge contacts stable).trans F.budget)

/-- Each port misses an ordinary vertex incident to another port, or it misses
both endpoints of every spanning path of the singleton deletion. -/
theorem SingletonCut.port_miss_dichotomy (F : SingletonCut G X z r a b) (no : ¬ Traceable G)
    {s : V} (hs : s ∈ ({r,a,b} : Finset V)) :
    (∃ v ∈ X, ¬ G.Adj s v ∧ ∃ t ∈ ({r,a,b} : Finset V), t ≠ s ∧ G.Adj t v) ∨
    ∀ P : PathOn G {v | v ≠ z}, P.first ≠ P.last ∧ ¬ G.Adj s P.first ∧ ¬ G.Adj s P.last := by
  classical
  by_cases some : ∃ v ∈ X, ¬ G.Adj s v ∧ ∃ t ∈ ({r,a,b} : Finset V), t ≠ s ∧ G.Adj t v
  · exact Or.inl some
  right
  have endpoint (P : PathOn G {v | v ≠ z}) : ¬ G.Adj s P.last := by
    obtain ⟨v,mem,off⟩ := F.misses_flank no P hs
    rcases Finset.mem_insert.mp mem with eq|pred
    · exact eq ▸ off
    · obtain ⟨i,atI,before⟩ := P.mem_predecessors.mp pred
      have chain := P.chain
      rw [P.split_at_edge i,List.append_assoc] at chain
      have edge : G.Adj (P.before i) (P.after i) := chain.right_of_append.rel_head
      have contact : G.Adj (P.after i) v := before ▸ edge.symm
      exact (some ⟨v,F.flanks_in_shore no P v mem,off,P.after i,(F.cut.2 _).mp atI,
        fun eq => off (eq ▸ contact),contact⟩).elim
  intro P
  let Q : PathOn G {v | v ≠ z} :=
    ⟨P.vertices.reverse,by simpa using P.nonempty,
      List.chain'_reverse.mpr (P.chain.imp (fun _ _ e => e.symm)),
      List.nodup_reverse.mpr P.nodup,fun v => by simpa using P.covers v⟩
  have eq : Q.last = P.first := by simp [Q,PathOn.last,PathOn.first]
  refine ⟨?_,eq ▸ endpoint Q,endpoint P⟩
  intro e
  obtain ⟨i,_⟩ := P.neighbor_has_position no ((F.cut.2 s).mpr hs)
  have il := i.isLt
  have first : P.first = P.vertices[0]'(by omega) := List.head_eq_getElem P.nonempty
  have last : P.last = P.vertices[P.vertices.length-1]'(by omega) := List.getLast_eq_getElem P.nonempty
  rw [first,last] at e
  have clash : 0 = P.vertices.length - 1 := P.nodup.getElem_inj_iff.mp e
  omega

#print axioms SingletonCut.misses_flank
#print axioms SingletonCut.port_miss_dichotomy
end Graffiti199Depleted.Catalogue.Incomplete

