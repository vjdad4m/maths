import OmissionFlanks

/- The following terminal-flank definitions and lemmas are the prefix of
the archived FlankAttachment.lean. The remainder treats a different
branch of the cubic-edge argument. -/
namespace Graffiti199Depleted.PathOn

open SimpleGraph

universe u

variable {V : Type u} {G : SimpleGraph V} {z : V}
variable [DecidableEq V] [DecidableRel G.Adj] [Fintype V]
variable (p : PathOn G {v | v ≠ z})

/-- The right endpoint together with the predecessors of the
omitted vertex's neighbors. -/
def terminalQuartet : Finset V := insert p.last p.predecessors

theorem terminalQuartet_card (noTrace : ¬ Catalogue.Traceable G) :
    p.terminalQuartet.card = G.degree z + 1 := by
  have off : p.last ∉ p.predecessors := by
    intro h
    obtain ⟨i,_,eq⟩ := p.mem_predecessors.mp h
    exact p.before_ne_last i eq
  rw [terminalQuartet,Finset.card_insert_of_not_mem off,p.predecessors_card noTrace]

omit [Fintype V] in
theorem omitted_off_terminalQuartet : z ∉ p.terminalQuartet := by
  intro mem
  rcases Finset.mem_insert.mp mem with eq|pred
  · exact p.last_mem eq.symm
  · obtain ⟨i,_,eq⟩ := p.mem_predecessors.mp pred
    exact ((p.covers (p.before i)).mp (p.before_mem i)) eq

omit [Fintype V] in
theorem no_edge_from_omitted_to_terminalQuartet (noTrace : ¬ Catalogue.Traceable G)
    (x : V) (mem : x ∈ p.terminalQuartet) : ¬ G.Adj z x := by
  rcases Finset.mem_insert.mp mem with rfl|pred
  · exact (omission_constraints noTrace p).lastOff
  · obtain ⟨i,hi,rfl⟩ := p.mem_predecessors.mp pred
    exact p.predecessor_not_neighbor noTrace i hi

omit [Fintype V] in
theorem terminalQuartet_independent (noTrace : ¬ Catalogue.Traceable G) :
    ∀ x ∈ p.terminalQuartet, ∀ y ∈ p.terminalQuartet, ¬ G.Adj x y := by
  intro x hx y hy
  rcases Finset.mem_insert.mp hx with rfl|xP <;> rcases Finset.mem_insert.mp hy with rfl|yP
  · exact G.loopless _
  · obtain ⟨i,h,rfl⟩ := p.mem_predecessors.mp yP
    exact p.terminal_not_adj_predecessor noTrace i h
  · obtain ⟨i,h,rfl⟩ := p.mem_predecessors.mp xP
    exact fun e => p.terminal_not_adj_predecessor noTrace i h e.symm
  · obtain ⟨i,hi,rfl⟩ := p.mem_predecessors.mp xP
    obtain ⟨j,hj,rfl⟩ := p.mem_predecessors.mp yP
    exact p.predecessors_nonadjacent noTrace i j hi hj


end Graffiti199Depleted.PathOn
