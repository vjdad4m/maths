import FinalCut

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} {U X H : Set V} {x y z r a b : V}

/-- A cyclic list can be opened at any specified consecutive pair. -/
private theorem cut_pair (P : PathOn G U) (close : G.Adj P.last P.first)
    {A B : List V} (atPair : P.vertices = A ++ x :: y :: B) : Traverses G U y x := by
  let L := A ++ [x]
  let R := y :: B
  have eq : P.vertices = L ++ R := by simpa [L,R] using atPair
  have ch : (L ++ R).Chain' G.Adj := eq ▸ P.chain
  have turn : (R ++ L).Chain' G.Adj := by
    apply ch.right_of_append.append ch.left_of_append
    intro s hs t ht
    have hlast : s ∈ P.vertices.getLast? := eq.symm ▸ List.mem_getLast?_append_of_mem_getLast? hs
    have hfirst : t ∈ P.vertices.head? := eq.symm ▸ List.mem_head?_append_of_mem_head? ht
    rw [List.getLast?_eq_getLast P.nonempty] at hlast
    rw [List.head?_eq_head P.nonempty] at hfirst
    exact (Option.mem_some.mp hlast) ▸ (Option.mem_some.mp hfirst) ▸ close
  have perm : (R ++ L).Perm P.vertices := eq.symm ▸ List.perm_append_comm
  let Q : PathOn G U := ⟨R ++ L,by simp [R],turn,perm.nodup_iff.mpr P.nodup,fun v => perm.mem_iff.trans (P.covers v)⟩
  refine ⟨Q,rfl,?_⟩
  change (R ++ (A ++ [x])).getLast _ = x
  simp

variable [Fintype V] [DecidableEq V]

theorem SingletonCut.reserve_cycle_edges (F : SingletonCut G X z r a b) {M : Set V}
    (sub : M ⊆ X) (P : PathOn G M) (start : G.Adj a P.first) (finish : G.Adj P.last b) :
    let W := (insert r (X \ M))ᶜ
    (∃ Q : PathOn G W, G.Adj Q.last Q.first) ∧
    ∀ {i j : V} {A B : List V}, P.vertices = A ++ i :: j :: B → Traverses G W j i := by
  let W := (insert r (X \ M))ᶜ
  let L := a :: (P.vertices ++ [b,z])
  have az := ((F.cut.2 a).mpr (by simp)).symm
  have bz := ((F.cut.2 b).mpr (by simp)).symm
  have aM : a ∉ M := fun h => F.offX a (by simp) (sub h)
  have bM : b ∉ M := fun h => F.offX b (by simp) (sub h)
  have zM : z ∉ M := fun h => F.zX (sub h)
  have ch : (P.vertices ++ [b,z]).Chain' G.Adj := by
    apply P.chain.append (by simpa using bz)
    intro u hu v hv
    rw [List.getLast?_eq_getLast P.nonempty] at hu
    have ub := Option.mem_some.mp hu
    have ve : b = v := by simpa using hv
    exact ub ▸ ve ▸ finish
  have first : P.vertices.head? = some P.first := List.head?_eq_head P.nonempty
  have allch : L.Chain' G.Adj := by
    change (a :: (P.vertices ++ [b,z])).Chain' G.Adj
    rw [List.chain'_cons']
    refine ⟨?_,ch⟩
    intro t ht
    rw [List.head?_append,first] at ht
    have h : P.first = t := by simpa using ht
    exact h ▸ start
  have nd : L.Nodup := by
    have aOff : a ∉ P.vertices := fun h => aM ((P.covers a).mp h)
    have bOff : b ∉ P.vertices := fun h => bM ((P.covers b).mp h)
    have zOff : z ∉ P.vertices := fun h => zM ((P.covers z).mp h)
    simp [L,P.nodup,aOff,bOff,zOff,F.ab,az.ne,bz.ne,List.nodup_append]
  let Q : PathOn G W := ⟨L,by simp [L],allch,nd,by
    intro t; rw [F.complement_of_cone sub]
    simp [L,P.covers,or_left_comm,or_comm,or_assoc]⟩
  have close : G.Adj Q.last Q.first := by
    have eq : Q.last = z := by simp [Q,PathOn.last,L]
    exact eq.symm ▸ az.symm
  refine ⟨⟨Q,close⟩,?_⟩
  intro i j A B eq
  apply cut_pair Q close (A := a :: A) (B := B ++ [b,z])
  change a :: (P.vertices ++ [b,z]) = _
  simp [eq,List.append_assoc]

#print axioms SingletonCut.reserve_cycle_edges
end Graffiti199Depleted.Catalogue.Incomplete
