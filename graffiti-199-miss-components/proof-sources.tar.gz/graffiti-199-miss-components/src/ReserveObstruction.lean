import ShoreContacts
import LabelChain
open private open_at from ConnectedAlphaTwo
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X M : Set V} {z r a b : V}

theorem SingletonCut.cliques_from_reserve_cycle (F : SingletonCut G X z r a b) (sub : M ⊆ X)
    (on : ∀ u ∈ X \ M, G.Adj r u) (P : PathOn G M) (start : G.Adj a P.first) (finish : G.Adj P.last b)
    (no : ¬ Traceable G) : ∃ C : ThreeCliques G (X \ M),
      P.vertices.Chain' (fun s t => ∀ i j, C.hits s i → C.hits t j → i = j) := by
  classical
  let H := X \ M
  obtain ⟨⟨Q,close⟩,edges⟩ := F.reserve_cycle_edges sub P start finish
  have non : H.Nonempty := by
    by_contra neg
    have emp := Set.not_nonempty_iff_eq_empty.mp neg
    let W := insert r H
    have zr := (F.cut.2 r).mpr (by simp)
    have zout : z ∈ Wᶜ := fun inW => inW.elim zr.ne (fun h => F.zX h.1)
    obtain ⟨e,route⟩ := open_at Q (Or.inr close) zout
    have single : W = {r} := by simp [W,emp]
    have first : Traverses G W r r := single.symm ▸ Traverses.single r
    obtain ⟨R,_,_⟩ := first.join route disjoint_compl_right zr.symm
    exact no (traceable_iff_hamiltonian_walk.mpr (pathOn_univ_iff_hamiltonian_walk.mp ⟨Set.union_compl_self W ▸ R⟩))
  obtain ⟨C⟩ := F.three_cliques_of_cycle (H := H) (fun _ h => h.1) on non Q close no
  refine ⟨C,List.chain'_iff_forall_rel_of_append_cons_cons.mpr ?_⟩
  intro u v L R eq i j ui vj
  obtain ⟨s,si,us⟩ := ui
  obtain ⟨t,tj,vt⟩ := vj
  exact Classical.byContradiction fun ne => no (C.splice F (fun _ h => h.1) on (edges eq).reverse ne si tj us.symm vt)

/-- A route between contacts of a and b with at least two internal vertices
suffices when each internal vertex either sees r or has a neighbor outside
the reserved path on the ordinary shore. All r-misses must be reserved. -/
theorem SingletonCut.traceable_of_contacted_internal_path (F : SingletonCut G X z r a b) (sub : M ⊆ X)
    (on : ∀ u ∈ X \ M, G.Adj r u) (P : PathOn G M) (start : G.Adj a P.first) (finish : G.Adj P.last b)
    {x s t y : V} {T : List V} (ord : P.vertices = x :: s :: t :: (T ++ [y]))
    (internal : ∀ v ∈ s :: t :: T, G.Adj r v ∨ ∃ w ∈ X \ M, G.Adj v w) : Traceable G := by
  classical
  by_contra no
  obtain ⟨C,chain⟩ := F.cliques_from_reserve_cycle sub on P start finish no
  have hits : ∀ v ∈ s :: t :: T, ∃ i, C.hits v i := by
    intro v vm
    have vM := (P.covers v).mp (by rw [ord]; exact List.mem_cons_of_mem _ (List.mem_append_left [y] vm))
    rcases internal _ vm with rv|⟨w,wh,vw⟩
    · exact C.hits_of_neighbor F (fun _ h => h.1) on (sub vM) (fun h => h.2 vM) rv
    · obtain ⟨i,wi⟩ := (C.cover _).mp wh
      exact ⟨i,w,wi,vw⟩
  obtain ⟨i,mono⟩ := single_color_of_chain C.hits (ord ▸ chain) hits
  obtain ⟨j,ne⟩ : ∃ j : Fin 3, j ≠ i := exists_ne i
  have mn : M.Nonempty := ⟨P.last,P.last_mem⟩
  obtain ⟨u,um,hj⟩ := C.reserve_hits F sub mn j
  exact ne (mono u (ord ▸ (P.covers u).mpr um) j hj)

#print axioms SingletonCut.traceable_of_contacted_internal_path
end Graffiti199Depleted.Catalogue.Incomplete
