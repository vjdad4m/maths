import Exclusive
import FlexibleEdge
import Mathlib.Data.List.FinRange
import Mathlib.Data.List.OfFn
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} {X : Set V} {x y b : V}

/-- The ordinary interior of a route from y to b which has only one neighbor
of y. No condition is placed on chords not incident to y. -/
structure RightArm (G : SimpleGraph V) (U : Set V) (y b : V) where
  h : V
  tail : List V
  nodup : (h :: tail).Nodup
  chain : (h :: tail).Chain' G.Adj
  inside : ∀ w ∈ h :: tail, w ∈ U
  start : G.Adj y h
  only : ∀ w ∈ h :: tail, G.Adj y w → w = h
  finish : G.Adj ((h :: tail).getLast (by simp)) b

noncomputable def RightArm.ofConnector {U : Set V} (C : ChordlessConnector G U y b) : RightArm G U y b := by
  let L := List.ofFn C.inside
  have ne : L ≠ [] := by simp [L]
  let h := C.inside 0
  have head : L.head ne = h := by simp [L,h,List.head_ofFn]
  have eq : h :: L.tail = L := by rw [← head,List.head_cons_tail]
  have chain : L.Chain' G.Adj := by
    apply List.chain'_iff_get.mpr
    intro i hi; simp only [L,List.length_ofFn] at hi
    simp only [L,List.get_eq_getElem,List.getElem_ofFn]
    exact (C.chain _ _).mpr (Or.inl rfl)
  refine ⟨h,L.tail,eq.symm ▸ List.nodup_ofFn_ofInjective C.inside.injective,eq.symm ▸ chain,
    ?_,(C.from_u 0).mpr rfl,?_,?_⟩
  · intro w wm; obtain ⟨i,e⟩ := List.mem_ofFn.mp (eq ▸ wm); exact e ▸ C.kept i
  · intro w wm yw; obtain ⟨i,e⟩ := List.mem_ofFn.mp (eq ▸ wm)
    exact e.symm.trans (congrArg C.inside (Fin.ext ((C.from_u _).mp (e.symm ▸ yw))))
  · have last : L.getLast ne = C.inside (Fin.last C.last) := List.getLast_ofFn_succ _
    have ends := congrArg List.getLast? eq
    rw [List.getLast?_eq_getLast (by simp),List.getLast?_eq_getLast ne] at ends
    exact (Option.some.inj ends).symm ▸ last.symm ▸ ((C.from_v _).mpr rfl).symm

variable [Fintype V] [DecidableEq V] {z r a : V}

private theorem left_route (F : SingletonCut G X z r a b) (R : RightArm G (X \ {x,y}) y b)
    (on : ∀ t ∈ X \ {x,y}, G.Adj r t) (xa : G.Adj x a) (ry : ¬ G.Adj r y) (J : List V)
    (jn : J ≠ []) (head : J.head jn = x) (nd : (J ++ [y]).Nodup)
    (ch : (J ++ [y]).Chain' G.Adj) (jX : ∀ t ∈ J ++ [y], t ∈ X)
    (dis : ∀ t ∈ J ++ [y], t ∉ R.h :: R.tail)
    (spare : ∃ v ∈ X, v ∉ J ++ [y] ∧ v ∉ R.h :: R.tail ∧ G.Adj y v) : Traceable G := by
  let L := (J ++ [y]) ++ (R.h :: R.tail)
  let M := {v : V | v ∈ L}
  have chain : L.Chain' G.Adj := by
    apply ch.append R.chain
    intro u hu v hv
    have uy : y = u := by simpa using hu
    have vh : R.h = v := by simpa using hv
    exact uy ▸ vh ▸ R.start
  let P : PathOn G M := ⟨L,by simp [L],chain,List.nodup_append.mpr ⟨nd,R.nodup,dis⟩,fun _ => Iff.rfl⟩
  have sub : M ⊆ X := by
    intro t tm; exact (List.mem_append.mp tm).elim (jX _) (fun e => (R.inside _ e).1)
  have eq : P.vertices = J ++ y :: R.h :: R.tail := by simp [P,L,List.append_assoc]
  have pf : P.first = x := by
    change ((J ++ [y]) ++ R.h :: R.tail).head _ = x
    rw [List.head_append_of_ne_nil (by simp),List.head_append_of_ne_nil jn,head]
  have pl : P.last = (R.h :: R.tail).getLast (by simp) := List.getLast_append_of_ne_nil _ (by simp)
  have xM : x ∈ M := pf ▸ (P.covers _).mp (List.head_mem P.nonempty)
  have yM : y ∈ M := (P.covers _).mp (by simp [eq])
  have onH : ∀ t ∈ X \ M, G.Adj r t := by
    intro t tm; exact on t ⟨tm.1,fun e => tm.2 (e.elim (fun h => h.symm ▸ xM) (fun h => (show t=y from h).symm ▸ yM))⟩
  obtain ⟨w,wx,wj,wr,yw⟩ := spare
  exact F.traceable_of_reserved_edge sub onH P (pf.symm ▸ xa.symm) (pl.symm ▸ R.finish) eq ry
    ⟨w,⟨wx,fun m => (List.mem_append.mp m).elim wj wr⟩,yw⟩ (Or.inl (on _ (R.inside _ (by simp))))

/-- If one ordinary contact of x lies outside the y-to-b arm, opposite
exclusive contacts give a left arm of length at most three. Three ordinary
contacts of y leave one spare when the two arms are joined. -/
theorem SingletonCut.traceable_of_unused_contact (F : SingletonCut G X z r a b)
    (xX : x ∈ X) (yX : y ∈ X) (distinct : x ≠ y) (rx : ¬ G.Adj r x) (ry : ¬ G.Adj r y)
    (xy : ¬ G.Adj x y) (on : ∀ t ∈ X \ {x,y}, G.Adj r t) (xa : G.Adj x a)
    (R : RightArm G (X \ {x,y}) y b) {s : V} (sU : s ∈ X \ {x,y}) (xs : G.Adj x s)
    (sOff : s ∉ R.h :: R.tail)
    (many : ∀ i j : V, ∃ v ∈ X \ {x,y}, v ≠ i ∧ v ≠ j ∧ G.Adj y v) : Traceable G := by
  classical
  have offx : x ∉ R.h :: R.tail := fun h => (R.inside _ h).2 (Or.inl rfl)
  have offy : y ∉ R.h :: R.tail := fun h => (R.inside _ h).2 (Or.inr rfl)
  have spare (i : V) : ∃ w ∈ X \ {x,y}, w ≠ i ∧ w ∉ R.h :: R.tail ∧ G.Adj y w := by
    obtain ⟨w,wu,wi,wh,yw⟩ := many i R.h
    exact ⟨w,wu,wi,fun m => wh (R.only _ m yw),yw⟩
  have common {v : V} (vU : v ∈ X \ {x,y}) (xv : G.Adj x v) (yv : G.Adj y v) (off : v ∉ R.h :: R.tail) :
      Traceable G := by
    obtain ⟨w,wu,wv,wr,yw⟩ := spare v
    apply left_route F R on xa ry [x,v] (by simp) rfl (by simp [xv.ne,distinct,yv.ne.symm])
      (by simp [List.chain'_cons,xv,yv.symm])
    · intro t tm; simp only [List.cons_append,List.nil_append,List.mem_cons,List.mem_nil_iff,or_false] at tm
      rcases tm with rfl|rfl|rfl <;> first | exact xX | exact yX | exact vU.1
    · intro t tm; simp only [List.cons_append,List.nil_append,List.mem_cons,List.mem_nil_iff,or_false] at tm
      rcases tm with rfl|rfl|rfl <;> assumption
    · exact ⟨w,wu.1,by simp [wv,show w≠x from fun e => wu.2 (Or.inl e),yw.ne.symm],wr,yw⟩
  by_cases ys : G.Adj y s
  · exact common sU xs ys sOff
  obtain ⟨t,tu,_ts,tOff,yt⟩ := spare s
  by_cases xt : G.Adj x t
  · exact common tu xt yt tOff
  have st := F.exclusive_contacts_complete xX yX distinct rx ry xy sU.1 tu.1 (on _ sU) (on _ tu) xs ys yt xt
  obtain ⟨w,wu,wt,wr,yw⟩ := spare t
  have sy : s ≠ y := fun e => sU.2 (Or.inr e)
  have tx : t ≠ x := fun e => tu.2 (Or.inl e)
  apply left_route F R on xa ry [x,s,t] (by simp) rfl
    (by simp [xs.ne,distinct,tx.symm,sy,st.ne,yt.ne.symm]) (by simp [List.chain'_cons,xs,st,yt.symm])
  · intro k km; simp only [List.cons_append,List.nil_append,List.mem_cons,List.mem_nil_iff,or_false] at km
    rcases km with rfl|rfl|rfl|rfl <;> first | exact xX | exact yX | exact sU.1 | exact tu.1
  · intro k km; simp only [List.cons_append,List.nil_append,List.mem_cons,List.mem_nil_iff,or_false] at km
    rcases km with rfl|rfl|rfl|rfl <;> assumption
  · exact ⟨w,wu.1,by simp [wt,show w ≠ s from fun e => ys (e ▸ yw),show w≠x from fun e => wu.2 (Or.inl e),yw.ne.symm],wr,yw⟩

#print axioms SingletonCut.traceable_of_unused_contact
end Graffiti199Depleted.Catalogue.Incomplete

