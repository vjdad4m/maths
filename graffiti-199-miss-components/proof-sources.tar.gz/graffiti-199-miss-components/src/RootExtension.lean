import SmallRoot

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V}

/-- A vertex with a unique neighbor in an ordered induced tree appends a leaf. -/
theorem append_to_root_ordering {n : ℕ} (f : Fin n ↪ V) (h : RootOrdering G f) {w : V}
    (off : ∀ i, w ≠ f i) {j : Fin n} (wj : G.Adj w (f j))
    (unique : ∀ i, G.Adj w (f i) → i = j) :
    ∃ g : Fin (n+1) ↪ V, RootOrdering G g ∧ (∀ i, g i.castSucc = f i) ∧ g (Fin.last n) = w := by
  let s : Fin (n+1) → V := Fin.snoc (α := fun _ => V) (fun i => f i) w
  have left (i : Fin n) : s i.castSucc = f i := by simp [s]
  have right : s (Fin.last n) = w := by simp [s]
  let g : Fin (n+1) ↪ V := ⟨s,by
    intro i k
    refine Fin.lastCases ?_ (fun t => ?_) i
    · refine Fin.lastCases (fun _ => rfl) (fun u eq => ?_) k
      exact (off u (right.symm.trans (eq.trans (left u)))).elim
    · refine Fin.lastCases (fun eq => ?_) (fun u eq => ?_) k
      · exact (off t (right.symm.trans (eq.symm.trans (left t)))).elim
      · exact congrArg Fin.castSucc (f.injective ((left t).symm.trans (eq.trans (left u))))⟩
  refine ⟨g,?_,left,right⟩
  intro i
  refine Fin.lastCases ?_ (fun t ht => ?_) i
  · intro _
    refine ⟨j.castSucc,show G.Adj (s (Fin.last n)) (s j.castSucc) by rwa [right,left],
      Fin.castSucc_lt_last j,?_⟩
    intro k
    refine Fin.lastCases (fun _ lt => (lt_irrefl _ lt).elim) (fun u edge _ => ?_) k
    exact congrArg Fin.castSucc (unique u (by simpa only [g,Function.Embedding.coeFn_mk,right,left] using edge))
  · obtain ⟨p,edge,lt,one⟩ := h t ht
    refine ⟨p.castSucc,show G.Adj (s t.castSucc) (s p.castSucc) by rwa [left,left],lt,?_⟩
    intro k
    refine Fin.lastCases (fun _ bad => (not_lt_of_ge (Fin.le_last t.castSucc) bad).elim)
      (fun u edge' lt' => ?_) k
    exact congrArg Fin.castSucc (one u (by simpa only [g,Function.Embedding.coeFn_mk,left] using edge') lt')

variable [Fintype V] [DecidableEq V] {X : Set V} {z r a b : V}

theorem SingletonCut.append_omitted (F : SingletonCut G X z r a b) {n : ℕ} [NeZero n]
    (f : Fin n ↪ V) (root : RootOrdering G f) (head : f 0 = r) (side : ∀ i, i ≠ 0 → f i ∈ X) :
    ∃ g : Fin (n+1) ↪ V, RootOrdering G g ∧ (∀ i, g i.castSucc = f i) ∧ g (Fin.last n) = z := by
  have zr := (F.cut.2 r).mpr (by simp)
  apply append_to_root_ordering f root (j := 0)
  · intro i eq
    by_cases hi : i = 0
    · subst i; exact zr.ne (eq.trans head)
    · exact F.zX (eq.symm ▸ side i hi)
  · exact head.symm ▸ zr
  · intro i edge
    by_contra non
    exact F.offX _ ((F.cut.2 _).mp edge) (side i non)

/-- The ordinary part of a rooted tree at a port cannot contain four
other vertices, since the singleton supplies a sixth vertex. -/
theorem SingletonCut.no_rooted_five (F : SingletonCut G X z r a b)
    (f : Fin 5 ↪ V) (head : f 0 = r) (side : ∀ i, i ≠ 0 → f i ∈ X) : ¬ RootOrdering G f := by
  intro root
  obtain ⟨g,h,_,_⟩ := F.append_omitted f root head side
  have six := six_le_treeNumber_of_ordering g fun i hi => h i (fun he => hi (Fin.ext he))
  exact (Nat.not_succ_le_self 5) (six.trans F.budget)

/-- Every ordinary vertex outside a rooted quartet either avoids it or
has a second neighbor there. The other cut vertices must hit the quartet. -/
theorem SingletonCut.quartet_contacts (F : SingletonCut G X z r a b)
    (f : Fin 4 ↪ V) (head : f 0 = r) (side : ∀ i, i ≠ 0 → f i ∈ X) (root : RootOrdering G f) :
    (∀ w ∈ X, (∀ i, w ≠ f i) → ∀ i, G.Adj w (f i) → ∃ j, i ≠ j ∧ G.Adj w (f j)) ∧
    (∀ p ∈ ({a,b} : Finset V), ∃ i, G.Adj p (f i)) := by
  classical
  obtain ⟨g,h,left,last⟩ := F.append_omitted f root head side
  have block {w : V} (off : ∀ i, w ≠ g i) {j : Fin 5} (edge : G.Adj w (g j))
      (uniq : ∀ i, G.Adj w (g i) → i = j) : False := by
    obtain ⟨l,hl,_,_⟩ := append_to_root_ordering g h off edge uniq
    exact (Nat.not_succ_le_self 5) ((six_le_treeNumber_of_ordering l
      (fun i hi => hl i (fun e => hi (Fin.ext e)))).trans F.budget)
  constructor
  · intro w wx off i edge
    by_contra! miss
    have wz : w ≠ z := fun e => F.zX (e ▸ wx)
    apply block (j := i.castSucc)
    · exact Fin.lastCases (by rwa [last]) (fun t => by rw [left]; exact off t)
    · rwa [left]
    · refine Fin.lastCases (fun ez => ?_) (fun t et => ?_)
      · rw [last] at ez
        exact (F.offX w ((F.cut.2 _).mp ez.symm) wx).elim
      · by_contra ne
        exact miss t (fun eq => ne (congrArg Fin.castSucc eq.symm)) (left t ▸ et)
  · intro p hp
    have hd : p ∈ ({r,a,b} : Finset V) := Finset.mem_insert_of_mem hp
    have pr : p ≠ r := by
      simp only [Finset.mem_insert,Finset.mem_singleton] at hp
      rcases hp with e|e
      · exact e.symm ▸ F.ra.symm
      · exact e.symm ▸ F.rb.symm
    have pz : p ≠ z := fun e => F.cut.1 (e ▸ hd)
    by_contra! none
    apply block (w := p) (j := Fin.last 4)
    · refine Fin.lastCases (by rwa [last]) (fun i => ?_)
      
      rw [left]
      by_cases hi : i = 0
      · subst i; rwa [head]
      · exact fun eq => F.offX p hd (eq.symm ▸ side i hi)
    · rw [last]
      exact ((F.cut.2 p).mpr hd).symm
    · exact Fin.lastCases (fun _ => rfl) (fun t edge => (none t (left t ▸ edge)).elim)

#print axioms SingletonCut.no_rooted_five
#print axioms SingletonCut.quartet_contacts
end Graffiti199Depleted.Catalogue.Incomplete


