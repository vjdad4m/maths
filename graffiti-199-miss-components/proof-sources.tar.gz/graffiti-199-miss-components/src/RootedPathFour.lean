import NestedMissStructure
open private NoRootedFour.forbids_four from RootedBlocks
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} {E : Set V} {a z r p u : V}

/-- In a region containing no induced four-tree rooted at a, if a sees the
first vertex of an induced four-vertex path it sees the entire path. -/
theorem complete_on_induced_path_of_end (none : NoRootedFour G E a)
    (ze : z ∈ E) (re : r ∈ E) (pe : p ∈ E) (ue : u ∈ E)
    (nd : [a,z,r,p,u].Nodup) (az : G.Adj a z) (zr : G.Adj z r) (rp : G.Adj r p)
    (pu : G.Adj p u) (zp : ¬ G.Adj z p) (zu : ¬ G.Adj z u) (ru : ¬ G.Adj r u) :
    G.Adj a r ∧ G.Adj a p ∧ G.Adj a u := by
  simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,not_or,
    List.nodup_nil,and_true] at nd
  have h1 (ar : ¬ G.Adj a r) (ap : ¬ G.Adj a p) : False :=
    NoRootedFour.forbids_four none ze re pe (by simp; tauto) az
      (Or.inr ⟨zr.symm,fun e => ar e.symm⟩)
      (Or.inr (Or.inr ⟨rp.symm,fun e => ap e.symm,fun e => zp e.symm⟩))
  have h2 (ap : G.Adj a p) (au : ¬ G.Adj a u) : False :=
    NoRootedFour.forbids_four none ze pe ue (by simp; tauto) az
      (Or.inl ⟨ap.symm,fun e => zp e.symm⟩)
      (Or.inr (Or.inr ⟨pu.symm,fun e => au e.symm,fun e => zu e.symm⟩))
  have h3 (ar : ¬ G.Adj a r) (au : G.Adj a u) : False :=
    NoRootedFour.forbids_four none ze re ue (by simp; tauto) az
      (Or.inr ⟨zr.symm,fun e => ar e.symm⟩)
      (Or.inl ⟨au.symm,fun e => zu e.symm,fun e => ru e.symm⟩)
  have h4 (ap : ¬ G.Adj a p) (au : G.Adj a u) : False :=
    NoRootedFour.forbids_four none ze ue pe (by simp; tauto) az
      (Or.inl ⟨au.symm,fun e => zu e.symm⟩)
      (Or.inr (Or.inr ⟨pu,fun e => ap e.symm,fun e => zp e.symm⟩))
  have h5 (ar : G.Adj a r) (ap : ¬ G.Adj a p) (au : ¬ G.Adj a u) : False :=
    NoRootedFour.forbids_four none re pe ue (by simp; tauto) ar
      (Or.inr ⟨rp.symm,fun e => ap e.symm⟩)
      (Or.inr (Or.inr ⟨pu.symm,fun e => au e.symm,fun e => ru e.symm⟩))
  tauto

def AwayFromEdge (G : SimpleGraph V) (s t : V) : Set V :=
  {v | v ≠ s ∧ v ≠ t ∧ ¬ G.Adj v s ∧ ¬ G.Adj v t}

/-- An induced two-edge tail outside a region forbids rooted four-trees there. -/
theorem no_four_away_from_edge [Fintype V] {s t : V} (budget : treeNumber G ≤ 5)
    (st : G.Adj s t) (ats : G.Adj a t) (as' : ¬ G.Adj a s) (ne : a ≠ s) :
    NoRootedFour G (AwayFromEdge G s t) a := by
  intro f h0 side tree
  have offS (n : Fin 4) : s ≠ f n := by
    by_cases h : n = 0
    · simpa only [h,h0] using ne.symm
    · exact (side n h).1.symm
  have offT (n : Fin 4) : t ≠ f n := by
    by_cases h : n = 0
    · simpa only [h,h0] using ats.ne.symm
    · exact (side n h).2.1.symm
  have edges (n : Fin 4) : ¬ G.Adj (f n) s := by
    by_cases h : n = 0
    · simpa only [h,h0] using as'
    · exact (side n h).2.2.1
  have six := six_le_treeNumber_of_rooted_four_and_tail f tree st.symm (h0.symm ▸ ats)
    offT offS edges (fun n h => (side n h).2.2.2)
  omega

#print axioms complete_on_induced_path_of_end
#print axioms no_four_away_from_edge
end Graffiti199Depleted.Catalogue.Incomplete
