import CatalogueThreeMisses
open private connectivity_after_delete from CliqueDeletion
open private order_after_delete treeNumber_after_delete_le from CubicDeletion
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
universe u
variable {V : Type u} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]

/-- Once surviving edges always lie in a common component, every vertex
with no cubic neighbor can be deleted while preserving three-connectivity. -/
theorem connectivity_after_safe_delete (conn : ConnectivityAtLeast G 3)
    (order : 5 ≤ Fintype.card V) (cross : CrossingBetweenSurvivingEdges G)
    {r : V} (safe : ∀ v, G.Adj r v → G.degree v ≠ 3) :
    ConnectivityAtLeast (G.induce {x | x ≠ r}) 3 := by
  classical
  apply connectivity_after_delete order
  intro D small hr
  have neighbor (x : Survives D) : ∃ y : Survives D, G.Adj x.val y.val := by
    by_contra! none
    have sub : G.neighborFinset x.val ⊆ D := by
      intro v hv
      by_contra out
      exact none ⟨v,out⟩ ((G.mem_neighborFinset _ _).mp hv)
    have lo := degree_of_small_deletion_preconnected (G := G) (by omega : 4 ≤ Fintype.card V)
      (fun K hK => (conn.2 K hK).preconnected) x.val
    have hi := Finset.card_le_card sub
    rw [G.card_neighborFinset_eq_degree] at hi
    have eq := Finset.eq_of_subset_of_card_le sub (by rw [G.card_neighborFinset_eq_degree]; omega)
    have hr' : r ∈ G.neighborFinset x.val := eq.symm ▸ hr
    exact safe _ ((G.mem_neighborFinset _ _).mp hr').symm (by omega)
  intro x y
  obtain ⟨v,xv⟩ := neighbor x
  obtain ⟨w,yw⟩ := neighbor y
  exact edgeReach_iff_crossing_between_surviving_edges.mpr cross D small x v y w xv yw

/-- In a minimum nontraceable graph, a neighbor of a safely deleted
vertex has two distinct neighbors outside its closed neighborhood. -/
theorem two_private_neighbors_of_safe_delete (smaller : SmallerAtThree.{u} (Fintype.card V))
    (conn : ConnectivityAtLeast G 3) (order : 5 ≤ Fintype.card V)
    (cross : CrossingBetweenSurvivingEdges G) (budget : treeNumber G ≤ 5) (no : ¬ Traceable G)
    {r s : V} (safe : ∀ v, G.Adj r v → G.degree v ≠ 3) (rs : G.Adj r s) :
    ∃ x y : V, x ≠ y ∧ x ≠ r ∧ y ≠ r ∧ G.Adj s x ∧ G.Adj s y ∧ ¬ G.Adj r x ∧ ¬ G.Adj r y := by
  classical
  have sz := order_after_delete r
  have tr := smaller {z : V // z ≠ r} (G.induce {x | x ≠ r}) (by omega)
    (connectivity_after_safe_delete conn order cross safe) ((treeNumber_after_delete_le (G := G) r).trans budget)
  obtain ⟨p⟩ := pathOn_of_traceable_delete tr
  obtain ⟨i,hi⟩ := List.mem_iff_get.mp ((p.covers s).mpr rs.ne.symm)
  obtain ⟨⟨j,hj,sj,rj⟩,⟨k,hk,sk,rk⟩⟩ := path_flanks_of_nontraceable p no i (hi.symm ▸ rs)
  have jk : j ≠ k := fun e => by rw [e] at hj; omega
  exact ⟨_,_,(List.nodup_iff_injective_get.mp p.nodup).ne jk,(p.covers _).mp (List.get_mem ..),
    (p.covers _).mp (List.get_mem ..),hi ▸ sj,hi ▸ sk,rj,rk⟩

#print axioms connectivity_after_safe_delete
#print axioms two_private_neighbors_of_safe_delete
end Graffiti199Depleted.Catalogue.Incomplete
