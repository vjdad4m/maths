import ConeRoute
open private triple_of_card_bound from OppositeComplete
open private open_at from ConnectedAlphaTwo
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X A B : Set V} {z r a b : V}

/-- Independence number at most three for the cone gives a clique on at least
one side of an anticomplete pair; both sides individually have independence at most two. -/
private theorem cone_split (F : SingletonCut G X z r a b)
    (sub : A ∪ B ⊆ X) (on : ∀ v ∈ A ∪ B, G.Adj r v)
    (an : A.Nonempty) (dis : Disjoint A B) (apart : ∀ v ∈ A, ∀ w ∈ B, ¬ G.Adj v w) :
    (A.Pairwise G.Adj ∨ B.Pairwise G.Adj) ∧ Triple G B := by
  classical
  have cap (S T : Finset V) (ss : ∀ v ∈ S, v ∈ A) (ts : ∀ v ∈ T, v ∈ B)
      (s0 : ∀ u ∈ S, ∀ v ∈ S, ¬ G.Adj u v) (t0 : ∀ u ∈ T, ∀ v ∈ T, ¬ G.Adj u v) :
      S.card + T.card ≤ 3 := by
    have dd : Disjoint S T := Finset.disjoint_left.mpr (by intro v h k; exact Set.disjoint_left.mp dis (ss _ h) (ts _ k))
    rw [← Finset.card_union_of_disjoint dd]
    apply F.cone_cap sub on (S ∪ T)
    · intro v h
      exact Or.inr ((Finset.mem_union.mp h).imp (ss _) (ts _))
    · intro u hu v hv
      rcases Finset.mem_union.mp hu with us|ut <;> rcases Finset.mem_union.mp hv with vs|vt
      · exact s0 _ us _ vs
      · exact apart _ (ss _ us) _ (ts _ vt)
      · exact fun e => apart _ (ss _ vs) _ (ts _ ut) e.symm
      · exact t0 _ ut _ vt
  constructor
  · by_cases cl : A.Pairwise G.Adj
    · exact Or.inl cl
    right
    by_contra nc
    change ¬ ∀ i ∈ A, ∀ j ∈ A, i ≠ j → G.Adj i j at cl
    change ¬ ∀ i ∈ B, ∀ j ∈ B, i ≠ j → G.Adj i j at nc
    push_neg at cl nc
    obtain ⟨i,hi,j,hj,ij,ee⟩ := cl
    obtain ⟨k,hk,l,hl,kl,ff⟩ := nc
    have pair (U : Set V) {i j : V} (ih : i ∈ U) (jh : j ∈ U) (e : ¬ G.Adj i j) :
        (∀ v ∈ ({i,j} : Finset V), v ∈ U) ∧
        (∀ u ∈ ({i,j} : Finset V), ∀ v ∈ ({i,j} : Finset V), ¬ G.Adj u v) := by
      constructor
      · intro v hv; rcases (show v = i ∨ v = j by simpa using hv) with rfl|rfl <;> assumption
      · intro u hu v hv
        rcases (show u = i ∨ u = j by simpa using hu) with rfl|rfl <;>
          rcases (show v = _ ∨ v = _ by simpa only [Finset.mem_insert,Finset.mem_singleton] using hv) with rfl|rfl
        · exact G.loopless _
        · exact e
        · exact fun h => e h.symm
        · exact G.loopless _
    have c := cap {i,j} {k,l} (pair A hi hj ee).1 (pair B hk hl ff).1 (pair A hi hj ee).2 (pair B hk hl ff).2
    simp [ij,kl] at c
  · intro i hi j hj k hk ij ik jk
    apply triple_of_card_bound (Y := B) ?_ hi hj hk ij ik jk
    intro T ht stable
    obtain ⟨s,hs⟩ := an
    have c := cap {s} T (by simpa using hs) ht (by simp) stable
    simp only [Finset.card_singleton] at c
    omega

private theorem two_part_route (F : SingletonCut G X z r a b)
    (sub : A ∪ B ⊆ X) (on : ∀ v ∈ A ∪ B, G.Adj r v)
    (an : A.Nonempty) (dis : Disjoint A B) (apart : ∀ v ∈ A, ∀ w ∈ B, ¬ G.Adj v w)
    (cl : A.Pairwise G.Adj) (P : PathOn G B) (Q : PathOn G (insert r (A ∪ B))ᶜ)
    (close : G.Adj Q.last Q.first) : Traceable G := by
  classical
  let W := insert r (A ∪ B)
  have rX := F.offX r (by simp)
  have rA : r ∉ A := fun h => rX (sub (Or.inl h))
  have rB : r ∉ B := fun h => rX (sub (Or.inr h))
  have zA : z ∉ A := fun h => F.zX (sub (Or.inl h))
  have zr := (F.cut.2 r).mpr (by simp)
  obtain ⟨s0,hA⟩ := an
  have sr : s0 ∉ ({r} : Finset V) := fun h => rA ((Finset.mem_singleton.mp h) ▸ hA)
  have keep : z ∉ ({r} : Finset V) := by simpa using zr.ne
  obtain ⟨walk⟩ := (F.conn.2 {r} (by simp)).preconnected ⟨s0,sr⟩ ⟨z,keep⟩
  obtain ⟨i,im,j,jm,ij⟩ := crossingOnWalk (U := {v : Survives {r} | v.val ∈ A}) walk hA zA
  have edge : G.Adj i.val j.val := ij
  have jW : j.val ∈ Wᶜ := by
    rintro (eq|h|h)
    · exact j.property (by simp [eq])
    · exact jm h
    · exact apart _ im _ h edge
  obtain ⟨e,_,inA⟩ := Traverses.end_clique cl im
  obtain ⟨d,gadget⟩ := open_at Q (Or.inr close) jW
  have first := (Traverses.single r).join inA (Set.disjoint_singleton_left.mpr rA) (on e (Or.inl (by
    obtain ⟨p,h,_⟩ := inA; exact h ▸ (p.covers p.first).mp (List.head_mem p.nonempty))))
  have dr : Disjoint B (({r} : Set V) ∪ A) := Set.disjoint_union_right.mpr
    ⟨Set.disjoint_singleton_right.mpr rB,dis.symm⟩
  have start := (show Traverses G B P.first P.last from ⟨P,rfl,rfl⟩).join first dr (on _ (Or.inr P.last_mem)).symm
  have eq : B ∪ ({r} ∪ A) = W := by ext v; simp only [W,Set.mem_union,Set.mem_insert_iff,Set.mem_singleton_iff]; tauto
  have ws : Traverses G W P.first i.val := eq ▸ start
  obtain ⟨path,_,_⟩ := ws.join gadget disjoint_compl_right edge
  have all : W ∪ Wᶜ = Set.univ := Set.union_compl_self _
  exact traceable_iff_hamiltonian_walk.mpr (pathOn_univ_iff_hamiltonian_walk.mp ⟨all ▸ path⟩)

/-- Exactly two nonempty connected neighbor components can be spliced
even though compressing the whole missing part then leaves a two-cut. -/
theorem SingletonCut.traceable_of_two_neighbor_parts (F : SingletonCut G X z r a b)
    (sub : A ∪ B ⊆ X) (on : ∀ v ∈ A ∪ B, G.Adj r v)
    (ac : (G.induce A).Connected) (bc : (G.induce B).Connected)
    (dis : Disjoint A B) (apart : ∀ v ∈ A, ∀ w ∈ B, ¬ G.Adj v w)
    (Q : PathOn G (insert r (A ∪ B))ᶜ) (close : G.Adj Q.last Q.first) : Traceable G := by
  have an : A.Nonempty := by obtain ⟨u⟩ := ac.nonempty; exact ⟨_,u.property⟩
  have bn : B.Nonempty := by obtain ⟨u⟩ := bc.nonempty; exact ⟨_,u.property⟩
  obtain ⟨cases',tb⟩ := cone_split F sub on an dis apart
  rcases cases' with cl|cl
  · obtain ⟨P⟩ := pathOn_connected_of_no_independent_triple bc tb
    exact two_part_route F sub on an dis apart cl P Q close
  · revert Q
    rw [Set.union_comm A B] at sub on ⊢
    intro Q close
    have cross := fun v (hv : v ∈ B) w (hw : w ∈ A) e => apart w hw v hv (G.symm e)
    have ta := (cone_split F sub on bn dis.symm cross).2
    obtain ⟨P⟩ := pathOn_connected_of_no_independent_triple ac ta
    exact two_part_route F sub on bn dis.symm cross cl P Q close

#print axioms SingletonCut.traceable_of_two_neighbor_parts
end Graffiti199Depleted.Catalogue.Incomplete


