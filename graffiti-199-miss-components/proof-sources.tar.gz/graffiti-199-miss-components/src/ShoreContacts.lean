import ReserveCycle
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X H M : Set V} {z r a b : V}

def ThreeCliques.hits (C : ThreeCliques G H) (v : V) (i : Fin 3) : Prop :=
  ∃ t ∈ C.part i, G.Adj v t

/-- Every exterior port-neighbor touches a clique, since otherwise four
independent ordinary neighbors and the singleton would form five leaves. -/
theorem ThreeCliques.hits_of_neighbor (C : ThreeCliques G H) (F : SingletonCut G X z r a b)
    (sub : H ⊆ X) (on : ∀ v ∈ H, G.Adj r v) {u : V} (uX : u ∈ X) (uH : u ∉ H)
    (ru : G.Adj r u) : ∃ i, C.hits u i := by
  classical
  by_contra! no
  choose v hv using C.nonempty
  have mem (i : Fin 3) := (C.cover _).mpr ⟨i,hv i⟩
  have ij {i j : Fin 3} (h : i ≠ j) := C.separate i j h _ (hv i) _ (hv j)
  have off (i : Fin 3) : u ≠ v i := fun e => uH (e.symm ▸ mem i)
  have non (i : Fin 3) : ¬ G.Adj u (v i) := fun e => no i ⟨_,hv i,e⟩
  let U := insert u H
  let T : Finset V := {u,v 0,v 1,v 2}
  have A := ij (by decide : (0 : Fin 3) ≠ 1)
  have B := ij (by decide : (0 : Fin 3) ≠ 2)
  have D := ij (by decide : (1 : Fin 3) ≠ 2)
  have cap := F.cone_cap (H := U) (Set.insert_subset uX sub)
    (by rintro t (e|h); exact e.symm ▸ ru; exact on _ h) T (by
      intro t ht; right
      rcases (show t=u ∨ t=v 0 ∨ t=v 1 ∨ t=v 2 by simpa [T] using ht) with h|h|h|h
      · exact Or.inl h
      all_goals exact Or.inr (h.symm ▸ mem _)) (by
      intro t ht s hs
      simp only [T,Finset.mem_insert,Finset.mem_singleton] at ht hs
      rcases ht with rfl|rfl|rfl|rfl <;> rcases hs with rfl|rfl|rfl|rfl <;>
        first | exact G.loopless _ | exact non _ | exact A.2 | exact B.2 | exact D.2 |
          exact fun e => non _ e.symm | exact fun e => A.2 e.symm | exact fun e => B.2 e.symm |
          exact fun e => D.2 e.symm)
  simp [T,off,A.1,B.1,D.1] at cap

/-- Each clique has an ordinary contact in the reserved set. -/
theorem ThreeCliques.reserve_hits (C : ThreeCliques G (X \ M)) (F : SingletonCut G X z r a b)
    (sub : M ⊆ X) (nz : M.Nonempty) (i : Fin 3) : ∃ u ∈ M, C.hits u i := by
  obtain ⟨m,mm⟩ := nz
  obtain ⟨v,vi⟩ := C.nonempty i
  have vH := (C.cover v).mpr ⟨i,vi⟩
  have off : m ∉ C.part i := fun h => ((C.cover m).mpr ⟨i,h⟩).2 mm
  obtain ⟨p⟩ := F.connX.preconnected (⟨v,vH.1⟩ : X) ⟨m,sub mm⟩
  obtain ⟨s,si,t,ti,st⟩ := crossingOnWalk (U := {k : X | k.val ∈ C.part i}) p vi off
  have tm : t.val ∈ M := by
    by_contra h
    obtain ⟨j,tj⟩ := (C.cover _).mp ⟨t.property,h⟩
    by_cases same : i = j
    · exact ti (same ▸ tj)
    · exact (C.separate i j same _ si _ tj).2 st
  exact ⟨t.val,tm,s.val,si,st.symm⟩

end Graffiti199Depleted.Catalogue.Incomplete
