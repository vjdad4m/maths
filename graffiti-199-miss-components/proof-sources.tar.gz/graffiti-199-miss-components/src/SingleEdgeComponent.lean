import SplitContact
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
universe u
variable {V : Type u} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {X : Set V} {z r a b : V} {i j : RootComponent G X r}

theorem SingletonCut.split_other_uniform (F : SingletonCut G X z r a b) (ij : i ≠ j)
    (cut : SplitMissEdge G X r a b i) : UniformMissPart G X r j := by
  classical
  by_contra bad
  obtain ⟨p,pj,bp⟩ := F.bad_witness bad
  have skip : p ∉ rootedBlockContacts G X r i := fun pi => bp (F.shared_contact_good ij.symm pj pi)
  obtain ⟨s,si,t,ti,st,_,ta,_,sa,_⟩ := cut
  have cl := (F.split_exclusive_contact ij si ti st ta.symm (fun e => sa e.symm) pj skip).2.1
  exact bp ⟨fun _ x _ y ne => cl (Or.inr x) (Or.inr y) ne,fun v vj =>
    cl (Or.inl rfl) (Or.inr vj) (fun e => (noncontactComponent_subset j vj).2 (e ▸ pj.2.1))⟩

theorem SingletonCut.split_excludes_other_cubic_contact (F : SingletonCut G X z r a b) (ij : i ≠ j)
    (cut : SplitMissEdge G X r a b i) (hub : CubicContactPair G X r j) : False := by
  obtain ⟨p,pj,u,uj,v,vj,_,only⟩ := hub
  have skip : p ∉ rootedBlockContacts G X r i := by
    rintro ⟨_,_,w,wi,pw⟩
    rcases (only w).mp pw with e|e|e
    · exact F.offX r (by simp) (e ▸ (noncontactComponent_subset i wi).1)
    · exact missPart_different ij wi uj e
    · exact missPart_different ij wi vj e
  obtain ⟨s,si,t,ti,st,_,ta,_,sa,_⟩ := cut
  have ap := (F.split_exclusive_contact ij si ti st ta.symm (fun e => sa e.symm) pj skip).2.2 p (Or.inl rfl)
  rcases (only a).mp ap.symm with e|e|e
  · exact F.ra e.symm
  · exact F.offX a (by simp) (e.symm ▸ (noncontactComponent_subset j uj).1)
  · exact F.offX a (by simp) (e.symm ▸ (noncontactComponent_subset j vj).1)

/-- At an arbitrary port at most one component of the missed ordinary
vertices has more than one vertex. -/
theorem SingletonCut.nonsingleton_unique (F : SingletonCut G X z r a b)
    (smaller : SmallerAtThree.{u} (Fintype.card V)) (order : 5 ≤ Fintype.card V)
    (cross : CrossingBetweenSurvivingEdges G) (no : ¬ Traceable G)
    (ind : ∀ u v, G.degree u = 3 → G.degree v = 3 → ¬ G.Adj u v)
    (li : 2 ≤ Nat.card (MissPart G X r i)) (lj : 2 ≤ Nat.card (MissPart G X r j)) : i = j := by
  classical
  by_contra ne
  have cls {v : RootComponent G X r} (h : 2 ≤ Nat.card (MissPart G X r v)) :
      SplitMissEdge G X r a b v ∨ (¬ UniformMissPart G X r v ∨ CubicContactPair G X r v) := by
    by_cases g : UniformMissPart G X r v
    · exact (F.uniform_edge_types smaller order cross no ind g h).imp_right Or.inr
    · exact Or.inr (Or.inl g)
  rcases cls li with s|h <;> rcases cls lj with t|k
  · exact ne (F.split_edge_unique s t)
  · exact k.elim (fun b => b (F.split_other_uniform ne s)) (F.split_excludes_other_cubic_contact ne s)
  · exact h.elim (fun b => b (F.split_other_uniform (Ne.symm ne) t)) (F.split_excludes_other_cubic_contact (Ne.symm ne) t)
  · exact ne (F.exception_or_cubic_unique h k)

#print axioms SingletonCut.nonsingleton_unique
end Graffiti199Depleted.Catalogue.Incomplete
