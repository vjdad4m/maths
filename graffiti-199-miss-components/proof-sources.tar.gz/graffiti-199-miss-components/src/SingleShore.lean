import ComponentBudget

open private triple_of_card_bound from OppositeComplete

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X : Set V} {r a b : V}

/-- Data on one component of a three-cut. The complement of the component
may contain any number of other components. -/
structure OneShore (G : SimpleGraph V) [Fintype V] [DecidableEq V] (X : Set V) (r a b : V) : Prop where
  conn : ConnectivityAtLeast G 3
  ra : r ≠ a
  rb : r ≠ b
  ab : a ≠ b
  offX : ∀ w ∈ ({r,a,b} : Finset V), w ∉ X
  boundX : ShoreBoundary G {r,a,b} X
  connX : (G.induce X).Connected

theorem OneShore.contact (F : OneShore G X r a b) {s : V} (hs : s ∈ ({r,a,b} : Finset V)) :
    ∃ x ∈ X, G.Adj s x := by
  obtain ⟨x⟩ := F.connX.nonempty
  exact contact_of_shore F.conn (by simp [F.ra,F.rb,F.ab]) F.offX F.boundX ⟨x.val,x.property⟩ hs

theorem PrivatePair.wide_in_single_shore (H : PrivatePair G X r) (F : OneShore G X r a b)
    (none : NoRootedFour G X a) (i : (G.induce (Noncontacts G X r)).ConnectedComponent)
    (ic : i ≠ H.c) (id' : i ≠ H.d) :
    ∃ x ∈ rootedBlockContacts G X r i, ∃ y ∈ rootedBlockContacts G X r i, x ≠ y := by
  classical
  obtain ⟨p,hp⟩ := rootedBlockContacts_nonempty F.connX ⟨H.p,H.pc.1,H.pc.2.1⟩ i
  by_contra missing
  have one (z : V) (hz : z ∈ rootedBlockContacts G X r i) : z = p :=
    Classical.byContradiction fun ne => missing ⟨z,hz,p,hp,ne⟩
  obtain ⟨⟨u,uc,au⟩,_⟩ := ports_meet_private_component F.conn F.boundX F.offX H.c H.pc H.oneC
  obtain ⟨⟨v,vd,av⟩,_⟩ := ports_meet_private_component F.conn F.boundX F.offX H.d H.qd H.oneD
  obtain ⟨⟨w,wi,aw⟩,_⟩ := ports_meet_private_component F.conn F.boundX F.offX i hp one
  have de {C E : (G.induce (Noncontacts G X r)).ConnectedComponent} (diff : C ≠ E)
      {s t : V} (h : s ∈ noncontactComponent G X r C) (m : t ∈ noncontactComponent G X r E) :
      s ≠ t := fun eq => Set.disjoint_left.mp (noncontactComponents_apart diff) h (eq.symm ▸ m)
  have e := triple_of_card_bound (Y := shoreContacts G X a) (fun T hT ind =>
    none.card_independent_contacts_le_two T hT ind)
    ⟨(noncontactComponent_subset H.c uc).1,au⟩ ⟨(noncontactComponent_subset H.d vd).1,av⟩
    ⟨(noncontactComponent_subset i wi).1,aw⟩ (de H.different uc vd)
    (de ic.symm uc wi) (de id'.symm vd wi)
  exact e.elim (noncontactComponents_anticomplete H.different uc vd)
    (fun h => h.elim (noncontactComponents_anticomplete ic.symm uc wi)
      (noncontactComponents_anticomplete id'.symm vd wi))


theorem OneShore.augmented_terminal_of_structure (F : OneShore G X r a b)
    (none : NoRootedFour G X r)
    (wideRest : ∀ H : PrivatePair G X r, ∀ i, i ≠ H.c → i ≠ H.d →
      ∃ x ∈ rootedBlockContacts G X r i, ∃ y ∈ rootedBlockContacts G X r i, x ≠ y) :
    ∃ z ∈ X, G.Adj a z ∧ ∃ t, Traverses G (insert r X) z t := by
  classical
  let I := (G.induce (Noncontacts G X r)).ConnectedComponent
  let Q (i : I) := rootedBlockContacts G X r i
  let priv (i : I) := ∃ p ∈ Q i, ∀ s ∈ Q i, s = p
  let wide (i : I) := ∃ x ∈ Q i, ∃ y ∈ Q i, x ≠ y
  have off := F.offX r (by simp)
  obtain ⟨v,vX,rv⟩ := F.contact (by simp : r ∈ ({r,a,b} : Finset V))
  have nonempty (i : I) : (Q i).Nonempty := rootedBlockContacts_nonempty F.connX ⟨v,vX,rv⟩ i
  have either (i : I) (notSmall : ¬ priv i) : wide i := by
    obtain ⟨p,hp⟩ := nonempty i
    by_contra notWide
    exact notSmall ⟨p,hp,fun s hs => Classical.byContradiction fun ne => notWide ⟨s,hs,p,hp,ne⟩⟩
  by_cases any : ∃ i, priv i
  · obtain ⟨c,p,pc,oneC⟩ := any
    obtain ⟨⟨z,zc,az⟩,_⟩ := ports_meet_private_component F.conn F.boundX F.offX c pc oneC
    refine ⟨z,(noncontactComponent_subset c zc).1,az,?_⟩
    by_cases another : ∃ d, d ≠ c ∧ priv d
    · obtain ⟨d,dc,q,qd,oneD⟩ := another
      let H : PrivatePair G X r := ⟨c,d,dc.symm,p,q,pc,qd,oneC,oneD⟩
      obtain ⟨w,hw⟩ := d.nonempty_supp
      exact ⟨w.val,start_double_private H none off (wideRest H) zc ⟨w,hw,rfl⟩⟩
    · exact start_single_private none off c pc oneC (fun i ic => either i (fun h => another ⟨i,ic,h⟩)) zc
  · obtain ⟨z,zx,az⟩ := F.contact (by simp : a ∈ ({r,a,b} : Finset V))
    exact ⟨z,zx,az,route_from_any_of_wide_shore none off (fun i => either i (fun h => any ⟨i,h⟩)) zx⟩


theorem OneShore.terminal (F : OneShore G X r a b)
    (nr : NoRootedFour G X r) (na : NoRootedFour G X a) :
    ∃ z ∈ X, G.Adj a z ∧ ∃ t, Traverses G (insert r X) z t :=
  F.augmented_terminal_of_structure nr (fun H => H.wide_in_single_shore F na)

#print axioms OneShore.terminal
end Graffiti199Depleted.Catalogue.Incomplete
