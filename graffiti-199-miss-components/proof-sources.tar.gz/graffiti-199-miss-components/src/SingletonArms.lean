import WideMiddle

open private six_le_treeNumber_of_five_independent_neighbors from CubicEdgeCuts
open private tip exit_edge from PrivateTips

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} {X : Set V} {z r a b : V}

structure SingletonCut (G : SimpleGraph V) [Fintype V] [DecidableEq V] (X : Set V) (z r a b : V)
    : Prop extends OneShore G X r a b where
  budget : treeNumber G ≤ 5
  zX : z ∉ X
  cut : CutSingleton G {r,a,b} z
  cover : ∀ v, v ∈ X ∨ v = z ∨ v = r ∨ v = a ∨ v = b

structure Arm (G : SimpleGraph V) (X : Set V) (r : V) where
  i : RootComponent G X r
  p : V
  hit : p ∈ rootedBlockContacts G X r i
  one : ∀ s ∈ rootedBlockContacts G X r i, s = p

abbrev Arm.block (A : Arm G X r) : Set V := RootBlock G X r A.i

theorem Arm.block_eq (A : Arm G X r) : A.block = insert A.p (noncontactComponent G X r A.i) := by
  ext v
  exact ⟨fun h => h.elim (fun h => Or.inl (A.one _ h)) Or.inr,fun h =>
    h.elim (fun eq => Or.inl (eq.symm ▸ A.hit)) Or.inr⟩

theorem Arm.sub (A : Arm G X r) : A.block ⊆ X :=
  fun _ h => h.elim (fun q => q.1) (fun c => (noncontactComponent_subset A.i c).1)

theorem Arm.apart (nr : NoRootedFour G X r) (off : r ∉ X) {A B : Arm G X r} (diff : A.i ≠ B.i) :
    Disjoint A.block B.block := by
  apply Set.disjoint_left.mpr
  rintro v (q|c) (t|d)
  · exact Set.disjoint_left.mp (nr.blockContacts_disjoint off diff) q t
  · exact (noncontactComponent_subset B.i d).2 q.2.1
  · exact (noncontactComponent_subset A.i c).2 t.2.1
  · exact Set.disjoint_left.mp (noncontactComponents_apart diff) c d

theorem Arm.join_middle (A : Arm G X r) (nr : NoRootedFour G X r) (off : r ∉ X) {v : V}
    (hv : v ∈ insert r (shoreContacts G X r)) (out : v ∉ A.block) : G.Adj A.p v := by
  apply exit_edge nr off A.hit A.one
  rcases hv with eq|hv
  · exact Or.inl eq
  · exact Or.inr ⟨hv,fun e => out (Or.inl (e.symm ▸ A.hit))⟩

variable [Fintype V]

theorem Arm.path (A : Arm G X r) (nr : NoRootedFour G X r) (off : r ∉ X) {s : V}
    (h : s ∈ noncontactComponent G X r A.i) : Traverses G A.block s A.p := by
  rw [A.block_eq]
  exact tip nr off A.hit h

variable [DecidableEq V]

theorem SingletonCut.no_four_arms (F : SingletonCut G X z r a b) (A : Fin 4 → Arm G X r)
    (idx : Function.Injective (fun i => (A i).i)) : False := by
  classical
  have some (i : Fin 4) : ∃ w ∈ noncontactComponent G X r (A i).i, G.Adj a w :=
    (ports_meet_private_component F.conn F.boundX F.offX (A i).i (A i).hit (A i).one).1
  choose w mem hit using some
  have intoX (i : Fin 4) : w i ∈ X := (noncontactComponent_subset (A i).i (mem i)).1
  let e : Fin 4 ↪ V := ⟨w,fun {i j} ew => Classical.byContradiction (fun ne =>
    Set.disjoint_left.mp (noncontactComponents_apart (idx.ne ne)) (mem i) (ew.symm ▸ mem j))⟩
  let T := Finset.univ.map e
  have zOut : z ∉ T := by
    intro h
    obtain ⟨i,_,eq⟩ := Finset.mem_map.mp h
    exact F.zX ((show w i = z from eq) ▸ intoX i)
  have count : (insert z T).card = 5 := by
    rw [Finset.card_insert_of_not_mem zOut]
    simp [T]
  have on (v : V) (h : v ∈ insert z T) : G.Adj a v := by
    rcases Finset.mem_insert.mp h with eq|h
    · exact eq.symm ▸ ((F.cut.2 a).mpr (by simp)).symm
    · obtain ⟨i,_,rfl⟩ := Finset.mem_map.mp h
      exact hit i
  have anti {i : Fin 4} : ¬ G.Adj z (e i) := fun h =>
    F.offX _ ((F.cut.2 _).mp h) (intoX i)
  have independent (v : V) (hv : v ∈ insert z T) (u : V) (hu : u ∈ insert z T) : ¬ G.Adj v u := by
    rcases Finset.mem_insert.mp hv with e₁|hv <;> rcases Finset.mem_insert.mp hu with e₂|hu
    · rw [e₁,e₂]; exact G.loopless _
    · obtain ⟨i,_,h⟩ := Finset.mem_map.mp hu
      simpa only [e₁,← h] using (anti (i := i))
    · obtain ⟨i,_,h⟩ := Finset.mem_map.mp hv
      exact fun edge => anti (i := i) (show G.Adj z (e i) by simpa only [e₂,h] using edge.symm)
    · obtain ⟨i,_,rfl⟩ := Finset.mem_map.mp hv
      obtain ⟨j,_,rfl⟩ := Finset.mem_map.mp hu
      by_cases eq : i = j
      · subst j; exact G.loopless _
      · exact noncontactComponents_anticomplete (idx.ne eq) (mem i) (mem j)
  have six := six_le_treeNumber_of_five_independent_neighbors (insert z T) a count.ge on independent
  exact (Nat.not_succ_le_self 5) (six.trans F.budget)

theorem SingletonCut.from_augmented_path (F : SingletonCut G X z r a b) {s t : V}
    (az : G.Adj a s) (P : Traverses G (insert r X) s t) : Traceable G := by
  have zcut := F.cut.1
  have zr : z ≠ r := fun eq => zcut (by simp [eq])
  have za : z ≠ a := fun eq => zcut (by simp [eq])
  have zb : z ≠ b := fun eq => zcut (by simp [eq])
  have aX := F.offX a (by simp)
  have bX := F.offX b (by simp)
  have d₁ : Disjoint (insert r X) ({a} : Set V) := by simp [F.ra.symm,aX]
  have d₂ : Disjoint (insert r X ∪ {a}) ({z} : Set V) := by simp [Set.disjoint_union_left,F.zX,zr,za]
  have d₃ : Disjoint ((insert r X ∪ {a}) ∪ {z}) ({b} : Set V) := by
    simp [Set.disjoint_union_left,F.rb.symm,F.ab.symm,zb.symm,bX]
  obtain ⟨p,_,_⟩ := ((P.reverse.join (Traverses.single a) d₁ az.symm).join (Traverses.single z) d₂
    ((F.cut.2 a).mpr (by simp)).symm).join (Traverses.single b) d₃ ((F.cut.2 b).mpr (by simp))
  have full : (((insert r X ∪ {a}) ∪ {z}) ∪ {b}) = Set.univ := by
    apply Set.eq_univ_iff_forall.mpr
    intro v
    simp only [Set.mem_union,Set.mem_insert_iff,Set.mem_singleton_iff]
    have := F.cover v
    tauto
  exact traceable_iff_hamiltonian_walk.mpr (pathOn_univ_iff_hamiltonian_walk.mp ⟨full ▸ p⟩)

#print axioms SingletonCut.no_four_arms
end Graffiti199Depleted.Catalogue.Incomplete

