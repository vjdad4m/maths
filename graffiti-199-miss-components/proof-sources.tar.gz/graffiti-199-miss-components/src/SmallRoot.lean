import TripleArmSplice
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X : Set V} {z r a b : V}

private theorem arm_of_not_wide (F : SingletonCut G X z r a b) (i : RootComponent G X r)
    (nw : ¬ Wide G X r i) : ∃ A : Arm G X r, A.i = i := by
  obtain ⟨v,vx,rv⟩ := F.toOneShore.contact (by simp : r ∈ ({r,a,b} : Finset V))
  obtain ⟨p,hp⟩ := rootedBlockContacts_nonempty F.connX ⟨v,vx,rv⟩ i
  exact ⟨⟨i,p,hp,fun s hs => Classical.byContradiction fun ne => nw ⟨s,hs,p,hp,ne⟩⟩,rfl⟩

/-- A single distinguished port with no induced four-vertex tree supported
otherwise inside the ordinary shore suffices to route a singleton cut. -/
theorem SingletonCut.traceable_of_small_root (F : SingletonCut G X z r a b)
    (nr : NoRootedFour G X r) : Traceable G := by
  classical
  by_cases wideRest : ∀ H : PrivatePair G X r, ∀ i : RootComponent G X r,
      i ≠ H.c → i ≠ H.d → Wide G X r i
  · obtain ⟨_,_,as',_,R⟩ := F.toOneShore.augmented_terminal_of_structure nr wideRest
    exact F.from_augmented_path as' R
  push_neg at wideRest
  obtain ⟨H,i,ic,id',nw⟩ := wideRest
  obtain ⟨C,hC⟩ := arm_of_not_wide F i nw
  let A : Arm G X r := ⟨H.c,H.p,H.pc,H.oneC⟩
  let B : Arm G X r := ⟨H.d,H.q,H.qd,H.oneD⟩
  have ab : A.i ≠ B.i := H.different
  have ac : A.i ≠ C.i := hC.symm ▸ ic.symm
  have bc : B.i ≠ C.i := hC.symm ▸ id'.symm
  apply F.three_arm_splice nr A B C ab ac bc
  intro j ja jb jc
  by_contra nw
  obtain ⟨J,hJ⟩ := arm_of_not_wide F j nw
  have aj : A.i ≠ J.i := hJ.symm ▸ ja.symm
  have bj : B.i ≠ J.i := hJ.symm ▸ jb.symm
  have cj : C.i ≠ J.i := hJ.symm ▸ jc.symm
  let f : Fin 4 → Arm G X r := ![A,B,C,J]
  apply F.no_four_arms f
  intro i j hi
  fin_cases i <;> fin_cases j <;>
    first | rfl | exact False.elim (ab hi) | exact False.elim (ab hi.symm) |
      exact False.elim (ac hi) | exact False.elim (ac hi.symm) | exact False.elim (bc hi) |
      exact False.elim (bc hi.symm) | exact False.elim (aj hi) | exact False.elim (aj hi.symm) |
      exact False.elim (bj hi) | exact False.elim (bj hi.symm) | exact False.elim (cj hi) |
      exact False.elim (cj hi.symm)

#print axioms SingletonCut.traceable_of_small_root
end Graffiti199Depleted.Catalogue.Incomplete
