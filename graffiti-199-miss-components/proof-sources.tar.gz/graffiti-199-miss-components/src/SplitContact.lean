import RootedPathFour
import MissComponentCount
open private NoRootedFour.forbids_four from RootedBlocks
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} {E U : Set V} {a z p : V}

private theorem connected_insert_contact (conn : (G.induce U).Connected)
    (hit : ∃ u ∈ U, G.Adj p u) : (G.induce (insert p U)).Connected := by
  obtain ⟨u,uu,pu⟩ := hit
  let H := G.induce (insert p U)
  let P : (insert p U : Set V) := ⟨p,Or.inl rfl⟩
  let inc : G.induce U →g H := ⟨fun x => ⟨x.val,Or.inr x.property⟩,fun e => e⟩
  apply (connected_iff_exists_forall_reachable _).mpr
  refine ⟨P,?_⟩
  intro v
  rcases v.property with e|vU
  · exact (show P = v from Subtype.ext e.symm) ▸ Reachable.refl P
  · exact (show H.Adj P (inc ⟨u,uu⟩) from pu).reachable.trans ((conn.preconnected ⟨u,uu⟩ ⟨v.val,vU⟩).map inc)

private theorem uniform_with_remote_leaf (none : NoRootedFour G E a)
    (conn : (G.induce U).Connected) (sub : U ⊆ E) (ze : z ∈ E) (az : G.Adj a z)
    (aOff : a ∉ U) (zOff : z ∉ U) (anti : ∀ v ∈ U, ¬ G.Adj z v)
    (hit : ∃ v ∈ U, G.Adj a v) : GoodAt G U a := by
  classical
  have da {v : V} (vU : v ∈ U) : a ≠ v := fun e => aOff (e.symm ▸ vU)
  have dz {v : V} (vU : v ∈ U) : z ≠ v := fun e => zOff (e.symm ▸ vU)
  have all (v : V) (vU : v ∈ U) : G.Adj a v := by
    by_contra av
    obtain ⟨x,xU,y,yU,ax,xy,ay⟩ := two_step_into_shore conn.preconnected hit ⟨v,vU,av⟩
    exact NoRootedFour.forbids_four none ze (sub xU) (sub yU) (by simp [az.ne,da xU,da yU,dz xU,dz yU,xy.ne]) az
      (Or.inl ⟨ax.symm,fun e => anti x xU e.symm⟩)
      (Or.inr (Or.inr ⟨xy.symm,fun e => ay e.symm,fun e => anti y yU e.symm⟩))
  refine ⟨?_,all⟩
  intro x xU y yU xy
  by_contra miss
  exact NoRootedFour.forbids_four none ze (sub xU) (sub yU) (by simp [az.ne,da xU,da yU,dz xU,dz yU,xy]) az
    (Or.inl ⟨(all x xU).symm,fun e => anti x xU e.symm⟩)
    (Or.inl ⟨(all y yU).symm,fun e => anti y yU e.symm,fun e => miss e.symm⟩)

variable [Fintype V] [DecidableEq V] {X : Set V} {r b s t : V} {i j : RootComponent G X r}

/-- A split edge in one part and a contact of a different part that avoids
the split part force a full clique consisting of that contact and its part.
The outer port meets the whole clique and the distinguished port. -/
theorem SingletonCut.split_exclusive_contact (F : SingletonCut G X z r a b)
    (ij : i ≠ j) (si : s ∈ MissPart G X r i) (ti : t ∈ MissPart G X r i)
    (st : G.Adj s t) (at' : G.Adj a t) (as' : ¬ G.Adj a s)
    (pj : p ∈ rootedBlockContacts G X r j) (skip : p ∉ rootedBlockContacts G X r i) :
    G.Adj a r ∧ GoodAt G (insert p (MissPart G X r j)) a := by
  classical
  let E := AwayFromEdge G s t
  have sm := noncontactComponent_subset i si
  have tm := noncontactComponent_subset i ti
  have offX {v : V} (vX : v ∈ X) : z ≠ v ∧ r ≠ v ∧ a ≠ v := by
    exact ⟨fun e => F.zX (e.symm ▸ vX),fun e => F.offX r (by simp) (e.symm ▸ vX),
      fun e => F.offX a (by simp) (e.symm ▸ vX)⟩
  have zOff {v : V} (vX : v ∈ X) : ¬ G.Adj z v := fun e => F.offX _ ((F.cut.2 v).mp e) vX
  have df {v : V} (vi : v ∈ MissPart G X r i) : p ≠ v := fun e => (noncontactComponent_subset i vi).2 (e ▸ pj.2.1)
  have av {v : V} (vi : v ∈ MissPart G X r i) : ¬ G.Adj p v := fun e => skip ⟨pj.1,pj.2.1,v,vi,e⟩
  have pe : p ∈ E := ⟨df si,df ti,av si,av ti⟩
  have ze : z ∈ E := ⟨(offX sm.1).1,(offX tm.1).1,zOff sm.1,zOff tm.1⟩
  have re : r ∈ E := ⟨(offX sm.1).2.1,(offX tm.1).2.1,sm.2,tm.2⟩
  have je {v : V} (vj : v ∈ MissPart G X r j) : v ∈ E :=
    ⟨missPart_different ij.symm vj si,missPart_different ij.symm vj ti,
      noncontactComponents_anticomplete ij.symm vj si,noncontactComponents_anticomplete ij.symm vj ti⟩
  obtain ⟨u,uj,pu⟩ := pj.2.2
  have um := noncontactComponent_subset j uj
  have none := no_four_away_from_edge F.budget st at' as' (offX sm.1).2.2
  have zr := (F.cut.2 r).mpr (by simp)
  have za := (F.cut.2 a).mpr (by simp)
  have path := complete_on_induced_path_of_end none ze re pe (je uj)
    (by simp [za.ne.symm,F.ra.symm,(offX pj.1).2.2,(offX um.1).2.2,zr.ne,(offX pj.1).1,
      (offX um.1).1,pj.2.1.ne,(offX um.1).2.1,pu.ne]) za.symm zr pj.2.1 pu (zOff pj.1) (zOff um.1) um.2
  have whole {v : V} (h : v ∈ insert p (MissPart G X r j)) : v ∈ X := by
    rcases h with e|h
    · exact e.symm ▸ pj.1
    · exact (noncontactComponent_subset j h).1
  refine ⟨path.1,uniform_with_remote_leaf none (connected_insert_contact (missPart_connected j) ⟨u,uj,pu⟩)
    (fun v h => h.elim (fun e => e.symm ▸ pe) je) ze za.symm
    (fun h => F.offX a (by simp) (whole h)) (fun h => F.zX (whole h))
    (fun _ h => zOff (whole h)) ⟨p,Or.inl rfl,path.2.1⟩⟩

#print axioms SingletonCut.split_exclusive_contact
end Graffiti199Depleted.Catalogue.Incomplete
