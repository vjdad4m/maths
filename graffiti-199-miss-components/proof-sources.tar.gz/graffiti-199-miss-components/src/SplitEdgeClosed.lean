import SplitRoute
open private swap_others from TwoMissMatching
open private degree_le_two from SplitThirdMiss
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
universe u
variable {V : Type u} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {X : Set V} {z r a b : V} {i : RootComponent G X r}

/-- With at least three ordinary misses the uniform edge type carrying a
cubic member is impossible in the minimum-order branch. -/
theorem SingletonCut.no_uniform_split (F : SingletonCut G X z r a b)
    (smaller : SmallerAtThree.{u} (Fintype.card V)) (order : 5 ≤ Fintype.card V)
    (cross : CrossingBetweenSurvivingEdges G) (no : ¬ Traceable G)
    (ind : ∀ u v, G.degree u = 3 → G.degree v = 3 → ¬ G.Adj u v)
    (three : ∃ T : Finset V, T.card = 3 ∧ ∀ v ∈ T, v ∈ Noncontacts G X r)
    (good : UniformMissPart G X r i) : ¬ SplitMissEdge G X r a b i := by
  classical
  intro cut
  have unique := F.split_has_at_most_one_outside smaller order cross no ind good cut
  have cap := F.uniform_size_le_two smaller order cross no ind good
  let C := MissPart G X r i
  letI : Fintype C := Fintype.ofFinite C
  have cSize : C.toFinset.card ≤ 2 := by rwa [Set.toFinset_card,← Nat.card_eq_fintype_card]
  obtain ⟨s,si,t,ti,st,d,ta,tb,sa,sb⟩ := cut
  have subpair : ({s,t} : Finset V) ⊆ C.toFinset :=
    Finset.insert_subset (Set.mem_toFinset.mpr si) (Finset.singleton_subset_iff.mpr (Set.mem_toFinset.mpr ti))
  have eq := Finset.eq_of_subset_of_card_le subpair (by rwa [Finset.card_pair st.ne])
  obtain ⟨T,sz,allT⟩ := three
  obtain ⟨w,wt,wout⟩ := Finset.exists_mem_not_mem_of_card_lt_card (show C.toFinset.card < T.card by omega)
  have wm := allT w wt
  have wi : w ∉ MissPart G X r i := fun h => wout (Set.mem_toFinset.mpr h)
  have names (v : V) (vm : v ∈ Noncontacts G X r) : v=s ∨ v=t ∨ v=w := by
    by_cases vi : v ∈ MissPart G X r i
    · have h : v ∈ ({s,t} : Finset V) := eq.symm ▸ Set.mem_toFinset.mpr vi
      simpa using (show v=s ∨ v=t ∨ v=w from (show v=s ∨ v=t by simpa using h).imp_right Or.inl)
    · exact Or.inr (Or.inr (unique ⟨vm,vi⟩ ⟨wm,wi⟩))
  have port : G.Adj a w ∨ G.Adj b w := by
    by_contra! misses
    obtain ⟨p,_,q,_,_,only⟩ := F.split_two_contacts cross good si ti st d
    have hi := degree_le_two (G := G) (x := w) (c := p) (d := q) (by
      intro v wv
      rcases F.cover v with vX|vz|vr|va|vb
      · have rv : G.Adj r v := Classical.byContradiction fun m =>
          F.isolated_off_edge smaller order cross no ind (two_le_part_size si ti st.ne) wm wi ⟨vX,m⟩ wv
        by_cases inI : v ∈ rootedBlockContacts G X r i
        · exact only v inI
        · exact (misses.1 (F.outside_contact_hits_both si ti st ta tb sa sb wm wi vX rv wv.symm inI).1).elim
      · exact (F.offX w ((F.cut.2 w).mp (vz ▸ wv.symm)) wm.1).elim
      · exact (wm.2 (vr ▸ wv.symm)).elim
      · exact (misses.1 (va ▸ wv.symm)).elim
      · exact (misses.2 (vb ▸ wv.symm)).elim)
    have lo := degree_of_small_deletion_preconnected (G := G) (by omega : 4 ≤ Fintype.card V)
      (fun K hk => (F.conn.2 K hk).preconnected) w
    omega
  exact no (port.elim
    (fun aw => (swap_others F).route_split_and_isolate cross good si ti st wm wi names tb aw.symm)
    (fun bw => F.route_split_and_isolate cross good si ti st wm wi names ta bw.symm))

/-- Among components that are cliques with uniform ordinary attachments,
the sole possible nontrivial component is a pair with an ordinary cubic
common neighbor having exactly r and the pair as its neighbors. -/
theorem SingletonCut.uniform_nonsingleton_has_cubic_contact (F : SingletonCut G X z r a b)
    (smaller : SmallerAtThree.{u} (Fintype.card V)) (order : 5 ≤ Fintype.card V)
    (cross : CrossingBetweenSurvivingEdges G) (no : ¬ Traceable G)
    (ind : ∀ u v, G.degree u = 3 → G.degree v = 3 → ¬ G.Adj u v)
    (three : ∃ T : Finset V, T.card = 3 ∧ ∀ v ∈ T, v ∈ Noncontacts G X r)
    (good : UniformMissPart G X r i) (large : 2 ≤ Nat.card (MissPart G X r i)) :
    Nat.card (MissPart G X r i) = 2 ∧ CubicContactPair G X r i :=
  ⟨Nat.le_antisymm (F.uniform_size_le_two smaller order cross no ind good) large,
    (F.uniform_edge_types smaller order cross no ind good large).resolve_left
      (F.no_uniform_split smaller order cross no ind three good)⟩

#print axioms SingletonCut.no_uniform_split
#print axioms SingletonCut.uniform_nonsingleton_has_cubic_contact
end Graffiti199Depleted.Catalogue.Incomplete
