import SingleEdgeComponent
open private NoRootedFour.forbids_four from RootedBlocks
open private swap_others from TwoMissMatching
open private cubic_three_neighbors from MissEdgeTypes
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
universe u
variable {V : Type u} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {X : Set V} {z r a b s t p q : V} {i : RootComponent G X r}

omit [DecidableEq V] [DecidableRel G.Adj] in
theorem two_le_part_size {x y : V} (xi : x ∈ MissPart G X r i) (yi : y ∈ MissPart G X r i) (xy : x ≠ y) :
    2 ≤ Nat.card (MissPart G X r i) := by
  classical
  let C := MissPart G X r i
  letI : Fintype C := Fintype.ofFinite C
  rw [Nat.card_eq_fintype_card,← Set.toFinset_card]
  apply Finset.one_lt_card.mpr
  exact ⟨x,Set.mem_toFinset.mpr xi,y,Set.mem_toFinset.mpr yi,xy⟩

theorem SingletonCut.isolated_off_edge (F : SingletonCut G X z r a b)
    (smaller : SmallerAtThree.{u} (Fintype.card V)) (order : 5 ≤ Fintype.card V)
    (cross : CrossingBetweenSurvivingEdges G) (no : ¬ Traceable G)
    (ind : ∀ u v, G.degree u = 3 → G.degree v = 3 → ¬ G.Adj u v)
    (size : 2 ≤ Nat.card (MissPart G X r i)) {x y : V}
    (xm : x ∈ Noncontacts G X r) (off : x ∉ MissPart G X r i) (ym : y ∈ Noncontacts G X r) :
    ¬ G.Adj x y := by
  intro xy
  let j := (G.induce (Noncontacts G X r)).connectedComponentMk ⟨x,xm⟩
  have xj : x ∈ MissPart G X r j := ⟨⟨x,xm⟩,rfl,rfl⟩
  exact off ((F.nonsingleton_unique smaller order cross no ind size
    (two_le_part_size xj (missPart_closed_along_miss_edge xj ym xy) xy.ne)).symm ▸ xj)

/-- The cubic endpoint of a uniform split edge has precisely two ordinary
contacts besides its mate. They constitute the entire attachment set. -/
theorem SingletonCut.split_two_contacts (F : SingletonCut G X z r a b)
    (cross : CrossingBetweenSurvivingEdges G) (good : UniformMissPart G X r i)
    (si : s ∈ MissPart G X r i) (ti : t ∈ MissPart G X r i) (st : G.Adj s t)
    (ds : G.degree s = 3) :
    ∃ p ∈ rootedBlockContacts G X r i, ∃ q ∈ rootedBlockContacts G X r i, p ≠ q ∧
      ∀ v ∈ rootedBlockContacts G X r i, v = p ∨ v = q := by
  obtain ⟨p,pi,q,qi,pq⟩ := F.edge_part_wide cross si ti st
  have tm := noncontactComponent_subset i ti
  have tp : t ≠ p := fun e => tm.2 (e.symm ▸ pi.2.1)
  have tq : t ≠ q := fun e => tm.2 (e.symm ▸ qi.2.1)
  have only := cubic_three_neighbors ds tp tq pq st (good.2 p pi s si).symm (good.2 q qi s si).symm
  exact ⟨p,pi,q,qi,pq,fun v vi => ((only v).mp (good.2 v vi s si).symm).resolve_left
    (fun e => tm.2 (e ▸ vi.2.1))⟩

omit [DecidableRel G.Adj] in
theorem SingletonCut.outside_contact_hits_both (F : SingletonCut G X z r a b)
    (si : s ∈ MissPart G X r i) (ti : t ∈ MissPart G X r i) (st : G.Adj s t)
    (ta : G.Adj t a) (tb : G.Adj t b) (sa : ¬ G.Adj s a) (sb : ¬ G.Adj s b)
    {x v : V} (xm : x ∈ Noncontacts G X r) (off : x ∉ MissPart G X r i)
    (vX : v ∈ X) (rv : G.Adj r v) (vx : G.Adj v x) (skip : v ∉ rootedBlockContacts G X r i) :
    G.Adj a x ∧ G.Adj b x := by
  let j := (G.induce (Noncontacts G X r)).connectedComponentMk ⟨x,xm⟩
  have xj : x ∈ MissPart G X r j := ⟨⟨x,xm⟩,rfl,rfl⟩
  have ij : i ≠ j := fun e => off (e.symm ▸ xj)
  have vj : v ∈ rootedBlockContacts G X r j := ⟨vX,rv,x,xj,vx⟩
  exact ⟨(F.split_exclusive_contact ij si ti st ta.symm (fun e => sa e.symm) vj skip).2.2 x (Or.inr xj),
    ((swap_others F).split_exclusive_contact ij si ti st tb.symm (fun e => sb e.symm) vj skip).2.2 x (Or.inr xj)⟩

omit [DecidableRel G.Adj] in
theorem SingletonCut.outside_port_collision (F : SingletonCut G X z r a b)
    {x y : V} (si : s ∈ MissPart G X r i) (ti : t ∈ MissPart G X r i)
    (st : G.Adj s t) (ta : G.Adj t a) (sa : ¬ G.Adj s a)
    (xX : x ∈ X) (yX : y ∈ X) (xe : x ∈ AwayFromEdge G s t) (ye : y ∈ AwayFromEdge G s t)
    (dif : x ≠ y) (xy : ¬ G.Adj x y) (ax : G.Adj a x) (ay : G.Adj a y) : False := by
  have sm := (noncontactComponent_subset i si).1
  have tm := (noncontactComponent_subset i ti).1
  have dz {v : V} (vX : v ∈ X) : z ≠ v := fun e => F.zX (e.symm ▸ vX)
  have anti {v : V} (vX : v ∈ X) : ¬ G.Adj z v := fun e => F.offX _ ((F.cut.2 _).mp e) vX
  have ze : z ∈ AwayFromEdge G s t := ⟨dz sm,dz tm,anti sm,anti tm⟩
  have za := (F.cut.2 a).mpr (by simp)
  have none := no_four_away_from_edge F.budget st ta.symm (fun e => sa e.symm)
    (fun e => F.offX a (by simp) (e.symm ▸ sm))
  exact NoRootedFour.forbids_four none ze xe ye
    (by simp [za.ne.symm,ax.ne,ay.ne,dz xX,dz yX,dif]) za.symm
    (Or.inl ⟨ax.symm,fun e => anti xX e.symm⟩)
    (Or.inl ⟨ay.symm,fun e => anti yX e.symm,fun e => xy e.symm⟩)

#print axioms SingletonCut.isolated_off_edge
#print axioms SingletonCut.split_two_contacts
end Graffiti199Depleted.Catalogue.Incomplete
