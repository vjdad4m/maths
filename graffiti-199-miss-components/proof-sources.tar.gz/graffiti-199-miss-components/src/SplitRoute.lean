import TwinConnector
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X : Set V} {z r a b s t w : V} {i : RootComponent G X r}

/-- Reserve the pair followed by a shortest connector to the third miss.
Its first interior vertex consumes only one of the pair's two contacts. -/
theorem SingletonCut.route_split_and_isolate (F : SingletonCut G X z r a b)
    (cross : CrossingBetweenSurvivingEdges G) (good : UniformMissPart G X r i)
    (si : s ∈ MissPart G X r i) (ti : t ∈ MissPart G X r i) (st : G.Adj s t)
    (wm : w ∈ Noncontacts G X r) (wi : w ∉ MissPart G X r i)
    (all : ∀ v ∈ Noncontacts G X r, v = s ∨ v = t ∨ v = w)
    (ta : G.Adj t a) (wb : G.Adj w b) : Traceable G := by
  classical
  have sm := noncontactComponent_subset i si
  have tm := noncontactComponent_subset i ti
  have sw : s ≠ w := fun e => wi (e ▸ si)
  have tw : t ≠ w := fun e => wi (e ▸ ti)
  have sn : ¬ G.Adj s w := fun e => wi (missPart_closed_along_miss_edge si wm e)
  have tn : ¬ G.Adj t w := fun e => wi (missPart_closed_along_miss_edge ti wm e)
  have dom (v : V) (vX : v ∈ X) (vs : v ≠ s) (tv : G.Adj t v) : G.Adj s v := by
    by_contra miss
    rcases F.difference_in_ports good ti si vs tv miss with e|e
    · exact F.offX a (by simp) (e ▸ vX)
    · exact F.offX b (by simp) (e ▸ vX)
  obtain ⟨R⟩ := rightArm_avoids_dominated_neighbor F.connX sm.1 tm.1 wm.1 st sw sn tn dom
  let K := R.h :: R.tail
  let L := t :: s :: (K ++ [w])
  let M := {v : V | v ∈ L}
  have headMem : R.h ∈ K := List.mem_cons_self ..
  have hInfo := R.inside R.h headMem
  have rh : G.Adj r R.h := by
    by_contra m
    exact (all _ ⟨hInfo.1,m⟩).elim hInfo.2.1 (fun h => h.elim hInfo.2.2.1 hInfo.2.2.2)
  have spare : ∃ p ∈ rootedBlockContacts G X r i, p ≠ R.h := by
    obtain ⟨p,pi,q,qi,pq⟩ := F.edge_part_wide cross si ti st
    by_cases e : p = R.h
    · exact ⟨q,qi,e ▸ pq.symm⟩
    · exact ⟨p,pi,e⟩
  obtain ⟨p,pi,ph⟩ := spare
  have sp := (good.2 p pi s si).symm
  have pK : p ∉ K := fun e => ph (R.only p e sp)
  have pn {u : V} (um : u ∈ Noncontacts G X r) : p ≠ u := fun e => um.2 (e ▸ pi.2.1)
  have pM : p ∉ M := by simp [M,L,pn tm,pn sm,pn wm,pK]
  have tK : t ∉ K := fun m => (R.inside t m).2.2.1 rfl
  have sK : s ∉ K := fun m => (R.inside s m).2.1 rfl
  have wK : w ∉ K := fun m => (R.inside w m).2.2.2 rfl
  have nk : (K ++ [w]).Nodup := List.nodup_append.mpr ⟨R.nodup,by simp,by simpa using wK⟩
  have nd : L.Nodup := List.nodup_cons.mpr ⟨by simp [st.ne.symm,tK,tw],
    List.nodup_cons.mpr ⟨by simp [sK,sw],nk⟩⟩
  have ck : (K ++ [w]).Chain' G.Adj := R.chain.append (by simp) (by
    intro u hu v hv
    have eq : K.getLast (by simp [K]) = u := by
      change u ∈ K.getLast? at hu
      rw [List.getLast?_eq_getLast (by simp [K])] at hu
      exact Option.mem_some.mp hu
    have ve : v = w := by simpa using hv.symm
    exact eq ▸ ve.symm ▸ R.finish)
  have ch : L.Chain' G.Adj := by
    apply List.chain'_cons.mpr
    refine ⟨st.symm,?_⟩
    apply List.chain'_cons.mpr
    exact ⟨R.start,ck⟩
  let P : PathOn G M := ⟨L,by simp [L],ch,nd,fun _ => Iff.rfl⟩
  have members (v : V) : v ∈ M ↔ v=t ∨ v=s ∨ v ∈ K ∨ v=w := by simp [M,L]
  have sub (v : V) (h : v ∈ M) : v ∈ X := by
    rcases (members v).mp h with e|e|e|e
    · exact e.symm ▸ tm.1
    · exact e.symm ▸ sm.1
    · exact (R.inside _ e).1
    · exact e.symm ▸ wm.1
  have on (v : V) (h : v ∈ X \ M) : G.Adj r v := by
    apply Classical.byContradiction
    intro n
    refine h.2 ((members v).mpr ?_)
    rcases all v ⟨h.1,n⟩ with e|e|e <;> tauto
  have endEq : P.last = w := by simp [P,L,PathOn.last]
  exact F.traceable_of_reserved_edge sub on P ta.symm (endEq.symm ▸ wb)
    (A := [t]) (B := R.tail ++ [w]) rfl sm.2 ⟨p,⟨pi.1,pM⟩,sp⟩ (Or.inl rh)

#print axioms SingletonCut.route_split_and_isolate
end Graffiti199Depleted.Catalogue.Incomplete

