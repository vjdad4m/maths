import SplitPairNeighbors
open private NoRootedFour.forbids_four from RootedBlocks
open private swap_others from TwoMissMatching
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
universe u
variable {V : Type u} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {X : Set V} {z r a b : V} {i : RootComponent G X r}

private theorem degree_le_two {x c d : V} (only : ∀ w, G.Adj x w → w = c ∨ w = d) :
    G.degree x ≤ 2 := by
  have sub : G.neighborFinset x ⊆ ({c,d} : Finset V) := by
    intro w h
    simpa using only w ((G.mem_neighborFinset _ _).mp h)
  have size := Finset.card_le_card sub
  have hi := Finset.card_insert_le c ({d} : Finset V)
  simp only [Finset.card_singleton] at hi
  rw [G.card_neighborFinset_eq_degree] at size
  exact size.trans hi

/-- Apart from a uniform split edge there is at most one missed vertex. -/
theorem SingletonCut.split_has_at_most_one_outside (F : SingletonCut G X z r a b)
    (smaller : SmallerAtThree.{u} (Fintype.card V)) (order : 5 ≤ Fintype.card V)
    (cross : CrossingBetweenSurvivingEdges G) (no : ¬ Traceable G)
    (ind : ∀ u v, G.degree u = 3 → G.degree v = 3 → ¬ G.Adj u v)
    (good : UniformMissPart G X r i) (cut : SplitMissEdge G X r a b i) :
    (Noncontacts G X r \ MissPart G X r i).Subsingleton := by
  classical
  obtain ⟨s,si,t,ti,st,d,ta,tb,sa,sb⟩ := cut
  obtain ⟨p,pi,q,_,_,only⟩ := F.split_two_contacts cross good si ti st d
  have size := two_le_part_size si ti st.ne
  let O := Noncontacts G X r \ MissPart G X r i
  have iso {x v : V} (xo : x ∈ O) (vm : v ∈ Noncontacts G X r) :=
    F.isolated_off_edge smaller order cross no ind size xo.1 xo.2 vm
  have away {x : V} (xo : x ∈ O) : x ∈ AwayFromEdge G s t :=
    ⟨fun e => xo.2 (e.symm ▸ si),fun e => xo.2 (e.symm ▸ ti),
      iso xo (noncontactComponent_subset i si),iso xo (noncontactComponent_subset i ti)⟩
  have lo (x : V) := degree_of_small_deletion_preconnected (G := G) (by omega : 4 ≤ Fintype.card V)
    (fun K hk => (F.conn.2 K hk).preconnected) x
  have limit {x : V} (xo : x ∈ O) (miss : ¬ G.Adj a x ∨ ¬ G.Adj b x) (v : V) (xv : G.Adj x v) :
      v = a ∨ v = b ∨ v = p ∨ v = q := by
    rcases F.cover v with vX|vz|vr|va|vb
    · have rv : G.Adj r v := Classical.byContradiction fun m => iso xo ⟨vX,m⟩ xv
      by_cases vi : v ∈ rootedBlockContacts G X r i
      · exact Or.inr (Or.inr (only v vi))
      · have both := F.outside_contact_hits_both si ti st ta tb sa sb xo.1 xo.2 vX rv xv.symm vi
        exact (miss.elim (fun h => h both.1) (fun h => h both.2)).elim
    · exact (F.offX x ((F.cut.2 x).mp (vz ▸ xv.symm)) xo.1.1).elim
    · exact (xo.1.2 (vr ▸ xv.symm)).elim
    · exact Or.inl va
    · exact Or.inr (Or.inl vb)
  have hits {x : V} (xo : x ∈ O) : G.Adj a x ∨ G.Adj b x := by
    by_contra! miss
    have cap := degree_le_two (x := x) (c := p) (d := q) fun v e =>
      ((limit xo (Or.inl miss.1) v e).resolve_left (fun eq => miss.1 (eq ▸ e.symm))).resolve_left
        (fun eq => miss.2 (eq ▸ e.symm))
    have := lo x
    omega
  have must {x : V} (xo : x ∈ O) (miss : ¬ G.Adj a x ∨ ¬ G.Adj b x) : G.Adj p x := by
    by_contra px
    have small {c d : V} (vc : ∀ v, G.Adj x v → v = c ∨ v = d) := degree_le_two vc
    have cap : G.degree x ≤ 2 := by
      rcases miss with ax|bx
      · apply small (c := b) (d := q)
        intro v e
        have h := (limit xo (Or.inl ax) v e).resolve_left (fun eq => ax (eq ▸ e.symm))
        exact h.imp_right (fun pair => pair.resolve_left (fun eq => px (eq ▸ e.symm)))
      · apply small (c := a) (d := q)
        intro v e
        have h := limit xo (Or.inr bx) v e
        exact h.imp_right (fun rest => (rest.resolve_left (fun eq => bx (eq ▸ e.symm))).resolve_left (fun eq => px (eq ▸ e.symm)))
    have := lo x
    omega
  intro x xo y yo
  change x ∈ O at xo
  change y ∈ O at yo
  by_contra xy
  have na := iso xo yo.1
  have A := F.outside_port_collision si ti st ta sa xo.1.1 yo.1.1 (away xo) (away yo) xy na
  have B := (swap_others F).outside_port_collision si ti st tb sb xo.1.1 yo.1.1 (away xo) (away yo) xy na
  have px := must xo (by rcases hits yo with h|h; exact Or.inl (fun e => A e h); exact Or.inr (fun e => B e h))
  have py := must yo (by rcases hits xo with h|h; exact Or.inl (A h); exact Or.inr (B h))
  have ps := good.2 p pi s si
  exact NoRootedFour.forbids_four (F.contact_no_four_on_misses pi.1 pi.2.1)
    (noncontactComponent_subset i si) xo.1 yo.1
    (by simp [ps.ne,px.ne,py.ne,(away xo).1.symm,(away yo).1.symm,xy])
    ps (Or.inl ⟨px.symm,(away xo).2.2.1⟩)
    (Or.inl ⟨py.symm,(away yo).2.2.1,fun e => na e.symm⟩)

#print axioms SingletonCut.split_has_at_most_one_outside
end Graffiti199Depleted.Catalogue.Incomplete
