import SingleShore
open private two_distinct_contacts from TwoCliqueShores

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] {D : Finset V}

omit [DecidableEq V] in
theorem no_four_with_two_components (conn : ConnectivityAtLeast G 3) (budget : treeNumber G ≤ 5)
    (size : D.card = 3) {A B C : (DeletionGraph G D).ConnectedComponent}
    (ab : A ≠ B) (ac : A ≠ C) (bc : B ≠ C) {s : V} (hs : s ∈ D) :
    NoRootedFour G (componentShore D A) s := by
  obtain ⟨u,hu,su⟩ := component_contact conn size B hs
  obtain ⟨v,hv,sv⟩ := component_contact conn size C hs
  have uv := distinct_component_vertices bc hu hv
  intro f eq mem root
  have diff {K : (DeletionGraph G D).ConnectedComponent} (ak : A ≠ K) {y : V}
      (hy : y ∈ componentShore D K) (i : Fin 4) : y ≠ f i := by
    by_cases hi : i = 0
    · subst i
      exact fun e => componentShore_off_cut D K s hs ((e.trans eq) ▸ hy)
    · exact (distinct_component_vertices ak (mem i hi) hy).1.symm
  have six := six_of_two_leaves f root uv.1 (fun e => uv.2 e.symm) (eq.symm ▸ su) (eq.symm ▸ sv)
    (diff ab hu) (diff ac hv) (fun i hi => (distinct_component_vertices ab (mem i hi) hu).2)
    (fun i hi => (distinct_component_vertices ac (mem i hi) hv).2)
  omega

theorem OneShore.between {X : Set V} {r a b : V} (F : OneShore G X r a b) (cl : X.Pairwise G.Adj) :
    ∃ s t, G.Adj r s ∧ G.Adj a t ∧ Traverses G X s t := by
  classical
  by_cases two : ∃ u ∈ X, ∃ v ∈ X, u ≠ v
  · obtain ⟨s,hs,t,ht,st,rs,at'⟩ := two_distinct_contacts F.conn F.rb F.offX F.boundX two
    exact ⟨s,t,rs,at',Traverses.clique cl hs ht st⟩
  · obtain ⟨u,hu,ru⟩ := F.contact (by simp : r ∈ ({r,a,b} : Finset V))
    obtain ⟨w,hw,aw⟩ := F.contact (by simp : a ∈ ({r,a,b} : Finset V))
    obtain ⟨t,ht,p⟩ := Traverses.start_clique cl hu
    have eq : w = t := Classical.byContradiction fun ne => two ⟨w,hw,t,ht,ne⟩
    exact ⟨u,t,ru,eq ▸ aw,p⟩

private theorem three_route (conn : ConnectivityAtLeast G 3) (budget : treeNumber G ≤ 5)
    (size : D.card = 3) {A B C : (DeletionGraph G D).ConnectedComponent}
    (ab : A ≠ B) (ac : A ≠ C) (bc : B ≠ C)
    (cover : ∀ J, J = A ∨ J = B ∨ J = C)
    (clB : (componentShore D B).Pairwise G.Adj) (clC : (componentShore D C).Pairwise G.Adj) :
    Traceable G := by
  classical
  obtain ⟨r,a,b,ra,rb,ab',ed⟩ := Finset.card_eq_three.mp size
  have hr : r ∈ D := by simp [ed]
  have ha : a ∈ D := by simp [ed]
  have hb : b ∈ D := by simp [ed]
  let X := componentShore D A
  let Y := componentShore D B
  let Z := componentShore D C
  have frame (K : (DeletionGraph G D).ConnectedComponent) {i j k : V}
      (ij : i ≠ j) (ik : i ≠ k) (jk : j ≠ k) (eq : D = {i,j,k}) :
      OneShore G (componentShore D K) i j k := ⟨conn,ij,ik,jk,
        eq ▸ componentShore_off_cut D K,eq ▸ componentShore_boundary D K,componentShore_connected D K⟩
  obtain ⟨_,_,first,_,P⟩ := (frame A ra rb ab' ed).terminal
    (no_four_with_two_components conn budget size ab ac bc hr)
    (no_four_with_two_components conn budget size ab ac bc ha)
  have ed' : D = {a,b,r} := ed.trans (by ext t; simp only [Finset.mem_insert,Finset.mem_singleton]; tauto)
  obtain ⟨_,_,mid₁,mid₂,Q⟩ := (frame B ab' ra.symm rb.symm ed').between clB
  obtain ⟨u,hu,last⟩ := component_contact conn size C hb
  obtain ⟨_,_,R⟩ := Traverses.start_clique clC hu
  have off (K : (DeletionGraph G D).ConnectedComponent) (v : V) (hv : v ∈ D) :
      v ∉ componentShore D K := componentShore_off_cut D K v hv
  have XY : Disjoint X Y := componentShore_disjoint ab
  have XZ : Disjoint X Z := componentShore_disjoint ac
  have YZ : Disjoint Y Z := componentShore_disjoint bc
  have d₁ : Disjoint (insert r X) ({a} : Set V) := by simp [X,ra.symm,off A a ha]
  have d₂ : Disjoint (insert r X ∪ {a}) Y := by
    simp [Set.disjoint_union_left,Set.disjoint_insert_left,XY,show r ∉ Y from off B r hr,
      show a ∉ Y from off B a ha]
  have d₃ : Disjoint ((insert r X ∪ {a}) ∪ Y) ({b} : Set V) := by
    simp [Set.disjoint_union_left,X,Y,off A b hb,off B b hb,rb.symm,ab'.symm]
  have d₄ : Disjoint (((insert r X ∪ {a}) ∪ Y) ∪ {b}) Z := by
    simp [Set.disjoint_union_left,Set.disjoint_insert_left,XZ,YZ,show r ∉ Z from off C r hr,
      show a ∉ Z from off C a ha,show b ∉ Z from off C b hb]
  obtain ⟨path,_,_⟩ := (((P.reverse.join (Traverses.single a) d₁ first.symm).join Q d₂ mid₁).join
    (Traverses.single b) d₃ mid₂.symm).join R d₄ last
  have all : ((((insert r X ∪ {a}) ∪ Y) ∪ {b}) ∪ Z) = Set.univ := by
    apply Set.eq_univ_iff_forall.mpr
    intro z
    simp only [Set.mem_union,Set.mem_singleton_iff,Set.mem_insert_iff]
    by_cases hd : z ∈ D
    · have : z = r ∨ z = a ∨ z = b := by simpa [ed] using hd
      tauto
    let t : Survives D := ⟨z,hd⟩
    let K := (DeletionGraph G D).connectedComponentMk t
    have mem : z ∈ componentShore D K := ⟨t,rfl,rfl⟩
    rcases cover K with e|e|e
    · have h : z ∈ X := by simpa only [X,e] using mem
      tauto
    · have h : z ∈ Y := by simpa only [Y,e] using mem
      tauto
    · have h : z ∈ Z := by simpa only [Z,e] using mem
      tauto
  exact traceable_iff_hamiltonian_walk.mpr (pathOn_univ_iff_hamiltonian_walk.mp ⟨all ▸ path⟩)

theorem traceable_of_exactly_three_components (conn : ConnectivityAtLeast G 3)
    (budget : treeNumber G ≤ 5) (size : D.card = 3)
    {A B C : (DeletionGraph G D).ConnectedComponent} (ab : A ≠ B) (ac : A ≠ C) (bc : B ≠ C)
    (cover : ∀ J, J = A ∨ J = B ∨ J = C) : Traceable G := by
  classical
  obtain ⟨r,hr⟩ := Finset.card_pos.mp (show 0 < D.card by omega)
  by_cases clB : (componentShore D B).Pairwise G.Adj
  · by_cases clC : (componentShore D C).Pairwise G.Adj
    · exact three_route conn budget size ab ac bc cover clB clC
    · have b : ¬ GoodAt G (componentShore D C) r := fun h => clC h.1
      have cA := (good_of_two_other_components conn size budget ac.symm bc.symm ab hr b).1
      exact three_route conn budget size ac.symm bc.symm ab (fun J => by have := cover J; tauto) cA clB
  · have b : ¬ GoodAt G (componentShore D B) r := fun h => clB h.1
    have cA := (good_of_two_other_components conn size budget ab.symm bc ac hr b).1
    have cC := (good_of_two_other_components conn size budget bc ab.symm ac.symm hr b).1
    exact three_route conn budget size ab.symm bc ac (fun J => by have := cover J; tauto) cA cC

#print axioms traceable_of_exactly_three_components
end Graffiti199Depleted.Catalogue.Incomplete
