import SingletonArms
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X : Set V} {z r a b : V}

theorem SingletonCut.three_arm_splice (F : SingletonCut G X z r a b) (nr : NoRootedFour G X r)
    (A B C : Arm G X r) (ab : A.i ≠ B.i) (ac : A.i ≠ C.i) (bc : B.i ≠ C.i)
    (wide : ∀ i : RootComponent G X r, i ≠ A.i → i ≠ B.i → i ≠ C.i → Wide G X r i) :
    Traceable G := by
  classical
  let I := RootComponent G X r
  letI : Finite I := Quot.finite _
  letI : Fintype I := Fintype.ofFinite I
  let T : Finset I := Finset.univ.filter fun i => i ≠ A.i ∧ i ≠ B.i ∧ i ≠ C.i
  have ht (i : I) : i ∈ T ↔ i ≠ A.i ∧ i ≠ B.i ∧ i ≠ C.i := by simp [T]
  let M := {v | v ∈ insert r X ∧ ∀ i ∉ T, v ∉ RootBlock G X r i}
  have off := F.offX r (by simp)
  obtain ⟨s,hs,t,ht',mid⟩ := middle_without_blocks nr off T (fun i h =>
    wide i ((ht i).mp h).1 ((ht i).mp h).2.1 ((ht i).mp h).2.2)
  change Traverses G M s t at mid
  have ends : s ∈ M ∧ t ∈ M := by
    obtain ⟨p,eq₀,eq₁⟩ := mid
    exact ⟨eq₀ ▸ (p.covers _).mp (List.head_mem p.nonempty),eq₁ ▸ p.last_mem⟩
  have ma : Disjoint M A.block := Set.disjoint_left.mpr fun _ hm => hm.2 A.i (by simp [T])
  have mb : Disjoint M B.block := Set.disjoint_left.mpr fun _ hm => hm.2 B.i (by simp [T])
  have mc : Disjoint M C.block := Set.disjoint_left.mpr fun _ hm => hm.2 C.i (by simp [T])
  have ab' := Arm.apart nr off ab
  have ac' := Arm.apart nr off ac
  have bc' := Arm.apart nr off bc
  obtain ⟨⟨u,hu,au⟩,_⟩ := ports_meet_private_component F.conn F.boundX F.offX A.i A.hit A.one
  obtain ⟨_,⟨v,hv,bv⟩⟩ := ports_meet_private_component F.conn F.boundX F.offX B.i B.hit B.one
  obtain ⟨w,hw⟩ := C.i.nonempty_supp
  have pA := (A.path nr off hu).reverse
  have pB := B.path nr off hv
  have pC := (C.path nr off (show w.val ∈ noncontactComponent G X r C.i from ⟨w,hw,rfl⟩)).reverse
  have enter := B.join_middle nr off hs (Set.disjoint_left.mp mb ends.1)
  have leave := (C.join_middle nr off ht' (Set.disjoint_left.mp mc ends.2)).symm
  have away (J : Arm G X r) {v : V} (out : v ∉ X) : v ∉ J.block := fun h => out (J.sub h)
  have aX := F.offX a (by simp)
  have bX := F.offX b (by simp)
  have zr : z ≠ r := fun eq => F.cut.1 (by simp [eq])
  have za : z ≠ a := fun eq => F.cut.1 (by simp [eq])
  have zb : z ≠ b := fun eq => F.cut.1 (by simp [eq])
  have notM {x : V} (xr : x ≠ r) (out : x ∉ X) : x ∉ M := fun h => h.1.elim xr out
  have dz : Disjoint (A.block ∪ {a}) ({z} : Set V) := by
    simp [Set.disjoint_union_left,away A F.zX,za]
  have db : Disjoint ((A.block ∪ {a}) ∪ {z}) ({b} : Set V) := by
    simp [Set.disjoint_union_left,away A bX,F.ab.symm,zb.symm]
  let U := ((A.block ∪ {a}) ∪ {z}) ∪ {b}
  have dB : Disjoint U B.block := by
    exact Set.disjoint_union_left.mpr ⟨Set.disjoint_union_left.mpr ⟨Set.disjoint_union_left.mpr
      ⟨ab',Set.disjoint_singleton_left.mpr (away B aX)⟩,Set.disjoint_singleton_left.mpr (away B F.zX)⟩,
      Set.disjoint_singleton_left.mpr (away B bX)⟩
  have dM : Disjoint (U ∪ B.block) M := by
    simp [U,Set.disjoint_union_left,ma.symm,mb.symm,notM F.ra.symm aX,notM F.rb.symm bX,notM zr F.zX]
  have dC : Disjoint ((U ∪ B.block) ∪ M) C.block := by
    have dU : Disjoint U C.block := Set.disjoint_union_left.mpr ⟨Set.disjoint_union_left.mpr
      ⟨Set.disjoint_union_left.mpr ⟨ac',Set.disjoint_singleton_left.mpr (away C aX)⟩,
        Set.disjoint_singleton_left.mpr (away C F.zX)⟩,Set.disjoint_singleton_left.mpr (away C bX)⟩
    exact Set.disjoint_union_left.mpr ⟨Set.disjoint_union_left.mpr ⟨dU,bc'⟩,mc⟩
  have dA : Disjoint A.block ({a} : Set V) := by simpa using away A aX
  have left := ((pA.join (Traverses.single a) dA au.symm).join (Traverses.single z) dz
    ((F.cut.2 a).mpr (by simp)).symm).join (Traverses.single b) db ((F.cut.2 b).mpr (by simp))
  obtain ⟨path,_,_⟩ := (((left.join pB dB bv).join mid dM enter).join pC dC leave)
  have cover : (((U ∪ B.block) ∪ M) ∪ C.block) = Set.univ := by
    apply Set.eq_univ_iff_forall.mpr
    intro x
    simp only [U,Set.mem_union,Set.mem_singleton_iff]
    have inM (h : x ∈ insert r X) (na : x ∉ A.block) (nb : x ∉ B.block) (nc : x ∉ C.block) :
        x ∈ M := by
      refine ⟨h,fun i out => ?_⟩
      have eq : i = A.i ∨ i = B.i ∨ i = C.i := by
        by_cases h : i = A.i
        · exact Or.inl h
        by_cases k : i = B.i
        · exact Or.inr (Or.inl k)
        exact Or.inr (Or.inr (Classical.byContradiction (fun l => out ((ht i).mpr ⟨h,k,l⟩))))
      rcases eq with e|e|e
      · exact e.symm ▸ na
      · exact e.symm ▸ nb
      · exact e.symm ▸ nc
    by_cases mc' : x ∈ C.block
    · exact Or.inr mc'
    left
    by_cases ma' : x ∈ A.block
    · exact Or.inl (Or.inl (Or.inl (Or.inl (Or.inl ma'))))
    by_cases mb' : x ∈ B.block
    · exact Or.inl (Or.inr mb')
    rcases F.cover x with h|h|h|h|h
    · exact Or.inr (inM (Or.inr h) ma' mb' mc')
    · exact Or.inl (Or.inl (Or.inl (Or.inr h)))
    · exact Or.inr (inM (Or.inl h) ma' mb' mc')
    · exact Or.inl (Or.inl (Or.inl (Or.inl (Or.inr h))))
    · exact Or.inl (Or.inl (Or.inr h))
  exact traceable_iff_hamiltonian_walk.mpr (pathOn_univ_iff_hamiltonian_walk.mp ⟨cover ▸ path⟩)

#print axioms SingletonCut.three_arm_splice
end Graffiti199Depleted.Catalogue.Incomplete

