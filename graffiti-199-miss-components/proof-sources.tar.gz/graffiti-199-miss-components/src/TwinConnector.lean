import SplitThirdMiss
open private nonisolated_in_shore from CubicPortThreeShores
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} {X : Set V} {s t w : V}

/-- In a chordless connector between nonadjacent ends, neither end occurs
among the interior vertices, even if the allowed region includes the ends. -/
theorem connector_interior_off_ends (C : ChordlessConnector G X s w)
    (sw : ¬ G.Adj s w) (i : Fin (C.last+1)) : C.inside i ≠ s ∧ C.inside i ≠ w := by
  constructor
  · intro e
    by_cases last : i.val = C.last
    · exact sw (e ▸ ((C.from_v i).mpr last).symm)
    let j : Fin (C.last+1) := ⟨i.val+1,by have := i.isLt; omega⟩
    have edge := (C.chain i j).mpr (Or.inl rfl)
    have zero := (C.from_u j).mp (show G.Adj s (C.inside j) by simpa only [e] using edge)
    change i.val+1 = 0 at zero
    omega
  · intro e
    by_cases first : i.val = 0
    · exact sw (e ▸ (C.from_u i).mpr first)
    let j : Fin (C.last+1) := ⟨i.val-1,by have := i.isLt; omega⟩
    have edge := (C.chain i j).mpr (Or.inr (by change i.val-1+1=i.val; omega))
    have last := (C.from_v j).mp (show G.Adj w (C.inside j) by simpa only [e] using edge)
    change i.val-1 = C.last at last
    have := i.isLt
    omega

/-- If t is next to s, and its other ordinary neighbors are also neighbors
of s, an ordinary geodesic from s to a nonneighbor w of both avoids t. -/
theorem rightArm_avoids_dominated_neighbor (conn : (G.induce X).Connected)
    (sX : s ∈ X) (tX : t ∈ X) (wX : w ∈ X) (st : G.Adj s t)
    (dif : s ≠ w) (sw : ¬ G.Adj s w) (tw : ¬ G.Adj t w)
    (dom : ∀ v ∈ X, v ≠ s → G.Adj t v → G.Adj s v) :
    Nonempty (RightArm G {v | v ∈ X ∧ v ≠ s ∧ v ≠ t ∧ v ≠ w} s w) := by
  classical
  obtain ⟨v,vX,wv⟩ := nonisolated_in_shore conn.preconnected wX ⟨s,sX,w,wX,dif⟩
  obtain ⟨C⟩ := exists_chordless_connector conn.preconnected dif sw ⟨t,tX,st⟩ ⟨v,vX,wv⟩
  have off (i : Fin (C.last+1)) : C.inside i ≠ t := by
    intro e
    have first := (C.from_u i).mp (e.symm ▸ st)
    by_cases last : i.val = C.last
    · exact tw (e ▸ ((C.from_v i).mpr last).symm)
    let j : Fin (C.last+1) := ⟨i.val+1,by have := i.isLt; omega⟩
    have edge := (C.chain i j).mpr (Or.inl rfl)
    have zero := (C.from_u j).mp (dom _ (C.kept j) (connector_interior_off_ends C sw j).1 (show G.Adj t (C.inside j) by simpa only [e] using edge))
    change i.val+1 = 0 at zero
    omega
  let Q : ChordlessConnector G {v | v ∈ X ∧ v ≠ s ∧ v ≠ t ∧ v ≠ w} s w :=
    { C with kept := fun i => ⟨C.kept i,(connector_interior_off_ends C sw i).1,off i,(connector_interior_off_ends C sw i).2⟩ }
  exact ⟨RightArm.ofConnector Q⟩

#print axioms rightArm_avoids_dominated_neighbor
end Graffiti199Depleted.Catalogue.Incomplete

