import ReserveCycle
open private component_only_vertex from ExactSingleton
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X : Set V} {z r a b x y h : V}

/-- Two distinct ordinary vertices with all their ordinary neighbors confined
to one common vertex, both missed by r, give three components at a second cut. -/
theorem SingletonCut.traceable_of_shared_tip (F : SingletonCut G X z r a b)
    (xX : x ∈ X) (yX : y ∈ X) (hX : h ∈ X) (xy : x ≠ y) (xh : x ≠ h) (yh : y ≠ h)
    (rx : ¬ G.Adj r x) (ry : ¬ G.Adj r y)
    (tx : ∀ s ∈ X, G.Adj x s → s = h) (ty : ∀ s ∈ X, G.Adj y s → s = h) : Traceable G := by
  classical
  let D : Finset V := {a,b,h}
  have off {t : V} (tX : t ∈ X) {v : V} (hv : v ∈ ({r,a,b} : Finset V)) : t ≠ v :=
    fun e => F.offX v hv (e ▸ tX)
  have ha := off hX (show a ∈ ({r,a,b} : Finset V) by simp)
  have hb := off hX (show b ∈ ({r,a,b} : Finset V) by simp)
  have surv {u : V} (uX : u ∈ X) (uh : u ≠ h) : u ∉ D := by
    simp [D,off uX (show a ∈ ({r,a,b} : Finset V) by simp),off uX (show b ∈ ({r,a,b} : Finset V) by simp),uh]
  let u : Survives D := ⟨x,surv xX xh⟩
  let v : Survives D := ⟨y,surv yX yh⟩
  let w : Survives D := ⟨r,by simp [D,F.ra,F.rb,(off hX (Finset.mem_insert_self r _)).symm]⟩
  have iso {s : V} (sX : s ∈ X) (rs : ¬ G.Adj r s) (tip : ∀ t ∈ X, G.Adj s t → t = h)
      (t : Survives D) : ¬ G.Adj s t.val := by
    intro e
    rcases F.cover t.val with ht|ez|er|ea|eb
    · exact t.property (by simp [D,tip _ ht e])
    · exact F.offX s ((F.cut.2 _).mp (ez ▸ e.symm)) sX
    · exact rs (er ▸ e.symm)
    · exact t.property (by simp [D,ea])
    · exact t.property (by simp [D,eb])
  let K := (DeletionGraph G D).ConnectedComponent
  let m := (DeletionGraph G D).connectedComponentMk
  have distinct {s t : Survives D} (si : ∀ w : Survives D, ¬ G.Adj s.val w.val)
      (ne : s.val ≠ t.val) : m s ≠ m t := fun eq => ne (congrArg Subtype.val (component_only_vertex si t eq.symm))
  have uv := distinct (s := u) (t := v) (iso xX rx tx) xy
  have uw := distinct (s := u) (t := w) (iso xX rx tx) (off xX (Finset.mem_insert_self r _))
  have vw := distinct (s := v) (t := w) (iso yX ry ty) (off yX (Finset.mem_insert_self r _))
  letI : Fintype K := Fintype.ofFinite _
  have ct := Finset.card_le_univ ({m u,m v,m w} : Finset K)
  apply traceable_of_three_or_more_components F.conn F.budget (D := D) (by simp [D,F.ab,ha.symm,hb.symm])
  change 3 ≤ Nat.card K
  simpa [Nat.card_eq_fintype_card,uv,uw,vw] using ct

#print axioms SingletonCut.traceable_of_shared_tip
end Graffiti199Depleted.Catalogue.Incomplete
