import DoubleMissGeometry
open private six_le_treeNumber_of_five_independent_neighbors from CubicEdgeCuts
open private triple_of_card_bound from OppositeComplete

namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V]
variable {R : Set V} {a x z : V}

/-- A common neighbor of two independent tips, complete to a set neither tip
meets, forces that set to have independence at most two. -/
theorem triple_of_two_tips (budget : treeNumber G ≤ 5) (xz : x ≠ z) (apart : ¬ G.Adj x z)
    (ax : G.Adj a x) (az : G.Adj a z) (xR : x ∉ R) (zR : z ∉ R)
    (complete : ∀ v ∈ R, G.Adj a v) (offX : ∀ v ∈ R, ¬ G.Adj x v)
    (offZ : ∀ v ∈ R, ¬ G.Adj z v) : Triple G R := by
  classical
  intro i hi j hj k hk ij ik jk
  apply triple_of_card_bound (Y := R) ?_ hi hj hk ij ik jk
  intro T sub independent
  have xx : x ∉ T := fun h => xR (sub _ h)
  have zT : z ∉ T := fun h => zR (sub _ h)
  have zz : z ∉ insert x T := by simp [xz.symm,zT]
  let S := insert z (insert x T)
  have on : ∀ v ∈ S, G.Adj a v := by
    intro v hv
    simp only [S,Finset.mem_insert] at hv
    rcases hv with rfl|rfl|e <;> first | assumption | exact complete _ (sub _ e)
  have stable : ∀ v ∈ S, ∀ w ∈ S, ¬ G.Adj v w := by
    intro v hv w hw
    simp only [S,Finset.mem_insert] at hv hw
    rcases hv with rfl|rfl|vm <;> rcases hw with rfl|rfl|wm
    · exact G.loopless _
    · exact fun e => apart e.symm
    · exact offZ _ (sub _ wm)
    · exact apart
    · exact G.loopless _
    · exact offX _ (sub _ wm)
    · exact fun e => offZ _ (sub _ vm) e.symm
    · exact fun e => offX _ (sub _ vm) e.symm
    · exact independent _ vm _ wm
  have c : S.card = T.card + 2 := by rw [Finset.card_insert_of_not_mem zz,Finset.card_insert_of_not_mem xx]
  change T.card ≤ 2
  by_contra small
  have five : 5 ≤ S.card := by omega
  exact (Nat.not_succ_le_self 5) ((six_le_treeNumber_of_five_independent_neighbors S a
    five on stable).trans budget)

#print axioms triple_of_two_tips
end Graffiti199Depleted.Catalogue.Incomplete

