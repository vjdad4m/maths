import FinalCut
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {X : Set V} {z r a b x y : V}

/-- If a port misses at most two ordinary vertices and neither has a contact
to either other port, every deletion path would have exactly the same two
ends. Rotating a deletion path to make one of them internal contradicts this. -/
theorem SingletonCut.traceable_of_two_unattached (F : SingletonCut G X z r a b)
    (P : PathOn G {v | v ≠ z}) (xX : x ∈ X)
    (on : ∀ t ∈ X \ {x,y}, G.Adj r t)
    (empty : ∀ t ∈ ({x,y} : Set V), ¬ G.Adj a t ∧ ¬ G.Adj b t) : Traceable G := by
  classical
  by_contra no
  rcases F.port_miss_dichotomy no (Finset.mem_insert_self r _) with hit|ends
  · obtain ⟨v,vX,rv,t,mem,ne,tv⟩ := hit
    have pair : v ∈ ({x,y} : Set V) := Classical.byContradiction fun off => rv (on _ ⟨vX,off⟩)
    simp only [Finset.mem_insert,Finset.mem_singleton] at mem
    rcases mem.resolve_left ne with ta|tb
    · exact (empty v pair).1 (ta ▸ tv)
    · exact (empty v pair).2 (tb ▸ tv)
  have dx := degree_of_small_deletion_preconnected (G := G) (by have := F.conn.1; omega : 4 ≤ Fintype.card V)
    (fun K hk => (F.conn.2 K hk).preconnected) x
  have ct : 1 < (G.neighborFinset x).card := by rw [G.card_neighborFinset_eq_degree]; omega
  obtain ⟨u,um,v,vm,uv⟩ := Finset.one_lt_card.mp ct
  have xz : x ≠ z := fun e => F.zX (e ▸ xX)
  have e₁ := (G.mem_neighborFinset x u).mp um
  have e₂ := (G.mem_neighborFinset x v).mp vm
  have other (t : V) (e : G.Adj x t) : t ≠ z := fun eq => F.offX x ((F.cut.2 _).mp (eq ▸ e.symm)) xX
  obtain ⟨Q,L,p,q,R,split⟩ := exists_internal_path P xz (other _ e₁) (other _ e₂) e₁ e₂ uv
  obtain ⟨distinct,f,l⟩ := ends Q
  have lastX := F.flanks_in_shore no Q Q.last (Finset.mem_insert_self _ _)
  let S : PathOn G {v | v ≠ z} := ⟨Q.vertices.reverse,by simpa using Q.nonempty,
    List.chain'_reverse.mpr (Q.chain.imp (fun _ _ e => e.symm)),List.nodup_reverse.mpr Q.nodup,
    fun t => List.mem_reverse.trans (Q.covers t)⟩
  have sf : S.last = Q.first := by simp [S,PathOn.first,PathOn.last]
  have firstX := sf ▸ F.flanks_in_shore no S S.last (Finset.mem_insert_self _ _)
  have pair (t : V) (h : t ∈ X) (e : ¬ G.Adj r t) : t = x ∨ t = y :=
    Classical.byContradiction fun bad => e (on _ ⟨h,bad⟩)
  have nd := Q.nodup
  rw [split] at nd
  have fst : Q.first ∈ L ++ [p] := by
    have eq : Q.vertices = (L ++ [p]) ++ x :: q :: R := by simpa using split
    have hd : Q.first ∈ Q.vertices.head? := by rw [List.head?_eq_head Q.nonempty]; rfl
    have prime : (L ++ [p]) ≠ [] := by simp
    rw [eq,List.head?_append,List.head?_eq_head prime] at hd
    exact (show (L ++ [p]).head prime = Q.first by simpa using hd) ▸ List.head_mem prime
  have lst : Q.last ∈ q :: R := by
    change Q.vertices.getLast _ ∈ _
    have eq : Q.vertices = (L ++ [p,x]) ++ q :: R := by simpa using split
    simp [eq]
  have nd' : ((L ++ [p]) ++ x :: q :: R).Nodup := by simpa using nd
  have fx : Q.first ≠ x := fun e => (List.nodup_append.mp nd').2.2 (e ▸ fst) (List.mem_cons_self ..)
  have lx : Q.last ≠ x := fun e => (List.nodup_cons.mp (List.nodup_append.mp nd').2.1).1 (e ▸ lst)
  exact distinct (((pair _ firstX f).resolve_left fx).trans ((pair _ lastX l).resolve_left lx).symm)

#print axioms SingletonCut.traceable_of_two_unattached
end Graffiti199Depleted.Catalogue.Incomplete

