import ComponentExterior
import SafeOmission
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
universe u
variable {V : Type u} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {X : Set V} {z r a b : V} {i : RootComponent G X r}

private theorem four_neighbors {v s t p q : V} (st : s ≠ t) (sp : s ≠ p)
    (sq : s ≠ q) (tp : t ≠ p) (tq : t ≠ q) (pq : p ≠ q)
    (vs : G.Adj v s) (vt : G.Adj v t) (vp : G.Adj v p) (vq : G.Adj v q) : 4 ≤ G.degree v := by
  classical
  have sub : ({s,t,p,q} : Finset V) ⊆ G.neighborFinset v := by
    intro x hx
    rcases (show x=s ∨ x=t ∨ x=p ∨ x=q by simpa using hx) with e|e|e|e
    all_goals subst x; apply (G.mem_neighborFinset _ _).mpr; assumption
  simpa [st,sp,sq,tp,tq,pq] using Finset.card_le_card sub

omit [DecidableRel G.Adj] in
private theorem two_others {U : Set V} (many : 3 ≤ Nat.card U) (v : V) :
    ∃ x ∈ U, ∃ y ∈ U, x ≠ y ∧ v ≠ x ∧ v ≠ y := by
  classical
  letI : Fintype U := Fintype.ofFinite U
  have size : 3 ≤ U.toFinset.card := by rwa [Set.toFinset_card,← Nat.card_eq_fintype_card]
  have left := Finset.pred_card_le_card_erase (s := U.toFinset) (a := v)
  obtain ⟨x,hx,y,hy,xy⟩ := Finset.one_lt_card.mp (show 1 < (U.toFinset.erase v).card by omega)
  exact ⟨x,Set.mem_toFinset.mp (Finset.mem_erase.mp hx).2,y,Set.mem_toFinset.mp (Finset.mem_erase.mp hy).2,
    xy,(Finset.mem_erase.mp hx).1.symm,(Finset.mem_erase.mp hy).1.symm⟩

theorem SingletonCut.other_port_high (F : SingletonCut G X z r a b)
    (ind : ∀ u v, G.degree u = 3 → G.degree v = 3 → ¬ G.Adj u v) {v : V}
    (cut : v ∈ ({r,a,b} : Finset V)) : G.degree v ≠ 3 := by
  have dz := (degree_three_iff_three_neighbors (G := G) z).mpr
    ⟨{r,a,b},by simp [F.ra,F.rb,F.ab],F.cut.2⟩
  exact fun dv => ind _ _ dz dv ((F.cut.2 v).mpr cut)

theorem SingletonCut.large_uniform_safe (F : SingletonCut G X z r a b)
    (cross : CrossingBetweenSurvivingEdges G)
    (ind : ∀ u v, G.degree u = 3 → G.degree v = 3 → ¬ G.Adj u v)
    (good : UniformMissPart G X r i) (many : 3 ≤ Nat.card (MissPart G X r i))
    {v : V} (vi : v ∈ MissPart G X r i) : ∀ w, G.Adj v w → G.degree w ≠ 3 := by
  obtain ⟨x,xi,y,yi,xy,vx,vy⟩ := two_others many v
  obtain ⟨p,pi,q,qi,pq⟩ := F.edge_part_wide cross xi yi (good.1 xi yi xy)
  have sep {s t : V} (si : s ∈ MissPart G X r i) (ti : t ∈ rootedBlockContacts G X r i) : s ≠ t :=
    fun e => (noncontactComponent_subset i si).2 (e.symm ▸ ti.2.1)
  intro w vw
  by_cases wi : w ∈ MissPart G X r i
  · obtain ⟨s,si,t,ti,st,ws,wt⟩ := two_others many w
    have hi := four_neighbors st (sep si pi) (sep si qi) (sep ti pi) (sep ti qi) pq
      (good.1 wi si ws) (good.1 wi ti wt) (good.2 p pi w wi).symm (good.2 q qi w wi).symm
    omega
  · rcases F.part_boundary vi wi vw with wa|wb|hit
    · exact wa.symm ▸ F.other_port_high ind (by simp : a ∈ ({r,a,b} : Finset V))
    · exact wb.symm ▸ F.other_port_high ind (by simp : b ∈ ({r,a,b} : Finset V))
    have off {t : V} (ti : t ∈ MissPart G X r i) : r ≠ t :=
      fun e => F.offX r (by simp) (e.symm ▸ (noncontactComponent_subset i ti).1)
    have hi := four_neighbors (off vi) (off xi) (off yi) vx vy xy hit.2.1.symm
      (good.2 w hit v vi) (good.2 w hit x xi) (good.2 w hit y yi)
    omega

/-- Deleting a member u with no cubic neighbor forces its neighbor v in
the same uniform part to see both other ports, and u to see neither. -/
theorem SingletonCut.safe_pair_port_pattern (F : SingletonCut G X z r a b)
    (smaller : SmallerAtThree.{u} (Fintype.card V)) (order : 5 ≤ Fintype.card V)
    (cross : CrossingBetweenSurvivingEdges G) (no : ¬ Traceable G) (good : UniformMissPart G X r i)
    {s t : V} (si : s ∈ MissPart G X r i) (ti : t ∈ MissPart G X r i) (st : s ≠ t)
    (safe : ∀ w, G.Adj s w → G.degree w ≠ 3) :
    G.Adj t a ∧ G.Adj t b ∧ ¬ G.Adj s a ∧ ¬ G.Adj s b := by
  obtain ⟨x,y,xy,xs,ys,tx,ty,sx,sy⟩ := two_private_neighbors_of_safe_delete smaller F.conn order
    cross F.budget no safe (good.1 si ti st)
  have ex := F.difference_in_ports good ti si xs tx sx
  have ey := F.difference_in_ports good ti si ys ty sy
  rcases ex with rfl|rfl <;> rcases ey with e|e
  · exact (xy e.symm).elim
  · exact ⟨tx,e ▸ ty,sx,e ▸ sy⟩
  · exact ⟨e ▸ ty,tx,e ▸ sy,sx⟩
  · exact (xy e.symm).elim

theorem SingletonCut.uniform_size_le_two (F : SingletonCut G X z r a b)
    (smaller : SmallerAtThree.{u} (Fintype.card V)) (order : 5 ≤ Fintype.card V)
    (cross : CrossingBetweenSurvivingEdges G) (no : ¬ Traceable G)
    (ind : ∀ u v, G.degree u = 3 → G.degree v = 3 → ¬ G.Adj u v)
    (good : UniformMissPart G X r i) : Nat.card (MissPart G X r i) ≤ 2 := by
  classical
  by_contra! many
  obtain ⟨s,si,t,ti,st,_,_⟩ := two_others (Nat.succ_le_of_lt many) r
  have left := F.safe_pair_port_pattern smaller order cross no good si ti st
    (F.large_uniform_safe cross ind good many si)
  have right := F.safe_pair_port_pattern smaller order cross no good ti si st.symm
    (F.large_uniform_safe cross ind good many ti)
  exact left.2.2.1 right.1

#print axioms SingletonCut.large_uniform_safe
#print axioms SingletonCut.safe_pair_port_pattern
#print axioms SingletonCut.uniform_size_le_two
end Graffiti199Depleted.Catalogue.Incomplete
