import PortMiss
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]
variable {X : Set V} {z r a b x : V}

private theorem forced_next (F : SingletonCut G X z r a b) (no : ¬ Traceable G)
    (almost : ∀ w ∈ X, ¬ G.Adj r w → w = x) (P : PathOn G {v | v ≠ z})
    {L R : List V} {y : V} (split : P.vertices = L ++ x :: y :: R) : G.Adj z y := by
  obtain ⟨w,mem,miss⟩ := F.misses_flank no P (Finset.mem_insert_self r _)
  have wx := almost w (F.flanks_in_shore no P w mem) miss
  have k : L.length < P.vertices.length - 1 := by rw [split]; simp
  let i : P.EdgePosition := ⟨L.length,k⟩
  have l : P.before i = x := by
    simp only [PathOn.before,i,split,List.getElem_append_right (le_refl L.length),Nat.sub_self,
      List.getElem_cons_zero]
  have q : P.after i = y := by
    simp only [PathOn.after,i,split,List.getElem_append_right (Nat.le_succ L.length),
      show L.length.succ - L.length = 1 by omega,List.getElem_cons_succ,List.getElem_cons_zero]
  rcases Finset.mem_insert.mp mem with last|pred
  · exact (P.before_ne_last i ((l.trans wx.symm).trans last)).elim
  · obtain ⟨j,edge,eq⟩ := P.mem_predecessors.mp pred
    have ji := P.before_injective (eq.trans (wx.trans l.symm))
    exact q ▸ ji ▸ edge

/-- When r misses at most x on its ordinary shore, x can be replaced by
the singleton in every spanning path of the singleton deletion. -/
theorem SingletonCut.exchange_unique_miss (F : SingletonCut G X z r a b) (no : ¬ Traceable G)
    (almost : ∀ w ∈ X, ¬ G.Adj r w → w = x) (P : PathOn G {v | v ≠ z}) :
    ∃ Q : PathOn G {v | v ≠ x}, Q.vertices = P.vertices.map (Equiv.swap x z) := by
  classical
  let E := Equiv.swap x z
  let rev : PathOn G {v | v ≠ z} :=
    ⟨P.vertices.reverse,by simpa using P.nonempty,
      List.chain'_reverse.mpr (P.chain.imp (fun _ _ e => e.symm)),
      List.nodup_reverse.mpr P.nodup,fun v => by simpa using P.covers v⟩
  have chain : (P.vertices.map E).Chain' G.Adj := by
    apply (List.chain'_map E).mpr
    apply List.chain'_iff_forall_rel_of_append_cons_cons.mpr
    intro u v L R split
    have edge := List.chain'_iff_forall_rel_of_append_cons_cons.mp P.chain split
    have uz : u ≠ z := (P.covers u).mp (by rw [split]; simp)
    have vz : v ≠ z := (P.covers v).mp (by rw [split]; simp)
    change G.Adj (Equiv.swap x z u) (Equiv.swap x z v)
    by_cases ux : u = x
    · subst u
      rw [Equiv.swap_apply_left,Equiv.swap_apply_of_ne_of_ne edge.ne.symm vz]
      exact forced_next F no almost P split
    · rw [Equiv.swap_apply_of_ne_of_ne ux uz]
      by_cases vx : v = x
      · subst v
        rw [Equiv.swap_apply_left]
        apply (forced_next F no almost rev (L := R.reverse) (R := L.reverse) (y := u) ?_).symm
        change P.vertices.reverse = _
        simp [split,List.reverse_append,List.reverse_cons,List.append_assoc]
      · rwa [Equiv.swap_apply_of_ne_of_ne vx vz]
  refine ⟨⟨P.vertices.map E,by simpa using P.nonempty,chain,P.nodup.map E.injective,?_⟩,rfl⟩
  intro v
  change v ∈ List.map E P.vertices ↔ v ≠ x
  constructor
  · intro mem eq
    obtain ⟨w,hw,ew⟩ := List.mem_map.mp mem
    have ez : E z = x := Equiv.swap_apply_right x z
    exact (P.covers w).mp hw (E.injective ((ew.trans eq).trans ez.symm))
  · intro vx
    apply List.mem_map.mpr
    refine ⟨E.symm v,(P.covers _).mpr ?_,E.apply_symm_apply _⟩
    intro eq
    exact vx ((E.apply_symm_apply v).symm.trans ((congrArg E eq).trans (Equiv.swap_apply_right x z)))

#print axioms SingletonCut.exchange_unique_miss
end Graffiti199Depleted.Catalogue.Incomplete
