import ThreeComponents
open private triple_of_card_bound from OppositeComplete
namespace Graffiti199Depleted.Catalogue.Incomplete
open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] {X : Set V} {r : V}

abbrev RootComponent (G : SimpleGraph V) (X : Set V) (r : V) :=
  (G.induce (Noncontacts G X r)).ConnectedComponent

abbrev RootBlock (G : SimpleGraph V) (X : Set V) (r : V) (i : RootComponent G X r) : Set V :=
  rootedBlockContacts G X r i ∪ noncontactComponent G X r i

abbrev Wide (G : SimpleGraph V) (X : Set V) (r : V) (i : RootComponent G X r) : Prop :=
  ∃ x ∈ rootedBlockContacts G X r i, ∃ y ∈ rootedBlockContacts G X r i, x ≠ y

/-- Route the root and all selected wide blocks, omitting every vertex
in an unselected block. Both ends are root contacts or the root itself. -/
theorem middle_without_blocks (none : NoRootedFour G X r) (rOff : r ∉ X)
    (T : Finset (RootComponent G X r)) (many : ∀ i ∈ T, Wide G X r i) :
    ∃ s ∈ insert r (shoreContacts G X r), ∃ t ∈ insert r (shoreContacts G X r),
      Traverses G {v | v ∈ insert r X ∧ ∀ i ∉ T, v ∉ RootBlock G X r i} s t := by
  classical
  let I := RootComponent G X r
  let Q (i : I) := rootedBlockContacts G X r i
  let C (i : I) := noncontactComponent G X r i
  let B (i : I) := Q i ∪ C i
  let P₀ : Set V := {x | x ∈ shoreContacts G X r ∧ ∀ i, x ∉ Q i}
  let Z : Set V := insert r P₀
  have subQ {i : I} {x : V} (h : x ∈ Q i) : x ∈ shoreContacts G X r := ⟨h.1,h.2.1⟩
  have subC {i : I} {x : V} (h : x ∈ C i) : x ∈ Noncontacts G X r :=
    noncontactComponent_subset i h
  have QQ {i j : I} (h : i ≠ j) : Disjoint (Q i) (Q j) :=
    none.blockContacts_disjoint rOff h
  have CC {i j : I} (h : i ≠ j) : Disjoint (C i) (C j) := noncontactComponents_apart h
  have QC (i j : I) : Disjoint (Q i) (C j) :=
    Set.disjoint_left.mpr fun _ u v => (subC v).2 (subQ u).2
  have apart (i j : I) (ij : i ≠ j) : Disjoint (B i) (B j) := by
    simp only [B,Set.disjoint_union_left,Set.disjoint_union_right]
    exact ⟨⟨QQ ij,(QC j i).symm⟩,⟨QC i j,CC ij⟩⟩
  have touch (i : I) {x y : V} (hx : x ∈ shoreContacts G X r) (no : x ∉ Q i)
      (hy : y ∈ Q i) : G.Adj x y := by
    obtain ⟨u,hu,yu⟩ := hy.2.2
    exact (none.cross_contacts_complete rOff hy.1 hx.1 (subC hu) hy.2.1 hx.2 yu
      (fun edge => no ⟨hx.1,hx.2,u,hu,edge⟩)).symm
  obtain ⟨base⟩ := route_residual_with_port none (P := P₀) (fun _ h => h.1)
  have first : ∃ s ∈ Z, ∃ t ∈ Z, Traverses G Z s t :=
    ⟨base.first,(base.covers _).mp (List.head_mem base.nonempty),base.last,base.last_mem,base,rfl,rfl⟩
  have each (i : I) (hi : i ∈ T) : ∃ s ∈ Q i, ∃ t ∈ Q i, Traverses G (B i) s t := by
    have two := many i hi
    obtain ⟨u,hu,_,_,_⟩ := two
    obtain ⟨v,hv,uv⟩ := hu.2.2
    have cl := none.clique_of_contact rOff i hu.1 hu.2.1 hv uv
    apply nonprivate_block_route (QC i i) (many i hi) ⟨v,hv⟩ cl
    · intro x hx y hy
      obtain ⟨u',hu',xu⟩ := hx.2.2
      exact none.contact_common_on_component rOff i hx.1 hx.2.1 hu' hy xu
    · intro x hx y hy z hz xy xz yz
      exact triple_of_card_bound (Y := Q i) (fun S hS ind =>
        none.card_independent_contacts_le_two S (fun w hw => subQ (hS w hw)) ind)
        hx hy hz xy xz yz
  have baseApart (i : I) (hi : i ∈ T) : Disjoint Z (B i) := by
    apply Set.disjoint_left.mpr
    rintro v (rfl|h) (hq|hc)
    · exact rOff (subQ hq).1
    · exact rOff (subC hc).1
    · exact h.2 i hq
    · exact (subC hc).2 h.1.2
  have baseAdj (i : I) (hi : i ∈ T) (s : V) (hs : s ∈ Z) (t : V) (ht : t ∈ Q i) :
      G.Adj s t := by
    rcases hs with rfl|hs
    · exact (subQ ht).2
    · exact touch i hs.1 (hs.2 i) ht
  obtain ⟨s,hs,t,ht,R⟩ := concatenate_contact_intervals T first each baseApart
    (fun _ _ _ _ h => apart _ _ h) baseAdj (fun i _ j _ h _ hx _ hy =>
      touch j (subQ hx) (Set.disjoint_left.mp (QQ h) hx) hy)
  have ends {v : V} (h : v ∈ intervalUnion Z Q T) : v ∈ insert r (shoreContacts G X r) := by
    rcases h with (eq|hp)|⟨i,_,q⟩
    · exact Or.inl eq
    · exact Or.inr hp.1
    · exact Or.inr (subQ q)
  have full : intervalUnion Z B T = {v | v ∈ insert r X ∧ ∀ i ∉ T, v ∉ RootBlock G X r i} := by
    ext v
    constructor
    · rintro ((eq|hp)|⟨j,hj,h⟩)
      · exact ⟨Or.inl eq,fun i _ hi => hi.elim (fun z => rOff (eq ▸ (subQ z).1))
          (fun z => rOff (eq ▸ (subC z).1))⟩
      · exact ⟨Or.inr hp.1.1,fun i _ hi => hi.elim (hp.2 i) (fun z => (subC z).2 hp.1.2)⟩
      · exact ⟨Or.inr (h.elim (fun hq => (subQ hq).1) (fun hc => (subC hc).1)),fun i out hi =>
          Set.disjoint_left.mp (apart j i (fun e => out (e ▸ hj))) h hi⟩
    · rintro ⟨eq|vx,away⟩
      · exact Or.inl (Or.inl eq)
      by_cases rv : G.Adj r v
      · by_cases any : ∃ j, v ∈ Q j
        · obtain ⟨j,hj⟩ := any
          exact Or.inr ⟨j,Classical.byContradiction (fun out => away j out (Or.inl hj)),Or.inl hj⟩
        · exact Or.inl (Or.inr ⟨⟨vx,rv⟩,fun j hj => any ⟨j,hj⟩⟩)
      · let w : Noncontacts G X r := ⟨v,vx,rv⟩
        let i := (G.induce (Noncontacts G X r)).connectedComponentMk w
        have h : v ∈ C i := ⟨w,rfl,rfl⟩
        exact Or.inr ⟨i,Classical.byContradiction (fun out => away i out (Or.inr h)),Or.inr h⟩
  exact ⟨s,ends hs,t,ends ht,full ▸ R⟩

#print axioms middle_without_blocks
end Graffiti199Depleted.Catalogue.Incomplete
