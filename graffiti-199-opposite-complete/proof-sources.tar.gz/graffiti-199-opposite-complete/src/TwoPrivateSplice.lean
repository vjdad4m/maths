import PrivateContactsCut

namespace Graffiti199Depleted.Catalogue

open SimpleGraph
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableEq V]
variable {X Y : Set V} {r a b p q : V}

/-- If the noncontacts of r in X have exactly the two private components,
a port complete to Y gives a spanning path. The residual contacts in X may
be arbitrary, and the order of the graph is unrestricted. -/
theorem traceable_of_exactly_two_private_components_complete_opposite
    (conn : ConnectivityAtLeast G 3) (budget : treeNumber G ≤ 5)
    (ra : r ≠ a) (rb : r ≠ b) (ab : a ≠ b)
    (offX : ∀ w ∈ ({r,a,b} : Finset V), w ∉ X)
    (offY : ∀ w ∈ ({r,a,b} : Finset V), w ∉ Y)
    (boundX : ShoreBoundary G {r,a,b} X) (boundY : ShoreBoundary G {r,a,b} Y)
    (apart : Disjoint X Y) (cover : ∀ v, v ∈ X ∨ v ∈ Y ∨ v = r ∨ v = a ∨ v = b)
    (connY : (G.induce Y).Connected) (aComplete : ∀ z ∈ Y, G.Adj a z)
    (rMiss : ∃ z ∈ Y, ¬ G.Adj r z)
    (c d : (G.induce (Noncontacts G X r)).ConnectedComponent) (cd : c ≠ d)
    (all : ∀ e : (G.induce (Noncontacts G X r)).ConnectedComponent, e = c ∨ e = d)
    (pc : p ∈ rootedBlockContacts G X r c) (qd : q ∈ rootedBlockContacts G X r d)
    (oneC : ∀ s ∈ rootedBlockContacts G X r c, s = p)
    (oneD : ∀ s ∈ rootedBlockContacts G X r d, s = q) : Traceable G := by
  classical
  let C := noncontactComponent G X r c
  let E := noncontactComponent G X r d
  let P : Set V := {v | v ∈ shoreContacts G X r ∧ v ≠ p ∧ v ≠ q}
  let M : Set V := insert r P
  have hC := noncontactComponent_subset c
  have hE := noncontactComponent_subset d
  have ce : Disjoint C E := noncontactComponents_apart cd
  have rOff := offX r (by simp)
  have aOff := offX a (by simp)
  have bOff := offX b (by simp)
  have rY := offY r (by simp)
  have aY := offY a (by simp)
  have bY := offY b (by simp)
  have cut : ({r,a,b} : Finset V).card = 3 := by simp [ra,rb,ab]
  have none := no_rooted_four_across_cut conn budget cut offY boundX boundY apart connY
    (show r ∈ ({r,a,b} : Finset V) by simp) rMiss
  obtain ⟨⟨u,uc,au⟩,⟨s,sc,bs⟩⟩ := ports_meet_private_component conn boundX offX c pc oneC
  obtain ⟨⟨v,ve,av⟩,_⟩ := ports_meet_private_component conn boundX offX d qd oneD
  have uv : u ≠ v := fun h => Set.disjoint_left.mp ce uc (h.symm ▸ ve)
  obtain ⟨other⟩ := pathOn_opposite_of_complete_port (G := G) (by simp : a ∈ ({r,a,b} : Finset V))
    budget offX offY boundX apart connY aComplete (hC uc).1 (hE ve).1 uv
    (noncontactComponents_anticomplete cd uc ve) au av
  have px : p ∈ X := pc.1
  have qx : q ∈ X := qd.1
  have rp : G.Adj r p := pc.2.1
  have rq : G.Adj r q := qd.2.1
  have pq : p ≠ q := fun h => Set.disjoint_left.mp (none.blockContacts_disjoint rOff cd)
    pc (h.symm ▸ qd)
  obtain ⟨c0,c0mem,pc0⟩ := pc.2.2
  obtain ⟨d0,d0mem,qd0⟩ := qd.2.2
  have clC : C.Pairwise G.Adj := none.clique_of_contact rOff c px rp c0mem pc0
  have clE : E.Pairwise G.Adj := none.clique_of_contact rOff d qx rq d0mem qd0
  obtain ⟨t,tc,left⟩ := Traverses.start_clique clC sc
  obtain ⟨w,we,right⟩ := Traverses.end_clique clE ve
  have bC : b ∉ C := fun h => bOff (hC h).1
  have left' : Traverses G (insert b C) b t := by
    simpa only [Set.singleton_union] using (Traverses.single b).join left (by simpa using bC) bs
  obtain ⟨middle⟩ := route_residual_with_port none (P := P) (fun _ h => h.1)
  have m1 : middle.first ∈ M := (middle.covers _).mp (List.head_mem middle.nonempty)
  have m2 : middle.last ∈ M := middle.last_mem
  have pM (m : V) (hm : m ∈ M) : G.Adj p m := by
    rcases hm with rfl | hm
    · exact rp.symm
    · exact none.cross_contacts_complete rOff px hm.1.1 (hC c0mem) rp hm.1.2 pc0
        (fun e => hm.2.1 (oneC _ ⟨hm.1.1,hm.1.2,c0,c0mem,e⟩))
  have qM (m : V) (hm : m ∈ M) : G.Adj q m := by
    rcases hm with rfl | hm
    · exact rq.symm
    · exact none.cross_contacts_complete rOff qx hm.1.1 (hE d0mem) rq hm.1.2 qd0
        (fun e => hm.2.2 (oneD _ ⟨hm.1.1,hm.1.2,d0,d0mem,e⟩))
  have sep (H : Set V) (h : H ⊆ X) : Disjoint H Y := apart.mono_left h
  have CP : Disjoint C P := Set.disjoint_left.mpr fun _ h k => (hC h).2 k.1.2
  have PE : Disjoint P E := Set.disjoint_left.mpr fun _ h k => (hE k).2 h.1.2
  have split : [insert b C,{p},M,{q},E,{a},Y].Pairwise Disjoint := by
    have bp : b ≠ p := fun h => bOff (h.symm ▸ px)
    have bq : b ≠ q := fun h => bOff (h.symm ▸ qx)
    have pa : p ≠ a := fun h => aOff (h ▸ px)
    have qa : q ≠ a := fun h => aOff (h ▸ qx)
    have facts : p ∉ C ∧ q ∉ C ∧ a ∉ C ∧ r ∉ C ∧ p ∉ E ∧ q ∉ E ∧
        a ∉ E ∧ b ∉ E ∧ r ∉ E ∧ p ∉ P ∧ q ∉ P ∧ a ∉ P ∧ b ∉ P :=
      ⟨fun h => (hC h).2 rp,fun h => (hC h).2 rq,fun h => aOff (hC h).1,
       fun h => rOff (hC h).1,fun h => (hE h).2 rp,fun h => (hE h).2 rq,
       fun h => aOff (hE h).1,fun h => bOff (hE h).1,fun h => rOff (hE h).1,
       fun h => h.2.1 rfl,fun h => h.2.2 rfl,fun h => aOff h.1.1,fun h => bOff h.1.1⟩
    have disY : Disjoint C Y ∧ Disjoint P Y ∧ Disjoint E Y ∧ p ∉ Y ∧ q ∉ Y :=
      ⟨sep C (fun _ h => (hC h).1),sep P (fun _ h => h.1.1),sep E (fun _ h => (hE h).1),
       Set.disjoint_left.mp apart px,Set.disjoint_left.mp apart qx⟩
    simp only [M,List.pairwise_cons,List.mem_cons,List.not_mem_nil,or_false,forall_eq_or_imp,
      forall_eq,List.Pairwise.nil,and_true,Set.disjoint_insert_left,Set.disjoint_insert_right,
      Set.disjoint_singleton_left,Set.disjoint_singleton_right,Set.mem_insert_iff,
      Set.mem_singleton_iff,not_or]
    have pr := rp.ne.symm
    have qr := rq.ne.symm
    have pr' := rp.ne
    have qr' := rq.ne
    rcases facts with ⟨f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13⟩
    rcases disY with ⟨d1,d2,d3,d4,d5⟩
    repeat' apply And.intro
    all_goals first | assumption | exact fun _ h => h.elim | exact Ne.symm (by assumption)
  have coverage (z : V) : z ∈ insert b C ∨ z = p ∨ z ∈ M ∨ z = q ∨ z ∈ E ∨ z = a ∨ z ∈ Y := by
    rcases cover z with zx|zy|rfl|rfl|rfl
    · by_cases rz : G.Adj r z
      · by_cases ep : z = p
        · tauto
        by_cases eq : z = q
        · tauto
        have mz : z ∈ M := Or.inr ⟨⟨zx,rz⟩,ep,eq⟩
        tauto
      · let z' : Noncontacts G X r := ⟨z,zx,rz⟩
        let e := (G.induce (Noncontacts G X r)).connectedComponentMk z'
        have m : z ∈ noncontactComponent G X r e := ⟨z',rfl,rfl⟩
        rcases all e with h|h
        · exact Or.inl (Set.mem_insert_of_mem _ (show z ∈ noncontactComponent G X r c from h ▸ m))
        · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inl (show z ∈ noncontactComponent G X r d from h ▸ m)))))
    · tauto
    · exact Or.inr (Or.inr (Or.inl (Set.mem_insert _ _)))
    · tauto
    · exact Or.inl (Set.mem_insert _ _)
  exact traceable_of_four_exceptional_halves split coverage left'
    ⟨middle,rfl,rfl⟩ right ⟨other,rfl,rfl⟩
    (none.contact_common_on_component rOff c px rp c0mem tc pc0).symm (pM _ m1)
    (qM _ m2).symm (none.contact_common_on_component rOff d qx rq d0mem we qd0)
    av.symm (aComplete _ ((other.covers _).mp (List.head_mem other.nonempty)))

#print axioms traceable_of_exactly_two_private_components_complete_opposite

end Graffiti199Depleted.Catalogue
