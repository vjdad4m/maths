"""Validate the proposed opposite-complete splice on deterministic constructed shores."""
from functools import lru_cache
from itertools import combinations
from random import Random

rng = Random(199)
def add(G, u, v):
    assert u != v
    G[u].add(v)
    G[v].add(u)

def path(G, nodes, valid_ends=None):
    V = tuple(nodes)
    if not V:
        return []
    @lru_cache(maxsize=None)
    def tail(x, rest):
        if not rest:
            return (x,) if valid_ends is None or x in valid_ends else None
        for y in rest:
            if y in G[x]:
                nxt = tail(y, tuple(z for z in rest if z != y))
                if nxt:
                    return (x,) + nxt
        return None
    for x in V:
        if valid_ends is None or x in valid_ends:
            sol = tail(x, tuple(z for z in V if z != x))
            if sol:
                return list(sol)
    return None

def make_alpha_two(G, n, connected=False):
    while True:
        E = [(u,v) for u,v in combinations(n,2) if rng.random() < .58]
        if any(not any(u in I and v in I for u,v in E) for I in combinations(n,3)):
            continue
        reached = {n[0]} if n else set()
        while any((u in reached) != (v in reached) for u,v in E):
            for u,v in E:
                if u in reached or v in reached:
                    reached.update([u,v])
        if connected and len(reached) != len(n):
            continue
        for u,v in E:
            add(G,u,v)
        return

def instance(block_count, residual_size, opposite_size):
    from collections import defaultdict
    G = defaultdict(set)
    r,a,b = 0,1,2
    next_v = 3
    def allocate(n):
        nonlocal next_v
        A = list(range(next_v,next_v+n))
        next_v += n
        return A
    def join(A,B):
        for u in A:
            for v in B:
                add(G,u,v)
    def clique(A):
        for u,v in combinations(A,2):
            add(G,u,v)
    P = allocate(residual_size)
    residual = P[:]
    make_alpha_two(G,P)
    groups = []
    for i in range(block_count + 2):
        Q = allocate(1 if i < 2 else rng.randrange(2,6))
        C = allocate(rng.randrange(1,5))
        make_alpha_two(G,Q)
        clique(C)
        join(P,Q)
        join(Q,C)
        P += Q
        groups.append((Q,C))
    join([r],P)
    Y = allocate(opposite_size)
    make_alpha_two(G,Y,True)
    join([a],Y)
    for _,C in groups[:2]:
        for u in (a,b):
            join([u],[rng.choice(C)])
    assert len(Y) >= 2
    join([r],[Y[0]])
    join([b],[rng.choice(Y)])
    # The constructed interface permits other edges. They can only preserve the route.
    (Q0,C0),(Q1,C1) = groups[:2]
    tb = next(c for c in C0 if b in G[c])
    ta = next(c for c in C1 if a in G[c])
    route = [b,tb] + [c for c in C0 if c != tb] + Q0
    route += path(G,residual + [r])
    for Q,C in groups[2:]:
        block = path(G,Q+C,set(Q))
        assert block
        route += block
    route += Q1 + [c for c in C1 if c != ta] + [ta,a] + path(G,Y)
    assert sorted(route) == list(range(next_v))
    assert all(v in G[u] for u,v in zip(route,route[1:]))
    return next_v

def main():
    orders = []
    for blocks in range(5):
        for residual in range(6):
            for opposite in range(2,8):
                for _ in range(5):
                    orders.append(instance(blocks,residual,opposite))
    print(f"All {len(orders)} constructed routes visit each vertex once along edges.")
    print(f"Orders {min(orders)} to {max(orders)}; 0–4 additional nonprivate blocks.")
    print("The enumeration tests the routing interface. It does not enumerate catalogue graphs.")

if __name__ == "__main__":
    main()

