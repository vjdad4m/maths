"""A nine-vertex graph meeting every graph hypothesis of the opposite-complete splice."""
from itertools import combinations
edges = {(0,1),(0,2),(0,3),(0,4),(0,7),(1,5),(1,6),(1,7),(1,8),
         (2,3),(2,4),(2,5),(2,6),(2,8),(3,4),(3,5),(4,6),(7,8)}
V = set(range(9))
A = {v:set() for v in V}
for u,v in edges:
    A[u].add(v)
    A[v].add(u)
def component(S, v):
    reached = {v}
    while True:
        step = reached | (set.union(*(A[u] for u in reached)) & S)
        if reached == step:
            return reached
        reached = step
def connected(S):
    return bool(S) and component(S,min(S)) == S
def subsets(k):
    return (set(x) for x in combinations(sorted(V),k))
kappa = min(k for k in range(8) if any(not connected(V - cut) for cut in subsets(k)))
trees = [S for k in range(1,10) for S in subsets(k)
         if sum(len(A[v] & S) for v in S) == 2 * (k-1) and connected(S)]
r,a,b = 0,1,2
X,Y = {3,4,5,6},{7,8}
assert connected(X) and connected(Y) and not any(A[u] & Y for u in X)
assert V == X | Y | {r,a,b} and Y <= A[a] and Y - A[r]
P = X & A[r]
C,E = [component(X - P,v) for v in (5,6)]
assert C != E and (set.union(*(A[v] for v in C)) & P) == {3}
assert (set.union(*(A[v] for v in E)) & P) == {4}
assert kappa == 3 and max(map(len,trees)) == 5
route = [b,5,3,r,4,6,a,7,8]
assert len(route) == len(V) and set(route) == V and all(v in A[u] for u,v in zip(route,route[1:]))
print("Order 9, connectivity 3, largest induced tree 5, private contacts 3 and 4.")
print("Spanning path:", *route)

