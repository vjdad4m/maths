import Case35Part1
namespace Graffiti199Depleted.Catalogue.OrderEleven
namespace Cert35Steps
open Std.Sat
set_option maxRecDepth 4096
set_option maxHeartbeats 0
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj]
def c3021 : CNF.Clause Nat := [(76, false), (17, false), (50, true), (86, false), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3021 (F : Frame G 3) : c3021.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h1 : LitSat F.assign (8, false) :=
    use_clause (p2709 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (75, false) :=
    use_clause (p2833 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, false) :=
    use_clause (p3016 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h4 : LitSat F.assign (32, true) :=
    use_clause (p3019 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, false) :=
    use_clause (p1985 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (30, true) :=
    use_clause (p40 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (5, true) :=
    use_clause (p3020 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h8 : LitSat F.assign (18, false) :=
    use_clause (p2429 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h9 : LitSat F.assign (29, false) :=
    use_clause (p2580 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p35 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c3022 : CNF.Clause Nat := [(50, true), (6, true), (86, false), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3022 (F : Frame G 3) : c3022.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (6, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (17, true) :=
    use_clause (p12 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h3 : LitSat F.assign (76, false) :=
    use_clause (p3021 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (32, false) :=
    use_clause (p2875 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h5 : LitSat F.assign (21, true) :=
    use_clause (p52 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h6 : LitSat F.assign (10, true) :=
    use_clause (p57 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h7 : LitSat F.assign (18, false) :=
    use_clause (p1643 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (77, false) :=
    use_clause (p3014 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h9 : LitSat F.assign (29, false) :=
    use_clause (p2178 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  exact use_clause (p34 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
def c3023 : CNF.Clause Nat := [(76, true), (50, false), (86, false), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3023 (F : Frame G 3) : c3023.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (32, false) :=
    use_clause (p2875 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (21, true) :=
    use_clause (p52 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (10, true) :=
    use_clause (p57 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h5 : LitSat F.assign (77, false) :=
    use_clause (p2432 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (29, false) :=
    use_clause (p2178 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (75, false) :=
    use_clause (p2436 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p32 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
def c3024 : CNF.Clause Nat := [(29, true), (32, true), (77, true), (76, false), (50, false), (86, false), (87, true), (38, false), (99, false), (110, false)]
theorem p3024 (F : Frame G 3) : c3024.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (29, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (18, false) :=
    use_clause (p2481 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h1 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h3 : LitSat F.assign (75, true) :=
    use_clause (p35 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (21, true) :=
    use_clause (p140 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p2436 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n9 h),
        True.intro⟩
def c3025 : CNF.Clause Nat := [(32, true), (77, true), (50, false), (86, false), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3025 (F : Frame G 3) : c3025.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (76, true) :=
    use_clause (p3023 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h1 : LitSat F.assign (22, false) :=
    use_clause (p2622 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (33, false) :=
    use_clause (p2623 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h4 : LitSat F.assign (29, true) :=
    use_clause (p3024 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, false) :=
    use_clause (p2190 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (21, false) :=
    use_clause (p2180 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h7 : LitSat F.assign (10, false) :=
    use_clause (p2562 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n8 h),
        True.intro⟩
  exact use_clause (p343 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
def c3026 : CNF.Clause Nat := [(77, true), (50, false), (86, false), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3026 (F : Frame G 3) : c3026.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (18, false) :=
    use_clause (p2481 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (32, true) :=
    use_clause (p3025 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (75, false) :=
    use_clause (p2425 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (29, false) :=
    use_clause (p2715 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p35 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
def c3027 : CNF.Clause Nat := [(50, false), (86, false), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3027 (F : Frame G 3) : c3027.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (18, false) :=
    use_clause (p2481 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (76, true) :=
    use_clause (p3023 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (8, false) :=
    use_clause (p2709 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (77, true) :=
    use_clause (p3026 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (32, false) :=
    use_clause (p2430 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h7 : LitSat F.assign (21, false) :=
    use_clause (p2432 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h8 : LitSat F.assign (10, true) :=
    use_clause (p64 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (29, false) :=
    use_clause (p2562 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h10 : LitSat F.assign (30, false) :=
    use_clause (p2659 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h11 : LitSat F.assign (75, true) :=
    use_clause (p145 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h12 : LitSat F.assign (88, true) :=
    use_clause (p40 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p2681 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
def c3028 : CNF.Clause Nat := [(77, false), (86, false), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3028 (F : Frame G 3) : c3028.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (50, false) :=
    use_clause (p3027 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (6, true) :=
    use_clause (p3022 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (32, false) :=
    use_clause (p2430 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h5 : LitSat F.assign (21, false) :=
    use_clause (p3014 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (76, true) :=
    use_clause (p52 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (10, true) :=
    use_clause (p64 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h8 : LitSat F.assign (8, false) :=
    use_clause (p2709 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (27, false) :=
    use_clause (p2578 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h10 : LitSat F.assign (75, false) :=
    use_clause (p2833 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h11 : LitSat F.assign (30, false) :=
    use_clause (p2659 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h12 : LitSat F.assign (5, true) :=
    use_clause (p10 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (88, true) :=
    use_clause (p40 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h14 : LitSat F.assign (18, false) :=
    use_clause (p2206 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h15 : LitSat F.assign (29, false) :=
    use_clause (p1899 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
  exact use_clause (p145 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c3029 : CNF.Clause Nat := [(75, true), (29, true), (32, true), (86, false), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3029 (F : Frame G 3) : c3029.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (29, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (77, false) :=
    use_clause (p3028 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, false) :=
    use_clause (p3027 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h2 : LitSat F.assign (6, true) :=
    use_clause (p3022 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (76, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (18, true) :=
    use_clause (p35 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (10, true) :=
    use_clause (p121 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (27, false) :=
    use_clause (p2578 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h9 : LitSat F.assign (5, false) :=
    use_clause (p2206 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3030 : CNF.Clause Nat := [(75, false), (32, true), (6, false), (50, true), (86, false), (87, true), (38, false), (39, false), (98, true), (110, false)]
theorem p3030 (F : Frame G 3) : c3030.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (76, false) :=
    use_clause (p2833 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h1 : LitSat F.assign (21, true) :=
    use_clause (p52 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h2 : LitSat F.assign (27, false) :=
    use_clause (p2435 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h3 : LitSat F.assign (5, false) :=
    use_clause (p2434 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  exact use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c3031 : CNF.Clause Nat := [(32, true), (86, false), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3031 (F : Frame G 3) : c3031.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (77, false) :=
    use_clause (p3028 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, false) :=
    use_clause (p3027 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (6, true) :=
    use_clause (p3022 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (75, false) :=
    use_clause (p3030 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (76, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (29, true) :=
    use_clause (p3029 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h8 : LitSat F.assign (27, false) :=
    use_clause (p2578 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h9 : LitSat F.assign (21, false) :=
    use_clause (p2536 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h10 : LitSat F.assign (5, true) :=
    use_clause (p10 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h11 : LitSat F.assign (18, true) :=
    use_clause (p124 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h12 : LitSat F.assign (10, true) :=
    use_clause (p64 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p2206 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3032 : CNF.Clause Nat := [(86, false), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3032 (F : Frame G 3) : c3032.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, false) :=
    use_clause (p3027 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (6, true) :=
    use_clause (p3022 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (32, true) :=
    use_clause (p3031 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, true) :=
    use_clause (p2875 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, false) :=
    use_clause (p2340 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (8, false) :=
    use_clause (p2709 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (30, false) :=
    use_clause (p2317 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p40 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
def c3033 : CNF.Clause Nat := [(29, false), (5, false), (30, false), (32, false), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3033 (F : Frame G 3) : c3033.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p3032 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (76, false) :=
    use_clause (p2340 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (75, true) :=
    use_clause (p1682 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (21, false) :=
    use_clause (p2253 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h7 : LitSat F.assign (10, false) :=
    use_clause (p2681 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p61 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3034 : CNF.Clause Nat := [(30, false), (6, false), (32, false), (50, true), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3034 (F : Frame G 3) : c3034.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p3032 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (76, false) :=
    use_clause (p2340 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (27, false) :=
    use_clause (p1677 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (18, false) :=
    use_clause (p2658 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h7 : LitSat F.assign (5, true) :=
    use_clause (p10 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (29, false) :=
    use_clause (p3033 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h9 : LitSat F.assign (77, true) :=
    use_clause (p34 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h10 : LitSat F.assign (10, false) :=
    use_clause (p2659 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        True.intro⟩
  have h11 : LitSat F.assign (21, false) :=
    use_clause (p2194 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p61 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3035 : CNF.Clause Nat := [(5, false), (29, true), (6, false), (32, false), (50, true), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3035 (F : Frame G 3) : c3035.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (29, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p3032 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h2 : LitSat F.assign (30, false) :=
    use_clause (p3034 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h3 : LitSat F.assign (8, true) :=
    use_clause (p42 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (76, false) :=
    use_clause (p2340 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h7 : LitSat F.assign (10, false) :=
    use_clause (p1619 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (21, true) :=
    use_clause (p61 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h9 : LitSat F.assign (75, false) :=
    use_clause (p1840 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h10 : LitSat F.assign (18, true) :=
    use_clause (p36 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h11 : LitSat F.assign (9, false) :=
    use_clause (p1618 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h12 : LitSat F.assign (20, false) :=
    use_clause (p2657 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  exact use_clause (p48 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3036 : CNF.Clause Nat := [(75, true), (27, false), (29, true), (8, false), (76, true), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3036 (F : Frame G 3) : c3036.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (27, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (29, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p3032 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h4 : LitSat F.assign (18, true) :=
    use_clause (p36 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (9, false) :=
    use_clause (p2542 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h6 : LitSat F.assign (20, false) :=
    use_clause (p2657 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  exact use_clause (p48 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c3037 : CNF.Clause Nat := [(75, false), (6, false), (76, true), (32, false), (88, false), (87, true), (38, false), (39, false), (98, true), (110, false)]
theorem p3037 (F : Frame G 3) : c3037.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (21, false) :=
    use_clause (p1840 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (10, false) :=
    use_clause (p2681 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p61 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        True.intro⟩
def c3038 : CNF.Clause Nat := [(29, true), (6, false), (32, false), (50, true), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3038 (F : Frame G 3) : c3038.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (29, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h1 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p3032 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (76, false) :=
    use_clause (p2340 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h5 : LitSat F.assign (75, false) :=
    use_clause (p3037 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h6 : LitSat F.assign (30, false) :=
    use_clause (p3034 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h7 : LitSat F.assign (8, true) :=
    use_clause (p42 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (5, false) :=
    use_clause (p3035 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h9 : LitSat F.assign (27, false) :=
    use_clause (p3036 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  exact use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c3039 : CNF.Clause Nat := [(6, false), (32, false), (50, true), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3039 (F : Frame G 3) : c3039.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p3032 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (76, false) :=
    use_clause (p2340 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h5 : LitSat F.assign (30, false) :=
    use_clause (p3034 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (8, true) :=
    use_clause (p42 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (75, false) :=
    use_clause (p3037 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h8 : LitSat F.assign (29, true) :=
    use_clause (p3038 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h9 : LitSat F.assign (27, false) :=
    use_clause (p1674 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h10 : LitSat F.assign (21, false) :=
    use_clause (p2534 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h11 : LitSat F.assign (5, true) :=
    use_clause (p10 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h12 : LitSat F.assign (10, true) :=
    use_clause (p61 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p1619 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c3040 : CNF.Clause Nat := [(75, true), (8, false), (32, false), (50, true), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3040 (F : Frame G 3) : c3040.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (6, false) :=
    use_clause (p3039 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h1 : LitSat F.assign (17, true) :=
    use_clause (p12 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (29, false) :=
    use_clause (p2535 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p3032 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (76, false) :=
    use_clause (p2340 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h8 : LitSat F.assign (18, true) :=
    use_clause (p36 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h9 : LitSat F.assign (27, false) :=
    use_clause (p3036 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h10 : LitSat F.assign (21, false) :=
    use_clause (p1643 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (20, false) :=
    use_clause (p2657 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h12 : LitSat F.assign (5, true) :=
    use_clause (p10 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h13 : LitSat F.assign (10, true) :=
    use_clause (p61 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h14 : LitSat F.assign (9, true) :=
    use_clause (p48 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  exact use_clause (p1624 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
def c3041 : CNF.Clause Nat := [(8, false), (32, false), (50, true), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3041 (F : Frame G 3) : c3041.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (6, false) :=
    use_clause (p3039 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (17, true) :=
    use_clause (p12 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p3032 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (76, false) :=
    use_clause (p2340 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h7 : LitSat F.assign (75, true) :=
    use_clause (p3040 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h8 : LitSat F.assign (10, false) :=
    use_clause (p2681 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (21, false) :=
    use_clause (p1859 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p61 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3042 : CNF.Clause Nat := [(75, false), (5, false), (76, true), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3042 (F : Frame G 3) : c3042.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p3032 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (10, false) :=
    use_clause (p2681 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h5 : LitSat F.assign (21, false) :=
    use_clause (p2684 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p61 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c3043 : CNF.Clause Nat := [(32, false), (50, true), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3043 (F : Frame G 3) : c3043.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p3032 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, false) :=
    use_clause (p2340 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (8, false) :=
    use_clause (p3041 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (30, true) :=
    use_clause (p42 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (27, false) :=
    use_clause (p1677 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h8 : LitSat F.assign (5, true) :=
    use_clause (p10 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (75, false) :=
    use_clause (p3042 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h10 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        True.intro⟩
  have h11 : LitSat F.assign (10, false) :=
    use_clause (p2659 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        True.intro⟩
  have h12 : LitSat F.assign (21, false) :=
    use_clause (p2194 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p61 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c3044 : CNF.Clause Nat := [(76, true), (50, true), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3044 (F : Frame G 3) : c3044.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (32, false) :=
    use_clause (p3043 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p3032 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (21, true) :=
    use_clause (p52 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (10, true) :=
    use_clause (p57 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (75, false) :=
    use_clause (p2681 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (30, false) :=
    use_clause (p2659 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h10 : LitSat F.assign (8, true) :=
    use_clause (p42 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h11 : LitSat F.assign (9, false) :=
    use_clause (p1613 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h12 : LitSat F.assign (20, true) :=
    use_clause (p48 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h13 : LitSat F.assign (17, false) :=
    use_clause (p1648 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h14 : LitSat F.assign (18, false) :=
    use_clause (p2657 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h15 : LitSat F.assign (6, true) :=
    use_clause (p12 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h16 : LitSat F.assign (29, true) :=
    use_clause (p36 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p2534 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h16 h),
        True.intro⟩
def c3045 : CNF.Clause Nat := [(21, false), (75, true), (50, true), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3045 (F : Frame G 3) : c3045.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (76, true) :=
    use_clause (p3044 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p3032 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (8, false) :=
    use_clause (p2709 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (30, true) :=
    use_clause (p42 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (9, false) :=
    use_clause (p2301 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h8 : LitSat F.assign (20, true) :=
    use_clause (p48 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (32, false) :=
    use_clause (p3043 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h10 : LitSat F.assign (5, false) :=
    use_clause (p1717 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h11 : LitSat F.assign (17, false) :=
    use_clause (p1648 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (27, true) :=
    use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h13 : LitSat F.assign (6, true) :=
    use_clause (p12 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h14 : LitSat F.assign (29, false) :=
    use_clause (p1672 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h15 : LitSat F.assign (18, false) :=
    use_clause (p2658 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h16 : LitSat F.assign (10, true) :=
    use_clause (p148 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h17 : LitSat F.assign (77, true) :=
    use_clause (p35 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p2659 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h16 h),
        True.intro⟩
def c3046 : CNF.Clause Nat := [(75, true), (50, true), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3046 (F : Frame G 3) : c3046.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (76, true) :=
    use_clause (p3044 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p3032 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (8, false) :=
    use_clause (p2709 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (30, true) :=
    use_clause (p42 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (9, false) :=
    use_clause (p2301 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (32, false) :=
    use_clause (p3043 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h8 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h9 : LitSat F.assign (20, true) :=
    use_clause (p48 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h10 : LitSat F.assign (21, false) :=
    use_clause (p3045 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h11 : LitSat F.assign (10, true) :=
    use_clause (p64 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h12 : LitSat F.assign (77, false) :=
    use_clause (p2659 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h13 : LitSat F.assign (18, true) :=
    use_clause (p124 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h14 : LitSat F.assign (6, false) :=
    use_clause (p2658 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h15 : LitSat F.assign (17, false) :=
    use_clause (p1642 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p12 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c3047 : CNF.Clause Nat := [(50, true), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3047 (F : Frame G 3) : c3047.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p3032 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (32, false) :=
    use_clause (p3043 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (76, true) :=
    use_clause (p3044 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (8, false) :=
    use_clause (p2709 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (30, true) :=
    use_clause (p42 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h8 : LitSat F.assign (75, true) :=
    use_clause (p3046 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (10, false) :=
    use_clause (p2681 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h10 : LitSat F.assign (17, false) :=
    use_clause (p2683 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h11 : LitSat F.assign (21, true) :=
    use_clause (p64 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h12 : LitSat F.assign (6, true) :=
    use_clause (p12 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h13 : LitSat F.assign (5, false) :=
    use_clause (p1717 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h14 : LitSat F.assign (27, false) :=
    use_clause (p1832 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n0 h),
        True.intro⟩
def c3048 : CNF.Clause Nat := [(76, false), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3048 (F : Frame G 3) : c3048.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (50, true) :=
    use_clause (p3047 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p3032 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (8, false) :=
    use_clause (p2709 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (20, false) :=
    use_clause (p2637 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (30, true) :=
    use_clause (p42 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h8 : LitSat F.assign (9, false) :=
    use_clause (p2301 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h9 : LitSat F.assign (75, false) :=
    use_clause (p1696 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p48 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3049 : CNF.Clause Nat := [(32, true), (87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3049 (F : Frame G 3) : c3049.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (76, false) :=
    use_clause (p3048 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p3047 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p3032 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (21, true) :=
    use_clause (p52 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (10, true) :=
    use_clause (p57 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (75, false) :=
    use_clause (p2681 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h10 : LitSat F.assign (30, false) :=
    use_clause (p2659 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h11 : LitSat F.assign (9, false) :=
    use_clause (p2300 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h12 : LitSat F.assign (8, true) :=
    use_clause (p42 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h13 : LitSat F.assign (20, true) :=
    use_clause (p48 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h14 : LitSat F.assign (29, false) :=
    use_clause (p2272 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h15 : LitSat F.assign (18, false) :=
    use_clause (p2657 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p36 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3050 : CNF.Clause Nat := [(75, true), (32, false), (76, true), (50, false), (86, true), (87, true), (38, false), (39, false), (74, true), (98, true), (99, false)]
theorem p3050 (F : Frame G 3) : c3050.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (8, false) :=
    use_clause (p2338 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (30, true) :=
    use_clause (p42 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (10, false) :=
    use_clause (p2659 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (29, false) :=
    use_clause (p1682 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h6 : LitSat F.assign (21, true) :=
    use_clause (p61 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h7 : LitSat F.assign (18, true) :=
    use_clause (p36 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (9, false) :=
    use_clause (p2300 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h9 : LitSat F.assign (20, false) :=
    use_clause (p1652 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  exact use_clause (p48 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n9 h),
        True.intro⟩
def c3051 : CNF.Clause Nat := [(87, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3051 (F : Frame G 3) : c3051.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p3032 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p3047 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (76, false) :=
    use_clause (p3048 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (32, true) :=
    use_clause (p3049 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (75, true) :=
    use_clause (p3050 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (8, false) :=
    use_clause (p2531 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (10, false) :=
    use_clause (p2681 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h10 : LitSat F.assign (6, false) :=
    use_clause (p3037 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (5, false) :=
    use_clause (p3042 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h12 : LitSat F.assign (30, true) :=
    use_clause (p42 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h13 : LitSat F.assign (21, true) :=
    use_clause (p61 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h14 : LitSat F.assign (26, false) :=
    use_clause (p2519 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h15 : LitSat F.assign (15, false) :=
    use_clause (p2518 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h16 : LitSat F.assign (17, true) :=
    use_clause (p23 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        True.intro⟩
  have h17 : LitSat F.assign (27, true) :=
    use_clause (p18 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p2634 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c3052 : CNF.Clause Nat := [(8, true), (10, true), (88, false), (86, true), (30, true), (22, true), (50, false), (11, true), (75, false), (76, true), (87, false), (39, false), (74, true), (98, true), (99, false)]
theorem p3052 (F : Frame G 3) : c3052.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (8, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have n12 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))))
  have n13 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))))
  have n14 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))))))
  have h0 : LitSat F.assign (32, true) :=
    use_clause (p216 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n12 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (n13 h),
        True.intro⟩
  have h1 : LitSat F.assign (77, false) :=
    use_clause (p2203 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n11 h),
        fun h => h,
        fun h => False.elim (n14 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h2 : LitSat F.assign (33, false) :=
    use_clause (p2414 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  exact use_clause (p245 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n12 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3053 : CNF.Clause Nat := [(88, false), (86, true), (50, false), (75, false), (38, false), (39, false), (99, false), (110, false)]
theorem p3053 (F : Frame G 3) : c3053.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (87, true) :=
    use_clause (p3051 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (30, false) :=
    use_clause (p2504 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, false) :=
    use_clause (p2396 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (11, false) :=
    use_clause (p2453 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, false) :=
    use_clause (p1689 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h7 : LitSat F.assign (10, false) :=
    use_clause (p2117 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h8 : LitSat F.assign (8, true) :=
    use_clause (p3052 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h9 : LitSat F.assign (77, false) :=
    use_clause (p2466 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (33, false) :=
    use_clause (p2650 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (32, false) :=
    use_clause (p2531 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p319 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
def c3054 : CNF.Clause Nat := [(86, true), (50, false), (75, false), (38, false), (39, false), (99, false), (110, false)]
theorem p3054 (F : Frame G 3) : c3054.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (87, true) :=
    use_clause (p3051 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (30, false) :=
    use_clause (p2504 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, false) :=
    use_clause (p2396 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (76, false) :=
    use_clause (p1689 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (88, false) :=
    use_clause (p3053 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (8, true) :=
    use_clause (p41 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (77, false) :=
    use_clause (p2466 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (33, false) :=
    use_clause (p2650 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (32, false) :=
    use_clause (p2531 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h11 : LitSat F.assign (21, false) :=
    use_clause (p2472 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  exact use_clause (p292 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3055 : CNF.Clause Nat := [(50, false), (75, false), (38, false), (39, false), (99, false), (110, false)]
theorem p3055 (F : Frame G 3) : c3055.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (87, true) :=
    use_clause (p3051 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (76, false) :=
    use_clause (p1689 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (29, false) :=
    use_clause (p2497 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (86, true) :=
    use_clause (p3054 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (32, false) :=
    use_clause (p2875 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (21, false) :=
    use_clause (p2436 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (18, false) :=
    use_clause (p2481 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (10, true) :=
    use_clause (p66 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h10 : LitSat F.assign (77, true) :=
    use_clause (p34 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p1786 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
def c3056 : CNF.Clause Nat := [(86, false), (75, false), (38, false), (39, false), (99, false), (110, false)]
theorem p3056 (F : Frame G 3) : c3056.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (50, false) :=
    use_clause (p3055 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p3051 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (76, false) :=
    use_clause (p1689 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (21, false) :=
    use_clause (p2904 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (32, false) :=
    use_clause (p2875 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (10, true) :=
    use_clause (p66 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (29, false) :=
    use_clause (p2233 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (77, false) :=
    use_clause (p1786 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        True.intro⟩
  have h10 : LitSat F.assign (18, false) :=
    use_clause (p2576 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p34 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
def c3057 : CNF.Clause Nat := [(21, true), (77, true), (32, true), (75, false), (38, false), (39, false), (99, false), (110, false)]
theorem p3057 (F : Frame G 3) : c3057.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p3056 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p3051 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (11, false) :=
    use_clause (p2453 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (76, false) :=
    use_clause (p1689 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (10, true) :=
    use_clause (p66 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (88, false) :=
    use_clause (p2681 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (8, true) :=
    use_clause (p195 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h9 : LitSat F.assign (33, true) :=
    use_clause (p296 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  exact use_clause (p2650 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3058 : CNF.Clause Nat := [(22, false), (18, false), (88, true), (77, true), (50, true), (75, false), (87, false), (38, false), (39, false), (74, true), (99, false)]
theorem p3058 (F : Frame G 3) : c3058.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (5, false) :=
    use_clause (p2653 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (17, false) :=
    use_clause (p1644 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (27, true) :=
    use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (6, true) :=
    use_clause (p12 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p2236 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c3059 : CNF.Clause Nat := [(10, false), (77, true), (75, false), (38, false), (39, false), (99, false), (110, false)]
theorem p3059 (F : Frame G 3) : c3059.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p3056 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, false) :=
    use_clause (p3055 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p3051 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (11, false) :=
    use_clause (p2453 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, false) :=
    use_clause (p1689 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (29, false) :=
    use_clause (p2233 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (88, false) :=
    use_clause (p2681 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (18, true) :=
    use_clause (p34 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (22, false) :=
    use_clause (p3058 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h10 : LitSat F.assign (33, true) :=
    use_clause (p88 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h11 : LitSat F.assign (8, false) :=
    use_clause (p2650 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h12 : LitSat F.assign (17, false) :=
    use_clause (p1821 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  have h13 : LitSat F.assign (30, true) :=
    use_clause (p41 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h14 : LitSat F.assign (6, true) :=
    use_clause (p12 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p2507 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c3060 : CNF.Clause Nat := [(88, true), (77, true), (32, true), (75, false), (38, false), (39, false), (99, false), (110, false)]
theorem p3060 (F : Frame G 3) : c3060.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (10, false) :=
    use_clause (p3059 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p3056 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p3051 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (11, false) :=
    use_clause (p2453 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, false) :=
    use_clause (p1689 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h7 : LitSat F.assign (8, true) :=
    use_clause (p197 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (33, true) :=
    use_clause (p316 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p2650 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3061 : CNF.Clause Nat := [(77, true), (32, true), (75, false), (38, false), (39, false), (99, false), (110, false)]
theorem p3061 (F : Frame G 3) : c3061.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p3056 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, false) :=
    use_clause (p3055 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p3051 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (11, false) :=
    use_clause (p2453 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, false) :=
    use_clause (p1689 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (21, true) :=
    use_clause (p3057 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h8 : LitSat F.assign (10, false) :=
    use_clause (p3059 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h9 : LitSat F.assign (88, true) :=
    use_clause (p3060 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h10 : LitSat F.assign (26, false) :=
    use_clause (p2176 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h11 : LitSat F.assign (5, false) :=
    use_clause (p2684 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h12 : LitSat F.assign (15, true) :=
    use_clause (p2792 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h13 : LitSat F.assign (27, true) :=
    use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h14 : LitSat F.assign (17, false) :=
    use_clause (p2636 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h15 : LitSat F.assign (30, false) :=
    use_clause (p2511 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h16 : LitSat F.assign (6, true) :=
    use_clause (p12 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h17 : LitSat F.assign (8, true) :=
    use_clause (p216 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h18 : LitSat F.assign (22, false) :=
    use_clause (p2236 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h19 : LitSat F.assign (33, false) :=
    use_clause (p2650 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p319 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (n0 h),
        True.intro⟩
def c3062 : CNF.Clause Nat := [(10, true), (32, true), (75, false), (38, false), (39, false), (99, false), (110, false)]
theorem p3062 (F : Frame G 3) : c3062.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (87, true) :=
    use_clause (p3051 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (77, true) :=
    use_clause (p3061 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (8, false) :=
    use_clause (p2466 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p3056 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, false) :=
    use_clause (p3055 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (76, false) :=
    use_clause (p1689 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h8 : LitSat F.assign (21, true) :=
    use_clause (p66 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (30, true) :=
    use_clause (p216 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h10 : LitSat F.assign (5, false) :=
    use_clause (p2194 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h11 : LitSat F.assign (6, false) :=
    use_clause (p2656 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (27, true) :=
    use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h13 : LitSat F.assign (17, true) :=
    use_clause (p12 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p2636 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c3063 : CNF.Clause Nat := [(32, true), (75, false), (38, false), (39, false), (99, false), (110, false)]
theorem p3063 (F : Frame G 3) : c3063.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p3056 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p3051 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, true) :=
    use_clause (p3061 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (8, false) :=
    use_clause (p2466 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h5 : LitSat F.assign (10, true) :=
    use_clause (p3062 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (88, false) :=
    use_clause (p2681 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h7 : LitSat F.assign (30, false) :=
    use_clause (p2659 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p41 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3064 : CNF.Clause Nat := [(10, false), (77, false), (75, false), (38, false), (39, false), (99, false), (110, false)]
theorem p3064 (F : Frame G 3) : c3064.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (87, true) :=
    use_clause (p3051 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (8, false) :=
    use_clause (p2466 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p3056 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, false) :=
    use_clause (p2681 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (30, false) :=
    use_clause (p2659 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p41 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3065 : CNF.Clause Nat := [(30, true), (77, false), (75, false), (38, false), (39, false), (99, false), (110, false)]
theorem p3065 (F : Frame G 3) : c3065.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (10, false) :=
    use_clause (p3064 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p3051 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (8, false) :=
    use_clause (p2466 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (32, true) :=
    use_clause (p3063 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p3056 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (50, false) :=
    use_clause (p3055 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (76, false) :=
    use_clause (p1689 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h8 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h9 : LitSat F.assign (88, true) :=
    use_clause (p41 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        True.intro⟩
  have h10 : LitSat F.assign (21, true) :=
    use_clause (p218 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h11 : LitSat F.assign (26, false) :=
    use_clause (p2176 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h12 : LitSat F.assign (5, false) :=
    use_clause (p2684 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  have h13 : LitSat F.assign (15, true) :=
    use_clause (p2792 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h14 : LitSat F.assign (27, true) :=
    use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p2258 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c3066 : CNF.Clause Nat := [(77, false), (75, false), (38, false), (39, false), (99, false), (110, false)]
theorem p3066 (F : Frame G 3) : c3066.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (32, true) :=
    use_clause (p3063 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, false) :=
    use_clause (p3055 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p3051 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (30, true) :=
    use_clause (p3065 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (6, false) :=
    use_clause (p2656 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (17, true) :=
    use_clause (p12 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h6 : LitSat F.assign (5, false) :=
    use_clause (p1830 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h7 : LitSat F.assign (27, false) :=
    use_clause (p2636 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3067 : CNF.Clause Nat := [(30, false), (75, false), (38, false), (39, false), (99, false), (110, false)]
theorem p3067 (F : Frame G 3) : c3067.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (77, false) :=
    use_clause (p3066 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (32, true) :=
    use_clause (p3063 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, false) :=
    use_clause (p3055 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p3051 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, false) :=
    use_clause (p1689 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (6, false) :=
    use_clause (p2507 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (17, true) :=
    use_clause (p12 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h8 : LitSat F.assign (27, false) :=
    use_clause (p2636 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (5, true) :=
    use_clause (p10 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h10 : LitSat F.assign (18, false) :=
    use_clause (p2508 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h11 : LitSat F.assign (29, false) :=
    use_clause (p2215 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p34 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3068 : CNF.Clause Nat := [(17, false), (5, false), (30, true), (77, true), (32, false), (86, true), (75, false), (87, false), (38, false), (39, false), (74, true), (99, false)]
theorem p3068 (F : Frame G 3) : c3068.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (76, false) :=
    use_clause (p1689 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n11 h),
        True.intro⟩
  have h1 : LitSat F.assign (29, false) :=
    use_clause (p2215 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n11 h),
        True.intro⟩
  have h2 : LitSat F.assign (18, true) :=
    use_clause (p34 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (8, false) :=
    use_clause (p2220 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n11 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, false) :=
    use_clause (p1838 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p41 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3069 : CNF.Clause Nat := [(5, false), (30, true), (77, true), (32, false), (86, true), (50, true), (11, true), (75, false), (87, false), (38, false), (39, false), (74, true), (99, false)]
theorem p3069 (F : Frame G 3) : c3069.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have n12 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))))
  have h0 : LitSat F.assign (22, false) :=
    use_clause (p2653 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n12 h),
        fun h => h,
        fun h => False.elim (n8 h),
        True.intro⟩
  have h1 : LitSat F.assign (17, false) :=
    use_clause (p3068 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n12 h),
        True.intro⟩
  have h2 : LitSat F.assign (6, true) :=
    use_clause (p12 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, false) :=
    use_clause (p1897 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (8, true) :=
    use_clause (p41 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (33, true) :=
    use_clause (p88 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p2650 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n12 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n8 h),
        True.intro⟩
def c3070 : CNF.Clause Nat := [(75, false), (38, false), (39, false), (99, false), (110, false)]
theorem p3070 (F : Frame G 3) : c3070.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (87, true) :=
    use_clause (p3051 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (11, false) :=
    use_clause (p2453 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, false) :=
    use_clause (p3055 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p3056 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (32, true) :=
    use_clause (p3063 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (77, false) :=
    use_clause (p3066 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (30, false) :=
    use_clause (p3067 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (5, false) :=
    use_clause (p3069 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (27, true) :=
    use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h10 : LitSat F.assign (17, false) :=
    use_clause (p2636 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (6, true) :=
    use_clause (p12 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h12 : LitSat F.assign (22, false) :=
    use_clause (p2236 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (88, false) :=
    use_clause (p1897 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h14 : LitSat F.assign (8, true) :=
    use_clause (p41 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
  have h15 : LitSat F.assign (33, true) :=
    use_clause (p88 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
  exact use_clause (p2650 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3071 : CNF.Clause Nat := [(32, false), (30, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3071 (F : Frame G 3) : c3071.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (87, true) :=
    use_clause (p3051 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (76, false) :=
    use_clause (p1689 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (75, false) :=
    use_clause (p3070 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (8, false) :=
    use_clause (p2466 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (86, false) :=
    use_clause (p2430 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (50, false) :=
    use_clause (p2203 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (88, true) :=
    use_clause (p41 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        True.intro⟩
  have h10 : LitSat F.assign (6, false) :=
    use_clause (p2078 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h11 : LitSat F.assign (17, true) :=
    use_clause (p12 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h12 : LitSat F.assign (9, false) :=
    use_clause (p1824 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h13 : LitSat F.assign (20, true) :=
    use_clause (p48 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h14 : LitSat F.assign (18, false) :=
    use_clause (p1642 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h15 : LitSat F.assign (29, true) :=
    use_clause (p36 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h16 : LitSat F.assign (27, false) :=
    use_clause (p1674 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h17 : LitSat F.assign (5, false) :=
    use_clause (p2693 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
def c3072 : CNF.Clause Nat := [(86, true), (17, false), (50, true), (32, true), (30, true), (8, true), (75, true), (76, true), (87, false), (38, false), (39, false), (74, true), (98, true)]
theorem p3072 (F : Frame G 3) : c3072.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (8, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have n12 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))))
  have h0 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n11 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p41 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (21, true) :=
    use_clause (p213 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n12 h),
        True.intro⟩
  have h3 : LitSat F.assign (10, true) :=
    use_clause (p216 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n12 h),
        True.intro⟩
  have h4 : LitSat F.assign (29, false) :=
    use_clause (p1854 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (18, true) :=
    use_clause (p36 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (20, false) :=
    use_clause (p1642 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h7 : LitSat F.assign (9, false) :=
    use_clause (p1835 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p48 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n12 h),
        True.intro⟩
def c3073 : CNF.Clause Nat := [(86, false), (50, true), (32, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3073 (F : Frame G 3) : c3073.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p3051 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (76, false) :=
    use_clause (p1689 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (75, false) :=
    use_clause (p3070 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (21, false) :=
    use_clause (p3014 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (10, false) :=
    use_clause (p1786 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p66 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
def c3074 : CNF.Clause Nat := [(5, false), (6, false), (10, false), (88, false), (86, true), (50, true), (75, true), (76, true), (87, false), (38, false), (39, false), (74, true), (98, true)]
theorem p3074 (F : Frame G 3) : c3074.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have n12 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))))
  have h0 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n11 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (9, false) :=
    use_clause (p1621 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n12 h),
        True.intro⟩
  have h2 : LitSat F.assign (20, true) :=
    use_clause (p48 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n12 h),
        True.intro⟩
  have h3 : LitSat F.assign (29, false) :=
    use_clause (p1841 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (18, false) :=
    use_clause (p1842 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p36 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
def c3075 : CNF.Clause Nat := [(29, false), (6, false), (88, false), (86, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3075 (F : Frame G 3) : c3075.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (75, false) :=
    use_clause (p3070 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p3051 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (20, false) :=
    use_clause (p2605 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (9, false) :=
    use_clause (p2654 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p48 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3076 : CNF.Clause Nat := [(50, true), (30, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3076 (F : Frame G 3) : c3076.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (32, false) :=
    use_clause (p3071 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p3051 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (76, false) :=
    use_clause (p1689 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (75, false) :=
    use_clause (p3070 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (8, false) :=
    use_clause (p2466 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (86, false) :=
    use_clause (p3073 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (88, true) :=
    use_clause (p41 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        True.intro⟩
  have h10 : LitSat F.assign (10, true) :=
    use_clause (p216 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h11 : LitSat F.assign (17, false) :=
    use_clause (p3072 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h12 : LitSat F.assign (6, true) :=
    use_clause (p12 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h13 : LitSat F.assign (5, false) :=
    use_clause (p3074 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h14 : LitSat F.assign (27, true) :=
    use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h15 : LitSat F.assign (29, false) :=
    use_clause (p3075 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h16 : LitSat F.assign (18, true) :=
    use_clause (p36 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h17 : LitSat F.assign (9, false) :=
    use_clause (p2542 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h18 : LitSat F.assign (20, false) :=
    use_clause (p1850 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p48 F)
      ⟨fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
def c3077 : CNF.Clause Nat := [(30, true), (38, false), (39, false), (99, false), (110, false)]
theorem p3077 (F : Frame G 3) : c3077.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (87, true) :=
    use_clause (p3051 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (76, false) :=
    use_clause (p1689 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (75, false) :=
    use_clause (p3070 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (8, false) :=
    use_clause (p2466 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (32, false) :=
    use_clause (p3071 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (50, true) :=
    use_clause (p3076 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (29, false) :=
    use_clause (p2497 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h10 : LitSat F.assign (18, true) :=
    use_clause (p36 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h11 : LitSat F.assign (86, false) :=
    use_clause (p2481 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h12 : LitSat F.assign (88, true) :=
    use_clause (p41 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        True.intro⟩
  have h13 : LitSat F.assign (21, true) :=
    use_clause (p213 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h14 : LitSat F.assign (10, true) :=
    use_clause (p216 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h15 : LitSat F.assign (20, false) :=
    use_clause (p1937 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
  have h16 : LitSat F.assign (9, false) :=
    use_clause (p1835 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
  exact use_clause (p48 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3078 : CNF.Clause Nat := [(50, false), (21, false), (38, false), (39, false), (99, false), (110, false)]
theorem p3078 (F : Frame G 3) : c3078.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p3051 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (76, false) :=
    use_clause (p1689 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (75, false) :=
    use_clause (p3070 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (30, true) :=
    use_clause (p3077 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (5, false) :=
    use_clause (p2194 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h7 : LitSat F.assign (6, false) :=
    use_clause (p2656 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h8 : LitSat F.assign (29, false) :=
    use_clause (p2497 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (15, false) :=
    use_clause (p2655 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h10 : LitSat F.assign (18, true) :=
    use_clause (p36 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h11 : LitSat F.assign (27, false) :=
    use_clause (p2567 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h12 : LitSat F.assign (26, true) :=
    use_clause (p18 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h13 : LitSat F.assign (17, true) :=
    use_clause (p28 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p2571 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3079 : CNF.Clause Nat := [(21, false), (38, false), (39, false), (99, false), (110, false)]
theorem p3079 (F : Frame G 3) : c3079.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (87, true) :=
    use_clause (p3051 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (76, false) :=
    use_clause (p1689 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (75, false) :=
    use_clause (p3070 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (30, true) :=
    use_clause (p3077 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (6, false) :=
    use_clause (p2656 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (86, false) :=
    use_clause (p2687 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (5, false) :=
    use_clause (p2194 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h10 : LitSat F.assign (50, false) :=
    use_clause (p3078 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (17, true) :=
    use_clause (p12 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  have h12 : LitSat F.assign (27, true) :=
    use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  have h13 : LitSat F.assign (9, false) :=
    use_clause (p1822 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h14 : LitSat F.assign (29, false) :=
    use_clause (p1672 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h15 : LitSat F.assign (20, true) :=
    use_clause (p48 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h16 : LitSat F.assign (18, true) :=
    use_clause (p36 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p1642 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
def c3080 : CNF.Clause Nat := [(38, false), (39, false), (99, false), (110, false)]
theorem p3080 (F : Frame G 3) : c3080.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p3051 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (76, false) :=
    use_clause (p1689 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (75, false) :=
    use_clause (p3070 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (8, false) :=
    use_clause (p2466 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h7 : LitSat F.assign (30, true) :=
    use_clause (p3077 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (6, false) :=
    use_clause (p2656 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h9 : LitSat F.assign (10, false) :=
    use_clause (p2659 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        True.intro⟩
  have h10 : LitSat F.assign (21, false) :=
    use_clause (p3079 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h11 : LitSat F.assign (32, true) :=
    use_clause (p66 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h12 : LitSat F.assign (86, false) :=
    use_clause (p2430 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h13 : LitSat F.assign (50, false) :=
    use_clause (p2203 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h14 : LitSat F.assign (88, true) :=
    use_clause (p199 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h15 : LitSat F.assign (17, true) :=
    use_clause (p12 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
  have h16 : LitSat F.assign (9, false) :=
    use_clause (p1824 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h17 : LitSat F.assign (20, true) :=
    use_clause (p48 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h18 : LitSat F.assign (18, false) :=
    use_clause (p1642 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
  have h19 : LitSat F.assign (29, true) :=
    use_clause (p36 F)
      ⟨fun h => False.elim (unit_incompatible h18 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h20 : LitSat F.assign (27, false) :=
    use_clause (p1674 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h21 : LitSat F.assign (5, false) :=
    use_clause (p2693 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h21 h),
        fun h => False.elim (unit_incompatible h20 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
def c3081 : CNF.Clause Nat := [(87, false), (30, false), (75, true), (39, false), (99, false), (110, false)]
theorem p3081 (F : Frame G 3) : c3081.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, false) :=
    use_clause (p2573 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (29, false) :=
    use_clause (p2497 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (18, true) :=
    use_clause (p36 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (32, false) :=
    use_clause (p2203 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h9 : LitSat F.assign (10, false) :=
    use_clause (p2378 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h10 : LitSat F.assign (5, false) :=
    use_clause (p2690 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h11 : LitSat F.assign (21, true) :=
    use_clause (p66 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h12 : LitSat F.assign (27, true) :=
    use_clause (p11 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2567 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c3082 : CNF.Clause Nat := [(18, false), (21, false), (76, true), (30, false), (75, true), (39, false), (99, false), (110, false)]
theorem p3082 (F : Frame G 3) : c3082.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p2770 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (87, false) :=
    use_clause (p3081 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h7 : LitSat F.assign (5, false) :=
    use_clause (p2690 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h8 : LitSat F.assign (20, false) :=
    use_clause (p1652 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h9 : LitSat F.assign (27, true) :=
    use_clause (p11 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (9, true) :=
    use_clause (p48 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  exact use_clause (p2689 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
def c3083 : CNF.Clause Nat := [(76, true), (32, true), (30, false), (75, true), (39, false), (99, false), (110, false)]
theorem p3083 (F : Frame G 3) : c3083.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (87, false) :=
    use_clause (p3081 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (21, true) :=
    use_clause (p52 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (86, false) :=
    use_clause (p2770 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (18, false) :=
    use_clause (p3082 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h9 : LitSat F.assign (29, true) :=
    use_clause (p36 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h10 : LitSat F.assign (9, false) :=
    use_clause (p2515 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h11 : LitSat F.assign (20, true) :=
    use_clause (p48 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h12 : LitSat F.assign (5, false) :=
    use_clause (p2495 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h13 : LitSat F.assign (15, false) :=
    use_clause (p1632 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h14 : LitSat F.assign (27, true) :=
    use_clause (p11 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h15 : LitSat F.assign (26, true) :=
    use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p1658 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
def c3084 : CNF.Clause Nat := [(21, false), (18, true), (32, true), (30, false), (75, true), (39, false), (99, false), (110, false)]
theorem p3084 (F : Frame G 3) : c3084.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (18, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (76, true) :=
    use_clause (p3083 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, false) :=
    use_clause (p3081 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (5, false) :=
    use_clause (p2342 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (27, true) :=
    use_clause (p11 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h8 : LitSat F.assign (86, false) :=
    use_clause (p2579 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h9 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h10 : LitSat F.assign (29, false) :=
    use_clause (p2190 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (9, false) :=
    use_clause (p1999 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h12 : LitSat F.assign (10, true) :=
    use_clause (p148 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h13 : LitSat F.assign (77, true) :=
    use_clause (p35 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h14 : LitSat F.assign (20, true) :=
    use_clause (p48 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p2343 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c3085 : CNF.Clause Nat := [(18, true), (32, true), (30, false), (75, true), (39, false), (99, false), (110, false)]
theorem p3085 (F : Frame G 3) : c3085.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (76, true) :=
    use_clause (p3083 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, false) :=
    use_clause (p3081 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (21, false) :=
    use_clause (p3084 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (10, true) :=
    use_clause (p64 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (29, true) :=
    use_clause (p145 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h9 : LitSat F.assign (88, false) :=
    use_clause (p2190 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (86, false) :=
    use_clause (p2562 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  exact use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
def c3086 : CNF.Clause Nat := [(32, true), (30, false), (75, true), (39, false), (99, false), (110, false)]
theorem p3086 (F : Frame G 3) : c3086.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (87, false) :=
    use_clause (p3081 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, true) :=
    use_clause (p3083 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (18, true) :=
    use_clause (p3085 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (5, false) :=
    use_clause (p2690 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (27, true) :=
    use_clause (p11 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h8 : LitSat F.assign (86, false) :=
    use_clause (p2579 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (88, false) :=
    use_clause (p2344 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
def c3087 : CNF.Clause Nat := [(76, false), (30, false), (75, true), (39, false), (99, false), (110, false)]
theorem p3087 (F : Frame G 3) : c3087.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (32, true) :=
    use_clause (p3086 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, false) :=
    use_clause (p3081 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, false) :=
    use_clause (p2694 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (77, false) :=
    use_clause (p2442 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (27, false) :=
    use_clause (p2579 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (29, false) :=
    use_clause (p2715 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h10 : LitSat F.assign (5, true) :=
    use_clause (p11 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h11 : LitSat F.assign (18, true) :=
    use_clause (p35 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  exact use_clause (p2690 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3088 : CNF.Clause Nat := [(30, false), (75, true), (39, false), (99, false), (110, false)]
theorem p3088 (F : Frame G 3) : c3088.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, false) :=
    use_clause (p3081 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (32, true) :=
    use_clause (p3086 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (76, false) :=
    use_clause (p3087 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (86, false) :=
    use_clause (p2442 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        True.intro⟩
  have h10 : LitSat F.assign (29, false) :=
    use_clause (p1682 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h11 : LitSat F.assign (18, true) :=
    use_clause (p36 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h12 : LitSat F.assign (10, false) :=
    use_clause (p2331 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h13 : LitSat F.assign (21, false) :=
    use_clause (p3082 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p61 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c3089 : CNF.Clause Nat := [(77, false), (32, false), (87, true), (30, true), (39, false), (99, false), (110, false)]
theorem p3089 (F : Frame G 3) : c3089.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p2442 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (8, false) :=
    use_clause (p2338 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p42 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c3090 : CNF.Clause Nat := [(32, false), (87, true), (75, true), (39, false), (99, false), (110, false)]
theorem p3090 (F : Frame G 3) : c3090.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (30, false) :=
    use_clause (p3088 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (77, false) :=
    use_clause (p3089 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (76, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (8, false) :=
    use_clause (p2350 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (86, true) :=
    use_clause (p42 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h8 : LitSat F.assign (88, true) :=
    use_clause (p40 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p1986 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
def c3091 : CNF.Clause Nat := [(88, false), (77, true), (86, false), (76, false), (87, true), (75, true), (39, false), (99, false), (110, false)]
theorem p3091 (F : Frame G 3) : c3091.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (27, false) :=
    use_clause (p2579 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (5, true) :=
    use_clause (p11 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (32, false) :=
    use_clause (p3090 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h7 : LitSat F.assign (29, false) :=
    use_clause (p2190 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (15, false) :=
    use_clause (p2633 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (18, true) :=
    use_clause (p35 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h10 : LitSat F.assign (10, true) :=
    use_clause (p121 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h11 : LitSat F.assign (26, true) :=
    use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2341 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        True.intro⟩
def c3092 : CNF.Clause Nat := [(77, true), (86, false), (76, false), (87, true), (75, true), (39, false), (99, false), (110, false)]
theorem p3092 (F : Frame G 3) : c3092.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (27, false) :=
    use_clause (p2579 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (5, true) :=
    use_clause (p11 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (33, false) :=
    use_clause (p2623 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h5 : LitSat F.assign (32, false) :=
    use_clause (p3090 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (30, false) :=
    use_clause (p3088 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h7 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h8 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h9 : LitSat F.assign (88, false) :=
    use_clause (p3091 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h10 : LitSat F.assign (8, true) :=
    use_clause (p40 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h11 : LitSat F.assign (15, false) :=
    use_clause (p2606 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h12 : LitSat F.assign (11, false) :=
    use_clause (p1595 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h13 : LitSat F.assign (26, true) :=
    use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (22, true) :=
    use_clause (p88 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h15 : LitSat F.assign (10, true) :=
    use_clause (p313 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h16 : LitSat F.assign (18, false) :=
    use_clause (p2304 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h17 : LitSat F.assign (29, false) :=
    use_clause (p2780 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p35 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
def c3093 : CNF.Clause Nat := [(8, false), (18, false), (10, false), (86, false), (76, false), (39, false), (99, false), (110, false)]
theorem p3093 (F : Frame G 3) : c3093.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (15, false) :=
    use_clause (p2606 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (26, false) :=
    use_clause (p2304 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  exact use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3094 : CNF.Clause Nat := [(86, false), (76, false), (87, true), (75, true), (39, false), (99, false), (110, false)]
theorem p3094 (F : Frame G 3) : c3094.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (32, false) :=
    use_clause (p3090 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (30, false) :=
    use_clause (p3088 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (27, false) :=
    use_clause (p2579 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (5, true) :=
    use_clause (p11 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h8 : LitSat F.assign (77, true) :=
    use_clause (p3092 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h9 : LitSat F.assign (21, false) :=
    use_clause (p1752 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h10 : LitSat F.assign (10, true) :=
    use_clause (p64 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h11 : LitSat F.assign (29, false) :=
    use_clause (p2562 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h12 : LitSat F.assign (18, true) :=
    use_clause (p145 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h13 : LitSat F.assign (8, false) :=
    use_clause (p3093 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h14 : LitSat F.assign (88, true) :=
    use_clause (p40 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h15 : LitSat F.assign (15, false) :=
    use_clause (p2633 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h16 : LitSat F.assign (26, false) :=
    use_clause (p2341 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3095 : CNF.Clause Nat := [(18, false), (8, false), (88, false), (86, true), (76, false), (75, true), (38, true), (39, false), (74, true), (98, true), (99, false)]
theorem p3095 (F : Frame G 3) : c3095.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (27, false) :=
    use_clause (p2344 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n10 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (5, true) :=
    use_clause (p11 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (9, false) :=
    use_clause (p1593 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (20, true) :=
    use_clause (p48 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h5 : LitSat F.assign (26, false) :=
    use_clause (p1139 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (15, false) :=
    use_clause (p1627 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c3096 : CNF.Clause Nat := [(76, false), (87, true), (75, true), (39, false), (99, false), (110, false)]
theorem p3096 (F : Frame G 3) : c3096.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (32, false) :=
    use_clause (p3090 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (30, false) :=
    use_clause (p3088 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, false) :=
    use_clause (p3094 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (8, true) :=
    use_clause (p42 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (29, false) :=
    use_clause (p2190 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h10 : LitSat F.assign (18, false) :=
    use_clause (p3095 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (77, true) :=
    use_clause (p35 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h12 : LitSat F.assign (10, true) :=
    use_clause (p148 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h13 : LitSat F.assign (21, true) :=
    use_clause (p145 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h14 : LitSat F.assign (27, false) :=
    use_clause (p2569 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
  have h15 : LitSat F.assign (5, true) :=
    use_clause (p11 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h16 : LitSat F.assign (9, false) :=
    use_clause (p1593 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h17 : LitSat F.assign (20, true) :=
    use_clause (p48 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h18 : LitSat F.assign (15, false) :=
    use_clause (p1632 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h19 : LitSat F.assign (26, false) :=
    use_clause (p2717 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h17 h),
        True.intro⟩
  exact use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3097 : CNF.Clause Nat := [(8, false), (10, false), (21, false), (77, false), (76, true), (87, true), (38, true), (39, false), (74, true), (99, false)]
theorem p3097 (F : Frame G 3) : c3097.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (5, false) :=
    use_clause (p1594 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (27, false) :=
    use_clause (p2569 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p11 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c3098 : CNF.Clause Nat := [(87, true), (75, true), (39, false), (99, false), (110, false)]
theorem p3098 (F : Frame G 3) : c3098.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (30, false) :=
    use_clause (p3088 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (32, false) :=
    use_clause (p3090 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (76, false) :=
    use_clause (p3096 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (21, true) :=
    use_clause (p52 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h9 : LitSat F.assign (10, true) :=
    use_clause (p57 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h10 : LitSat F.assign (8, false) :=
    use_clause (p3097 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h11 : LitSat F.assign (86, true) :=
    use_clause (p42 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h12 : LitSat F.assign (27, false) :=
    use_clause (p2240 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h13 : LitSat F.assign (29, false) :=
    use_clause (p2562 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h14 : LitSat F.assign (5, true) :=
    use_clause (p11 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h15 : LitSat F.assign (18, true) :=
    use_clause (p36 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h16 : LitSat F.assign (26, false) :=
    use_clause (p2431 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h17 : LitSat F.assign (15, false) :=
    use_clause (p1628 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3099 : CNF.Clause Nat := [(86, false), (75, true), (39, false), (99, false), (110, false)]
theorem p3099 (F : Frame G 3) : c3099.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p3098 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (76, false) :=
    use_clause (p2573 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (29, false) :=
    use_clause (p2497 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (18, true) :=
    use_clause (p36 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (5, false) :=
    use_clause (p2196 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h9 : LitSat F.assign (27, true) :=
    use_clause (p11 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (17, false) :=
    use_clause (p2568 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h11 : LitSat F.assign (6, false) :=
    use_clause (p2675 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h12 : LitSat F.assign (15, false) :=
    use_clause (p2460 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p20 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
def c3100 : CNF.Clause Nat := [(5, true), (18, false), (77, false), (87, false), (38, true), (99, false), (110, false)]
theorem p3100 (F : Frame G 3) : c3100.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (5, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (27, true) :=
    use_clause (p11 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (17, false) :=
    use_clause (p2568 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (6, false) :=
    use_clause (p2675 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p25 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3101 : CNF.Clause Nat := [(9, false), (5, false), (86, true), (32, true), (76, true), (87, false), (30, true), (75, true), (38, true), (74, true), (98, true)]
theorem p3101 (F : Frame G 3) : c3101.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (8, false) :=
    use_clause (p1593 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (10, false) :=
    use_clause (p1596 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  exact use_clause (p216 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n10 h),
        True.intro⟩
def c3102 : CNF.Clause Nat := [(75, true), (39, false), (99, false), (110, false)]
theorem p3102 (F : Frame G 3) : c3102.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (30, false) :=
    use_clause (p3088 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, true) :=
    use_clause (p3098 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (76, false) :=
    use_clause (p2573 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (29, false) :=
    use_clause (p2497 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (18, true) :=
    use_clause (p36 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h10 : LitSat F.assign (32, false) :=
    use_clause (p2203 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h11 : LitSat F.assign (86, false) :=
    use_clause (p3099 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h12 : LitSat F.assign (5, true) :=
    use_clause (p3100 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h13 : LitSat F.assign (9, false) :=
    use_clause (p3101 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h14 : LitSat F.assign (20, true) :=
    use_clause (p48 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h15 : LitSat F.assign (15, false) :=
    use_clause (p1627 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h16 : LitSat F.assign (26, false) :=
    use_clause (p2303 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3103 : CNF.Clause Nat := [(20, false), (5, false), (87, false), (39, false), (99, false), (110, false)]
theorem p3103 (F : Frame G 3) : c3103.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (20, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (75, true) :=
    use_clause (p3102 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (76, false) :=
    use_clause (p2573 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (29, false) :=
    use_clause (p2497 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (18, false) :=
    use_clause (p1703 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (77, true) :=
    use_clause (p34 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (22, false) :=
    use_clause (p1819 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (11, false) :=
    use_clause (p1820 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h10 : LitSat F.assign (26, false) :=
    use_clause (p2471 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h11 : LitSat F.assign (33, false) :=
    use_clause (p1817 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h12 : LitSat F.assign (15, true) :=
    use_clause (p9 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (88, true) :=
    use_clause (p173 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p2445 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c3104 : CNF.Clause Nat := [(86, true), (5, false), (87, false), (39, false), (99, false), (110, false)]
theorem p3104 (F : Frame G 3) : c3104.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (20, false) :=
    use_clause (p3103 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (75, true) :=
    use_clause (p3102 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, false) :=
    use_clause (p2573 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (29, false) :=
    use_clause (p2497 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (18, false) :=
    use_clause (p1703 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (77, true) :=
    use_clause (p34 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (22, false) :=
    use_clause (p1819 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h10 : LitSat F.assign (11, false) :=
    use_clause (p1820 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h11 : LitSat F.assign (30, false) :=
    use_clause (p2504 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h12 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h13 : LitSat F.assign (9, true) :=
    use_clause (p114 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
  have h14 : LitSat F.assign (26, false) :=
    use_clause (p2451 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        True.intro⟩
  have h15 : LitSat F.assign (15, true) :=
    use_clause (p9 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h16 : LitSat F.assign (88, false) :=
    use_clause (p2445 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h17 : LitSat F.assign (8, true) :=
    use_clause (p41 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h16 h),
        True.intro⟩
  have h18 : LitSat F.assign (33, true) :=
    use_clause (p173 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h16 h),
        True.intro⟩
  exact use_clause (p2229 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c3105 : CNF.Clause Nat := [(5, false), (87, false), (39, false), (99, false), (110, false)]
theorem p3105 (F : Frame G 3) : c3105.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (29, false) :=
    use_clause (p2497 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (76, false) :=
    use_clause (p2573 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (75, true) :=
    use_clause (p3102 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (18, false) :=
    use_clause (p1703 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (77, true) :=
    use_clause (p34 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (11, false) :=
    use_clause (p1820 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (22, false) :=
    use_clause (p1819 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h10 : LitSat F.assign (86, true) :=
    use_clause (p3104 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (33, false) :=
    use_clause (p2004 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h12 : LitSat F.assign (88, true) :=
    use_clause (p173 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        True.intro⟩
  have h13 : LitSat F.assign (26, false) :=
    use_clause (p2444 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h14 : LitSat F.assign (15, false) :=
    use_clause (p2584 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3106 : CNF.Clause Nat := [(87, false), (39, false), (99, false), (110, false)]
theorem p3106 (F : Frame G 3) : c3106.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (75, true) :=
    use_clause (p3102 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (76, false) :=
    use_clause (p2573 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (29, false) :=
    use_clause (p2497 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (5, false) :=
    use_clause (p3105 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (27, true) :=
    use_clause (p11 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (20, false) :=
    use_clause (p2777 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (26, false) :=
    use_clause (p2510 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h11 : LitSat F.assign (18, false) :=
    use_clause (p1705 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h12 : LitSat F.assign (15, true) :=
    use_clause (p9 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h13 : LitSat F.assign (77, true) :=
    use_clause (p34 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        True.intro⟩
  have h14 : LitSat F.assign (86, false) :=
    use_clause (p2460 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h15 : LitSat F.assign (10, false) :=
    use_clause (p2449 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h16 : LitSat F.assign (32, false) :=
    use_clause (p2203 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h17 : LitSat F.assign (9, true) :=
    use_clause (p114 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h18 : LitSat F.assign (21, true) :=
    use_clause (p66 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p2452 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h18 h),
        True.intro⟩
def c3107 : CNF.Clause Nat := [(88, false), (15, false), (76, true), (77, false), (5, true), (87, true), (75, false), (38, true), (39, false), (98, true), (110, false)]
theorem p3107 (F : Frame G 3) : c3107.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (5, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (27, true) :=
    use_clause (p11 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (17, false) :=
    use_clause (p2634 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h3 : LitSat F.assign (10, false) :=
    use_clause (p2718 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n10 h),
        fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (6, true) :=
    use_clause (p25 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (21, true) :=
    use_clause (p61 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  exact use_clause (p1866 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
def c3108 : CNF.Clause Nat := [(86, false), (76, true), (77, false), (27, false), (39, false), (99, false), (110, false)]
theorem p3108 (F : Frame G 3) : c3108.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (27, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (87, false) :=
    use_clause (p3106 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (32, false) :=
    use_clause (p2442 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h5 : LitSat F.assign (21, false) :=
    use_clause (p2240 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p52 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c3109 : CNF.Clause Nat := [(76, true), (77, false), (5, true), (39, false), (99, false), (110, false)]
theorem p3109 (F : Frame G 3) : c3109.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (5, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (27, true) :=
    use_clause (p11 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, false) :=
    use_clause (p3106 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (75, true) :=
    use_clause (p3102 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (86, false) :=
    use_clause (p3108 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (17, false) :=
    use_clause (p2634 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h10 : LitSat F.assign (15, false) :=
    use_clause (p3107 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h11 : LitSat F.assign (6, true) :=
    use_clause (p25 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h12 : LitSat F.assign (26, true) :=
    use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (21, false) :=
    use_clause (p1866 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        True.intro⟩
  have h14 : LitSat F.assign (32, true) :=
    use_clause (p52 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h15 : LitSat F.assign (30, true) :=
    use_clause (p3089 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p1660 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3110 : CNF.Clause Nat := [(76, false), (27, false), (87, true), (75, false), (50, false), (39, false), (74, true), (110, false)]
theorem p3110 (F : Frame G 3) : c3110.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (27, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (8, false) :=
    use_clause (p2778 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (30, false) :=
    use_clause (p1696 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p2579 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p42 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c3111 : CNF.Clause Nat := [(8, false), (76, true), (27, false), (87, true), (75, false), (50, false), (39, false), (98, true), (110, false)]
theorem p3111 (F : Frame G 3) : c3111.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (27, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (32, false) :=
    use_clause (p2531 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n8 h),
        True.intro⟩
  have h1 : LitSat F.assign (21, false) :=
    use_clause (p2774 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n8 h),
        True.intro⟩
  exact use_clause (p52 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        True.intro⟩
def c3112 : CNF.Clause Nat := [(21, true), (30, false), (88, false), (86, true), (76, true), (27, false), (87, true), (75, false), (38, true), (39, false), (98, true), (110, false)]
theorem p3112 (F : Frame G 3) : c3112.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (27, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n8 h),
        fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (32, true) :=
    use_clause (p52 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h2 : LitSat F.assign (10, true) :=
    use_clause (p61 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h3 : LitSat F.assign (26, false) :=
    use_clause (p1660 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h4 : LitSat F.assign (15, false) :=
    use_clause (p2718 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n8 h),
        True.intro⟩
def c3113 : CNF.Clause Nat := [(86, true), (5, true), (39, false), (99, false), (110, false)]
theorem p3113 (F : Frame G 3) : c3113.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (5, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (75, true) :=
    use_clause (p3102 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, false) :=
    use_clause (p3106 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (27, true) :=
    use_clause (p11 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h6 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (76, false) :=
    use_clause (p3110 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (8, false) :=
    use_clause (p3111 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (77, false) :=
    use_clause (p3109 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h10 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        True.intro⟩
  have h11 : LitSat F.assign (30, true) :=
    use_clause (p42 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h12 : LitSat F.assign (21, true) :=
    use_clause (p3112 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h13 : LitSat F.assign (18, false) :=
    use_clause (p2517 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h14 : LitSat F.assign (29, false) :=
    use_clause (p2516 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
  exact use_clause (p34 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
def c3114 : CNF.Clause Nat := [(30, false), (5, true), (39, false), (99, false), (110, false)]
theorem p3114 (F : Frame G 3) : c3114.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (5, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (86, true) :=
    use_clause (p3113 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (75, true) :=
    use_clause (p3102 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, false) :=
    use_clause (p3106 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (27, true) :=
    use_clause (p11 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h7 : LitSat F.assign (76, false) :=
    use_clause (p3110 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (77, false) :=
    use_clause (p3109 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h10 : LitSat F.assign (32, false) :=
    use_clause (p2503 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (21, true) :=
    use_clause (p52 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h12 : LitSat F.assign (10, true) :=
    use_clause (p57 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h13 : LitSat F.assign (17, false) :=
    use_clause (p2514 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h14 : LitSat F.assign (29, false) :=
    use_clause (p2562 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h15 : LitSat F.assign (6, true) :=
    use_clause (p25 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
  have h16 : LitSat F.assign (18, true) :=
    use_clause (p34 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h17 : LitSat F.assign (26, false) :=
    use_clause (p1708 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h18 : LitSat F.assign (15, false) :=
    use_clause (p1628 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3115 : CNF.Clause Nat := [(5, true), (39, false), (99, false), (110, false)]
theorem p3115 (F : Frame G 3) : c3115.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (5, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (87, false) :=
    use_clause (p3106 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (75, true) :=
    use_clause (p3102 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (27, true) :=
    use_clause (p11 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h7 : LitSat F.assign (76, false) :=
    use_clause (p3110 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (77, false) :=
    use_clause (p3109 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (8, false) :=
    use_clause (p3111 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (86, true) :=
    use_clause (p3113 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h11 : LitSat F.assign (30, false) :=
    use_clause (p3114 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h12 : LitSat F.assign (88, true) :=
    use_clause (p40 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h13 : LitSat F.assign (15, false) :=
    use_clause (p2584 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h14 : LitSat F.assign (17, false) :=
    use_clause (p2634 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h15 : LitSat F.assign (26, true) :=
    use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h16 : LitSat F.assign (6, true) :=
    use_clause (p20 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        True.intro⟩
  have h17 : LitSat F.assign (21, false) :=
    use_clause (p1708 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h18 : LitSat F.assign (32, true) :=
    use_clause (p52 F)
      ⟨fun h => False.elim (unit_incompatible h17 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h19 : LitSat F.assign (18, false) :=
    use_clause (p2529 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h20 : LitSat F.assign (29, false) :=
    use_clause (p2715 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p34 F)
      ⟨fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h20 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
def c3116 : CNF.Clause Nat := [(21, false), (86, false), (76, true), (5, false), (87, true), (75, false), (38, true), (39, false), (74, true), (110, false)]
theorem p3116 (F : Frame G 3) : c3116.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (26, false) :=
    use_clause (p2501 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h2 : LitSat F.assign (30, false) :=
    use_clause (p2502 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h3 : LitSat F.assign (29, false) :=
    use_clause (p2619 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h4 : LitSat F.assign (15, true) :=
    use_clause (p9 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (18, false) :=
    use_clause (p1628 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (88, false) :=
    use_clause (p2584 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n9 h),
        True.intro⟩
  have h7 : LitSat F.assign (77, true) :=
    use_clause (p34 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (8, true) :=
    use_clause (p40 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  exact use_clause (p2526 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n9 h),
        True.intro⟩
def c3117 : CNF.Clause Nat := [(86, false), (76, true), (39, false), (99, false), (110, false)]
theorem p3117 (F : Frame G 3) : c3117.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (5, true) :=
    use_clause (p3115 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, false) :=
    use_clause (p3106 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (75, true) :=
    use_clause (p3102 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (21, false) :=
    use_clause (p3116 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (32, true) :=
    use_clause (p52 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h9 : LitSat F.assign (10, true) :=
    use_clause (p61 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h10 : LitSat F.assign (8, false) :=
    use_clause (p2531 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (30, false) :=
    use_clause (p2503 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h12 : LitSat F.assign (77, false) :=
    use_clause (p3089 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h13 : LitSat F.assign (29, false) :=
    use_clause (p2715 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h14 : LitSat F.assign (88, true) :=
    use_clause (p40 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h15 : LitSat F.assign (18, true) :=
    use_clause (p34 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
  exact use_clause (p2666 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h14 h),
        True.intro⟩
def c3118 : CNF.Clause Nat := [(21, true), (76, true), (39, false), (99, false), (110, false)]
theorem p3118 (F : Frame G 3) : c3118.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (87, false) :=
    use_clause (p3106 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p3117 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (5, true) :=
    use_clause (p3115 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (75, true) :=
    use_clause (p3102 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (32, true) :=
    use_clause (p52 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h10 : LitSat F.assign (10, true) :=
    use_clause (p61 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h11 : LitSat F.assign (8, false) :=
    use_clause (p2531 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h12 : LitSat F.assign (18, false) :=
    use_clause (p1864 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h13 : LitSat F.assign (30, true) :=
    use_clause (p42 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (77, false) :=
    use_clause (p2346 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h15 : LitSat F.assign (29, true) :=
    use_clause (p34 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h14 h),
        True.intro⟩
  have h16 : LitSat F.assign (9, false) :=
    use_clause (p2515 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h17 : LitSat F.assign (20, false) :=
    use_clause (p1863 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p107 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
def c3119 : CNF.Clause Nat := [(76, true), (39, false), (99, false), (110, false)]
theorem p3119 (F : Frame G 3) : c3119.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (5, true) :=
    use_clause (p3115 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, false) :=
    use_clause (p3106 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (75, true) :=
    use_clause (p3102 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (86, false) :=
    use_clause (p3117 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (21, true) :=
    use_clause (p3118 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (30, false) :=
    use_clause (p2502 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h11 : LitSat F.assign (32, false) :=
    use_clause (p1862 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h12 : LitSat F.assign (8, true) :=
    use_clause (p42 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h13 : LitSat F.assign (10, true) :=
    use_clause (p57 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  exact use_clause (p1594 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3120 : CNF.Clause Nat := [(39, false), (99, false), (110, false)]
theorem p3120 (F : Frame G 3) : c3120.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (38, false) :=
    use_clause (p3080 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (75, true) :=
    use_clause (p3102 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, false) :=
    use_clause (p3106 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (5, true) :=
    use_clause (p3115 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (76, true) :=
    use_clause (p3119 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (8, false) :=
    use_clause (p2778 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (30, false) :=
    use_clause (p1696 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (86, false) :=
    use_clause (p2494 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p42 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3121 : CNF.Clause Nat := [(75, false), (5, false), (86, true), (76, false), (87, true), (99, false), (110, false)]
theorem p3121 (F : Frame G 3) : c3121.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (8, false) :=
    use_clause (p2437 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (26, false) :=
    use_clause (p2745 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (30, true) :=
    use_clause (p42 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h9 : LitSat F.assign (6, false) :=
    use_clause (p1695 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h10 : LitSat F.assign (17, false) :=
    use_clause (p1694 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  exact use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3122 : CNF.Clause Nat := [(30, false), (9, false), (88, false), (76, false), (99, false), (110, false)]
theorem p3122 (F : Frame G 3) : c3122.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (17, false) :=
    use_clause (p2696 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h4 : LitSat F.assign (15, false) :=
    use_clause (p2743 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (6, true) :=
    use_clause (p13 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2291 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c3123 : CNF.Clause Nat := [(32, true), (26, false), (29, true), (21, true), (75, true), (5, false), (88, false), (76, false), (87, true), (50, false), (74, true), (98, true), (99, false)]
theorem p3123 (F : Frame G 3) : c3123.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (26, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (29, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have n12 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))))
  have h0 : LitSat F.assign (10, true) :=
    use_clause (p64 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n11 h),
        True.intro⟩
  have h1 : LitSat F.assign (18, true) :=
    use_clause (p145 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n11 h),
        True.intro⟩
  exact use_clause (p2341 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n12 h),
        True.intro⟩
def c3124 : CNF.Clause Nat := [(32, false), (29, true), (17, false), (8, false), (9, false), (75, true), (5, false), (88, false), (76, false), (50, false), (38, false), (74, true)]
theorem p3124 (F : Frame G 3) : c3124.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (29, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (77, false) :=
    use_clause (p2071 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h1 : LitSat F.assign (18, false) :=
    use_clause (p2698 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p35 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3125 : CNF.Clause Nat := [(5, false), (86, true), (76, false), (87, true), (99, false), (110, false)]
theorem p3125 (F : Frame G 3) : c3125.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (20, false) :=
    use_clause (p2637 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (75, false) :=
    use_clause (p3121 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (9, true) :=
    use_clause (p48 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h9 : LitSat F.assign (21, false) :=
    use_clause (p2263 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h10 : LitSat F.assign (30, false) :=
    use_clause (p3122 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h11 : LitSat F.assign (8, true) :=
    use_clause (p42 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h12 : LitSat F.assign (6, false) :=
    use_clause (p1603 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h13 : LitSat F.assign (17, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (29, false) :=
    use_clause (p2189 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h15 : LitSat F.assign (32, false) :=
    use_clause (p3124 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h16 : LitSat F.assign (10, true) :=
    use_clause (p64 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h17 : LitSat F.assign (18, true) :=
    use_clause (p145 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h18 : LitSat F.assign (26, false) :=
    use_clause (p3123 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h19 : LitSat F.assign (15, false) :=
    use_clause (p2697 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3126 : CNF.Clause Nat := [(32, true), (15, false), (29, true), (8, false), (21, true), (75, true), (88, false), (76, false), (87, true), (50, false), (38, false), (74, true), (98, true), (99, false)]
theorem p3126 (F : Frame G 3) : c3126.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (29, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have n12 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))))
  have n13 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))))
  have h0 : LitSat F.assign (10, true) :=
    use_clause (p64 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n12 h),
        True.intro⟩
  have h1 : LitSat F.assign (18, true) :=
    use_clause (p145 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n12 h),
        True.intro⟩
  exact use_clause (p2697 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n13 h),
        True.intro⟩
def c3127 : CNF.Clause Nat := [(32, false), (17, false), (8, false), (9, false), (75, true), (88, false), (76, false), (50, false), (38, false), (74, true), (99, false)]
theorem p3127 (F : Frame G 3) : c3127.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (29, false) :=
    use_clause (p2189 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n10 h),
        fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (18, false) :=
    use_clause (p2698 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (77, false) :=
    use_clause (p2271 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n10 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p35 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3128 : CNF.Clause Nat := [(75, true), (86, true), (76, false), (87, true), (99, false), (110, false)]
theorem p3128 (F : Frame G 3) : c3128.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (5, false) :=
    use_clause (p3125 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (20, false) :=
    use_clause (p2637 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (9, true) :=
    use_clause (p48 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (21, false) :=
    use_clause (p2263 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h10 : LitSat F.assign (30, false) :=
    use_clause (p3122 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h11 : LitSat F.assign (8, true) :=
    use_clause (p42 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h12 : LitSat F.assign (6, false) :=
    use_clause (p1603 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h13 : LitSat F.assign (17, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h14 : LitSat F.assign (27, true) :=
    use_clause (p27 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h15 : LitSat F.assign (29, false) :=
    use_clause (p2189 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h16 : LitSat F.assign (32, false) :=
    use_clause (p3127 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h17 : LitSat F.assign (77, true) :=
    use_clause (p118 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h18 : LitSat F.assign (15, false) :=
    use_clause (p3126 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h19 : LitSat F.assign (26, false) :=
    use_clause (p2746 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3129 : CNF.Clause Nat := [(86, true), (76, false), (87, true), (99, false), (110, false)]
theorem p3129 (F : Frame G 3) : c3129.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (75, true) :=
    use_clause (p3128 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (8, false) :=
    use_clause (p2437 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (30, true) :=
    use_clause (p42 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (17, false) :=
    use_clause (p2683 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (6, true) :=
    use_clause (p13 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (15, false) :=
    use_clause (p1695 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (26, false) :=
    use_clause (p2291 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3130 : CNF.Clause Nat := [(88, false), (10, false), (75, false), (86, false), (99, false), (110, false)]
theorem p3130 (F : Frame G 3) : c3130.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (15, false) :=
    use_clause (p2584 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (26, false) :=
    use_clause (p2261 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3131 : CNF.Clause Nat := [(75, false), (76, false), (87, true), (99, false), (110, false)]
theorem p3131 (F : Frame G 3) : c3131.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (86, true) :=
    use_clause (p3129 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (22, false) :=
    use_clause (p2622 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (33, false) :=
    use_clause (p2623 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h6 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (8, false) :=
    use_clause (p2437 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (21, false) :=
    use_clause (p2436 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h10 : LitSat F.assign (32, false) :=
    use_clause (p2428 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (10, true) :=
    use_clause (p64 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h12 : LitSat F.assign (88, false) :=
    use_clause (p3130 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h13 : LitSat F.assign (30, true) :=
    use_clause (p40 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
  have h14 : LitSat F.assign (77, true) :=
    use_clause (p280 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
  have h15 : LitSat F.assign (11, true) :=
    use_clause (p287 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
  have h16 : LitSat F.assign (17, false) :=
    use_clause (p2158 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h17 : LitSat F.assign (15, false) :=
    use_clause (p1811 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h18 : LitSat F.assign (6, true) :=
    use_clause (p13 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h19 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h17 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2438 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c3132 : CNF.Clause Nat := [(32, true), (21, true), (88, true), (76, false), (87, true), (99, false), (110, false)]
theorem p3132 (F : Frame G 3) : c3132.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (75, false) :=
    use_clause (p3131 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (86, true) :=
    use_clause (p3129 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (22, false) :=
    use_clause (p2622 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (33, false) :=
    use_clause (p2623 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (18, false) :=
    use_clause (p2481 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h8 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h9 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h10 : LitSat F.assign (29, true) :=
    use_clause (p145 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h11 : LitSat F.assign (11, true) :=
    use_clause (p287 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p2318 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c3133 : CNF.Clause Nat := [(32, false), (17, false), (75, true), (86, false), (76, false), (99, false), (110, false)]
theorem p3133 (F : Frame G 3) : c3133.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (18, false) :=
    use_clause (p2481 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (29, false) :=
    use_clause (p2715 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h6 : LitSat F.assign (77, false) :=
    use_clause (p1749 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p35 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3134 : CNF.Clause Nat := [(21, false), (75, true), (86, false), (76, false), (99, false), (110, false)]
theorem p3134 (F : Frame G 3) : c3134.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (18, false) :=
    use_clause (p2481 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (77, false) :=
    use_clause (p2432 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (29, false) :=
    use_clause (p2180 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p35 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
def c3135 : CNF.Clause Nat := [(32, false), (75, true), (86, false), (76, false), (99, false), (110, false)]
theorem p3135 (F : Frame G 3) : c3135.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (18, false) :=
    use_clause (p2481 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (29, false) :=
    use_clause (p2715 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h6 : LitSat F.assign (17, false) :=
    use_clause (p3133 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (77, true) :=
    use_clause (p35 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (6, true) :=
    use_clause (p13 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1754 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
def c3136 : CNF.Clause Nat := [(76, false), (87, true), (99, false), (110, false)]
theorem p3136 (F : Frame G 3) : c3136.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (86, true) :=
    use_clause (p3129 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (18, false) :=
    use_clause (p2481 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (75, false) :=
    use_clause (p3131 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (21, false) :=
    use_clause (p3134 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (32, false) :=
    use_clause (p3135 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (29, true) :=
    use_clause (p145 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h11 : LitSat F.assign (88, true) :=
    use_clause (p3132 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h12 : LitSat F.assign (17, false) :=
    use_clause (p2189 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h13 : LitSat F.assign (15, false) :=
    use_clause (p2585 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h14 : LitSat F.assign (6, true) :=
    use_clause (p13 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h15 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2438 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c3137 : CNF.Clause Nat := [(86, false), (87, true), (99, false), (110, false)]
theorem p3137 (F : Frame G 3) : c3137.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (76, false) :=
    use_clause (p3136 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (32, false) :=
    use_clause (p2917 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (21, true) :=
    use_clause (p52 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (75, false) :=
    use_clause (p2436 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (77, false) :=
    use_clause (p2432 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
def c3138 : CNF.Clause Nat := [(21, false), (75, true), (87, true), (99, false), (110, false)]
theorem p3138 (F : Frame G 3) : c3138.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (76, false) :=
    use_clause (p3136 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p3137 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (9, false) :=
    use_clause (p2300 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h10 : LitSat F.assign (20, true) :=
    use_clause (p48 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h11 : LitSat F.assign (18, false) :=
    use_clause (p1652 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h12 : LitSat F.assign (29, true) :=
    use_clause (p36 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h13 : LitSat F.assign (8, false) :=
    use_clause (p2272 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h14 : LitSat F.assign (30, true) :=
    use_clause (p42 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h15 : LitSat F.assign (6, false) :=
    use_clause (p2751 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h16 : LitSat F.assign (32, false) :=
    use_clause (p1682 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h17 : LitSat F.assign (17, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h18 : LitSat F.assign (10, true) :=
    use_clause (p57 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  exact use_clause (p2403 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h18 h),
        True.intro⟩
def c3139 : CNF.Clause Nat := [(8, false), (10, false), (32, false), (77, false), (76, true), (87, true), (39, true), (74, true), (99, false)]
theorem p3139 (F : Frame G 3) : c3139.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (6, false) :=
    use_clause (p1604 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (17, false) :=
    use_clause (p2271 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c3140 : CNF.Clause Nat := [(75, true), (87, true), (99, false), (110, false)]
theorem p3140 (F : Frame G 3) : c3140.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p3137 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (76, false) :=
    use_clause (p3136 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (21, false) :=
    use_clause (p3138 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (32, true) :=
    use_clause (p52 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h11 : LitSat F.assign (10, true) :=
    use_clause (p61 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h12 : LitSat F.assign (8, false) :=
    use_clause (p3139 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h13 : LitSat F.assign (30, true) :=
    use_clause (p42 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h14 : LitSat F.assign (29, false) :=
    use_clause (p1682 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h15 : LitSat F.assign (17, false) :=
    use_clause (p2403 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h16 : LitSat F.assign (18, true) :=
    use_clause (p36 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h17 : LitSat F.assign (6, true) :=
    use_clause (p13 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p2270 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
def c3141 : CNF.Clause Nat := [(21, true), (75, false), (88, false), (76, true), (87, true), (39, true), (98, true), (99, false)]
theorem p3141 (F : Frame G 3) : c3141.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (32, true) :=
    use_clause (p52 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (10, true) :=
    use_clause (p61 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (26, false) :=
    use_clause (p2188 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (15, false) :=
    use_clause (p2293 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3142 : CNF.Clause Nat := [(87, true), (99, false), (110, false)]
theorem p3142 (F : Frame G 3) : c3142.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (76, false) :=
    use_clause (p3136 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, false) :=
    use_clause (p3137 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (75, true) :=
    use_clause (p3140 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (21, true) :=
    use_clause (p3141 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h10 : LitSat F.assign (8, false) :=
    use_clause (p2472 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h11 : LitSat F.assign (30, true) :=
    use_clause (p42 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h12 : LitSat F.assign (15, false) :=
    use_clause (p2518 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h13 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (10, false) :=
    use_clause (p2261 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        True.intro⟩
  have h15 : LitSat F.assign (32, false) :=
    use_clause (p2519 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p57 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3143 : CNF.Clause Nat := [(10, true), (32, true), (21, false), (75, false), (86, true), (99, false), (110, false)]
theorem p3143 (F : Frame G 3) : c3143.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (8, false) :=
    use_clause (p2472 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p3142 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (76, false) :=
    use_clause (p2157 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h8 : LitSat F.assign (88, true) :=
    use_clause (p197 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (30, true) :=
    use_clause (p216 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h10 : LitSat F.assign (26, false) :=
    use_clause (p2444 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h11 : LitSat F.assign (15, false) :=
    use_clause (p2518 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3144 : CNF.Clause Nat := [(88, false), (10, false), (75, false), (87, false), (39, true), (99, false)]
theorem p3144 (F : Frame G 3) : c3144.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (26, false) :=
    use_clause (p2444 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (15, false) :=
    use_clause (p1924 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c3145 : CNF.Clause Nat := [(10, false), (21, false), (75, false), (86, true), (99, false), (110, false)]
theorem p3145 (F : Frame G 3) : c3145.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (8, false) :=
    use_clause (p2472 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p3142 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (76, false) :=
    use_clause (p2157 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (88, false) :=
    use_clause (p3144 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (30, true) :=
    use_clause (p41 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (77, false) :=
    use_clause (p2426 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h10 : LitSat F.assign (17, false) :=
    use_clause (p2570 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h11 : LitSat F.assign (6, true) :=
    use_clause (p13 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (29, false) :=
    use_clause (p2496 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h13 : LitSat F.assign (18, false) :=
    use_clause (p2395 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p34 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
def c3146 : CNF.Clause Nat := [(6, false), (77, true), (32, false), (99, false), (110, false)]
theorem p3146 (F : Frame G 3) : c3146.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p3142 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, false) :=
    use_clause (p2157 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (29, false) :=
    use_clause (p2496 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (18, false) :=
    use_clause (p2402 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p34 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c3147 : CNF.Clause Nat := [(88, true), (21, false), (75, false), (86, true), (99, false), (110, false)]
theorem p3147 (F : Frame G 3) : c3147.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p3142 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (10, false) :=
    use_clause (p3145 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (32, true) :=
    use_clause (p3143 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (33, false) :=
    use_clause (p2414 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h6 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (8, false) :=
    use_clause (p2472 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (22, false) :=
    use_clause (p2396 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h9 : LitSat F.assign (76, false) :=
    use_clause (p2157 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h10 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h11 : LitSat F.assign (30, true) :=
    use_clause (p41 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h12 : LitSat F.assign (77, false) :=
    use_clause (p2426 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h13 : LitSat F.assign (11, true) :=
    use_clause (p88 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h14 : LitSat F.assign (6, false) :=
    use_clause (p3146 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h15 : LitSat F.assign (17, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h16 : LitSat F.assign (29, false) :=
    use_clause (p2209 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h17 : LitSat F.assign (18, false) :=
    use_clause (p2394 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p34 F)
      ⟨fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
def c3148 : CNF.Clause Nat := [(21, false), (75, false), (86, true), (99, false), (110, false)]
theorem p3148 (F : Frame G 3) : c3148.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p3142 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, false) :=
    use_clause (p2157 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (10, false) :=
    use_clause (p3145 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (32, true) :=
    use_clause (p3143 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (88, true) :=
    use_clause (p3147 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (26, false) :=
    use_clause (p2444 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h10 : LitSat F.assign (18, false) :=
    use_clause (p1876 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h11 : LitSat F.assign (6, false) :=
    use_clause (p1960 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h12 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (17, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (29, false) :=
    use_clause (p2177 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h15 : LitSat F.assign (77, false) :=
    use_clause (p1953 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  exact use_clause (p34 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h15 h),
        True.intro⟩
def c3149 : CNF.Clause Nat := [(77, true), (32, false), (75, false), (99, false), (110, false)]
theorem p3149 (F : Frame G 3) : c3149.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p3142 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, false) :=
    use_clause (p2157 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (6, false) :=
    use_clause (p3146 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (17, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (27, false) :=
    use_clause (p2759 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (29, false) :=
    use_clause (p2209 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (5, true) :=
    use_clause (p27 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (18, true) :=
    use_clause (p34 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p1703 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c3150 : CNF.Clause Nat := [(17, false), (32, false), (75, false), (86, true), (99, false), (110, false)]
theorem p3150 (F : Frame G 3) : c3150.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (77, true) :=
    use_clause (p3149 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (21, false) :=
    use_clause (p3148 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, true) :=
    use_clause (p3142 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (76, false) :=
    use_clause (p2157 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (88, false) :=
    use_clause (p1953 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h10 : LitSat F.assign (8, false) :=
    use_clause (p2775 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h11 : LitSat F.assign (26, false) :=
    use_clause (p2571 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h12 : LitSat F.assign (30, true) :=
    use_clause (p41 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h13 : LitSat F.assign (10, true) :=
    use_clause (p199 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h14 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p2225 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c3151 : CNF.Clause Nat := [(32, false), (75, false), (86, true), (99, false), (110, false)]
theorem p3151 (F : Frame G 3) : c3151.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (87, true) :=
    use_clause (p3142 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (77, true) :=
    use_clause (p3149 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (17, false) :=
    use_clause (p3150 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (6, true) :=
    use_clause (p13 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h8 : LitSat F.assign (30, false) :=
    use_clause (p2491 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (26, false) :=
    use_clause (p2492 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h10 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h11 : LitSat F.assign (8, false) :=
    use_clause (p2226 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h12 : LitSat F.assign (88, false) :=
    use_clause (p1914 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p41 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
def c3152 : CNF.Clause Nat := [(75, false), (86, true), (99, false), (110, false)]
theorem p3152 (F : Frame G 3) : c3152.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p3142 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, false) :=
    use_clause (p2157 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (21, false) :=
    use_clause (p3148 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (32, false) :=
    use_clause (p3151 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (10, true) :=
    use_clause (p66 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h10 : LitSat F.assign (88, false) :=
    use_clause (p3144 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h11 : LitSat F.assign (30, true) :=
    use_clause (p189 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h12 : LitSat F.assign (15, false) :=
    use_clause (p2225 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h13 : LitSat F.assign (17, false) :=
    use_clause (p2570 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h14 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h15 : LitSat F.assign (6, true) :=
    use_clause (p13 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h16 : LitSat F.assign (29, false) :=
    use_clause (p2496 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h17 : LitSat F.assign (77, false) :=
    use_clause (p2491 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h18 : LitSat F.assign (18, false) :=
    use_clause (p1704 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p34 F)
      ⟨fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h17 h),
        True.intro⟩
def c3153 : CNF.Clause Nat := [(88, true), (30, true), (6, false), (32, true), (75, true), (86, true), (76, true), (87, false), (39, true), (74, true), (98, true)]
theorem p3153 (F : Frame G 3) : c3153.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (n8 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (10, true) :=
    use_clause (p192 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h4 : LitSat F.assign (21, true) :=
    use_clause (p189 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h5 : LitSat F.assign (8, true) :=
    use_clause (p41 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h6 : LitSat F.assign (20, true) :=
    use_clause (p3005 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  exact use_clause (p1827 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3154 : CNF.Clause Nat := [(20, false), (6, false), (32, true), (86, true), (99, false), (110, false)]
theorem p3154 (F : Frame G 3) : c3154.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (20, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p3142 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h6 : LitSat F.assign (76, false) :=
    use_clause (p2157 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (75, false) :=
    use_clause (p3152 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (29, false) :=
    use_clause (p2496 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h10 : LitSat F.assign (18, true) :=
    use_clause (p36 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h11 : LitSat F.assign (30, false) :=
    use_clause (p2401 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h12 : LitSat F.assign (88, true) :=
    use_clause (p3153 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (8, false) :=
    use_clause (p2639 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h14 : LitSat F.assign (10, false) :=
    use_clause (p1937 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
  exact use_clause (p216 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3155 : CNF.Clause Nat := [(6, false), (32, true), (86, true), (99, false), (110, false)]
theorem p3155 (F : Frame G 3) : c3155.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p3142 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (76, false) :=
    use_clause (p2157 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (75, false) :=
    use_clause (p3152 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (29, false) :=
    use_clause (p2496 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h10 : LitSat F.assign (18, true) :=
    use_clause (p36 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h11 : LitSat F.assign (30, false) :=
    use_clause (p2401 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h12 : LitSat F.assign (88, true) :=
    use_clause (p3153 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h13 : LitSat F.assign (20, false) :=
    use_clause (p3154 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h14 : LitSat F.assign (9, true) :=
    use_clause (p48 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h15 : LitSat F.assign (10, false) :=
    use_clause (p3005 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h16 : LitSat F.assign (21, false) :=
    use_clause (p2300 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p66 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
def c3156 : CNF.Clause Nat := [(32, true), (86, true), (99, false), (110, false)]
theorem p3156 (F : Frame G 3) : c3156.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p3142 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (76, false) :=
    use_clause (p2157 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (75, false) :=
    use_clause (p3152 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (6, false) :=
    use_clause (p3155 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (17, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h11 : LitSat F.assign (26, false) :=
    use_clause (p2571 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h12 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h13 : LitSat F.assign (9, false) :=
    use_clause (p2461 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h14 : LitSat F.assign (20, true) :=
    use_clause (p48 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h15 : LitSat F.assign (18, false) :=
    use_clause (p1636 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h16 : LitSat F.assign (29, true) :=
    use_clause (p36 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h17 : LitSat F.assign (10, false) :=
    use_clause (p2204 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h18 : LitSat F.assign (21, true) :=
    use_clause (p66 F)
      ⟨fun h => False.elim (unit_incompatible h17 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h19 : LitSat F.assign (30, false) :=
    use_clause (p2655 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h20 : LitSat F.assign (8, false) :=
    use_clause (p1827 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h21 : LitSat F.assign (88, false) :=
    use_clause (p2177 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p208 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h20 h),
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h21 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
def c3157 : CNF.Clause Nat := [(17, false), (32, false), (75, true), (87, false), (50, false), (38, false), (74, true), (99, false)]
theorem p3157 (F : Frame G 3) : c3157.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (76, false) :=
    use_clause (p2157 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (29, false) :=
    use_clause (p2493 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (18, false) :=
    use_clause (p2419 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p36 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3158 : CNF.Clause Nat := [(86, true), (99, false), (110, false)]
theorem p3158 (F : Frame G 3) : c3158.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p3142 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, false) :=
    use_clause (p2157 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h5 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (75, false) :=
    use_clause (p3152 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (32, true) :=
    use_clause (p3156 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (17, false) :=
    use_clause (p3157 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (6, true) :=
    use_clause (p13 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (29, false) :=
    use_clause (p2496 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h11 : LitSat F.assign (18, false) :=
    use_clause (p2402 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p36 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3159 : CNF.Clause Nat := [(75, true), (99, false), (110, false)]
theorem p3159 (F : Frame G 3) : c3159.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, true) :=
    use_clause (p3158 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (18, false) :=
    use_clause (p2481 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p3142 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (76, false) :=
    use_clause (p2157 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h8 : LitSat F.assign (32, false) :=
    use_clause (p2917 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h10 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        True.intro⟩
  have h11 : LitSat F.assign (29, true) :=
    use_clause (p36 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h12 : LitSat F.assign (21, false) :=
    use_clause (p2432 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h13 : LitSat F.assign (10, false) :=
    use_clause (p2204 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p66 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
def c3160 : CNF.Clause Nat := [(29, false), (99, false), (110, false)]
theorem p3160 (F : Frame G 3) : c3160.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (86, true) :=
    use_clause (p3158 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (75, true) :=
    use_clause (p3159 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p3142 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (76, false) :=
    use_clause (p2157 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h8 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (32, false) :=
    use_clause (p2917 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h10 : LitSat F.assign (21, false) :=
    use_clause (p2436 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h11 : LitSat F.assign (10, true) :=
    use_clause (p66 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h12 : LitSat F.assign (88, false) :=
    use_clause (p3130 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h13 : LitSat F.assign (22, false) :=
    use_clause (p2396 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h14 : LitSat F.assign (6, false) :=
    use_clause (p2496 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h15 : LitSat F.assign (77, false) :=
    use_clause (p2204 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h16 : LitSat F.assign (17, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h17 : LitSat F.assign (33, true) :=
    use_clause (p292 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
  exact use_clause (p2512 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3161 : CNF.Clause Nat := [(99, false), (110, false)]
theorem p3161 (F : Frame G 3) : c3161.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have h0 : LitSat F.assign (98, false) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h1 : LitSat F.assign (74, false) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, false) :=
    use_clause (p3120 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (87, true) :=
    use_clause (p3142 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h6 : LitSat F.assign (76, false) :=
    use_clause (p2157 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h7 : LitSat F.assign (86, true) :=
    use_clause (p3158 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h8 : LitSat F.assign (32, false) :=
    use_clause (p2917 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (18, false) :=
    use_clause (p2481 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h10 : LitSat F.assign (75, true) :=
    use_clause (p3159 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h11 : LitSat F.assign (21, false) :=
    use_clause (p2436 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h12 : LitSat F.assign (10, true) :=
    use_clause (p66 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (29, false) :=
    use_clause (p3160 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h14 : LitSat F.assign (77, true) :=
    use_clause (p34 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        True.intro⟩
  have h15 : LitSat F.assign (15, false) :=
    use_clause (p2400 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h14 h),
        True.intro⟩
  have h16 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h17 : LitSat F.assign (17, false) :=
    use_clause (p2571 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h18 : LitSat F.assign (6, false) :=
    use_clause (p2470 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3162 : CNF.Clause Nat := [(6, false), (39, true), (21, true), (98, true), (10, false), (77, false), (76, true), (38, false), (32, true), (75, false), (50, false), (87, false), (110, false)]
theorem p3162 (F : Frame G 3) : c3162.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have n12 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))))
  have h0 : LitSat F.assign (22, false) :=
    use_clause (p1783 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n11 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p3161 F)
      ⟨fun h => h,
        fun h => False.elim (n12 h),
        True.intro⟩
  have h2 : LitSat F.assign (30, false) :=
    use_clause (p2491 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n11 h),
        fun h => False.elim (n12 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h3 : LitSat F.assign (26, false) :=
    use_clause (p2492 F)
      ⟨fun h => False.elim (n11 h),
        fun h => False.elim (n12 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h4 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h5 : LitSat F.assign (9, false) :=
    use_clause (p2461 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n12 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, false) :=
    use_clause (p2400 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n10 h),
        fun h => h,
        fun h => False.elim (n11 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (88, false) :=
    use_clause (p2772 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n12 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h8 : LitSat F.assign (20, true) :=
    use_clause (p45 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (74, true) :=
    use_clause (p189 F)
      ⟨fun h => False.elim (n11 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (33, true) :=
    use_clause (p290 F)
      ⟨fun h => False.elim (n12 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p1801 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n10 h),
        True.intro⟩
def c3163 : CNF.Clause Nat := [(15, false), (74, false), (21, true), (98, true), (10, false), (22, true), (76, true), (38, false), (32, true), (75, false), (50, false), (87, false), (110, false)]
theorem p3163 (F : Frame G 3) : c3163.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have n12 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))))
  have h0 : LitSat F.assign (99, false) :=
    use_clause (p3161 F)
      ⟨fun h => h,
        fun h => False.elim (n12 h),
        True.intro⟩
  have h1 : LitSat F.assign (88, false) :=
    use_clause (p2772 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n12 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h2 : LitSat F.assign (11, false) :=
    use_clause (p2734 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p297 F)
      ⟨fun h => False.elim (n12 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3164 : CNF.Clause Nat := [(26, false), (17, false), (21, true), (98, true), (10, false), (77, false), (76, true), (38, false), (32, true), (75, false), (50, false), (87, false), (110, false)]
theorem p3164 (F : Frame G 3) : c3164.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (26, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have n12 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))))
  have h0 : LitSat F.assign (30, false) :=
    use_clause (p2570 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n12 h),
        True.intro⟩
  have h1 : LitSat F.assign (88, false) :=
    use_clause (p1930 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n11 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (8, false) :=
    use_clause (p2448 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n11 h),
        fun h => False.elim (n12 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, true) :=
    use_clause (p203 F)
      ⟨fun h => False.elim (n11 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p2420 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3165 : CNF.Clause Nat := [(39, true), (21, true), (98, true), (10, false), (77, false), (29, true), (76, true), (38, false), (32, true), (75, false), (50, false), (87, false), (110, false)]
theorem p3165 (F : Frame G 3) : c3165.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (29, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have n12 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))))
  have h0 : LitSat F.assign (22, false) :=
    use_clause (p1783 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n11 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p3161 F)
      ⟨fun h => h,
        fun h => False.elim (n12 h),
        True.intro⟩
  have h2 : LitSat F.assign (6, false) :=
    use_clause (p3162 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n12 h),
        True.intro⟩
  have h3 : LitSat F.assign (17, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h4 : LitSat F.assign (27, false) :=
    use_clause (p2759 F)
      ⟨fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n12 h),
        True.intro⟩
  have h5 : LitSat F.assign (5, true) :=
    use_clause (p27 F)
      ⟨fun h => False.elim (n10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h6 : LitSat F.assign (18, false) :=
    use_clause (p1703 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n11 h),
        fun h => False.elim (n12 h),
        True.intro⟩
  have h7 : LitSat F.assign (26, false) :=
    use_clause (p3164 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n12 h),
        True.intro⟩
  have h8 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h9 : LitSat F.assign (9, false) :=
    use_clause (p2461 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n12 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h10 : LitSat F.assign (86, false) :=
    use_clause (p2400 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n10 h),
        fun h => h,
        fun h => False.elim (n11 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (74, false) :=
    use_clause (p3163 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n12 h),
        True.intro⟩
  exact use_clause (p113 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3166 : CNF.Clause Nat := [(21, true), (98, true), (10, false), (77, false), (29, true), (76, true), (38, false), (32, true), (75, false), (50, false), (87, false), (110, false)]
theorem p3166 (F : Frame G 3) : c3166.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (29, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (22, false) :=
    use_clause (p1783 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n10 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p3161 F)
      ⟨fun h => h,
        fun h => False.elim (n11 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p3165 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n11 h),
        True.intro⟩
  have h3 : LitSat F.assign (11, false) :=
    use_clause (p2453 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n11 h),
        fun h => h,
        fun h => False.elim (n8 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, false) :=
    use_clause (p2681 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n11 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  exact use_clause (p297 F)
      ⟨fun h => False.elim (n11 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3167 : CNF.Clause Nat := [(98, true), (10, false), (77, false), (29, true), (76, true), (38, false), (32, true), (75, false), (50, false), (87, false), (110, false)]
theorem p3167 (F : Frame G 3) : c3167.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (29, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (99, false) :=
    use_clause (p3161 F)
      ⟨fun h => h,
        fun h => False.elim (n10 h),
        True.intro⟩
  have h1 : LitSat F.assign (21, true) :=
    use_clause (p3166 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, false) :=
    use_clause (p2712 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p2436 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h4 : LitSat F.assign (8, false) :=
    use_clause (p2472 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h5 : LitSat F.assign (30, false) :=
    use_clause (p2426 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (88, true) :=
    use_clause (p41 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (18, false) :=
    use_clause (p1876 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (9, false) :=
    use_clause (p2300 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p113 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3168 : CNF.Clause Nat := [(21, false), (88, true), (98, false), (77, false), (38, false), (75, false), (50, false), (110, false)]
theorem p3168 (F : Frame G 3) : c3168.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p2265 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2436 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (8, false) :=
    use_clause (p2472 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (30, false) :=
    use_clause (p2426 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p41 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c3169 : CNF.Clause Nat := [(11, false), (98, false), (77, false), (38, false), (75, false), (50, false), (87, false)]
theorem p3169 (F : Frame G 3) : c3169.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (26, false) :=
    use_clause (p2443 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (39, false) :=
    use_clause (p1820 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (15, false) :=
    use_clause (p2173 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3170 : CNF.Clause Nat := [(98, false), (77, false), (29, true), (76, true), (38, false), (75, false), (50, false), (87, false), (99, true)]
theorem p3170 (F : Frame G 3) : c3170.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (29, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (22, false) :=
    use_clause (p1783 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (88, false) :=
    use_clause (p2789 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h2 : LitSat F.assign (18, false) :=
    use_clause (p2050 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (11, false) :=
    use_clause (p3169 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (33, true) :=
    use_clause (p85 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (74, true) :=
    use_clause (p171 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h6 : LitSat F.assign (17, false) :=
    use_clause (p2046 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h7 : LitSat F.assign (39, false) :=
    use_clause (p2116 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h8 : LitSat F.assign (6, false) :=
    use_clause (p2042 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
def c3171 : CNF.Clause Nat := [(98, true), (77, false), (110, false), (29, true), (76, true), (38, false), (32, true), (75, false), (50, false), (87, false)]
theorem p3171 (F : Frame G 3) : c3171.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (29, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (10, false) :=
    use_clause (p3167 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (21, true) :=
    use_clause (p66 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, false) :=
    use_clause (p2712 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p2436 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (8, false) :=
    use_clause (p2472 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (30, false) :=
    use_clause (p2426 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p216 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
def c3172 : CNF.Clause Nat := [(77, false), (29, true), (76, true), (38, false), (32, true), (75, false), (50, false), (87, false), (110, false)]
theorem p3172 (F : Frame G 3) : c3172.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (29, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (99, false) :=
    use_clause (p3161 F)
      ⟨fun h => h,
        fun h => False.elim (n8 h),
        True.intro⟩
  have h1 : LitSat F.assign (98, false) :=
    use_clause (p3170 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p3171 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
def c3173 : CNF.Clause Nat := [(21, false), (98, true), (77, true), (76, true), (38, false), (75, false), (50, false), (110, false)]
theorem p3173 (F : Frame G 3) : c3173.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (99, false) :=
    use_clause (p3161 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (74, false) :=
    use_clause (p2712 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p2436 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p366 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3174 : CNF.Clause Nat := [(88, false), (86, false), (10, false), (38, false), (75, false), (50, false), (87, false), (110, false)]
theorem p3174 (F : Frame G 3) : c3174.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p2117 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h1 : LitSat F.assign (15, false) :=
    use_clause (p2584 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (17, false) :=
    use_clause (p1930 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h4 : LitSat F.assign (6, false) :=
    use_clause (p2470 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3175 : CNF.Clause Nat := [(88, true), (98, true), (77, true), (76, true), (38, false), (32, true), (75, false), (50, false), (87, false), (110, false)]
theorem p3175 (F : Frame G 3) : c3175.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (21, false) :=
    use_clause (p3173 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p3161 F)
      ⟨fun h => h,
        fun h => False.elim (n9 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, true) :=
    use_clause (p289 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (11, true) :=
    use_clause (p293 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p2474 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n8 h),
        True.intro⟩
def c3176 : CNF.Clause Nat := [(98, true), (77, true), (76, true), (38, false), (32, true), (75, false), (50, false), (87, false), (110, false)]
theorem p3176 (F : Frame G 3) : c3176.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (99, false) :=
    use_clause (p3161 F)
      ⟨fun h => h,
        fun h => False.elim (n8 h),
        True.intro⟩
  have h1 : LitSat F.assign (21, false) :=
    use_clause (p3173 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h2 : LitSat F.assign (10, true) :=
    use_clause (p66 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p3175 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h4 : LitSat F.assign (39, false) :=
    use_clause (p2117 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (15, false) :=
    use_clause (p1924 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, false) :=
    use_clause (p3174 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h7 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (74, true) :=
    use_clause (p366 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (17, false) :=
    use_clause (p1930 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h10 : LitSat F.assign (6, false) :=
    use_clause (p2552 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  exact use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3177 : CNF.Clause Nat := [(88, false), (10, false), (98, false), (38, false), (75, false), (50, false), (87, false), (110, false)]
theorem p3177 (F : Frame G 3) : c3177.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p2117 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h1 : LitSat F.assign (15, false) :=
    use_clause (p1924 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h2 : LitSat F.assign (26, false) :=
    use_clause (p2523 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3178 : CNF.Clause Nat := [(88, true), (98, false), (77, true), (38, false), (75, false), (50, false), (87, false), (110, false)]
theorem p3178 (F : Frame G 3) : c3178.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (22, false) :=
    use_clause (p2137 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p3161 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (11, true) :=
    use_clause (p82 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (33, true) :=
    use_clause (p73 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (39, false) :=
    use_clause (p2453 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (15, false) :=
    use_clause (p2173 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h6 : LitSat F.assign (26, false) :=
    use_clause (p2210 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3179 : CNF.Clause Nat := [(77, true), (76, true), (38, false), (32, true), (75, false), (50, false), (87, false), (110, false)]
theorem p3179 (F : Frame G 3) : c3179.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (99, false) :=
    use_clause (p3161 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (98, true) :=
    use_clause (p3176 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, false) :=
    use_clause (p2137 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p3178 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (26, false) :=
    use_clause (p2523 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (21, false) :=
    use_clause (p2111 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (10, false) :=
    use_clause (p3177 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h7 : LitSat F.assign (11, true) :=
    use_clause (p360 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (39, false) :=
    use_clause (p2453 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (15, false) :=
    use_clause (p2173 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
def c3180 : CNF.Clause Nat := [(98, false), (76, true), (38, false), (32, true), (75, false), (50, false), (87, false), (110, false)]
theorem p3180 (F : Frame G 3) : c3180.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (77, true) :=
    use_clause (p3179 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (29, true) :=
    use_clause (p3172 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, false) :=
    use_clause (p1783 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p3161 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, false) :=
    use_clause (p2789 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h5 : LitSat F.assign (11, false) :=
    use_clause (p3169 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (6, false) :=
    use_clause (p2048 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (17, false) :=
    use_clause (p2047 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (21, false) :=
    use_clause (p3168 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h9 : LitSat F.assign (33, true) :=
    use_clause (p85 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h10 : LitSat F.assign (10, true) :=
    use_clause (p359 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h11 : LitSat F.assign (39, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        True.intro⟩
  have h12 : LitSat F.assign (86, false) :=
    use_clause (p2527 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h13 : LitSat F.assign (8, false) :=
    use_clause (p2358 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h14 : LitSat F.assign (74, false) :=
    use_clause (p1698 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h15 : LitSat F.assign (30, false) :=
    use_clause (p2504 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p41 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
end Cert35Steps
end Graffiti199Depleted.Catalogue.OrderEleven
