import Case35Part5
namespace Graffiti199Depleted.Catalogue.OrderEleven
namespace Cert35Steps
open Std.Sat
set_option maxRecDepth 4096
set_option maxHeartbeats 0
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj]
def c3661 : CNF.Clause Nat := [(74, true), (76, false), (110, false)]
theorem p3661 (F : Frame G 3) : c3661.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (77, true) :=
    use_clause (p3660 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p3161 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (75, false) :=
    use_clause (p3551 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p3655 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p377 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h5 : LitSat F.assign (39, false) :=
    use_clause (p3638 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (30, false) :=
    use_clause (p2925 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h9 : LitSat F.assign (87, false) :=
    use_clause (p3449 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h10 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        True.intro⟩
  have h11 : LitSat F.assign (8, true) :=
    use_clause (p42 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h12 : LitSat F.assign (20, false) :=
    use_clause (p2637 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        True.intro⟩
  have h13 : LitSat F.assign (15, false) :=
    use_clause (p1710 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  have h14 : LitSat F.assign (9, true) :=
    use_clause (p47 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h15 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h16 : LitSat F.assign (6, false) :=
    use_clause (p1603 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h17 : LitSat F.assign (17, false) :=
    use_clause (p2554 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  exact use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
def c3662 : CNF.Clause Nat := [(15, false), (76, false), (110, false)]
theorem p3662 (F : Frame G 3) : c3662.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (74, true) :=
    use_clause (p3661 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (77, true) :=
    use_clause (p3660 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p3161 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (75, false) :=
    use_clause (p3551 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p3655 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p377 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h6 : LitSat F.assign (39, false) :=
    use_clause (p3638 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (30, false) :=
    use_clause (p2925 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (87, false) :=
    use_clause (p3449 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h10 : LitSat F.assign (88, false) :=
    use_clause (p2589 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h11 : LitSat F.assign (8, false) :=
    use_clause (p2757 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  exact use_clause (p39 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
def c3663 : CNF.Clause Nat := [(76, false), (110, false)]
theorem p3663 (F : Frame G 3) : c3663.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have h0 : LitSat F.assign (77, true) :=
    use_clause (p3660 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p3161 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (75, false) :=
    use_clause (p3551 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p3655 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p377 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h5 : LitSat F.assign (39, false) :=
    use_clause (p3638 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h6 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (87, false) :=
    use_clause (p3449 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (30, false) :=
    use_clause (p2925 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h10 : LitSat F.assign (74, true) :=
    use_clause (p3661 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h11 : LitSat F.assign (11, false) :=
    use_clause (p2155 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h12 : LitSat F.assign (33, false) :=
    use_clause (p3336 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h13 : LitSat F.assign (15, false) :=
    use_clause (p3662 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h14 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h15 : LitSat F.assign (5, false) :=
    use_clause (p2752 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h16 : LitSat F.assign (6, false) :=
    use_clause (p2754 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h17 : LitSat F.assign (27, true) :=
    use_clause (p27 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h18 : LitSat F.assign (9, false) :=
    use_clause (p2753 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h19 : LitSat F.assign (20, true) :=
    use_clause (p47 F)
      ⟨fun h => False.elim (unit_incompatible h18 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h20 : LitSat F.assign (88, false) :=
    use_clause (p2546 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h17 h),
        True.intro⟩
  have h21 : LitSat F.assign (22, true) :=
    use_clause (p85 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h20 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h22 : LitSat F.assign (8, true) :=
    use_clause (p39 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h20 h),
        True.intro⟩
  exact use_clause (p2066 F)
      ⟨fun h => False.elim (unit_incompatible h22 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h21 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3664 : CNF.Clause Nat := [(26, false), (74, false), (110, false)]
theorem p3664 (F : Frame G 3) : c3664.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (26, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (99, false) :=
    use_clause (p3161 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (75, false) :=
    use_clause (p3551 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p3655 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p377 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (77, true) :=
    use_clause (p3660 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (39, false) :=
    use_clause (p3638 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (21, false) :=
    use_clause (p2265 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h9 : LitSat F.assign (11, false) :=
    use_clause (p2155 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h10 : LitSat F.assign (76, false) :=
    use_clause (p3663 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h11 : LitSat F.assign (87, false) :=
    use_clause (p3449 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h12 : LitSat F.assign (5, false) :=
    use_clause (p2752 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h13 : LitSat F.assign (6, false) :=
    use_clause (p2754 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h14 : LitSat F.assign (27, true) :=
    use_clause (p27 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h15 : LitSat F.assign (17, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h16 : LitSat F.assign (9, false) :=
    use_clause (p2753 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h17 : LitSat F.assign (33, false) :=
    use_clause (p2046 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h18 : LitSat F.assign (20, true) :=
    use_clause (p47 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h19 : LitSat F.assign (10, true) :=
    use_clause (p253 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h20 : LitSat F.assign (88, false) :=
    use_clause (p2546 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h14 h),
        True.intro⟩
  have h21 : LitSat F.assign (30, false) :=
    use_clause (p2061 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h22 : LitSat F.assign (22, true) :=
    use_clause (p85 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h20 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h23 : LitSat F.assign (8, true) :=
    use_clause (p39 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h21 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h20 h),
        True.intro⟩
  exact use_clause (p2066 F)
      ⟨fun h => False.elim (unit_incompatible h23 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h22 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c3665 : CNF.Clause Nat := [(17, false), (88, true), (74, false), (110, false)]
theorem p3665 (F : Frame G 3) : c3665.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (77, true) :=
    use_clause (p3660 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (39, false) :=
    use_clause (p3638 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p3161 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (75, false) :=
    use_clause (p3551 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (86, false) :=
    use_clause (p3655 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, true) :=
    use_clause (p377 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (26, false) :=
    use_clause (p3664 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (8, false) :=
    use_clause (p2757 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h10 : LitSat F.assign (87, false) :=
    use_clause (p3449 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h11 : LitSat F.assign (30, true) :=
    use_clause (p39 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h12 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h13 : LitSat F.assign (11, false) :=
    use_clause (p2155 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h14 : LitSat F.assign (76, false) :=
    use_clause (p3663 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h15 : LitSat F.assign (29, false) :=
    use_clause (p2588 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h16 : LitSat F.assign (22, false) :=
    use_clause (p2059 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h17 : LitSat F.assign (18, false) :=
    use_clause (p2663 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p165 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c3666 : CNF.Clause Nat := [(88, true), (74, false), (110, false)]
theorem p3666 (F : Frame G 3) : c3666.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (77, true) :=
    use_clause (p3660 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (39, false) :=
    use_clause (p3638 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p3161 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (75, false) :=
    use_clause (p3551 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (86, false) :=
    use_clause (p3655 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, true) :=
    use_clause (p377 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (26, false) :=
    use_clause (p3664 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (8, false) :=
    use_clause (p2757 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h10 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h11 : LitSat F.assign (11, false) :=
    use_clause (p2155 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h12 : LitSat F.assign (76, false) :=
    use_clause (p3663 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h13 : LitSat F.assign (87, false) :=
    use_clause (p3449 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h14 : LitSat F.assign (30, true) :=
    use_clause (p39 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h15 : LitSat F.assign (17, false) :=
    use_clause (p3665 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h16 : LitSat F.assign (6, true) :=
    use_clause (p13 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h17 : LitSat F.assign (29, false) :=
    use_clause (p1697 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h18 : LitSat F.assign (18, false) :=
    use_clause (p1687 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h19 : LitSat F.assign (22, false) :=
    use_clause (p2151 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  exact use_clause (p165 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c3667 : CNF.Clause Nat := [(74, false), (110, false)]
theorem p3667 (F : Frame G 3) : c3667.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have h0 : LitSat F.assign (76, false) :=
    use_clause (p3663 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h1 : LitSat F.assign (77, true) :=
    use_clause (p3660 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p3161 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (75, false) :=
    use_clause (p3551 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p3655 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p377 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h6 : LitSat F.assign (39, false) :=
    use_clause (p3638 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h7 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h9 : LitSat F.assign (87, false) :=
    use_clause (p3449 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h10 : LitSat F.assign (21, false) :=
    use_clause (p2265 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h11 : LitSat F.assign (26, false) :=
    use_clause (p3664 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h12 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h13 : LitSat F.assign (8, false) :=
    use_clause (p2757 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h14 : LitSat F.assign (88, true) :=
    use_clause (p3666 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h15 : LitSat F.assign (9, false) :=
    use_clause (p2141 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h16 : LitSat F.assign (20, true) :=
    use_clause (p47 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h17 : LitSat F.assign (32, true) :=
    use_clause (p250 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h18 : LitSat F.assign (10, true) :=
    use_clause (p253 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h19 : LitSat F.assign (17, false) :=
    use_clause (p1952 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h14 h),
        True.intro⟩
  have h20 : LitSat F.assign (6, true) :=
    use_clause (p13 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h21 : LitSat F.assign (30, false) :=
    use_clause (p2140 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h20 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h22 : LitSat F.assign (29, false) :=
    use_clause (p1697 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h20 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h23 : LitSat F.assign (18, false) :=
    use_clause (p1906 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h20 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h14 h),
        True.intro⟩
  exact use_clause (p102 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h23 h),
        fun h => False.elim (unit_incompatible h22 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h21 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
def c3668 : CNF.Clause Nat := [(6, false), (8, false), (110, false)]
theorem p3668 (F : Frame G 3) : c3668.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (87, false) :=
    use_clause (p3449 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p3655 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, false) :=
    use_clause (p3667 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (76, false) :=
    use_clause (p3663 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p3161 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (75, false) :=
    use_clause (p3551 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, true) :=
    use_clause (p377 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (39, false) :=
    use_clause (p3638 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        True.intro⟩
  have h10 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h11 : LitSat F.assign (9, false) :=
    use_clause (p1603 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h12 : LitSat F.assign (10, false) :=
    use_clause (p1604 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (20, true) :=
    use_clause (p47 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h14 : LitSat F.assign (32, true) :=
    use_clause (p251 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h15 : LitSat F.assign (21, true) :=
    use_clause (p253 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h16 : LitSat F.assign (18, false) :=
    use_clause (p2764 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h17 : LitSat F.assign (29, false) :=
    use_clause (p2040 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p36 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3669 : CNF.Clause Nat := [(9, true), (17, false), (110, false)]
theorem p3669 (F : Frame G 3) : c3669.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (9, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (77, true) :=
    use_clause (p3660 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p3161 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (75, false) :=
    use_clause (p3551 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p3655 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p377 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h5 : LitSat F.assign (39, false) :=
    use_clause (p3638 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (87, false) :=
    use_clause (p3449 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (74, false) :=
    use_clause (p3667 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h10 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        True.intro⟩
  have h11 : LitSat F.assign (76, false) :=
    use_clause (p3663 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h12 : LitSat F.assign (29, false) :=
    use_clause (p2755 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h13 : LitSat F.assign (18, true) :=
    use_clause (p36 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h14 : LitSat F.assign (21, false) :=
    use_clause (p1951 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  have h15 : LitSat F.assign (20, true) :=
    use_clause (p47 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h16 : LitSat F.assign (32, true) :=
    use_clause (p250 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h17 : LitSat F.assign (10, true) :=
    use_clause (p253 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  exact use_clause (p1909 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
def c3670 : CNF.Clause Nat := [(8, false), (110, false)]
theorem p3670 (F : Frame G 3) : c3670.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have h0 : LitSat F.assign (87, false) :=
    use_clause (p3449 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p3655 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, false) :=
    use_clause (p3667 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (76, false) :=
    use_clause (p3663 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h5 : LitSat F.assign (77, true) :=
    use_clause (p3660 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, false) :=
    use_clause (p3161 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h7 : LitSat F.assign (75, false) :=
    use_clause (p3551 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h8 : LitSat F.assign (98, true) :=
    use_clause (p377 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h9 : LitSat F.assign (39, false) :=
    use_clause (p3638 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h10 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        True.intro⟩
  have h11 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h12 : LitSat F.assign (6, false) :=
    use_clause (p3668 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h13 : LitSat F.assign (17, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h14 : LitSat F.assign (29, false) :=
    use_clause (p2755 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h15 : LitSat F.assign (18, true) :=
    use_clause (p36 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h16 : LitSat F.assign (9, true) :=
    use_clause (p3669 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h17 : LitSat F.assign (15, false) :=
    use_clause (p2141 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h18 : LitSat F.assign (26, false) :=
    use_clause (p2766 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
def c3671 : CNF.Clause Nat := [(17, false), (110, false)]
theorem p3671 (F : Frame G 3) : c3671.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have h0 : LitSat F.assign (87, false) :=
    use_clause (p3449 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p3655 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, false) :=
    use_clause (p3667 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (8, false) :=
    use_clause (p3670 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h4 : LitSat F.assign (30, true) :=
    use_clause (p42 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (76, false) :=
    use_clause (p3663 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h7 : LitSat F.assign (77, true) :=
    use_clause (p3660 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h8 : LitSat F.assign (99, false) :=
    use_clause (p3161 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (75, false) :=
    use_clause (p3551 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h10 : LitSat F.assign (98, true) :=
    use_clause (p377 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h11 : LitSat F.assign (39, false) :=
    use_clause (p3638 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h12 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        True.intro⟩
  have h13 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h14 : LitSat F.assign (29, false) :=
    use_clause (p2755 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  have h15 : LitSat F.assign (18, false) :=
    use_clause (p1949 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  exact use_clause (p36 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3672 : CNF.Clause Nat := [(110, false)]
theorem p3672 (F : Frame G 3) : c3672.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have h0 : LitSat F.assign (99, false) :=
    use_clause (p3161 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, false) :=
    use_clause (p3449 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h2 : LitSat F.assign (75, false) :=
    use_clause (p3551 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h3 : LitSat F.assign (39, false) :=
    use_clause (p3638 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h4 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (86, false) :=
    use_clause (p3655 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, true) :=
    use_clause (p377 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (77, true) :=
    use_clause (p3660 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h9 : LitSat F.assign (76, false) :=
    use_clause (p3663 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h10 : LitSat F.assign (74, false) :=
    use_clause (p3667 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h11 : LitSat F.assign (88, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h12 : LitSat F.assign (8, false) :=
    use_clause (p3670 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h13 : LitSat F.assign (30, true) :=
    use_clause (p42 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h14 : LitSat F.assign (17, false) :=
    use_clause (p3671 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h15 : LitSat F.assign (6, true) :=
    use_clause (p13 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h16 : LitSat F.assign (15, false) :=
    use_clause (p2140 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h17 : LitSat F.assign (18, false) :=
    use_clause (p1687 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h18 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h19 : LitSat F.assign (29, true) :=
    use_clause (p36 F)
      ⟨fun h => False.elim (unit_incompatible h17 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  exact use_clause (p1663 F)
      ⟨fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3673 : CNF.Clause Nat := [(29, false), (26, false), (30, false), (74, true), (77, false), (75, true), (88, false), (39, true), (98, false)]
theorem p3673 (F : Frame G 3) : c3673.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (26, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p3649 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p1663 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3674 : CNF.Clause Nat := [(30, false), (74, true), (77, false), (75, true), (6, false), (88, false), (39, true), (76, true), (98, false), (50, false)]
theorem p3674 (F : Frame G 3) : c3674.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, false) :=
    use_clause (p2789 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (15, false) :=
    use_clause (p2140 F)
      ⟨fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h4 : LitSat F.assign (22, false) :=
    use_clause (p2151 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (29, false) :=
    use_clause (p3673 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h7 : LitSat F.assign (18, true) :=
    use_clause (p36 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h8 : LitSat F.assign (21, false) :=
    use_clause (p1951 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (33, false) :=
    use_clause (p2039 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n8 h),
        True.intro⟩
  have h10 : LitSat F.assign (10, true) :=
    use_clause (p60 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (99, true) :=
    use_clause (p151 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2268 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
def c3675 : CNF.Clause Nat := [(18, false), (77, false), (75, true), (6, false), (88, false), (39, true), (76, true), (98, false), (50, false)]
theorem p3675 (F : Frame G 3) : c3675.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, false) :=
    use_clause (p2789 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (21, false) :=
    use_clause (p1951 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (10, true) :=
    use_clause (p60 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (32, true) :=
    use_clause (p51 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, false) :=
    use_clause (p2922 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, false) :=
    use_clause (p2270 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (20, false) :=
    use_clause (p1906 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p246 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3676 : CNF.Clause Nat := [(74, true), (77, false), (75, true), (6, false), (88, false), (39, true), (76, true), (98, false), (50, false)]
theorem p3676 (F : Frame G 3) : c3676.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (18, false) :=
    use_clause (p3675 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, false) :=
    use_clause (p2789 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (30, false) :=
    use_clause (p3674 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (29, true) :=
    use_clause (p36 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, false) :=
    use_clause (p3649 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, true) :=
    use_clause (p371 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (8, true) :=
    use_clause (p42 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p2572 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n7 h),
        True.intro⟩
def c3677 : CNF.Clause Nat := [(77, false), (75, true), (6, false), (88, false), (39, true), (76, true), (98, false), (50, false)]
theorem p3677 (F : Frame G 3) : c3677.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, false) :=
    use_clause (p2789 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (74, true) :=
    use_clause (p3676 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (21, false) :=
    use_clause (p2265 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h5 : LitSat F.assign (10, true) :=
    use_clause (p60 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (32, true) :=
    use_clause (p51 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (86, false) :=
    use_clause (p2922 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h8 : LitSat F.assign (99, false) :=
    use_clause (p2367 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n6 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p371 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3678 : CNF.Clause Nat := [(99, true), (87, true), (75, true), (6, false), (88, false), (39, true), (76, true), (98, false), (50, false)]
theorem p3678 (F : Frame G 3) : c3678.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, false) :=
    use_clause (p3677 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, true) :=
    use_clause (p364 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (22, false) :=
    use_clause (p2096 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (86, true) :=
    use_clause (p371 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (11, true) :=
    use_clause (p80 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (33, true) :=
    use_clause (p71 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (10, false) :=
    use_clause (p1608 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (18, false) :=
    use_clause (p2089 F)
      ⟨fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h10 : LitSat F.assign (21, true) :=
    use_clause (p60 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (29, true) :=
    use_clause (p33 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p2040 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c3679 : CNF.Clause Nat := [(87, true), (75, true), (6, false), (88, false), (39, true), (76, true), (98, false), (50, false)]
theorem p3679 (F : Frame G 3) : c3679.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, false) :=
    use_clause (p3677 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, true) :=
    use_clause (p364 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, true) :=
    use_clause (p3678 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h5 : LitSat F.assign (32, false) :=
    use_clause (p2367 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (21, false) :=
    use_clause (p2377 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p51 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3680 : CNF.Clause Nat := [(99, false), (87, false), (77, true), (75, true), (6, false), (38, false), (76, true), (98, false), (50, false)]
theorem p3680 (F : Frame G 3) : c3680.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (74, true) :=
    use_clause (p364 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (18, false) :=
    use_clause (p2172 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h2 : LitSat F.assign (29, false) :=
    use_clause (p2267 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p33 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c3681 : CNF.Clause Nat := [(75, true), (6, false), (88, false), (39, true), (76, true), (98, false), (50, false)]
theorem p3681 (F : Frame G 3) : c3681.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (77, false) :=
    use_clause (p3677 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (74, true) :=
    use_clause (p364 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (22, false) :=
    use_clause (p2096 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, true) :=
    use_clause (p3679 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, false) :=
    use_clause (p3680 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (33, true) :=
    use_clause (p71 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (18, false) :=
    use_clause (p2039 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (15, false) :=
    use_clause (p2041 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h10 : LitSat F.assign (29, true) :=
    use_clause (p33 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h11 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p1667 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3682 : CNF.Clause Nat := [(87, false), (6, false), (88, false), (39, true), (76, true), (98, false), (50, false)]
theorem p3682 (F : Frame G 3) : c3682.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (75, true) :=
    use_clause (p3681 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (21, false) :=
    use_clause (p2111 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (26, false) :=
    use_clause (p2468 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (10, false) :=
    use_clause (p1924 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (32, false) :=
    use_clause (p1914 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p65 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3683 : CNF.Clause Nat := [(15, false), (6, false), (88, false), (39, true), (76, true), (98, false), (50, false)]
theorem p3683 (F : Frame G 3) : c3683.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (75, true) :=
    use_clause (p3681 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (21, false) :=
    use_clause (p2111 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, false) :=
    use_clause (p3682 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (32, true) :=
    use_clause (p51 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (10, true) :=
    use_clause (p60 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (20, false) :=
    use_clause (p1910 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (86, false) :=
    use_clause (p2142 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (99, false) :=
    use_clause (p2293 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h10 : LitSat F.assign (9, true) :=
    use_clause (p255 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (77, false) :=
    use_clause (p2141 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h12 : LitSat F.assign (11, false) :=
    use_clause (p1608 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (74, true) :=
    use_clause (p372 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (22, true) :=
    use_clause (p80 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2096 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3684 : CNF.Clause Nat := [(74, false), (99, true), (75, false), (6, false), (88, false), (38, false), (98, false), (50, false)]
theorem p3684 (F : Frame G 3) : c3684.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (22, false) :=
    use_clause (p2096 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (33, false) :=
    use_clause (p2135 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, true) :=
    use_clause (p71 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (11, true) :=
    use_clause (p83 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2155 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c3685 : CNF.Clause Nat := [(77, false), (15, true), (32, false), (10, false), (75, false), (88, false), (39, true), (98, false), (50, false)]
theorem p3685 (F : Frame G 3) : c3685.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (15, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (27, false) :=
    use_clause (p2091 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (5, false) :=
    use_clause (p2139 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n8 h),
        True.intro⟩
  exact use_clause (p15 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3686 : CNF.Clause Nat := [(6, false), (88, false), (39, true), (76, true), (98, false), (50, false)]
theorem p3686 (F : Frame G 3) : c3686.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (75, true) :=
    use_clause (p3681 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (21, false) :=
    use_clause (p2111 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, false) :=
    use_clause (p3682 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (10, true) :=
    use_clause (p60 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (32, true) :=
    use_clause (p51 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (15, false) :=
    use_clause (p3683 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (99, false) :=
    use_clause (p2261 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h10 : LitSat F.assign (74, false) :=
    use_clause (p3684 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h11 : LitSat F.assign (77, false) :=
    use_clause (p3685 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h12 : LitSat F.assign (11, false) :=
    use_clause (p1608 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (86, true) :=
    use_clause (p372 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (22, true) :=
    use_clause (p80 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2082 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3687 : CNF.Clause Nat := [(26, false), (77, true), (10, false), (75, false), (17, false), (88, false), (38, false), (76, true), (98, false), (50, false)]
theorem p3687 (F : Frame G 3) : c3687.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (26, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (74, false) :=
    use_clause (p1952 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (21, false) :=
    use_clause (p2111 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p2261 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, false) :=
    use_clause (p1930 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (11, false) :=
    use_clause (p2185 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, true) :=
    use_clause (p372 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (32, true) :=
    use_clause (p51 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (22, true) :=
    use_clause (p80 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2082 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n9 h),
        True.intro⟩
def c3688 : CNF.Clause Nat := [(77, true), (10, false), (75, false), (88, false), (39, true), (76, true), (98, false), (50, false)]
theorem p3688 (F : Frame G 3) : c3688.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (6, false) :=
    use_clause (p3686 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (17, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (74, false) :=
    use_clause (p1952 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (21, false) :=
    use_clause (p2111 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (26, false) :=
    use_clause (p3687 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h7 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (87, false) :=
    use_clause (p1924 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (99, false) :=
    use_clause (p2293 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h10 : LitSat F.assign (32, true) :=
    use_clause (p51 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (86, true) :=
    use_clause (p372 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2142 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c3689 : CNF.Clause Nat := [(10, false), (75, false), (88, false), (39, true), (76, true), (98, false), (50, false)]
theorem p3689 (F : Frame G 3) : c3689.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (21, false) :=
    use_clause (p2111 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (6, false) :=
    use_clause (p3686 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (17, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (74, false) :=
    use_clause (p1952 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (77, true) :=
    use_clause (p3688 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (87, false) :=
    use_clause (p2789 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (86, false) :=
    use_clause (p2922 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (30, false) :=
    use_clause (p2061 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h10 : LitSat F.assign (32, true) :=
    use_clause (p51 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (8, true) :=
    use_clause (p42 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  exact use_clause (p2424 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3690 : CNF.Clause Nat := [(26, false), (87, false), (75, false), (17, false), (88, false), (38, false), (98, false), (50, false)]
theorem p3690 (F : Frame G 3) : c3690.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (26, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, false) :=
    use_clause (p2788 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, false) :=
    use_clause (p2137 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (33, false) :=
    use_clause (p2150 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p2444 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p71 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3691 : CNF.Clause Nat := [(75, false), (88, false), (39, true), (76, true), (98, false), (50, false)]
theorem p3691 (F : Frame G 3) : c3691.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (6, false) :=
    use_clause (p3686 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (17, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (21, false) :=
    use_clause (p2111 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h5 : LitSat F.assign (10, false) :=
    use_clause (p3689 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p60 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (32, true) :=
    use_clause (p65 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (22, false) :=
    use_clause (p2137 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (77, false) :=
    use_clause (p2788 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h10 : LitSat F.assign (26, false) :=
    use_clause (p3690 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h11 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h12 : LitSat F.assign (11, false) :=
    use_clause (p2173 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h13 : LitSat F.assign (99, true) :=
    use_clause (p80 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (33, true) :=
    use_clause (p86 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2414 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3692 : CNF.Clause Nat := [(77, true), (10, true), (75, true), (17, false), (88, false), (38, false), (76, true), (98, false), (50, false)]
theorem p3692 (F : Frame G 3) : c3692.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (74, true) :=
    use_clause (p364 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, false) :=
    use_clause (p2096 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (33, false) :=
    use_clause (p1942 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, true) :=
    use_clause (p71 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (32, false) :=
    use_clause (p2367 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (21, false) :=
    use_clause (p2377 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p65 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3693 : CNF.Clause Nat := [(10, true), (75, true), (50, false), (17, false), (88, false), (38, false), (76, true), (98, false)]
theorem p3693 (F : Frame G 3) : c3693.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, true) :=
    use_clause (p3692 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, false) :=
    use_clause (p2789 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (29, false) :=
    use_clause (p2755 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (21, true) :=
    use_clause (p60 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (74, false) :=
    use_clause (p2265 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h6 : LitSat F.assign (18, false) :=
    use_clause (p1951 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p36 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c3694 : CNF.Clause Nat := [(88, false), (39, true), (76, true), (98, false), (50, false)]
theorem p3694 (F : Frame G 3) : c3694.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (6, false) :=
    use_clause (p3686 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (17, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h4 : LitSat F.assign (75, false) :=
    use_clause (p3691 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (10, true) :=
    use_clause (p3693 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (74, false) :=
    use_clause (p1952 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h7 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (87, false) :=
    use_clause (p2789 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (86, false) :=
    use_clause (p2922 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (29, false) :=
    use_clause (p2755 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h11 : LitSat F.assign (30, false) :=
    use_clause (p2061 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h12 : LitSat F.assign (99, true) :=
    use_clause (p371 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (18, true) :=
    use_clause (p36 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h14 : LitSat F.assign (8, true) :=
    use_clause (p42 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h15 : LitSat F.assign (21, false) :=
    use_clause (p1951 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h16 : LitSat F.assign (32, false) :=
    use_clause (p2271 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p51 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3695 : CNF.Clause Nat := [(74, true), (30, true), (17, false), (21, true), (86, true), (75, true), (88, true), (38, false), (76, true), (50, false)]
theorem p3695 (F : Frame G 3) : c3695.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p368 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (32, true) :=
    use_clause (p188 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p3157 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3696 : CNF.Clause Nat := [(17, false), (21, true), (77, false), (10, false), (75, true), (39, true), (76, true), (98, false), (50, false)]
theorem p3696 (F : Frame G 3) : c3696.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2922 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, false) :=
    use_clause (p3694 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (30, false) :=
    use_clause (p2061 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (74, true) :=
    use_clause (p3695 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h6 : LitSat F.assign (33, false) :=
    use_clause (p2046 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n7 h),
        True.intro⟩
  have h7 : LitSat F.assign (11, false) :=
    use_clause (p2155 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h8 : LitSat F.assign (87, false) :=
    use_clause (p2714 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (99, true) :=
    use_clause (p75 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (32, true) :=
    use_clause (p51 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2367 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
def c3697 : CNF.Clause Nat := [(74, false), (6, false), (21, true), (86, true), (77, false), (75, true), (38, false), (76, true), (98, false), (50, false)]
theorem p3697 (F : Frame G 3) : c3697.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, false) :=
    use_clause (p2042 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p371 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (32, true) :=
    use_clause (p51 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2367 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3698 : CNF.Clause Nat := [(21, true), (77, false), (10, false), (75, true), (39, true), (76, true), (98, false), (50, false)]
theorem p3698 (F : Frame G 3) : c3698.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2922 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (88, false) :=
    use_clause (p3694 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (17, false) :=
    use_clause (p3696 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (6, true) :=
    use_clause (p13 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (74, false) :=
    use_clause (p3697 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h7 : LitSat F.assign (18, false) :=
    use_clause (p2050 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h8 : LitSat F.assign (29, false) :=
    use_clause (p2048 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p36 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3699 : CNF.Clause Nat := [(77, false), (10, false), (75, true), (39, true), (76, true), (98, false), (50, false)]
theorem p3699 (F : Frame G 3) : c3699.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (88, false) :=
    use_clause (p3694 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p2922 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (21, true) :=
    use_clause (p3698 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (74, false) :=
    use_clause (p2265 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (18, false) :=
    use_clause (p2050 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h7 : LitSat F.assign (29, false) :=
    use_clause (p3376 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p36 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c3700 : CNF.Clause Nat := [(10, false), (75, true), (39, true), (76, true), (98, false), (50, false)]
theorem p3700 (F : Frame G 3) : c3700.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, false) :=
    use_clause (p3694 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, false) :=
    use_clause (p3699 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (74, true) :=
    use_clause (p364 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (32, false) :=
    use_clause (p2367 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (21, false) :=
    use_clause (p2377 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (87, true) :=
    use_clause (p51 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (6, false) :=
    use_clause (p3680 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h10 : LitSat F.assign (26, false) :=
    use_clause (p2679 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h11 : LitSat F.assign (18, false) :=
    use_clause (p2172 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h12 : LitSat F.assign (17, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h13 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h14 : LitSat F.assign (29, true) :=
    use_clause (p33 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h15 : LitSat F.assign (9, false) :=
    use_clause (p2982 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h16 : LitSat F.assign (33, false) :=
    use_clause (p2213 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h17 : LitSat F.assign (86, false) :=
    use_clause (p2290 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h18 : LitSat F.assign (30, false) :=
    use_clause (p2411 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h19 : LitSat F.assign (20, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h20 : LitSat F.assign (22, true) :=
    use_clause (p72 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h21 : LitSat F.assign (8, true) :=
    use_clause (p92 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p2551 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h21 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h20 h),
        True.intro⟩
def c3701 : CNF.Clause Nat := [(77, true), (75, true), (39, true), (76, true), (98, false), (50, false)]
theorem p3701 (F : Frame G 3) : c3701.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (10, false) :=
    use_clause (p3700 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, false) :=
    use_clause (p3694 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (74, true) :=
    use_clause (p364 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h6 : LitSat F.assign (32, false) :=
    use_clause (p2367 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (21, false) :=
    use_clause (p2377 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p65 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3702 : CNF.Clause Nat := [(21, true), (75, true), (39, true), (76, true), (98, false), (50, false)]
theorem p3702 (F : Frame G 3) : c3702.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, true) :=
    use_clause (p3701 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (10, false) :=
    use_clause (p3700 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, false) :=
    use_clause (p3694 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, true) :=
    use_clause (p60 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (32, true) :=
    use_clause (p65 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (18, false) :=
    use_clause (p2050 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h8 : LitSat F.assign (29, false) :=
    use_clause (p3376 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h9 : LitSat F.assign (74, true) :=
    use_clause (p36 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (11, false) :=
    use_clause (p2155 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (99, false) :=
    use_clause (p2367 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p163 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3703 : CNF.Clause Nat := [(87, false), (75, true), (39, true), (76, true), (98, false), (50, false)]
theorem p3703 (F : Frame G 3) : c3703.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (77, true) :=
    use_clause (p3701 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (21, true) :=
    use_clause (p3702 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (74, false) :=
    use_clause (p2265 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (18, false) :=
    use_clause (p2050 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (29, false) :=
    use_clause (p3376 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p36 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c3704 : CNF.Clause Nat := [(29, true), (32, false), (75, true), (39, true), (76, true), (98, false), (50, false)]
theorem p3704 (F : Frame G 3) : c3704.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (29, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, true) :=
    use_clause (p3701 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (21, true) :=
    use_clause (p3702 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (74, false) :=
    use_clause (p2265 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, false) :=
    use_clause (p3694 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, false) :=
    use_clause (p3703 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (22, false) :=
    use_clause (p2326 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (99, true) :=
    use_clause (p368 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (18, true) :=
    use_clause (p36 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (33, true) :=
    use_clause (p152 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (30, false) :=
    use_clause (p2107 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h13 : LitSat F.assign (6, false) :=
    use_clause (p2325 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h14 : LitSat F.assign (8, true) :=
    use_clause (p40 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h15 : LitSat F.assign (17, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p2271 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c3705 : CNF.Clause Nat := [(32, false), (75, true), (39, true), (76, true), (98, false), (50, false)]
theorem p3705 (F : Frame G 3) : c3705.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (77, true) :=
    use_clause (p3701 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (21, true) :=
    use_clause (p3702 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (74, false) :=
    use_clause (p2265 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, false) :=
    use_clause (p3694 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, false) :=
    use_clause (p3703 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (29, true) :=
    use_clause (p3704 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (17, false) :=
    use_clause (p2106 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (6, false) :=
    use_clause (p2324 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c3706 : CNF.Clause Nat := [(75, true), (39, true), (50, false), (76, true), (98, false)]
theorem p3706 (F : Frame G 3) : c3706.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (10, false) :=
    use_clause (p3700 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, false) :=
    use_clause (p3703 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (32, false) :=
    use_clause (p3705 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p56 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3707 : CNF.Clause Nat := [(77, false), (21, false), (10, false), (87, true), (88, true), (39, true), (98, false), (50, false)]
theorem p3707 (F : Frame G 3) : c3707.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2922 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, false) :=
    use_clause (p2265 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c3708 : CNF.Clause Nat := [(6, false), (29, false), (21, false), (10, false), (87, true), (39, true), (76, true), (98, false), (50, false)]
theorem p3708 (F : Frame G 3) : c3708.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, false) :=
    use_clause (p3694 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, false) :=
    use_clause (p3707 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (74, false) :=
    use_clause (p2377 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (30, false) :=
    use_clause (p2412 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (8, false) :=
    use_clause (p1604 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p40 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3709 : CNF.Clause Nat := [(29, false), (21, false), (10, false), (87, true), (39, true), (76, true), (98, false), (50, false)]
theorem p3709 (F : Frame G 3) : c3709.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, false) :=
    use_clause (p3694 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, false) :=
    use_clause (p3707 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (74, false) :=
    use_clause (p2377 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (75, true) :=
    use_clause (p3706 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (6, false) :=
    use_clause (p3708 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h8 : LitSat F.assign (17, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (30, false) :=
    use_clause (p2411 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h10 : LitSat F.assign (8, true) :=
    use_clause (p40 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h11 : LitSat F.assign (11, false) :=
    use_clause (p1615 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (33, false) :=
    use_clause (p2415 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p77 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3710 : CNF.Clause Nat := [(87, true), (32, true), (39, true), (76, true), (98, false), (50, false)]
theorem p3710 (F : Frame G 3) : c3710.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, false) :=
    use_clause (p3694 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (10, true) :=
    use_clause (p56 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (21, true) :=
    use_clause (p51 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (77, false) :=
    use_clause (p3707 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (74, false) :=
    use_clause (p2377 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (29, false) :=
    use_clause (p3709 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (18, true) :=
    use_clause (p34 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h10 : LitSat F.assign (22, false) :=
    use_clause (p1654 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (30, false) :=
    use_clause (p2268 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h12 : LitSat F.assign (11, true) :=
    use_clause (p81 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (8, true) :=
    use_clause (p40 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p1615 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3711 : CNF.Clause Nat := [(18, true), (29, true), (74, true), (87, false), (39, true), (76, true), (98, false), (50, false)]
theorem p3711 (F : Frame G 3) : c3711.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (29, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (75, true) :=
    use_clause (p3706 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (22, false) :=
    use_clause (p2137 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (88, false) :=
    use_clause (p3694 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h5 : LitSat F.assign (77, true) :=
    use_clause (p34 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (11, true) :=
    use_clause (p170 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p3169 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c3712 : CNF.Clause Nat := [(18, false), (87, false), (88, true), (38, false), (98, false), (50, false)]
theorem p3712 (F : Frame G 3) : c3712.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2172 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (77, false) :=
    use_clause (p2050 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p375 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3713 : CNF.Clause Nat := [(77, true), (87, false), (75, false), (88, true), (39, true), (98, false), (50, false)]
theorem p3713 (F : Frame G 3) : c3713.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, false) :=
    use_clause (p2137 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (11, true) :=
    use_clause (p81 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (33, true) :=
    use_clause (p72 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (15, false) :=
    use_clause (p2173 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (26, false) :=
    use_clause (p2210 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c3714 : CNF.Clause Nat := [(10, false), (32, true), (39, true), (76, true), (98, false), (50, false)]
theorem p3714 (F : Frame G 3) : c3714.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, false) :=
    use_clause (p3694 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (75, true) :=
    use_clause (p3706 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p3710 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (77, true) :=
    use_clause (p3713 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (18, false) :=
    use_clause (p3712 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (29, false) :=
    use_clause (p3376 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h8 : LitSat F.assign (74, true) :=
    use_clause (p3711 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (21, false) :=
    use_clause (p2265 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h10 : LitSat F.assign (99, true) :=
    use_clause (p3170 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h11 : LitSat F.assign (15, true) :=
    use_clause (p2914 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  have h12 : LitSat F.assign (8, false) :=
    use_clause (p2045 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h13 : LitSat F.assign (86, false) :=
    use_clause (p2922 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h14 : LitSat F.assign (30, false) :=
    use_clause (p2225 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  exact use_clause (p202 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3715 : CNF.Clause Nat := [(32, true), (39, true), (76, true), (98, false), (50, false)]
theorem p3715 (F : Frame G 3) : c3715.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (75, true) :=
    use_clause (p3706 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, false) :=
    use_clause (p3694 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p3710 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (18, false) :=
    use_clause (p3712 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (77, true) :=
    use_clause (p3713 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (29, false) :=
    use_clause (p3376 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (74, true) :=
    use_clause (p3711 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (21, false) :=
    use_clause (p2265 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h10 : LitSat F.assign (10, false) :=
    use_clause (p3714 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p65 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3716 : CNF.Clause Nat := [(87, false), (39, true), (76, true), (98, false), (50, false)]
theorem p3716 (F : Frame G 3) : c3716.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (32, true) :=
    use_clause (p3715 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (75, true) :=
    use_clause (p3706 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, false) :=
    use_clause (p3694 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h4 : LitSat F.assign (18, false) :=
    use_clause (p3712 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (77, true) :=
    use_clause (p3713 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (29, false) :=
    use_clause (p3376 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, true) :=
    use_clause (p3170 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (74, true) :=
    use_clause (p3711 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p2367 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
def c3717 : CNF.Clause Nat := [(74, false), (77, false), (39, true), (76, true), (98, false), (50, false)]
theorem p3717 (F : Frame G 3) : c3717.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (75, true) :=
    use_clause (p3706 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (32, true) :=
    use_clause (p3715 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (8, false) :=
    use_clause (p2424 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, false) :=
    use_clause (p3716 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (88, false) :=
    use_clause (p3694 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (21, false) :=
    use_clause (p2265 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h8 : LitSat F.assign (11, false) :=
    use_clause (p2155 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (99, false) :=
    use_clause (p2367 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h10 : LitSat F.assign (10, true) :=
    use_clause (p60 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (33, true) :=
    use_clause (p75 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (22, true) :=
    use_clause (p79 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (86, false) :=
    use_clause (p2922 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h14 : LitSat F.assign (17, false) :=
    use_clause (p2213 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h15 : LitSat F.assign (30, true) :=
    use_clause (p39 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h16 : LitSat F.assign (6, true) :=
    use_clause (p13 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p2151 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c3718 : CNF.Clause Nat := [(29, true), (77, false), (39, true), (76, true), (98, false), (50, false)]
theorem p3718 (F : Frame G 3) : c3718.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (29, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, false) :=
    use_clause (p3716 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, false) :=
    use_clause (p3694 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (74, false) :=
    use_clause (p3717 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (75, true) :=
    use_clause (p3706 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (32, true) :=
    use_clause (p3715 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (8, false) :=
    use_clause (p2424 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (30, true) :=
    use_clause (p40 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h10 : LitSat F.assign (10, false) :=
    use_clause (p2922 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (21, true) :=
    use_clause (p60 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (18, false) :=
    use_clause (p2107 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h13 : LitSat F.assign (22, false) :=
    use_clause (p2326 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h14 : LitSat F.assign (99, true) :=
    use_clause (p168 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h15 : LitSat F.assign (33, true) :=
    use_clause (p169 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h16 : LitSat F.assign (11, true) :=
    use_clause (p170 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h17 : LitSat F.assign (26, false) :=
    use_clause (p2193 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h18 : LitSat F.assign (27, false) :=
    use_clause (p2056 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h19 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h20 : LitSat F.assign (5, true) :=
    use_clause (p14 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h18 h),
        True.intro⟩
  have h21 : LitSat F.assign (6, false) :=
    use_clause (p2329 F)
      ⟨fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h22 : LitSat F.assign (17, false) :=
    use_clause (p2416 F)
      ⟨fun h => False.elim (unit_incompatible h20 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h21 h),
        fun h => False.elim (unit_incompatible h22 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c3719 : CNF.Clause Nat := [(77, false), (39, true), (76, true), (98, false), (50, false)]
theorem p3719 (F : Frame G 3) : c3719.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (87, false) :=
    use_clause (p3716 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (32, true) :=
    use_clause (p3715 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, false) :=
    use_clause (p3694 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h4 : LitSat F.assign (74, false) :=
    use_clause (p3717 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h6 : LitSat F.assign (29, true) :=
    use_clause (p3718 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (17, false) :=
    use_clause (p2106 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h8 : LitSat F.assign (6, false) :=
    use_clause (p2324 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c3720 : CNF.Clause Nat := [(21, false), (29, false), (6, false), (99, false), (87, true), (32, false), (75, false), (88, true), (38, false), (98, false), (50, false)]
theorem p3720 (F : Frame G 3) : c3720.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p2367 F)
      ⟨fun h => h,
        fun h => False.elim (n10 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (30, false) :=
    use_clause (p2412 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (8, false) :=
    use_clause (p1688 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p40 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        True.intro⟩
def c3721 : CNF.Clause Nat := [(29, false), (6, false), (39, true), (76, true), (98, false), (50, false)]
theorem p3721 (F : Frame G 3) : c3721.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (32, true) :=
    use_clause (p3715 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, false) :=
    use_clause (p3694 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, false) :=
    use_clause (p3719 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (74, false) :=
    use_clause (p2367 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, false) :=
    use_clause (p3716 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (75, true) :=
    use_clause (p3706 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (21, false) :=
    use_clause (p3720 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h10 : LitSat F.assign (10, true) :=
    use_clause (p60 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (11, false) :=
    use_clause (p1608 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (8, false) :=
    use_clause (p1604 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h13 : LitSat F.assign (33, true) :=
    use_clause (p77 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (30, true) :=
    use_clause (p40 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p1684 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3722 : CNF.Clause Nat := [(6, false), (39, true), (76, true), (98, false), (50, false)]
theorem p3722 (F : Frame G 3) : c3722.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, false) :=
    use_clause (p3716 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, false) :=
    use_clause (p3694 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (32, true) :=
    use_clause (p3715 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (77, false) :=
    use_clause (p3719 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (74, false) :=
    use_clause (p2367 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h8 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (29, false) :=
    use_clause (p3721 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h10 : LitSat F.assign (18, true) :=
    use_clause (p34 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h11 : LitSat F.assign (33, false) :=
    use_clause (p2325 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h12 : LitSat F.assign (22, true) :=
    use_clause (p72 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (11, true) :=
    use_clause (p77 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (21, false) :=
    use_clause (p1654 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h15 : LitSat F.assign (10, false) :=
    use_clause (p1608 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p60 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3723 : CNF.Clause Nat := [(10, false), (18, false), (99, false), (87, true), (32, false), (75, false), (88, true), (38, false), (98, false), (50, false)]
theorem p3723 (F : Frame G 3) : c3723.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (74, false) :=
    use_clause (p2367 F)
      ⟨fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (30, false) :=
    use_clause (p2268 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (8, false) :=
    use_clause (p2227 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p40 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c3724 : CNF.Clause Nat := [(18, false), (39, true), (76, true), (98, false), (50, false)]
theorem p3724 (F : Frame G 3) : c3724.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (6, false) :=
    use_clause (p3722 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (17, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, false) :=
    use_clause (p3716 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, false) :=
    use_clause (p3694 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (32, true) :=
    use_clause (p3715 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (77, false) :=
    use_clause (p3719 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (74, false) :=
    use_clause (p2367 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h10 : LitSat F.assign (75, true) :=
    use_clause (p3706 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h11 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h12 : LitSat F.assign (10, false) :=
    use_clause (p3723 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h13 : LitSat F.assign (21, true) :=
    use_clause (p60 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (22, false) :=
    use_clause (p1654 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h15 : LitSat F.assign (15, false) :=
    use_clause (p1637 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h16 : LitSat F.assign (33, true) :=
    use_clause (p72 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h17 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h18 : LitSat F.assign (8, false) :=
    use_clause (p2387 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h16 h),
        True.intro⟩
  have h19 : LitSat F.assign (30, false) :=
    use_clause (p1670 F)
      ⟨fun h => False.elim (unit_incompatible h17 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p40 F)
      ⟨fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3725 : CNF.Clause Nat := [(39, true), (76, true), (98, false), (50, false)]
theorem p3725 (F : Frame G 3) : c3725.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p29 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, false) :=
    use_clause (p3694 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (32, true) :=
    use_clause (p3715 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, false) :=
    use_clause (p3716 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (77, false) :=
    use_clause (p3719 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (74, false) :=
    use_clause (p2367 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (6, false) :=
    use_clause (p3722 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (17, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h10 : LitSat F.assign (18, false) :=
    use_clause (p3724 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h11 : LitSat F.assign (29, true) :=
    use_clause (p34 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h12 : LitSat F.assign (8, false) :=
    use_clause (p2413 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h13 : LitSat F.assign (30, true) :=
    use_clause (p40 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h14 : LitSat F.assign (26, false) :=
    use_clause (p1664 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h15 : LitSat F.assign (33, false) :=
    use_clause (p1684 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h16 : LitSat F.assign (10, false) :=
    use_clause (p2411 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h17 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h18 : LitSat F.assign (22, true) :=
    use_clause (p72 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h19 : LitSat F.assign (21, true) :=
    use_clause (p60 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1641 F)
      ⟨fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3726 : CNF.Clause Nat := [(21, false), (87, true), (29, false), (38, false), (74, true), (77, true), (88, true), (32, false), (39, false), (76, true)]
theorem p3726 (F : Frame G 3) : c3726.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (75, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (11, false) :=
    use_clause (p1809 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (33, true) :=
    use_clause (p77 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (8, false) :=
    use_clause (p2235 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h7 : LitSat F.assign (30, false) :=
    use_clause (p1684 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p40 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c3727 : CNF.Clause Nat := [(87, true), (29, false), (38, false), (77, true), (88, true), (32, false), (76, true), (98, false), (50, false)]
theorem p3727 (F : Frame G 3) : c3727.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, false) :=
    use_clause (p2367 F)
      ⟨fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (75, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (39, true) :=
    use_clause (p3725 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (21, false) :=
    use_clause (p3726 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (10, true) :=
    use_clause (p60 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (30, false) :=
    use_clause (p2319 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h8 : LitSat F.assign (8, true) :=
    use_clause (p40 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (11, false) :=
    use_clause (p1615 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (33, false) :=
    use_clause (p2358 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p77 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3728 : CNF.Clause Nat := [(87, false), (38, false), (75, false), (77, true), (88, true), (32, false), (98, false), (50, false)]
theorem p3728 (F : Frame G 3) : c3728.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, false) :=
    use_clause (p2137 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (33, false) :=
    use_clause (p2414 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p72 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3729 : CNF.Clause Nat := [(38, false), (77, true), (88, true), (32, false), (76, true), (98, false), (50, false)]
theorem p3729 (F : Frame G 3) : c3729.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, false) :=
    use_clause (p2367 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (75, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h4 : LitSat F.assign (39, true) :=
    use_clause (p3725 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, false) :=
    use_clause (p3728 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (29, false) :=
    use_clause (p3727 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h8 : LitSat F.assign (18, true) :=
    use_clause (p34 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (10, false) :=
    use_clause (p3723 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h10 : LitSat F.assign (21, true) :=
    use_clause (p60 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (11, false) :=
    use_clause (p1809 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h12 : LitSat F.assign (22, false) :=
    use_clause (p1654 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p81 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3730 : CNF.Clause Nat := [(22, true), (87, true), (18, false), (38, true), (77, true), (88, true), (32, false), (39, false), (98, false), (50, false)]
theorem p3730 (F : Frame G 3) : c3730.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, false) :=
    use_clause (p2367 F)
      ⟨fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (11, true) :=
    use_clause (p81 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (33, true) :=
    use_clause (p72 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (30, false) :=
    use_clause (p2347 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (27, false) :=
    use_clause (p2093 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h8 : LitSat F.assign (8, true) :=
    use_clause (p40 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (5, true) :=
    use_clause (p11 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p1595 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3731 : CNF.Clause Nat := [(11, false), (10, false), (87, true), (18, false), (74, true), (77, true), (88, true), (32, false), (39, false), (76, true), (50, false)]
theorem p3731 (F : Frame G 3) : c3731.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (30, false) :=
    use_clause (p2347 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (8, false) :=
    use_clause (p1615 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p40 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c3732 : CNF.Clause Nat := [(87, true), (18, false), (77, true), (88, true), (32, false), (76, true), (98, false), (50, false)]
theorem p3732 (F : Frame G 3) : c3732.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, false) :=
    use_clause (p3729 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (74, false) :=
    use_clause (p2367 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (39, true) :=
    use_clause (p3725 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h5 : LitSat F.assign (22, true) :=
    use_clause (p3730 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (21, false) :=
    use_clause (p1654 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (10, true) :=
    use_clause (p60 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (11, false) :=
    use_clause (p3731 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h9 : LitSat F.assign (33, true) :=
    use_clause (p77 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (27, false) :=
    use_clause (p2369 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h11 : LitSat F.assign (5, true) :=
    use_clause (p11 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h12 : LitSat F.assign (8, false) :=
    use_clause (p1594 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h13 : LitSat F.assign (30, false) :=
    use_clause (p2351 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p40 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c3733 : CNF.Clause Nat := [(18, false), (77, true), (88, true), (32, false), (76, true), (98, false), (50, false)]
theorem p3733 (F : Frame G 3) : c3733.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, false) :=
    use_clause (p3729 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (74, false) :=
    use_clause (p2367 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (75, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h5 : LitSat F.assign (39, true) :=
    use_clause (p3725 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p3732 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (33, false) :=
    use_clause (p2414 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h8 : LitSat F.assign (5, false) :=
    use_clause (p2359 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h9 : LitSat F.assign (22, true) :=
    use_clause (p72 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (27, true) :=
    use_clause (p11 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p2382 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3734 : CNF.Clause Nat := [(87, false), (29, false), (38, true), (75, false), (77, true), (88, true), (32, false), (39, false), (98, false), (50, false)]
theorem p3734 (F : Frame G 3) : c3734.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (33, false) :=
    use_clause (p2414 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h3 : LitSat F.assign (22, true) :=
    use_clause (p72 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (27, false) :=
    use_clause (p2382 F)
      ⟨fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h5 : LitSat F.assign (5, false) :=
    use_clause (p2025 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p11 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c3735 : CNF.Clause Nat := [(11, false), (22, false), (86, false), (87, true), (29, false), (38, true), (99, false), (77, true), (32, false), (76, true), (98, false), (50, false)]
theorem p3735 (F : Frame G 3) : c3735.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p3725 F)
      ⟨fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n11 h),
        True.intro⟩
  have h2 : LitSat F.assign (27, false) :=
    use_clause (p2361 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n11 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h3 : LitSat F.assign (5, true) :=
    use_clause (p11 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (21, false) :=
    use_clause (p2357 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (10, false) :=
    use_clause (p1598 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p60 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3736 : CNF.Clause Nat := [(22, false), (77, true), (88, true), (32, false), (76, true), (98, false), (50, false)]
theorem p3736 (F : Frame G 3) : c3736.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, false) :=
    use_clause (p2367 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (39, true) :=
    use_clause (p3725 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (75, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h5 : LitSat F.assign (38, false) :=
    use_clause (p3729 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (18, false) :=
    use_clause (p3733 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (29, true) :=
    use_clause (p34 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h8 : LitSat F.assign (87, false) :=
    use_clause (p3734 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h9 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h10 : LitSat F.assign (11, false) :=
    use_clause (p3735 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h11 : LitSat F.assign (33, true) :=
    use_clause (p77 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (30, false) :=
    use_clause (p1684 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (8, true) :=
    use_clause (p40 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h14 : LitSat F.assign (10, false) :=
    use_clause (p2358 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h15 : LitSat F.assign (27, false) :=
    use_clause (p2332 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h16 : LitSat F.assign (21, true) :=
    use_clause (p60 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h17 : LitSat F.assign (5, true) :=
    use_clause (p11 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p2357 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3737 : CNF.Clause Nat := [(77, true), (88, true), (32, false), (76, true), (98, false), (50, false)]
theorem p3737 (F : Frame G 3) : c3737.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p3725 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (74, false) :=
    use_clause (p2367 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (75, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h5 : LitSat F.assign (38, false) :=
    use_clause (p3729 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (18, false) :=
    use_clause (p3733 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (29, true) :=
    use_clause (p34 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h8 : LitSat F.assign (87, false) :=
    use_clause (p3734 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h10 : LitSat F.assign (22, false) :=
    use_clause (p3736 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h11 : LitSat F.assign (11, true) :=
    use_clause (p81 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (33, true) :=
    use_clause (p72 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (30, false) :=
    use_clause (p1684 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (8, true) :=
    use_clause (p40 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h15 : LitSat F.assign (10, false) :=
    use_clause (p1615 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h16 : LitSat F.assign (21, false) :=
    use_clause (p2104 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  exact use_clause (p60 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3738 : CNF.Clause Nat := [(99, false), (87, true), (29, false), (74, true), (77, false), (88, true), (32, false), (39, false), (98, false), (50, false)]
theorem p3738 (F : Frame G 3) : c3738.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (8, false) :=
    use_clause (p2338 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (30, false) :=
    use_clause (p2691 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  exact use_clause (p40 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3739 : CNF.Clause Nat := [(87, true), (29, false), (74, true), (88, true), (32, false), (76, true), (98, false), (50, false)]
theorem p3739 (F : Frame G 3) : c3739.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, true) :=
    use_clause (p3737 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p3725 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (5, false) :=
    use_clause (p1747 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p3738 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (75, true) :=
    use_clause (p368 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (30, false) :=
    use_clause (p2249 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h8 : LitSat F.assign (8, true) :=
    use_clause (p40 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (38, false) :=
    use_clause (p2424 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h10 : LitSat F.assign (33, false) :=
    use_clause (p2112 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h11 : LitSat F.assign (27, true) :=
    use_clause (p11 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h12 : LitSat F.assign (22, true) :=
    use_clause (p70 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2332 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
def c3740 : CNF.Clause Nat := [(87, false), (74, true), (77, false), (88, true), (32, false), (39, false), (76, true), (50, false)]
theorem p3740 (F : Frame G 3) : c3740.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (75, false) :=
    use_clause (p1880 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p2203 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p368 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3741 : CNF.Clause Nat := [(99, true), (74, true), (88, true), (32, false), (76, true), (98, false), (50, false)]
theorem p3741 (F : Frame G 3) : c3741.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p3725 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (77, true) :=
    use_clause (p3737 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, false) :=
    use_clause (p3740 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (29, false) :=
    use_clause (p3739 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (75, true) :=
    use_clause (p368 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (30, false) :=
    use_clause (p2249 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h8 : LitSat F.assign (8, true) :=
    use_clause (p40 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (38, false) :=
    use_clause (p2424 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h10 : LitSat F.assign (10, false) :=
    use_clause (p1732 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h11 : LitSat F.assign (33, false) :=
    use_clause (p2112 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h12 : LitSat F.assign (21, true) :=
    use_clause (p60 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (11, true) :=
    use_clause (p75 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (18, true) :=
    use_clause (p167 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h15 : LitSat F.assign (22, true) :=
    use_clause (p70 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h16 : LitSat F.assign (15, false) :=
    use_clause (p1628 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h17 : LitSat F.assign (27, false) :=
    use_clause (p2064 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h18 : LitSat F.assign (26, true) :=
    use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h19 : LitSat F.assign (5, true) :=
    use_clause (p11 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  exact use_clause (p1818 F)
      ⟨fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
def c3742 : CNF.Clause Nat := [(74, true), (88, true), (32, false), (76, true), (98, false), (50, false)]
theorem p3742 (F : Frame G 3) : c3742.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, true) :=
    use_clause (p3737 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p3725 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, false) :=
    use_clause (p3740 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h5 : LitSat F.assign (29, false) :=
    use_clause (p3739 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, true) :=
    use_clause (p3741 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (8, false) :=
    use_clause (p2338 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (30, true) :=
    use_clause (p40 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (75, false) :=
    use_clause (p2249 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h10 : LitSat F.assign (10, false) :=
    use_clause (p2153 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h11 : LitSat F.assign (18, true) :=
    use_clause (p36 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h12 : LitSat F.assign (21, true) :=
    use_clause (p60 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (5, false) :=
    use_clause (p2351 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h14 : LitSat F.assign (27, false) :=
    use_clause (p2240 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
  have h15 : LitSat F.assign (38, false) :=
    use_clause (p2107 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p11 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h15 h),
        True.intro⟩
def c3743 : CNF.Clause Nat := [(86, false), (87, true), (22, false), (11, false), (74, false), (77, false), (76, true), (98, false), (50, false)]
theorem p3743 (F : Frame G 3) : c3743.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p3725 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, false) :=
    use_clause (p2035 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (27, false) :=
    use_clause (p2064 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (5, true) :=
    use_clause (p11 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (21, false) :=
    use_clause (p2087 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (15, false) :=
    use_clause (p2065 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h7 : LitSat F.assign (10, true) :=
    use_clause (p60 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (26, true) :=
    use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p2152 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3744 : CNF.Clause Nat := [(87, true), (88, true), (32, false), (76, true), (98, false), (50, false)]
theorem p3744 (F : Frame G 3) : c3744.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, true) :=
    use_clause (p3737 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, true) :=
    use_clause (p3742 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p2367 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (39, true) :=
    use_clause (p3725 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (33, false) :=
    use_clause (p2116 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (22, true) :=
    use_clause (p70 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (8, false) :=
    use_clause (p2066 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (11, true) :=
    use_clause (p75 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (86, false) :=
    use_clause (p3743 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h10 : LitSat F.assign (75, true) :=
    use_clause (p371 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (30, true) :=
    use_clause (p39 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p2249 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3745 : CNF.Clause Nat := [(88, true), (32, false), (76, true), (98, false), (50, false)]
theorem p3745 (F : Frame G 3) : c3745.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p3725 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (77, true) :=
    use_clause (p3737 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (74, true) :=
    use_clause (p3742 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (33, false) :=
    use_clause (p2116 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p2367 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (11, true) :=
    use_clause (p75 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (22, true) :=
    use_clause (p70 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (38, false) :=
    use_clause (p2035 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (9, false) :=
    use_clause (p2246 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h10 : LitSat F.assign (87, true) :=
    use_clause (p3744 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (75, false) :=
    use_clause (p1880 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h12 : LitSat F.assign (20, false) :=
    use_clause (p1873 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h13 : LitSat F.assign (27, false) :=
    use_clause (p2052 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h14 : LitSat F.assign (86, true) :=
    use_clause (p3291 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h15 : LitSat F.assign (5, true) :=
    use_clause (p11 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h16 : LitSat F.assign (10, false) :=
    use_clause (p3314 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  have h17 : LitSat F.assign (21, false) :=
    use_clause (p2087 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p265 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3746 : CNF.Clause Nat := [(74, false), (77, false), (32, false), (76, true), (98, false), (50, false)]
theorem p3746 (F : Frame G 3) : c3746.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p3725 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p3745 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p2105 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (38, false) :=
    use_clause (p2242 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, false) :=
    use_clause (p2789 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, false) :=
    use_clause (p2254 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (33, false) :=
    use_clause (p2116 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (22, false) :=
    use_clause (p2096 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (75, true) :=
    use_clause (p371 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (30, false) :=
    use_clause (p2249 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h11 : LitSat F.assign (8, true) :=
    use_clause (p225 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (26, false) :=
    use_clause (p2333 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h13 : LitSat F.assign (15, false) :=
    use_clause (p2334 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3747 : CNF.Clause Nat := [(75, false), (74, true), (77, false), (88, false), (32, false), (39, false), (98, false), (50, false)]
theorem p3747 (F : Frame G 3) : c3747.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2105 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (38, false) :=
    use_clause (p2242 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, false) :=
    use_clause (p2789 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (30, false) :=
    use_clause (p2249 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (8, true) :=
    use_clause (p42 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (26, false) :=
    use_clause (p2333 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (15, false) :=
    use_clause (p2334 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3748 : CNF.Clause Nat := [(77, false), (32, false), (76, true), (98, false), (50, false)]
theorem p3748 (F : Frame G 3) : c3748.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p3745 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p3725 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, false) :=
    use_clause (p2789 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p2105 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h5 : LitSat F.assign (74, false) :=
    use_clause (p3746 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (75, false) :=
    use_clause (p3747 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, true) :=
    use_clause (p371 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (8, false) :=
    use_clause (p2338 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (30, true) :=
    use_clause (p42 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h10 : LitSat F.assign (29, false) :=
    use_clause (p2691 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h11 : LitSat F.assign (18, false) :=
    use_clause (p2692 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p36 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c3749 : CNF.Clause Nat := [(18, false), (30, false), (99, false), (87, true), (75, false), (32, false), (76, true), (98, false), (50, false)]
theorem p3749 (F : Frame G 3) : c3749.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p3745 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p3725 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, false) :=
    use_clause (p2133 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (10, false) :=
    use_clause (p2331 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (5, false) :=
    use_clause (p2351 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (21, true) :=
    use_clause (p60 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (27, true) :=
    use_clause (p11 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h8 : LitSat F.assign (17, false) :=
    use_clause (p2103 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (6, false) :=
    use_clause (p2269 F)
      ⟨fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p25 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
def c3750 : CNF.Clause Nat := [(30, false), (99, false), (87, true), (74, true), (32, false), (76, true), (98, false), (50, false)]
theorem p3750 (F : Frame G 3) : c3750.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p3745 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p3725 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, false) :=
    use_clause (p3748 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (75, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (38, false) :=
    use_clause (p2133 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h6 : LitSat F.assign (18, false) :=
    use_clause (p3749 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h7 : LitSat F.assign (29, true) :=
    use_clause (p34 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h8 : LitSat F.assign (10, false) :=
    use_clause (p2354 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (21, true) :=
    use_clause (p60 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (27, false) :=
    use_clause (p2516 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h11 : LitSat F.assign (5, false) :=
    use_clause (p2356 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p11 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
def c3751 : CNF.Clause Nat := [(8, false), (75, false), (88, false), (32, false), (39, false), (98, false), (50, false)]
theorem p3751 (F : Frame G 3) : c3751.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (38, false) :=
    use_clause (p2133 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (26, false) :=
    use_clause (p2333 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (15, false) :=
    use_clause (p2334 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3752 : CNF.Clause Nat := [(86, false), (87, true), (74, true), (32, false), (76, true), (98, false), (50, false)]
theorem p3752 (F : Frame G 3) : c3752.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p3745 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p3725 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, false) :=
    use_clause (p3748 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (75, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (38, false) :=
    use_clause (p2133 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h6 : LitSat F.assign (29, false) :=
    use_clause (p2283 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h7 : LitSat F.assign (18, true) :=
    use_clause (p34 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h8 : LitSat F.assign (10, false) :=
    use_clause (p2666 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (21, true) :=
    use_clause (p60 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (27, false) :=
    use_clause (p2175 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h11 : LitSat F.assign (5, false) :=
    use_clause (p1971 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p11 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
def c3753 : CNF.Clause Nat := [(87, true), (74, true), (32, false), (76, true), (98, false), (50, false)]
theorem p3753 (F : Frame G 3) : c3753.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p3725 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p3745 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, false) :=
    use_clause (p3748 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (75, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (8, false) :=
    use_clause (p3751 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, false) :=
    use_clause (p3752 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, true) :=
    use_clause (p372 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (30, true) :=
    use_clause (p42 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p3750 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3754 : CNF.Clause Nat := [(5, false), (20, false), (99, true), (29, false), (87, false), (75, false), (77, true), (32, false), (39, false), (98, false), (50, false)]
theorem p3754 (F : Frame G 3) : c3754.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (20, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (22, false) :=
    use_clause (p2025 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (33, false) :=
    use_clause (p1870 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p71 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3755 : CNF.Clause Nat := [(30, false), (74, true), (32, false), (76, true), (98, false), (50, false)]
theorem p3755 (F : Frame G 3) : c3755.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (32, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, false) :=
    use_clause (p3748 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (75, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p3753 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, true) :=
    use_clause (p3745 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (39, true) :=
    use_clause (p3725 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (18, false) :=
    use_clause (p1879 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (29, true) :=
    use_clause (p34 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h8 : LitSat F.assign (9, false) :=
    use_clause (p1869 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h9 : LitSat F.assign (86, false) :=
    use_clause (p2283 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h10 : LitSat F.assign (38, false) :=
    use_clause (p2133 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h11 : LitSat F.assign (99, false) :=
    use_clause (p2335 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h12 : LitSat F.assign (20, true) :=
    use_clause (p106 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h13 : LitSat F.assign (5, false) :=
    use_clause (p3754 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h14 : LitSat F.assign (27, true) :=
    use_clause (p11 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  have h15 : LitSat F.assign (17, false) :=
    use_clause (p2103 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h16 : LitSat F.assign (6, true) :=
    use_clause (p25 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        True.intro⟩
  have h17 : LitSat F.assign (15, false) :=
    use_clause (p1914 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h18 : LitSat F.assign (22, false) :=
    use_clause (p2134 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h19 : LitSat F.assign (26, true) :=
    use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h17 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  have h20 : LitSat F.assign (11, true) :=
    use_clause (p80 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2124 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h20 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
def c3756 : CNF.Clause Nat := [(88, true), (86, false), (74, true), (38, true), (21, false), (18, false), (11, false), (10, false), (8, false), (5, false)]
theorem p3756 (F : Frame G 3) : c3756.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (77, true) :=
    use_clause (p1595 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p1601 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2195 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3757 : CNF.Clause Nat := [(87, false), (74, true), (39, false), (75, true), (50, false), (38, false), (22, false), (9, false)]
theorem p3757 (F : Frame G 3) : c3757.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (76, false) :=
    use_clause (p1837 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (77, false) :=
    use_clause (p1806 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p364 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3758 : CNF.Clause Nat := [(88, true), (74, true), (75, false), (38, true), (11, false), (10, false), (8, false), (5, false)]
theorem p3758 (F : Frame G 3) : c3758.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (77, true) :=
    use_clause (p1595 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p1601 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1820 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3759 : CNF.Clause Nat := [(77, false), (87, true), (74, false), (39, false), (50, false), (38, false), (21, false), (9, false), (8, false)]
theorem p3759 (F : Frame G 3) : c3759.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (76, false) :=
    use_clause (p1712 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, false) :=
    use_clause (p2265 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p376 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3760 : CNF.Clause Nat := [(88, false), (87, true), (75, false), (50, false), (38, false), (21, false), (9, false)]
theorem p3760 (F : Frame G 3) : c3760.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (76, false) :=
    use_clause (p2263 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, false) :=
    use_clause (p2111 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p376 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3761 : CNF.Clause Nat := [(76, true), (39, false), (87, true), (74, true), (75, true), (38, false), (18, false), (10, false), (8, false)]
theorem p3761 (F : Frame G 3) : c3761.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p376 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2364 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3762 : CNF.Clause Nat := [(87, true), (32, true), (88, false), (86, false), (74, true), (75, true), (38, true), (21, false), (15, false), (10, false), (8, false), (5, false)]
theorem p3762 (F : Frame G 3) : c3762.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (29, false) :=
    use_clause (p1973 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, true) :=
    use_clause (p1594 F)
      ⟨fun h => False.elim (n11 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h5 : LitSat F.assign (77, false) :=
    use_clause (p1752 F)
      ⟨fun h => False.elim (n11 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (98, false) :=
    use_clause (p2008 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p115 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3763 : CNF.Clause Nat := [(74, true), (75, true), (38, true), (21, false), (18, false), (15, false), (11, false), (10, false), (9, false), (8, false), (5, false)]
theorem p3763 (F : Frame G 3) : c3763.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (86, true) :=
    use_clause (p1593 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (88, true) :=
    use_clause (p3756 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h5 : LitSat F.assign (32, false) :=
    use_clause (p2666 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p3762 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h7 : LitSat F.assign (77, false) :=
    use_clause (p2400 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n7 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (76, true) :=
    use_clause (p1598 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (99, true) :=
    use_clause (p1597 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p2499 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
def c3764 : CNF.Clause Nat := [(87, true), (88, true), (50, false), (74, true), (75, true), (38, false), (20, false), (18, false), (15, false), (11, false), (10, false), (8, false), (6, false)]
theorem p3764 (F : Frame G 3) : c3764.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (20, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have n12 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p1611 F)
      ⟨fun h => False.elim (n12 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (76, true) :=
    use_clause (p3761 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n11 h),
        True.intro⟩
  have h4 : LitSat F.assign (77, false) :=
    use_clause (p1713 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p2388 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p375 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3765 : CNF.Clause Nat := [(88, true), (50, false), (6, false), (74, true), (75, true), (38, false), (20, false), (18, false), (15, false), (11, false), (10, false), (8, false)]
theorem p3765 (F : Frame G 3) : c3765.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (20, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p3764 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, false) :=
    use_clause (p3712 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, false) :=
    use_clause (p1904 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, true) :=
    use_clause (p370 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (39, true) :=
    use_clause (p1605 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2576 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3766 : CNF.Clause Nat := [(88, true), (86, false), (50, true), (74, true), (38, false), (11, false), (10, false), (8, false), (6, false), (5, false)]
theorem p3766 (F : Frame G 3) : c3766.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p30 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (77, true) :=
    use_clause (p1620 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p412 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1786 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3767 : CNF.Clause Nat := [(77, true), (39, false), (87, true), (88, true), (50, false), (74, false), (75, true), (38, false), (21, true), (10, false)]
theorem p3767 (F : Frame G 3) : c3767.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (76, false) :=
    use_clause (p2405 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, true) :=
    use_clause (p365 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (32, true) :=
    use_clause (p51 F)
      ⟨fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2169 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3768 : CNF.Clause Nat := [(77, true), (39, false), (87, true), (22, true), (88, true), (74, true), (38, false), (11, false), (10, false), (8, false), (5, false)]
theorem p3768 (F : Frame G 3) : c3768.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (76, true) :=
    use_clause (p1625 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (33, true) :=
    use_clause (p72 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2374 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c3769 : CNF.Clause Nat := [(88, true), (86, false), (74, true), (38, true), (11, false), (10, false), (8, false), (5, false)]
theorem p3769 (F : Frame G 3) : c3769.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (77, true) :=
    use_clause (p1595 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p1601 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p3314 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3770 : CNF.Clause Nat := [(87, true), (32, true), (88, false), (74, true), (38, true), (21, true), (15, false), (10, false), (8, false), (5, false)]
theorem p3770 (F : Frame G 3) : c3770.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (32, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (76, true) :=
    use_clause (p1594 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p49 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2008 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c3771 : CNF.Clause Nat := [(77, true), (74, false), (75, true), (38, true), (11, false), (10, false), (9, false), (5, false)]
theorem p3771 (F : Frame G 3) : c3771.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (76, true) :=
    use_clause (p1598 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, true) :=
    use_clause (p1597 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p2260 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c3772 : CNF.Clause Nat := [(74, true), (75, false), (38, true), (15, false), (11, false), (10, false), (8, false), (5, false)]
theorem p3772 (F : Frame G 3) : c3772.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p3758 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (76, false) :=
    use_clause (p1963 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, false) :=
    use_clause (p1924 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p1594 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c3773 : CNF.Clause Nat := [(87, true), (88, true), (50, false), (74, true), (75, true), (38, false), (18, false), (15, false), (11, false), (10, false), (8, false), (6, false)]
theorem p3773 (F : Frame G 3) : c3773.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p1611 F)
      ⟨fun h => False.elim (n11 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (76, true) :=
    use_clause (p3761 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p2388 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p374 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (77, true) :=
    use_clause (p375 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2364 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3774 : CNF.Clause Nat := [(77, true), (98, true), (88, true), (50, false), (74, true), (75, true), (38, false), (18, false), (15, false), (10, false), (8, false)]
theorem p3774 (F : Frame G 3) : c3774.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (76, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, true) :=
    use_clause (p370 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2388 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3775 : CNF.Clause Nat := [(88, true), (50, false), (74, true), (75, true), (38, false), (20, true), (18, false), (15, false), (11, false), (10, false), (8, false), (6, false), (5, false)]
theorem p3775 (F : Frame G 3) : c3775.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (20, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have n12 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p3773 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n11 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, false) :=
    use_clause (p3712 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, true) :=
    use_clause (p3774 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p2400 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, true) :=
    use_clause (p43 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (76, true) :=
    use_clause (p373 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2307 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n12 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c3776 : CNF.Clause Nat := [(21, false), (88, false), (50, false), (74, true), (75, true), (38, false), (9, false)]
theorem p3776 (F : Frame G 3) : c3776.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (76, false) :=
    use_clause (p2263 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h1 : LitSat F.assign (77, false) :=
    use_clause (p2300 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p364 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3777 : CNF.Clause Nat := [(77, true), (87, true), (88, false), (50, false), (74, true), (75, true), (15, false), (8, false)]
theorem p3777 (F : Frame G 3) : c3777.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (76, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p367 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1710 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c3778 : CNF.Clause Nat := [(98, false), (39, false), (87, true), (88, true), (50, false), (74, false), (75, true), (38, false), (11, false), (10, false)]
theorem p3778 (F : Frame G 3) : c3778.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, false) :=
    use_clause (p2035 F)
      ⟨fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (21, true) :=
    use_clause (p3767 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n9 h),
        True.intro⟩
  exact use_clause (p2377 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3779 : CNF.Clause Nat := [(87, true), (88, true), (50, false), (74, false), (75, true), (38, false), (11, false), (10, false), (9, false), (8, false), (6, false)]
theorem p3779 (F : Frame G 3) : c3779.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p1611 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, false) :=
    use_clause (p3778 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (76, true) :=
    use_clause (p376 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p2405 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (32, false) :=
    use_clause (p2384 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (77, true) :=
    use_clause (p375 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (21, true) :=
    use_clause (p49 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1740 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3780 : CNF.Clause Nat := [(88, true), (50, false), (74, false), (75, true), (38, false), (18, false), (15, false), (11, false), (10, false), (9, false), (8, false), (6, false)]
theorem p3780 (F : Frame G 3) : c3780.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p3779 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n11 h),
        True.intro⟩
  have h2 : LitSat F.assign (77, false) :=
    use_clause (p1825 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p2725 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p375 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3781 : CNF.Clause Nat := [(76, true), (50, true), (74, false), (75, true), (38, false), (11, false), (10, false), (9, false), (6, false), (5, false)]
theorem p3781 (F : Frame G 3) : c3781.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p30 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p1621 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (77, true) :=
    use_clause (p1623 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2035 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3782 : CNF.Clause Nat := [(88, true), (50, true), (74, true), (75, false), (38, false), (11, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3782 (F : Frame G 3) : c3782.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p30 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (77, true) :=
    use_clause (p1620 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p412 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1823 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3783 : CNF.Clause Nat := [(74, true), (75, true), (38, true), (18, false), (15, false), (11, false), (10, false), (9, false), (8, false), (5, false)]
theorem p3783 (F : Frame G 3) : c3783.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (86, true) :=
    use_clause (p1593 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (21, false) :=
    use_clause (p3763 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, true) :=
    use_clause (p3769 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h6 : LitSat F.assign (32, false) :=
    use_clause (p2666 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (87, true) :=
    use_clause (p3770 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h8 : LitSat F.assign (77, false) :=
    use_clause (p3314 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (76, true) :=
    use_clause (p1598 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (99, true) :=
    use_clause (p1597 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p2306 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3784 : CNF.Clause Nat := [(75, true), (38, true), (18, false), (15, false), (11, false), (10, false), (9, false), (8, false), (5, false)]
theorem p3784 (F : Frame G 3) : c3784.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (74, true) :=
    use_clause (p3783 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h4 : LitSat F.assign (77, true) :=
    use_clause (p3771 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, false) :=
    use_clause (p1825 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (32, false) :=
    use_clause (p2246 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (88, true) :=
    use_clause (p1601 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (98, false) :=
    use_clause (p2170 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (76, true) :=
    use_clause (p1596 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h10 : LitSat F.assign (99, true) :=
    use_clause (p1602 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (21, true) :=
    use_clause (p49 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2719 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3785 : CNF.Clause Nat := [(77, true), (39, false), (87, true), (88, true), (50, false), (74, true), (75, true), (38, false), (11, false), (10, false), (8, false), (5, false)]
theorem p3785 (F : Frame G 3) : c3785.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (76, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (22, true) :=
    use_clause (p3768 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n11 h),
        True.intro⟩
  exact use_clause (p2397 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3786 : CNF.Clause Nat := [(87, true), (88, true), (50, false), (74, true), (75, true), (38, false), (18, true), (15, false), (11, false), (10, false), (8, false), (6, false), (5, false)]
theorem p3786 (F : Frame G 3) : c3786.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (18, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have n12 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p1611 F)
      ⟨fun h => False.elim (n11 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, true) :=
    use_clause (p3785 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n12 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, false) :=
    use_clause (p2279 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (76, true) :=
    use_clause (p376 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, true) :=
    use_clause (p374 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (22, false) :=
    use_clause (p2397 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (33, false) :=
    use_clause (p2033 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (29, false) :=
    use_clause (p2278 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  exact use_clause (p176 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3787 : CNF.Clause Nat := [(77, true), (39, false), (87, false), (50, false), (74, true), (75, true), (18, true), (11, false), (9, false)]
theorem p3787 (F : Frame G 3) : c3787.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (18, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (76, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h1 : LitSat F.assign (29, true) :=
    use_clause (p35 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p2380 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        True.intro⟩
def c3788 : CNF.Clause Nat := [(39, false), (87, false), (88, true), (50, false), (74, true), (75, true), (38, false), (18, true), (11, false), (10, false), (9, false), (8, false)]
theorem p3788 (F : Frame G 3) : c3788.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (18, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (22, false) :=
    use_clause (p3757 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n10 h),
        True.intro⟩
  have h2 : LitSat F.assign (77, true) :=
    use_clause (p3787 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h3 : LitSat F.assign (29, false) :=
    use_clause (p2564 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p2466 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p175 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3789 : CNF.Clause Nat := [(88, true), (50, false), (74, true), (75, true), (38, false), (18, true), (15, false), (11, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3789 (F : Frame G 3) : c3789.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (18, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have n12 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))))
  have h0 : LitSat F.assign (87, true) :=
    use_clause (p3786 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n12 h),
        True.intro⟩
  have h1 : LitSat F.assign (39, false) :=
    use_clause (p3788 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, true) :=
    use_clause (p1603 F)
      ⟨fun h => False.elim (n11 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (77, true) :=
    use_clause (p1605 F)
      ⟨fun h => False.elim (n11 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p2400 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c3790 : CNF.Clause Nat := [(88, true), (50, false), (74, false), (75, true), (38, false), (18, true), (15, false), (11, false), (10, false), (9, false), (8, false), (6, false)]
theorem p3790 (F : Frame G 3) : c3790.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (18, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p3779 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n11 h),
        True.intro⟩
  have h2 : LitSat F.assign (77, false) :=
    use_clause (p1825 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, false) :=
    use_clause (p2405 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (29, false) :=
    use_clause (p2724 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p33 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3791 : CNF.Clause Nat := [(77, true), (39, false), (87, true), (88, true), (50, false), (74, true), (38, false), (11, false), (10, false), (8, false), (5, false)]
theorem p3791 (F : Frame G 3) : c3791.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (76, true) :=
    use_clause (p1625 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (22, true) :=
    use_clause (p3768 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  exact use_clause (p2397 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3792 : CNF.Clause Nat := [(87, true), (88, true), (50, false), (74, true), (75, false), (38, false), (11, false), (10, false), (8, false), (6, false), (5, false)]
theorem p3792 (F : Frame G 3) : c3792.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p1611 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, true) :=
    use_clause (p3791 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h4 : LitSat F.assign (32, false) :=
    use_clause (p1732 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p2363 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (76, true) :=
    use_clause (p376 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (21, true) :=
    use_clause (p49 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1992 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c3793 : CNF.Clause Nat := [(88, true), (50, true), (74, false), (75, false), (38, false), (11, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3793 (F : Frame G 3) : c3793.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p30 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p412 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, false) :=
    use_clause (p1823 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (33, false) :=
    use_clause (p1790 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (76, true) :=
    use_clause (p1623 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (22, true) :=
    use_clause (p72 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1798 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3794 : CNF.Clause Nat := [(87, true), (86, false), (74, true), (38, true), (18, true), (15, false), (11, false), (10, false), (8, false), (6, false), (5, false)]
theorem p3794 (F : Frame G 3) : c3794.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (18, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p3769 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h2 : LitSat F.assign (75, false) :=
    use_clause (p3772 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (76, true) :=
    use_clause (p1594 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, false) :=
    use_clause (p2026 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h7 : LitSat F.assign (32, false) :=
    use_clause (p1986 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h8 : LitSat F.assign (29, false) :=
    use_clause (p1912 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p143 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3795 : CNF.Clause Nat := [(76, true), (88, false), (75, true), (74, false), (38, true), (18, true), (15, false), (11, false), (10, false), (9, false), (5, false)]
theorem p3795 (F : Frame G 3) : c3795.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (18, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, true) :=
    use_clause (p3771 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p1596 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (29, false) :=
    use_clause (p2125 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (33, false) :=
    use_clause (p2116 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (22, false) :=
    use_clause (p2096 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (99, false) :=
    use_clause (p2738 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p160 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3796 : CNF.Clause Nat := [(75, true), (74, false), (38, true), (18, true), (15, false), (11, false), (10, false), (9, false), (8, false), (5, false)]
theorem p3796 (F : Frame G 3) : c3796.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (18, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (77, true) :=
    use_clause (p3771 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, false) :=
    use_clause (p1825 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (88, true) :=
    use_clause (p1601 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (76, true) :=
    use_clause (p3795 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, false) :=
    use_clause (p2260 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (98, false) :=
    use_clause (p2026 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p1602 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3797 : CNF.Clause Nat := [(88, true), (75, true), (74, true), (50, false), (38, false), (5, false), (15, false), (11, false), (10, false), (9, false), (8, false), (6, false)]
theorem p3797 (F : Frame G 3) : c3797.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (18, true) :=
    use_clause (p3789 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (20, false) :=
    use_clause (p3765 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  exact use_clause (p3775 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3798 : CNF.Clause Nat := [(87, true), (88, false), (75, true), (50, false), (74, true), (38, false), (15, false), (9, false), (8, false), (6, false)]
theorem p3798 (F : Frame G 3) : c3798.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (21, false) :=
    use_clause (p3776 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (77, true) :=
    use_clause (p3777 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, false) :=
    use_clause (p2141 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (76, true) :=
    use_clause (p376 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (32, true) :=
    use_clause (p49 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (39, false) :=
    use_clause (p2688 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (86, false) :=
    use_clause (p3644 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  exact use_clause (p1603 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
def c3799 : CNF.Clause Nat := [(75, true), (50, false), (74, true), (6, false), (38, false), (5, false), (15, false), (11, false), (10, false), (9, false), (8, false)]
theorem p3799 (F : Frame G 3) : c3799.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p3797 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (21, false) :=
    use_clause (p3776 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p3798 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, false) :=
    use_clause (p1894 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h5 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (86, false) :=
    use_clause (p2400 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, false) :=
    use_clause (p2045 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (39, true) :=
    use_clause (p1603 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h9 : LitSat F.assign (32, true) :=
    use_clause (p50 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2078 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
def c3800 : CNF.Clause Nat := [(88, true), (75, false), (50, false), (74, true), (38, false), (15, false), (11, false), (10, false), (8, false), (6, false), (5, false)]
theorem p3800 (F : Frame G 3) : c3800.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p3792 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h2 : LitSat F.assign (77, false) :=
    use_clause (p1810 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (22, false) :=
    use_clause (p2474 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (39, true) :=
    use_clause (p1605 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (33, true) :=
    use_clause (p72 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2650 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3801 : CNF.Clause Nat := [(50, false), (74, true), (8, false), (6, false), (38, false), (5, false), (15, false), (11, false), (10, false), (9, false)]
theorem p3801 (F : Frame G 3) : c3801.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (75, true) :=
    use_clause (p3799 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p3800 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (76, false) :=
    use_clause (p1963 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, false) :=
    use_clause (p1924 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (21, false) :=
    use_clause (p3760 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n9 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, true) :=
    use_clause (p376 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (39, true) :=
    use_clause (p1604 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (32, true) :=
    use_clause (p51 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2133 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3802 : CNF.Clause Nat := [(75, true), (50, true), (74, true), (38, false), (11, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3802 (F : Frame G 3) : c3802.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (39, true) :=
    use_clause (p30 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, true) :=
    use_clause (p1618 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p3766 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h3 : LitSat F.assign (76, false) :=
    use_clause (p2005 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p1621 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p1619 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p2129 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3803 : CNF.Clause Nat := [(74, true), (38, false), (8, false), (6, false), (9, false), (5, false), (15, false), (11, false), (10, false)]
theorem p3803 (F : Frame G 3) : c3803.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, false) :=
    use_clause (p3801 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p30 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (75, true) :=
    use_clause (p3802 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, true) :=
    use_clause (p3782 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, false) :=
    use_clause (p2117 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, false) :=
    use_clause (p2262 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h7 : LitSat F.assign (76, true) :=
    use_clause (p1619 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (98, true) :=
    use_clause (p413 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2009 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3804 : CNF.Clause Nat := [(88, true), (75, true), (74, false), (50, false), (38, false), (6, false), (15, false), (11, false), (10, false), (9, false), (8, false)]
theorem p3804 (F : Frame G 3) : c3804.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (18, false) :=
    use_clause (p3780 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p3790 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3805 : CNF.Clause Nat := [(98, false), (76, true), (88, false), (75, true), (50, false), (74, false), (38, false), (11, false), (9, false)]
theorem p3805 (F : Frame G 3) : c3805.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (39, true) :=
    use_clause (p3725 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (29, false) :=
    use_clause (p2541 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h2 : LitSat F.assign (77, false) :=
    use_clause (p2155 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h3 : LitSat F.assign (18, false) :=
    use_clause (p2170 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p33 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3806 : CNF.Clause Nat := [(75, true), (50, false), (38, false), (15, false), (11, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3806 (F : Frame G 3) : c3806.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (74, true) :=
    use_clause (p3803 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p3804 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (76, false) :=
    use_clause (p1893 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, false) :=
    use_clause (p3805 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, true) :=
    use_clause (p376 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (39, true) :=
    use_clause (p1606 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (77, false) :=
    use_clause (p1825 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (99, true) :=
    use_clause (p1626 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (32, false) :=
    use_clause (p2252 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        True.intro⟩
  have h10 : LitSat F.assign (21, false) :=
    use_clause (p2224 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  exact use_clause (p50 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3807 : CNF.Clause Nat := [(98, false), (39, false), (88, true), (75, false), (50, false), (74, false), (38, false), (15, false), (11, false), (10, false)]
theorem p3807 (F : Frame G 3) : c3807.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (33, false) :=
    use_clause (p2370 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, false) :=
    use_clause (p2081 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, false) :=
    use_clause (p2155 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p72 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3808 : CNF.Clause Nat := [(88, true), (75, false), (50, false), (74, false), (38, false), (15, false), (11, false), (10, false), (9, false), (8, false), (6, false)]
theorem p3808 (F : Frame G 3) : c3808.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, false) :=
    use_clause (p2734 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p1611 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, false) :=
    use_clause (p3807 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, true) :=
    use_clause (p376 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (33, false) :=
    use_clause (p1726 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, false) :=
    use_clause (p2405 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (32, false) :=
    use_clause (p2384 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h8 : LitSat F.assign (77, true) :=
    use_clause (p68 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (21, true) :=
    use_clause (p49 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p3759 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
def c3809 : CNF.Clause Nat := [(50, false), (38, false), (15, false), (11, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3809 (F : Frame G 3) : c3809.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (74, true) :=
    use_clause (p3803 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (75, true) :=
    use_clause (p3806 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, false) :=
    use_clause (p2734 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, true) :=
    use_clause (p3808 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h5 : LitSat F.assign (76, false) :=
    use_clause (p1893 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, false) :=
    use_clause (p2293 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, false) :=
    use_clause (p3684 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p376 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3810 : CNF.Clause Nat := [(75, true), (50, true), (74, false), (38, false), (11, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3810 (F : Frame G 3) : c3810.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p30 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (76, true) :=
    use_clause (p3781 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, false) :=
    use_clause (p1834 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p2260 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (87, true) :=
    use_clause (p412 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (77, true) :=
    use_clause (p1622 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (86, true) :=
    use_clause (p411 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p1957 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3811 : CNF.Clause Nat := [(38, false), (15, false), (8, false), (6, false), (9, false), (5, false), (10, false), (11, false)]
theorem p3811 (F : Frame G 3) : c3811.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (74, true) :=
    use_clause (p3803 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, false) :=
    use_clause (p3809 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (39, true) :=
    use_clause (p30 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (75, true) :=
    use_clause (p3810 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, true) :=
    use_clause (p3793 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, false) :=
    use_clause (p2117 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, false) :=
    use_clause (p2262 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h8 : LitSat F.assign (76, false) :=
    use_clause (p1834 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (32, false) :=
    use_clause (p1843 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h10 : LitSat F.assign (21, true) :=
    use_clause (p51 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (98, true) :=
    use_clause (p413 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2084 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
def c3812 : CNF.Clause Nat := [(74, true), (15, false), (11, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3812 (F : Frame G 3) : c3812.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (38, false) :=
    use_clause (p3811 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (75, false) :=
    use_clause (p3772 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (18, false) :=
    use_clause (p3784 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h5 : LitSat F.assign (86, true) :=
    use_clause (p1593 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p3794 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h7 : LitSat F.assign (77, false) :=
    use_clause (p3314 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  exact use_clause (p3787 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c3813 : CNF.Clause Nat := [(75, true), (74, false), (38, true), (15, false), (11, false), (10, false), (9, false), (8, false), (5, false)]
theorem p3813 (F : Frame G 3) : c3813.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (18, false) :=
    use_clause (p3784 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  exact use_clause (p3796 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
def c3814 : CNF.Clause Nat := [(15, false), (11, false), (8, false), (6, false), (9, false), (5, false), (10, false)]
theorem p3814 (F : Frame G 3) : c3814.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, false) :=
    use_clause (p3811 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (74, true) :=
    use_clause (p3812 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (75, true) :=
    use_clause (p3813 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, false) :=
    use_clause (p2734 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h7 : LitSat F.assign (88, true) :=
    use_clause (p1601 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (76, false) :=
    use_clause (p1963 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (32, false) :=
    use_clause (p1843 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h10 : LitSat F.assign (77, true) :=
    use_clause (p1598 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (98, true) :=
    use_clause (p376 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (21, true) :=
    use_clause (p51 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2086 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
def c3815 : CNF.Clause Nat := [(76, true), (77, false), (39, false), (87, true), (88, true), (50, false), (75, true), (74, true), (38, false), (10, false), (8, false)]
theorem p3815 (F : Frame G 3) : c3815.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p368 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p376 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (18, false) :=
    use_clause (p3761 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h5 : LitSat F.assign (33, false) :=
    use_clause (p2110 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (29, false) :=
    use_clause (p2572 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (22, false) :=
    use_clause (p2326 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p161 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3816 : CNF.Clause Nat := [(87, true), (88, true), (50, false), (75, true), (74, true), (38, false), (11, false), (10, false), (8, false), (6, false), (5, false)]
theorem p3816 (F : Frame G 3) : c3816.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p1611 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, true) :=
    use_clause (p3791 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, true) :=
    use_clause (p3815 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (32, false) :=
    use_clause (p1755 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (21, false) :=
    use_clause (p1764 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, false) :=
    use_clause (p2393 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p49 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3817 : CNF.Clause Nat := [(76, true), (98, true), (39, false), (87, false), (88, true), (75, true), (74, true), (38, false), (10, false)]
theorem p3817 (F : Frame G 3) : c3817.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (86, true) :=
    use_clause (p373 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1786 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3818 : CNF.Clause Nat := [(39, false), (88, true), (75, true), (50, false), (74, true), (8, false), (38, false), (87, false), (11, false), (10, false), (9, false)]
theorem p3818 (F : Frame G 3) : c3818.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (18, true) :=
    use_clause (p3788 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, false) :=
    use_clause (p3712 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (76, true) :=
    use_clause (p3817 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p2573 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (77, false) :=
    use_clause (p2000 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p375 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3819 : CNF.Clause Nat := [(88, true), (75, true), (74, true), (38, false), (11, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3819 (F : Frame G 3) : c3819.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (50, true) :=
    use_clause (p3802 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p3816 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, false) :=
    use_clause (p3818 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, true) :=
    use_clause (p1603 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (77, true) :=
    use_clause (p1605 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p2922 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (76, false) :=
    use_clause (p1957 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p1606 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
def c3820 : CNF.Clause Nat := [(76, true), (39, false), (87, true), (88, false), (75, true), (74, true), (38, false)]
theorem p3820 (F : Frame G 3) : c3820.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p376 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2242 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
end Cert35Steps
end Graffiti199Depleted.Catalogue.OrderEleven
