import Case35Part6
namespace Graffiti199Depleted.Catalogue.OrderEleven
namespace Cert35Steps
open Std.Sat
set_option maxRecDepth 4096
set_option maxHeartbeats 0
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj]
def c3821 : CNF.Clause Nat := [(39, false), (87, true), (88, false), (50, false), (75, true), (74, true), (38, false), (9, false), (8, false)]
theorem p3821 (F : Frame G 3) : c3821.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (76, true) :=
    use_clause (p3820 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, false) :=
    use_clause (p2026 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, false) :=
    use_clause (p2688 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p367 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3822 : CNF.Clause Nat := [(87, true), (88, false), (50, false), (75, true), (74, true), (38, false), (15, true), (11, false), (10, false), (9, false), (8, false), (6, false)]
theorem p3822 (F : Frame G 3) : c3822.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (15, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, false) :=
    use_clause (p3821 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h2 : LitSat F.assign (76, true) :=
    use_clause (p1604 F)
      ⟨fun h => False.elim (n11 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, true) :=
    use_clause (p1603 F)
      ⟨fun h => False.elim (n11 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p2184 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, false) :=
    use_clause (p2291 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p1612 F)
      ⟨fun h => False.elim (n11 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3823 : CNF.Clause Nat := [(39, false), (87, false), (21, true), (88, false), (75, true), (74, true), (38, false), (9, false), (8, false), (6, false)]
theorem p3823 (F : Frame G 3) : c3823.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (76, false) :=
    use_clause (p2011 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (98, false) :=
    use_clause (p2129 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (32, false) :=
    use_clause (p2078 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p50 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3824 : CNF.Clause Nat := [(76, true), (39, true), (50, false), (75, true), (10, false), (9, false), (6, false)]
theorem p3824 (F : Frame G 3) : c3824.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (98, true) :=
    use_clause (p1606 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p3725 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c3825 : CNF.Clause Nat := [(75, true), (74, true), (38, false), (11, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3825 (F : Frame G 3) : c3825.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (15, false) :=
    use_clause (p3814 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p3802 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p3819 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (21, false) :=
    use_clause (p3776 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p3822 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h5 : LitSat F.assign (39, false) :=
    use_clause (p3823 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, true) :=
    use_clause (p1603 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (76, true) :=
    use_clause (p3824 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h8 : LitSat F.assign (99, false) :=
    use_clause (p2573 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (77, false) :=
    use_clause (p1957 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p1607 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
def c3826 : CNF.Clause Nat := [(39, false), (22, true), (87, false), (88, true), (75, false), (38, false), (10, false), (9, false), (8, false)]
theorem p3826 (F : Frame G 3) : c3826.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, false) :=
    use_clause (p1823 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (33, true) :=
    use_clause (p72 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2650 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c3827 : CNF.Clause Nat := [(88, true), (74, true), (38, false), (11, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3827 (F : Frame G 3) : c3827.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (75, true) :=
    use_clause (p3825 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h1 : LitSat F.assign (15, false) :=
    use_clause (p3814 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p3782 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p3792 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h4 : LitSat F.assign (22, false) :=
    use_clause (p2474 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (39, false) :=
    use_clause (p3826 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (77, true) :=
    use_clause (p1605 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h7 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p1826 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3828 : CNF.Clause Nat := [(76, true), (39, false), (21, true), (87, true), (88, false), (75, false), (38, false)]
theorem p3828 (F : Frame G 3) : c3828.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, true) :=
    use_clause (p376 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (32, true) :=
    use_clause (p51 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2133 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c3829 : CNF.Clause Nat := [(39, false), (21, true), (87, true), (88, false), (75, false), (74, true), (38, false), (11, false), (10, false), (9, false), (8, false)]
theorem p3829 (F : Frame G 3) : c3829.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2262 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h2 : LitSat F.assign (76, true) :=
    use_clause (p3828 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (33, false) :=
    use_clause (p1726 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (30, false) :=
    use_clause (p1725 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h5 : LitSat F.assign (77, false) :=
    use_clause (p2688 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, false) :=
    use_clause (p2005 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p219 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3830 : CNF.Clause Nat := [(87, true), (50, false), (88, false), (75, false), (74, true), (38, false), (15, true), (11, false), (10, false), (9, false), (8, false), (6, false)]
theorem p3830 (F : Frame G 3) : c3830.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (15, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (21, false) :=
    use_clause (p3760 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n9 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, false) :=
    use_clause (p3829 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h3 : LitSat F.assign (76, true) :=
    use_clause (p1604 F)
      ⟨fun h => False.elim (n11 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h4 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p2291 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, false) :=
    use_clause (p1917 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, true) :=
    use_clause (p1612 F)
      ⟨fun h => False.elim (n11 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (77, true) :=
    use_clause (p372 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2058 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
def c3831 : CNF.Clause Nat := [(87, false), (88, false), (75, false), (38, false), (15, true), (11, false), (10, false), (9, false), (6, false)]
theorem p3831 (F : Frame G 3) : c3831.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (15, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, false) :=
    use_clause (p2117 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p3144 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p1612 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2468 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c3832 : CNF.Clause Nat := [(74, true), (38, false), (11, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3832 (F : Frame G 3) : c3832.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (15, false) :=
    use_clause (p3814 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (75, true) :=
    use_clause (p3825 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p3827 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, false) :=
    use_clause (p3831 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, false) :=
    use_clause (p3830 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (39, true) :=
    use_clause (p30 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (76, true) :=
    use_clause (p1619 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (21, true) :=
    use_clause (p3829 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p1831 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3833 : CNF.Clause Nat := [(77, true), (76, true), (39, false), (87, false), (88, true), (50, false), (75, true), (74, false), (38, false), (6, false)]
theorem p3833 (F : Frame G 3) : c3833.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (21, false) :=
    use_clause (p2224 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, false) :=
    use_clause (p3680 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (32, false) :=
    use_clause (p2237 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p50 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3834 : CNF.Clause Nat := [(77, false), (39, false), (87, false), (88, true), (50, false), (74, false), (38, false), (9, false), (6, false), (5, false)]
theorem p3834 (F : Frame G 3) : c3834.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (22, false) :=
    use_clause (p1806 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (33, false) :=
    use_clause (p1791 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p2201 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p70 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3835 : CNF.Clause Nat := [(39, false), (87, false), (88, true), (50, false), (75, true), (74, false), (38, false), (10, false), (9, false), (6, false), (5, false)]
theorem p3835 (F : Frame G 3) : c3835.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, false) :=
    use_clause (p3834 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (76, true) :=
    use_clause (p3833 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  exact use_clause (p2405 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3836 : CNF.Clause Nat := [(39, true), (50, false), (75, true), (74, false), (38, false), (11, false), (10, false), (9, false), (6, false)]
theorem p3836 (F : Frame G 3) : c3836.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (76, true) :=
    use_clause (p3824 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p2405 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (77, true) :=
    use_clause (p1607 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p1612 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2155 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3837 : CNF.Clause Nat := [(88, true), (75, true), (38, false), (11, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3837 (F : Frame G 3) : c3837.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (74, true) :=
    use_clause (p3832 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p3810 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p3836 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p3779 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p3835 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
def c3838 : CNF.Clause Nat := [(99, false), (98, true), (76, true), (88, false), (39, false), (50, false), (74, false), (38, false), (6, false)]
theorem p3838 (F : Frame G 3) : c3838.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p376 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (32, false) :=
    use_clause (p2252 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (21, false) :=
    use_clause (p2224 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p50 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3839 : CNF.Clause Nat := [(75, true), (74, false), (5, false), (38, false), (11, false), (10, false), (9, false), (8, false), (6, false)]
theorem p3839 (F : Frame G 3) : c3839.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p3810 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p3836 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p3837 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, false) :=
    use_clause (p1834 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p3805 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p376 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, false) :=
    use_clause (p3838 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h8 : LitSat F.assign (77, true) :=
    use_clause (p1626 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (86, true) :=
    use_clause (p377 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  exact use_clause (p1786 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
def c3840 : CNF.Clause Nat := [(98, false), (39, false), (50, false), (88, true), (75, false), (74, false), (38, false), (11, false), (10, false)]
theorem p3840 (F : Frame G 3) : c3840.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (22, false) :=
    use_clause (p2081 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (33, false) :=
    use_clause (p2146 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, false) :=
    use_clause (p2155 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p72 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3841 : CNF.Clause Nat := [(87, true), (50, false), (88, true), (75, false), (74, false), (38, false), (11, false), (10, false), (9, false), (8, false), (6, false)]
theorem p3841 (F : Frame G 3) : c3841.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p1611 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, false) :=
    use_clause (p3840 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (76, true) :=
    use_clause (p376 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (33, false) :=
    use_clause (p1726 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p2405 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (32, false) :=
    use_clause (p2384 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (77, true) :=
    use_clause (p68 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (21, true) :=
    use_clause (p49 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p3759 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
def c3842 : CNF.Clause Nat := [(88, true), (38, false), (11, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3842 (F : Frame G 3) : c3842.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (74, true) :=
    use_clause (p3832 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (75, true) :=
    use_clause (p3839 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (15, false) :=
    use_clause (p3814 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p3793 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, true) :=
    use_clause (p3841 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (22, false) :=
    use_clause (p2474 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (39, false) :=
    use_clause (p3826 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (99, false) :=
    use_clause (p2228 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h10 : LitSat F.assign (77, false) :=
    use_clause (p1826 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p375 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3843 : CNF.Clause Nat := [(39, false), (21, true), (87, true), (88, false), (75, false), (74, false), (38, false), (11, false), (9, false)]
theorem p3843 (F : Frame G 3) : c3843.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (76, false) :=
    use_clause (p1834 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p3828 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c3844 : CNF.Clause Nat := [(50, false), (88, false), (75, false), (74, false), (38, false), (15, true), (11, false), (10, false), (9, false), (6, false)]
theorem p3844 (F : Frame G 3) : c3844.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (15, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, false) :=
    use_clause (p3831 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h2 : LitSat F.assign (21, false) :=
    use_clause (p3760 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (39, false) :=
    use_clause (p3843 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h4 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p2261 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, false) :=
    use_clause (p3684 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p1612 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3845 : CNF.Clause Nat := [(38, false), (11, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3845 (F : Frame G 3) : c3845.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (15, false) :=
    use_clause (p3814 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, true) :=
    use_clause (p3832 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (75, true) :=
    use_clause (p3839 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, true) :=
    use_clause (p3842 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, false) :=
    use_clause (p3831 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (50, false) :=
    use_clause (p3844 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (39, true) :=
    use_clause (p30 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (76, false) :=
    use_clause (p1834 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (21, true) :=
    use_clause (p3843 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (98, true) :=
    use_clause (p376 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2084 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3846 : CNF.Clause Nat := [(87, true), (88, false), (86, false), (74, true), (26, false), (38, true), (10, false), (9, false), (8, false), (5, false)]
theorem p3846 (F : Frame G 3) : c3846.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (26, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (76, true) :=
    use_clause (p1594 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, false) :=
    use_clause (p2026 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h5 : LitSat F.assign (32, false) :=
    use_clause (p1986 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h6 : LitSat F.assign (21, false) :=
    use_clause (p1933 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p49 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3847 : CNF.Clause Nat := [(75, true), (74, true), (26, false), (38, true), (11, false), (10, false), (9, false), (8, false), (5, false)]
theorem p3847 (F : Frame G 3) : c3847.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (26, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (86, true) :=
    use_clause (p1593 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (88, true) :=
    use_clause (p3769 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, true) :=
    use_clause (p3846 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h6 : LitSat F.assign (77, false) :=
    use_clause (p3314 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (76, true) :=
    use_clause (p1598 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (99, true) :=
    use_clause (p1597 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p2573 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
def c3848 : CNF.Clause Nat := [(74, true), (26, false), (38, true), (11, false), (10, false), (9, false), (8, false), (5, false)]
theorem p3848 (F : Frame G 3) : c3848.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (26, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (75, true) :=
    use_clause (p3847 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, true) :=
    use_clause (p3758 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h5 : LitSat F.assign (76, false) :=
    use_clause (p2345 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (77, true) :=
    use_clause (p1598 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (87, true) :=
    use_clause (p1594 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p1820 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
def c3849 : CNF.Clause Nat := [(75, true), (74, false), (26, false), (38, true), (11, false), (10, false), (9, false), (5, false)]
theorem p3849 (F : Frame G 3) : c3849.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (26, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (77, true) :=
    use_clause (p3771 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, false) :=
    use_clause (p2121 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (76, true) :=
    use_clause (p1596 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, true) :=
    use_clause (p1602 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2260 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3850 : CNF.Clause Nat := [(88, true), (75, false), (74, false), (38, true), (11, false), (10, false), (8, false), (5, false)]
theorem p3850 (F : Frame G 3) : c3850.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p1601 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (77, false) :=
    use_clause (p1820 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (76, true) :=
    use_clause (p1598 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2260 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3851 : CNF.Clause Nat := [(11, false), (10, false), (8, false), (6, false), (9, false), (5, false)]
theorem p3851 (F : Frame G 3) : c3851.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (15, false) :=
    use_clause (p3814 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, false) :=
    use_clause (p3845 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (26, true) :=
    use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h6 : LitSat F.assign (74, true) :=
    use_clause (p3848 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (75, true) :=
    use_clause (p3849 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (88, true) :=
    use_clause (p3850 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (76, false) :=
    use_clause (p1891 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        True.intro⟩
  have h10 : LitSat F.assign (21, false) :=
    use_clause (p1928 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h11 : LitSat F.assign (77, true) :=
    use_clause (p1598 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (32, false) :=
    use_clause (p2246 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h13 : LitSat F.assign (98, false) :=
    use_clause (p2121 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p50 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3852 : CNF.Clause Nat := [(76, true), (87, true), (88, true), (39, false), (50, false), (75, true), (74, true), (38, false), (10, false), (8, false)]
theorem p3852 (F : Frame G 3) : c3852.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p3815 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
def c3853 : CNF.Clause Nat := [(77, true), (76, false), (87, true), (88, true), (39, false), (50, false), (75, true), (74, true), (11, true), (8, false)]
theorem p3853 (F : Frame G 3) : c3853.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, true) :=
    use_clause (p367 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (33, true) :=
    use_clause (p77 F)
      ⟨fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2381 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3854 : CNF.Clause Nat := [(87, true), (88, true), (39, false), (50, false), (75, true), (74, true), (38, false), (11, true), (10, false), (9, false), (8, false), (5, false)]
theorem p3854 (F : Frame G 3) : c3854.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (76, true) :=
    use_clause (p3852 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, true) :=
    use_clause (p3853 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h4 : LitSat F.assign (32, false) :=
    use_clause (p1722 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p2393 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (21, false) :=
    use_clause (p1764 F)
      ⟨fun h => False.elim (n11 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p49 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3855 : CNF.Clause Nat := [(88, true), (39, false), (5, false), (50, false), (75, true), (74, true), (38, false), (11, true), (10, false), (9, false), (8, false)]
theorem p3855 (F : Frame G 3) : c3855.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p3854 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, false) :=
    use_clause (p3757 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n9 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, true) :=
    use_clause (p81 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, true) :=
    use_clause (p79 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2466 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3856 : CNF.Clause Nat := [(39, false), (50, false), (75, true), (74, true), (38, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3856 (F : Frame G 3) : c3856.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (11, false) :=
    use_clause (p3851 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p3855 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (21, false) :=
    use_clause (p3776 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p3821 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p3823 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
def c3857 : CNF.Clause Nat := [(77, true), (87, true), (88, true), (76, false), (86, false), (50, false), (75, true), (74, true), (38, false), (11, true)]
theorem p3857 (F : Frame G 3) : c3857.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, true) :=
    use_clause (p367 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, true) :=
    use_clause (p81 F)
      ⟨fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1946 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3858 : CNF.Clause Nat := [(87, true), (88, true), (76, false), (86, false), (39, true), (50, false), (75, true), (74, true), (38, false), (11, true), (10, false), (6, false), (5, false)]
theorem p3858 (F : Frame G 3) : c3858.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have n12 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, true) :=
    use_clause (p3857 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, false) :=
    use_clause (p2922 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (32, false) :=
    use_clause (p1754 F)
      ⟨fun h => False.elim (n11 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (21, false) :=
    use_clause (p1752 F)
      ⟨fun h => False.elim (n12 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p49 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3859 : CNF.Clause Nat := [(88, true), (76, false), (5, false), (86, false), (39, true), (50, false), (75, true), (74, true), (38, false), (11, true), (10, false), (6, false)]
theorem p3859 (F : Frame G 3) : c3859.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p3858 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p2573 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (77, false) :=
    use_clause (p1957 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p74 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3860 : CNF.Clause Nat := [(87, true), (88, false), (76, false), (39, true), (50, false), (75, true), (74, true), (38, false), (9, false), (8, false), (6, false)]
theorem p3860 (F : Frame G 3) : c3860.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (21, false) :=
    use_clause (p3776 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, true) :=
    use_clause (p1603 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (15, false) :=
    use_clause (p3798 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h4 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p2184 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h6 : LitSat F.assign (77, true) :=
    use_clause (p367 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (32, true) :=
    use_clause (p49 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1754 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3861 : CNF.Clause Nat := [(50, false), (75, true), (74, true), (38, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3861 (F : Frame G 3) : c3861.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (11, false) :=
    use_clause (p3851 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, false) :=
    use_clause (p3856 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, true) :=
    use_clause (p1603 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (76, true) :=
    use_clause (p3824 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, true) :=
    use_clause (p3859 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p3860 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, false) :=
    use_clause (p2573 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (15, false) :=
    use_clause (p1894 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h9 : LitSat F.assign (77, false) :=
    use_clause (p1957 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        True.intro⟩
  have h10 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h11 : LitSat F.assign (22, true) :=
    use_clause (p80 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1916 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3862 : CNF.Clause Nat := [(77, true), (76, false), (88, true), (86, false), (39, false), (38, false), (11, true), (8, false)]
theorem p3862 (F : Frame G 3) : c3862.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (33, true) :=
    use_clause (p77 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2374 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c3863 : CNF.Clause Nat := [(87, true), (88, true), (75, true), (74, true), (38, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3863 (F : Frame G 3) : c3863.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, false) :=
    use_clause (p3861 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, true) :=
    use_clause (p1618 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (39, true) :=
    use_clause (p30 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (11, false) :=
    use_clause (p3851 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h5 : LitSat F.assign (76, true) :=
    use_clause (p1619 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h6 : LitSat F.assign (77, true) :=
    use_clause (p3862 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, false) :=
    use_clause (p2393 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (32, false) :=
    use_clause (p1722 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h9 : LitSat F.assign (21, false) :=
    use_clause (p1764 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  exact use_clause (p49 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3864 : CNF.Clause Nat := [(88, true), (75, true), (74, true), (38, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3864 (F : Frame G 3) : c3864.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (50, false) :=
    use_clause (p3861 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, true) :=
    use_clause (p1618 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p30 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (11, false) :=
    use_clause (p3851 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p3863 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (77, false) :=
    use_clause (p1786 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (76, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p3862 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c3865 : CNF.Clause Nat := [(87, true), (88, false), (39, false), (75, true), (74, true), (38, false), (9, false), (8, false)]
theorem p3865 (F : Frame G 3) : c3865.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (76, true) :=
    use_clause (p3820 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, false) :=
    use_clause (p2009 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, false) :=
    use_clause (p2688 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p367 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3866 : CNF.Clause Nat := [(75, true), (74, true), (5, false), (38, false), (10, false), (9, false), (8, false), (6, false)]
theorem p3866 (F : Frame G 3) : c3866.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (50, false) :=
    use_clause (p3861 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p30 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, true) :=
    use_clause (p1618 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p3864 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p3865 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (76, false) :=
    use_clause (p2011 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (77, false) :=
    use_clause (p1786 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p364 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3867 : CNF.Clause Nat := [(76, true), (87, true), (50, false), (88, true), (39, false), (75, false), (38, false), (11, true), (10, false), (8, false)]
theorem p3867 (F : Frame G 3) : c3867.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, true) :=
    use_clause (p376 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (32, false) :=
    use_clause (p3745 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, false) :=
    use_clause (p2363 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (21, true) :=
    use_clause (p51 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (33, true) :=
    use_clause (p77 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2235 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3868 : CNF.Clause Nat := [(87, true), (50, false), (88, true), (39, false), (75, false), (74, true), (38, false), (11, true), (10, false), (8, false)]
theorem p3868 (F : Frame G 3) : c3868.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (76, true) :=
    use_clause (p3867 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h3 : LitSat F.assign (22, false) :=
    use_clause (p1918 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (77, true) :=
    use_clause (p3862 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h5 : LitSat F.assign (33, true) :=
    use_clause (p84 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2033 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3869 : CNF.Clause Nat := [(50, false), (88, true), (39, false), (75, false), (74, true), (38, false), (11, true), (10, false), (9, false), (8, false)]
theorem p3869 (F : Frame G 3) : c3869.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p3868 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h2 : LitSat F.assign (77, false) :=
    use_clause (p1823 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (22, true) :=
    use_clause (p3826 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2396 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3870 : CNF.Clause Nat := [(87, true), (50, true), (88, true), (39, false), (75, false), (74, true), (38, false), (11, true), (10, false), (8, false), (6, false), (5, false)]
theorem p3870 (F : Frame G 3) : c3870.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (76, true) :=
    use_clause (p1619 F)
      ⟨fun h => False.elim (n11 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, true) :=
    use_clause (p3862 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h4 : LitSat F.assign (32, false) :=
    use_clause (p2244 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p2363 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (21, false) :=
    use_clause (p1764 F)
      ⟨fun h => False.elim (n11 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p49 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3871 : CNF.Clause Nat := [(88, true), (39, false), (74, true), (38, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3871 (F : Frame G 3) : c3871.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (75, true) :=
    use_clause (p3866 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (11, false) :=
    use_clause (p3851 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, false) :=
    use_clause (p3869 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p3870 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (77, false) :=
    use_clause (p1823 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (22, true) :=
    use_clause (p3826 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2653 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3872 : CNF.Clause Nat := [(50, false), (99, true), (87, true), (88, false), (39, false), (75, false), (38, false), (11, true), (9, false), (8, false)]
theorem p3872 (F : Frame G 3) : c3872.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (21, false) :=
    use_clause (p3760 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n8 h),
        True.intro⟩
  have h2 : LitSat F.assign (76, true) :=
    use_clause (p3828 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (33, false) :=
    use_clause (p1885 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (77, false) :=
    use_clause (p2688 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p76 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3873 : CNF.Clause Nat := [(39, false), (74, true), (38, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3873 (F : Frame G 3) : c3873.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (75, true) :=
    use_clause (p3866 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (11, false) :=
    use_clause (p3851 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p3871 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, false) :=
    use_clause (p2117 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p2262 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (50, false) :=
    use_clause (p3872 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (76, true) :=
    use_clause (p1619 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (33, false) :=
    use_clause (p2006 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (77, false) :=
    use_clause (p2688 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  exact use_clause (p76 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3874 : CNF.Clause Nat := [(87, true), (88, true), (39, true), (75, false), (74, true), (38, false), (11, true), (10, false), (8, false), (6, false), (5, false)]
theorem p3874 (F : Frame G 3) : c3874.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (76, true) :=
    use_clause (p1604 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h4 : LitSat F.assign (22, false) :=
    use_clause (p1918 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (77, true) :=
    use_clause (p81 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, false) :=
    use_clause (p2922 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (32, false) :=
    use_clause (p1754 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (21, false) :=
    use_clause (p1752 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p49 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3875 : CNF.Clause Nat := [(77, true), (87, false), (88, true), (50, false), (75, false), (38, false), (11, true)]
theorem p3875 (F : Frame G 3) : c3875.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, true) :=
    use_clause (p81 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2396 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c3876 : CNF.Clause Nat := [(88, true), (74, true), (38, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3876 (F : Frame G 3) : c3876.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, false) :=
    use_clause (p3873 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (75, true) :=
    use_clause (p3866 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (11, false) :=
    use_clause (p3851 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, true) :=
    use_clause (p3874 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (77, true) :=
    use_clause (p3875 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (22, false) :=
    use_clause (p1806 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (26, false) :=
    use_clause (p1826 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h9 : LitSat F.assign (99, true) :=
    use_clause (p79 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (33, true) :=
    use_clause (p84 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h12 : LitSat F.assign (76, false) :=
    use_clause (p2157 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h13 : LitSat F.assign (86, false) :=
    use_clause (p1799 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h14 : LitSat F.assign (98, false) :=
    use_clause (p2045 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  exact use_clause (p373 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3877 : CNF.Clause Nat := [(87, true), (88, false), (39, true), (75, false), (74, true), (38, false), (11, true), (10, false), (9, false), (8, false), (6, false)]
theorem p3877 (F : Frame G 3) : c3877.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (76, true) :=
    use_clause (p1604 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h3 : LitSat F.assign (15, false) :=
    use_clause (p1963 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h4 : LitSat F.assign (33, false) :=
    use_clause (p2055 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, false) :=
    use_clause (p2291 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h7 : LitSat F.assign (22, true) :=
    use_clause (p83 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (77, true) :=
    use_clause (p76 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (86, false) :=
    use_clause (p1919 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h10 : LitSat F.assign (98, false) :=
    use_clause (p2058 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p1609 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
def c3878 : CNF.Clause Nat := [(74, true), (38, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3878 (F : Frame G 3) : c3878.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (11, false) :=
    use_clause (p3851 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (75, true) :=
    use_clause (p3866 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (39, false) :=
    use_clause (p3873 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (88, true) :=
    use_clause (p3876 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p3877 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (15, false) :=
    use_clause (p1924 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (99, false) :=
    use_clause (p3144 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h10 : LitSat F.assign (77, false) :=
    use_clause (p1826 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h11 : LitSat F.assign (76, false) :=
    use_clause (p1895 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h12 : LitSat F.assign (98, false) :=
    use_clause (p2468 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h13 : LitSat F.assign (22, true) :=
    use_clause (p80 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (86, true) :=
    use_clause (p366 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h15 : LitSat F.assign (32, false) :=
    use_clause (p2082 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h16 : LitSat F.assign (21, false) :=
    use_clause (p1921 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
  exact use_clause (p50 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3879 : CNF.Clause Nat := [(77, true), (87, true), (50, false), (88, true), (39, false), (75, true), (74, false), (38, false), (10, false)]
theorem p3879 (F : Frame G 3) : c3879.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (21, true) :=
    use_clause (p3767 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (76, false) :=
    use_clause (p2405 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, false) :=
    use_clause (p2377 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p376 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3880 : CNF.Clause Nat := [(76, true), (21, true), (87, true), (50, false), (88, true)]
theorem p3880 (F : Frame G 3) : c3880.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, true) :=
    use_clause (p376 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (32, true) :=
    use_clause (p51 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p3745 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c3881 : CNF.Clause Nat := [(50, false), (88, true), (39, false), (75, true), (38, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3881 (F : Frame G 3) : c3881.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (74, true) :=
    use_clause (p3878 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h2 : LitSat F.assign (11, false) :=
    use_clause (p3851 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, false) :=
    use_clause (p3835 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h4 : LitSat F.assign (77, true) :=
    use_clause (p3879 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (21, false) :=
    use_clause (p3759 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (76, true) :=
    use_clause (p3880 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, false) :=
    use_clause (p2405 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (32, false) :=
    use_clause (p1722 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h9 : LitSat F.assign (20, false) :=
    use_clause (p1742 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h10 : LitSat F.assign (22, true) :=
    use_clause (p79 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (98, true) :=
    use_clause (p49 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (86, true) :=
    use_clause (p247 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2014 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
def c3882 : CNF.Clause Nat := [(77, true), (50, true), (88, true), (39, false), (75, true), (74, false), (38, false), (11, true), (10, false), (9, false), (6, false), (5, false)]
theorem p3882 (F : Frame G 3) : c3882.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, true) :=
    use_clause (p81 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (76, false) :=
    use_clause (p2260 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, false) :=
    use_clause (p2652 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p1621 F)
      ⟨fun h => False.elim (n11 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3883 : CNF.Clause Nat := [(76, true), (87, true), (50, true), (88, true), (39, false), (75, true), (74, false), (38, false), (11, true), (10, false), (9, false), (6, false), (5, false)]
theorem p3883 (F : Frame G 3) : c3883.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have n12 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, true) :=
    use_clause (p3882 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n12 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p1621 F)
      ⟨fun h => False.elim (n12 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p2738 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n12 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, true) :=
    use_clause (p371 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (33, true) :=
    use_clause (p75 F)
      ⟨fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2003 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3884 : CNF.Clause Nat := [(87, true), (88, true), (39, false), (75, true), (38, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3884 (F : Frame G 3) : c3884.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (11, false) :=
    use_clause (p3851 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, true) :=
    use_clause (p3878 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, false) :=
    use_clause (p3881 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h4 : LitSat F.assign (77, true) :=
    use_clause (p3882 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h5 : LitSat F.assign (76, true) :=
    use_clause (p3883 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, false) :=
    use_clause (p2260 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (21, false) :=
    use_clause (p1712 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (32, false) :=
    use_clause (p1722 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h9 : LitSat F.assign (20, false) :=
    use_clause (p1713 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h10 : LitSat F.assign (22, true) :=
    use_clause (p79 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (98, true) :=
    use_clause (p49 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (86, true) :=
    use_clause (p247 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2014 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
def c3885 : CNF.Clause Nat := [(88, true), (39, false), (75, true), (38, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3885 (F : Frame G 3) : c3885.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (74, true) :=
    use_clause (p3878 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h1 : LitSat F.assign (11, false) :=
    use_clause (p3851 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, false) :=
    use_clause (p3881 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, true) :=
    use_clause (p3882 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p3884 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p2129 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, false) :=
    use_clause (p2201 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (86, false) :=
    use_clause (p1786 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p377 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3886 : CNF.Clause Nat := [(98, false), (77, true), (50, false), (88, false), (39, false), (74, false), (38, false), (11, true), (6, false)]
theorem p3886 (F : Frame G 3) : c3886.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (22, false) :=
    use_clause (p2096 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h2 : LitSat F.assign (33, false) :=
    use_clause (p2015 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p86 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3887 : CNF.Clause Nat := [(76, false), (98, true), (77, true), (50, false), (75, true), (74, false), (38, false), (11, true), (10, false)]
theorem p3887 (F : Frame G 3) : c3887.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2405 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (22, true) :=
    use_clause (p80 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (33, true) :=
    use_clause (p76 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, true) :=
    use_clause (p377 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p1750 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c3888 : CNF.Clause Nat := [(77, true), (50, false), (88, false), (39, false), (75, true), (74, false), (38, false), (11, true), (10, false), (6, false), (5, false)]
theorem p3888 (F : Frame G 3) : c3888.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, false) :=
    use_clause (p3886 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h2 : LitSat F.assign (76, false) :=
    use_clause (p3887 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p3838 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p376 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (22, true) :=
    use_clause (p80 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (33, true) :=
    use_clause (p76 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (86, true) :=
    use_clause (p377 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h8 : LitSat F.assign (18, false) :=
    use_clause (p2028 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h9 : LitSat F.assign (21, false) :=
    use_clause (p1922 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h10 : LitSat F.assign (29, true) :=
    use_clause (p33 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h11 : LitSat F.assign (32, true) :=
    use_clause (p50 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1685 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3889 : CNF.Clause Nat := [(50, false), (39, false), (75, true), (38, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3889 (F : Frame G 3) : c3889.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p3885 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, true) :=
    use_clause (p3878 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (11, false) :=
    use_clause (p3851 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h4 : LitSat F.assign (77, true) :=
    use_clause (p3888 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (76, false) :=
    use_clause (p2688 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (98, false) :=
    use_clause (p2242 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (21, false) :=
    use_clause (p2300 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (87, true) :=
    use_clause (p376 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (32, true) :=
    use_clause (p50 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2078 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
def c3890 : CNF.Clause Nat := [(98, false), (77, true), (88, false), (39, false), (74, false), (38, false), (11, true), (6, false)]
theorem p3890 (F : Frame G 3) : c3890.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (22, false) :=
    use_clause (p2130 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h2 : LitSat F.assign (33, false) :=
    use_clause (p2015 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p86 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3891 : CNF.Clause Nat := [(87, true), (76, false), (98, true), (50, true), (88, false), (39, false), (38, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3891 (F : Frame G 3) : c3891.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (21, false) :=
    use_clause (p1831 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, true) :=
    use_clause (p410 F)
      ⟨fun h => False.elim (n11 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (32, false) :=
    use_clause (p2171 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p49 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3892 : CNF.Clause Nat := [(76, false), (98, true), (5, false), (50, true), (88, false), (39, false), (38, false), (10, false), (9, false), (8, false), (6, false)]
theorem p3892 (F : Frame G 3) : c3892.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (87, true) :=
    use_clause (p3891 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p2011 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c3893 : CNF.Clause Nat := [(98, true), (39, false), (75, true), (38, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3893 (F : Frame G 3) : c3893.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (50, false) :=
    use_clause (p3889 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p3885 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h2 : LitSat F.assign (76, true) :=
    use_clause (p1621 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p3892 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
def c3894 : CNF.Clause Nat := [(39, false), (75, true), (38, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3894 (F : Frame G 3) : c3894.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (74, true) :=
    use_clause (p3878 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (11, false) :=
    use_clause (p3851 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p3885 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p3893 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (77, false) :=
    use_clause (p2242 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p3890 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c3895 : CNF.Clause Nat := [(88, true), (76, false), (50, false), (75, true), (74, false), (38, false), (11, true), (10, false), (8, false)]
theorem p3895 (F : Frame G 3) : c3895.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2405 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (77, true) :=
    use_clause (p74 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (22, true) :=
    use_clause (p79 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (20, false) :=
    use_clause (p1742 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (86, false) :=
    use_clause (p1782 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, false) :=
    use_clause (p2066 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p43 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3896 : CNF.Clause Nat := [(75, true), (38, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3896 (F : Frame G 3) : c3896.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (74, true) :=
    use_clause (p3878 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (11, false) :=
    use_clause (p3851 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (39, false) :=
    use_clause (p3894 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (76, true) :=
    use_clause (p3824 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, false) :=
    use_clause (p2405 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (88, true) :=
    use_clause (p3895 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (21, false) :=
    use_clause (p2263 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (15, false) :=
    use_clause (p1893 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h10 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h11 : LitSat F.assign (98, false) :=
    use_clause (p2097 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h12 : LitSat F.assign (77, true) :=
    use_clause (p3887 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h13 : LitSat F.assign (86, true) :=
    use_clause (p377 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h14 : LitSat F.assign (87, false) :=
    use_clause (p1957 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
  have h15 : LitSat F.assign (32, false) :=
    use_clause (p1754 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
  exact use_clause (p49 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3897 : CNF.Clause Nat := [(77, true), (50, false), (88, true), (39, false), (75, false), (74, false), (38, false), (11, true), (10, false), (9, false), (8, false), (5, false)]
theorem p3897 (F : Frame G 3) : c3897.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (33, true) :=
    use_clause (p77 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (22, true) :=
    use_clause (p81 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, false) :=
    use_clause (p3875 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h5 : LitSat F.assign (21, false) :=
    use_clause (p2235 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n10 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (32, false) :=
    use_clause (p1889 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, false) :=
    use_clause (p2652 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p49 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3898 : CNF.Clause Nat := [(50, false), (88, true), (5, false), (39, false), (75, false), (74, false), (38, false), (11, true), (10, false), (9, false), (8, false)]
theorem p3898 (F : Frame G 3) : c3898.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, true) :=
    use_clause (p3897 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (32, false) :=
    use_clause (p1732 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, false) :=
    use_clause (p1823 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, false) :=
    use_clause (p2363 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h5 : LitSat F.assign (21, false) :=
    use_clause (p3759 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  exact use_clause (p49 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3899 : CNF.Clause Nat := [(77, true), (88, true), (39, false), (75, false), (74, false), (38, false), (11, true), (10, false), (8, false), (5, false)]
theorem p3899 (F : Frame G 3) : c3899.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (33, true) :=
    use_clause (p77 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (22, true) :=
    use_clause (p81 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, false) :=
    use_clause (p2260 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, false) :=
    use_clause (p2650 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (98, false) :=
    use_clause (p2652 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p376 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3900 : CNF.Clause Nat := [(88, true), (39, false), (38, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3900 (F : Frame G 3) : c3900.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (75, true) :=
    use_clause (p3896 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, true) :=
    use_clause (p3878 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (11, false) :=
    use_clause (p3851 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, false) :=
    use_clause (p3898 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (77, true) :=
    use_clause (p3899 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, false) :=
    use_clause (p1823 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, false) :=
    use_clause (p2363 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (86, true) :=
    use_clause (p410 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (76, true) :=
    use_clause (p376 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (22, false) :=
    use_clause (p2014 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h11 : LitSat F.assign (99, false) :=
    use_clause (p2260 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p79 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3901 : CNF.Clause Nat := [(98, true), (39, false), (38, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3901 (F : Frame G 3) : c3901.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (11, false) :=
    use_clause (p3851 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (75, true) :=
    use_clause (p3896 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p3900 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, false) :=
    use_clause (p2117 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p2262 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (50, false) :=
    use_clause (p3872 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (76, true) :=
    use_clause (p376 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p3892 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c3902 : CNF.Clause Nat := [(39, false), (38, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3902 (F : Frame G 3) : c3902.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (74, true) :=
    use_clause (p3878 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (11, false) :=
    use_clause (p3851 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p3900 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p3901 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (77, false) :=
    use_clause (p2242 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p3890 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3903 : CNF.Clause Nat := [(77, true), (88, true), (39, true), (75, false), (74, false), (38, false), (11, true), (10, false)]
theorem p3903 (F : Frame G 3) : c3903.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, false) :=
    use_clause (p3875 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, false) :=
    use_clause (p2405 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p3725 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p376 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3904 : CNF.Clause Nat := [(87, true), (98, true), (88, true), (39, true), (75, false), (74, false), (38, false), (11, true), (10, false), (9, false), (8, false), (6, false)]
theorem p3904 (F : Frame G 3) : c3904.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (76, true) :=
    use_clause (p376 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, true) :=
    use_clause (p1609 F)
      ⟨fun h => False.elim (n11 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p2405 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (22, false) :=
    use_clause (p1918 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p79 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3905 : CNF.Clause Nat := [(98, true), (88, true), (39, true), (75, false), (74, false), (38, false), (11, true), (10, false), (9, false), (8, false), (6, false)]
theorem p3905 (F : Frame G 3) : c3905.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, true) :=
    use_clause (p3903 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p3904 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h4 : LitSat F.assign (22, false) :=
    use_clause (p1806 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, true) :=
    use_clause (p79 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (76, false) :=
    use_clause (p2405 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (32, false) :=
    use_clause (p2273 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (21, false) :=
    use_clause (p2224 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p50 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3906 : CNF.Clause Nat := [(88, true), (39, true), (75, false), (74, false), (38, false), (11, true), (10, false), (9, false), (8, false), (6, false)]
theorem p3906 (F : Frame G 3) : c3906.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p3905 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h3 : LitSat F.assign (76, true) :=
    use_clause (p3725 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (33, false) :=
    use_clause (p2323 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p2405 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p75 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3907 : CNF.Clause Nat := [(76, true), (77, true), (98, true), (88, false), (39, true), (75, false), (74, false), (38, false), (11, true), (10, false), (6, false), (5, false)]
theorem p3907 (F : Frame G 3) : c3907.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p376 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (15, false) :=
    use_clause (p1924 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p3144 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (22, true) :=
    use_clause (p80 F)
      ⟨fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (33, true) :=
    use_clause (p76 F)
      ⟨fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (18, false) :=
    use_clause (p1865 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (32, false) :=
    use_clause (p1671 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (20, false) :=
    use_clause (p1728 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h11 : LitSat F.assign (21, true) :=
    use_clause (p50 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (29, false) :=
    use_clause (p1867 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h13 : LitSat F.assign (86, false) :=
    use_clause (p1922 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n6 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p108 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3908 : CNF.Clause Nat := [(77, true), (98, true), (88, false), (39, true), (75, false), (74, false), (38, false), (11, true), (10, false), (6, false), (5, false)]
theorem p3908 (F : Frame G 3) : c3908.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (76, true) :=
    use_clause (p3907 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p2405 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (33, false) :=
    use_clause (p2055 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p76 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3909 : CNF.Clause Nat := [(87, false), (77, false), (88, false), (39, true), (75, false), (10, false), (9, false)]
theorem p3909 (F : Frame G 3) : c3909.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (15, false) :=
    use_clause (p1924 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (26, false) :=
    use_clause (p1826 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c3910 : CNF.Clause Nat := [(98, true), (38, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3910 (F : Frame G 3) : c3910.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (11, false) :=
    use_clause (p3851 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, true) :=
    use_clause (p3878 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (75, true) :=
    use_clause (p3896 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (39, false) :=
    use_clause (p3902 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, true) :=
    use_clause (p3906 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (77, true) :=
    use_clause (p3908 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h8 : LitSat F.assign (21, false) :=
    use_clause (p2300 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (87, false) :=
    use_clause (p3909 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (76, true) :=
    use_clause (p376 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (86, true) :=
    use_clause (p1609 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h12 : LitSat F.assign (32, true) :=
    use_clause (p49 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1754 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
def c3911 : CNF.Clause Nat := [(38, false), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3911 (F : Frame G 3) : c3911.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (11, false) :=
    use_clause (p3851 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (74, true) :=
    use_clause (p3878 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (75, true) :=
    use_clause (p3896 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (39, false) :=
    use_clause (p3902 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p30 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (88, true) :=
    use_clause (p3906 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, true) :=
    use_clause (p3910 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, true) :=
    use_clause (p3684 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (76, true) :=
    use_clause (p3725 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p2808 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
def c3912 : CNF.Clause Nat := [(77, true), (76, false), (98, true), (75, true), (74, true), (88, true), (50, false)]
theorem p3912 (F : Frame G 3) : c3912.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p367 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2573 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3913 : CNF.Clause Nat := [(98, true), (86, false), (75, true), (74, true), (88, true), (38, true), (10, false), (9, false), (5, false)]
theorem p3913 (F : Frame G 3) : c3913.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (76, true) :=
    use_clause (p1596 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h4 : LitSat F.assign (77, true) :=
    use_clause (p3912 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, false) :=
    use_clause (p3314 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (32, false) :=
    use_clause (p1755 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (21, false) :=
    use_clause (p1764 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p49 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3914 : CNF.Clause Nat := [(76, true), (86, false), (75, true), (74, true), (38, true), (10, false), (8, false), (5, false)]
theorem p3914 (F : Frame G 3) : c3914.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p1594 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p3314 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c3915 : CNF.Clause Nat := [(75, true), (74, true), (88, true), (38, true), (11, true), (10, false), (9, false), (8, false), (5, false)]
theorem p3915 (F : Frame G 3) : c3915.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (86, true) :=
    use_clause (p1593 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p3913 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (76, true) :=
    use_clause (p3914 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h6 : LitSat F.assign (77, false) :=
    use_clause (p2393 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (33, false) :=
    use_clause (p2381 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p77 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3916 : CNF.Clause Nat := [(76, true), (98, true), (75, false), (74, true), (88, true), (38, true), (11, true), (10, false), (8, false), (5, false)]
theorem p3916 (F : Frame G 3) : c3916.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p1594 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (86, true) :=
    use_clause (p373 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (77, false) :=
    use_clause (p3314 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (33, true) :=
    use_clause (p77 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (22, true) :=
    use_clause (p81 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (29, false) :=
    use_clause (p2233 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h10 : LitSat F.assign (18, false) :=
    use_clause (p2028 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p34 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
def c3917 : CNF.Clause Nat := [(77, true), (76, false), (98, true), (74, true), (88, true), (38, true), (11, true), (10, false), (8, false)]
theorem p3917 (F : Frame G 3) : c3917.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (33, true) :=
    use_clause (p77 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, false) :=
    use_clause (p2573 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (32, false) :=
    use_clause (p2350 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (29, false) :=
    use_clause (p2355 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (15, false) :=
    use_clause (p2373 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h10 : LitSat F.assign (18, true) :=
    use_clause (p137 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (26, true) :=
    use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p2304 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c3918 : CNF.Clause Nat := [(98, true), (74, true), (88, true), (38, true), (11, true), (10, false), (9, false), (8, false), (5, false)]
theorem p3918 (F : Frame G 3) : c3918.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (75, true) :=
    use_clause (p3915 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (76, true) :=
    use_clause (p3916 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (77, true) :=
    use_clause (p3917 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (32, false) :=
    use_clause (p1732 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (87, false) :=
    use_clause (p2000 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (21, true) :=
    use_clause (p49 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p1752 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
def c3919 : CNF.Clause Nat := [(77, true), (87, false), (75, false), (88, true), (38, true), (11, true), (8, false)]
theorem p3919 (F : Frame G 3) : c3919.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (33, true) :=
    use_clause (p77 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (15, false) :=
    use_clause (p2229 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h6 : LitSat F.assign (26, false) :=
    use_clause (p2385 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c3920 : CNF.Clause Nat := [(87, false), (98, false), (75, false), (88, true), (38, true), (11, true), (8, false), (5, false)]
theorem p3920 (F : Frame G 3) : c3920.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (77, true) :=
    use_clause (p3919 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (33, false) :=
    use_clause (p2112 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h5 : LitSat F.assign (22, false) :=
    use_clause (p1819 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p84 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3921 : CNF.Clause Nat := [(74, true), (88, true), (38, true), (11, true), (10, false), (9, false), (8, false), (5, false)]
theorem p3921 (F : Frame G 3) : c3921.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (75, true) :=
    use_clause (p3915 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p3918 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, false) :=
    use_clause (p3920 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (76, true) :=
    use_clause (p1594 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h8 : LitSat F.assign (77, false) :=
    use_clause (p2393 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (33, false) :=
    use_clause (p2381 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p77 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3922 : CNF.Clause Nat := [(77, true), (98, false), (76, true), (75, true), (74, false), (88, true), (38, true), (11, true), (10, false)]
theorem p3922 (F : Frame G 3) : c3922.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (33, true) :=
    use_clause (p77 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (22, true) :=
    use_clause (p81 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (29, false) :=
    use_clause (p2366 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h7 : LitSat F.assign (87, false) :=
    use_clause (p2214 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (26, false) :=
    use_clause (p2222 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (18, true) :=
    use_clause (p33 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h10 : LitSat F.assign (21, true) :=
    use_clause (p3880 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h11 : LitSat F.assign (15, true) :=
    use_clause (p9 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  exact use_clause (p1631 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3923 : CNF.Clause Nat := [(76, true), (75, true), (74, false), (88, true), (38, true), (11, true), (10, false), (9, false), (5, false)]
theorem p3923 (F : Frame G 3) : c3923.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p1596 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (77, true) :=
    use_clause (p3922 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (33, false) :=
    use_clause (p2116 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, false) :=
    use_clause (p2738 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p75 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3924 : CNF.Clause Nat := [(76, false), (88, true), (38, true), (11, true), (10, false), (9, false), (8, false), (5, false)]
theorem p3924 (F : Frame G 3) : c3924.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (74, true) :=
    use_clause (p3921 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p2260 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (77, true) :=
    use_clause (p74 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (22, true) :=
    use_clause (p79 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (33, true) :=
    use_clause (p75 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (87, false) :=
    use_clause (p2000 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h9 : LitSat F.assign (86, false) :=
    use_clause (p1750 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h10 : LitSat F.assign (98, false) :=
    use_clause (p2066 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p1599 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
def c3925 : CNF.Clause Nat := [(77, true), (75, false), (76, true), (74, false), (88, true), (38, true), (11, true), (10, false), (8, false)]
theorem p3925 (F : Frame G 3) : c3925.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (22, true) :=
    use_clause (p81 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, false) :=
    use_clause (p3919 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p376 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (21, true) :=
    use_clause (p3880 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (26, false) :=
    use_clause (p2222 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (15, false) :=
    use_clause (p1634 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3926 : CNF.Clause Nat := [(87, false), (77, false), (74, false), (88, true), (50, false), (39, false), (11, true), (9, false), (5, false)]
theorem p3926 (F : Frame G 3) : c3926.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (22, false) :=
    use_clause (p1995 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p2201 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p79 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3927 : CNF.Clause Nat := [(88, true), (38, true), (11, true), (10, false), (9, false), (8, false), (5, false)]
theorem p3927 (F : Frame G 3) : c3927.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (74, true) :=
    use_clause (p3921 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, false) :=
    use_clause (p3924 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (75, true) :=
    use_clause (p3923 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (77, true) :=
    use_clause (p3925 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (87, false) :=
    use_clause (p3926 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h8 : LitSat F.assign (98, true) :=
    use_clause (p376 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (33, false) :=
    use_clause (p2116 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h10 : LitSat F.assign (99, false) :=
    use_clause (p2738 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  exact use_clause (p75 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3928 : CNF.Clause Nat := [(77, true), (76, false), (86, false), (75, true), (74, true), (88, false), (38, true), (11, true), (10, false), (9, false), (6, false), (5, false)]
theorem p3928 (F : Frame G 3) : c3928.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (98, false) :=
    use_clause (p2026 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p367 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p2573 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (22, true) :=
    use_clause (p80 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (26, false) :=
    use_clause (p1916 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h8 : LitSat F.assign (18, false) :=
    use_clause (p2021 F)
      ⟨fun h => False.elim (n11 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (15, true) :=
    use_clause (p9 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h10 : LitSat F.assign (29, true) :=
    use_clause (p35 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p1956 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3929 : CNF.Clause Nat := [(75, true), (74, true), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3929 (F : Frame G 3) : c3929.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (11, false) :=
    use_clause (p3851 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, false) :=
    use_clause (p3911 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p3927 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (86, true) :=
    use_clause (p1593 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (76, true) :=
    use_clause (p3914 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h8 : LitSat F.assign (98, false) :=
    use_clause (p2026 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h9 : LitSat F.assign (32, false) :=
    use_clause (p1986 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h10 : LitSat F.assign (77, true) :=
    use_clause (p3928 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h11 : LitSat F.assign (87, false) :=
    use_clause (p2000 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  have h12 : LitSat F.assign (21, false) :=
    use_clause (p1764 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  exact use_clause (p49 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3930 : CNF.Clause Nat := [(87, false), (75, false), (88, false), (38, true), (11, true), (10, false), (9, false)]
theorem p3930 (F : Frame G 3) : c3930.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (15, false) :=
    use_clause (p1924 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (26, true) :=
    use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (77, false) :=
    use_clause (p1826 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (99, false) :=
    use_clause (p2444 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h7 : LitSat F.assign (33, false) :=
    use_clause (p2100 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p76 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3931 : CNF.Clause Nat := [(74, true), (10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3931 (F : Frame G 3) : c3931.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (11, false) :=
    use_clause (p3851 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (38, false) :=
    use_clause (p3911 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p3927 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (75, true) :=
    use_clause (p3929 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, false) :=
    use_clause (p3930 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (76, true) :=
    use_clause (p1594 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (15, false) :=
    use_clause (p1963 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h9 : LitSat F.assign (26, false) :=
    use_clause (p2345 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3932 : CNF.Clause Nat := [(98, false), (74, false), (88, false), (50, false), (39, false), (11, true), (5, false)]
theorem p3932 (F : Frame G 3) : c3932.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (22, false) :=
    use_clause (p2096 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h2 : LitSat F.assign (33, false) :=
    use_clause (p2101 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, true) :=
    use_clause (p83 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (77, true) :=
    use_clause (p86 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2738 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
def c3933 : CNF.Clause Nat := [(77, true), (86, false), (99, true), (76, false), (74, false), (50, false), (11, true), (10, false)]
theorem p3933 (F : Frame G 3) : c3933.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (22, true) :=
    use_clause (p80 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (33, true) :=
    use_clause (p76 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1750 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3934 : CNF.Clause Nat := [(75, true), (74, false), (88, false), (38, true), (11, true), (10, false), (9, false), (5, false)]
theorem p3934 (F : Frame G 3) : c3934.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (98, false) :=
    use_clause (p3932 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, true) :=
    use_clause (p1596 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p2260 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (86, true) :=
    use_clause (p377 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (32, false) :=
    use_clause (p1986 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (77, true) :=
    use_clause (p3933 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (87, false) :=
    use_clause (p2000 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h10 : LitSat F.assign (21, false) :=
    use_clause (p1764 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  exact use_clause (p49 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3935 : CNF.Clause Nat := [(10, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3935 (F : Frame G 3) : c3935.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (11, false) :=
    use_clause (p3851 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, false) :=
    use_clause (p3911 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (39, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (88, true) :=
    use_clause (p3927 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (74, true) :=
    use_clause (p3931 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, false) :=
    use_clause (p3932 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (75, true) :=
    use_clause (p3934 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (87, false) :=
    use_clause (p3930 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h10 : LitSat F.assign (76, true) :=
    use_clause (p376 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (15, false) :=
    use_clause (p1963 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h12 : LitSat F.assign (26, false) :=
    use_clause (p2613 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3936 : CNF.Clause Nat := [(39, false), (99, false), (77, false), (76, true), (50, false), (38, false), (10, true), (8, false)]
theorem p3936 (F : Frame G 3) : c3936.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (32, false) :=
    use_clause (p2338 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (87, false) :=
    use_clause (p2466 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p56 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3937 : CNF.Clause Nat := [(76, true), (50, false), (75, true), (88, true), (74, true), (38, false), (10, true), (9, false), (8, false), (6, false)]
theorem p3937 (F : Frame G 3) : c3937.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p368 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (39, false) :=
    use_clause (p3936 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, true) :=
    use_clause (p1603 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p3725 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p53 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (32, true) :=
    use_clause (p55 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (21, true) :=
    use_clause (p59 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (15, false) :=
    use_clause (p1804 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h10 : LitSat F.assign (26, false) :=
    use_clause (p1805 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c3938 : CNF.Clause Nat := [(77, true), (39, false), (76, false), (50, false), (75, true), (88, true), (74, true), (38, false), (8, false)]
theorem p3938 (F : Frame G 3) : c3938.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p3912 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (22, false) :=
    use_clause (p2397 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (33, false) :=
    use_clause (p2381 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p72 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3939 : CNF.Clause Nat := [(39, false), (76, false), (50, false), (75, true), (88, true), (74, true), (38, false), (10, true), (9, false), (8, false)]
theorem p3939 (F : Frame G 3) : c3939.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, true) :=
    use_clause (p3938 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, false) :=
    use_clause (p2000 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (21, false) :=
    use_clause (p1740 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (32, false) :=
    use_clause (p1731 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p63 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3940 : CNF.Clause Nat := [(77, true), (86, false), (39, true), (76, false), (50, false), (75, true), (88, true), (74, true), (38, false), (8, false), (6, false)]
theorem p3940 (F : Frame G 3) : c3940.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (11, false) :=
    use_clause (p1605 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p3857 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p2157 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3941 : CNF.Clause Nat := [(50, false), (75, true), (6, false), (88, true), (74, true), (38, false), (10, true), (9, false), (8, false)]
theorem p3941 (F : Frame G 3) : c3941.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (76, true) :=
    use_clause (p3937 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, false) :=
    use_clause (p3939 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, true) :=
    use_clause (p1603 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (77, true) :=
    use_clause (p3940 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (21, false) :=
    use_clause (p1740 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, false) :=
    use_clause (p1957 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (32, false) :=
    use_clause (p1754 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p63 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3942 : CNF.Clause Nat := [(76, true), (86, false), (39, false), (75, true), (88, true), (74, true), (38, false), (10, true), (8, false), (5, false)]
theorem p3942 (F : Frame G 3) : c3942.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p368 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, false) :=
    use_clause (p2466 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n8 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p53 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (32, true) :=
    use_clause (p56 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (33, false) :=
    use_clause (p2110 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (22, false) :=
    use_clause (p2076 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (29, false) :=
    use_clause (p1747 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p152 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3943 : CNF.Clause Nat := [(77, true), (76, false), (86, false), (50, true), (88, true), (74, true), (38, false), (8, false), (6, false), (5, false)]
theorem p3943 (F : Frame G 3) : c3943.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (39, true) :=
    use_clause (p30 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (11, false) :=
    use_clause (p1620 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p3862 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        True.intro⟩
def c3944 : CNF.Clause Nat := [(75, true), (88, true), (74, true), (38, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3944 (F : Frame G 3) : c3944.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (10, false) :=
    use_clause (p3935 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, false) :=
    use_clause (p3941 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (39, true) :=
    use_clause (p30 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, true) :=
    use_clause (p1618 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (76, true) :=
    use_clause (p3942 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (77, true) :=
    use_clause (p3943 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h7 : LitSat F.assign (87, false) :=
    use_clause (p1957 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (32, false) :=
    use_clause (p1796 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h9 : LitSat F.assign (98, false) :=
    use_clause (p2393 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  exact use_clause (p54 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3945 : CNF.Clause Nat := [(87, true), (76, true), (50, false), (74, true), (10, true)]
theorem p3945 (F : Frame G 3) : c3945.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, true) :=
    use_clause (p53 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (32, true) :=
    use_clause (p56 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p3753 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c3946 : CNF.Clause Nat := [(77, true), (39, false), (87, false), (50, false), (75, false), (88, true), (38, false), (8, false)]
theorem p3946 (F : Frame G 3) : c3946.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, false) :=
    use_clause (p2396 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (33, false) :=
    use_clause (p2650 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p72 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3947 : CNF.Clause Nat := [(39, false), (87, false), (76, true), (50, false), (75, false), (88, true), (38, false), (10, true), (9, false), (8, false), (5, false)]
theorem p3947 (F : Frame G 3) : c3947.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, true) :=
    use_clause (p3946 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, false) :=
    use_clause (p2785 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p3936 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h4 : LitSat F.assign (11, false) :=
    use_clause (p1820 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p79 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3948 : CNF.Clause Nat := [(76, true), (50, false), (88, true), (74, true), (38, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3948 (F : Frame G 3) : c3948.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (75, true) :=
    use_clause (p3944 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h2 : LitSat F.assign (10, false) :=
    use_clause (p3935 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p3945 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (39, false) :=
    use_clause (p3947 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p3725 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h6 : LitSat F.assign (32, true) :=
    use_clause (p55 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (21, true) :=
    use_clause (p59 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (77, false) :=
    use_clause (p2144 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (11, false) :=
    use_clause (p1605 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p3875 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
def c3949 : CNF.Clause Nat := [(77, true), (39, false), (76, false), (50, false), (75, false), (88, true), (74, true), (38, false), (8, false)]
theorem p3949 (F : Frame G 3) : c3949.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, false) :=
    use_clause (p3946 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (22, false) :=
    use_clause (p2397 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (33, true) :=
    use_clause (p72 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2374 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c3950 : CNF.Clause Nat := [(39, false), (76, false), (50, false), (75, false), (88, true), (74, true), (38, false), (10, true), (9, false), (8, false)]
theorem p3950 (F : Frame G 3) : c3950.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (77, true) :=
    use_clause (p3949 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, false) :=
    use_clause (p2000 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (21, false) :=
    use_clause (p1740 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (32, false) :=
    use_clause (p1731 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p63 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3951 : CNF.Clause Nat := [(77, true), (39, true), (76, false), (50, false), (88, true), (74, true), (38, false), (8, false), (6, false)]
theorem p3951 (F : Frame G 3) : c3951.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (11, false) :=
    use_clause (p1605 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (22, true) :=
    use_clause (p81 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2397 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c3952 : CNF.Clause Nat := [(87, true), (21, true), (77, false), (39, true), (76, false), (88, true), (74, true), (10, true)]
theorem p3952 (F : Frame G 3) : c3952.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (86, true) :=
    use_clause (p378 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (32, true) :=
    use_clause (p63 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p3644 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c3953 : CNF.Clause Nat := [(50, false), (88, true), (74, true), (38, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3953 (F : Frame G 3) : c3953.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (75, true) :=
    use_clause (p3944 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (10, false) :=
    use_clause (p3935 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (76, true) :=
    use_clause (p3948 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (39, false) :=
    use_clause (p3950 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (77, true) :=
    use_clause (p3951 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (21, false) :=
    use_clause (p1740 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (87, true) :=
    use_clause (p3952 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h8 : LitSat F.assign (86, false) :=
    use_clause (p1957 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h9 : LitSat F.assign (99, false) :=
    use_clause (p2573 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h10 : LitSat F.assign (22, false) :=
    use_clause (p1806 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h11 : LitSat F.assign (11, false) :=
    use_clause (p1610 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  exact use_clause (p79 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3954 : CNF.Clause Nat := [(77, true), (76, true), (50, true), (75, false), (88, true), (74, true), (38, false), (10, true), (8, false), (6, false), (5, false)]
theorem p3954 (F : Frame G 3) : c3954.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p30 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (11, false) :=
    use_clause (p1620 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (33, true) :=
    use_clause (p77 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (21, false) :=
    use_clause (p2235 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (87, false) :=
    use_clause (p2650 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p60 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3955 : CNF.Clause Nat := [(87, true), (77, false), (76, true), (39, false), (75, false), (38, false), (10, true), (8, false), (6, false)]
theorem p3955 (F : Frame G 3) : c3955.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (32, true) :=
    use_clause (p56 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (21, true) :=
    use_clause (p60 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1758 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c3956 : CNF.Clause Nat := [(76, true), (88, true), (74, true), (38, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3956 (F : Frame G 3) : c3956.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, false) :=
    use_clause (p3953 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p30 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (75, true) :=
    use_clause (p3944 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (10, false) :=
    use_clause (p3935 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h5 : LitSat F.assign (77, true) :=
    use_clause (p3954 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p3955 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (22, false) :=
    use_clause (p2785 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (98, false) :=
    use_clause (p2129 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h9 : LitSat F.assign (99, false) :=
    use_clause (p2466 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h10 : LitSat F.assign (33, true) :=
    use_clause (p70 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (86, true) :=
    use_clause (p373 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1799 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3957 : CNF.Clause Nat := [(77, true), (76, false), (50, true), (88, true), (74, true), (38, false), (8, false), (6, false), (5, false)]
theorem p3957 (F : Frame G 3) : c3957.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p30 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p375 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p3943 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, false) :=
    use_clause (p1689 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p378 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c3958 : CNF.Clause Nat := [(88, true), (74, true), (38, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3958 (F : Frame G 3) : c3958.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (10, false) :=
    use_clause (p3935 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, false) :=
    use_clause (p3953 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (39, true) :=
    use_clause (p30 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, true) :=
    use_clause (p3956 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (77, true) :=
    use_clause (p3957 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (21, false) :=
    use_clause (p1712 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (32, false) :=
    use_clause (p1722 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (87, true) :=
    use_clause (p63 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (98, true) :=
    use_clause (p62 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2129 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
def c3959 : CNF.Clause Nat := [(75, false), (39, false), (87, false), (76, true), (50, false), (88, false), (38, false), (10, true), (6, false)]
theorem p3959 (F : Frame G 3) : c3959.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (32, false) :=
    use_clause (p1897 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p55 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (21, true) :=
    use_clause (p65 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2111 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3960 : CNF.Clause Nat := [(39, false), (76, true), (50, false), (88, false), (74, true), (38, false), (10, true), (9, false), (8, false), (6, false)]
theorem p3960 (F : Frame G 3) : c3960.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (87, true) :=
    use_clause (p3945 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (75, false) :=
    use_clause (p3959 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h2 : LitSat F.assign (21, false) :=
    use_clause (p3776 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p3823 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
def c3961 : CNF.Clause Nat := [(76, true), (50, false), (6, false), (88, false), (74, true), (38, false), (10, true), (9, false), (8, false)]
theorem p3961 (F : Frame G 3) : c3961.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, false) :=
    use_clause (p3960 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, false) :=
    use_clause (p3725 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (32, true) :=
    use_clause (p55 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (21, true) :=
    use_clause (p59 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (75, false) :=
    use_clause (p1960 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p3776 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        True.intro⟩
def c3962 : CNF.Clause Nat := [(39, false), (21, true), (76, false), (88, false), (38, false), (10, true), (9, false), (8, false)]
theorem p3962 (F : Frame G 3) : c3962.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, false) :=
    use_clause (p2011 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, false) :=
    use_clause (p2009 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p58 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3963 : CNF.Clause Nat := [(75, true), (39, true), (76, false), (50, false), (88, false), (74, true), (38, false), (9, false), (8, false), (6, false)]
theorem p3963 (F : Frame G 3) : c3963.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (86, true) :=
    use_clause (p1603 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p3860 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, false) :=
    use_clause (p1957 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p2573 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (15, false) :=
    use_clause (p1894 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (11, false) :=
    use_clause (p1607 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (22, true) :=
    use_clause (p80 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p1916 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        True.intro⟩
def c3964 : CNF.Clause Nat := [(87, true), (75, false), (39, true), (21, true), (76, false), (50, false), (88, false), (74, true), (38, false), (10, true), (8, false), (6, false)]
theorem p3964 (F : Frame G 3) : c3964.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (21, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, true) :=
    use_clause (p58 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (32, true) :=
    use_clause (p63 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (15, false) :=
    use_clause (p1710 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p2156 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (77, false) :=
    use_clause (p2424 F)
      ⟨fun h => False.elim (n10 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (86, true) :=
    use_clause (p372 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2184 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c3965 : CNF.Clause Nat := [(50, false), (88, false), (6, false), (8, false), (74, true), (38, false), (10, true), (9, false)]
theorem p3965 (F : Frame G 3) : c3965.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (76, true) :=
    use_clause (p3961 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (21, false) :=
    use_clause (p2263 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, false) :=
    use_clause (p3962 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (75, true) :=
    use_clause (p3963 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p3964 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (15, false) :=
    use_clause (p2446 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h6 : LitSat F.assign (26, false) :=
    use_clause (p1895 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3966 : CNF.Clause Nat := [(75, true), (76, true), (50, true), (88, false), (74, true), (38, false), (10, true), (6, false)]
theorem p3966 (F : Frame G 3) : c3966.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p30 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (77, true) :=
    use_clause (p364 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p3820 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, false) :=
    use_clause (p2787 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (32, false) :=
    use_clause (p2078 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p55 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3967 : CNF.Clause Nat := [(87, true), (75, false), (76, true), (39, false), (88, false), (38, false), (10, true)]
theorem p3967 (F : Frame G 3) : c3967.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, true) :=
    use_clause (p53 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (32, true) :=
    use_clause (p56 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2133 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c3968 : CNF.Clause Nat := [(76, true), (50, true), (88, false), (74, true), (38, false), (10, true), (6, false), (5, false)]
theorem p3968 (F : Frame G 3) : c3968.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p30 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (75, true) :=
    use_clause (p3966 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p3967 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (32, false) :=
    use_clause (p1897 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p55 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (21, true) :=
    use_clause (p65 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2149 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c3969 : CNF.Clause Nat := [(74, true), (38, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3969 (F : Frame G 3) : c3969.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (74, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (10, false) :=
    use_clause (p3935 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p3958 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, false) :=
    use_clause (p3965 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (39, true) :=
    use_clause (p30 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (76, true) :=
    use_clause (p3968 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (21, false) :=
    use_clause (p1831 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p3962 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c3970 : CNF.Clause Nat := [(87, true), (88, true), (76, true), (50, false), (10, true)]
theorem p3970 (F : Frame G 3) : c3970.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, true) :=
    use_clause (p53 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (32, true) :=
    use_clause (p56 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p3745 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c3971 : CNF.Clause Nat := [(39, false), (88, true), (76, true), (50, false), (38, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3971 (F : Frame G 3) : c3971.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (10, false) :=
    use_clause (p3935 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p3970 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (74, true) :=
    use_clause (p3969 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (77, false) :=
    use_clause (p3834 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h4 : LitSat F.assign (75, false) :=
    use_clause (p3947 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  exact use_clause (p3833 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        True.intro⟩
def c3972 : CNF.Clause Nat := [(88, true), (76, true), (50, false), (38, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3972 (F : Frame G 3) : c3972.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (74, true) :=
    use_clause (p3969 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (10, false) :=
    use_clause (p3935 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p3970 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (39, false) :=
    use_clause (p3971 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p3725 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (32, true) :=
    use_clause (p55 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (21, true) :=
    use_clause (p59 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (99, false) :=
    use_clause (p2224 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (77, true) :=
    use_clause (p375 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (22, false) :=
    use_clause (p1806 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h11 : LitSat F.assign (33, true) :=
    use_clause (p70 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (15, false) :=
    use_clause (p1785 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h13 : LitSat F.assign (26, false) :=
    use_clause (p1671 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3973 : CNF.Clause Nat := [(87, true), (39, false), (88, false), (76, true), (50, false), (74, false), (38, false), (10, true), (9, false), (5, false)]
theorem p3973 (F : Frame G 3) : c3973.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, true) :=
    use_clause (p53 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (75, false) :=
    use_clause (p3967 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (11, false) :=
    use_clause (p3805 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n8 h),
        True.intro⟩
  exact use_clause (p3932 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n9 h),
        True.intro⟩
def c3974 : CNF.Clause Nat := [(98, true), (77, true), (87, false), (39, false), (88, false), (76, true), (50, false), (74, false), (38, false), (10, true), (9, false), (6, false)]
theorem p3974 (F : Frame G 3) : c3974.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (77, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (75, false) :=
    use_clause (p3959 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n11 h),
        True.intro⟩
  have h2 : LitSat F.assign (32, true) :=
    use_clause (p55 F)
      ⟨fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (21, true) :=
    use_clause (p59 F)
      ⟨fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p3838 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n11 h),
        True.intro⟩
  have h5 : LitSat F.assign (18, false) :=
    use_clause (p1835 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, true) :=
    use_clause (p377 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (29, true) :=
    use_clause (p33 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p1972 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c3975 : CNF.Clause Nat := [(98, false), (75, true), (39, false), (88, false), (76, true), (50, false), (74, false), (38, false), (9, false), (5, false)]
theorem p3975 (F : Frame G 3) : c3975.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (75, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (11, false) :=
    use_clause (p3805 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n8 h),
        True.intro⟩
  exact use_clause (p3932 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n9 h),
        True.intro⟩
def c3976 : CNF.Clause Nat := [(39, false), (88, false), (76, true), (50, false), (74, false), (38, false), (10, true), (9, false), (6, false), (5, false)]
theorem p3976 (F : Frame G 3) : c3976.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p3973 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h2 : LitSat F.assign (75, false) :=
    use_clause (p3959 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, false) :=
    use_clause (p3975 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h4 : LitSat F.assign (32, true) :=
    use_clause (p55 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (77, true) :=
    use_clause (p3974 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  exact use_clause (p2078 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3977 : CNF.Clause Nat := [(88, false), (76, true), (5, false), (50, false), (74, false), (38, false), (10, true), (9, false), (6, false)]
theorem p3977 (F : Frame G 3) : c3977.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (39, false) :=
    use_clause (p3976 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, false) :=
    use_clause (p3725 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p53 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (32, true) :=
    use_clause (p55 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (21, true) :=
    use_clause (p59 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, false) :=
    use_clause (p2224 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (75, false) :=
    use_clause (p1960 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h8 : LitSat F.assign (77, false) :=
    use_clause (p2300 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h9 : LitSat F.assign (86, true) :=
    use_clause (p377 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h10 : LitSat F.assign (11, false) :=
    use_clause (p1607 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h11 : LitSat F.assign (18, false) :=
    use_clause (p1965 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h12 : LitSat F.assign (33, true) :=
    use_clause (p76 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (29, true) :=
    use_clause (p33 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  exact use_clause (p1685 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3978 : CNF.Clause Nat := [(76, true), (50, false), (38, false), (9, false), (8, false), (6, false), (5, false)]
theorem p3978 (F : Frame G 3) : c3978.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (76, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (74, true) :=
    use_clause (p3969 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (10, false) :=
    use_clause (p3935 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p3972 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  exact use_clause (p3977 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3979 : CNF.Clause Nat := [(99, false), (87, true), (39, false), (76, false), (50, false), (74, false), (10, true), (8, false), (5, false)]
theorem p3979 (F : Frame G 3) : c3979.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, false) :=
    use_clause (p2245 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h2 : LitSat F.assign (32, false) :=
    use_clause (p2350 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p54 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3980 : CNF.Clause Nat := [(87, true), (39, false), (88, true), (76, false), (50, false), (74, false), (38, false), (10, true), (9, false), (8, false), (5, false)]
theorem p3980 (F : Frame G 3) : c3980.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (76, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (74, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (8, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p3672 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p3979 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h2 : LitSat F.assign (77, true) :=
    use_clause (p375 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (21, false) :=
    use_clause (p1740 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (32, false) :=
    use_clause (p1731 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p63 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
end Cert35Steps
end Graffiti199Depleted.Catalogue.OrderEleven
