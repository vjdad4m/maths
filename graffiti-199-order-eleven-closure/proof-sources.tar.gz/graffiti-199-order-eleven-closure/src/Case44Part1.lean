import Case44Part0
namespace Graffiti199Depleted.Catalogue.OrderEleven
namespace Cert44Steps
open Std.Sat
set_option maxRecDepth 4096
set_option maxHeartbeats 0
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj]
def c2761 : CNF.Clause Nat := [(40, true), (38, false), (62, false), (51, true), (110, false)]
theorem p2761 (F : Frame G 4) : c2761.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (50, true) :=
    use_clause (p2757 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (30, false) :=
    use_clause (p2758 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, false) :=
    use_clause (p2760 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (19, true) :=
    use_clause (p143 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (33, false) :=
    use_clause (p2114 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (22, true) :=
    use_clause (p154 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (11, true) :=
    use_clause (p157 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h10 : LitSat F.assign (18, false) :=
    use_clause (p1326 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h11 : LitSat F.assign (7, true) :=
    use_clause (p26 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h12 : LitSat F.assign (31, false) :=
    use_clause (p1364 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h13 : LitSat F.assign (9, false) :=
    use_clause (p1292 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c2762 : CNF.Clause Nat := [(88, true), (30, true), (38, false), (62, false), (51, true), (110, false)]
theorem p2762 (F : Frame G 4) : c2762.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (40, true) :=
    use_clause (p2761 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p2757 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h6 : LitSat F.assign (19, true) :=
    use_clause (p143 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h7 : LitSat F.assign (33, false) :=
    use_clause (p2114 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (7, false) :=
    use_clause (p1870 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (22, true) :=
    use_clause (p154 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h10 : LitSat F.assign (18, false) :=
    use_clause (p1326 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h11 : LitSat F.assign (29, false) :=
    use_clause (p1904 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  exact use_clause (p28 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c2763 : CNF.Clause Nat := [(19, false), (7, true), (30, true), (38, false), (62, false), (51, true), (110, false)]
theorem p2763 (F : Frame G 4) : c2763.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (19, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (7, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (88, true) :=
    use_clause (p2762 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (40, true) :=
    use_clause (p2761 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p2757 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (11, false) :=
    use_clause (p1507 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (9, false) :=
    use_clause (p2016 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (33, false) :=
    use_clause (p2114 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h10 : LitSat F.assign (87, true) :=
    use_clause (p184 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h11 : LitSat F.assign (18, false) :=
    use_clause (p1988 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h12 : LitSat F.assign (29, false) :=
    use_clause (p1376 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  exact use_clause (p28 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c2764 : CNF.Clause Nat := [(7, true), (30, true), (38, false), (62, false), (51, true), (110, false)]
theorem p2764 (F : Frame G 4) : c2764.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (7, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (88, true) :=
    use_clause (p2762 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (40, true) :=
    use_clause (p2761 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p2757 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (19, false) :=
    use_clause (p2763 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (18, false) :=
    use_clause (p2742 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (87, true) :=
    use_clause (p144 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (29, true) :=
    use_clause (p28 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h10 : LitSat F.assign (33, false) :=
    use_clause (p1536 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h11 : LitSat F.assign (22, false) :=
    use_clause (p1904 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p201 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c2765 : CNF.Clause Nat := [(30, true), (38, false), (62, false), (51, true), (110, false)]
theorem p2765 (F : Frame G 4) : c2765.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (40, true) :=
    use_clause (p2761 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p2757 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, true) :=
    use_clause (p2762 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (7, true) :=
    use_clause (p2764 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (19, false) :=
    use_clause (p1870 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (87, false) :=
    use_clause (p1668 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p144 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
def c2766 : CNF.Clause Nat := [(38, false), (62, false), (51, true), (110, false)]
theorem p2766 (F : Frame G 4) : c2766.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (50, true) :=
    use_clause (p2757 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (40, true) :=
    use_clause (p2761 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (30, true) :=
    use_clause (p2765 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (88, false) :=
    use_clause (p1570 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (18, false) :=
    use_clause (p2113 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (9, false) :=
    use_clause (p2058 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h10 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h11 : LitSat F.assign (7, false) :=
    use_clause (p1953 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h12 : LitSat F.assign (29, true) :=
    use_clause (p28 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h13 : LitSat F.assign (22, false) :=
    use_clause (p1904 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h14 : LitSat F.assign (33, false) :=
    use_clause (p2062 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p154 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c2767 : CNF.Clause Nat := [(29, false), (88, true), (40, false), (50, false), (62, false), (110, false)]
theorem p2767 (F : Frame G 4) : c2767.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (22, false) :=
    use_clause (p1904 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (33, false) :=
    use_clause (p2062 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p154 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c2768 : CNF.Clause Nat := [(30, false), (40, false), (62, false), (51, true), (110, false)]
theorem p2768 (F : Frame G 4) : c2768.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (38, false) :=
    use_clause (p2766 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p2757 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, false) :=
    use_clause (p1570 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (9, false) :=
    use_clause (p2058 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h9 : LitSat F.assign (7, false) :=
    use_clause (p1953 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h10 : LitSat F.assign (29, false) :=
    use_clause (p2767 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (18, true) :=
    use_clause (p28 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h12 : LitSat F.assign (5, false) :=
    use_clause (p1367 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h13 : LitSat F.assign (27, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h14 : LitSat F.assign (22, false) :=
    use_clause (p2064 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h15 : LitSat F.assign (11, true) :=
    use_clause (p160 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h16 : LitSat F.assign (33, true) :=
    use_clause (p154 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h17 : LitSat F.assign (26, false) :=
    use_clause (p2100 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h18 : LitSat F.assign (15, false) :=
    use_clause (p2099 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h16 h),
        True.intro⟩
  exact use_clause (p73 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c2769 : CNF.Clause Nat := [(7, true), (88, true), (40, false), (62, false), (51, true), (110, false)]
theorem p2769 (F : Frame G 4) : c2769.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (7, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (38, false) :=
    use_clause (p2766 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (30, false) :=
    use_clause (p2768 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (19, true) :=
    use_clause (p143 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h6 : LitSat F.assign (27, false) :=
    use_clause (p2196 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (5, true) :=
    use_clause (p13 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (50, true) :=
    use_clause (p2757 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (29, false) :=
    use_clause (p2767 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h10 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h11 : LitSat F.assign (18, true) :=
    use_clause (p28 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h12 : LitSat F.assign (22, false) :=
    use_clause (p1326 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h13 : LitSat F.assign (11, true) :=
    use_clause (p160 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h14 : LitSat F.assign (33, true) :=
    use_clause (p154 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h15 : LitSat F.assign (9, false) :=
    use_clause (p1278 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h16 : LitSat F.assign (26, false) :=
    use_clause (p2100 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h17 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h18 : LitSat F.assign (39, true) :=
    use_clause (p52 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p2098 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c2770 : CNF.Clause Nat := [(22, true), (7, false), (5, false), (19, false), (88, true), (38, true), (50, false), (62, false), (110, false)]
theorem p2770 (F : Frame G 4) : c2770.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (19, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n8 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (11, true) :=
    use_clause (p160 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (33, true) :=
    use_clause (p154 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h6 : LitSat F.assign (9, false) :=
    use_clause (p1278 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h7 : LitSat F.assign (31, false) :=
    use_clause (p1954 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c2771 : CNF.Clause Nat := [(88, true), (40, false), (62, false), (51, true), (110, false)]
theorem p2771 (F : Frame G 4) : c2771.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (30, false) :=
    use_clause (p2768 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (38, false) :=
    use_clause (p2766 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p2757 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h7 : LitSat F.assign (19, true) :=
    use_clause (p143 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h8 : LitSat F.assign (29, false) :=
    use_clause (p2767 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (27, false) :=
    use_clause (p2196 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h10 : LitSat F.assign (5, true) :=
    use_clause (p13 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h11 : LitSat F.assign (7, true) :=
    use_clause (p2769 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h12 : LitSat F.assign (22, true) :=
    use_clause (p2770 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h13 : LitSat F.assign (18, false) :=
    use_clause (p1326 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h14 : LitSat F.assign (15, false) :=
    use_clause (p1310 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h15 : LitSat F.assign (26, true) :=
    use_clause (p70 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h16 : LitSat F.assign (39, true) :=
    use_clause (p57 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h17 : LitSat F.assign (9, false) :=
    use_clause (p1966 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
  have h18 : LitSat F.assign (31, false) :=
    use_clause (p1991 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c2772 : CNF.Clause Nat := [(7, false), (40, false), (62, false), (51, true), (110, false)]
theorem p2772 (F : Frame G 4) : c2772.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p2757 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, true) :=
    use_clause (p2771 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (26, false) :=
    use_clause (p1987 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h6 : LitSat F.assign (30, false) :=
    use_clause (p2768 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (38, false) :=
    use_clause (p2766 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (39, false) :=
    use_clause (p1923 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h9 : LitSat F.assign (31, false) :=
    use_clause (p2031 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h10 : LitSat F.assign (15, true) :=
    use_clause (p10 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h11 : LitSat F.assign (9, true) :=
    use_clause (p146 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (27, false) :=
    use_clause (p1395 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h13 : LitSat F.assign (29, false) :=
    use_clause (p2128 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h14 : LitSat F.assign (87, false) :=
    use_clause (p1473 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h15 : LitSat F.assign (5, true) :=
    use_clause (p13 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h16 : LitSat F.assign (18, true) :=
    use_clause (p50 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h17 : LitSat F.assign (19, true) :=
    use_clause (p144 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h14 h),
        True.intro⟩
  exact use_clause (p1989 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c2773 : CNF.Clause Nat := [(19, false), (40, false), (62, false), (51, true), (110, false)]
theorem p2773 (F : Frame G 4) : c2773.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (19, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (7, false) :=
    use_clause (p2772 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p2771 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, false) :=
    use_clause (p2766 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p2757 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (27, false) :=
    use_clause (p2196 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (5, true) :=
    use_clause (p13 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (29, false) :=
    use_clause (p1884 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h10 : LitSat F.assign (18, false) :=
    use_clause (p1989 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  exact use_clause (p28 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c2774 : CNF.Clause Nat := [(40, false), (62, false), (51, true), (110, false)]
theorem p2774 (F : Frame G 4) : c2774.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (38, false) :=
    use_clause (p2766 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p2757 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (30, false) :=
    use_clause (p2768 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (88, true) :=
    use_clause (p2771 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (26, false) :=
    use_clause (p1987 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h8 : LitSat F.assign (7, false) :=
    use_clause (p2772 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (19, false) :=
    use_clause (p2773 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (87, true) :=
    use_clause (p144 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h11 : LitSat F.assign (5, false) :=
    use_clause (p2180 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h12 : LitSat F.assign (9, false) :=
    use_clause (p1473 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h13 : LitSat F.assign (27, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h14 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h15 : LitSat F.assign (39, false) :=
    use_clause (p1993 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h16 : LitSat F.assign (18, false) :=
    use_clause (p1988 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p54 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c2775 : CNF.Clause Nat := [(87, false), (7, true), (88, false), (62, false), (51, true), (110, false)]
theorem p2775 (F : Frame G 4) : c2775.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (7, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (40, false) :=
    use_clause (p2774 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (29, true) :=
    use_clause (p23 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (18, true) :=
    use_clause (p26 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, false) :=
    use_clause (p2766 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (39, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (50, true) :=
    use_clause (p2757 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h9 : LitSat F.assign (27, false) :=
    use_clause (p1515 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h10 : LitSat F.assign (9, false) :=
    use_clause (p1705 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h11 : LitSat F.assign (5, true) :=
    use_clause (p13 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h12 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  exact use_clause (p2008 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c2776 : CNF.Clause Nat := [(31, false), (5, false), (87, true), (18, false), (88, false), (39, false), (62, false), (110, false)]
theorem p2776 (F : Frame G 4) : c2776.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (31, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (19, false) :=
    use_clause (p1922 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (30, false) :=
    use_clause (p2219 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p144 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c2777 : CNF.Clause Nat := [(5, false), (87, true), (29, false), (18, false), (88, false), (40, true), (38, true), (50, false), (62, false), (110, false)]
theorem p2777 (F : Frame G 4) : c2777.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (39, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n9 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n9 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (31, false) :=
    use_clause (p2776 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h5 : LitSat F.assign (9, true) :=
    use_clause (p146 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h6 : LitSat F.assign (30, false) :=
    use_clause (p1946 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h7 : LitSat F.assign (15, false) :=
    use_clause (p2128 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (19, true) :=
    use_clause (p144 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (26, true) :=
    use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h10 : LitSat F.assign (11, false) :=
    use_clause (p2105 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h11 : LitSat F.assign (22, false) :=
    use_clause (p1496 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p185 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c2778 : CNF.Clause Nat := [(27, false), (88, false), (40, true), (38, true), (62, false), (110, false)]
theorem p2778 (F : Frame G 4) : c2778.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (27, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (39, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (15, false) :=
    use_clause (p1395 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (26, false) :=
    use_clause (p1992 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c2779 : CNF.Clause Nat := [(7, true), (88, false), (62, false), (51, true), (110, false)]
theorem p2779 (F : Frame G 4) : c2779.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (7, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (38, false) :=
    use_clause (p2766 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (40, false) :=
    use_clause (p2774 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (27, false) :=
    use_clause (p2778 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (5, true) :=
    use_clause (p13 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p2757 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (18, true) :=
    use_clause (p26 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (29, true) :=
    use_clause (p23 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (87, false) :=
    use_clause (p2775 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p2777 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c2780 : CNF.Clause Nat := [(88, false), (62, false), (51, true), (110, false)]
theorem p2780 (F : Frame G 4) : c2780.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (38, false) :=
    use_clause (p2766 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (40, false) :=
    use_clause (p2774 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p2757 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (27, false) :=
    use_clause (p2778 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (5, true) :=
    use_clause (p13 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (7, true) :=
    use_clause (p2779 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (30, false) :=
    use_clause (p1569 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h11 : LitSat F.assign (9, false) :=
    use_clause (p1271 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h12 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h13 : LitSat F.assign (87, false) :=
    use_clause (p1512 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h14 : LitSat F.assign (19, false) :=
    use_clause (p1922 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p144 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
def c2781 : CNF.Clause Nat := [(7, false), (5, false), (62, false), (51, true), (110, false)]
theorem p2781 (F : Frame G 4) : c2781.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (88, false) :=
    use_clause (p2780 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (40, false) :=
    use_clause (p2774 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (38, false) :=
    use_clause (p2766 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (50, true) :=
    use_clause (p2757 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (11, false) :=
    use_clause (p1273 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (9, false) :=
    use_clause (p1271 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (33, true) :=
    use_clause (p157 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h11 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h12 : LitSat F.assign (30, false) :=
    use_clause (p1955 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  have h13 : LitSat F.assign (19, false) :=
    use_clause (p1954 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  exact use_clause (p143 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c2782 : CNF.Clause Nat := [(5, false), (62, false), (51, true), (110, false)]
theorem p2782 (F : Frame G 4) : c2782.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (88, false) :=
    use_clause (p2780 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, false) :=
    use_clause (p2766 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (40, false) :=
    use_clause (p2774 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (39, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (50, true) :=
    use_clause (p2757 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (7, false) :=
    use_clause (p2781 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (18, true) :=
    use_clause (p26 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h11 : LitSat F.assign (29, true) :=
    use_clause (p23 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h12 : LitSat F.assign (33, false) :=
    use_clause (p2062 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        True.intro⟩
  have h13 : LitSat F.assign (22, true) :=
    use_clause (p154 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h14 : LitSat F.assign (11, true) :=
    use_clause (p157 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h15 : LitSat F.assign (19, false) :=
    use_clause (p1326 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h16 : LitSat F.assign (9, false) :=
    use_clause (p1278 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h17 : LitSat F.assign (30, true) :=
    use_clause (p143 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h18 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  exact use_clause (p1373 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c2783 : CNF.Clause Nat := [(7, true), (62, false), (51, true), (110, false)]
theorem p2783 (F : Frame G 4) : c2783.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (7, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (38, false) :=
    use_clause (p2766 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (5, false) :=
    use_clause (p2782 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (27, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, false) :=
    use_clause (p2780 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (40, false) :=
    use_clause (p2774 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (39, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (50, true) :=
    use_clause (p2757 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h11 : LitSat F.assign (18, true) :=
    use_clause (p26 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h12 : LitSat F.assign (29, true) :=
    use_clause (p23 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h13 : LitSat F.assign (33, false) :=
    use_clause (p2062 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        True.intro⟩
  have h14 : LitSat F.assign (22, true) :=
    use_clause (p154 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h15 : LitSat F.assign (19, false) :=
    use_clause (p1326 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h16 : LitSat F.assign (31, false) :=
    use_clause (p2064 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h17 : LitSat F.assign (30, true) :=
    use_clause (p143 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h18 : LitSat F.assign (9, true) :=
    use_clause (p146 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  exact use_clause (p1946 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c2784 : CNF.Clause Nat := [(33, false), (7, false), (27, false), (88, true), (50, false), (62, false), (110, false)]
theorem p2784 (F : Frame G 4) : c2784.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (33, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (27, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (30, false) :=
    use_clause (p1955 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h5 : LitSat F.assign (19, false) :=
    use_clause (p2104 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p143 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c2785 : CNF.Clause Nat := [(62, false), (51, true), (110, false)]
theorem p2785 (F : Frame G 4) : c2785.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p2757 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, false) :=
    use_clause (p2766 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (40, false) :=
    use_clause (p2774 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, false) :=
    use_clause (p2780 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (5, false) :=
    use_clause (p2782 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (27, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (7, true) :=
    use_clause (p2783 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h10 : LitSat F.assign (33, false) :=
    use_clause (p2784 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h11 : LitSat F.assign (22, true) :=
    use_clause (p154 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h12 : LitSat F.assign (11, true) :=
    use_clause (p157 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h13 : LitSat F.assign (31, false) :=
    use_clause (p2064 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h14 : LitSat F.assign (9, false) :=
    use_clause (p1292 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c2786 : CNF.Clause Nat := [(33, true), (50, false), (7, false), (88, true), (51, true), (110, false)]
theorem p2786 (F : Frame G 4) : c2786.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (33, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, false) :=
    use_clause (p2785 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (22, true) :=
    use_clause (p154 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (11, true) :=
    use_clause (p157 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (38, false) :=
    use_clause (p1542 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h9 : LitSat F.assign (29, false) :=
    use_clause (p1904 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h10 : LitSat F.assign (39, true) :=
    use_clause (p137 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h11 : LitSat F.assign (18, true) :=
    use_clause (p18 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h12 : LitSat F.assign (19, false) :=
    use_clause (p1326 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h13 : LitSat F.assign (30, true) :=
    use_clause (p143 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h14 : LitSat F.assign (9, false) :=
    use_clause (p2204 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h15 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h16 : LitSat F.assign (5, false) :=
    use_clause (p2190 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h17 : LitSat F.assign (6, false) :=
    use_clause (p2187 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h18 : LitSat F.assign (17, false) :=
    use_clause (p2188 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h15 h),
        True.intro⟩
  exact use_clause (p78 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c2787 : CNF.Clause Nat := [(5, true), (38, true), (50, false), (7, false), (88, true), (51, true), (110, false)]
theorem p2787 (F : Frame G 4) : c2787.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (5, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (62, false) :=
    use_clause (p2785 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p137 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (33, true) :=
    use_clause (p2786 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (27, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (19, false) :=
    use_clause (p2102 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h10 : LitSat F.assign (30, true) :=
    use_clause (p143 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (9, false) :=
    use_clause (p2189 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h12 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h13 : LitSat F.assign (29, false) :=
    use_clause (p365 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h14 : LitSat F.assign (26, false) :=
    use_clause (p343 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h15 : LitSat F.assign (18, true) :=
    use_clause (p18 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h16 : LitSat F.assign (15, true) :=
    use_clause (p68 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h17 : LitSat F.assign (6, false) :=
    use_clause (p2187 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h18 : LitSat F.assign (17, false) :=
    use_clause (p2186 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  exact use_clause (p78 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2788 : CNF.Clause Nat := [(31, false), (5, false), (39, false), (50, false), (7, false), (88, true), (40, false), (110, false)]
theorem p2788 (F : Frame G 4) : c2788.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (31, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (30, false) :=
    use_clause (p2190 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (19, false) :=
    use_clause (p1991 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p143 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c2789 : CNF.Clause Nat := [(38, true), (50, false), (7, false), (88, true), (51, true), (110, false)]
theorem p2789 (F : Frame G 4) : c2789.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (33, true) :=
    use_clause (p2786 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (62, false) :=
    use_clause (p2785 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (39, true) :=
    use_clause (p137 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h8 : LitSat F.assign (5, true) :=
    use_clause (p2787 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (31, false) :=
    use_clause (p2788 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h10 : LitSat F.assign (9, true) :=
    use_clause (p146 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h11 : LitSat F.assign (30, false) :=
    use_clause (p2189 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (11, false) :=
    use_clause (p1300 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h13 : LitSat F.assign (19, true) :=
    use_clause (p143 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h14 : LitSat F.assign (22, true) :=
    use_clause (p160 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h15 : LitSat F.assign (18, false) :=
    use_clause (p1326 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h16 : LitSat F.assign (29, false) :=
    use_clause (p1884 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p18 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c2790 : CNF.Clause Nat := [(50, false), (7, false), (88, true), (51, true), (110, false)]
theorem p2790 (F : Frame G 4) : c2790.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, false) :=
    use_clause (p2785 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (33, true) :=
    use_clause (p2786 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (38, true) :=
    use_clause (p2789 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (19, false) :=
    use_clause (p1870 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (22, false) :=
    use_clause (p1979 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h10 : LitSat F.assign (30, true) :=
    use_clause (p143 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h11 : LitSat F.assign (11, true) :=
    use_clause (p160 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h12 : LitSat F.assign (18, false) :=
    use_clause (p1663 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h13 : LitSat F.assign (29, true) :=
    use_clause (p18 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h14 : LitSat F.assign (31, false) :=
    use_clause (p1361 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h15 : LitSat F.assign (9, true) :=
    use_clause (p146 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h16 : LitSat F.assign (39, false) :=
    use_clause (p2189 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h17 : LitSat F.assign (17, false) :=
    use_clause (p2198 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h18 : LitSat F.assign (6, false) :=
    use_clause (p1288 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c2791 : CNF.Clause Nat := [(29, false), (30, false), (9, false), (7, false), (88, true), (51, true), (110, false)]
theorem p2791 (F : Frame G 4) : c2791.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (62, false) :=
    use_clause (p2785 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (50, false) :=
    use_clause (p2790 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (39, true) :=
    use_clause (p139 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h7 : LitSat F.assign (11, false) :=
    use_clause (p2204 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h8 : LitSat F.assign (33, true) :=
    use_clause (p157 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (27, false) :=
    use_clause (p1350 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (5, true) :=
    use_clause (p12 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h12 : LitSat F.assign (17, false) :=
    use_clause (p2200 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h13 : LitSat F.assign (6, false) :=
    use_clause (p1295 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p15 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c2792 : CNF.Clause Nat := [(30, false), (9, false), (7, false), (88, true), (51, true), (110, false)]
theorem p2792 (F : Frame G 4) : c2792.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (62, false) :=
    use_clause (p2785 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, false) :=
    use_clause (p2790 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, true) :=
    use_clause (p139 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (11, false) :=
    use_clause (p2204 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h9 : LitSat F.assign (22, true) :=
    use_clause (p160 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h10 : LitSat F.assign (29, false) :=
    use_clause (p2791 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h11 : LitSat F.assign (18, true) :=
    use_clause (p18 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (17, false) :=
    use_clause (p1321 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h13 : LitSat F.assign (27, false) :=
    use_clause (p1905 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h14 : LitSat F.assign (6, true) :=
    use_clause (p15 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h15 : LitSat F.assign (5, true) :=
    use_clause (p12 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p1295 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c2793 : CNF.Clause Nat := [(22, true), (19, false), (9, false), (39, false), (88, true), (40, false), (110, false)]
theorem p2793 (F : Frame G 4) : c2793.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (19, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (11, true) :=
    use_clause (p160 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (33, true) :=
    use_clause (p154 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p2101 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c2794 : CNF.Clause Nat := [(9, false), (7, false), (88, true), (51, true), (110, false)]
theorem p2794 (F : Frame G 4) : c2794.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (50, false) :=
    use_clause (p2790 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p140 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, false) :=
    use_clause (p2785 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (39, true) :=
    use_clause (p139 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (30, false) :=
    use_clause (p2792 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (19, true) :=
    use_clause (p143 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h10 : LitSat F.assign (22, true) :=
    use_clause (p2793 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (17, false) :=
    use_clause (p1323 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h12 : LitSat F.assign (18, false) :=
    use_clause (p1326 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h13 : LitSat F.assign (6, true) :=
    use_clause (p15 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h14 : LitSat F.assign (29, true) :=
    use_clause (p18 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p1867 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c2795 : CNF.Clause Nat := [(29, false), (19, false), (7, false), (88, true), (51, true), (110, false)]
theorem p2795 (F : Frame G 4) : c2795.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (19, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (9, false) :=
    use_clause (p2794 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, false) :=
    use_clause (p2790 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (38, true) :=
    use_clause (p140 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (62, false) :=
    use_clause (p2785 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (5, false) :=
    use_clause (p1871 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h10 : LitSat F.assign (6, false) :=
    use_clause (p1867 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h11 : LitSat F.assign (27, true) :=
    use_clause (p12 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h12 : LitSat F.assign (17, true) :=
    use_clause (p15 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h13 : LitSat F.assign (33, false) :=
    use_clause (p1352 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (22, false) :=
    use_clause (p1323 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p154 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2796 : CNF.Clause Nat := [(19, false), (7, false), (88, true), (51, true), (110, false)]
theorem p2796 (F : Frame G 4) : c2796.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (19, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (9, false) :=
    use_clause (p2794 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (62, false) :=
    use_clause (p2785 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (50, false) :=
    use_clause (p2790 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (39, true) :=
    use_clause (p139 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h9 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (29, false) :=
    use_clause (p2795 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (18, true) :=
    use_clause (p18 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h12 : LitSat F.assign (22, false) :=
    use_clause (p1326 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (17, false) :=
    use_clause (p1318 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h14 : LitSat F.assign (33, true) :=
    use_clause (p154 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h15 : LitSat F.assign (6, true) :=
    use_clause (p15 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p2210 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h14 h),
        True.intro⟩
def c2797 : CNF.Clause Nat := [(7, false), (88, true), (51, true), (110, false)]
theorem p2797 (F : Frame G 4) : c2797.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, false) :=
    use_clause (p2785 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (50, false) :=
    use_clause (p2790 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (39, true) :=
    use_clause (p139 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h8 : LitSat F.assign (9, false) :=
    use_clause (p2794 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h10 : LitSat F.assign (19, false) :=
    use_clause (p2796 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h11 : LitSat F.assign (30, true) :=
    use_clause (p143 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h12 : LitSat F.assign (5, false) :=
    use_clause (p2190 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h13 : LitSat F.assign (27, true) :=
    use_clause (p12 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h14 : LitSat F.assign (33, false) :=
    use_clause (p1355 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h15 : LitSat F.assign (29, false) :=
    use_clause (p1348 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h16 : LitSat F.assign (22, true) :=
    use_clause (p154 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h17 : LitSat F.assign (18, true) :=
    use_clause (p18 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h18 : LitSat F.assign (6, false) :=
    use_clause (p2187 F)
      ⟨fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h19 : LitSat F.assign (17, false) :=
    use_clause (p1321 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p15 F)
      ⟨fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c2798 : CNF.Clause Nat := [(6, false), (30, false), (50, true), (88, true), (51, true), (110, false)]
theorem p2798 (F : Frame G 4) : c2798.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (62, false) :=
    use_clause (p2785 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p139 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (7, false) :=
    use_clause (p2797 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (18, true) :=
    use_clause (p24 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (31, false) :=
    use_clause (p2187 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h10 : LitSat F.assign (9, true) :=
    use_clause (p146 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h11 : LitSat F.assign (27, false) :=
    use_clause (p1905 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h12 : LitSat F.assign (11, false) :=
    use_clause (p2204 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h13 : LitSat F.assign (5, true) :=
    use_clause (p12 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h14 : LitSat F.assign (33, true) :=
    use_clause (p157 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  exact use_clause (p2199 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h14 h),
        True.intro⟩
def c2799 : CNF.Clause Nat := [(30, false), (50, true), (88, true), (51, true), (110, false)]
theorem p2799 (F : Frame G 4) : c2799.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (62, false) :=
    use_clause (p2785 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (39, true) :=
    use_clause (p139 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (7, false) :=
    use_clause (p2797 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (18, true) :=
    use_clause (p24 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (29, true) :=
    use_clause (p21 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h10 : LitSat F.assign (6, false) :=
    use_clause (p2798 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (17, true) :=
    use_clause (p15 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (22, false) :=
    use_clause (p1321 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h13 : LitSat F.assign (11, true) :=
    use_clause (p160 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h14 : LitSat F.assign (9, false) :=
    use_clause (p2204 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h15 : LitSat F.assign (31, false) :=
    use_clause (p1544 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
  exact use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
def c2800 : CNF.Clause Nat := [(50, true), (88, true), (51, true), (110, false)]
theorem p2800 (F : Frame G 4) : c2800.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (62, false) :=
    use_clause (p2785 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (7, false) :=
    use_clause (p2797 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (18, true) :=
    use_clause (p24 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (29, true) :=
    use_clause (p21 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (38, true) :=
    use_clause (p140 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (30, false) :=
    use_clause (p2799 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (19, true) :=
    use_clause (p143 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h11 : LitSat F.assign (6, false) :=
    use_clause (p1867 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h12 : LitSat F.assign (17, false) :=
    use_clause (p1318 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  exact use_clause (p15 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2801 : CNF.Clause Nat := [(88, true), (51, true), (110, false)]
theorem p2801 (F : Frame G 4) : c2801.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (62, false) :=
    use_clause (p2785 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h6 : LitSat F.assign (7, false) :=
    use_clause (p2797 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (29, true) :=
    use_clause (p21 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (18, true) :=
    use_clause (p24 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (50, true) :=
    use_clause (p2800 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h10 : LitSat F.assign (22, false) :=
    use_clause (p1904 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h11 : LitSat F.assign (11, true) :=
    use_clause (p160 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h12 : LitSat F.assign (33, true) :=
    use_clause (p154 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h13 : LitSat F.assign (38, false) :=
    use_clause (p1663 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h14 : LitSat F.assign (39, true) :=
    use_clause (p137 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h15 : LitSat F.assign (31, false) :=
    use_clause (p1605 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h16 : LitSat F.assign (9, true) :=
    use_clause (p146 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h17 : LitSat F.assign (30, false) :=
    use_clause (p2204 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h18 : LitSat F.assign (19, false) :=
    use_clause (p2101 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p143 F)
      ⟨fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
def c2802 : CNF.Clause Nat := [(18, false), (50, false), (51, true), (110, false)]
theorem p2802 (F : Frame G 4) : c2802.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (88, true) :=
    use_clause (p2801 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (62, false) :=
    use_clause (p2785 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (31, false) :=
    use_clause (p1988 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h7 : LitSat F.assign (9, true) :=
    use_clause (p146 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h8 : LitSat F.assign (38, false) :=
    use_clause (p2221 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (39, true) :=
    use_clause (p137 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h10 : LitSat F.assign (7, false) :=
    use_clause (p1923 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (29, false) :=
    use_clause (p1547 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p21 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c2803 : CNF.Clause Nat := [(50, false), (51, true), (110, false)]
theorem p2803 (F : Frame G 4) : c2803.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (88, true) :=
    use_clause (p2801 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (62, false) :=
    use_clause (p2785 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (26, false) :=
    use_clause (p1987 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h7 : LitSat F.assign (18, false) :=
    use_clause (p2802 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (7, true) :=
    use_clause (p24 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (29, true) :=
    use_clause (p18 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h10 : LitSat F.assign (39, false) :=
    use_clause (p1923 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (31, false) :=
    use_clause (p2031 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h12 : LitSat F.assign (38, true) :=
    use_clause (p137 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h13 : LitSat F.assign (15, true) :=
    use_clause (p62 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h14 : LitSat F.assign (9, true) :=
    use_clause (p146 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h15 : LitSat F.assign (30, false) :=
    use_clause (p2108 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h16 : LitSat F.assign (87, false) :=
    use_clause (p1435 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h17 : LitSat F.assign (19, true) :=
    use_clause (p144 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h16 h),
        True.intro⟩
  exact use_clause (p1870 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c2804 : CNF.Clause Nat := [(18, true), (51, true), (110, false)]
theorem p2804 (F : Frame G 4) : c2804.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (50, false) :=
    use_clause (p2803 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (62, false) :=
    use_clause (p2785 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (88, true) :=
    use_clause (p2801 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (39, true) :=
    use_clause (p139 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (27, false) :=
    use_clause (p1993 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h9 : LitSat F.assign (5, true) :=
    use_clause (p12 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h10 : LitSat F.assign (38, true) :=
    use_clause (p140 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h11 : LitSat F.assign (7, true) :=
    use_clause (p24 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h12 : LitSat F.assign (29, true) :=
    use_clause (p18 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h13 : LitSat F.assign (87, false) :=
    use_clause (p1676 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h14 : LitSat F.assign (30, false) :=
    use_clause (p1583 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h15 : LitSat F.assign (19, false) :=
    use_clause (p1871 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p144 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
def c2805 : CNF.Clause Nat := [(29, false), (51, true), (110, false)]
theorem p2805 (F : Frame G 4) : c2805.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (18, true) :=
    use_clause (p2804 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, false) :=
    use_clause (p2803 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (62, false) :=
    use_clause (p2785 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (88, true) :=
    use_clause (p2801 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (39, true) :=
    use_clause (p139 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h9 : LitSat F.assign (27, false) :=
    use_clause (p1993 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h10 : LitSat F.assign (5, true) :=
    use_clause (p12 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h11 : LitSat F.assign (38, true) :=
    use_clause (p140 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h12 : LitSat F.assign (17, false) :=
    use_clause (p2119 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h13 : LitSat F.assign (19, false) :=
    use_clause (p1871 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h14 : LitSat F.assign (6, true) :=
    use_clause (p15 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h15 : LitSat F.assign (22, false) :=
    use_clause (p1990 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h16 : LitSat F.assign (30, false) :=
    use_clause (p1595 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h17 : LitSat F.assign (33, false) :=
    use_clause (p1675 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p201 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c2806 : CNF.Clause Nat := [(51, true), (110, false)]
theorem p2806 (F : Frame G 4) : c2806.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have h0 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (62, false) :=
    use_clause (p2785 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h4 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, true) :=
    use_clause (p2801 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h6 : LitSat F.assign (50, false) :=
    use_clause (p2803 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h7 : LitSat F.assign (39, true) :=
    use_clause (p139 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h8 : LitSat F.assign (38, true) :=
    use_clause (p140 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h9 : LitSat F.assign (27, false) :=
    use_clause (p1993 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h10 : LitSat F.assign (5, true) :=
    use_clause (p12 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h11 : LitSat F.assign (18, true) :=
    use_clause (p2804 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h12 : LitSat F.assign (29, false) :=
    use_clause (p2805 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h13 : LitSat F.assign (7, true) :=
    use_clause (p21 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h14 : LitSat F.assign (87, false) :=
    use_clause (p1676 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h15 : LitSat F.assign (30, false) :=
    use_clause (p1583 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h16 : LitSat F.assign (19, true) :=
    use_clause (p144 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h14 h),
        True.intro⟩
  have h17 : LitSat F.assign (17, false) :=
    use_clause (p1318 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h18 : LitSat F.assign (6, false) :=
    use_clause (p1553 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p15 F)
      ⟨fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c2807 : CNF.Clause Nat := [(18, false), (40, false), (50, false), (88, false), (110, false)]
theorem p2807 (F : Frame G 4) : c2807.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (26, false) :=
    use_clause (p1749 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (39, false) :=
    use_clause (p2067 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (31, false) :=
    use_clause (p1988 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (9, true) :=
    use_clause (p146 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (38, false) :=
    use_clause (p2221 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (15, false) :=
    use_clause (p2214 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
def c2808 : CNF.Clause Nat := [(38, true), (40, false), (88, false), (62, true), (110, false)]
theorem p2808 (F : Frame G 4) : c2808.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (39, false) :=
    use_clause (p2067 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (18, false) :=
    use_clause (p2807 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (26, false) :=
    use_clause (p1749 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h8 : LitSat F.assign (15, true) :=
    use_clause (p10 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h9 : LitSat F.assign (7, true) :=
    use_clause (p53 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (9, false) :=
    use_clause (p2214 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h11 : LitSat F.assign (31, false) :=
    use_clause (p2031 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2809 : CNF.Clause Nat := [(9, false), (40, false), (88, false), (62, true), (110, false)]
theorem p2809 (F : Frame G 4) : c2809.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (38, true) :=
    use_clause (p2808 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (39, false) :=
    use_clause (p2067 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (18, false) :=
    use_clause (p2807 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (19, false) :=
    use_clause (p1527 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (26, false) :=
    use_clause (p1749 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h10 : LitSat F.assign (15, false) :=
    use_clause (p2214 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h11 : LitSat F.assign (29, true) :=
    use_clause (p63 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h12 : LitSat F.assign (17, false) :=
    use_clause (p2119 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h13 : LitSat F.assign (87, false) :=
    use_clause (p1435 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h14 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h15 : LitSat F.assign (30, true) :=
    use_clause (p144 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
  exact use_clause (p2107 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c2810 : CNF.Clause Nat := [(40, false), (88, false), (62, true), (110, false)]
theorem p2810 (F : Frame G 4) : c2810.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (39, false) :=
    use_clause (p2067 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (26, false) :=
    use_clause (p1749 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (19, false) :=
    use_clause (p1527 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h8 : LitSat F.assign (18, false) :=
    use_clause (p2807 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (38, true) :=
    use_clause (p2808 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (9, false) :=
    use_clause (p2809 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h11 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (17, false) :=
    use_clause (p1994 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h13 : LitSat F.assign (7, false) :=
    use_clause (p2031 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h14 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h15 : LitSat F.assign (15, true) :=
    use_clause (p65 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h16 : LitSat F.assign (29, true) :=
    use_clause (p27 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h17 : LitSat F.assign (30, false) :=
    use_clause (p2107 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h18 : LitSat F.assign (22, false) :=
    use_clause (p1990 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h19 : LitSat F.assign (33, false) :=
    use_clause (p1683 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p201 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2811 : CNF.Clause Nat := [(18, true), (88, false), (62, true), (110, false)]
theorem p2811 (F : Frame G 4) : c2811.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (39, false) :=
    use_clause (p2067 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (26, false) :=
    use_clause (p1749 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (40, false) :=
    use_clause (p2810 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h10 : LitSat F.assign (7, true) :=
    use_clause (p25 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h11 : LitSat F.assign (29, true) :=
    use_clause (p19 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h12 : LitSat F.assign (17, false) :=
    use_clause (p2119 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h13 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h14 : LitSat F.assign (9, false) :=
    use_clause (p1281 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h15 : LitSat F.assign (31, false) :=
    use_clause (p1975 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2812 : CNF.Clause Nat := [(29, false), (9, false), (88, false), (62, true), (110, false)]
theorem p2812 (F : Frame G 4) : c2812.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (39, false) :=
    use_clause (p2067 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (18, true) :=
    use_clause (p2811 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (30, false) :=
    use_clause (p2076 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (26, false) :=
    use_clause (p1749 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (40, false) :=
    use_clause (p2810 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h10 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h11 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h12 : LitSat F.assign (17, false) :=
    use_clause (p2119 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h13 : LitSat F.assign (19, false) :=
    use_clause (p2077 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h14 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h15 : LitSat F.assign (87, true) :=
    use_clause (p144 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p1465 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c2813 : CNF.Clause Nat := [(9, false), (88, false), (62, true), (110, false)]
theorem p2813 (F : Frame G 4) : c2813.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (39, false) :=
    use_clause (p2067 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (18, true) :=
    use_clause (p2811 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (30, false) :=
    use_clause (p2076 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (26, false) :=
    use_clause (p1749 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (40, false) :=
    use_clause (p2810 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h11 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h12 : LitSat F.assign (29, false) :=
    use_clause (p2812 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h13 : LitSat F.assign (7, true) :=
    use_clause (p22 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h14 : LitSat F.assign (6, false) :=
    use_clause (p1281 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h15 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h16 : LitSat F.assign (19, false) :=
    use_clause (p1313 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h17 : LitSat F.assign (87, false) :=
    use_clause (p2080 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p144 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h17 h),
        True.intro⟩
def c2814 : CNF.Clause Nat := [(88, false), (62, true), (110, false)]
theorem p2814 (F : Frame G 4) : c2814.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (39, false) :=
    use_clause (p2067 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h6 : LitSat F.assign (40, false) :=
    use_clause (p2810 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (18, true) :=
    use_clause (p2811 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (30, false) :=
    use_clause (p2076 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h10 : LitSat F.assign (9, false) :=
    use_clause (p2813 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h11 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h12 : LitSat F.assign (19, false) :=
    use_clause (p2065 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h13 : LitSat F.assign (87, true) :=
    use_clause (p144 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h14 : LitSat F.assign (6, false) :=
    use_clause (p2081 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h15 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h16 : LitSat F.assign (29, false) :=
    use_clause (p2119 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        True.intro⟩
  have h17 : LitSat F.assign (7, false) :=
    use_clause (p1383 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p22 F)
      ⟨fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c2815 : CNF.Clause Nat := [(39, true), (38, false), (18, false), (62, true), (110, false)]
theorem p2815 (F : Frame G 4) : c2815.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (88, false) :=
    use_clause (p2814 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (30, false) :=
    use_clause (p2076 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (19, true) :=
    use_clause (p143 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (31, false) :=
    use_clause (p2065 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (9, true) :=
    use_clause (p146 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h10 : LitSat F.assign (26, false) :=
    use_clause (p2063 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (40, false) :=
    use_clause (p1874 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h12 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h13 : LitSat F.assign (22, false) :=
    use_clause (p1316 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h14 : LitSat F.assign (29, false) :=
    use_clause (p2077 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h15 : LitSat F.assign (11, true) :=
    use_clause (p160 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h16 : LitSat F.assign (7, true) :=
    use_clause (p22 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p1292 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c2816 : CNF.Clause Nat := [(19, false), (29, true), (9, false), (39, false), (38, false), (62, true), (110, false)]
theorem p2816 (F : Frame G 4) : c2816.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (19, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (29, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (88, false) :=
    use_clause (p2814 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (40, false) :=
    use_clause (p2092 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (7, true) :=
    use_clause (p22 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (11, false) :=
    use_clause (p1292 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h9 : LitSat F.assign (33, false) :=
    use_clause (p2079 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p157 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c2817 : CNF.Clause Nat := [(30, false), (39, false), (38, false), (88, true), (110, false)]
theorem p2817 (F : Frame G 4) : c2817.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (33, false) :=
    use_clause (p2117 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h6 : LitSat F.assign (22, true) :=
    use_clause (p154 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (11, true) :=
    use_clause (p157 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p2118 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c2818 : CNF.Clause Nat := [(9, false), (39, false), (38, false), (62, true), (110, false)]
theorem p2818 (F : Frame G 4) : c2818.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (88, false) :=
    use_clause (p2814 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (30, false) :=
    use_clause (p2817 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (19, true) :=
    use_clause (p143 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (29, false) :=
    use_clause (p2078 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p2816 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c2819 : CNF.Clause Nat := [(38, false), (18, false), (62, true), (110, false)]
theorem p2819 (F : Frame G 4) : c2819.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (88, false) :=
    use_clause (p2814 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (39, true) :=
    use_clause (p2815 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (30, false) :=
    use_clause (p2817 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (19, true) :=
    use_clause (p143 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (9, false) :=
    use_clause (p2818 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h11 : LitSat F.assign (50, false) :=
    use_clause (p2065 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h12 : LitSat F.assign (22, false) :=
    use_clause (p2091 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h13 : LitSat F.assign (33, true) :=
    use_clause (p154 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h14 : LitSat F.assign (6, false) :=
    use_clause (p2115 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
  have h15 : LitSat F.assign (17, false) :=
    use_clause (p2116 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p15 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c2820 : CNF.Clause Nat := [(33, false), (31, false), (19, false), (39, false), (18, false), (62, true), (110, false)]
theorem p2820 (F : Frame G 4) : c2820.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (33, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (31, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (19, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (38, false) :=
    use_clause (p2819 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (50, false) :=
    use_clause (p2065 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (40, true) :=
    use_clause (p136 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (88, false) :=
    use_clause (p2814 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h8 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (11, false) :=
    use_clause (p1587 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h10 : LitSat F.assign (6, false) :=
    use_clause (p2210 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h11 : LitSat F.assign (22, true) :=
    use_clause (p160 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h12 : LitSat F.assign (17, true) :=
    use_clause (p15 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p1323 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c2821 : CNF.Clause Nat := [(31, false), (19, false), (39, false), (18, false), (62, true), (110, false)]
theorem p2821 (F : Frame G 4) : c2821.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (31, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (19, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (38, false) :=
    use_clause (p2819 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, false) :=
    use_clause (p2814 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (50, false) :=
    use_clause (p2065 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (5, false) :=
    use_clause (p1375 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (40, true) :=
    use_clause (p136 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h10 : LitSat F.assign (27, true) :=
    use_clause (p14 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h11 : LitSat F.assign (33, false) :=
    use_clause (p2820 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h12 : LitSat F.assign (22, true) :=
    use_clause (p154 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h13 : LitSat F.assign (11, true) :=
    use_clause (p157 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h14 : LitSat F.assign (29, false) :=
    use_clause (p1854 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
  have h15 : LitSat F.assign (7, false) :=
    use_clause (p1826 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
  have h16 : LitSat F.assign (15, false) :=
    use_clause (p1310 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h17 : LitSat F.assign (26, false) :=
    use_clause (p2068 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p72 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c2822 : CNF.Clause Nat := [(19, false), (39, false), (18, false), (62, true), (110, false)]
theorem p2822 (F : Frame G 4) : c2822.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (19, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (38, false) :=
    use_clause (p2819 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (88, false) :=
    use_clause (p2814 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (31, false) :=
    use_clause (p2821 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (9, true) :=
    use_clause (p146 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h8 : LitSat F.assign (40, false) :=
    use_clause (p2092 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (29, false) :=
    use_clause (p2078 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h10 : LitSat F.assign (50, true) :=
    use_clause (p136 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h11 : LitSat F.assign (7, true) :=
    use_clause (p22 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h12 : LitSat F.assign (26, false) :=
    use_clause (p2063 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h13 : LitSat F.assign (11, false) :=
    use_clause (p1292 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h14 : LitSat F.assign (15, true) :=
    use_clause (p9 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h15 : LitSat F.assign (22, true) :=
    use_clause (p160 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p1310 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c2823 : CNF.Clause Nat := [(39, false), (18, false), (62, true), (110, false)]
theorem p2823 (F : Frame G 4) : c2823.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (38, false) :=
    use_clause (p2819 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, false) :=
    use_clause (p2814 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (19, false) :=
    use_clause (p2822 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (30, true) :=
    use_clause (p143 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h9 : LitSat F.assign (50, false) :=
    use_clause (p2076 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (33, false) :=
    use_clause (p2117 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h11 : LitSat F.assign (40, true) :=
    use_clause (p136 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h12 : LitSat F.assign (22, true) :=
    use_clause (p154 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h13 : LitSat F.assign (11, true) :=
    use_clause (p157 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h14 : LitSat F.assign (29, false) :=
    use_clause (p1854 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
  have h15 : LitSat F.assign (9, false) :=
    use_clause (p2204 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h16 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h17 : LitSat F.assign (6, false) :=
    use_clause (p2187 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h18 : LitSat F.assign (17, true) :=
    use_clause (p15 F)
      ⟨fun h => False.elim (unit_incompatible h17 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h19 : LitSat F.assign (5, false) :=
    use_clause (p1369 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h20 : LitSat F.assign (27, true) :=
    use_clause (p14 F)
      ⟨fun h => False.elim (unit_incompatible h19 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h21 : LitSat F.assign (7, true) :=
    use_clause (p95 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p1826 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h20 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h21 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
def c2824 : CNF.Clause Nat := [(18, false), (62, true), (110, false)]
theorem p2824 (F : Frame G 4) : c2824.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (88, false) :=
    use_clause (p2814 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (38, false) :=
    use_clause (p2819 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (39, false) :=
    use_clause (p2823 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (40, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        True.intro⟩
  have h10 : LitSat F.assign (30, false) :=
    use_clause (p2076 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h11 : LitSat F.assign (22, false) :=
    use_clause (p2203 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h12 : LitSat F.assign (19, true) :=
    use_clause (p143 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h13 : LitSat F.assign (11, true) :=
    use_clause (p160 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h14 : LitSat F.assign (33, true) :=
    use_clause (p154 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h15 : LitSat F.assign (31, false) :=
    use_clause (p2065 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h16 : LitSat F.assign (9, true) :=
    use_clause (p146 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h17 : LitSat F.assign (17, false) :=
    use_clause (p1849 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h14 h),
        True.intro⟩
  have h18 : LitSat F.assign (6, false) :=
    use_clause (p1288 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c2825 : CNF.Clause Nat := [(22, true), (9, false), (19, false), (39, true), (62, true), (110, false)]
theorem p2825 (F : Frame G 4) : c2825.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (19, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (18, false) :=
    use_clause (p2824 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, false) :=
    use_clause (p2814 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (11, true) :=
    use_clause (p160 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (33, true) :=
    use_clause (p154 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h9 : LitSat F.assign (6, false) :=
    use_clause (p1288 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h10 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (40, false) :=
    use_clause (p1849 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h12 : LitSat F.assign (7, true) :=
    use_clause (p25 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p1292 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c2826 : CNF.Clause Nat := [(9, false), (19, false), (39, true), (62, true), (110, false)]
theorem p2826 (F : Frame G 4) : c2826.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (19, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (18, false) :=
    use_clause (p2824 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, false) :=
    use_clause (p2814 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (22, true) :=
    use_clause (p2825 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (40, false) :=
    use_clause (p2203 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h10 : LitSat F.assign (7, true) :=
    use_clause (p25 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h11 : LitSat F.assign (11, false) :=
    use_clause (p1292 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h12 : LitSat F.assign (33, false) :=
    use_clause (p2083 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  exact use_clause (p157 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c2827 : CNF.Clause Nat := [(19, false), (39, true), (62, true), (110, false)]
theorem p2827 (F : Frame G 4) : c2827.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (19, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (18, false) :=
    use_clause (p2824 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, false) :=
    use_clause (p2814 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (9, false) :=
    use_clause (p2826 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h10 : LitSat F.assign (7, false) :=
    use_clause (p2084 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h11 : LitSat F.assign (40, true) :=
    use_clause (p25 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h12 : LitSat F.assign (29, true) :=
    use_clause (p27 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h13 : LitSat F.assign (22, false) :=
    use_clause (p2203 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h14 : LitSat F.assign (33, true) :=
    use_clause (p154 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h15 : LitSat F.assign (15, false) :=
    use_clause (p2191 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h16 : LitSat F.assign (38, true) :=
    use_clause (p60 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h17 : LitSat F.assign (6, false) :=
    use_clause (p1867 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h18 : LitSat F.assign (17, false) :=
    use_clause (p2193 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c2828 : CNF.Clause Nat := [(33, false), (31, false), (39, true), (62, true), (110, false)]
theorem p2828 (F : Frame G 4) : c2828.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (33, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (31, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (88, false) :=
    use_clause (p2814 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (19, false) :=
    use_clause (p2827 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (30, true) :=
    use_clause (p143 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (18, false) :=
    use_clause (p2824 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (29, false) :=
    use_clause (p1361 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h10 : LitSat F.assign (26, false) :=
    use_clause (p1343 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h11 : LitSat F.assign (40, true) :=
    use_clause (p19 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h12 : LitSat F.assign (15, true) :=
    use_clause (p63 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p2191 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c2829 : CNF.Clause Nat := [(33, true), (30, false), (50, false), (39, true), (88, true), (110, false)]
theorem p2829 (F : Frame G 4) : c2829.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (33, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (22, true) :=
    use_clause (p154 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (11, true) :=
    use_clause (p157 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (40, false) :=
    use_clause (p2203 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (38, false) :=
    use_clause (p2118 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p134 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
def c2830 : CNF.Clause Nat := [(40, true), (39, true), (62, true), (110, false)]
theorem p2830 (F : Frame G 4) : c2830.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, false) :=
    use_clause (p2814 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (19, false) :=
    use_clause (p2827 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (30, true) :=
    use_clause (p143 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h6 : LitSat F.assign (33, true) :=
    use_clause (p2829 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (31, false) :=
    use_clause (p2828 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (9, true) :=
    use_clause (p146 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (18, false) :=
    use_clause (p2824 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h11 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h12 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (7, true) :=
    use_clause (p25 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h14 : LitSat F.assign (6, false) :=
    use_clause (p1281 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h15 : LitSat F.assign (17, false) :=
    use_clause (p2082 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  exact use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c2831 : CNF.Clause Nat := [(39, true), (62, true), (110, false)]
theorem p2831 (F : Frame G 4) : c2831.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (88, false) :=
    use_clause (p2814 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h7 : LitSat F.assign (19, false) :=
    use_clause (p2827 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (30, true) :=
    use_clause (p143 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (33, true) :=
    use_clause (p2829 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h10 : LitSat F.assign (31, false) :=
    use_clause (p2828 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h11 : LitSat F.assign (9, true) :=
    use_clause (p146 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h12 : LitSat F.assign (40, true) :=
    use_clause (p2830 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h13 : LitSat F.assign (22, false) :=
    use_clause (p2203 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h14 : LitSat F.assign (17, false) :=
    use_clause (p2192 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h15 : LitSat F.assign (11, true) :=
    use_clause (p160 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h16 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p1288 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c2832 : CNF.Clause Nat := [(22, true), (62, true), (110, false)]
theorem p2832 (F : Frame G 4) : c2832.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (39, true) :=
    use_clause (p2831 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (18, false) :=
    use_clause (p2824 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, false) :=
    use_clause (p2814 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (11, true) :=
    use_clause (p160 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h9 : LitSat F.assign (33, true) :=
    use_clause (p154 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h10 : LitSat F.assign (30, false) :=
    use_clause (p2117 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h11 : LitSat F.assign (19, true) :=
    use_clause (p143 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h12 : LitSat F.assign (40, false) :=
    use_clause (p1587 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h13 : LitSat F.assign (7, true) :=
    use_clause (p25 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h14 : LitSat F.assign (9, false) :=
    use_clause (p1292 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h15 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h16 : LitSat F.assign (50, false) :=
    use_clause (p2084 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h17 : LitSat F.assign (38, false) :=
    use_clause (p2044 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p136 F)
      ⟨fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c2833 : CNF.Clause Nat := [(62, true), (110, false)]
theorem p2833 (F : Frame G 4) : c2833.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have h0 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, false) :=
    use_clause (p2814 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (18, false) :=
    use_clause (p2824 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h7 : LitSat F.assign (39, true) :=
    use_clause (p2831 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h8 : LitSat F.assign (22, true) :=
    use_clause (p2832 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (29, false) :=
    use_clause (p1854 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h10 : LitSat F.assign (40, true) :=
    use_clause (p19 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h11 : LitSat F.assign (7, true) :=
    use_clause (p27 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h12 : LitSat F.assign (50, false) :=
    use_clause (p2203 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h13 : LitSat F.assign (27, false) :=
    use_clause (p1826 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h14 : LitSat F.assign (38, true) :=
    use_clause (p88 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h15 : LitSat F.assign (30, false) :=
    use_clause (p2817 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h16 : LitSat F.assign (9, false) :=
    use_clause (p2818 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h17 : LitSat F.assign (19, true) :=
    use_clause (p143 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h18 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p2091 F)
      ⟨fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2834 : CNF.Clause Nat := [(19, false), (40, false), (50, true), (22, false), (39, false), (110, false)]
theorem p2834 (F : Frame G 4) : c2834.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (19, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, false) :=
    use_clause (p2067 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (62, true) :=
    use_clause (p2833 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (27, false) :=
    use_clause (p2196 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (9, false) :=
    use_clause (p2092 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h10 : LitSat F.assign (5, false) :=
    use_clause (p1375 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h11 : LitSat F.assign (38, false) :=
    use_clause (p2091 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p14 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c2835 : CNF.Clause Nat := [(40, false), (50, true), (22, false), (39, false), (110, false)]
theorem p2835 (F : Frame G 4) : c2835.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, false) :=
    use_clause (p2067 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (62, true) :=
    use_clause (p2833 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (19, false) :=
    use_clause (p2834 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (30, true) :=
    use_clause (p143 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h9 : LitSat F.assign (31, false) :=
    use_clause (p1374 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h10 : LitSat F.assign (33, false) :=
    use_clause (p2117 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h11 : LitSat F.assign (9, true) :=
    use_clause (p146 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h12 : LitSat F.assign (11, true) :=
    use_clause (p157 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p2204 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
def c2836 : CNF.Clause Nat := [(30, false), (40, true), (39, false), (110, false)]
theorem p2836 (F : Frame G 4) : c2836.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, false) :=
    use_clause (p2067 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (62, true) :=
    use_clause (p2833 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (15, false) :=
    use_clause (p1968 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (31, false) :=
    use_clause (p1374 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (38, false) :=
    use_clause (p2817 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (26, true) :=
    use_clause (p9 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h11 : LitSat F.assign (9, true) :=
    use_clause (p146 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p2073 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c2837 : CNF.Clause Nat := [(9, false), (19, false), (40, true), (22, false), (88, true), (110, false)]
theorem p2837 (F : Frame G 4) : c2837.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (19, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, true) :=
    use_clause (p2833 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (26, false) :=
    use_clause (p2073 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (38, false) :=
    use_clause (p2034 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (15, true) :=
    use_clause (p9 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p1310 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c2838 : CNF.Clause Nat := [(50, true), (22, false), (39, false), (110, false)]
theorem p2838 (F : Frame G 4) : c2838.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, false) :=
    use_clause (p2067 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (29, false) :=
    use_clause (p1854 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h7 : LitSat F.assign (40, false) :=
    use_clause (p2835 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (30, false) :=
    use_clause (p2836 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (19, true) :=
    use_clause (p143 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h10 : LitSat F.assign (9, false) :=
    use_clause (p2837 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h11 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h12 : LitSat F.assign (5, false) :=
    use_clause (p1375 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h13 : LitSat F.assign (38, false) :=
    use_clause (p2091 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (27, true) :=
    use_clause (p14 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h15 : LitSat F.assign (7, true) :=
    use_clause (p96 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  exact use_clause (p1826 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c2839 : CNF.Clause Nat := [(22, false), (39, false), (110, false)]
theorem p2839 (F : Frame G 4) : c2839.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, false) :=
    use_clause (p2067 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (62, true) :=
    use_clause (p2833 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (29, false) :=
    use_clause (p1854 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h8 : LitSat F.assign (50, true) :=
    use_clause (p2838 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (40, false) :=
    use_clause (p2203 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h10 : LitSat F.assign (30, false) :=
    use_clause (p2836 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h11 : LitSat F.assign (19, true) :=
    use_clause (p143 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h12 : LitSat F.assign (9, false) :=
    use_clause (p2837 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h13 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h14 : LitSat F.assign (18, false) :=
    use_clause (p2065 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h15 : LitSat F.assign (7, false) :=
    use_clause (p2084 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h16 : LitSat F.assign (27, false) :=
    use_clause (p2064 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h17 : LitSat F.assign (5, false) :=
    use_clause (p1375 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h18 : LitSat F.assign (38, false) :=
    use_clause (p2091 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p112 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
def c2840 : CNF.Clause Nat := [(39, false), (110, false)]
theorem p2840 (F : Frame G 4) : c2840.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (39, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have h0 : LitSat F.assign (62, true) :=
    use_clause (p2833 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h1 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, false) :=
    use_clause (p2067 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (22, false) :=
    use_clause (p2839 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h8 : LitSat F.assign (33, true) :=
    use_clause (p154 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h9 : LitSat F.assign (30, false) :=
    use_clause (p2117 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h10 : LitSat F.assign (19, true) :=
    use_clause (p143 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h11 : LitSat F.assign (9, false) :=
    use_clause (p2066 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h12 : LitSat F.assign (31, false) :=
    use_clause (p2072 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  exact use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c2841 : CNF.Clause Nat := [(50, false), (19, false), (33, false), (11, false), (31, false), (87, false), (110, false)]
theorem p2841 (F : Frame G 4) : c2841.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (19, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (33, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (31, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p2840 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (62, true) :=
    use_clause (p2833 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (38, false) :=
    use_clause (p2114 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h6 : LitSat F.assign (40, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h8 : LitSat F.assign (88, false) :=
    use_clause (p2185 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (29, false) :=
    use_clause (p2767 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h10 : LitSat F.assign (26, false) :=
    use_clause (p2100 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h11 : LitSat F.assign (18, false) :=
    use_clause (p2065 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h12 : LitSat F.assign (7, false) :=
    use_clause (p2084 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h13 : LitSat F.assign (15, false) :=
    use_clause (p2191 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p67 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
def c2842 : CNF.Clause Nat := [(31, false), (30, true), (87, false), (22, true), (110, false)]
theorem p2842 (F : Frame G 4) : c2842.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (31, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p2840 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (62, true) :=
    use_clause (p2833 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (88, false) :=
    use_clause (p2185 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h7 : LitSat F.assign (11, true) :=
    use_clause (p160 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h8 : LitSat F.assign (33, true) :=
    use_clause (p154 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h9 : LitSat F.assign (19, true) :=
    use_clause (p143 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h10 : LitSat F.assign (38, false) :=
    use_clause (p2114 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h11 : LitSat F.assign (40, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h12 : LitSat F.assign (27, false) :=
    use_clause (p2196 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h13 : LitSat F.assign (50, false) :=
    use_clause (p2841 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h14 : LitSat F.assign (5, true) :=
    use_clause (p14 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
  have h15 : LitSat F.assign (6, false) :=
    use_clause (p2240 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h16 : LitSat F.assign (17, false) :=
    use_clause (p1998 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
def c2843 : CNF.Clause Nat := [(88, true), (9, false), (30, true), (22, true), (110, false)]
theorem p2843 (F : Frame G 4) : c2843.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p2840 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (62, true) :=
    use_clause (p2833 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (11, true) :=
    use_clause (p160 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (33, true) :=
    use_clause (p154 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h8 : LitSat F.assign (19, true) :=
    use_clause (p143 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h9 : LitSat F.assign (6, false) :=
    use_clause (p1288 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h10 : LitSat F.assign (38, false) :=
    use_clause (p2114 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h11 : LitSat F.assign (40, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h12 : LitSat F.assign (5, false) :=
    use_clause (p1278 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h13 : LitSat F.assign (27, false) :=
    use_clause (p2196 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h14 : LitSat F.assign (50, true) :=
    use_clause (p14 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        True.intro⟩
  have h15 : LitSat F.assign (17, false) :=
    use_clause (p1849 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  exact use_clause (p87 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2844 : CNF.Clause Nat := [(30, true), (87, false), (22, true), (110, false)]
theorem p2844 (F : Frame G 4) : c2844.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p2840 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (62, true) :=
    use_clause (p2833 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (31, false) :=
    use_clause (p2842 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (9, true) :=
    use_clause (p146 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h8 : LitSat F.assign (26, false) :=
    use_clause (p2073 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (88, true) :=
    use_clause (p2843 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (40, false) :=
    use_clause (p1473 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h11 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  have h12 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  have h13 : LitSat F.assign (7, false) :=
    use_clause (p1668 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h14 : LitSat F.assign (33, false) :=
    use_clause (p1536 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h15 : LitSat F.assign (27, false) :=
    use_clause (p1395 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h16 : LitSat F.assign (19, true) :=
    use_clause (p201 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h17 : LitSat F.assign (50, false) :=
    use_clause (p2016 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h18 : LitSat F.assign (29, false) :=
    use_clause (p2077 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h19 : LitSat F.assign (5, true) :=
    use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h17 h),
        True.intro⟩
  have h20 : LitSat F.assign (18, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  exact use_clause (p1501 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h20 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
def c2845 : CNF.Clause Nat := [(9, false), (87, false), (22, true), (110, false)]
theorem p2845 (F : Frame G 4) : c2845.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (62, true) :=
    use_clause (p2833 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (30, true) :=
    use_clause (p2844 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (15, false) :=
    use_clause (p1968 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (39, false) :=
    use_clause (p2840 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (26, false) :=
    use_clause (p2073 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (38, true) :=
    use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h10 : LitSat F.assign (40, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        True.intro⟩
  have h11 : LitSat F.assign (88, false) :=
    use_clause (p1473 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h12 : LitSat F.assign (50, false) :=
    use_clause (p2058 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h13 : LitSat F.assign (33, true) :=
    use_clause (p154 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (6, false) :=
    use_clause (p2745 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h15 : LitSat F.assign (17, false) :=
    use_clause (p1492 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
  exact use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
def c2846 : CNF.Clause Nat := [(87, false), (22, true), (110, false)]
theorem p2846 (F : Frame G 4) : c2846.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p2840 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (62, true) :=
    use_clause (p2833 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (30, true) :=
    use_clause (p2844 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (15, false) :=
    use_clause (p1968 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (9, false) :=
    use_clause (p2845 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h10 : LitSat F.assign (88, false) :=
    use_clause (p2185 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h11 : LitSat F.assign (33, true) :=
    use_clause (p154 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h12 : LitSat F.assign (26, false) :=
    use_clause (p1343 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h13 : LitSat F.assign (38, true) :=
    use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (40, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h15 : LitSat F.assign (18, false) :=
    use_clause (p2113 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h16 : LitSat F.assign (7, false) :=
    use_clause (p1372 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h17 : LitSat F.assign (17, false) :=
    use_clause (p1370 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h18 : LitSat F.assign (6, false) :=
    use_clause (p1371 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h19 : LitSat F.assign (29, true) :=
    use_clause (p67 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        True.intro⟩
  have h20 : LitSat F.assign (50, true) :=
    use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p2767 F)
      ⟨fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h20 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c2847 : CNF.Clause Nat := [(38, true), (30, false), (87, true), (110, false)]
theorem p2847 (F : Frame G 4) : c2847.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (62, true) :=
    use_clause (p2833 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (15, false) :=
    use_clause (p1968 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (88, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (31, false) :=
    use_clause (p2185 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (9, true) :=
    use_clause (p146 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (39, false) :=
    use_clause (p2840 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (40, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        True.intro⟩
  have h11 : LitSat F.assign (26, true) :=
    use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h12 : LitSat F.assign (50, false) :=
    use_clause (p2058 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h13 : LitSat F.assign (27, false) :=
    use_clause (p1332 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h14 : LitSat F.assign (17, false) :=
    use_clause (p2205 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p2363 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
def c2848 : CNF.Clause Nat := [(30, false), (22, true), (110, false)]
theorem p2848 (F : Frame G 4) : c2848.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (62, true) :=
    use_clause (p2833 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, false) :=
    use_clause (p2846 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (31, false) :=
    use_clause (p2185 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (9, true) :=
    use_clause (p146 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (39, false) :=
    use_clause (p2840 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (15, false) :=
    use_clause (p1968 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h11 : LitSat F.assign (6, false) :=
    use_clause (p1576 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h12 : LitSat F.assign (38, true) :=
    use_clause (p2847 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h13 : LitSat F.assign (21, false) :=
    use_clause (p2130 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h14 : LitSat F.assign (33, false) :=
    use_clause (p1511 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h15 : LitSat F.assign (10, true) :=
    use_clause (p205 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h16 : LitSat F.assign (19, true) :=
    use_clause (p187 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h17 : LitSat F.assign (40, false) :=
    use_clause (p1667 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h18 : LitSat F.assign (50, false) :=
    use_clause (p2016 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h19 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h17 h),
        True.intro⟩
  have h20 : LitSat F.assign (17, true) :=
    use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h18 h),
        True.intro⟩
  exact use_clause (p1503 F)
      ⟨fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h20 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
def c2849 : CNF.Clause Nat := [(22, true), (110, false)]
theorem p2849 (F : Frame G 4) : c2849.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have h0 : LitSat F.assign (39, false) :=
    use_clause (p2840 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h1 : LitSat F.assign (62, true) :=
    use_clause (p2833 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, false) :=
    use_clause (p2846 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h7 : LitSat F.assign (88, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (31, false) :=
    use_clause (p2185 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (9, true) :=
    use_clause (p146 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h10 : LitSat F.assign (30, false) :=
    use_clause (p2848 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h11 : LitSat F.assign (19, true) :=
    use_clause (p144 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h12 : LitSat F.assign (33, true) :=
    use_clause (p182 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h13 : LitSat F.assign (38, false) :=
    use_clause (p1511 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h14 : LitSat F.assign (40, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        True.intro⟩
  have h15 : LitSat F.assign (50, false) :=
    use_clause (p1527 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h16 : LitSat F.assign (27, false) :=
    use_clause (p2196 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h17 : LitSat F.assign (5, true) :=
    use_clause (p14 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h15 h),
        True.intro⟩
  have h18 : LitSat F.assign (17, true) :=
    use_clause (p2363 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1746 F)
      ⟨fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
def c2850 : CNF.Clause Nat := [(88, false), (9, false), (30, true), (110, false)]
theorem p2850 (F : Frame G 4) : c2850.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (22, true) :=
    use_clause (p2849 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (39, false) :=
    use_clause (p2840 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, true) :=
    use_clause (p2833 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (38, false) :=
    use_clause (p1558 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (40, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (87, false) :=
    use_clause (p1473 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h10 : LitSat F.assign (19, true) :=
    use_clause (p144 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h11 : LitSat F.assign (50, false) :=
    use_clause (p1527 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h12 : LitSat F.assign (27, false) :=
    use_clause (p2196 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h13 : LitSat F.assign (5, true) :=
    use_clause (p14 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h14 : LitSat F.assign (17, true) :=
    use_clause (p2363 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h15 : LitSat F.assign (26, false) :=
    use_clause (p1521 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h16 : LitSat F.assign (15, false) :=
    use_clause (p1305 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c2851 : CNF.Clause Nat := [(9, false), (30, true), (110, false)]
theorem p2851 (F : Frame G 4) : c2851.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (22, true) :=
    use_clause (p2849 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (39, false) :=
    use_clause (p2840 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, true) :=
    use_clause (p2833 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (88, false) :=
    use_clause (p2850 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (19, true) :=
    use_clause (p143 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h9 : LitSat F.assign (26, false) :=
    use_clause (p2073 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h10 : LitSat F.assign (38, false) :=
    use_clause (p2034 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (15, false) :=
    use_clause (p1310 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c2852 : CNF.Clause Nat := [(38, true), (30, true), (110, false)]
theorem p2852 (F : Frame G 4) : c2852.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, true) :=
    use_clause (p2833 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (9, false) :=
    use_clause (p2851 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (88, false) :=
    use_clause (p2185 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h7 : LitSat F.assign (19, true) :=
    use_clause (p143 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h9 : LitSat F.assign (22, true) :=
    use_clause (p2849 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h10 : LitSat F.assign (39, false) :=
    use_clause (p2840 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h11 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h12 : LitSat F.assign (40, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        True.intro⟩
  have h13 : LitSat F.assign (15, false) :=
    use_clause (p1310 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h14 : LitSat F.assign (50, false) :=
    use_clause (p2203 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h15 : LitSat F.assign (27, false) :=
    use_clause (p2196 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h16 : LitSat F.assign (26, true) :=
    use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  have h17 : LitSat F.assign (5, true) :=
    use_clause (p14 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h14 h),
        True.intro⟩
  exact use_clause (p2110 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c2853 : CNF.Clause Nat := [(26, false), (30, true), (110, false)]
theorem p2853 (F : Frame G 4) : c2853.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (26, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (62, true) :=
    use_clause (p2833 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (9, false) :=
    use_clause (p2851 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h6 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (88, false) :=
    use_clause (p2185 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (19, true) :=
    use_clause (p143 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (38, true) :=
    use_clause (p2852 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h10 : LitSat F.assign (33, false) :=
    use_clause (p2114 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (11, true) :=
    use_clause (p157 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h12 : LitSat F.assign (15, false) :=
    use_clause (p2074 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h14 : LitSat F.assign (22, true) :=
    use_clause (p2849 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h15 : LitSat F.assign (39, false) :=
    use_clause (p2840 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h16 : LitSat F.assign (50, false) :=
    use_clause (p2103 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h17 : LitSat F.assign (5, false) :=
    use_clause (p2110 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h18 : LitSat F.assign (17, false) :=
    use_clause (p1323 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h19 : LitSat F.assign (6, true) :=
    use_clause (p17 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h16 h),
        True.intro⟩
  have h20 : LitSat F.assign (40, false) :=
    use_clause (p2195 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h21 : LitSat F.assign (27, false) :=
    use_clause (p2070 F)
      ⟨fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p33 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h20 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h21 h),
        fun h => False.elim (unit_incompatible h16 h),
        True.intro⟩
def c2854 : CNF.Clause Nat := [(30, true), (110, false)]
theorem p2854 (F : Frame G 4) : c2854.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have h0 : LitSat F.assign (22, true) :=
    use_clause (p2849 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h1 : LitSat F.assign (39, false) :=
    use_clause (p2840 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, true) :=
    use_clause (p2833 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h5 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (9, false) :=
    use_clause (p2851 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h8 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h9 : LitSat F.assign (88, false) :=
    use_clause (p2185 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h10 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h11 : LitSat F.assign (19, true) :=
    use_clause (p143 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h12 : LitSat F.assign (38, true) :=
    use_clause (p2852 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h13 : LitSat F.assign (33, false) :=
    use_clause (p2114 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h14 : LitSat F.assign (11, true) :=
    use_clause (p157 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h15 : LitSat F.assign (15, false) :=
    use_clause (p2074 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h16 : LitSat F.assign (26, false) :=
    use_clause (p2853 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h17 : LitSat F.assign (40, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h18 : LitSat F.assign (5, false) :=
    use_clause (p2194 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h19 : LitSat F.assign (50, false) :=
    use_clause (p2203 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h20 : LitSat F.assign (27, false) :=
    use_clause (p2196 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p39 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h20 h),
        fun h => False.elim (unit_incompatible h19 h),
        True.intro⟩
def c2855 : CNF.Clause Nat := [(38, false), (87, false), (110, false)]
theorem p2855 (F : Frame G 4) : c2855.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (30, true) :=
    use_clause (p2854 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (22, true) :=
    use_clause (p2849 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (39, false) :=
    use_clause (p2840 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (62, true) :=
    use_clause (p2833 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (9, false) :=
    use_clause (p2034 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (18, false) :=
    use_clause (p2113 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h10 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h11 : LitSat F.assign (7, false) :=
    use_clause (p1372 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h12 : LitSat F.assign (17, false) :=
    use_clause (p1370 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h13 : LitSat F.assign (6, false) :=
    use_clause (p1371 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h14 : LitSat F.assign (40, true) :=
    use_clause (p133 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        True.intro⟩
  have h15 : LitSat F.assign (50, true) :=
    use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p2203 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c2856 : CNF.Clause Nat := [(88, true), (110, false)]
theorem p2856 (F : Frame G 4) : c2856.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have h0 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h4 : LitSat F.assign (62, true) :=
    use_clause (p2833 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h5 : LitSat F.assign (30, true) :=
    use_clause (p2854 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h6 : LitSat F.assign (15, false) :=
    use_clause (p1968 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h7 : LitSat F.assign (22, true) :=
    use_clause (p2849 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h8 : LitSat F.assign (39, false) :=
    use_clause (p2840 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (87, true) :=
    use_clause (p261 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h10 : LitSat F.assign (38, false) :=
    use_clause (p2855 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h11 : LitSat F.assign (40, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        True.intro⟩
  have h12 : LitSat F.assign (26, true) :=
    use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h13 : LitSat F.assign (50, false) :=
    use_clause (p2203 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h14 : LitSat F.assign (9, false) :=
    use_clause (p2073 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h15 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h16 : LitSat F.assign (33, false) :=
    use_clause (p1343 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h17 : LitSat F.assign (27, false) :=
    use_clause (p1331 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h18 : LitSat F.assign (11, true) :=
    use_clause (p157 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h19 : LitSat F.assign (5, true) :=
    use_clause (p14 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
  have h20 : LitSat F.assign (17, false) :=
    use_clause (p2075 F)
      ⟨fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h15 h),
        True.intro⟩
  have h21 : LitSat F.assign (6, false) :=
    use_clause (p1270 F)
      ⟨fun h => False.elim (unit_incompatible h19 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h21 h),
        fun h => False.elim (unit_incompatible h20 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
def c2857 : CNF.Clause Nat := [(110, false)]
theorem p2857 (F : Frame G 4) : c2857.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (110, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have h0 : LitSat F.assign (99, false) :=
    use_clause (p2575 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2740 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, true) :=
    use_clause (p2806 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h4 : LitSat F.assign (62, true) :=
    use_clause (p2833 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h5 : LitSat F.assign (39, false) :=
    use_clause (p2840 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h6 : LitSat F.assign (22, true) :=
    use_clause (p2849 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h7 : LitSat F.assign (30, true) :=
    use_clause (p2854 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h8 : LitSat F.assign (15, false) :=
    use_clause (p1968 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h9 : LitSat F.assign (88, true) :=
    use_clause (p2856 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h10 : LitSat F.assign (31, false) :=
    use_clause (p2185 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h11 : LitSat F.assign (38, false) :=
    use_clause (p1558 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h12 : LitSat F.assign (9, true) :=
    use_clause (p146 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (87, true) :=
    use_clause (p2847 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h14 : LitSat F.assign (26, true) :=
    use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p2073 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n0 h),
        True.intro⟩
def c2858 : CNF.Clause Nat := [(98, false), (87, false), (38, true), (62, false), (88, false), (30, false), (51, false), (39, true)]
theorem p2858 (F : Frame G 4) : c2858.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (40, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (6, false) :=
    use_clause (p1576 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, false) :=
    use_clause (p1570 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (5, false) :=
    use_clause (p2180 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (17, true) :=
    use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (27, true) :=
    use_clause (p14 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p2120 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c2859 : CNF.Clause Nat := [(86, true), (98, true), (87, false), (40, false), (38, true), (62, false), (88, false)]
theorem p2859 (F : Frame G 4) : c2859.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (9, false) :=
    use_clause (p1473 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (31, true) :=
    use_clause (p147 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h4 : LitSat F.assign (5, false) :=
    use_clause (p2059 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (50, false) :=
    use_clause (p1801 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h6 : LitSat F.assign (10, false) :=
    use_clause (p1482 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (27, true) :=
    use_clause (p14 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (21, true) :=
    use_clause (p148 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1755 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c2860 : CNF.Clause Nat := [(99, false), (98, true), (87, false), (38, true), (62, false), (88, false), (51, false), (39, true)]
theorem p2860 (F : Frame G 4) : c2860.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (40, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (86, true) :=
    use_clause (p2859 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (17, false) :=
    use_clause (p1891 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h4 : LitSat F.assign (6, false) :=
    use_clause (p1760 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h5 : LitSat F.assign (5, false) :=
    use_clause (p2059 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (50, true) :=
    use_clause (p2343 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h7 : LitSat F.assign (21, false) :=
    use_clause (p1698 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h8 : LitSat F.assign (27, true) :=
    use_clause (p87 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h9 : LitSat F.assign (10, true) :=
    use_clause (p148 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1701 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
def c2861 : CNF.Clause Nat := [(87, false), (38, true), (62, false), (88, false), (30, false), (22, false), (51, false), (39, true)]
theorem p2861 (F : Frame G 4) : c2861.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (40, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (9, false) :=
    use_clause (p1473 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, false) :=
    use_clause (p2858 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, true) :=
    use_clause (p2859 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p2860 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (31, true) :=
    use_clause (p145 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (10, false) :=
    use_clause (p1482 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (21, true) :=
    use_clause (p148 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (50, false) :=
    use_clause (p1677 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (15, false) :=
    use_clause (p1312 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (17, false) :=
    use_clause (p1324 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (26, true) :=
    use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h13 : LitSat F.assign (6, true) :=
    use_clause (p17 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h14 : LitSat F.assign (27, false) :=
    use_clause (p1333 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h15 : LitSat F.assign (5, false) :=
    use_clause (p1575 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p14 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
def c2862 : CNF.Clause Nat := [(38, true), (62, false), (88, false), (30, false), (22, false), (51, false), (39, true)]
theorem p2862 (F : Frame G 4) : c2862.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (40, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (87, false) :=
    use_clause (p2861 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p266 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (6, false) :=
    use_clause (p1576 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (50, false) :=
    use_clause (p1570 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (17, true) :=
    use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (86, false) :=
    use_clause (p1693 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (99, true) :=
    use_clause (p264 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (27, false) :=
    use_clause (p1721 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h10 : LitSat F.assign (5, false) :=
    use_clause (p2216 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p14 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
def c2863 : CNF.Clause Nat := [(86, true), (38, false), (62, false), (88, false), (22, false), (51, false)]
theorem p2863 (F : Frame G 4) : c2863.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, false) :=
    use_clause (p1558 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (9, false) :=
    use_clause (p2034 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (31, true) :=
    use_clause (p147 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h6 : LitSat F.assign (21, false) :=
    use_clause (p1972 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (10, false) :=
    use_clause (p1490 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p148 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2864 : CNF.Clause Nat := [(99, false), (38, false), (62, false), (88, false), (22, false), (51, false), (39, true)]
theorem p2864 (F : Frame G 4) : c2864.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, false) :=
    use_clause (p1558 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, true) :=
    use_clause (p2863 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (11, false) :=
    use_clause (p1480 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (9, false) :=
    use_clause (p2034 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (6, false) :=
    use_clause (p1645 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (21, false) :=
    use_clause (p1972 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h8 : LitSat F.assign (7, false) :=
    use_clause (p1738 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h9 : LitSat F.assign (10, true) :=
    use_clause (p148 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (40, false) :=
    use_clause (p1652 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h11 : LitSat F.assign (31, false) :=
    use_clause (p1490 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h12 : LitSat F.assign (33, true) :=
    use_clause (p223 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (50, false) :=
    use_clause (p1765 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h14 : LitSat F.assign (17, true) :=
    use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
  have h15 : LitSat F.assign (29, true) :=
    use_clause (p119 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  exact use_clause (p1415 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
def c2865 : CNF.Clause Nat := [(62, false), (88, false), (39, true), (30, false), (22, false), (51, false)]
theorem p2865 (F : Frame G 4) : c2865.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p2862 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, false) :=
    use_clause (p1558 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (9, false) :=
    use_clause (p2034 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (86, true) :=
    use_clause (p2863 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (11, false) :=
    use_clause (p1480 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, false) :=
    use_clause (p2864 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (31, true) :=
    use_clause (p145 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (33, true) :=
    use_clause (p155 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (17, false) :=
    use_clause (p1384 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h11 : LitSat F.assign (10, false) :=
    use_clause (p1490 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h12 : LitSat F.assign (21, true) :=
    use_clause (p148 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (6, false) :=
    use_clause (p1381 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h14 : LitSat F.assign (50, true) :=
    use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h15 : LitSat F.assign (7, false) :=
    use_clause (p1512 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h16 : LitSat F.assign (40, false) :=
    use_clause (p1474 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h17 : LitSat F.assign (29, false) :=
    use_clause (p1418 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p131 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h16 h),
        True.intro⟩
def c2866 : CNF.Clause Nat := [(6, false), (31, false), (21, false), (86, false), (50, false), (62, true), (88, false), (22, false), (51, false)]
theorem p2866 (F : Frame G 4) : c2866.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (31, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (40, false) :=
    use_clause (p1677 F)
      ⟨fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (29, false) :=
    use_clause (p1454 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (18, false) :=
    use_clause (p1593 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p19 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c2867 : CNF.Clause Nat := [(31, false), (21, false), (98, true), (99, true), (86, false), (87, false), (62, true), (88, false), (22, false), (51, false), (39, true)]
theorem p2867 (F : Frame G 4) : c2867.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (31, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n10 h),
        fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (40, false) :=
    use_clause (p1677 F)
      ⟨fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (6, false) :=
    use_clause (p2866 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h4 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n10 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (7, false) :=
    use_clause (p1383 F)
      ⟨fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (18, false) :=
    use_clause (p1330 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p25 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c2868 : CNF.Clause Nat := [(21, false), (98, true), (99, true), (86, false), (87, false), (38, false), (62, true), (88, false), (22, false), (51, false), (39, true)]
theorem p2868 (F : Frame G 4) : c2868.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n10 h),
        fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (40, false) :=
    use_clause (p1677 F)
      ⟨fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (31, false) :=
    use_clause (p2867 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h4 : LitSat F.assign (9, true) :=
    use_clause (p145 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (33, false) :=
    use_clause (p1564 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h6 : LitSat F.assign (11, true) :=
    use_clause (p155 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (29, false) :=
    use_clause (p1457 F)
      ⟨fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (18, true) :=
    use_clause (p19 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h9 : LitSat F.assign (15, false) :=
    use_clause (p1317 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (26, false) :=
    use_clause (p1449 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c2869 : CNF.Clause Nat := [(18, false), (9, false), (10, false), (99, true), (86, false), (87, false), (62, true), (88, false), (22, false), (51, false), (39, true)]
theorem p2869 (F : Frame G 4) : c2869.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (40, false) :=
    use_clause (p1451 F)
      ⟨fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n10 h),
        fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (26, false) :=
    use_clause (p1464 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h5 : LitSat F.assign (11, false) :=
    use_clause (p1462 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h6 : LitSat F.assign (17, false) :=
    use_clause (p1315 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (33, true) :=
    use_clause (p155 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  exact use_clause (p1681 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
def c2870 : CNF.Clause Nat := [(9, false), (98, true), (99, true), (86, false), (87, false), (38, false), (62, true), (88, false), (22, false), (51, false), (39, true)]
theorem p2870 (F : Frame G 4) : c2870.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (21, false) :=
    use_clause (p2868 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h2 : LitSat F.assign (10, true) :=
    use_clause (p148 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n10 h),
        fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (40, false) :=
    use_clause (p1451 F)
      ⟨fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (18, false) :=
    use_clause (p2869 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h6 : LitSat F.assign (29, true) :=
    use_clause (p19 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (7, true) :=
    use_clause (p25 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h8 : LitSat F.assign (17, false) :=
    use_clause (p1463 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h9 : LitSat F.assign (6, false) :=
    use_clause (p1284 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c2871 : CNF.Clause Nat := [(29, false), (31, false), (98, true), (99, true), (86, false), (87, false), (38, false), (62, true), (22, false), (51, false)]
theorem p2871 (F : Frame G 4) : c2871.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (31, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (11, false) :=
    use_clause (p1457 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (33, false) :=
    use_clause (p1363 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p155 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2872 : CNF.Clause Nat := [(98, true), (99, true), (86, false), (87, false), (38, false), (62, true), (88, false), (22, false), (51, false), (39, true)]
theorem p2872 (F : Frame G 4) : c2872.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (21, false) :=
    use_clause (p2868 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h3 : LitSat F.assign (10, true) :=
    use_clause (p148 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (9, false) :=
    use_clause (p2870 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h5 : LitSat F.assign (31, true) :=
    use_clause (p145 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h6 : LitSat F.assign (40, false) :=
    use_clause (p1433 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (29, false) :=
    use_clause (p2871 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h8 : LitSat F.assign (18, true) :=
    use_clause (p19 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (7, true) :=
    use_clause (p22 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h10 : LitSat F.assign (6, false) :=
    use_clause (p1593 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h11 : LitSat F.assign (17, false) :=
    use_clause (p1383 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  exact use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c2873 : CNF.Clause Nat := [(40, false), (33, false), (98, false), (86, false), (62, true), (88, false), (30, false), (51, false), (39, true)]
theorem p2873 (F : Frame G 4) : c2873.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (33, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (6, false) :=
    use_clause (p1579 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (17, false) :=
    use_clause (p1528 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c2874 : CNF.Clause Nat := [(6, false), (40, true), (33, false), (98, false), (86, false), (38, false), (62, true), (88, false), (22, false), (51, false), (39, true)]
theorem p2874 (F : Frame G 4) : c2874.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (33, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n10 h),
        fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (26, false) :=
    use_clause (p1506 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h2 : LitSat F.assign (15, false) :=
    use_clause (p2703 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c2875 : CNF.Clause Nat := [(99, true), (86, false), (87, false), (38, false), (88, false), (30, false), (22, false), (51, false), (39, true)]
theorem p2875 (F : Frame G 4) : c2875.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (62, false) :=
    use_clause (p2865 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p2872 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h4 : LitSat F.assign (11, false) :=
    use_clause (p2118 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h5 : LitSat F.assign (33, true) :=
    use_clause (p155 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (40, false) :=
    use_clause (p2873 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h7 : LitSat F.assign (6, false) :=
    use_clause (p2874 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h8 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (7, false) :=
    use_clause (p1601 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h10 : LitSat F.assign (18, true) :=
    use_clause (p25 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h11 : LitSat F.assign (26, false) :=
    use_clause (p1685 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h12 : LitSat F.assign (15, false) :=
    use_clause (p1315 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c2876 : CNF.Clause Nat := [(86, false), (87, false), (38, false), (88, false), (30, false), (22, false), (51, false), (39, true)]
theorem p2876 (F : Frame G 4) : c2876.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (62, false) :=
    use_clause (p2865 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p2875 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (6, false) :=
    use_clause (p1645 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (18, false) :=
    use_clause (p1741 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (40, false) :=
    use_clause (p1891 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h7 : LitSat F.assign (7, false) :=
    use_clause (p1839 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p25 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2877 : CNF.Clause Nat := [(7, false), (17, false), (99, false), (86, true), (87, false), (38, false), (50, false), (88, false), (30, false), (51, false)]
theorem p2877 (F : Frame G 4) : c2877.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (98, false) :=
    use_clause (p1601 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p2540 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c2878 : CNF.Clause Nat := [(99, false), (40, true), (86, true), (87, false), (38, false), (62, true), (88, false), (30, false), (51, false), (39, true)]
theorem p2878 (F : Frame G 4) : c2878.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (6, false) :=
    use_clause (p1645 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (9, false) :=
    use_clause (p1646 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (7, false) :=
    use_clause (p2877 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h6 : LitSat F.assign (18, true) :=
    use_clause (p25 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (29, true) :=
    use_clause (p22 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (31, false) :=
    use_clause (p1957 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (11, false) :=
    use_clause (p1638 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (98, true) :=
    use_clause (p147 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h11 : LitSat F.assign (33, true) :=
    use_clause (p233 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1825 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c2879 : CNF.Clause Nat := [(17, false), (98, false), (99, true), (40, true), (87, false), (88, false), (30, false), (22, false), (51, false), (39, true)]
theorem p2879 (F : Frame G 4) : c2879.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (62, false) :=
    use_clause (p2865 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (7, false) :=
    use_clause (p1601 F)
      ⟨fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (18, true) :=
    use_clause (p25 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (15, false) :=
    use_clause (p1315 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (26, false) :=
    use_clause (p1685 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c2880 : CNF.Clause Nat := [(40, true), (87, false), (38, false), (88, false), (30, false), (22, false), (51, false), (39, true)]
theorem p2880 (F : Frame G 4) : c2880.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (86, false) :=
    use_clause (p2876 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (62, false) :=
    use_clause (p2865 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p2878 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (17, false) :=
    use_clause (p2879 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h7 : LitSat F.assign (18, false) :=
    use_clause (p1529 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (29, true) :=
    use_clause (p19 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (7, true) :=
    use_clause (p25 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p1614 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c2881 : CNF.Clause Nat := [(99, true), (40, false), (86, true), (87, false), (50, false), (88, false), (22, false), (51, false)]
theorem p2881 (F : Frame G 4) : c2881.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (9, false) :=
    use_clause (p1451 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h3 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h4 : LitSat F.assign (10, false) :=
    use_clause (p1679 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (21, false) :=
    use_clause (p1474 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p206 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2882 : CNF.Clause Nat := [(87, false), (38, false), (88, false), (30, false), (22, false), (51, false), (39, true)]
theorem p2882 (F : Frame G 4) : c2882.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (62, false) :=
    use_clause (p2865 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p2876 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (40, true) :=
    use_clause (p2880 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, true) :=
    use_clause (p2881 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (6, false) :=
    use_clause (p1645 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, false) :=
    use_clause (p1528 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (31, false) :=
    use_clause (p2174 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p2527 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c2883 : CNF.Clause Nat := [(40, false), (38, false), (88, false), (30, false), (22, false), (51, false), (39, true)]
theorem p2883 (F : Frame G 4) : c2883.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, false) :=
    use_clause (p2882 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p266 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (62, false) :=
    use_clause (p2865 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (17, false) :=
    use_clause (p1528 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (7, false) :=
    use_clause (p1690 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h7 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h8 : LitSat F.assign (18, false) :=
    use_clause (p1529 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (29, false) :=
    use_clause (p1990 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p27 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c2884 : CNF.Clause Nat := [(6, false), (40, true), (98, false), (38, false), (50, false), (62, true), (88, false), (30, false), (22, false), (51, false)]
theorem p2884 (F : Frame G 4) : c2884.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (18, false) :=
    use_clause (p1529 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (29, true) :=
    use_clause (p19 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (7, true) :=
    use_clause (p25 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p1614 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c2885 : CNF.Clause Nat := [(38, false), (88, false), (30, false), (22, false), (51, false), (39, true)]
theorem p2885 (F : Frame G 4) : c2885.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (62, false) :=
    use_clause (p2865 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, false) :=
    use_clause (p2882 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p266 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (40, false) :=
    use_clause (p2883 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (6, false) :=
    use_clause (p2884 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h8 : LitSat F.assign (7, false) :=
    use_clause (p1601 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (18, true) :=
    use_clause (p25 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h10 : LitSat F.assign (29, true) :=
    use_clause (p22 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h11 : LitSat F.assign (26, false) :=
    use_clause (p1338 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h12 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h13 : LitSat F.assign (99, false) :=
    use_clause (p1626 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p1315 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
def c2886 : CNF.Clause Nat := [(7, true), (98, false), (88, false), (30, false), (22, false), (51, false), (39, true)]
theorem p2886 (F : Frame G 4) : c2886.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (7, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (62, false) :=
    use_clause (p2865 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, false) :=
    use_clause (p2885 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (40, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (17, false) :=
    use_clause (p1528 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h7 : LitSat F.assign (18, false) :=
    use_clause (p1529 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (10, false) :=
    use_clause (p1679 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (15, true) :=
    use_clause (p60 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h10 : LitSat F.assign (26, true) :=
    use_clause (p53 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h11 : LitSat F.assign (31, false) :=
    use_clause (p660 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h12 : LitSat F.assign (9, false) :=
    use_clause (p1604 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h13 : LitSat F.assign (86, false) :=
    use_clause (p1506 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h14 : LitSat F.assign (99, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        True.intro⟩
  have h15 : LitSat F.assign (87, true) :=
    use_clause (p210 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1890 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h14 h),
        True.intro⟩
def c2887 : CNF.Clause Nat := [(98, false), (88, false), (30, false), (22, false), (51, false), (39, true)]
theorem p2887 (F : Frame G 4) : c2887.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, false) :=
    use_clause (p2885 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (40, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (62, false) :=
    use_clause (p2865 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (17, false) :=
    use_clause (p1528 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h6 : LitSat F.assign (10, false) :=
    use_clause (p1679 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h7 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h8 : LitSat F.assign (18, false) :=
    use_clause (p1529 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (7, true) :=
    use_clause (p2886 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h10 : LitSat F.assign (26, false) :=
    use_clause (p1608 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h11 : LitSat F.assign (29, true) :=
    use_clause (p49 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h12 : LitSat F.assign (15, true) :=
    use_clause (p10 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h13 : LitSat F.assign (86, false) :=
    use_clause (p1909 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h14 : LitSat F.assign (9, false) :=
    use_clause (p2108 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h15 : LitSat F.assign (31, false) :=
    use_clause (p660 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h16 : LitSat F.assign (87, true) :=
    use_clause (p210 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h17 : LitSat F.assign (99, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p1770 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c2888 : CNF.Clause Nat := [(99, true), (9, true), (98, true), (40, false), (50, false), (88, false), (51, false)]
theorem p2888 (F : Frame G 4) : c2888.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (9, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, true) :=
    use_clause (p267 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h3 : LitSat F.assign (31, true) :=
    use_clause (p145 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h4 : LitSat F.assign (21, false) :=
    use_clause (p1677 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (10, false) :=
    use_clause (p1448 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p148 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2889 : CNF.Clause Nat := [(88, false), (30, false), (39, true), (51, false), (22, false)]
theorem p2889 (F : Frame G 4) : c2889.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (62, false) :=
    use_clause (p2865 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, false) :=
    use_clause (p2885 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (40, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p2887 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (9, false) :=
    use_clause (p1451 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (99, true) :=
    use_clause (p2888 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (6, false) :=
    use_clause (p1770 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h10 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h11 : LitSat F.assign (31, false) :=
    use_clause (p2174 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  exact use_clause (p2527 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
def c2890 : CNF.Clause Nat := [(98, true), (40, false), (62, true), (88, true), (51, false), (39, true)]
theorem p2890 (F : Frame G 4) : c2890.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, true) :=
    use_clause (p263 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (17, false) :=
    use_clause (p1891 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h5 : LitSat F.assign (6, false) :=
    use_clause (p1760 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c2891 : CNF.Clause Nat := [(87, false), (10, true), (17, false), (98, false), (40, false), (50, false), (88, true), (51, false)]
theorem p2891 (F : Frame G 4) : c2891.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (10, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (21, false) :=
    use_clause (p1698 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (9, false) :=
    use_clause (p1702 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p1891 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h5 : LitSat F.assign (31, true) :=
    use_clause (p211 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (19, true) :=
    use_clause (p175 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2173 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c2892 : CNF.Clause Nat := [(6, true), (38, true), (40, false), (62, true), (30, false), (22, false), (51, false), (39, true)]
theorem p2892 (F : Frame G 4) : c2892.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (6, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, false) :=
    use_clause (p2889 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p2890 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (10, false) :=
    use_clause (p1722 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (87, false) :=
    use_clause (p2891 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h8 : LitSat F.assign (86, true) :=
    use_clause (p261 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (21, true) :=
    use_clause (p149 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (7, false) :=
    use_clause (p1839 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (33, false) :=
    use_clause (p1920 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        True.intro⟩
  have h12 : LitSat F.assign (11, true) :=
    use_clause (p156 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (26, false) :=
    use_clause (p1856 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h14 : LitSat F.assign (18, true) :=
    use_clause (p53 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h15 : LitSat F.assign (29, true) :=
    use_clause (p51 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h16 : LitSat F.assign (5, false) :=
    use_clause (p1869 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h17 : LitSat F.assign (27, false) :=
    use_clause (p1857 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p85 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c2893 : CNF.Clause Nat := [(38, true), (40, false), (62, true), (30, false), (22, false), (51, false), (39, true)]
theorem p2893 (F : Frame G 4) : c2893.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, false) :=
    use_clause (p2889 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p2890 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (6, true) :=
    use_clause (p2892 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (33, false) :=
    use_clause (p1530 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h7 : LitSat F.assign (87, false) :=
    use_clause (p1890 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (11, true) :=
    use_clause (p156 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (86, true) :=
    use_clause (p261 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h10 : LitSat F.assign (10, false) :=
    use_clause (p1289 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (21, true) :=
    use_clause (p149 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (18, false) :=
    use_clause (p1838 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h13 : LitSat F.assign (26, false) :=
    use_clause (p1856 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h14 : LitSat F.assign (29, true) :=
    use_clause (p49 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h15 : LitSat F.assign (15, true) :=
    use_clause (p10 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  exact use_clause (p607 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c2894 : CNF.Clause Nat := [(6, false), (40, false), (62, true), (30, false), (22, false), (51, false), (39, true)]
theorem p2894 (F : Frame G 4) : c2894.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p2893 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, false) :=
    use_clause (p2889 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p2890 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (33, false) :=
    use_clause (p1530 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (87, false) :=
    use_clause (p1890 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (11, true) :=
    use_clause (p156 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (86, true) :=
    use_clause (p261 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h10 : LitSat F.assign (10, false) :=
    use_clause (p1289 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (21, true) :=
    use_clause (p149 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (18, false) :=
    use_clause (p1846 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h13 : LitSat F.assign (29, false) :=
    use_clause (p1782 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h14 : LitSat F.assign (7, false) :=
    use_clause (p1858 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p27 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c2895 : CNF.Clause Nat := [(40, false), (62, true), (30, false), (22, false), (51, false), (39, true)]
theorem p2895 (F : Frame G 4) : c2895.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, false) :=
    use_clause (p2889 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p2890 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (38, true) :=
    use_clause (p2893 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (6, false) :=
    use_clause (p2894 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h8 : LitSat F.assign (10, false) :=
    use_clause (p1722 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h9 : LitSat F.assign (87, false) :=
    use_clause (p2891 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h10 : LitSat F.assign (21, true) :=
    use_clause (p149 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (86, true) :=
    use_clause (p261 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h12 : LitSat F.assign (18, false) :=
    use_clause (p1846 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h13 : LitSat F.assign (29, false) :=
    use_clause (p1782 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h14 : LitSat F.assign (7, false) :=
    use_clause (p1839 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p27 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c2896 : CNF.Clause Nat := [(87, true), (17, false), (98, false), (38, false), (40, true), (50, false), (62, true), (88, true), (30, false), (22, false), (51, false)]
theorem p2896 (F : Frame G 4) : c2896.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, true) :=
    use_clause (p261 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (7, false) :=
    use_clause (p1839 F)
      ⟨fun h => h,
        fun h => False.elim (n10 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h4 : LitSat F.assign (18, true) :=
    use_clause (p25 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (29, true) :=
    use_clause (p22 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (10, false) :=
    use_clause (p1834 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h7 : LitSat F.assign (21, false) :=
    use_clause (p1782 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n9 h),
        True.intro⟩
  exact use_clause (p149 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2897 : CNF.Clause Nat := [(17, false), (98, false), (62, true), (30, false), (22, false), (51, false), (39, true)]
theorem p2897 (F : Frame G 4) : c2897.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (40, false) :=
    use_clause (p2895 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, false) :=
    use_clause (p2889 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p2896 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (11, false) :=
    use_clause (p2118 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (7, false) :=
    use_clause (p2298 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h9 : LitSat F.assign (33, true) :=
    use_clause (p156 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (18, true) :=
    use_clause (p25 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h11 : LitSat F.assign (29, true) :=
    use_clause (p22 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p1825 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c2898 : CNF.Clause Nat := [(87, false), (6, false), (98, false), (40, true), (62, true), (99, false), (22, false), (51, false), (39, true)]
theorem p2898 (F : Frame G 4) : c2898.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (26, false) :=
    use_clause (p1806 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (18, false) :=
    use_clause (p1752 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (29, false) :=
    use_clause (p1728 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p19 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c2899 : CNF.Clause Nat := [(18, true), (87, true), (6, false), (40, true), (62, true), (88, true), (30, false), (39, true)]
theorem p2899 (F : Frame G 4) : c2899.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (29, true) :=
    use_clause (p19 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (7, true) :=
    use_clause (p25 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (33, false) :=
    use_clause (p1362 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (11, false) :=
    use_clause (p1283 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p156 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2900 : CNF.Clause Nat := [(98, false), (62, true), (30, false), (22, false), (51, false), (39, true)]
theorem p2900 (F : Frame G 4) : c2900.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (40, false) :=
    use_clause (p2895 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, false) :=
    use_clause (p2889 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (17, false) :=
    use_clause (p2897 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h7 : LitSat F.assign (87, false) :=
    use_clause (p2898 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (86, true) :=
    use_clause (p261 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h9 : LitSat F.assign (18, true) :=
    use_clause (p2899 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h10 : LitSat F.assign (21, false) :=
    use_clause (p1838 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h11 : LitSat F.assign (10, true) :=
    use_clause (p149 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (7, false) :=
    use_clause (p1282 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h13 : LitSat F.assign (11, false) :=
    use_clause (p1289 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (29, true) :=
    use_clause (p22 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h15 : LitSat F.assign (33, true) :=
    use_clause (p156 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1362 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2901 : CNF.Clause Nat := [(62, true), (30, false), (22, false), (51, false), (39, true)]
theorem p2901 (F : Frame G 4) : c2901.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, false) :=
    use_clause (p2889 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h4 : LitSat F.assign (40, false) :=
    use_clause (p2895 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, false) :=
    use_clause (p2900 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (86, true) :=
    use_clause (p263 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (18, false) :=
    use_clause (p1741 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h10 : LitSat F.assign (29, true) :=
    use_clause (p19 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h11 : LitSat F.assign (7, true) :=
    use_clause (p25 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h12 : LitSat F.assign (11, false) :=
    use_clause (p1457 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h13 : LitSat F.assign (17, false) :=
    use_clause (p1839 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h14 : LitSat F.assign (33, true) :=
    use_clause (p156 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h15 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h16 : LitSat F.assign (26, false) :=
    use_clause (p1339 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h17 : LitSat F.assign (15, false) :=
    use_clause (p1678 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c2902 : CNF.Clause Nat := [(98, true), (40, true), (30, false), (22, false), (51, false), (39, true)]
theorem p2902 (F : Frame G 4) : c2902.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, true) :=
    use_clause (p2901 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, false) :=
    use_clause (p2889 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, true) :=
    use_clause (p263 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (9, false) :=
    use_clause (p2034 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (7, false) :=
    use_clause (p1738 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h9 : LitSat F.assign (11, false) :=
    use_clause (p1480 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h10 : LitSat F.assign (31, true) :=
    use_clause (p222 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (33, true) :=
    use_clause (p156 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (17, false) :=
    use_clause (p1796 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h13 : LitSat F.assign (50, false) :=
    use_clause (p1765 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h14 : LitSat F.assign (18, true) :=
    use_clause (p116 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h15 : LitSat F.assign (6, true) :=
    use_clause (p17 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
  exact use_clause (p2057 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
def c2903 : CNF.Clause Nat := [(87, false), (6, false), (40, true), (30, false), (22, false), (51, false), (39, true)]
theorem p2903 (F : Frame G 4) : c2903.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, false) :=
    use_clause (p2889 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p2902 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (62, true) :=
    use_clause (p2901 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (15, false) :=
    use_clause (p1794 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h6 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (50, false) :=
    use_clause (p1806 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (27, false) :=
    use_clause (p1798 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h10 : LitSat F.assign (5, false) :=
    use_clause (p813 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p33 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
def c2904 : CNF.Clause Nat := [(6, false), (40, true), (30, false), (22, false), (51, false), (39, true)]
theorem p2904 (F : Frame G 4) : c2904.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, true) :=
    use_clause (p2902 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (62, true) :=
    use_clause (p2901 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, false) :=
    use_clause (p2889 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (15, false) :=
    use_clause (p1794 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (18, false) :=
    use_clause (p1797 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (87, false) :=
    use_clause (p2903 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h10 : LitSat F.assign (86, true) :=
    use_clause (p261 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h11 : LitSat F.assign (33, false) :=
    use_clause (p1344 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (11, true) :=
    use_clause (p156 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (10, false) :=
    use_clause (p1289 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (21, true) :=
    use_clause (p149 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h15 : LitSat F.assign (7, false) :=
    use_clause (p1807 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h16 : LitSat F.assign (29, false) :=
    use_clause (p1782 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p29 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c2905 : CNF.Clause Nat := [(7, true), (18, true), (11, false), (26, false), (86, false), (6, true), (98, false), (40, true), (62, false), (22, false), (39, true)]
theorem p2905 (F : Frame G 4) : c2905.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (7, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (18, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (26, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (6, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n10 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (29, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p121 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n10 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (17, true) :=
    use_clause (p133 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p1425 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c2906 : CNF.Clause Nat := [(7, false), (86, false), (6, true), (38, false), (62, false), (99, false), (30, false), (22, false), (39, true)]
theorem p2906 (F : Frame G 4) : c2906.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (6, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (17, false) :=
    use_clause (p1656 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, false) :=
    use_clause (p1812 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  exact use_clause (p17 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c2907 : CNF.Clause Nat := [(26, false), (87, true), (40, true), (30, false), (22, false), (51, false), (39, true)]
theorem p2907 (F : Frame G 4) : c2907.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (26, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, false) :=
    use_clause (p2889 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (62, true) :=
    use_clause (p2901 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (6, false) :=
    use_clause (p2904 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, true) :=
    use_clause (p261 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h7 : LitSat F.assign (7, false) :=
    use_clause (p2906 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h8 : LitSat F.assign (98, true) :=
    use_clause (p2902 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h9 : LitSat F.assign (33, false) :=
    use_clause (p1344 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (11, true) :=
    use_clause (p156 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (18, true) :=
    use_clause (p2905 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h12 : LitSat F.assign (50, false) :=
    use_clause (p1815 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h13 : LitSat F.assign (17, true) :=
    use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
  have h14 : LitSat F.assign (21, false) :=
    use_clause (p1833 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h15 : LitSat F.assign (10, false) :=
    use_clause (p1834 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p149 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2908 : CNF.Clause Nat := [(50, true), (87, true), (40, true), (30, false), (22, false), (51, false), (39, true)]
theorem p2908 (F : Frame G 4) : c2908.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (26, false) :=
    use_clause (p2907 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, false) :=
    use_clause (p2889 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, true) :=
    use_clause (p261 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (6, false) :=
    use_clause (p2904 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p2902 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (62, true) :=
    use_clause (p2901 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h8 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (17, true) :=
    use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h10 : LitSat F.assign (27, false) :=
    use_clause (p1661 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (5, false) :=
    use_clause (p1658 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p31 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        True.intro⟩
def c2909 : CNF.Clause Nat := [(18, false), (50, false), (86, false), (98, false), (38, false), (62, false), (88, true), (30, false), (22, false)]
theorem p2909 (F : Frame G 4) : c2909.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (11, false) :=
    use_clause (p1815 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (33, false) :=
    use_clause (p1836 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p156 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2910 : CNF.Clause Nat := [(87, true), (40, true), (30, false), (22, false), (51, false), (39, true)]
theorem p2910 (F : Frame G 4) : c2910.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (6, false) :=
    use_clause (p2904 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p2902 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h4 : LitSat F.assign (62, true) :=
    use_clause (p2901 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, false) :=
    use_clause (p2889 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (86, true) :=
    use_clause (p261 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (7, false) :=
    use_clause (p2906 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (50, true) :=
    use_clause (p2908 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h10 : LitSat F.assign (18, false) :=
    use_clause (p2909 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h11 : LitSat F.assign (29, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h12 : LitSat F.assign (17, true) :=
    use_clause (p133 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h13 : LitSat F.assign (10, false) :=
    use_clause (p1814 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h14 : LitSat F.assign (21, false) :=
    use_clause (p1782 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p149 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2911 : CNF.Clause Nat := [(40, true), (30, false), (22, false), (51, false), (39, true)]
theorem p2911 (F : Frame G 4) : c2911.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (62, true) :=
    use_clause (p2901 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, false) :=
    use_clause (p2889 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p2902 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (6, false) :=
    use_clause (p2904 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (87, true) :=
    use_clause (p2910 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (9, false) :=
    use_clause (p2034 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (11, false) :=
    use_clause (p2118 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (7, false) :=
    use_clause (p1971 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h11 : LitSat F.assign (33, true) :=
    use_clause (p156 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (50, false) :=
    use_clause (p1765 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h13 : LitSat F.assign (17, true) :=
    use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
  have h14 : LitSat F.assign (29, true) :=
    use_clause (p119 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h15 : LitSat F.assign (31, false) :=
    use_clause (p1796 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h16 : LitSat F.assign (86, false) :=
    use_clause (p1415 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p232 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2912 : CNF.Clause Nat := [(87, false), (98, false), (40, false), (62, false), (88, true), (30, false), (51, false), (39, true)]
theorem p2912 (F : Frame G 4) : c2912.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (19, false) :=
    use_clause (p1795 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, false) :=
    use_clause (p1802 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (6, false) :=
    use_clause (p1890 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h5 : LitSat F.assign (5, false) :=
    use_clause (p2121 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, false) :=
    use_clause (p2343 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h7 : LitSat F.assign (17, true) :=
    use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h8 : LitSat F.assign (10, false) :=
    use_clause (p1722 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (21, true) :=
    use_clause (p175 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (38, false) :=
    use_clause (p1972 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h11 : LitSat F.assign (27, false) :=
    use_clause (p1755 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p14 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c2913 : CNF.Clause Nat := [(17, false), (38, true), (86, false), (50, true), (98, false), (62, false), (99, false), (30, false), (22, false), (51, false)]
theorem p2913 (F : Frame G 4) : c2913.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (27, false) :=
    use_clause (p1661 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h1 : LitSat F.assign (5, false) :=
    use_clause (p1658 F)
      ⟨fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p14 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c2914 : CNF.Clause Nat := [(38, true), (98, false), (30, false), (22, false), (51, false), (39, true)]
theorem p2914 (F : Frame G 4) : c2914.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, false) :=
    use_clause (p2889 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, true) :=
    use_clause (p2901 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (40, true) :=
    use_clause (p2911 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, false) :=
    use_clause (p2912 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (86, true) :=
    use_clause (p261 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (50, false) :=
    use_clause (p1802 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (17, false) :=
    use_clause (p2913 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (6, true) :=
    use_clause (p17 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h10 : LitSat F.assign (15, false) :=
    use_clause (p1794 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h11 : LitSat F.assign (26, true) :=
    use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h12 : LitSat F.assign (33, false) :=
    use_clause (p1344 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (27, false) :=
    use_clause (p1332 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h14 : LitSat F.assign (11, true) :=
    use_clause (p156 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h15 : LitSat F.assign (5, true) :=
    use_clause (p14 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  exact use_clause (p1270 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c2915 : CNF.Clause Nat := [(98, false), (30, false), (22, false), (51, false), (39, true)]
theorem p2915 (F : Frame G 4) : c2915.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (40, true) :=
    use_clause (p2911 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, true) :=
    use_clause (p2901 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, false) :=
    use_clause (p2889 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, false) :=
    use_clause (p2912 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, true) :=
    use_clause (p261 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (38, true) :=
    use_clause (p2914 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (21, false) :=
    use_clause (p1659 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (10, false) :=
    use_clause (p1652 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p149 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2916 : CNF.Clause Nat := [(30, false), (22, false), (39, true), (51, false)]
theorem p2916 (F : Frame G 4) : c2916.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, false) :=
    use_clause (p2889 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (62, true) :=
    use_clause (p2901 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (40, true) :=
    use_clause (p2911 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p2915 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (86, true) :=
    use_clause (p263 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (50, true) :=
    use_clause (p2343 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h9 : LitSat F.assign (33, false) :=
    use_clause (p1723 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        True.intro⟩
  have h10 : LitSat F.assign (11, false) :=
    use_clause (p1597 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  exact use_clause (p156 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2917 : CNF.Clause Nat := [(40, false), (88, true), (86, false), (87, false), (62, false), (22, false), (51, false), (39, true)]
theorem p2917 (F : Frame G 4) : c2917.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p2343 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (33, false) :=
    use_clause (p1723 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (11, false) :=
    use_clause (p1597 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p156 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2918 : CNF.Clause Nat := [(88, true), (86, false), (98, true), (62, false), (22, false), (51, false), (39, true)]
theorem p2918 (F : Frame G 4) : c2918.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (30, false) :=
    use_clause (p2916 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (40, false) :=
    use_clause (p2917 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (21, false) :=
    use_clause (p1972 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (7, false) :=
    use_clause (p1738 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h8 : LitSat F.assign (11, false) :=
    use_clause (p1480 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (10, true) :=
    use_clause (p148 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (19, true) :=
    use_clause (p176 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (33, true) :=
    use_clause (p156 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (27, false) :=
    use_clause (p1737 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h13 : LitSat F.assign (6, false) :=
    use_clause (p2220 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h14 : LitSat F.assign (50, false) :=
    use_clause (p1765 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h15 : LitSat F.assign (5, false) :=
    use_clause (p1995 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h16 : LitSat F.assign (29, true) :=
    use_clause (p105 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h17 : LitSat F.assign (17, true) :=
    use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h14 h),
        True.intro⟩
  exact use_clause (p1415 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c2919 : CNF.Clause Nat := [(99, false), (88, false), (98, true), (62, false), (22, false), (51, false), (39, true)]
theorem p2919 (F : Frame G 4) : c2919.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p2860 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  exact use_clause (p2864 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c2920 : CNF.Clause Nat := [(38, false), (86, false), (98, true), (62, false), (22, false), (51, false), (39, true)]
theorem p2920 (F : Frame G 4) : c2920.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p2918 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p2919 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (9, false) :=
    use_clause (p2034 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (11, false) :=
    use_clause (p1480 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (31, true) :=
    use_clause (p145 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h7 : LitSat F.assign (33, true) :=
    use_clause (p155 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (17, false) :=
    use_clause (p1384 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (10, false) :=
    use_clause (p1490 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (21, true) :=
    use_clause (p148 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (6, false) :=
    use_clause (p1381 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h12 : LitSat F.assign (50, true) :=
    use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n6 h),
        fun h => h,
        True.intro⟩
  have h13 : LitSat F.assign (40, false) :=
    use_clause (p1723 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h14 : LitSat F.assign (7, false) :=
    use_clause (p1512 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h15 : LitSat F.assign (29, false) :=
    use_clause (p1418 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p131 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
end Cert44Steps
end Graffiti199Depleted.Catalogue.OrderEleven
