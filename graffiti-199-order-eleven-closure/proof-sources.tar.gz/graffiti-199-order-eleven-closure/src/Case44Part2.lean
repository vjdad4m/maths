import Case44Part1
namespace Graffiti199Depleted.Catalogue.OrderEleven
namespace Cert44Steps
open Std.Sat
set_option maxRecDepth 4096
set_option maxHeartbeats 0
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj]
def c2921 : CNF.Clause Nat := [(86, false), (98, true), (62, false), (22, false), (51, false), (39, true)]
theorem p2921 (F : Frame G 4) : c2921.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p2918 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p2919 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (38, false) :=
    use_clause (p2920 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (40, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (9, false) :=
    use_clause (p1451 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h7 : LitSat F.assign (50, false) :=
    use_clause (p2888 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (31, true) :=
    use_clause (p145 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h9 : LitSat F.assign (10, false) :=
    use_clause (p1482 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h10 : LitSat F.assign (21, true) :=
    use_clause (p148 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (15, false) :=
    use_clause (p1312 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (17, false) :=
    use_clause (p1324 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (26, true) :=
    use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h14 : LitSat F.assign (6, true) :=
    use_clause (p17 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h15 : LitSat F.assign (27, false) :=
    use_clause (p1333 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h16 : LitSat F.assign (5, false) :=
    use_clause (p1575 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p14 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
def c2922 : CNF.Clause Nat := [(98, true), (62, false), (39, true), (22, false), (51, false)]
theorem p2922 (F : Frame G 4) : c2922.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2921 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p263 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p2919 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c2923 : CNF.Clause Nat := [(27, false), (19, true), (99, false), (40, false), (88, false), (86, true), (62, false), (30, true), (51, false)]
theorem p2923 (F : Frame G 4) : c2923.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (27, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (19, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p144 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  have h2 : LitSat F.assign (21, false) :=
    use_clause (p1755 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (10, false) :=
    use_clause (p1701 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p180 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2924 : CNF.Clause Nat := [(99, false), (38, true), (88, false), (86, true), (98, false), (62, false), (30, true), (51, false), (39, true)]
theorem p2924 (F : Frame G 4) : c2924.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (40, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n8 h),
        fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (19, false) :=
    use_clause (p1795 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h2 : LitSat F.assign (26, false) :=
    use_clause (p1949 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p144 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h4 : LitSat F.assign (15, true) :=
    use_clause (p10 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (5, false) :=
    use_clause (p2180 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (27, false) :=
    use_clause (p2923 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h7 : LitSat F.assign (50, true) :=
    use_clause (p14 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (29, false) :=
    use_clause (p2106 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h9 : LitSat F.assign (18, false) :=
    use_clause (p1752 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h10 : LitSat F.assign (7, false) :=
    use_clause (p1897 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p55 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
def c2925 : CNF.Clause Nat := [(88, false), (86, true), (62, false), (22, false), (51, false), (39, true)]
theorem p2925 (F : Frame G 4) : c2925.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, true) :=
    use_clause (p2922 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (30, false) :=
    use_clause (p2916 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, false) :=
    use_clause (p1558 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (40, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p2924 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p264 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (5, false) :=
    use_clause (p2180 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h8 : LitSat F.assign (50, false) :=
    use_clause (p2881 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (27, true) :=
    use_clause (p14 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h10 : LitSat F.assign (17, false) :=
    use_clause (p2120 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h11 : LitSat F.assign (11, false) :=
    use_clause (p1513 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h12 : LitSat F.assign (6, true) :=
    use_clause (p17 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h13 : LitSat F.assign (19, true) :=
    use_clause (p202 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1574 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n0 h),
        True.intro⟩
def c2926 : CNF.Clause Nat := [(86, true), (62, false), (22, false), (51, false), (39, true)]
theorem p2926 (F : Frame G 4) : c2926.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, true) :=
    use_clause (p2922 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (30, false) :=
    use_clause (p2916 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, false) :=
    use_clause (p2925 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (19, true) :=
    use_clause (p143 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p1795 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c2927 : CNF.Clause Nat := [(88, true), (62, false), (22, false), (51, false), (39, true)]
theorem p2927 (F : Frame G 4) : c2927.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (86, true) :=
    use_clause (p2926 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p2922 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (30, false) :=
    use_clause (p2916 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (19, false) :=
    use_clause (p1795 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p142 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h7 : LitSat F.assign (40, false) :=
    use_clause (p2917 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (7, false) :=
    use_clause (p1738 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h10 : LitSat F.assign (27, false) :=
    use_clause (p1798 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h11 : LitSat F.assign (11, false) :=
    use_clause (p1480 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h12 : LitSat F.assign (33, true) :=
    use_clause (p156 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (50, false) :=
    use_clause (p1765 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h14 : LitSat F.assign (5, false) :=
    use_clause (p1995 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h15 : LitSat F.assign (18, true) :=
    use_clause (p107 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h16 : LitSat F.assign (29, true) :=
    use_clause (p105 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h17 : LitSat F.assign (6, false) :=
    use_clause (p2057 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
  have h18 : LitSat F.assign (17, false) :=
    use_clause (p1415 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
def c2928 : CNF.Clause Nat := [(87, false), (99, false), (27, true), (38, true), (88, false), (86, false), (98, false), (62, false), (51, false), (39, true)]
theorem p2928 (F : Frame G 4) : c2928.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (27, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (40, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n9 h),
        fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (17, false) :=
    use_clause (p1693 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (5, false) :=
    use_clause (p2180 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (6, false) :=
    use_clause (p1760 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p2343 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p87 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n9 h),
        True.intro⟩
def c2929 : CNF.Clause Nat := [(50, false), (87, true), (40, false), (88, false), (86, false), (98, false), (22, false), (51, false)]
theorem p2929 (F : Frame G 4) : c2929.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (21, false) :=
    use_clause (p1677 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (10, false) :=
    use_clause (p1679 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p149 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2930 : CNF.Clause Nat := [(99, false), (62, false), (22, false), (51, false), (39, true)]
theorem p2930 (F : Frame G 4) : c2930.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (86, true) :=
    use_clause (p2926 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p2922 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p2927 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (38, false) :=
    use_clause (p1558 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (40, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (27, false) :=
    use_clause (p1764 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h7 : LitSat F.assign (17, false) :=
    use_clause (p1693 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h8 : LitSat F.assign (30, false) :=
    use_clause (p2916 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (19, false) :=
    use_clause (p1795 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h10 : LitSat F.assign (26, false) :=
    use_clause (p1949 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h11 : LitSat F.assign (15, true) :=
    use_clause (p10 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h12 : LitSat F.assign (87, false) :=
    use_clause (p2928 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h13 : LitSat F.assign (50, false) :=
    use_clause (p2929 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h14 : LitSat F.assign (5, true) :=
    use_clause (p14 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
  have h15 : LitSat F.assign (6, true) :=
    use_clause (p17 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
  have h16 : LitSat F.assign (11, false) :=
    use_clause (p1537 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h17 : LitSat F.assign (33, false) :=
    use_clause (p2149 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p195 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2931 : CNF.Clause Nat := [(87, true), (62, false), (22, false), (51, false), (39, true)]
theorem p2931 (F : Frame G 4) : c2931.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2930 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, true) :=
    use_clause (p2926 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p2922 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, true) :=
    use_clause (p2927 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (38, false) :=
    use_clause (p1558 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (40, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (27, false) :=
    use_clause (p1764 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h8 : LitSat F.assign (17, false) :=
    use_clause (p1693 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h9 : LitSat F.assign (30, false) :=
    use_clause (p2916 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (50, false) :=
    use_clause (p2929 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h11 : LitSat F.assign (5, true) :=
    use_clause (p14 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  have h12 : LitSat F.assign (6, true) :=
    use_clause (p17 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  have h13 : LitSat F.assign (19, false) :=
    use_clause (p1577 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h14 : LitSat F.assign (33, false) :=
    use_clause (p1579 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p190 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2932 : CNF.Clause Nat := [(62, false), (22, false), (39, true), (51, false)]
theorem p2932 (F : Frame G 4) : c2932.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, true) :=
    use_clause (p2922 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, true) :=
    use_clause (p2926 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p2927 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (38, false) :=
    use_clause (p1558 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h5 : LitSat F.assign (40, true) :=
    use_clause (p134 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (27, false) :=
    use_clause (p1764 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, false) :=
    use_clause (p2930 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (87, true) :=
    use_clause (p2931 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (5, false) :=
    use_clause (p2180 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h10 : LitSat F.assign (50, true) :=
    use_clause (p14 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        True.intro⟩
  have h11 : LitSat F.assign (33, false) :=
    use_clause (p1723 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        True.intro⟩
  have h12 : LitSat F.assign (11, false) :=
    use_clause (p1597 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  exact use_clause (p155 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2933 : CNF.Clause Nat := [(40, false), (87, false), (99, true), (88, false), (86, false), (98, false), (22, false), (51, false), (39, true)]
theorem p2933 (F : Frame G 4) : c2933.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (62, false) :=
    use_clause (p2932 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (17, false) :=
    use_clause (p1693 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (11, false) :=
    use_clause (p1597 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h5 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h6 : LitSat F.assign (33, true) :=
    use_clause (p155 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1631 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        True.intro⟩
def c2934 : CNF.Clause Nat := [(33, false), (87, false), (99, true), (88, false), (86, false), (98, false), (22, false), (51, false), (39, true)]
theorem p2934 (F : Frame G 4) : c2934.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (33, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (40, false) :=
    use_clause (p2933 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, false) :=
    use_clause (p2932 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (6, false) :=
    use_clause (p2874 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h6 : LitSat F.assign (7, false) :=
    use_clause (p1606 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h7 : LitSat F.assign (18, true) :=
    use_clause (p25 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h8 : LitSat F.assign (26, false) :=
    use_clause (p1685 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (15, false) :=
    use_clause (p1315 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2935 : CNF.Clause Nat := [(87, false), (99, true), (88, false), (86, false), (98, false), (22, false), (51, false), (39, true)]
theorem p2935 (F : Frame G 4) : c2935.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (62, false) :=
    use_clause (p2932 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (40, false) :=
    use_clause (p2933 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (33, false) :=
    use_clause (p2934 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (11, true) :=
    use_clause (p155 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (29, false) :=
    use_clause (p1457 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h8 : LitSat F.assign (18, true) :=
    use_clause (p19 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (7, true) :=
    use_clause (p22 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p1610 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c2936 : CNF.Clause Nat := [(11, false), (87, true), (88, false), (86, false), (98, false), (22, false), (51, false), (39, true)]
theorem p2936 (F : Frame G 4) : c2936.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (62, false) :=
    use_clause (p2932 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (40, false) :=
    use_clause (p2929 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (17, false) :=
    use_clause (p1602 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h7 : LitSat F.assign (26, false) :=
    use_clause (p1506 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h8 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h9 : LitSat F.assign (10, false) :=
    use_clause (p1462 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h10 : LitSat F.assign (21, false) :=
    use_clause (p1715 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  exact use_clause (p149 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2937 : CNF.Clause Nat := [(99, true), (88, false), (86, false), (98, false), (22, false), (51, false), (39, true)]
theorem p2937 (F : Frame G 4) : c2937.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (62, false) :=
    use_clause (p2932 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (30, false) :=
    use_clause (p2916 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, false) :=
    use_clause (p2935 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (40, false) :=
    use_clause (p2929 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (11, false) :=
    use_clause (p2936 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h8 : LitSat F.assign (19, true) :=
    use_clause (p194 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (33, true) :=
    use_clause (p155 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (7, false) :=
    use_clause (p1600 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h11 : LitSat F.assign (6, false) :=
    use_clause (p2874 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h12 : LitSat F.assign (18, true) :=
    use_clause (p25 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h13 : LitSat F.assign (29, true) :=
    use_clause (p22 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h14 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h15 : LitSat F.assign (15, false) :=
    use_clause (p1315 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h16 : LitSat F.assign (26, false) :=
    use_clause (p1341 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
def c2938 : CNF.Clause Nat := [(29, true), (38, false), (40, true), (88, false), (86, false), (98, false), (50, false), (62, true), (22, false)]
theorem p2938 (F : Frame G 4) : c2938.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (29, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (18, true) :=
    use_clause (p19 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (7, true) :=
    use_clause (p22 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p1610 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c2939 : CNF.Clause Nat := [(87, true), (88, false), (86, false), (98, false), (22, false), (51, false), (39, true)]
theorem p2939 (F : Frame G 4) : c2939.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, false) :=
    use_clause (p2932 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (40, false) :=
    use_clause (p2929 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (29, true) :=
    use_clause (p2938 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (7, false) :=
    use_clause (p1555 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h8 : LitSat F.assign (21, false) :=
    use_clause (p1782 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (18, true) :=
    use_clause (p25 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h10 : LitSat F.assign (10, true) :=
    use_clause (p149 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (15, false) :=
    use_clause (p1671 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h12 : LitSat F.assign (17, false) :=
    use_clause (p2134 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h13 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h14 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p1506 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c2940 : CNF.Clause Nat := [(88, false), (86, false), (98, false), (22, false), (51, false), (39, true)]
theorem p2940 (F : Frame G 4) : c2940.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (62, false) :=
    use_clause (p2932 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p2937 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p2939 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (26, false) :=
    use_clause (p1806 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (40, true) :=
    use_clause (p2250 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h6 : LitSat F.assign (17, false) :=
    use_clause (p1693 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h7 : LitSat F.assign (6, false) :=
    use_clause (p1760 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2941 : CNF.Clause Nat := [(40, false), (87, false), (99, false), (86, false), (62, true), (51, false), (39, true)]
theorem p2941 (F : Frame G 4) : c2941.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (17, false) :=
    use_clause (p1891 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h1 : LitSat F.assign (6, false) :=
    use_clause (p1760 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c2942 : CNF.Clause Nat := [(87, false), (86, false), (98, false), (22, false), (51, false), (39, true)]
theorem p2942 (F : Frame G 4) : c2942.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, false) :=
    use_clause (p2940 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (62, false) :=
    use_clause (p2932 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (40, false) :=
    use_clause (p2941 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (6, false) :=
    use_clause (p2898 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (18, false) :=
    use_clause (p1741 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h10 : LitSat F.assign (29, true) :=
    use_clause (p19 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h11 : LitSat F.assign (7, true) :=
    use_clause (p25 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h12 : LitSat F.assign (11, false) :=
    use_clause (p1457 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h13 : LitSat F.assign (33, false) :=
    use_clause (p2232 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p156 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2943 : CNF.Clause Nat := [(17, false), (40, true), (86, false), (98, false), (22, false), (51, false), (39, true)]
theorem p2943 (F : Frame G 4) : c2943.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (30, false) :=
    use_clause (p2916 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, false) :=
    use_clause (p2940 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, false) :=
    use_clause (p2942 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (19, true) :=
    use_clause (p142 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (62, false) :=
    use_clause (p2932 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (29, false) :=
    use_clause (p1850 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h9 : LitSat F.assign (18, true) :=
    use_clause (p19 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h10 : LitSat F.assign (15, false) :=
    use_clause (p317 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h11 : LitSat F.assign (21, false) :=
    use_clause (p334 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h13 : LitSat F.assign (10, true) :=
    use_clause (p149 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1694 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
def c2944 : CNF.Clause Nat := [(11, false), (40, true), (86, false), (98, false), (22, false), (51, false), (39, true)]
theorem p2944 (F : Frame G 4) : c2944.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (62, false) :=
    use_clause (p2932 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (17, false) :=
    use_clause (p2943 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, false) :=
    use_clause (p2942 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (88, false) :=
    use_clause (p2940 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (7, false) :=
    use_clause (p1283 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (10, false) :=
    use_clause (p1289 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (29, true) :=
    use_clause (p22 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h10 : LitSat F.assign (21, true) :=
    use_clause (p149 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1782 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c2945 : CNF.Clause Nat := [(40, true), (86, false), (98, false), (22, false), (51, false), (39, true)]
theorem p2945 (F : Frame G 4) : c2945.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (30, false) :=
    use_clause (p2916 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, false) :=
    use_clause (p2940 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, false) :=
    use_clause (p2942 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (19, true) :=
    use_clause (p142 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (62, false) :=
    use_clause (p2932 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h8 : LitSat F.assign (17, false) :=
    use_clause (p2943 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h10 : LitSat F.assign (11, false) :=
    use_clause (p2944 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h11 : LitSat F.assign (33, true) :=
    use_clause (p156 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (18, false) :=
    use_clause (p1397 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h13 : LitSat F.assign (29, true) :=
    use_clause (p19 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h14 : LitSat F.assign (7, true) :=
    use_clause (p25 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h15 : LitSat F.assign (21, false) :=
    use_clause (p1782 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h16 : LitSat F.assign (10, false) :=
    use_clause (p1282 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p149 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2946 : CNF.Clause Nat := [(86, false), (98, false), (22, false), (51, false), (39, true)]
theorem p2946 (F : Frame G 4) : c2946.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (62, false) :=
    use_clause (p2932 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (30, false) :=
    use_clause (p2916 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, false) :=
    use_clause (p2940 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, false) :=
    use_clause (p2942 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (19, true) :=
    use_clause (p142 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (40, true) :=
    use_clause (p2945 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (10, false) :=
    use_clause (p1848 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h10 : LitSat F.assign (21, false) :=
    use_clause (p1847 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p149 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2947 : CNF.Clause Nat := [(40, false), (88, true), (98, false), (22, false), (51, false), (39, true)]
theorem p2947 (F : Frame G 4) : c2947.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (62, false) :=
    use_clause (p2932 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p2946 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (30, false) :=
    use_clause (p2916 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p141 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h7 : LitSat F.assign (26, false) :=
    use_clause (p1806 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (19, true) :=
    use_clause (p143 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (21, false) :=
    use_clause (p1698 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h10 : LitSat F.assign (7, false) :=
    use_clause (p1902 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h11 : LitSat F.assign (10, true) :=
    use_clause (p173 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (15, true) :=
    use_clause (p2321 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h13 : LitSat F.assign (18, false) :=
    use_clause (p1752 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h14 : LitSat F.assign (38, true) :=
    use_clause (p53 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h15 : LitSat F.assign (29, true) :=
    use_clause (p27 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p1620 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c2948 : CNF.Clause Nat := [(88, true), (98, false), (22, false), (51, false), (39, true)]
theorem p2948 (F : Frame G 4) : c2948.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2946 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, false) :=
    use_clause (p2932 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (30, false) :=
    use_clause (p2916 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p141 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h7 : LitSat F.assign (19, true) :=
    use_clause (p143 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h8 : LitSat F.assign (26, false) :=
    use_clause (p1806 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (40, false) :=
    use_clause (p2947 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h10 : LitSat F.assign (6, false) :=
    use_clause (p2898 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h12 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h13 : LitSat F.assign (18, false) :=
    use_clause (p1313 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h14 : LitSat F.assign (29, false) :=
    use_clause (p1850 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p19 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c2949 : CNF.Clause Nat := [(99, false), (40, true), (87, false), (98, false), (22, false), (51, false), (39, true)]
theorem p2949 (F : Frame G 4) : c2949.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (88, true) :=
    use_clause (p2948 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (62, false) :=
    use_clause (p2932 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (26, false) :=
    use_clause (p1806 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p2250 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
def c2950 : CNF.Clause Nat := [(29, true), (15, false), (40, true), (87, false), (98, false), (22, false), (51, false), (39, true)]
theorem p2950 (F : Frame G 4) : c2950.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (29, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (99, false) :=
    use_clause (p2949 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p2948 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p2946 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (62, false) :=
    use_clause (p2932 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (18, true) :=
    use_clause (p19 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (7, true) :=
    use_clause (p22 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (17, false) :=
    use_clause (p1315 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h9 : LitSat F.assign (31, false) :=
    use_clause (p2081 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h10 : LitSat F.assign (9, false) :=
    use_clause (p1281 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2951 : CNF.Clause Nat := [(18, false), (15, false), (40, true), (87, false), (98, false), (22, false), (51, false), (39, true)]
theorem p2951 (F : Frame G 4) : c2951.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (29, true) :=
    use_clause (p2950 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2949 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p2948 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p2946 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h5 : LitSat F.assign (62, false) :=
    use_clause (p2932 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (17, false) :=
    use_clause (p1315 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h8 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h9 : LitSat F.assign (31, false) :=
    use_clause (p2081 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h10 : LitSat F.assign (9, false) :=
    use_clause (p1465 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c2952 : CNF.Clause Nat := [(6, false), (11, false), (7, false), (19, false), (99, true), (40, true), (88, false), (86, true), (98, false), (62, true), (51, false), (39, true)]
theorem p2952 (F : Frame G 4) : c2952.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (19, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have n11 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n11 h),
        fun h => h,
        fun h => False.elim (n9 h),
        True.intro⟩
  have h2 : LitSat F.assign (9, false) :=
    use_clause (p1281 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n11 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (10, false) :=
    use_clause (p1286 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n11 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (21, true) :=
    use_clause (p206 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2085 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c2953 : CNF.Clause Nat := [(15, false), (19, false), (40, true), (87, false), (98, false), (22, false), (51, false), (39, true)]
theorem p2953 (F : Frame G 4) : c2953.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (19, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p2949 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p2948 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p2946 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h5 : LitSat F.assign (62, false) :=
    use_clause (p2932 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (29, true) :=
    use_clause (p2950 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h8 : LitSat F.assign (18, false) :=
    use_clause (p2951 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h9 : LitSat F.assign (7, true) :=
    use_clause (p25 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h10 : LitSat F.assign (33, false) :=
    use_clause (p1534 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h11 : LitSat F.assign (11, true) :=
    use_clause (p155 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (6, false) :=
    use_clause (p2952 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h13 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h14 : LitSat F.assign (31, false) :=
    use_clause (p1106 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h15 : LitSat F.assign (9, false) :=
    use_clause (p2080 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c2954 : CNF.Clause Nat := [(26, false), (99, true), (38, false), (40, true), (87, false), (88, false), (98, false), (50, false), (62, true), (51, false)]
theorem p2954 (F : Frame G 4) : c2954.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (26, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (11, false) :=
    use_clause (p1589 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h2 : LitSat F.assign (18, false) :=
    use_clause (p1685 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (33, true) :=
    use_clause (p155 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (29, true) :=
    use_clause (p19 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (7, true) :=
    use_clause (p25 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  exact use_clause (p1534 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n7 h),
        True.intro⟩
def c2955 : CNF.Clause Nat := [(40, true), (87, false), (98, false), (22, false), (51, false), (39, true)]
theorem p2955 (F : Frame G 4) : c2955.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p2948 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p2946 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (62, false) :=
    use_clause (p2932 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (30, false) :=
    use_clause (p2916 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, false) :=
    use_clause (p2949 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (26, false) :=
    use_clause (p2954 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h10 : LitSat F.assign (29, true) :=
    use_clause (p2950 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h11 : LitSat F.assign (18, false) :=
    use_clause (p2951 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h12 : LitSat F.assign (19, false) :=
    use_clause (p2953 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h13 : LitSat F.assign (7, true) :=
    use_clause (p25 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h14 : LitSat F.assign (33, true) :=
    use_clause (p198 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1534 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c2956 : CNF.Clause Nat := [(87, false), (98, false), (22, false), (51, false), (39, true)]
theorem p2956 (F : Frame G 4) : c2956.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p2948 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, false) :=
    use_clause (p2946 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (62, false) :=
    use_clause (p2932 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (30, false) :=
    use_clause (p2916 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (40, true) :=
    use_clause (p2955 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (19, false) :=
    use_clause (p1527 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h8 : LitSat F.assign (10, false) :=
    use_clause (p1679 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (99, true) :=
    use_clause (p2881 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (21, true) :=
    use_clause (p180 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1698 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
def c2957 : CNF.Clause Nat := [(29, true), (38, false), (40, true), (99, false), (19, false), (88, false), (98, false), (50, false), (62, true)]
theorem p2957 (F : Frame G 4) : c2957.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (29, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (19, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (18, true) :=
    use_clause (p19 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h1 : LitSat F.assign (7, true) :=
    use_clause (p22 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  exact use_clause (p1976 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c2958 : CNF.Clause Nat := [(98, false), (22, false), (51, false), (39, true)]
theorem p2958 (F : Frame G 4) : c2958.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (62, false) :=
    use_clause (p2932 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (30, false) :=
    use_clause (p2916 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p2946 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, true) :=
    use_clause (p2948 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, false) :=
    use_clause (p2956 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (19, true) :=
    use_clause (p144 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (99, true) :=
    use_clause (p264 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (40, false) :=
    use_clause (p1527 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h10 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h11 : LitSat F.assign (29, true) :=
    use_clause (p2957 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h12 : LitSat F.assign (21, false) :=
    use_clause (p1673 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h13 : LitSat F.assign (17, false) :=
    use_clause (p1850 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h14 : LitSat F.assign (10, true) :=
    use_clause (p149 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h15 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h16 : LitSat F.assign (15, false) :=
    use_clause (p1620 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h17 : LitSat F.assign (7, false) :=
    use_clause (p1282 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h18 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h19 : LitSat F.assign (18, true) :=
    use_clause (p25 F)
      ⟨fun h => False.elim (unit_incompatible h17 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p1694 F)
      ⟨fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
def c2959 : CNF.Clause Nat := [(86, true), (17, false), (99, false), (38, false), (40, true), (88, false), (98, true), (50, false), (62, true), (51, false)]
theorem p2959 (F : Frame G 4) : c2959.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (9, false) :=
    use_clause (p1646 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h3 : LitSat F.assign (7, false) :=
    use_clause (p2540 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (31, true) :=
    use_clause (p147 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (18, true) :=
    use_clause (p25 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h6 : LitSat F.assign (29, true) :=
    use_clause (p22 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  exact use_clause (p1957 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c2960 : CNF.Clause Nat := [(99, false), (40, true), (88, false), (22, false), (51, false), (39, true)]
theorem p2960 (F : Frame G 4) : c2960.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, false) :=
    use_clause (p2958 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (62, false) :=
    use_clause (p2932 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (6, false) :=
    use_clause (p1645 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (9, false) :=
    use_clause (p1646 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (86, true) :=
    use_clause (p2959 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h10 : LitSat F.assign (18, false) :=
    use_clause (p1741 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h11 : LitSat F.assign (29, true) :=
    use_clause (p19 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h12 : LitSat F.assign (7, true) :=
    use_clause (p25 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h13 : LitSat F.assign (11, false) :=
    use_clause (p1457 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h14 : LitSat F.assign (33, false) :=
    use_clause (p2232 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h15 : LitSat F.assign (31, false) :=
    use_clause (p1383 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p223 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2961 : CNF.Clause Nat := [(40, true), (88, false), (22, false), (51, false), (39, true)]
theorem p2961 (F : Frame G 4) : c2961.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, false) :=
    use_clause (p2958 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (62, false) :=
    use_clause (p2932 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p2960 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, true) :=
    use_clause (p267 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p2872 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c2962 : CNF.Clause Nat := [(88, false), (22, false), (51, false), (39, true)]
theorem p2962 (F : Frame G 4) : c2962.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, false) :=
    use_clause (p2958 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (62, false) :=
    use_clause (p2932 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (40, true) :=
    use_clause (p2961 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (9, false) :=
    use_clause (p1451 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, true) :=
    use_clause (p2888 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (21, false) :=
    use_clause (p1698 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (86, false) :=
    use_clause (p2941 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (10, true) :=
    use_clause (p148 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (31, true) :=
    use_clause (p147 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p1433 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
def c2963 : CNF.Clause Nat := [(22, false), (51, false), (39, true)]
theorem p2963 (F : Frame G 4) : c2963.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (62, false) :=
    use_clause (p2932 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, false) :=
    use_clause (p2958 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, false) :=
    use_clause (p2962 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (86, true) :=
    use_clause (p263 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (40, false) :=
    use_clause (p2890 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h10 : LitSat F.assign (18, false) :=
    use_clause (p1741 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h11 : LitSat F.assign (29, true) :=
    use_clause (p19 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h12 : LitSat F.assign (7, true) :=
    use_clause (p25 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h13 : LitSat F.assign (11, false) :=
    use_clause (p1457 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h14 : LitSat F.assign (33, true) :=
    use_clause (p156 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h15 : LitSat F.assign (26, false) :=
    use_clause (p1341 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h16 : LitSat F.assign (17, false) :=
    use_clause (p2232 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h17 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h18 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p1678 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c2964 : CNF.Clause Nat := [(29, false), (62, true), (86, false), (40, true), (87, false), (33, false), (11, false), (99, false), (39, true)]
theorem p2964 (F : Frame G 4) : c2964.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (33, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (15, false) :=
    use_clause (p1426 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h3 : LitSat F.assign (26, false) :=
    use_clause (p1341 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c2965 : CNF.Clause Nat := [(62, true), (86, false), (40, true), (87, false), (88, true), (51, false), (39, true)]
theorem p2965 (F : Frame G 4) : c2965.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (33, true) :=
    use_clause (p153 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (11, true) :=
    use_clause (p159 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, true) :=
    use_clause (p151 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h6 : LitSat F.assign (29, false) :=
    use_clause (p2964 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (18, true) :=
    use_clause (p19 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h8 : LitSat F.assign (7, true) :=
    use_clause (p22 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h9 : LitSat F.assign (6, false) :=
    use_clause (p1681 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h10 : LitSat F.assign (17, false) :=
    use_clause (p1606 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        True.intro⟩
def c2966 : CNF.Clause Nat := [(6, true), (50, true), (62, false), (86, false), (40, true), (87, false), (99, false), (39, true)]
theorem p2966 (F : Frame G 4) : c2966.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (6, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h1 : LitSat F.assign (7, false) :=
    use_clause (p1738 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (17, true) :=
    use_clause (p17 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (29, true) :=
    use_clause (p119 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p1415 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c2967 : CNF.Clause Nat := [(86, false), (40, true), (87, false), (88, true), (51, false), (39, true)]
theorem p2967 (F : Frame G 4) : c2967.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (33, true) :=
    use_clause (p153 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, true) :=
    use_clause (p151 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (62, true) :=
    use_clause (p2965 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (50, false) :=
    use_clause (p1765 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (7, false) :=
    use_clause (p1738 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (6, true) :=
    use_clause (p2966 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (29, false) :=
    use_clause (p1739 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h10 : LitSat F.assign (18, false) :=
    use_clause (p2057 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p29 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c2968 : CNF.Clause Nat := [(18, true), (7, true), (10, false), (30, false), (50, true), (62, false), (98, false), (40, true), (99, false), (39, true)]
theorem p2968 (F : Frame G 4) : c2968.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (7, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (29, true) :=
    use_clause (p29 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (17, true) :=
    use_clause (p116 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p1814 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        True.intro⟩
def c2969 : CNF.Clause Nat := [(62, false), (40, true), (87, false), (88, true), (51, false), (39, true)]
theorem p2969 (F : Frame G 4) : c2969.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2967 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p263 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h4 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (33, true) :=
    use_clause (p153 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, true) :=
    use_clause (p151 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (19, false) :=
    use_clause (p1795 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (50, false) :=
    use_clause (p1765 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h9 : LitSat F.assign (21, false) :=
    use_clause (p1972 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h10 : LitSat F.assign (30, true) :=
    use_clause (p143 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h11 : LitSat F.assign (10, true) :=
    use_clause (p175 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (7, false) :=
    use_clause (p1971 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h13 : LitSat F.assign (18, true) :=
    use_clause (p2968 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h14 : LitSat F.assign (6, false) :=
    use_clause (p1797 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h15 : LitSat F.assign (17, false) :=
    use_clause (p1834 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  exact use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
def c2970 : CNF.Clause Nat := [(18, false), (40, true), (87, false), (88, true), (51, false), (39, true)]
theorem p2970 (F : Frame G 4) : c2970.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (62, false) :=
    use_clause (p2969 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p2967 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p263 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (11, true) :=
    use_clause (p159 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, true) :=
    use_clause (p151 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (15, false) :=
    use_clause (p1752 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (26, false) :=
    use_clause (p1707 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c2971 : CNF.Clause Nat := [(40, true), (87, false), (88, true), (51, false), (39, true)]
theorem p2971 (F : Frame G 4) : c2971.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (11, true) :=
    use_clause (p159 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, true) :=
    use_clause (p151 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, false) :=
    use_clause (p2967 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (62, false) :=
    use_clause (p2969 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (18, false) :=
    use_clause (p2970 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (29, true) :=
    use_clause (p19 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (7, true) :=
    use_clause (p25 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p2543 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c2972 : CNF.Clause Nat := [(7, false), (62, true), (86, true), (18, true), (87, false), (88, true), (51, false), (39, true)]
theorem p2972 (F : Frame G 4) : c2972.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (18, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (40, true) :=
    use_clause (p2971 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (33, true) :=
    use_clause (p153 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, true) :=
    use_clause (p151 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p263 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h7 : LitSat F.assign (15, false) :=
    use_clause (p1830 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h8 : LitSat F.assign (38, false) :=
    use_clause (p1769 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (19, false) :=
    use_clause (p1902 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h10 : LitSat F.assign (29, true) :=
    use_clause (p56 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h11 : LitSat F.assign (30, true) :=
    use_clause (p143 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h12 : LitSat F.assign (6, false) :=
    use_clause (p1648 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h13 : LitSat F.assign (17, false) :=
    use_clause (p2082 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c2973 : CNF.Clause Nat := [(62, true), (86, true), (18, true), (87, false), (88, true), (51, false), (39, true)]
theorem p2973 (F : Frame G 4) : c2973.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (18, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, true) :=
    use_clause (p263 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (40, true) :=
    use_clause (p2971 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (33, true) :=
    use_clause (p153 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (11, true) :=
    use_clause (p159 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, true) :=
    use_clause (p151 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h8 : LitSat F.assign (21, false) :=
    use_clause (p1698 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h9 : LitSat F.assign (15, false) :=
    use_clause (p1830 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h10 : LitSat F.assign (7, false) :=
    use_clause (p2972 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h11 : LitSat F.assign (38, true) :=
    use_clause (p60 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h12 : LitSat F.assign (29, true) :=
    use_clause (p27 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h13 : LitSat F.assign (19, false) :=
    use_clause (p1726 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h14 : LitSat F.assign (30, true) :=
    use_clause (p143 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h15 : LitSat F.assign (10, true) :=
    use_clause (p175 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h16 : LitSat F.assign (6, false) :=
    use_clause (p1890 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h17 : LitSat F.assign (17, false) :=
    use_clause (p1722 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  exact use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        True.intro⟩
def c2974 : CNF.Clause Nat := [(86, true), (18, true), (87, false), (88, true), (51, false), (39, true)]
theorem p2974 (F : Frame G 4) : c2974.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (18, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (40, true) :=
    use_clause (p2971 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, true) :=
    use_clause (p151 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p263 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (62, true) :=
    use_clause (p2973 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (19, false) :=
    use_clause (p1795 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (30, false) :=
    use_clause (p2912 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p143 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c2975 : CNF.Clause Nat := [(86, false), (87, false), (88, true), (51, false), (39, true)]
theorem p2975 (F : Frame G 4) : c2975.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (40, true) :=
    use_clause (p2971 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (33, true) :=
    use_clause (p153 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, true) :=
    use_clause (p151 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (62, true) :=
    use_clause (p2941 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (50, true) :=
    use_clause (p2343 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p1723 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c2976 : CNF.Clause Nat := [(62, false), (87, false), (88, true), (51, false), (39, true)]
theorem p2976 (F : Frame G 4) : c2976.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (86, false) :=
    use_clause (p2975 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (98, true) :=
    use_clause (p263 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (40, true) :=
    use_clause (p2971 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, true) :=
    use_clause (p151 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (30, false) :=
    use_clause (p2912 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (19, false) :=
    use_clause (p1795 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p143 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c2977 : CNF.Clause Nat := [(87, false), (88, true), (51, false), (39, true)]
theorem p2977 (F : Frame G 4) : c2977.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (33, true) :=
    use_clause (p153 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (11, true) :=
    use_clause (p159 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, true) :=
    use_clause (p151 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (40, true) :=
    use_clause (p2971 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, false) :=
    use_clause (p2975 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, true) :=
    use_clause (p263 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (18, true) :=
    use_clause (p2974 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (62, false) :=
    use_clause (p2976 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h11 : LitSat F.assign (15, false) :=
    use_clause (p1830 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h12 : LitSat F.assign (38, false) :=
    use_clause (p1663 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h13 : LitSat F.assign (26, false) :=
    use_clause (p1684 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  exact use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c2978 : CNF.Clause Nat := [(62, true), (40, false), (88, true), (51, false), (39, true)]
theorem p2978 (F : Frame G 4) : c2978.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p151 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (33, true) :=
    use_clause (p153 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, false) :=
    use_clause (p2977 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (86, true) :=
    use_clause (p261 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (17, false) :=
    use_clause (p1920 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (98, true) :=
    use_clause (p266 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (11, true) :=
    use_clause (p159 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h10 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h11 : LitSat F.assign (10, false) :=
    use_clause (p1289 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (21, true) :=
    use_clause (p149 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (30, false) :=
    use_clause (p1901 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
  have h14 : LitSat F.assign (19, false) :=
    use_clause (p1847 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p142 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c2979 : CNF.Clause Nat := [(40, false), (88, true), (51, false), (39, true)]
theorem p2979 (F : Frame G 4) : c2979.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, false) :=
    use_clause (p2977 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, true) :=
    use_clause (p261 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, true) :=
    use_clause (p266 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (33, true) :=
    use_clause (p153 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, true) :=
    use_clause (p151 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (17, false) :=
    use_clause (p1920 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (62, true) :=
    use_clause (p2978 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (19, false) :=
    use_clause (p1795 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h10 : LitSat F.assign (30, true) :=
    use_clause (p142 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h11 : LitSat F.assign (50, false) :=
    use_clause (p1802 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h12 : LitSat F.assign (26, false) :=
    use_clause (p1344 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (6, true) :=
    use_clause (p17 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h14 : LitSat F.assign (38, false) :=
    use_clause (p1655 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h15 : LitSat F.assign (15, false) :=
    use_clause (p2149 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c2980 : CNF.Clause Nat := [(50, true), (62, false), (88, true), (51, false), (39, true)]
theorem p2980 (F : Frame G 4) : c2980.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p151 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, false) :=
    use_clause (p2977 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, true) :=
    use_clause (p266 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (19, false) :=
    use_clause (p1795 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h6 : LitSat F.assign (30, true) :=
    use_clause (p142 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (40, false) :=
    use_clause (p2979 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (33, true) :=
    use_clause (p153 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (26, false) :=
    use_clause (p1344 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h11 : LitSat F.assign (6, false) :=
    use_clause (p1794 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h12 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h13 : LitSat F.assign (86, true) :=
    use_clause (p261 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h14 : LitSat F.assign (17, true) :=
    use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h15 : LitSat F.assign (21, false) :=
    use_clause (p1833 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h16 : LitSat F.assign (10, true) :=
    use_clause (p149 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h17 : LitSat F.assign (7, false) :=
    use_clause (p1736 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h18 : LitSat F.assign (18, true) :=
    use_clause (p2968 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p1834 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c2981 : CNF.Clause Nat := [(17, false), (7, true), (15, false), (30, false), (62, false), (38, false), (40, true), (86, false), (87, true), (99, false), (51, false)]
theorem p2981 (F : Frame G 4) : c2981.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (7, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (15, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, true) :=
    use_clause (p266 F)
      ⟨fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (21, false) :=
    use_clause (p1833 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h3 : LitSat F.assign (10, true) :=
    use_clause (p149 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (29, false) :=
    use_clause (p1640 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h5 : LitSat F.assign (18, false) :=
    use_clause (p1834 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n10 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  exact use_clause (p29 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c2982 : CNF.Clause Nat := [(62, false), (88, true), (51, false), (39, true)]
theorem p2982 (F : Frame G 4) : c2982.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (40, false) :=
    use_clause (p2979 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, false) :=
    use_clause (p2977 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, true) :=
    use_clause (p261 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p266 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (33, true) :=
    use_clause (p153 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (99, true) :=
    use_clause (p151 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (19, false) :=
    use_clause (p1795 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h10 : LitSat F.assign (30, true) :=
    use_clause (p142 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h11 : LitSat F.assign (26, false) :=
    use_clause (p1344 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h13 : LitSat F.assign (6, false) :=
    use_clause (p1794 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h14 : LitSat F.assign (50, true) :=
    use_clause (p2980 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h15 : LitSat F.assign (7, false) :=
    use_clause (p2048 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h16 : LitSat F.assign (17, false) :=
    use_clause (p2981 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h17 : LitSat F.assign (18, true) :=
    use_clause (p133 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h18 : LitSat F.assign (29, true) :=
    use_clause (p131 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h19 : LitSat F.assign (21, false) :=
    use_clause (p1835 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h20 : LitSat F.assign (10, false) :=
    use_clause (p1837 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  exact use_clause (p149 F)
      ⟨fun h => False.elim (unit_incompatible h20 h),
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2983 : CNF.Clause Nat := [(30, false), (88, true), (51, false), (39, true)]
theorem p2983 (F : Frame G 4) : c2983.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (62, false) :=
    use_clause (p2982 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (40, false) :=
    use_clause (p2979 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, false) :=
    use_clause (p2977 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p266 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (33, true) :=
    use_clause (p153 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (11, true) :=
    use_clause (p159 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (99, true) :=
    use_clause (p151 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (26, false) :=
    use_clause (p1344 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (29, false) :=
    use_clause (p1362 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h13 : LitSat F.assign (7, true) :=
    use_clause (p22 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h14 : LitSat F.assign (6, false) :=
    use_clause (p1283 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h15 : LitSat F.assign (17, false) :=
    use_clause (p1824 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  exact use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c2984 : CNF.Clause Nat := [(6, false), (88, true), (51, false), (39, true)]
theorem p2984 (F : Frame G 4) : c2984.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, false) :=
    use_clause (p2977 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (30, false) :=
    use_clause (p2983 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (19, true) :=
    use_clause (p142 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h4 : LitSat F.assign (62, false) :=
    use_clause (p2982 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (40, false) :=
    use_clause (p2979 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (86, true) :=
    use_clause (p261 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h8 : LitSat F.assign (98, true) :=
    use_clause (p266 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (33, true) :=
    use_clause (p153 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (11, true) :=
    use_clause (p159 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (7, false) :=
    use_clause (p1283 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h13 : LitSat F.assign (18, false) :=
    use_clause (p1397 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  exact use_clause (p25 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c2985 : CNF.Clause Nat := [(88, true), (51, false), (39, true)]
theorem p2985 (F : Frame G 4) : c2985.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p151 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (11, true) :=
    use_clause (p159 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, false) :=
    use_clause (p2977 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p266 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, true) :=
    use_clause (p261 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h7 : LitSat F.assign (40, false) :=
    use_clause (p2979 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (62, false) :=
    use_clause (p2982 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h10 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h11 : LitSat F.assign (30, false) :=
    use_clause (p2983 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h12 : LitSat F.assign (19, true) :=
    use_clause (p142 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h13 : LitSat F.assign (6, false) :=
    use_clause (p2984 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h14 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h15 : LitSat F.assign (29, false) :=
    use_clause (p1850 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h16 : LitSat F.assign (18, true) :=
    use_clause (p19 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h17 : LitSat F.assign (7, true) :=
    use_clause (p22 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h18 : LitSat F.assign (10, false) :=
    use_clause (p1293 F)
      ⟨fun h => False.elim (unit_incompatible h17 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h19 : LitSat F.assign (21, true) :=
    use_clause (p149 F)
      ⟨fun h => False.elim (unit_incompatible h18 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h20 : LitSat F.assign (15, false) :=
    use_clause (p316 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h21 : LitSat F.assign (26, false) :=
    use_clause (p1778 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h19 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h20 h),
        fun h => False.elim (unit_incompatible h21 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
def c2986 : CNF.Clause Nat := [(19, false), (18, false), (7, false), (98, false), (50, false), (38, false), (88, false), (22, true), (51, false)]
theorem p2986 (F : Frame G 4) : c2986.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (19, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, false) :=
    use_clause (p1976 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (33, false) :=
    use_clause (p1600 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p152 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2987 : CNF.Clause Nat := [(19, true), (86, true), (11, false), (30, true), (98, false), (62, true), (40, true), (51, false), (39, true)]
theorem p2987 (F : Frame G 4) : c2987.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (19, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p144 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (99, true) :=
    use_clause (p199 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (26, false) :=
    use_clause (p1589 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p2250 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
def c2988 : CNF.Clause Nat := [(19, false), (7, false), (17, false), (98, false), (50, false), (62, true), (38, false), (40, true), (88, false), (22, true), (51, false)]
theorem p2988 (F : Frame G 4) : c2988.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (19, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (33, false) :=
    use_clause (p1600 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (18, false) :=
    use_clause (p2986 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, true) :=
    use_clause (p152 F)
      ⟨fun h => False.elim (n9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (29, true) :=
    use_clause (p19 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p1850 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c2989 : CNF.Clause Nat := [(33, true), (19, true), (30, true), (17, false), (98, false), (88, false), (22, true), (51, false)]
theorem p2989 (F : Frame G 4) : c2989.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (33, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (19, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (30, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (86, true) :=
    use_clause (p200 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (11, true) :=
    use_clause (p161 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1602 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        True.intro⟩
def c2990 : CNF.Clause Nat := [(11, false), (7, false), (17, false), (98, false), (62, true), (40, true), (51, false), (39, true)]
theorem p2990 (F : Frame G 4) : c2990.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n7 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (19, false) :=
    use_clause (p2988 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (30, false) :=
    use_clause (p1601 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, false) :=
    use_clause (p1602 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  exact use_clause (p2987 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
def c2991 : CNF.Clause Nat := [(7, false), (17, false), (98, false), (62, true), (40, true), (51, false), (39, true)]
theorem p2991 (F : Frame G 4) : c2991.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (30, false) :=
    use_clause (p1601 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (19, false) :=
    use_clause (p2988 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (33, true) :=
    use_clause (p2989 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (11, false) :=
    use_clause (p2990 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h9 : LitSat F.assign (86, true) :=
    use_clause (p203 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (87, true) :=
    use_clause (p196 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1606 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
def c2992 : CNF.Clause Nat := [(11, true), (17, false), (98, false), (62, true), (40, true), (51, false), (39, true)]
theorem p2992 (F : Frame G 4) : c2992.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (7, false) :=
    use_clause (p2991 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (29, true) :=
    use_clause (p22 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, true) :=
    use_clause (p158 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (33, true) :=
    use_clause (p161 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (15, false) :=
    use_clause (p1626 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (26, false) :=
    use_clause (p1341 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c2993 : CNF.Clause Nat := [(33, false), (17, false), (98, false), (62, true), (40, true), (51, false), (39, true)]
theorem p2993 (F : Frame G 4) : c2993.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (33, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (11, true) :=
    use_clause (p2992 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p1602 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (7, false) :=
    use_clause (p2991 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (29, true) :=
    use_clause (p22 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (26, false) :=
    use_clause (p1341 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h10 : LitSat F.assign (99, false) :=
    use_clause (p1626 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h11 : LitSat F.assign (9, false) :=
    use_clause (p1603 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h12 : LitSat F.assign (87, true) :=
    use_clause (p264 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (31, true) :=
    use_clause (p146 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  exact use_clause (p1561 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c2994 : CNF.Clause Nat := [(19, true), (17, false), (98, false), (62, true), (40, true), (51, false), (39, true)]
theorem p2994 (F : Frame G 4) : c2994.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (19, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (33, false) :=
    use_clause (p2993 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, true) :=
    use_clause (p152 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h5 : LitSat F.assign (11, true) :=
    use_clause (p2992 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, false) :=
    use_clause (p1602 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (30, true) :=
    use_clause (p2987 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h9 : LitSat F.assign (87, true) :=
    use_clause (p186 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2878 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c2995 : CNF.Clause Nat := [(17, false), (98, false), (62, true), (40, true), (51, false), (39, true)]
theorem p2995 (F : Frame G 4) : c2995.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (7, false) :=
    use_clause (p2991 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (29, true) :=
    use_clause (p22 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (33, false) :=
    use_clause (p2993 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, true) :=
    use_clause (p152 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (19, true) :=
    use_clause (p2994 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p1850 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c2996 : CNF.Clause Nat := [(19, false), (99, false), (98, false), (62, true), (40, true), (51, false), (39, true)]
theorem p2996 (F : Frame G 4) : c2996.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (19, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (17, false) :=
    use_clause (p2995 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, false) :=
    use_clause (p1645 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (29, true) :=
    use_clause (p2957 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (21, false) :=
    use_clause (p1673 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (10, true) :=
    use_clause (p149 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (7, false) :=
    use_clause (p1282 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h11 : LitSat F.assign (15, false) :=
    use_clause (p1620 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h12 : LitSat F.assign (18, true) :=
    use_clause (p25 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h13 : LitSat F.assign (26, true) :=
    use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p1694 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c2997 : CNF.Clause Nat := [(33, true), (98, false), (62, true), (40, true), (51, false), (39, true)]
theorem p2997 (F : Frame G 4) : c2997.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (33, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (17, false) :=
    use_clause (p2995 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, true) :=
    use_clause (p152 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (11, true) :=
    use_clause (p161 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (87, false) :=
    use_clause (p1645 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h10 : LitSat F.assign (19, false) :=
    use_clause (p2996 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h11 : LitSat F.assign (30, true) :=
    use_clause (p192 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (18, false) :=
    use_clause (p1529 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h13 : LitSat F.assign (29, true) :=
    use_clause (p19 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h14 : LitSat F.assign (7, true) :=
    use_clause (p25 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h15 : LitSat F.assign (21, false) :=
    use_clause (p1673 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
  have h16 : LitSat F.assign (10, false) :=
    use_clause (p1286 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p149 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c2998 : CNF.Clause Nat := [(29, false), (87, true), (99, false), (33, false), (6, false), (98, false), (62, true), (40, true), (88, false), (39, true)]
theorem p2998 (F : Frame G 4) : c2998.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (33, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (21, false) :=
    use_clause (p1673 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h4 : LitSat F.assign (26, false) :=
    use_clause (p1341 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (10, true) :=
    use_clause (p149 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h7 : LitSat F.assign (7, false) :=
    use_clause (p1282 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h8 : LitSat F.assign (18, false) :=
    use_clause (p1671 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p25 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c2999 : CNF.Clause Nat := [(99, false), (98, false), (62, true), (40, true), (51, false), (39, true)]
theorem p2999 (F : Frame G 4) : c2999.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (33, true) :=
    use_clause (p2997 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (17, false) :=
    use_clause (p2995 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (87, false) :=
    use_clause (p1645 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (19, false) :=
    use_clause (p2996 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h10 : LitSat F.assign (29, false) :=
    use_clause (p2998 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h11 : LitSat F.assign (18, true) :=
    use_clause (p19 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h12 : LitSat F.assign (7, true) :=
    use_clause (p22 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h13 : LitSat F.assign (30, false) :=
    use_clause (p1529 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h14 : LitSat F.assign (10, false) :=
    use_clause (p1282 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h15 : LitSat F.assign (11, true) :=
    use_clause (p196 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h16 : LitSat F.assign (86, true) :=
    use_clause (p2987 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h17 : LitSat F.assign (21, true) :=
    use_clause (p149 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1696 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3000 : CNF.Clause Nat := [(29, true), (98, false), (62, true), (40, true), (51, false), (39, true)]
theorem p3000 (F : Frame G 4) : c3000.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (29, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p2999 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (11, true) :=
    use_clause (p158 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (33, true) :=
    use_clause (p2997 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (17, false) :=
    use_clause (p2995 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h10 : LitSat F.assign (18, true) :=
    use_clause (p19 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h11 : LitSat F.assign (7, true) :=
    use_clause (p22 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h12 : LitSat F.assign (30, false) :=
    use_clause (p1529 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h13 : LitSat F.assign (19, false) :=
    use_clause (p2986 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h14 : LitSat F.assign (86, true) :=
    use_clause (p2987 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h15 : LitSat F.assign (87, true) :=
    use_clause (p191 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1681 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3001 : CNF.Clause Nat := [(98, false), (62, true), (40, true), (51, false), (39, true)]
theorem p3001 (F : Frame G 4) : c3001.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (17, false) :=
    use_clause (p2995 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h6 : LitSat F.assign (33, true) :=
    use_clause (p2997 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, false) :=
    use_clause (p2999 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (29, true) :=
    use_clause (p3000 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (26, false) :=
    use_clause (p1341 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h11 : LitSat F.assign (86, false) :=
    use_clause (p2703 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h12 : LitSat F.assign (87, true) :=
    use_clause (p264 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (7, false) :=
    use_clause (p1534 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h14 : LitSat F.assign (18, false) :=
    use_clause (p1613 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  exact use_clause (p25 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c3002 : CNF.Clause Nat := [(29, false), (99, true), (33, false), (62, true), (40, true), (51, false), (39, true)]
theorem p3002 (F : Frame G 4) : c3002.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (33, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (11, true) :=
    use_clause (p158 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, false) :=
    use_clause (p3001 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, true) :=
    use_clause (p267 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h9 : LitSat F.assign (26, false) :=
    use_clause (p1341 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (31, false) :=
    use_clause (p1363 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h12 : LitSat F.assign (9, true) :=
    use_clause (p145 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h13 : LitSat F.assign (10, false) :=
    use_clause (p1462 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h14 : LitSat F.assign (21, false) :=
    use_clause (p1564 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p148 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3003 : CNF.Clause Nat := [(99, true), (33, false), (62, true), (40, true), (51, false), (39, true)]
theorem p3003 (F : Frame G 4) : c3003.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (33, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, false) :=
    use_clause (p3001 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, true) :=
    use_clause (p267 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h5 : LitSat F.assign (29, false) :=
    use_clause (p3002 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (18, true) :=
    use_clause (p19 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (7, true) :=
    use_clause (p22 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (6, false) :=
    use_clause (p1681 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (17, false) :=
    use_clause (p1606 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c3004 : CNF.Clause Nat := [(33, false), (62, true), (40, true), (51, false), (39, true)]
theorem p3004 (F : Frame G 4) : c3004.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (33, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, false) :=
    use_clause (p3001 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h4 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, true) :=
    use_clause (p3003 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (6, false) :=
    use_clause (p1645 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h10 : LitSat F.assign (86, true) :=
    use_clause (p2959 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h11 : LitSat F.assign (9, false) :=
    use_clause (p1646 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h12 : LitSat F.assign (7, false) :=
    use_clause (p1606 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h13 : LitSat F.assign (18, true) :=
    use_clause (p25 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h14 : LitSat F.assign (29, true) :=
    use_clause (p22 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h15 : LitSat F.assign (31, false) :=
    use_clause (p1957 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h16 : LitSat F.assign (11, false) :=
    use_clause (p2964 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p225 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3005 : CNF.Clause Nat := [(62, true), (40, true), (51, false), (39, true)]
theorem p3005 (F : Frame G 4) : c3005.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p3001 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (33, false) :=
    use_clause (p3004 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (99, true) :=
    use_clause (p152 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (6, false) :=
    use_clause (p1645 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h10 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h11 : LitSat F.assign (9, false) :=
    use_clause (p1646 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h12 : LitSat F.assign (31, true) :=
    use_clause (p220 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (7, false) :=
    use_clause (p1383 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h14 : LitSat F.assign (18, true) :=
    use_clause (p25 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h15 : LitSat F.assign (29, true) :=
    use_clause (p22 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p1957 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
def c3006 : CNF.Clause Nat := [(50, true), (33, true), (98, true), (40, true), (51, false), (39, true)]
theorem p3006 (F : Frame G 4) : c3006.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (33, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, true) :=
    use_clause (p3005 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, true) :=
    use_clause (p152 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (21, false) :=
    use_clause (p1972 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (10, true) :=
    use_clause (p148 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (6, false) :=
    use_clause (p1645 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h10 : LitSat F.assign (86, false) :=
    use_clause (p2966 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h11 : LitSat F.assign (17, true) :=
    use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h12 : LitSat F.assign (31, true) :=
    use_clause (p213 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1380 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
def c3007 : CNF.Clause Nat := [(17, false), (33, true), (98, true), (62, false), (38, false), (88, false), (22, true), (51, false)]
theorem p3007 (F : Frame G 4) : c3007.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (33, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p152 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (21, false) :=
    use_clause (p1972 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (10, true) :=
    use_clause (p148 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (31, false) :=
    use_clause (p1380 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (9, false) :=
    use_clause (p1646 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p220 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3008 : CNF.Clause Nat := [(33, true), (98, true), (40, true), (51, false), (39, true)]
theorem p3008 (F : Frame G 4) : c3008.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (33, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, true) :=
    use_clause (p3005 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, true) :=
    use_clause (p152 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (6, false) :=
    use_clause (p1645 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (21, false) :=
    use_clause (p1972 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h9 : LitSat F.assign (10, true) :=
    use_clause (p148 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (50, true) :=
    use_clause (p3006 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h11 : LitSat F.assign (29, false) :=
    use_clause (p1710 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        True.intro⟩
  have h12 : LitSat F.assign (17, false) :=
    use_clause (p3007 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h13 : LitSat F.assign (7, true) :=
    use_clause (p131 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h14 : LitSat F.assign (18, true) :=
    use_clause (p129 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h15 : LitSat F.assign (31, false) :=
    use_clause (p1512 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h16 : LitSat F.assign (9, false) :=
    use_clause (p1713 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  exact use_clause (p220 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3009 : CNF.Clause Nat := [(99, false), (98, true), (40, true), (51, false), (39, true)]
theorem p3009 (F : Frame G 4) : c3009.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (33, true) :=
    use_clause (p3008 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (62, true) :=
    use_clause (p3005 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (6, false) :=
    use_clause (p1645 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (50, false) :=
    use_clause (p1765 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h8 : LitSat F.assign (21, false) :=
    use_clause (p1972 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h9 : LitSat F.assign (86, false) :=
    use_clause (p2966 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h10 : LitSat F.assign (17, true) :=
    use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h11 : LitSat F.assign (10, true) :=
    use_clause (p148 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (31, false) :=
    use_clause (p1380 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h13 : LitSat F.assign (9, false) :=
    use_clause (p1646 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p147 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c3010 : CNF.Clause Nat := [(17, false), (99, true), (33, false), (98, true), (62, false), (38, false), (88, false), (51, false)]
theorem p3010 (F : Frame G 4) : c3010.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (33, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (9, false) :=
    use_clause (p1492 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (31, false) :=
    use_clause (p1384 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  exact use_clause (p145 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c3011 : CNF.Clause Nat := [(9, false), (98, true), (40, true), (51, false), (39, true)]
theorem p3011 (F : Frame G 4) : c3011.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (9, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (62, true) :=
    use_clause (p3005 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (33, true) :=
    use_clause (p3008 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p3009 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (17, false) :=
    use_clause (p3010 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (11, true) :=
    use_clause (p158 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (86, true) :=
    use_clause (p267 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h10 : LitSat F.assign (21, false) :=
    use_clause (p1485 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h11 : LitSat F.assign (10, true) :=
    use_clause (p148 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (6, false) :=
    use_clause (p1290 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (50, false) :=
    use_clause (p1493 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
def c3012 : CNF.Clause Nat := [(98, true), (40, true), (51, false), (39, true)]
theorem p3012 (F : Frame G 4) : c3012.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (62, true) :=
    use_clause (p3005 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (33, true) :=
    use_clause (p3008 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, false) :=
    use_clause (p3009 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (86, true) :=
    use_clause (p267 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (11, true) :=
    use_clause (p158 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (17, false) :=
    use_clause (p3010 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h11 : LitSat F.assign (9, false) :=
    use_clause (p3011 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h12 : LitSat F.assign (31, true) :=
    use_clause (p145 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h13 : LitSat F.assign (26, false) :=
    use_clause (p1345 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (15, true) :=
    use_clause (p8 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h15 : LitSat F.assign (6, false) :=
    use_clause (p1488 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h16 : LitSat F.assign (50, true) :=
    use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        fun h => h,
        True.intro⟩
  have h17 : LitSat F.assign (10, false) :=
    use_clause (p1493 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h18 : LitSat F.assign (21, false) :=
    use_clause (p1483 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p148 F)
      ⟨fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3013 : CNF.Clause Nat := [(40, true), (51, false), (39, true)]
theorem p3013 (F : Frame G 4) : c3013.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (40, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h4 : LitSat F.assign (62, true) :=
    use_clause (p3005 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p3012 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, false) :=
    use_clause (p2088 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (33, false) :=
    use_clause (p1511 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p152 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3014 : CNF.Clause Nat := [(50, false), (33, true), (98, false), (62, false), (51, false), (39, true)]
theorem p3014 (F : Frame G 4) : c3014.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (33, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, true) :=
    use_clause (p152 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (26, false) :=
    use_clause (p1949 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (38, false) :=
    use_clause (p2088 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (15, true) :=
    use_clause (p10 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (11, true) :=
    use_clause (p161 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (40, true) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (30, false) :=
    use_clause (p1802 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h10 : LitSat F.assign (86, false) :=
    use_clause (p1520 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p2924 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3015 : CNF.Clause Nat := [(6, false), (33, true), (98, false), (62, false), (51, false), (39, true)]
theorem p3015 (F : Frame G 4) : c3015.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (33, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, true) :=
    use_clause (p152 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (26, false) :=
    use_clause (p1949 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (38, false) :=
    use_clause (p2088 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (15, true) :=
    use_clause (p10 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h7 : LitSat F.assign (19, false) :=
    use_clause (p1795 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h8 : LitSat F.assign (40, true) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (30, false) :=
    use_clause (p1576 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h10 : LitSat F.assign (27, false) :=
    use_clause (p1649 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h11 : LitSat F.assign (86, true) :=
    use_clause (p2924 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h12 : LitSat F.assign (87, true) :=
    use_clause (p192 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2928 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3016 : CNF.Clause Nat := [(33, true), (98, false), (62, false), (51, false), (39, true)]
theorem p3016 (F : Frame G 4) : c3016.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (33, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (40, true) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, true) :=
    use_clause (p152 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (38, false) :=
    use_clause (p2088 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (19, false) :=
    use_clause (p1795 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (50, false) :=
    use_clause (p3014 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (6, false) :=
    use_clause (p3015 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (17, true) :=
    use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h10 : LitSat F.assign (86, false) :=
    use_clause (p1693 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h11 : LitSat F.assign (30, true) :=
    use_clause (p2989 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h12 : LitSat F.assign (87, true) :=
    use_clause (p186 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p2858 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c3017 : CNF.Clause Nat := [(17, false), (50, true), (99, false), (33, false), (98, false), (62, false), (88, false), (51, false)]
theorem p3017 (F : Frame G 4) : c3017.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (33, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (38, false) :=
    use_clause (p1511 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (5, false) :=
    use_clause (p1746 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (27, false) :=
    use_clause (p1721 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p14 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c3018 : CNF.Clause Nat := [(6, false), (99, false), (98, false), (62, false), (51, false), (39, true)]
theorem p3018 (F : Frame G 4) : c3018.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (33, true) :=
    use_clause (p3016 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, false) :=
    use_clause (p1511 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (40, true) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (30, false) :=
    use_clause (p1576 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (86, false) :=
    use_clause (p1579 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p2924 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3019 : CNF.Clause Nat := [(50, true), (99, false), (98, false), (62, false), (51, false), (39, true)]
theorem p3019 (F : Frame G 4) : c3019.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (6, false) :=
    use_clause (p3018 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (33, true) :=
    use_clause (p3016 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (17, false) :=
    use_clause (p3017 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        True.intro⟩
def c3020 : CNF.Clause Nat := [(99, false), (98, false), (62, false), (51, false), (39, true)]
theorem p3020 (F : Frame G 4) : c3020.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (33, true) :=
    use_clause (p3016 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, false) :=
    use_clause (p1511 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (40, true) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (26, false) :=
    use_clause (p1949 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h7 : LitSat F.assign (19, false) :=
    use_clause (p1795 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h8 : LitSat F.assign (15, true) :=
    use_clause (p10 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h9 : LitSat F.assign (50, true) :=
    use_clause (p3019 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h10 : LitSat F.assign (30, false) :=
    use_clause (p1802 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h11 : LitSat F.assign (87, false) :=
    use_clause (p1830 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h12 : LitSat F.assign (86, true) :=
    use_clause (p2924 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h13 : LitSat F.assign (11, true) :=
    use_clause (p196 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1520 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c3021 : CNF.Clause Nat := [(50, false), (99, true), (33, false), (98, false), (62, false), (40, false), (88, false), (22, true), (51, false)]
theorem p3021 (F : Frame G 4) : c3021.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (33, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (30, false) :=
    use_clause (p1570 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (19, false) :=
    use_clause (p1527 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, true) :=
    use_clause (p199 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p191 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1723 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c3022 : CNF.Clause Nat := [(86, false), (50, true), (33, false), (98, false), (51, false), (39, true)]
theorem p3022 (F : Frame G 4) : c3022.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (33, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (40, true) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (17, false) :=
    use_clause (p1693 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (6, false) :=
    use_clause (p1579 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c3023 : CNF.Clause Nat := [(98, false), (62, false), (51, false), (39, true)]
theorem p3023 (F : Frame G 4) : c3023.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (40, true) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (33, true) :=
    use_clause (p3016 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (38, false) :=
    use_clause (p1511 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, false) :=
    use_clause (p3020 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (11, true) :=
    use_clause (p158 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (50, false) :=
    use_clause (p3021 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (86, false) :=
    use_clause (p3022 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (87, true) :=
    use_clause (p264 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (27, false) :=
    use_clause (p1513 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h12 : LitSat F.assign (5, false) :=
    use_clause (p2180 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p14 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
def c3024 : CNF.Clause Nat := [(99, true), (33, false), (62, false), (51, false), (39, true)]
theorem p3024 (F : Frame G 4) : c3024.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (33, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (40, true) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, false) :=
    use_clause (p3023 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (9, false) :=
    use_clause (p1473 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h6 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (86, true) :=
    use_clause (p267 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h8 : LitSat F.assign (11, true) :=
    use_clause (p158 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (50, false) :=
    use_clause (p2888 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (31, true) :=
    use_clause (p145 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h11 : LitSat F.assign (17, false) :=
    use_clause (p1469 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        True.intro⟩
  have h12 : LitSat F.assign (27, false) :=
    use_clause (p1356 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (10, false) :=
    use_clause (p1482 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h14 : LitSat F.assign (6, true) :=
    use_clause (p17 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h15 : LitSat F.assign (21, true) :=
    use_clause (p148 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h16 : LitSat F.assign (5, false) :=
    use_clause (p1575 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h17 : LitSat F.assign (38, false) :=
    use_clause (p1381 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p14 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
def c3025 : CNF.Clause Nat := [(33, false), (62, false), (51, false), (39, true)]
theorem p3025 (F : Frame G 4) : c3025.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (33, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, false) :=
    use_clause (p3023 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (40, true) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, true) :=
    use_clause (p3024 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (38, true) :=
    use_clause (p2860 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (50, false) :=
    use_clause (p1765 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (17, false) :=
    use_clause (p2531 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h10 : LitSat F.assign (6, false) :=
    use_clause (p1645 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
def c3026 : CNF.Clause Nat := [(62, false), (51, false), (39, true)]
theorem p3026 (F : Frame G 4) : c3026.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (40, true) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (98, false) :=
    use_clause (p3023 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (9, false) :=
    use_clause (p1473 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h7 : LitSat F.assign (33, false) :=
    use_clause (p3025 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (99, true) :=
    use_clause (p152 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (31, true) :=
    use_clause (p220 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (38, true) :=
    use_clause (p2860 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h11 : LitSat F.assign (17, false) :=
    use_clause (p2531 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h12 : LitSat F.assign (50, false) :=
    use_clause (p1801 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h13 : LitSat F.assign (6, false) :=
    use_clause (p1645 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p17 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h12 h),
        True.intro⟩
def c3027 : CNF.Clause Nat := [(99, false), (98, true), (51, false), (39, true)]
theorem p3027 (F : Frame G 4) : c3027.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, false) :=
    use_clause (p3026 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (40, true) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (17, false) :=
    use_clause (p2531 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h8 : LitSat F.assign (6, false) :=
    use_clause (p1770 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3028 : CNF.Clause Nat := [(98, true), (51, false), (39, true)]
theorem p3028 (F : Frame G 4) : c3028.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (62, false) :=
    use_clause (p3026 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (40, true) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, false) :=
    use_clause (p3027 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (86, true) :=
    use_clause (p267 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h9 : LitSat F.assign (11, true) :=
    use_clause (p158 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (33, true) :=
    use_clause (p152 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (9, true) :=
    use_clause (p2888 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h12 : LitSat F.assign (21, false) :=
    use_clause (p1677 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h13 : LitSat F.assign (17, false) :=
    use_clause (p1582 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  have h14 : LitSat F.assign (10, true) :=
    use_clause (p148 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h15 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p1290 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3029 : CNF.Clause Nat := [(17, false), (99, true), (98, false), (50, false), (40, false), (88, false), (22, true), (51, false)]
theorem p3029 (F : Frame G 4) : c3029.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (19, false) :=
    use_clause (p1527 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (30, false) :=
    use_clause (p1528 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p1693 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p199 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3030 : CNF.Clause Nat := [(99, true), (33, false), (51, false), (39, true)]
theorem p3030 (F : Frame G 4) : c3030.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (33, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, true) :=
    use_clause (p3028 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, false) :=
    use_clause (p3026 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (40, true) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (17, false) :=
    use_clause (p3029 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h9 : LitSat F.assign (86, false) :=
    use_clause (p1579 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h10 : LitSat F.assign (87, false) :=
    use_clause (p1631 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p264 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3031 : CNF.Clause Nat := [(38, false), (10, false), (18, true), (30, false), (6, false), (99, false), (98, false), (50, false), (62, true), (40, false), (88, false)]
theorem p3031 (F : Frame G 4) : c3031.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (18, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (7, false) :=
    use_clause (p1751 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (29, false) :=
    use_clause (p1682 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n10 h),
        True.intro⟩
  exact use_clause (p27 F)
      ⟨fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n8 h),
        True.intro⟩
def c3032 : CNF.Clause Nat := [(15, true), (38, true), (30, false), (6, false), (99, false), (51, false), (39, true)]
theorem p3032 (F : Frame G 4) : c3032.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (15, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (98, true) :=
    use_clause (p3028 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (62, false) :=
    use_clause (p3026 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (18, false) :=
    use_clause (p1529 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (40, true) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (26, true) :=
    use_clause (p10 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (7, true) :=
    use_clause (p60 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p1697 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3033 : CNF.Clause Nat := [(6, false), (33, false), (51, false), (39, true)]
theorem p3033 (F : Frame G 4) : c3033.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (33, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p3030 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, false) :=
    use_clause (p3026 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (40, true) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, true) :=
    use_clause (p3028 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (19, false) :=
    use_clause (p1527 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (87, false) :=
    use_clause (p1770 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h9 : LitSat F.assign (86, false) :=
    use_clause (p1579 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h10 : LitSat F.assign (30, true) :=
    use_clause (p144 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h11 : LitSat F.assign (18, false) :=
    use_clause (p1529 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h12 : LitSat F.assign (21, false) :=
    use_clause (p1901 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h13 : LitSat F.assign (10, true) :=
    use_clause (p149 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (38, false) :=
    use_clause (p3031 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h15 : LitSat F.assign (15, true) :=
    use_clause (p3032 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h16 : LitSat F.assign (31, false) :=
    use_clause (p1683 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h17 : LitSat F.assign (9, false) :=
    use_clause (p1604 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p209 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3034 : CNF.Clause Nat := [(33, false), (51, false), (39, true)]
theorem p3034 (F : Frame G 4) : c3034.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (33, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (62, false) :=
    use_clause (p3026 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (40, true) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, true) :=
    use_clause (p3028 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (19, false) :=
    use_clause (p1527 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (99, true) :=
    use_clause (p3030 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (6, false) :=
    use_clause (p3033 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h10 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h11 : LitSat F.assign (30, false) :=
    use_clause (p1528 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h12 : LitSat F.assign (38, false) :=
    use_clause (p1627 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h13 : LitSat F.assign (86, false) :=
    use_clause (p1693 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h14 : LitSat F.assign (11, true) :=
    use_clause (p203 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h15 : LitSat F.assign (87, true) :=
    use_clause (p144 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        True.intro⟩
  have h16 : LitSat F.assign (15, false) :=
    use_clause (p1830 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h17 : LitSat F.assign (26, false) :=
    use_clause (p1589 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  exact use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c3035 : CNF.Clause Nat := [(17, false), (33, true), (98, false), (50, false), (40, false), (88, false), (22, true), (51, false)]
theorem p3035 (F : Frame G 4) : c3035.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (33, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (19, false) :=
    use_clause (p1527 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h1 : LitSat F.assign (30, false) :=
    use_clause (p1528 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p2989 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
def c3036 : CNF.Clause Nat := [(51, false), (39, true)]
theorem p3036 (F : Frame G 4) : c3036.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (51, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (22, false) :=
    use_clause (p2963 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (88, true) :=
    use_clause (p2985 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (40, true) :=
    use_clause (p3013 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h4 : LitSat F.assign (62, false) :=
    use_clause (p3026 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h5 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (98, true) :=
    use_clause (p3028 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h7 : LitSat F.assign (19, false) :=
    use_clause (p1527 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h8 : LitSat F.assign (33, false) :=
    use_clause (p3034 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (99, true) :=
    use_clause (p152 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (11, true) :=
    use_clause (p161 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (17, false) :=
    use_clause (p3035 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h12 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h13 : LitSat F.assign (87, false) :=
    use_clause (p1770 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h14 : LitSat F.assign (86, true) :=
    use_clause (p186 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h15 : LitSat F.assign (30, true) :=
    use_clause (p192 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h16 : LitSat F.assign (21, false) :=
    use_clause (p1677 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h17 : LitSat F.assign (29, false) :=
    use_clause (p1637 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h18 : LitSat F.assign (26, false) :=
    use_clause (p1748 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h19 : LitSat F.assign (18, false) :=
    use_clause (p1529 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h20 : LitSat F.assign (10, true) :=
    use_clause (p149 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h21 : LitSat F.assign (15, true) :=
    use_clause (p63 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  exact use_clause (p1462 F)
      ⟨fun h => False.elim (unit_incompatible h21 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h20 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        True.intro⟩
def c3037 : CNF.Clause Nat := [(22, true), (19, true), (30, false), (33, true), (6, false), (88, false), (98, false), (38, false), (50, false), (62, true), (51, true)]
theorem p3037 (F : Frame G 4) : c3037.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (19, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (33, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have n10 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, true) :=
    use_clause (p152 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (11, true) :=
    use_clause (p161 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, false) :=
    use_clause (p2253 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (7, false) :=
    use_clause (p1751 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (86, true) :=
    use_clause (p186 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (29, true) :=
    use_clause (p21 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n10 h),
        fun h => False.elim (n9 h),
        True.intro⟩
  exact use_clause (p1637 F)
      ⟨fun h => False.elim (n8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c3038 : CNF.Clause Nat := [(22, false), (6, false), (88, false), (98, false), (38, false), (50, false), (62, true), (51, true)]
theorem p3038 (F : Frame G 4) : c3038.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h1 : LitSat F.assign (7, false) :=
    use_clause (p1690 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (29, false) :=
    use_clause (p1990 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p21 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c3039 : CNF.Clause Nat := [(33, true), (6, false), (88, false), (98, false), (38, false), (50, false), (62, true), (51, true)]
theorem p3039 (F : Frame G 4) : c3039.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (33, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (22, false) :=
    use_clause (p3038 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, true) :=
    use_clause (p152 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, false) :=
    use_clause (p2253 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h5 : LitSat F.assign (19, false) :=
    use_clause (p1687 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h6 : LitSat F.assign (30, true) :=
    use_clause (p192 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p3037 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
def c3040 : CNF.Clause Nat := [(99, false), (30, false), (6, false), (88, false), (98, false), (38, false), (50, false), (62, true), (51, true)]
theorem p3040 (F : Frame G 4) : c3040.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (30, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (33, true) :=
    use_clause (p3039 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (87, false) :=
    use_clause (p1631 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (7, false) :=
    use_clause (p1751 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (29, true) :=
    use_clause (p21 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (21, false) :=
    use_clause (p1672 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h7 : LitSat F.assign (10, false) :=
    use_clause (p1682 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p149 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3041 : CNF.Clause Nat := [(99, true), (87, true), (33, false), (22, true), (88, false), (98, false), (50, false), (62, true), (51, true)]
theorem p3041 (F : Frame G 4) : c3041.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (87, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (33, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (11, true) :=
    use_clause (p158 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, true) :=
    use_clause (p264 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (29, false) :=
    use_clause (p1637 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (18, false) :=
    use_clause (p1550 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  exact use_clause (p18 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        True.intro⟩
def c3042 : CNF.Clause Nat := [(6, false), (88, false), (98, false), (38, false), (50, false), (62, true), (51, true)]
theorem p3042 (F : Frame G 4) : c3042.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, false) :=
    use_clause (p3038 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (33, true) :=
    use_clause (p3039 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, false) :=
    use_clause (p1631 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, true) :=
    use_clause (p3041 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (19, false) :=
    use_clause (p1687 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h7 : LitSat F.assign (30, false) :=
    use_clause (p3040 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h8 : LitSat F.assign (11, true) :=
    use_clause (p196 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (86, true) :=
    use_clause (p144 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h10 : LitSat F.assign (29, false) :=
    use_clause (p1637 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h11 : LitSat F.assign (18, false) :=
    use_clause (p1550 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p18 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3043 : CNF.Clause Nat := [(29, true), (86, false), (99, true), (88, false), (98, false), (38, false), (50, false), (62, true), (51, true)]
theorem p3043 (F : Frame G 4) : c3043.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (29, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (7, true) :=
    use_clause (p21 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (18, true) :=
    use_clause (p18 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (22, false) :=
    use_clause (p1690 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (33, false) :=
    use_clause (p1550 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  exact use_clause (p152 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3044 : CNF.Clause Nat := [(86, false), (99, true), (88, false), (98, false), (38, false), (50, false), (62, true), (51, true)]
theorem p3044 (F : Frame G 4) : c3044.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (29, true) :=
    use_clause (p3043 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (22, false) :=
    use_clause (p1651 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (11, false) :=
    use_clause (p1637 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p158 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3045 : CNF.Clause Nat := [(31, false), (17, false), (88, false), (98, false), (38, false), (50, false), (62, true), (51, true)]
theorem p3045 (F : Frame G 4) : c3045.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (31, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p1627 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, false) :=
    use_clause (p3044 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p264 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (11, false) :=
    use_clause (p1562 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h6 : LitSat F.assign (22, true) :=
    use_clause (p158 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (33, true) :=
    use_clause (p155 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (7, false) :=
    use_clause (p1690 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (18, false) :=
    use_clause (p1538 F)
      ⟨fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p24 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c3046 : CNF.Clause Nat := [(88, false), (98, false), (62, true), (39, true)]
theorem p3046 (F : Frame G 4) : c3046.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (51, false) :=
    use_clause (p3036 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p137 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (6, false) :=
    use_clause (p3042 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h6 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, false) :=
    use_clause (p1627 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (86, false) :=
    use_clause (p3044 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (87, true) :=
    use_clause (p264 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (31, false) :=
    use_clause (p3045 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h11 : LitSat F.assign (9, true) :=
    use_clause (p146 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h12 : LitSat F.assign (29, false) :=
    use_clause (p1435 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h13 : LitSat F.assign (11, false) :=
    use_clause (p1438 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h14 : LitSat F.assign (7, true) :=
    use_clause (p21 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h15 : LitSat F.assign (22, true) :=
    use_clause (p158 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1690 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c3047 : CNF.Clause Nat := [(87, false), (88, true), (98, false), (38, false), (50, false), (62, true), (51, true)]
theorem p3047 (F : Frame G 4) : c3047.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (18, false) :=
    use_clause (p1963 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (7, true) :=
    use_clause (p24 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (22, false) :=
    use_clause (p1542 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (33, false) :=
    use_clause (p1769 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p153 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3048 : CNF.Clause Nat := [(22, true), (88, true), (98, false), (38, false), (50, false), (62, true), (51, true)]
theorem p3048 (F : Frame G 4) : c3048.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, false) :=
    use_clause (p3047 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (86, true) :=
    use_clause (p261 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (11, true) :=
    use_clause (p159 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (33, true) :=
    use_clause (p153 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (18, false) :=
    use_clause (p1541 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (7, true) :=
    use_clause (p24 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h9 : LitSat F.assign (29, true) :=
    use_clause (p18 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h10 : LitSat F.assign (19, false) :=
    use_clause (p1902 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h11 : LitSat F.assign (30, false) :=
    use_clause (p1362 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p142 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c3049 : CNF.Clause Nat := [(6, false), (7, false), (98, false), (62, true), (39, true)]
theorem p3049 (F : Frame G 4) : c3049.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, false) :=
    use_clause (p3046 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (51, false) :=
    use_clause (p3036 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (38, true) :=
    use_clause (p137 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (22, true) :=
    use_clause (p3048 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h6 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (87, false) :=
    use_clause (p3047 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h8 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (19, false) :=
    use_clause (p1902 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h10 : LitSat F.assign (30, true) :=
    use_clause (p142 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h11 : LitSat F.assign (33, false) :=
    use_clause (p1554 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h12 : LitSat F.assign (11, true) :=
    use_clause (p156 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (86, true) :=
    use_clause (p261 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h14 : LitSat F.assign (10, false) :=
    use_clause (p1289 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h15 : LitSat F.assign (21, false) :=
    use_clause (p1858 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  exact use_clause (p149 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3050 : CNF.Clause Nat := [(18, true), (7, false), (98, false), (62, true), (39, true)]
theorem p3050 (F : Frame G 4) : c3050.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (6, false) :=
    use_clause (p3049 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, false) :=
    use_clause (p3046 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (51, false) :=
    use_clause (p3036 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (38, true) :=
    use_clause (p137 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (22, true) :=
    use_clause (p3048 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (87, false) :=
    use_clause (p3047 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h10 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (19, false) :=
    use_clause (p1902 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  have h12 : LitSat F.assign (30, true) :=
    use_clause (p142 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h13 : LitSat F.assign (33, false) :=
    use_clause (p1554 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h14 : LitSat F.assign (11, true) :=
    use_clause (p156 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h15 : LitSat F.assign (86, true) :=
    use_clause (p261 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h16 : LitSat F.assign (29, true) :=
    use_clause (p18 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h17 : LitSat F.assign (26, false) :=
    use_clause (p1425 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h18 : LitSat F.assign (15, true) :=
    use_clause (p62 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h19 : LitSat F.assign (10, false) :=
    use_clause (p1860 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  have h20 : LitSat F.assign (21, true) :=
    use_clause (p149 F)
      ⟨fun h => False.elim (unit_incompatible h19 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h21 : LitSat F.assign (5, false) :=
    use_clause (p1859 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h20 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h22 : LitSat F.assign (27, false) :=
    use_clause (p1857 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h20 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  exact use_clause (p81 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h21 h),
        fun h => False.elim (unit_incompatible h22 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
def c3051 : CNF.Clause Nat := [(7, false), (98, false), (62, true), (39, true)]
theorem p3051 (F : Frame G 4) : c3051.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (51, false) :=
    use_clause (p3036 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (38, true) :=
    use_clause (p137 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, false) :=
    use_clause (p3046 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (22, true) :=
    use_clause (p3048 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, false) :=
    use_clause (p3047 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h7 : LitSat F.assign (86, true) :=
    use_clause (p261 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h10 : LitSat F.assign (19, false) :=
    use_clause (p1902 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h11 : LitSat F.assign (30, true) :=
    use_clause (p142 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h12 : LitSat F.assign (33, false) :=
    use_clause (p1554 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h13 : LitSat F.assign (11, true) :=
    use_clause (p156 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (6, false) :=
    use_clause (p3049 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h15 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h16 : LitSat F.assign (18, true) :=
    use_clause (p3050 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  exact use_clause (p1612 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
def c3052 : CNF.Clause Nat := [(11, false), (98, false), (62, true), (39, true)]
theorem p3052 (F : Frame G 4) : c3052.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (51, false) :=
    use_clause (p3036 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (7, false) :=
    use_clause (p3051 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (18, true) :=
    use_clause (p24 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (29, true) :=
    use_clause (p21 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (38, true) :=
    use_clause (p137 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (88, false) :=
    use_clause (p3046 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (22, true) :=
    use_clause (p3048 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (87, false) :=
    use_clause (p3047 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h10 : LitSat F.assign (86, true) :=
    use_clause (p261 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h11 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h12 : LitSat F.assign (17, false) :=
    use_clause (p1612 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h13 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h14 : LitSat F.assign (10, false) :=
    use_clause (p1289 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h15 : LitSat F.assign (21, true) :=
    use_clause (p149 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h16 : LitSat F.assign (5, false) :=
    use_clause (p1859 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h17 : LitSat F.assign (27, false) :=
    use_clause (p1857 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  exact use_clause (p80 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c3053 : CNF.Clause Nat := [(98, false), (62, true), (39, true)]
theorem p3053 (F : Frame G 4) : c3053.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (98, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (51, false) :=
    use_clause (p3036 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p137 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h4 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h5 : LitSat F.assign (88, false) :=
    use_clause (p3046 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, true) :=
    use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (87, false) :=
    use_clause (p3047 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h8 : LitSat F.assign (86, true) :=
    use_clause (p261 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h9 : LitSat F.assign (22, true) :=
    use_clause (p3048 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h10 : LitSat F.assign (7, false) :=
    use_clause (p3051 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h11 : LitSat F.assign (18, true) :=
    use_clause (p24 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h12 : LitSat F.assign (11, false) :=
    use_clause (p3052 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h13 : LitSat F.assign (33, true) :=
    use_clause (p156 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (17, false) :=
    use_clause (p1861 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h15 : LitSat F.assign (6, false) :=
    use_clause (p1916 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
  exact use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
def c3054 : CNF.Clause Nat := [(18, false), (6, false), (86, false), (22, false), (98, true), (38, false), (50, false), (40, false), (51, true)]
theorem p3054 (F : Frame G 4) : c3054.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p1741 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p265 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (21, false) :=
    use_clause (p1328 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (9, false) :=
    use_clause (p1436 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (10, true) :=
    use_clause (p148 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (31, true) :=
    use_clause (p145 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p1433 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n7 h),
        True.intro⟩
def c3055 : CNF.Clause Nat := [(6, false), (11, true), (86, false), (22, false), (98, true), (38, false), (50, false), (62, true), (51, true)]
theorem p3055 (F : Frame G 4) : c3055.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (6, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (18, false) :=
    use_clause (p3054 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h4 : LitSat F.assign (7, true) :=
    use_clause (p24 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h5 : LitSat F.assign (29, true) :=
    use_clause (p18 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n8 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h6 : LitSat F.assign (33, false) :=
    use_clause (p1680 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h7 : LitSat F.assign (99, false) :=
    use_clause (p1880 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p155 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3056 : CNF.Clause Nat := [(18, true), (17, false), (11, true), (86, false), (22, false), (98, true), (38, false), (50, false), (62, true), (51, true)]
theorem p3056 (F : Frame G 4) : c3056.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have n9 : ¬ LitSat F.assign (51, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (7, true) :=
    use_clause (p24 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h4 : LitSat F.assign (29, true) :=
    use_clause (p18 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n9 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h5 : LitSat F.assign (10, false) :=
    use_clause (p1539 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (21, true) :=
    use_clause (p148 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (99, false) :=
    use_clause (p1773 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (88, true) :=
    use_clause (p265 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (33, true) :=
    use_clause (p155 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (9, false) :=
    use_clause (p1463 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h11 : LitSat F.assign (31, false) :=
    use_clause (p1363 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p145 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
def c3057 : CNF.Clause Nat := [(11, true), (86, false), (22, false), (62, true), (39, true)]
theorem p3057 (F : Frame G 4) : c3057.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (11, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, false) :=
    use_clause (p3053 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, false) :=
    use_clause (p3036 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (38, true) :=
    use_clause (p137 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n4 h),
        fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h7 : LitSat F.assign (6, false) :=
    use_clause (p3055 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h8 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h9 : LitSat F.assign (18, true) :=
    use_clause (p3056 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h10 : LitSat F.assign (99, false) :=
    use_clause (p1741 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h11 : LitSat F.assign (21, false) :=
    use_clause (p1330 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (88, true) :=
    use_clause (p265 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (10, true) :=
    use_clause (p148 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (9, false) :=
    use_clause (p1437 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        True.intro⟩
  have h15 : LitSat F.assign (31, false) :=
    use_clause (p1433 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  exact use_clause (p145 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
def c3058 : CNF.Clause Nat := [(18, false), (17, false), (86, false), (22, false), (98, true), (38, false), (50, false), (40, false), (62, true)]
theorem p3058 (F : Frame G 4) : c3058.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p1741 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h3 : LitSat F.assign (21, false) :=
    use_clause (p1330 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, true) :=
    use_clause (p265 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (10, true) :=
    use_clause (p148 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (9, false) :=
    use_clause (p1437 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h7 : LitSat F.assign (31, false) :=
    use_clause (p1433 F)
      ⟨fun h => False.elim (n6 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p145 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
def c3059 : CNF.Clause Nat := [(7, false), (11, false), (86, false), (22, false), (98, true), (38, false), (50, false), (40, false)]
theorem p3059 (F : Frame G 4) : c3059.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (10, false) :=
    use_clause (p1539 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (21, true) :=
    use_clause (p148 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, false) :=
    use_clause (p1442 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p1773 F)
      ⟨fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p265 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3060 : CNF.Clause Nat := [(86, false), (22, false), (62, true), (39, true)]
theorem p3060 (F : Frame G 4) : c3060.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (98, false) :=
    use_clause (p3053 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h1 : LitSat F.assign (51, false) :=
    use_clause (p3036 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, true) :=
    use_clause (p137 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (11, true) :=
    use_clause (p3057 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (7, false) :=
    use_clause (p3059 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (18, true) :=
    use_clause (p24 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h8 : LitSat F.assign (6, false) :=
    use_clause (p3054 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h9 : LitSat F.assign (17, false) :=
    use_clause (p3058 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  exact use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        True.intro⟩
def c3061 : CNF.Clause Nat := [(86, true), (62, true), (39, true)]
theorem p3061 (F : Frame G 4) : c3061.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (98, false) :=
    use_clause (p3053 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, false) :=
    use_clause (p3036 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (38, true) :=
    use_clause (p137 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h5 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h6 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h7 : LitSat F.assign (88, true) :=
    use_clause (p263 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (99, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h9 : LitSat F.assign (18, false) :=
    use_clause (p1963 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h10 : LitSat F.assign (6, false) :=
    use_clause (p1770 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h11 : LitSat F.assign (7, true) :=
    use_clause (p24 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h12 : LitSat F.assign (29, true) :=
    use_clause (p18 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h13 : LitSat F.assign (17, true) :=
    use_clause (p16 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h14 : LitSat F.assign (21, false) :=
    use_clause (p1773 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h15 : LitSat F.assign (10, false) :=
    use_clause (p2136 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  exact use_clause (p148 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3062 : CNF.Clause Nat := [(99, false), (17, false), (29, false), (7, false), (86, false), (98, true), (38, false), (50, false), (40, false)]
theorem p3062 (F : Frame G 4) : c3062.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (21, false) :=
    use_clause (p1773 F)
      ⟨fun h => False.elim (n7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h3 : LitSat F.assign (10, false) :=
    use_clause (p1776 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p148 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3063 : CNF.Clause Nat := [(17, false), (29, false), (7, false), (22, true), (86, false), (98, true), (38, false), (50, false), (40, false)]
theorem p3063 (F : Frame G 4) : c3063.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (17, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (29, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (7, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (22, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (99, false) :=
    use_clause (p3062 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h3 : LitSat F.assign (33, true) :=
    use_clause (p152 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (11, true) :=
    use_clause (p158 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1540 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c3064 : CNF.Clause Nat := [(18, true), (62, true), (39, true)]
theorem p3064 (F : Frame G 4) : c3064.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (86, true) :=
    use_clause (p3061 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h2 : LitSat F.assign (22, false) :=
    use_clause (p3060 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (98, false) :=
    use_clause (p3053 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (51, false) :=
    use_clause (p3036 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (38, true) :=
    use_clause (p137 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h7 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h8 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (7, true) :=
    use_clause (p24 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h10 : LitSat F.assign (29, true) :=
    use_clause (p18 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h11 : LitSat F.assign (17, false) :=
    use_clause (p3063 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h12 : LitSat F.assign (6, true) :=
    use_clause (p16 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h13 : LitSat F.assign (99, false) :=
    use_clause (p1880 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h14 : LitSat F.assign (33, false) :=
    use_clause (p1680 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        True.intro⟩
  exact use_clause (p152 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3065 : CNF.Clause Nat := [(62, true), (39, true)]
theorem p3065 (F : Frame G 4) : c3065.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (62, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (51, false) :=
    use_clause (p3036 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h2 : LitSat F.assign (40, true) :=
    use_clause (p138 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p139 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h4 : LitSat F.assign (38, true) :=
    use_clause (p137 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h5 : LitSat F.assign (98, false) :=
    use_clause (p3053 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (86, true) :=
    use_clause (p3061 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h8 : LitSat F.assign (22, false) :=
    use_clause (p3060 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (18, true) :=
    use_clause (p3064 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h10 : LitSat F.assign (99, false) :=
    use_clause (p1963 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        True.intro⟩
  have h11 : LitSat F.assign (88, true) :=
    use_clause (p265 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h12 : LitSat F.assign (33, true) :=
    use_clause (p152 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h13 : LitSat F.assign (11, true) :=
    use_clause (p158 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (21, false) :=
    use_clause (p1442 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h15 : LitSat F.assign (10, true) :=
    use_clause (p148 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h16 : LitSat F.assign (9, false) :=
    use_clause (p1450 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h17 : LitSat F.assign (31, true) :=
    use_clause (p145 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  have h18 : LitSat F.assign (29, false) :=
    use_clause (p1363 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h19 : LitSat F.assign (7, false) :=
    use_clause (p1478 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  exact use_clause (p21 F)
      ⟨fun h => False.elim (unit_incompatible h19 h),
        fun h => False.elim (unit_incompatible h18 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
def c3066 : CNF.Clause Nat := [(18, false), (33, true), (50, false), (38, false), (40, false), (98, true), (39, true)]
theorem p3066 (F : Frame G 4) : c3066.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (18, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (33, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, true) :=
    use_clause (p3065 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, false) :=
    use_clause (p3036 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h4 : LitSat F.assign (99, false) :=
    use_clause (p1963 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (88, true) :=
    use_clause (p265 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h6 : LitSat F.assign (22, true) :=
    use_clause (p152 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (9, false) :=
    use_clause (p1473 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h8 : LitSat F.assign (21, false) :=
    use_clause (p1328 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (31, true) :=
    use_clause (p145 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h10 : LitSat F.assign (10, true) :=
    use_clause (p148 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1482 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
def c3067 : CNF.Clause Nat := [(99, true), (50, false), (86, false), (38, false), (40, false), (98, true), (62, false)]
theorem p3067 (F : Frame G 4) : c3067.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (33, false) :=
    use_clause (p1723 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h3 : LitSat F.assign (88, true) :=
    use_clause (p265 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h4 : LitSat F.assign (11, true) :=
    use_clause (p155 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (9, false) :=
    use_clause (p1473 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (21, false) :=
    use_clause (p1442 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h7 : LitSat F.assign (31, true) :=
    use_clause (p145 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h8 : LitSat F.assign (10, true) :=
    use_clause (p148 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1482 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c3068 : CNF.Clause Nat := [(50, false), (86, false), (38, false), (40, false), (98, true), (39, true)]
theorem p3068 (F : Frame G 4) : c3068.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, true) :=
    use_clause (p3065 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, false) :=
    use_clause (p3036 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (33, false) :=
    use_clause (p1723 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (18, false) :=
    use_clause (p3066 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h6 : LitSat F.assign (99, true) :=
    use_clause (p3067 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h7 : LitSat F.assign (10, false) :=
    use_clause (p1652 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (7, false) :=
    use_clause (p1738 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h9 : LitSat F.assign (21, true) :=
    use_clause (p148 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (29, true) :=
    use_clause (p28 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h11 : LitSat F.assign (27, false) :=
    use_clause (p1755 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h12 : LitSat F.assign (5, false) :=
    use_clause (p1666 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h13 : LitSat F.assign (6, false) :=
    use_clause (p1739 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h14 : LitSat F.assign (17, false) :=
    use_clause (p1415 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  exact use_clause (p83 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n5 h),
        True.intro⟩
def c3069 : CNF.Clause Nat := [(99, false), (86, false), (38, false), (40, false), (98, true), (39, true)]
theorem p3069 (F : Frame G 4) : c3069.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (50, false) :=
    use_clause (p3068 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (62, true) :=
    use_clause (p3065 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (51, false) :=
    use_clause (p3036 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h5 : LitSat F.assign (10, false) :=
    use_clause (p1652 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h6 : LitSat F.assign (21, true) :=
    use_clause (p148 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (27, false) :=
    use_clause (p1755 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  have h8 : LitSat F.assign (5, false) :=
    use_clause (p1666 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n0 h),
        True.intro⟩
  exact use_clause (p12 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3070 : CNF.Clause Nat := [(17, true), (86, false), (38, false), (40, false), (98, true), (39, true)]
theorem p3070 (F : Frame G 4) : c3070.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (17, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, true) :=
    use_clause (p3065 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h3 : LitSat F.assign (99, false) :=
    use_clause (p3069 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, true) :=
    use_clause (p265 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (9, false) :=
    use_clause (p1473 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h6 : LitSat F.assign (31, true) :=
    use_clause (p145 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (10, false) :=
    use_clause (p1482 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h8 : LitSat F.assign (21, true) :=
    use_clause (p148 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (50, false) :=
    use_clause (p3068 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        True.intro⟩
  have h10 : LitSat F.assign (51, false) :=
    use_clause (p3036 F)
      ⟨fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h11 : LitSat F.assign (6, true) :=
    use_clause (p17 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h12 : LitSat F.assign (7, false) :=
    use_clause (p1441 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h13 : LitSat F.assign (18, true) :=
    use_clause (p115 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        True.intro⟩
  have h14 : LitSat F.assign (33, false) :=
    use_clause (p2057 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h15 : LitSat F.assign (22, false) :=
    use_clause (p1328 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p152 F)
      ⟨fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3071 : CNF.Clause Nat := [(86, false), (38, false), (40, false), (98, true), (39, true)]
theorem p3071 (F : Frame G 4) : c3071.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, true) :=
    use_clause (p3065 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, false) :=
    use_clause (p3036 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, false) :=
    use_clause (p3068 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, false) :=
    use_clause (p3069 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (88, true) :=
    use_clause (p265 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (9, false) :=
    use_clause (p1473 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h8 : LitSat F.assign (31, true) :=
    use_clause (p145 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h9 : LitSat F.assign (10, false) :=
    use_clause (p1482 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h10 : LitSat F.assign (21, true) :=
    use_clause (p148 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (17, true) :=
    use_clause (p3070 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h12 : LitSat F.assign (5, false) :=
    use_clause (p1479 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h13 : LitSat F.assign (22, false) :=
    use_clause (p1324 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (27, true) :=
    use_clause (p12 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h15 : LitSat F.assign (33, true) :=
    use_clause (p152 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1356 F)
      ⟨fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3072 : CNF.Clause Nat := [(86, true), (40, false), (98, true), (39, true)]
theorem p3072 (F : Frame G 4) : c3072.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (86, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, true) :=
    use_clause (p3065 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, false) :=
    use_clause (p3036 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (88, true) :=
    use_clause (p263 F)
      ⟨fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (99, true) :=
    use_clause (p267 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        True.intro⟩
  have h6 : LitSat F.assign (9, false) :=
    use_clause (p1473 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (5, false) :=
    use_clause (p2059 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h8 : LitSat F.assign (31, true) :=
    use_clause (p147 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (50, false) :=
    use_clause (p1801 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h10 : LitSat F.assign (10, false) :=
    use_clause (p1482 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h11 : LitSat F.assign (27, true) :=
    use_clause (p12 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h12 : LitSat F.assign (21, true) :=
    use_clause (p148 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  exact use_clause (p1755 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
def c3073 : CNF.Clause Nat := [(21, false), (99, false), (38, true), (86, false), (40, false), (87, false), (39, true)]
theorem p3073 (F : Frame G 4) : c3073.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (21, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (62, true) :=
    use_clause (p3065 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h2 : LitSat F.assign (51, false) :=
    use_clause (p3036 F)
      ⟨fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p140 F)
      ⟨fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (33, false) :=
    use_clause (p1723 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n5 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (27, false) :=
    use_clause (p1755 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h6 : LitSat F.assign (5, true) :=
    use_clause (p13 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h7 : LitSat F.assign (88, false) :=
    use_clause (p2059 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (n5 h),
        True.intro⟩
  have h8 : LitSat F.assign (26, false) :=
    use_clause (p1964 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h9 : LitSat F.assign (22, true) :=
    use_clause (p153 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (15, true) :=
    use_clause (p10 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n6 h),
        True.intro⟩
  exact use_clause (p1970 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
def c3074 : CNF.Clause Nat := [(5, false), (10, false), (99, false), (38, true), (86, false), (40, false), (87, false), (39, true)]
theorem p3074 (F : Frame G 4) : c3074.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (5, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (10, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (38, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (87, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (62, true) :=
    use_clause (p3065 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        True.intro⟩
  have h2 : LitSat F.assign (51, false) :=
    use_clause (p3036 F)
      ⟨fun h => h,
        fun h => False.elim (n7 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p140 F)
      ⟨fun h => False.elim (n3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h4 : LitSat F.assign (33, false) :=
    use_clause (p1723 F)
      ⟨fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        fun h => h,
        True.intro⟩
  have h5 : LitSat F.assign (88, false) :=
    use_clause (p2059 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (n6 h),
        True.intro⟩
  have h6 : LitSat F.assign (15, false) :=
    use_clause (p1759 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n5 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n6 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h7 : LitSat F.assign (11, true) :=
    use_clause (p156 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h8 : LitSat F.assign (22, true) :=
    use_clause (p153 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (26, true) :=
    use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n7 h),
        True.intro⟩
  exact use_clause (p1566 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n6 h),
        True.intro⟩
def c3075 : CNF.Clause Nat := [(88, true), (99, false), (40, false), (98, true), (39, true)]
theorem p3075 (F : Frame G 4) : c3075.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (88, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (86, true) :=
    use_clause (p3072 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h2 : LitSat F.assign (38, false) :=
    use_clause (p3071 F)
      ⟨fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, false) :=
    use_clause (p3036 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h5 : LitSat F.assign (21, false) :=
    use_clause (p3073 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h6 : LitSat F.assign (10, true) :=
    use_clause (p148 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (5, false) :=
    use_clause (p3074 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (27, true) :=
    use_clause (p13 F)
      ⟨fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h9 : LitSat F.assign (62, true) :=
    use_clause (p3065 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h10 : LitSat F.assign (50, true) :=
    use_clause (p140 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h11 : LitSat F.assign (31, false) :=
    use_clause (p1801 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n1 h),
        True.intro⟩
  have h12 : LitSat F.assign (33, false) :=
    use_clause (p1723 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        True.intro⟩
  have h13 : LitSat F.assign (11, true) :=
    use_clause (p156 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h14 : LitSat F.assign (22, true) :=
    use_clause (p153 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h15 : LitSat F.assign (9, true) :=
    use_clause (p219 F)
      ⟨fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h16 : LitSat F.assign (15, false) :=
    use_clause (p1365 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h17 : LitSat F.assign (26, false) :=
    use_clause (p1966 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h14 h),
        True.intro⟩
  exact use_clause (p10 F)
      ⟨fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h17 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n4 h),
        True.intro⟩
def c3076 : CNF.Clause Nat := [(99, false), (40, false), (98, true), (39, true)]
theorem p3076 (F : Frame G 4) : c3076.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (62, true) :=
    use_clause (p3065 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h3 : LitSat F.assign (86, true) :=
    use_clause (p3072 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h4 : LitSat F.assign (51, false) :=
    use_clause (p3036 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h5 : LitSat F.assign (38, false) :=
    use_clause (p3071 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (50, true) :=
    use_clause (p140 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
  have h7 : LitSat F.assign (33, false) :=
    use_clause (p1723 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (31, false) :=
    use_clause (p1801 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (n0 h),
        True.intro⟩
  have h9 : LitSat F.assign (21, false) :=
    use_clause (p3073 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h10 : LitSat F.assign (10, true) :=
    use_clause (p148 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (88, true) :=
    use_clause (p3075 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h12 : LitSat F.assign (9, false) :=
    use_clause (p1473 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h11 h),
        True.intro⟩
  have h13 : LitSat F.assign (29, false) :=
    use_clause (p1710 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => h,
        True.intro⟩
  have h14 : LitSat F.assign (11, true) :=
    use_clause (p223 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (n2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h15 : LitSat F.assign (18, false) :=
    use_clause (p1774 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n1 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
  have h16 : LitSat F.assign (26, false) :=
    use_clause (p1481 F)
      ⟨fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p50 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h16 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h15 h),
        fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h4 h),
        True.intro⟩
def c3077 : CNF.Clause Nat := [(40, false), (98, true), (39, true)]
theorem p3077 (F : Frame G 4) : c3077.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (40, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (62, true) :=
    use_clause (p3065 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h3 : LitSat F.assign (51, false) :=
    use_clause (p3036 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        True.intro⟩
  have h4 : LitSat F.assign (86, true) :=
    use_clause (p3072 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h5 : LitSat F.assign (38, false) :=
    use_clause (p3071 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h6 : LitSat F.assign (50, true) :=
    use_clause (p140 F)
      ⟨fun h => False.elim (unit_incompatible h5 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h7 : LitSat F.assign (33, false) :=
    use_clause (p1723 F)
      ⟨fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => h,
        True.intro⟩
  have h8 : LitSat F.assign (99, false) :=
    use_clause (p3076 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        True.intro⟩
  have h9 : LitSat F.assign (88, true) :=
    use_clause (p265 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (11, true) :=
    use_clause (p155 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h7 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (9, false) :=
    use_clause (p1473 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h12 : LitSat F.assign (31, true) :=
    use_clause (p145 F)
      ⟨fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h8 h),
        True.intro⟩
  have h13 : LitSat F.assign (10, false) :=
    use_clause (p1482 F)
      ⟨fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h9 h),
        True.intro⟩
  have h14 : LitSat F.assign (21, false) :=
    use_clause (p1483 F)
      ⟨fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  exact use_clause (p148 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h14 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3078 : CNF.Clause Nat := [(31, false), (11, false), (22, false), (88, false), (86, false), (50, false), (38, false), (98, true), (62, false)]
theorem p3078 (F : Frame G 4) : c3078.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (31, false) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (11, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (22, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (88, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have n5 : ¬ LitSat F.assign (50, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))
  have n6 : ¬ LitSat F.assign (38, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))
  have n7 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))))))
  have n8 : ¬ LitSat F.assign (62, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (21, false) :=
    use_clause (p1483 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  have h2 : LitSat F.assign (10, false) :=
    use_clause (p1557 F)
      ⟨fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (n0 h),
        fun h => h,
        fun h => False.elim (n6 h),
        fun h => False.elim (n5 h),
        fun h => False.elim (n8 h),
        True.intro⟩
  exact use_clause (p148 F)
      ⟨fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n7 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
def c3079 : CNF.Clause Nat := [(33, true), (99, true), (86, false), (98, true), (39, true)]
theorem p3079 (F : Frame G 4) : c3079.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (33, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have n4 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (88, true) :=
    use_clause (p265 F)
      ⟨fun h => h,
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h2 : LitSat F.assign (51, false) :=
    use_clause (p3036 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h3 : LitSat F.assign (40, false) :=
    use_clause (p3077 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (n4 h),
        True.intro⟩
  have h4 : LitSat F.assign (50, true) :=
    use_clause (p135 F)
      ⟨fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
  have h6 : LitSat F.assign (87, true) :=
    use_clause (p266 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (62, true) :=
    use_clause (p3065 F)
      ⟨fun h => h,
        fun h => False.elim (n4 h),
        True.intro⟩
  have h8 : LitSat F.assign (22, true) :=
    use_clause (p152 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h9 : LitSat F.assign (11, true) :=
    use_clause (p155 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h10 : LitSat F.assign (31, false) :=
    use_clause (p3078 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h8 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h11 : LitSat F.assign (9, true) :=
    use_clause (p145 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n3 h),
        fun h => False.elim (n1 h),
        True.intro⟩
  have h12 : LitSat F.assign (26, false) :=
    use_clause (p1486 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h13 : LitSat F.assign (15, false) :=
    use_clause (p1487 F)
      ⟨fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h1 h),
        fun h => False.elim (unit_incompatible h9 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  exact use_clause (p8 F)
      ⟨fun h => False.elim (unit_incompatible h13 h),
        fun h => False.elim (unit_incompatible h12 h),
        fun h => False.elim (n4 h),
        fun h => False.elim (unit_incompatible h3 h),
        True.intro⟩
def c3080 : CNF.Clause Nat := [(99, true), (86, false), (98, true), (39, true)]
theorem p3080 (F : Frame G 4) : c3080.eval F.assign = true := by
  apply Classical.byContradiction
  intro absent
  have n0 : ¬ LitSat F.assign (99, true) :=
    literal_denied absent (List.mem_cons_self ..)
  have n1 : ¬ LitSat F.assign (86, false) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  have n2 : ¬ LitSat F.assign (98, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
  have n3 : ¬ LitSat F.assign (39, true) :=
    literal_denied absent (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))))
  have h0 : LitSat F.assign (110, false) :=
    use_clause (p2857 F)
      ⟨fun h => h,
        True.intro⟩
  have h1 : LitSat F.assign (51, false) :=
    use_clause (p3036 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h2 : LitSat F.assign (40, false) :=
    use_clause (p3077 F)
      ⟨fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h3 : LitSat F.assign (50, true) :=
    use_clause (p135 F)
      ⟨fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  have h4 : LitSat F.assign (38, true) :=
    use_clause (p134 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        fun h => False.elim (unit_incompatible h2 h),
        True.intro⟩
  have h5 : LitSat F.assign (62, true) :=
    use_clause (p3065 F)
      ⟨fun h => h,
        fun h => False.elim (n3 h),
        True.intro⟩
  have h6 : LitSat F.assign (88, true) :=
    use_clause (p265 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h7 : LitSat F.assign (33, true) :=
    use_clause (p3079 F)
      ⟨fun h => h,
        fun h => False.elim (n0 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (n2 h),
        fun h => False.elim (n3 h),
        True.intro⟩
  have h8 : LitSat F.assign (10, false) :=
    use_clause (p1493 F)
      ⟨fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        True.intro⟩
  have h9 : LitSat F.assign (7, false) :=
    use_clause (p2027 F)
      ⟨fun h => h,
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        fun h => False.elim (unit_incompatible h7 h),
        True.intro⟩
  have h10 : LitSat F.assign (21, true) :=
    use_clause (p148 F)
      ⟨fun h => False.elim (unit_incompatible h8 h),
        fun h => h,
        fun h => False.elim (n2 h),
        fun h => False.elim (unit_incompatible h0 h),
        True.intro⟩
  have h11 : LitSat F.assign (29, true) :=
    use_clause (p23 F)
      ⟨fun h => False.elim (unit_incompatible h9 h),
        fun h => h,
        fun h => False.elim (unit_incompatible h2 h),
        fun h => False.elim (unit_incompatible h1 h),
        True.intro⟩
  exact use_clause (p1418 F)
      ⟨fun h => False.elim (unit_incompatible h4 h),
        fun h => False.elim (unit_incompatible h3 h),
        fun h => False.elim (unit_incompatible h5 h),
        fun h => False.elim (unit_incompatible h11 h),
        fun h => False.elim (unit_incompatible h10 h),
        fun h => False.elim (n1 h),
        fun h => False.elim (unit_incompatible h6 h),
        True.intro⟩
end Cert44Steps
end Graffiti199Depleted.Catalogue.OrderEleven
