import FramesFromMinimum
import Shore35
import Fused44

namespace Graffiti199Depleted.Catalogue.OrderEleven

open SimpleGraph

universe u
variable {V : Type u} {G : SimpleGraph V} [Fintype V] [DecidableEq V] [DecidableRel G.Adj]

/-- Close the order-eleven crossing-failure branch with independent
degree-three vertices under the previous minimum-order hypothesis. -/
theorem traceable_at_order_eleven_of_crossing_failure_of_independent_cubics
    (order : Fintype.card V = 11)
    (smaller : SmallerAtThree.{u} (Fintype.card V))
    (conn : ConnectivityAtLeast G 3) (budget : treeNumber G ≤ 5)
    (ind : ∀ a b, G.degree a = 3 → G.degree b = 3 → ¬ G.Adj a b)
    (fail : ¬ CrossingBetweenSurvivingEdges G) : Traceable G := by
  classical
  by_contra no
  have frames := order_eleven_frames_of_crossing_failure_of_independent_cubics order smaller conn
    budget no ind fail
  exact frames.elim (fun h => h.elim caseContradiction35) (fun h => h.elim caseContradiction44)

/-- Under the frozen lower-order premise, an independent-cubic crossing
failure without a spanning path must have at least twelve vertices. -/
theorem order_ge_twelve_of_crossing_failure
    (smaller : SmallerAtThree.{u} (Fintype.card V))
    (conn : ConnectivityAtLeast G 3) (budget : treeNumber G ≤ 5)
    (order : 5 ≤ Fintype.card V) (no : ¬ Traceable G)
    (ind : ∀ a b, G.degree a = 3 → G.degree b = 3 → ¬ G.Adj a b)
    (fail : ¬ CrossingBetweenSurvivingEdges G) : 12 ≤ Fintype.card V := by
  have low := order_ge_eleven_of_crossing_failure smaller conn budget order no ind fail
  by_contra! small
  exact no (traceable_at_order_eleven_of_crossing_failure_of_independent_cubics (by omega)
    smaller conn budget ind fail)

#print axioms caseContradiction35
#print axioms traceable_of_three_five_shores
#print axioms traceable_of_four_four_shores
#print axioms traceable_at_order_eleven_of_crossing_failure_of_independent_cubics
#print axioms order_ge_twelve_of_crossing_failure

end Graffiti199Depleted.Catalogue.OrderEleven
