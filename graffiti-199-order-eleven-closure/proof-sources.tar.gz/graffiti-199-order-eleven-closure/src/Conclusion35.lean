import Case35Part14
namespace Graffiti199Depleted.Catalogue.OrderEleven
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj]
theorem caseContradiction35 (F : Frame G 3) : False := by
  have h : false = true := Cert35Steps.p5026 F
  contradiction
#print axioms caseContradiction35
end Graffiti199Depleted.Catalogue.OrderEleven
