import StarContacts
import Std.Tactic.BVDecide.LRAT.Checker

namespace Graffiti199Depleted.Catalogue.OrderEleven

open SimpleGraph Std.Sat

abbrev Vertex := Fin 11
abbrev Port := Fin 3

def port (p : Port) : Vertex := ⟨p.val,by have := p.isLt; omega⟩
def IsPort (v : Vertex) : Prop := v.val < 3
instance (v : Vertex) : Decidable (IsPort v) := inferInstanceAs (Decidable (v.val < 3))

def InSide (k : Nat) (left : Bool) (v : Vertex) : Prop :=
  if left then 3 ≤ v.val ∧ v.val < 3+k else 3+k ≤ v.val
instance (k : Nat) (b : Bool) (v : Vertex) : Decidable (InSide k b v) := by
  unfold InSide
  infer_instance

def sideVertices (k : Nat) (b : Bool) : List Vertex :=
  (List.finRange 11).filter fun v => decide (InSide k b v)

theorem mem_sideVertices {k : Nat} {b : Bool} {v : Vertex} :
    v ∈ sideVertices k b ↔ InSide k b v := by simp [sideVertices]

def Allowed (k : Nat) (u v : Vertex) : Prop :=
  u ≠ v ∧ ((IsPort u ∧ ¬ IsPort v) ∨ (¬ IsPort u ∧ IsPort v) ∨
    (InSide k true u ∧ InSide k true v) ∨ (InSide k false u ∧ InSide k false v))

instance (k : Nat) (u v : Vertex) : Decidable (Allowed k u v) := by unfold Allowed; infer_instance

theorem allowed_symm (k : Nat) (u v : Vertex) : Allowed k u v ↔ Allowed k v u := by
  unfold Allowed
  rw [ne_comm]
  tauto

theorem allowed_port_side {k : Nat} {p : Port} {v : Vertex} {b : Bool}
    (hv : InSide k b v) : Allowed k (port p) v := by
  have hp : IsPort (port p) := p.isLt
  have hn : ¬ IsPort v := by unfold IsPort InSide at *; split at hv <;> omega
  exact ⟨fun eq => hn (eq ▸ hp),Or.inl ⟨hp,hn⟩⟩

theorem allowed_same_side {k : Nat} {x y : Vertex} {b : Bool}
    (hx : InSide k b x) (hy : InSide k b y) (ne : x ≠ y) : Allowed k x y := by
  cases b
  · exact ⟨ne,Or.inr (Or.inr (Or.inr ⟨hx,hy⟩))⟩
  · exact ⟨ne,Or.inr (Or.inr (Or.inl ⟨hx,hy⟩))⟩

/-- DIMACS variable identifiers use the two sorted labels. -/
def edgeVar (u v : Vertex) : Nat := 11 * min u.val v.val + max u.val v.val + 1

theorem edgeVar_symm (u v : Vertex) : edgeVar u v = edgeVar v u := by
  simp [edgeVar,min_comm,max_comm]

private theorem edgeVar_identifies {x y u v : Vertex}
    (h : edgeVar x y = edgeVar u v) : (x = u ∧ y = v) ∨ (x = v ∧ y = u) := by
  have minMax {a b c d : Vertex} (hab : a.val ≤ b.val) (hcd : c.val ≤ d.val)
      (e : edgeVar a b = edgeVar c d) : a = c ∧ b = d := by
    simp only [edgeVar,min_eq_left hab,max_eq_right hab,min_eq_left hcd,max_eq_right hcd] at e
    have hb := b.isLt
    have hd := d.isLt
    exact ⟨Fin.ext (by omega),Fin.ext (by omega)⟩
  rcases le_total x.val y.val with hxy|hyx <;> rcases le_total u.val v.val with huv|hvu
  · exact Or.inl (minMax hxy huv h)
  · exact Or.inr (minMax hxy hvu (h.trans (edgeVar_symm u v)))
  · have e := minMax hyx huv ((edgeVar_symm y x).trans h)
    exact Or.inr ⟨e.2,e.1⟩
  · have e := minMax hyx hvu (((edgeVar_symm y x).trans h).trans (edgeVar_symm u v))
    exact Or.inl ⟨e.2,e.1⟩

/-- A labeled input to the finite proof. All the stated conditions will
be derived from the actual cut in the graph lift. -/
structure Frame {V : Type*} (G : SimpleGraph V) [Fintype V] [DecidableRel G.Adj]
    (k : Nat) where
  name : Vertex ≃ V
  allowed : ∀ x y : Vertex, ¬ IsPort x → G.Adj (name x) (name y) → Allowed k x y
  lower : ∀ x : Vertex, ¬ IsPort x → 3 ≤ G.degree (name x)
  cubic : ∀ x y : V, G.degree x = 3 → G.degree y = 3 → ¬ G.Adj x y
  matchPorts : ∀ b : Bool, ∃ m : Port ↪ Vertex,
    (∀ p : Port, InSide k b (m p)) ∧ (∀ p : Port, G.Adj (name (port p)) (name (m p)))
  fixedMatching : ∀ (b : Bool) (p : Port) (v : Vertex),
    v.val = 3 + (if b then 0 else k) + p.val → G.Adj (name (port p)) (name v)
  sidesConnected : ∀ b : Bool, (G.induce {x | InSide k b (name.symm x)}).Connected
  budget : treeNumber G ≤ 5
  noPath : ¬ Traceable G

variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj] {k : Nat}

noncomputable def Frame.assign (F : Frame G k) (i : Nat) : Bool := by
  classical
  exact decide (∃ x y : Vertex, i = edgeVar x y ∧ Allowed k x y ∧ G.Adj (F.name x) (F.name y))

theorem Frame.assign_edge (F : Frame G k) (x y : Vertex) :
    F.assign (edgeVar x y) = true ↔ Allowed k x y ∧ G.Adj (F.name x) (F.name y) := by
  classical
  simp only [Frame.assign,decide_eq_true_eq]
  constructor
  · rintro ⟨u,v,eq,h,adj⟩
    rcases edgeVar_identifies eq with ⟨rfl,rfl⟩|⟨rfl,rfl⟩
    · exact ⟨h,adj⟩
    · exact ⟨(allowed_symm _ _ _).mp h,adj.symm⟩
  · intro h
    exact ⟨x,y,rfl,h⟩

/-- A clause with an explicit graph-theoretic reason. -/
inductive Rule where
  | matched (left : Bool) (p : Port) (v : Vertex)
  | degree (v : Vertex) (exceptions : List Vertex)
  | cubic (u v : Vertex) (exceptionsU exceptionsV : List Vertex)
  | hall (left : Bool) (selected : List Port) (exceptions : List Vertex)
  | connected (left : Bool) (selected : List Vertex)
  | star (p : Port) (leaves : List Vertex)
  | path (vertices : List Vertex)
deriving Inhabited

def Rule.Valid (k : Nat) : Rule → Prop
  | .matched b p v => InSide k b v ∧ v.val = 3 + (if b then 0 else k) + p.val
  | .degree v exceptions => ¬ IsPort v ∧ exceptions.length ≤ 2
  | .cubic u v exceptionsU exceptionsV =>
      ¬ IsPort u ∧ ¬ IsPort v ∧ exceptionsU.length ≤ 3 ∧ exceptionsV.length ≤ 3
  | .hall _ ports exceptions => ports.Nodup ∧ exceptions.length < ports.length
  | .connected left selected =>
      (∃ v ∈ sideVertices k left, v ∈ selected) ∧
      (∃ v ∈ sideVertices k left, v ∉ selected) ∧
      (∀ v ∈ selected, v ∈ sideVertices k left)
  | .star _ leaves => leaves.length = 5 ∧ leaves.Nodup ∧ (∀ v ∈ leaves, ¬ IsPort v)
  | .path vertices => vertices.length = 11 ∧ vertices.Nodup

instance (k : Nat) (r : Rule) : Decidable (r.Valid k) := by
  cases r <;> unfold Rule.Valid <;> infer_instance

def positive (u v : Vertex) : Literal Nat := (edgeVar u v,true)
def negative (u v : Vertex) : Literal Nat := (edgeVar u v,false)

def beyond (k : Nat) (u : Vertex) (ex : List Vertex) : List Vertex :=
  (List.finRange 11).filter (fun v => decide (Allowed k u v ∧ v ∉ ex))

theorem mem_beyond {k : Nat} {u v : Vertex} {ex : List Vertex} :
    v ∈ beyond k u ex ↔ Allowed k u v ∧ v ∉ ex := by simp [beyond]

def Rule.clause (k : Nat) : Rule → CNF.Clause Nat
  | .matched _ p v => [positive (port p) v]
  | .degree u excluded => (beyond k u excluded).map (positive u)
  | .cubic u v eu ev => negative u v :: ((beyond k u eu).map (positive u) ++
      (beyond k v ev).map (positive v))
  | .hall left ports excluded => ports.flatMap fun p =>
      ((sideVertices k left).filter (fun v => decide (v ∉ excluded))).map (positive (port p))
  | .connected left selected => selected.flatMap fun u =>
      ((sideVertices k left).filter (fun v => decide (v ∉ selected))).map (positive u)
  | .star p leaves => (leaves.map (negative (port p))) ++ (leaves.flatMap fun u =>
      ((leaves.filter fun v => decide (u.val < v.val ∧ Allowed k u v))).map (positive u))
  | .path vertices => (vertices.zip vertices.tail).map (fun uv => negative uv.1 uv.2)

def rulesCNF (k : Nat) (rules : List Rule) : CNF Nat := rules.map (Rule.clause k)

#print axioms Frame.assign_edge

end Graffiti199Depleted.Catalogue.OrderEleven
