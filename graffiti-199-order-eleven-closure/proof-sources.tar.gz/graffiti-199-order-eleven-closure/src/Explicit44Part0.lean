import Local44Part7
import ExplicitRup
namespace Graffiti199Depleted.Catalogue.OrderEleven
namespace Cert44Steps
open Std.Sat
set_option maxRecDepth 4096
set_option maxHeartbeats 0
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj]
def c2401 : CNF.Clause Nat := [(21,true), (50,false), (86,true), (38,false), (62,false), (99,false), (110,false)]
theorem p2401 (F : Frame G 4) : c2401.eval F.assign = true := by
  apply explicit_rup F.assign c2401 [c2397, c2129, c2389, c2347, c2398, c2399, c143, c2400, c181, c1710] [(87,true), (30,false), (51,false), (98,false), (40,false), (19,false), (88,true), (29,true), (10,true)]
  · exact sat_cons (p2397 F) ( sat_cons (p2129 F) ( sat_cons (p2389 F) ( sat_cons (p2347 F) ( sat_cons (p2398 F) ( sat_cons (p2399 F) ( sat_cons (p143 F) ( sat_cons (p2400 F) ( sat_cons (p181 F) ( sat_cons (p1710 F) (rfl))))))))))
  · rfl
def c2402 : CNF.Clause Nat := [(40,true), (50,false), (86,true), (38,false), (62,false), (99,false), (110,false)]
theorem p2402 (F : Frame G 4) : c2402.eval F.assign = true := by
  apply explicit_rup F.assign c2402 [c2401, c2397, c2129, c2389, c2347, c2399, c143, c2400, c2176, c1705, c147] [(21,true), (87,true), (30,false), (51,false), (98,false), (19,false), (88,true), (29,true), (31,false), (9,false)]
  · exact sat_cons (p2401 F) ( sat_cons (p2397 F) ( sat_cons (p2129 F) ( sat_cons (p2389 F) ( sat_cons (p2347 F) ( sat_cons (p2399 F) ( sat_cons (p143 F) ( sat_cons (p2400 F) ( sat_cons (p2176 F) ( sat_cons (p1705 F) ( sat_cons (p147 F) (rfl)))))))))))
  · rfl
def c2403 : CNF.Clause Nat := [(50,false), (86,true), (38,false), (62,false), (99,false), (110,false)]
theorem p2403 (F : Frame G 4) : c2403.eval F.assign = true := by
  apply explicit_rup F.assign c2403 [c2389, c2347, c2129, c2397, c2401, c2402, c1963, c1801, c1773, c147, c28, c1473, c1419, c143] [(51,false), (98,false), (30,false), (87,true), (21,true), (40,true), (18,false), (31,false), (7,false), (9,true), (29,true), (88,false), (19,false)]
  · exact sat_cons (p2389 F) ( sat_cons (p2347 F) ( sat_cons (p2129 F) ( sat_cons (p2397 F) ( sat_cons (p2401 F) ( sat_cons (p2402 F) ( sat_cons (p1963 F) ( sat_cons (p1801 F) ( sat_cons (p1773 F) ( sat_cons (p147 F) ( sat_cons (p28 F) ( sat_cons (p1473 F) ( sat_cons (p1419 F) ( sat_cons (p143 F) (rfl))))))))))))))
  · rfl
def c2404 : CNF.Clause Nat := [(87,false), (38,false), (39,true), (62,false), (99,false), (110,false)]
theorem p2404 (F : Frame G 4) : c2404.eval F.assign = true := by
  apply explicit_rup F.assign c2404 [c2389, c2396, c2403, c135, c2093, c12, c2059, c1670, c2183, c143, c1981, c120, c17, c2017] [(51,false), (86,false), (50,false), (40,true), (27,false), (5,true), (88,false), (18,false), (19,false), (30,true), (6,false), (7,true), (17,true)]
  · exact sat_cons (p2389 F) ( sat_cons (p2396 F) ( sat_cons (p2403 F) ( sat_cons (p135 F) ( sat_cons (p2093 F) ( sat_cons (p12 F) ( sat_cons (p2059 F) ( sat_cons (p1670 F) ( sat_cons (p2183 F) ( sat_cons (p143 F) ( sat_cons (p1981 F) ( sat_cons (p120 F) ( sat_cons (p17 F) ( sat_cons (p2017 F) (rfl))))))))))))))
  · rfl
def c2405 : CNF.Clause Nat := [(6,false), (30,false), (38,false), (39,true), (62,false), (99,false), (110,false)]
theorem p2405 (F : Frame G 4) : c2405.eval F.assign = true := by
  apply explicit_rup F.assign c2405 [c2404, c2389, c2396, c2403, c135, c2347, c1768, c2217, c150, c147, c1287] [(87,false), (51,false), (86,false), (50,false), (40,true), (98,false), (21,false), (31,false), (10,true), (9,true)]
  · exact sat_cons (p2404 F) ( sat_cons (p2389 F) ( sat_cons (p2396 F) ( sat_cons (p2403 F) ( sat_cons (p135 F) ( sat_cons (p2347 F) ( sat_cons (p1768 F) ( sat_cons (p2217 F) ( sat_cons (p150 F) ( sat_cons (p147 F) ( sat_cons (p1287 F) (rfl)))))))))))
  · rfl
def c2406 : CNF.Clause Nat := [(30,false), (38,false), (39,true), (62,false), (99,false), (110,false)]
theorem p2406 (F : Frame G 4) : c2406.eval F.assign = true := by
  apply explicit_rup F.assign c2406 [c2396, c2404, c261, c2389, c2403, c135, c2347, c2405, c17, c2017, c118, c2127, c147, c1354, c2218, c12] [(86,false), (87,false), (88,true), (51,false), (50,false), (40,true), (98,false), (6,false), (17,true), (7,false), (29,true), (9,false), (31,true), (27,false), (5,false)]
  · exact sat_cons (p2396 F) ( sat_cons (p2404 F) ( sat_cons (p261 F) ( sat_cons (p2389 F) ( sat_cons (p2403 F) ( sat_cons (p135 F) ( sat_cons (p2347 F) ( sat_cons (p2405 F) ( sat_cons (p17 F) ( sat_cons (p2017 F) ( sat_cons (p118 F) ( sat_cons (p2127 F) ( sat_cons (p147 F) ( sat_cons (p1354 F) ( sat_cons (p2218 F) ( sat_cons (p12 F) (rfl))))))))))))))))
  · rfl
def c2407 : CNF.Clause Nat := [(38,false), (39,true), (62,false), (99,false), (110,false)]
theorem p2407 (F : Frame G 4) : c2407.eval F.assign = true := by
  apply explicit_rup F.assign c2407 [c2389, c2347, c2396, c2403, c135, c2404, c261, c2406, c144, c1662, c150, c2228, c1322, c1325, c147, c113, c17, c2124] [(51,false), (98,false), (86,false), (50,false), (40,true), (87,false), (88,true), (30,false), (19,true), (10,false), (21,true), (9,false), (17,false), (18,false), (31,true), (29,true), (6,true)]
  · exact sat_cons (p2389 F) ( sat_cons (p2347 F) ( sat_cons (p2396 F) ( sat_cons (p2403 F) ( sat_cons (p135 F) ( sat_cons (p2404 F) ( sat_cons (p261 F) ( sat_cons (p2406 F) ( sat_cons (p144 F) ( sat_cons (p1662 F) ( sat_cons (p150 F) ( sat_cons (p2228 F) ( sat_cons (p1322 F) ( sat_cons (p1325 F) ( sat_cons (p147 F) ( sat_cons (p113 F) ( sat_cons (p17 F) ( sat_cons (p2124 F) (rfl))))))))))))))))))
  · rfl
def c2408 : CNF.Clause Nat := [(31,false), (19,false), (88,false), (87,true), (39,true), (62,false), (99,false), (110,false)]
theorem p2408 (F : Frame G 4) : c2408.eval F.assign = true := by
  apply explicit_rup F.assign c2408 [c2407, c134, c2389, c140, c2347, c2176, c2031, c150, c2137, c1886, c54] [(38,false), (40,true), (51,false), (50,true), (98,false), (21,false), (7,false), (10,true), (18,false), (26,false)]
  · exact sat_cons (p2407 F) ( sat_cons (p134 F) ( sat_cons (p2389 F) ( sat_cons (p140 F) ( sat_cons (p2347 F) ( sat_cons (p2176 F) ( sat_cons (p2031 F) ( sat_cons (p150 F) ( sat_cons (p2137 F) ( sat_cons (p1886 F) ( sat_cons (p54 F) (rfl)))))))))))
  · rfl
def c2409 : CNF.Clause Nat := [(21,false), (19,false), (87,true), (86,true), (39,true), (62,false), (99,false), (110,false)]
theorem p2409 (F : Frame G 4) : c2409.eval F.assign = true := by
  apply explicit_rup F.assign c2409 [c2407, c134, c2389, c140, c2347, c1309, c1325, c10, c57, c2023] [(38,false), (40,true), (51,false), (50,true), (98,false), (15,false), (18,false), (26,true), (29,true)]
  · exact sat_cons (p2407 F) ( sat_cons (p134 F) ( sat_cons (p2389 F) ( sat_cons (p140 F) ( sat_cons (p2347 F) ( sat_cons (p1309 F) ( sat_cons (p1325 F) ( sat_cons (p10 F) ( sat_cons (p57 F) ( sat_cons (p2023 F) (rfl))))))))))
  · rfl
def c2410 : CNF.Clause Nat := [(19,false), (87,true), (86,true), (39,true), (62,false), (99,false), (110,false)]
theorem p2410 (F : Frame G 4) : c2410.eval F.assign = true := by
  apply explicit_rup F.assign c2410 [c261, c2407, c134, c2389, c140, c2347, c2408, c147, c2409, c150, c1277, c1287, c13, c79, c2168, c2245, c10, c57, c2169] [(88,true), (38,false), (40,true), (51,false), (50,true), (98,false), (31,false), (9,true), (21,false), (10,true), (5,false), (6,false), (27,true), (17,true), (15,false), (29,false), (26,true), (18,true)]
  · exact sat_cons (p261 F) ( sat_cons (p2407 F) ( sat_cons (p134 F) ( sat_cons (p2389 F) ( sat_cons (p140 F) ( sat_cons (p2347 F) ( sat_cons (p2408 F) ( sat_cons (p147 F) ( sat_cons (p2409 F) ( sat_cons (p150 F) ( sat_cons (p1277 F) ( sat_cons (p1287 F) ( sat_cons (p13 F) ( sat_cons (p79 F) ( sat_cons (p2168 F) ( sat_cons (p2245 F) ( sat_cons (p10 F) ( sat_cons (p57 F) ( sat_cons (p2169 F) (rfl)))))))))))))))))))
  · rfl
def c2411 : CNF.Clause Nat := [(87,true), (86,true), (39,true), (62,false), (99,false), (110,false)]
theorem p2411 (F : Frame G 4) : c2411.eval F.assign = true := by
  apply explicit_rup F.assign c2411 [c2407, c134, c2389, c140, c2347, c261, c2410, c144, c2171, c2058, c147] [(38,false), (40,true), (51,false), (50,true), (98,false), (88,true), (19,false), (30,true), (31,false), (9,false)]
  · exact sat_cons (p2407 F) ( sat_cons (p134 F) ( sat_cons (p2389 F) ( sat_cons (p140 F) ( sat_cons (p2347 F) ( sat_cons (p261 F) ( sat_cons (p2410 F) ( sat_cons (p144 F) ( sat_cons (p2171 F) ( sat_cons (p2058 F) ( sat_cons (p147 F) (rfl)))))))))))
  · rfl
def c2412 : CNF.Clause Nat := [(10,false), (86,true), (39,true), (62,false), (99,false), (110,false)]
theorem p2412 (F : Frame G 4) : c2412.eval F.assign = true := by
  apply explicit_rup F.assign c2412 [c2407, c134, c2411, c2347, c2389, c140, c1801, c147, c1473, c2058, c143, c1965, c2225, c10, c52, c2234] [(38,false), (40,true), (87,true), (98,false), (51,false), (50,true), (31,false), (9,true), (88,false), (30,false), (19,true), (26,false), (29,false), (15,true), (7,true)]
  · exact sat_cons (p2407 F) ( sat_cons (p134 F) ( sat_cons (p2411 F) ( sat_cons (p2347 F) ( sat_cons (p2389 F) ( sat_cons (p140 F) ( sat_cons (p1801 F) ( sat_cons (p147 F) ( sat_cons (p1473 F) ( sat_cons (p2058 F) ( sat_cons (p143 F) ( sat_cons (p1965 F) ( sat_cons (p2225 F) ( sat_cons (p10 F) ( sat_cons (p52 F) ( sat_cons (p2234 F) (rfl))))))))))))))))
  · rfl
def c2413 : CNF.Clause Nat := [(86,true), (39,true), (62,false), (99,false), (110,false)]
theorem p2413 (F : Frame G 4) : c2413.eval F.assign = true := by
  apply explicit_rup F.assign c2413 [c2407, c134, c2389, c140, c2347, c2411, c1801, c147, c1473, c2058, c143, c2412, c174, c1755, c13, c2226, c1964, c52, c10, c2234] [(38,false), (40,true), (51,false), (50,true), (98,false), (87,true), (31,false), (9,true), (88,false), (30,false), (19,true), (10,false), (21,true), (27,false), (5,true), (29,false), (26,false), (7,true), (15,true)]
  · exact sat_cons (p2407 F) ( sat_cons (p134 F) ( sat_cons (p2389 F) ( sat_cons (p140 F) ( sat_cons (p2347 F) ( sat_cons (p2411 F) ( sat_cons (p1801 F) ( sat_cons (p147 F) ( sat_cons (p1473 F) ( sat_cons (p2058 F) ( sat_cons (p143 F) ( sat_cons (p2412 F) ( sat_cons (p174 F) ( sat_cons (p1755 F) ( sat_cons (p13 F) ( sat_cons (p2226 F) ( sat_cons (p1964 F) ( sat_cons (p52 F) ( sat_cons (p10 F) ( sat_cons (p2234 F) (rfl))))))))))))))))))))
  · rfl
def c2414 : CNF.Clause Nat := [(39,true), (62,false), (99,false), (110,false)]
theorem p2414 (F : Frame G 4) : c2414.eval F.assign = true := by
  apply explicit_rup F.assign c2414 [c2389, c2407, c140, c134, c2413, c2097, c2028, c10] [(51,false), (38,false), (50,true), (40,true), (86,true), (15,false), (26,false)]
  · exact sat_cons (p2389 F) ( sat_cons (p2407 F) ( sat_cons (p140 F) ( sat_cons (p134 F) ( sat_cons (p2413 F) ( sat_cons (p2097 F) ( sat_cons (p2028 F) ( sat_cons (p10 F) (rfl))))))))
  · rfl
def c2415 : CNF.Clause Nat := [(38,true), (40,false), (50,false), (86,false), (62,false), (99,false), (110,false)]
theorem p2415 (F : Frame G 4) : c2415.eval F.assign = true := by
  apply explicit_rup F.assign c2415 [c1918, c2028, c2097, c2414, c2389, c2347, c75, c70, c1636, c1633, c150, c1394, c2248, c13, c2226, c1389, c142] [(18,false), (26,false), (15,false), (39,true), (51,false), (98,false), (7,true), (29,true), (87,false), (10,false), (21,true), (27,false), (88,false), (5,true), (19,false), (30,false)]
  · exact sat_cons (p1918 F) ( sat_cons (p2028 F) ( sat_cons (p2097 F) ( sat_cons (p2414 F) ( sat_cons (p2389 F) ( sat_cons (p2347 F) ( sat_cons (p75 F) ( sat_cons (p70 F) ( sat_cons (p1636 F) ( sat_cons (p1633 F) ( sat_cons (p150 F) ( sat_cons (p1394 F) ( sat_cons (p2248 F) ( sat_cons (p13 F) ( sat_cons (p2226 F) ( sat_cons (p1389 F) ( sat_cons (p142 F) (rfl)))))))))))))))))
  · rfl
def c2416 : CNF.Clause Nat := [(21,false), (38,false), (50,false), (86,false), (62,false), (99,false), (110,false)]
theorem p2416 (F : Frame G 4) : c2416.eval F.assign = true := by
  apply explicit_rup F.assign c2416 [c2389, c1877, c1807, c2393] [(51,false), (29,false), (7,false)]
  · exact sat_cons (p2389 F) ( sat_cons (p1877 F) ( sat_cons (p1807 F) ( sat_cons (p2393 F) (rfl))))
  · rfl
def c2417 : CNF.Clause Nat := [(40,false), (50,false), (86,false), (62,false), (99,false), (110,false)]
theorem p2417 (F : Frame G 4) : c2417.eval F.assign = true := by
  apply explicit_rup F.assign c2417 [c2347, c2415, c1652, c2416, c150, c2392] [(98,false), (38,true), (10,false), (21,false), (87,true)]
  · exact sat_cons (p2347 F) ( sat_cons (p2415 F) ( sat_cons (p1652 F) ( sat_cons (p2416 F) ( sat_cons (p150 F) ( sat_cons (p2392 F) (rfl))))))
  · rfl
def c2418 : CNF.Clause Nat := [(87,false), (38,false), (50,false), (86,false), (62,false), (99,false), (110,false)]
theorem p2418 (F : Frame G 4) : c2418.eval F.assign = true := by
  apply explicit_rup F.assign c2418 [c2416, c2414, c2389, c1738, c2392, c2393, c1412] [(21,false), (39,true), (51,false), (7,false), (10,true), (29,true)]
  · exact sat_cons (p2416 F) ( sat_cons (p2414 F) ( sat_cons (p2389 F) ( sat_cons (p1738 F) ( sat_cons (p2392 F) ( sat_cons (p2393 F) ( sat_cons (p1412 F) (rfl)))))))
  · rfl
def c2419 : CNF.Clause Nat := [(38,false), (50,false), (86,false), (62,false), (99,false), (110,false)]
theorem p2419 (F : Frame G 4) : c2419.eval F.assign = true := by
  apply explicit_rup F.assign c2419 [c2417, c2414, c2389, c2347, c2416, c2418, c150, c1412, c2393, c20, c1933] [(40,false), (39,true), (51,false), (98,false), (21,false), (87,false), (10,true), (29,false), (7,true), (18,true)]
  · exact sat_cons (p2417 F) ( sat_cons (p2414 F) ( sat_cons (p2389 F) ( sat_cons (p2347 F) ( sat_cons (p2416 F) ( sat_cons (p2418 F) ( sat_cons (p150 F) ( sat_cons (p1412 F) ( sat_cons (p2393 F) ( sat_cons (p20 F) ( sat_cons (p1933 F) (rfl)))))))))))
  · rfl
def c2420 : CNF.Clause Nat := [(29,true), (50,false), (86,false), (62,false), (99,false), (110,false)]
theorem p2420 (F : Frame G 4) : c2420.eval F.assign = true := by
  apply explicit_rup F.assign c2420 [c2417, c2097, c2414, c2389, c2393, c20, c2287] [(40,false), (15,false), (39,true), (51,false), (7,true), (18,true)]
  · exact sat_cons (p2417 F) ( sat_cons (p2097 F) ( sat_cons (p2414 F) ( sat_cons (p2389 F) ( sat_cons (p2393 F) ( sat_cons (p20 F) ( sat_cons (p2287 F) (rfl)))))))
  · rfl
def c2421 : CNF.Clause Nat := [(30,false), (87,true), (29,false), (26,false), (38,true), (40,true), (86,false), (39,false), (51,true), (62,false), (110,false)]
theorem p2421 (F : Frame G 4) : c2421.eval F.assign = true := by
  apply explicit_rup F.assign c2421 [c1389, c1335, c13] [(5,false), (27,false)]
  · exact sat_cons (p1389 F) ( sat_cons (p1335 F) ( sat_cons (p13 F) (rfl)))
  · rfl
def c2422 : CNF.Clause Nat := [(87,true), (19,true), (29,false), (26,false), (38,true), (40,true), (50,false), (86,false), (39,false), (51,true), (62,false), (98,true), (110,false)]
theorem p2422 (F : Frame G 4) : c2422.eval F.assign = true := by
  apply explicit_rup F.assign c2422 [c1882, c2421, c142, c150, c2155] [(21,false), (30,false), (88,true), (10,true)]
  · exact sat_cons (p1882 F) ( sat_cons (p2421 F) ( sat_cons (p142 F) ( sat_cons (p150 F) ( sat_cons (p2155 F) (rfl)))))
  · rfl
def c2423 : CNF.Clause Nat := [(50,false), (86,false), (62,false), (99,false), (110,false)]
theorem p2423 (F : Frame G 4) : c2423.eval F.assign = true := by
  apply explicit_rup F.assign c2423 [c2414, c2389, c2347, c2097, c2417, c2419, c9, c2420, c2381, c2422, c1816, c1636, c26] [(39,true), (51,false), (98,false), (15,false), (40,false), (38,false), (26,true), (29,true), (19,false), (87,true), (18,false), (7,false)]
  · exact sat_cons (p2414 F) ( sat_cons (p2389 F) ( sat_cons (p2347 F) ( sat_cons (p2097 F) ( sat_cons (p2417 F) ( sat_cons (p2419 F) ( sat_cons (p9 F) ( sat_cons (p2420 F) ( sat_cons (p2381 F) ( sat_cons (p2422 F) ( sat_cons (p1816 F) ( sat_cons (p1636 F) ( sat_cons (p26 F) (rfl)))))))))))))
  · rfl
def c2424 : CNF.Clause Nat := [(87,false), (40,true), (29,false), (50,true), (86,false), (51,true), (62,false), (99,false)]
theorem p2424 (F : Frame G 4) : c2424.eval F.assign = true := by
  apply explicit_rup F.assign c2424 [c140, c1738, c1739, c1415, c125] [(38,true), (7,false), (6,false), (17,false)]
  · exact sat_cons (p140 F) ( sat_cons (p1738 F) ( sat_cons (p1739 F) ( sat_cons (p1415 F) ( sat_cons (p125 F) (rfl)))))
  · rfl
def c2425 : CNF.Clause Nat := [(40,true), (29,false), (86,false), (62,false), (99,false), (110,false)]
theorem p2425 (F : Frame G 4) : c2425.eval F.assign = true := by
  apply explicit_rup F.assign c2425 [c2414, c2389, c2423, c140, c1412, c1421, c2347, c2424, c150, c1394, c1807, c12, c1389, c142, c1653, c2052, c125, c246, c2111] [(39,true), (51,false), (50,false), (38,true), (10,false), (88,false), (98,false), (87,false), (21,true), (27,false), (7,false), (5,true), (30,false), (19,true), (6,false), (22,false), (17,true), (11,true)]
  · exact sat_cons (p2414 F) ( sat_cons (p2389 F) ( sat_cons (p2423 F) ( sat_cons (p140 F) ( sat_cons (p1412 F) ( sat_cons (p1421 F) ( sat_cons (p2347 F) ( sat_cons (p2424 F) ( sat_cons (p150 F) ( sat_cons (p1394 F) ( sat_cons (p1807 F) ( sat_cons (p12 F) ( sat_cons (p1389 F) ( sat_cons (p142 F) ( sat_cons (p1653 F) ( sat_cons (p2052 F) ( sat_cons (p125 F) ( sat_cons (p246 F) ( sat_cons (p2111 F) (rfl)))))))))))))))))))
  · rfl
def c2426 : CNF.Clause Nat := [(29,false), (86,false), (62,false), (99,false), (110,false)]
theorem p2426 (F : Frame G 4) : c2426.eval F.assign = true := by
  apply explicit_rup F.assign c2426 [c2389, c2423, c140, c2414, c2347, c1412, c2425, c2390, c150, c2093, c1738, c1739, c1415, c12, c127, c1670] [(51,false), (50,false), (38,true), (39,true), (98,false), (10,false), (40,true), (21,false), (87,true), (27,false), (7,false), (6,false), (17,false), (5,true), (18,true)]
  · exact sat_cons (p2389 F) ( sat_cons (p2423 F) ( sat_cons (p140 F) ( sat_cons (p2414 F) ( sat_cons (p2347 F) ( sat_cons (p1412 F) ( sat_cons (p2425 F) ( sat_cons (p2390 F) ( sat_cons (p150 F) ( sat_cons (p2093 F) ( sat_cons (p1738 F) ( sat_cons (p1739 F) ( sat_cons (p1415 F) ( sat_cons (p12 F) ( sat_cons (p127 F) ( sat_cons (p1670 F) (rfl))))))))))))))))
  · rfl
def c2427 : CNF.Clause Nat := [(87,false), (86,false), (62,false), (99,false), (110,false)]
theorem p2427 (F : Frame G 4) : c2427.eval F.assign = true := by
  apply explicit_rup F.assign c2427 [c2426, c2389, c2423, c140, c2093, c1738, c12, c28, c1670] [(29,false), (51,false), (50,false), (38,true), (27,false), (7,false), (5,true), (18,true)]
  · exact sat_cons (p2426 F) ( sat_cons (p2389 F) ( sat_cons (p2423 F) ( sat_cons (p140 F) ( sat_cons (p2093 F) ( sat_cons (p1738 F) ( sat_cons (p12 F) ( sat_cons (p28 F) ( sat_cons (p1670 F) (rfl)))))))))
  · rfl
def c2428 : CNF.Clause Nat := [(40,false), (86,false), (62,false), (99,false), (110,false)]
theorem p2428 (F : Frame G 4) : c2428.eval F.assign = true := by
  apply explicit_rup F.assign c2428 [c2427, c2389, c2423, c140, c2347, c1652, c2390, c150] [(87,false), (51,false), (50,false), (38,true), (98,false), (10,false), (21,false)]
  · exact sat_cons (p2427 F) ( sat_cons (p2389 F) ( sat_cons (p2423 F) ( sat_cons (p140 F) ( sat_cons (p2347 F) ( sat_cons (p1652 F) ( sat_cons (p2390 F) ( sat_cons (p150 F) (rfl))))))))
  · rfl
def c2429 : CNF.Clause Nat := [(86,false), (62,false), (99,false), (110,false)]
theorem p2429 (F : Frame G 4) : c2429.eval F.assign = true := by
  apply explicit_rup F.assign c2429 [c2414, c2389, c2423, c140, c2426, c2428, c23, c20, c1933] [(39,true), (51,false), (50,false), (38,true), (29,false), (40,false), (7,true), (18,true)]
  · exact sat_cons (p2414 F) ( sat_cons (p2389 F) ( sat_cons (p2423 F) ( sat_cons (p140 F) ( sat_cons (p2426 F) ( sat_cons (p2428 F) ( sat_cons (p23 F) ( sat_cons (p20 F) ( sat_cons (p1933 F) (rfl)))))))))
  · rfl
def c2430 : CNF.Clause Nat := [(87,true), (7,false), (38,false), (62,false), (99,false), (110,false)]
theorem p2430 (F : Frame G 4) : c2430.eval F.assign = true := by
  apply explicit_rup F.assign c2430 [c2429, c2414, c2347, c261, c2015, c147, c2004, c2182, c144] [(86,false), (39,true), (98,false), (88,true), (9,false), (31,true), (19,false), (30,false)]
  · exact sat_cons (p2429 F) ( sat_cons (p2414 F) ( sat_cons (p2347 F) ( sat_cons (p261 F) ( sat_cons (p2015 F) ( sat_cons (p147 F) ( sat_cons (p2004 F) ( sat_cons (p2182 F) ( sat_cons (p144 F) (rfl)))))))))
  · rfl
def c2431 : CNF.Clause Nat := [(7,false), (29,true), (50,true), (62,false), (99,false), (110,false)]
theorem p2431 (F : Frame G 4) : c2431.eval F.assign = true := by
  apply explicit_rup F.assign c2431 [c2389, c140, c2429, c2414, c2430, c2093, c1984, c12, c20, c2059, c2183, c143, c2012, c2017, c124] [(51,false), (38,true), (86,false), (39,true), (87,true), (27,false), (18,false), (5,true), (40,true), (88,false), (19,false), (30,true), (6,false), (17,false)]
  · exact sat_cons (p2389 F) ( sat_cons (p140 F) ( sat_cons (p2429 F) ( sat_cons (p2414 F) ( sat_cons (p2430 F) ( sat_cons (p2093 F) ( sat_cons (p1984 F) ( sat_cons (p12 F) ( sat_cons (p20 F) ( sat_cons (p2059 F) ( sat_cons (p2183 F) ( sat_cons (p143 F) ( sat_cons (p2012 F) ( sat_cons (p2017 F) ( sat_cons (p124 F) (rfl)))))))))))))))
  · rfl
def c2432 : CNF.Clause Nat := [(87,false), (18,false), (50,true), (62,false), (99,false), (110,false)]
theorem p2432 (F : Frame G 4) : c2432.eval F.assign = true := by
  apply explicit_rup F.assign c2432 [c2389, c140, c2093, c1670, c12] [(51,false), (38,true), (27,false), (5,false)]
  · exact sat_cons (p2389 F) ( sat_cons (p140 F) ( sat_cons (p2093 F) ( sat_cons (p1670 F) ( sat_cons (p12 F) (rfl)))))
  · rfl
def c2433 : CNF.Clause Nat := [(5,false), (87,true), (18,false), (40,false), (38,false), (62,false), (99,false), (110,false)]
theorem p2433 (F : Frame G 4) : c2433.eval F.assign = true := by
  apply explicit_rup F.assign c2433 [c2347, c2429, c2414, c261, c2015, c147, c2219, c2183, c144] [(98,false), (86,false), (39,true), (88,true), (9,false), (31,true), (30,false), (19,false)]
  · exact sat_cons (p2347 F) ( sat_cons (p2429 F) ( sat_cons (p2414 F) ( sat_cons (p261 F) ( sat_cons (p2015 F) ( sat_cons (p147 F) ( sat_cons (p2219 F) ( sat_cons (p2183 F) ( sat_cons (p144 F) (rfl)))))))))
  · rfl
def c2434 : CNF.Clause Nat := [(29,true), (50,true), (62,false), (99,false), (110,false)]
theorem p2434 (F : Frame G 4) : c2434.eval F.assign = true := by
  apply explicit_rup F.assign c2434 [c2389, c140, c2429, c2414, c2347, c2431, c23, c28, c2432, c261, c2015, c147, c2197, c126, c2433, c12, c2025, c144, c1662, c1322, c150] [(51,false), (38,true), (86,false), (39,true), (98,false), (7,false), (40,true), (18,true), (87,false), (88,true), (9,false), (31,true), (6,false), (17,true), (5,false), (27,true), (30,false), (19,true), (10,false), (21,false)]
  · exact sat_cons (p2389 F) ( sat_cons (p140 F) ( sat_cons (p2429 F) ( sat_cons (p2414 F) ( sat_cons (p2347 F) ( sat_cons (p2431 F) ( sat_cons (p23 F) ( sat_cons (p28 F) ( sat_cons (p2432 F) ( sat_cons (p261 F) ( sat_cons (p2015 F) ( sat_cons (p147 F) ( sat_cons (p2197 F) ( sat_cons (p126 F) ( sat_cons (p2433 F) ( sat_cons (p12 F) ( sat_cons (p2025 F) ( sat_cons (p144 F) ( sat_cons (p1662 F) ( sat_cons (p1322 F) ( sat_cons (p150 F) (rfl)))))))))))))))))))))
  · rfl
def c2435 : CNF.Clause Nat := [(19,false), (87,true), (18,false), (29,false), (38,false), (86,true), (39,false), (51,true), (62,false), (98,true), (110,false)]
theorem p2435 (F : Frame G 4) : c2435.eval F.assign = true := by
  apply explicit_rup F.assign c2435 [c261, c2015, c147, c2006, c1325, c150] [(88,true), (9,false), (31,true), (10,false), (21,false)]
  · exact sat_cons (p261 F) ( sat_cons (p2015 F) ( sat_cons (p147 F) ( sat_cons (p2006 F) ( sat_cons (p1325 F) ( sat_cons (p150 F) (rfl))))))
  · rfl
def c2436 : CNF.Clause Nat := [(18,false), (50,true), (62,false), (99,false), (110,false)]
theorem p2436 (F : Frame G 4) : c2436.eval F.assign = true := by
  apply explicit_rup F.assign c2436 [c2434, c2389, c140, c2429, c2414, c2347, c2432, c261, c2015, c147, c2435, c144, c1357, c2219, c12] [(29,true), (51,false), (38,true), (86,false), (39,true), (98,false), (87,false), (88,true), (9,false), (31,true), (19,false), (30,true), (27,false), (5,false)]
  · exact sat_cons (p2434 F) ( sat_cons (p2389 F) ( sat_cons (p140 F) ( sat_cons (p2429 F) ( sat_cons (p2414 F) ( sat_cons (p2347 F) ( sat_cons (p2432 F) ( sat_cons (p261 F) ( sat_cons (p2015 F) ( sat_cons (p147 F) ( sat_cons (p2435 F) ( sat_cons (p144 F) ( sat_cons (p1357 F) ( sat_cons (p2219 F) ( sat_cons (p12 F) (rfl)))))))))))))))
  · rfl
def c2437 : CNF.Clause Nat := [(30,false), (87,true), (7,true), (50,true), (62,false), (99,false), (110,false)]
theorem p2437 (F : Frame G 4) : c2437.eval F.assign = true := by
  apply explicit_rup F.assign c2437 [c2347, c2429, c2389, c140, c2414, c261, c2015, c147, c2436, c26, c2434, c1357, c2012, c12, c127, c2218] [(98,false), (86,false), (51,false), (38,true), (39,true), (88,true), (9,false), (31,true), (18,false), (40,true), (29,true), (27,false), (6,false), (5,true), (17,true)]
  · exact sat_cons (p2347 F) ( sat_cons (p2429 F) ( sat_cons (p2389 F) ( sat_cons (p140 F) ( sat_cons (p2414 F) ( sat_cons (p261 F) ( sat_cons (p2015 F) ( sat_cons (p147 F) ( sat_cons (p2436 F) ( sat_cons (p26 F) ( sat_cons (p2434 F) ( sat_cons (p1357 F) ( sat_cons (p2012 F) ( sat_cons (p12 F) ( sat_cons (p127 F) ( sat_cons (p2218 F) (rfl))))))))))))))))
  · rfl
def c2438 : CNF.Clause Nat := [(87,true), (7,true), (50,true), (62,false), (99,false), (110,false)]
theorem p2438 (F : Frame G 4) : c2438.eval F.assign = true := by
  apply explicit_rup F.assign c2438 [c2436, c2434, c2389, c140, c2429, c2414, c2347, c261, c2015, c147, c2437, c144, c2006, c2124, c150, c127, c1322] [(18,false), (29,true), (51,false), (38,true), (86,false), (39,true), (98,false), (88,true), (9,false), (31,true), (30,false), (19,true), (10,false), (6,false), (21,true), (17,true)]
  · exact sat_cons (p2436 F) ( sat_cons (p2434 F) ( sat_cons (p2389 F) ( sat_cons (p140 F) ( sat_cons (p2429 F) ( sat_cons (p2414 F) ( sat_cons (p2347 F) ( sat_cons (p261 F) ( sat_cons (p2015 F) ( sat_cons (p147 F) ( sat_cons (p2437 F) ( sat_cons (p144 F) ( sat_cons (p2006 F) ( sat_cons (p2124 F) ( sat_cons (p150 F) ( sat_cons (p127 F) ( sat_cons (p1322 F) (rfl)))))))))))))))))
  · rfl
def c2439 : CNF.Clause Nat := [(7,true), (50,true), (62,false), (99,false), (110,false)]
theorem p2439 (F : Frame G 4) : c2439.eval F.assign = true := by
  apply explicit_rup F.assign c2439 [c2436, c2434, c2389, c140, c2429, c2414, c2347, c26, c2438, c2093, c1413, c12, c147, c2059, c2183, c1373, c143] [(18,false), (29,true), (51,false), (38,true), (86,false), (39,true), (98,false), (40,true), (87,true), (27,false), (9,false), (5,true), (31,true), (88,false), (19,false), (30,false)]
  · exact sat_cons (p2436 F) ( sat_cons (p2434 F) ( sat_cons (p2389 F) ( sat_cons (p140 F) ( sat_cons (p2429 F) ( sat_cons (p2414 F) ( sat_cons (p2347 F) ( sat_cons (p26 F) ( sat_cons (p2438 F) ( sat_cons (p2093 F) ( sat_cons (p1413 F) ( sat_cons (p12 F) ( sat_cons (p147 F) ( sat_cons (p2059 F) ( sat_cons (p2183 F) ( sat_cons (p1373 F) ( sat_cons (p143 F) (rfl)))))))))))))))))
  · rfl
def c2440 : CNF.Clause Nat := [(50,true), (62,false), (99,false), (110,false)]
theorem p2440 (F : Frame G 4) : c2440.eval F.assign = true := by
  apply explicit_rup F.assign c2440 [c2429, c2414, c2389, c2347, c140, c2434, c2439, c2430, c2090, c1413, c147] [(86,false), (39,true), (51,false), (98,false), (38,true), (29,true), (7,true), (87,true), (31,false), (9,false)]
  · exact sat_cons (p2429 F) ( sat_cons (p2414 F) ( sat_cons (p2389 F) ( sat_cons (p2347 F) ( sat_cons (p140 F) ( sat_cons (p2434 F) ( sat_cons (p2439 F) ( sat_cons (p2430 F) ( sat_cons (p2090 F) ( sat_cons (p1413 F) ( sat_cons (p147 F) (rfl)))))))))))
  · rfl
def c2441 : CNF.Clause Nat := [(30,false), (7,false), (31,true), (29,false), (87,false), (62,false), (99,false), (110,false)]
theorem p2441 (F : Frame G 4) : c2441.eval F.assign = true := by
  apply explicit_rup F.assign c2441 [c2440, c2347, c2429, c147, c1705, c2403, c2414, c2389, c1754, c2058, c215, c1271, c13, c1377, c341, c9] [(50,true), (98,false), (86,false), (9,true), (88,false), (38,false), (39,true), (51,false), (11,false), (40,false), (33,true), (5,false), (27,true), (15,false), (26,false)]
  · exact sat_cons (p2440 F) ( sat_cons (p2347 F) ( sat_cons (p2429 F) ( sat_cons (p147 F) ( sat_cons (p1705 F) ( sat_cons (p2403 F) ( sat_cons (p2414 F) ( sat_cons (p2389 F) ( sat_cons (p1754 F) ( sat_cons (p2058 F) ( sat_cons (p215 F) ( sat_cons (p1271 F) ( sat_cons (p13 F) ( sat_cons (p1377 F) ( sat_cons (p341 F) ( sat_cons (p9 F) (rfl))))))))))))))))
  · rfl
def c2442 : CNF.Clause Nat := [(7,false), (31,true), (29,false), (87,false), (62,false), (99,false), (110,false)]
theorem p2442 (F : Frame G 4) : c2442.eval F.assign = true := by
  apply explicit_rup F.assign c2442 [c2440, c2347, c2429, c147, c1705, c2403, c2414, c2389, c2441, c143, c2023, c1896, c1983, c9, c13, c1377] [(50,true), (98,false), (86,false), (9,true), (88,false), (38,false), (39,true), (51,false), (30,false), (19,true), (26,false), (5,false), (40,false), (15,true), (27,true)]
  · exact sat_cons (p2440 F) ( sat_cons (p2347 F) ( sat_cons (p2429 F) ( sat_cons (p147 F) ( sat_cons (p1705 F) ( sat_cons (p2403 F) ( sat_cons (p2414 F) ( sat_cons (p2389 F) ( sat_cons (p2441 F) ( sat_cons (p143 F) ( sat_cons (p2023 F) ( sat_cons (p1896 F) ( sat_cons (p1983 F) ( sat_cons (p9 F) ( sat_cons (p13 F) ( sat_cons (p1377 F) (rfl))))))))))))))))
  · rfl
def c2443 : CNF.Clause Nat := [(15,true), (26,true), (31,true), (29,false), (87,false), (62,false), (99,false), (110,false)]
theorem p2443 (F : Frame G 4) : c2443.eval F.assign = true := by
  apply explicit_rup F.assign c2443 [c2442, c2440, c2347, c2429, c147, c1705, c2403, c2414, c2389, c9, c1904, c75, c214, c1799] [(7,false), (50,true), (98,false), (86,false), (9,true), (88,false), (38,false), (39,true), (51,false), (40,true), (22,false), (18,true), (33,true)]
  · exact sat_cons (p2442 F) ( sat_cons (p2440 F) ( sat_cons (p2347 F) ( sat_cons (p2429 F) ( sat_cons (p147 F) ( sat_cons (p1705 F) ( sat_cons (p2403 F) ( sat_cons (p2414 F) ( sat_cons (p2389 F) ( sat_cons (p9 F) ( sat_cons (p1904 F) ( sat_cons (p75 F) ( sat_cons (p214 F) ( sat_cons (p1799 F) (rfl))))))))))))))
  · rfl
def c2444 : CNF.Clause Nat := [(19,false), (31,true), (29,false), (87,false), (62,false), (99,false), (110,false)]
theorem p2444 (F : Frame G 4) : c2444.eval F.assign = true := by
  apply explicit_rup F.assign c2444 [c2442, c2347, c2429, c147, c2440, c2403, c2389, c2023, c2443, c1377, c13, c2226, c26, c1306] [(7,false), (98,false), (86,false), (9,true), (50,true), (38,false), (51,false), (26,false), (15,true), (27,false), (5,true), (40,false), (18,true)]
  · exact sat_cons (p2442 F) ( sat_cons (p2347 F) ( sat_cons (p2429 F) ( sat_cons (p147 F) ( sat_cons (p2440 F) ( sat_cons (p2403 F) ( sat_cons (p2389 F) ( sat_cons (p2023 F) ( sat_cons (p2443 F) ( sat_cons (p1377 F) ( sat_cons (p13 F) ( sat_cons (p2226 F) ( sat_cons (p26 F) ( sat_cons (p1306 F) (rfl))))))))))))))
  · rfl
def c2445 : CNF.Clause Nat := [(31,true), (29,false), (87,false), (62,false), (99,false), (110,false)]
theorem p2445 (F : Frame G 4) : c2445.eval F.assign = true := by
  apply explicit_rup F.assign c2445 [c2440, c2429, c2414, c2389, c2347, c147, c1705, c2442, c2444, c143, c2058, c1945, c26] [(50,true), (86,false), (39,true), (51,false), (98,false), (9,true), (88,false), (7,false), (19,false), (30,true), (40,false), (18,false)]
  · exact sat_cons (p2440 F) ( sat_cons (p2429 F) ( sat_cons (p2414 F) ( sat_cons (p2389 F) ( sat_cons (p2347 F) ( sat_cons (p147 F) ( sat_cons (p1705 F) ( sat_cons (p2442 F) ( sat_cons (p2444 F) ( sat_cons (p143 F) ( sat_cons (p2058 F) ( sat_cons (p1945 F) ( sat_cons (p26 F) (rfl)))))))))))))
  · rfl
def c2446 : CNF.Clause Nat := [(29,false), (87,false), (62,false), (99,false), (110,false)]
theorem p2446 (F : Frame G 4) : c2446.eval F.assign = true := by
  apply explicit_rup F.assign c2446 [c2429, c2440, c2403, c2414, c2389, c2445, c1801, c1761, c26, c1512, c2087, c1953, c9, c143, c2023] [(86,false), (50,true), (38,false), (39,true), (51,false), (31,true), (40,false), (18,false), (7,true), (88,false), (15,false), (30,false), (26,true), (19,true)]
  · exact sat_cons (p2429 F) ( sat_cons (p2440 F) ( sat_cons (p2403 F) ( sat_cons (p2414 F) ( sat_cons (p2389 F) ( sat_cons (p2445 F) ( sat_cons (p1801 F) ( sat_cons (p1761 F) ( sat_cons (p26 F) ( sat_cons (p1512 F) ( sat_cons (p2087 F) ( sat_cons (p1953 F) ( sat_cons (p9 F) ( sat_cons (p143 F) ( sat_cons (p2023 F) (rfl)))))))))))))))
  · rfl
def c2447 : CNF.Clause Nat := [(31,false), (29,true), (87,false), (50,false), (39,false), (51,true), (62,false), (99,false)]
theorem p2447 (F : Frame G 4) : c2447.eval F.assign = true := by
  apply explicit_rup F.assign c2447 [c1801, c1761, c20] [(40,false), (18,false)]
  · exact sat_cons (p1801 F) ( sat_cons (p1761 F) ( sat_cons (p20 F) (rfl)))
  · rfl
def c2448 : CNF.Clause Nat := [(40,true), (9,false), (29,true), (87,false), (38,true), (50,false), (86,true), (39,false), (51,true), (99,false)]
theorem p2448 (F : Frame G 4) : c2448.eval F.assign = true := by
  apply explicit_rup F.assign c2448 [c23, c20, c1271, c1766, c13] [(7,true), (18,true), (5,false), (27,false)]
  · exact sat_cons (p23 F) ( sat_cons (p20 F) ( sat_cons (p1271 F) ( sat_cons (p1766 F) ( sat_cons (p13 F) (rfl)))))
  · rfl
def c2449 : CNF.Clause Nat := [(87,false), (62,false), (99,false), (110,false)]
theorem p2449 (F : Frame G 4) : c2449.eval F.assign = true := by
  apply explicit_rup F.assign c2449 [c2429, c2440, c2403, c2414, c2389, c2347, c2446, c2447, c147, c2448, c1473, c2058, c143, c1983, c28, c1985, c13, c1377, c2169, c73] [(86,false), (50,true), (38,false), (39,true), (51,false), (98,false), (29,false), (31,false), (9,true), (40,true), (88,false), (30,false), (19,true), (7,false), (18,true), (5,false), (27,true), (15,false), (26,false)]
  · exact sat_cons (p2429 F) ( sat_cons (p2440 F) ( sat_cons (p2403 F) ( sat_cons (p2414 F) ( sat_cons (p2389 F) ( sat_cons (p2347 F) ( sat_cons (p2446 F) ( sat_cons (p2447 F) ( sat_cons (p147 F) ( sat_cons (p2448 F) ( sat_cons (p1473 F) ( sat_cons (p2058 F) ( sat_cons (p143 F) ( sat_cons (p1983 F) ( sat_cons (p28 F) ( sat_cons (p1985 F) ( sat_cons (p13 F) ( sat_cons (p1377 F) ( sat_cons (p2169 F) ( sat_cons (p73 F) (rfl))))))))))))))))))))
  · rfl
def c2450 : CNF.Clause Nat := [(40,false), (9,false), (87,true), (38,true), (50,false), (86,true), (39,false), (51,true), (62,false), (110,false)]
theorem p2450 (F : Frame G 4) : c2450.eval F.assign = true := by
  apply explicit_rup F.assign c2450 [c261, c2058, c144, c2170, c2021, c13] [(88,true), (30,false), (19,true), (27,false), (5,false)]
  · exact sat_cons (p261 F) ( sat_cons (p2058 F) ( sat_cons (p144 F) ( sat_cons (p2170 F) ( sat_cons (p2021 F) ( sat_cons (p13 F) (rfl))))))
  · rfl
def c2451 : CNF.Clause Nat := [(9,false), (29,true), (62,false), (99,false), (110,false)]
theorem p2451 (F : Frame G 4) : c2451.eval F.assign = true := by
  apply explicit_rup F.assign c2451 [c2449, c2429, c2440, c2403, c2414, c2389, c2347, c2450, c23, c20, c1291, c1271, c150, c13, c1325, c2025, c144] [(87,false), (86,false), (50,true), (38,false), (39,true), (51,false), (98,false), (40,false), (7,true), (18,true), (10,false), (5,false), (21,true), (27,true), (19,false), (30,false)]
  · exact sat_cons (p2449 F) ( sat_cons (p2429 F) ( sat_cons (p2440 F) ( sat_cons (p2403 F) ( sat_cons (p2414 F) ( sat_cons (p2389 F) ( sat_cons (p2347 F) ( sat_cons (p2450 F) ( sat_cons (p23 F) ( sat_cons (p20 F) ( sat_cons (p1291 F) ( sat_cons (p1271 F) ( sat_cons (p150 F) ( sat_cons (p13 F) ( sat_cons (p1325 F) ( sat_cons (p2025 F) ( sat_cons (p144 F) (rfl)))))))))))))))))
  · rfl
def c2452 : CNF.Clause Nat := [(40,true), (10,false), (31,false), (29,true), (88,false), (87,true), (38,true), (50,false), (39,false), (51,true), (110,false)]
theorem p2452 (F : Frame G 4) : c2452.eval F.assign = true := by
  apply explicit_rup F.assign c2452 [c23, c20, c2166, c1272, c13] [(7,true), (18,true), (27,false), (5,false)]
  · exact sat_cons (p23 F) ( sat_cons (p20 F) ( sat_cons (p2166 F) ( sat_cons (p1272 F) ( sat_cons (p13 F) (rfl)))))
  · rfl
def c2453 : CNF.Clause Nat := [(29,true), (62,false), (99,false), (110,false)]
theorem p2453 (F : Frame G 4) : c2453.eval F.assign = true := by
  apply explicit_rup F.assign c2453 [c2429, c2449, c261, c2440, c2403, c2414, c2389, c2347, c2451, c147, c2176, c150, c2452, c2031, c2137, c28] [(86,false), (87,false), (88,true), (50,true), (38,false), (39,true), (51,false), (98,false), (9,false), (31,true), (21,false), (10,true), (40,true), (7,false), (18,false)]
  · exact sat_cons (p2429 F) ( sat_cons (p2449 F) ( sat_cons (p261 F) ( sat_cons (p2440 F) ( sat_cons (p2403 F) ( sat_cons (p2414 F) ( sat_cons (p2389 F) ( sat_cons (p2347 F) ( sat_cons (p2451 F) ( sat_cons (p147 F) ( sat_cons (p2176 F) ( sat_cons (p150 F) ( sat_cons (p2452 F) ( sat_cons (p2031 F) ( sat_cons (p2137 F) ( sat_cons (p28 F) (rfl))))))))))))))))
  · rfl
def c2454 : CNF.Clause Nat := [(31,false), (62,false), (99,false), (110,false)]
theorem p2454 (F : Frame G 4) : c2454.eval F.assign = true := by
  apply explicit_rup F.assign c2454 [c2453, c2429, c2449, c261, c2440, c2403, c2414, c2347, c2176, c150, c2033, c2167, c9, c2023, c1346, c144] [(29,true), (86,false), (87,false), (88,true), (50,true), (38,false), (39,true), (98,false), (21,false), (10,true), (40,false), (15,false), (26,true), (19,false), (30,false)]
  · exact sat_cons (p2453 F) ( sat_cons (p2429 F) ( sat_cons (p2449 F) ( sat_cons (p261 F) ( sat_cons (p2440 F) ( sat_cons (p2403 F) ( sat_cons (p2414 F) ( sat_cons (p2347 F) ( sat_cons (p2176 F) ( sat_cons (p150 F) ( sat_cons (p2033 F) ( sat_cons (p2167 F) ( sat_cons (p9 F) ( sat_cons (p2023 F) ( sat_cons (p1346 F) ( sat_cons (p144 F) (rfl))))))))))))))))
  · rfl
def c2455 : CNF.Clause Nat := [(62,false), (99,false), (110,false)]
theorem p2455 (F : Frame G 4) : c2455.eval F.assign = true := by
  apply explicit_rup F.assign c2455 [c2347, c2389, c2414, c2429, c2440, c2403, c2449, c261, c2453, c2454, c147, c2128, c2450, c9, c2023, c144, c1335, c1945, c13, c26, c1271] [(98,false), (51,false), (39,true), (86,false), (50,true), (38,false), (87,false), (88,true), (29,true), (31,false), (9,true), (15,false), (40,false), (26,true), (19,false), (30,true), (27,false), (18,false), (5,true), (7,true)]
  · exact sat_cons (p2347 F) ( sat_cons (p2389 F) ( sat_cons (p2414 F) ( sat_cons (p2429 F) ( sat_cons (p2440 F) ( sat_cons (p2403 F) ( sat_cons (p2449 F) ( sat_cons (p261 F) ( sat_cons (p2453 F) ( sat_cons (p2454 F) ( sat_cons (p147 F) ( sat_cons (p2128 F) ( sat_cons (p2450 F) ( sat_cons (p9 F) ( sat_cons (p2023 F) ( sat_cons (p144 F) ( sat_cons (p1335 F) ( sat_cons (p1945 F) ( sat_cons (p13 F) ( sat_cons (p26 F) ( sat_cons (p1271 F) (rfl)))))))))))))))))))))
  · rfl
def c2456 : CNF.Clause Nat := [(86,true), (30,true), (39,false), (51,false), (31,true), (87,true), (50,false), (98,true), (110,false)]
theorem p2456 (F : Frame G 4) : c2456.eval F.assign = true := by
  apply explicit_rup F.assign c2456 [c261, c147, c144, c2211] [(88,true), (9,true), (19,true)]
  · exact sat_cons (p261 F) ( sat_cons (p147 F) ( sat_cons (p144 F) ( sat_cons (p2211 F) (rfl))))
  · rfl
def c2457 : CNF.Clause Nat := [(19,false), (11,true), (88,false), (39,false), (51,false), (31,true), (87,true), (50,false), (99,false), (110,false)]
theorem p2457 (F : Frame G 4) : c2457.eval F.assign = true := by
  apply explicit_rup F.assign c2457 [c2347, c2212, c2456, c1791, c2211, c227, c1845, c1784, c150] [(98,false), (30,false), (86,true), (22,false), (9,false), (33,true), (21,false), (10,false)]
  · exact sat_cons (p2347 F) ( sat_cons (p2212 F) ( sat_cons (p2456 F) ( sat_cons (p1791 F) ( sat_cons (p2211 F) ( sat_cons (p227 F) ( sat_cons (p1845 F) ( sat_cons (p1784 F) ( sat_cons (p150 F) (rfl)))))))))
  · rfl
def c2458 : CNF.Clause Nat := [(88,false), (39,false), (40,true), (31,true), (87,true), (50,false), (99,false), (110,false)]
theorem p2458 (F : Frame G 4) : c2458.eval F.assign = true := by
  apply explicit_rup F.assign c2458 [c2347, c2455, c138, c2212, c2456, c2161, c22, c25, c2053, c2457, c172, c2045, c2143, c150, c2160, c1460, c9] [(98,false), (62,false), (51,true), (30,false), (86,true), (7,false), (29,true), (18,true), (11,false), (19,false), (9,true), (21,false), (38,false), (10,true), (15,false), (26,false)]
  · exact sat_cons (p2347 F) ( sat_cons (p2455 F) ( sat_cons (p138 F) ( sat_cons (p2212 F) ( sat_cons (p2456 F) ( sat_cons (p2161 F) ( sat_cons (p22 F) ( sat_cons (p25 F) ( sat_cons (p2053 F) ( sat_cons (p2457 F) ( sat_cons (p172 F) ( sat_cons (p2045 F) ( sat_cons (p2143 F) ( sat_cons (p150 F) ( sat_cons (p2160 F) ( sat_cons (p1460 F) ( sat_cons (p9 F) (rfl)))))))))))))))))
  · rfl
def c2459 : CNF.Clause Nat := [(39,false), (40,true), (31,true), (87,true), (50,false), (99,false), (110,false)]
theorem p2459 (F : Frame G 4) : c2459.eval F.assign = true := by
  apply explicit_rup F.assign c2459 [c2455, c138, c2347, c2212, c2456, c1791, c2458, c142, c1931, c22, c25, c2053, c246, c163, c1784] [(62,false), (51,true), (98,false), (30,false), (86,true), (22,false), (88,false), (19,true), (7,false), (29,true), (18,true), (11,false), (10,true), (33,true)]
  · exact sat_cons (p2455 F) ( sat_cons (p138 F) ( sat_cons (p2347 F) ( sat_cons (p2212 F) ( sat_cons (p2456 F) ( sat_cons (p1791 F) ( sat_cons (p2458 F) ( sat_cons (p142 F) ( sat_cons (p1931 F) ( sat_cons (p22 F) ( sat_cons (p25 F) ( sat_cons (p2053 F) ( sat_cons (p246 F) ( sat_cons (p163 F) ( sat_cons (p1784 F) (rfl)))))))))))))))
  · rfl
def c2460 : CNF.Clause Nat := [(29,false), (19,false), (88,true), (86,false), (40,true), (31,true), (87,true), (50,false), (99,false), (110,false)]
theorem p2460 (F : Frame G 4) : c2460.eval F.assign = true := by
  apply explicit_rup F.assign c2460 [c2459, c134, c2455, c138, c2347, c2159, c150, c1917, c2051, c25, c16, c1388, c2035, c165] [(39,false), (38,true), (62,false), (51,true), (98,false), (21,false), (10,true), (18,false), (6,false), (7,true), (17,true), (30,false), (9,false)]
  · exact sat_cons (p2459 F) ( sat_cons (p134 F) ( sat_cons (p2455 F) ( sat_cons (p138 F) ( sat_cons (p2347 F) ( sat_cons (p2159 F) ( sat_cons (p150 F) ( sat_cons (p1917 F) ( sat_cons (p2051 F) ( sat_cons (p25 F) ( sat_cons (p16 F) ( sat_cons (p1388 F) ( sat_cons (p2035 F) ( sat_cons (p165 F) (rfl))))))))))))))
  · rfl
def c2461 : CNF.Clause Nat := [(19,false), (88,true), (86,false), (40,true), (31,true), (87,true), (50,false), (99,false), (110,false)]
theorem p2461 (F : Frame G 4) : c2461.eval F.assign = true := by
  apply explicit_rup F.assign c2461 [c2459, c134, c2455, c138, c2347, c2460, c19, c22, c2039, c8, c2096, c2177, c16, c165, c1388] [(39,false), (38,true), (62,false), (51,true), (98,false), (29,false), (18,true), (7,true), (15,false), (26,true), (6,false), (9,false), (17,true), (30,true)]
  · exact sat_cons (p2459 F) ( sat_cons (p134 F) ( sat_cons (p2455 F) ( sat_cons (p138 F) ( sat_cons (p2347 F) ( sat_cons (p2460 F) ( sat_cons (p19 F) ( sat_cons (p22 F) ( sat_cons (p2039 F) ( sat_cons (p8 F) ( sat_cons (p2096 F) ( sat_cons (p2177 F) ( sat_cons (p16 F) ( sat_cons (p165 F) ( sat_cons (p1388 F) (rfl)))))))))))))))
  · rfl
def c2462 : CNF.Clause Nat := [(18,false), (9,false), (30,false), (38,false), (39,true), (51,false), (50,false), (99,false), (110,false)]
theorem p2462 (F : Frame G 4) : c2462.eval F.assign = true := by
  apply explicit_rup F.assign c2462 [c2455, c1958, c2229, c16] [(62,false), (6,false), (17,false)]
  · exact sat_cons (p2455 F) ( sat_cons (p1958 F) ( sat_cons (p2229 F) ( sat_cons (p16 F) (rfl))))
  · rfl
def c2463 : CNF.Clause Nat := [(88,true), (86,false), (40,true), (31,true), (87,true), (50,false), (99,false), (110,false)]
theorem p2463 (F : Frame G 4) : c2463.eval F.assign = true := by
  apply explicit_rup F.assign c2463 [c2459, c134, c2455, c138, c2347, c2461, c142, c167, c2462, c25, c19, c1388, c2159, c16, c150, c1282] [(39,false), (38,true), (62,false), (51,true), (98,false), (19,false), (30,true), (9,true), (18,false), (7,true), (29,true), (17,false), (21,false), (6,true), (10,true)]
  · exact sat_cons (p2459 F) ( sat_cons (p134 F) ( sat_cons (p2455 F) ( sat_cons (p138 F) ( sat_cons (p2347 F) ( sat_cons (p2461 F) ( sat_cons (p142 F) ( sat_cons (p167 F) ( sat_cons (p2462 F) ( sat_cons (p25 F) ( sat_cons (p19 F) ( sat_cons (p1388 F) ( sat_cons (p2159 F) ( sat_cons (p16 F) ( sat_cons (p150 F) ( sat_cons (p1282 F) (rfl))))))))))))))))
  · rfl
def c2464 : CNF.Clause Nat := [(29,false), (88,false), (86,false), (39,true), (40,true), (87,true), (50,false), (99,false), (110,false)]
theorem p2464 (F : Frame G 4) : c2464.eval F.assign = true := by
  apply explicit_rup F.assign c2464 [c134, c2455, c138, c2347, c2159, c150, c1917, c25, c1282, c16, c1640, c1911, c8] [(38,true), (62,false), (51,true), (98,false), (21,false), (10,true), (18,false), (7,true), (6,false), (17,true), (15,false), (26,false)]
  · exact sat_cons (p134 F) ( sat_cons (p2455 F) ( sat_cons (p138 F) ( sat_cons (p2347 F) ( sat_cons (p2159 F) ( sat_cons (p150 F) ( sat_cons (p1917 F) ( sat_cons (p25 F) ( sat_cons (p1282 F) ( sat_cons (p16 F) ( sat_cons (p1640 F) ( sat_cons (p1911 F) ( sat_cons (p8 F) (rfl)))))))))))))
  · rfl
def c2465 : CNF.Clause Nat := [(86,false), (40,true), (31,true), (87,true), (50,false), (99,false), (110,false)]
theorem p2465 (F : Frame G 4) : c2465.eval F.assign = true := by
  apply explicit_rup F.assign c2465 [c2459, c134, c2455, c138, c2347, c2463, c2464, c19, c22, c2039, c8, c2042, c1695, c150] [(39,false), (38,true), (62,false), (51,true), (98,false), (88,true), (29,false), (18,true), (7,true), (15,false), (26,true), (10,false), (21,false)]
  · exact sat_cons (p2459 F) ( sat_cons (p134 F) ( sat_cons (p2455 F) ( sat_cons (p138 F) ( sat_cons (p2347 F) ( sat_cons (p2463 F) ( sat_cons (p2464 F) ( sat_cons (p19 F) ( sat_cons (p22 F) ( sat_cons (p2039 F) ( sat_cons (p8 F) ( sat_cons (p2042 F) ( sat_cons (p1695 F) ( sat_cons (p150 F) (rfl))))))))))))))
  · rfl
def c2466 : CNF.Clause Nat := [(29,true), (9,false), (86,true), (39,true), (40,true), (87,true), (50,false), (99,false), (110,false)]
theorem p2466 (F : Frame G 4) : c2466.eval F.assign = true := by
  apply explicit_rup F.assign c2466 [c134, c2455, c138, c2347, c19, c22, c2462, c1291, c1281, c144, c150, c16, c1329] [(38,true), (62,false), (51,true), (98,false), (18,true), (7,true), (30,false), (10,false), (6,false), (19,true), (21,true), (17,true)]
  · exact sat_cons (p134 F) ( sat_cons (p2455 F) ( sat_cons (p138 F) ( sat_cons (p2347 F) ( sat_cons (p19 F) ( sat_cons (p22 F) ( sat_cons (p2462 F) ( sat_cons (p1291 F) ( sat_cons (p1281 F) ( sat_cons (p144 F) ( sat_cons (p150 F) ( sat_cons (p16 F) ( sat_cons (p1329 F) (rfl)))))))))))))
  · rfl
def c2467 : CNF.Clause Nat := [(18,false), (9,false), (86,true), (39,true), (40,true), (87,true), (50,false), (99,false), (110,false)]
theorem p2467 (F : Frame G 4) : c2467.eval F.assign = true := by
  apply explicit_rup F.assign c2467 [c2466, c134, c2455, c138, c2462, c144, c2177, c2231, c8] [(29,true), (38,true), (62,false), (51,true), (30,false), (19,true), (26,false), (15,false)]
  · exact sat_cons (p2466 F) ( sat_cons (p134 F) ( sat_cons (p2455 F) ( sat_cons (p138 F) ( sat_cons (p2462 F) ( sat_cons (p144 F) ( sat_cons (p2177 F) ( sat_cons (p2231 F) ( sat_cons (p8 F) (rfl)))))))))
  · rfl
def c2468 : CNF.Clause Nat := [(40,true), (31,true), (87,true), (50,false), (99,false), (110,false)]
theorem p2468 (F : Frame G 4) : c2468.eval F.assign = true := by
  apply explicit_rup F.assign c2468 [c2455, c2347, c138, c2459, c134, c2465, c261, c147, c2466, c2467, c25, c1291, c1281, c150, c16, c1695, c2122, c8, c144, c2231] [(62,false), (98,false), (51,true), (39,false), (38,true), (86,false), (88,true), (9,true), (29,true), (18,false), (7,true), (10,false), (6,false), (21,true), (17,true), (26,false), (30,false), (15,true), (19,true)]
  · exact sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p138 F) ( sat_cons (p2459 F) ( sat_cons (p134 F) ( sat_cons (p2465 F) ( sat_cons (p261 F) ( sat_cons (p147 F) ( sat_cons (p2466 F) ( sat_cons (p2467 F) ( sat_cons (p25 F) ( sat_cons (p1291 F) ( sat_cons (p1281 F) ( sat_cons (p150 F) ( sat_cons (p16 F) ( sat_cons (p1695 F) ( sat_cons (p2122 F) ( sat_cons (p8 F) ( sat_cons (p144 F) ( sat_cons (p2231 F) (rfl))))))))))))))))))))
  · rfl
def c2469 : CNF.Clause Nat := [(38,false), (29,false), (9,false), (86,true), (39,true), (40,false), (87,true), (50,false), (62,true), (98,true), (99,false)]
theorem p2469 (F : Frame G 4) : c2469.eval F.assign = true := by
  apply explicit_rup F.assign c2469 [c261, c1672, c150, c2136, c1287, c16] [(88,true), (21,false), (10,true), (17,false), (6,false)]
  · exact sat_cons (p261 F) ( sat_cons (p1672 F) ( sat_cons (p150 F) ( sat_cons (p2136 F) ( sat_cons (p1287 F) ( sat_cons (p16 F) (rfl))))))
  · rfl
def c2470 : CNF.Clause Nat := [(7,false), (26,false), (51,false), (9,false), (86,true), (39,true), (40,false), (87,true), (50,false), (99,false), (110,false)]
theorem p2470 (F : Frame G 4) : c2470.eval F.assign = true := by
  apply explicit_rup F.assign c2470 [c261, c2455, c2347, c2041, c1689, c144, c150, c2244, c1287, c16] [(88,true), (62,false), (98,false), (19,false), (21,false), (30,true), (10,true), (17,false), (6,false)]
  · exact sat_cons (p261 F) ( sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p2041 F) ( sat_cons (p1689 F) ( sat_cons (p144 F) ( sat_cons (p150 F) ( sat_cons (p2244 F) ( sat_cons (p1287 F) ( sat_cons (p16 F) (rfl))))))))))
  · rfl
def c2471 : CNF.Clause Nat := [(10,false), (29,false), (51,false), (9,false), (86,true), (39,true), (40,false), (87,true), (50,false), (99,false), (110,false)]
theorem p2471 (F : Frame G 4) : c2471.eval F.assign = true := by
  apply explicit_rup F.assign c2471 [c261, c2214, c2347, c2455, c2469, c10, c1277, c1287, c85, c16, c2244, c2245, c144] [(88,true), (15,false), (98,false), (62,false), (38,false), (26,true), (5,false), (6,false), (27,true), (17,true), (30,false), (19,false)]
  · exact sat_cons (p261 F) ( sat_cons (p2214 F) ( sat_cons (p2347 F) ( sat_cons (p2455 F) ( sat_cons (p2469 F) ( sat_cons (p10 F) ( sat_cons (p1277 F) ( sat_cons (p1287 F) ( sat_cons (p85 F) ( sat_cons (p16 F) ( sat_cons (p2244 F) ( sat_cons (p2245 F) ( sat_cons (p144 F) (rfl)))))))))))))
  · rfl
def c2472 : CNF.Clause Nat := [(17,false), (21,false), (18,false), (26,false), (51,false), (9,false), (86,true), (40,false), (87,true), (50,false), (99,false), (110,false)]
theorem p2472 (F : Frame G 4) : c2472.eval F.assign = true := by
  apply explicit_rup F.assign c2472 [c2455, c2347, c2244, c1329, c144] [(62,false), (98,false), (30,false), (19,false)]
  · exact sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p2244 F) ( sat_cons (p1329 F) ( sat_cons (p144 F) (rfl)))))
  · rfl
def c2473 : CNF.Clause Nat := [(29,false), (51,false), (9,false), (86,true), (39,true), (40,false), (87,true), (50,false), (99,false), (110,false)]
theorem p2473 (F : Frame G 4) : c2473.eval F.assign = true := by
  apply explicit_rup F.assign c2473 [c261, c2214, c2455, c2347, c2469, c10, c2470, c60, c2471, c150, c2472, c16, c1958, c144, c2226, c2241, c84] [(88,true), (15,false), (62,false), (98,false), (38,false), (26,true), (7,false), (18,true), (10,false), (21,true), (17,false), (6,true), (30,false), (19,true), (5,false), (27,false)]
  · exact sat_cons (p261 F) ( sat_cons (p2214 F) ( sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p2469 F) ( sat_cons (p10 F) ( sat_cons (p2470 F) ( sat_cons (p60 F) ( sat_cons (p2471 F) ( sat_cons (p150 F) ( sat_cons (p2472 F) ( sat_cons (p16 F) ( sat_cons (p1958 F) ( sat_cons (p144 F) ( sat_cons (p2226 F) ( sat_cons (p2241 F) ( sat_cons (p84 F) (rfl)))))))))))))))))
  · rfl
def c2474 : CNF.Clause Nat := [(38,true), (51,false), (9,false), (86,true), (39,true), (40,false), (87,true), (50,false), (99,false), (110,false)]
theorem p2474 (F : Frame G 4) : c2474.eval F.assign = true := by
  apply explicit_rup F.assign c2474 [c2473, c261, c2214, c2455, c58, c10, c2470] [(29,false), (88,true), (15,false), (62,false), (7,true), (26,true)]
  · exact sat_cons (p2473 F) ( sat_cons (p261 F) ( sat_cons (p2214 F) ( sat_cons (p2455 F) ( sat_cons (p58 F) ( sat_cons (p10 F) ( sat_cons (p2470 F) (rfl)))))))
  · rfl
def c2475 : CNF.Clause Nat := [(51,false), (9,false), (86,true), (39,true), (40,false), (87,true), (50,false), (99,false), (110,false)]
theorem p2475 (F : Frame G 4) : c2475.eval F.assign = true := by
  apply explicit_rup F.assign c2475 [c261, c2455, c2214, c2473, c2474, c2221, c27, c63, c2470] [(88,true), (62,false), (15,false), (29,false), (38,true), (18,false), (7,true), (26,true)]
  · exact sat_cons (p261 F) ( sat_cons (p2455 F) ( sat_cons (p2214 F) ( sat_cons (p2473 F) ( sat_cons (p2474 F) ( sat_cons (p2221 F) ( sat_cons (p27 F) ( sat_cons (p63 F) ( sat_cons (p2470 F) (rfl)))))))))
  · rfl
def c2476 : CNF.Clause Nat := [(86,true), (39,true), (31,true), (87,true), (50,false), (99,false), (110,false)]
theorem p2476 (F : Frame G 4) : c2476.eval F.assign = true := by
  apply explicit_rup F.assign c2476 [c2468, c2455, c2347, c261, c147, c2475, c137, c2221, c2469, c18] [(40,true), (62,false), (98,false), (88,true), (9,true), (51,false), (38,true), (18,false), (29,false)]
  · exact sat_cons (p2468 F) ( sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p261 F) ( sat_cons (p147 F) ( sat_cons (p2475 F) ( sat_cons (p137 F) ( sat_cons (p2221 F) ( sat_cons (p2469 F) ( sat_cons (p18 F) (rfl))))))))))
  · rfl
def c2477 : CNF.Clause Nat := [(51,true), (38,false), (86,false), (39,true), (40,false), (87,true), (50,false), (99,false), (110,false)]
theorem p2477 (F : Frame G 4) : c2477.eval F.assign = true := by
  apply explicit_rup F.assign c2477 [c1918, c1865, c2455, c2347, c62, c24, c18, c1866, c1913, c150, c16, c1872, c2136, c1914, c238] [(18,false), (15,false), (62,false), (98,false), (26,true), (7,true), (29,true), (21,false), (6,false), (10,true), (17,true), (22,false), (88,false), (33,false)]
  · exact sat_cons (p1918 F) ( sat_cons (p1865 F) ( sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p62 F) ( sat_cons (p24 F) ( sat_cons (p18 F) ( sat_cons (p1866 F) ( sat_cons (p1913 F) ( sat_cons (p150 F) ( sat_cons (p16 F) ( sat_cons (p1872 F) ( sat_cons (p2136 F) ( sat_cons (p1914 F) ( sat_cons (p238 F) (rfl)))))))))))))))
  · rfl
def c2478 : CNF.Clause Nat := [(29,false), (38,false), (86,false), (39,true), (40,false), (87,true), (50,false), (99,false), (110,false)]
theorem p2478 (F : Frame G 4) : c2478.eval F.assign = true := by
  apply explicit_rup F.assign c2478 [c2477, c1791, c1366, c2455, c2347, c2159, c1913, c238, c16, c1920] [(51,true), (22,false), (88,false), (62,false), (98,false), (21,false), (6,false), (33,true), (17,true)]
  · exact sat_cons (p2477 F) ( sat_cons (p1791 F) ( sat_cons (p1366 F) ( sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p2159 F) ( sat_cons (p1913 F) ( sat_cons (p238 F) ( sat_cons (p16 F) ( sat_cons (p1920 F) (rfl))))))))))
  · rfl
def c2479 : CNF.Clause Nat := [(38,false), (86,false), (39,true), (40,false), (87,true), (50,false), (99,false), (110,false)]
theorem p2479 (F : Frame G 4) : c2479.eval F.assign = true := by
  apply explicit_rup F.assign c2479 [c1918, c1865, c2455, c2347, c2477, c1366, c1791, c2478, c27, c63, c1864, c1915, c238, c16, c1920] [(18,false), (15,false), (62,false), (98,false), (51,true), (88,false), (22,false), (29,false), (7,true), (26,true), (21,false), (6,false), (33,true), (17,true)]
  · exact sat_cons (p1918 F) ( sat_cons (p1865 F) ( sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p2477 F) ( sat_cons (p1366 F) ( sat_cons (p1791 F) ( sat_cons (p2478 F) ( sat_cons (p27 F) ( sat_cons (p63 F) ( sat_cons (p1864 F) ( sat_cons (p1915 F) ( sat_cons (p238 F) ( sat_cons (p16 F) ( sat_cons (p1920 F) (rfl)))))))))))))))
  · rfl
def c2480 : CNF.Clause Nat := [(39,true), (31,true), (87,true), (50,false), (99,false), (110,false)]
theorem p2480 (F : Frame G 4) : c2480.eval F.assign = true := by
  apply explicit_rup F.assign c2480 [c2468, c2455, c2347, c2476, c1865, c2479, c137, c10, c1366, c1791, c1866, c1915, c238, c16, c1920] [(40,true), (62,false), (98,false), (86,true), (15,false), (38,false), (51,true), (26,true), (88,false), (22,false), (21,false), (6,false), (33,true), (17,true)]
  · exact sat_cons (p2468 F) ( sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p2476 F) ( sat_cons (p1865 F) ( sat_cons (p2479 F) ( sat_cons (p137 F) ( sat_cons (p10 F) ( sat_cons (p1366 F) ( sat_cons (p1791 F) ( sat_cons (p1866 F) ( sat_cons (p1915 F) ( sat_cons (p238 F) ( sat_cons (p16 F) ( sat_cons (p1920 F) (rfl)))))))))))))))
  · rfl
def c2481 : CNF.Clause Nat := [(51,false), (86,false), (31,true), (87,true), (50,false), (99,false), (110,false)]
theorem p2481 (F : Frame G 4) : c2481.eval F.assign = true := by
  apply explicit_rup F.assign c2481 [c2480, c2468, c2347, c1644, c1366, c1791, c150, c242, c1845] [(39,true), (40,true), (98,false), (10,false), (88,false), (22,false), (21,true), (33,true)]
  · exact sat_cons (p2480 F) ( sat_cons (p2468 F) ( sat_cons (p2347 F) ( sat_cons (p1644 F) ( sat_cons (p1366 F) ( sat_cons (p1791 F) ( sat_cons (p150 F) ( sat_cons (p242 F) ( sat_cons (p1845 F) (rfl)))))))))
  · rfl
def c2482 : CNF.Clause Nat := [(86,false), (31,true), (87,true), (50,false), (99,false), (110,false)]
theorem p2482 (F : Frame G 4) : c2482.eval F.assign = true := by
  apply explicit_rup F.assign c2482 [c2480, c2468, c2455, c2347, c1865, c1918, c2481, c24, c18, c1633, c150, c1864, c1866, c69] [(39,true), (40,true), (62,false), (98,false), (15,false), (18,false), (51,false), (7,true), (29,true), (10,false), (21,true), (38,false), (26,false)]
  · exact sat_cons (p2480 F) ( sat_cons (p2468 F) ( sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p1865 F) ( sat_cons (p1918 F) ( sat_cons (p2481 F) ( sat_cons (p24 F) ( sat_cons (p18 F) ( sat_cons (p1633 F) ( sat_cons (p150 F) ( sat_cons (p1864 F) ( sat_cons (p1866 F) ( sat_cons (p69 F) (rfl))))))))))))))
  · rfl
def c2483 : CNF.Clause Nat := [(30,false), (38,true), (21,false), (51,true), (9,false), (88,false), (39,false), (40,false), (50,false), (99,false), (110,false)]
theorem p2483 (F : Frame G 4) : c2483.eval F.assign = true := by
  apply explicit_rup F.assign c2483 [c2455, c2032, c2026, c2012, c18, c78, c2239] [(62,false), (29,false), (5,false), (6,false), (18,true), (17,true)]
  · exact sat_cons (p2455 F) ( sat_cons (p2032 F) ( sat_cons (p2026 F) ( sat_cons (p2012 F) ( sat_cons (p18 F) ( sat_cons (p78 F) ( sat_cons (p2239 F) (rfl)))))))
  · rfl
def c2484 : CNF.Clause Nat := [(38,true), (21,false), (51,true), (31,true), (87,true), (50,false), (99,false), (110,false)]
theorem p2484 (F : Frame G 4) : c2484.eval F.assign = true := by
  apply explicit_rup F.assign c2484 [c2347, c2482, c147, c261, c2480, c2468, c2455, c2483, c144, c2021, c1325, c13, c24, c2020] [(98,false), (86,false), (9,true), (88,true), (39,true), (40,true), (62,false), (30,false), (19,true), (5,false), (18,false), (27,true), (7,true)]
  · exact sat_cons (p2347 F) ( sat_cons (p2482 F) ( sat_cons (p147 F) ( sat_cons (p261 F) ( sat_cons (p2480 F) ( sat_cons (p2468 F) ( sat_cons (p2455 F) ( sat_cons (p2483 F) ( sat_cons (p144 F) ( sat_cons (p2021 F) ( sat_cons (p1325 F) ( sat_cons (p13 F) ( sat_cons (p24 F) ( sat_cons (p2020 F) (rfl))))))))))))))
  · rfl
def c2485 : CNF.Clause Nat := [(21,false), (51,true), (31,true), (87,true), (50,false), (99,false), (110,false)]
theorem p2485 (F : Frame G 4) : c2485.eval F.assign = true := by
  apply explicit_rup F.assign c2485 [c2347, c2482, c147, c261, c2468, c2455, c2484, c2221, c1672, c18] [(98,false), (86,false), (9,true), (88,true), (40,true), (62,false), (38,true), (18,false), (29,false)]
  · exact sat_cons (p2347 F) ( sat_cons (p2482 F) ( sat_cons (p147 F) ( sat_cons (p261 F) ( sat_cons (p2468 F) ( sat_cons (p2455 F) ( sat_cons (p2484 F) ( sat_cons (p2221 F) ( sat_cons (p1672 F) ( sat_cons (p18 F) (rfl))))))))))
  · rfl
def c2486 : CNF.Clause Nat := [(51,true), (31,true), (87,true), (50,false), (99,false), (110,false)]
theorem p2486 (F : Frame G 4) : c2486.eval F.assign = true := by
  apply explicit_rup F.assign c2486 [c2347, c2482, c147, c261, c2480, c2468, c2455, c2485, c150, c2033, c18, c21, c2221, c1299, c1302, c13, c78, c2238, c2239, c144] [(98,false), (86,false), (9,true), (88,true), (39,true), (40,true), (62,false), (21,false), (10,true), (29,false), (18,true), (7,true), (38,false), (5,false), (6,false), (27,true), (17,true), (19,false), (30,false)]
  · exact sat_cons (p2347 F) ( sat_cons (p2482 F) ( sat_cons (p147 F) ( sat_cons (p261 F) ( sat_cons (p2480 F) ( sat_cons (p2468 F) ( sat_cons (p2455 F) ( sat_cons (p2485 F) ( sat_cons (p150 F) ( sat_cons (p2033 F) ( sat_cons (p18 F) ( sat_cons (p21 F) ( sat_cons (p2221 F) ( sat_cons (p1299 F) ( sat_cons (p1302 F) ( sat_cons (p13 F) ( sat_cons (p78 F) ( sat_cons (p2238 F) ( sat_cons (p2239 F) ( sat_cons (p144 F) (rfl))))))))))))))))))))
  · rfl
def c2487 : CNF.Clause Nat := [(31,true), (87,true), (50,false), (99,false), (110,false)]
theorem p2487 (F : Frame G 4) : c2487.eval F.assign = true := by
  apply explicit_rup F.assign c2487 [c2347, c2480, c2482, c2486, c2212, c2456] [(98,false), (39,true), (86,false), (51,true), (30,false)]
  · exact sat_cons (p2347 F) ( sat_cons (p2480 F) ( sat_cons (p2482 F) ( sat_cons (p2486 F) ( sat_cons (p2212 F) ( sat_cons (p2456 F) (rfl))))))
  · rfl
def c2488 : CNF.Clause Nat := [(86,true), (30,true), (39,false), (51,false), (31,false), (87,true), (50,false), (62,true), (98,true), (99,false)]
theorem p2488 (F : Frame G 4) : c2488.eval F.assign = true := by
  apply explicit_rup F.assign c2488 [c261, c144, c2175, c150, c2019, c2165, c1309, c9, c1695, c22, c25, c2179, c1329, c42] [(88,true), (19,true), (10,false), (21,true), (40,false), (38,false), (15,false), (26,true), (7,false), (29,true), (18,true), (6,false), (17,false)]
  · exact sat_cons (p261 F) ( sat_cons (p144 F) ( sat_cons (p2175 F) ( sat_cons (p150 F) ( sat_cons (p2019 F) ( sat_cons (p2165 F) ( sat_cons (p1309 F) ( sat_cons (p9 F) ( sat_cons (p1695 F) ( sat_cons (p22 F) ( sat_cons (p25 F) ( sat_cons (p2179 F) ( sat_cons (p1329 F) ( sat_cons (p42 F) (rfl))))))))))))))
  · rfl
def c2489 : CNF.Clause Nat := [(88,false), (18,false), (38,true), (21,false), (40,true), (39,false), (51,false), (87,true), (50,false), (99,false), (110,false)]
theorem p2489 (F : Frame G 4) : c2489.eval F.assign = true := by
  apply explicit_rup F.assign c2489 [c2347, c2455, c2487, c2212, c2488, c1845, c1791, c2161, c22, c1929, c2053, c109, c247, c1622] [(98,false), (62,false), (31,true), (30,false), (86,true), (33,false), (22,false), (7,false), (29,true), (5,false), (11,false), (27,true), (10,true)]
  · exact sat_cons (p2347 F) ( sat_cons (p2455 F) ( sat_cons (p2487 F) ( sat_cons (p2212 F) ( sat_cons (p2488 F) ( sat_cons (p1845 F) ( sat_cons (p1791 F) ( sat_cons (p2161 F) ( sat_cons (p22 F) ( sat_cons (p1929 F) ( sat_cons (p2053 F) ( sat_cons (p109 F) ( sat_cons (p247 F) ( sat_cons (p1622 F) (rfl))))))))))))))
  · rfl
def c2490 : CNF.Clause Nat := [(18,false), (38,true), (21,false), (40,true), (39,false), (51,false), (87,true), (50,false), (99,false), (110,false)]
theorem p2490 (F : Frame G 4) : c2490.eval F.assign = true := by
  apply explicit_rup F.assign c2490 [c2347, c2455, c2487, c2212, c2488, c1845, c1791, c2489, c142, c163, c1931, c2053, c22] [(98,false), (62,false), (31,true), (30,false), (86,true), (33,false), (22,false), (88,false), (19,true), (11,true), (7,false), (29,false)]
  · exact sat_cons (p2347 F) ( sat_cons (p2455 F) ( sat_cons (p2487 F) ( sat_cons (p2212 F) ( sat_cons (p2488 F) ( sat_cons (p1845 F) ( sat_cons (p1791 F) ( sat_cons (p2489 F) ( sat_cons (p142 F) ( sat_cons (p163 F) ( sat_cons (p1931 F) ( sat_cons (p2053 F) ( sat_cons (p22 F) (rfl)))))))))))))
  · rfl
def c2491 : CNF.Clause Nat := [(7,false), (86,false), (39,false), (51,false), (87,true), (99,false), (110,false)]
theorem p2491 (F : Frame G 4) : c2491.eval F.assign = true := by
  apply explicit_rup F.assign c2491 [c2212, c2161, c1931, c142] [(30,false), (88,false), (19,false)]
  · exact sat_cons (p2212 F) ( sat_cons (p2161 F) ( sat_cons (p1931 F) ( sat_cons (p142 F) (rfl))))
  · rfl
def c2492 : CNF.Clause Nat := [(88,true), (11,true), (22,true), (86,false), (39,false), (51,false), (87,true), (99,false), (110,false)]
theorem p2492 (F : Frame G 4) : c2492.eval F.assign = true := by
  apply explicit_rup F.assign c2492 [c2347, c163, c241, c1845] [(98,false), (33,true), (21,true)]
  · exact sat_cons (p2347 F) ( sat_cons (p163 F) ( sat_cons (p241 F) ( sat_cons (p1845 F) (rfl))))
  · rfl
def c2493 : CNF.Clause Nat := [(21,false), (40,true), (39,false), (51,false), (87,true), (50,false), (99,false), (110,false)]
theorem p2493 (F : Frame G 4) : c2493.eval F.assign = true := by
  apply explicit_rup F.assign c2493 [c2455, c2347, c2487, c2212, c2488, c2491, c25, c22, c2159, c2490] [(62,false), (98,false), (31,true), (30,false), (86,true), (7,false), (18,true), (29,true), (38,false)]
  · exact sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p2487 F) ( sat_cons (p2212 F) ( sat_cons (p2488 F) ( sat_cons (p2491 F) ( sat_cons (p25 F) ( sat_cons (p22 F) ( sat_cons (p2159 F) ( sat_cons (p2490 F) (rfl))))))))))
  · rfl
def c2494 : CNF.Clause Nat := [(40,true), (39,false), (51,false), (87,true), (50,false), (99,false), (110,false)]
theorem p2494 (F : Frame G 4) : c2494.eval F.assign = true := by
  apply explicit_rup F.assign c2494 [c2347, c2455, c2487, c2212, c2488, c2491, c1791, c22, c25, c2053, c2492, c2493, c150, c1623, c2172, c2042, c9] [(98,false), (62,false), (31,true), (30,false), (86,true), (7,false), (22,false), (29,true), (18,true), (11,false), (88,true), (21,false), (10,true), (38,false), (15,false), (26,false)]
  · exact sat_cons (p2347 F) ( sat_cons (p2455 F) ( sat_cons (p2487 F) ( sat_cons (p2212 F) ( sat_cons (p2488 F) ( sat_cons (p2491 F) ( sat_cons (p1791 F) ( sat_cons (p22 F) ( sat_cons (p25 F) ( sat_cons (p2053 F) ( sat_cons (p2492 F) ( sat_cons (p2493 F) ( sat_cons (p150 F) ( sat_cons (p1623 F) ( sat_cons (p2172 F) ( sat_cons (p2042 F) ( sat_cons (p9 F) (rfl)))))))))))))))))
  · rfl
def c2495 : CNF.Clause Nat := [(39,false), (51,false), (87,true), (50,false), (99,false), (110,false)]
theorem p2495 (F : Frame G 4) : c2495.eval F.assign = true := by
  apply explicit_rup F.assign c2495 [c2487, c2455, c2347, c2212, c2488, c1791, c2494, c1644, c1366, c150, c242, c1845] [(31,true), (62,false), (98,false), (30,false), (86,true), (22,false), (40,true), (10,false), (88,false), (21,true), (33,true)]
  · exact sat_cons (p2487 F) ( sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p2212 F) ( sat_cons (p2488 F) ( sat_cons (p1791 F) ( sat_cons (p2494 F) ( sat_cons (p1644 F) ( sat_cons (p1366 F) ( sat_cons (p150 F) ( sat_cons (p242 F) ( sat_cons (p1845 F) (rfl))))))))))))
  · rfl
def c2496 : CNF.Clause Nat := [(40,false), (21,false), (86,false), (39,true), (87,true), (50,false), (99,false), (110,false)]
theorem p2496 (F : Frame G 4) : c2496.eval F.assign = true := by
  apply explicit_rup F.assign c2496 [c1865, c2479, c1866, c10] [(15,false), (38,false), (26,false)]
  · exact sat_cons (p1865 F) ( sat_cons (p2479 F) ( sat_cons (p1866 F) ( sat_cons (p10 F) (rfl))))
  · rfl
def c2497 : CNF.Clause Nat := [(21,false), (86,false), (51,false), (87,true), (50,false), (99,false), (110,false)]
theorem p2497 (F : Frame G 4) : c2497.eval F.assign = true := by
  apply explicit_rup F.assign c2497 [c1791, c2495, c2487, c2455, c2347, c2496, c134, c2159, c19, c22, c2039, c2038, c8, c16, c1695, c2042, c1283, c246] [(22,false), (39,false), (31,true), (62,false), (98,false), (40,false), (38,true), (29,false), (18,true), (7,true), (15,false), (17,false), (26,true), (6,true), (88,false), (10,false), (11,false)]
  · exact sat_cons (p1791 F) ( sat_cons (p2495 F) ( sat_cons (p2487 F) ( sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p2496 F) ( sat_cons (p134 F) ( sat_cons (p2159 F) ( sat_cons (p19 F) ( sat_cons (p22 F) ( sat_cons (p2039 F) ( sat_cons (p2038 F) ( sat_cons (p8 F) ( sat_cons (p16 F) ( sat_cons (p1695 F) ( sat_cons (p2042 F) ( sat_cons (p1283 F) ( sat_cons (p246 F) (rfl))))))))))))))))))
  · rfl
def c2498 : CNF.Clause Nat := [(26,false), (40,true), (10,false), (86,false), (39,true), (51,false), (31,false), (50,false), (99,false), (110,false)]
theorem p2498 (F : Frame G 4) : c2498.eval F.assign = true := by
  apply explicit_rup F.assign c2498 [c2455, c2347, c2042, c1340, c19] [(62,false), (98,false), (18,false), (29,false)]
  · exact sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p2042 F) ( sat_cons (p1340 F) ( sat_cons (p19 F) (rfl)))))
  · rfl
def c2499 : CNF.Clause Nat := [(18,true), (15,false), (40,true), (10,false), (86,false), (39,true), (51,false), (87,true), (62,true), (99,false)]
theorem p2499 (F : Frame G 4) : c2499.eval F.assign = true := by
  apply explicit_rup F.assign c2499 [c134, c25, c19, c1282, c1640, c16] [(38,true), (7,true), (29,true), (6,false), (17,false)]
  · exact sat_cons (p134 F) ( sat_cons (p25 F) ( sat_cons (p19 F) ( sat_cons (p1282 F) ( sat_cons (p1640 F) ( sat_cons (p16 F) (rfl))))))
  · rfl
def c2500 : CNF.Clause Nat := [(40,true), (86,false), (51,false), (87,true), (50,false), (99,false), (110,false)]
theorem p2500 (F : Frame G 4) : c2500.eval F.assign = true := by
  apply explicit_rup F.assign c2500 [c2347, c2497, c150, c2495, c2487, c2455, c134, c2498, c8, c2499, c2039, c1917, c22] [(98,false), (21,false), (10,true), (39,false), (31,true), (62,false), (38,true), (26,false), (15,true), (18,true), (7,false), (29,false)]
  · exact sat_cons (p2347 F) ( sat_cons (p2497 F) ( sat_cons (p150 F) ( sat_cons (p2495 F) ( sat_cons (p2487 F) ( sat_cons (p2455 F) ( sat_cons (p134 F) ( sat_cons (p2498 F) ( sat_cons (p8 F) ( sat_cons (p2499 F) ( sat_cons (p2039 F) ( sat_cons (p1917 F) ( sat_cons (p22 F) (rfl)))))))))))))
  · rfl
end Cert44Steps
end Graffiti199Depleted.Catalogue.OrderEleven
