import Explicit44Part0
namespace Graffiti199Depleted.Catalogue.OrderEleven
namespace Cert44Steps
open Std.Sat
set_option maxRecDepth 4096
set_option maxHeartbeats 0
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj]
def c2501 : CNF.Clause Nat := [(86,false), (51,false), (87,true), (50,false), (99,false), (110,false)]
theorem p2501 (F : Frame G 4) : c2501.eval F.assign = true := by
  apply explicit_rup F.assign c2501 [c2495, c2487, c2455, c2500, c1919, c1865, c2479, c16, c10, c1915] [(39,false), (31,true), (62,false), (40,true), (17,false), (15,false), (38,false), (6,true), (26,true)]
  · exact sat_cons (p2495 F) ( sat_cons (p2487 F) ( sat_cons (p2455 F) ( sat_cons (p2500 F) ( sat_cons (p1919 F) ( sat_cons (p1865 F) ( sat_cons (p2479 F) ( sat_cons (p16 F) ( sat_cons (p10 F) ( sat_cons (p1915 F) (rfl))))))))))
  · rfl
def c2502 : CNF.Clause Nat := [(15,true), (38,true), (19,false), (40,false), (51,false), (87,true), (50,false), (99,false), (110,false)]
theorem p2502 (F : Frame G 4) : c2502.eval F.assign = true := by
  apply explicit_rup F.assign c2502 [c2487, c2501, c261, c2031, c2495, c2455, c2347, c60, c58, c2137, c2178, c150, c16, c1329] [(31,true), (86,false), (88,true), (7,false), (39,false), (62,false), (98,false), (18,true), (29,true), (10,false), (6,false), (21,true), (17,true)]
  · exact sat_cons (p2487 F) ( sat_cons (p2501 F) ( sat_cons (p261 F) ( sat_cons (p2031 F) ( sat_cons (p2495 F) ( sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p60 F) ( sat_cons (p58 F) ( sat_cons (p2137 F) ( sat_cons (p2178 F) ( sat_cons (p150 F) ( sat_cons (p16 F) ( sat_cons (p1329 F) (rfl))))))))))))))
  · rfl
def c2503 : CNF.Clause Nat := [(38,true), (26,false), (40,false), (51,false), (87,true), (50,false), (99,false), (110,false)]
theorem p2503 (F : Frame G 4) : c2503.eval F.assign = true := by
  apply explicit_rup F.assign c2503 [c2501, c2347, c2495, c2487, c1342, c144, c261, c2031, c2455, c2502, c1309, c150, c2137, c2243, c27] [(86,false), (98,false), (39,false), (31,true), (30,false), (19,true), (88,true), (7,false), (62,false), (15,true), (21,false), (10,true), (18,false), (29,false)]
  · exact sat_cons (p2501 F) ( sat_cons (p2347 F) ( sat_cons (p2495 F) ( sat_cons (p2487 F) ( sat_cons (p1342 F) ( sat_cons (p144 F) ( sat_cons (p261 F) ( sat_cons (p2031 F) ( sat_cons (p2455 F) ( sat_cons (p2502 F) ( sat_cons (p1309 F) ( sat_cons (p150 F) ( sat_cons (p2137 F) ( sat_cons (p2243 F) ( sat_cons (p27 F) (rfl)))))))))))))))
  · rfl
def c2504 : CNF.Clause Nat := [(21,false), (38,false), (19,false), (40,false), (88,false), (39,true), (31,false), (50,false), (62,true), (99,false)]
theorem p2504 (F : Frame G 4) : c2504.eval F.assign = true := by
  apply explicit_rup F.assign c2504 [c2230, c1424, c16] [(17,false), (6,false)]
  · exact sat_cons (p2230 F) ( sat_cons (p1424 F) ( sat_cons (p16 F) (rfl)))
  · rfl
def c2505 : CNF.Clause Nat := [(26,false), (40,false), (51,false), (87,true), (50,false), (99,false), (110,false)]
theorem p2505 (F : Frame G 4) : c2505.eval F.assign = true := by
  apply explicit_rup F.assign c2505 [c2487, c2501, c261, c2031, c2495, c2455, c2347, c1342, c144, c2503, c2504, c150, c2137, c27, c2136, c2178, c16] [(31,true), (86,false), (88,true), (7,false), (39,false), (62,false), (98,false), (30,false), (19,true), (38,true), (21,false), (10,true), (18,false), (29,true), (17,false), (6,false)]
  · exact sat_cons (p2487 F) ( sat_cons (p2501 F) ( sat_cons (p261 F) ( sat_cons (p2031 F) ( sat_cons (p2495 F) ( sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p1342 F) ( sat_cons (p144 F) ( sat_cons (p2503 F) ( sat_cons (p2504 F) ( sat_cons (p150 F) ( sat_cons (p2137 F) ( sat_cons (p27 F) ( sat_cons (p2136 F) ( sat_cons (p2178 F) ( sat_cons (p16 F) (rfl)))))))))))))))))
  · rfl
def c2506 : CNF.Clause Nat := [(10,false), (40,false), (51,false), (87,true), (50,false), (99,false), (110,false)]
theorem p2506 (F : Frame G 4) : c2506.eval F.assign = true := by
  apply explicit_rup F.assign c2506 [c2505, c2487, c2501, c261, c2031, c2495, c2455, c2347, c2137, c53, c27, c1360, c2136, c144, c16, c2178] [(26,false), (31,true), (86,false), (88,true), (7,false), (39,false), (62,false), (98,false), (18,false), (38,true), (29,true), (30,false), (17,false), (19,true), (6,true)]
  · exact sat_cons (p2505 F) ( sat_cons (p2487 F) ( sat_cons (p2501 F) ( sat_cons (p261 F) ( sat_cons (p2031 F) ( sat_cons (p2495 F) ( sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p2137 F) ( sat_cons (p53 F) ( sat_cons (p27 F) ( sat_cons (p1360 F) ( sat_cons (p2136 F) ( sat_cons (p144 F) ( sat_cons (p16 F) ( sat_cons (p2178 F) (rfl))))))))))))))))
  · rfl
def c2507 : CNF.Clause Nat := [(38,false), (40,false), (51,false), (87,true), (50,false), (99,false), (110,false)]
theorem p2507 (F : Frame G 4) : c2507.eval F.assign = true := by
  apply explicit_rup F.assign c2507 [c2347, c2506, c150, c2487, c2501, c261, c2031, c2495, c2455, c1672, c2230, c2504, c27, c16, c144, c1958] [(98,false), (10,false), (21,true), (31,true), (86,false), (88,true), (7,false), (39,false), (62,false), (29,false), (17,false), (19,false), (18,true), (6,true), (30,true)]
  · exact sat_cons (p2347 F) ( sat_cons (p2506 F) ( sat_cons (p150 F) ( sat_cons (p2487 F) ( sat_cons (p2501 F) ( sat_cons (p261 F) ( sat_cons (p2031 F) ( sat_cons (p2495 F) ( sat_cons (p2455 F) ( sat_cons (p1672 F) ( sat_cons (p2230 F) ( sat_cons (p2504 F) ( sat_cons (p27 F) ( sat_cons (p16 F) ( sat_cons (p144 F) ( sat_cons (p1958 F) (rfl))))))))))))))))
  · rfl
def c2508 : CNF.Clause Nat := [(40,false), (51,false), (87,true), (50,false), (99,false), (110,false)]
theorem p2508 (F : Frame G 4) : c2508.eval F.assign = true := by
  apply explicit_rup F.assign c2508 [c2501, c261, c2495, c2487, c2455, c2347, c2031, c2505, c2506, c150, c2507, c10, c51, c1309, c1360, c144] [(86,false), (88,true), (39,false), (31,true), (62,false), (98,false), (7,false), (26,false), (10,false), (21,true), (38,false), (15,true), (29,true), (19,false), (30,false)]
  · exact sat_cons (p2501 F) ( sat_cons (p261 F) ( sat_cons (p2495 F) ( sat_cons (p2487 F) ( sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p2031 F) ( sat_cons (p2505 F) ( sat_cons (p2506 F) ( sat_cons (p150 F) ( sat_cons (p2507 F) ( sat_cons (p10 F) ( sat_cons (p51 F) ( sat_cons (p1309 F) ( sat_cons (p1360 F) ( sat_cons (p144 F) (rfl))))))))))))))))
  · rfl
def c2509 : CNF.Clause Nat := [(30,false), (51,false), (87,true), (50,false), (99,false), (110,false)]
theorem p2509 (F : Frame G 4) : c2509.eval F.assign = true := by
  apply explicit_rup F.assign c2509 [c2495, c2508, c134, c2501, c2487, c2455, c2347, c1360, c19, c22, c1958, c2131, c16] [(39,false), (40,false), (38,true), (86,false), (31,true), (62,false), (98,false), (29,false), (18,true), (7,true), (6,false), (17,false)]
  · exact sat_cons (p2495 F) ( sat_cons (p2508 F) ( sat_cons (p134 F) ( sat_cons (p2501 F) ( sat_cons (p2487 F) ( sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p1360 F) ( sat_cons (p19 F) ( sat_cons (p22 F) ( sat_cons (p1958 F) ( sat_cons (p2131 F) ( sat_cons (p16 F) (rfl)))))))))))))
  · rfl
def c2510 : CNF.Clause Nat := [(29,true), (19,false), (40,true), (88,false), (39,true), (51,false), (31,false), (50,false), (62,true), (99,false)]
theorem p2510 (F : Frame G 4) : c2510.eval F.assign = true := by
  apply explicit_rup F.assign c2510 [c134, c19, c22, c1669, c2132, c16] [(38,true), (18,true), (7,true), (6,false), (17,false)]
  · exact sat_cons (p134 F) ( sat_cons (p19 F) ( sat_cons (p22 F) ( sat_cons (p1669 F) ( sat_cons (p2132 F) ( sat_cons (p16 F) (rfl))))))
  · rfl
def c2511 : CNF.Clause Nat := [(51,false), (87,true), (50,false), (99,false), (110,false)]
theorem p2511 (F : Frame G 4) : c2511.eval F.assign = true := by
  apply explicit_rup F.assign c2511 [c2487, c2455, c2347, c2495, c2501, c261, c2508, c134, c2509, c144, c2510, c1340, c2178, c8, c16, c1313, c2123, c25] [(31,true), (62,false), (98,false), (39,false), (86,false), (88,true), (40,false), (38,true), (30,false), (19,true), (29,true), (26,false), (6,false), (15,true), (17,true), (18,false), (7,false)]
  · exact sat_cons (p2487 F) ( sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p2495 F) ( sat_cons (p2501 F) ( sat_cons (p261 F) ( sat_cons (p2508 F) ( sat_cons (p134 F) ( sat_cons (p2509 F) ( sat_cons (p144 F) ( sat_cons (p2510 F) ( sat_cons (p1340 F) ( sat_cons (p2178 F) ( sat_cons (p8 F) ( sat_cons (p16 F) ( sat_cons (p1313 F) ( sat_cons (p2123 F) ( sat_cons (p25 F) (rfl))))))))))))))))))
  · rfl
def c2512 : CNF.Clause Nat := [(86,true), (87,true), (50,false), (99,false), (110,false)]
theorem p2512 (F : Frame G 4) : c2512.eval F.assign = true := by
  apply explicit_rup F.assign c2512 [c2455, c2511, c138, c2487, c2347, c261, c2031, c24, c21, c2137, c1360, c150, c144, c1325] [(62,false), (51,false), (40,true), (31,true), (98,false), (88,true), (7,false), (18,true), (29,true), (10,false), (30,false), (21,true), (19,true)]
  · exact sat_cons (p2455 F) ( sat_cons (p2511 F) ( sat_cons (p138 F) ( sat_cons (p2487 F) ( sat_cons (p2347 F) ( sat_cons (p261 F) ( sat_cons (p2031 F) ( sat_cons (p24 F) ( sat_cons (p21 F) ( sat_cons (p2137 F) ( sat_cons (p1360 F) ( sat_cons (p150 F) ( sat_cons (p144 F) ( sat_cons (p1325 F) (rfl))))))))))))))
  · rfl
def c2513 : CNF.Clause Nat := [(39,true), (87,true), (50,false), (99,false), (110,false)]
theorem p2513 (F : Frame G 4) : c2513.eval F.assign = true := by
  apply explicit_rup F.assign c2513 [c2512, c2455, c2511, c138, c137, c2479] [(86,true), (62,false), (51,false), (40,true), (38,true)]
  · exact sat_cons (p2512 F) ( sat_cons (p2455 F) ( sat_cons (p2511 F) ( sat_cons (p138 F) ( sat_cons (p137 F) ( sat_cons (p2479 F) (rfl))))))
  · rfl
def c2514 : CNF.Clause Nat := [(87,true), (50,false), (99,false), (110,false)]
theorem p2514 (F : Frame G 4) : c2514.eval F.assign = true := by
  apply explicit_rup F.assign c2514 [c2455, c2487, c2511, c138, c2512, c1918, c24, c2031, c2513, c1991, c1906, c142] [(62,false), (31,true), (51,false), (40,true), (86,true), (18,false), (7,true), (88,false), (39,true), (19,false), (30,false)]
  · exact sat_cons (p2455 F) ( sat_cons (p2487 F) ( sat_cons (p2511 F) ( sat_cons (p138 F) ( sat_cons (p2512 F) ( sat_cons (p1918 F) ( sat_cons (p24 F) ( sat_cons (p2031 F) ( sat_cons (p2513 F) ( sat_cons (p1991 F) ( sat_cons (p1906 F) ( sat_cons (p142 F) (rfl))))))))))))
  · rfl
def c2515 : CNF.Clause Nat := [(86,false), (51,true), (50,false), (99,false), (110,false)]
theorem p2515 (F : Frame G 4) : c2515.eval F.assign = true := by
  apply explicit_rup F.assign c2515 [c2455, c138, c2514, c2347, c1865, c1918, c24, c18, c2201, c1880, c1636, c81, c76, c16, c62, c1912, c2226, c1928, c1776, c2017, c178] [(62,false), (40,true), (87,true), (98,false), (15,false), (18,false), (7,true), (29,true), (27,false), (6,false), (39,false), (5,true), (38,true), (17,true), (26,true), (88,false), (19,false), (21,false), (10,false), (30,false)]
  · exact sat_cons (p2455 F) ( sat_cons (p138 F) ( sat_cons (p2514 F) ( sat_cons (p2347 F) ( sat_cons (p1865 F) ( sat_cons (p1918 F) ( sat_cons (p24 F) ( sat_cons (p18 F) ( sat_cons (p2201 F) ( sat_cons (p1880 F) ( sat_cons (p1636 F) ( sat_cons (p81 F) ( sat_cons (p76 F) ( sat_cons (p16 F) ( sat_cons (p62 F) ( sat_cons (p1912 F) ( sat_cons (p2226 F) ( sat_cons (p1928 F) ( sat_cons (p1776 F) ( sat_cons (p2017 F) ( sat_cons (p178 F) (rfl)))))))))))))))))))))
  · rfl
def c2516 : CNF.Clause Nat := [(39,true), (7,false), (19,true), (51,true), (50,false), (99,false), (110,false)]
theorem p2516 (F : Frame G 4) : c2516.eval F.assign = true := by
  apply explicit_rup F.assign c2516 [c2514, c2455, c138, c2201, c2234, c2515, c137, c1963, c62, c1980, c16, c81, c2017, c1700, c143] [(87,true), (62,false), (40,true), (27,false), (15,false), (86,false), (38,true), (18,false), (26,true), (6,false), (17,true), (5,true), (30,false), (88,false)]
  · exact sat_cons (p2514 F) ( sat_cons (p2455 F) ( sat_cons (p138 F) ( sat_cons (p2201 F) ( sat_cons (p2234 F) ( sat_cons (p2515 F) ( sat_cons (p137 F) ( sat_cons (p1963 F) ( sat_cons (p62 F) ( sat_cons (p1980 F) ( sat_cons (p16 F) ( sat_cons (p81 F) ( sat_cons (p2017 F) ( sat_cons (p1700 F) ( sat_cons (p143 F) (rfl)))))))))))))))
  · rfl
def c2517 : CNF.Clause Nat := [(18,false), (39,false), (7,false), (51,true), (87,false), (99,false), (110,false)]
theorem p2517 (F : Frame G 4) : c2517.eval F.assign = true := by
  apply explicit_rup F.assign c2517 [c2455, c138, c2201, c1984, c1985, c13] [(62,false), (40,true), (27,false), (38,false), (5,false)]
  · exact sat_cons (p2455 F) ( sat_cons (p138 F) ( sat_cons (p2201 F) ( sat_cons (p1984 F) ( sat_cons (p1985 F) ( sat_cons (p13 F) (rfl))))))
  · rfl
def c2518 : CNF.Clause Nat := [(17,false), (29,false), (39,false), (7,false), (86,true), (40,false), (87,false), (98,true), (99,false)]
theorem p2518 (F : Frame G 4) : c2518.eval F.assign = true := by
  apply explicit_rup F.assign c2518 [c1641, c1757, c147] [(31,false), (9,false)]
  · exact sat_cons (p1641 F) ( sat_cons (p1757 F) ( sat_cons (p147 F) (rfl)))
  · rfl
def c2519 : CNF.Clause Nat := [(38,true), (17,true), (18,true), (27,true), (15,true), (51,true), (50,false), (99,false), (110,false)]
theorem p2519 (F : Frame G 4) : c2519.eval F.assign = true := by
  apply explicit_rup F.assign c2519 [c2455, c138, c2514, c69, c77, c1980] [(62,false), (40,true), (87,true), (26,true), (6,true)]
  · exact sat_cons (p2455 F) ( sat_cons (p138 F) ( sat_cons (p2514 F) ( sat_cons (p69 F) ( sat_cons (p77 F) ( sat_cons (p1980 F) (rfl))))))
  · rfl
def c2520 : CNF.Clause Nat := [(6,false), (19,true), (51,true), (50,false), (99,false), (110,false)]
theorem p2520 (F : Frame G 4) : c2520.eval F.assign = true := by
  apply explicit_rup F.assign c2520 [c2515, c2455, c138, c2514, c1981, c1770, c143] [(86,false), (62,false), (40,true), (87,true), (30,false), (88,false)]
  · exact sat_cons (p2515 F) ( sat_cons (p2455 F) ( sat_cons (p138 F) ( sat_cons (p2514 F) ( sat_cons (p1981 F) ( sat_cons (p1770 F) ( sat_cons (p143 F) (rfl)))))))
  · rfl
def c2521 : CNF.Clause Nat := [(30,true), (21,true), (29,false), (39,false), (19,true), (86,true), (40,false), (87,false), (50,false), (98,true), (99,false)]
theorem p2521 (F : Frame G 4) : c2521.eval F.assign = true := by
  apply explicit_rup F.assign c2521 [c143, c181, c2033] [(88,true), (10,true)]
  · exact sat_cons (p143 F) ( sat_cons (p181 F) ( sat_cons (p2033 F) (rfl)))
  · rfl
def c2522 : CNF.Clause Nat := [(7,false), (19,true), (51,true), (50,false), (99,false), (110,false)]
theorem p2522 (F : Frame G 4) : c2522.eval F.assign = true := by
  apply explicit_rup F.assign c2522 [c2515, c2455, c138, c2514, c2347, c2234, c2201, c2516, c2517, c18, c2518, c2519, c1773, c2521, c2032, c1906, c147] [(86,false), (62,false), (40,true), (87,true), (98,false), (15,false), (27,false), (39,true), (18,false), (29,true), (17,false), (38,true), (21,false), (30,true), (9,false), (31,false)]
  · exact sat_cons (p2515 F) ( sat_cons (p2455 F) ( sat_cons (p138 F) ( sat_cons (p2514 F) ( sat_cons (p2347 F) ( sat_cons (p2234 F) ( sat_cons (p2201 F) ( sat_cons (p2516 F) ( sat_cons (p2517 F) ( sat_cons (p18 F) ( sat_cons (p2518 F) ( sat_cons (p2519 F) ( sat_cons (p1773 F) ( sat_cons (p2521 F) ( sat_cons (p2032 F) ( sat_cons (p1906 F) ( sat_cons (p147 F) (rfl)))))))))))))))))
  · rfl
def c2523 : CNF.Clause Nat := [(19,true), (51,true), (50,false), (99,false), (110,false)]
theorem p2523 (F : Frame G 4) : c2523.eval F.assign = true := by
  apply explicit_rup F.assign c2523 [c2515, c2455, c138, c2514, c2347, c2520, c2522, c24, c21, c1963, c1904, c137, c1985, c78, c1757, c147, c1817, c1771, c218] [(86,false), (62,false), (40,true), (87,true), (98,false), (6,false), (7,false), (18,true), (29,true), (38,false), (22,false), (39,true), (5,false), (17,true), (9,false), (31,true), (88,false), (11,false)]
  · exact sat_cons (p2515 F) ( sat_cons (p2455 F) ( sat_cons (p138 F) ( sat_cons (p2514 F) ( sat_cons (p2347 F) ( sat_cons (p2520 F) ( sat_cons (p2522 F) ( sat_cons (p24 F) ( sat_cons (p21 F) ( sat_cons (p1963 F) ( sat_cons (p1904 F) ( sat_cons (p137 F) ( sat_cons (p1985 F) ( sat_cons (p78 F) ( sat_cons (p1757 F) ( sat_cons (p147 F) ( sat_cons (p1817 F) ( sat_cons (p1771 F) ( sat_cons (p218 F) (rfl)))))))))))))))))))
  · rfl
def c2524 : CNF.Clause Nat := [(7,true), (51,true), (50,false), (99,false), (110,false)]
theorem p2524 (F : Frame G 4) : c2524.eval F.assign = true := by
  apply explicit_rup F.assign c2524 [c2523, c2515, c2455, c138, c2514, c2347, c24, c21, c1963, c1904, c2226, c137, c13, c2241, c78, c1757, c147, c1817, c1771, c218] [(19,true), (86,false), (62,false), (40,true), (87,true), (98,false), (18,true), (29,true), (38,false), (22,false), (5,false), (39,true), (27,true), (6,false), (17,true), (9,false), (31,true), (88,false), (11,false)]
  · exact sat_cons (p2523 F) ( sat_cons (p2515 F) ( sat_cons (p2455 F) ( sat_cons (p138 F) ( sat_cons (p2514 F) ( sat_cons (p2347 F) ( sat_cons (p24 F) ( sat_cons (p21 F) ( sat_cons (p1963 F) ( sat_cons (p1904 F) ( sat_cons (p2226 F) ( sat_cons (p137 F) ( sat_cons (p13 F) ( sat_cons (p2241 F) ( sat_cons (p78 F) ( sat_cons (p1757 F) ( sat_cons (p147 F) ( sat_cons (p1817 F) ( sat_cons (p1771 F) ( sat_cons (p218 F) (rfl))))))))))))))))))))
  · rfl
def c2525 : CNF.Clause Nat := [(39,false), (51,true), (50,false), (99,false), (110,false)]
theorem p2525 (F : Frame G 4) : c2525.eval F.assign = true := by
  apply explicit_rup F.assign c2525 [c2524, c2523, c2515, c2455, c138, c2514, c2347, c1991, c1983, c147] [(7,true), (19,true), (86,false), (62,false), (40,true), (87,true), (98,false), (31,false), (9,false)]
  · exact sat_cons (p2524 F) ( sat_cons (p2523 F) ( sat_cons (p2515 F) ( sat_cons (p2455 F) ( sat_cons (p138 F) ( sat_cons (p2514 F) ( sat_cons (p2347 F) ( sat_cons (p1991 F) ( sat_cons (p1983 F) ( sat_cons (p147 F) (rfl))))))))))
  · rfl
def c2526 : CNF.Clause Nat := [(51,true), (50,false), (99,false), (110,false)]
theorem p2526 (F : Frame G 4) : c2526.eval F.assign = true := by
  apply explicit_rup F.assign c2526 [c2514, c2455, c138, c2523, c2524, c2201, c2525, c137, c1963, c18, c1650, c2226, c81] [(87,true), (62,false), (40,true), (19,true), (7,true), (27,false), (39,false), (38,true), (18,false), (29,true), (6,false), (5,false)]
  · exact sat_cons (p2514 F) ( sat_cons (p2455 F) ( sat_cons (p138 F) ( sat_cons (p2523 F) ( sat_cons (p2524 F) ( sat_cons (p2201 F) ( sat_cons (p2525 F) ( sat_cons (p137 F) ( sat_cons (p1963 F) ( sat_cons (p18 F) ( sat_cons (p1650 F) ( sat_cons (p2226 F) ( sat_cons (p81 F) (rfl)))))))))))))
  · rfl
def c2527 : CNF.Clause Nat := [(17,false), (31,true), (40,false), (51,false), (87,false), (98,true), (99,false)]
theorem p2527 (F : Frame G 4) : c2527.eval F.assign = true := by
  apply explicit_rup F.assign c2527 [c1891, c1702, c147] [(86,false), (9,false)]
  · exact sat_cons (p1891 F) ( sat_cons (p1702 F) ( sat_cons (p147 F) (rfl)))
  · rfl
def c2528 : CNF.Clause Nat := [(7,false), (19,false), (40,false), (50,false), (99,false), (110,false)]
theorem p2528 (F : Frame G 4) : c2528.eval F.assign = true := by
  apply explicit_rup F.assign c2528 [c2514, c2526, c2203, c1792, c2455, c2347, c1823, c2084, c2527, c16, c1770, c1760, c214] [(87,true), (51,true), (22,false), (39,false), (62,false), (98,false), (33,false), (31,false), (17,false), (6,true), (88,false), (86,false)]
  · exact sat_cons (p2514 F) ( sat_cons (p2526 F) ( sat_cons (p2203 F) ( sat_cons (p1792 F) ( sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p1823 F) ( sat_cons (p2084 F) ( sat_cons (p2527 F) ( sat_cons (p16 F) ( sat_cons (p1770 F) ( sat_cons (p1760 F) ( sat_cons (p214 F) (rfl)))))))))))))
  · rfl
def c2529 : CNF.Clause Nat := [(6,false), (19,false), (40,false), (50,false), (99,false), (110,false)]
theorem p2529 (F : Frame G 4) : c2529.eval F.assign = true := by
  apply explicit_rup F.assign c2529 [c2528, c2514, c2526, c1698, c2203, c1792, c2455, c2347, c1981, c1770, c1760, c1980, c174, c2321, c2235, c147, c217, c2191] [(7,false), (87,true), (51,true), (21,false), (22,false), (39,false), (62,false), (98,false), (30,false), (88,false), (86,false), (26,false), (10,true), (15,true), (9,false), (31,true), (33,true)]
  · exact sat_cons (p2528 F) ( sat_cons (p2514 F) ( sat_cons (p2526 F) ( sat_cons (p1698 F) ( sat_cons (p2203 F) ( sat_cons (p1792 F) ( sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p1981 F) ( sat_cons (p1770 F) ( sat_cons (p1760 F) ( sat_cons (p1980 F) ( sat_cons (p174 F) ( sat_cons (p2321 F) ( sat_cons (p2235 F) ( sat_cons (p147 F) ( sat_cons (p217 F) ( sat_cons (p2191 F) (rfl))))))))))))))))))
  · rfl
def c2530 : CNF.Clause Nat := [(19,false), (40,false), (50,false), (99,false), (110,false)]
theorem p2530 (F : Frame G 4) : c2530.eval F.assign = true := by
  apply explicit_rup F.assign c2530 [c2514, c2526, c1792, c2455, c2347, c2529, c16, c2173, c2527] [(87,true), (51,true), (39,false), (62,false), (98,false), (6,false), (17,true), (31,false)]
  · exact sat_cons (p2514 F) ( sat_cons (p2526 F) ( sat_cons (p1792 F) ( sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p2529 F) ( sat_cons (p16 F) ( sat_cons (p2173 F) ( sat_cons (p2527 F) (rfl)))))))))
  · rfl
def c2531 : CNF.Clause Nat := [(17,false), (22,true), (40,false), (51,false), (87,false), (98,true), (99,false)]
theorem p2531 (F : Frame G 4) : c2531.eval F.assign = true := by
  apply explicit_rup F.assign c2531 [c1891, c1702, c2527, c2237, c2174, c218] [(86,false), (9,false), (31,true), (11,false), (88,false)]
  · exact sat_cons (p1891 F) ( sat_cons (p1702 F) ( sat_cons (p2527 F) ( sat_cons (p2237 F) ( sat_cons (p2174 F) ( sat_cons (p218 F) (rfl))))))
  · rfl
def c2532 : CNF.Clause Nat := [(40,false), (50,false), (99,false), (110,false)]
theorem p2532 (F : Frame G 4) : c2532.eval F.assign = true := by
  apply explicit_rup F.assign c2532 [c2514, c2526, c1792, c2455, c2347, c2203, c2530, c2531, c16, c1981, c1770, c1760, c143] [(87,true), (51,true), (39,false), (62,false), (98,false), (22,false), (19,false), (17,false), (6,true), (30,false), (88,false), (86,false)]
  · exact sat_cons (p2514 F) ( sat_cons (p2526 F) ( sat_cons (p1792 F) ( sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p2203 F) ( sat_cons (p2530 F) ( sat_cons (p2531 F) ( sat_cons (p16 F) ( sat_cons (p1981 F) ( sat_cons (p1770 F) ( sat_cons (p1760 F) ( sat_cons (p143 F) (rfl)))))))))))))
  · rfl
def c2533 : CNF.Clause Nat := [(7,false), (22,true), (86,true), (88,true), (6,false), (40,true), (39,true), (62,true), (98,true), (99,false)]
theorem p2533 (F : Frame G 4) : c2533.eval F.assign = true := by
  apply explicit_rup F.assign c2533 [c1283, c1281, c218] [(11,false), (9,false)]
  · exact sat_cons (p1283 F) ( sat_cons (p1281 F) ( sat_cons (p218 F) (rfl)))
  · rfl
def c2534 : CNF.Clause Nat := [(7,true), (86,true), (6,false), (50,false), (99,false), (110,false)]
theorem p2534 (F : Frame G 4) : c2534.eval F.assign = true := by
  apply explicit_rup F.assign c2534 [c2526, c2514, c1792, c2532, c134, c1645, c2455, c22, c25, c2133, c1958, c143] [(51,true), (87,true), (39,false), (40,false), (38,true), (88,false), (62,false), (29,true), (18,true), (19,false), (30,false)]
  · exact sat_cons (p2526 F) ( sat_cons (p2514 F) ( sat_cons (p1792 F) ( sat_cons (p2532 F) ( sat_cons (p134 F) ( sat_cons (p1645 F) ( sat_cons (p2455 F) ( sat_cons (p22 F) ( sat_cons (p25 F) ( sat_cons (p2133 F) ( sat_cons (p1958 F) ( sat_cons (p143 F) (rfl))))))))))))
  · rfl
def c2535 : CNF.Clause Nat := [(86,true), (6,false), (50,false), (99,false), (110,false)]
theorem p2535 (F : Frame G 4) : c2535.eval F.assign = true := by
  apply explicit_rup F.assign c2535 [c2526, c2514, c1792, c2532, c134, c1645, c2455, c2347, c2534, c1281, c2533, c147, c1961, c143, c1958, c19, c1340, c2233, c8] [(51,true), (87,true), (39,false), (40,false), (38,true), (88,false), (62,false), (98,false), (7,true), (9,false), (22,true), (31,true), (19,false), (30,true), (18,false), (29,true), (26,false), (15,false)]
  · exact sat_cons (p2526 F) ( sat_cons (p2514 F) ( sat_cons (p1792 F) ( sat_cons (p2532 F) ( sat_cons (p134 F) ( sat_cons (p1645 F) ( sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p2534 F) ( sat_cons (p1281 F) ( sat_cons (p2533 F) ( sat_cons (p147 F) ( sat_cons (p1961 F) ( sat_cons (p143 F) ( sat_cons (p1958 F) ( sat_cons (p19 F) ( sat_cons (p1340 F) ( sat_cons (p2233 F) ( sat_cons (p8 F) (rfl)))))))))))))))))))
  · rfl
def c2536 : CNF.Clause Nat := [(7,false), (6,false), (50,false), (99,false), (110,false)]
theorem p2536 (F : Frame G 4) : c2536.eval F.assign = true := by
  apply explicit_rup F.assign c2536 [c2526, c2535, c1791, c2514, c1792, c2532, c134, c1645, c2455, c1283, c2003, c163, c19, c2001, c2002, c8] [(51,true), (86,true), (22,false), (87,true), (39,false), (40,false), (38,true), (88,false), (62,false), (11,false), (18,false), (33,true), (29,true), (26,false), (15,false)]
  · exact sat_cons (p2526 F) ( sat_cons (p2535 F) ( sat_cons (p1791 F) ( sat_cons (p2514 F) ( sat_cons (p1792 F) ( sat_cons (p2532 F) ( sat_cons (p134 F) ( sat_cons (p1645 F) ( sat_cons (p2455 F) ( sat_cons (p1283 F) ( sat_cons (p2003 F) ( sat_cons (p163 F) ( sat_cons (p19 F) ( sat_cons (p2001 F) ( sat_cons (p2002 F) ( sat_cons (p8 F) (rfl))))))))))))))))
  · rfl
def c2537 : CNF.Clause Nat := [(6,false), (50,false), (99,false), (110,false)]
theorem p2537 (F : Frame G 4) : c2537.eval F.assign = true := by
  apply explicit_rup F.assign c2537 [c2514, c2526, c1792, c2532, c134, c2455, c2535, c2536, c22, c25, c1417] [(87,true), (51,true), (39,false), (40,false), (38,true), (62,false), (86,true), (7,false), (29,true), (18,true)]
  · exact sat_cons (p2514 F) ( sat_cons (p2526 F) ( sat_cons (p1792 F) ( sat_cons (p2532 F) ( sat_cons (p134 F) ( sat_cons (p2455 F) ( sat_cons (p2535 F) ( sat_cons (p2536 F) ( sat_cons (p22 F) ( sat_cons (p25 F) ( sat_cons (p1417 F) (rfl)))))))))))
  · rfl
def c2538 : CNF.Clause Nat := [(86,false), (17,false), (38,false), (40,true), (51,false), (87,false), (50,false), (62,true), (110,false)]
theorem p2538 (F : Frame G 4) : c2538.eval F.assign = true := by
  apply explicit_rup F.assign c2538 [c1924, c19, c22, c2003] [(29,false), (18,true), (7,true)]
  · exact sat_cons (p1924 F) ( sat_cons (p19 F) ( sat_cons (p22 F) ( sat_cons (p2003 F) (rfl))))
  · rfl
def c2539 : CNF.Clause Nat := [(88,true), (22,true), (11,true), (18,false), (86,true), (17,false), (38,false), (51,false), (87,false), (98,true), (99,false)]
theorem p2539 (F : Frame G 4) : c2539.eval F.assign = true := by
  apply explicit_rup F.assign c2539 [c163, c218, c1730] [(33,true), (9,true)]
  · exact sat_cons (p163 F) ( sat_cons (p218 F) ( sat_cons (p1730 F) (rfl)))
  · rfl
def c2540 : CNF.Clause Nat := [(88,false), (7,false), (86,true), (17,false), (38,false), (51,false), (87,false), (50,false), (98,true), (99,false)]
theorem p2540 (F : Frame G 4) : c2540.eval F.assign = true := by
  apply explicit_rup F.assign c2540 [c1383, c1646, c147] [(31,false), (9,false)]
  · exact sat_cons (p1383 F) ( sat_cons (p1646 F) ( sat_cons (p147 F) (rfl)))
  · rfl
def c2541 : CNF.Clause Nat := [(31,false), (22,false), (7,false), (50,false), (99,false), (110,false)]
theorem p2541 (F : Frame G 4) : c2541.eval F.assign = true := by
  apply explicit_rup F.assign c2541 [c2347, c2514, c2526, c1792, c2532, c134, c2455, c2537, c16, c2538, c2540, c1961, c1368, c143] [(98,false), (87,true), (51,true), (39,false), (40,false), (38,true), (62,false), (6,false), (17,true), (86,false), (88,false), (19,false), (30,false)]
  · exact sat_cons (p2347 F) ( sat_cons (p2514 F) ( sat_cons (p2526 F) ( sat_cons (p1792 F) ( sat_cons (p2532 F) ( sat_cons (p134 F) ( sat_cons (p2455 F) ( sat_cons (p2537 F) ( sat_cons (p16 F) ( sat_cons (p2538 F) ( sat_cons (p2540 F) ( sat_cons (p1961 F) ( sat_cons (p1368 F) ( sat_cons (p143 F) (rfl))))))))))))))
  · rfl
def c2542 : CNF.Clause Nat := [(18,false), (7,false), (50,false), (99,false), (110,false)]
theorem p2542 (F : Frame G 4) : c2542.eval F.assign = true := by
  apply explicit_rup F.assign c2542 [c2347, c2514, c2526, c1792, c2532, c134, c2455, c2537, c16, c2538, c2540, c1962, c8, c1707, c2539, c2541, c147, c215, c1730] [(98,false), (87,true), (51,true), (39,false), (40,false), (38,true), (62,false), (6,false), (17,true), (86,false), (88,false), (15,false), (26,true), (11,false), (22,true), (31,false), (9,true), (33,true)]
  · exact sat_cons (p2347 F) ( sat_cons (p2514 F) ( sat_cons (p2526 F) ( sat_cons (p1792 F) ( sat_cons (p2532 F) ( sat_cons (p134 F) ( sat_cons (p2455 F) ( sat_cons (p2537 F) ( sat_cons (p16 F) ( sat_cons (p2538 F) ( sat_cons (p2540 F) ( sat_cons (p1962 F) ( sat_cons (p8 F) ( sat_cons (p1707 F) ( sat_cons (p2539 F) ( sat_cons (p2541 F) ( sat_cons (p147 F) ( sat_cons (p215 F) ( sat_cons (p1730 F) (rfl)))))))))))))))))))
  · rfl
def c2543 : CNF.Clause Nat := [(11,false), (29,false), (88,true), (7,false), (86,true), (40,true), (39,true), (51,false), (87,false), (62,true), (99,false)]
theorem p2543 (F : Frame G 4) : c2543.eval F.assign = true := by
  apply explicit_rup F.assign c2543 [c134, c2297, c1726, c143] [(38,true), (30,false), (19,false)]
  · exact sat_cons (p134 F) ( sat_cons (p2297 F) ( sat_cons (p1726 F) ( sat_cons (p143 F) (rfl))))
  · rfl
def c2544 : CNF.Clause Nat := [(7,false), (50,false), (99,false), (110,false)]
theorem p2544 (F : Frame G 4) : c2544.eval F.assign = true := by
  apply explicit_rup F.assign c2544 [c2455, c2514, c2526, c2532, c1792, c134, c2537, c16, c2538, c2347, c2540, c2542, c19, c2232, c2543, c163, c215, c2541] [(62,false), (87,true), (51,true), (40,false), (39,false), (38,true), (6,false), (17,true), (86,false), (98,false), (88,false), (18,false), (29,true), (33,false), (11,false), (22,true), (31,true)]
  · exact sat_cons (p2455 F) ( sat_cons (p2514 F) ( sat_cons (p2526 F) ( sat_cons (p2532 F) ( sat_cons (p1792 F) ( sat_cons (p134 F) ( sat_cons (p2537 F) ( sat_cons (p16 F) ( sat_cons (p2538 F) ( sat_cons (p2347 F) ( sat_cons (p2540 F) ( sat_cons (p2542 F) ( sat_cons (p19 F) ( sat_cons (p2232 F) ( sat_cons (p2543 F) ( sat_cons (p163 F) ( sat_cons (p215 F) ( sat_cons (p2541 F) (rfl))))))))))))))))))
  · rfl
def c2545 : CNF.Clause Nat := [(50,false), (99,false), (110,false)]
theorem p2545 (F : Frame G 4) : c2545.eval F.assign = true := by
  apply explicit_rup F.assign c2545 [c2455, c2347, c2514, c2526, c1792, c2532, c134, c2537, c16, c2538, c2544, c22, c25, c1959, c1960, c143, c1957, c1646, c147] [(62,false), (98,false), (87,true), (51,true), (39,false), (40,false), (38,true), (6,false), (17,true), (86,false), (7,false), (29,true), (18,true), (30,false), (19,false), (88,true), (31,false), (9,false)]
  · exact sat_cons (p2455 F) ( sat_cons (p2347 F) ( sat_cons (p2514 F) ( sat_cons (p2526 F) ( sat_cons (p1792 F) ( sat_cons (p2532 F) ( sat_cons (p134 F) ( sat_cons (p2537 F) ( sat_cons (p16 F) ( sat_cons (p2538 F) ( sat_cons (p2544 F) ( sat_cons (p22 F) ( sat_cons (p25 F) ( sat_cons (p1959 F) ( sat_cons (p1960 F) ( sat_cons (p143 F) ( sat_cons (p1957 F) ( sat_cons (p1646 F) ( sat_cons (p147 F) (rfl)))))))))))))))))))
  · rfl
def c2546 : CNF.Clause Nat := [(87,false), (18,false), (86,true), (99,false), (110,false)]
theorem p2546 (F : Frame G 4) : c2546.eval F.assign = true := by
  apply explicit_rup F.assign c2546 [c2455, c2545, c139, c2347, c2303, c1792, c1985, c140, c2517, c12, c21, c1351, c1986, c147, c15, c1757] [(62,false), (50,false), (39,true), (98,false), (40,true), (51,false), (5,false), (38,true), (7,false), (27,true), (29,true), (31,false), (6,false), (9,true), (17,true)]
  · exact sat_cons (p2455 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p2347 F) ( sat_cons (p2303 F) ( sat_cons (p1792 F) ( sat_cons (p1985 F) ( sat_cons (p140 F) ( sat_cons (p2517 F) ( sat_cons (p12 F) ( sat_cons (p21 F) ( sat_cons (p1351 F) ( sat_cons (p1986 F) ( sat_cons (p147 F) ( sat_cons (p15 F) ( sat_cons (p1757 F) (rfl))))))))))))))))
  · rfl
def c2547 : CNF.Clause Nat := [(17,false), (51,true), (38,false), (18,false), (86,true), (99,false), (110,false)]
theorem p2547 (F : Frame G 4) : c2547.eval F.assign = true := by
  apply explicit_rup F.assign c2547 [c2455, c138, c2546, c261, c2545, c139, c2347, c1318, c1320, c144, c150, c2017, c2014, c21] [(62,false), (40,true), (87,false), (88,true), (50,false), (39,true), (98,false), (19,false), (21,false), (30,true), (10,true), (7,false), (29,false)]
  · exact sat_cons (p2455 F) ( sat_cons (p138 F) ( sat_cons (p2546 F) ( sat_cons (p261 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p2347 F) ( sat_cons (p1318 F) ( sat_cons (p1320 F) ( sat_cons (p144 F) ( sat_cons (p150 F) ( sat_cons (p2017 F) ( sat_cons (p2014 F) ( sat_cons (p21 F) (rfl))))))))))))))
  · rfl
def c2548 : CNF.Clause Nat := [(51,true), (38,false), (18,false), (86,true), (99,false), (110,false)]
theorem p2548 (F : Frame G 4) : c2548.eval F.assign = true := by
  apply explicit_rup F.assign c2548 [c2546, c261, c2455, c2545, c139, c2347, c138, c2547, c15, c2012, c2197, c144, c147, c1325, c2223, c2135, c150, c21, c12, c298] [(87,false), (88,true), (62,false), (50,false), (39,true), (98,false), (40,true), (17,false), (6,true), (30,false), (31,false), (19,true), (9,true), (21,false), (29,false), (27,false), (10,true), (7,true), (5,true)]
  · exact sat_cons (p2546 F) ( sat_cons (p261 F) ( sat_cons (p2455 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p2347 F) ( sat_cons (p138 F) ( sat_cons (p2547 F) ( sat_cons (p15 F) ( sat_cons (p2012 F) ( sat_cons (p2197 F) ( sat_cons (p144 F) ( sat_cons (p147 F) ( sat_cons (p1325 F) ( sat_cons (p2223 F) ( sat_cons (p2135 F) ( sat_cons (p150 F) ( sat_cons (p21 F) ( sat_cons (p12 F) ( sat_cons (p298 F) (rfl))))))))))))))))))))
  · rfl
def c2549 : CNF.Clause Nat := [(6,false), (38,false), (18,false), (86,true), (99,false), (110,false)]
theorem p2549 (F : Frame G 4) : c2549.eval F.assign = true := by
  apply explicit_rup F.assign c2549 [c2546, c261, c2455, c2545, c139, c2548, c2212, c144, c2347, c2165, c150, c2163, c147, c2158, c2179, c1298, c22, c104, c2135] [(87,false), (88,true), (62,false), (50,false), (39,true), (51,true), (30,false), (19,true), (98,false), (21,false), (10,true), (31,false), (9,true), (7,false), (29,false), (5,false), (40,true), (27,true)]
  · exact sat_cons (p2546 F) ( sat_cons (p261 F) ( sat_cons (p2455 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p2548 F) ( sat_cons (p2212 F) ( sat_cons (p144 F) ( sat_cons (p2347 F) ( sat_cons (p2165 F) ( sat_cons (p150 F) ( sat_cons (p2163 F) ( sat_cons (p147 F) ( sat_cons (p2158 F) ( sat_cons (p2179 F) ( sat_cons (p1298 F) ( sat_cons (p22 F) ( sat_cons (p104 F) ( sat_cons (p2135 F) (rfl)))))))))))))))))))
  · rfl
def c2550 : CNF.Clause Nat := [(40,false), (17,false), (9,false), (10,false), (19,false), (51,false), (38,false), (88,false), (18,false), (99,false), (110,false)]
theorem p2550 (F : Frame G 4) : c2550.eval F.assign = true := by
  apply explicit_rup F.assign c2550 [c2455, c2545, c139, c2158, c2215, c2014, c2135, c104] [(62,false), (50,false), (39,true), (7,false), (5,false), (29,false), (27,false)]
  · exact sat_cons (p2455 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p2158 F) ( sat_cons (p2215 F) ( sat_cons (p2014 F) ( sat_cons (p2135 F) ( sat_cons (p104 F) (rfl))))))))
  · rfl
def c2551 : CNF.Clause Nat := [(38,false), (18,false), (86,true), (99,false), (110,false)]
theorem p2551 (F : Frame G 4) : c2551.eval F.assign = true := by
  apply explicit_rup F.assign c2551 [c2546, c261, c2455, c2545, c139, c2347, c2548, c2212, c2165, c144, c150, c2163, c147, c2158, c2177, c2549, c15, c2550, c22, c44, c2231] [(87,false), (88,true), (62,false), (50,false), (39,true), (98,false), (51,true), (30,false), (21,false), (19,true), (10,true), (31,false), (9,true), (7,false), (26,false), (6,false), (17,true), (40,false), (29,true), (15,true)]
  · exact sat_cons (p2546 F) ( sat_cons (p261 F) ( sat_cons (p2455 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p2347 F) ( sat_cons (p2548 F) ( sat_cons (p2212 F) ( sat_cons (p2165 F) ( sat_cons (p144 F) ( sat_cons (p150 F) ( sat_cons (p2163 F) ( sat_cons (p147 F) ( sat_cons (p2158 F) ( sat_cons (p2177 F) ( sat_cons (p2549 F) ( sat_cons (p15 F) ( sat_cons (p2550 F) ( sat_cons (p22 F) ( sat_cons (p44 F) ( sat_cons (p2231 F) (rfl)))))))))))))))))))))
  · rfl
def c2552 : CNF.Clause Nat := [(5,false), (17,false), (18,false), (86,true), (99,false), (110,false)]
theorem p2552 (F : Frame G 4) : c2552.eval F.assign = true := by
  apply explicit_rup F.assign c2552 [c2546, c2455, c2545, c139, c2551, c140, c2212, c144, c136, c261, c2347, c2215, c2145, c147] [(87,false), (62,false), (50,false), (39,true), (38,false), (51,true), (30,false), (19,true), (40,true), (88,true), (98,false), (9,false), (31,false)]
  · exact sat_cons (p2546 F) ( sat_cons (p2455 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p2551 F) ( sat_cons (p140 F) ( sat_cons (p2212 F) ( sat_cons (p144 F) ( sat_cons (p136 F) ( sat_cons (p261 F) ( sat_cons (p2347 F) ( sat_cons (p2215 F) ( sat_cons (p2145 F) ( sat_cons (p147 F) (rfl))))))))))))))
  · rfl
def c2553 : CNF.Clause Nat := [(17,false), (18,false), (86,true), (99,false), (110,false)]
theorem p2553 (F : Frame G 4) : c2553.eval F.assign = true := by
  apply explicit_rup F.assign c2553 [c2546, c2455, c2545, c139, c2551, c140, c2212, c144, c136, c261, c2347, c1322, c150, c2014, c2552, c14, c95, c2238] [(87,false), (62,false), (50,false), (39,true), (38,false), (51,true), (30,false), (19,true), (40,true), (88,true), (98,false), (21,false), (10,true), (29,false), (5,false), (27,true), (7,true)]
  · exact sat_cons (p2546 F) ( sat_cons (p2455 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p2551 F) ( sat_cons (p140 F) ( sat_cons (p2212 F) ( sat_cons (p144 F) ( sat_cons (p136 F) ( sat_cons (p261 F) ( sat_cons (p2347 F) ( sat_cons (p1322 F) ( sat_cons (p150 F) ( sat_cons (p2014 F) ( sat_cons (p2552 F) ( sat_cons (p14 F) ( sat_cons (p95 F) ( sat_cons (p2238 F) (rfl))))))))))))))))))
  · rfl
def c2554 : CNF.Clause Nat := [(18,false), (86,true), (99,false), (110,false)]
theorem p2554 (F : Frame G 4) : c2554.eval F.assign = true := by
  apply explicit_rup F.assign c2554 [c2455, c2545, c139, c2347, c2546, c261, c2551, c140, c136, c2212, c144, c2553, c15, c2179, c2197, c147, c2215, c14, c95, c1642, c1302, c150] [(62,false), (50,false), (39,true), (98,false), (87,false), (88,true), (38,false), (51,true), (40,true), (30,false), (19,true), (17,false), (6,true), (29,false), (31,false), (9,true), (5,false), (27,true), (7,true), (21,false), (10,false)]
  · exact sat_cons (p2455 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p2347 F) ( sat_cons (p2546 F) ( sat_cons (p261 F) ( sat_cons (p2551 F) ( sat_cons (p140 F) ( sat_cons (p136 F) ( sat_cons (p2212 F) ( sat_cons (p144 F) ( sat_cons (p2553 F) ( sat_cons (p15 F) ( sat_cons (p2179 F) ( sat_cons (p2197 F) ( sat_cons (p147 F) ( sat_cons (p2215 F) ( sat_cons (p14 F) ( sat_cons (p95 F) ( sat_cons (p1642 F) ( sat_cons (p1302 F) ( sat_cons (p150 F) (rfl))))))))))))))))))))))
  · rfl
def c2555 : CNF.Clause Nat := [(29,true), (38,true), (86,true), (99,false), (110,false)]
theorem p2555 (F : Frame G 4) : c2555.eval F.assign = true := by
  apply explicit_rup F.assign c2555 [c2455, c2545, c139, c140, c1792, c2212, c144, c261, c136, c2554, c2347, c27, c88, c94, c2215, c2242, c147] [(62,false), (50,false), (39,true), (51,true), (87,false), (30,false), (19,true), (88,true), (40,true), (18,false), (98,false), (7,true), (27,true), (5,true), (9,false), (31,false)]
  · exact sat_cons (p2455 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p140 F) ( sat_cons (p1792 F) ( sat_cons (p2212 F) ( sat_cons (p144 F) ( sat_cons (p261 F) ( sat_cons (p136 F) ( sat_cons (p2554 F) ( sat_cons (p2347 F) ( sat_cons (p27 F) ( sat_cons (p88 F) ( sat_cons (p94 F) ( sat_cons (p2215 F) ( sat_cons (p2242 F) ( sat_cons (p147 F) (rfl)))))))))))))))))
  · rfl
def c2556 : CNF.Clause Nat := [(38,true), (86,true), (99,false), (110,false)]
theorem p2556 (F : Frame G 4) : c2556.eval F.assign = true := by
  apply explicit_rup F.assign c2556 [c2455, c2545, c139, c2347, c140, c136, c1792, c2212, c261, c144, c2555, c2179, c15, c1322, c2014, c150] [(62,false), (50,false), (39,true), (98,false), (51,true), (40,true), (87,false), (30,false), (88,true), (19,true), (29,true), (6,false), (17,true), (21,false), (10,false)]
  · exact sat_cons (p2455 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p2347 F) ( sat_cons (p140 F) ( sat_cons (p136 F) ( sat_cons (p1792 F) ( sat_cons (p2212 F) ( sat_cons (p261 F) ( sat_cons (p144 F) ( sat_cons (p2555 F) ( sat_cons (p2179 F) ( sat_cons (p15 F) ( sat_cons (p1322 F) ( sat_cons (p2014 F) ( sat_cons (p150 F) (rfl))))))))))))))))
  · rfl
def c2557 : CNF.Clause Nat := [(29,false), (40,false), (10,false), (88,false), (51,false), (50,true), (62,true), (99,false)]
theorem p2557 (F : Frame G 4) : c2557.eval F.assign = true := by
  apply explicit_rup F.assign c2557 [c139, c2179, c2014, c15] [(39,true), (6,false), (17,false)]
  · exact sat_cons (p139 F) ( sat_cons (p2179 F) ( sat_cons (p2014 F) ( sat_cons (p15 F) (rfl))))
  · rfl
def c2558 : CNF.Clause Nat := [(7,false), (51,false), (86,true), (99,false), (110,false)]
theorem p2558 (F : Frame G 4) : c2558.eval F.assign = true := by
  apply explicit_rup F.assign c2558 [c2455, c2545, c139, c1792, c2212, c144, c261, c2556, c2347, c2044, c2158, c147] [(62,false), (50,false), (39,true), (87,false), (30,false), (19,true), (88,true), (38,true), (98,false), (31,false), (9,false)]
  · exact sat_cons (p2455 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p1792 F) ( sat_cons (p2212 F) ( sat_cons (p144 F) ( sat_cons (p261 F) ( sat_cons (p2556 F) ( sat_cons (p2347 F) ( sat_cons (p2044 F) ( sat_cons (p2158 F) ( sat_cons (p147 F) (rfl))))))))))))
  · rfl
def c2559 : CNF.Clause Nat := [(51,false), (86,true), (99,false), (110,false)]
theorem p2559 (F : Frame G 4) : c2559.eval F.assign = true := by
  apply explicit_rup F.assign c2559 [c2556, c2554, c2455, c2545, c139, c2347, c1792, c261, c2165, c150, c2558, c25, c27, c2557] [(38,true), (18,false), (62,false), (50,false), (39,true), (98,false), (87,false), (88,true), (21,false), (10,true), (7,false), (40,true), (29,true)]
  · exact sat_cons (p2556 F) ( sat_cons (p2554 F) ( sat_cons (p2455 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p2347 F) ( sat_cons (p1792 F) ( sat_cons (p261 F) ( sat_cons (p2165 F) ( sat_cons (p150 F) ( sat_cons (p2558 F) ( sat_cons (p25 F) ( sat_cons (p27 F) ( sat_cons (p2557 F) (rfl))))))))))))))
  · rfl
def c2560 : CNF.Clause Nat := [(10,false), (87,true), (88,false), (86,true), (99,false), (110,false)]
theorem p2560 (F : Frame G 4) : c2560.eval F.assign = true := by
  apply explicit_rup F.assign c2560 [c2455, c2554, c2559, c18, c24, c138, c2545, c139, c2014, c15, c2012, c1296, c144, c12, c2238] [(62,false), (18,false), (51,false), (29,true), (7,true), (40,true), (50,false), (39,true), (17,false), (6,true), (30,false), (5,false), (19,true), (27,true)]
  · exact sat_cons (p2455 F) ( sat_cons (p2554 F) ( sat_cons (p2559 F) ( sat_cons (p18 F) ( sat_cons (p24 F) ( sat_cons (p138 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p2014 F) ( sat_cons (p15 F) ( sat_cons (p2012 F) ( sat_cons (p1296 F) ( sat_cons (p144 F) ( sat_cons (p12 F) ( sat_cons (p2238 F) (rfl)))))))))))))))
  · rfl
def c2561 : CNF.Clause Nat := [(19,false), (87,true), (88,false), (86,true), (99,false), (110,false)]
theorem p2561 (F : Frame G 4) : c2561.eval F.assign = true := by
  apply explicit_rup F.assign c2561 [c2347, c2560, c150, c2455, c2554, c2559, c18, c138, c2545, c139, c1322, c15, c2223, c2222, c147] [(98,false), (10,false), (21,true), (62,false), (18,false), (51,false), (29,true), (40,true), (50,false), (39,true), (17,false), (6,true), (9,false), (31,false)]
  · exact sat_cons (p2347 F) ( sat_cons (p2560 F) ( sat_cons (p150 F) ( sat_cons (p2455 F) ( sat_cons (p2554 F) ( sat_cons (p2559 F) ( sat_cons (p18 F) ( sat_cons (p138 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p1322 F) ( sat_cons (p15 F) ( sat_cons (p2223 F) ( sat_cons (p2222 F) ( sat_cons (p147 F) (rfl)))))))))))))))
  · rfl
def c2562 : CNF.Clause Nat := [(30,false), (86,true), (99,false), (110,false)]
theorem p2562 (F : Frame G 4) : c2562.eval F.assign = true := by
  apply explicit_rup F.assign c2562 [c2455, c2554, c2559, c24, c138, c2556, c2545, c139, c2017, c2012, c15] [(62,false), (18,false), (51,false), (7,true), (40,true), (38,true), (50,false), (39,true), (17,false), (6,false)]
  · exact sat_cons (p2455 F) ( sat_cons (p2554 F) ( sat_cons (p2559 F) ( sat_cons (p24 F) ( sat_cons (p138 F) ( sat_cons (p2556 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p2017 F) ( sat_cons (p2012 F) ( sat_cons (p15 F) (rfl)))))))))))
  · rfl
def c2563 : CNF.Clause Nat := [(87,true), (88,false), (86,true), (99,false), (110,false)]
theorem p2563 (F : Frame G 4) : c2563.eval F.assign = true := by
  apply explicit_rup F.assign c2563 [c2562, c2561, c144] [(30,false), (19,false)]
  · exact sat_cons (p2562 F) ( sat_cons (p2561 F) ( sat_cons (p144 F) (rfl)))
  · rfl
def c2564 : CNF.Clause Nat := [(88,false), (86,true), (99,false), (110,false)]
theorem p2564 (F : Frame G 4) : c2564.eval F.assign = true := by
  apply explicit_rup F.assign c2564 [c2455, c2554, c2559, c18, c24, c138, c2545, c139, c2347, c2563, c2201, c2518, c12, c15, c1432, c1295, c147] [(62,false), (18,false), (51,false), (29,true), (7,true), (40,true), (50,false), (39,true), (98,false), (87,true), (27,false), (17,false), (5,true), (6,true), (31,false), (9,false)]
  · exact sat_cons (p2455 F) ( sat_cons (p2554 F) ( sat_cons (p2559 F) ( sat_cons (p18 F) ( sat_cons (p24 F) ( sat_cons (p138 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p2347 F) ( sat_cons (p2563 F) ( sat_cons (p2201 F) ( sat_cons (p2518 F) ( sat_cons (p12 F) ( sat_cons (p15 F) ( sat_cons (p1432 F) ( sat_cons (p1295 F) ( sat_cons (p147 F) (rfl)))))))))))))))))
  · rfl
def c2565 : CNF.Clause Nat := [(86,true), (99,false), (110,false)]
theorem p2565 (F : Frame G 4) : c2565.eval F.assign = true := by
  apply explicit_rup F.assign c2565 [c2455, c2545, c139, c2347, c2554, c2559, c138, c24, c18, c2562, c2564, c261, c143, c2518, c1983, c15, c147, c2222] [(62,false), (50,false), (39,true), (98,false), (18,false), (51,false), (40,true), (7,true), (29,true), (30,false), (88,false), (87,true), (19,true), (17,false), (9,false), (6,true), (31,true)]
  · exact sat_cons (p2455 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p2347 F) ( sat_cons (p2554 F) ( sat_cons (p2559 F) ( sat_cons (p138 F) ( sat_cons (p24 F) ( sat_cons (p18 F) ( sat_cons (p2562 F) ( sat_cons (p2564 F) ( sat_cons (p261 F) ( sat_cons (p143 F) ( sat_cons (p2518 F) ( sat_cons (p1983 F) ( sat_cons (p15 F) ( sat_cons (p147 F) ( sat_cons (p2222 F) (rfl))))))))))))))))))
  · rfl
def c2566 : CNF.Clause Nat := [(7,false), (87,false), (99,false), (110,false)]
theorem p2566 (F : Frame G 4) : c2566.eval F.assign = true := by
  apply explicit_rup F.assign c2566 [c2455, c2545, c139, c1792, c2303, c2565, c2201, c1936, c12] [(62,false), (50,false), (39,true), (51,false), (40,true), (86,true), (27,false), (5,false)]
  · exact sat_cons (p2455 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p1792 F) ( sat_cons (p2303 F) ( sat_cons (p2565 F) ( sat_cons (p2201 F) ( sat_cons (p1936 F) ( sat_cons (p12 F) (rfl)))))))))
  · rfl
def c2567 : CNF.Clause Nat := [(87,false), (99,false), (110,false)]
theorem p2567 (F : Frame G 4) : c2567.eval F.assign = true := by
  apply explicit_rup F.assign c2567 [c2565, c2455, c2545, c139, c2303, c1792, c140, c2566, c24, c21, c1985, c1986, c12, c15, c1925] [(86,true), (62,false), (50,false), (39,true), (40,true), (51,false), (38,true), (7,false), (18,true), (29,true), (5,false), (6,false), (27,true), (17,true)]
  · exact sat_cons (p2565 F) ( sat_cons (p2455 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p2303 F) ( sat_cons (p1792 F) ( sat_cons (p140 F) ( sat_cons (p2566 F) ( sat_cons (p24 F) ( sat_cons (p21 F) ( sat_cons (p1985 F) ( sat_cons (p1986 F) ( sat_cons (p12 F) ( sat_cons (p15 F) ( sat_cons (p1925 F) (rfl)))))))))))))))
  · rfl
def c2568 : CNF.Clause Nat := [(27,false), (29,false), (18,false), (51,true), (40,false), (99,false), (110,false)]
theorem p2568 (F : Frame G 4) : c2568.eval F.assign = true := by
  apply explicit_rup F.assign c2568 [c2545, c140, c2567, c2565, c2455, c139, c2347, c1925, c1349, c1351, c15, c2011, c165, c142, c1941] [(50,false), (38,true), (87,false), (86,true), (62,false), (39,true), (98,false), (17,false), (30,false), (31,false), (6,true), (88,false), (9,true), (19,true)]
  · exact sat_cons (p2545 F) ( sat_cons (p140 F) ( sat_cons (p2567 F) ( sat_cons (p2565 F) ( sat_cons (p2455 F) ( sat_cons (p139 F) ( sat_cons (p2347 F) ( sat_cons (p1925 F) ( sat_cons (p1349 F) ( sat_cons (p1351 F) ( sat_cons (p15 F) ( sat_cons (p2011 F) ( sat_cons (p165 F) ( sat_cons (p142 F) ( sat_cons (p1941 F) (rfl)))))))))))))))
  · rfl
def c2569 : CNF.Clause Nat := [(6,false), (29,false), (18,false), (38,false), (40,false), (99,false), (110,false)]
theorem p2569 (F : Frame G 4) : c2569.eval F.assign = true := by
  apply explicit_rup F.assign c2569 [c2567, c2565, c2455, c2545, c139, c2347, c2012, c2011, c142, c2222, c1941, c165] [(87,false), (86,true), (62,false), (50,false), (39,true), (98,false), (30,false), (88,false), (19,true), (31,false), (9,false)]
  · exact sat_cons (p2567 F) ( sat_cons (p2565 F) ( sat_cons (p2455 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p2347 F) ( sat_cons (p2012 F) ( sat_cons (p2011 F) ( sat_cons (p142 F) ( sat_cons (p2222 F) ( sat_cons (p1941 F) ( sat_cons (p165 F) (rfl))))))))))))
  · rfl
def c2570 : CNF.Clause Nat := [(51,true), (7,true), (40,false), (99,false), (110,false)]
theorem p2570 (F : Frame G 4) : c2570.eval F.assign = true := by
  apply explicit_rup F.assign c2570 [c2567, c2565, c2455, c2545, c139, c2347, c140, c24, c21, c2568, c12, c2569, c15, c1926, c1320, c1937, c150, c241, c1872] [(87,false), (86,true), (62,false), (50,false), (39,true), (98,false), (38,true), (18,true), (29,true), (27,false), (5,true), (6,false), (17,true), (11,false), (21,false), (88,false), (10,true), (22,true)]
  · exact sat_cons (p2567 F) ( sat_cons (p2565 F) ( sat_cons (p2455 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p2347 F) ( sat_cons (p140 F) ( sat_cons (p24 F) ( sat_cons (p21 F) ( sat_cons (p2568 F) ( sat_cons (p12 F) ( sat_cons (p2569 F) ( sat_cons (p15 F) ( sat_cons (p1926 F) ( sat_cons (p1320 F) ( sat_cons (p1937 F) ( sat_cons (p150 F) ( sat_cons (p241 F) ( sat_cons (p1872 F) (rfl)))))))))))))))))))
  · rfl
def c2571 : CNF.Clause Nat := [(17,false), (7,true), (40,false), (99,false), (110,false)]
theorem p2571 (F : Frame G 4) : c2571.eval F.assign = true := by
  apply explicit_rup F.assign c2571 [c2565, c2570, c1366, c2567, c2347, c2455, c2545, c139, c1644, c150, c1845, c244, c1932, c1925, c106, c14, c104, c1926] [(86,true), (51,true), (88,false), (87,false), (98,false), (62,false), (50,false), (39,true), (10,false), (21,true), (33,false), (11,true), (5,false), (27,false), (18,true), (38,true), (29,true)]
  · exact sat_cons (p2565 F) ( sat_cons (p2570 F) ( sat_cons (p1366 F) ( sat_cons (p2567 F) ( sat_cons (p2347 F) ( sat_cons (p2455 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p1644 F) ( sat_cons (p150 F) ( sat_cons (p1845 F) ( sat_cons (p244 F) ( sat_cons (p1932 F) ( sat_cons (p1925 F) ( sat_cons (p106 F) ( sat_cons (p14 F) ( sat_cons (p104 F) ( sat_cons (p1926 F) (rfl))))))))))))))))))
  · rfl
def c2572 : CNF.Clause Nat := [(7,true), (40,false), (99,false), (110,false)]
theorem p2572 (F : Frame G 4) : c2572.eval F.assign = true := by
  apply explicit_rup F.assign c2572 [c2567, c2565, c2455, c2545, c139, c2347, c2570, c1644, c1366, c150, c1932, c1845, c242, c2571, c15, c1842, c106, c14, c104, c2569] [(87,false), (86,true), (62,false), (50,false), (39,true), (98,false), (51,true), (10,false), (88,false), (21,true), (5,false), (33,false), (22,true), (17,false), (6,true), (27,false), (18,true), (38,true), (29,true)]
  · exact sat_cons (p2567 F) ( sat_cons (p2565 F) ( sat_cons (p2455 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p2347 F) ( sat_cons (p2570 F) ( sat_cons (p1644 F) ( sat_cons (p1366 F) ( sat_cons (p150 F) ( sat_cons (p1932 F) ( sat_cons (p1845 F) ( sat_cons (p242 F) ( sat_cons (p2571 F) ( sat_cons (p15 F) ( sat_cons (p1842 F) ( sat_cons (p106 F) ( sat_cons (p14 F) ( sat_cons (p104 F) ( sat_cons (p2569 F) (rfl))))))))))))))))))))
  · rfl
def c2573 : CNF.Clause Nat := [(6,false), (40,false), (99,false), (110,false)]
theorem p2573 (F : Frame G 4) : c2573.eval F.assign = true := by
  apply explicit_rup F.assign c2573 [c2455, c2567, c2545, c139, c2565, c2572, c2491, c140, c1933, c18, c2347, c2012, c2011, c142, c2051, c1819, c150] [(62,false), (87,false), (50,false), (39,true), (86,true), (7,true), (51,false), (38,true), (18,false), (29,true), (98,false), (30,false), (88,false), (19,true), (10,false), (21,false)]
  · exact sat_cons (p2455 F) ( sat_cons (p2567 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p2565 F) ( sat_cons (p2572 F) ( sat_cons (p2491 F) ( sat_cons (p140 F) ( sat_cons (p1933 F) ( sat_cons (p18 F) ( sat_cons (p2347 F) ( sat_cons (p2012 F) ( sat_cons (p2011 F) ( sat_cons (p142 F) ( sat_cons (p2051 F) ( sat_cons (p1819 F) ( sat_cons (p150 F) (rfl)))))))))))))))))
  · rfl
def c2574 : CNF.Clause Nat := [(40,false), (99,false), (110,false)]
theorem p2574 (F : Frame G 4) : c2574.eval F.assign = true := by
  apply explicit_rup F.assign c2574 [c2567, c2565, c2455, c2545, c139, c2347, c2572, c2491, c140, c1933, c18, c2573, c15, c1616, c1914, c150, c1872, c1934, c238] [(87,false), (86,true), (62,false), (50,false), (39,true), (98,false), (7,true), (51,false), (38,true), (18,false), (29,true), (6,false), (17,true), (21,false), (33,false), (10,true), (22,false), (88,false)]
  · exact sat_cons (p2567 F) ( sat_cons (p2565 F) ( sat_cons (p2455 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p2347 F) ( sat_cons (p2572 F) ( sat_cons (p2491 F) ( sat_cons (p140 F) ( sat_cons (p1933 F) ( sat_cons (p18 F) ( sat_cons (p2573 F) ( sat_cons (p15 F) ( sat_cons (p1616 F) ( sat_cons (p1914 F) ( sat_cons (p150 F) ( sat_cons (p1872 F) ( sat_cons (p1934 F) ( sat_cons (p238 F) (rfl)))))))))))))))))))
  · rfl
def c2575 : CNF.Clause Nat := [(99,false), (110,false)]
theorem p2575 (F : Frame G 4) : c2575.eval F.assign = true := by
  apply explicit_rup F.assign c2575 [c2347, c2455, c2545, c139, c2565, c2567, c2574, c136, c138, c2491, c25, c22, c1623, c2159, c150] [(98,false), (62,false), (50,false), (39,true), (86,true), (87,false), (40,false), (38,true), (51,true), (7,false), (18,true), (29,true), (10,false), (21,false)]
  · exact sat_cons (p2347 F) ( sat_cons (p2455 F) ( sat_cons (p2545 F) ( sat_cons (p139 F) ( sat_cons (p2565 F) ( sat_cons (p2567 F) ( sat_cons (p2574 F) ( sat_cons (p136 F) ( sat_cons (p138 F) ( sat_cons (p2491 F) ( sat_cons (p25 F) ( sat_cons (p22 F) ( sat_cons (p1623 F) ( sat_cons (p2159 F) ( sat_cons (p150 F) (rfl)))))))))))))))
  · rfl
def c2576 : CNF.Clause Nat := [(98,true), (87,true), (38,false), (29,false), (7,true), (40,true), (39,false), (86,false), (110,false)]
theorem p2576 (F : Frame G 4) : c2576.eval F.assign = true := by
  apply explicit_rup F.assign c2576 [c2575, c262, c1421, c138, c25, c2159, c2143, c150, c145, c2163] [(99,false), (88,true), (62,false), (51,true), (18,true), (21,false), (9,false), (10,true), (31,true)]
  · exact sat_cons (p2575 F) ( sat_cons (p262 F) ( sat_cons (p1421 F) ( sat_cons (p138 F) ( sat_cons (p25 F) ( sat_cons (p2159 F) ( sat_cons (p2143 F) ( sat_cons (p150 F) ( sat_cons (p145 F) ( sat_cons (p2163 F) (rfl))))))))))
  · rfl
def c2577 : CNF.Clause Nat := [(98,false), (38,false), (29,false), (7,true), (40,true), (39,false), (86,false), (110,false)]
theorem p2577 (F : Frame G 4) : c2577.eval F.assign = true := by
  apply explicit_rup F.assign c2577 [c2575, c2308, c1908, c2067, c25, c1556, c1401, c157] [(99,false), (51,true), (18,false), (88,false), (62,true), (11,false), (33,false)]
  · exact sat_cons (p2575 F) ( sat_cons (p2308 F) ( sat_cons (p1908 F) ( sat_cons (p2067 F) ( sat_cons (p25 F) ( sat_cons (p1556 F) ( sat_cons (p1401 F) ( sat_cons (p157 F) (rfl))))))))
  · rfl
def c2578 : CNF.Clause Nat := [(33,true), (88,true), (62,false), (51,false), (87,false), (38,false), (86,false), (99,true)]
theorem p2578 (F : Frame G 4) : c2578.eval F.assign = true := by
  apply explicit_rup F.assign c2578 [c154, c157, c1480] [(22,true), (11,true)]
  · exact sat_cons (p154 F) ( sat_cons (p157 F) ( sat_cons (p1480 F) (rfl)))
  · rfl
def c2579 : CNF.Clause Nat := [(62,false), (51,false), (87,false), (98,true), (38,false), (29,false), (39,false), (86,false), (110,false)]
theorem p2579 (F : Frame G 4) : c2579.eval F.assign = true := by
  apply explicit_rup F.assign c2579 [c2159, c2575, c1421, c1391, c2578, c1475, c160, c252, c2034, c2162, c169] [(21,false), (99,false), (88,false), (30,false), (33,true), (11,false), (22,true), (10,true), (9,false), (19,false)]
  · exact sat_cons (p2159 F) ( sat_cons (p2575 F) ( sat_cons (p1421 F) ( sat_cons (p1391 F) ( sat_cons (p2578 F) ( sat_cons (p1475 F) ( sat_cons (p160 F) ( sat_cons (p252 F) ( sat_cons (p2034 F) ( sat_cons (p2162 F) ( sat_cons (p169 F) (rfl)))))))))))
  · rfl
def c2580 : CNF.Clause Nat := [(51,false), (38,false), (29,false), (7,true), (40,true), (39,false), (86,false), (110,false)]
theorem p2580 (F : Frame G 4) : c2580.eval F.assign = true := by
  apply explicit_rup F.assign c2580 [c2577, c2576, c2579, c25, c1417, c1408, c1519, c103] [(98,false), (87,true), (62,false), (18,true), (50,false), (27,false), (5,false)]
  · exact sat_cons (p2577 F) ( sat_cons (p2576 F) ( sat_cons (p2579 F) ( sat_cons (p25 F) ( sat_cons (p1417 F) ( sat_cons (p1408 F) ( sat_cons (p1519 F) ( sat_cons (p103 F) (rfl))))))))
  · rfl
def c2581 : CNF.Clause Nat := [(33,false), (5,false), (62,false), (87,false), (98,true), (38,false), (29,false), (39,false), (86,false), (110,false)]
theorem p2581 (F : Frame G 4) : c2581.eval F.assign = true := by
  apply explicit_rup F.assign c2581 [c1389, c1421, c2575, c1475, c160, c1952, c2052, c169] [(30,false), (88,false), (99,false), (11,false), (22,true), (9,false), (19,false)]
  · exact sat_cons (p1389 F) ( sat_cons (p1421 F) ( sat_cons (p2575 F) ( sat_cons (p1475 F) ( sat_cons (p160 F) ( sat_cons (p1952 F) ( sat_cons (p2052 F) ( sat_cons (p169 F) (rfl))))))))
  · rfl
def c2582 : CNF.Clause Nat := [(38,false), (29,false), (7,true), (40,true), (39,false), (86,false), (110,false)]
theorem p2582 (F : Frame G 4) : c2582.eval F.assign = true := by
  apply explicit_rup F.assign c2582 [c2575, c2577, c2576, c2580, c138, c26, c1416, c1421, c1417, c12, c1389, c2581, c154, c2052, c169, c168, c1385] [(99,false), (98,false), (87,true), (51,false), (62,true), (18,true), (27,false), (88,false), (50,false), (5,true), (30,false), (33,false), (22,true), (19,false), (9,true), (31,true)]
  · exact sat_cons (p2575 F) ( sat_cons (p2577 F) ( sat_cons (p2576 F) ( sat_cons (p2580 F) ( sat_cons (p138 F) ( sat_cons (p26 F) ( sat_cons (p1416 F) ( sat_cons (p1421 F) ( sat_cons (p1417 F) ( sat_cons (p12 F) ( sat_cons (p1389 F) ( sat_cons (p2581 F) ( sat_cons (p154 F) ( sat_cons (p2052 F) ( sat_cons (p169 F) ( sat_cons (p168 F) ( sat_cons (p1385 F) (rfl)))))))))))))))))
  · rfl
def c2583 : CNF.Clause Nat := [(51,true), (98,true), (87,false), (29,false), (7,true), (40,true), (39,false), (86,false), (110,false)]
theorem p2583 (F : Frame G 4) : c2583.eval F.assign = true := by
  apply explicit_rup F.assign c2583 [c2582, c2575, c138, c140, c26, c1416, c2053, c13, c1403, c9, c1308, c160, c1705, c2008, c145] [(38,false), (99,false), (62,true), (50,true), (18,true), (27,false), (11,false), (5,true), (26,false), (15,true), (22,false), (88,true), (9,false), (31,false)]
  · exact sat_cons (p2582 F) ( sat_cons (p2575 F) ( sat_cons (p138 F) ( sat_cons (p140 F) ( sat_cons (p26 F) ( sat_cons (p1416 F) ( sat_cons (p2053 F) ( sat_cons (p13 F) ( sat_cons (p1403 F) ( sat_cons (p9 F) ( sat_cons (p1308 F) ( sat_cons (p160 F) ( sat_cons (p1705 F) ( sat_cons (p2008 F) ( sat_cons (p145 F) (rfl)))))))))))))))
  · rfl
def c2584 : CNF.Clause Nat := [(88,false), (50,false), (62,false), (51,false), (98,true), (87,false), (29,false), (39,false), (99,true)]
theorem p2584 (F : Frame G 4) : c2584.eval F.assign = true := by
  apply explicit_rup F.assign c2584 [c1387, c1705, c145] [(31,false), (9,false)]
  · exact sat_cons (p1387 F) ( sat_cons (p1705 F) ( sat_cons (p145 F) (rfl)))
  · rfl
def c2585 : CNF.Clause Nat := [(50,false), (62,false), (51,false), (98,true), (87,false), (29,false), (39,false), (86,false), (110,false)]
theorem p2585 (F : Frame G 4) : c2585.eval F.assign = true := by
  apply explicit_rup F.assign c2585 [c2575, c1791, c2584, c160, c154, c1475] [(99,false), (22,false), (88,false), (11,true), (33,true)]
  · exact sat_cons (p2575 F) ( sat_cons (p1791 F) ( sat_cons (p2584 F) ( sat_cons (p160 F) ( sat_cons (p154 F) ( sat_cons (p1475 F) (rfl))))))
  · rfl
def c2586 : CNF.Clause Nat := [(62,false), (98,true), (87,false), (29,false), (7,true), (40,true), (39,false), (86,false), (110,false)]
theorem p2586 (F : Frame G 4) : c2586.eval F.assign = true := by
  apply explicit_rup F.assign c2586 [c2583, c2582, c1416, c2585, c14, c93, c1519] [(51,true), (38,false), (27,false), (50,false), (5,true), (18,true)]
  · exact sat_cons (p2583 F) ( sat_cons (p2582 F) ( sat_cons (p1416 F) ( sat_cons (p2585 F) ( sat_cons (p14 F) ( sat_cons (p93 F) ( sat_cons (p1519 F) (rfl)))))))
  · rfl
def c2587 : CNF.Clause Nat := [(98,true), (87,false), (29,false), (7,true), (40,true), (39,false), (86,false), (110,false)]
theorem p2587 (F : Frame G 4) : c2587.eval F.assign = true := by
  apply explicit_rup F.assign c2587 [c2582, c2583, c2586, c25, c1408, c1519, c109] [(38,false), (51,true), (62,false), (18,true), (27,false), (5,false)]
  · exact sat_cons (p2582 F) ( sat_cons (p2583 F) ( sat_cons (p2586 F) ( sat_cons (p25 F) ( sat_cons (p1408 F) ( sat_cons (p1519 F) ( sat_cons (p109 F) (rfl)))))))
  · rfl
def c2588 : CNF.Clause Nat := [(87,false), (29,false), (7,true), (40,true), (39,false), (86,false), (110,false)]
theorem p2588 (F : Frame G 4) : c2588.eval F.assign = true := by
  apply explicit_rup F.assign c2588 [c2575, c2587, c2308, c1908, c1854, c2067, c25, c154, c1401] [(99,false), (98,true), (51,true), (18,false), (22,false), (88,false), (62,true), (33,true)]
  · exact sat_cons (p2575 F) ( sat_cons (p2587 F) ( sat_cons (p2308 F) ( sat_cons (p1908 F) ( sat_cons (p1854 F) ( sat_cons (p2067 F) ( sat_cons (p25 F) ( sat_cons (p154 F) ( sat_cons (p1401 F) (rfl)))))))))
  · rfl
def c2589 : CNF.Clause Nat := [(98,false), (29,false), (7,true), (40,true), (39,false), (86,false), (110,false)]
theorem p2589 (F : Frame G 4) : c2589.eval F.assign = true := by
  apply explicit_rup F.assign c2589 [c2582, c2575, c2308, c1908, c2067, c25, c1410, c1401, c9, c157, c2148] [(38,false), (99,false), (51,true), (18,false), (88,false), (62,true), (26,false), (33,false), (15,true), (11,true)]
  · exact sat_cons (p2582 F) ( sat_cons (p2575 F) ( sat_cons (p2308 F) ( sat_cons (p1908 F) ( sat_cons (p2067 F) ( sat_cons (p25 F) ( sat_cons (p1410 F) ( sat_cons (p1401 F) ( sat_cons (p9 F) ( sat_cons (p157 F) ( sat_cons (p2148 F) (rfl)))))))))))
  · rfl
def c2590 : CNF.Clause Nat := [(62,false), (51,false), (98,true), (87,true), (38,true), (29,false), (39,false), (86,false), (110,false)]
theorem p2590 (F : Frame G 4) : c2590.eval F.assign = true := by
  apply explicit_rup F.assign c2590 [c2575, c262, c1391, c2185, c145, c170, c2170, c2211, c14, c1929, c2052, c150, c237, c1494] [(99,false), (88,true), (30,false), (31,false), (9,true), (19,true), (27,false), (50,false), (5,true), (21,false), (22,false), (10,true), (33,true)]
  · exact sat_cons (p2575 F) ( sat_cons (p262 F) ( sat_cons (p1391 F) ( sat_cons (p2185 F) ( sat_cons (p145 F) ( sat_cons (p170 F) ( sat_cons (p2170 F) ( sat_cons (p2211 F) ( sat_cons (p14 F) ( sat_cons (p1929 F) ( sat_cons (p2052 F) ( sat_cons (p150 F) ( sat_cons (p237 F) ( sat_cons (p1494 F) (rfl))))))))))))))
  · rfl
def c2591 : CNF.Clause Nat := [(51,false), (29,false), (7,true), (40,true), (39,false), (86,false), (110,false)]
theorem p2591 (F : Frame G 4) : c2591.eval F.assign = true := by
  apply explicit_rup F.assign c2591 [c2575, c2588, c2589, c262, c2582, c2590, c25, c136, c2053, c1791, c245, c240, c1622, c1929, c109] [(99,false), (87,false), (98,false), (88,true), (38,false), (62,false), (18,true), (50,true), (11,false), (22,false), (10,true), (21,true), (27,false), (5,false)]
  · exact sat_cons (p2575 F) ( sat_cons (p2588 F) ( sat_cons (p2589 F) ( sat_cons (p262 F) ( sat_cons (p2582 F) ( sat_cons (p2590 F) ( sat_cons (p25 F) ( sat_cons (p136 F) ( sat_cons (p2053 F) ( sat_cons (p1791 F) ( sat_cons (p245 F) ( sat_cons (p240 F) ( sat_cons (p1622 F) ( sat_cons (p1929 F) ( sat_cons (p109 F) (rfl)))))))))))))))
  · rfl
def c2592 : CNF.Clause Nat := [(22,true), (11,true), (18,false), (51,true), (98,true), (87,true), (38,true), (29,false), (40,true), (86,false), (110,false)]
theorem p2592 (F : Frame G 4) : c2592.eval F.assign = true := by
  apply explicit_rup F.assign c2592 [c140, c138, c2575, c262, c245, c240, c2155, c1307, c9] [(50,true), (62,true), (99,false), (88,true), (10,true), (21,true), (26,false), (15,false)]
  · exact sat_cons (p140 F) ( sat_cons (p138 F) ( sat_cons (p2575 F) ( sat_cons (p262 F) ( sat_cons (p245 F) ( sat_cons (p240 F) ( sat_cons (p2155 F) ( sat_cons (p1307 F) ( sat_cons (p9 F) (rfl)))))))))
  · rfl
def c2593 : CNF.Clause Nat := [(29,false), (7,true), (40,true), (39,false), (86,false), (110,false)]
theorem p2593 (F : Frame G 4) : c2593.eval F.assign = true := by
  apply explicit_rup F.assign c2593 [c2575, c2582, c2588, c2589, c262, c2591, c138, c140, c26, c2053, c2592, c1308, c9, c1882, c2155, c150] [(99,false), (38,false), (87,false), (98,false), (88,true), (51,false), (62,true), (50,true), (18,true), (11,false), (22,true), (15,false), (26,true), (21,false), (10,false)]
  · exact sat_cons (p2575 F) ( sat_cons (p2582 F) ( sat_cons (p2588 F) ( sat_cons (p2589 F) ( sat_cons (p262 F) ( sat_cons (p2591 F) ( sat_cons (p138 F) ( sat_cons (p140 F) ( sat_cons (p26 F) ( sat_cons (p2053 F) ( sat_cons (p2592 F) ( sat_cons (p1308 F) ( sat_cons (p9 F) ( sat_cons (p1882 F) ( sat_cons (p2155 F) ( sat_cons (p150 F) (rfl))))))))))))))))
  · rfl
def c2594 : CNF.Clause Nat := [(19,false), (9,false), (38,true), (88,false), (29,true), (7,true), (40,true), (39,false), (110,false)]
theorem p2594 (F : Frame G 4) : c2594.eval F.assign = true := by
  apply explicit_rup F.assign c2594 [c23, c22, c2170, c2211, c91] [(51,true), (62,true), (27,false), (50,false)]
  · exact sat_cons (p23 F) ( sat_cons (p22 F) ( sat_cons (p2170 F) ( sat_cons (p2211 F) ( sat_cons (p91 F) (rfl)))))
  · rfl
def c2595 : CNF.Clause Nat := [(88,false), (98,true), (7,true), (40,true), (39,false), (86,false), (110,false)]
theorem p2595 (F : Frame G 4) : c2595.eval F.assign = true := by
  apply explicit_rup F.assign c2595 [c2593, c23, c22, c1391, c29, c2575, c1421, c2185, c145, c2594, c170, c1408, c1519, c111] [(29,false), (51,true), (62,true), (30,false), (18,true), (99,false), (38,false), (31,false), (9,true), (19,false), (87,true), (27,false), (5,false)]
  · exact sat_cons (p2593 F) ( sat_cons (p23 F) ( sat_cons (p22 F) ( sat_cons (p1391 F) ( sat_cons (p29 F) ( sat_cons (p2575 F) ( sat_cons (p1421 F) ( sat_cons (p2185 F) ( sat_cons (p145 F) ( sat_cons (p2594 F) ( sat_cons (p170 F) ( sat_cons (p1408 F) ( sat_cons (p1519 F) ( sat_cons (p111 F) (rfl))))))))))))))
  · rfl
def c2596 : CNF.Clause Nat := [(98,true), (7,true), (40,true), (39,false), (86,false), (110,false)]
theorem p2596 (F : Frame G 4) : c2596.eval F.assign = true := by
  apply explicit_rup F.assign c2596 [c2593, c29, c23, c22, c2575, c2595, c262, c1408, c1519, c105, c111, c1791, c2578, c160, c1475] [(29,false), (18,true), (51,true), (62,true), (99,false), (88,false), (87,true), (27,false), (5,false), (50,true), (38,true), (22,false), (33,true), (11,true)]
  · exact sat_cons (p2593 F) ( sat_cons (p29 F) ( sat_cons (p23 F) ( sat_cons (p22 F) ( sat_cons (p2575 F) ( sat_cons (p2595 F) ( sat_cons (p262 F) ( sat_cons (p1408 F) ( sat_cons (p1519 F) ( sat_cons (p105 F) ( sat_cons (p111 F) ( sat_cons (p1791 F) ( sat_cons (p2578 F) ( sat_cons (p160 F) ( sat_cons (p1475 F) (rfl)))))))))))))))
  · rfl
def c2597 : CNF.Clause Nat := [(7,true), (40,true), (39,false), (86,false), (110,false)]
theorem p2597 (F : Frame G 4) : c2597.eval F.assign = true := by
  apply explicit_rup F.assign c2597 [c2575, c2593, c22, c23, c29, c2596, c1401, c2067, c154, c157, c1791, c1393, c1785, c91] [(99,false), (29,false), (62,true), (51,true), (18,true), (98,true), (33,false), (88,false), (22,true), (11,true), (50,false), (27,false), (38,false)]
  · exact sat_cons (p2575 F) ( sat_cons (p2593 F) ( sat_cons (p22 F) ( sat_cons (p23 F) ( sat_cons (p29 F) ( sat_cons (p2596 F) ( sat_cons (p1401 F) ( sat_cons (p2067 F) ( sat_cons (p154 F) ( sat_cons (p157 F) ( sat_cons (p1791 F) ( sat_cons (p1393 F) ( sat_cons (p1785 F) ( sat_cons (p91 F) (rfl))))))))))))))
  · rfl
def c2598 : CNF.Clause Nat := [(51,false), (98,false), (7,false), (39,false), (86,false), (110,false)]
theorem p2598 (F : Frame G 4) : c2598.eval F.assign = true := by
  apply explicit_rup F.assign c2598 [c1518, c2043, c2161, c1423, c142] [(87,false), (30,false), (88,false), (19,false)]
  · exact sat_cons (p1518 F) ( sat_cons (p2043 F) ( sat_cons (p2161 F) ( sat_cons (p1423 F) ( sat_cons (p142 F) (rfl)))))
  · rfl
def c2599 : CNF.Clause Nat := [(30,false), (18,false), (62,false), (98,false), (7,false), (39,false), (86,false), (110,false)]
theorem p2599 (F : Frame G 4) : c2599.eval F.assign = true := by
  apply explicit_rup F.assign c2599 [c2598, c1389, c2113, c1868, c11] [(51,false), (5,false), (38,false), (50,false)]
  · exact sat_cons (p2598 F) ( sat_cons (p1389 F) ( sat_cons (p2113 F) ( sat_cons (p1868 F) ( sat_cons (p11 F) (rfl)))))
  · rfl
def c2600 : CNF.Clause Nat := [(38,true), (87,true), (88,true), (30,true), (51,true), (98,false), (7,false), (40,true), (86,false), (110,false)]
theorem p2600 (F : Frame G 4) : c2600.eval F.assign = true := by
  apply explicit_rup F.assign c2600 [c142, c138, c2575, c140, c2047, c1809, c164, c154, c157, c1393, c1275, c13] [(19,true), (62,true), (99,false), (50,true), (31,false), (33,false), (9,true), (22,true), (11,true), (27,false), (5,false)]
  · exact sat_cons (p142 F) ( sat_cons (p138 F) ( sat_cons (p2575 F) ( sat_cons (p140 F) ( sat_cons (p2047 F) ( sat_cons (p1809 F) ( sat_cons (p164 F) ( sat_cons (p154 F) ( sat_cons (p157 F) ( sat_cons (p1393 F) ( sat_cons (p1275 F) ( sat_cons (p13 F) (rfl))))))))))))
  · rfl
end Cert44Steps
end Graffiti199Depleted.Catalogue.OrderEleven
