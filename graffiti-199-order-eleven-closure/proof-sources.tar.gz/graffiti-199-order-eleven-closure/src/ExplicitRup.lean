import LocalRup

namespace Graffiti199Depleted.Catalogue.OrderEleven

open Std.Sat

/-- Each inferred unit is supplied literally, so reduction never carries
the expression for an earlier inference into a later one. -/
def explicitRup (units : List (Literal Nat)) : CNF Nat → List (Literal Nat) → Bool
  | [c], [] => (reduceClause units c).isEmpty
  | c :: cs, l :: ls =>
    (reduceClause units c == [l]) && explicitRup (l :: units) cs ls
  | _, _ => false

private theorem explicit_valid (units : List (Literal Nat)) (parents : CNF Nat)
    (witness : List (Literal Nat)) (checked : explicitRup units parents witness = true) :
    refuteByUnits units parents = true := by
  induction witness generalizing units parents with
  | nil =>
    rcases parents with _|⟨c,parents⟩
    · simp [explicitRup] at checked
    · cases parents with
      | nil =>
        have h : reduceClause units c = [] := by simpa [explicitRup] using checked
        simp [refuteByUnits,h]
      | cons other cs => simp [explicitRup] at checked
  | cons l ls ih =>
    rcases parents with _|⟨c,cs⟩
    · simp [explicitRup] at checked
    · have h : reduceClause units c = [l] ∧ explicitRup (l :: units) cs ls = true := by
        simpa [explicitRup] using checked
      simpa [refuteByUnits,h.1] using ih (l :: units) cs h.2

theorem explicit_rup (a : Nat → Bool) (c : CNF.Clause Nat) (parents : CNF Nat)
    (witness : List (Literal Nat)) (sat : parents.eval a = true)
    (checked : explicitRup (c.map negateLiteral) parents witness = true) :
    c.eval a = true :=
  local_rup a c parents sat (explicit_valid _ _ _ checked)

#print axioms explicit_rup
end Graffiti199Depleted.Catalogue.OrderEleven
