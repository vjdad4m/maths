import GraphLift

namespace Graffiti199Depleted.Catalogue.OrderEleven

open SimpleGraph

universe u
variable {V : Type u} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj]

variable [DecidableEq V]

/-- Transport a counterexample in the exact order-eleven crossing-failure
branch to the finite certificate format for the two component splits. -/
theorem order_eleven_frames_of_crossing_failure_of_independent_cubics
    (order : Fintype.card V = 11)
    (smaller : SmallerAtThree.{u} (Fintype.card V))
    (conn : ConnectivityAtLeast G 3) (budget : treeNumber G ≤ 5)
    (no : ¬ Traceable G)
    (ind : ∀ a b, G.degree a = 3 → G.degree b = 3 → ¬ G.Adj a b)
    (fail : ¬ CrossingBetweenSurvivingEdges G) : Nonempty (Frame G 3) ∨ Nonempty (Frame G 4) := by
  classical
  obtain ⟨F,_,cover,cards⟩ :=
    order_eleven_crossing_failure_two_shapes order smaller conn budget no ind fail
  let A := componentShore F.cut F.first
  let B := componentShore F.cut F.second
  change (Nat.card A = 3 ∧ Nat.card B = 5) ∨ (Nat.card A = 4 ∧ Nat.card B = 4) ∨
    (Nat.card A = 5 ∧ Nat.card B = 3) at cards
  have offA := componentShore_off_cut F.cut F.first
  have offB := componentShore_off_cut F.cut F.second
  have apart := componentShore_disjoint F.different
  have ba := componentShore_boundary F.cut F.first
  have bb := componentShore_boundary F.cut F.second
  have ca := componentShore_connected F.cut F.first
  have cb := componentShore_connected F.cut F.second
  rcases cards with ⟨a3,b5⟩|⟨a4,b4⟩|⟨a5,b3⟩
  · exact Or.inl (frame_of_two_shores conn order F.size (by decide) (by decide) a3 b5
      offA offB apart cover ba bb ca cb ind budget no)
  · exact Or.inr (frame_of_two_shores conn order F.size (by decide) (by decide) a4 b4
      offA offB apart cover ba bb ca cb ind budget no)
  · have reverseCover (v : V) : v ∈ B ∨ v ∈ A ∨ v ∈ F.cut := by
      have h : v ∈ A ∨ v ∈ B ∨ v ∈ F.cut := cover v
      tauto
    exact Or.inl (frame_of_two_shores conn order F.size (by decide) (by decide) b3 a5
      offB offA apart.symm reverseCover bb ba cb ca ind budget no)

#print axioms order_eleven_frames_of_crossing_failure_of_independent_cubics

end Graffiti199Depleted.Catalogue.OrderEleven
