import RuleSound
import ShoreHall
import OrderElevenGeometry

namespace Graffiti199Depleted.Catalogue.OrderEleven

open SimpleGraph

private theorem matchedEnumeration {W : Type*} [Finite W] {n : Nat}
    (large : 3 ≤ n) (card : Nat.card W = n) (m : Port ↪ W) :
    ∃ e : Fin n ≃ W, ∀ p : Port,
      e ⟨p.val, lt_of_lt_of_le p.isLt large⟩ = m p := by
  classical
  let R := Set.range m
  let eR : Port ≃ R := Equiv.ofBijective (fun i => ⟨m i, ⟨i,rfl⟩⟩) (by
    constructor
    · intro i j h
      exact m.injective (congrArg Subtype.val h)
    · rintro ⟨x,i,rfl⟩
      exact ⟨i,rfl⟩)
  letI : Fintype W := Fintype.ofFinite W
  letI : Fintype R := Fintype.ofFinite R
  letI : Fintype (Rᶜ : Set W) := Fintype.ofFinite (Rᶜ : Set W)
  have cr := Nat.card_congr eR
  have cr' : Nat.card R = 3 := cr.symm.trans (by simp [Port,Nat.card_eq_fintype_card])
  have cc := Nat.card_congr (Equiv.sumCompl R)
  rw [Nat.card_sum] at cc
  change Nat.card R + Nat.card (Rᶜ : Set W) = Nat.card W at cc
  rw [cr',card] at cc
  have cRest : Fintype.card (Rᶜ : Set W) = n-3 := by
    rw [← Nat.card_eq_fintype_card]
    omega
  let eC : Fin (n-3) ≃ (Rᶜ : Set W) := (Fintype.equivFinOfCardEq cRest).symm
  let e := (finCongr (show n = 3+(n-3) by omega)).trans
    (finSumFinEquiv.symm.trans ((eR.sumCongr eC).trans (Equiv.sumCompl R)))
  refine ⟨e,?_⟩
  intro p
  have index : (finCongr (show n = 3+(n-3) by omega)) ⟨p.val, lt_of_lt_of_le p.isLt large⟩ =
      Fin.castAdd (n-3) p := Fin.ext rfl
  change (Equiv.sumCompl R) ((eR.sumCongr eC) (finSumFinEquiv.symm
    ((finCongr (show n = 3+(n-3) by omega)) ⟨p.val, lt_of_lt_of_le p.isLt large⟩))) = _
  rw [index,finSumFinEquiv_symm_apply_castAdd]
  rfl

variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj]
    {D : Finset V} {A B : Set V} {k : Nat}

private def enumerate (pe : Port ≃ ↥D) (ae : Fin k ≃ A) (be : Fin (8-k) ≃ B)
    (ku : k ≤ 8) (v : Vertex) : V :=
  if hp : v.val < 3 then (pe ⟨v.val,hp⟩).val
  else if ha : v.val < 3+k then (ae ⟨v.val-3,by omega⟩).val
  else (be ⟨v.val-3-k,by have := v.isLt; omega⟩).val

/-- Lift the labeled certificate to the actual cut. The Hall matchings select
the three fixed labels on each side. Edges inside the cut play no role. -/
theorem frame_of_two_shores
    (conn : ConnectivityAtLeast G 3) (order : Fintype.card V = 11)
    (cut : D.card = 3) (low : 3 ≤ k) (high : k ≤ 5)
    (cardA : Nat.card A = k) (cardB : Nat.card B = 8-k)
    (offA : ∀ x ∈ D, x ∉ A) (offB : ∀ x ∈ D, x ∉ B)
    (apart : Disjoint A B) (cover : ∀ v, v ∈ A ∨ v ∈ B ∨ v ∈ D)
    (ba : ShoreBoundary G D A) (bb : ShoreBoundary G D B)
    (ca : (G.induce A).Connected) (cb : (G.induce B).Connected)
    (cubic : ∀ x y : V, G.degree x = 3 → G.degree y = 3 → ¬ G.Adj x y)
    (budget : treeNumber G ≤ 5) (no : ¬ Traceable G) : Nonempty (Frame G k) := by
  classical
  have dis := Set.disjoint_left.mp apart
  obtain ⟨⟨a,ina⟩⟩ := ca.nonempty
  obtain ⟨⟨b,inb⟩⟩ := cb.nonempty
  obtain ⟨ma,adjA⟩ := shore_distinct_attachments conn cut offA ba (by omega)
    ⟨b,fun h => dis h inb, fun h => offB b h inb⟩
  obtain ⟨mb,adjB⟩ := shore_distinct_attachments conn cut offB bb (by omega)
    ⟨a,fun h => dis ina h, fun h => offA a h ina⟩
  let pe : Port ≃ ↥D := (Fintype.equivFinOfCardEq (by rw [Fintype.card_coe,cut])).symm
  obtain ⟨ae,fixA⟩ := matchedEnumeration low cardA (pe.toEmbedding.trans ma)
  obtain ⟨be,fixB⟩ := matchedEnumeration (show 3 ≤ 8-k by omega) cardB (pe.toEmbedding.trans mb)
  have ku : k ≤ 8 := by omega
  let f := enumerate pe ae be ku
  have tag (v : Vertex) :
      (IsPort v ↔ f v ∈ D) ∧
      (InSide k true v ↔ f v ∈ A) ∧
      (InSide k false v ↔ f v ∈ B) := by
    unfold IsPort InSide f enumerate
    by_cases hp : v.val < 3
    · rw [dif_pos hp]
      have hd := (pe ⟨v.val,hp⟩).property
      simp [hp,hd,offA _ hd,offB _ hd,show ¬ 3 ≤ v.val by omega,
        show ¬ 3+k ≤ v.val by omega]
    · rw [dif_neg hp]
      by_cases ha : v.val < 3+k
      · rw [dif_pos ha]
        have hk := (ae ⟨v.val-3,by omega⟩).property
        have nd : (ae ⟨v.val-3,by omega⟩).val ∉ D := fun h => offA _ h hk
        have nb : (ae ⟨v.val-3,by omega⟩).val ∉ B := fun h => dis hk h
        simp [hp,ha,hk,nd,nb,show 3 ≤ v.val by omega,show ¬ 3+k ≤ v.val by omega]
      · rw [dif_neg ha]
        have hk := (be ⟨v.val-3-k,by have := v.isLt; omega⟩).property
        have nd : (be ⟨v.val-3-k,by have := v.isLt; omega⟩).val ∉ D :=
          fun h => offB _ h hk
        have na : (be ⟨v.val-3-k,by have := v.isLt; omega⟩).val ∉ A :=
          fun h => dis h hk
        simp [hp,ha,hk,nd,na,show 3+k ≤ v.val by omega]
  have inj : Function.Injective f := by
    intro u v eq
    have hp : IsPort u ↔ IsPort v := by rw [(tag u).1,(tag v).1,eq]
    have ha : InSide k true u ↔ InSide k true v := by rw [(tag u).2.1,(tag v).2.1,eq]
    unfold IsPort at hp
    unfold InSide at ha
    simp only [if_true] at ha
    unfold f enumerate at eq
    by_cases up : u.val < 3
    · have vp := hp.mp up
      rw [dif_pos up,dif_pos vp] at eq
      exact Fin.ext (congrArg (Fin.val : Port → Nat) (pe.injective (Subtype.ext eq)))
    · have vp : ¬ v.val < 3 := fun h => up (hp.mpr h)
      rw [dif_neg up,dif_neg vp] at eq
      by_cases ua : u.val < 3+k
      · have va := (ha.mp ⟨by omega,ua⟩).2
        rw [dif_pos ua,dif_pos va] at eq
        have h := congrArg Fin.val (ae.injective (Subtype.ext eq))
        exact Fin.ext (by change u.val-3 = v.val-3 at h; omega)
      · have va : ¬ v.val < 3+k := fun h => ua (ha.mpr ⟨by omega,h⟩).2
        rw [dif_neg ua,dif_neg va] at eq
        have h := congrArg Fin.val (be.injective (Subtype.ext eq))
        exact Fin.ext (by change u.val-3-k = v.val-3-k at h; omega)
  have sur : Function.Surjective f := by
    have card : Fintype.card Vertex = Fintype.card V := by simp [Vertex,order]
    exact (Fintype.bijective_iff_injective_and_card f).mpr ⟨inj,card⟩ |>.2
  let name : Vertex ≃ V := Equiv.ofBijective f ⟨inj,sur⟩
  have fix (left : Bool) (p : Port) (v : Vertex)
      (hv : v.val = 3 + (if left then 0 else k) + p.val) :
      G.Adj (name (port p)) (name v) := by
    have hp : (port p).val < 3 := p.isLt
    have pn : name (port p) = (pe p).val := by
      change enumerate pe ae be ku (port p) = _
      rw [enumerate,dif_pos hp]
      rfl
    rw [pn]
    change G.Adj _ (enumerate pe ae be ku v)
    have pp := p.isLt
    cases left <;> simp only [Bool.false_eq_true,ite_false,ite_true] at hv
    · rw [enumerate,dif_neg (show ¬ v.val < 3 by omega),
        dif_neg (show ¬ v.val < 3+k by omega)]
      have ix : (⟨v.val-3-k, by have := v.isLt; omega⟩ : Fin (8-k)) =
          ⟨p.val,by omega⟩ := Fin.ext (by change v.val-3-k = p.val; omega)
      rw [ix,fixB]
      exact adjB (pe p)
    · rw [enumerate,dif_neg (show ¬ v.val < 3 by omega),
        dif_pos (show v.val < 3+k by omega)]
      have ix : (⟨v.val-3, by omega⟩ : Fin k) =
          ⟨p.val,by omega⟩ := Fin.ext (by change v.val-3 = p.val; omega)
      rw [ix,fixA]
      exact adjA (pe p)
  refine ⟨⟨name,?_,?_,cubic,?_,fix,?_,budget,no⟩⟩
  · intro u v nu adj
    have ne : u ≠ v := fun eq => G.loopless _ (eq ▸ adj)
    by_cases vp : IsPort v
    · exact ⟨ne,Or.inr (Or.inl ⟨nu,vp⟩)⟩
    have moveA (x : Vertex) : InSide k true x ↔ name x ∈ A := (tag x).2.1
    have moveB (x : Vertex) : InSide k false x ↔ name x ∈ B := (tag x).2.2
    have nd : name v ∉ D := fun e => vp ((tag v).1.mpr e)
    rcases cover (name u) with ua|ub|ud
    · have va : name v ∈ A := by
        by_cases mem : name v ∈ A
        · exact mem
        · exact (nd (ba _ ua _ mem adj)).elim
      exact allowed_same_side ((moveA u).mpr ua) ((moveA v).mpr va) ne
    · have vb : name v ∈ B := by
        by_cases mem : name v ∈ B
        · exact mem
        · exact (nd (bb _ ub _ mem adj)).elim
      exact allowed_same_side ((moveB u).mpr ub) ((moveB v).mpr vb) ne
    · exact (nu ((tag u).1.mpr ud)).elim
  · intro x _
    exact degree_of_small_deletion_preconnected (by omega)
      (fun R h => (conn.2 R h).preconnected) (name x)
  · intro left
    let m : Port ↪ Vertex := ⟨fun p => ⟨3+(if left then 0 else k)+p.val,by
      have h := p.isLt
      split <;> omega⟩,by
      intro p q eq
      have e := congrArg Fin.val eq
      exact Fin.ext (by change 3+(if left then 0 else k)+p.val =
        3+(if left then 0 else k)+q.val at e; omega)⟩
    refine ⟨m,?_,fun p => fix left p (m p) rfl⟩
    intro p
    have h := p.isLt
    cases left <;> simp only [m,InSide,Bool.false_eq_true,ite_false,ite_true,
      Function.Embedding.coeFn_mk] <;> omega
  · intro left
    have sa : {x | InSide k true (name.symm x)} = A := by
      ext x
      rw [Set.mem_setOf_eq,(tag (name.symm x)).2.1]
      change name (name.symm x) ∈ A ↔ x ∈ A
      rw [name.apply_symm_apply]
    have sb : {x | InSide k false (name.symm x)} = B := by
      ext x
      rw [Set.mem_setOf_eq,(tag (name.symm x)).2.2]
      change name (name.symm x) ∈ B ↔ x ∈ B
      rw [name.apply_symm_apply]
    cases left
    · rw [sb]
      exact cb
    · rw [sa]
      exact ca

#print axioms frame_of_two_shores

end Graffiti199Depleted.Catalogue.OrderEleven
