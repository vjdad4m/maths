import LocalRup

namespace Graffiti199Depleted.Catalogue.OrderEleven

open Std.Sat

def LitSat (a : Nat → Bool) (l : Literal Nat) : Prop := a l.1 = l.2

def ClauseCases (a : Nat → Bool) (conclusion : Prop) : CNF.Clause Nat → Prop
  | [] => True
  | l :: rest => (LitSat a l → conclusion) ∧ ClauseCases a conclusion rest

private theorem select_literal {a : Nat → Bool} {q : Prop} {l : Literal Nat}
    (truth : LitSat a l) (c : CNF.Clause Nat)
    (mem : l ∈ c) (steps : ClauseCases a q c) : q := by
  induction c with
  | nil => simp at mem
  | cons j rest ih =>
    rcases List.mem_cons.mp mem with same|later
    · subst j
      exact steps.1 truth
    · exact ih later steps.2

/-- A satisfied clause proves a conclusion that follows from each literal. -/
theorem use_clause {a : Nat → Bool} {q : Prop} {c : CNF.Clause Nat}
    (sat : c.eval a = true) (steps : ClauseCases a q c) : q := by
  obtain ⟨l,hl,hit⟩ := List.any_eq_true.mp sat
  have h : LitSat a l := by simpa [LitSat] using hit
  exact select_literal h c hl steps

theorem unit_incompatible {a : Nat → Bool} {l : Literal Nat} (h : LitSat a l) :
    ¬ LitSat a (negateLiteral l) := by
  rcases l with ⟨v,b⟩
  cases b <;> simp_all [LitSat,negateLiteral]

theorem literal_denied {a : Nat → Bool} {c : CNF.Clause Nat}
    (absent : ¬ c.eval a = true) {l : Literal Nat} (mem : l ∈ c) : ¬ LitSat a l := by
  intro h
  exact absent (List.any_eq_true.mpr ⟨l,mem,by simpa [LitSat] using h⟩)

#print axioms use_clause
end Graffiti199Depleted.Catalogue.OrderEleven
