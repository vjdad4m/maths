import Local35Part2
namespace Graffiti199Depleted.Catalogue.OrderEleven
namespace Cert35Steps
open Std.Sat
set_option maxRecDepth 4096
set_option maxHeartbeats 0
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj]
def c901 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (17,false), (19,false), (86,false), (98,false), (32,false), (29,false), (77,false)]
theorem p901 (F : Frame G 3) : c901.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 1, 7, 8, 9, 2, 6, 10]) (by decide +kernel)
def c902 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (28,false), (30,false), (86,false), (98,false), (21,false), (18,false), (77,false)]
theorem p902 (F : Frame G 3) : c902.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 2, 7, 8, 9, 1, 6, 10]) (by decide +kernel)
def c903 : CNF.Clause Nat := [(11,false), (77,false), (75,false), (98,false), (87,false), (30,false), (27,false), (16,false), (15,false), (39,false)]
theorem p903 (F : Frame G 3) : c903.eval F.assign = true := by
  exact Rule.sound F (.path [0, 10, 6, 8, 9, 7, 2, 4, 1, 3, 5]) (by decide +kernel)
def c904 : CNF.Clause Nat := [(11,false), (77,false), (75,false), (98,false), (87,false), (19,false), (16,false), (27,false), (26,false), (39,false)]
theorem p904 (F : Frame G 3) : c904.eval F.assign = true := by
  exact Rule.sound F (.path [0, 10, 6, 8, 9, 7, 1, 4, 2, 3, 5]) (by decide +kernel)
def c905 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (28,false), (33,false), (77,false), (7,false), (8,false), (86,false), (98,false)]
theorem p905 (F : Frame G 3) : c905.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 2, 10, 6, 0, 7, 8, 9]) (by decide +kernel)
def c906 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (4,false), (7,false), (75,false), (98,false), (21,false), (19,false), (88,false)]
theorem p906 (F : Frame G 3) : c906.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 0, 6, 8, 9, 1, 7, 10]) (by decide +kernel)
def c907 : CNF.Clause Nat := [(16,false), (19,false), (8,false), (4,false), (39,false), (28,false), (33,false), (77,false), (75,false), (98,false)]
theorem p907 (F : Frame G 3) : c907.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 7, 0, 3, 5, 2, 10, 6, 8, 9]) (by decide +kernel)
def c908 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (19,false), (86,false), (98,false), (10,false), (7,false), (29,false), (33,false)]
theorem p908 (F : Frame G 3) : c908.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 1, 7, 8, 9, 0, 6, 2, 10]) (by decide +kernel)
def c909 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (18,false), (7,false), (10,false), (32,false), (31,false), (86,false), (88,false)]
theorem p909 (F : Frame G 3) : c909.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 1, 6, 0, 9, 2, 8, 7, 10]) (by decide +kernel)
def c910 : CNF.Clause Nat := [(10,false), (98,false), (75,false), (74,false), (19,false), (22,false), (33,false), (27,false), (38,false), (39,false)]
theorem p910 (F : Frame G 3) : c910.eval F.assign = true := by
  exact Rule.sound F (.path [0, 9, 8, 6, 7, 1, 10, 2, 4, 3, 5]) (by decide +kernel)
def c911 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (16,false), (19,false), (74,false), (77,false), (33,false), (31,false), (98,false)]
theorem p911 (F : Frame G 3) : c911.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 1, 7, 6, 10, 2, 8, 9]) (by decide +kernel)
def c912 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (28,false), (31,false), (75,false), (7,false), (10,false), (87,false), (88,false)]
theorem p912 (F : Frame G 3) : c912.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 2, 8, 6, 0, 9, 7, 10]) (by decide +kernel)
def c913 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (11,false), (22,false), (19,false), (74,false), (75,false), (31,false), (32,false)]
theorem p913 (F : Frame G 3) : c913.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 0, 10, 1, 7, 6, 8, 2, 9]) (by decide +kernel)
def c914 : CNF.Clause Nat := [(5,false), (38,false), (39,false), (17,false), (21,false), (98,false), (31,false), (29,false), (74,false), (88,false)]
theorem p914 (F : Frame G 3) : c914.eval F.assign = true := by
  exact Rule.sound F (.path [0, 4, 3, 5, 1, 9, 8, 2, 6, 7, 10]) (by decide +kernel)
def c915 : CNF.Clause Nat := [(7,false), (74,false), (88,false), (33,false), (32,false), (98,false), (20,false), (16,false), (38,false), (39,false)]
theorem p915 (F : Frame G 3) : c915.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 7, 10, 2, 9, 8, 1, 4, 3, 5]) (by decide +kernel)
def c916 : CNF.Clause Nat := [(26,false), (28,false), (50,false), (16,false), (19,false), (74,false), (77,false), (11,false), (9,false), (98,false)]
theorem p916 (F : Frame G 3) : c916.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 4, 1, 7, 6, 10, 0, 8, 9]) (by decide +kernel)
def c917 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (5,false), (7,false), (18,false), (22,false), (88,false), (86,false), (98,false)]
theorem p917 (F : Frame G 3) : c917.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 0, 6, 1, 10, 7, 8, 9]) (by decide +kernel)
def c918 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (28,false), (29,false), (7,false), (11,false), (88,false), (86,false), (98,false)]
theorem p918 (F : Frame G 3) : c918.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 2, 6, 0, 10, 7, 8, 9]) (by decide +kernel)
def c919 : CNF.Clause Nat := [(16,false), (20,false), (98,false), (87,false), (88,false), (11,false), (7,false), (29,false), (26,false), (39,false)]
theorem p919 (F : Frame G 3) : c919.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 8, 9, 7, 10, 0, 6, 2, 3, 5]) (by decide +kernel)
def c920 : CNF.Clause Nat := [(16,false), (15,false), (39,false), (28,false), (29,false), (74,false), (88,false), (11,false), (9,false), (98,false)]
theorem p920 (F : Frame G 3) : c920.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 3, 5, 2, 6, 7, 10, 0, 8, 9]) (by decide +kernel)
def c921 : CNF.Clause Nat := [(27,false), (28,false), (39,false), (4,false), (7,false), (18,false), (20,false), (98,false), (87,false), (88,false)]
theorem p921 (F : Frame G 3) : c921.eval F.assign = true := by
  exact Rule.sound F (.path [4, 2, 5, 3, 0, 6, 1, 8, 9, 7, 10]) (by decide +kernel)
def c922 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (6,false), (7,false), (77,false), (33,false), (30,false), (87,false), (98,false)]
theorem p922 (F : Frame G 3) : c922.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 0, 6, 10, 2, 7, 9, 8]) (by decide +kernel)
def c923 : CNF.Clause Nat := [(16,false), (15,false), (39,false), (28,false), (31,false), (98,false), (87,false), (8,false), (7,false), (77,false)]
theorem p923 (F : Frame G 3) : c923.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 3, 5, 2, 8, 9, 7, 0, 6, 10]) (by decide +kernel)
def c924 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (28,false), (31,false), (98,false), (87,false), (8,false), (7,false), (77,false)]
theorem p924 (F : Frame G 3) : c924.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 2, 8, 9, 7, 0, 6, 10]) (by decide +kernel)
def c925 : CNF.Clause Nat := [(7,false), (74,false), (88,false), (22,false), (16,false), (38,false), (39,false), (28,false), (31,false), (98,false)]
theorem p925 (F : Frame G 3) : c925.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 7, 10, 1, 4, 3, 5, 2, 8, 9]) (by decide +kernel)
def c926 : CNF.Clause Nat := [(38,false), (39,false), (28,false), (33,false), (11,false), (7,false), (75,false), (20,false), (19,false), (87,false)]
theorem p926 (F : Frame G 3) : c926.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 2, 10, 0, 6, 8, 1, 7, 9]) (by decide +kernel)
def c927 : CNF.Clause Nat := [(39,false), (50,false), (16,false), (19,false), (30,false), (32,false), (98,false), (9,false), (7,false), (77,false)]
theorem p927 (F : Frame G 3) : c927.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 1, 7, 2, 9, 8, 0, 6, 10]) (by decide +kernel)
def c928 : CNF.Clause Nat := [(7,false), (75,false), (98,false), (32,false), (28,false), (39,false), (38,false), (16,false), (19,false), (88,false)]
theorem p928 (F : Frame G 3) : c928.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 8, 9, 2, 5, 3, 4, 1, 7, 10]) (by decide +kernel)
def c929 : CNF.Clause Nat := [(4,false), (6,false), (50,false), (16,false), (22,false), (88,false), (30,false), (29,false), (75,false), (98,false)]
theorem p929 (F : Frame G 3) : c929.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 5, 4, 1, 10, 7, 2, 6, 8, 9]) (by decide +kernel)
def c930 : CNF.Clause Nat := [(16,false), (38,false), (4,false), (6,false), (28,false), (33,false), (88,false), (74,false), (75,false), (98,false)]
theorem p930 (F : Frame G 3) : c930.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 0, 5, 2, 10, 7, 6, 8, 9]) (by decide +kernel)
def c931 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (19,false), (8,false), (11,false), (33,false), (29,false), (75,false), (98,false)]
theorem p931 (F : Frame G 3) : c931.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 1, 7, 0, 10, 2, 6, 8, 9]) (by decide +kernel)
def c932 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (4,false), (7,false), (75,false), (98,false), (87,false), (19,false), (22,false)]
theorem p932 (F : Frame G 3) : c932.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 0, 6, 8, 9, 7, 1, 10]) (by decide +kernel)
def c933 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (28,false), (30,false), (88,false), (77,false), (7,false), (9,false), (98,false)]
theorem p933 (F : Frame G 3) : c933.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 2, 7, 10, 6, 0, 8, 9]) (by decide +kernel)
def c934 : CNF.Clause Nat := [(19,false), (88,false), (77,false), (75,false), (98,false), (32,false), (26,false), (4,false), (5,false), (50,false)]
theorem p934 (F : Frame G 3) : c934.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 10, 6, 8, 9, 2, 3, 0, 4, 5]) (by decide +kernel)
def c935 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (6,false), (7,false), (77,false), (88,false), (30,false), (31,false), (98,false)]
theorem p935 (F : Frame G 3) : c935.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 0, 6, 10, 7, 2, 8, 9]) (by decide +kernel)
def c936 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (15,false), (19,false), (88,false), (77,false), (7,false), (9,false), (98,false)]
theorem p936 (F : Frame G 3) : c936.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 1, 7, 10, 6, 0, 8, 9]) (by decide +kernel)
def c937 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (28,false), (32,false), (10,false), (7,false), (75,false), (86,false), (88,false)]
theorem p937 (F : Frame G 3) : c937.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 2, 9, 0, 6, 8, 7, 10]) (by decide +kernel)
def c938 : CNF.Clause Nat := [(16,false), (38,false), (4,false), (6,false), (28,false), (30,false), (87,false), (98,false), (75,false), (77,false)]
theorem p938 (F : Frame G 3) : c938.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 0, 5, 2, 7, 9, 8, 6, 10]) (by decide +kernel)
def c939 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (8,false), (19,false), (21,false), (32,false), (31,false), (75,false), (77,false)]
theorem p939 (F : Frame G 3) : c939.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 0, 7, 1, 9, 2, 8, 6, 10]) (by decide +kernel)
def c940 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (11,false), (77,false), (74,false), (19,false), (20,false), (31,false), (32,false)]
theorem p940 (F : Frame G 3) : c940.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 0, 10, 6, 7, 1, 8, 2, 9]) (by decide +kernel)
def c941 : CNF.Clause Nat := [(28,false), (33,false), (11,false), (4,false), (38,false), (16,false), (19,false), (74,false), (75,false), (98,false)]
theorem p941 (F : Frame G 3) : c941.eval F.assign = true := by
  exact Rule.sound F (.path [5, 2, 10, 0, 3, 4, 1, 7, 6, 8, 9]) (by decide +kernel)
def c942 : CNF.Clause Nat := [(7,false), (75,false), (98,false), (87,false), (88,false), (33,false), (27,false), (16,false), (15,false), (39,false)]
theorem p942 (F : Frame G 3) : c942.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 8, 9, 7, 10, 2, 4, 1, 3, 5]) (by decide +kernel)
def c943 : CNF.Clause Nat := [(7,false), (75,false), (98,false), (87,false), (88,false), (22,false), (16,false), (27,false), (26,false), (39,false)]
theorem p943 (F : Frame G 3) : c943.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 8, 9, 7, 10, 1, 4, 2, 3, 5]) (by decide +kernel)
def c944 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (5,false), (7,false), (75,false), (98,false), (21,false), (19,false), (88,false)]
theorem p944 (F : Frame G 3) : c944.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 0, 6, 8, 9, 1, 7, 10]) (by decide +kernel)
def c945 : CNF.Clause Nat := [(7,false), (75,false), (98,false), (87,false), (88,false), (33,false), (26,false), (38,false), (16,false), (17,false)]
theorem p945 (F : Frame G 3) : c945.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 8, 9, 7, 10, 2, 3, 4, 1, 5]) (by decide +kernel)
def c946 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (7,false), (77,false), (22,false), (19,false), (30,false), (31,false), (98,false)]
theorem p946 (F : Frame G 3) : c946.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 0, 6, 10, 1, 7, 2, 8, 9]) (by decide +kernel)
def c947 : CNF.Clause Nat := [(26,false), (28,false), (50,false), (16,false), (19,false), (86,false), (98,false), (10,false), (7,false), (77,false)]
theorem p947 (F : Frame G 3) : c947.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 4, 1, 7, 8, 9, 0, 6, 10]) (by decide +kernel)
def c948 : CNF.Clause Nat := [(39,false), (50,false), (16,false), (19,false), (30,false), (31,false), (98,false), (10,false), (7,false), (77,false)]
theorem p948 (F : Frame G 3) : c948.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 1, 7, 2, 8, 9, 0, 6, 10]) (by decide +kernel)
def c949 : CNF.Clause Nat := [(4,false), (38,false), (16,false), (17,false), (28,false), (32,false), (98,false), (86,false), (74,false), (77,false)]
theorem p949 (F : Frame G 3) : c949.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 1, 5, 2, 9, 8, 7, 6, 10]) (by decide +kernel)
def c950 : CNF.Clause Nat := [(19,false), (74,false), (77,false), (11,false), (4,false), (38,false), (50,false), (28,false), (31,false), (98,false)]
theorem p950 (F : Frame G 3) : c950.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 6, 10, 0, 3, 4, 5, 2, 8, 9]) (by decide +kernel)
def c951 : CNF.Clause Nat := [(19,false), (8,false), (4,false), (38,false), (50,false), (28,false), (32,false), (76,false), (75,false), (99,false)]
theorem p951 (F : Frame G 3) : c951.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 0, 3, 4, 5, 2, 9, 6, 8, 10]) (by decide +kernel)
def c952 : CNF.Clause Nat := [(19,false), (87,false), (76,false), (7,false), (4,false), (38,false), (50,false), (28,false), (31,false), (99,false)]
theorem p952 (F : Frame G 3) : c952.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 9, 6, 0, 3, 4, 5, 2, 8, 10]) (by decide +kernel)
def c953 : CNF.Clause Nat := [(4,false), (38,false), (16,false), (17,false), (28,false), (30,false), (86,false), (75,false), (76,false), (110,false)]
theorem p953 (F : Frame G 3) : c953.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 1, 5, 2, 7, 8, 6, 9, 10]) (by decide +kernel)
def c954 : CNF.Clause Nat := [(5,false), (4,false), (39,false), (17,false), (18,false), (76,false), (98,false), (31,false), (30,false), (88,false)]
theorem p954 (F : Frame G 3) : c954.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 3, 5, 1, 6, 9, 8, 2, 7, 10]) (by decide +kernel)
def c955 : CNF.Clause Nat := [(5,false), (4,false), (39,false), (17,false), (19,false), (74,false), (76,false), (32,false), (31,false), (99,false)]
theorem p955 (F : Frame G 3) : c955.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 3, 5, 1, 7, 6, 9, 2, 8, 10]) (by decide +kernel)
def c956 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (19,false), (8,false), (7,false), (76,false), (32,false), (31,false), (99,false)]
theorem p956 (F : Frame G 3) : c956.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 1, 7, 0, 6, 9, 2, 8, 10]) (by decide +kernel)
def c957 : CNF.Clause Nat := [(5,false), (4,false), (39,false), (17,false), (19,false), (88,false), (99,false), (31,false), (29,false), (76,false)]
theorem p957 (F : Frame G 3) : c957.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 3, 5, 1, 7, 10, 8, 2, 6, 9]) (by decide +kernel)
def c958 : CNF.Clause Nat := [(22,false), (88,false), (74,false), (75,false), (9,false), (10,false), (32,false), (26,false), (38,false), (50,false)]
theorem p958 (F : Frame G 3) : c958.eval F.assign = true := by
  exact Rule.sound F (.path [1, 10, 7, 6, 8, 0, 9, 2, 3, 4, 5]) (by decide +kernel)
def c959 : CNF.Clause Nat := [(7,false), (18,false), (16,false), (38,false), (39,false), (28,false), (32,false), (87,false), (86,false), (99,false)]
theorem p959 (F : Frame G 3) : c959.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 1, 4, 3, 5, 2, 9, 7, 8, 10]) (by decide +kernel)
def c960 : CNF.Clause Nat := [(5,false), (16,false), (17,false), (39,false), (26,false), (29,false), (74,false), (87,false), (98,false), (99,false)]
theorem p960 (F : Frame G 3) : c960.eval F.assign = true := by
  exact Rule.sound F (.path [0, 4, 1, 5, 3, 2, 6, 7, 9, 8, 10]) (by decide +kernel)
def c961 : CNF.Clause Nat := [(5,false), (38,false), (39,false), (17,false), (18,false), (74,false), (88,false), (33,false), (31,false), (98,false)]
theorem p961 (F : Frame G 3) : c961.eval F.assign = true := by
  exact Rule.sound F (.path [0, 4, 3, 5, 1, 6, 7, 10, 2, 8, 9]) (by decide +kernel)
def c962 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (28,false), (29,false), (7,false), (10,false), (87,false), (86,false), (99,false)]
theorem p962 (F : Frame G 3) : c962.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 2, 6, 0, 9, 7, 8, 10]) (by decide +kernel)
def c963 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (6,false), (7,false), (29,false), (32,false), (87,false), (86,false), (99,false)]
theorem p963 (F : Frame G 3) : c963.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 0, 6, 2, 9, 7, 8, 10]) (by decide +kernel)
def c964 : CNF.Clause Nat := [(7,false), (74,false), (87,false), (21,false), (16,false), (38,false), (39,false), (28,false), (31,false), (99,false)]
theorem p964 (F : Frame G 3) : c964.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 7, 9, 1, 4, 3, 5, 2, 8, 10]) (by decide +kernel)
def c965 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (28,false), (32,false), (10,false), (7,false), (74,false), (86,false), (99,false)]
theorem p965 (F : Frame G 3) : c965.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 2, 9, 0, 6, 7, 8, 10]) (by decide +kernel)
def c966 : CNF.Clause Nat := [(16,false), (18,false), (74,false), (88,false), (11,false), (4,false), (39,false), (28,false), (31,false), (98,false)]
theorem p966 (F : Frame G 3) : c966.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 6, 7, 10, 0, 3, 5, 2, 8, 9]) (by decide +kernel)
def c967 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (6,false), (7,false), (76,false), (32,false), (31,false), (86,false), (88,false)]
theorem p967 (F : Frame G 3) : c967.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 0, 6, 9, 2, 8, 7, 10]) (by decide +kernel)
def c968 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (4,false), (7,false), (18,false), (19,false), (87,false), (98,false), (99,false)]
theorem p968 (F : Frame G 3) : c968.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 0, 6, 1, 7, 9, 8, 10]) (by decide +kernel)
def c969 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (15,false), (19,false), (87,false), (98,false), (75,false), (7,false), (11,false)]
theorem p969 (F : Frame G 3) : c969.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 1, 7, 9, 8, 6, 0, 10]) (by decide +kernel)
def c970 : CNF.Clause Nat := [(16,false), (18,false), (7,false), (10,false), (98,false), (99,false), (88,false), (30,false), (26,false), (39,false)]
theorem p970 (F : Frame G 3) : c970.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 6, 0, 9, 8, 10, 7, 2, 3, 5]) (by decide +kernel)
def c971 : CNF.Clause Nat := [(27,false), (28,false), (39,false), (4,false), (7,false), (18,false), (21,false), (98,false), (86,false), (88,false)]
theorem p971 (F : Frame G 3) : c971.eval F.assign = true := by
  exact Rule.sound F (.path [4, 2, 5, 3, 0, 6, 1, 9, 8, 7, 10]) (by decide +kernel)
def c972 : CNF.Clause Nat := [(7,false), (75,false), (99,false), (88,false), (87,false), (21,false), (16,false), (38,false), (26,false), (28,false)]
theorem p972 (F : Frame G 3) : c972.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 8, 10, 7, 9, 1, 4, 3, 2, 5]) (by decide +kernel)
def c973 : CNF.Clause Nat := [(7,false), (29,false), (31,false), (99,false), (88,false), (87,false), (21,false), (15,false), (38,false), (50,false)]
theorem p973 (F : Frame G 3) : c973.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 2, 8, 10, 7, 9, 1, 3, 4, 5]) (by decide +kernel)
def c974 : CNF.Clause Nat := [(38,false), (39,false), (28,false), (29,false), (7,false), (10,false), (21,false), (19,false), (86,false), (99,false)]
theorem p974 (F : Frame G 3) : c974.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 2, 6, 0, 9, 1, 7, 8, 10]) (by decide +kernel)
def c975 : CNF.Clause Nat := [(7,false), (29,false), (27,false), (38,false), (39,false), (17,false), (21,false), (87,false), (86,false), (99,false)]
theorem p975 (F : Frame G 3) : c975.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 2, 4, 3, 5, 1, 9, 7, 8, 10]) (by decide +kernel)
def c976 : CNF.Clause Nat := [(5,false), (38,false), (39,false), (17,false), (21,false), (32,false), (29,false), (75,false), (86,false), (88,false)]
theorem p976 (F : Frame G 3) : c976.eval F.assign = true := by
  exact Rule.sound F (.path [0, 4, 3, 5, 1, 9, 2, 6, 8, 7, 10]) (by decide +kernel)
def c977 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (28,false), (29,false), (76,false), (21,false), (19,false), (86,false), (99,false)]
theorem p977 (F : Frame G 3) : c977.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 2, 6, 9, 1, 7, 8, 10]) (by decide +kernel)
def c978 : CNF.Clause Nat := [(16,false), (38,false), (4,false), (6,false), (28,false), (32,false), (76,false), (74,false), (86,false), (99,false)]
theorem p978 (F : Frame G 3) : c978.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 0, 5, 2, 9, 6, 7, 8, 10]) (by decide +kernel)
def c979 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (15,false), (21,false), (10,false), (7,false), (74,false), (86,false), (99,false)]
theorem p979 (F : Frame G 3) : c979.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 1, 9, 0, 6, 7, 8, 10]) (by decide +kernel)
def c980 : CNF.Clause Nat := [(16,false), (38,false), (4,false), (6,false), (28,false), (29,false), (76,false), (98,false), (86,false), (88,false)]
theorem p980 (F : Frame G 3) : c980.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 0, 5, 2, 6, 9, 8, 7, 10]) (by decide +kernel)
def c981 : CNF.Clause Nat := [(16,false), (38,false), (26,false), (28,false), (6,false), (7,false), (76,false), (98,false), (86,false), (88,false)]
theorem p981 (F : Frame G 3) : c981.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 2, 5, 0, 6, 9, 8, 7, 10]) (by decide +kernel)
def c982 : CNF.Clause Nat := [(26,false), (38,false), (50,false), (17,false), (19,false), (88,false), (11,false), (7,false), (75,false), (98,false)]
theorem p982 (F : Frame G 3) : c982.eval F.assign = true := by
  exact Rule.sound F (.path [2, 3, 4, 5, 1, 7, 10, 0, 6, 8, 9]) (by decide +kernel)
def c983 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (17,false), (18,false), (76,false), (98,false), (31,false), (30,false), (88,false)]
theorem p983 (F : Frame G 3) : c983.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 1, 6, 9, 8, 2, 7, 10]) (by decide +kernel)
def c984 : CNF.Clause Nat := [(39,false), (38,false), (16,false), (22,false), (88,false), (8,false), (9,false), (31,false), (29,false), (76,false)]
theorem p984 (F : Frame G 3) : c984.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 4, 1, 10, 7, 0, 8, 2, 6, 9]) (by decide +kernel)
def c985 : CNF.Clause Nat := [(19,false), (88,false), (99,false), (75,false), (7,false), (10,false), (32,false), (26,false), (38,false), (50,false)]
theorem p985 (F : Frame G 3) : c985.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 10, 8, 6, 0, 9, 2, 3, 4, 5]) (by decide +kernel)
def c986 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (17,false), (19,false), (88,false), (99,false), (31,false), (29,false), (76,false)]
theorem p986 (F : Frame G 3) : c986.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 1, 7, 10, 8, 2, 6, 9]) (by decide +kernel)
def c987 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (16,false), (19,false), (88,false), (99,false), (31,false), (29,false), (76,false)]
theorem p987 (F : Frame G 3) : c987.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 1, 7, 10, 8, 2, 6, 9]) (by decide +kernel)
def c988 : CNF.Clause Nat := [(31,false), (75,false), (76,false), (10,false), (4,false), (38,false), (50,false), (17,false), (19,false), (88,false)]
theorem p988 (F : Frame G 3) : c988.eval F.assign = true := by
  exact Rule.sound F (.path [2, 8, 6, 9, 0, 3, 4, 5, 1, 7, 10]) (by decide +kernel)
def c989 : CNF.Clause Nat := [(19,false), (87,false), (98,false), (99,false), (77,false), (7,false), (5,false), (38,false), (26,false), (28,false)]
theorem p989 (F : Frame G 3) : c989.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 9, 8, 10, 6, 0, 4, 3, 2, 5]) (by decide +kernel)
def c990 : CNF.Clause Nat := [(7,false), (77,false), (99,false), (98,false), (21,false), (19,false), (30,false), (26,false), (38,false), (50,false)]
theorem p990 (F : Frame G 3) : c990.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 10, 8, 9, 1, 7, 2, 3, 4, 5]) (by decide +kernel)
def c991 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (7,false), (77,false), (99,false), (31,false), (30,false), (19,false), (21,false)]
theorem p991 (F : Frame G 3) : c991.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 4, 0, 6, 10, 8, 2, 7, 1, 9]) (by decide +kernel)
def c992 : CNF.Clause Nat := [(4,false), (5,false), (50,false), (28,false), (31,false), (86,false), (87,false), (21,false), (18,false), (77,false)]
theorem p992 (F : Frame G 3) : c992.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 4, 5, 2, 8, 7, 9, 1, 6, 10]) (by decide +kernel)
def c993 : CNF.Clause Nat := [(28,false), (39,false), (4,false), (5,false), (16,false), (18,false), (77,false), (99,false), (86,false), (87,false)]
theorem p993 (F : Frame G 3) : c993.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 0, 4, 1, 6, 10, 8, 7, 9]) (by decide +kernel)
def c994 : CNF.Clause Nat := [(26,false), (28,false), (50,false), (16,false), (18,false), (77,false), (99,false), (98,false), (10,false), (8,false)]
theorem p994 (F : Frame G 3) : c994.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 4, 1, 6, 10, 8, 9, 0, 7]) (by decide +kernel)
def c995 : CNF.Clause Nat := [(26,false), (28,false), (50,false), (5,false), (7,false), (77,false), (99,false), (98,false), (21,false), (19,false)]
theorem p995 (F : Frame G 3) : c995.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 4, 0, 6, 10, 8, 9, 1, 7]) (by decide +kernel)
def c996 : CNF.Clause Nat := [(26,false), (28,false), (50,false), (16,false), (19,false), (8,false), (7,false), (76,false), (98,false), (99,false)]
theorem p996 (F : Frame G 3) : c996.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 4, 1, 7, 0, 6, 9, 8, 10]) (by decide +kernel)
def c997 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (16,false), (19,false), (30,false), (31,false), (98,false), (76,false), (77,false)]
theorem p997 (F : Frame G 3) : c997.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 1, 7, 2, 8, 9, 6, 10]) (by decide +kernel)
def c998 : CNF.Clause Nat := [(16,false), (5,false), (4,false), (39,false), (28,false), (31,false), (99,false), (77,false), (74,false), (87,false)]
theorem p998 (F : Frame G 3) : c998.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 0, 3, 5, 2, 8, 10, 6, 7, 9]) (by decide +kernel)
def c999 : CNF.Clause Nat := [(27,false), (50,false), (39,false), (4,false), (11,false), (77,false), (74,false), (19,false), (20,false), (98,false)]
theorem p999 (F : Frame G 3) : c999.eval F.assign = true := by
  exact Rule.sound F (.path [2, 4, 5, 3, 0, 10, 6, 7, 1, 8, 9]) (by decide +kernel)
def c1000 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (4,false), (7,false), (77,false), (99,false), (31,false), (32,false), (87,false)]
theorem p1000 (F : Frame G 3) : c1000.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 0, 6, 10, 8, 2, 9, 7]) (by decide +kernel)
def c1001 : CNF.Clause Nat := [(4,false), (10,false), (87,false), (19,false), (16,false), (50,false), (28,false), (29,false), (77,false), (99,false)]
theorem p1001 (F : Frame G 3) : c1001.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 9, 7, 1, 4, 5, 2, 6, 10, 8]) (by decide +kernel)
def c1002 : CNF.Clause Nat := [(4,false), (7,false), (77,false), (99,false), (98,false), (87,false), (19,false), (16,false), (27,false), (28,false)]
theorem p1002 (F : Frame G 3) : c1002.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 10, 8, 9, 7, 1, 4, 2, 5]) (by decide +kernel)
def c1003 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (5,false), (10,false), (76,false), (18,false), (19,false), (86,false), (99,false)]
theorem p1003 (F : Frame G 3) : c1003.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 0, 9, 6, 1, 7, 8, 10]) (by decide +kernel)
def c1004 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (16,false), (18,false), (7,false), (10,false), (98,false), (86,false), (88,false)]
theorem p1004 (F : Frame G 3) : c1004.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 1, 6, 0, 9, 8, 7, 10]) (by decide +kernel)
def c1005 : CNF.Clause Nat := [(4,false), (5,false), (50,false), (17,false), (19,false), (87,false), (32,false), (29,false), (75,false), (99,false)]
theorem p1005 (F : Frame G 3) : c1005.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 4, 5, 1, 7, 9, 2, 6, 8, 10]) (by decide +kernel)
def c1006 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (17,false), (19,false), (87,false), (32,false), (29,false), (75,false), (99,false)]
theorem p1006 (F : Frame G 3) : c1006.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 1, 7, 9, 2, 6, 8, 10]) (by decide +kernel)
def c1007 : CNF.Clause Nat := [(19,false), (87,false), (98,false), (75,false), (7,false), (11,false), (33,false), (26,false), (38,false), (50,false)]
theorem p1007 (F : Frame G 3) : c1007.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 9, 8, 6, 0, 10, 2, 3, 4, 5]) (by decide +kernel)
def c1008 : CNF.Clause Nat := [(7,false), (74,false), (87,false), (98,false), (99,false), (33,false), (28,false), (39,false), (15,false), (16,false)]
theorem p1008 (F : Frame G 3) : c1008.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 7, 9, 8, 10, 2, 5, 3, 1, 4]) (by decide +kernel)
def c1009 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (4,false), (7,false), (74,false), (87,false), (32,false), (31,false), (99,false)]
theorem p1009 (F : Frame G 3) : c1009.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 0, 6, 7, 9, 2, 8, 10]) (by decide +kernel)
def c1010 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (19,false), (74,false), (7,false), (10,false), (98,false), (31,false), (33,false)]
theorem p1010 (F : Frame G 3) : c1010.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 1, 7, 6, 0, 9, 8, 2, 10]) (by decide +kernel)
def c1011 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (4,false), (7,false), (74,false), (87,false), (98,false), (31,false), (33,false)]
theorem p1011 (F : Frame G 3) : c1011.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 0, 6, 7, 9, 8, 2, 10]) (by decide +kernel)
def c1012 : CNF.Clause Nat := [(5,false), (4,false), (39,false), (17,false), (19,false), (87,false), (32,false), (29,false), (75,false), (99,false)]
theorem p1012 (F : Frame G 3) : c1012.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 3, 5, 1, 7, 9, 2, 6, 8, 10]) (by decide +kernel)
def c1013 : CNF.Clause Nat := [(7,false), (75,false), (99,false), (33,false), (27,false), (38,false), (39,false), (17,false), (19,false), (87,false)]
theorem p1013 (F : Frame G 3) : c1013.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 8, 10, 2, 4, 3, 5, 1, 7, 9]) (by decide +kernel)
def c1014 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (21,false), (87,false), (8,false), (7,false), (29,false), (31,false), (99,false)]
theorem p1014 (F : Frame G 3) : c1014.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 1, 9, 7, 0, 6, 2, 8, 10]) (by decide +kernel)
def c1015 : CNF.Clause Nat := [(16,false), (17,false), (39,false), (26,false), (33,false), (99,false), (98,false), (10,false), (7,false), (74,false)]
theorem p1015 (F : Frame G 3) : c1015.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 5, 3, 2, 10, 8, 9, 0, 6, 7]) (by decide +kernel)
def c1016 : CNF.Clause Nat := [(16,false), (17,false), (39,false), (4,false), (7,false), (74,false), (87,false), (32,false), (31,false), (99,false)]
theorem p1016 (F : Frame G 3) : c1016.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 5, 3, 0, 6, 7, 9, 2, 8, 10]) (by decide +kernel)
def c1017 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (18,false), (7,false), (8,false), (87,false), (32,false), (31,false), (99,false)]
theorem p1017 (F : Frame G 3) : c1017.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 1, 6, 0, 7, 9, 2, 8, 10]) (by decide +kernel)
def c1018 : CNF.Clause Nat := [(27,false), (38,false), (39,false), (17,false), (18,false), (74,false), (8,false), (10,false), (98,false), (99,false)]
theorem p1018 (F : Frame G 3) : c1018.eval F.assign = true := by
  exact Rule.sound F (.path [2, 4, 3, 5, 1, 6, 7, 0, 9, 8, 10]) (by decide +kernel)
def c1019 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (22,false), (11,false), (7,false), (29,false), (30,false), (87,false), (98,false)]
theorem p1019 (F : Frame G 3) : c1019.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 1, 10, 0, 6, 2, 7, 9, 8]) (by decide +kernel)
def c1020 : CNF.Clause Nat := [(26,false), (28,false), (50,false), (16,false), (22,false), (99,false), (98,false), (10,false), (7,false), (74,false)]
theorem p1020 (F : Frame G 3) : c1020.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 4, 1, 10, 8, 9, 0, 6, 7]) (by decide +kernel)
def c1021 : CNF.Clause Nat := [(4,false), (7,false), (74,false), (87,false), (98,false), (99,false), (22,false), (16,false), (27,false), (28,false)]
theorem p1021 (F : Frame G 3) : c1021.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 7, 9, 8, 10, 1, 4, 2, 5]) (by decide +kernel)
def c1022 : CNF.Clause Nat := [(4,false), (7,false), (74,false), (87,false), (21,false), (16,false), (50,false), (28,false), (31,false), (99,false)]
theorem p1022 (F : Frame G 3) : c1022.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 7, 9, 1, 4, 5, 2, 8, 10]) (by decide +kernel)
def c1023 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (28,false), (30,false), (87,false), (10,false), (7,false), (75,false), (99,false)]
theorem p1023 (F : Frame G 3) : c1023.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 2, 7, 9, 0, 6, 8, 10]) (by decide +kernel)
def c1024 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (28,false), (32,false), (87,false), (8,false), (7,false), (75,false), (99,false)]
theorem p1024 (F : Frame G 3) : c1024.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 2, 9, 7, 0, 6, 8, 10]) (by decide +kernel)
def c1025 : CNF.Clause Nat := [(38,false), (50,false), (28,false), (32,false), (10,false), (8,false), (19,false), (18,false), (75,false), (99,false)]
theorem p1025 (F : Frame G 3) : c1025.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 2, 9, 0, 7, 1, 6, 8, 10]) (by decide +kernel)
def c1026 : CNF.Clause Nat := [(16,false), (38,false), (26,false), (28,false), (6,false), (10,false), (87,false), (74,false), (75,false), (99,false)]
theorem p1026 (F : Frame G 3) : c1026.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 2, 5, 0, 9, 7, 6, 8, 10]) (by decide +kernel)
def c1027 : CNF.Clause Nat := [(16,false), (15,false), (39,false), (28,false), (33,false), (99,false), (75,false), (7,false), (8,false), (87,false)]
theorem p1027 (F : Frame G 3) : c1027.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 3, 5, 2, 10, 8, 6, 0, 7, 9]) (by decide +kernel)
def c1028 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (28,false), (29,false), (75,false), (99,false), (11,false), (8,false), (87,false)]
theorem p1028 (F : Frame G 3) : c1028.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 2, 6, 8, 10, 0, 7, 9]) (by decide +kernel)
def c1029 : CNF.Clause Nat := [(16,false), (15,false), (39,false), (6,false), (7,false), (75,false), (99,false), (33,false), (30,false), (87,false)]
theorem p1029 (F : Frame G 3) : c1029.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 3, 5, 0, 6, 8, 10, 2, 7, 9]) (by decide +kernel)
def c1030 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (6,false), (7,false), (75,false), (99,false), (33,false), (30,false), (87,false)]
theorem p1030 (F : Frame G 3) : c1030.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 0, 6, 8, 10, 2, 7, 9]) (by decide +kernel)
def c1031 : CNF.Clause Nat := [(16,false), (19,false), (87,false), (10,false), (4,false), (39,false), (28,false), (29,false), (75,false), (99,false)]
theorem p1031 (F : Frame G 3) : c1031.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 7, 9, 0, 3, 5, 2, 6, 8, 10]) (by decide +kernel)
def c1032 : CNF.Clause Nat := [(38,false), (39,false), (28,false), (33,false), (22,false), (18,false), (75,false), (9,false), (8,false), (87,false)]
theorem p1032 (F : Frame G 3) : c1032.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 2, 10, 1, 6, 8, 0, 7, 9]) (by decide +kernel)
def c1033 : CNF.Clause Nat := [(38,false), (39,false), (28,false), (33,false), (99,false), (75,false), (7,false), (8,false), (19,false), (21,false)]
theorem p1033 (F : Frame G 3) : c1033.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 2, 10, 8, 6, 0, 7, 1, 9]) (by decide +kernel)
def c1034 : CNF.Clause Nat := [(27,false), (38,false), (39,false), (6,false), (7,false), (75,false), (99,false), (22,false), (19,false), (87,false)]
theorem p1034 (F : Frame G 3) : c1034.eval F.assign = true := by
  exact Rule.sound F (.path [2, 4, 3, 5, 0, 6, 8, 10, 1, 7, 9]) (by decide +kernel)
def c1035 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (6,false), (7,false), (74,false), (87,false), (32,false), (31,false), (99,false)]
theorem p1035 (F : Frame G 3) : c1035.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 0, 6, 7, 9, 2, 8, 10]) (by decide +kernel)
def c1036 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (28,false), (29,false), (74,false), (8,false), (10,false), (98,false), (99,false)]
theorem p1036 (F : Frame G 3) : c1036.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 2, 6, 7, 0, 9, 8, 10]) (by decide +kernel)
def c1037 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (6,false), (7,false), (74,false), (87,false), (98,false), (31,false), (33,false)]
theorem p1037 (F : Frame G 3) : c1037.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 0, 6, 7, 9, 8, 2, 10]) (by decide +kernel)
def c1038 : CNF.Clause Nat := [(27,false), (28,false), (39,false), (4,false), (7,false), (77,false), (99,false), (86,false), (19,false), (21,false)]
theorem p1038 (F : Frame G 3) : c1038.eval F.assign = true := by
  exact Rule.sound F (.path [4, 2, 5, 3, 0, 6, 10, 8, 7, 1, 9]) (by decide +kernel)
def c1039 : CNF.Clause Nat := [(7,false), (29,false), (32,false), (98,false), (99,false), (88,false), (19,false), (15,false), (38,false), (50,false)]
theorem p1039 (F : Frame G 3) : c1039.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 2, 9, 8, 10, 7, 1, 3, 4, 5]) (by decide +kernel)
def c1040 : CNF.Clause Nat := [(7,false), (77,false), (88,false), (19,false), (16,false), (38,false), (39,false), (28,false), (31,false), (98,false)]
theorem p1040 (F : Frame G 3) : c1040.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 10, 7, 1, 4, 3, 5, 2, 8, 9]) (by decide +kernel)
def c1041 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (28,false), (29,false), (77,false), (11,false), (8,false), (86,false), (98,false)]
theorem p1041 (F : Frame G 3) : c1041.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 2, 6, 10, 0, 7, 8, 9]) (by decide +kernel)
def c1042 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (28,false), (32,false), (10,false), (8,false), (86,false), (75,false), (77,false)]
theorem p1042 (F : Frame G 3) : c1042.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 2, 9, 0, 7, 8, 6, 10]) (by decide +kernel)
def c1043 : CNF.Clause Nat := [(28,false), (39,false), (4,false), (5,false), (16,false), (19,false), (74,false), (76,false), (98,false), (99,false)]
theorem p1043 (F : Frame G 3) : c1043.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 0, 4, 1, 7, 6, 9, 8, 10]) (by decide +kernel)
def c1044 : CNF.Clause Nat := [(39,false), (50,false), (16,false), (19,false), (74,false), (77,false), (11,false), (9,false), (31,false), (32,false)]
theorem p1044 (F : Frame G 3) : c1044.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 1, 7, 6, 10, 0, 8, 2, 9]) (by decide +kernel)
def c1045 : CNF.Clause Nat := [(4,false), (8,false), (74,false), (77,false), (99,false), (98,false), (21,false), (16,false), (27,false), (28,false)]
theorem p1045 (F : Frame G 3) : c1045.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 7, 6, 10, 8, 9, 1, 4, 2, 5]) (by decide +kernel)
def c1046 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (27,false), (30,false), (74,false), (77,false), (22,false), (20,false), (98,false)]
theorem p1046 (F : Frame G 3) : c1046.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 2, 7, 6, 10, 1, 8, 9]) (by decide +kernel)
def c1047 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (16,false), (19,false), (30,false), (32,false), (98,false), (75,false), (77,false)]
theorem p1047 (F : Frame G 3) : c1047.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 1, 7, 2, 9, 8, 6, 10]) (by decide +kernel)
def c1048 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (31,false), (99,false), (11,false), (7,false), (18,false), (19,false), (87,false)]
theorem p1048 (F : Frame G 3) : c1048.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 2, 8, 10, 0, 6, 1, 7, 9]) (by decide +kernel)
def c1049 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (31,false), (20,false), (19,false), (87,false), (76,false), (7,false), (11,false)]
theorem p1049 (F : Frame G 3) : c1049.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 2, 8, 1, 7, 9, 6, 0, 10]) (by decide +kernel)
def c1050 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (6,false), (7,false), (74,false), (88,false), (99,false), (31,false), (32,false)]
theorem p1050 (F : Frame G 3) : c1050.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 0, 6, 7, 10, 8, 2, 9]) (by decide +kernel)
def c1051 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (7,false), (29,false), (32,false), (21,false), (19,false), (88,false), (99,false)]
theorem p1051 (F : Frame G 3) : c1051.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 4, 0, 6, 2, 9, 1, 7, 10, 8]) (by decide +kernel)
def c1052 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (4,false), (7,false), (74,false), (88,false), (99,false), (31,false), (32,false)]
theorem p1052 (F : Frame G 3) : c1052.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 0, 6, 7, 10, 8, 2, 9]) (by decide +kernel)
def c1053 : CNF.Clause Nat := [(7,false), (75,false), (98,false), (21,false), (16,false), (38,false), (39,false), (28,false), (30,false), (88,false)]
theorem p1053 (F : Frame G 3) : c1053.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 8, 9, 1, 4, 3, 5, 2, 7, 10]) (by decide +kernel)
def c1054 : CNF.Clause Nat := [(27,false), (38,false), (39,false), (17,false), (18,false), (7,false), (8,false), (87,false), (98,false), (99,false)]
theorem p1054 (F : Frame G 3) : c1054.eval F.assign = true := by
  exact Rule.sound F (.path [2, 4, 3, 5, 1, 6, 0, 7, 9, 8, 10]) (by decide +kernel)
def c1055 : CNF.Clause Nat := [(27,false), (38,false), (39,false), (6,false), (7,false), (18,false), (19,false), (87,false), (98,false), (99,false)]
theorem p1055 (F : Frame G 3) : c1055.eval F.assign = true := by
  exact Rule.sound F (.path [2, 4, 3, 5, 0, 6, 1, 7, 9, 8, 10]) (by decide +kernel)
def c1056 : CNF.Clause Nat := [(7,false), (75,false), (99,false), (88,false), (87,false), (32,false), (27,false), (16,false), (15,false), (39,false)]
theorem p1056 (F : Frame G 3) : c1056.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 8, 10, 7, 9, 2, 4, 1, 3, 5]) (by decide +kernel)
def c1057 : CNF.Clause Nat := [(38,false), (39,false), (28,false), (31,false), (99,false), (11,false), (10,false), (21,false), (18,false), (74,false)]
theorem p1057 (F : Frame G 3) : c1057.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 2, 8, 10, 0, 9, 1, 6, 7]) (by decide +kernel)
def c1058 : CNF.Clause Nat := [(16,false), (19,false), (74,false), (76,false), (10,false), (4,false), (39,false), (28,false), (31,false), (99,false)]
theorem p1058 (F : Frame G 3) : c1058.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 7, 6, 9, 0, 3, 5, 2, 8, 10]) (by decide +kernel)
def c1059 : CNF.Clause Nat := [(28,false), (26,false), (38,false), (16,false), (19,false), (88,false), (99,false), (75,false), (7,false), (10,false)]
theorem p1059 (F : Frame G 3) : c1059.eval F.assign = true := by
  exact Rule.sound F (.path [5, 2, 3, 4, 1, 7, 10, 8, 6, 0, 9]) (by decide +kernel)
def c1060 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (16,false), (19,false), (88,false), (99,false), (75,false), (7,false), (10,false)]
theorem p1060 (F : Frame G 3) : c1060.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 1, 7, 10, 8, 6, 0, 9]) (by decide +kernel)
def c1061 : CNF.Clause Nat := [(38,false), (50,false), (28,false), (31,false), (9,false), (7,false), (76,false), (21,false), (19,false), (88,false)]
theorem p1061 (F : Frame G 3) : c1061.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 2, 8, 0, 6, 9, 1, 7, 10]) (by decide +kernel)
def c1062 : CNF.Clause Nat := [(19,false), (74,false), (77,false), (99,false), (98,false), (10,false), (4,false), (26,false), (27,false), (50,false)]
theorem p1062 (F : Frame G 3) : c1062.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 6, 10, 8, 9, 0, 3, 2, 4, 5]) (by decide +kernel)
def c1063 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (28,false), (31,false), (98,false), (21,false), (19,false), (74,false), (77,false)]
theorem p1063 (F : Frame G 3) : c1063.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 2, 8, 9, 1, 7, 6, 10]) (by decide +kernel)
def c1064 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (17,false), (19,false), (30,false), (31,false), (98,false), (76,false), (77,false)]
theorem p1064 (F : Frame G 3) : c1064.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 1, 7, 2, 8, 9, 6, 10]) (by decide +kernel)
def c1065 : CNF.Clause Nat := [(16,false), (38,false), (4,false), (6,false), (28,false), (29,false), (74,false), (87,false), (98,false), (99,false)]
theorem p1065 (F : Frame G 3) : c1065.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 0, 5, 2, 6, 7, 9, 8, 10]) (by decide +kernel)
def c1066 : CNF.Clause Nat := [(38,false), (50,false), (28,false), (30,false), (19,false), (18,false), (7,false), (10,false), (98,false), (99,false)]
theorem p1066 (F : Frame G 3) : c1066.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 2, 7, 1, 6, 0, 9, 8, 10]) (by decide +kernel)
def c1067 : CNF.Clause Nat := [(4,false), (6,false), (50,false), (27,false), (30,false), (88,false), (99,false), (98,false), (21,false), (18,false)]
theorem p1067 (F : Frame G 3) : c1067.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 5, 4, 2, 7, 10, 8, 9, 1, 6]) (by decide +kernel)
def c1068 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (7,false), (18,false), (19,false), (88,false), (99,false), (31,false), (32,false)]
theorem p1068 (F : Frame G 3) : c1068.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 0, 6, 1, 7, 10, 8, 2, 9]) (by decide +kernel)
def c1069 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (19,false), (8,false), (7,false), (77,false), (99,false), (31,false), (32,false)]
theorem p1069 (F : Frame G 3) : c1069.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 1, 7, 0, 6, 10, 8, 2, 9]) (by decide +kernel)
def c1070 : CNF.Clause Nat := [(38,false), (50,false), (28,false), (29,false), (7,false), (8,false), (88,false), (99,false), (20,false), (21,false)]
theorem p1070 (F : Frame G 3) : c1070.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 2, 6, 0, 7, 10, 8, 1, 9]) (by decide +kernel)
def c1071 : CNF.Clause Nat := [(16,false), (38,false), (4,false), (6,false), (28,false), (32,false), (87,false), (74,false), (75,false), (99,false)]
theorem p1071 (F : Frame G 3) : c1071.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 0, 5, 2, 9, 7, 6, 8, 10]) (by decide +kernel)
def c1072 : CNF.Clause Nat := [(16,false), (38,false), (4,false), (6,false), (28,false), (29,false), (75,false), (98,false), (87,false), (88,false)]
theorem p1072 (F : Frame G 3) : c1072.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 0, 5, 2, 6, 8, 9, 7, 10]) (by decide +kernel)
def c1073 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (6,false), (7,false), (76,false), (32,false), (30,false), (88,false), (99,false)]
theorem p1073 (F : Frame G 3) : c1073.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 0, 6, 9, 2, 7, 10, 8]) (by decide +kernel)
def c1074 : CNF.Clause Nat := [(28,false), (50,false), (16,false), (15,false), (4,false), (10,false), (76,false), (75,false), (86,false), (88,false)]
theorem p1074 (F : Frame G 3) : c1074.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 1, 3, 0, 9, 6, 8, 7, 10]) (by decide +kernel)
def c1075 : CNF.Clause Nat := [(28,false), (17,false), (15,false), (38,false), (5,false), (8,false), (86,false), (98,false), (76,false), (77,false)]
theorem p1075 (F : Frame G 3) : c1075.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 1, 3, 4, 0, 7, 8, 9, 6, 10]) (by decide +kernel)
def c1076 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (28,false), (29,false), (76,false), (10,false), (8,false), (86,false), (99,false)]
theorem p1076 (F : Frame G 3) : c1076.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 2, 6, 9, 0, 7, 8, 10]) (by decide +kernel)
def c1077 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (15,false), (19,false), (86,false), (98,false), (10,false), (7,false), (77,false)]
theorem p1077 (F : Frame G 3) : c1077.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 1, 7, 8, 9, 0, 6, 10]) (by decide +kernel)
def c1078 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (27,false), (29,false), (75,false), (98,false), (21,false), (19,false), (88,false)]
theorem p1078 (F : Frame G 3) : c1078.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 2, 6, 8, 9, 1, 7, 10]) (by decide +kernel)
def c1079 : CNF.Clause Nat := [(28,false), (39,false), (4,false), (5,false), (16,false), (18,false), (75,false), (98,false), (87,false), (88,false)]
theorem p1079 (F : Frame G 3) : c1079.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 0, 4, 1, 6, 8, 9, 7, 10]) (by decide +kernel)
def c1080 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (4,false), (7,false), (29,false), (32,false), (87,false), (86,false), (99,false)]
theorem p1080 (F : Frame G 3) : c1080.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 0, 6, 2, 9, 7, 8, 10]) (by decide +kernel)
def c1081 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (4,false), (7,false), (29,false), (32,false), (98,false), (86,false), (88,false)]
theorem p1081 (F : Frame G 3) : c1081.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 0, 6, 2, 9, 8, 7, 10]) (by decide +kernel)
def c1082 : CNF.Clause Nat := [(27,false), (50,false), (39,false), (15,false), (19,false), (86,false), (98,false), (10,false), (7,false), (77,false)]
theorem p1082 (F : Frame G 3) : c1082.eval F.assign = true := by
  exact Rule.sound F (.path [2, 4, 5, 3, 1, 7, 8, 9, 0, 6, 10]) (by decide +kernel)
def c1083 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (4,false), (10,false), (87,false), (74,false), (18,false), (22,false), (99,false)]
theorem p1083 (F : Frame G 3) : c1083.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 0, 9, 7, 6, 1, 10, 8]) (by decide +kernel)
def c1084 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (18,false), (7,false), (10,false), (32,false), (31,false), (86,false), (88,false)]
theorem p1084 (F : Frame G 3) : c1084.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 1, 6, 0, 9, 2, 8, 7, 10]) (by decide +kernel)
def c1085 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (20,false), (31,false), (29,false), (7,false), (10,false), (87,false), (88,false)]
theorem p1085 (F : Frame G 3) : c1085.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 1, 8, 2, 6, 0, 9, 7, 10]) (by decide +kernel)
def c1086 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (7,false), (29,false), (32,false), (87,false), (19,false), (20,false), (99,false)]
theorem p1086 (F : Frame G 3) : c1086.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 0, 6, 2, 9, 7, 1, 8, 10]) (by decide +kernel)
def c1087 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (6,false), (7,false), (29,false), (32,false), (87,false), (86,false), (99,false)]
theorem p1087 (F : Frame G 3) : c1087.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 0, 6, 2, 9, 7, 8, 10]) (by decide +kernel)
def c1088 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (28,false), (29,false), (7,false), (10,false), (87,false), (86,false), (99,false)]
theorem p1088 (F : Frame G 3) : c1088.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 2, 6, 0, 9, 7, 8, 10]) (by decide +kernel)
def c1089 : CNF.Clause Nat := [(19,false), (88,false), (99,false), (31,false), (26,false), (38,false), (50,false), (6,false), (7,false), (76,false)]
theorem p1089 (F : Frame G 3) : c1089.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 10, 8, 2, 3, 4, 5, 0, 6, 9]) (by decide +kernel)
def c1090 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (10,false), (76,false), (29,false), (31,false), (20,false), (19,false), (88,false)]
theorem p1090 (F : Frame G 3) : c1090.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 0, 9, 6, 2, 8, 1, 7, 10]) (by decide +kernel)
def c1091 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (15,false), (19,false), (88,false), (99,false), (75,false), (7,false), (10,false)]
theorem p1091 (F : Frame G 3) : c1091.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 1, 7, 10, 8, 6, 0, 9]) (by decide +kernel)
def c1092 : CNF.Clause Nat := [(4,false), (6,false), (50,false), (16,false), (19,false), (74,false), (76,false), (32,false), (31,false), (99,false)]
theorem p1092 (F : Frame G 3) : c1092.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 5, 4, 1, 7, 6, 9, 2, 8, 10]) (by decide +kernel)
def c1093 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (19,false), (30,false), (31,false), (99,false), (11,false), (7,false), (76,false)]
theorem p1093 (F : Frame G 3) : c1093.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 1, 7, 2, 8, 10, 0, 6, 9]) (by decide +kernel)
def c1094 : CNF.Clause Nat := [(4,false), (9,false), (99,false), (77,false), (76,false), (32,false), (30,false), (19,false), (16,false), (50,false)]
theorem p1094 (F : Frame G 3) : c1094.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 8, 10, 6, 9, 2, 7, 1, 4, 5]) (by decide +kernel)
def c1095 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (28,false), (30,false), (88,false), (99,false), (20,false), (18,false), (76,false)]
theorem p1095 (F : Frame G 3) : c1095.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 2, 7, 10, 8, 1, 6, 9]) (by decide +kernel)
def c1096 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (15,false), (22,false), (99,false), (86,false), (74,false), (7,false), (10,false)]
theorem p1096 (F : Frame G 3) : c1096.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 1, 10, 8, 7, 6, 0, 9]) (by decide +kernel)
def c1097 : CNF.Clause Nat := [(16,false), (38,false), (26,false), (28,false), (6,false), (10,false), (87,false), (74,false), (77,false), (99,false)]
theorem p1097 (F : Frame G 3) : c1097.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 2, 5, 0, 9, 7, 6, 10, 8]) (by decide +kernel)
def c1098 : CNF.Clause Nat := [(38,false), (50,false), (28,false), (31,false), (9,false), (7,false), (77,false), (88,false), (19,false), (21,false)]
theorem p1098 (F : Frame G 3) : c1098.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 2, 8, 0, 6, 10, 7, 1, 9]) (by decide +kernel)
def c1099 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (28,false), (30,false), (88,false), (99,false), (9,false), (7,false), (76,false)]
theorem p1099 (F : Frame G 3) : c1099.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 2, 7, 10, 8, 0, 6, 9]) (by decide +kernel)
def c1100 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (10,false), (76,false), (18,false), (19,false), (30,false), (31,false), (99,false)]
theorem p1100 (F : Frame G 3) : c1100.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 0, 9, 6, 1, 7, 2, 8, 10]) (by decide +kernel)
def c1101 : CNF.Clause Nat := [(26,false), (39,false), (50,false), (5,false), (7,false), (77,false), (99,false), (20,false), (19,false), (87,false)]
theorem p1101 (F : Frame G 3) : c1101.eval F.assign = true := by
  exact Rule.sound F (.path [2, 3, 5, 4, 0, 6, 10, 8, 1, 7, 9]) (by decide +kernel)
def c1102 : CNF.Clause Nat := [(26,false), (28,false), (50,false), (16,false), (18,false), (76,false), (10,false), (8,false), (86,false), (99,false)]
theorem p1102 (F : Frame G 3) : c1102.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 4, 1, 6, 9, 0, 7, 8, 10]) (by decide +kernel)
def c1103 : CNF.Clause Nat := [(26,false), (28,false), (50,false), (5,false), (7,false), (18,false), (21,false), (87,false), (86,false), (99,false)]
theorem p1103 (F : Frame G 3) : c1103.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 4, 0, 6, 1, 9, 7, 8, 10]) (by decide +kernel)
def c1104 : CNF.Clause Nat := [(31,false), (99,false), (88,false), (87,false), (76,false), (18,false), (15,false), (4,false), (5,false), (50,false)]
theorem p1104 (F : Frame G 3) : c1104.eval F.assign = true := by
  exact Rule.sound F (.path [2, 8, 10, 7, 9, 6, 1, 3, 0, 4, 5]) (by decide +kernel)
def c1105 : CNF.Clause Nat := [(31,false), (99,false), (77,false), (76,false), (87,false), (19,false), (15,false), (4,false), (5,false), (50,false)]
theorem p1105 (F : Frame G 3) : c1105.eval F.assign = true := by
  exact Rule.sound F (.path [2, 8, 10, 6, 9, 7, 1, 3, 0, 4, 5]) (by decide +kernel)
def c1106 : CNF.Clause Nat := [(4,false), (6,false), (50,false), (27,false), (31,false), (20,false), (19,false), (87,false), (76,false), (77,false)]
theorem p1106 (F : Frame G 3) : c1106.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 5, 4, 2, 8, 1, 7, 9, 6, 10]) (by decide +kernel)
def c1107 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (27,false), (31,false), (20,false), (19,false), (87,false), (76,false), (77,false)]
theorem p1107 (F : Frame G 3) : c1107.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 2, 8, 1, 7, 9, 6, 10]) (by decide +kernel)
def c1108 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (18,false), (7,false), (10,false), (98,false), (86,false), (30,false), (33,false)]
theorem p1108 (F : Frame G 3) : c1108.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 1, 6, 0, 9, 8, 7, 2, 10]) (by decide +kernel)
def c1109 : CNF.Clause Nat := [(11,false), (99,false), (98,false), (76,false), (74,false), (19,false), (16,false), (27,false), (26,false), (39,false)]
theorem p1109 (F : Frame G 3) : c1109.eval F.assign = true := by
  exact Rule.sound F (.path [0, 10, 8, 9, 6, 7, 1, 4, 2, 3, 5]) (by decide +kernel)
def c1110 : CNF.Clause Nat := [(11,false), (99,false), (98,false), (76,false), (74,false), (30,false), (27,false), (16,false), (15,false), (39,false)]
theorem p1110 (F : Frame G 3) : c1110.eval F.assign = true := by
  exact Rule.sound F (.path [0, 10, 8, 9, 6, 7, 2, 4, 1, 3, 5]) (by decide +kernel)
def c1111 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (7,false), (18,false), (19,false), (30,false), (32,false), (98,false), (99,false)]
theorem p1111 (F : Frame G 3) : c1111.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 4, 0, 6, 1, 7, 2, 9, 8, 10]) (by decide +kernel)
def c1112 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (7,false), (74,false), (19,false), (21,false), (32,false), (31,false), (99,false)]
theorem p1112 (F : Frame G 3) : c1112.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 4, 0, 6, 7, 1, 9, 2, 8, 10]) (by decide +kernel)
def c1113 : CNF.Clause Nat := [(21,false), (98,false), (86,false), (74,false), (7,false), (11,false), (33,false), (27,false), (38,false), (39,false)]
theorem p1113 (F : Frame G 3) : c1113.eval F.assign = true := by
  exact Rule.sound F (.path [1, 9, 8, 7, 6, 0, 10, 2, 4, 3, 5]) (by decide +kernel)
def c1114 : CNF.Clause Nat := [(7,false), (74,false), (19,false), (16,false), (38,false), (39,false), (28,false), (32,false), (98,false), (99,false)]
theorem p1114 (F : Frame G 3) : c1114.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 7, 1, 4, 3, 5, 2, 9, 8, 10]) (by decide +kernel)
def c1115 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (6,false), (7,false), (76,false), (32,false), (30,false), (86,false), (99,false)]
theorem p1115 (F : Frame G 3) : c1115.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 0, 6, 9, 2, 7, 8, 10]) (by decide +kernel)
def c1116 : CNF.Clause Nat := [(19,false), (86,false), (99,false), (11,false), (4,false), (38,false), (50,false), (28,false), (29,false), (76,false)]
theorem p1116 (F : Frame G 3) : c1116.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 8, 10, 0, 3, 4, 5, 2, 6, 9]) (by decide +kernel)
def c1117 : CNF.Clause Nat := [(39,false), (38,false), (16,false), (19,false), (30,false), (29,false), (7,false), (10,false), (98,false), (99,false)]
theorem p1117 (F : Frame G 3) : c1117.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 4, 1, 7, 2, 6, 0, 9, 8, 10]) (by decide +kernel)
def c1118 : CNF.Clause Nat := [(5,false), (4,false), (39,false), (17,false), (19,false), (30,false), (33,false), (99,false), (75,false), (76,false)]
theorem p1118 (F : Frame G 3) : c1118.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 3, 5, 1, 7, 2, 10, 8, 6, 9]) (by decide +kernel)
def c1119 : CNF.Clause Nat := [(11,false), (22,false), (16,false), (38,false), (39,false), (28,false), (30,false), (86,false), (75,false), (76,false)]
theorem p1119 (F : Frame G 3) : c1119.eval F.assign = true := by
  exact Rule.sound F (.path [0, 10, 1, 4, 3, 5, 2, 7, 8, 6, 9]) (by decide +kernel)
def c1120 : CNF.Clause Nat := [(11,false), (33,false), (27,false), (38,false), (39,false), (17,false), (19,false), (86,false), (75,false), (76,false)]
theorem p1120 (F : Frame G 3) : c1120.eval F.assign = true := by
  exact Rule.sound F (.path [0, 10, 2, 4, 3, 5, 1, 7, 8, 6, 9]) (by decide +kernel)
def c1121 : CNF.Clause Nat := [(4,false), (6,false), (50,false), (16,false), (19,false), (74,false), (76,false), (98,false), (31,false), (33,false)]
theorem p1121 (F : Frame G 3) : c1121.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 5, 4, 1, 7, 6, 9, 8, 2, 10]) (by decide +kernel)
def c1122 : CNF.Clause Nat := [(4,false), (6,false), (50,false), (16,false), (19,false), (86,false), (98,false), (32,false), (29,false), (77,false)]
theorem p1122 (F : Frame G 3) : c1122.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 5, 4, 1, 7, 8, 9, 2, 6, 10]) (by decide +kernel)
def c1123 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (7,false), (18,false), (19,false), (86,false), (98,false), (32,false), (33,false)]
theorem p1123 (F : Frame G 3) : c1123.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 0, 6, 1, 7, 8, 9, 2, 10]) (by decide +kernel)
def c1124 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (4,false), (7,false), (77,false), (22,false), (19,false), (86,false), (98,false)]
theorem p1124 (F : Frame G 3) : c1124.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 0, 6, 10, 1, 7, 8, 9]) (by decide +kernel)
def c1125 : CNF.Clause Nat := [(6,false), (39,false), (38,false), (16,false), (19,false), (30,false), (31,false), (98,false), (76,false), (77,false)]
theorem p1125 (F : Frame G 3) : c1125.eval F.assign = true := by
  exact Rule.sound F (.path [0, 5, 3, 4, 1, 7, 2, 8, 9, 6, 10]) (by decide +kernel)
def c1126 : CNF.Clause Nat := [(10,false), (76,false), (77,false), (33,false), (31,false), (86,false), (19,false), (15,false), (38,false), (50,false)]
theorem p1126 (F : Frame G 3) : c1126.eval F.assign = true := by
  exact Rule.sound F (.path [0, 9, 6, 10, 2, 8, 7, 1, 3, 4, 5]) (by decide +kernel)
def c1127 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (6,false), (7,false), (77,false), (33,false), (30,false), (86,false), (98,false)]
theorem p1127 (F : Frame G 3) : c1127.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 0, 6, 10, 2, 7, 8, 9]) (by decide +kernel)
def c1128 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (28,false), (32,false), (98,false), (9,false), (7,false), (77,false), (88,false)]
theorem p1128 (F : Frame G 3) : c1128.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 2, 9, 8, 0, 6, 10, 7]) (by decide +kernel)
def c1129 : CNF.Clause Nat := [(39,false), (50,false), (16,false), (18,false), (7,false), (10,false), (32,false), (30,false), (88,false), (99,false)]
theorem p1129 (F : Frame G 3) : c1129.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 1, 6, 0, 9, 2, 7, 10, 8]) (by decide +kernel)
def c1130 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (32,false), (98,false), (75,false), (7,false), (8,false), (19,false), (22,false)]
theorem p1130 (F : Frame G 3) : c1130.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 2, 9, 8, 6, 0, 7, 1, 10]) (by decide +kernel)
def c1131 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (26,false), (32,false), (98,false), (75,false), (7,false), (8,false), (88,false)]
theorem p1131 (F : Frame G 3) : c1131.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 2, 9, 8, 6, 0, 7, 10]) (by decide +kernel)
def c1132 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (28,false), (32,false), (98,false), (75,false), (7,false), (8,false), (88,false)]
theorem p1132 (F : Frame G 3) : c1132.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 2, 9, 8, 6, 0, 7, 10]) (by decide +kernel)
def c1133 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (4,false), (7,false), (29,false), (30,false), (87,false), (98,false), (99,false)]
theorem p1133 (F : Frame G 3) : c1133.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 0, 6, 2, 7, 9, 8, 10]) (by decide +kernel)
def c1134 : CNF.Clause Nat := [(39,false), (4,false), (5,false), (16,false), (21,false), (87,false), (88,false), (33,false), (29,false), (75,false)]
theorem p1134 (F : Frame G 3) : c1134.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 0, 4, 1, 9, 7, 10, 2, 6, 8]) (by decide +kernel)
def c1135 : CNF.Clause Nat := [(4,false), (5,false), (50,false), (17,false), (19,false), (88,false), (77,false), (29,false), (31,false), (98,false)]
theorem p1135 (F : Frame G 3) : c1135.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 4, 5, 1, 7, 10, 6, 2, 8, 9]) (by decide +kernel)
def c1136 : CNF.Clause Nat := [(39,false), (50,false), (16,false), (19,false), (8,false), (7,false), (77,false), (99,false), (31,false), (32,false)]
theorem p1136 (F : Frame G 3) : c1136.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 1, 7, 0, 6, 10, 8, 2, 9]) (by decide +kernel)
def c1137 : CNF.Clause Nat := [(39,false), (38,false), (16,false), (19,false), (30,false), (31,false), (99,false), (11,false), (7,false), (76,false)]
theorem p1137 (F : Frame G 3) : c1137.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 4, 1, 7, 2, 8, 10, 0, 6, 9]) (by decide +kernel)
def c1138 : CNF.Clause Nat := [(7,false), (76,false), (32,false), (28,false), (39,false), (38,false), (16,false), (19,false), (88,false), (99,false)]
theorem p1138 (F : Frame G 3) : c1138.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 9, 2, 5, 3, 4, 1, 7, 10, 8]) (by decide +kernel)
def c1139 : CNF.Clause Nat := [(26,false), (39,false), (50,false), (5,false), (8,false), (88,false), (99,false), (20,false), (18,false), (76,false)]
theorem p1139 (F : Frame G 3) : c1139.eval F.assign = true := by
  exact Rule.sound F (.path [2, 3, 5, 4, 0, 7, 10, 8, 1, 6, 9]) (by decide +kernel)
def c1140 : CNF.Clause Nat := [(26,false), (28,false), (50,false), (5,false), (10,false), (76,false), (18,false), (19,false), (88,false), (99,false)]
theorem p1140 (F : Frame G 3) : c1140.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 4, 0, 9, 6, 1, 7, 10, 8]) (by decide +kernel)
def c1141 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (7,false), (76,false), (21,false), (19,false), (30,false), (31,false), (99,false)]
theorem p1141 (F : Frame G 3) : c1141.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 0, 6, 9, 1, 7, 2, 8, 10]) (by decide +kernel)
def c1142 : CNF.Clause Nat := [(4,false), (10,false), (76,false), (77,false), (88,false), (19,false), (20,false), (31,false), (27,false), (50,false)]
theorem p1142 (F : Frame G 3) : c1142.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 9, 6, 10, 7, 1, 8, 2, 4, 5]) (by decide +kernel)
def c1143 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (27,false), (31,false), (99,false), (88,false), (19,false), (18,false), (76,false)]
theorem p1143 (F : Frame G 3) : c1143.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 2, 8, 10, 7, 1, 6, 9]) (by decide +kernel)
def c1144 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (26,false), (31,false), (75,false), (76,false), (10,false), (8,false), (88,false)]
theorem p1144 (F : Frame G 3) : c1144.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 2, 8, 6, 9, 0, 7, 10]) (by decide +kernel)
def c1145 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (4,false), (10,false), (32,false), (30,false), (88,false), (77,false), (75,false)]
theorem p1145 (F : Frame G 3) : c1145.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 0, 9, 2, 7, 10, 6, 8]) (by decide +kernel)
def c1146 : CNF.Clause Nat := [(39,false), (50,false), (16,false), (18,false), (7,false), (11,false), (99,false), (86,false), (30,false), (32,false)]
theorem p1146 (F : Frame G 3) : c1146.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 1, 6, 0, 10, 8, 7, 2, 9]) (by decide +kernel)
def c1147 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (16,false), (19,false), (30,false), (33,false), (99,false), (75,false), (76,false)]
theorem p1147 (F : Frame G 3) : c1147.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 1, 7, 2, 10, 8, 6, 9]) (by decide +kernel)
def c1148 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (28,false), (33,false), (11,false), (8,false), (86,false), (75,false), (76,false)]
theorem p1148 (F : Frame G 3) : c1148.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 2, 10, 0, 7, 8, 6, 9]) (by decide +kernel)
def c1149 : CNF.Clause Nat := [(39,false), (50,false), (16,false), (19,false), (8,false), (7,false), (76,false), (32,false), (31,false), (99,false)]
theorem p1149 (F : Frame G 3) : c1149.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 1, 7, 0, 6, 9, 2, 8, 10]) (by decide +kernel)
def c1150 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (7,false), (18,false), (19,false), (30,false), (32,false), (98,false), (99,false)]
theorem p1150 (F : Frame G 3) : c1150.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 0, 6, 1, 7, 2, 9, 8, 10]) (by decide +kernel)
def c1151 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (27,false), (30,false), (19,false), (22,false), (99,false), (75,false), (76,false)]
theorem p1151 (F : Frame G 3) : c1151.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 2, 7, 1, 10, 8, 6, 9]) (by decide +kernel)
def c1152 : CNF.Clause Nat := [(4,false), (7,false), (76,false), (98,false), (99,false), (22,false), (19,false), (30,false), (27,false), (50,false)]
theorem p1152 (F : Frame G 3) : c1152.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 9, 8, 10, 1, 7, 2, 4, 5]) (by decide +kernel)
def c1153 : CNF.Clause Nat := [(39,false), (50,false), (16,false), (19,false), (30,false), (29,false), (7,false), (10,false), (98,false), (99,false)]
theorem p1153 (F : Frame G 3) : c1153.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 1, 7, 2, 6, 0, 9, 8, 10]) (by decide +kernel)
def c1154 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (16,false), (19,false), (86,false), (99,false), (33,false), (29,false), (76,false)]
theorem p1154 (F : Frame G 3) : c1154.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 1, 7, 8, 10, 2, 6, 9]) (by decide +kernel)
def c1155 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (7,false), (29,false), (30,false), (19,false), (21,false), (98,false), (99,false)]
theorem p1155 (F : Frame G 3) : c1155.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 0, 6, 2, 7, 1, 9, 8, 10]) (by decide +kernel)
def c1156 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (7,false), (29,false), (32,false), (21,false), (19,false), (86,false), (99,false)]
theorem p1156 (F : Frame G 3) : c1156.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 0, 6, 2, 9, 1, 7, 8, 10]) (by decide +kernel)
def c1157 : CNF.Clause Nat := [(39,false), (50,false), (16,false), (19,false), (8,false), (10,false), (98,false), (75,false), (29,false), (33,false)]
theorem p1157 (F : Frame G 3) : c1157.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 1, 7, 0, 9, 8, 6, 2, 10]) (by decide +kernel)
def c1158 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (7,false), (18,false), (19,false), (87,false), (32,false), (31,false), (99,false)]
theorem p1158 (F : Frame G 3) : c1158.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 0, 6, 1, 7, 9, 2, 8, 10]) (by decide +kernel)
def c1159 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (4,false), (7,false), (29,false), (33,false), (99,false), (86,false), (87,false)]
theorem p1159 (F : Frame G 3) : c1159.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 0, 6, 2, 10, 8, 7, 9]) (by decide +kernel)
def c1160 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (29,false), (7,false), (11,false), (22,false), (19,false), (86,false), (98,false)]
theorem p1160 (F : Frame G 3) : c1160.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 2, 6, 0, 10, 1, 7, 8, 9]) (by decide +kernel)
def c1161 : CNF.Clause Nat := [(4,false), (5,false), (50,false), (17,false), (18,false), (75,false), (98,false), (87,false), (30,false), (33,false)]
theorem p1161 (F : Frame G 3) : c1161.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 4, 5, 1, 6, 8, 9, 7, 2, 10]) (by decide +kernel)
def c1162 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (16,false), (19,false), (8,false), (10,false), (98,false), (75,false), (77,false)]
theorem p1162 (F : Frame G 3) : c1162.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 1, 7, 0, 9, 8, 6, 10]) (by decide +kernel)
def c1163 : CNF.Clause Nat := [(38,false), (39,false), (28,false), (31,false), (98,false), (10,false), (8,false), (19,false), (18,false), (77,false)]
theorem p1163 (F : Frame G 3) : c1163.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 2, 8, 9, 0, 7, 1, 6, 10]) (by decide +kernel)
def c1164 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (10,false), (21,false), (18,false), (74,false), (86,false), (31,false), (33,false)]
theorem p1164 (F : Frame G 3) : c1164.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 0, 9, 1, 6, 7, 8, 2, 10]) (by decide +kernel)
def c1165 : CNF.Clause Nat := [(4,false), (10,false), (98,false), (99,false), (33,false), (29,false), (74,false), (19,false), (16,false), (50,false)]
theorem p1165 (F : Frame G 3) : c1165.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 9, 8, 10, 2, 6, 7, 1, 4, 5]) (by decide +kernel)
def c1166 : CNF.Clause Nat := [(4,false), (7,false), (74,false), (19,false), (16,false), (50,false), (28,false), (32,false), (98,false), (99,false)]
theorem p1166 (F : Frame G 3) : c1166.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 7, 1, 4, 5, 2, 9, 8, 10]) (by decide +kernel)
def c1167 : CNF.Clause Nat := [(39,false), (50,false), (16,false), (21,false), (10,false), (7,false), (74,false), (30,false), (31,false), (99,false)]
theorem p1167 (F : Frame G 3) : c1167.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 1, 9, 0, 6, 7, 2, 8, 10]) (by decide +kernel)
def c1168 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (33,false), (99,false), (98,false), (10,false), (7,false), (18,false), (19,false)]
theorem p1168 (F : Frame G 3) : c1168.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 2, 10, 8, 9, 0, 6, 1, 7]) (by decide +kernel)
def c1169 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (28,false), (33,false), (11,false), (10,false), (98,false), (75,false), (74,false)]
theorem p1169 (F : Frame G 3) : c1169.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 2, 10, 0, 9, 8, 6, 7]) (by decide +kernel)
def c1170 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (26,false), (33,false), (11,false), (10,false), (98,false), (75,false), (74,false)]
theorem p1170 (F : Frame G 3) : c1170.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 2, 10, 0, 9, 8, 6, 7]) (by decide +kernel)
def c1171 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (28,false), (29,false), (76,false), (10,false), (8,false), (86,false), (99,false)]
theorem p1171 (F : Frame G 3) : c1171.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 2, 6, 9, 0, 7, 8, 10]) (by decide +kernel)
def c1172 : CNF.Clause Nat := [(16,false), (15,false), (39,false), (28,false), (33,false), (99,false), (86,false), (8,false), (7,false), (76,false)]
theorem p1172 (F : Frame G 3) : c1172.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 3, 5, 2, 10, 8, 7, 0, 6, 9]) (by decide +kernel)
def c1173 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (28,false), (33,false), (99,false), (86,false), (8,false), (7,false), (76,false)]
theorem p1173 (F : Frame G 3) : c1173.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 2, 10, 8, 7, 0, 6, 9]) (by decide +kernel)
def c1174 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (7,false), (29,false), (32,false), (21,false), (19,false), (86,false), (99,false)]
theorem p1174 (F : Frame G 3) : c1174.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 0, 6, 2, 9, 1, 7, 8, 10]) (by decide +kernel)
def c1175 : CNF.Clause Nat := [(27,false), (28,false), (39,false), (4,false), (8,false), (19,false), (22,false), (99,false), (75,false), (76,false)]
theorem p1175 (F : Frame G 3) : c1175.eval F.assign = true := by
  exact Rule.sound F (.path [4, 2, 5, 3, 0, 7, 1, 10, 8, 6, 9]) (by decide +kernel)
def c1176 : CNF.Clause Nat := [(27,false), (38,false), (39,false), (6,false), (8,false), (74,false), (18,false), (21,false), (98,false), (99,false)]
theorem p1176 (F : Frame G 3) : c1176.eval F.assign = true := by
  exact Rule.sound F (.path [2, 4, 3, 5, 0, 7, 6, 1, 9, 8, 10]) (by decide +kernel)
def c1177 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (4,false), (7,false), (74,false), (19,false), (21,false), (98,false), (99,false)]
theorem p1177 (F : Frame G 3) : c1177.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 0, 6, 7, 1, 9, 8, 10]) (by decide +kernel)
def c1178 : CNF.Clause Nat := [(39,false), (50,false), (16,false), (18,false), (7,false), (10,false), (87,false), (30,false), (31,false), (99,false)]
theorem p1178 (F : Frame G 3) : c1178.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 1, 6, 0, 9, 7, 2, 8, 10]) (by decide +kernel)
def c1179 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (29,false), (7,false), (8,false), (19,false), (21,false), (98,false), (99,false)]
theorem p1179 (F : Frame G 3) : c1179.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 2, 6, 0, 7, 1, 9, 8, 10]) (by decide +kernel)
def c1180 : CNF.Clause Nat := [(39,false), (50,false), (16,false), (19,false), (87,false), (76,false), (29,false), (31,false), (9,false), (11,false)]
theorem p1180 (F : Frame G 3) : c1180.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 1, 7, 9, 6, 2, 8, 0, 10]) (by decide +kernel)
def c1181 : CNF.Clause Nat := [(39,false), (50,false), (16,false), (19,false), (8,false), (7,false), (76,false), (98,false), (31,false), (33,false)]
theorem p1181 (F : Frame G 3) : c1181.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 1, 7, 0, 6, 9, 8, 2, 10]) (by decide +kernel)
def c1182 : CNF.Clause Nat := [(27,false), (50,false), (39,false), (4,false), (7,false), (75,false), (99,false), (22,false), (19,false), (87,false)]
theorem p1182 (F : Frame G 3) : c1182.eval F.assign = true := by
  exact Rule.sound F (.path [2, 4, 5, 3, 0, 6, 8, 10, 1, 7, 9]) (by decide +kernel)
def c1183 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (7,false), (74,false), (19,false), (21,false), (98,false), (31,false), (33,false)]
theorem p1183 (F : Frame G 3) : c1183.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 0, 6, 7, 1, 9, 8, 2, 10]) (by decide +kernel)
def c1184 : CNF.Clause Nat := [(39,false), (38,false), (16,false), (19,false), (74,false), (76,false), (32,false), (31,false), (9,false), (11,false)]
theorem p1184 (F : Frame G 3) : c1184.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 4, 1, 7, 6, 9, 2, 8, 0, 10]) (by decide +kernel)
def c1185 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (26,false), (33,false), (99,false), (75,false), (7,false), (8,false), (87,false)]
theorem p1185 (F : Frame G 3) : c1185.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 2, 10, 8, 6, 0, 7, 9]) (by decide +kernel)
def c1186 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (16,false), (19,false), (74,false), (76,false), (32,false), (31,false), (99,false)]
theorem p1186 (F : Frame G 3) : c1186.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 1, 7, 6, 9, 2, 8, 10]) (by decide +kernel)
def c1187 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (18,false), (7,false), (8,false), (86,false), (98,false), (32,false), (33,false)]
theorem p1187 (F : Frame G 3) : c1187.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 1, 6, 0, 7, 8, 9, 2, 10]) (by decide +kernel)
def c1188 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (15,false), (18,false), (76,false), (10,false), (8,false), (86,false), (99,false)]
theorem p1188 (F : Frame G 3) : c1188.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 1, 6, 9, 0, 7, 8, 10]) (by decide +kernel)
def c1189 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (11,false), (33,false), (30,false), (19,false), (18,false), (75,false), (98,false)]
theorem p1189 (F : Frame G 3) : c1189.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 0, 10, 2, 7, 1, 6, 8, 9]) (by decide +kernel)
def c1190 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (16,false), (19,false), (30,false), (32,false), (76,false), (75,false), (99,false)]
theorem p1190 (F : Frame G 3) : c1190.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 1, 7, 2, 9, 6, 8, 10]) (by decide +kernel)
def c1191 : CNF.Clause Nat := [(4,false), (38,false), (16,false), (17,false), (28,false), (30,false), (74,false), (76,false), (98,false), (99,false)]
theorem p1191 (F : Frame G 3) : c1191.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 1, 5, 2, 7, 6, 9, 8, 10]) (by decide +kernel)
def c1192 : CNF.Clause Nat := [(10,false), (76,false), (77,false), (99,false), (86,false), (19,false), (16,false), (27,false), (26,false), (39,false)]
theorem p1192 (F : Frame G 3) : c1192.eval F.assign = true := by
  exact Rule.sound F (.path [0, 9, 6, 10, 8, 7, 1, 4, 2, 3, 5]) (by decide +kernel)
def c1193 : CNF.Clause Nat := [(28,false), (39,false), (4,false), (5,false), (16,false), (19,false), (86,false), (98,false), (76,false), (77,false)]
theorem p1193 (F : Frame G 3) : c1193.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 0, 4, 1, 7, 8, 9, 6, 10]) (by decide +kernel)
def c1194 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (18,false), (7,false), (11,false), (99,false), (31,false), (30,false), (87,false)]
theorem p1194 (F : Frame G 3) : c1194.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 1, 6, 0, 10, 8, 2, 7, 9]) (by decide +kernel)
def c1195 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (7,false), (18,false), (21,false), (87,false), (30,false), (31,false), (99,false)]
theorem p1195 (F : Frame G 3) : c1195.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 0, 6, 1, 9, 7, 2, 8, 10]) (by decide +kernel)
def c1196 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (4,false), (7,false), (75,false), (99,false), (22,false), (19,false), (87,false)]
theorem p1196 (F : Frame G 3) : c1196.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 0, 6, 8, 10, 1, 7, 9]) (by decide +kernel)
def c1197 : CNF.Clause Nat := [(38,false), (50,false), (28,false), (31,false), (99,false), (22,false), (19,false), (8,false), (7,false), (76,false)]
theorem p1197 (F : Frame G 3) : c1197.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 2, 8, 10, 1, 7, 0, 6, 9]) (by decide +kernel)
def c1198 : CNF.Clause Nat := [(4,false), (5,false), (16,false), (17,false), (28,false), (32,false), (87,false), (74,false), (75,false), (99,false)]
theorem p1198 (F : Frame G 3) : c1198.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 4, 1, 5, 2, 9, 7, 6, 8, 10]) (by decide +kernel)
def c1199 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (17,false), (19,false), (74,false), (77,false), (99,false), (31,false), (32,false)]
theorem p1199 (F : Frame G 3) : c1199.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 1, 7, 6, 10, 8, 2, 9]) (by decide +kernel)
def c1200 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (28,false), (31,false), (86,false), (87,false), (10,false), (7,false), (77,false)]
theorem p1200 (F : Frame G 3) : c1200.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 2, 8, 7, 9, 0, 6, 10]) (by decide +kernel)
end Cert35Steps
end Graffiti199Depleted.Catalogue.OrderEleven
