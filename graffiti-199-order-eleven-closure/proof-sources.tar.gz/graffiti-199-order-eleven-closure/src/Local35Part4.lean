import Local35Part3
namespace Graffiti199Depleted.Catalogue.OrderEleven
namespace Cert35Steps
open Std.Sat
set_option maxRecDepth 4096
set_option maxHeartbeats 0
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj]
def c1201 : CNF.Clause Nat := [(4,false), (6,false), (50,false), (16,false), (18,false), (77,false), (99,false), (31,false), (30,false), (87,false)]
theorem p1201 (F : Frame G 3) : c1201.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 5, 4, 1, 6, 10, 8, 2, 7, 9]) (by decide +kernel)
def c1202 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (7,false), (18,false), (19,false), (87,false), (32,false), (31,false), (99,false)]
theorem p1202 (F : Frame G 3) : c1202.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 0, 6, 1, 7, 9, 2, 8, 10]) (by decide +kernel)
def c1203 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (19,false), (30,false), (31,false), (99,false), (77,false), (7,false), (10,false)]
theorem p1203 (F : Frame G 3) : c1203.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 1, 7, 2, 8, 10, 6, 0, 9]) (by decide +kernel)
def c1204 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (19,false), (8,false), (10,false), (76,false), (75,false), (31,false), (33,false)]
theorem p1204 (F : Frame G 3) : c1204.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 1, 7, 0, 9, 6, 8, 2, 10]) (by decide +kernel)
def c1205 : CNF.Clause Nat := [(19,false), (74,false), (76,false), (10,false), (4,false), (38,false), (50,false), (28,false), (31,false), (99,false)]
theorem p1205 (F : Frame G 3) : c1205.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 6, 9, 0, 3, 4, 5, 2, 8, 10]) (by decide +kernel)
def c1206 : CNF.Clause Nat := [(4,false), (5,false), (50,false), (28,false), (30,false), (86,false), (99,false), (22,false), (18,false), (76,false)]
theorem p1206 (F : Frame G 3) : c1206.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 4, 5, 2, 7, 8, 10, 1, 6, 9]) (by decide +kernel)
def c1207 : CNF.Clause Nat := [(4,false), (5,false), (50,false), (17,false), (19,false), (74,false), (76,false), (32,false), (31,false), (99,false)]
theorem p1207 (F : Frame G 3) : c1207.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 4, 5, 1, 7, 6, 9, 2, 8, 10]) (by decide +kernel)
def c1208 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (17,false), (19,false), (74,false), (76,false), (32,false), (31,false), (99,false)]
theorem p1208 (F : Frame G 3) : c1208.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 1, 7, 6, 9, 2, 8, 10]) (by decide +kernel)
def c1209 : CNF.Clause Nat := [(19,false), (30,false), (26,false), (38,false), (50,false), (6,false), (11,false), (99,false), (75,false), (76,false)]
theorem p1209 (F : Frame G 3) : c1209.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 2, 3, 4, 5, 0, 10, 8, 6, 9]) (by decide +kernel)
def c1210 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (18,false), (7,false), (10,false), (87,false), (86,false), (31,false), (33,false)]
theorem p1210 (F : Frame G 3) : c1210.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 1, 6, 0, 9, 7, 8, 2, 10]) (by decide +kernel)
def c1211 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (19,false), (30,false), (29,false), (7,false), (10,false), (98,false), (99,false)]
theorem p1211 (F : Frame G 3) : c1211.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 1, 7, 2, 6, 0, 9, 8, 10]) (by decide +kernel)
def c1212 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (7,false), (29,false), (30,false), (19,false), (21,false), (98,false), (99,false)]
theorem p1212 (F : Frame G 3) : c1212.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 0, 6, 2, 7, 1, 9, 8, 10]) (by decide +kernel)
def c1213 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (19,false), (8,false), (7,false), (29,false), (32,false), (98,false), (99,false)]
theorem p1213 (F : Frame G 3) : c1213.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 1, 7, 0, 6, 2, 9, 8, 10]) (by decide +kernel)
def c1214 : CNF.Clause Nat := [(4,false), (7,false), (75,false), (99,false), (33,false), (32,false), (87,false), (19,false), (16,false), (50,false)]
theorem p1214 (F : Frame G 3) : c1214.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 8, 10, 2, 9, 7, 1, 4, 5]) (by decide +kernel)
def c1215 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (19,false), (8,false), (10,false), (98,false), (75,false), (29,false), (33,false)]
theorem p1215 (F : Frame G 3) : c1215.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 1, 7, 0, 9, 8, 6, 2, 10]) (by decide +kernel)
def c1216 : CNF.Clause Nat := [(4,false), (5,false), (50,false), (17,false), (19,false), (30,false), (32,false), (98,false), (75,false), (77,false)]
theorem p1216 (F : Frame G 3) : c1216.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 4, 5, 1, 7, 2, 9, 8, 6, 10]) (by decide +kernel)
def c1217 : CNF.Clause Nat := [(21,false), (87,false), (86,false), (99,false), (77,false), (7,false), (4,false), (26,false), (27,false), (50,false)]
theorem p1217 (F : Frame G 3) : c1217.eval F.assign = true := by
  exact Rule.sound F (.path [1, 9, 7, 8, 10, 6, 0, 3, 2, 4, 5]) (by decide +kernel)
def c1218 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (17,false), (21,false), (87,false), (86,false), (31,false), (29,false), (77,false)]
theorem p1218 (F : Frame G 3) : c1218.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 1, 9, 7, 8, 2, 6, 10]) (by decide +kernel)
def c1219 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (17,false), (18,false), (77,false), (99,false), (31,false), (32,false), (87,false)]
theorem p1219 (F : Frame G 3) : c1219.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 1, 6, 10, 8, 2, 9, 7]) (by decide +kernel)
def c1220 : CNF.Clause Nat := [(17,false), (50,false), (38,false), (26,false), (31,false), (86,false), (87,false), (10,false), (7,false), (77,false)]
theorem p1220 (F : Frame G 3) : c1220.eval F.assign = true := by
  exact Rule.sound F (.path [1, 5, 4, 3, 2, 8, 7, 9, 0, 6, 10]) (by decide +kernel)
def c1221 : CNF.Clause Nat := [(26,false), (28,false), (50,false), (5,false), (7,false), (18,false), (19,false), (86,false), (98,false), (110,false)]
theorem p1221 (F : Frame G 3) : c1221.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 4, 0, 6, 1, 7, 8, 9, 10]) (by decide +kernel)
def c1222 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (4,false), (7,false), (18,false), (19,false), (86,false), (98,false), (110,false)]
theorem p1222 (F : Frame G 3) : c1222.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 0, 6, 1, 7, 8, 9, 10]) (by decide +kernel)
def c1223 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (7,false), (18,false), (19,false), (86,false), (31,false), (32,false), (110,false)]
theorem p1223 (F : Frame G 3) : c1223.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 0, 6, 1, 7, 8, 2, 9, 10]) (by decide +kernel)
def c1224 : CNF.Clause Nat := [(19,false), (8,false), (4,false), (38,false), (50,false), (28,false), (32,false), (98,false), (75,false), (77,false)]
theorem p1224 (F : Frame G 3) : c1224.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 0, 3, 4, 5, 2, 9, 8, 6, 10]) (by decide +kernel)
def c1225 : CNF.Clause Nat := [(7,false), (75,false), (86,false), (19,false), (16,false), (38,false), (39,false), (28,false), (32,false), (110,false)]
theorem p1225 (F : Frame G 3) : c1225.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 8, 7, 1, 4, 3, 5, 2, 9, 10]) (by decide +kernel)
def c1226 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (28,false), (30,false), (19,false), (21,false), (110,false), (77,false), (75,false)]
theorem p1226 (F : Frame G 3) : c1226.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 2, 7, 1, 9, 10, 6, 8]) (by decide +kernel)
def c1227 : CNF.Clause Nat := [(15,false), (38,false), (50,false), (6,false), (7,false), (77,false), (110,false), (32,false), (30,false), (86,false)]
theorem p1227 (F : Frame G 3) : c1227.eval F.assign = true := by
  exact Rule.sound F (.path [1, 3, 4, 5, 0, 6, 10, 9, 2, 7, 8]) (by decide +kernel)
def c1228 : CNF.Clause Nat := [(19,false), (86,false), (75,false), (7,false), (4,false), (38,false), (50,false), (28,false), (32,false), (110,false)]
theorem p1228 (F : Frame G 3) : c1228.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 8, 6, 0, 3, 4, 5, 2, 9, 10]) (by decide +kernel)
def c1229 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (7,false), (18,false), (19,false), (86,false), (31,false), (32,false), (110,false)]
theorem p1229 (F : Frame G 3) : c1229.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 4, 0, 6, 1, 7, 8, 2, 9, 10]) (by decide +kernel)
def c1230 : CNF.Clause Nat := [(7,false), (77,false), (110,false), (32,false), (28,false), (39,false), (38,false), (16,false), (19,false), (86,false)]
theorem p1230 (F : Frame G 3) : c1230.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 10, 9, 2, 5, 3, 4, 1, 7, 8]) (by decide +kernel)
def c1231 : CNF.Clause Nat := [(26,false), (28,false), (50,false), (5,false), (7,false), (77,false), (110,false), (21,false), (19,false), (86,false)]
theorem p1231 (F : Frame G 3) : c1231.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 4, 0, 6, 10, 9, 1, 7, 8]) (by decide +kernel)
def c1232 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (4,false), (7,false), (77,false), (110,false), (21,false), (19,false), (86,false)]
theorem p1232 (F : Frame G 3) : c1232.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 0, 6, 10, 9, 1, 7, 8]) (by decide +kernel)
def c1233 : CNF.Clause Nat := [(7,false), (75,false), (86,false), (30,false), (28,false), (39,false), (38,false), (16,false), (21,false), (110,false)]
theorem p1233 (F : Frame G 3) : c1233.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 8, 7, 2, 5, 3, 4, 1, 9, 10]) (by decide +kernel)
def c1234 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (5,false), (7,false), (75,false), (86,false), (19,false), (21,false), (110,false)]
theorem p1234 (F : Frame G 3) : c1234.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 0, 6, 8, 7, 1, 9, 10]) (by decide +kernel)
def c1235 : CNF.Clause Nat := [(27,false), (38,false), (39,false), (6,false), (7,false), (75,false), (86,false), (19,false), (21,false), (110,false)]
theorem p1235 (F : Frame G 3) : c1235.eval F.assign = true := by
  exact Rule.sound F (.path [2, 4, 3, 5, 0, 6, 8, 7, 1, 9, 10]) (by decide +kernel)
def c1236 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (4,false), (7,false), (75,false), (86,false), (19,false), (21,false), (110,false)]
theorem p1236 (F : Frame G 3) : c1236.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 0, 6, 8, 7, 1, 9, 10]) (by decide +kernel)
def c1237 : CNF.Clause Nat := [(19,false), (8,false), (4,false), (38,false), (50,false), (28,false), (31,false), (75,false), (76,false), (110,false)]
theorem p1237 (F : Frame G 3) : c1237.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 0, 3, 4, 5, 2, 8, 6, 9, 10]) (by decide +kernel)
def c1238 : CNF.Clause Nat := [(19,false), (86,false), (31,false), (26,false), (38,false), (50,false), (6,false), (7,false), (76,false), (110,false)]
theorem p1238 (F : Frame G 3) : c1238.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 8, 2, 3, 4, 5, 0, 6, 9, 10]) (by decide +kernel)
def c1239 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (4,false), (10,false), (76,false), (77,false), (99,false), (20,false), (19,false)]
theorem p1239 (F : Frame G 3) : c1239.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 0, 9, 6, 10, 8, 1, 7]) (by decide +kernel)
def c1240 : CNF.Clause Nat := [(28,false), (39,false), (4,false), (5,false), (16,false), (18,false), (77,false), (110,false), (87,false), (86,false)]
theorem p1240 (F : Frame G 3) : c1240.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 0, 4, 1, 6, 10, 9, 7, 8]) (by decide +kernel)
def c1241 : CNF.Clause Nat := [(4,false), (11,false), (77,false), (76,false), (87,false), (86,false), (31,false), (27,false), (16,false), (17,false)]
theorem p1241 (F : Frame G 3) : c1241.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 10, 6, 9, 7, 8, 2, 4, 1, 5]) (by decide +kernel)
def c1242 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (4,false), (7,false), (77,false), (110,false), (32,false), (31,false), (86,false)]
theorem p1242 (F : Frame G 3) : c1242.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 0, 6, 10, 9, 2, 8, 7]) (by decide +kernel)
def c1243 : CNF.Clause Nat := [(4,false), (26,false), (28,false), (50,false), (16,false), (19,false), (87,false), (98,false), (75,false), (77,false)]
theorem p1243 (F : Frame G 3) : c1243.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 2, 5, 4, 1, 7, 9, 8, 6, 10]) (by decide +kernel)
def c1244 : CNF.Clause Nat := [(16,false), (50,false), (28,false), (26,false), (4,false), (7,false), (75,false), (99,false), (88,false), (87,false)]
theorem p1244 (F : Frame G 3) : c1244.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 2, 3, 0, 6, 8, 10, 7, 9]) (by decide +kernel)
def c1245 : CNF.Clause Nat := [(28,false), (39,false), (15,false), (16,false), (5,false), (7,false), (75,false), (99,false), (88,false), (87,false)]
theorem p1245 (F : Frame G 3) : c1245.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 1, 4, 0, 6, 8, 10, 7, 9]) (by decide +kernel)
def c1246 : CNF.Clause Nat := [(4,false), (15,false), (16,false), (50,false), (28,false), (31,false), (75,false), (76,false), (87,false), (88,false)]
theorem p1246 (F : Frame G 3) : c1246.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 1, 4, 5, 2, 8, 6, 9, 7, 10]) (by decide +kernel)
def c1247 : CNF.Clause Nat := [(16,false), (17,false), (39,false), (26,false), (30,false), (87,false), (10,false), (7,false), (75,false), (99,false)]
theorem p1247 (F : Frame G 3) : c1247.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 5, 3, 2, 7, 9, 0, 6, 8, 10]) (by decide +kernel)
def c1248 : CNF.Clause Nat := [(16,false), (17,false), (28,false), (26,false), (4,false), (8,false), (87,false), (110,false), (77,false), (75,false)]
theorem p1248 (F : Frame G 3) : c1248.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 5, 2, 3, 0, 7, 9, 10, 6, 8]) (by decide +kernel)
def c1249 : CNF.Clause Nat := [(27,false), (28,false), (39,false), (15,false), (19,false), (87,false), (10,false), (7,false), (75,false), (99,false)]
theorem p1249 (F : Frame G 3) : c1249.eval F.assign = true := by
  exact Rule.sound F (.path [4, 2, 5, 3, 1, 7, 9, 0, 6, 8, 10]) (by decide +kernel)
def c1250 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (5,false), (11,false), (77,false), (75,false), (20,false), (19,false), (87,false)]
theorem p1250 (F : Frame G 3) : c1250.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 0, 10, 6, 8, 1, 7, 9]) (by decide +kernel)
def c1251 : CNF.Clause Nat := [(16,false), (19,false), (87,false), (110,false), (77,false), (75,false), (9,false), (4,false), (26,false), (28,false)]
theorem p1251 (F : Frame G 3) : c1251.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 7, 9, 10, 6, 8, 0, 3, 2, 5]) (by decide +kernel)
def c1252 : CNF.Clause Nat := [(27,false), (28,false), (39,false), (4,false), (9,false), (75,false), (77,false), (110,false), (21,false), (19,false)]
theorem p1252 (F : Frame G 3) : c1252.eval F.assign = true := by
  exact Rule.sound F (.path [4, 2, 5, 3, 0, 8, 6, 10, 9, 1, 7]) (by decide +kernel)
def c1253 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (16,false), (19,false), (87,false), (110,false), (11,false), (7,false), (75,false)]
theorem p1253 (F : Frame G 3) : c1253.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 1, 7, 9, 10, 0, 6, 8]) (by decide +kernel)
def c1254 : CNF.Clause Nat := [(27,false), (38,false), (39,false), (17,false), (21,false), (87,false), (86,false), (9,false), (7,false), (77,false)]
theorem p1254 (F : Frame G 3) : c1254.eval F.assign = true := by
  exact Rule.sound F (.path [2, 4, 3, 5, 1, 9, 7, 8, 0, 6, 10]) (by decide +kernel)
def c1255 : CNF.Clause Nat := [(27,false), (28,false), (39,false), (15,false), (19,false), (74,false), (7,false), (9,false), (99,false), (110,false)]
theorem p1255 (F : Frame G 3) : c1255.eval F.assign = true := by
  exact Rule.sound F (.path [4, 2, 5, 3, 1, 7, 6, 0, 8, 10, 9]) (by decide +kernel)
def c1256 : CNF.Clause Nat := [(38,false), (39,false), (28,false), (31,false), (20,false), (19,false), (74,false), (7,false), (10,false), (110,false)]
theorem p1256 (F : Frame G 3) : c1256.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 2, 8, 1, 7, 6, 0, 9, 10]) (by decide +kernel)
def c1257 : CNF.Clause Nat := [(16,false), (27,false), (28,false), (39,false), (4,false), (9,false), (99,false), (77,false), (74,false), (87,false)]
theorem p1257 (F : Frame G 3) : c1257.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 2, 5, 3, 0, 8, 10, 6, 7, 9]) (by decide +kernel)
def c1258 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (5,false), (7,false), (77,false), (110,false), (21,false), (19,false), (86,false)]
theorem p1258 (F : Frame G 3) : c1258.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 0, 6, 10, 9, 1, 7, 8]) (by decide +kernel)
def c1259 : CNF.Clause Nat := [(7,false), (77,false), (110,false), (87,false), (86,false), (20,false), (16,false), (27,false), (26,false), (39,false)]
theorem p1259 (F : Frame G 3) : c1259.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 10, 9, 7, 8, 1, 4, 2, 3, 5]) (by decide +kernel)
def c1260 : CNF.Clause Nat := [(7,false), (77,false), (110,false), (87,false), (86,false), (31,false), (27,false), (16,false), (15,false), (39,false)]
theorem p1260 (F : Frame G 3) : c1260.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 10, 9, 7, 8, 2, 4, 1, 3, 5]) (by decide +kernel)
def c1261 : CNF.Clause Nat := [(31,false), (9,false), (7,false), (77,false), (110,false), (87,false), (19,false), (15,false), (38,false), (50,false)]
theorem p1261 (F : Frame G 3) : c1261.eval F.assign = true := by
  exact Rule.sound F (.path [2, 8, 0, 6, 10, 9, 7, 1, 3, 4, 5]) (by decide +kernel)
def c1262 : CNF.Clause Nat := [(28,false), (39,false), (4,false), (5,false), (16,false), (20,false), (75,false), (74,false), (87,false), (110,false)]
theorem p1262 (F : Frame G 3) : c1262.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 0, 4, 1, 8, 6, 7, 9, 10]) (by decide +kernel)
def c1263 : CNF.Clause Nat := [(4,false), (38,false), (27,false), (28,false), (17,false), (21,false), (110,false), (77,false), (74,false), (86,false)]
theorem p1263 (F : Frame G 3) : c1263.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 2, 5, 1, 9, 10, 6, 7, 8]) (by decide +kernel)
def c1264 : CNF.Clause Nat := [(4,false), (38,false), (16,false), (17,false), (28,false), (32,false), (110,false), (88,false), (74,false), (75,false)]
theorem p1264 (F : Frame G 3) : c1264.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 1, 5, 2, 9, 10, 7, 6, 8]) (by decide +kernel)
def c1265 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (4,false), (10,false), (87,false), (30,false), (31,false), (75,false), (77,false)]
theorem p1265 (F : Frame G 3) : c1265.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 0, 9, 7, 2, 8, 6, 10]) (by decide +kernel)
def c1266 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (28,false), (31,false), (99,false), (77,false), (7,false), (8,false), (87,false)]
theorem p1266 (F : Frame G 3) : c1266.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 2, 8, 10, 6, 0, 7, 9]) (by decide +kernel)
def c1267 : CNF.Clause Nat := [(38,false), (16,false), (17,false), (28,false), (29,false), (7,false), (11,false), (99,false), (86,false), (87,false)]
theorem p1267 (F : Frame G 3) : c1267.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 1, 5, 2, 6, 0, 10, 8, 7, 9]) (by decide +kernel)
def c1268 : CNF.Clause Nat := [(16,false), (38,false), (26,false), (28,false), (6,false), (7,false), (75,false), (98,false), (87,false), (88,false)]
theorem p1268 (F : Frame G 3) : c1268.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 2, 5, 0, 6, 8, 9, 7, 10]) (by decide +kernel)
def c1269 : CNF.Clause Nat := [(16,false), (38,false), (26,false), (28,false), (6,false), (9,false), (75,false), (74,false), (87,false), (110,false)]
theorem p1269 (F : Frame G 3) : c1269.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 2, 5, 0, 8, 6, 7, 9, 10]) (by decide +kernel)
def c1270 : CNF.Clause Nat := [(16,false), (38,false), (26,false), (28,false), (6,false), (7,false), (75,false), (86,false), (87,false), (110,false)]
theorem p1270 (F : Frame G 3) : c1270.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 2, 5, 0, 6, 8, 7, 9, 10]) (by decide +kernel)
def c1271 : CNF.Clause Nat := [(26,false), (28,false), (50,false), (5,false), (7,false), (75,false), (20,false), (19,false), (87,false), (110,false)]
theorem p1271 (F : Frame G 3) : c1271.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 4, 0, 6, 8, 1, 7, 9, 10]) (by decide +kernel)
def c1272 : CNF.Clause Nat := [(38,false), (50,false), (28,false), (31,false), (75,false), (7,false), (8,false), (19,false), (21,false), (110,false)]
theorem p1272 (F : Frame G 3) : c1272.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 2, 8, 6, 0, 7, 1, 9, 10]) (by decide +kernel)
def c1273 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (28,false), (33,false), (110,false), (10,false), (7,false), (74,false), (86,false)]
theorem p1273 (F : Frame G 3) : c1273.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 2, 10, 9, 0, 6, 7, 8]) (by decide +kernel)
def c1274 : CNF.Clause Nat := [(38,false), (50,false), (28,false), (31,false), (75,false), (7,false), (11,false), (22,false), (19,false), (87,false)]
theorem p1274 (F : Frame G 3) : c1274.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 2, 8, 6, 0, 10, 1, 7, 9]) (by decide +kernel)
def c1275 : CNF.Clause Nat := [(15,false), (39,false), (50,false), (27,false), (31,false), (99,false), (11,false), (7,false), (74,false), (87,false)]
theorem p1275 (F : Frame G 3) : c1275.eval F.assign = true := by
  exact Rule.sound F (.path [1, 3, 5, 4, 2, 8, 10, 0, 6, 7, 9]) (by decide +kernel)
def c1276 : CNF.Clause Nat := [(4,false), (7,false), (74,false), (86,false), (98,false), (110,false), (22,false), (16,false), (27,false), (28,false)]
theorem p1276 (F : Frame G 3) : c1276.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 7, 8, 9, 10, 1, 4, 2, 5]) (by decide +kernel)
def c1277 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (26,false), (31,false), (9,false), (11,false), (110,false), (76,false), (74,false)]
theorem p1277 (F : Frame G 3) : c1277.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 2, 8, 0, 10, 9, 6, 7]) (by decide +kernel)
def c1278 : CNF.Clause Nat := [(27,false), (50,false), (39,false), (4,false), (11,false), (22,false), (19,false), (74,false), (75,false), (98,false)]
theorem p1278 (F : Frame G 3) : c1278.eval F.assign = true := by
  exact Rule.sound F (.path [2, 4, 5, 3, 0, 10, 1, 7, 6, 8, 9]) (by decide +kernel)
def c1279 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (15,false), (18,false), (74,false), (86,false), (9,false), (10,false), (110,false)]
theorem p1279 (F : Frame G 3) : c1279.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 1, 6, 7, 8, 0, 9, 10]) (by decide +kernel)
def c1280 : CNF.Clause Nat := [(4,false), (7,false), (74,false), (87,false), (110,false), (99,false), (20,false), (16,false), (27,false), (28,false)]
theorem p1280 (F : Frame G 3) : c1280.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 7, 9, 10, 8, 1, 4, 2, 5]) (by decide +kernel)
def c1281 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (4,false), (7,false), (18,false), (19,false), (86,false), (99,false), (110,false)]
theorem p1281 (F : Frame G 3) : c1281.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 0, 6, 1, 7, 8, 10, 9]) (by decide +kernel)
def c1282 : CNF.Clause Nat := [(4,false), (38,false), (16,false), (17,false), (28,false), (29,false), (74,false), (86,false), (99,false), (110,false)]
theorem p1282 (F : Frame G 3) : c1282.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 1, 5, 2, 6, 7, 8, 10, 9]) (by decide +kernel)
def c1283 : CNF.Clause Nat := [(15,false), (38,false), (50,false), (6,false), (7,false), (74,false), (86,false), (31,false), (32,false), (110,false)]
theorem p1283 (F : Frame G 3) : c1283.eval F.assign = true := by
  exact Rule.sound F (.path [1, 3, 4, 5, 0, 6, 7, 8, 2, 9, 10]) (by decide +kernel)
def c1284 : CNF.Clause Nat := [(16,false), (38,false), (4,false), (6,false), (28,false), (31,false), (86,false), (74,false), (77,false), (110,false)]
theorem p1284 (F : Frame G 3) : c1284.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 0, 5, 2, 8, 7, 6, 10, 9]) (by decide +kernel)
def c1285 : CNF.Clause Nat := [(4,false), (38,false), (16,false), (17,false), (28,false), (29,false), (77,false), (99,false), (86,false), (87,false)]
theorem p1285 (F : Frame G 3) : c1285.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 1, 5, 2, 6, 10, 8, 7, 9]) (by decide +kernel)
def c1286 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (19,false), (74,false), (7,false), (9,false), (31,false), (32,false), (110,false)]
theorem p1286 (F : Frame G 3) : c1286.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 1, 7, 6, 0, 8, 2, 9, 10]) (by decide +kernel)
def c1287 : CNF.Clause Nat := [(15,false), (38,false), (50,false), (6,false), (7,false), (29,false), (31,false), (99,false), (88,false), (87,false)]
theorem p1287 (F : Frame G 3) : c1287.eval F.assign = true := by
  exact Rule.sound F (.path [1, 3, 4, 5, 0, 6, 2, 8, 10, 7, 9]) (by decide +kernel)
def c1288 : CNF.Clause Nat := [(15,false), (38,false), (50,false), (6,false), (7,false), (74,false), (87,false), (32,false), (31,false), (99,false)]
theorem p1288 (F : Frame G 3) : c1288.eval F.assign = true := by
  exact Rule.sound F (.path [1, 3, 4, 5, 0, 6, 7, 9, 2, 8, 10]) (by decide +kernel)
def c1289 : CNF.Clause Nat := [(20,false), (31,false), (26,false), (38,false), (50,false), (6,false), (7,false), (74,false), (87,false), (110,false)]
theorem p1289 (F : Frame G 3) : c1289.eval F.assign = true := by
  exact Rule.sound F (.path [1, 8, 2, 3, 4, 5, 0, 6, 7, 9, 10]) (by decide +kernel)
def c1290 : CNF.Clause Nat := [(16,false), (38,false), (26,false), (28,false), (6,false), (9,false), (99,false), (77,false), (74,false), (87,false)]
theorem p1290 (F : Frame G 3) : c1290.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 2, 5, 0, 8, 10, 6, 7, 9]) (by decide +kernel)
def c1291 : CNF.Clause Nat := [(16,false), (38,false), (4,false), (6,false), (28,false), (30,false), (87,false), (110,false), (77,false), (75,false)]
theorem p1291 (F : Frame G 3) : c1291.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 0, 5, 2, 7, 9, 10, 6, 8]) (by decide +kernel)
def c1292 : CNF.Clause Nat := [(19,false), (87,false), (110,false), (77,false), (75,false), (31,false), (26,false), (4,false), (6,false), (50,false)]
theorem p1292 (F : Frame G 3) : c1292.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 9, 10, 6, 8, 2, 3, 0, 5, 4]) (by decide +kernel)
def c1293 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (17,false), (19,false), (87,false), (32,false), (29,false), (77,false), (99,false)]
theorem p1293 (F : Frame G 3) : c1293.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 1, 7, 9, 2, 6, 10, 8]) (by decide +kernel)
def c1294 : CNF.Clause Nat := [(28,false), (39,false), (4,false), (5,false), (16,false), (19,false), (86,false), (75,false), (76,false), (110,false)]
theorem p1294 (F : Frame G 3) : c1294.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 0, 4, 1, 7, 8, 6, 9, 10]) (by decide +kernel)
def c1295 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (7,false), (29,false), (30,false), (19,false), (20,false), (99,false), (110,false)]
theorem p1295 (F : Frame G 3) : c1295.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 0, 6, 2, 7, 1, 8, 10, 9]) (by decide +kernel)
def c1296 : CNF.Clause Nat := [(4,false), (6,false), (50,false), (16,false), (19,false), (87,false), (110,false), (99,false), (31,false), (29,false)]
theorem p1296 (F : Frame G 3) : c1296.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 5, 4, 1, 7, 9, 10, 8, 2, 6]) (by decide +kernel)
def c1297 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (16,false), (19,false), (87,false), (110,false), (99,false), (31,false), (29,false)]
theorem p1297 (F : Frame G 3) : c1297.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 1, 7, 9, 10, 8, 2, 6]) (by decide +kernel)
def c1298 : CNF.Clause Nat := [(4,false), (39,false), (28,false), (27,false), (16,false), (19,false), (86,false), (75,false), (76,false), (110,false)]
theorem p1298 (F : Frame G 3) : c1298.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 2, 4, 1, 7, 8, 6, 9, 10]) (by decide +kernel)
def c1299 : CNF.Clause Nat := [(28,false), (39,false), (15,false), (16,false), (5,false), (7,false), (76,false), (87,false), (86,false), (99,false)]
theorem p1299 (F : Frame G 3) : c1299.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 1, 4, 0, 6, 9, 7, 8, 10]) (by decide +kernel)
def c1300 : CNF.Clause Nat := [(4,false), (38,false), (16,false), (17,false), (28,false), (30,false), (87,false), (98,false), (75,false), (77,false)]
theorem p1300 (F : Frame G 3) : c1300.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 1, 5, 2, 7, 9, 8, 6, 10]) (by decide +kernel)
def c1301 : CNF.Clause Nat := [(26,false), (28,false), (50,false), (5,false), (7,false), (75,false), (86,false), (19,false), (21,false), (110,false)]
theorem p1301 (F : Frame G 3) : c1301.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 4, 0, 6, 8, 7, 1, 9, 10]) (by decide +kernel)
def c1302 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (7,false), (75,false), (31,false), (30,false), (19,false), (21,false), (110,false)]
theorem p1302 (F : Frame G 3) : c1302.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 0, 6, 8, 2, 7, 1, 9, 10]) (by decide +kernel)
def c1303 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (4,false), (7,false), (75,false), (86,false), (30,false), (32,false), (110,false)]
theorem p1303 (F : Frame G 3) : c1303.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 0, 6, 8, 7, 2, 9, 10]) (by decide +kernel)
def c1304 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (4,false), (7,false), (75,false), (31,false), (30,false), (87,false), (110,false)]
theorem p1304 (F : Frame G 3) : c1304.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 0, 6, 8, 2, 7, 9, 10]) (by decide +kernel)
def c1305 : CNF.Clause Nat := [(16,false), (18,false), (7,false), (4,false), (39,false), (28,false), (30,false), (86,false), (98,false), (110,false)]
theorem p1305 (F : Frame G 3) : c1305.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 6, 0, 3, 5, 2, 7, 8, 9, 10]) (by decide +kernel)
def c1306 : CNF.Clause Nat := [(5,false), (38,false), (39,false), (17,false), (19,false), (87,false), (110,false), (33,false), (29,false), (75,false)]
theorem p1306 (F : Frame G 3) : c1306.eval F.assign = true := by
  exact Rule.sound F (.path [0, 4, 3, 5, 1, 7, 9, 10, 2, 6, 8]) (by decide +kernel)
def c1307 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (6,false), (7,false), (75,false), (31,false), (30,false), (87,false), (110,false)]
theorem p1307 (F : Frame G 3) : c1307.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 0, 6, 8, 2, 7, 9, 10]) (by decide +kernel)
def c1308 : CNF.Clause Nat := [(5,false), (38,false), (39,false), (17,false), (18,false), (75,false), (31,false), (30,false), (87,false), (110,false)]
theorem p1308 (F : Frame G 3) : c1308.eval F.assign = true := by
  exact Rule.sound F (.path [0, 4, 3, 5, 1, 6, 8, 2, 7, 9, 10]) (by decide +kernel)
def c1309 : CNF.Clause Nat := [(19,false), (30,false), (26,false), (38,false), (50,false), (6,false), (7,false), (75,false), (98,false), (110,false)]
theorem p1309 (F : Frame G 3) : c1309.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 2, 3, 4, 5, 0, 6, 8, 9, 10]) (by decide +kernel)
def c1310 : CNF.Clause Nat := [(7,false), (75,false), (99,false), (110,false), (87,false), (19,false), (16,false), (27,false), (26,false), (39,false)]
theorem p1310 (F : Frame G 3) : c1310.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 8, 10, 9, 7, 1, 4, 2, 3, 5]) (by decide +kernel)
def c1311 : CNF.Clause Nat := [(7,false), (75,false), (99,false), (110,false), (87,false), (30,false), (27,false), (16,false), (15,false), (39,false)]
theorem p1311 (F : Frame G 3) : c1311.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 8, 10, 9, 7, 2, 4, 1, 3, 5]) (by decide +kernel)
def c1312 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (17,false), (19,false), (87,false), (110,false), (33,false), (29,false), (75,false)]
theorem p1312 (F : Frame G 3) : c1312.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 1, 7, 9, 10, 2, 6, 8]) (by decide +kernel)
def c1313 : CNF.Clause Nat := [(4,false), (7,false), (75,false), (86,false), (19,false), (21,false), (110,false), (33,false), (27,false), (50,false)]
theorem p1313 (F : Frame G 3) : c1313.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 8, 7, 1, 9, 10, 2, 4, 5]) (by decide +kernel)
def c1314 : CNF.Clause Nat := [(4,false), (7,false), (75,false), (86,false), (30,false), (27,false), (50,false), (17,false), (21,false), (110,false)]
theorem p1314 (F : Frame G 3) : c1314.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 8, 7, 2, 4, 5, 1, 9, 10]) (by decide +kernel)
def c1315 : CNF.Clause Nat := [(39,false), (50,false), (16,false), (19,false), (30,false), (29,false), (7,false), (9,false), (99,false), (110,false)]
theorem p1315 (F : Frame G 3) : c1315.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 1, 7, 2, 6, 0, 8, 10, 9]) (by decide +kernel)
def c1316 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (27,false), (29,false), (75,false), (99,false), (88,false), (19,false), (21,false)]
theorem p1316 (F : Frame G 3) : c1316.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 2, 6, 8, 10, 7, 1, 9]) (by decide +kernel)
def c1317 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (27,false), (30,false), (88,false), (110,false), (21,false), (18,false), (75,false)]
theorem p1317 (F : Frame G 3) : c1317.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 2, 7, 10, 9, 1, 6, 8]) (by decide +kernel)
def c1318 : CNF.Clause Nat := [(7,false), (75,false), (31,false), (30,false), (88,false), (110,false), (21,false), (15,false), (38,false), (50,false)]
theorem p1318 (F : Frame G 3) : c1318.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 8, 2, 7, 10, 9, 1, 3, 4, 5]) (by decide +kernel)
def c1319 : CNF.Clause Nat := [(7,false), (75,false), (99,false), (88,false), (19,false), (21,false), (32,false), (26,false), (38,false), (50,false)]
theorem p1319 (F : Frame G 3) : c1319.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 8, 10, 7, 1, 9, 2, 3, 4, 5]) (by decide +kernel)
def c1320 : CNF.Clause Nat := [(5,false), (38,false), (39,false), (17,false), (19,false), (30,false), (29,false), (75,false), (98,false), (110,false)]
theorem p1320 (F : Frame G 3) : c1320.eval F.assign = true := by
  exact Rule.sound F (.path [0, 4, 3, 5, 1, 7, 2, 6, 8, 9, 10]) (by decide +kernel)
def c1321 : CNF.Clause Nat := [(7,false), (75,false), (98,false), (110,false), (88,false), (30,false), (27,false), (16,false), (15,false), (39,false)]
theorem p1321 (F : Frame G 3) : c1321.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 8, 9, 10, 7, 2, 4, 1, 3, 5]) (by decide +kernel)
def c1322 : CNF.Clause Nat := [(38,false), (39,false), (28,false), (30,false), (19,false), (18,false), (75,false), (98,false), (10,false), (11,false)]
theorem p1322 (F : Frame G 3) : c1322.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 2, 7, 1, 6, 8, 9, 0, 10]) (by decide +kernel)
def c1323 : CNF.Clause Nat := [(16,false), (19,false), (88,false), (110,false), (98,false), (75,false), (7,false), (4,false), (26,false), (28,false)]
theorem p1323 (F : Frame G 3) : c1323.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 7, 10, 9, 8, 6, 0, 3, 2, 5]) (by decide +kernel)
def c1324 : CNF.Clause Nat := [(39,false), (50,false), (16,false), (19,false), (30,false), (29,false), (7,false), (9,false), (98,false), (110,false)]
theorem p1324 (F : Frame G 3) : c1324.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 1, 7, 2, 6, 0, 8, 9, 10]) (by decide +kernel)
def c1325 : CNF.Clause Nat := [(4,false), (5,false), (50,false), (28,false), (29,false), (77,false), (110,false), (21,false), (19,false), (86,false)]
theorem p1325 (F : Frame G 3) : c1325.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 4, 5, 2, 6, 10, 9, 1, 7, 8]) (by decide +kernel)
def c1326 : CNF.Clause Nat := [(28,false), (39,false), (15,false), (16,false), (5,false), (8,false), (86,false), (75,false), (77,false), (110,false)]
theorem p1326 (F : Frame G 3) : c1326.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 1, 4, 0, 7, 8, 6, 10, 9]) (by decide +kernel)
def c1327 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (16,false), (19,false), (86,false), (98,false), (110,false), (33,false), (29,false)]
theorem p1327 (F : Frame G 3) : c1327.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 1, 7, 8, 9, 10, 2, 6]) (by decide +kernel)
def c1328 : CNF.Clause Nat := [(27,false), (50,false), (39,false), (15,false), (19,false), (8,false), (7,false), (76,false), (98,false), (99,false)]
theorem p1328 (F : Frame G 3) : c1328.eval F.assign = true := by
  exact Rule.sound F (.path [2, 4, 5, 3, 1, 7, 0, 6, 9, 8, 10]) (by decide +kernel)
def c1329 : CNF.Clause Nat := [(4,false), (7,false), (18,false), (19,false), (86,false), (99,false), (110,false), (32,false), (27,false), (50,false)]
theorem p1329 (F : Frame G 3) : c1329.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 1, 7, 8, 10, 9, 2, 4, 5]) (by decide +kernel)
def c1330 : CNF.Clause Nat := [(39,false), (50,false), (16,false), (19,false), (8,false), (7,false), (29,false), (31,false), (98,false), (110,false)]
theorem p1330 (F : Frame G 3) : c1330.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 1, 7, 0, 6, 2, 8, 9, 10]) (by decide +kernel)
def c1331 : CNF.Clause Nat := [(39,false), (50,false), (16,false), (19,false), (8,false), (7,false), (75,false), (31,false), (32,false), (110,false)]
theorem p1331 (F : Frame G 3) : c1331.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 1, 7, 0, 6, 8, 2, 9, 10]) (by decide +kernel)
def c1332 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (28,false), (31,false), (75,false), (74,false), (8,false), (10,false), (110,false)]
theorem p1332 (F : Frame G 3) : c1332.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 2, 8, 6, 7, 0, 9, 10]) (by decide +kernel)
def c1333 : CNF.Clause Nat := [(16,false), (19,false), (74,false), (75,false), (99,false), (110,false), (32,false), (26,false), (4,false), (6,false)]
theorem p1333 (F : Frame G 3) : c1333.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 7, 6, 8, 10, 9, 2, 3, 0, 5]) (by decide +kernel)
def c1334 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (8,false), (19,false), (21,false), (110,false), (99,false), (31,false), (29,false)]
theorem p1334 (F : Frame G 3) : c1334.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 0, 7, 1, 9, 10, 8, 2, 6]) (by decide +kernel)
def c1335 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (19,false), (8,false), (7,false), (29,false), (31,false), (99,false), (110,false)]
theorem p1335 (F : Frame G 3) : c1335.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 1, 7, 0, 6, 2, 8, 10, 9]) (by decide +kernel)
def c1336 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (7,false), (29,false), (31,false), (86,false), (19,false), (21,false), (110,false)]
theorem p1336 (F : Frame G 3) : c1336.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 0, 6, 2, 8, 7, 1, 9, 10]) (by decide +kernel)
def c1337 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (18,false), (74,false), (8,false), (11,false), (33,false), (31,false), (98,false)]
theorem p1337 (F : Frame G 3) : c1337.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 1, 6, 7, 0, 10, 2, 8, 9]) (by decide +kernel)
def c1338 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (6,false), (7,false), (74,false), (86,false), (31,false), (32,false), (110,false)]
theorem p1338 (F : Frame G 3) : c1338.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 0, 6, 7, 8, 2, 9, 10]) (by decide +kernel)
def c1339 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (22,false), (11,false), (7,false), (74,false), (86,false), (31,false), (32,false)]
theorem p1339 (F : Frame G 3) : c1339.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 1, 10, 0, 6, 7, 8, 2, 9]) (by decide +kernel)
def c1340 : CNF.Clause Nat := [(16,false), (17,false), (39,false), (4,false), (7,false), (74,false), (86,false), (31,false), (32,false), (110,false)]
theorem p1340 (F : Frame G 3) : c1340.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 5, 3, 0, 6, 7, 8, 2, 9, 10]) (by decide +kernel)
def c1341 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (28,false), (29,false), (74,false), (88,false), (11,false), (9,false), (98,false)]
theorem p1341 (F : Frame G 3) : c1341.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 2, 6, 7, 10, 0, 8, 9]) (by decide +kernel)
def c1342 : CNF.Clause Nat := [(39,false), (38,false), (27,false), (31,false), (9,false), (7,false), (18,false), (19,false), (88,false), (110,false)]
theorem p1342 (F : Frame G 3) : c1342.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 4, 2, 8, 0, 6, 1, 7, 10, 9]) (by decide +kernel)
def c1343 : CNF.Clause Nat := [(39,false), (38,false), (27,false), (31,false), (20,false), (21,false), (110,false), (11,false), (7,false), (74,false)]
theorem p1343 (F : Frame G 3) : c1343.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 4, 2, 8, 1, 9, 10, 0, 6, 7]) (by decide +kernel)
def c1344 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (4,false), (7,false), (74,false), (86,false), (31,false), (32,false), (110,false)]
theorem p1344 (F : Frame G 3) : c1344.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 0, 6, 7, 8, 2, 9, 10]) (by decide +kernel)
def c1345 : CNF.Clause Nat := [(20,false), (98,false), (110,false), (88,false), (74,false), (29,false), (26,false), (4,false), (5,false), (50,false)]
theorem p1345 (F : Frame G 3) : c1345.eval F.assign = true := by
  exact Rule.sound F (.path [1, 8, 9, 10, 7, 6, 2, 3, 0, 4, 5]) (by decide +kernel)
def c1346 : CNF.Clause Nat := [(4,false), (7,false), (74,false), (88,false), (110,false), (98,false), (20,false), (16,false), (27,false), (28,false)]
theorem p1346 (F : Frame G 3) : c1346.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 7, 10, 9, 8, 1, 4, 2, 5]) (by decide +kernel)
def c1347 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (6,false), (7,false), (74,false), (88,false), (99,false), (31,false), (32,false)]
theorem p1347 (F : Frame G 3) : c1347.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 0, 6, 7, 10, 8, 2, 9]) (by decide +kernel)
def c1348 : CNF.Clause Nat := [(4,false), (5,false), (50,false), (28,false), (31,false), (99,false), (110,false), (21,false), (18,false), (74,false)]
theorem p1348 (F : Frame G 3) : c1348.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 4, 5, 2, 8, 10, 9, 1, 6, 7]) (by decide +kernel)
def c1349 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (28,false), (31,false), (99,false), (110,false), (21,false), (18,false), (74,false)]
theorem p1349 (F : Frame G 3) : c1349.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 2, 8, 10, 9, 1, 6, 7]) (by decide +kernel)
def c1350 : CNF.Clause Nat := [(16,false), (38,false), (26,false), (28,false), (6,false), (7,false), (74,false), (86,false), (98,false), (110,false)]
theorem p1350 (F : Frame G 3) : c1350.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 2, 5, 0, 6, 7, 8, 9, 10]) (by decide +kernel)
def c1351 : CNF.Clause Nat := [(38,false), (50,false), (28,false), (29,false), (74,false), (8,false), (10,false), (98,false), (20,false), (22,false)]
theorem p1351 (F : Frame G 3) : c1351.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 2, 6, 7, 0, 9, 8, 1, 10]) (by decide +kernel)
def c1352 : CNF.Clause Nat := [(19,false), (74,false), (75,false), (31,false), (26,false), (38,false), (50,false), (6,false), (10,false), (110,false)]
theorem p1352 (F : Frame G 3) : c1352.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 6, 8, 2, 3, 4, 5, 0, 9, 10]) (by decide +kernel)
def c1353 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (7,false), (74,false), (19,false), (22,false), (110,false), (32,false), (31,false)]
theorem p1353 (F : Frame G 3) : c1353.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 0, 6, 7, 1, 10, 9, 2, 8]) (by decide +kernel)
def c1354 : CNF.Clause Nat := [(17,false), (50,false), (38,false), (26,false), (31,false), (98,false), (76,false), (7,false), (8,false), (88,false)]
theorem p1354 (F : Frame G 3) : c1354.eval F.assign = true := by
  exact Rule.sound F (.path [1, 5, 4, 3, 2, 8, 9, 6, 0, 7, 10]) (by decide +kernel)
def c1355 : CNF.Clause Nat := [(17,false), (50,false), (38,false), (4,false), (7,false), (74,false), (86,false), (31,false), (32,false), (110,false)]
theorem p1355 (F : Frame G 3) : c1355.eval F.assign = true := by
  exact Rule.sound F (.path [1, 5, 4, 3, 0, 6, 7, 8, 2, 9, 10]) (by decide +kernel)
def c1356 : CNF.Clause Nat := [(4,false), (8,false), (74,false), (18,false), (16,false), (50,false), (28,false), (31,false), (98,false), (110,false)]
theorem p1356 (F : Frame G 3) : c1356.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 7, 6, 1, 4, 5, 2, 8, 9, 10]) (by decide +kernel)
def c1357 : CNF.Clause Nat := [(4,false), (8,false), (74,false), (76,false), (110,false), (22,false), (20,false), (31,false), (27,false), (50,false)]
theorem p1357 (F : Frame G 3) : c1357.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 7, 6, 9, 10, 1, 8, 2, 4, 5]) (by decide +kernel)
def c1358 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (6,false), (8,false), (74,false), (29,false), (31,false), (98,false), (110,false)]
theorem p1358 (F : Frame G 3) : c1358.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 0, 7, 6, 2, 8, 9, 10]) (by decide +kernel)
def c1359 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (6,false), (7,false), (74,false), (30,false), (31,false), (98,false), (110,false)]
theorem p1359 (F : Frame G 3) : c1359.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 0, 6, 7, 2, 8, 9, 10]) (by decide +kernel)
def c1360 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (6,false), (8,false), (74,false), (76,false), (32,false), (31,false), (99,false)]
theorem p1360 (F : Frame G 3) : c1360.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 0, 7, 6, 9, 2, 8, 10]) (by decide +kernel)
def c1361 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (19,false), (8,false), (7,false), (29,false), (31,false), (98,false), (110,false)]
theorem p1361 (F : Frame G 3) : c1361.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 1, 7, 0, 6, 2, 8, 9, 10]) (by decide +kernel)
def c1362 : CNF.Clause Nat := [(39,false), (50,false), (16,false), (19,false), (86,false), (31,false), (29,false), (7,false), (10,false), (110,false)]
theorem p1362 (F : Frame G 3) : c1362.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 1, 7, 8, 2, 6, 0, 9, 10]) (by decide +kernel)
def c1363 : CNF.Clause Nat := [(39,false), (50,false), (16,false), (19,false), (87,false), (110,false), (11,false), (7,false), (29,false), (31,false)]
theorem p1363 (F : Frame G 3) : c1363.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 1, 7, 9, 10, 0, 6, 2, 8]) (by decide +kernel)
def c1364 : CNF.Clause Nat := [(39,false), (50,false), (16,false), (19,false), (87,false), (10,false), (9,false), (31,false), (29,false), (77,false)]
theorem p1364 (F : Frame G 3) : c1364.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 1, 7, 9, 0, 8, 2, 6, 10]) (by decide +kernel)
def c1365 : CNF.Clause Nat := [(4,false), (5,false), (50,false), (28,false), (30,false), (87,false), (98,false), (20,false), (18,false), (77,false)]
theorem p1365 (F : Frame G 3) : c1365.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 4, 5, 2, 7, 9, 8, 1, 6, 10]) (by decide +kernel)
def c1366 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (31,false), (20,false), (18,false), (77,false), (11,false), (8,false), (87,false)]
theorem p1366 (F : Frame G 3) : c1366.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 2, 8, 1, 6, 10, 0, 7, 9]) (by decide +kernel)
def c1367 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (27,false), (30,false), (87,false), (21,false), (18,false), (77,false), (99,false)]
theorem p1367 (F : Frame G 3) : c1367.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 2, 7, 9, 1, 6, 10, 8]) (by decide +kernel)
def c1368 : CNF.Clause Nat := [(4,false), (7,false), (77,false), (99,false), (31,false), (27,false), (50,false), (17,false), (19,false), (87,false)]
theorem p1368 (F : Frame G 3) : c1368.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 10, 8, 2, 4, 5, 1, 7, 9]) (by decide +kernel)
def c1369 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (31,false), (99,false), (77,false), (7,false), (8,false), (19,false), (21,false)]
theorem p1369 (F : Frame G 3) : c1369.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 2, 8, 10, 6, 0, 7, 1, 9]) (by decide +kernel)
def c1370 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (19,false), (30,false), (31,false), (75,false), (7,false), (10,false), (110,false)]
theorem p1370 (F : Frame G 3) : c1370.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 1, 7, 2, 8, 6, 0, 9, 10]) (by decide +kernel)
def c1371 : CNF.Clause Nat := [(7,false), (77,false), (99,false), (31,false), (26,false), (38,false), (50,false), (17,false), (19,false), (87,false)]
theorem p1371 (F : Frame G 3) : c1371.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 10, 8, 2, 3, 4, 5, 1, 7, 9]) (by decide +kernel)
def c1372 : CNF.Clause Nat := [(19,false), (8,false), (4,false), (38,false), (50,false), (28,false), (29,false), (77,false), (99,false), (98,false)]
theorem p1372 (F : Frame G 3) : c1372.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 0, 3, 4, 5, 2, 6, 10, 8, 9]) (by decide +kernel)
def c1373 : CNF.Clause Nat := [(4,false), (7,false), (76,false), (87,false), (19,false), (16,false), (50,false), (28,false), (31,false), (99,false)]
theorem p1373 (F : Frame G 3) : c1373.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 9, 7, 1, 4, 5, 2, 8, 10]) (by decide +kernel)
def c1374 : CNF.Clause Nat := [(16,false), (17,false), (39,false), (26,false), (31,false), (99,false), (110,false), (10,false), (7,false), (74,false)]
theorem p1374 (F : Frame G 3) : c1374.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 5, 3, 2, 8, 10, 9, 0, 6, 7]) (by decide +kernel)
def c1375 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (16,false), (18,false), (7,false), (8,false), (86,false), (99,false), (110,false)]
theorem p1375 (F : Frame G 3) : c1375.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 1, 6, 0, 7, 8, 10, 9]) (by decide +kernel)
def c1376 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (16,false), (18,false), (7,false), (10,false), (87,false), (86,false), (99,false)]
theorem p1376 (F : Frame G 3) : c1376.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 1, 6, 0, 9, 7, 8, 10]) (by decide +kernel)
def c1377 : CNF.Clause Nat := [(27,false), (38,false), (39,false), (6,false), (7,false), (75,false), (98,false), (21,false), (19,false), (88,false)]
theorem p1377 (F : Frame G 3) : c1377.eval F.assign = true := by
  exact Rule.sound F (.path [2, 4, 3, 5, 0, 6, 8, 9, 1, 7, 10]) (by decide +kernel)
def c1378 : CNF.Clause Nat := [(19,false), (86,false), (31,false), (27,false), (38,false), (39,false), (6,false), (7,false), (76,false), (110,false)]
theorem p1378 (F : Frame G 3) : c1378.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 8, 2, 4, 3, 5, 0, 6, 9, 10]) (by decide +kernel)
def c1379 : CNF.Clause Nat := [(19,false), (86,false), (31,false), (27,false), (50,false), (39,false), (4,false), (7,false), (76,false), (110,false)]
theorem p1379 (F : Frame G 3) : c1379.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 8, 2, 4, 5, 3, 0, 6, 9, 10]) (by decide +kernel)
def c1380 : CNF.Clause Nat := [(4,false), (5,false), (16,false), (17,false), (28,false), (29,false), (76,false), (110,false), (99,false), (86,false)]
theorem p1380 (F : Frame G 3) : c1380.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 4, 1, 5, 2, 6, 9, 10, 8, 7]) (by decide +kernel)
def c1381 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (4,false), (7,false), (29,false), (30,false), (86,false), (98,false), (110,false)]
theorem p1381 (F : Frame G 3) : c1381.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 0, 6, 2, 7, 8, 9, 10]) (by decide +kernel)
def c1382 : CNF.Clause Nat := [(16,false), (50,false), (28,false), (26,false), (4,false), (8,false), (74,false), (75,false), (98,false), (110,false)]
theorem p1382 (F : Frame G 3) : c1382.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 2, 3, 0, 7, 6, 8, 9, 10]) (by decide +kernel)
def c1383 : CNF.Clause Nat := [(31,false), (75,false), (74,false), (19,false), (15,false), (39,false), (50,false), (5,false), (10,false), (110,false)]
theorem p1383 (F : Frame G 3) : c1383.eval F.assign = true := by
  exact Rule.sound F (.path [2, 8, 6, 7, 1, 3, 5, 4, 0, 9, 10]) (by decide +kernel)
def c1384 : CNF.Clause Nat := [(28,false), (50,false), (16,false), (15,false), (4,false), (7,false), (75,false), (86,false), (88,false), (110,false)]
theorem p1384 (F : Frame G 3) : c1384.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 1, 3, 0, 6, 8, 7, 10, 9]) (by decide +kernel)
def c1385 : CNF.Clause Nat := [(4,false), (15,false), (16,false), (50,false), (28,false), (29,false), (76,false), (110,false), (99,false), (86,false)]
theorem p1385 (F : Frame G 3) : c1385.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 1, 4, 5, 2, 6, 9, 10, 8, 7]) (by decide +kernel)
def c1386 : CNF.Clause Nat := [(4,false), (15,false), (16,false), (50,false), (28,false), (31,false), (86,false), (74,false), (76,false), (110,false)]
theorem p1386 (F : Frame G 3) : c1386.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 1, 4, 5, 2, 8, 7, 6, 9, 10]) (by decide +kernel)
def c1387 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (6,false), (7,false), (76,false), (98,false), (31,false), (30,false), (88,false)]
theorem p1387 (F : Frame G 3) : c1387.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 0, 6, 9, 8, 2, 7, 10]) (by decide +kernel)
def c1388 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (17,false), (19,false), (74,false), (29,false), (31,false), (98,false), (110,false)]
theorem p1388 (F : Frame G 3) : c1388.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 1, 7, 6, 2, 8, 9, 10]) (by decide +kernel)
def c1389 : CNF.Clause Nat := [(4,false), (15,false), (16,false), (50,false), (28,false), (31,false), (98,false), (76,false), (74,false), (88,false)]
theorem p1389 (F : Frame G 3) : c1389.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 1, 4, 5, 2, 8, 9, 6, 7, 10]) (by decide +kernel)
def c1390 : CNF.Clause Nat := [(16,false), (15,false), (39,false), (6,false), (7,false), (74,false), (30,false), (31,false), (99,false), (110,false)]
theorem p1390 (F : Frame G 3) : c1390.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 3, 5, 0, 6, 7, 2, 8, 10, 9]) (by decide +kernel)
def c1391 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (6,false), (9,false), (31,false), (30,false), (74,false), (76,false), (110,false)]
theorem p1391 (F : Frame G 3) : c1391.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 0, 8, 2, 7, 6, 9, 10]) (by decide +kernel)
def c1392 : CNF.Clause Nat := [(16,false), (19,false), (74,false), (75,false), (9,false), (4,false), (39,false), (28,false), (32,false), (110,false)]
theorem p1392 (F : Frame G 3) : c1392.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 7, 6, 8, 0, 3, 5, 2, 9, 10]) (by decide +kernel)
def c1393 : CNF.Clause Nat := [(4,false), (38,false), (16,false), (17,false), (28,false), (30,false), (74,false), (75,false), (98,false), (110,false)]
theorem p1393 (F : Frame G 3) : c1393.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 1, 5, 2, 7, 6, 8, 9, 10]) (by decide +kernel)
def c1394 : CNF.Clause Nat := [(5,false), (4,false), (39,false), (17,false), (19,false), (74,false), (29,false), (31,false), (98,false), (110,false)]
theorem p1394 (F : Frame G 3) : c1394.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 3, 5, 1, 7, 6, 2, 8, 9, 10]) (by decide +kernel)
def c1395 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (16,false), (22,false), (110,false), (76,false), (7,false), (8,false), (86,false)]
theorem p1395 (F : Frame G 3) : c1395.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 1, 10, 9, 6, 0, 7, 8]) (by decide +kernel)
def c1396 : CNF.Clause Nat := [(27,false), (28,false), (39,false), (15,false), (19,false), (86,false), (9,false), (7,false), (76,false), (110,false)]
theorem p1396 (F : Frame G 3) : c1396.eval F.assign = true := by
  exact Rule.sound F (.path [4, 2, 5, 3, 1, 7, 8, 0, 6, 9, 10]) (by decide +kernel)
def c1397 : CNF.Clause Nat := [(16,false), (17,false), (28,false), (26,false), (4,false), (9,false), (86,false), (74,false), (76,false), (110,false)]
theorem p1397 (F : Frame G 3) : c1397.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 5, 2, 3, 0, 8, 7, 6, 9, 10]) (by decide +kernel)
def c1398 : CNF.Clause Nat := [(28,false), (39,false), (4,false), (5,false), (16,false), (20,false), (86,false), (74,false), (76,false), (110,false)]
theorem p1398 (F : Frame G 3) : c1398.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 0, 4, 1, 8, 7, 6, 9, 10]) (by decide +kernel)
def c1399 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (16,false), (21,false), (110,false), (11,false), (7,false), (74,false), (86,false)]
theorem p1399 (F : Frame G 3) : c1399.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 1, 9, 10, 0, 6, 7, 8]) (by decide +kernel)
def c1400 : CNF.Clause Nat := [(10,false), (76,false), (77,false), (88,false), (86,false), (31,false), (27,false), (16,false), (15,false), (39,false)]
theorem p1400 (F : Frame G 3) : c1400.eval F.assign = true := by
  exact Rule.sound F (.path [0, 9, 6, 10, 7, 8, 2, 4, 1, 3, 5]) (by decide +kernel)
def c1401 : CNF.Clause Nat := [(10,false), (76,false), (77,false), (88,false), (86,false), (20,false), (16,false), (27,false), (26,false), (39,false)]
theorem p1401 (F : Frame G 3) : c1401.eval F.assign = true := by
  exact Rule.sound F (.path [0, 9, 6, 10, 7, 8, 1, 4, 2, 3, 5]) (by decide +kernel)
def c1402 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (20,false), (31,false), (30,false), (87,false), (76,false), (7,false), (11,false)]
theorem p1402 (F : Frame G 3) : c1402.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 1, 8, 2, 7, 9, 6, 0, 10]) (by decide +kernel)
def c1403 : CNF.Clause Nat := [(38,false), (39,false), (28,false), (31,false), (20,false), (18,false), (7,false), (8,false), (87,false), (110,false)]
theorem p1403 (F : Frame G 3) : c1403.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 2, 8, 1, 6, 0, 7, 9, 10]) (by decide +kernel)
def c1404 : CNF.Clause Nat := [(5,false), (38,false), (39,false), (17,false), (20,false), (31,false), (29,false), (76,false), (87,false), (88,false)]
theorem p1404 (F : Frame G 3) : c1404.eval F.assign = true := by
  exact Rule.sound F (.path [0, 4, 3, 5, 1, 8, 2, 6, 9, 7, 10]) (by decide +kernel)
def c1405 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (7,false), (29,false), (31,false), (20,false), (19,false), (87,false), (110,false)]
theorem p1405 (F : Frame G 3) : c1405.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 0, 6, 2, 8, 1, 7, 9, 10]) (by decide +kernel)
def c1406 : CNF.Clause Nat := [(16,false), (15,false), (39,false), (28,false), (31,false), (86,false), (8,false), (7,false), (76,false), (110,false)]
theorem p1406 (F : Frame G 3) : c1406.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 3, 5, 2, 8, 7, 0, 6, 9, 10]) (by decide +kernel)
def c1407 : CNF.Clause Nat := [(38,false), (39,false), (28,false), (33,false), (11,false), (7,false), (76,false), (21,false), (19,false), (86,false)]
theorem p1407 (F : Frame G 3) : c1407.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 2, 10, 0, 6, 9, 1, 7, 8]) (by decide +kernel)
def c1408 : CNF.Clause Nat := [(4,false), (38,false), (16,false), (17,false), (28,false), (30,false), (74,false), (77,false), (99,false), (98,false)]
theorem p1408 (F : Frame G 3) : c1408.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 1, 5, 2, 7, 6, 10, 8, 9]) (by decide +kernel)
def c1409 : CNF.Clause Nat := [(4,false), (38,false), (16,false), (17,false), (28,false), (31,false), (86,false), (74,false), (76,false), (110,false)]
theorem p1409 (F : Frame G 3) : c1409.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 1, 5, 2, 8, 7, 6, 9, 10]) (by decide +kernel)
def c1410 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (5,false), (7,false), (18,false), (19,false), (86,false), (98,false), (110,false)]
theorem p1410 (F : Frame G 3) : c1410.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 0, 6, 1, 7, 8, 9, 10]) (by decide +kernel)
def c1411 : CNF.Clause Nat := [(10,false), (110,false), (77,false), (74,false), (86,false), (31,false), (27,false), (16,false), (15,false), (39,false)]
theorem p1411 (F : Frame G 3) : c1411.eval F.assign = true := by
  exact Rule.sound F (.path [0, 9, 10, 6, 7, 8, 2, 4, 1, 3, 5]) (by decide +kernel)
def c1412 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (6,false), (8,false), (74,false), (76,false), (98,false), (31,false), (33,false)]
theorem p1412 (F : Frame G 3) : c1412.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 0, 7, 6, 9, 8, 2, 10]) (by decide +kernel)
def c1413 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (26,false), (31,false), (9,false), (10,false), (76,false), (74,false), (88,false)]
theorem p1413 (F : Frame G 3) : c1413.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 2, 8, 0, 9, 6, 7, 10]) (by decide +kernel)
def c1414 : CNF.Clause Nat := [(31,false), (99,false), (88,false), (74,false), (76,false), (21,false), (16,false), (38,false), (4,false), (6,false)]
theorem p1414 (F : Frame G 3) : c1414.eval F.assign = true := by
  exact Rule.sound F (.path [2, 8, 10, 7, 6, 9, 1, 4, 3, 0, 5]) (by decide +kernel)
def c1415 : CNF.Clause Nat := [(16,false), (27,false), (28,false), (39,false), (4,false), (7,false), (74,false), (88,false), (99,false), (98,false)]
theorem p1415 (F : Frame G 3) : c1415.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 2, 5, 3, 0, 6, 7, 10, 8, 9]) (by decide +kernel)
def c1416 : CNF.Clause Nat := [(7,false), (76,false), (110,false), (99,false), (86,false), (30,false), (27,false), (16,false), (15,false), (39,false)]
theorem p1416 (F : Frame G 3) : c1416.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 9, 10, 8, 7, 2, 4, 1, 3, 5]) (by decide +kernel)
def c1417 : CNF.Clause Nat := [(7,false), (76,false), (110,false), (99,false), (86,false), (19,false), (16,false), (27,false), (26,false), (39,false)]
theorem p1417 (F : Frame G 3) : c1417.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 9, 10, 8, 7, 1, 4, 2, 3, 5]) (by decide +kernel)
def c1418 : CNF.Clause Nat := [(7,false), (29,false), (27,false), (38,false), (39,false), (17,false), (22,false), (110,false), (87,false), (86,false)]
theorem p1418 (F : Frame G 3) : c1418.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 2, 4, 3, 5, 1, 10, 9, 7, 8]) (by decide +kernel)
def c1419 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (7,false), (29,false), (31,false), (86,false), (19,false), (21,false), (110,false)]
theorem p1419 (F : Frame G 3) : c1419.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 0, 6, 2, 8, 7, 1, 9, 10]) (by decide +kernel)
def c1420 : CNF.Clause Nat := [(33,false), (11,false), (4,false), (39,false), (50,false), (16,false), (18,false), (76,false), (87,false), (86,false)]
theorem p1420 (F : Frame G 3) : c1420.eval F.assign = true := by
  exact Rule.sound F (.path [2, 10, 0, 3, 5, 4, 1, 6, 9, 7, 8]) (by decide +kernel)
def c1421 : CNF.Clause Nat := [(7,false), (76,false), (110,false), (22,false), (16,false), (38,false), (39,false), (28,false), (30,false), (86,false)]
theorem p1421 (F : Frame G 3) : c1421.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 9, 10, 1, 4, 3, 5, 2, 7, 8]) (by decide +kernel)
def c1422 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (4,false), (7,false), (76,false), (110,false), (22,false), (19,false), (86,false)]
theorem p1422 (F : Frame G 3) : c1422.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 0, 6, 9, 10, 1, 7, 8]) (by decide +kernel)
def c1423 : CNF.Clause Nat := [(4,false), (7,false), (76,false), (110,false), (33,false), (31,false), (86,false), (19,false), (16,false), (50,false)]
theorem p1423 (F : Frame G 3) : c1423.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 9, 10, 2, 8, 7, 1, 4, 5]) (by decide +kernel)
def c1424 : CNF.Clause Nat := [(31,false), (86,false), (74,false), (7,false), (4,false), (39,false), (50,false), (16,false), (21,false), (110,false)]
theorem p1424 (F : Frame G 3) : c1424.eval F.assign = true := by
  exact Rule.sound F (.path [2, 8, 7, 6, 0, 3, 5, 4, 1, 9, 10]) (by decide +kernel)
def c1425 : CNF.Clause Nat := [(38,false), (50,false), (28,false), (29,false), (7,false), (11,false), (110,false), (21,false), (19,false), (86,false)]
theorem p1425 (F : Frame G 3) : c1425.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 2, 6, 0, 10, 9, 1, 7, 8]) (by decide +kernel)
def c1426 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (4,false), (7,false), (74,false), (86,false), (20,false), (21,false), (110,false)]
theorem p1426 (F : Frame G 3) : c1426.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 0, 6, 7, 8, 1, 9, 10]) (by decide +kernel)
def c1427 : CNF.Clause Nat := [(26,false), (38,false), (50,false), (17,false), (18,false), (74,false), (86,false), (9,false), (10,false), (110,false)]
theorem p1427 (F : Frame G 3) : c1427.eval F.assign = true := by
  exact Rule.sound F (.path [2, 3, 4, 5, 1, 6, 7, 8, 0, 9, 10]) (by decide +kernel)
def c1428 : CNF.Clause Nat := [(7,false), (74,false), (86,false), (31,false), (27,false), (38,false), (39,false), (17,false), (21,false), (110,false)]
theorem p1428 (F : Frame G 3) : c1428.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 7, 8, 2, 4, 3, 5, 1, 9, 10]) (by decide +kernel)
def c1429 : CNF.Clause Nat := [(6,false), (39,false), (38,false), (27,false), (31,false), (20,false), (18,false), (74,false), (87,false), (110,false)]
theorem p1429 (F : Frame G 3) : c1429.eval F.assign = true := by
  exact Rule.sound F (.path [0, 5, 3, 4, 2, 8, 1, 6, 7, 9, 10]) (by decide +kernel)
def c1430 : CNF.Clause Nat := [(5,false), (4,false), (39,false), (28,false), (31,false), (20,false), (18,false), (74,false), (87,false), (110,false)]
theorem p1430 (F : Frame G 3) : c1430.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 3, 5, 2, 8, 1, 6, 7, 9, 10]) (by decide +kernel)
def c1431 : CNF.Clause Nat := [(5,false), (38,false), (39,false), (28,false), (29,false), (74,false), (86,false), (20,false), (21,false), (110,false)]
theorem p1431 (F : Frame G 3) : c1431.eval F.assign = true := by
  exact Rule.sound F (.path [0, 4, 3, 5, 2, 6, 7, 8, 1, 9, 10]) (by decide +kernel)
def c1432 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (4,false), (9,false), (86,false), (74,false), (18,false), (21,false), (110,false)]
theorem p1432 (F : Frame G 3) : c1432.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 0, 8, 7, 6, 1, 9, 10]) (by decide +kernel)
def c1433 : CNF.Clause Nat := [(21,false), (110,false), (88,false), (86,false), (31,false), (29,false), (7,false), (4,false), (38,false), (50,false)]
theorem p1433 (F : Frame G 3) : c1433.eval F.assign = true := by
  exact Rule.sound F (.path [1, 9, 10, 7, 8, 2, 6, 0, 3, 4, 5]) (by decide +kernel)
def c1434 : CNF.Clause Nat := [(28,false), (39,false), (15,false), (16,false), (5,false), (7,false), (76,false), (110,false), (88,false), (86,false)]
theorem p1434 (F : Frame G 3) : c1434.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 1, 4, 0, 6, 9, 10, 7, 8]) (by decide +kernel)
def c1435 : CNF.Clause Nat := [(4,false), (7,false), (75,false), (31,false), (27,false), (50,false), (17,false), (19,false), (88,false), (110,false)]
theorem p1435 (F : Frame G 3) : c1435.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 8, 2, 4, 5, 1, 7, 10, 9]) (by decide +kernel)
def c1436 : CNF.Clause Nat := [(7,false), (29,false), (27,false), (38,false), (39,false), (17,false), (19,false), (86,false), (98,false), (110,false)]
theorem p1436 (F : Frame G 3) : c1436.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 2, 4, 3, 5, 1, 7, 8, 9, 10]) (by decide +kernel)
def c1437 : CNF.Clause Nat := [(7,false), (75,false), (31,false), (27,false), (38,false), (39,false), (17,false), (19,false), (87,false), (110,false)]
theorem p1437 (F : Frame G 3) : c1437.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 8, 2, 4, 3, 5, 1, 7, 9, 10]) (by decide +kernel)
def c1438 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (4,false), (7,false), (76,false), (110,false), (88,false), (19,false), (20,false)]
theorem p1438 (F : Frame G 3) : c1438.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 0, 6, 9, 10, 7, 1, 8]) (by decide +kernel)
def c1439 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (7,false), (29,false), (31,false), (20,false), (19,false), (87,false), (110,false)]
theorem p1439 (F : Frame G 3) : c1439.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 0, 6, 2, 8, 1, 7, 9, 10]) (by decide +kernel)
def c1440 : CNF.Clause Nat := [(38,false), (50,false), (28,false), (31,false), (20,false), (18,false), (7,false), (8,false), (87,false), (110,false)]
theorem p1440 (F : Frame G 3) : c1440.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 2, 8, 1, 6, 0, 7, 9, 10]) (by decide +kernel)
def c1441 : CNF.Clause Nat := [(4,false), (9,false), (75,false), (76,false), (110,false), (33,false), (30,false), (19,false), (16,false), (50,false)]
theorem p1441 (F : Frame G 3) : c1441.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 8, 6, 9, 10, 2, 7, 1, 4, 5]) (by decide +kernel)
def c1442 : CNF.Clause Nat := [(39,false), (38,false), (16,false), (18,false), (7,false), (9,false), (31,false), (30,false), (87,false), (110,false)]
theorem p1442 (F : Frame G 3) : c1442.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 4, 1, 6, 0, 8, 2, 7, 9, 10]) (by decide +kernel)
def c1443 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (7,false), (18,false), (19,false), (30,false), (31,false), (98,false), (110,false)]
theorem p1443 (F : Frame G 3) : c1443.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 4, 0, 6, 1, 7, 2, 8, 9, 10]) (by decide +kernel)
def c1444 : CNF.Clause Nat := [(31,false), (98,false), (76,false), (74,false), (8,false), (11,false), (22,false), (15,false), (38,false), (50,false)]
theorem p1444 (F : Frame G 3) : c1444.eval F.assign = true := by
  exact Rule.sound F (.path [2, 8, 9, 6, 7, 0, 10, 1, 3, 4, 5]) (by decide +kernel)
def c1445 : CNF.Clause Nat := [(31,false), (98,false), (76,false), (74,false), (8,false), (11,false), (22,false), (16,false), (38,false), (39,false)]
theorem p1445 (F : Frame G 3) : c1445.eval F.assign = true := by
  exact Rule.sound F (.path [2, 8, 9, 6, 7, 0, 10, 1, 4, 3, 5]) (by decide +kernel)
def c1446 : CNF.Clause Nat := [(27,false), (38,false), (39,false), (17,false), (19,false), (86,false), (75,false), (7,false), (10,false), (110,false)]
theorem p1446 (F : Frame G 3) : c1446.eval F.assign = true := by
  exact Rule.sound F (.path [2, 4, 3, 5, 1, 7, 8, 6, 0, 9, 10]) (by decide +kernel)
def c1447 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (28,false), (29,false), (7,false), (8,false), (86,false), (98,false), (110,false)]
theorem p1447 (F : Frame G 3) : c1447.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 2, 6, 0, 7, 8, 9, 10]) (by decide +kernel)
def c1448 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (6,false), (7,false), (76,false), (110,false), (33,false), (30,false), (86,false)]
theorem p1448 (F : Frame G 3) : c1448.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 0, 6, 9, 10, 2, 7, 8]) (by decide +kernel)
def c1449 : CNF.Clause Nat := [(27,false), (28,false), (39,false), (4,false), (7,false), (18,false), (19,false), (86,false), (98,false), (110,false)]
theorem p1449 (F : Frame G 3) : c1449.eval F.assign = true := by
  exact Rule.sound F (.path [4, 2, 5, 3, 0, 6, 1, 7, 8, 9, 10]) (by decide +kernel)
def c1450 : CNF.Clause Nat := [(5,false), (4,false), (39,false), (17,false), (19,false), (86,false), (31,false), (29,false), (76,false), (110,false)]
theorem p1450 (F : Frame G 3) : c1450.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 3, 5, 1, 7, 8, 2, 6, 9, 10]) (by decide +kernel)
def c1451 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (28,false), (33,false), (99,false), (75,false), (7,false), (8,false), (87,false)]
theorem p1451 (F : Frame G 3) : c1451.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 2, 10, 8, 6, 0, 7, 9]) (by decide +kernel)
def c1452 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (5,false), (7,false), (18,false), (19,false), (87,false), (98,false), (99,false)]
theorem p1452 (F : Frame G 3) : c1452.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 0, 6, 1, 7, 9, 8, 10]) (by decide +kernel)
def c1453 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (5,false), (7,false), (74,false), (19,false), (22,false), (99,false), (98,false)]
theorem p1453 (F : Frame G 3) : c1453.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 0, 6, 7, 1, 10, 8, 9]) (by decide +kernel)
def c1454 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (5,false), (7,false), (75,false), (99,false), (22,false), (19,false), (87,false)]
theorem p1454 (F : Frame G 3) : c1454.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 0, 6, 8, 10, 1, 7, 9]) (by decide +kernel)
def c1455 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (28,false), (29,false), (7,false), (9,false), (99,false), (88,false), (87,false)]
theorem p1455 (F : Frame G 3) : c1455.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 2, 6, 0, 8, 10, 7, 9]) (by decide +kernel)
def c1456 : CNF.Clause Nat := [(7,false), (77,false), (99,false), (31,false), (30,false), (87,false), (21,false), (15,false), (38,false), (50,false)]
theorem p1456 (F : Frame G 3) : c1456.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 10, 8, 2, 7, 9, 1, 3, 4, 5]) (by decide +kernel)
def c1457 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (6,false), (7,false), (77,false), (99,false), (31,false), (30,false), (87,false)]
theorem p1457 (F : Frame G 3) : c1457.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 0, 6, 10, 8, 2, 7, 9]) (by decide +kernel)
def c1458 : CNF.Clause Nat := [(38,false), (39,false), (28,false), (31,false), (20,false), (18,false), (7,false), (8,false), (88,false), (110,false)]
theorem p1458 (F : Frame G 3) : c1458.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 2, 8, 1, 6, 0, 7, 10, 9]) (by decide +kernel)
def c1459 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (7,false), (18,false), (19,false), (30,false), (31,false), (99,false), (110,false)]
theorem p1459 (F : Frame G 3) : c1459.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 0, 6, 1, 7, 2, 8, 10, 9]) (by decide +kernel)
def c1460 : CNF.Clause Nat := [(39,false), (38,false), (16,false), (19,false), (30,false), (31,false), (99,false), (77,false), (7,false), (10,false)]
theorem p1460 (F : Frame G 3) : c1460.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 4, 1, 7, 2, 8, 10, 6, 0, 9]) (by decide +kernel)
def c1461 : CNF.Clause Nat := [(38,false), (39,false), (28,false), (31,false), (9,false), (7,false), (74,false), (19,false), (21,false), (110,false)]
theorem p1461 (F : Frame G 3) : c1461.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 2, 8, 0, 6, 7, 1, 9, 10]) (by decide +kernel)
def c1462 : CNF.Clause Nat := [(16,false), (18,false), (74,false), (87,false), (110,false), (11,false), (9,false), (31,false), (26,false), (39,false)]
theorem p1462 (F : Frame G 3) : c1462.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 6, 7, 9, 10, 0, 8, 2, 3, 5]) (by decide +kernel)
def c1463 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (28,false), (31,false), (98,false), (110,false), (22,false), (18,false), (74,false)]
theorem p1463 (F : Frame G 3) : c1463.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 2, 8, 9, 10, 1, 6, 7]) (by decide +kernel)
def c1464 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (17,false), (18,false), (74,false), (30,false), (31,false), (98,false), (110,false)]
theorem p1464 (F : Frame G 3) : c1464.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 1, 6, 7, 2, 8, 9, 10]) (by decide +kernel)
def c1465 : CNF.Clause Nat := [(5,false), (4,false), (39,false), (17,false), (19,false), (74,false), (75,false), (31,false), (32,false), (110,false)]
theorem p1465 (F : Frame G 3) : c1465.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 3, 5, 1, 7, 6, 8, 2, 9, 10]) (by decide +kernel)
def c1466 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (17,false), (19,false), (74,false), (75,false), (31,false), (32,false), (110,false)]
theorem p1466 (F : Frame G 3) : c1466.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 1, 7, 6, 8, 2, 9, 10]) (by decide +kernel)
def c1467 : CNF.Clause Nat := [(39,false), (50,false), (16,false), (18,false), (7,false), (10,false), (32,false), (31,false), (86,false), (88,false)]
theorem p1467 (F : Frame G 3) : c1467.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 1, 6, 0, 9, 2, 8, 7, 10]) (by decide +kernel)
def c1468 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (28,false), (31,false), (99,false), (110,false), (10,false), (7,false), (74,false)]
theorem p1468 (F : Frame G 3) : c1468.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 2, 8, 10, 9, 0, 6, 7]) (by decide +kernel)
def c1469 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (8,false), (74,false), (18,false), (20,false), (31,false), (32,false), (110,false)]
theorem p1469 (F : Frame G 3) : c1469.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 0, 7, 6, 1, 8, 2, 9, 10]) (by decide +kernel)
def c1470 : CNF.Clause Nat := [(8,false), (74,false), (75,false), (99,false), (110,false), (21,false), (16,false), (27,false), (26,false), (39,false)]
theorem p1470 (F : Frame G 3) : c1470.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 6, 8, 10, 9, 1, 4, 2, 3, 5]) (by decide +kernel)
def c1471 : CNF.Clause Nat := [(8,false), (74,false), (75,false), (99,false), (110,false), (32,false), (27,false), (16,false), (15,false), (39,false)]
theorem p1471 (F : Frame G 3) : c1471.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 6, 8, 10, 9, 2, 4, 1, 3, 5]) (by decide +kernel)
def c1472 : CNF.Clause Nat := [(27,false), (38,false), (39,false), (17,false), (19,false), (8,false), (7,false), (75,false), (98,false), (110,false)]
theorem p1472 (F : Frame G 3) : c1472.eval F.assign = true := by
  exact Rule.sound F (.path [2, 4, 3, 5, 1, 7, 0, 6, 8, 9, 10]) (by decide +kernel)
def c1473 : CNF.Clause Nat := [(26,false), (28,false), (50,false), (16,false), (20,false), (99,false), (110,false), (10,false), (7,false), (74,false)]
theorem p1473 (F : Frame G 3) : c1473.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 4, 1, 8, 10, 9, 0, 6, 7]) (by decide +kernel)
def c1474 : CNF.Clause Nat := [(28,false), (39,false), (15,false), (16,false), (5,false), (7,false), (74,false), (87,false), (98,false), (99,false)]
theorem p1474 (F : Frame G 3) : c1474.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 1, 4, 0, 6, 7, 9, 8, 10]) (by decide +kernel)
def c1475 : CNF.Clause Nat := [(16,false), (50,false), (28,false), (26,false), (4,false), (7,false), (74,false), (86,false), (98,false), (110,false)]
theorem p1475 (F : Frame G 3) : c1475.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 2, 3, 0, 6, 7, 8, 9, 10]) (by decide +kernel)
def c1476 : CNF.Clause Nat := [(4,false), (6,false), (50,false), (27,false), (31,false), (99,false), (110,false), (87,false), (19,false), (18,false)]
theorem p1476 (F : Frame G 3) : c1476.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 5, 4, 2, 8, 10, 9, 7, 1, 6]) (by decide +kernel)
def c1477 : CNF.Clause Nat := [(16,false), (50,false), (28,false), (26,false), (4,false), (7,false), (74,false), (86,false), (99,false), (110,false)]
theorem p1477 (F : Frame G 3) : c1477.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 2, 3, 0, 6, 7, 8, 10, 9]) (by decide +kernel)
def c1478 : CNF.Clause Nat := [(31,false), (86,false), (74,false), (7,false), (10,false), (110,false), (22,false), (15,false), (39,false), (50,false)]
theorem p1478 (F : Frame G 3) : c1478.eval F.assign = true := by
  exact Rule.sound F (.path [2, 8, 7, 6, 0, 9, 10, 1, 3, 5, 4]) (by decide +kernel)
def c1479 : CNF.Clause Nat := [(31,false), (99,false), (110,false), (87,false), (74,false), (18,false), (15,false), (4,false), (5,false), (50,false)]
theorem p1479 (F : Frame G 3) : c1479.eval F.assign = true := by
  exact Rule.sound F (.path [2, 8, 10, 9, 7, 6, 1, 3, 0, 4, 5]) (by decide +kernel)
def c1480 : CNF.Clause Nat := [(16,false), (50,false), (28,false), (26,false), (4,false), (7,false), (74,false), (87,false), (98,false), (99,false)]
theorem p1480 (F : Frame G 3) : c1480.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 2, 3, 0, 6, 7, 9, 8, 10]) (by decide +kernel)
def c1481 : CNF.Clause Nat := [(10,false), (76,false), (29,false), (27,false), (38,false), (39,false), (17,false), (19,false), (86,false), (99,false)]
theorem p1481 (F : Frame G 3) : c1481.eval F.assign = true := by
  exact Rule.sound F (.path [0, 9, 6, 2, 4, 3, 5, 1, 7, 8, 10]) (by decide +kernel)
def c1482 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (16,false), (19,false), (88,false), (110,false), (10,false), (7,false), (75,false)]
theorem p1482 (F : Frame G 3) : c1482.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 1, 7, 10, 9, 0, 6, 8]) (by decide +kernel)
def c1483 : CNF.Clause Nat := [(5,false), (4,false), (39,false), (17,false), (19,false), (88,false), (110,false), (32,false), (29,false), (75,false)]
theorem p1483 (F : Frame G 3) : c1483.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 3, 5, 1, 7, 10, 9, 2, 6, 8]) (by decide +kernel)
def c1484 : CNF.Clause Nat := [(4,false), (38,false), (16,false), (17,false), (28,false), (30,false), (88,false), (99,false), (75,false), (76,false)]
theorem p1484 (F : Frame G 3) : c1484.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 1, 5, 2, 7, 10, 8, 6, 9]) (by decide +kernel)
def c1485 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (5,false), (7,false), (75,false), (99,false), (88,false), (19,false), (21,false)]
theorem p1485 (F : Frame G 3) : c1485.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 0, 6, 8, 10, 7, 1, 9]) (by decide +kernel)
def c1486 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (20,false), (31,false), (29,false), (7,false), (8,false), (88,false), (110,false)]
theorem p1486 (F : Frame G 3) : c1486.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 1, 8, 2, 6, 0, 7, 10, 9]) (by decide +kernel)
def c1487 : CNF.Clause Nat := [(38,false), (39,false), (28,false), (29,false), (7,false), (9,false), (86,false), (19,false), (21,false), (110,false)]
theorem p1487 (F : Frame G 3) : c1487.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 2, 6, 0, 8, 7, 1, 9, 10]) (by decide +kernel)
def c1488 : CNF.Clause Nat := [(7,false), (77,false), (110,false), (21,false), (16,false), (38,false), (39,false), (28,false), (30,false), (86,false)]
theorem p1488 (F : Frame G 3) : c1488.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 10, 9, 1, 4, 3, 5, 2, 7, 8]) (by decide +kernel)
def c1489 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (28,false), (31,false), (9,false), (8,false), (88,false), (77,false), (76,false)]
theorem p1489 (F : Frame G 3) : c1489.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 2, 8, 0, 7, 10, 6, 9]) (by decide +kernel)
def c1490 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (30,false), (19,false), (18,false), (7,false), (9,false), (99,false), (110,false)]
theorem p1490 (F : Frame G 3) : c1490.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 2, 7, 1, 6, 0, 8, 10, 9]) (by decide +kernel)
def c1491 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (7,false), (18,false), (19,false), (30,false), (31,false), (99,false), (110,false)]
theorem p1491 (F : Frame G 3) : c1491.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 0, 6, 1, 7, 2, 8, 10, 9]) (by decide +kernel)
def c1492 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (16,false), (19,false), (30,false), (29,false), (77,false), (99,false), (98,false)]
theorem p1492 (F : Frame G 3) : c1492.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 1, 7, 2, 6, 10, 8, 9]) (by decide +kernel)
def c1493 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (16,false), (18,false), (77,false), (88,false), (30,false), (31,false), (98,false)]
theorem p1493 (F : Frame G 3) : c1493.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 1, 6, 10, 7, 2, 8, 9]) (by decide +kernel)
def c1494 : CNF.Clause Nat := [(5,false), (4,false), (39,false), (17,false), (20,false), (31,false), (29,false), (77,false), (88,false), (87,false)]
theorem p1494 (F : Frame G 3) : c1494.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 3, 5, 1, 8, 2, 6, 10, 7, 9]) (by decide +kernel)
def c1495 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (4,false), (7,false), (76,false), (32,false), (30,false), (88,false), (99,false)]
theorem p1495 (F : Frame G 3) : c1495.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 0, 6, 9, 2, 7, 10, 8]) (by decide +kernel)
def c1496 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (28,false), (29,false), (76,false), (10,false), (9,false), (86,false), (88,false)]
theorem p1496 (F : Frame G 3) : c1496.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 2, 6, 9, 0, 8, 7, 10]) (by decide +kernel)
def c1497 : CNF.Clause Nat := [(17,false), (50,false), (38,false), (4,false), (7,false), (76,false), (110,false), (88,false), (30,false), (31,false)]
theorem p1497 (F : Frame G 3) : c1497.eval F.assign = true := by
  exact Rule.sound F (.path [1, 5, 4, 3, 0, 6, 9, 10, 7, 2, 8]) (by decide +kernel)
def c1498 : CNF.Clause Nat := [(17,false), (50,false), (38,false), (26,false), (29,false), (76,false), (110,false), (11,false), (8,false), (86,false)]
theorem p1498 (F : Frame G 3) : c1498.eval F.assign = true := by
  exact Rule.sound F (.path [1, 5, 4, 3, 2, 6, 9, 10, 0, 7, 8]) (by decide +kernel)
def c1499 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (15,false), (18,false), (76,false), (10,false), (8,false), (88,false), (99,false)]
theorem p1499 (F : Frame G 3) : c1499.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 1, 6, 9, 0, 7, 10, 8]) (by decide +kernel)
def c1500 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (18,false), (76,false), (32,false), (31,false), (9,false), (8,false), (88,false)]
theorem p1500 (F : Frame G 3) : c1500.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 1, 6, 9, 2, 8, 0, 7, 10]) (by decide +kernel)
end Cert35Steps
end Graffiti199Depleted.Catalogue.OrderEleven
