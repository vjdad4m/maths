import Local35Part4
namespace Graffiti199Depleted.Catalogue.OrderEleven
namespace Cert35Steps
open Std.Sat
set_option maxRecDepth 4096
set_option maxHeartbeats 0
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj]
def c1501 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (28,false), (30,false), (19,false), (21,false), (76,false), (75,false), (99,false)]
theorem p1501 (F : Frame G 3) : c1501.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 2, 7, 1, 9, 6, 8, 10]) (by decide +kernel)
def c1502 : CNF.Clause Nat := [(8,false), (74,false), (76,false), (98,false), (99,false), (33,false), (27,false), (16,false), (15,false), (39,false)]
theorem p1502 (F : Frame G 3) : c1502.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 6, 9, 8, 10, 2, 4, 1, 3, 5]) (by decide +kernel)
def c1503 : CNF.Clause Nat := [(8,false), (74,false), (76,false), (98,false), (99,false), (22,false), (16,false), (27,false), (26,false), (39,false)]
theorem p1503 (F : Frame G 3) : c1503.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 6, 9, 8, 10, 1, 4, 2, 3, 5]) (by decide +kernel)
def c1504 : CNF.Clause Nat := [(5,false), (4,false), (39,false), (28,false), (31,false), (75,false), (74,false), (19,false), (21,false), (110,false)]
theorem p1504 (F : Frame G 3) : c1504.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 3, 5, 2, 8, 6, 7, 1, 9, 10]) (by decide +kernel)
def c1505 : CNF.Clause Nat := [(16,false), (17,false), (39,false), (26,false), (31,false), (98,false), (110,false), (11,false), (7,false), (74,false)]
theorem p1505 (F : Frame G 3) : c1505.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 5, 3, 2, 8, 9, 10, 0, 6, 7]) (by decide +kernel)
def c1506 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (16,false), (20,false), (98,false), (110,false), (11,false), (7,false), (74,false)]
theorem p1506 (F : Frame G 3) : c1506.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 1, 8, 9, 10, 0, 6, 7]) (by decide +kernel)
def c1507 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (16,false), (19,false), (74,false), (7,false), (9,false), (98,false), (110,false)]
theorem p1507 (F : Frame G 3) : c1507.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 1, 7, 6, 0, 8, 9, 10]) (by decide +kernel)
def c1508 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (5,false), (7,false), (74,false), (19,false), (22,false), (110,false), (98,false)]
theorem p1508 (F : Frame G 3) : c1508.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 0, 6, 7, 1, 10, 9, 8]) (by decide +kernel)
def c1509 : CNF.Clause Nat := [(6,false), (39,false), (38,false), (16,false), (19,false), (74,false), (76,false), (110,false), (33,false), (31,false)]
theorem p1509 (F : Frame G 3) : c1509.eval F.assign = true := by
  exact Rule.sound F (.path [0, 5, 3, 4, 1, 7, 6, 9, 10, 2, 8]) (by decide +kernel)
def c1510 : CNF.Clause Nat := [(4,false), (38,false), (16,false), (17,false), (28,false), (30,false), (74,false), (75,false), (99,false), (110,false)]
theorem p1510 (F : Frame G 3) : c1510.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 1, 5, 2, 7, 6, 8, 10, 9]) (by decide +kernel)
def c1511 : CNF.Clause Nat := [(31,false), (99,false), (110,false), (76,false), (7,false), (8,false), (19,false), (16,false), (38,false), (39,false)]
theorem p1511 (F : Frame G 3) : c1511.eval F.assign = true := by
  exact Rule.sound F (.path [2, 8, 10, 9, 6, 0, 7, 1, 4, 3, 5]) (by decide +kernel)
def c1512 : CNF.Clause Nat := [(4,false), (38,false), (27,false), (28,false), (17,false), (19,false), (74,false), (75,false), (99,false), (110,false)]
theorem p1512 (F : Frame G 3) : c1512.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 2, 5, 1, 7, 6, 8, 10, 9]) (by decide +kernel)
def c1513 : CNF.Clause Nat := [(4,false), (26,false), (28,false), (50,false), (16,false), (19,false), (74,false), (75,false), (99,false), (110,false)]
theorem p1513 (F : Frame G 3) : c1513.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 2, 5, 4, 1, 7, 6, 8, 10, 9]) (by decide +kernel)
def c1514 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (28,false), (31,false), (75,false), (74,false), (19,false), (21,false), (110,false)]
theorem p1514 (F : Frame G 3) : c1514.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 2, 8, 6, 7, 1, 9, 10]) (by decide +kernel)
def c1515 : CNF.Clause Nat := [(5,false), (38,false), (39,false), (17,false), (19,false), (30,false), (31,false), (98,false), (76,false), (77,false)]
theorem p1515 (F : Frame G 3) : c1515.eval F.assign = true := by
  exact Rule.sound F (.path [0, 4, 3, 5, 1, 7, 2, 8, 9, 6, 10]) (by decide +kernel)
def c1516 : CNF.Clause Nat := [(4,false), (38,false), (16,false), (17,false), (28,false), (31,false), (98,false), (87,false), (74,false), (77,false)]
theorem p1516 (F : Frame G 3) : c1516.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 1, 5, 2, 8, 9, 7, 6, 10]) (by decide +kernel)
def c1517 : CNF.Clause Nat := [(4,false), (7,false), (29,false), (32,false), (110,false), (99,false), (86,false), (19,false), (16,false), (50,false)]
theorem p1517 (F : Frame G 3) : c1517.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 2, 9, 10, 8, 7, 1, 4, 5]) (by decide +kernel)
def c1518 : CNF.Clause Nat := [(28,false), (39,false), (15,false), (16,false), (5,false), (7,false), (77,false), (88,false), (86,false), (98,false)]
theorem p1518 (F : Frame G 3) : c1518.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 1, 4, 0, 6, 10, 7, 8, 9]) (by decide +kernel)
def c1519 : CNF.Clause Nat := [(26,false), (28,false), (50,false), (5,false), (10,false), (76,false), (77,false), (88,false), (19,false), (20,false)]
theorem p1519 (F : Frame G 3) : c1519.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 4, 0, 9, 6, 10, 7, 1, 8]) (by decide +kernel)
def c1520 : CNF.Clause Nat := [(27,false), (50,false), (39,false), (15,false), (19,false), (88,false), (110,false), (10,false), (7,false), (75,false)]
theorem p1520 (F : Frame G 3) : c1520.eval F.assign = true := by
  exact Rule.sound F (.path [2, 4, 5, 3, 1, 7, 10, 9, 0, 6, 8]) (by decide +kernel)
def c1521 : CNF.Clause Nat := [(31,false), (99,false), (88,false), (74,false), (76,false), (21,false), (15,false), (4,false), (5,false), (50,false)]
theorem p1521 (F : Frame G 3) : c1521.eval F.assign = true := by
  exact Rule.sound F (.path [2, 8, 10, 7, 6, 9, 1, 3, 0, 4, 5]) (by decide +kernel)
def c1522 : CNF.Clause Nat := [(16,false), (50,false), (28,false), (26,false), (4,false), (9,false), (99,false), (88,false), (74,false), (76,false)]
theorem p1522 (F : Frame G 3) : c1522.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 2, 3, 0, 8, 10, 7, 6, 9]) (by decide +kernel)
def c1523 : CNF.Clause Nat := [(26,false), (39,false), (50,false), (16,false), (20,false), (86,false), (88,false), (11,false), (7,false), (76,false)]
theorem p1523 (F : Frame G 3) : c1523.eval F.assign = true := by
  exact Rule.sound F (.path [2, 3, 5, 4, 1, 8, 7, 10, 0, 6, 9]) (by decide +kernel)
def c1524 : CNF.Clause Nat := [(28,false), (17,false), (15,false), (38,false), (5,false), (7,false), (74,false), (87,false), (110,false), (99,false)]
theorem p1524 (F : Frame G 3) : c1524.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 1, 3, 4, 0, 6, 7, 9, 10, 8]) (by decide +kernel)
def c1525 : CNF.Clause Nat := [(15,false), (38,false), (50,false), (28,false), (31,false), (75,false), (74,false), (8,false), (10,false), (110,false)]
theorem p1525 (F : Frame G 3) : c1525.eval F.assign = true := by
  exact Rule.sound F (.path [1, 3, 4, 5, 2, 8, 6, 7, 0, 9, 10]) (by decide +kernel)
def c1526 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (28,false), (29,false), (74,false), (87,false), (10,false), (9,false), (99,false)]
theorem p1526 (F : Frame G 3) : c1526.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 2, 6, 7, 9, 0, 8, 10]) (by decide +kernel)
def c1527 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (15,false), (18,false), (74,false), (87,false), (10,false), (9,false), (99,false)]
theorem p1527 (F : Frame G 3) : c1527.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 1, 6, 7, 9, 0, 8, 10]) (by decide +kernel)
def c1528 : CNF.Clause Nat := [(17,false), (50,false), (38,false), (26,false), (29,false), (74,false), (87,false), (10,false), (9,false), (99,false)]
theorem p1528 (F : Frame G 3) : c1528.eval F.assign = true := by
  exact Rule.sound F (.path [1, 5, 4, 3, 2, 6, 7, 9, 0, 8, 10]) (by decide +kernel)
def c1529 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (4,false), (7,false), (74,false), (19,false), (20,false), (99,false), (110,false)]
theorem p1529 (F : Frame G 3) : c1529.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 0, 6, 7, 1, 8, 10, 9]) (by decide +kernel)
def c1530 : CNF.Clause Nat := [(26,false), (38,false), (50,false), (17,false), (18,false), (74,false), (87,false), (10,false), (9,false), (99,false)]
theorem p1530 (F : Frame G 3) : c1530.eval F.assign = true := by
  exact Rule.sound F (.path [2, 3, 4, 5, 1, 6, 7, 9, 0, 8, 10]) (by decide +kernel)
def c1531 : CNF.Clause Nat := [(5,false), (38,false), (15,false), (17,false), (28,false), (29,false), (77,false), (99,false), (98,false), (87,false)]
theorem p1531 (F : Frame G 3) : c1531.eval F.assign = true := by
  exact Rule.sound F (.path [0, 4, 3, 1, 5, 2, 6, 10, 8, 9, 7]) (by decide +kernel)
def c1532 : CNF.Clause Nat := [(16,false), (50,false), (28,false), (26,false), (4,false), (7,false), (77,false), (88,false), (87,false), (98,false)]
theorem p1532 (F : Frame G 3) : c1532.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 2, 3, 0, 6, 10, 7, 9, 8]) (by decide +kernel)
def c1533 : CNF.Clause Nat := [(6,false), (39,false), (38,false), (27,false), (30,false), (74,false), (76,false), (21,false), (20,false), (99,false)]
theorem p1533 (F : Frame G 3) : c1533.eval F.assign = true := by
  exact Rule.sound F (.path [0, 5, 3, 4, 2, 7, 6, 9, 1, 8, 10]) (by decide +kernel)
def c1534 : CNF.Clause Nat := [(6,false), (39,false), (38,false), (27,false), (30,false), (19,false), (21,false), (76,false), (75,false), (99,false)]
theorem p1534 (F : Frame G 3) : c1534.eval F.assign = true := by
  exact Rule.sound F (.path [0, 5, 3, 4, 2, 7, 1, 9, 6, 8, 10]) (by decide +kernel)
def c1535 : CNF.Clause Nat := [(4,false), (6,false), (50,false), (27,false), (31,false), (20,false), (22,false), (110,false), (76,false), (74,false)]
theorem p1535 (F : Frame G 3) : c1535.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 5, 4, 2, 8, 1, 10, 9, 6, 7]) (by decide +kernel)
def c1536 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (28,false), (31,false), (9,false), (11,false), (110,false), (76,false), (74,false)]
theorem p1536 (F : Frame G 3) : c1536.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 2, 8, 0, 10, 9, 6, 7]) (by decide +kernel)
def c1537 : CNF.Clause Nat := [(17,false), (50,false), (38,false), (26,false), (31,false), (9,false), (11,false), (110,false), (76,false), (74,false)]
theorem p1537 (F : Frame G 3) : c1537.eval F.assign = true := by
  exact Rule.sound F (.path [1, 5, 4, 3, 2, 8, 0, 10, 9, 6, 7]) (by decide +kernel)
def c1538 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (15,false), (22,false), (110,false), (87,false), (74,false), (7,false), (9,false)]
theorem p1538 (F : Frame G 3) : c1538.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 1, 10, 9, 7, 6, 0, 8]) (by decide +kernel)
def c1539 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (28,false), (31,false), (75,false), (74,false), (87,false), (10,false), (11,false)]
theorem p1539 (F : Frame G 3) : c1539.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 2, 8, 6, 7, 9, 0, 10]) (by decide +kernel)
def c1540 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (27,false), (32,false), (110,false), (99,false), (20,false), (18,false), (74,false)]
theorem p1540 (F : Frame G 3) : c1540.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 2, 9, 10, 8, 1, 6, 7]) (by decide +kernel)
def c1541 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (16,false), (19,false), (74,false), (29,false), (31,false), (99,false), (110,false)]
theorem p1541 (F : Frame G 3) : c1541.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 1, 7, 6, 2, 8, 10, 9]) (by decide +kernel)
def c1542 : CNF.Clause Nat := [(16,false), (50,false), (28,false), (26,false), (4,false), (7,false), (74,false), (88,false), (99,false), (98,false)]
theorem p1542 (F : Frame G 3) : c1542.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 2, 3, 0, 6, 7, 10, 8, 9]) (by decide +kernel)
def c1543 : CNF.Clause Nat := [(28,false), (39,false), (4,false), (5,false), (16,false), (19,false), (74,false), (77,false), (99,false), (98,false)]
theorem p1543 (F : Frame G 3) : c1543.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 0, 4, 1, 7, 6, 10, 8, 9]) (by decide +kernel)
def c1544 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (17,false), (19,false), (74,false), (76,false), (110,false), (33,false), (31,false)]
theorem p1544 (F : Frame G 3) : c1544.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 1, 7, 6, 9, 10, 2, 8]) (by decide +kernel)
def c1545 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (4,false), (9,false), (99,false), (22,false), (19,false), (74,false), (76,false)]
theorem p1545 (F : Frame G 3) : c1545.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 0, 8, 10, 1, 7, 6, 9]) (by decide +kernel)
def c1546 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (15,false), (18,false), (76,false), (110,false), (11,false), (8,false), (86,false)]
theorem p1546 (F : Frame G 3) : c1546.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 1, 6, 9, 10, 0, 7, 8]) (by decide +kernel)
def c1547 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (28,false), (30,false), (86,false), (9,false), (7,false), (76,false), (110,false)]
theorem p1547 (F : Frame G 3) : c1547.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 2, 7, 8, 0, 6, 9, 10]) (by decide +kernel)
def c1548 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (28,false), (30,false), (88,false), (99,false), (9,false), (7,false), (76,false)]
theorem p1548 (F : Frame G 3) : c1548.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 2, 7, 10, 8, 0, 6, 9]) (by decide +kernel)
def c1549 : CNF.Clause Nat := [(19,false), (88,false), (110,false), (76,false), (75,false), (9,false), (4,false), (26,false), (27,false), (50,false)]
theorem p1549 (F : Frame G 3) : c1549.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 10, 9, 6, 8, 0, 3, 2, 4, 5]) (by decide +kernel)
def c1550 : CNF.Clause Nat := [(19,false), (88,false), (110,false), (76,false), (75,false), (31,false), (26,false), (4,false), (5,false), (50,false)]
theorem p1550 (F : Frame G 3) : c1550.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 10, 9, 6, 8, 2, 3, 0, 4, 5]) (by decide +kernel)
def c1551 : CNF.Clause Nat := [(26,false), (27,false), (50,false), (17,false), (19,false), (8,false), (9,false), (99,false), (77,false), (76,false)]
theorem p1551 (F : Frame G 3) : c1551.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 4, 5, 1, 7, 0, 8, 10, 6, 9]) (by decide +kernel)
def c1552 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (19,false), (86,false), (9,false), (7,false), (29,false), (32,false), (110,false)]
theorem p1552 (F : Frame G 3) : c1552.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 1, 7, 8, 0, 6, 2, 9, 10]) (by decide +kernel)
def c1553 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (6,false), (7,false), (74,false), (30,false), (31,false), (99,false), (110,false)]
theorem p1553 (F : Frame G 3) : c1553.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 0, 6, 7, 2, 8, 10, 9]) (by decide +kernel)
def c1554 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (15,false), (21,false), (110,false), (99,false), (9,false), (7,false), (74,false)]
theorem p1554 (F : Frame G 3) : c1554.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 1, 9, 10, 8, 0, 6, 7]) (by decide +kernel)
def c1555 : CNF.Clause Nat := [(26,false), (28,false), (50,false), (16,false), (21,false), (110,false), (99,false), (9,false), (7,false), (74,false)]
theorem p1555 (F : Frame G 3) : c1555.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 4, 1, 9, 10, 8, 0, 6, 7]) (by decide +kernel)
def c1556 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (7,false), (29,false), (30,false), (19,false), (20,false), (99,false), (110,false)]
theorem p1556 (F : Frame G 3) : c1556.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 0, 6, 2, 7, 1, 8, 10, 9]) (by decide +kernel)
def c1557 : CNF.Clause Nat := [(19,false), (74,false), (77,false), (110,false), (98,false), (31,false), (26,false), (4,false), (5,false), (50,false)]
theorem p1557 (F : Frame G 3) : c1557.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 6, 10, 9, 8, 2, 3, 0, 4, 5]) (by decide +kernel)
def c1558 : CNF.Clause Nat := [(19,false), (74,false), (77,false), (110,false), (98,false), (9,false), (4,false), (26,false), (27,false), (50,false)]
theorem p1558 (F : Frame G 3) : c1558.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 6, 10, 9, 8, 0, 3, 2, 4, 5]) (by decide +kernel)
def c1559 : CNF.Clause Nat := [(19,false), (74,false), (77,false), (110,false), (98,false), (31,false), (26,false), (4,false), (6,false), (50,false)]
theorem p1559 (F : Frame G 3) : c1559.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 6, 10, 9, 8, 2, 3, 0, 5, 4]) (by decide +kernel)
def c1560 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (17,false), (19,false), (88,false), (77,false), (29,false), (31,false), (98,false)]
theorem p1560 (F : Frame G 3) : c1560.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 1, 7, 10, 6, 2, 8, 9]) (by decide +kernel)
def c1561 : CNF.Clause Nat := [(4,false), (9,false), (75,false), (74,false), (87,false), (110,false), (22,false), (16,false), (27,false), (28,false)]
theorem p1561 (F : Frame G 3) : c1561.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 8, 6, 7, 9, 10, 1, 4, 2, 5]) (by decide +kernel)
def c1562 : CNF.Clause Nat := [(31,false), (98,false), (110,false), (77,false), (74,false), (8,false), (4,false), (15,false), (16,false), (50,false)]
theorem p1562 (F : Frame G 3) : c1562.eval F.assign = true := by
  exact Rule.sound F (.path [2, 8, 9, 10, 6, 7, 0, 3, 1, 4, 5]) (by decide +kernel)
def c1563 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (33,false), (22,false), (19,false), (87,false), (10,false), (7,false), (75,false)]
theorem p1563 (F : Frame G 3) : c1563.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 2, 10, 1, 7, 9, 0, 6, 8]) (by decide +kernel)
def c1564 : CNF.Clause Nat := [(4,false), (7,false), (75,false), (31,false), (27,false), (50,false), (17,false), (19,false), (87,false), (110,false)]
theorem p1564 (F : Frame G 3) : c1564.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 8, 2, 4, 5, 1, 7, 9, 10]) (by decide +kernel)
def c1565 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (7,false), (18,false), (19,false), (30,false), (31,false), (98,false), (110,false)]
theorem p1565 (F : Frame G 3) : c1565.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 0, 6, 1, 7, 2, 8, 9, 10]) (by decide +kernel)
def c1566 : CNF.Clause Nat := [(39,false), (50,false), (16,false), (18,false), (7,false), (9,false), (31,false), (30,false), (87,false), (110,false)]
theorem p1566 (F : Frame G 3) : c1566.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 1, 6, 0, 8, 2, 7, 9, 10]) (by decide +kernel)
def c1567 : CNF.Clause Nat := [(26,false), (39,false), (50,false), (5,false), (7,false), (77,false), (22,false), (19,false), (87,false), (98,false)]
theorem p1567 (F : Frame G 3) : c1567.eval F.assign = true := by
  exact Rule.sound F (.path [2, 3, 5, 4, 0, 6, 10, 1, 7, 9, 8]) (by decide +kernel)
def c1568 : CNF.Clause Nat := [(27,false), (50,false), (39,false), (15,false), (18,false), (7,false), (8,false), (88,false), (99,false), (98,false)]
theorem p1568 (F : Frame G 3) : c1568.eval F.assign = true := by
  exact Rule.sound F (.path [2, 4, 5, 3, 1, 6, 0, 7, 10, 8, 9]) (by decide +kernel)
def c1569 : CNF.Clause Nat := [(38,false), (50,false), (28,false), (32,false), (98,false), (20,false), (18,false), (7,false), (8,false), (88,false)]
theorem p1569 (F : Frame G 3) : c1569.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 2, 9, 8, 1, 6, 0, 7, 10]) (by decide +kernel)
def c1570 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (15,false), (19,false), (8,false), (7,false), (75,false), (98,false), (110,false)]
theorem p1570 (F : Frame G 3) : c1570.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 1, 7, 0, 6, 8, 9, 10]) (by decide +kernel)
def c1571 : CNF.Clause Nat := [(26,false), (28,false), (50,false), (16,false), (18,false), (77,false), (88,false), (8,false), (9,false), (98,false)]
theorem p1571 (F : Frame G 3) : c1571.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 4, 1, 6, 10, 7, 0, 8, 9]) (by decide +kernel)
def c1572 : CNF.Clause Nat := [(26,false), (27,false), (50,false), (17,false), (18,false), (7,false), (9,false), (86,false), (88,false), (110,false)]
theorem p1572 (F : Frame G 3) : c1572.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 4, 5, 1, 6, 0, 8, 7, 10, 9]) (by decide +kernel)
def c1573 : CNF.Clause Nat := [(26,false), (27,false), (50,false), (6,false), (7,false), (77,false), (110,false), (21,false), (19,false), (86,false)]
theorem p1573 (F : Frame G 3) : c1573.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 4, 5, 0, 6, 10, 9, 1, 7, 8]) (by decide +kernel)
def c1574 : CNF.Clause Nat := [(26,false), (27,false), (50,false), (17,false), (20,false), (86,false), (8,false), (7,false), (77,false), (110,false)]
theorem p1574 (F : Frame G 3) : c1574.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 4, 5, 1, 8, 7, 0, 6, 10, 9]) (by decide +kernel)
def c1575 : CNF.Clause Nat := [(4,false), (7,false), (77,false), (110,false), (21,false), (16,false), (50,false), (28,false), (30,false), (86,false)]
theorem p1575 (F : Frame G 3) : c1575.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 10, 9, 1, 4, 5, 2, 7, 8]) (by decide +kernel)
def c1576 : CNF.Clause Nat := [(31,false), (99,false), (110,false), (76,false), (74,false), (8,false), (4,false), (15,false), (16,false), (50,false)]
theorem p1576 (F : Frame G 3) : c1576.eval F.assign = true := by
  exact Rule.sound F (.path [2, 8, 10, 9, 6, 7, 0, 3, 1, 4, 5]) (by decide +kernel)
def c1577 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (15,false), (19,false), (88,false), (110,false), (10,false), (7,false), (75,false)]
theorem p1577 (F : Frame G 3) : c1577.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 1, 7, 10, 9, 0, 6, 8]) (by decide +kernel)
def c1578 : CNF.Clause Nat := [(38,false), (39,false), (28,false), (33,false), (11,false), (7,false), (76,false), (87,false), (19,false), (20,false)]
theorem p1578 (F : Frame G 3) : c1578.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 2, 10, 0, 6, 9, 7, 1, 8]) (by decide +kernel)
def c1579 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (31,false), (75,false), (7,false), (8,false), (19,false), (21,false), (110,false)]
theorem p1579 (F : Frame G 3) : c1579.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 2, 8, 6, 0, 7, 1, 9, 10]) (by decide +kernel)
def c1580 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (19,false), (8,false), (7,false), (75,false), (31,false), (32,false), (110,false)]
theorem p1580 (F : Frame G 3) : c1580.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 1, 7, 0, 6, 8, 2, 9, 10]) (by decide +kernel)
def c1581 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (28,false), (29,false), (7,false), (9,false), (86,false), (87,false), (110,false)]
theorem p1581 (F : Frame G 3) : c1581.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 2, 6, 0, 8, 7, 9, 10]) (by decide +kernel)
def c1582 : CNF.Clause Nat := [(27,false), (28,false), (39,false), (4,false), (7,false), (75,false), (20,false), (19,false), (87,false), (110,false)]
theorem p1582 (F : Frame G 3) : c1582.eval F.assign = true := by
  exact Rule.sound F (.path [4, 2, 5, 3, 0, 6, 8, 1, 7, 9, 10]) (by decide +kernel)
def c1583 : CNF.Clause Nat := [(16,false), (19,false), (8,false), (4,false), (39,false), (28,false), (31,false), (75,false), (76,false), (110,false)]
theorem p1583 (F : Frame G 3) : c1583.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 7, 0, 3, 5, 2, 8, 6, 9, 10]) (by decide +kernel)
def c1584 : CNF.Clause Nat := [(27,false), (38,false), (39,false), (6,false), (8,false), (74,false), (77,false), (22,false), (20,false), (98,false)]
theorem p1584 (F : Frame G 3) : c1584.eval F.assign = true := by
  exact Rule.sound F (.path [2, 4, 3, 5, 0, 7, 6, 10, 1, 8, 9]) (by decide +kernel)
def c1585 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (7,false), (29,false), (31,false), (98,false), (87,false), (19,false), (22,false)]
theorem p1585 (F : Frame G 3) : c1585.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 0, 6, 2, 8, 9, 7, 1, 10]) (by decide +kernel)
def c1586 : CNF.Clause Nat := [(4,false), (5,false), (50,false), (28,false), (29,false), (76,false), (110,false), (22,false), (19,false), (86,false)]
theorem p1586 (F : Frame G 3) : c1586.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 4, 5, 2, 6, 9, 10, 1, 7, 8]) (by decide +kernel)
def c1587 : CNF.Clause Nat := [(18,false), (74,false), (86,false), (31,false), (33,false), (110,false), (10,false), (4,false), (38,false), (50,false)]
theorem p1587 (F : Frame G 3) : c1587.eval F.assign = true := by
  exact Rule.sound F (.path [1, 6, 7, 8, 2, 10, 9, 0, 3, 4, 5]) (by decide +kernel)
def c1588 : CNF.Clause Nat := [(5,false), (4,false), (39,false), (17,false), (19,false), (86,false), (98,false), (110,false), (33,false), (29,false)]
theorem p1588 (F : Frame G 3) : c1588.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 3, 5, 1, 7, 8, 9, 10, 2, 6]) (by decide +kernel)
def c1589 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (16,false), (18,false), (7,false), (9,false), (86,false), (87,false), (110,false)]
theorem p1589 (F : Frame G 3) : c1589.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 1, 6, 0, 8, 7, 9, 10]) (by decide +kernel)
def c1590 : CNF.Clause Nat := [(5,false), (4,false), (39,false), (17,false), (19,false), (87,false), (98,false), (31,false), (29,false), (77,false)]
theorem p1590 (F : Frame G 3) : c1590.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 3, 5, 1, 7, 9, 8, 2, 6, 10]) (by decide +kernel)
def c1591 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (5,false), (9,false), (75,false), (77,false), (22,false), (19,false), (87,false)]
theorem p1591 (F : Frame G 3) : c1591.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 0, 8, 6, 10, 1, 7, 9]) (by decide +kernel)
def c1592 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (5,false), (7,false), (75,false), (20,false), (19,false), (87,false), (110,false)]
theorem p1592 (F : Frame G 3) : c1592.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 0, 6, 8, 1, 7, 9, 10]) (by decide +kernel)
def c1593 : CNF.Clause Nat := [(5,false), (8,false), (9,false), (38,true), (74,true), (75,true), (86,true)]
theorem p1593 (F : Frame G 3) : c1593.eval F.assign = true := by
  apply local_rup F.assign c1593 [c1, c4, c379]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p379 F) (rfl)))
  · decide +kernel
def c1594 : CNF.Clause Nat := [(5,false), (8,false), (10,false), (38,true), (74,true), (76,true), (87,true)]
theorem p1594 (F : Frame G 3) : c1594.eval F.assign = true := by
  apply local_rup F.assign c1594 [c1, c4, c380]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p380 F) (rfl)))
  · decide +kernel
def c1595 : CNF.Clause Nat := [(5,false), (8,false), (11,false), (38,true), (74,true), (77,true), (88,true)]
theorem p1595 (F : Frame G 3) : c1595.eval F.assign = true := by
  apply local_rup F.assign c1595 [c1, c4, c381]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p381 F) (rfl)))
  · decide +kernel
def c1596 : CNF.Clause Nat := [(5,false), (9,false), (10,false), (38,true), (75,true), (76,true), (98,true)]
theorem p1596 (F : Frame G 3) : c1596.eval F.assign = true := by
  apply local_rup F.assign c1596 [c1, c4, c382]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p382 F) (rfl)))
  · decide +kernel
def c1597 : CNF.Clause Nat := [(5,false), (9,false), (11,false), (38,true), (75,true), (77,true), (99,true)]
theorem p1597 (F : Frame G 3) : c1597.eval F.assign = true := by
  apply local_rup F.assign c1597 [c1, c4, c383]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p383 F) (rfl)))
  · decide +kernel
def c1598 : CNF.Clause Nat := [(5,false), (10,false), (11,false), (38,true), (76,true), (77,true), (110,true)]
theorem p1598 (F : Frame G 3) : c1598.eval F.assign = true := by
  apply local_rup F.assign c1598 [c1, c4, c384]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p384 F) (rfl)))
  · decide +kernel
def c1599 : CNF.Clause Nat := [(5,false), (8,false), (9,false), (10,false), (38,true), (86,true), (87,true), (98,true)]
theorem p1599 (F : Frame G 3) : c1599.eval F.assign = true := by
  apply local_rup F.assign c1599 [c1, c385]
  · exact sat_cons (p1 F) ( sat_cons (p385 F) (rfl))
  · decide +kernel
def c1600 : CNF.Clause Nat := [(5,false), (8,false), (9,false), (11,false), (38,true), (86,true), (88,true), (99,true)]
theorem p1600 (F : Frame G 3) : c1600.eval F.assign = true := by
  apply local_rup F.assign c1600 [c1, c386]
  · exact sat_cons (p1 F) ( sat_cons (p386 F) (rfl))
  · decide +kernel
def c1601 : CNF.Clause Nat := [(5,false), (8,false), (10,false), (11,false), (38,true), (87,true), (88,true), (110,true)]
theorem p1601 (F : Frame G 3) : c1601.eval F.assign = true := by
  apply local_rup F.assign c1601 [c1, c387]
  · exact sat_cons (p1 F) ( sat_cons (p387 F) (rfl))
  · decide +kernel
def c1602 : CNF.Clause Nat := [(5,false), (9,false), (10,false), (11,false), (38,true), (98,true), (99,true), (110,true)]
theorem p1602 (F : Frame G 3) : c1602.eval F.assign = true := by
  apply local_rup F.assign c1602 [c1, c388]
  · exact sat_cons (p1 F) ( sat_cons (p388 F) (rfl))
  · decide +kernel
def c1603 : CNF.Clause Nat := [(6,false), (8,false), (9,false), (39,true), (74,true), (75,true), (86,true)]
theorem p1603 (F : Frame G 3) : c1603.eval F.assign = true := by
  apply local_rup F.assign c1603 [c1, c4, c389]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p389 F) (rfl)))
  · decide +kernel
def c1604 : CNF.Clause Nat := [(6,false), (8,false), (10,false), (39,true), (74,true), (76,true), (87,true)]
theorem p1604 (F : Frame G 3) : c1604.eval F.assign = true := by
  apply local_rup F.assign c1604 [c1, c4, c390]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p390 F) (rfl)))
  · decide +kernel
def c1605 : CNF.Clause Nat := [(6,false), (8,false), (11,false), (39,true), (74,true), (77,true), (88,true)]
theorem p1605 (F : Frame G 3) : c1605.eval F.assign = true := by
  apply local_rup F.assign c1605 [c1, c4, c391]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p391 F) (rfl)))
  · decide +kernel
def c1606 : CNF.Clause Nat := [(6,false), (9,false), (10,false), (39,true), (75,true), (76,true), (98,true)]
theorem p1606 (F : Frame G 3) : c1606.eval F.assign = true := by
  apply local_rup F.assign c1606 [c1, c4, c392]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p392 F) (rfl)))
  · decide +kernel
def c1607 : CNF.Clause Nat := [(6,false), (9,false), (11,false), (39,true), (75,true), (77,true), (99,true)]
theorem p1607 (F : Frame G 3) : c1607.eval F.assign = true := by
  apply local_rup F.assign c1607 [c1, c4, c393]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p393 F) (rfl)))
  · decide +kernel
def c1608 : CNF.Clause Nat := [(6,false), (10,false), (11,false), (39,true), (76,true), (77,true), (110,true)]
theorem p1608 (F : Frame G 3) : c1608.eval F.assign = true := by
  apply local_rup F.assign c1608 [c1, c4, c394]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p394 F) (rfl)))
  · decide +kernel
def c1609 : CNF.Clause Nat := [(6,false), (8,false), (9,false), (10,false), (39,true), (86,true), (87,true), (98,true)]
theorem p1609 (F : Frame G 3) : c1609.eval F.assign = true := by
  apply local_rup F.assign c1609 [c1, c395]
  · exact sat_cons (p1 F) ( sat_cons (p395 F) (rfl))
  · decide +kernel
def c1610 : CNF.Clause Nat := [(6,false), (8,false), (9,false), (11,false), (39,true), (86,true), (88,true), (99,true)]
theorem p1610 (F : Frame G 3) : c1610.eval F.assign = true := by
  apply local_rup F.assign c1610 [c1, c396]
  · exact sat_cons (p1 F) ( sat_cons (p396 F) (rfl))
  · decide +kernel
def c1611 : CNF.Clause Nat := [(6,false), (8,false), (10,false), (11,false), (39,true), (87,true), (88,true), (110,true)]
theorem p1611 (F : Frame G 3) : c1611.eval F.assign = true := by
  apply local_rup F.assign c1611 [c1, c397]
  · exact sat_cons (p1 F) ( sat_cons (p397 F) (rfl))
  · decide +kernel
def c1612 : CNF.Clause Nat := [(6,false), (9,false), (10,false), (11,false), (39,true), (98,true), (99,true), (110,true)]
theorem p1612 (F : Frame G 3) : c1612.eval F.assign = true := by
  apply local_rup F.assign c1612 [c1, c398]
  · exact sat_cons (p1 F) ( sat_cons (p398 F) (rfl))
  · decide +kernel
def c1613 : CNF.Clause Nat := [(8,false), (9,false), (10,false), (74,true), (75,true), (76,true), (86,true), (87,true), (98,true)]
theorem p1613 (F : Frame G 3) : c1613.eval F.assign = true := by
  apply local_rup F.assign c1613 [c1, c4, c399]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p399 F) (rfl)))
  · decide +kernel
def c1614 : CNF.Clause Nat := [(8,false), (9,false), (11,false), (74,true), (75,true), (77,true), (86,true), (88,true), (99,true)]
theorem p1614 (F : Frame G 3) : c1614.eval F.assign = true := by
  apply local_rup F.assign c1614 [c1, c4, c400]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p400 F) (rfl)))
  · decide +kernel
def c1615 : CNF.Clause Nat := [(8,false), (10,false), (11,false), (74,true), (76,true), (77,true), (87,true), (88,true), (110,true)]
theorem p1615 (F : Frame G 3) : c1615.eval F.assign = true := by
  apply local_rup F.assign c1615 [c1, c4, c401]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p401 F) (rfl)))
  · decide +kernel
def c1616 : CNF.Clause Nat := [(9,false), (10,false), (11,false), (75,true), (76,true), (77,true), (98,true), (99,true), (110,true)]
theorem p1616 (F : Frame G 3) : c1616.eval F.assign = true := by
  apply local_rup F.assign c1616 [c1, c4, c402]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p402 F) (rfl)))
  · decide +kernel
def c1617 : CNF.Clause Nat := [(8,false), (9,false), (10,false), (11,false), (86,true), (87,true), (88,true), (98,true), (99,true), (110,true)]
theorem p1617 (F : Frame G 3) : c1617.eval F.assign = true := by
  apply local_rup F.assign c1617 [c1, c403]
  · exact sat_cons (p1 F) ( sat_cons (p403 F) (rfl))
  · decide +kernel
def c1618 : CNF.Clause Nat := [(5,false), (6,false), (8,false), (9,false), (50,true), (74,true), (75,true), (86,true)]
theorem p1618 (F : Frame G 3) : c1618.eval F.assign = true := by
  apply local_rup F.assign c1618 [c4, c404]
  · exact sat_cons (p4 F) ( sat_cons (p404 F) (rfl))
  · decide +kernel
def c1619 : CNF.Clause Nat := [(5,false), (6,false), (8,false), (10,false), (50,true), (74,true), (76,true), (87,true)]
theorem p1619 (F : Frame G 3) : c1619.eval F.assign = true := by
  apply local_rup F.assign c1619 [c4, c405]
  · exact sat_cons (p4 F) ( sat_cons (p405 F) (rfl))
  · decide +kernel
def c1620 : CNF.Clause Nat := [(5,false), (6,false), (8,false), (11,false), (50,true), (74,true), (77,true), (88,true)]
theorem p1620 (F : Frame G 3) : c1620.eval F.assign = true := by
  apply local_rup F.assign c1620 [c4, c406]
  · exact sat_cons (p4 F) ( sat_cons (p406 F) (rfl))
  · decide +kernel
def c1621 : CNF.Clause Nat := [(5,false), (6,false), (9,false), (10,false), (50,true), (75,true), (76,true), (98,true)]
theorem p1621 (F : Frame G 3) : c1621.eval F.assign = true := by
  apply local_rup F.assign c1621 [c4, c407]
  · exact sat_cons (p4 F) ( sat_cons (p407 F) (rfl))
  · decide +kernel
def c1622 : CNF.Clause Nat := [(5,false), (6,false), (9,false), (11,false), (50,true), (75,true), (77,true), (99,true)]
theorem p1622 (F : Frame G 3) : c1622.eval F.assign = true := by
  apply local_rup F.assign c1622 [c4, c408]
  · exact sat_cons (p4 F) ( sat_cons (p408 F) (rfl))
  · decide +kernel
def c1623 : CNF.Clause Nat := [(5,false), (6,false), (10,false), (11,false), (50,true), (76,true), (77,true), (110,true)]
theorem p1623 (F : Frame G 3) : c1623.eval F.assign = true := by
  apply local_rup F.assign c1623 [c4, c409]
  · exact sat_cons (p4 F) ( sat_cons (p409 F) (rfl))
  · decide +kernel
def c1624 : CNF.Clause Nat := [(5,false), (8,false), (9,false), (10,false), (74,true), (75,true), (76,true), (86,true), (87,true), (98,true)]
theorem p1624 (F : Frame G 3) : c1624.eval F.assign = true := by
  apply local_rup F.assign c1624 [c4, c414]
  · exact sat_cons (p4 F) ( sat_cons (p414 F) (rfl))
  · decide +kernel
def c1625 : CNF.Clause Nat := [(5,false), (8,false), (10,false), (11,false), (74,true), (76,true), (77,true), (87,true), (88,true), (110,true)]
theorem p1625 (F : Frame G 3) : c1625.eval F.assign = true := by
  apply local_rup F.assign c1625 [c4, c415]
  · exact sat_cons (p4 F) ( sat_cons (p415 F) (rfl))
  · decide +kernel
def c1626 : CNF.Clause Nat := [(5,false), (9,false), (10,false), (11,false), (75,true), (76,true), (77,true), (98,true), (99,true), (110,true)]
theorem p1626 (F : Frame G 3) : c1626.eval F.assign = true := by
  apply local_rup F.assign c1626 [c4, c416]
  · exact sat_cons (p4 F) ( sat_cons (p416 F) (rfl))
  · decide +kernel
def c1627 : CNF.Clause Nat := [(15,false), (18,false), (20,false), (38,true), (74,true), (75,true), (86,true)]
theorem p1627 (F : Frame G 3) : c1627.eval F.assign = true := by
  apply local_rup F.assign c1627 [c2, c5, c417]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p417 F) (rfl)))
  · decide +kernel
def c1628 : CNF.Clause Nat := [(15,false), (18,false), (21,false), (38,true), (74,true), (76,true), (87,true)]
theorem p1628 (F : Frame G 3) : c1628.eval F.assign = true := by
  apply local_rup F.assign c1628 [c2, c5, c418]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p418 F) (rfl)))
  · decide +kernel
def c1629 : CNF.Clause Nat := [(15,false), (18,false), (22,false), (38,true), (74,true), (77,true), (88,true)]
theorem p1629 (F : Frame G 3) : c1629.eval F.assign = true := by
  apply local_rup F.assign c1629 [c2, c5, c419]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p419 F) (rfl)))
  · decide +kernel
def c1630 : CNF.Clause Nat := [(15,false), (18,false), (20,false), (21,false), (38,true), (75,true), (76,true), (98,true)]
theorem p1630 (F : Frame G 3) : c1630.eval F.assign = true := by
  apply local_rup F.assign c1630 [c2, c420]
  · exact sat_cons (p2 F) ( sat_cons (p420 F) (rfl))
  · decide +kernel
def c1631 : CNF.Clause Nat := [(15,false), (18,false), (21,false), (22,false), (38,true), (76,true), (77,true), (110,true)]
theorem p1631 (F : Frame G 3) : c1631.eval F.assign = true := by
  apply local_rup F.assign c1631 [c2, c421]
  · exact sat_cons (p2 F) ( sat_cons (p421 F) (rfl))
  · decide +kernel
def c1632 : CNF.Clause Nat := [(15,false), (20,false), (21,false), (38,true), (86,true), (87,true), (98,true)]
theorem p1632 (F : Frame G 3) : c1632.eval F.assign = true := by
  apply local_rup F.assign c1632 [c2, c5, c422]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p422 F) (rfl)))
  · decide +kernel
def c1633 : CNF.Clause Nat := [(15,false), (20,false), (22,false), (38,true), (86,true), (88,true), (99,true)]
theorem p1633 (F : Frame G 3) : c1633.eval F.assign = true := by
  apply local_rup F.assign c1633 [c2, c5, c423]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p423 F) (rfl)))
  · decide +kernel
def c1634 : CNF.Clause Nat := [(15,false), (21,false), (22,false), (38,true), (87,true), (88,true), (110,true)]
theorem p1634 (F : Frame G 3) : c1634.eval F.assign = true := by
  apply local_rup F.assign c1634 [c2, c5, c424]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p424 F) (rfl)))
  · decide +kernel
def c1635 : CNF.Clause Nat := [(15,false), (20,false), (21,false), (22,false), (38,true), (98,true), (99,true), (110,true)]
theorem p1635 (F : Frame G 3) : c1635.eval F.assign = true := by
  apply local_rup F.assign c1635 [c2, c425]
  · exact sat_cons (p2 F) ( sat_cons (p425 F) (rfl))
  · decide +kernel
def c1636 : CNF.Clause Nat := [(15,false), (17,false), (18,false), (20,false), (39,true), (74,true), (75,true), (86,true)]
theorem p1636 (F : Frame G 3) : c1636.eval F.assign = true := by
  apply local_rup F.assign c1636 [c5, c426]
  · exact sat_cons (p5 F) ( sat_cons (p426 F) (rfl))
  · decide +kernel
def c1637 : CNF.Clause Nat := [(15,false), (17,false), (18,false), (21,false), (39,true), (74,true), (76,true), (87,true)]
theorem p1637 (F : Frame G 3) : c1637.eval F.assign = true := by
  apply local_rup F.assign c1637 [c5, c427]
  · exact sat_cons (p5 F) ( sat_cons (p427 F) (rfl))
  · decide +kernel
def c1638 : CNF.Clause Nat := [(15,false), (17,false), (18,false), (22,false), (39,true), (74,true), (77,true), (88,true)]
theorem p1638 (F : Frame G 3) : c1638.eval F.assign = true := by
  apply local_rup F.assign c1638 [c5, c428]
  · exact sat_cons (p5 F) ( sat_cons (p428 F) (rfl))
  · decide +kernel
def c1639 : CNF.Clause Nat := [(15,false), (17,false), (20,false), (21,false), (39,true), (86,true), (87,true), (98,true)]
theorem p1639 (F : Frame G 3) : c1639.eval F.assign = true := by
  apply local_rup F.assign c1639 [c5, c430]
  · exact sat_cons (p5 F) ( sat_cons (p430 F) (rfl))
  · decide +kernel
def c1640 : CNF.Clause Nat := [(15,false), (17,false), (20,false), (22,false), (39,true), (86,true), (88,true), (99,true)]
theorem p1640 (F : Frame G 3) : c1640.eval F.assign = true := by
  apply local_rup F.assign c1640 [c5, c431]
  · exact sat_cons (p5 F) ( sat_cons (p431 F) (rfl))
  · decide +kernel
def c1641 : CNF.Clause Nat := [(15,false), (17,false), (21,false), (22,false), (39,true), (87,true), (88,true), (110,true)]
theorem p1641 (F : Frame G 3) : c1641.eval F.assign = true := by
  apply local_rup F.assign c1641 [c5, c432]
  · exact sat_cons (p5 F) ( sat_cons (p432 F) (rfl))
  · decide +kernel
def c1642 : CNF.Clause Nat := [(17,false), (18,false), (20,false), (50,true), (74,true), (75,true), (86,true)]
theorem p1642 (F : Frame G 3) : c1642.eval F.assign = true := by
  apply local_rup F.assign c1642 [c2, c5, c433]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p433 F) (rfl)))
  · decide +kernel
def c1643 : CNF.Clause Nat := [(17,false), (18,false), (21,false), (50,true), (74,true), (76,true), (87,true)]
theorem p1643 (F : Frame G 3) : c1643.eval F.assign = true := by
  apply local_rup F.assign c1643 [c2, c5, c434]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p434 F) (rfl)))
  · decide +kernel
def c1644 : CNF.Clause Nat := [(17,false), (18,false), (22,false), (50,true), (74,true), (77,true), (88,true)]
theorem p1644 (F : Frame G 3) : c1644.eval F.assign = true := by
  apply local_rup F.assign c1644 [c2, c5, c435]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p435 F) (rfl)))
  · decide +kernel
def c1645 : CNF.Clause Nat := [(17,false), (18,false), (20,false), (21,false), (50,true), (75,true), (76,true), (98,true)]
theorem p1645 (F : Frame G 3) : c1645.eval F.assign = true := by
  apply local_rup F.assign c1645 [c2, c436]
  · exact sat_cons (p2 F) ( sat_cons (p436 F) (rfl))
  · decide +kernel
def c1646 : CNF.Clause Nat := [(17,false), (18,false), (20,false), (22,false), (50,true), (75,true), (77,true), (99,true)]
theorem p1646 (F : Frame G 3) : c1646.eval F.assign = true := by
  apply local_rup F.assign c1646 [c2, c437]
  · exact sat_cons (p2 F) ( sat_cons (p437 F) (rfl))
  · decide +kernel
def c1647 : CNF.Clause Nat := [(17,false), (18,false), (21,false), (22,false), (50,true), (76,true), (77,true), (110,true)]
theorem p1647 (F : Frame G 3) : c1647.eval F.assign = true := by
  apply local_rup F.assign c1647 [c2, c438]
  · exact sat_cons (p2 F) ( sat_cons (p438 F) (rfl))
  · decide +kernel
def c1648 : CNF.Clause Nat := [(17,false), (20,false), (21,false), (50,true), (86,true), (87,true), (98,true)]
theorem p1648 (F : Frame G 3) : c1648.eval F.assign = true := by
  apply local_rup F.assign c1648 [c2, c5, c439]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p439 F) (rfl)))
  · decide +kernel
def c1649 : CNF.Clause Nat := [(17,false), (20,false), (22,false), (50,true), (86,true), (88,true), (99,true)]
theorem p1649 (F : Frame G 3) : c1649.eval F.assign = true := by
  apply local_rup F.assign c1649 [c2, c5, c440]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p440 F) (rfl)))
  · decide +kernel
def c1650 : CNF.Clause Nat := [(17,false), (21,false), (22,false), (50,true), (87,true), (88,true), (110,true)]
theorem p1650 (F : Frame G 3) : c1650.eval F.assign = true := by
  apply local_rup F.assign c1650 [c2, c5, c441]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p441 F) (rfl)))
  · decide +kernel
def c1651 : CNF.Clause Nat := [(17,false), (20,false), (21,false), (22,false), (50,true), (98,true), (99,true), (110,true)]
theorem p1651 (F : Frame G 3) : c1651.eval F.assign = true := by
  apply local_rup F.assign c1651 [c2, c442]
  · exact sat_cons (p2 F) ( sat_cons (p442 F) (rfl))
  · decide +kernel
def c1652 : CNF.Clause Nat := [(18,false), (20,false), (21,false), (74,true), (75,true), (76,true), (86,true), (87,true), (98,true)]
theorem p1652 (F : Frame G 3) : c1652.eval F.assign = true := by
  apply local_rup F.assign c1652 [c2, c5, c443]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p443 F) (rfl)))
  · decide +kernel
def c1653 : CNF.Clause Nat := [(18,false), (20,false), (22,false), (74,true), (75,true), (77,true), (86,true), (88,true), (99,true)]
theorem p1653 (F : Frame G 3) : c1653.eval F.assign = true := by
  apply local_rup F.assign c1653 [c2, c5, c444]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p444 F) (rfl)))
  · decide +kernel
def c1654 : CNF.Clause Nat := [(18,false), (21,false), (22,false), (74,true), (76,true), (77,true), (87,true), (88,true), (110,true)]
theorem p1654 (F : Frame G 3) : c1654.eval F.assign = true := by
  apply local_rup F.assign c1654 [c2, c5, c445]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p445 F) (rfl)))
  · decide +kernel
def c1655 : CNF.Clause Nat := [(18,false), (20,false), (21,false), (22,false), (75,true), (76,true), (77,true), (98,true), (99,true), (110,true)]
theorem p1655 (F : Frame G 3) : c1655.eval F.assign = true := by
  apply local_rup F.assign c1655 [c2, c446]
  · exact sat_cons (p2 F) ( sat_cons (p446 F) (rfl))
  · decide +kernel
def c1656 : CNF.Clause Nat := [(20,false), (21,false), (22,false), (86,true), (87,true), (88,true), (98,true), (99,true), (110,true)]
theorem p1656 (F : Frame G 3) : c1656.eval F.assign = true := by
  apply local_rup F.assign c1656 [c2, c5, c447]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p447 F) (rfl)))
  · decide +kernel
def c1657 : CNF.Clause Nat := [(17,false), (18,false), (20,false), (22,false), (74,true), (75,true), (77,true), (86,true), (88,true), (99,true)]
theorem p1657 (F : Frame G 3) : c1657.eval F.assign = true := by
  apply local_rup F.assign c1657 [c5, c448]
  · exact sat_cons (p5 F) ( sat_cons (p448 F) (rfl))
  · decide +kernel
def c1658 : CNF.Clause Nat := [(26,false), (27,false), (29,false), (30,false), (38,true), (74,true), (75,true), (86,true)]
theorem p1658 (F : Frame G 3) : c1658.eval F.assign = true := by
  apply local_rup F.assign c1658 [c6, c449]
  · exact sat_cons (p6 F) ( sat_cons (p449 F) (rfl))
  · decide +kernel
def c1659 : CNF.Clause Nat := [(26,false), (27,false), (29,false), (32,false), (38,true), (75,true), (76,true), (98,true)]
theorem p1659 (F : Frame G 3) : c1659.eval F.assign = true := by
  apply local_rup F.assign c1659 [c6, c450]
  · exact sat_cons (p6 F) ( sat_cons (p450 F) (rfl))
  · decide +kernel
def c1660 : CNF.Clause Nat := [(26,false), (27,false), (30,false), (32,false), (38,true), (86,true), (87,true), (98,true)]
theorem p1660 (F : Frame G 3) : c1660.eval F.assign = true := by
  apply local_rup F.assign c1660 [c6, c451]
  · exact sat_cons (p6 F) ( sat_cons (p451 F) (rfl))
  · decide +kernel
def c1661 : CNF.Clause Nat := [(26,false), (27,false), (30,false), (33,false), (38,true), (86,true), (88,true), (99,true)]
theorem p1661 (F : Frame G 3) : c1661.eval F.assign = true := by
  apply local_rup F.assign c1661 [c6, c452]
  · exact sat_cons (p6 F) ( sat_cons (p452 F) (rfl))
  · decide +kernel
def c1662 : CNF.Clause Nat := [(26,false), (27,false), (32,false), (33,false), (38,true), (98,true), (99,true), (110,true)]
theorem p1662 (F : Frame G 3) : c1662.eval F.assign = true := by
  apply local_rup F.assign c1662 [c6, c453]
  · exact sat_cons (p6 F) ( sat_cons (p453 F) (rfl))
  · decide +kernel
def c1663 : CNF.Clause Nat := [(26,false), (29,false), (30,false), (39,true), (74,true), (75,true), (86,true)]
theorem p1663 (F : Frame G 3) : c1663.eval F.assign = true := by
  apply local_rup F.assign c1663 [c3, c6, c454]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p454 F) (rfl)))
  · decide +kernel
def c1664 : CNF.Clause Nat := [(26,false), (29,false), (30,false), (32,false), (39,true), (74,true), (76,true), (87,true)]
theorem p1664 (F : Frame G 3) : c1664.eval F.assign = true := by
  apply local_rup F.assign c1664 [c3, c455]
  · exact sat_cons (p3 F) ( sat_cons (p455 F) (rfl))
  · decide +kernel
def c1665 : CNF.Clause Nat := [(26,false), (29,false), (30,false), (33,false), (39,true), (74,true), (77,true), (88,true)]
theorem p1665 (F : Frame G 3) : c1665.eval F.assign = true := by
  apply local_rup F.assign c1665 [c3, c456]
  · exact sat_cons (p3 F) ( sat_cons (p456 F) (rfl))
  · decide +kernel
def c1666 : CNF.Clause Nat := [(26,false), (29,false), (32,false), (39,true), (75,true), (76,true), (98,true)]
theorem p1666 (F : Frame G 3) : c1666.eval F.assign = true := by
  apply local_rup F.assign c1666 [c3, c6, c457]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p457 F) (rfl)))
  · decide +kernel
def c1667 : CNF.Clause Nat := [(26,false), (29,false), (33,false), (39,true), (75,true), (77,true), (99,true)]
theorem p1667 (F : Frame G 3) : c1667.eval F.assign = true := by
  apply local_rup F.assign c1667 [c3, c6, c458]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p458 F) (rfl)))
  · decide +kernel
def c1668 : CNF.Clause Nat := [(26,false), (30,false), (32,false), (39,true), (86,true), (87,true), (98,true)]
theorem p1668 (F : Frame G 3) : c1668.eval F.assign = true := by
  apply local_rup F.assign c1668 [c3, c6, c459]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p459 F) (rfl)))
  · decide +kernel
def c1669 : CNF.Clause Nat := [(26,false), (30,false), (33,false), (39,true), (86,true), (88,true), (99,true)]
theorem p1669 (F : Frame G 3) : c1669.eval F.assign = true := by
  apply local_rup F.assign c1669 [c3, c6, c460]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p460 F) (rfl)))
  · decide +kernel
def c1670 : CNF.Clause Nat := [(26,false), (30,false), (32,false), (33,false), (39,true), (87,true), (88,true), (110,true)]
theorem p1670 (F : Frame G 3) : c1670.eval F.assign = true := by
  apply local_rup F.assign c1670 [c3, c461]
  · exact sat_cons (p3 F) ( sat_cons (p461 F) (rfl))
  · decide +kernel
def c1671 : CNF.Clause Nat := [(26,false), (32,false), (33,false), (39,true), (98,true), (99,true), (110,true)]
theorem p1671 (F : Frame G 3) : c1671.eval F.assign = true := by
  apply local_rup F.assign c1671 [c3, c6, c462]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p462 F) (rfl)))
  · decide +kernel
def c1672 : CNF.Clause Nat := [(27,false), (29,false), (30,false), (50,true), (74,true), (75,true), (86,true)]
theorem p1672 (F : Frame G 3) : c1672.eval F.assign = true := by
  apply local_rup F.assign c1672 [c3, c6, c463]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p463 F) (rfl)))
  · decide +kernel
def c1673 : CNF.Clause Nat := [(27,false), (29,false), (30,false), (33,false), (50,true), (74,true), (77,true), (88,true)]
theorem p1673 (F : Frame G 3) : c1673.eval F.assign = true := by
  apply local_rup F.assign c1673 [c3, c464]
  · exact sat_cons (p3 F) ( sat_cons (p464 F) (rfl))
  · decide +kernel
def c1674 : CNF.Clause Nat := [(27,false), (29,false), (32,false), (50,true), (75,true), (76,true), (98,true)]
theorem p1674 (F : Frame G 3) : c1674.eval F.assign = true := by
  apply local_rup F.assign c1674 [c3, c6, c465]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p465 F) (rfl)))
  · decide +kernel
def c1675 : CNF.Clause Nat := [(27,false), (29,false), (33,false), (50,true), (75,true), (77,true), (99,true)]
theorem p1675 (F : Frame G 3) : c1675.eval F.assign = true := by
  apply local_rup F.assign c1675 [c3, c6, c466]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p466 F) (rfl)))
  · decide +kernel
def c1676 : CNF.Clause Nat := [(27,false), (29,false), (32,false), (33,false), (50,true), (76,true), (77,true), (110,true)]
theorem p1676 (F : Frame G 3) : c1676.eval F.assign = true := by
  apply local_rup F.assign c1676 [c3, c467]
  · exact sat_cons (p3 F) ( sat_cons (p467 F) (rfl))
  · decide +kernel
def c1677 : CNF.Clause Nat := [(27,false), (30,false), (32,false), (50,true), (86,true), (87,true), (98,true)]
theorem p1677 (F : Frame G 3) : c1677.eval F.assign = true := by
  apply local_rup F.assign c1677 [c3, c6, c468]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p468 F) (rfl)))
  · decide +kernel
def c1678 : CNF.Clause Nat := [(27,false), (30,false), (33,false), (50,true), (86,true), (88,true), (99,true)]
theorem p1678 (F : Frame G 3) : c1678.eval F.assign = true := by
  apply local_rup F.assign c1678 [c3, c6, c469]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p469 F) (rfl)))
  · decide +kernel
def c1679 : CNF.Clause Nat := [(27,false), (30,false), (32,false), (33,false), (50,true), (87,true), (88,true), (110,true)]
theorem p1679 (F : Frame G 3) : c1679.eval F.assign = true := by
  apply local_rup F.assign c1679 [c3, c470]
  · exact sat_cons (p3 F) ( sat_cons (p470 F) (rfl))
  · decide +kernel
def c1680 : CNF.Clause Nat := [(27,false), (32,false), (33,false), (50,true), (98,true), (99,true), (110,true)]
theorem p1680 (F : Frame G 3) : c1680.eval F.assign = true := by
  apply local_rup F.assign c1680 [c3, c6, c471]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p471 F) (rfl)))
  · decide +kernel
def c1681 : CNF.Clause Nat := [(27,false), (29,false), (32,false), (33,false), (75,true), (76,true), (77,true), (98,true), (99,true), (110,true)]
theorem p1681 (F : Frame G 3) : c1681.eval F.assign = true := by
  apply local_rup F.assign c1681 [c6, c472]
  · exact sat_cons (p6 F) ( sat_cons (p472 F) (rfl))
  · decide +kernel
def c1682 : CNF.Clause Nat := [(29,false), (30,false), (32,false), (74,true), (75,true), (76,true), (86,true), (87,true), (98,true)]
theorem p1682 (F : Frame G 3) : c1682.eval F.assign = true := by
  apply local_rup F.assign c1682 [c3, c6, c473]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p473 F) (rfl)))
  · decide +kernel
def c1683 : CNF.Clause Nat := [(29,false), (30,false), (33,false), (74,true), (75,true), (77,true), (86,true), (88,true), (99,true)]
theorem p1683 (F : Frame G 3) : c1683.eval F.assign = true := by
  apply local_rup F.assign c1683 [c3, c6, c474]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p474 F) (rfl)))
  · decide +kernel
def c1684 : CNF.Clause Nat := [(29,false), (30,false), (32,false), (33,false), (74,true), (76,true), (77,true), (87,true), (88,true), (110,true)]
theorem p1684 (F : Frame G 3) : c1684.eval F.assign = true := by
  apply local_rup F.assign c1684 [c3, c475]
  · exact sat_cons (p3 F) ( sat_cons (p475 F) (rfl))
  · decide +kernel
def c1685 : CNF.Clause Nat := [(29,false), (32,false), (33,false), (75,true), (76,true), (77,true), (98,true), (99,true), (110,true)]
theorem p1685 (F : Frame G 3) : c1685.eval F.assign = true := by
  apply local_rup F.assign c1685 [c3, c6, c476]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p476 F) (rfl)))
  · decide +kernel
def c1686 : CNF.Clause Nat := [(30,false), (32,false), (33,false), (86,true), (87,true), (88,true), (98,true), (99,true), (110,true)]
theorem p1686 (F : Frame G 3) : c1686.eval F.assign = true := by
  apply local_rup F.assign c1686 [c3, c6, c477]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p477 F) (rfl)))
  · decide +kernel
def c1687 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (18,false), (30,false), (98,false), (110,false)]
theorem p1687 (F : Frame G 3) : c1687.eval F.assign = true := by
  apply local_rup F.assign c1687 [c4, c5, c6, c478]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p478 F) (rfl))))
  · decide +kernel
def c1688 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (8,false), (21,false), (32,false), (29,false), (75,false), (99,false)]
theorem p1688 (F : Frame G 3) : c1688.eval F.assign = true := by
  apply local_rup F.assign c1688 [c5, c479]
  · exact sat_cons (p5 F) ( sat_cons (p479 F) (rfl))
  · decide +kernel
def c1689 : CNF.Clause Nat := [(76,false), (87,false), (38,false), (39,false), (99,false)]
theorem p1689 (F : Frame G 3) : c1689.eval F.assign = true := by
  apply local_rup F.assign c1689 [c4, c5, c2, c3, c6, c480]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p480 F) (rfl))))))
  · decide +kernel
def c1690 : CNF.Clause Nat := [(5,false), (50,false), (17,false), (30,false), (29,false), (75,false), (98,false), (110,false)]
theorem p1690 (F : Frame G 3) : c1690.eval F.assign = true := by
  apply local_rup F.assign c1690 [c1, c5, c481]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p481 F) (rfl)))
  · decide +kernel
def c1691 : CNF.Clause Nat := [(50,false), (6,false), (15,false), (30,false), (29,false), (75,false), (98,false), (110,false)]
theorem p1691 (F : Frame G 3) : c1691.eval F.assign = true := by
  apply local_rup F.assign c1691 [c1, c5, c482]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p482 F) (rfl)))
  · decide +kernel
def c1692 : CNF.Clause Nat := [(39,false), (50,false), (30,false), (29,false), (75,false), (98,false), (110,false)]
theorem p1692 (F : Frame G 3) : c1692.eval F.assign = true := by
  apply local_rup F.assign c1692 [c1, c2, c5, c483]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p483 F) (rfl))))
  · decide +kernel
def c1693 : CNF.Clause Nat := [(5,false), (50,false), (30,false), (18,false), (75,false), (98,false), (110,false)]
theorem p1693 (F : Frame G 3) : c1693.eval F.assign = true := by
  apply local_rup F.assign c1693 [c1, c3, c5, c484]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p484 F) (rfl))))
  · decide +kernel
def c1694 : CNF.Clause Nat := [(5,false), (50,false), (17,false), (30,false), (75,false), (76,false), (110,false)]
theorem p1694 (F : Frame G 3) : c1694.eval F.assign = true := by
  apply local_rup F.assign c1694 [c1, c5, c6, c485]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p485 F) (rfl))))
  · decide +kernel
def c1695 : CNF.Clause Nat := [(50,false), (6,false), (15,false), (30,false), (75,false), (76,false), (110,false)]
theorem p1695 (F : Frame G 3) : c1695.eval F.assign = true := by
  apply local_rup F.assign c1695 [c1, c5, c6, c486]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p486 F) (rfl))))
  · decide +kernel
def c1696 : CNF.Clause Nat := [(39,false), (50,false), (30,false), (75,false), (76,false), (110,false)]
theorem p1696 (F : Frame G 3) : c1696.eval F.assign = true := by
  apply local_rup F.assign c1696 [c1, c2, c5, c6, c487]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p487 F) (rfl)))))
  · decide +kernel
def c1697 : CNF.Clause Nat := [(50,false), (6,false), (15,false), (74,false), (29,false), (98,false), (110,false)]
theorem p1697 (F : Frame G 3) : c1697.eval F.assign = true := by
  apply local_rup F.assign c1697 [c1, c5, c6, c488]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p488 F) (rfl))))
  · decide +kernel
def c1698 : CNF.Clause Nat := [(39,false), (50,false), (74,false), (29,false), (98,false), (110,false)]
theorem p1698 (F : Frame G 3) : c1698.eval F.assign = true := by
  apply local_rup F.assign c1698 [c1, c2, c5, c6, c489]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p489 F) (rfl)))))
  · decide +kernel
def c1699 : CNF.Clause Nat := [(5,false), (50,false), (20,false), (18,false), (74,false), (87,false), (110,false)]
theorem p1699 (F : Frame G 3) : c1699.eval F.assign = true := by
  apply local_rup F.assign c1699 [c1, c3, c6, c490]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p490 F) (rfl))))
  · decide +kernel
def c1700 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (20,false), (18,false), (74,false), (87,false), (110,false)]
theorem p1700 (F : Frame G 3) : c1700.eval F.assign = true := by
  apply local_rup F.assign c1700 [c1, c6, c491]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p491 F) (rfl)))
  · decide +kernel
def c1701 : CNF.Clause Nat := [(5,false), (50,false), (20,false), (74,false), (76,false), (110,false)]
theorem p1701 (F : Frame G 3) : c1701.eval F.assign = true := by
  apply local_rup F.assign c1701 [c1, c3, c6, c5, c492]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p492 F) (rfl)))))
  · decide +kernel
def c1702 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (20,false), (74,false), (76,false), (110,false)]
theorem p1702 (F : Frame G 3) : c1702.eval F.assign = true := by
  apply local_rup F.assign c1702 [c1, c6, c5, c493]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p493 F) (rfl))))
  · decide +kernel
def c1703 : CNF.Clause Nat := [(5,false), (50,false), (75,false), (18,false), (87,false), (110,false)]
theorem p1703 (F : Frame G 3) : c1703.eval F.assign = true := by
  apply local_rup F.assign c1703 [c1, c3, c6, c5, c494]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p494 F) (rfl)))))
  · decide +kernel
def c1704 : CNF.Clause Nat := [(50,false), (6,false), (26,false), (75,false), (18,false), (87,false), (110,false)]
theorem p1704 (F : Frame G 3) : c1704.eval F.assign = true := by
  apply local_rup F.assign c1704 [c1, c6, c5, c495]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p495 F) (rfl))))
  · decide +kernel
def c1705 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (75,false), (18,false), (87,false), (110,false)]
theorem p1705 (F : Frame G 3) : c1705.eval F.assign = true := by
  apply local_rup F.assign c1705 [c1, c6, c5, c496]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p496 F) (rfl))))
  · decide +kernel
def c1706 : CNF.Clause Nat := [(50,false), (6,false), (15,false), (74,false), (75,false), (32,false), (110,false)]
theorem p1706 (F : Frame G 3) : c1706.eval F.assign = true := by
  apply local_rup F.assign c1706 [c1, c5, c6, c497]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p497 F) (rfl))))
  · decide +kernel
def c1707 : CNF.Clause Nat := [(39,false), (50,false), (74,false), (75,false), (32,false), (110,false)]
theorem p1707 (F : Frame G 3) : c1707.eval F.assign = true := by
  apply local_rup F.assign c1707 [c1, c2, c5, c6, c498]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p498 F) (rfl)))))
  · decide +kernel
def c1708 : CNF.Clause Nat := [(27,false), (26,false), (39,false), (6,false), (75,false), (86,false), (21,false), (110,false)]
theorem p1708 (F : Frame G 3) : c1708.eval F.assign = true := by
  apply local_rup F.assign c1708 [c4, c5, c499]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p499 F) (rfl)))
  · decide +kernel
def c1709 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (75,false), (74,false), (21,false), (110,false)]
theorem p1709 (F : Frame G 3) : c1709.eval F.assign = true := by
  apply local_rup F.assign c1709 [c1, c6, c5, c500]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p500 F) (rfl))))
  · decide +kernel
def c1710 : CNF.Clause Nat := [(15,false), (50,false), (98,false), (76,false), (8,false), (88,false)]
theorem p1710 (F : Frame G 3) : c1710.eval F.assign = true := by
  apply local_rup F.assign c1710 [c2, c3, c6, c4, c501]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p501 F) (rfl)))))
  · decide +kernel
def c1711 : CNF.Clause Nat := [(39,false), (50,false), (74,false), (76,false), (98,false), (33,false)]
theorem p1711 (F : Frame G 3) : c1711.eval F.assign = true := by
  apply local_rup F.assign c1711 [c1, c2, c5, c6, c502]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p502 F) (rfl)))))
  · decide +kernel
def c1712 : CNF.Clause Nat := [(38,false), (39,false), (9,false), (8,false), (21,false), (76,false), (77,false)]
theorem p1712 (F : Frame G 3) : c1712.eval F.assign = true := by
  apply local_rup F.assign c1712 [c3, c6, c5, c503]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p503 F) (rfl))))
  · decide +kernel
def c1713 : CNF.Clause Nat := [(38,false), (39,false), (20,false), (8,false), (10,false), (76,false), (77,false)]
theorem p1713 (F : Frame G 3) : c1713.eval F.assign = true := by
  apply local_rup F.assign c1713 [c3, c6, c5, c504]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p504 F) (rfl))))
  · decide +kernel
def c1714 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (30,false), (9,false), (10,false), (76,false), (77,false)]
theorem p1714 (F : Frame G 3) : c1714.eval F.assign = true := by
  apply local_rup F.assign c1714 [c5, c6, c505]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p505 F) (rfl)))
  · decide +kernel
def c1715 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (10,false), (21,false), (20,false), (29,false), (74,false), (88,false)]
theorem p1715 (F : Frame G 3) : c1715.eval F.assign = true := by
  apply local_rup F.assign c1715 [c6, c506]
  · exact sat_cons (p6 F) ( sat_cons (p506 F) (rfl))
  · decide +kernel
def c1716 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (11,false), (22,false), (30,false), (29,false), (75,false), (98,false)]
theorem p1716 (F : Frame G 3) : c1716.eval F.assign = true := by
  apply local_rup F.assign c1716 [c5, c507]
  · exact sat_cons (p5 F) ( sat_cons (p507 F) (rfl))
  · decide +kernel
def c1717 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (76,false), (21,false), (30,false), (99,false)]
theorem p1717 (F : Frame G 3) : c1717.eval F.assign = true := by
  apply local_rup F.assign c1717 [c4, c5, c6, c509]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p509 F) (rfl))))
  · decide +kernel
def c1718 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (76,false), (21,false), (20,false), (30,false), (88,false)]
theorem p1718 (F : Frame G 3) : c1718.eval F.assign = true := by
  apply local_rup F.assign c1718 [c4, c6, c510]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p510 F) (rfl)))
  · decide +kernel
def c1719 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (74,false), (20,false), (32,false), (110,false)]
theorem p1719 (F : Frame G 3) : c1719.eval F.assign = true := by
  apply local_rup F.assign c1719 [c4, c5, c6, c511]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p511 F) (rfl))))
  · decide +kernel
def c1720 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (10,false), (21,false), (30,false), (75,false), (77,false)]
theorem p1720 (F : Frame G 3) : c1720.eval F.assign = true := by
  apply local_rup F.assign c1720 [c5, c6, c512]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p512 F) (rfl)))
  · decide +kernel
def c1721 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (8,false), (20,false), (32,false), (76,false), (77,false)]
theorem p1721 (F : Frame G 3) : c1721.eval F.assign = true := by
  apply local_rup F.assign c1721 [c5, c6, c513]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p513 F) (rfl)))
  · decide +kernel
def c1722 : CNF.Clause Nat := [(39,false), (38,false), (8,false), (9,false), (32,false), (76,false), (77,false)]
theorem p1722 (F : Frame G 3) : c1722.eval F.assign = true := by
  apply local_rup F.assign c1722 [c2, c5, c6, c514]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p514 F) (rfl))))
  · decide +kernel
def c1723 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (30,false), (75,false), (76,false), (10,false), (11,false)]
theorem p1723 (F : Frame G 3) : c1723.eval F.assign = true := by
  apply local_rup F.assign c1723 [c5, c6, c515]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p515 F) (rfl)))
  · decide +kernel
def c1724 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (10,false), (21,false), (30,false), (75,false), (77,false)]
theorem p1724 (F : Frame G 3) : c1724.eval F.assign = true := by
  apply local_rup F.assign c1724 [c5, c6, c516]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p516 F) (rfl)))
  · decide +kernel
def c1725 : CNF.Clause Nat := [(39,false), (38,false), (30,false), (75,false), (76,false), (10,false), (11,false)]
theorem p1725 (F : Frame G 3) : c1725.eval F.assign = true := by
  apply local_rup F.assign c1725 [c2, c5, c6, c517]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p517 F) (rfl))))
  · decide +kernel
def c1726 : CNF.Clause Nat := [(39,false), (38,false), (8,false), (11,false), (33,false), (75,false), (76,false)]
theorem p1726 (F : Frame G 3) : c1726.eval F.assign = true := by
  apply local_rup F.assign c1726 [c2, c5, c6, c518]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p518 F) (rfl))))
  · decide +kernel
def c1727 : CNF.Clause Nat := [(39,false), (5,false), (22,false), (33,false), (30,false), (74,false), (75,false), (98,false)]
theorem p1727 (F : Frame G 3) : c1727.eval F.assign = true := by
  apply local_rup F.assign c1727 [c1, c2, c519]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p519 F) (rfl)))
  · decide +kernel
def c1728 : CNF.Clause Nat := [(38,false), (50,false), (33,false), (22,false), (20,false), (75,false), (74,false), (87,false)]
theorem p1728 (F : Frame G 3) : c1728.eval F.assign = true := by
  apply local_rup F.assign c1728 [c1, c3, c520]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p520 F) (rfl)))
  · decide +kernel
def c1729 : CNF.Clause Nat := [(39,false), (38,false), (30,false), (32,false), (76,false), (75,false), (9,false), (11,false)]
theorem p1729 (F : Frame G 3) : c1729.eval F.assign = true := by
  apply local_rup F.assign c1729 [c2, c5, c521]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p521 F) (rfl)))
  · decide +kernel
def c1730 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (8,false), (20,false), (32,false), (76,false), (77,false)]
theorem p1730 (F : Frame G 3) : c1730.eval F.assign = true := by
  apply local_rup F.assign c1730 [c5, c6, c522]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p522 F) (rfl)))
  · decide +kernel
def c1731 : CNF.Clause Nat := [(39,false), (50,false), (8,false), (9,false), (32,false), (76,false), (77,false)]
theorem p1731 (F : Frame G 3) : c1731.eval F.assign = true := by
  apply local_rup F.assign c1731 [c2, c5, c6, c523]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p523 F) (rfl))))
  · decide +kernel
def c1732 : CNF.Clause Nat := [(39,false), (50,false), (8,false), (10,false), (32,false), (75,false), (77,false)]
theorem p1732 (F : Frame G 3) : c1732.eval F.assign = true := by
  apply local_rup F.assign c1732 [c2, c5, c6, c524]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p524 F) (rfl))))
  · decide +kernel
def c1733 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (9,false), (30,false), (21,false), (76,false), (77,false)]
theorem p1733 (F : Frame G 3) : c1733.eval F.assign = true := by
  apply local_rup F.assign c1733 [c6, c5, c525]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p525 F) (rfl)))
  · decide +kernel
def c1734 : CNF.Clause Nat := [(39,false), (50,false), (30,false), (9,false), (10,false), (76,false), (77,false)]
theorem p1734 (F : Frame G 3) : c1734.eval F.assign = true := by
  apply local_rup F.assign c1734 [c2, c5, c6, c526]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p526 F) (rfl))))
  · decide +kernel
def c1735 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (10,false), (32,false), (30,false), (20,false), (75,false), (77,false)]
theorem p1735 (F : Frame G 3) : c1735.eval F.assign = true := by
  apply local_rup F.assign c1735 [c5, c527]
  · exact sat_cons (p5 F) ( sat_cons (p527 F) (rfl))
  · decide +kernel
def c1736 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (10,false), (21,false), (30,false), (75,false), (77,false)]
theorem p1736 (F : Frame G 3) : c1736.eval F.assign = true := by
  apply local_rup F.assign c1736 [c5, c6, c528]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p528 F) (rfl)))
  · decide +kernel
def c1737 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (20,false), (8,false), (10,false), (76,false), (77,false)]
theorem p1737 (F : Frame G 3) : c1737.eval F.assign = true := by
  apply local_rup F.assign c1737 [c6, c5, c529]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p529 F) (rfl)))
  · decide +kernel
def c1738 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (8,false), (9,false), (32,false), (76,false), (77,false)]
theorem p1738 (F : Frame G 3) : c1738.eval F.assign = true := by
  apply local_rup F.assign c1738 [c5, c6, c530]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p530 F) (rfl)))
  · decide +kernel
def c1739 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (9,false), (30,false), (21,false), (76,false), (77,false)]
theorem p1739 (F : Frame G 3) : c1739.eval F.assign = true := by
  apply local_rup F.assign c1739 [c6, c5, c531]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p531 F) (rfl)))
  · decide +kernel
def c1740 : CNF.Clause Nat := [(38,false), (50,false), (9,false), (8,false), (21,false), (76,false), (77,false)]
theorem p1740 (F : Frame G 3) : c1740.eval F.assign = true := by
  apply local_rup F.assign c1740 [c3, c6, c5, c532]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p532 F) (rfl))))
  · decide +kernel
def c1741 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (8,false), (20,false), (32,false), (76,false), (77,false)]
theorem p1741 (F : Frame G 3) : c1741.eval F.assign = true := by
  apply local_rup F.assign c1741 [c5, c6, c533]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p533 F) (rfl)))
  · decide +kernel
def c1742 : CNF.Clause Nat := [(38,false), (50,false), (20,false), (8,false), (10,false), (76,false), (77,false)]
theorem p1742 (F : Frame G 3) : c1742.eval F.assign = true := by
  apply local_rup F.assign c1742 [c3, c6, c5, c534]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p534 F) (rfl))))
  · decide +kernel
def c1743 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (10,false), (21,false), (30,false), (75,false), (77,false)]
theorem p1743 (F : Frame G 3) : c1743.eval F.assign = true := by
  apply local_rup F.assign c1743 [c5, c6, c535]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p535 F) (rfl)))
  · decide +kernel
def c1744 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (10,false), (32,false), (30,false), (20,false), (75,false), (77,false)]
theorem p1744 (F : Frame G 3) : c1744.eval F.assign = true := by
  apply local_rup F.assign c1744 [c5, c536]
  · exact sat_cons (p5 F) ( sat_cons (p536 F) (rfl))
  · decide +kernel
def c1745 : CNF.Clause Nat := [(50,false), (38,false), (11,false), (77,false), (76,false), (21,false), (86,false)]
theorem p1745 (F : Frame G 3) : c1745.eval F.assign = true := by
  apply local_rup F.assign c1745 [c3, c1, c5, c537]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p537 F) (rfl))))
  · decide +kernel
def c1746 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (86,false), (9,false), (76,false), (32,false), (33,false)]
theorem p1746 (F : Frame G 3) : c1746.eval F.assign = true := by
  apply local_rup F.assign c1746 [c5, c4, c538]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p538 F) (rfl)))
  · decide +kernel
def c1747 : CNF.Clause Nat := [(39,false), (5,false), (86,false), (98,false), (32,false), (29,false), (77,false)]
theorem p1747 (F : Frame G 3) : c1747.eval F.assign = true := by
  apply local_rup F.assign c1747 [c1, c2, c5, c539]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p539 F) (rfl))))
  · decide +kernel
def c1748 : CNF.Clause Nat := [(39,false), (5,false), (30,false), (33,false), (77,false), (75,false), (98,false)]
theorem p1748 (F : Frame G 3) : c1748.eval F.assign = true := by
  apply local_rup F.assign c1748 [c1, c2, c5, c540]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p540 F) (rfl))))
  · decide +kernel
def c1749 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (86,false), (32,false), (76,false), (77,false)]
theorem p1749 (F : Frame G 3) : c1749.eval F.assign = true := by
  apply local_rup F.assign c1749 [c1, c5, c6, c541]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p541 F) (rfl))))
  · decide +kernel
def c1750 : CNF.Clause Nat := [(10,false), (76,false), (74,false), (86,false), (33,false), (22,false), (50,false)]
theorem p1750 (F : Frame G 3) : c1750.eval F.assign = true := by
  apply local_rup F.assign c1750 [c1, c6, c2, c542]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p542 F) (rfl))))
  · decide +kernel
def c1751 : CNF.Clause Nat := [(38,false), (50,false), (30,false), (86,false), (20,false), (21,false), (76,false), (77,false)]
theorem p1751 (F : Frame G 3) : c1751.eval F.assign = true := by
  apply local_rup F.assign c1751 [c1, c3, c543]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p543 F) (rfl)))
  · decide +kernel
def c1752 : CNF.Clause Nat := [(5,false), (50,false), (86,false), (21,false), (76,false), (77,false)]
theorem p1752 (F : Frame G 3) : c1752.eval F.assign = true := by
  apply local_rup F.assign c1752 [c1, c3, c6, c5, c544]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p544 F) (rfl)))))
  · decide +kernel
def c1753 : CNF.Clause Nat := [(10,false), (76,false), (77,false), (33,false), (27,false), (50,false), (17,false), (86,false)]
theorem p1753 (F : Frame G 3) : c1753.eval F.assign = true := by
  apply local_rup F.assign c1753 [c1, c5, c545]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p545 F) (rfl)))
  · decide +kernel
def c1754 : CNF.Clause Nat := [(6,false), (50,false), (86,false), (32,false), (76,false), (77,false)]
theorem p1754 (F : Frame G 3) : c1754.eval F.assign = true := by
  apply local_rup F.assign c1754 [c1, c2, c5, c6, c546]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p546 F) (rfl)))))
  · decide +kernel
def c1755 : CNF.Clause Nat := [(39,false), (50,false), (86,false), (32,false), (76,false), (77,false)]
theorem p1755 (F : Frame G 3) : c1755.eval F.assign = true := by
  apply local_rup F.assign c1755 [c1, c2, c5, c6, c547]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p547 F) (rfl)))))
  · decide +kernel
def c1756 : CNF.Clause Nat := [(27,false), (39,false), (10,false), (21,false), (22,false), (77,false), (74,false), (86,false)]
theorem p1756 (F : Frame G 3) : c1756.eval F.assign = true := by
  apply local_rup F.assign c1756 [c3, c1, c548]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p548 F) (rfl)))
  · decide +kernel
def c1757 : CNF.Clause Nat := [(27,false), (39,false), (11,false), (22,false), (21,false), (76,false), (74,false), (86,false)]
theorem p1757 (F : Frame G 3) : c1757.eval F.assign = true := by
  apply local_rup F.assign c1757 [c3, c1, c549]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p549 F) (rfl)))
  · decide +kernel
def c1758 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (8,false), (21,false), (32,false), (75,false), (77,false)]
theorem p1758 (F : Frame G 3) : c1758.eval F.assign = true := by
  apply local_rup F.assign c1758 [c5, c6, c550]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p550 F) (rfl)))
  · decide +kernel
def c1759 : CNF.Clause Nat := [(5,false), (39,false), (17,false), (21,false), (32,false), (33,false), (77,false), (74,false), (86,false)]
theorem p1759 (F : Frame G 3) : c1759.eval F.assign = true := by
  apply local_rup F.assign c1759 [c1, c551]
  · exact sat_cons (p1 F) ( sat_cons (p551 F) (rfl))
  · decide +kernel
def c1760 : CNF.Clause Nat := [(5,false), (39,false), (17,false), (86,false), (32,false), (76,false), (77,false)]
theorem p1760 (F : Frame G 3) : c1760.eval F.assign = true := by
  apply local_rup F.assign c1760 [c1, c5, c6, c552]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p552 F) (rfl))))
  · decide +kernel
def c1761 : CNF.Clause Nat := [(15,false), (39,false), (33,false), (11,false), (10,false), (76,false), (74,false), (86,false)]
theorem p1761 (F : Frame G 3) : c1761.eval F.assign = true := by
  apply local_rup F.assign c1761 [c2, c3, c553]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p553 F) (rfl)))
  · decide +kernel
def c1762 : CNF.Clause Nat := [(38,false), (39,false), (33,false), (11,false), (10,false), (76,false), (74,false), (86,false)]
theorem p1762 (F : Frame G 3) : c1762.eval F.assign = true := by
  apply local_rup F.assign c1762 [c2, c3, c554]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p554 F) (rfl)))
  · decide +kernel
def c1763 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (11,false), (77,false), (76,false), (21,false), (30,false)]
theorem p1763 (F : Frame G 3) : c1763.eval F.assign = true := by
  apply local_rup F.assign c1763 [c5, c6, c555]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p555 F) (rfl)))
  · decide +kernel
def c1764 : CNF.Clause Nat := [(5,false), (39,false), (86,false), (21,false), (76,false), (77,false)]
theorem p1764 (F : Frame G 3) : c1764.eval F.assign = true := by
  apply local_rup F.assign c1764 [c1, c3, c6, c5, c556]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p556 F) (rfl)))))
  · decide +kernel
def c1765 : CNF.Clause Nat := [(38,false), (39,false), (32,false), (10,false), (11,false), (77,false), (74,false), (86,false)]
theorem p1765 (F : Frame G 3) : c1765.eval F.assign = true := by
  apply local_rup F.assign c1765 [c2, c3, c557]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p557 F) (rfl)))
  · decide +kernel
def c1766 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (10,false), (76,false), (77,false), (33,false), (30,false), (86,false)]
theorem p1766 (F : Frame G 3) : c1766.eval F.assign = true := by
  apply local_rup F.assign c1766 [c2, c558]
  · exact sat_cons (p2 F) ( sat_cons (p558 F) (rfl))
  · decide +kernel
def c1767 : CNF.Clause Nat := [(15,false), (50,false), (30,false), (86,false), (75,false), (76,false), (10,false), (11,false)]
theorem p1767 (F : Frame G 3) : c1767.eval F.assign = true := by
  apply local_rup F.assign c1767 [c2, c3, c559]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p559 F) (rfl)))
  · decide +kernel
def c1768 : CNF.Clause Nat := [(39,false), (50,false), (21,false), (76,false), (77,false), (33,false), (30,false), (86,false)]
theorem p1768 (F : Frame G 3) : c1768.eval F.assign = true := by
  apply local_rup F.assign c1768 [c1, c2, c560]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p560 F) (rfl)))
  · decide +kernel
def c1769 : CNF.Clause Nat := [(26,false), (27,false), (50,false), (6,false), (11,false), (22,false), (86,false), (75,false), (76,false)]
theorem p1769 (F : Frame G 3) : c1769.eval F.assign = true := by
  apply local_rup F.assign c1769 [c5, c561]
  · exact sat_cons (p5 F) ( sat_cons (p561 F) (rfl))
  · decide +kernel
def c1770 : CNF.Clause Nat := [(26,false), (27,false), (50,false), (17,false), (22,false), (11,false), (75,false), (86,false), (87,false)]
theorem p1770 (F : Frame G 3) : c1770.eval F.assign = true := by
  apply local_rup F.assign c1770 [c4, c562]
  · exact sat_cons (p4 F) ( sat_cons (p562 F) (rfl))
  · decide +kernel
def c1771 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (75,false), (77,false), (22,false), (8,false), (10,false)]
theorem p1771 (F : Frame G 3) : c1771.eval F.assign = true := by
  apply local_rup F.assign c1771 [c6, c5, c563]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p563 F) (rfl)))
  · decide +kernel
def c1772 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (75,false), (77,false), (22,false), (87,false)]
theorem p1772 (F : Frame G 3) : c1772.eval F.assign = true := by
  apply local_rup F.assign c1772 [c1, c6, c5, c564]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p564 F) (rfl))))
  · decide +kernel
def c1773 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (86,false), (87,false), (21,false), (18,false), (77,false)]
theorem p1773 (F : Frame G 3) : c1773.eval F.assign = true := by
  apply local_rup F.assign c1773 [c1, c6, c565]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p565 F) (rfl)))
  · decide +kernel
def c1774 : CNF.Clause Nat := [(6,false), (50,false), (27,false), (86,false), (21,false), (76,false), (77,false)]
theorem p1774 (F : Frame G 3) : c1774.eval F.assign = true := by
  apply local_rup F.assign c1774 [c1, c6, c5, c566]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p566 F) (rfl))))
  · decide +kernel
def c1775 : CNF.Clause Nat := [(26,false), (39,false), (50,false), (5,false), (10,false), (76,false), (77,false), (22,false), (86,false)]
theorem p1775 (F : Frame G 3) : c1775.eval F.assign = true := by
  apply local_rup F.assign c1775 [c5, c567]
  · exact sat_cons (p5 F) ( sat_cons (p567 F) (rfl))
  · decide +kernel
def c1776 : CNF.Clause Nat := [(26,false), (50,false), (20,false), (86,false), (87,false), (10,false), (77,false)]
theorem p1776 (F : Frame G 3) : c1776.eval F.assign = true := by
  apply local_rup F.assign c1776 [c3, c2, c4, c568]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p568 F) (rfl))))
  · decide +kernel
def c1777 : CNF.Clause Nat := [(50,false), (39,false), (26,false), (86,false), (87,false), (10,false), (77,false)]
theorem p1777 (F : Frame G 3) : c1777.eval F.assign = true := by
  apply local_rup F.assign c1777 [c2, c6, c4, c569]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p569 F) (rfl))))
  · decide +kernel
def c1778 : CNF.Clause Nat := [(11,false), (77,false), (75,false), (27,false), (50,false), (17,false), (87,false)]
theorem p1778 (F : Frame G 3) : c1778.eval F.assign = true := by
  apply local_rup F.assign c1778 [c1, c6, c5, c570]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p570 F) (rfl))))
  · decide +kernel
def c1779 : CNF.Clause Nat := [(39,false), (50,false), (21,false), (87,false), (86,false), (29,false), (77,false)]
theorem p1779 (F : Frame G 3) : c1779.eval F.assign = true := by
  apply local_rup F.assign c1779 [c1, c2, c6, c571]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p571 F) (rfl))))
  · decide +kernel
def c1780 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (86,false), (21,false), (76,false), (77,false)]
theorem p1780 (F : Frame G 3) : c1780.eval F.assign = true := by
  apply local_rup F.assign c1780 [c1, c6, c5, c572]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p572 F) (rfl))))
  · decide +kernel
def c1781 : CNF.Clause Nat := [(86,false), (87,false), (76,false), (77,false), (11,false), (38,false), (17,false)]
theorem p1781 (F : Frame G 3) : c1781.eval F.assign = true := by
  apply local_rup F.assign c1781 [c6, c1, c2, c573]
  · exact sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p573 F) (rfl))))
  · decide +kernel
def c1782 : CNF.Clause Nat := [(86,false), (22,false), (77,false), (76,false), (10,false), (38,false), (50,false)]
theorem p1782 (F : Frame G 3) : c1782.eval F.assign = true := by
  apply local_rup F.assign c1782 [c6, c5, c1, c574]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p574 F) (rfl))))
  · decide +kernel
def c1783 : CNF.Clause Nat := [(38,false), (50,false), (75,false), (77,false), (22,false), (87,false)]
theorem p1783 (F : Frame G 3) : c1783.eval F.assign = true := by
  apply local_rup F.assign c1783 [c1, c3, c6, c5, c575]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p575 F) (rfl)))))
  · decide +kernel
def c1784 : CNF.Clause Nat := [(9,false), (6,false), (39,false), (38,false), (22,false), (77,false), (74,false), (87,false)]
theorem p1784 (F : Frame G 3) : c1784.eval F.assign = true := by
  apply local_rup F.assign c1784 [c6, c2, c576]
  · exact sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p576 F) (rfl)))
  · decide +kernel
def c1785 : CNF.Clause Nat := [(9,false), (33,false), (77,false), (74,false), (87,false), (21,false), (15,false), (38,false), (50,false)]
theorem p1785 (F : Frame G 3) : c1785.eval F.assign = true := by
  apply local_rup F.assign c1785 [c6, c577]
  · exact sat_cons (p6 F) ( sat_cons (p577 F) (rfl))
  · decide +kernel
def c1786 : CNF.Clause Nat := [(38,false), (39,false), (86,false), (87,false), (10,false), (77,false)]
theorem p1786 (F : Frame G 3) : c1786.eval F.assign = true := by
  apply local_rup F.assign c1786 [c2, c3, c6, c4, c578]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p578 F) (rfl)))))
  · decide +kernel
def c1787 : CNF.Clause Nat := [(38,false), (27,false), (17,false), (22,false), (77,false), (75,false), (86,false), (87,false)]
theorem p1787 (F : Frame G 3) : c1787.eval F.assign = true := by
  apply local_rup F.assign c1787 [c1, c3, c579]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p579 F) (rfl)))
  · decide +kernel
def c1788 : CNF.Clause Nat := [(6,false), (39,false), (38,false), (27,false), (75,false), (77,false), (22,false), (87,false)]
theorem p1788 (F : Frame G 3) : c1788.eval F.assign = true := by
  apply local_rup F.assign c1788 [c6, c5, c580]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p580 F) (rfl)))
  · decide +kernel
def c1789 : CNF.Clause Nat := [(6,false), (39,false), (38,false), (20,false), (86,false), (87,false), (76,false), (29,false), (33,false)]
theorem p1789 (F : Frame G 3) : c1789.eval F.assign = true := by
  apply local_rup F.assign c1789 [c2, c581]
  · exact sat_cons (p2 F) ( sat_cons (p581 F) (rfl))
  · decide +kernel
def c1790 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (11,false), (33,false), (75,false), (74,false), (87,false)]
theorem p1790 (F : Frame G 3) : c1790.eval F.assign = true := by
  apply local_rup F.assign c1790 [c2, c6, c582]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p582 F) (rfl)))
  · decide +kernel
def c1791 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (9,false), (33,false), (77,false), (74,false), (87,false)]
theorem p1791 (F : Frame G 3) : c1791.eval F.assign = true := by
  apply local_rup F.assign c1791 [c2, c6, c583]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p583 F) (rfl)))
  · decide +kernel
def c1792 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (11,false), (77,false), (76,false), (32,false), (30,false), (86,false)]
theorem p1792 (F : Frame G 3) : c1792.eval F.assign = true := by
  apply local_rup F.assign c1792 [c2, c584]
  · exact sat_cons (p2 F) ( sat_cons (p584 F) (rfl))
  · decide +kernel
def c1793 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (11,false), (77,false), (29,false), (86,false), (87,false)]
theorem p1793 (F : Frame G 3) : c1793.eval F.assign = true := by
  apply local_rup F.assign c1793 [c2, c6, c585]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p585 F) (rfl)))
  · decide +kernel
def c1794 : CNF.Clause Nat := [(39,false), (38,false), (22,false), (11,false), (75,false), (86,false), (87,false)]
theorem p1794 (F : Frame G 3) : c1794.eval F.assign = true := by
  apply local_rup F.assign c1794 [c3, c2, c4, c586]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p586 F) (rfl))))
  · decide +kernel
def c1795 : CNF.Clause Nat := [(5,false), (39,false), (86,false), (87,false), (76,false), (18,false), (22,false)]
theorem p1795 (F : Frame G 3) : c1795.eval F.assign = true := by
  apply local_rup F.assign c1795 [c1, c3, c6, c587]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p587 F) (rfl))))
  · decide +kernel
def c1796 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (8,false), (86,false), (32,false), (76,false), (77,false)]
theorem p1796 (F : Frame G 3) : c1796.eval F.assign = true := by
  apply local_rup F.assign c1796 [c2, c6, c588]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p588 F) (rfl)))
  · decide +kernel
def c1797 : CNF.Clause Nat := [(5,false), (39,false), (20,false), (22,false), (77,false), (74,false), (87,false)]
theorem p1797 (F : Frame G 3) : c1797.eval F.assign = true := by
  apply local_rup F.assign c1797 [c1, c3, c6, c589]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p589 F) (rfl))))
  · decide +kernel
def c1798 : CNF.Clause Nat := [(5,false), (39,false), (75,false), (76,false), (87,false), (22,false)]
theorem p1798 (F : Frame G 3) : c1798.eval F.assign = true := by
  apply local_rup F.assign c1798 [c1, c3, c6, c5, c590]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p590 F) (rfl)))))
  · decide +kernel
def c1799 : CNF.Clause Nat := [(38,false), (6,false), (33,false), (77,false), (75,false), (86,false), (87,false)]
theorem p1799 (F : Frame G 3) : c1799.eval F.assign = true := by
  apply local_rup F.assign c1799 [c2, c1, c3, c591]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p591 F) (rfl))))
  · decide +kernel
def c1800 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (22,false), (33,false), (9,false), (74,false), (87,false)]
theorem p1800 (F : Frame G 3) : c1800.eval F.assign = true := by
  apply local_rup F.assign c1800 [c6, c4, c592]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p592 F) (rfl)))
  · decide +kernel
end Cert35Steps
end Graffiti199Depleted.Catalogue.OrderEleven
