import Local35Part5
namespace Graffiti199Depleted.Catalogue.OrderEleven
namespace Cert35Steps
open Std.Sat
set_option maxRecDepth 4096
set_option maxHeartbeats 0
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj]
def c1801 : CNF.Clause Nat := [(10,false), (87,false), (74,false), (77,false), (33,false), (20,false), (50,false)]
theorem p1801 (F : Frame G 3) : c1801.eval F.assign = true := by
  apply local_rup F.assign c1801 [c1, c6, c2, c593]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p593 F) (rfl))))
  · decide +kernel
def c1802 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (20,false), (86,false), (87,false), (32,false), (29,false), (77,false)]
theorem p1802 (F : Frame G 3) : c1802.eval F.assign = true := by
  apply local_rup F.assign c1802 [c1, c594]
  · exact sat_cons (p1 F) ( sat_cons (p594 F) (rfl))
  · decide +kernel
def c1803 : CNF.Clause Nat := [(6,false), (50,false), (20,false), (86,false), (87,false), (32,false), (29,false), (77,false)]
theorem p1803 (F : Frame G 3) : c1803.eval F.assign = true := by
  apply local_rup F.assign c1803 [c1, c2, c595]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p595 F) (rfl)))
  · decide +kernel
def c1804 : CNF.Clause Nat := [(15,false), (50,false), (32,false), (87,false), (86,false), (9,false), (77,false)]
theorem p1804 (F : Frame G 3) : c1804.eval F.assign = true := by
  apply local_rup F.assign c1804 [c2, c3, c4, c596]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p596 F) (rfl))))
  · decide +kernel
def c1805 : CNF.Clause Nat := [(26,false), (50,false), (21,false), (87,false), (86,false), (9,false), (77,false)]
theorem p1805 (F : Frame G 3) : c1805.eval F.assign = true := by
  apply local_rup F.assign c1805 [c3, c2, c4, c597]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p597 F) (rfl))))
  · decide +kernel
def c1806 : CNF.Clause Nat := [(38,false), (50,false), (9,false), (77,false), (22,false), (87,false)]
theorem p1806 (F : Frame G 3) : c1806.eval F.assign = true := by
  apply local_rup F.assign c1806 [c3, c6, c4, c5, c598]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p598 F) (rfl)))))
  · decide +kernel
def c1807 : CNF.Clause Nat := [(11,false), (77,false), (74,false), (86,false), (32,false), (21,false), (15,false), (38,false), (50,false)]
theorem p1807 (F : Frame G 3) : c1807.eval F.assign = true := by
  apply local_rup F.assign c1807 [c6, c599]
  · exact sat_cons (p6 F) ( sat_cons (p599 F) (rfl))
  · decide +kernel
def c1808 : CNF.Clause Nat := [(11,false), (77,false), (75,false), (30,false), (87,false), (21,false), (15,false), (38,false), (50,false)]
theorem p1808 (F : Frame G 3) : c1808.eval F.assign = true := by
  apply local_rup F.assign c1808 [c6, c600]
  · exact sat_cons (p6 F) ( sat_cons (p600 F) (rfl))
  · decide +kernel
def c1809 : CNF.Clause Nat := [(38,false), (39,false), (32,false), (21,false), (86,false), (75,false), (11,false)]
theorem p1809 (F : Frame G 3) : c1809.eval F.assign = true := by
  apply local_rup F.assign c1809 [c3, c5, c4, c601]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p601 F) (rfl))))
  · decide +kernel
def c1810 : CNF.Clause Nat := [(15,false), (50,false), (75,false), (77,false), (11,false), (8,false), (87,false)]
theorem p1810 (F : Frame G 3) : c1810.eval F.assign = true := by
  apply local_rup F.assign c1810 [c2, c3, c6, c602]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p602 F) (rfl))))
  · decide +kernel
def c1811 : CNF.Clause Nat := [(15,false), (50,false), (30,false), (86,false), (75,false), (77,false), (11,false), (10,false)]
theorem p1811 (F : Frame G 3) : c1811.eval F.assign = true := by
  apply local_rup F.assign c1811 [c2, c3, c603]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p603 F) (rfl)))
  · decide +kernel
def c1812 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (11,false), (33,false), (20,false), (18,false), (74,false), (87,false)]
theorem p1812 (F : Frame G 3) : c1812.eval F.assign = true := by
  apply local_rup F.assign c1812 [c6, c604]
  · exact sat_cons (p6 F) ( sat_cons (p604 F) (rfl))
  · decide +kernel
def c1813 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (21,false), (32,false), (86,false), (74,false), (11,false)]
theorem p1813 (F : Frame G 3) : c1813.eval F.assign = true := by
  apply local_rup F.assign c1813 [c6, c4, c605]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p605 F) (rfl)))
  · decide +kernel
def c1814 : CNF.Clause Nat := [(5,false), (38,false), (39,false), (17,false), (18,false), (77,false), (33,false), (86,false), (87,false)]
theorem p1814 (F : Frame G 3) : c1814.eval F.assign = true := by
  apply local_rup F.assign c1814 [c6, c606]
  · exact sat_cons (p6 F) ( sat_cons (p606 F) (rfl))
  · decide +kernel
def c1815 : CNF.Clause Nat := [(5,false), (38,false), (39,false), (17,false), (21,false), (87,false), (86,false), (29,false), (77,false)]
theorem p1815 (F : Frame G 3) : c1815.eval F.assign = true := by
  apply local_rup F.assign c1815 [c6, c607]
  · exact sat_cons (p6 F) ( sat_cons (p607 F) (rfl))
  · decide +kernel
def c1816 : CNF.Clause Nat := [(5,false), (50,false), (17,false), (21,false), (87,false), (30,false), (75,false), (77,false)]
theorem p1816 (F : Frame G 3) : c1816.eval F.assign = true := by
  apply local_rup F.assign c1816 [c1, c6, c608]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p608 F) (rfl)))
  · decide +kernel
def c1817 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (77,false), (33,false), (20,false), (87,false)]
theorem p1817 (F : Frame G 3) : c1817.eval F.assign = true := by
  apply local_rup F.assign c1817 [c4, c6, c5, c609]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p609 F) (rfl))))
  · decide +kernel
def c1818 : CNF.Clause Nat := [(26,false), (50,false), (5,false), (11,false), (77,false), (75,false), (86,false), (21,false)]
theorem p1818 (F : Frame G 3) : c1818.eval F.assign = true := by
  apply local_rup F.assign c1818 [c3, c5, c610]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p610 F) (rfl)))
  · decide +kernel
def c1819 : CNF.Clause Nat := [(5,false), (50,false), (75,false), (77,false), (22,false), (87,false)]
theorem p1819 (F : Frame G 3) : c1819.eval F.assign = true := by
  apply local_rup F.assign c1819 [c1, c3, c6, c5, c611]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p611 F) (rfl)))))
  · decide +kernel
def c1820 : CNF.Clause Nat := [(75,false), (77,false), (11,false), (39,false), (50,false), (87,false)]
theorem p1820 (F : Frame G 3) : c1820.eval F.assign = true := by
  apply local_rup F.assign c1820 [c6, c1, c2, c5, c612]
  · exact sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p612 F) (rfl)))))
  · decide +kernel
def c1821 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (87,false), (10,false), (75,false), (33,false)]
theorem p1821 (F : Frame G 3) : c1821.eval F.assign = true := by
  apply local_rup F.assign c1821 [c5, c4, c6, c613]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p613 F) (rfl))))
  · decide +kernel
def c1822 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (21,false), (87,false), (30,false), (9,false), (77,false)]
theorem p1822 (F : Frame G 3) : c1822.eval F.assign = true := by
  apply local_rup F.assign c1822 [c6, c4, c614]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p614 F) (rfl)))
  · decide +kernel
def c1823 : CNF.Clause Nat := [(39,false), (38,false), (87,false), (10,false), (9,false), (75,false), (77,false)]
theorem p1823 (F : Frame G 3) : c1823.eval F.assign = true := by
  apply local_rup F.assign c1823 [c3, c2, c5, c615]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p615 F) (rfl))))
  · decide +kernel
def c1824 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (87,false), (32,false), (9,false), (77,false)]
theorem p1824 (F : Frame G 3) : c1824.eval F.assign = true := by
  apply local_rup F.assign c1824 [c5, c6, c4, c616]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p616 F) (rfl))))
  · decide +kernel
def c1825 : CNF.Clause Nat := [(15,false), (50,false), (9,false), (11,false), (77,false), (74,false), (87,false)]
theorem p1825 (F : Frame G 3) : c1825.eval F.assign = true := by
  apply local_rup F.assign c1825 [c2, c3, c6, c617]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p617 F) (rfl))))
  · decide +kernel
def c1826 : CNF.Clause Nat := [(26,false), (50,false), (87,false), (10,false), (9,false), (75,false), (77,false)]
theorem p1826 (F : Frame G 3) : c1826.eval F.assign = true := by
  apply local_rup F.assign c1826 [c3, c2, c5, c618]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p618 F) (rfl))))
  · decide +kernel
def c1827 : CNF.Clause Nat := [(38,false), (50,false), (20,false), (21,false), (87,false), (8,false), (77,false)]
theorem p1827 (F : Frame G 3) : c1827.eval F.assign = true := by
  apply local_rup F.assign c1827 [c3, c6, c4, c619]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p619 F) (rfl))))
  · decide +kernel
def c1828 : CNF.Clause Nat := [(6,false), (50,false), (20,false), (33,false), (77,false), (74,false), (87,false)]
theorem p1828 (F : Frame G 3) : c1828.eval F.assign = true := by
  apply local_rup F.assign c1828 [c1, c2, c6, c620]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p620 F) (rfl))))
  · decide +kernel
def c1829 : CNF.Clause Nat := [(5,false), (50,false), (17,false), (20,false), (33,false), (77,false), (74,false), (87,false)]
theorem p1829 (F : Frame G 3) : c1829.eval F.assign = true := by
  apply local_rup F.assign c1829 [c1, c6, c621]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p621 F) (rfl)))
  · decide +kernel
def c1830 : CNF.Clause Nat := [(5,false), (39,false), (17,false), (87,false), (32,false), (75,false), (77,false)]
theorem p1830 (F : Frame G 3) : c1830.eval F.assign = true := by
  apply local_rup F.assign c1830 [c1, c5, c6, c622]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p622 F) (rfl))))
  · decide +kernel
def c1831 : CNF.Clause Nat := [(38,false), (39,false), (9,false), (76,false), (21,false), (88,false)]
theorem p1831 (F : Frame G 3) : c1831.eval F.assign = true := by
  apply local_rup F.assign c1831 [c3, c6, c4, c5, c623]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p623 F) (rfl)))))
  · decide +kernel
def c1832 : CNF.Clause Nat := [(6,false), (39,false), (38,false), (27,false), (75,false), (76,false), (21,false), (88,false)]
theorem p1832 (F : Frame G 3) : c1832.eval F.assign = true := by
  apply local_rup F.assign c1832 [c6, c5, c625]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p625 F) (rfl)))
  · decide +kernel
def c1833 : CNF.Clause Nat := [(38,false), (27,false), (17,false), (20,false), (75,false), (76,false), (87,false), (88,false)]
theorem p1833 (F : Frame G 3) : c1833.eval F.assign = true := by
  apply local_rup F.assign c1833 [c1, c3, c626]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p626 F) (rfl)))
  · decide +kernel
def c1834 : CNF.Clause Nat := [(38,false), (39,false), (9,false), (11,false), (88,false), (74,false), (76,false)]
theorem p1834 (F : Frame G 3) : c1834.eval F.assign = true := by
  apply local_rup F.assign c1834 [c2, c3, c6, c627]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p627 F) (rfl))))
  · decide +kernel
def c1835 : CNF.Clause Nat := [(38,false), (39,false), (9,false), (18,false), (21,false), (87,false), (88,false)]
theorem p1835 (F : Frame G 3) : c1835.eval F.assign = true := by
  apply local_rup F.assign c1835 [c3, c6, c4, c628]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p628 F) (rfl))))
  · decide +kernel
def c1836 : CNF.Clause Nat := [(21,false), (87,false), (88,false), (11,false), (39,false), (29,false), (75,false)]
theorem p1836 (F : Frame G 3) : c1836.eval F.assign = true := by
  apply local_rup F.assign c1836 [c2, c1, c3, c629]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p629 F) (rfl))))
  · decide +kernel
def c1837 : CNF.Clause Nat := [(38,false), (39,false), (9,false), (76,false), (87,false), (22,false)]
theorem p1837 (F : Frame G 3) : c1837.eval F.assign = true := by
  apply local_rup F.assign c1837 [c3, c6, c4, c5, c630]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p630 F) (rfl)))))
  · decide +kernel
def c1838 : CNF.Clause Nat := [(5,false), (39,false), (17,false), (18,false), (75,false), (32,false), (87,false), (88,false)]
theorem p1838 (F : Frame G 3) : c1838.eval F.assign = true := by
  apply local_rup F.assign c1838 [c1, c6, c631]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p631 F) (rfl)))
  · decide +kernel
def c1839 : CNF.Clause Nat := [(5,false), (39,false), (17,false), (20,false), (75,false), (76,false), (32,false), (30,false), (88,false)]
theorem p1839 (F : Frame G 3) : c1839.eval F.assign = true := by
  apply local_rup F.assign c1839 [c1, c632]
  · exact sat_cons (p1 F) ( sat_cons (p632 F) (rfl))
  · decide +kernel
def c1840 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (75,false), (32,false), (21,false), (88,false)]
theorem p1840 (F : Frame G 3) : c1840.eval F.assign = true := by
  apply local_rup F.assign c1840 [c4, c6, c5, c633]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p633 F) (rfl))))
  · decide +kernel
def c1841 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (10,false), (87,false), (20,false), (29,false), (77,false)]
theorem p1841 (F : Frame G 3) : c1841.eval F.assign = true := by
  apply local_rup F.assign c1841 [c5, c6, c634]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p634 F) (rfl)))
  · decide +kernel
def c1842 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (10,false), (87,false), (88,false), (77,false), (18,false), (20,false)]
theorem p1842 (F : Frame G 3) : c1842.eval F.assign = true := by
  apply local_rup F.assign c1842 [c3, c635]
  · exact sat_cons (p3 F) ( sat_cons (p635 F) (rfl))
  · decide +kernel
def c1843 : CNF.Clause Nat := [(15,false), (39,false), (6,false), (10,false), (32,false), (75,false), (74,false), (88,false)]
theorem p1843 (F : Frame G 3) : c1843.eval F.assign = true := by
  apply local_rup F.assign c1843 [c2, c6, c636]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p636 F) (rfl)))
  · decide +kernel
def c1844 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (10,false), (32,false), (75,false), (74,false), (88,false)]
theorem p1844 (F : Frame G 3) : c1844.eval F.assign = true := by
  apply local_rup F.assign c1844 [c2, c6, c637]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p637 F) (rfl)))
  · decide +kernel
def c1845 : CNF.Clause Nat := [(15,false), (39,false), (6,false), (10,false), (76,false), (75,false), (30,false), (88,false)]
theorem p1845 (F : Frame G 3) : c1845.eval F.assign = true := by
  apply local_rup F.assign c1845 [c2, c6, c638]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p638 F) (rfl)))
  · decide +kernel
def c1846 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (10,false), (76,false), (75,false), (30,false), (88,false)]
theorem p1846 (F : Frame G 3) : c1846.eval F.assign = true := by
  apply local_rup F.assign c1846 [c2, c6, c639]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p639 F) (rfl)))
  · decide +kernel
def c1847 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (10,false), (76,false), (75,false), (20,false), (88,false)]
theorem p1847 (F : Frame G 3) : c1847.eval F.assign = true := by
  apply local_rup F.assign c1847 [c3, c5, c640]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p640 F) (rfl)))
  · decide +kernel
def c1848 : CNF.Clause Nat := [(6,false), (38,false), (20,false), (75,false), (76,false), (87,false), (88,false)]
theorem p1848 (F : Frame G 3) : c1848.eval F.assign = true := by
  apply local_rup F.assign c1848 [c3, c1, c2, c641]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p641 F) (rfl))))
  · decide +kernel
def c1849 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (9,false), (75,false), (76,false), (32,false), (30,false), (88,false)]
theorem p1849 (F : Frame G 3) : c1849.eval F.assign = true := by
  apply local_rup F.assign c1849 [c2, c642]
  · exact sat_cons (p2 F) ( sat_cons (p642 F) (rfl))
  · decide +kernel
def c1850 : CNF.Clause Nat := [(27,false), (39,false), (10,false), (87,false), (88,false), (77,false), (18,false), (20,false)]
theorem p1850 (F : Frame G 3) : c1850.eval F.assign = true := by
  apply local_rup F.assign c1850 [c3, c1, c643]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p643 F) (rfl)))
  · decide +kernel
def c1851 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (11,false), (88,false), (20,false), (75,false), (76,false)]
theorem p1851 (F : Frame G 3) : c1851.eval F.assign = true := by
  apply local_rup F.assign c1851 [c3, c5, c644]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p644 F) (rfl)))
  · decide +kernel
def c1852 : CNF.Clause Nat := [(5,false), (39,false), (17,false), (87,false), (76,false), (75,false), (33,false)]
theorem p1852 (F : Frame G 3) : c1852.eval F.assign = true := by
  apply local_rup F.assign c1852 [c1, c5, c6, c645]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p645 F) (rfl))))
  · decide +kernel
def c1853 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (11,false), (77,false), (74,false), (86,false), (32,false)]
theorem p1853 (F : Frame G 3) : c1853.eval F.assign = true := by
  apply local_rup F.assign c1853 [c2, c6, c646]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p646 F) (rfl)))
  · decide +kernel
def c1854 : CNF.Clause Nat := [(17,false), (39,false), (10,false), (87,false), (88,false), (77,false), (29,false)]
theorem p1854 (F : Frame G 3) : c1854.eval F.assign = true := by
  apply local_rup F.assign c1854 [c2, c1, c6, c647]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p647 F) (rfl))))
  · decide +kernel
def c1855 : CNF.Clause Nat := [(11,false), (77,false), (75,false), (20,false), (38,false), (39,false), (30,false), (87,false)]
theorem p1855 (F : Frame G 3) : c1855.eval F.assign = true := by
  apply local_rup F.assign c1855 [c2, c3, c648]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p648 F) (rfl)))
  · decide +kernel
def c1856 : CNF.Clause Nat := [(38,false), (39,false), (9,false), (10,false), (87,false), (74,false), (18,false), (22,false)]
theorem p1856 (F : Frame G 3) : c1856.eval F.assign = true := by
  apply local_rup F.assign c1856 [c3, c6, c649]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p649 F) (rfl)))
  · decide +kernel
def c1857 : CNF.Clause Nat := [(17,false), (39,false), (26,false), (75,false), (10,false), (87,false), (88,false)]
theorem p1857 (F : Frame G 3) : c1857.eval F.assign = true := by
  apply local_rup F.assign c1857 [c2, c6, c4, c650]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p650 F) (rfl))))
  · decide +kernel
def c1858 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (22,false), (88,false), (87,false), (10,false), (29,false)]
theorem p1858 (F : Frame G 3) : c1858.eval F.assign = true := by
  apply local_rup F.assign c1858 [c4, c6, c651]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p651 F) (rfl)))
  · decide +kernel
def c1859 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (21,false), (32,false), (75,false), (8,false), (88,false)]
theorem p1859 (F : Frame G 3) : c1859.eval F.assign = true := by
  apply local_rup F.assign c1859 [c6, c4, c652]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p652 F) (rfl)))
  · decide +kernel
def c1860 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (21,false), (32,false), (9,false), (74,false), (88,false)]
theorem p1860 (F : Frame G 3) : c1860.eval F.assign = true := by
  apply local_rup F.assign c1860 [c6, c4, c653]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p653 F) (rfl)))
  · decide +kernel
def c1861 : CNF.Clause Nat := [(11,false), (77,false), (74,false), (87,false), (21,false), (20,false), (27,false), (38,false), (39,false)]
theorem p1861 (F : Frame G 3) : c1861.eval F.assign = true := by
  apply local_rup F.assign c1861 [c6, c654]
  · exact sat_cons (p6 F) ( sat_cons (p654 F) (rfl))
  · decide +kernel
def c1862 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (75,false), (32,false), (21,false), (88,false)]
theorem p1862 (F : Frame G 3) : c1862.eval F.assign = true := by
  apply local_rup F.assign c1862 [c4, c6, c5, c655]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p655 F) (rfl))))
  · decide +kernel
def c1863 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (10,false), (32,false), (29,false), (75,false), (20,false), (88,false)]
theorem p1863 (F : Frame G 3) : c1863.eval F.assign = true := by
  apply local_rup F.assign c1863 [c5, c656]
  · exact sat_cons (p5 F) ( sat_cons (p656 F) (rfl))
  · decide +kernel
def c1864 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (10,false), (32,false), (75,false), (18,false), (88,false)]
theorem p1864 (F : Frame G 3) : c1864.eval F.assign = true := by
  apply local_rup F.assign c1864 [c6, c5, c657]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p657 F) (rfl)))
  · decide +kernel
def c1865 : CNF.Clause Nat := [(26,false), (50,false), (5,false), (10,false), (87,false), (88,false), (22,false), (18,false), (75,false)]
theorem p1865 (F : Frame G 3) : c1865.eval F.assign = true := by
  apply local_rup F.assign c1865 [c3, c658]
  · exact sat_cons (p3 F) ( sat_cons (p658 F) (rfl))
  · decide +kernel
def c1866 : CNF.Clause Nat := [(6,false), (50,false), (27,false), (75,false), (77,false), (88,false), (21,false)]
theorem p1866 (F : Frame G 3) : c1866.eval F.assign = true := by
  apply local_rup F.assign c1866 [c1, c6, c5, c659]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p659 F) (rfl))))
  · decide +kernel
def c1867 : CNF.Clause Nat := [(6,false), (50,false), (21,false), (87,false), (88,false), (33,false), (29,false), (75,false)]
theorem p1867 (F : Frame G 3) : c1867.eval F.assign = true := by
  apply local_rup F.assign c1867 [c1, c2, c660]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p660 F) (rfl)))
  · decide +kernel
def c1868 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (9,false), (18,false), (21,false), (87,false), (88,false)]
theorem p1868 (F : Frame G 3) : c1868.eval F.assign = true := by
  apply local_rup F.assign c1868 [c6, c4, c661]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p661 F) (rfl)))
  · decide +kernel
def c1869 : CNF.Clause Nat := [(50,false), (39,false), (9,false), (75,false), (29,false), (32,false), (87,false), (88,false)]
theorem p1869 (F : Frame G 3) : c1869.eval F.assign = true := by
  apply local_rup F.assign c1869 [c2, c1, c662]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p662 F) (rfl)))
  · decide +kernel
def c1870 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (75,false), (20,false), (87,false), (32,false), (33,false)]
theorem p1870 (F : Frame G 3) : c1870.eval F.assign = true := by
  apply local_rup F.assign c1870 [c4, c5, c663]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p663 F) (rfl)))
  · decide +kernel
def c1871 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (9,false), (10,false), (87,false), (74,false), (18,false), (22,false)]
theorem p1871 (F : Frame G 3) : c1871.eval F.assign = true := by
  apply local_rup F.assign c1871 [c6, c664]
  · exact sat_cons (p6 F) ( sat_cons (p664 F) (rfl))
  · decide +kernel
def c1872 : CNF.Clause Nat := [(75,false), (77,false), (88,false), (87,false), (21,false), (15,false), (5,false), (50,false)]
theorem p1872 (F : Frame G 3) : c1872.eval F.assign = true := by
  apply local_rup F.assign c1872 [c6, c1, c665]
  · exact sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p665 F) (rfl)))
  · decide +kernel
def c1873 : CNF.Clause Nat := [(39,false), (50,false), (20,false), (32,false), (87,false), (74,false), (77,false)]
theorem p1873 (F : Frame G 3) : c1873.eval F.assign = true := by
  apply local_rup F.assign c1873 [c1, c2, c6, c666]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p666 F) (rfl))))
  · decide +kernel
def c1874 : CNF.Clause Nat := [(11,false), (33,false), (75,false), (74,false), (87,false), (21,false), (15,false), (38,false), (50,false)]
theorem p1874 (F : Frame G 3) : c1874.eval F.assign = true := by
  apply local_rup F.assign c1874 [c6, c667]
  · exact sat_cons (p6 F) ( sat_cons (p667 F) (rfl))
  · decide +kernel
def c1875 : CNF.Clause Nat := [(11,false), (88,false), (74,false), (75,false), (32,false), (21,false), (15,false), (38,false), (50,false)]
theorem p1875 (F : Frame G 3) : c1875.eval F.assign = true := by
  apply local_rup F.assign c1875 [c6, c668]
  · exact sat_cons (p6 F) ( sat_cons (p668 F) (rfl))
  · decide +kernel
def c1876 : CNF.Clause Nat := [(38,false), (50,false), (75,false), (18,false), (21,false), (87,false), (88,false)]
theorem p1876 (F : Frame G 3) : c1876.eval F.assign = true := by
  apply local_rup F.assign c1876 [c1, c3, c6, c669]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p669 F) (rfl))))
  · decide +kernel
def c1877 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (20,false), (75,false), (76,false), (32,false), (30,false), (88,false)]
theorem p1877 (F : Frame G 3) : c1877.eval F.assign = true := by
  apply local_rup F.assign c1877 [c1, c670]
  · exact sat_cons (p1 F) ( sat_cons (p670 F) (rfl))
  · decide +kernel
def c1878 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (20,false), (75,false), (76,false), (87,false), (30,false), (33,false)]
theorem p1878 (F : Frame G 3) : c1878.eval F.assign = true := by
  apply local_rup F.assign c1878 [c1, c671]
  · exact sat_cons (p1 F) ( sat_cons (p671 F) (rfl))
  · decide +kernel
def c1879 : CNF.Clause Nat := [(39,false), (50,false), (18,false), (75,false), (32,false), (87,false), (88,false)]
theorem p1879 (F : Frame G 3) : c1879.eval F.assign = true := by
  apply local_rup F.assign c1879 [c1, c2, c6, c672]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p672 F) (rfl))))
  · decide +kernel
def c1880 : CNF.Clause Nat := [(39,false), (50,false), (87,false), (32,false), (75,false), (77,false)]
theorem p1880 (F : Frame G 3) : c1880.eval F.assign = true := by
  apply local_rup F.assign c1880 [c1, c2, c5, c6, c673]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p673 F) (rfl)))))
  · decide +kernel
def c1881 : CNF.Clause Nat := [(38,false), (50,false), (20,false), (21,false), (76,false), (74,false), (88,false)]
theorem p1881 (F : Frame G 3) : c1881.eval F.assign = true := by
  apply local_rup F.assign c1881 [c1, c3, c6, c674]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p674 F) (rfl))))
  · decide +kernel
def c1882 : CNF.Clause Nat := [(38,false), (50,false), (29,false), (75,false), (20,false), (21,false), (87,false), (88,false)]
theorem p1882 (F : Frame G 3) : c1882.eval F.assign = true := by
  apply local_rup F.assign c1882 [c1, c3, c675]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p675 F) (rfl)))
  · decide +kernel
def c1883 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (88,false), (33,false), (75,false), (76,false)]
theorem p1883 (F : Frame G 3) : c1883.eval F.assign = true := by
  apply local_rup F.assign c1883 [c1, c5, c6, c676]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p676 F) (rfl))))
  · decide +kernel
def c1884 : CNF.Clause Nat := [(39,false), (50,false), (20,false), (75,false), (76,false), (32,false), (30,false), (88,false)]
theorem p1884 (F : Frame G 3) : c1884.eval F.assign = true := by
  apply local_rup F.assign c1884 [c1, c2, c677]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p677 F) (rfl)))
  · decide +kernel
def c1885 : CNF.Clause Nat := [(39,false), (50,false), (88,false), (33,false), (75,false), (76,false)]
theorem p1885 (F : Frame G 3) : c1885.eval F.assign = true := by
  apply local_rup F.assign c1885 [c1, c2, c5, c6, c678]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p678 F) (rfl)))))
  · decide +kernel
def c1886 : CNF.Clause Nat := [(39,false), (38,false), (21,false), (10,false), (9,false), (29,false), (74,false), (88,false)]
theorem p1886 (F : Frame G 3) : c1886.eval F.assign = true := by
  apply local_rup F.assign c1886 [c2, c6, c679]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p679 F) (rfl)))
  · decide +kernel
def c1887 : CNF.Clause Nat := [(39,false), (50,false), (20,false), (29,false), (10,false), (87,false), (88,false)]
theorem p1887 (F : Frame G 3) : c1887.eval F.assign = true := by
  apply local_rup F.assign c1887 [c2, c6, c4, c680]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p680 F) (rfl))))
  · decide +kernel
def c1888 : CNF.Clause Nat := [(75,false), (27,false), (50,false), (17,false), (21,false), (87,false), (88,false)]
theorem p1888 (F : Frame G 3) : c1888.eval F.assign = true := by
  apply local_rup F.assign c1888 [c1, c4, c6, c681]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p681 F) (rfl))))
  · decide +kernel
def c1889 : CNF.Clause Nat := [(39,false), (50,false), (74,false), (75,false), (9,false), (10,false), (32,false), (33,false)]
theorem p1889 (F : Frame G 3) : c1889.eval F.assign = true := by
  apply local_rup F.assign c1889 [c2, c5, c682]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p682 F) (rfl)))
  · decide +kernel
def c1890 : CNF.Clause Nat := [(11,false), (88,false), (74,false), (76,false), (32,false), (20,false), (50,false)]
theorem p1890 (F : Frame G 3) : c1890.eval F.assign = true := by
  apply local_rup F.assign c1890 [c1, c6, c2, c683]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p683 F) (rfl))))
  · decide +kernel
def c1891 : CNF.Clause Nat := [(50,false), (39,false), (26,false), (9,false), (11,false), (88,false), (74,false), (76,false)]
theorem p1891 (F : Frame G 3) : c1891.eval F.assign = true := by
  apply local_rup F.assign c1891 [c2, c6, c684]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p684 F) (rfl)))
  · decide +kernel
def c1892 : CNF.Clause Nat := [(21,false), (87,false), (88,false), (77,false), (75,false), (26,false), (5,false), (50,false)]
theorem p1892 (F : Frame G 3) : c1892.eval F.assign = true := by
  apply local_rup F.assign c1892 [c6, c1, c685]
  · exact sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p685 F) (rfl)))
  · decide +kernel
def c1893 : CNF.Clause Nat := [(15,false), (38,false), (50,false), (9,false), (10,false), (76,false), (74,false), (88,false)]
theorem p1893 (F : Frame G 3) : c1893.eval F.assign = true := by
  apply local_rup F.assign c1893 [c3, c6, c686]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p686 F) (rfl)))
  · decide +kernel
def c1894 : CNF.Clause Nat := [(15,false), (38,false), (50,false), (9,false), (76,false), (87,false), (88,false)]
theorem p1894 (F : Frame G 3) : c1894.eval F.assign = true := by
  apply local_rup F.assign c1894 [c3, c6, c4, c687]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p687 F) (rfl))))
  · decide +kernel
def c1895 : CNF.Clause Nat := [(38,false), (26,false), (6,false), (9,false), (75,false), (76,false), (87,false), (88,false)]
theorem p1895 (F : Frame G 3) : c1895.eval F.assign = true := by
  apply local_rup F.assign c1895 [c2, c3, c688]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p688 F) (rfl)))
  · decide +kernel
def c1896 : CNF.Clause Nat := [(17,false), (50,false), (38,false), (26,false), (9,false), (11,false), (77,false), (74,false), (87,false)]
theorem p1896 (F : Frame G 3) : c1896.eval F.assign = true := by
  apply local_rup F.assign c1896 [c6, c689]
  · exact sat_cons (p6 F) ( sat_cons (p689 F) (rfl))
  · decide +kernel
def c1897 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (75,false), (32,false), (87,false), (88,false)]
theorem p1897 (F : Frame G 3) : c1897.eval F.assign = true := by
  apply local_rup F.assign c1897 [c2, c4, c6, c690]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p690 F) (rfl))))
  · decide +kernel
def c1898 : CNF.Clause Nat := [(21,false), (10,false), (39,false), (33,false), (88,false), (74,false), (75,false)]
theorem p1898 (F : Frame G 3) : c1898.eval F.assign = true := by
  apply local_rup F.assign c1898 [c2, c1, c3, c691]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p691 F) (rfl))))
  · decide +kernel
def c1899 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (10,false), (76,false), (29,false), (86,false), (88,false)]
theorem p1899 (F : Frame G 3) : c1899.eval F.assign = true := by
  apply local_rup F.assign c1899 [c2, c6, c692]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p692 F) (rfl)))
  · decide +kernel
def c1900 : CNF.Clause Nat := [(38,false), (39,false), (33,false), (88,false), (86,false), (75,false), (10,false)]
theorem p1900 (F : Frame G 3) : c1900.eval F.assign = true := by
  apply local_rup F.assign c1900 [c2, c3, c4, c693]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p693 F) (rfl))))
  · decide +kernel
def c1901 : CNF.Clause Nat := [(21,false), (76,false), (75,false), (86,false), (88,false), (11,false), (26,false)]
theorem p1901 (F : Frame G 3) : c1901.eval F.assign = true := by
  apply local_rup F.assign c1901 [c2, c1, c3, c694]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p694 F) (rfl))))
  · decide +kernel
def c1902 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (11,false), (33,false), (75,false), (18,false), (87,false)]
theorem p1902 (F : Frame G 3) : c1902.eval F.assign = true := by
  apply local_rup F.assign c1902 [c6, c5, c695]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p695 F) (rfl)))
  · decide +kernel
def c1903 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (76,false), (21,false), (86,false), (33,false)]
theorem p1903 (F : Frame G 3) : c1903.eval F.assign = true := by
  apply local_rup F.assign c1903 [c4, c5, c6, c696]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p696 F) (rfl))))
  · decide +kernel
def c1904 : CNF.Clause Nat := [(38,false), (50,false), (20,false), (18,false), (77,false), (11,false), (8,false), (87,false)]
theorem p1904 (F : Frame G 3) : c1904.eval F.assign = true := by
  apply local_rup F.assign c1904 [c3, c6, c697]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p697 F) (rfl)))
  · decide +kernel
def c1905 : CNF.Clause Nat := [(20,false), (75,false), (77,false), (88,false), (87,false), (10,false), (26,false), (27,false), (50,false)]
theorem p1905 (F : Frame G 3) : c1905.eval F.assign = true := by
  apply local_rup F.assign c1905 [c1, c698]
  · exact sat_cons (p1 F) ( sat_cons (p698 F) (rfl))
  · decide +kernel
def c1906 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (10,false), (32,false), (20,false), (18,false), (77,false), (88,false)]
theorem p1906 (F : Frame G 3) : c1906.eval F.assign = true := by
  apply local_rup F.assign c1906 [c6, c699]
  · exact sat_cons (p6 F) ( sat_cons (p699 F) (rfl))
  · decide +kernel
def c1907 : CNF.Clause Nat := [(15,false), (50,false), (6,false), (8,false), (87,false), (32,false), (75,false), (77,false)]
theorem p1907 (F : Frame G 3) : c1907.eval F.assign = true := by
  apply local_rup F.assign c1907 [c2, c6, c700]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p700 F) (rfl)))
  · decide +kernel
def c1908 : CNF.Clause Nat := [(10,false), (87,false), (88,false), (77,false), (75,false), (20,false), (27,false)]
theorem p1908 (F : Frame G 3) : c1908.eval F.assign = true := by
  apply local_rup F.assign c1908 [c1, c2, c3, c701]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p701 F) (rfl))))
  · decide +kernel
def c1909 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (20,false), (32,false), (10,false), (77,false), (88,false)]
theorem p1909 (F : Frame G 3) : c1909.eval F.assign = true := by
  apply local_rup F.assign c1909 [c6, c4, c702]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p702 F) (rfl)))
  · decide +kernel
def c1910 : CNF.Clause Nat := [(38,false), (50,false), (32,false), (10,false), (75,false), (20,false), (88,false)]
theorem p1910 (F : Frame G 3) : c1910.eval F.assign = true := by
  apply local_rup F.assign c1910 [c3, c4, c5, c703]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p703 F) (rfl))))
  · decide +kernel
def c1911 : CNF.Clause Nat := [(5,false), (50,false), (17,false), (22,false), (88,false), (86,false), (29,false), (76,false)]
theorem p1911 (F : Frame G 3) : c1911.eval F.assign = true := by
  apply local_rup F.assign c1911 [c1, c6, c704]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p704 F) (rfl)))
  · decide +kernel
def c1912 : CNF.Clause Nat := [(15,false), (50,false), (6,false), (11,false), (88,false), (86,false), (29,false), (76,false)]
theorem p1912 (F : Frame G 3) : c1912.eval F.assign = true := by
  apply local_rup F.assign c1912 [c2, c6, c705]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p705 F) (rfl)))
  · decide +kernel
def c1913 : CNF.Clause Nat := [(50,false), (38,false), (11,false), (22,false), (86,false), (75,false), (76,false)]
theorem p1913 (F : Frame G 3) : c1913.eval F.assign = true := by
  apply local_rup F.assign c1913 [c3, c1, c5, c706]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p706 F) (rfl))))
  · decide +kernel
def c1914 : CNF.Clause Nat := [(15,false), (50,false), (6,false), (75,false), (32,false), (87,false), (88,false)]
theorem p1914 (F : Frame G 3) : c1914.eval F.assign = true := by
  apply local_rup F.assign c1914 [c2, c4, c6, c707]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p707 F) (rfl))))
  · decide +kernel
def c1915 : CNF.Clause Nat := [(26,false), (50,false), (22,false), (11,false), (9,false), (75,false), (74,false), (87,false)]
theorem p1915 (F : Frame G 3) : c1915.eval F.assign = true := by
  apply local_rup F.assign c1915 [c3, c2, c708]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p708 F) (rfl)))
  · decide +kernel
def c1916 : CNF.Clause Nat := [(26,false), (50,false), (22,false), (88,false), (87,false), (76,false), (9,false)]
theorem p1916 (F : Frame G 3) : c1916.eval F.assign = true := by
  apply local_rup F.assign c1916 [c3, c2, c4, c709]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p709 F) (rfl))))
  · decide +kernel
def c1917 : CNF.Clause Nat := [(38,false), (26,false), (6,false), (11,false), (88,false), (86,false), (75,false), (76,false)]
theorem p1917 (F : Frame G 3) : c1917.eval F.assign = true := by
  apply local_rup F.assign c1917 [c2, c3, c710]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p710 F) (rfl)))
  · decide +kernel
def c1918 : CNF.Clause Nat := [(50,false), (38,false), (10,false), (76,false), (75,false), (86,false), (22,false)]
theorem p1918 (F : Frame G 3) : c1918.eval F.assign = true := by
  apply local_rup F.assign c1918 [c3, c1, c5, c711]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p711 F) (rfl))))
  · decide +kernel
def c1919 : CNF.Clause Nat := [(6,false), (38,false), (22,false), (88,false), (86,false), (75,false), (76,false)]
theorem p1919 (F : Frame G 3) : c1919.eval F.assign = true := by
  apply local_rup F.assign c1919 [c3, c1, c2, c712]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p712 F) (rfl))))
  · decide +kernel
def c1920 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (21,false), (10,false), (29,false), (86,false), (88,false)]
theorem p1920 (F : Frame G 3) : c1920.eval F.assign = true := by
  apply local_rup F.assign c1920 [c4, c6, c713]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p713 F) (rfl)))
  · decide +kernel
def c1921 : CNF.Clause Nat := [(26,false), (50,false), (5,false), (75,false), (86,false), (87,false), (21,false), (22,false)]
theorem p1921 (F : Frame G 3) : c1921.eval F.assign = true := by
  apply local_rup F.assign c1921 [c3, c4, c714]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p714 F) (rfl)))
  · decide +kernel
def c1922 : CNF.Clause Nat := [(38,false), (50,false), (33,false), (22,false), (21,false), (10,false), (74,false), (86,false)]
theorem p1922 (F : Frame G 3) : c1922.eval F.assign = true := by
  apply local_rup F.assign c1922 [c3, c4, c715]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p715 F) (rfl)))
  · decide +kernel
def c1923 : CNF.Clause Nat := [(75,false), (86,false), (87,false), (32,false), (33,false), (22,false), (50,false)]
theorem p1923 (F : Frame G 3) : c1923.eval F.assign = true := by
  apply local_rup F.assign c1923 [c1, c4, c2, c716]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p716 F) (rfl))))
  · decide +kernel
def c1924 : CNF.Clause Nat := [(15,false), (50,false), (75,false), (10,false), (87,false), (88,false)]
theorem p1924 (F : Frame G 3) : c1924.eval F.assign = true := by
  apply local_rup F.assign c1924 [c2, c3, c6, c4, c717]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p717 F) (rfl)))))
  · decide +kernel
def c1925 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (22,false), (88,false), (87,false), (10,false), (29,false)]
theorem p1925 (F : Frame G 3) : c1925.eval F.assign = true := by
  apply local_rup F.assign c1925 [c4, c6, c719]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p719 F) (rfl)))
  · decide +kernel
def c1926 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (21,false), (32,false), (29,false), (9,false), (86,false), (88,false)]
theorem p1926 (F : Frame G 3) : c1926.eval F.assign = true := by
  apply local_rup F.assign c1926 [c4, c720]
  · exact sat_cons (p4 F) ( sat_cons (p720 F) (rfl))
  · decide +kernel
def c1927 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (21,false), (87,false), (88,false), (11,false), (29,false)]
theorem p1927 (F : Frame G 3) : c1927.eval F.assign = true := by
  apply local_rup F.assign c1927 [c4, c6, c721]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p721 F) (rfl)))
  · decide +kernel
def c1928 : CNF.Clause Nat := [(26,false), (50,false), (21,false), (10,false), (11,false), (88,false), (74,false), (75,false)]
theorem p1928 (F : Frame G 3) : c1928.eval F.assign = true := by
  apply local_rup F.assign c1928 [c3, c2, c722]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p722 F) (rfl)))
  · decide +kernel
def c1929 : CNF.Clause Nat := [(6,false), (50,false), (22,false), (88,false), (87,false), (32,false), (29,false), (75,false)]
theorem p1929 (F : Frame G 3) : c1929.eval F.assign = true := by
  apply local_rup F.assign c1929 [c1, c2, c723]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p723 F) (rfl)))
  · decide +kernel
def c1930 : CNF.Clause Nat := [(17,false), (50,false), (38,false), (26,false), (75,false), (10,false), (87,false), (88,false)]
theorem p1930 (F : Frame G 3) : c1930.eval F.assign = true := by
  apply local_rup F.assign c1930 [c6, c4, c724]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p724 F) (rfl)))
  · decide +kernel
def c1931 : CNF.Clause Nat := [(17,false), (50,false), (38,false), (9,false), (29,false), (76,false), (87,false), (88,false)]
theorem p1931 (F : Frame G 3) : c1931.eval F.assign = true := by
  apply local_rup F.assign c1931 [c1, c6, c725]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p725 F) (rfl)))
  · decide +kernel
def c1932 : CNF.Clause Nat := [(26,false), (50,false), (18,false), (76,false), (10,false), (9,false), (86,false), (88,false)]
theorem p1932 (F : Frame G 3) : c1932.eval F.assign = true := by
  apply local_rup F.assign c1932 [c3, c2, c726]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p726 F) (rfl)))
  · decide +kernel
def c1933 : CNF.Clause Nat := [(26,false), (50,false), (21,false), (76,false), (9,false), (86,false), (88,false)]
theorem p1933 (F : Frame G 3) : c1933.eval F.assign = true := by
  apply local_rup F.assign c1933 [c3, c2, c4, c727]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p727 F) (rfl))))
  · decide +kernel
def c1934 : CNF.Clause Nat := [(17,false), (50,false), (38,false), (26,false), (9,false), (10,false), (76,false), (74,false), (88,false)]
theorem p1934 (F : Frame G 3) : c1934.eval F.assign = true := by
  apply local_rup F.assign c1934 [c6, c728]
  · exact sat_cons (p6 F) ( sat_cons (p728 F) (rfl))
  · decide +kernel
def c1935 : CNF.Clause Nat := [(38,false), (50,false), (20,false), (18,false), (76,false), (87,false), (88,false)]
theorem p1935 (F : Frame G 3) : c1935.eval F.assign = true := by
  apply local_rup F.assign c1935 [c1, c3, c6, c729]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p729 F) (rfl))))
  · decide +kernel
def c1936 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (20,false), (29,false), (76,false), (87,false), (88,false)]
theorem p1936 (F : Frame G 3) : c1936.eval F.assign = true := by
  apply local_rup F.assign c1936 [c1, c6, c730]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p730 F) (rfl)))
  · decide +kernel
def c1937 : CNF.Clause Nat := [(38,false), (50,false), (20,false), (18,false), (10,false), (87,false), (88,false)]
theorem p1937 (F : Frame G 3) : c1937.eval F.assign = true := by
  apply local_rup F.assign c1937 [c3, c6, c4, c731]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p731 F) (rfl))))
  · decide +kernel
def c1938 : CNF.Clause Nat := [(38,false), (50,false), (86,false), (87,false), (21,false), (18,false), (77,false)]
theorem p1938 (F : Frame G 3) : c1938.eval F.assign = true := by
  apply local_rup F.assign c1938 [c1, c3, c6, c732]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p732 F) (rfl))))
  · decide +kernel
def c1939 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (18,false), (9,false), (32,false), (87,false), (88,false)]
theorem p1939 (F : Frame G 3) : c1939.eval F.assign = true := by
  apply local_rup F.assign c1939 [c4, c6, c733]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p733 F) (rfl)))
  · decide +kernel
def c1940 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (18,false), (76,false), (87,false), (8,false), (9,false), (33,false)]
theorem p1940 (F : Frame G 3) : c1940.eval F.assign = true := by
  apply local_rup F.assign c1940 [c6, c734]
  · exact sat_cons (p6 F) ( sat_cons (p734 F) (rfl))
  · decide +kernel
def c1941 : CNF.Clause Nat := [(9,false), (33,false), (88,false), (74,false), (76,false), (21,false), (50,false)]
theorem p1941 (F : Frame G 3) : c1941.eval F.assign = true := by
  apply local_rup F.assign c1941 [c1, c6, c2, c735]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p735 F) (rfl))))
  · decide +kernel
def c1942 : CNF.Clause Nat := [(17,false), (50,false), (38,false), (74,false), (88,false), (33,false), (98,false)]
theorem p1942 (F : Frame G 3) : c1942.eval F.assign = true := by
  apply local_rup F.assign c1942 [c1, c4, c6, c736]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p736 F) (rfl))))
  · decide +kernel
def c1943 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (18,false), (76,false), (32,false), (86,false), (88,false)]
theorem p1943 (F : Frame G 3) : c1943.eval F.assign = true := by
  apply local_rup F.assign c1943 [c1, c6, c737]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p737 F) (rfl)))
  · decide +kernel
def c1944 : CNF.Clause Nat := [(76,false), (98,false), (86,false), (88,false), (33,false), (27,false), (17,false)]
theorem p1944 (F : Frame G 3) : c1944.eval F.assign = true := by
  apply local_rup F.assign c1944 [c1, c4, c2, c738]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p738 F) (rfl))))
  · decide +kernel
def c1945 : CNF.Clause Nat := [(15,false), (50,false), (29,false), (11,false), (88,false), (86,false), (98,false)]
theorem p1945 (F : Frame G 3) : c1945.eval F.assign = true := by
  apply local_rup F.assign c1945 [c2, c3, c4, c739]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p739 F) (rfl))))
  · decide +kernel
def c1946 : CNF.Clause Nat := [(50,false), (38,false), (76,false), (98,false), (86,false), (22,false)]
theorem p1946 (F : Frame G 3) : c1946.eval F.assign = true := by
  apply local_rup F.assign c1946 [c3, c1, c4, c5, c740]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p740 F) (rfl)))))
  · decide +kernel
def c1947 : CNF.Clause Nat := [(50,false), (38,false), (76,false), (98,false), (20,false), (88,false)]
theorem p1947 (F : Frame G 3) : c1947.eval F.assign = true := by
  apply local_rup F.assign c1947 [c3, c1, c4, c5, c741]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p741 F) (rfl)))))
  · decide +kernel
def c1948 : CNF.Clause Nat := [(38,false), (50,false), (98,false), (21,false), (18,false), (74,false), (88,false)]
theorem p1948 (F : Frame G 3) : c1948.eval F.assign = true := by
  apply local_rup F.assign c1948 [c1, c3, c6, c742]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p742 F) (rfl))))
  · decide +kernel
def c1949 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (18,false), (77,false), (88,false), (30,false), (98,false)]
theorem p1949 (F : Frame G 3) : c1949.eval F.assign = true := by
  apply local_rup F.assign c1949 [c1, c6, c743]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p743 F) (rfl)))
  · decide +kernel
def c1950 : CNF.Clause Nat := [(5,false), (50,false), (98,false), (21,false), (18,false), (77,false), (88,false)]
theorem p1950 (F : Frame G 3) : c1950.eval F.assign = true := by
  apply local_rup F.assign c1950 [c1, c3, c6, c744]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p744 F) (rfl))))
  · decide +kernel
def c1951 : CNF.Clause Nat := [(38,false), (50,false), (98,false), (21,false), (18,false), (77,false), (88,false)]
theorem p1951 (F : Frame G 3) : c1951.eval F.assign = true := by
  apply local_rup F.assign c1951 [c1, c3, c6, c745]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p745 F) (rfl))))
  · decide +kernel
def c1952 : CNF.Clause Nat := [(38,false), (17,false), (98,false), (10,false), (74,false), (88,false)]
theorem p1952 (F : Frame G 3) : c1952.eval F.assign = true := by
  apply local_rup F.assign c1952 [c2, c3, c6, c4, c746]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p746 F) (rfl)))))
  · decide +kernel
def c1953 : CNF.Clause Nat := [(17,false), (50,false), (38,false), (77,false), (88,false), (87,false), (32,false)]
theorem p1953 (F : Frame G 3) : c1953.eval F.assign = true := by
  apply local_rup F.assign c1953 [c1, c4, c6, c747]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p747 F) (rfl))))
  · decide +kernel
def c1954 : CNF.Clause Nat := [(50,false), (38,false), (77,false), (22,false), (20,false), (86,false), (87,false)]
theorem p1954 (F : Frame G 3) : c1954.eval F.assign = true := by
  apply local_rup F.assign c1954 [c3, c1, c4, c748]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p748 F) (rfl))))
  · decide +kernel
def c1955 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (29,false), (33,false), (88,false), (86,false), (20,false), (21,false)]
theorem p1955 (F : Frame G 3) : c1955.eval F.assign = true := by
  apply local_rup F.assign c1955 [c4, c749]
  · exact sat_cons (p4 F) ( sat_cons (p749 F) (rfl))
  · decide +kernel
def c1956 : CNF.Clause Nat := [(15,false), (50,false), (6,false), (10,false), (76,false), (29,false), (86,false), (88,false)]
theorem p1956 (F : Frame G 3) : c1956.eval F.assign = true := by
  apply local_rup F.assign c1956 [c2, c6, c750]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p750 F) (rfl)))
  · decide +kernel
def c1957 : CNF.Clause Nat := [(38,false), (6,false), (86,false), (87,false), (76,false), (77,false)]
theorem p1957 (F : Frame G 3) : c1957.eval F.assign = true := by
  apply local_rup F.assign c1957 [c2, c1, c3, c6, c751]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p751 F) (rfl)))))
  · decide +kernel
def c1958 : CNF.Clause Nat := [(38,false), (26,false), (6,false), (10,false), (87,false), (86,false), (75,false), (77,false)]
theorem p1958 (F : Frame G 3) : c1958.eval F.assign = true := by
  apply local_rup F.assign c1958 [c2, c3, c752]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p752 F) (rfl)))
  · decide +kernel
def c1959 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (30,false), (32,false), (76,false), (75,false), (9,false), (11,false)]
theorem p1959 (F : Frame G 3) : c1959.eval F.assign = true := by
  apply local_rup F.assign c1959 [c5, c753]
  · exact sat_cons (p5 F) ( sat_cons (p753 F) (rfl))
  · decide +kernel
def c1960 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (75,false), (32,false), (21,false), (88,false)]
theorem p1960 (F : Frame G 3) : c1960.eval F.assign = true := by
  apply local_rup F.assign c1960 [c4, c6, c5, c754]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p754 F) (rfl))))
  · decide +kernel
def c1961 : CNF.Clause Nat := [(5,false), (50,false), (75,false), (76,false), (21,false), (88,false)]
theorem p1961 (F : Frame G 3) : c1961.eval F.assign = true := by
  apply local_rup F.assign c1961 [c1, c3, c6, c5, c755]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p755 F) (rfl)))))
  · decide +kernel
def c1962 : CNF.Clause Nat := [(8,false), (88,false), (77,false), (75,false), (20,false), (21,false), (32,false), (27,false), (50,false)]
theorem p1962 (F : Frame G 3) : c1962.eval F.assign = true := by
  apply local_rup F.assign c1962 [c1, c756]
  · exact sat_cons (p1 F) ( sat_cons (p756 F) (rfl))
  · decide +kernel
def c1963 : CNF.Clause Nat := [(15,false), (50,false), (75,false), (76,false), (10,false), (8,false), (88,false)]
theorem p1963 (F : Frame G 3) : c1963.eval F.assign = true := by
  apply local_rup F.assign c1963 [c2, c3, c6, c757]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p757 F) (rfl))))
  · decide +kernel
def c1964 : CNF.Clause Nat := [(38,false), (50,false), (29,false), (76,false), (87,false), (86,false), (20,false), (22,false)]
theorem p1964 (F : Frame G 3) : c1964.eval F.assign = true := by
  apply local_rup F.assign c1964 [c1, c3, c758]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p758 F) (rfl)))
  · decide +kernel
def c1965 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (18,false), (21,false), (32,false), (86,false), (88,false)]
theorem p1965 (F : Frame G 3) : c1965.eval F.assign = true := by
  apply local_rup F.assign c1965 [c4, c6, c759]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p759 F) (rfl)))
  · decide +kernel
def c1966 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (29,false), (20,false), (21,false), (87,false), (88,false)]
theorem p1966 (F : Frame G 3) : c1966.eval F.assign = true := by
  apply local_rup F.assign c1966 [c4, c6, c760]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p760 F) (rfl)))
  · decide +kernel
def c1967 : CNF.Clause Nat := [(26,false), (27,false), (50,false), (6,false), (75,false), (20,false), (21,false), (87,false), (88,false)]
theorem p1967 (F : Frame G 3) : c1967.eval F.assign = true := by
  apply local_rup F.assign c1967 [c4, c761]
  · exact sat_cons (p4 F) ( sat_cons (p761 F) (rfl))
  · decide +kernel
def c1968 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (20,false), (18,false), (10,false), (87,false), (88,false)]
theorem p1968 (F : Frame G 3) : c1968.eval F.assign = true := by
  apply local_rup F.assign c1968 [c6, c4, c762]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p762 F) (rfl)))
  · decide +kernel
def c1969 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (18,false), (20,false), (32,false), (87,false), (88,false)]
theorem p1969 (F : Frame G 3) : c1969.eval F.assign = true := by
  apply local_rup F.assign c1969 [c4, c6, c763]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p763 F) (rfl)))
  · decide +kernel
def c1970 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (29,false), (20,false), (21,false), (87,false), (88,false)]
theorem p1970 (F : Frame G 3) : c1970.eval F.assign = true := by
  apply local_rup F.assign c1970 [c4, c6, c764]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p764 F) (rfl)))
  · decide +kernel
def c1971 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (18,false), (21,false), (32,false), (86,false), (88,false)]
theorem p1971 (F : Frame G 3) : c1971.eval F.assign = true := by
  apply local_rup F.assign c1971 [c4, c6, c765]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p765 F) (rfl)))
  · decide +kernel
def c1972 : CNF.Clause Nat := [(39,false), (50,false), (21,false), (32,false), (29,false), (9,false), (86,false), (88,false)]
theorem p1972 (F : Frame G 3) : c1972.eval F.assign = true := by
  apply local_rup F.assign c1972 [c2, c4, c766]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p766 F) (rfl)))
  · decide +kernel
def c1973 : CNF.Clause Nat := [(39,false), (50,false), (21,false), (10,false), (29,false), (86,false), (88,false)]
theorem p1973 (F : Frame G 3) : c1973.eval F.assign = true := by
  apply local_rup F.assign c1973 [c2, c4, c6, c767]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p767 F) (rfl))))
  · decide +kernel
def c1974 : CNF.Clause Nat := [(39,false), (38,false), (27,false), (20,false), (21,false), (87,false), (74,false), (11,false)]
theorem p1974 (F : Frame G 3) : c1974.eval F.assign = true := by
  apply local_rup F.assign c1974 [c6, c4, c768]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p768 F) (rfl)))
  · decide +kernel
def c1975 : CNF.Clause Nat := [(38,false), (39,false), (20,false), (18,false), (10,false), (87,false), (88,false)]
theorem p1975 (F : Frame G 3) : c1975.eval F.assign = true := by
  apply local_rup F.assign c1975 [c3, c6, c4, c769]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p769 F) (rfl))))
  · decide +kernel
def c1976 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (29,false), (20,false), (21,false), (87,false), (88,false)]
theorem p1976 (F : Frame G 3) : c1976.eval F.assign = true := by
  apply local_rup F.assign c1976 [c4, c6, c770]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p770 F) (rfl)))
  · decide +kernel
def c1977 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (77,false), (33,false), (20,false), (87,false)]
theorem p1977 (F : Frame G 3) : c1977.eval F.assign = true := by
  apply local_rup F.assign c1977 [c4, c6, c5, c771]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p771 F) (rfl))))
  · decide +kernel
def c1978 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (77,false), (22,false), (86,false), (32,false)]
theorem p1978 (F : Frame G 3) : c1978.eval F.assign = true := by
  apply local_rup F.assign c1978 [c4, c5, c6, c772]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p772 F) (rfl))))
  · decide +kernel
def c1979 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (86,false), (88,false), (22,false), (18,false), (76,false)]
theorem p1979 (F : Frame G 3) : c1979.eval F.assign = true := by
  apply local_rup F.assign c1979 [c1, c6, c773]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p773 F) (rfl)))
  · decide +kernel
def c1980 : CNF.Clause Nat := [(9,false), (33,false), (88,false), (87,false), (76,false), (18,false), (50,false)]
theorem p1980 (F : Frame G 3) : c1980.eval F.assign = true := by
  apply local_rup F.assign c1980 [c1, c6, c2, c774]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p774 F) (rfl))))
  · decide +kernel
def c1981 : CNF.Clause Nat := [(11,false), (88,false), (74,false), (76,false), (32,false), (20,false), (38,false), (39,false)]
theorem p1981 (F : Frame G 3) : c1981.eval F.assign = true := by
  apply local_rup F.assign c1981 [c6, c2, c775]
  · exact sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p775 F) (rfl)))
  · decide +kernel
def c1982 : CNF.Clause Nat := [(27,false), (39,false), (76,false), (21,false), (20,false), (86,false), (88,false)]
theorem p1982 (F : Frame G 3) : c1982.eval F.assign = true := by
  apply local_rup F.assign c1982 [c3, c1, c4, c776]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p776 F) (rfl))))
  · decide +kernel
def c1983 : CNF.Clause Nat := [(20,false), (86,false), (88,false), (33,false), (26,false), (39,false), (6,false), (76,false)]
theorem p1983 (F : Frame G 3) : c1983.eval F.assign = true := by
  apply local_rup F.assign c1983 [c2, c4, c777]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p777 F) (rfl)))
  · decide +kernel
def c1984 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (76,false), (32,false), (20,false), (88,false)]
theorem p1984 (F : Frame G 3) : c1984.eval F.assign = true := by
  apply local_rup F.assign c1984 [c4, c6, c5, c778]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p778 F) (rfl))))
  · decide +kernel
def c1985 : CNF.Clause Nat := [(17,false), (39,false), (76,false), (32,false), (86,false), (88,false)]
theorem p1985 (F : Frame G 3) : c1985.eval F.assign = true := by
  apply local_rup F.assign c1985 [c2, c1, c4, c6, c779]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p779 F) (rfl)))))
  · decide +kernel
def c1986 : CNF.Clause Nat := [(50,false), (39,false), (76,false), (32,false), (86,false), (88,false)]
theorem p1986 (F : Frame G 3) : c1986.eval F.assign = true := by
  apply local_rup F.assign c1986 [c2, c1, c4, c6, c780]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p780 F) (rfl)))))
  · decide +kernel
def c1987 : CNF.Clause Nat := [(5,false), (39,false), (17,false), (20,false), (33,false), (88,false), (74,false), (76,false)]
theorem p1987 (F : Frame G 3) : c1987.eval F.assign = true := by
  apply local_rup F.assign c1987 [c1, c6, c781]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p781 F) (rfl)))
  · decide +kernel
def c1988 : CNF.Clause Nat := [(5,false), (39,false), (33,false), (88,false), (86,false), (20,false), (18,false), (76,false)]
theorem p1988 (F : Frame G 3) : c1988.eval F.assign = true := by
  apply local_rup F.assign c1988 [c1, c3, c782]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p782 F) (rfl)))
  · decide +kernel
def c1989 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (20,false), (29,false), (10,false), (87,false), (88,false)]
theorem p1989 (F : Frame G 3) : c1989.eval F.assign = true := by
  apply local_rup F.assign c1989 [c6, c4, c783]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p783 F) (rfl)))
  · decide +kernel
def c1990 : CNF.Clause Nat := [(39,false), (50,false), (22,false), (11,false), (9,false), (29,false), (74,false), (87,false)]
theorem p1990 (F : Frame G 3) : c1990.eval F.assign = true := by
  apply local_rup F.assign c1990 [c2, c6, c784]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p784 F) (rfl)))
  · decide +kernel
def c1991 : CNF.Clause Nat := [(26,false), (39,false), (50,false), (5,false), (76,false), (21,false), (20,false), (86,false), (88,false)]
theorem p1991 (F : Frame G 3) : c1991.eval F.assign = true := by
  apply local_rup F.assign c1991 [c4, c785]
  · exact sat_cons (p4 F) ( sat_cons (p785 F) (rfl))
  · decide +kernel
def c1992 : CNF.Clause Nat := [(39,false), (38,false), (21,false), (76,false), (75,false), (86,false), (8,false), (11,false)]
theorem p1992 (F : Frame G 3) : c1992.eval F.assign = true := by
  apply local_rup F.assign c1992 [c3, c2, c786]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p786 F) (rfl)))
  · decide +kernel
def c1993 : CNF.Clause Nat := [(38,false), (17,false), (33,false), (88,false), (86,false), (75,false), (76,false)]
theorem p1993 (F : Frame G 3) : c1993.eval F.assign = true := by
  apply local_rup F.assign c1993 [c1, c2, c3, c787]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p787 F) (rfl))))
  · decide +kernel
def c1994 : CNF.Clause Nat := [(10,false), (76,false), (75,false), (27,false), (38,false), (39,false), (17,false), (88,false)]
theorem p1994 (F : Frame G 3) : c1994.eval F.assign = true := by
  apply local_rup F.assign c1994 [c6, c5, c788]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p788 F) (rfl)))
  · decide +kernel
def c1995 : CNF.Clause Nat := [(9,false), (39,false), (50,false), (22,false), (77,false), (74,false), (87,false)]
theorem p1995 (F : Frame G 3) : c1995.eval F.assign = true := by
  apply local_rup F.assign c1995 [c6, c1, c2, c789]
  · exact sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p789 F) (rfl))))
  · decide +kernel
def c1996 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (9,false), (10,false), (21,false), (74,false), (77,false)]
theorem p1996 (F : Frame G 3) : c1996.eval F.assign = true := by
  apply local_rup F.assign c1996 [c6, c5, c790]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p790 F) (rfl)))
  · decide +kernel
def c1997 : CNF.Clause Nat := [(10,false), (76,false), (75,false), (27,false), (50,false), (17,false), (88,false)]
theorem p1997 (F : Frame G 3) : c1997.eval F.assign = true := by
  apply local_rup F.assign c1997 [c1, c6, c5, c791]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p791 F) (rfl))))
  · decide +kernel
def c1998 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (22,false), (88,false), (30,false), (9,false), (76,false)]
theorem p1998 (F : Frame G 3) : c1998.eval F.assign = true := by
  apply local_rup F.assign c1998 [c6, c4, c792]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p792 F) (rfl)))
  · decide +kernel
def c1999 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (9,false), (76,false), (21,false), (88,false)]
theorem p1999 (F : Frame G 3) : c1999.eval F.assign = true := by
  apply local_rup F.assign c1999 [c6, c4, c5, c793]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p793 F) (rfl))))
  · decide +kernel
def c2000 : CNF.Clause Nat := [(9,false), (39,false), (50,false), (87,false), (76,false), (77,false)]
theorem p2000 (F : Frame G 3) : c2000.eval F.assign = true := by
  apply local_rup F.assign c2000 [c6, c1, c2, c5, c794]
  · exact sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p794 F) (rfl)))))
  · decide +kernel
def c2001 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (88,false), (33,false), (9,false), (76,false)]
theorem p2001 (F : Frame G 3) : c2001.eval F.assign = true := by
  apply local_rup F.assign c2001 [c5, c6, c4, c795]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p795 F) (rfl))))
  · decide +kernel
def c2002 : CNF.Clause Nat := [(38,false), (6,false), (29,false), (77,false), (88,false), (86,false), (98,false)]
theorem p2002 (F : Frame G 3) : c2002.eval F.assign = true := by
  apply local_rup F.assign c2002 [c2, c1, c3, c796]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p796 F) (rfl))))
  · decide +kernel
def c2003 : CNF.Clause Nat := [(38,false), (6,false), (33,false), (77,false), (74,false), (86,false), (98,false)]
theorem p2003 (F : Frame G 3) : c2003.eval F.assign = true := by
  apply local_rup F.assign c2003 [c2, c1, c3, c797]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p797 F) (rfl))))
  · decide +kernel
def c2004 : CNF.Clause Nat := [(50,false), (39,false), (77,false), (33,false), (86,false), (87,false)]
theorem p2004 (F : Frame G 3) : c2004.eval F.assign = true := by
  apply local_rup F.assign c2004 [c2, c1, c4, c6, c798]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p798 F) (rfl)))))
  · decide +kernel
def c2005 : CNF.Clause Nat := [(38,false), (39,false), (86,false), (88,false), (11,false), (76,false)]
theorem p2005 (F : Frame G 3) : c2005.eval F.assign = true := by
  apply local_rup F.assign c2005 [c2, c3, c6, c4, c799]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p799 F) (rfl)))))
  · decide +kernel
def c2006 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (8,false), (88,false), (33,false), (75,false), (76,false)]
theorem p2006 (F : Frame G 3) : c2006.eval F.assign = true := by
  apply local_rup F.assign c2006 [c2, c6, c800]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p800 F) (rfl)))
  · decide +kernel
def c2007 : CNF.Clause Nat := [(38,false), (39,false), (33,false), (88,false), (74,false), (9,false), (98,false)]
theorem p2007 (F : Frame G 3) : c2007.eval F.assign = true := by
  apply local_rup F.assign c2007 [c2, c3, c4, c801]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p801 F) (rfl))))
  · decide +kernel
def c2008 : CNF.Clause Nat := [(15,false), (39,false), (98,false), (76,false), (8,false), (88,false)]
theorem p2008 (F : Frame G 3) : c2008.eval F.assign = true := by
  apply local_rup F.assign c2008 [c2, c3, c6, c4, c802]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p802 F) (rfl)))))
  · decide +kernel
def c2009 : CNF.Clause Nat := [(38,false), (39,false), (98,false), (76,false), (8,false), (88,false)]
theorem p2009 (F : Frame G 3) : c2009.eval F.assign = true := by
  apply local_rup F.assign c2009 [c2, c3, c6, c4, c803]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p803 F) (rfl)))))
  · decide +kernel
def c2010 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (76,false), (98,false), (30,false), (88,false)]
theorem p2010 (F : Frame G 3) : c2010.eval F.assign = true := by
  apply local_rup F.assign c2010 [c2, c4, c6, c804]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p804 F) (rfl))))
  · decide +kernel
def c2011 : CNF.Clause Nat := [(38,false), (39,false), (9,false), (76,false), (87,false), (88,false)]
theorem p2011 (F : Frame G 3) : c2011.eval F.assign = true := by
  apply local_rup F.assign c2011 [c2, c3, c6, c4, c805]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p805 F) (rfl)))))
  · decide +kernel
def c2012 : CNF.Clause Nat := [(38,false), (27,false), (17,false), (18,false), (76,false), (98,false), (86,false), (88,false)]
theorem p2012 (F : Frame G 3) : c2012.eval F.assign = true := by
  apply local_rup F.assign c2012 [c1, c3, c806]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p806 F) (rfl)))
  · decide +kernel
def c2013 : CNF.Clause Nat := [(38,false), (17,false), (29,false), (76,false), (98,false), (86,false), (88,false)]
theorem p2013 (F : Frame G 3) : c2013.eval F.assign = true := by
  apply local_rup F.assign c2013 [c1, c2, c3, c807]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p807 F) (rfl))))
  · decide +kernel
def c2014 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (10,false), (76,false), (77,false), (22,false), (86,false)]
theorem p2014 (F : Frame G 3) : c2014.eval F.assign = true := by
  apply local_rup F.assign c2014 [c3, c5, c808]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p808 F) (rfl)))
  · decide +kernel
def c2015 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (74,false), (88,false), (33,false), (98,false)]
theorem p2015 (F : Frame G 3) : c2015.eval F.assign = true := by
  apply local_rup F.assign c2015 [c2, c4, c6, c809]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p809 F) (rfl))))
  · decide +kernel
def c2016 : CNF.Clause Nat := [(27,false), (39,false), (18,false), (22,false), (88,false), (86,false), (98,false)]
theorem p2016 (F : Frame G 3) : c2016.eval F.assign = true := by
  apply local_rup F.assign c2016 [c3, c1, c4, c810]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p810 F) (rfl))))
  · decide +kernel
def c2017 : CNF.Clause Nat := [(5,false), (39,false), (29,false), (76,false), (98,false), (86,false), (22,false)]
theorem p2017 (F : Frame G 3) : c2017.eval F.assign = true := by
  apply local_rup F.assign c2017 [c1, c3, c5, c811]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p811 F) (rfl))))
  · decide +kernel
def c2018 : CNF.Clause Nat := [(76,false), (98,false), (27,false), (38,false), (39,false), (17,false), (88,false)]
theorem p2018 (F : Frame G 3) : c2018.eval F.assign = true := by
  apply local_rup F.assign c2018 [c4, c6, c5, c812]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p812 F) (rfl))))
  · decide +kernel
def c2019 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (76,false), (98,false), (20,false), (88,false)]
theorem p2019 (F : Frame G 3) : c2019.eval F.assign = true := by
  apply local_rup F.assign c2019 [c3, c4, c5, c813]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p813 F) (rfl))))
  · decide +kernel
def c2020 : CNF.Clause Nat := [(27,false), (39,false), (76,false), (98,false), (20,false), (88,false)]
theorem p2020 (F : Frame G 3) : c2020.eval F.assign = true := by
  apply local_rup F.assign c2020 [c3, c1, c4, c5, c814]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p814 F) (rfl)))))
  · decide +kernel
def c2021 : CNF.Clause Nat := [(5,false), (39,false), (86,false), (88,false), (22,false), (18,false), (76,false)]
theorem p2021 (F : Frame G 3) : c2021.eval F.assign = true := by
  apply local_rup F.assign c2021 [c1, c3, c6, c815]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p815 F) (rfl))))
  · decide +kernel
def c2022 : CNF.Clause Nat := [(5,false), (38,false), (39,false), (17,false), (22,false), (33,false), (86,false), (74,false), (76,false)]
theorem p2022 (F : Frame G 3) : c2022.eval F.assign = true := by
  apply local_rup F.assign c2022 [c6, c816]
  · exact sat_cons (p6 F) ( sat_cons (p816 F) (rfl))
  · decide +kernel
def c2023 : CNF.Clause Nat := [(98,false), (76,false), (74,false), (88,false), (11,false), (15,false), (50,false)]
theorem p2023 (F : Frame G 3) : c2023.eval F.assign = true := by
  apply local_rup F.assign c2023 [c6, c1, c2, c817]
  · exact sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p817 F) (rfl))))
  · decide +kernel
def c2024 : CNF.Clause Nat := [(26,false), (39,false), (50,false), (20,false), (98,false), (10,false), (74,false), (88,false)]
theorem p2024 (F : Frame G 3) : c2024.eval F.assign = true := by
  apply local_rup F.assign c2024 [c2, c4, c818]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p818 F) (rfl)))
  · decide +kernel
def c2025 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (29,false), (98,false), (87,false), (22,false)]
theorem p2025 (F : Frame G 3) : c2025.eval F.assign = true := by
  apply local_rup F.assign c2025 [c4, c6, c5, c819]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p819 F) (rfl))))
  · decide +kernel
def c2026 : CNF.Clause Nat := [(98,false), (76,false), (39,false), (50,false), (88,false)]
theorem p2026 (F : Frame G 3) : c2026.eval F.assign = true := by
  apply local_rup F.assign c2026 [c6, c4, c1, c2, c5, c820]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p820 F) (rfl))))))
  · decide +kernel
def c2027 : CNF.Clause Nat := [(15,false), (50,false), (30,false), (74,false), (75,false), (98,false), (110,false)]
theorem p2027 (F : Frame G 3) : c2027.eval F.assign = true := by
  apply local_rup F.assign c2027 [c1, c2, c3, c821]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p821 F) (rfl))))
  · decide +kernel
def c2028 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (18,false), (22,false), (33,false), (86,false), (87,false)]
theorem p2028 (F : Frame G 3) : c2028.eval F.assign = true := by
  apply local_rup F.assign c2028 [c4, c6, c822]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p822 F) (rfl)))
  · decide +kernel
def c2029 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (18,false), (88,false), (33,false), (98,false)]
theorem p2029 (F : Frame G 3) : c2029.eval F.assign = true := by
  apply local_rup F.assign c2029 [c4, c5, c6, c823]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p823 F) (rfl))))
  · decide +kernel
def c2030 : CNF.Clause Nat := [(98,false), (87,false), (88,false), (77,false), (15,false), (50,false)]
theorem p2030 (F : Frame G 3) : c2030.eval F.assign = true := by
  apply local_rup F.assign c2030 [c6, c4, c1, c2, c824]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p824 F) (rfl)))))
  · decide +kernel
def c2031 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (30,false), (98,false), (10,false), (77,false)]
theorem p2031 (F : Frame G 3) : c2031.eval F.assign = true := by
  apply local_rup F.assign c2031 [c5, c6, c4, c825]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p825 F) (rfl))))
  · decide +kernel
def c2032 : CNF.Clause Nat := [(27,false), (39,false), (15,false), (22,false), (77,false), (76,false), (10,false), (8,false), (86,false)]
theorem p2032 (F : Frame G 3) : c2032.eval F.assign = true := by
  apply local_rup F.assign c2032 [c3, c826]
  · exact sat_cons (p3 F) ( sat_cons (p826 F) (rfl))
  · decide +kernel
def c2033 : CNF.Clause Nat := [(38,false), (39,false), (33,false), (77,false), (76,false), (10,false), (8,false), (86,false)]
theorem p2033 (F : Frame G 3) : c2033.eval F.assign = true := by
  apply local_rup F.assign c2033 [c2, c3, c827]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p827 F) (rfl)))
  · decide +kernel
def c2034 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (8,false), (77,false), (33,false), (98,false)]
theorem p2034 (F : Frame G 3) : c2034.eval F.assign = true := by
  apply local_rup F.assign c2034 [c5, c4, c6, c828]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p828 F) (rfl))))
  · decide +kernel
def c2035 : CNF.Clause Nat := [(11,false), (77,false), (74,false), (38,false), (39,false), (98,false)]
theorem p2035 (F : Frame G 3) : c2035.eval F.assign = true := by
  apply local_rup F.assign c2035 [c5, c2, c3, c6, c829]
  · exact sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p829 F) (rfl)))))
  · decide +kernel
def c2036 : CNF.Clause Nat := [(38,false), (39,false), (30,false), (86,false), (98,false), (10,false), (77,false)]
theorem p2036 (F : Frame G 3) : c2036.eval F.assign = true := by
  apply local_rup F.assign c2036 [c2, c3, c4, c830]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p830 F) (rfl))))
  · decide +kernel
def c2037 : CNF.Clause Nat := [(38,false), (17,false), (33,false), (77,false), (76,false), (87,false), (86,false)]
theorem p2037 (F : Frame G 3) : c2037.eval F.assign = true := by
  apply local_rup F.assign c2037 [c1, c2, c3, c831]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p831 F) (rfl))))
  · decide +kernel
def c2038 : CNF.Clause Nat := [(38,false), (26,false), (6,false), (11,false), (88,false), (74,false), (76,false), (98,false)]
theorem p2038 (F : Frame G 3) : c2038.eval F.assign = true := by
  apply local_rup F.assign c2038 [c2, c3, c832]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p832 F) (rfl)))
  · decide +kernel
def c2039 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (18,false), (88,false), (33,false), (98,false)]
theorem p2039 (F : Frame G 3) : c2039.eval F.assign = true := by
  apply local_rup F.assign c2039 [c4, c5, c6, c833]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p833 F) (rfl))))
  · decide +kernel
def c2040 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (29,false), (98,false), (21,false), (88,false)]
theorem p2040 (F : Frame G 3) : c2040.eval F.assign = true := by
  apply local_rup F.assign c2040 [c4, c6, c5, c834]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p834 F) (rfl))))
  · decide +kernel
def c2041 : CNF.Clause Nat := [(15,false), (50,false), (6,false), (74,false), (88,false), (33,false), (98,false)]
theorem p2041 (F : Frame G 3) : c2041.eval F.assign = true := by
  apply local_rup F.assign c2041 [c2, c4, c6, c835]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p835 F) (rfl))))
  · decide +kernel
def c2042 : CNF.Clause Nat := [(38,false), (6,false), (98,false), (87,false), (74,false), (77,false)]
theorem p2042 (F : Frame G 3) : c2042.eval F.assign = true := by
  apply local_rup F.assign c2042 [c2, c1, c3, c6, c836]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p836 F) (rfl)))))
  · decide +kernel
def c2043 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (18,false), (77,false), (33,false), (86,false), (87,false)]
theorem p2043 (F : Frame G 3) : c2043.eval F.assign = true := by
  apply local_rup F.assign c2043 [c1, c6, c837]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p837 F) (rfl)))
  · decide +kernel
def c2044 : CNF.Clause Nat := [(15,false), (50,false), (30,false), (87,false), (98,false), (9,false), (77,false)]
theorem p2044 (F : Frame G 3) : c2044.eval F.assign = true := by
  apply local_rup F.assign c2044 [c2, c3, c4, c838]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p838 F) (rfl))))
  · decide +kernel
def c2045 : CNF.Clause Nat := [(15,false), (50,false), (98,false), (87,false), (8,false), (77,false)]
theorem p2045 (F : Frame G 3) : c2045.eval F.assign = true := by
  apply local_rup F.assign c2045 [c2, c3, c6, c4, c839]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p839 F) (rfl)))))
  · decide +kernel
def c2046 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (74,false), (77,false), (33,false), (98,false)]
theorem p2046 (F : Frame G 3) : c2046.eval F.assign = true := by
  apply local_rup F.assign c2046 [c1, c5, c6, c840]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p840 F) (rfl))))
  · decide +kernel
def c2047 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (87,false), (98,false), (29,false), (77,false)]
theorem p2047 (F : Frame G 3) : c2047.eval F.assign = true := by
  apply local_rup F.assign c2047 [c1, c5, c6, c841]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p841 F) (rfl))))
  · decide +kernel
def c2048 : CNF.Clause Nat := [(6,false), (50,false), (87,false), (98,false), (29,false), (77,false)]
theorem p2048 (F : Frame G 3) : c2048.eval F.assign = true := by
  apply local_rup F.assign c2048 [c1, c2, c5, c6, c842]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p842 F) (rfl)))))
  · decide +kernel
def c2049 : CNF.Clause Nat := [(6,false), (50,false), (30,false), (98,false), (76,false), (77,false)]
theorem p2049 (F : Frame G 3) : c2049.eval F.assign = true := by
  apply local_rup F.assign c2049 [c1, c2, c5, c6, c843]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p843 F) (rfl)))))
  · decide +kernel
def c2050 : CNF.Clause Nat := [(38,false), (50,false), (98,false), (87,false), (18,false), (77,false)]
theorem p2050 (F : Frame G 3) : c2050.eval F.assign = true := by
  apply local_rup F.assign c2050 [c1, c3, c6, c5, c844]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p844 F) (rfl)))))
  · decide +kernel
def c2051 : CNF.Clause Nat := [(26,false), (50,false), (87,false), (98,false), (9,false), (77,false)]
theorem p2051 (F : Frame G 3) : c2051.eval F.assign = true := by
  apply local_rup F.assign c2051 [c3, c2, c5, c4, c845]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p845 F) (rfl)))))
  · decide +kernel
def c2052 : CNF.Clause Nat := [(77,false), (22,false), (87,false), (98,false), (27,false), (50,false)]
theorem p2052 (F : Frame G 3) : c2052.eval F.assign = true := by
  apply local_rup F.assign c2052 [c1, c4, c5, c6, c846]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p846 F) (rfl)))))
  · decide +kernel
def c2053 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (8,false), (77,false), (33,false), (98,false)]
theorem p2053 (F : Frame G 3) : c2053.eval F.assign = true := by
  apply local_rup F.assign c2053 [c5, c4, c6, c847]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p847 F) (rfl))))
  · decide +kernel
def c2054 : CNF.Clause Nat := [(6,false), (50,false), (21,false), (76,false), (75,false), (30,false), (88,false)]
theorem p2054 (F : Frame G 3) : c2054.eval F.assign = true := by
  apply local_rup F.assign c2054 [c1, c2, c6, c848]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p848 F) (rfl))))
  · decide +kernel
def c2055 : CNF.Clause Nat := [(6,false), (50,false), (88,false), (33,false), (75,false), (76,false)]
theorem p2055 (F : Frame G 3) : c2055.eval F.assign = true := by
  apply local_rup F.assign c2055 [c1, c2, c5, c6, c849]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p849 F) (rfl)))))
  · decide +kernel
def c2056 : CNF.Clause Nat := [(11,false), (77,false), (75,false), (98,false), (21,false), (30,false), (27,false), (50,false)]
theorem p2056 (F : Frame G 3) : c2056.eval F.assign = true := by
  apply local_rup F.assign c2056 [c1, c5, c850]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p850 F) (rfl)))
  · decide +kernel
def c2057 : CNF.Clause Nat := [(11,false), (88,false), (74,false), (75,false), (98,false), (21,false), (27,false)]
theorem p2057 (F : Frame G 3) : c2057.eval F.assign = true := by
  apply local_rup F.assign c2057 [c1, c2, c3, c851]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p851 F) (rfl))))
  · decide +kernel
def c2058 : CNF.Clause Nat := [(38,false), (26,false), (6,false), (8,false), (88,false), (77,false), (75,false), (98,false)]
theorem p2058 (F : Frame G 3) : c2058.eval F.assign = true := by
  apply local_rup F.assign c2058 [c2, c3, c852]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p852 F) (rfl)))
  · decide +kernel
def c2059 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (22,false), (77,false), (74,false), (30,false), (98,false)]
theorem p2059 (F : Frame G 3) : c2059.eval F.assign = true := by
  apply local_rup F.assign c2059 [c1, c6, c853]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p853 F) (rfl)))
  · decide +kernel
def c2060 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (22,false), (88,false), (74,false), (75,false), (32,false)]
theorem p2060 (F : Frame G 3) : c2060.eval F.assign = true := by
  apply local_rup F.assign c2060 [c1, c6, c854]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p854 F) (rfl)))
  · decide +kernel
def c2061 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (30,false), (98,false), (10,false), (77,false)]
theorem p2061 (F : Frame G 3) : c2061.eval F.assign = true := by
  apply local_rup F.assign c2061 [c5, c6, c4, c855]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p855 F) (rfl))))
  · decide +kernel
def c2062 : CNF.Clause Nat := [(17,false), (39,false), (11,false), (77,false), (76,false), (98,false), (30,false)]
theorem p2062 (F : Frame G 3) : c2062.eval F.assign = true := by
  apply local_rup F.assign c2062 [c2, c1, c6, c856]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p856 F) (rfl))))
  · decide +kernel
def c2063 : CNF.Clause Nat := [(27,false), (39,false), (8,false), (86,false), (98,false), (76,false), (18,false), (22,false)]
theorem p2063 (F : Frame G 3) : c2063.eval F.assign = true := by
  apply local_rup F.assign c2063 [c3, c1, c857]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p857 F) (rfl)))
  · decide +kernel
def c2064 : CNF.Clause Nat := [(27,false), (39,false), (77,false), (22,false), (86,false), (98,false)]
theorem p2064 (F : Frame G 3) : c2064.eval F.assign = true := by
  apply local_rup F.assign c2064 [c3, c1, c4, c5, c858]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p858 F) (rfl)))))
  · decide +kernel
def c2065 : CNF.Clause Nat := [(39,false), (15,false), (5,false), (11,false), (77,false), (74,false), (86,false), (98,false)]
theorem p2065 (F : Frame G 3) : c2065.eval F.assign = true := by
  apply local_rup F.assign c2065 [c3, c2, c859]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p859 F) (rfl)))
  · decide +kernel
def c2066 : CNF.Clause Nat := [(8,false), (74,false), (77,false), (22,false), (50,false), (98,false)]
theorem p2066 (F : Frame G 3) : c2066.eval F.assign = true := by
  apply local_rup F.assign c2066 [c1, c2, c3, c6, c860]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p860 F) (rfl)))))
  · decide +kernel
def c2067 : CNF.Clause Nat := [(39,false), (15,false), (5,false), (11,false), (77,false), (74,false), (30,false), (98,false)]
theorem p2067 (F : Frame G 3) : c2067.eval F.assign = true := by
  apply local_rup F.assign c2067 [c2, c6, c861]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p861 F) (rfl)))
  · decide +kernel
def c2068 : CNF.Clause Nat := [(8,false), (87,false), (76,false), (77,false), (33,false), (20,false), (50,false)]
theorem p2068 (F : Frame G 3) : c2068.eval F.assign = true := by
  apply local_rup F.assign c2068 [c1, c6, c2, c863]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p863 F) (rfl))))
  · decide +kernel
def c2069 : CNF.Clause Nat := [(9,false), (98,false), (76,false), (77,false), (88,false), (27,false)]
theorem p2069 (F : Frame G 3) : c2069.eval F.assign = true := by
  apply local_rup F.assign c2069 [c1, c5, c2, c3, c864]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p864 F) (rfl)))))
  · decide +kernel
def c2070 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (30,false), (98,false), (76,false), (11,false)]
theorem p2070 (F : Frame G 3) : c2070.eval F.assign = true := by
  apply local_rup F.assign c2070 [c5, c6, c4, c865]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p865 F) (rfl))))
  · decide +kernel
def c2071 : CNF.Clause Nat := [(5,false), (50,false), (17,false), (88,false), (77,false), (76,false), (32,false)]
theorem p2071 (F : Frame G 3) : c2071.eval F.assign = true := by
  apply local_rup F.assign c2071 [c1, c5, c6, c866]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p866 F) (rfl))))
  · decide +kernel
def c2072 : CNF.Clause Nat := [(27,false), (39,false), (77,false), (88,false), (20,false), (98,false)]
theorem p2072 (F : Frame G 3) : c2072.eval F.assign = true := by
  apply local_rup F.assign c2072 [c3, c1, c4, c5, c867]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p867 F) (rfl)))))
  · decide +kernel
def c2073 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (29,false), (98,false), (21,false), (88,false)]
theorem p2073 (F : Frame G 3) : c2073.eval F.assign = true := by
  apply local_rup F.assign c2073 [c4, c6, c5, c868]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p868 F) (rfl))))
  · decide +kernel
def c2074 : CNF.Clause Nat := [(27,false), (39,false), (77,false), (22,false), (87,false), (98,false)]
theorem p2074 (F : Frame G 3) : c2074.eval F.assign = true := by
  apply local_rup F.assign c2074 [c3, c1, c4, c5, c869]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p869 F) (rfl)))))
  · decide +kernel
def c2075 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (77,false), (22,false), (87,false), (98,false)]
theorem p2075 (F : Frame G 3) : c2075.eval F.assign = true := by
  apply local_rup F.assign c2075 [c3, c4, c5, c870]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p870 F) (rfl))))
  · decide +kernel
def c2076 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (77,false), (22,false), (86,false), (98,false)]
theorem p2076 (F : Frame G 3) : c2076.eval F.assign = true := by
  apply local_rup F.assign c2076 [c3, c4, c5, c871]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p871 F) (rfl))))
  · decide +kernel
def c2077 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (18,false), (88,false), (33,false), (98,false)]
theorem p2077 (F : Frame G 3) : c2077.eval F.assign = true := by
  apply local_rup F.assign c2077 [c4, c5, c6, c872]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p872 F) (rfl))))
  · decide +kernel
def c2078 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (77,false), (88,false), (87,false), (32,false)]
theorem p2078 (F : Frame G 3) : c2078.eval F.assign = true := by
  apply local_rup F.assign c2078 [c2, c4, c6, c873]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p873 F) (rfl))))
  · decide +kernel
def c2079 : CNF.Clause Nat := [(38,false), (39,false), (32,false), (98,false), (75,false), (8,false), (22,false)]
theorem p2079 (F : Frame G 3) : c2079.eval F.assign = true := by
  apply local_rup F.assign c2079 [c3, c4, c5, c874]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p874 F) (rfl))))
  · decide +kernel
def c2080 : CNF.Clause Nat := [(39,false), (38,false), (22,false), (11,false), (74,false), (30,false), (98,false)]
theorem p2080 (F : Frame G 3) : c2080.eval F.assign = true := by
  apply local_rup F.assign c2080 [c2, c4, c6, c875]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p875 F) (rfl))))
  · decide +kernel
def c2081 : CNF.Clause Nat := [(39,false), (38,false), (22,false), (11,false), (10,false), (98,false), (75,false), (74,false)]
theorem p2081 (F : Frame G 3) : c2081.eval F.assign = true := by
  apply local_rup F.assign c2081 [c3, c2, c876]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p876 F) (rfl)))
  · decide +kernel
def c2082 : CNF.Clause Nat := [(22,false), (88,false), (86,false), (75,false), (10,false), (32,false), (26,false), (38,false), (50,false)]
theorem p2082 (F : Frame G 3) : c2082.eval F.assign = true := by
  apply local_rup F.assign c2082 [c4, c877]
  · exact sat_cons (p4 F) ( sat_cons (p877 F) (rfl))
  · decide +kernel
def c2083 : CNF.Clause Nat := [(5,false), (38,false), (39,false), (33,false), (22,false), (21,false), (87,false), (74,false), (75,false)]
theorem p2083 (F : Frame G 3) : c2083.eval F.assign = true := by
  apply local_rup F.assign c2083 [c3, c878]
  · exact sat_cons (p3 F) ( sat_cons (p878 F) (rfl))
  · decide +kernel
def c2084 : CNF.Clause Nat := [(39,false), (5,false), (21,false), (98,false), (75,false), (74,false), (88,false)]
theorem p2084 (F : Frame G 3) : c2084.eval F.assign = true := by
  apply local_rup F.assign c2084 [c3, c1, c2, c879]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p879 F) (rfl))))
  · decide +kernel
def c2085 : CNF.Clause Nat := [(26,false), (50,false), (5,false), (77,false), (88,false), (20,false), (98,false)]
theorem p2085 (F : Frame G 3) : c2085.eval F.assign = true := by
  apply local_rup F.assign c2085 [c3, c4, c5, c880]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p880 F) (rfl))))
  · decide +kernel
def c2086 : CNF.Clause Nat := [(39,false), (5,false), (21,false), (98,false), (75,false), (77,false), (88,false)]
theorem p2086 (F : Frame G 3) : c2086.eval F.assign = true := by
  apply local_rup F.assign c2086 [c3, c1, c2, c881]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p881 F) (rfl))))
  · decide +kernel
def c2087 : CNF.Clause Nat := [(39,false), (5,false), (21,false), (98,false), (86,false), (74,false), (77,false)]
theorem p2087 (F : Frame G 3) : c2087.eval F.assign = true := by
  apply local_rup F.assign c2087 [c3, c1, c2, c882]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p882 F) (rfl))))
  · decide +kernel
def c2088 : CNF.Clause Nat := [(77,false), (88,false), (86,false), (98,false), (21,false), (27,false)]
theorem p2088 (F : Frame G 3) : c2088.eval F.assign = true := by
  apply local_rup F.assign c2088 [c1, c4, c2, c3, c883]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p883 F) (rfl)))))
  · decide +kernel
def c2089 : CNF.Clause Nat := [(18,false), (50,false), (33,false), (88,false), (86,false), (98,false)]
theorem p2089 (F : Frame G 3) : c2089.eval F.assign = true := by
  apply local_rup F.assign c2089 [c1, c4, c2, c3, c884]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p884 F) (rfl)))))
  · decide +kernel
def c2090 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (98,false), (21,false), (18,false), (8,false), (88,false)]
theorem p2090 (F : Frame G 3) : c2090.eval F.assign = true := by
  apply local_rup F.assign c2090 [c6, c4, c885]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p885 F) (rfl)))
  · decide +kernel
def c2091 : CNF.Clause Nat := [(10,false), (98,false), (75,false), (77,false), (88,false), (27,false)]
theorem p2091 (F : Frame G 3) : c2091.eval F.assign = true := by
  apply local_rup F.assign c2091 [c1, c5, c2, c3, c886]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p886 F) (rfl)))))
  · decide +kernel
def c2092 : CNF.Clause Nat := [(39,false), (50,false), (8,false), (10,false), (98,false), (29,false), (77,false)]
theorem p2092 (F : Frame G 3) : c2092.eval F.assign = true := by
  apply local_rup F.assign c2092 [c2, c5, c6, c887]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p887 F) (rfl))))
  · decide +kernel
def c2093 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (33,false), (11,false), (18,false), (86,false), (98,false)]
theorem p2093 (F : Frame G 3) : c2093.eval F.assign = true := by
  apply local_rup F.assign c2093 [c4, c5, c888]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p888 F) (rfl)))
  · decide +kernel
def c2094 : CNF.Clause Nat := [(10,false), (21,false), (50,false), (33,false), (77,false), (74,false), (86,false)]
theorem p2094 (F : Frame G 3) : c2094.eval F.assign = true := by
  apply local_rup F.assign c2094 [c1, c2, c3, c889]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p889 F) (rfl))))
  · decide +kernel
def c2095 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (21,false), (87,false), (88,false), (33,false), (29,false), (75,false)]
theorem p2095 (F : Frame G 3) : c2095.eval F.assign = true := by
  apply local_rup F.assign c2095 [c1, c890]
  · exact sat_cons (p1 F) ( sat_cons (p890 F) (rfl))
  · decide +kernel
def c2096 : CNF.Clause Nat := [(74,false), (88,false), (22,false), (50,false), (98,false)]
theorem p2096 (F : Frame G 3) : c2096.eval F.assign = true := by
  apply local_rup F.assign c2096 [c1, c4, c2, c3, c6, c891]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p891 F) (rfl))))))
  · decide +kernel
def c2097 : CNF.Clause Nat := [(38,false), (26,false), (6,false), (9,false), (98,false), (76,false), (74,false), (88,false)]
theorem p2097 (F : Frame G 3) : c2097.eval F.assign = true := by
  apply local_rup F.assign c2097 [c2, c3, c892]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p892 F) (rfl)))
  · decide +kernel
def c2098 : CNF.Clause Nat := [(11,false), (77,false), (76,false), (87,false), (20,false), (26,false), (38,false), (50,false)]
theorem p2098 (F : Frame G 3) : c2098.eval F.assign = true := by
  apply local_rup F.assign c2098 [c5, c6, c893]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p893 F) (rfl)))
  · decide +kernel
def c2099 : CNF.Clause Nat := [(11,false), (77,false), (76,false), (87,false), (20,false), (27,false), (38,false), (39,false)]
theorem p2099 (F : Frame G 3) : c2099.eval F.assign = true := by
  apply local_rup F.assign c2099 [c5, c6, c894]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p894 F) (rfl)))
  · decide +kernel
def c2100 : CNF.Clause Nat := [(50,false), (39,false), (26,false), (33,false), (88,false), (87,false), (10,false), (75,false)]
theorem p2100 (F : Frame G 3) : c2100.eval F.assign = true := by
  apply local_rup F.assign c2100 [c2, c4, c895]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p895 F) (rfl)))
  · decide +kernel
end Cert35Steps
end Graffiti199Depleted.Catalogue.OrderEleven
