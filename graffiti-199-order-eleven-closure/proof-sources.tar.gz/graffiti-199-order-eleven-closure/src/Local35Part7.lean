import Local35Part6
namespace Graffiti199Depleted.Catalogue.OrderEleven
namespace Cert35Steps
open Std.Sat
set_option maxRecDepth 4096
set_option maxHeartbeats 0
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj]
def c2101 : CNF.Clause Nat := [(50,false), (39,false), (74,false), (88,false), (33,false), (98,false)]
theorem p2101 (F : Frame G 3) : c2101.eval F.assign = true := by
  apply local_rup F.assign c2101 [c2, c1, c4, c6, c896]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p896 F) (rfl)))))
  · decide +kernel
def c2102 : CNF.Clause Nat := [(50,false), (39,false), (29,false), (33,false), (88,false), (86,false), (98,false)]
theorem p2102 (F : Frame G 3) : c2102.eval F.assign = true := by
  apply local_rup F.assign c2102 [c2, c1, c4, c897]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p897 F) (rfl))))
  · decide +kernel
def c2103 : CNF.Clause Nat := [(75,false), (98,false), (32,false), (27,false), (50,false), (17,false), (88,false)]
theorem p2103 (F : Frame G 3) : c2103.eval F.assign = true := by
  apply local_rup F.assign c2103 [c1, c4, c5, c898]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p898 F) (rfl))))
  · decide +kernel
def c2104 : CNF.Clause Nat := [(39,false), (50,false), (21,false), (32,false), (29,false), (75,false), (86,false), (8,false), (11,false)]
theorem p2104 (F : Frame G 3) : c2104.eval F.assign = true := by
  apply local_rup F.assign c2104 [c2, c899]
  · exact sat_cons (p2 F) ( sat_cons (p899 F) (rfl))
  · decide +kernel
def c2105 : CNF.Clause Nat := [(50,false), (39,false), (77,false), (88,false), (86,false), (32,false)]
theorem p2105 (F : Frame G 3) : c2105.eval F.assign = true := by
  apply local_rup F.assign c2105 [c2, c1, c4, c6, c900]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p900 F) (rfl)))))
  · decide +kernel
def c2106 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (86,false), (98,false), (32,false), (29,false), (77,false)]
theorem p2106 (F : Frame G 3) : c2106.eval F.assign = true := by
  apply local_rup F.assign c2106 [c1, c5, c901]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p901 F) (rfl)))
  · decide +kernel
def c2107 : CNF.Clause Nat := [(38,false), (50,false), (30,false), (86,false), (98,false), (21,false), (18,false), (77,false)]
theorem p2107 (F : Frame G 3) : c2107.eval F.assign = true := by
  apply local_rup F.assign c2107 [c1, c3, c902]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p902 F) (rfl)))
  · decide +kernel
def c2108 : CNF.Clause Nat := [(11,false), (77,false), (75,false), (98,false), (87,false), (30,false), (27,false), (15,false), (39,false)]
theorem p2108 (F : Frame G 3) : c2108.eval F.assign = true := by
  apply local_rup F.assign c2108 [c2, c903]
  · exact sat_cons (p2 F) ( sat_cons (p903 F) (rfl))
  · decide +kernel
def c2109 : CNF.Clause Nat := [(11,false), (77,false), (75,false), (98,false), (87,false), (27,false), (26,false), (39,false)]
theorem p2109 (F : Frame G 3) : c2109.eval F.assign = true := by
  apply local_rup F.assign c2109 [c5, c2, c904]
  · exact sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p904 F) (rfl)))
  · decide +kernel
def c2110 : CNF.Clause Nat := [(38,false), (39,false), (33,false), (77,false), (8,false), (86,false), (98,false)]
theorem p2110 (F : Frame G 3) : c2110.eval F.assign = true := by
  apply local_rup F.assign c2110 [c2, c3, c4, c905]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p905 F) (rfl))))
  · decide +kernel
def c2111 : CNF.Clause Nat := [(50,false), (38,false), (75,false), (98,false), (21,false), (88,false)]
theorem p2111 (F : Frame G 3) : c2111.eval F.assign = true := by
  apply local_rup F.assign c2111 [c3, c1, c4, c5, c906]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p906 F) (rfl)))))
  · decide +kernel
def c2112 : CNF.Clause Nat := [(8,false), (39,false), (33,false), (77,false), (75,false), (98,false)]
theorem p2112 (F : Frame G 3) : c2112.eval F.assign = true := by
  apply local_rup F.assign c2112 [c2, c5, c1, c3, c907]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p907 F) (rfl)))))
  · decide +kernel
def c2113 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (86,false), (98,false), (10,false), (29,false), (33,false)]
theorem p2113 (F : Frame G 3) : c2113.eval F.assign = true := by
  apply local_rup F.assign c2113 [c5, c4, c908]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p908 F) (rfl)))
  · decide +kernel
def c2114 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (18,false), (10,false), (32,false), (86,false), (88,false)]
theorem p2114 (F : Frame G 3) : c2114.eval F.assign = true := by
  apply local_rup F.assign c2114 [c4, c6, c909]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p909 F) (rfl)))
  · decide +kernel
def c2115 : CNF.Clause Nat := [(10,false), (98,false), (75,false), (74,false), (22,false), (33,false), (27,false), (38,false), (39,false)]
theorem p2115 (F : Frame G 3) : c2115.eval F.assign = true := by
  apply local_rup F.assign c2115 [c5, c910]
  · exact sat_cons (p5 F) ( sat_cons (p910 F) (rfl))
  · decide +kernel
def c2116 : CNF.Clause Nat := [(39,false), (50,false), (74,false), (77,false), (33,false), (98,false)]
theorem p2116 (F : Frame G 3) : c2116.eval F.assign = true := by
  apply local_rup F.assign c2116 [c1, c2, c5, c6, c911]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p911 F) (rfl)))))
  · decide +kernel
def c2117 : CNF.Clause Nat := [(38,false), (39,false), (75,false), (10,false), (87,false), (88,false)]
theorem p2117 (F : Frame G 3) : c2117.eval F.assign = true := by
  apply local_rup F.assign c2117 [c2, c3, c6, c4, c912]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p912 F) (rfl)))))
  · decide +kernel
def c2118 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (11,false), (22,false), (74,false), (75,false), (32,false)]
theorem p2118 (F : Frame G 3) : c2118.eval F.assign = true := by
  apply local_rup F.assign c2118 [c5, c6, c913]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p913 F) (rfl)))
  · decide +kernel
def c2119 : CNF.Clause Nat := [(5,false), (38,false), (39,false), (17,false), (21,false), (98,false), (29,false), (74,false), (88,false)]
theorem p2119 (F : Frame G 3) : c2119.eval F.assign = true := by
  apply local_rup F.assign c2119 [c6, c914]
  · exact sat_cons (p6 F) ( sat_cons (p914 F) (rfl))
  · decide +kernel
def c2120 : CNF.Clause Nat := [(74,false), (88,false), (33,false), (32,false), (98,false), (20,false), (38,false), (39,false)]
theorem p2120 (F : Frame G 3) : c2120.eval F.assign = true := by
  apply local_rup F.assign c2120 [c4, c2, c915]
  · exact sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p915 F) (rfl)))
  · decide +kernel
def c2121 : CNF.Clause Nat := [(26,false), (50,false), (74,false), (77,false), (11,false), (9,false), (98,false)]
theorem p2121 (F : Frame G 3) : c2121.eval F.assign = true := by
  apply local_rup F.assign c2121 [c3, c2, c5, c916]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p916 F) (rfl))))
  · decide +kernel
def c2122 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (18,false), (22,false), (88,false), (86,false), (98,false)]
theorem p2122 (F : Frame G 3) : c2122.eval F.assign = true := by
  apply local_rup F.assign c2122 [c3, c4, c917]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p917 F) (rfl)))
  · decide +kernel
def c2123 : CNF.Clause Nat := [(38,false), (39,false), (29,false), (11,false), (88,false), (86,false), (98,false)]
theorem p2123 (F : Frame G 3) : c2123.eval F.assign = true := by
  apply local_rup F.assign c2123 [c2, c3, c4, c918]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p918 F) (rfl))))
  · decide +kernel
def c2124 : CNF.Clause Nat := [(20,false), (98,false), (87,false), (88,false), (11,false), (29,false), (26,false), (39,false)]
theorem p2124 (F : Frame G 3) : c2124.eval F.assign = true := by
  apply local_rup F.assign c2124 [c2, c4, c919]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p919 F) (rfl)))
  · decide +kernel
def c2125 : CNF.Clause Nat := [(15,false), (39,false), (29,false), (74,false), (88,false), (11,false), (9,false), (98,false)]
theorem p2125 (F : Frame G 3) : c2125.eval F.assign = true := by
  apply local_rup F.assign c2125 [c2, c3, c920]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p920 F) (rfl)))
  · decide +kernel
def c2126 : CNF.Clause Nat := [(27,false), (39,false), (18,false), (20,false), (98,false), (87,false), (88,false)]
theorem p2126 (F : Frame G 3) : c2126.eval F.assign = true := by
  apply local_rup F.assign c2126 [c3, c1, c4, c921]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p921 F) (rfl))))
  · decide +kernel
def c2127 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (77,false), (33,false), (30,false), (87,false), (98,false)]
theorem p2127 (F : Frame G 3) : c2127.eval F.assign = true := by
  apply local_rup F.assign c2127 [c2, c4, c922]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p922 F) (rfl)))
  · decide +kernel
def c2128 : CNF.Clause Nat := [(15,false), (39,false), (98,false), (87,false), (8,false), (77,false)]
theorem p2128 (F : Frame G 3) : c2128.eval F.assign = true := by
  apply local_rup F.assign c2128 [c2, c3, c6, c4, c923]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p923 F) (rfl)))))
  · decide +kernel
def c2129 : CNF.Clause Nat := [(38,false), (39,false), (98,false), (87,false), (8,false), (77,false)]
theorem p2129 (F : Frame G 3) : c2129.eval F.assign = true := by
  apply local_rup F.assign c2129 [c2, c3, c6, c4, c924]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p924 F) (rfl)))))
  · decide +kernel
def c2130 : CNF.Clause Nat := [(74,false), (88,false), (22,false), (38,false), (39,false), (98,false)]
theorem p2130 (F : Frame G 3) : c2130.eval F.assign = true := by
  apply local_rup F.assign c2130 [c4, c2, c3, c6, c925]
  · exact sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p925 F) (rfl)))))
  · decide +kernel
def c2131 : CNF.Clause Nat := [(38,false), (39,false), (33,false), (11,false), (75,false), (20,false), (87,false)]
theorem p2131 (F : Frame G 3) : c2131.eval F.assign = true := by
  apply local_rup F.assign c2131 [c3, c4, c5, c926]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p926 F) (rfl))))
  · decide +kernel
def c2132 : CNF.Clause Nat := [(39,false), (50,false), (30,false), (32,false), (98,false), (9,false), (77,false)]
theorem p2132 (F : Frame G 3) : c2132.eval F.assign = true := by
  apply local_rup F.assign c2132 [c2, c5, c4, c927]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p927 F) (rfl))))
  · decide +kernel
def c2133 : CNF.Clause Nat := [(75,false), (98,false), (32,false), (39,false), (38,false), (88,false)]
theorem p2133 (F : Frame G 3) : c2133.eval F.assign = true := by
  apply local_rup F.assign c2133 [c4, c3, c2, c5, c928]
  · exact sat_cons (p4 F) ( sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p928 F) (rfl)))))
  · decide +kernel
def c2134 : CNF.Clause Nat := [(6,false), (50,false), (22,false), (88,false), (30,false), (29,false), (75,false), (98,false)]
theorem p2134 (F : Frame G 3) : c2134.eval F.assign = true := by
  apply local_rup F.assign c2134 [c1, c2, c929]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p929 F) (rfl)))
  · decide +kernel
def c2135 : CNF.Clause Nat := [(38,false), (6,false), (33,false), (88,false), (74,false), (75,false), (98,false)]
theorem p2135 (F : Frame G 3) : c2135.eval F.assign = true := by
  apply local_rup F.assign c2135 [c2, c1, c3, c930]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p930 F) (rfl))))
  · decide +kernel
def c2136 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (8,false), (11,false), (33,false), (29,false), (75,false), (98,false)]
theorem p2136 (F : Frame G 3) : c2136.eval F.assign = true := by
  apply local_rup F.assign c2136 [c5, c931]
  · exact sat_cons (p5 F) ( sat_cons (p931 F) (rfl))
  · decide +kernel
def c2137 : CNF.Clause Nat := [(50,false), (38,false), (75,false), (98,false), (87,false), (22,false)]
theorem p2137 (F : Frame G 3) : c2137.eval F.assign = true := by
  apply local_rup F.assign c2137 [c3, c1, c4, c5, c932]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p932 F) (rfl)))))
  · decide +kernel
def c2138 : CNF.Clause Nat := [(15,false), (50,false), (30,false), (88,false), (77,false), (9,false), (98,false)]
theorem p2138 (F : Frame G 3) : c2138.eval F.assign = true := by
  apply local_rup F.assign c2138 [c2, c3, c4, c933]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p933 F) (rfl))))
  · decide +kernel
def c2139 : CNF.Clause Nat := [(88,false), (77,false), (75,false), (98,false), (32,false), (26,false), (5,false), (50,false)]
theorem p2139 (F : Frame G 3) : c2139.eval F.assign = true := by
  apply local_rup F.assign c2139 [c5, c1, c934]
  · exact sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p934 F) (rfl)))
  · decide +kernel
def c2140 : CNF.Clause Nat := [(15,false), (50,false), (6,false), (77,false), (88,false), (30,false), (98,false)]
theorem p2140 (F : Frame G 3) : c2140.eval F.assign = true := by
  apply local_rup F.assign c2140 [c2, c4, c6, c935]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p935 F) (rfl))))
  · decide +kernel
def c2141 : CNF.Clause Nat := [(50,false), (38,false), (15,false), (88,false), (77,false), (9,false), (98,false)]
theorem p2141 (F : Frame G 3) : c2141.eval F.assign = true := by
  apply local_rup F.assign c2141 [c3, c5, c4, c936]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p936 F) (rfl))))
  · decide +kernel
def c2142 : CNF.Clause Nat := [(15,false), (50,false), (32,false), (10,false), (75,false), (86,false), (88,false)]
theorem p2142 (F : Frame G 3) : c2142.eval F.assign = true := by
  apply local_rup F.assign c2142 [c2, c3, c4, c937]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p937 F) (rfl))))
  · decide +kernel
def c2143 : CNF.Clause Nat := [(38,false), (6,false), (30,false), (87,false), (98,false), (75,false), (77,false)]
theorem p2143 (F : Frame G 3) : c2143.eval F.assign = true := by
  apply local_rup F.assign c2143 [c2, c1, c3, c938]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p938 F) (rfl))))
  · decide +kernel
def c2144 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (8,false), (21,false), (32,false), (75,false), (77,false)]
theorem p2144 (F : Frame G 3) : c2144.eval F.assign = true := by
  apply local_rup F.assign c2144 [c5, c6, c939]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p939 F) (rfl)))
  · decide +kernel
def c2145 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (11,false), (77,false), (74,false), (20,false), (32,false)]
theorem p2145 (F : Frame G 3) : c2145.eval F.assign = true := by
  apply local_rup F.assign c2145 [c5, c6, c940]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p940 F) (rfl)))
  · decide +kernel
def c2146 : CNF.Clause Nat := [(33,false), (11,false), (38,false), (74,false), (75,false), (98,false)]
theorem p2146 (F : Frame G 3) : c2146.eval F.assign = true := by
  apply local_rup F.assign c2146 [c3, c1, c2, c5, c941]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p941 F) (rfl)))))
  · decide +kernel
def c2147 : CNF.Clause Nat := [(75,false), (98,false), (87,false), (88,false), (33,false), (27,false), (15,false), (39,false)]
theorem p2147 (F : Frame G 3) : c2147.eval F.assign = true := by
  apply local_rup F.assign c2147 [c4, c2, c942]
  · exact sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p942 F) (rfl)))
  · decide +kernel
def c2148 : CNF.Clause Nat := [(75,false), (98,false), (87,false), (88,false), (22,false), (27,false), (26,false), (39,false)]
theorem p2148 (F : Frame G 3) : c2148.eval F.assign = true := by
  apply local_rup F.assign c2148 [c4, c2, c943]
  · exact sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p943 F) (rfl)))
  · decide +kernel
def c2149 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (75,false), (98,false), (21,false), (88,false)]
theorem p2149 (F : Frame G 3) : c2149.eval F.assign = true := by
  apply local_rup F.assign c2149 [c3, c4, c5, c944]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p944 F) (rfl))))
  · decide +kernel
def c2150 : CNF.Clause Nat := [(75,false), (98,false), (87,false), (88,false), (33,false), (26,false), (38,false), (17,false)]
theorem p2150 (F : Frame G 3) : c2150.eval F.assign = true := by
  apply local_rup F.assign c2150 [c4, c2, c945]
  · exact sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p945 F) (rfl)))
  · decide +kernel
def c2151 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (77,false), (22,false), (30,false), (98,false)]
theorem p2151 (F : Frame G 3) : c2151.eval F.assign = true := by
  apply local_rup F.assign c2151 [c4, c5, c6, c946]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p946 F) (rfl))))
  · decide +kernel
def c2152 : CNF.Clause Nat := [(26,false), (50,false), (86,false), (98,false), (10,false), (77,false)]
theorem p2152 (F : Frame G 3) : c2152.eval F.assign = true := by
  apply local_rup F.assign c2152 [c3, c2, c5, c4, c947]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p947 F) (rfl)))))
  · decide +kernel
def c2153 : CNF.Clause Nat := [(39,false), (50,false), (30,false), (98,false), (10,false), (77,false)]
theorem p2153 (F : Frame G 3) : c2153.eval F.assign = true := by
  apply local_rup F.assign c2153 [c2, c5, c6, c4, c948]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p948 F) (rfl)))))
  · decide +kernel
def c2154 : CNF.Clause Nat := [(38,false), (17,false), (32,false), (98,false), (86,false), (74,false), (77,false)]
theorem p2154 (F : Frame G 3) : c2154.eval F.assign = true := by
  apply local_rup F.assign c2154 [c1, c2, c3, c949]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p949 F) (rfl))))
  · decide +kernel
def c2155 : CNF.Clause Nat := [(74,false), (77,false), (11,false), (38,false), (50,false), (98,false)]
theorem p2155 (F : Frame G 3) : c2155.eval F.assign = true := by
  apply local_rup F.assign c2155 [c5, c1, c3, c6, c950]
  · exact sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p950 F) (rfl)))))
  · decide +kernel
def c2156 : CNF.Clause Nat := [(8,false), (38,false), (50,false), (32,false), (76,false), (75,false), (99,false)]
theorem p2156 (F : Frame G 3) : c2156.eval F.assign = true := by
  apply local_rup F.assign c2156 [c5, c1, c3, c951]
  · exact sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p951 F) (rfl))))
  · decide +kernel
def c2157 : CNF.Clause Nat := [(87,false), (76,false), (38,false), (50,false), (99,false)]
theorem p2157 (F : Frame G 3) : c2157.eval F.assign = true := by
  apply local_rup F.assign c2157 [c5, c4, c1, c3, c6, c952]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p952 F) (rfl))))))
  · decide +kernel
def c2158 : CNF.Clause Nat := [(38,false), (17,false), (30,false), (86,false), (75,false), (76,false), (110,false)]
theorem p2158 (F : Frame G 3) : c2158.eval F.assign = true := by
  apply local_rup F.assign c2158 [c1, c2, c3, c953]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p953 F) (rfl))))
  · decide +kernel
def c2159 : CNF.Clause Nat := [(5,false), (39,false), (17,false), (18,false), (76,false), (98,false), (30,false), (88,false)]
theorem p2159 (F : Frame G 3) : c2159.eval F.assign = true := by
  apply local_rup F.assign c2159 [c1, c6, c954]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p954 F) (rfl)))
  · decide +kernel
def c2160 : CNF.Clause Nat := [(5,false), (39,false), (17,false), (74,false), (76,false), (32,false), (99,false)]
theorem p2160 (F : Frame G 3) : c2160.eval F.assign = true := by
  apply local_rup F.assign c2160 [c1, c5, c6, c955]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p955 F) (rfl))))
  · decide +kernel
def c2161 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (8,false), (76,false), (32,false), (99,false)]
theorem p2161 (F : Frame G 3) : c2161.eval F.assign = true := by
  apply local_rup F.assign c2161 [c5, c4, c6, c956]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p956 F) (rfl))))
  · decide +kernel
def c2162 : CNF.Clause Nat := [(5,false), (39,false), (17,false), (88,false), (99,false), (29,false), (76,false)]
theorem p2162 (F : Frame G 3) : c2162.eval F.assign = true := by
  apply local_rup F.assign c2162 [c1, c5, c6, c957]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p957 F) (rfl))))
  · decide +kernel
def c2163 : CNF.Clause Nat := [(18,false), (38,false), (39,false), (32,false), (87,false), (86,false), (99,false)]
theorem p2163 (F : Frame G 3) : c2163.eval F.assign = true := by
  apply local_rup F.assign c2163 [c4, c2, c3, c959]
  · exact sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p959 F) (rfl))))
  · decide +kernel
def c2164 : CNF.Clause Nat := [(5,false), (17,false), (39,false), (26,false), (29,false), (74,false), (87,false), (98,false), (99,false)]
theorem p2164 (F : Frame G 3) : c2164.eval F.assign = true := by
  apply local_rup F.assign c2164 [c2, c960]
  · exact sat_cons (p2 F) ( sat_cons (p960 F) (rfl))
  · decide +kernel
def c2165 : CNF.Clause Nat := [(5,false), (38,false), (39,false), (17,false), (18,false), (74,false), (88,false), (33,false), (98,false)]
theorem p2165 (F : Frame G 3) : c2165.eval F.assign = true := by
  apply local_rup F.assign c2165 [c6, c961]
  · exact sat_cons (p6 F) ( sat_cons (p961 F) (rfl))
  · decide +kernel
def c2166 : CNF.Clause Nat := [(38,false), (39,false), (29,false), (10,false), (87,false), (86,false), (99,false)]
theorem p2166 (F : Frame G 3) : c2166.eval F.assign = true := by
  apply local_rup F.assign c2166 [c2, c3, c4, c962]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p962 F) (rfl))))
  · decide +kernel
def c2167 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (29,false), (32,false), (87,false), (86,false), (99,false)]
theorem p2167 (F : Frame G 3) : c2167.eval F.assign = true := by
  apply local_rup F.assign c2167 [c2, c4, c963]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p963 F) (rfl)))
  · decide +kernel
def c2168 : CNF.Clause Nat := [(74,false), (87,false), (21,false), (38,false), (39,false), (99,false)]
theorem p2168 (F : Frame G 3) : c2168.eval F.assign = true := by
  apply local_rup F.assign c2168 [c4, c2, c3, c6, c964]
  · exact sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p964 F) (rfl)))))
  · decide +kernel
def c2169 : CNF.Clause Nat := [(38,false), (39,false), (32,false), (10,false), (74,false), (86,false), (99,false)]
theorem p2169 (F : Frame G 3) : c2169.eval F.assign = true := by
  apply local_rup F.assign c2169 [c2, c3, c4, c965]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p965 F) (rfl))))
  · decide +kernel
def c2170 : CNF.Clause Nat := [(18,false), (74,false), (88,false), (11,false), (39,false), (98,false)]
theorem p2170 (F : Frame G 3) : c2170.eval F.assign = true := by
  apply local_rup F.assign c2170 [c2, c1, c3, c6, c966]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p966 F) (rfl)))))
  · decide +kernel
def c2171 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (76,false), (32,false), (86,false), (88,false)]
theorem p2171 (F : Frame G 3) : c2171.eval F.assign = true := by
  apply local_rup F.assign c2171 [c2, c4, c6, c967]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p967 F) (rfl))))
  · decide +kernel
def c2172 : CNF.Clause Nat := [(50,false), (38,false), (18,false), (87,false), (98,false), (99,false)]
theorem p2172 (F : Frame G 3) : c2172.eval F.assign = true := by
  apply local_rup F.assign c2172 [c3, c1, c4, c5, c968]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p968 F) (rfl)))))
  · decide +kernel
def c2173 : CNF.Clause Nat := [(50,false), (38,false), (15,false), (87,false), (98,false), (75,false), (11,false)]
theorem p2173 (F : Frame G 3) : c2173.eval F.assign = true := by
  apply local_rup F.assign c2173 [c3, c5, c4, c969]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p969 F) (rfl))))
  · decide +kernel
def c2174 : CNF.Clause Nat := [(18,false), (10,false), (98,false), (99,false), (88,false), (30,false), (26,false), (39,false)]
theorem p2174 (F : Frame G 3) : c2174.eval F.assign = true := by
  apply local_rup F.assign c2174 [c2, c4, c970]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p970 F) (rfl)))
  · decide +kernel
def c2175 : CNF.Clause Nat := [(27,false), (39,false), (18,false), (21,false), (98,false), (86,false), (88,false)]
theorem p2175 (F : Frame G 3) : c2175.eval F.assign = true := by
  apply local_rup F.assign c2175 [c3, c1, c4, c971]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p971 F) (rfl))))
  · decide +kernel
def c2176 : CNF.Clause Nat := [(75,false), (99,false), (88,false), (87,false), (21,false), (38,false), (26,false)]
theorem p2176 (F : Frame G 3) : c2176.eval F.assign = true := by
  apply local_rup F.assign c2176 [c4, c2, c3, c972]
  · exact sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p972 F) (rfl))))
  · decide +kernel
def c2177 : CNF.Clause Nat := [(29,false), (99,false), (88,false), (87,false), (21,false), (15,false), (38,false), (50,false)]
theorem p2177 (F : Frame G 3) : c2177.eval F.assign = true := by
  apply local_rup F.assign c2177 [c4, c6, c973]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p973 F) (rfl)))
  · decide +kernel
def c2178 : CNF.Clause Nat := [(38,false), (39,false), (29,false), (10,false), (21,false), (86,false), (99,false)]
theorem p2178 (F : Frame G 3) : c2178.eval F.assign = true := by
  apply local_rup F.assign c2178 [c3, c4, c5, c974]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p974 F) (rfl))))
  · decide +kernel
def c2179 : CNF.Clause Nat := [(29,false), (27,false), (38,false), (39,false), (17,false), (21,false), (87,false), (86,false), (99,false)]
theorem p2179 (F : Frame G 3) : c2179.eval F.assign = true := by
  apply local_rup F.assign c2179 [c4, c975]
  · exact sat_cons (p4 F) ( sat_cons (p975 F) (rfl))
  · decide +kernel
def c2180 : CNF.Clause Nat := [(38,false), (50,false), (29,false), (76,false), (21,false), (86,false), (99,false)]
theorem p2180 (F : Frame G 3) : c2180.eval F.assign = true := by
  apply local_rup F.assign c2180 [c1, c3, c5, c977]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p977 F) (rfl))))
  · decide +kernel
def c2181 : CNF.Clause Nat := [(38,false), (6,false), (32,false), (76,false), (74,false), (86,false), (99,false)]
theorem p2181 (F : Frame G 3) : c2181.eval F.assign = true := by
  apply local_rup F.assign c2181 [c2, c1, c3, c978]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p978 F) (rfl))))
  · decide +kernel
def c2182 : CNF.Clause Nat := [(50,false), (38,false), (15,false), (21,false), (10,false), (74,false), (86,false), (99,false)]
theorem p2182 (F : Frame G 3) : c2182.eval F.assign = true := by
  apply local_rup F.assign c2182 [c3, c4, c979]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p979 F) (rfl)))
  · decide +kernel
def c2183 : CNF.Clause Nat := [(38,false), (6,false), (29,false), (76,false), (98,false), (86,false), (88,false)]
theorem p2183 (F : Frame G 3) : c2183.eval F.assign = true := by
  apply local_rup F.assign c2183 [c2, c1, c3, c980]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p980 F) (rfl))))
  · decide +kernel
def c2184 : CNF.Clause Nat := [(38,false), (26,false), (6,false), (76,false), (98,false), (86,false), (88,false)]
theorem p2184 (F : Frame G 3) : c2184.eval F.assign = true := by
  apply local_rup F.assign c2184 [c2, c3, c4, c981]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p981 F) (rfl))))
  · decide +kernel
def c2185 : CNF.Clause Nat := [(26,false), (38,false), (50,false), (17,false), (88,false), (11,false), (75,false), (98,false)]
theorem p2185 (F : Frame G 3) : c2185.eval F.assign = true := by
  apply local_rup F.assign c2185 [c5, c4, c982]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p982 F) (rfl)))
  · decide +kernel
def c2186 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (18,false), (76,false), (98,false), (30,false), (88,false)]
theorem p2186 (F : Frame G 3) : c2186.eval F.assign = true := by
  apply local_rup F.assign c2186 [c1, c6, c983]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p983 F) (rfl)))
  · decide +kernel
def c2187 : CNF.Clause Nat := [(39,false), (38,false), (22,false), (88,false), (8,false), (9,false), (29,false), (76,false)]
theorem p2187 (F : Frame G 3) : c2187.eval F.assign = true := by
  apply local_rup F.assign c2187 [c2, c6, c984]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p984 F) (rfl)))
  · decide +kernel
def c2188 : CNF.Clause Nat := [(88,false), (99,false), (75,false), (10,false), (32,false), (26,false), (38,false), (50,false)]
theorem p2188 (F : Frame G 3) : c2188.eval F.assign = true := by
  apply local_rup F.assign c2188 [c5, c4, c985]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p985 F) (rfl)))
  · decide +kernel
def c2189 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (88,false), (99,false), (29,false), (76,false)]
theorem p2189 (F : Frame G 3) : c2189.eval F.assign = true := by
  apply local_rup F.assign c2189 [c1, c5, c6, c986]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p986 F) (rfl))))
  · decide +kernel
def c2190 : CNF.Clause Nat := [(39,false), (50,false), (88,false), (99,false), (29,false), (76,false)]
theorem p2190 (F : Frame G 3) : c2190.eval F.assign = true := by
  apply local_rup F.assign c2190 [c1, c2, c5, c6, c987]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p987 F) (rfl)))))
  · decide +kernel
def c2191 : CNF.Clause Nat := [(75,false), (76,false), (10,false), (38,false), (50,false), (17,false), (88,false)]
theorem p2191 (F : Frame G 3) : c2191.eval F.assign = true := by
  apply local_rup F.assign c2191 [c6, c1, c5, c988]
  · exact sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p988 F) (rfl))))
  · decide +kernel
def c2192 : CNF.Clause Nat := [(87,false), (98,false), (99,false), (77,false), (5,false), (38,false), (26,false)]
theorem p2192 (F : Frame G 3) : c2192.eval F.assign = true := by
  apply local_rup F.assign c2192 [c5, c4, c3, c989]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p3 F) ( sat_cons (p989 F) (rfl))))
  · decide +kernel
def c2193 : CNF.Clause Nat := [(77,false), (99,false), (98,false), (21,false), (30,false), (26,false), (38,false), (50,false)]
theorem p2193 (F : Frame G 3) : c2193.eval F.assign = true := by
  apply local_rup F.assign c2193 [c4, c5, c990]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p990 F) (rfl)))
  · decide +kernel
def c2194 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (77,false), (99,false), (30,false), (21,false)]
theorem p2194 (F : Frame G 3) : c2194.eval F.assign = true := by
  apply local_rup F.assign c2194 [c4, c6, c5, c991]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p991 F) (rfl))))
  · decide +kernel
def c2195 : CNF.Clause Nat := [(5,false), (50,false), (86,false), (87,false), (21,false), (18,false), (77,false)]
theorem p2195 (F : Frame G 3) : c2195.eval F.assign = true := by
  apply local_rup F.assign c2195 [c1, c3, c6, c992]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p992 F) (rfl))))
  · decide +kernel
def c2196 : CNF.Clause Nat := [(39,false), (5,false), (18,false), (77,false), (99,false), (86,false), (87,false)]
theorem p2196 (F : Frame G 3) : c2196.eval F.assign = true := by
  apply local_rup F.assign c2196 [c3, c1, c2, c993]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p993 F) (rfl))))
  · decide +kernel
def c2197 : CNF.Clause Nat := [(26,false), (50,false), (18,false), (77,false), (99,false), (98,false), (10,false), (8,false)]
theorem p2197 (F : Frame G 3) : c2197.eval F.assign = true := by
  apply local_rup F.assign c2197 [c3, c2, c994]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p994 F) (rfl)))
  · decide +kernel
def c2198 : CNF.Clause Nat := [(26,false), (50,false), (5,false), (77,false), (99,false), (98,false), (21,false)]
theorem p2198 (F : Frame G 3) : c2198.eval F.assign = true := by
  apply local_rup F.assign c2198 [c3, c4, c5, c995]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p995 F) (rfl))))
  · decide +kernel
def c2199 : CNF.Clause Nat := [(26,false), (50,false), (8,false), (76,false), (98,false), (99,false)]
theorem p2199 (F : Frame G 3) : c2199.eval F.assign = true := by
  apply local_rup F.assign c2199 [c3, c2, c5, c4, c996]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p996 F) (rfl)))))
  · decide +kernel
def c2200 : CNF.Clause Nat := [(39,false), (50,false), (30,false), (98,false), (76,false), (77,false)]
theorem p2200 (F : Frame G 3) : c2200.eval F.assign = true := by
  apply local_rup F.assign c2200 [c1, c2, c5, c6, c997]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p997 F) (rfl)))))
  · decide +kernel
def c2201 : CNF.Clause Nat := [(5,false), (39,false), (99,false), (77,false), (74,false), (87,false)]
theorem p2201 (F : Frame G 3) : c2201.eval F.assign = true := by
  apply local_rup F.assign c2201 [c2, c1, c3, c6, c998]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p998 F) (rfl)))))
  · decide +kernel
def c2202 : CNF.Clause Nat := [(27,false), (50,false), (39,false), (11,false), (77,false), (74,false), (20,false), (98,false)]
theorem p2202 (F : Frame G 3) : c2202.eval F.assign = true := by
  apply local_rup F.assign c2202 [c1, c5, c999]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p999 F) (rfl)))
  · decide +kernel
def c2203 : CNF.Clause Nat := [(50,false), (39,false), (77,false), (99,false), (32,false), (87,false)]
theorem p2203 (F : Frame G 3) : c2203.eval F.assign = true := by
  apply local_rup F.assign c2203 [c2, c1, c4, c6, c1000]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1000 F) (rfl)))))
  · decide +kernel
def c2204 : CNF.Clause Nat := [(10,false), (87,false), (50,false), (29,false), (77,false), (99,false)]
theorem p2204 (F : Frame G 3) : c2204.eval F.assign = true := by
  apply local_rup F.assign c2204 [c1, c5, c2, c3, c1001]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1001 F) (rfl)))))
  · decide +kernel
def c2205 : CNF.Clause Nat := [(77,false), (99,false), (98,false), (87,false), (27,false)]
theorem p2205 (F : Frame G 3) : c2205.eval F.assign = true := by
  apply local_rup F.assign c2205 [c1, c4, c5, c2, c3, c1002]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1002 F) (rfl))))))
  · decide +kernel
def c2206 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (10,false), (76,false), (18,false), (86,false), (99,false)]
theorem p2206 (F : Frame G 3) : c2206.eval F.assign = true := by
  apply local_rup F.assign c2206 [c3, c5, c1003]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p1003 F) (rfl)))
  · decide +kernel
def c2207 : CNF.Clause Nat := [(39,false), (38,false), (18,false), (10,false), (98,false), (86,false), (88,false)]
theorem p2207 (F : Frame G 3) : c2207.eval F.assign = true := by
  apply local_rup F.assign c2207 [c3, c2, c4, c1004]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1004 F) (rfl))))
  · decide +kernel
def c2208 : CNF.Clause Nat := [(5,false), (50,false), (17,false), (87,false), (32,false), (29,false), (75,false), (99,false)]
theorem p2208 (F : Frame G 3) : c2208.eval F.assign = true := by
  apply local_rup F.assign c2208 [c1, c5, c1005]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p1005 F) (rfl)))
  · decide +kernel
def c2209 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (87,false), (32,false), (29,false), (75,false), (99,false)]
theorem p2209 (F : Frame G 3) : c2209.eval F.assign = true := by
  apply local_rup F.assign c2209 [c1, c5, c1006]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p1006 F) (rfl)))
  · decide +kernel
def c2210 : CNF.Clause Nat := [(87,false), (98,false), (75,false), (11,false), (33,false), (26,false), (38,false), (50,false)]
theorem p2210 (F : Frame G 3) : c2210.eval F.assign = true := by
  apply local_rup F.assign c2210 [c5, c4, c1007]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1007 F) (rfl)))
  · decide +kernel
def c2211 : CNF.Clause Nat := [(74,false), (87,false), (98,false), (99,false), (33,false), (39,false), (15,false)]
theorem p2211 (F : Frame G 3) : c2211.eval F.assign = true := by
  apply local_rup F.assign c2211 [c4, c3, c2, c1008]
  · exact sat_cons (p4 F) ( sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p1008 F) (rfl))))
  · decide +kernel
def c2212 : CNF.Clause Nat := [(50,false), (39,false), (74,false), (87,false), (32,false), (99,false)]
theorem p2212 (F : Frame G 3) : c2212.eval F.assign = true := by
  apply local_rup F.assign c2212 [c2, c1, c4, c6, c1009]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1009 F) (rfl)))))
  · decide +kernel
def c2213 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (74,false), (10,false), (98,false), (33,false)]
theorem p2213 (F : Frame G 3) : c2213.eval F.assign = true := by
  apply local_rup F.assign c2213 [c5, c4, c6, c1010]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1010 F) (rfl))))
  · decide +kernel
def c2214 : CNF.Clause Nat := [(50,false), (39,false), (74,false), (87,false), (98,false), (33,false)]
theorem p2214 (F : Frame G 3) : c2214.eval F.assign = true := by
  apply local_rup F.assign c2214 [c2, c1, c4, c6, c1011]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1011 F) (rfl)))))
  · decide +kernel
def c2215 : CNF.Clause Nat := [(5,false), (39,false), (17,false), (87,false), (32,false), (29,false), (75,false), (99,false)]
theorem p2215 (F : Frame G 3) : c2215.eval F.assign = true := by
  apply local_rup F.assign c2215 [c1, c5, c1012]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p1012 F) (rfl)))
  · decide +kernel
def c2216 : CNF.Clause Nat := [(75,false), (99,false), (33,false), (27,false), (38,false), (39,false), (17,false), (87,false)]
theorem p2216 (F : Frame G 3) : c2216.eval F.assign = true := by
  apply local_rup F.assign c2216 [c4, c5, c1013]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1013 F) (rfl)))
  · decide +kernel
def c2217 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (21,false), (87,false), (8,false), (29,false), (99,false)]
theorem p2217 (F : Frame G 3) : c2217.eval F.assign = true := by
  apply local_rup F.assign c2217 [c4, c6, c1014]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1014 F) (rfl)))
  · decide +kernel
def c2218 : CNF.Clause Nat := [(17,false), (39,false), (26,false), (33,false), (99,false), (98,false), (10,false), (74,false)]
theorem p2218 (F : Frame G 3) : c2218.eval F.assign = true := by
  apply local_rup F.assign c2218 [c2, c4, c1015]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1015 F) (rfl)))
  · decide +kernel
def c2219 : CNF.Clause Nat := [(17,false), (39,false), (74,false), (87,false), (32,false), (99,false)]
theorem p2219 (F : Frame G 3) : c2219.eval F.assign = true := by
  apply local_rup F.assign c2219 [c2, c1, c4, c6, c1016]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1016 F) (rfl)))))
  · decide +kernel
def c2220 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (18,false), (8,false), (87,false), (32,false), (99,false)]
theorem p2220 (F : Frame G 3) : c2220.eval F.assign = true := by
  apply local_rup F.assign c2220 [c4, c6, c1017]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1017 F) (rfl)))
  · decide +kernel
def c2221 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (22,false), (11,false), (29,false), (30,false), (87,false), (98,false)]
theorem p2221 (F : Frame G 3) : c2221.eval F.assign = true := by
  apply local_rup F.assign c2221 [c4, c1019]
  · exact sat_cons (p4 F) ( sat_cons (p1019 F) (rfl))
  · decide +kernel
def c2222 : CNF.Clause Nat := [(26,false), (50,false), (22,false), (99,false), (98,false), (10,false), (74,false)]
theorem p2222 (F : Frame G 3) : c2222.eval F.assign = true := by
  apply local_rup F.assign c2222 [c3, c2, c4, c1020]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1020 F) (rfl))))
  · decide +kernel
def c2223 : CNF.Clause Nat := [(74,false), (87,false), (98,false), (99,false), (22,false), (27,false)]
theorem p2223 (F : Frame G 3) : c2223.eval F.assign = true := by
  apply local_rup F.assign c2223 [c1, c4, c2, c3, c1021]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1021 F) (rfl)))))
  · decide +kernel
def c2224 : CNF.Clause Nat := [(74,false), (87,false), (21,false), (50,false), (99,false)]
theorem p2224 (F : Frame G 3) : c2224.eval F.assign = true := by
  apply local_rup F.assign c2224 [c1, c4, c2, c3, c6, c1022]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p1022 F) (rfl))))))
  · decide +kernel
def c2225 : CNF.Clause Nat := [(15,false), (50,false), (30,false), (87,false), (10,false), (75,false), (99,false)]
theorem p2225 (F : Frame G 3) : c2225.eval F.assign = true := by
  apply local_rup F.assign c2225 [c2, c3, c4, c1023]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1023 F) (rfl))))
  · decide +kernel
def c2226 : CNF.Clause Nat := [(15,false), (50,false), (32,false), (87,false), (8,false), (75,false), (99,false)]
theorem p2226 (F : Frame G 3) : c2226.eval F.assign = true := by
  apply local_rup F.assign c2226 [c2, c3, c4, c1024]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1024 F) (rfl))))
  · decide +kernel
def c2227 : CNF.Clause Nat := [(38,false), (50,false), (32,false), (10,false), (8,false), (18,false), (75,false), (99,false)]
theorem p2227 (F : Frame G 3) : c2227.eval F.assign = true := by
  apply local_rup F.assign c2227 [c3, c5, c1025]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p1025 F) (rfl)))
  · decide +kernel
def c2228 : CNF.Clause Nat := [(38,false), (26,false), (6,false), (10,false), (87,false), (74,false), (75,false), (99,false)]
theorem p2228 (F : Frame G 3) : c2228.eval F.assign = true := by
  apply local_rup F.assign c2228 [c2, c3, c1026]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1026 F) (rfl)))
  · decide +kernel
def c2229 : CNF.Clause Nat := [(15,false), (39,false), (33,false), (99,false), (75,false), (8,false), (87,false)]
theorem p2229 (F : Frame G 3) : c2229.eval F.assign = true := by
  apply local_rup F.assign c2229 [c2, c3, c4, c1027]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1027 F) (rfl))))
  · decide +kernel
def c2230 : CNF.Clause Nat := [(38,false), (39,false), (29,false), (75,false), (99,false), (11,false), (8,false), (87,false)]
theorem p2230 (F : Frame G 3) : c2230.eval F.assign = true := by
  apply local_rup F.assign c2230 [c2, c3, c1028]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1028 F) (rfl)))
  · decide +kernel
def c2231 : CNF.Clause Nat := [(15,false), (39,false), (6,false), (75,false), (99,false), (33,false), (30,false), (87,false)]
theorem p2231 (F : Frame G 3) : c2231.eval F.assign = true := by
  apply local_rup F.assign c2231 [c2, c4, c1029]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1029 F) (rfl)))
  · decide +kernel
def c2232 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (75,false), (99,false), (33,false), (30,false), (87,false)]
theorem p2232 (F : Frame G 3) : c2232.eval F.assign = true := by
  apply local_rup F.assign c2232 [c2, c4, c1030]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1030 F) (rfl)))
  · decide +kernel
def c2233 : CNF.Clause Nat := [(87,false), (10,false), (39,false), (29,false), (75,false), (99,false)]
theorem p2233 (F : Frame G 3) : c2233.eval F.assign = true := by
  apply local_rup F.assign c2233 [c2, c5, c1, c3, c1031]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p1031 F) (rfl)))))
  · decide +kernel
def c2234 : CNF.Clause Nat := [(38,false), (39,false), (33,false), (22,false), (18,false), (75,false), (9,false), (8,false), (87,false)]
theorem p2234 (F : Frame G 3) : c2234.eval F.assign = true := by
  apply local_rup F.assign c2234 [c3, c1032]
  · exact sat_cons (p3 F) ( sat_cons (p1032 F) (rfl))
  · decide +kernel
def c2235 : CNF.Clause Nat := [(38,false), (39,false), (33,false), (99,false), (75,false), (8,false), (21,false)]
theorem p2235 (F : Frame G 3) : c2235.eval F.assign = true := by
  apply local_rup F.assign c2235 [c3, c4, c5, c1033]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1033 F) (rfl))))
  · decide +kernel
def c2236 : CNF.Clause Nat := [(27,false), (38,false), (39,false), (6,false), (75,false), (99,false), (22,false), (87,false)]
theorem p2236 (F : Frame G 3) : c2236.eval F.assign = true := by
  apply local_rup F.assign c2236 [c4, c5, c1034]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1034 F) (rfl)))
  · decide +kernel
def c2237 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (74,false), (87,false), (32,false), (99,false)]
theorem p2237 (F : Frame G 3) : c2237.eval F.assign = true := by
  apply local_rup F.assign c2237 [c2, c4, c6, c1035]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1035 F) (rfl))))
  · decide +kernel
def c2238 : CNF.Clause Nat := [(38,false), (39,false), (29,false), (74,false), (8,false), (10,false), (98,false), (99,false)]
theorem p2238 (F : Frame G 3) : c2238.eval F.assign = true := by
  apply local_rup F.assign c2238 [c2, c3, c1036]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1036 F) (rfl)))
  · decide +kernel
def c2239 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (74,false), (87,false), (98,false), (33,false)]
theorem p2239 (F : Frame G 3) : c2239.eval F.assign = true := by
  apply local_rup F.assign c2239 [c2, c4, c6, c1037]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1037 F) (rfl))))
  · decide +kernel
def c2240 : CNF.Clause Nat := [(27,false), (39,false), (77,false), (99,false), (86,false), (21,false)]
theorem p2240 (F : Frame G 3) : c2240.eval F.assign = true := by
  apply local_rup F.assign c2240 [c3, c1, c4, c5, c1038]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1038 F) (rfl)))))
  · decide +kernel
def c2241 : CNF.Clause Nat := [(29,false), (32,false), (98,false), (99,false), (88,false), (15,false), (38,false), (50,false)]
theorem p2241 (F : Frame G 3) : c2241.eval F.assign = true := by
  apply local_rup F.assign c2241 [c4, c5, c1039]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1039 F) (rfl)))
  · decide +kernel
def c2242 : CNF.Clause Nat := [(77,false), (88,false), (38,false), (39,false), (98,false)]
theorem p2242 (F : Frame G 3) : c2242.eval F.assign = true := by
  apply local_rup F.assign c2242 [c4, c5, c2, c3, c6, c1040]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p1040 F) (rfl))))))
  · decide +kernel
def c2243 : CNF.Clause Nat := [(38,false), (39,false), (29,false), (77,false), (11,false), (8,false), (86,false), (98,false)]
theorem p2243 (F : Frame G 3) : c2243.eval F.assign = true := by
  apply local_rup F.assign c2243 [c2, c3, c1041]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1041 F) (rfl)))
  · decide +kernel
def c2244 : CNF.Clause Nat := [(38,false), (39,false), (32,false), (10,false), (8,false), (86,false), (75,false), (77,false)]
theorem p2244 (F : Frame G 3) : c2244.eval F.assign = true := by
  apply local_rup F.assign c2244 [c2, c3, c1042]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1042 F) (rfl)))
  · decide +kernel
def c2245 : CNF.Clause Nat := [(39,false), (5,false), (74,false), (76,false), (98,false), (99,false)]
theorem p2245 (F : Frame G 3) : c2245.eval F.assign = true := by
  apply local_rup F.assign c2245 [c3, c1, c2, c5, c1043]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1043 F) (rfl)))))
  · decide +kernel
def c2246 : CNF.Clause Nat := [(39,false), (50,false), (74,false), (77,false), (11,false), (9,false), (32,false)]
theorem p2246 (F : Frame G 3) : c2246.eval F.assign = true := by
  apply local_rup F.assign c2246 [c2, c5, c6, c1044]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1044 F) (rfl))))
  · decide +kernel
def c2247 : CNF.Clause Nat := [(8,false), (74,false), (77,false), (99,false), (98,false), (21,false), (27,false)]
theorem p2247 (F : Frame G 3) : c2247.eval F.assign = true := by
  apply local_rup F.assign c2247 [c1, c2, c3, c1045]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1045 F) (rfl))))
  · decide +kernel
def c2248 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (30,false), (74,false), (77,false), (22,false), (20,false), (98,false)]
theorem p2248 (F : Frame G 3) : c2248.eval F.assign = true := by
  apply local_rup F.assign c2248 [c1, c1046]
  · exact sat_cons (p1 F) ( sat_cons (p1046 F) (rfl))
  · decide +kernel
def c2249 : CNF.Clause Nat := [(39,false), (50,false), (30,false), (32,false), (98,false), (75,false), (77,false)]
theorem p2249 (F : Frame G 3) : c2249.eval F.assign = true := by
  apply local_rup F.assign c2249 [c1, c2, c5, c1047]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1047 F) (rfl))))
  · decide +kernel
def c2250 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (99,false), (11,false), (18,false), (87,false)]
theorem p2250 (F : Frame G 3) : c2250.eval F.assign = true := by
  apply local_rup F.assign c2250 [c6, c4, c5, c1048]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1048 F) (rfl))))
  · decide +kernel
def c2251 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (20,false), (87,false), (76,false), (11,false)]
theorem p2251 (F : Frame G 3) : c2251.eval F.assign = true := by
  apply local_rup F.assign c2251 [c6, c5, c4, c1049]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1049 F) (rfl))))
  · decide +kernel
def c2252 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (74,false), (88,false), (99,false), (32,false)]
theorem p2252 (F : Frame G 3) : c2252.eval F.assign = true := by
  apply local_rup F.assign c2252 [c2, c4, c6, c1050]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1050 F) (rfl))))
  · decide +kernel
def c2253 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (29,false), (32,false), (21,false), (88,false), (99,false)]
theorem p2253 (F : Frame G 3) : c2253.eval F.assign = true := by
  apply local_rup F.assign c2253 [c4, c5, c1051]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1051 F) (rfl)))
  · decide +kernel
def c2254 : CNF.Clause Nat := [(50,false), (39,false), (74,false), (88,false), (99,false), (32,false)]
theorem p2254 (F : Frame G 3) : c2254.eval F.assign = true := by
  apply local_rup F.assign c2254 [c2, c1, c4, c6, c1052]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1052 F) (rfl)))))
  · decide +kernel
def c2255 : CNF.Clause Nat := [(75,false), (98,false), (21,false), (38,false), (39,false), (30,false), (88,false)]
theorem p2255 (F : Frame G 3) : c2255.eval F.assign = true := by
  apply local_rup F.assign c2255 [c4, c2, c3, c1053]
  · exact sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1053 F) (rfl))))
  · decide +kernel
def c2256 : CNF.Clause Nat := [(27,false), (38,false), (39,false), (17,false), (18,false), (8,false), (87,false), (98,false), (99,false)]
theorem p2256 (F : Frame G 3) : c2256.eval F.assign = true := by
  apply local_rup F.assign c2256 [c4, c1054]
  · exact sat_cons (p4 F) ( sat_cons (p1054 F) (rfl))
  · decide +kernel
def c2257 : CNF.Clause Nat := [(27,false), (38,false), (39,false), (6,false), (18,false), (87,false), (98,false), (99,false)]
theorem p2257 (F : Frame G 3) : c2257.eval F.assign = true := by
  apply local_rup F.assign c2257 [c4, c5, c1055]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1055 F) (rfl)))
  · decide +kernel
def c2258 : CNF.Clause Nat := [(75,false), (99,false), (88,false), (87,false), (32,false), (27,false), (15,false), (39,false)]
theorem p2258 (F : Frame G 3) : c2258.eval F.assign = true := by
  apply local_rup F.assign c2258 [c4, c2, c1056]
  · exact sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p1056 F) (rfl)))
  · decide +kernel
def c2259 : CNF.Clause Nat := [(38,false), (39,false), (99,false), (11,false), (10,false), (21,false), (18,false), (74,false)]
theorem p2259 (F : Frame G 3) : c2259.eval F.assign = true := by
  apply local_rup F.assign c2259 [c3, c6, c1057]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p1057 F) (rfl)))
  · decide +kernel
def c2260 : CNF.Clause Nat := [(74,false), (76,false), (10,false), (39,false), (99,false)]
theorem p2260 (F : Frame G 3) : c2260.eval F.assign = true := by
  apply local_rup F.assign c2260 [c2, c5, c1, c3, c6, c1058]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p1058 F) (rfl))))))
  · decide +kernel
def c2261 : CNF.Clause Nat := [(26,false), (38,false), (88,false), (99,false), (75,false), (10,false)]
theorem p2261 (F : Frame G 3) : c2261.eval F.assign = true := by
  apply local_rup F.assign c2261 [c3, c2, c5, c4, c1059]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1059 F) (rfl)))))
  · decide +kernel
def c2262 : CNF.Clause Nat := [(39,false), (38,false), (88,false), (99,false), (75,false), (10,false)]
theorem p2262 (F : Frame G 3) : c2262.eval F.assign = true := by
  apply local_rup F.assign c2262 [c3, c2, c5, c4, c1060]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1060 F) (rfl)))))
  · decide +kernel
def c2263 : CNF.Clause Nat := [(38,false), (50,false), (9,false), (76,false), (21,false), (88,false)]
theorem p2263 (F : Frame G 3) : c2263.eval F.assign = true := by
  apply local_rup F.assign c2263 [c3, c6, c4, c5, c1061]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1061 F) (rfl)))))
  · decide +kernel
def c2264 : CNF.Clause Nat := [(74,false), (77,false), (99,false), (98,false), (10,false), (26,false), (27,false), (50,false)]
theorem p2264 (F : Frame G 3) : c2264.eval F.assign = true := by
  apply local_rup F.assign c2264 [c5, c1, c1062]
  · exact sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p1062 F) (rfl)))
  · decide +kernel
def c2265 : CNF.Clause Nat := [(38,false), (50,false), (98,false), (21,false), (74,false), (77,false)]
theorem p2265 (F : Frame G 3) : c2265.eval F.assign = true := by
  apply local_rup F.assign c2265 [c1, c3, c6, c5, c1063]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1063 F) (rfl)))))
  · decide +kernel
def c2266 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (30,false), (98,false), (76,false), (77,false)]
theorem p2266 (F : Frame G 3) : c2266.eval F.assign = true := by
  apply local_rup F.assign c2266 [c1, c5, c6, c1064]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1064 F) (rfl))))
  · decide +kernel
def c2267 : CNF.Clause Nat := [(38,false), (6,false), (29,false), (74,false), (87,false), (98,false), (99,false)]
theorem p2267 (F : Frame G 3) : c2267.eval F.assign = true := by
  apply local_rup F.assign c2267 [c2, c1, c3, c1065]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p1065 F) (rfl))))
  · decide +kernel
def c2268 : CNF.Clause Nat := [(38,false), (50,false), (30,false), (18,false), (10,false), (98,false), (99,false)]
theorem p2268 (F : Frame G 3) : c2268.eval F.assign = true := by
  apply local_rup F.assign c2268 [c3, c5, c4, c1066]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1066 F) (rfl))))
  · decide +kernel
def c2269 : CNF.Clause Nat := [(6,false), (50,false), (27,false), (30,false), (88,false), (99,false), (98,false), (21,false), (18,false)]
theorem p2269 (F : Frame G 3) : c2269.eval F.assign = true := by
  apply local_rup F.assign c2269 [c1, c1067]
  · exact sat_cons (p1 F) ( sat_cons (p1067 F) (rfl))
  · decide +kernel
def c2270 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (18,false), (88,false), (99,false), (32,false)]
theorem p2270 (F : Frame G 3) : c2270.eval F.assign = true := by
  apply local_rup F.assign c2270 [c4, c5, c6, c1068]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1068 F) (rfl))))
  · decide +kernel
def c2271 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (8,false), (77,false), (99,false), (32,false)]
theorem p2271 (F : Frame G 3) : c2271.eval F.assign = true := by
  apply local_rup F.assign c2271 [c5, c4, c6, c1069]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1069 F) (rfl))))
  · decide +kernel
def c2272 : CNF.Clause Nat := [(38,false), (50,false), (29,false), (8,false), (88,false), (99,false), (20,false), (21,false)]
theorem p2272 (F : Frame G 3) : c2272.eval F.assign = true := by
  apply local_rup F.assign c2272 [c3, c4, c1070]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1070 F) (rfl)))
  · decide +kernel
def c2273 : CNF.Clause Nat := [(38,false), (6,false), (32,false), (87,false), (74,false), (75,false), (99,false)]
theorem p2273 (F : Frame G 3) : c2273.eval F.assign = true := by
  apply local_rup F.assign c2273 [c2, c1, c3, c1071]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p1071 F) (rfl))))
  · decide +kernel
def c2274 : CNF.Clause Nat := [(38,false), (6,false), (29,false), (75,false), (98,false), (87,false), (88,false)]
theorem p2274 (F : Frame G 3) : c2274.eval F.assign = true := by
  apply local_rup F.assign c2274 [c2, c1, c3, c1072]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p1072 F) (rfl))))
  · decide +kernel
def c2275 : CNF.Clause Nat := [(15,false), (50,false), (6,false), (76,false), (32,false), (30,false), (88,false), (99,false)]
theorem p2275 (F : Frame G 3) : c2275.eval F.assign = true := by
  apply local_rup F.assign c2275 [c2, c4, c1073]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1073 F) (rfl)))
  · decide +kernel
def c2276 : CNF.Clause Nat := [(50,false), (15,false), (10,false), (76,false), (75,false), (86,false), (88,false)]
theorem p2276 (F : Frame G 3) : c2276.eval F.assign = true := by
  apply local_rup F.assign c2276 [c3, c2, c1, c1074]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p1074 F) (rfl))))
  · decide +kernel
def c2277 : CNF.Clause Nat := [(17,false), (15,false), (38,false), (5,false), (8,false), (86,false), (98,false), (76,false), (77,false)]
theorem p2277 (F : Frame G 3) : c2277.eval F.assign = true := by
  apply local_rup F.assign c2277 [c3, c1075]
  · exact sat_cons (p3 F) ( sat_cons (p1075 F) (rfl))
  · decide +kernel
def c2278 : CNF.Clause Nat := [(15,false), (50,false), (29,false), (76,false), (10,false), (8,false), (86,false), (99,false)]
theorem p2278 (F : Frame G 3) : c2278.eval F.assign = true := by
  apply local_rup F.assign c2278 [c2, c3, c1076]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1076 F) (rfl)))
  · decide +kernel
def c2279 : CNF.Clause Nat := [(50,false), (38,false), (15,false), (86,false), (98,false), (10,false), (77,false)]
theorem p2279 (F : Frame G 3) : c2279.eval F.assign = true := by
  apply local_rup F.assign c2279 [c3, c5, c4, c1077]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1077 F) (rfl))))
  · decide +kernel
def c2280 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (29,false), (75,false), (98,false), (21,false), (88,false)]
theorem p2280 (F : Frame G 3) : c2280.eval F.assign = true := by
  apply local_rup F.assign c2280 [c1, c5, c1078]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p1078 F) (rfl)))
  · decide +kernel
def c2281 : CNF.Clause Nat := [(39,false), (5,false), (18,false), (75,false), (98,false), (87,false), (88,false)]
theorem p2281 (F : Frame G 3) : c2281.eval F.assign = true := by
  apply local_rup F.assign c2281 [c3, c1, c2, c1079]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p1079 F) (rfl))))
  · decide +kernel
def c2282 : CNF.Clause Nat := [(50,false), (39,false), (29,false), (32,false), (87,false), (86,false), (99,false)]
theorem p2282 (F : Frame G 3) : c2282.eval F.assign = true := by
  apply local_rup F.assign c2282 [c2, c1, c4, c1080]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p1080 F) (rfl))))
  · decide +kernel
def c2283 : CNF.Clause Nat := [(50,false), (39,false), (29,false), (32,false), (98,false), (86,false), (88,false)]
theorem p2283 (F : Frame G 3) : c2283.eval F.assign = true := by
  apply local_rup F.assign c2283 [c2, c1, c4, c1081]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p1081 F) (rfl))))
  · decide +kernel
def c2284 : CNF.Clause Nat := [(27,false), (50,false), (39,false), (15,false), (86,false), (98,false), (10,false), (77,false)]
theorem p2284 (F : Frame G 3) : c2284.eval F.assign = true := by
  apply local_rup F.assign c2284 [c5, c4, c1082]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1082 F) (rfl)))
  · decide +kernel
def c2285 : CNF.Clause Nat := [(50,false), (38,false), (10,false), (87,false), (74,false), (18,false), (22,false), (99,false)]
theorem p2285 (F : Frame G 3) : c2285.eval F.assign = true := by
  apply local_rup F.assign c2285 [c3, c1, c1083]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p1083 F) (rfl)))
  · decide +kernel
def c2286 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (18,false), (10,false), (32,false), (86,false), (88,false)]
theorem p2286 (F : Frame G 3) : c2286.eval F.assign = true := by
  apply local_rup F.assign c2286 [c4, c6, c1084]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1084 F) (rfl)))
  · decide +kernel
def c2287 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (20,false), (29,false), (10,false), (87,false), (88,false)]
theorem p2287 (F : Frame G 3) : c2287.eval F.assign = true := by
  apply local_rup F.assign c2287 [c6, c4, c1085]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1085 F) (rfl)))
  · decide +kernel
def c2288 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (29,false), (32,false), (87,false), (20,false), (99,false)]
theorem p2288 (F : Frame G 3) : c2288.eval F.assign = true := by
  apply local_rup F.assign c2288 [c4, c5, c1086]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1086 F) (rfl)))
  · decide +kernel
def c2289 : CNF.Clause Nat := [(15,false), (50,false), (6,false), (29,false), (32,false), (87,false), (86,false), (99,false)]
theorem p2289 (F : Frame G 3) : c2289.eval F.assign = true := by
  apply local_rup F.assign c2289 [c2, c4, c1087]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1087 F) (rfl)))
  · decide +kernel
def c2290 : CNF.Clause Nat := [(15,false), (50,false), (29,false), (10,false), (87,false), (86,false), (99,false)]
theorem p2290 (F : Frame G 3) : c2290.eval F.assign = true := by
  apply local_rup F.assign c2290 [c2, c3, c4, c1088]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1088 F) (rfl))))
  · decide +kernel
def c2291 : CNF.Clause Nat := [(88,false), (99,false), (26,false), (38,false), (50,false), (6,false), (76,false)]
theorem p2291 (F : Frame G 3) : c2291.eval F.assign = true := by
  apply local_rup F.assign c2291 [c5, c6, c4, c1089]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1089 F) (rfl))))
  · decide +kernel
def c2292 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (10,false), (76,false), (29,false), (20,false), (88,false)]
theorem p2292 (F : Frame G 3) : c2292.eval F.assign = true := by
  apply local_rup F.assign c2292 [c6, c5, c1090]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1090 F) (rfl)))
  · decide +kernel
def c2293 : CNF.Clause Nat := [(50,false), (38,false), (15,false), (88,false), (99,false), (75,false), (10,false)]
theorem p2293 (F : Frame G 3) : c2293.eval F.assign = true := by
  apply local_rup F.assign c2293 [c3, c5, c4, c1091]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1091 F) (rfl))))
  · decide +kernel
def c2294 : CNF.Clause Nat := [(6,false), (50,false), (74,false), (76,false), (32,false), (99,false)]
theorem p2294 (F : Frame G 3) : c2294.eval F.assign = true := by
  apply local_rup F.assign c2294 [c1, c2, c5, c6, c1092]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1092 F) (rfl)))))
  · decide +kernel
def c2295 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (30,false), (99,false), (11,false), (76,false)]
theorem p2295 (F : Frame G 3) : c2295.eval F.assign = true := by
  apply local_rup F.assign c2295 [c5, c6, c4, c1093]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1093 F) (rfl))))
  · decide +kernel
def c2296 : CNF.Clause Nat := [(9,false), (99,false), (77,false), (76,false), (32,false), (30,false), (50,false)]
theorem p2296 (F : Frame G 3) : c2296.eval F.assign = true := by
  apply local_rup F.assign c2296 [c1, c5, c2, c1094]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p1094 F) (rfl))))
  · decide +kernel
def c2297 : CNF.Clause Nat := [(38,false), (50,false), (30,false), (88,false), (99,false), (20,false), (18,false), (76,false)]
theorem p2297 (F : Frame G 3) : c2297.eval F.assign = true := by
  apply local_rup F.assign c2297 [c1, c3, c1095]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p1095 F) (rfl)))
  · decide +kernel
def c2298 : CNF.Clause Nat := [(50,false), (38,false), (15,false), (22,false), (99,false), (86,false), (74,false), (10,false)]
theorem p2298 (F : Frame G 3) : c2298.eval F.assign = true := by
  apply local_rup F.assign c2298 [c3, c4, c1096]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1096 F) (rfl)))
  · decide +kernel
def c2299 : CNF.Clause Nat := [(38,false), (26,false), (6,false), (10,false), (87,false), (74,false), (77,false), (99,false)]
theorem p2299 (F : Frame G 3) : c2299.eval F.assign = true := by
  apply local_rup F.assign c2299 [c2, c3, c1097]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1097 F) (rfl)))
  · decide +kernel
def c2300 : CNF.Clause Nat := [(38,false), (50,false), (9,false), (77,false), (88,false), (21,false)]
theorem p2300 (F : Frame G 3) : c2300.eval F.assign = true := by
  apply local_rup F.assign c2300 [c3, c6, c4, c5, c1098]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1098 F) (rfl)))))
  · decide +kernel
def c2301 : CNF.Clause Nat := [(38,false), (39,false), (30,false), (88,false), (99,false), (9,false), (76,false)]
theorem p2301 (F : Frame G 3) : c2301.eval F.assign = true := by
  apply local_rup F.assign c2301 [c2, c3, c4, c1099]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1099 F) (rfl))))
  · decide +kernel
def c2302 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (10,false), (76,false), (18,false), (30,false), (99,false)]
theorem p2302 (F : Frame G 3) : c2302.eval F.assign = true := by
  apply local_rup F.assign c2302 [c5, c6, c1100]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1100 F) (rfl)))
  · decide +kernel
def c2303 : CNF.Clause Nat := [(26,false), (39,false), (50,false), (5,false), (77,false), (99,false), (20,false), (87,false)]
theorem p2303 (F : Frame G 3) : c2303.eval F.assign = true := by
  apply local_rup F.assign c2303 [c4, c5, c1101]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1101 F) (rfl)))
  · decide +kernel
def c2304 : CNF.Clause Nat := [(26,false), (50,false), (18,false), (76,false), (10,false), (8,false), (86,false), (99,false)]
theorem p2304 (F : Frame G 3) : c2304.eval F.assign = true := by
  apply local_rup F.assign c2304 [c3, c2, c1102]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p1102 F) (rfl)))
  · decide +kernel
def c2305 : CNF.Clause Nat := [(26,false), (50,false), (5,false), (18,false), (21,false), (87,false), (86,false), (99,false)]
theorem p2305 (F : Frame G 3) : c2305.eval F.assign = true := by
  apply local_rup F.assign c2305 [c3, c4, c1103]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1103 F) (rfl)))
  · decide +kernel
def c2306 : CNF.Clause Nat := [(99,false), (88,false), (87,false), (76,false), (18,false), (15,false), (5,false), (50,false)]
theorem p2306 (F : Frame G 3) : c2306.eval F.assign = true := by
  apply local_rup F.assign c2306 [c6, c1, c1104]
  · exact sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p1104 F) (rfl)))
  · decide +kernel
def c2307 : CNF.Clause Nat := [(99,false), (77,false), (76,false), (87,false), (15,false), (5,false), (50,false)]
theorem p2307 (F : Frame G 3) : c2307.eval F.assign = true := by
  apply local_rup F.assign c2307 [c6, c5, c1, c1105]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p1105 F) (rfl))))
  · decide +kernel
def c2308 : CNF.Clause Nat := [(6,false), (50,false), (27,false), (20,false), (87,false), (76,false), (77,false)]
theorem p2308 (F : Frame G 3) : c2308.eval F.assign = true := by
  apply local_rup F.assign c2308 [c1, c6, c5, c1106]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1106 F) (rfl))))
  · decide +kernel
def c2309 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (20,false), (87,false), (76,false), (77,false)]
theorem p2309 (F : Frame G 3) : c2309.eval F.assign = true := by
  apply local_rup F.assign c2309 [c1, c6, c5, c1107]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1107 F) (rfl))))
  · decide +kernel
def c2310 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (18,false), (10,false), (98,false), (86,false), (30,false), (33,false)]
theorem p2310 (F : Frame G 3) : c2310.eval F.assign = true := by
  apply local_rup F.assign c2310 [c4, c1108]
  · exact sat_cons (p4 F) ( sat_cons (p1108 F) (rfl))
  · decide +kernel
def c2311 : CNF.Clause Nat := [(11,false), (99,false), (98,false), (76,false), (74,false), (27,false), (26,false), (39,false)]
theorem p2311 (F : Frame G 3) : c2311.eval F.assign = true := by
  apply local_rup F.assign c2311 [c5, c2, c1109]
  · exact sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p1109 F) (rfl)))
  · decide +kernel
def c2312 : CNF.Clause Nat := [(11,false), (99,false), (98,false), (76,false), (74,false), (30,false), (27,false), (15,false), (39,false)]
theorem p2312 (F : Frame G 3) : c2312.eval F.assign = true := by
  apply local_rup F.assign c2312 [c2, c1110]
  · exact sat_cons (p2 F) ( sat_cons (p1110 F) (rfl))
  · decide +kernel
def c2313 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (18,false), (30,false), (32,false), (98,false), (99,false)]
theorem p2313 (F : Frame G 3) : c2313.eval F.assign = true := by
  apply local_rup F.assign c2313 [c4, c5, c1111]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1111 F) (rfl)))
  · decide +kernel
def c2314 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (74,false), (21,false), (32,false), (99,false)]
theorem p2314 (F : Frame G 3) : c2314.eval F.assign = true := by
  apply local_rup F.assign c2314 [c4, c5, c6, c1112]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1112 F) (rfl))))
  · decide +kernel
def c2315 : CNF.Clause Nat := [(21,false), (98,false), (86,false), (74,false), (11,false), (33,false), (27,false), (38,false), (39,false)]
theorem p2315 (F : Frame G 3) : c2315.eval F.assign = true := by
  apply local_rup F.assign c2315 [c4, c1113]
  · exact sat_cons (p4 F) ( sat_cons (p1113 F) (rfl))
  · decide +kernel
def c2316 : CNF.Clause Nat := [(74,false), (38,false), (39,false), (32,false), (98,false), (99,false)]
theorem p2316 (F : Frame G 3) : c2316.eval F.assign = true := by
  apply local_rup F.assign c2316 [c4, c5, c2, c3, c1114]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1114 F) (rfl)))))
  · decide +kernel
def c2317 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (76,false), (32,false), (30,false), (86,false), (99,false)]
theorem p2317 (F : Frame G 3) : c2317.eval F.assign = true := by
  apply local_rup F.assign c2317 [c2, c4, c1115]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1115 F) (rfl)))
  · decide +kernel
def c2318 : CNF.Clause Nat := [(86,false), (99,false), (11,false), (38,false), (50,false), (29,false), (76,false)]
theorem p2318 (F : Frame G 3) : c2318.eval F.assign = true := by
  apply local_rup F.assign c2318 [c5, c1, c3, c1116]
  · exact sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p1116 F) (rfl))))
  · decide +kernel
def c2319 : CNF.Clause Nat := [(39,false), (38,false), (30,false), (29,false), (10,false), (98,false), (99,false)]
theorem p2319 (F : Frame G 3) : c2319.eval F.assign = true := by
  apply local_rup F.assign c2319 [c2, c5, c4, c1117]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1117 F) (rfl))))
  · decide +kernel
def c2320 : CNF.Clause Nat := [(5,false), (39,false), (17,false), (30,false), (33,false), (99,false), (75,false), (76,false)]
theorem p2320 (F : Frame G 3) : c2320.eval F.assign = true := by
  apply local_rup F.assign c2320 [c1, c5, c1118]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p1118 F) (rfl)))
  · decide +kernel
def c2321 : CNF.Clause Nat := [(11,false), (22,false), (38,false), (39,false), (30,false), (86,false), (75,false), (76,false)]
theorem p2321 (F : Frame G 3) : c2321.eval F.assign = true := by
  apply local_rup F.assign c2321 [c2, c3, c1119]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1119 F) (rfl)))
  · decide +kernel
def c2322 : CNF.Clause Nat := [(11,false), (33,false), (27,false), (38,false), (39,false), (17,false), (86,false), (75,false), (76,false)]
theorem p2322 (F : Frame G 3) : c2322.eval F.assign = true := by
  apply local_rup F.assign c2322 [c5, c1120]
  · exact sat_cons (p5 F) ( sat_cons (p1120 F) (rfl))
  · decide +kernel
def c2323 : CNF.Clause Nat := [(6,false), (50,false), (74,false), (76,false), (98,false), (33,false)]
theorem p2323 (F : Frame G 3) : c2323.eval F.assign = true := by
  apply local_rup F.assign c2323 [c1, c2, c5, c6, c1121]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1121 F) (rfl)))))
  · decide +kernel
def c2324 : CNF.Clause Nat := [(6,false), (50,false), (86,false), (98,false), (32,false), (29,false), (77,false)]
theorem p2324 (F : Frame G 3) : c2324.eval F.assign = true := by
  apply local_rup F.assign c2324 [c1, c2, c5, c1122]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1122 F) (rfl))))
  · decide +kernel
def c2325 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (18,false), (86,false), (98,false), (32,false), (33,false)]
theorem p2325 (F : Frame G 3) : c2325.eval F.assign = true := by
  apply local_rup F.assign c2325 [c4, c5, c1123]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1123 F) (rfl)))
  · decide +kernel
def c2326 : CNF.Clause Nat := [(50,false), (38,false), (77,false), (22,false), (86,false), (98,false)]
theorem p2326 (F : Frame G 3) : c2326.eval F.assign = true := by
  apply local_rup F.assign c2326 [c3, c1, c4, c5, c1124]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1124 F) (rfl)))))
  · decide +kernel
def c2327 : CNF.Clause Nat := [(6,false), (39,false), (38,false), (30,false), (98,false), (76,false), (77,false)]
theorem p2327 (F : Frame G 3) : c2327.eval F.assign = true := by
  apply local_rup F.assign c2327 [c2, c5, c6, c1125]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1125 F) (rfl))))
  · decide +kernel
def c2328 : CNF.Clause Nat := [(10,false), (76,false), (77,false), (33,false), (86,false), (15,false), (38,false), (50,false)]
theorem p2328 (F : Frame G 3) : c2328.eval F.assign = true := by
  apply local_rup F.assign c2328 [c6, c5, c1126]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1126 F) (rfl)))
  · decide +kernel
def c2329 : CNF.Clause Nat := [(15,false), (50,false), (6,false), (77,false), (33,false), (30,false), (86,false), (98,false)]
theorem p2329 (F : Frame G 3) : c2329.eval F.assign = true := by
  apply local_rup F.assign c2329 [c2, c4, c1127]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1127 F) (rfl)))
  · decide +kernel
def c2330 : CNF.Clause Nat := [(15,false), (50,false), (32,false), (98,false), (9,false), (77,false), (88,false)]
theorem p2330 (F : Frame G 3) : c2330.eval F.assign = true := by
  apply local_rup F.assign c2330 [c2, c3, c4, c1128]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1128 F) (rfl))))
  · decide +kernel
def c2331 : CNF.Clause Nat := [(39,false), (50,false), (18,false), (10,false), (32,false), (30,false), (88,false), (99,false)]
theorem p2331 (F : Frame G 3) : c2331.eval F.assign = true := by
  apply local_rup F.assign c2331 [c2, c4, c1129]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1129 F) (rfl)))
  · decide +kernel
def c2332 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (32,false), (98,false), (75,false), (8,false), (22,false)]
theorem p2332 (F : Frame G 3) : c2332.eval F.assign = true := by
  apply local_rup F.assign c2332 [c4, c5, c1130]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1130 F) (rfl)))
  · decide +kernel
def c2333 : CNF.Clause Nat := [(50,false), (39,false), (26,false), (32,false), (98,false), (75,false), (8,false), (88,false)]
theorem p2333 (F : Frame G 3) : c2333.eval F.assign = true := by
  apply local_rup F.assign c2333 [c2, c4, c1131]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1131 F) (rfl)))
  · decide +kernel
def c2334 : CNF.Clause Nat := [(15,false), (50,false), (32,false), (98,false), (75,false), (8,false), (88,false)]
theorem p2334 (F : Frame G 3) : c2334.eval F.assign = true := by
  apply local_rup F.assign c2334 [c2, c3, c4, c1132]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1132 F) (rfl))))
  · decide +kernel
def c2335 : CNF.Clause Nat := [(50,false), (39,false), (29,false), (30,false), (87,false), (98,false), (99,false)]
theorem p2335 (F : Frame G 3) : c2335.eval F.assign = true := by
  apply local_rup F.assign c2335 [c2, c1, c4, c1133]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p1133 F) (rfl))))
  · decide +kernel
def c2336 : CNF.Clause Nat := [(39,false), (5,false), (21,false), (87,false), (88,false), (33,false), (29,false), (75,false)]
theorem p2336 (F : Frame G 3) : c2336.eval F.assign = true := by
  apply local_rup F.assign c2336 [c1, c2, c1134]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p1134 F) (rfl)))
  · decide +kernel
def c2337 : CNF.Clause Nat := [(5,false), (50,false), (17,false), (88,false), (77,false), (29,false), (98,false)]
theorem p2337 (F : Frame G 3) : c2337.eval F.assign = true := by
  apply local_rup F.assign c2337 [c1, c5, c6, c1135]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1135 F) (rfl))))
  · decide +kernel
def c2338 : CNF.Clause Nat := [(39,false), (50,false), (8,false), (77,false), (99,false), (32,false)]
theorem p2338 (F : Frame G 3) : c2338.eval F.assign = true := by
  apply local_rup F.assign c2338 [c2, c5, c4, c6, c1136]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1136 F) (rfl)))))
  · decide +kernel
def c2339 : CNF.Clause Nat := [(39,false), (38,false), (30,false), (99,false), (11,false), (76,false)]
theorem p2339 (F : Frame G 3) : c2339.eval F.assign = true := by
  apply local_rup F.assign c2339 [c2, c5, c6, c4, c1137]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1137 F) (rfl)))))
  · decide +kernel
def c2340 : CNF.Clause Nat := [(76,false), (32,false), (39,false), (38,false), (88,false), (99,false)]
theorem p2340 (F : Frame G 3) : c2340.eval F.assign = true := by
  apply local_rup F.assign c2340 [c4, c3, c2, c5, c1138]
  · exact sat_cons (p4 F) ( sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1138 F) (rfl)))))
  · decide +kernel
def c2341 : CNF.Clause Nat := [(26,false), (50,false), (5,false), (10,false), (76,false), (18,false), (88,false), (99,false)]
theorem p2341 (F : Frame G 3) : c2341.eval F.assign = true := by
  apply local_rup F.assign c2341 [c3, c5, c1140]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p1140 F) (rfl)))
  · decide +kernel
def c2342 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (76,false), (21,false), (30,false), (99,false)]
theorem p2342 (F : Frame G 3) : c2342.eval F.assign = true := by
  apply local_rup F.assign c2342 [c4, c5, c6, c1141]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1141 F) (rfl))))
  · decide +kernel
def c2343 : CNF.Clause Nat := [(10,false), (76,false), (77,false), (88,false), (20,false), (27,false), (50,false)]
theorem p2343 (F : Frame G 3) : c2343.eval F.assign = true := by
  apply local_rup F.assign c2343 [c1, c5, c6, c1142]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1142 F) (rfl))))
  · decide +kernel
def c2344 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (99,false), (88,false), (18,false), (76,false)]
theorem p2344 (F : Frame G 3) : c2344.eval F.assign = true := by
  apply local_rup F.assign c2344 [c1, c6, c5, c1143]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1143 F) (rfl))))
  · decide +kernel
def c2345 : CNF.Clause Nat := [(50,false), (39,false), (26,false), (75,false), (76,false), (10,false), (8,false), (88,false)]
theorem p2345 (F : Frame G 3) : c2345.eval F.assign = true := by
  apply local_rup F.assign c2345 [c2, c6, c1144]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p1144 F) (rfl)))
  · decide +kernel
def c2346 : CNF.Clause Nat := [(50,false), (39,false), (10,false), (32,false), (30,false), (88,false), (77,false), (75,false)]
theorem p2346 (F : Frame G 3) : c2346.eval F.assign = true := by
  apply local_rup F.assign c2346 [c2, c1, c1145]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p1145 F) (rfl)))
  · decide +kernel
def c2347 : CNF.Clause Nat := [(39,false), (50,false), (18,false), (11,false), (99,false), (86,false), (30,false), (32,false)]
theorem p2347 (F : Frame G 3) : c2347.eval F.assign = true := by
  apply local_rup F.assign c2347 [c2, c4, c1146]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1146 F) (rfl)))
  · decide +kernel
def c2348 : CNF.Clause Nat := [(39,false), (50,false), (30,false), (33,false), (99,false), (75,false), (76,false)]
theorem p2348 (F : Frame G 3) : c2348.eval F.assign = true := by
  apply local_rup F.assign c2348 [c1, c2, c5, c1147]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1147 F) (rfl))))
  · decide +kernel
def c2349 : CNF.Clause Nat := [(15,false), (50,false), (33,false), (11,false), (8,false), (86,false), (75,false), (76,false)]
theorem p2349 (F : Frame G 3) : c2349.eval F.assign = true := by
  apply local_rup F.assign c2349 [c2, c3, c1148]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1148 F) (rfl)))
  · decide +kernel
def c2350 : CNF.Clause Nat := [(39,false), (50,false), (8,false), (76,false), (32,false), (99,false)]
theorem p2350 (F : Frame G 3) : c2350.eval F.assign = true := by
  apply local_rup F.assign c2350 [c2, c5, c4, c6, c1149]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1149 F) (rfl)))))
  · decide +kernel
def c2351 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (18,false), (30,false), (32,false), (98,false), (99,false)]
theorem p2351 (F : Frame G 3) : c2351.eval F.assign = true := by
  apply local_rup F.assign c2351 [c4, c5, c1150]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1150 F) (rfl)))
  · decide +kernel
def c2352 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (30,false), (22,false), (99,false), (75,false), (76,false)]
theorem p2352 (F : Frame G 3) : c2352.eval F.assign = true := by
  apply local_rup F.assign c2352 [c1, c5, c1151]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p1151 F) (rfl)))
  · decide +kernel
def c2353 : CNF.Clause Nat := [(76,false), (98,false), (99,false), (22,false), (30,false), (27,false), (50,false)]
theorem p2353 (F : Frame G 3) : c2353.eval F.assign = true := by
  apply local_rup F.assign c2353 [c1, c4, c5, c1152]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1152 F) (rfl))))
  · decide +kernel
def c2354 : CNF.Clause Nat := [(39,false), (50,false), (30,false), (29,false), (10,false), (98,false), (99,false)]
theorem p2354 (F : Frame G 3) : c2354.eval F.assign = true := by
  apply local_rup F.assign c2354 [c2, c5, c4, c1153]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1153 F) (rfl))))
  · decide +kernel
def c2355 : CNF.Clause Nat := [(39,false), (50,false), (86,false), (99,false), (33,false), (29,false), (76,false)]
theorem p2355 (F : Frame G 3) : c2355.eval F.assign = true := by
  apply local_rup F.assign c2355 [c1, c2, c5, c1154]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1154 F) (rfl))))
  · decide +kernel
def c2356 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (29,false), (30,false), (21,false), (98,false), (99,false)]
theorem p2356 (F : Frame G 3) : c2356.eval F.assign = true := by
  apply local_rup F.assign c2356 [c4, c5, c1155]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1155 F) (rfl)))
  · decide +kernel
def c2357 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (29,false), (32,false), (21,false), (86,false), (99,false)]
theorem p2357 (F : Frame G 3) : c2357.eval F.assign = true := by
  apply local_rup F.assign c2357 [c4, c5, c1156]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1156 F) (rfl)))
  · decide +kernel
def c2358 : CNF.Clause Nat := [(39,false), (50,false), (8,false), (10,false), (98,false), (75,false), (29,false), (33,false)]
theorem p2358 (F : Frame G 3) : c2358.eval F.assign = true := by
  apply local_rup F.assign c2358 [c2, c5, c1157]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1157 F) (rfl)))
  · decide +kernel
def c2359 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (18,false), (87,false), (32,false), (99,false)]
theorem p2359 (F : Frame G 3) : c2359.eval F.assign = true := by
  apply local_rup F.assign c2359 [c4, c5, c6, c1158]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1158 F) (rfl))))
  · decide +kernel
def c2360 : CNF.Clause Nat := [(50,false), (39,false), (29,false), (33,false), (99,false), (86,false), (87,false)]
theorem p2360 (F : Frame G 3) : c2360.eval F.assign = true := by
  apply local_rup F.assign c2360 [c2, c1, c4, c1159]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p1159 F) (rfl))))
  · decide +kernel
def c2361 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (29,false), (11,false), (22,false), (86,false), (98,false)]
theorem p2361 (F : Frame G 3) : c2361.eval F.assign = true := by
  apply local_rup F.assign c2361 [c4, c5, c1160]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1160 F) (rfl)))
  · decide +kernel
def c2362 : CNF.Clause Nat := [(5,false), (50,false), (17,false), (18,false), (75,false), (98,false), (87,false), (30,false), (33,false)]
theorem p2362 (F : Frame G 3) : c2362.eval F.assign = true := by
  apply local_rup F.assign c2362 [c1, c1161]
  · exact sat_cons (p1 F) ( sat_cons (p1161 F) (rfl))
  · decide +kernel
def c2363 : CNF.Clause Nat := [(39,false), (38,false), (8,false), (10,false), (98,false), (75,false), (77,false)]
theorem p2363 (F : Frame G 3) : c2363.eval F.assign = true := by
  apply local_rup F.assign c2363 [c3, c2, c5, c1162]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1162 F) (rfl))))
  · decide +kernel
def c2364 : CNF.Clause Nat := [(38,false), (39,false), (98,false), (10,false), (8,false), (18,false), (77,false)]
theorem p2364 (F : Frame G 3) : c2364.eval F.assign = true := by
  apply local_rup F.assign c2364 [c3, c6, c5, c1163]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1163 F) (rfl))))
  · decide +kernel
def c2365 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (10,false), (21,false), (18,false), (74,false), (86,false), (33,false)]
theorem p2365 (F : Frame G 3) : c2365.eval F.assign = true := by
  apply local_rup F.assign c2365 [c6, c1164]
  · exact sat_cons (p6 F) ( sat_cons (p1164 F) (rfl))
  · decide +kernel
def c2366 : CNF.Clause Nat := [(10,false), (98,false), (99,false), (33,false), (29,false), (74,false), (50,false)]
theorem p2366 (F : Frame G 3) : c2366.eval F.assign = true := by
  apply local_rup F.assign c2366 [c1, c5, c2, c1165]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p1165 F) (rfl))))
  · decide +kernel
def c2367 : CNF.Clause Nat := [(74,false), (50,false), (32,false), (98,false), (99,false)]
theorem p2367 (F : Frame G 3) : c2367.eval F.assign = true := by
  apply local_rup F.assign c2367 [c1, c4, c5, c2, c3, c1166]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1166 F) (rfl))))))
  · decide +kernel
def c2368 : CNF.Clause Nat := [(39,false), (50,false), (21,false), (10,false), (74,false), (30,false), (99,false)]
theorem p2368 (F : Frame G 3) : c2368.eval F.assign = true := by
  apply local_rup F.assign c2368 [c2, c4, c6, c1167]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1167 F) (rfl))))
  · decide +kernel
def c2369 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (33,false), (99,false), (98,false), (10,false), (18,false)]
theorem p2369 (F : Frame G 3) : c2369.eval F.assign = true := by
  apply local_rup F.assign c2369 [c4, c5, c1168]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1168 F) (rfl)))
  · decide +kernel
def c2370 : CNF.Clause Nat := [(15,false), (50,false), (33,false), (11,false), (10,false), (98,false), (75,false), (74,false)]
theorem p2370 (F : Frame G 3) : c2370.eval F.assign = true := by
  apply local_rup F.assign c2370 [c2, c3, c1169]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1169 F) (rfl)))
  · decide +kernel
def c2371 : CNF.Clause Nat := [(50,false), (39,false), (26,false), (33,false), (11,false), (10,false), (98,false), (75,false), (74,false)]
theorem p2371 (F : Frame G 3) : c2371.eval F.assign = true := by
  apply local_rup F.assign c2371 [c2, c1170]
  · exact sat_cons (p2 F) ( sat_cons (p1170 F) (rfl))
  · decide +kernel
def c2372 : CNF.Clause Nat := [(38,false), (39,false), (29,false), (76,false), (10,false), (8,false), (86,false), (99,false)]
theorem p2372 (F : Frame G 3) : c2372.eval F.assign = true := by
  apply local_rup F.assign c2372 [c2, c3, c1171]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1171 F) (rfl)))
  · decide +kernel
def c2373 : CNF.Clause Nat := [(15,false), (39,false), (33,false), (99,false), (86,false), (8,false), (76,false)]
theorem p2373 (F : Frame G 3) : c2373.eval F.assign = true := by
  apply local_rup F.assign c2373 [c2, c3, c4, c1172]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1172 F) (rfl))))
  · decide +kernel
def c2374 : CNF.Clause Nat := [(38,false), (39,false), (33,false), (99,false), (86,false), (8,false), (76,false)]
theorem p2374 (F : Frame G 3) : c2374.eval F.assign = true := by
  apply local_rup F.assign c2374 [c2, c3, c4, c1173]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1173 F) (rfl))))
  · decide +kernel
def c2375 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (29,false), (32,false), (21,false), (86,false), (99,false)]
theorem p2375 (F : Frame G 3) : c2375.eval F.assign = true := by
  apply local_rup F.assign c2375 [c4, c5, c1174]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1174 F) (rfl)))
  · decide +kernel
def c2376 : CNF.Clause Nat := [(27,false), (39,false), (8,false), (22,false), (99,false), (75,false), (76,false)]
theorem p2376 (F : Frame G 3) : c2376.eval F.assign = true := by
  apply local_rup F.assign c2376 [c3, c1, c5, c1175]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p1175 F) (rfl))))
  · decide +kernel
def c2377 : CNF.Clause Nat := [(50,false), (38,false), (74,false), (21,false), (98,false), (99,false)]
theorem p2377 (F : Frame G 3) : c2377.eval F.assign = true := by
  apply local_rup F.assign c2377 [c3, c1, c4, c5, c1177]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1177 F) (rfl)))))
  · decide +kernel
def c2378 : CNF.Clause Nat := [(39,false), (50,false), (18,false), (10,false), (87,false), (30,false), (99,false)]
theorem p2378 (F : Frame G 3) : c2378.eval F.assign = true := by
  apply local_rup F.assign c2378 [c2, c4, c6, c1178]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1178 F) (rfl))))
  · decide +kernel
def c2379 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (29,false), (8,false), (21,false), (98,false), (99,false)]
theorem p2379 (F : Frame G 3) : c2379.eval F.assign = true := by
  apply local_rup F.assign c2379 [c4, c5, c1179]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1179 F) (rfl)))
  · decide +kernel
def c2380 : CNF.Clause Nat := [(39,false), (50,false), (87,false), (76,false), (29,false), (9,false), (11,false)]
theorem p2380 (F : Frame G 3) : c2380.eval F.assign = true := by
  apply local_rup F.assign c2380 [c2, c5, c6, c1180]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1180 F) (rfl))))
  · decide +kernel
def c2381 : CNF.Clause Nat := [(39,false), (50,false), (8,false), (76,false), (98,false), (33,false)]
theorem p2381 (F : Frame G 3) : c2381.eval F.assign = true := by
  apply local_rup F.assign c2381 [c2, c5, c4, c6, c1181]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1181 F) (rfl)))))
  · decide +kernel
def c2382 : CNF.Clause Nat := [(27,false), (50,false), (39,false), (75,false), (99,false), (22,false), (87,false)]
theorem p2382 (F : Frame G 3) : c2382.eval F.assign = true := by
  apply local_rup F.assign c2382 [c1, c4, c5, c1182]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1182 F) (rfl))))
  · decide +kernel
def c2383 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (74,false), (21,false), (98,false), (33,false)]
theorem p2383 (F : Frame G 3) : c2383.eval F.assign = true := by
  apply local_rup F.assign c2383 [c4, c5, c6, c1183]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1183 F) (rfl))))
  · decide +kernel
def c2384 : CNF.Clause Nat := [(39,false), (38,false), (74,false), (76,false), (32,false), (9,false), (11,false)]
theorem p2384 (F : Frame G 3) : c2384.eval F.assign = true := by
  apply local_rup F.assign c2384 [c2, c5, c6, c1184]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1184 F) (rfl))))
  · decide +kernel
def c2385 : CNF.Clause Nat := [(50,false), (39,false), (26,false), (33,false), (99,false), (75,false), (8,false), (87,false)]
theorem p2385 (F : Frame G 3) : c2385.eval F.assign = true := by
  apply local_rup F.assign c2385 [c2, c4, c1185]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1185 F) (rfl)))
  · decide +kernel
def c2386 : CNF.Clause Nat := [(39,false), (50,false), (74,false), (76,false), (32,false), (99,false)]
theorem p2386 (F : Frame G 3) : c2386.eval F.assign = true := by
  apply local_rup F.assign c2386 [c1, c2, c5, c6, c1186]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1186 F) (rfl)))))
  · decide +kernel
def c2387 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (18,false), (8,false), (86,false), (98,false), (32,false), (33,false)]
theorem p2387 (F : Frame G 3) : c2387.eval F.assign = true := by
  apply local_rup F.assign c2387 [c4, c1187]
  · exact sat_cons (p4 F) ( sat_cons (p1187 F) (rfl))
  · decide +kernel
def c2388 : CNF.Clause Nat := [(50,false), (38,false), (15,false), (18,false), (76,false), (10,false), (8,false), (86,false), (99,false)]
theorem p2388 (F : Frame G 3) : c2388.eval F.assign = true := by
  apply local_rup F.assign c2388 [c3, c1188]
  · exact sat_cons (p3 F) ( sat_cons (p1188 F) (rfl))
  · decide +kernel
def c2389 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (11,false), (33,false), (30,false), (18,false), (75,false), (98,false)]
theorem p2389 (F : Frame G 3) : c2389.eval F.assign = true := by
  apply local_rup F.assign c2389 [c5, c1189]
  · exact sat_cons (p5 F) ( sat_cons (p1189 F) (rfl))
  · decide +kernel
def c2390 : CNF.Clause Nat := [(39,false), (50,false), (30,false), (32,false), (76,false), (75,false), (99,false)]
theorem p2390 (F : Frame G 3) : c2390.eval F.assign = true := by
  apply local_rup F.assign c2390 [c1, c2, c5, c1190]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1190 F) (rfl))))
  · decide +kernel
def c2391 : CNF.Clause Nat := [(38,false), (17,false), (30,false), (74,false), (76,false), (98,false), (99,false)]
theorem p2391 (F : Frame G 3) : c2391.eval F.assign = true := by
  apply local_rup F.assign c2391 [c1, c2, c3, c1191]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1191 F) (rfl))))
  · decide +kernel
def c2392 : CNF.Clause Nat := [(10,false), (76,false), (77,false), (99,false), (86,false), (27,false), (26,false), (39,false)]
theorem p2392 (F : Frame G 3) : c2392.eval F.assign = true := by
  apply local_rup F.assign c2392 [c5, c2, c1192]
  · exact sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p1192 F) (rfl)))
  · decide +kernel
def c2393 : CNF.Clause Nat := [(39,false), (5,false), (86,false), (98,false), (76,false), (77,false)]
theorem p2393 (F : Frame G 3) : c2393.eval F.assign = true := by
  apply local_rup F.assign c2393 [c3, c1, c2, c5, c1193]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1193 F) (rfl)))))
  · decide +kernel
def c2394 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (18,false), (11,false), (99,false), (30,false), (87,false)]
theorem p2394 (F : Frame G 3) : c2394.eval F.assign = true := by
  apply local_rup F.assign c2394 [c4, c6, c1194]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1194 F) (rfl)))
  · decide +kernel
def c2395 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (18,false), (21,false), (87,false), (30,false), (99,false)]
theorem p2395 (F : Frame G 3) : c2395.eval F.assign = true := by
  apply local_rup F.assign c2395 [c4, c6, c1195]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1195 F) (rfl)))
  · decide +kernel
def c2396 : CNF.Clause Nat := [(50,false), (38,false), (75,false), (99,false), (22,false), (87,false)]
theorem p2396 (F : Frame G 3) : c2396.eval F.assign = true := by
  apply local_rup F.assign c2396 [c3, c1, c4, c5, c1196]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1196 F) (rfl)))))
  · decide +kernel
def c2397 : CNF.Clause Nat := [(38,false), (50,false), (99,false), (22,false), (8,false), (76,false)]
theorem p2397 (F : Frame G 3) : c2397.eval F.assign = true := by
  apply local_rup F.assign c2397 [c3, c6, c5, c4, c1197]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1197 F) (rfl)))))
  · decide +kernel
def c2398 : CNF.Clause Nat := [(5,false), (17,false), (32,false), (87,false), (74,false), (75,false), (99,false)]
theorem p2398 (F : Frame G 3) : c2398.eval F.assign = true := by
  apply local_rup F.assign c2398 [c1, c2, c3, c1198]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1198 F) (rfl))))
  · decide +kernel
def c2399 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (74,false), (77,false), (99,false), (32,false)]
theorem p2399 (F : Frame G 3) : c2399.eval F.assign = true := by
  apply local_rup F.assign c2399 [c1, c5, c6, c1199]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1199 F) (rfl))))
  · decide +kernel
def c2400 : CNF.Clause Nat := [(15,false), (50,false), (86,false), (87,false), (10,false), (77,false)]
theorem p2400 (F : Frame G 3) : c2400.eval F.assign = true := by
  apply local_rup F.assign c2400 [c2, c3, c6, c4, c1200]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1200 F) (rfl)))))
  · decide +kernel
end Cert35Steps
end Graffiti199Depleted.Catalogue.OrderEleven
