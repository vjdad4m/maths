import Local35Part7
namespace Graffiti199Depleted.Catalogue.OrderEleven
namespace Cert35Steps
open Std.Sat
set_option maxRecDepth 4096
set_option maxHeartbeats 0
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj]
def c2401 : CNF.Clause Nat := [(6,false), (50,false), (18,false), (77,false), (99,false), (30,false), (87,false)]
theorem p2401 (F : Frame G 3) : c2401.eval F.assign = true := by
  apply local_rup F.assign c2401 [c1, c2, c6, c1201]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p1201 F) (rfl))))
  · decide +kernel
def c2402 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (18,false), (87,false), (32,false), (99,false)]
theorem p2402 (F : Frame G 3) : c2402.eval F.assign = true := by
  apply local_rup F.assign c2402 [c4, c5, c6, c1202]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1202 F) (rfl))))
  · decide +kernel
def c2403 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (30,false), (99,false), (77,false), (10,false)]
theorem p2403 (F : Frame G 3) : c2403.eval F.assign = true := by
  apply local_rup F.assign c2403 [c5, c6, c4, c1203]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1203 F) (rfl))))
  · decide +kernel
def c2404 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (8,false), (10,false), (76,false), (75,false), (33,false)]
theorem p2404 (F : Frame G 3) : c2404.eval F.assign = true := by
  apply local_rup F.assign c2404 [c5, c6, c1204]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1204 F) (rfl)))
  · decide +kernel
def c2405 : CNF.Clause Nat := [(74,false), (76,false), (10,false), (38,false), (50,false), (99,false)]
theorem p2405 (F : Frame G 3) : c2405.eval F.assign = true := by
  apply local_rup F.assign c2405 [c5, c1, c3, c6, c1205]
  · exact sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p1205 F) (rfl)))))
  · decide +kernel
def c2406 : CNF.Clause Nat := [(5,false), (50,false), (30,false), (86,false), (99,false), (22,false), (18,false), (76,false)]
theorem p2406 (F : Frame G 3) : c2406.eval F.assign = true := by
  apply local_rup F.assign c2406 [c1, c3, c1206]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p1206 F) (rfl)))
  · decide +kernel
def c2407 : CNF.Clause Nat := [(5,false), (50,false), (17,false), (74,false), (76,false), (32,false), (99,false)]
theorem p2407 (F : Frame G 3) : c2407.eval F.assign = true := by
  apply local_rup F.assign c2407 [c1, c5, c6, c1207]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1207 F) (rfl))))
  · decide +kernel
def c2408 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (74,false), (76,false), (32,false), (99,false)]
theorem p2408 (F : Frame G 3) : c2408.eval F.assign = true := by
  apply local_rup F.assign c2408 [c1, c5, c6, c1208]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1208 F) (rfl))))
  · decide +kernel
def c2409 : CNF.Clause Nat := [(30,false), (26,false), (38,false), (50,false), (6,false), (11,false), (99,false), (75,false), (76,false)]
theorem p2409 (F : Frame G 3) : c2409.eval F.assign = true := by
  apply local_rup F.assign c2409 [c5, c1209]
  · exact sat_cons (p5 F) ( sat_cons (p1209 F) (rfl))
  · decide +kernel
def c2410 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (18,false), (10,false), (87,false), (86,false), (33,false)]
theorem p2410 (F : Frame G 3) : c2410.eval F.assign = true := by
  apply local_rup F.assign c2410 [c4, c6, c1210]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1210 F) (rfl)))
  · decide +kernel
def c2411 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (30,false), (29,false), (10,false), (98,false), (99,false)]
theorem p2411 (F : Frame G 3) : c2411.eval F.assign = true := by
  apply local_rup F.assign c2411 [c5, c4, c1211]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1211 F) (rfl)))
  · decide +kernel
def c2412 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (29,false), (30,false), (21,false), (98,false), (99,false)]
theorem p2412 (F : Frame G 3) : c2412.eval F.assign = true := by
  apply local_rup F.assign c2412 [c4, c5, c1212]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1212 F) (rfl)))
  · decide +kernel
def c2413 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (8,false), (29,false), (32,false), (98,false), (99,false)]
theorem p2413 (F : Frame G 3) : c2413.eval F.assign = true := by
  apply local_rup F.assign c2413 [c5, c4, c1213]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1213 F) (rfl)))
  · decide +kernel
def c2414 : CNF.Clause Nat := [(75,false), (99,false), (33,false), (32,false), (87,false), (50,false)]
theorem p2414 (F : Frame G 3) : c2414.eval F.assign = true := by
  apply local_rup F.assign c2414 [c1, c4, c5, c2, c1214]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p1214 F) (rfl)))))
  · decide +kernel
def c2415 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (8,false), (10,false), (98,false), (75,false), (29,false), (33,false)]
theorem p2415 (F : Frame G 3) : c2415.eval F.assign = true := by
  apply local_rup F.assign c2415 [c5, c1215]
  · exact sat_cons (p5 F) ( sat_cons (p1215 F) (rfl))
  · decide +kernel
def c2416 : CNF.Clause Nat := [(5,false), (50,false), (17,false), (30,false), (32,false), (98,false), (75,false), (77,false)]
theorem p2416 (F : Frame G 3) : c2416.eval F.assign = true := by
  apply local_rup F.assign c2416 [c1, c5, c1216]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p1216 F) (rfl)))
  · decide +kernel
def c2417 : CNF.Clause Nat := [(21,false), (87,false), (86,false), (99,false), (77,false), (26,false), (27,false), (50,false)]
theorem p2417 (F : Frame G 3) : c2417.eval F.assign = true := by
  apply local_rup F.assign c2417 [c4, c1, c1217]
  · exact sat_cons (p4 F) ( sat_cons (p1 F) ( sat_cons (p1217 F) (rfl)))
  · decide +kernel
def c2418 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (21,false), (87,false), (86,false), (29,false), (77,false)]
theorem p2418 (F : Frame G 3) : c2418.eval F.assign = true := by
  apply local_rup F.assign c2418 [c1, c6, c1218]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p1218 F) (rfl)))
  · decide +kernel
def c2419 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (18,false), (77,false), (99,false), (32,false), (87,false)]
theorem p2419 (F : Frame G 3) : c2419.eval F.assign = true := by
  apply local_rup F.assign c2419 [c1, c6, c1219]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p1219 F) (rfl)))
  · decide +kernel
def c2420 : CNF.Clause Nat := [(17,false), (50,false), (38,false), (26,false), (86,false), (87,false), (10,false), (77,false)]
theorem p2420 (F : Frame G 3) : c2420.eval F.assign = true := by
  apply local_rup F.assign c2420 [c6, c4, c1220]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1220 F) (rfl)))
  · decide +kernel
def c2421 : CNF.Clause Nat := [(26,false), (50,false), (5,false), (18,false), (86,false), (98,false), (110,false)]
theorem p2421 (F : Frame G 3) : c2421.eval F.assign = true := by
  apply local_rup F.assign c2421 [c3, c4, c5, c1221]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1221 F) (rfl))))
  · decide +kernel
def c2422 : CNF.Clause Nat := [(50,false), (38,false), (18,false), (86,false), (98,false), (110,false)]
theorem p2422 (F : Frame G 3) : c2422.eval F.assign = true := by
  apply local_rup F.assign c2422 [c3, c1, c4, c5, c1222]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1222 F) (rfl)))))
  · decide +kernel
def c2423 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (18,false), (86,false), (32,false), (110,false)]
theorem p2423 (F : Frame G 3) : c2423.eval F.assign = true := by
  apply local_rup F.assign c2423 [c4, c5, c6, c1223]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1223 F) (rfl))))
  · decide +kernel
def c2424 : CNF.Clause Nat := [(8,false), (38,false), (50,false), (32,false), (98,false), (75,false), (77,false)]
theorem p2424 (F : Frame G 3) : c2424.eval F.assign = true := by
  apply local_rup F.assign c2424 [c5, c1, c3, c1224]
  · exact sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p1224 F) (rfl))))
  · decide +kernel
def c2425 : CNF.Clause Nat := [(75,false), (86,false), (38,false), (39,false), (32,false), (110,false)]
theorem p2425 (F : Frame G 3) : c2425.eval F.assign = true := by
  apply local_rup F.assign c2425 [c4, c5, c2, c3, c1225]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1225 F) (rfl)))))
  · decide +kernel
def c2426 : CNF.Clause Nat := [(38,false), (50,false), (30,false), (21,false), (110,false), (77,false), (75,false)]
theorem p2426 (F : Frame G 3) : c2426.eval F.assign = true := by
  apply local_rup F.assign c2426 [c1, c3, c5, c1226]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p1226 F) (rfl))))
  · decide +kernel
def c2427 : CNF.Clause Nat := [(15,false), (38,false), (50,false), (6,false), (77,false), (110,false), (32,false), (30,false), (86,false)]
theorem p2427 (F : Frame G 3) : c2427.eval F.assign = true := by
  apply local_rup F.assign c2427 [c4, c1227]
  · exact sat_cons (p4 F) ( sat_cons (p1227 F) (rfl))
  · decide +kernel
def c2428 : CNF.Clause Nat := [(86,false), (75,false), (38,false), (50,false), (32,false), (110,false)]
theorem p2428 (F : Frame G 3) : c2428.eval F.assign = true := by
  apply local_rup F.assign c2428 [c5, c4, c1, c3, c1228]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p1228 F) (rfl)))))
  · decide +kernel
def c2429 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (18,false), (86,false), (32,false), (110,false)]
theorem p2429 (F : Frame G 3) : c2429.eval F.assign = true := by
  apply local_rup F.assign c2429 [c4, c5, c6, c1229]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1229 F) (rfl))))
  · decide +kernel
def c2430 : CNF.Clause Nat := [(77,false), (110,false), (32,false), (39,false), (38,false), (86,false)]
theorem p2430 (F : Frame G 3) : c2430.eval F.assign = true := by
  apply local_rup F.assign c2430 [c4, c3, c2, c5, c1230]
  · exact sat_cons (p4 F) ( sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1230 F) (rfl)))))
  · decide +kernel
def c2431 : CNF.Clause Nat := [(26,false), (50,false), (5,false), (77,false), (110,false), (21,false), (86,false)]
theorem p2431 (F : Frame G 3) : c2431.eval F.assign = true := by
  apply local_rup F.assign c2431 [c3, c4, c5, c1231]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1231 F) (rfl))))
  · decide +kernel
def c2432 : CNF.Clause Nat := [(50,false), (38,false), (77,false), (110,false), (21,false), (86,false)]
theorem p2432 (F : Frame G 3) : c2432.eval F.assign = true := by
  apply local_rup F.assign c2432 [c3, c1, c4, c5, c1232]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1232 F) (rfl)))))
  · decide +kernel
def c2433 : CNF.Clause Nat := [(75,false), (86,false), (30,false), (39,false), (38,false), (21,false), (110,false)]
theorem p2433 (F : Frame G 3) : c2433.eval F.assign = true := by
  apply local_rup F.assign c2433 [c4, c3, c2, c1233]
  · exact sat_cons (p4 F) ( sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p1233 F) (rfl))))
  · decide +kernel
def c2434 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (75,false), (86,false), (21,false), (110,false)]
theorem p2434 (F : Frame G 3) : c2434.eval F.assign = true := by
  apply local_rup F.assign c2434 [c3, c4, c5, c1234]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1234 F) (rfl))))
  · decide +kernel
def c2435 : CNF.Clause Nat := [(27,false), (38,false), (39,false), (6,false), (75,false), (86,false), (21,false), (110,false)]
theorem p2435 (F : Frame G 3) : c2435.eval F.assign = true := by
  apply local_rup F.assign c2435 [c4, c5, c1235]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1235 F) (rfl)))
  · decide +kernel
def c2436 : CNF.Clause Nat := [(50,false), (38,false), (75,false), (86,false), (21,false), (110,false)]
theorem p2436 (F : Frame G 3) : c2436.eval F.assign = true := by
  apply local_rup F.assign c2436 [c3, c1, c4, c5, c1236]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1236 F) (rfl)))))
  · decide +kernel
def c2437 : CNF.Clause Nat := [(8,false), (38,false), (50,false), (75,false), (76,false), (110,false)]
theorem p2437 (F : Frame G 3) : c2437.eval F.assign = true := by
  apply local_rup F.assign c2437 [c5, c1, c3, c6, c1237]
  · exact sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p1237 F) (rfl)))))
  · decide +kernel
def c2438 : CNF.Clause Nat := [(86,false), (26,false), (38,false), (50,false), (6,false), (76,false), (110,false)]
theorem p2438 (F : Frame G 3) : c2438.eval F.assign = true := by
  apply local_rup F.assign c2438 [c5, c6, c4, c1238]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1238 F) (rfl))))
  · decide +kernel
def c2439 : CNF.Clause Nat := [(50,false), (38,false), (10,false), (76,false), (77,false), (99,false), (20,false)]
theorem p2439 (F : Frame G 3) : c2439.eval F.assign = true := by
  apply local_rup F.assign c2439 [c3, c1, c5, c1239]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p1239 F) (rfl))))
  · decide +kernel
def c2440 : CNF.Clause Nat := [(39,false), (5,false), (18,false), (77,false), (110,false), (87,false), (86,false)]
theorem p2440 (F : Frame G 3) : c2440.eval F.assign = true := by
  apply local_rup F.assign c2440 [c3, c1, c2, c1240]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p1240 F) (rfl))))
  · decide +kernel
def c2441 : CNF.Clause Nat := [(11,false), (77,false), (76,false), (87,false), (86,false), (27,false), (17,false)]
theorem p2441 (F : Frame G 3) : c2441.eval F.assign = true := by
  apply local_rup F.assign c2441 [c1, c6, c2, c1241]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p1241 F) (rfl))))
  · decide +kernel
def c2442 : CNF.Clause Nat := [(50,false), (39,false), (77,false), (110,false), (32,false), (86,false)]
theorem p2442 (F : Frame G 3) : c2442.eval F.assign = true := by
  apply local_rup F.assign c2442 [c2, c1, c4, c6, c1242]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1242 F) (rfl)))))
  · decide +kernel
def c2443 : CNF.Clause Nat := [(26,false), (50,false), (87,false), (98,false), (75,false), (77,false)]
theorem p2443 (F : Frame G 3) : c2443.eval F.assign = true := by
  apply local_rup F.assign c2443 [c1, c3, c2, c5, c1243]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1243 F) (rfl)))))
  · decide +kernel
def c2444 : CNF.Clause Nat := [(50,false), (26,false), (75,false), (99,false), (88,false), (87,false)]
theorem p2444 (F : Frame G 3) : c2444.eval F.assign = true := by
  apply local_rup F.assign c2444 [c2, c3, c1, c4, c1244]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p1244 F) (rfl)))))
  · decide +kernel
def c2445 : CNF.Clause Nat := [(39,false), (15,false), (5,false), (75,false), (99,false), (88,false), (87,false)]
theorem p2445 (F : Frame G 3) : c2445.eval F.assign = true := by
  apply local_rup F.assign c2445 [c3, c2, c4, c1245]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1245 F) (rfl))))
  · decide +kernel
def c2446 : CNF.Clause Nat := [(15,false), (50,false), (75,false), (76,false), (87,false), (88,false)]
theorem p2446 (F : Frame G 3) : c2446.eval F.assign = true := by
  apply local_rup F.assign c2446 [c1, c2, c3, c6, c1246]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p1246 F) (rfl)))))
  · decide +kernel
def c2447 : CNF.Clause Nat := [(17,false), (39,false), (26,false), (30,false), (87,false), (10,false), (75,false), (99,false)]
theorem p2447 (F : Frame G 3) : c2447.eval F.assign = true := by
  apply local_rup F.assign c2447 [c2, c4, c1247]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1247 F) (rfl)))
  · decide +kernel
def c2448 : CNF.Clause Nat := [(17,false), (26,false), (8,false), (87,false), (110,false), (77,false), (75,false)]
theorem p2448 (F : Frame G 3) : c2448.eval F.assign = true := by
  apply local_rup F.assign c2448 [c2, c3, c1, c1248]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p1248 F) (rfl))))
  · decide +kernel
def c2449 : CNF.Clause Nat := [(27,false), (39,false), (15,false), (87,false), (10,false), (75,false), (99,false)]
theorem p2449 (F : Frame G 3) : c2449.eval F.assign = true := by
  apply local_rup F.assign c2449 [c3, c5, c4, c1249]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1249 F) (rfl))))
  · decide +kernel
def c2450 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (11,false), (77,false), (75,false), (20,false), (87,false)]
theorem p2450 (F : Frame G 3) : c2450.eval F.assign = true := by
  apply local_rup F.assign c2450 [c3, c5, c1250]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p1250 F) (rfl)))
  · decide +kernel
def c2451 : CNF.Clause Nat := [(87,false), (110,false), (77,false), (75,false), (9,false), (26,false)]
theorem p2451 (F : Frame G 3) : c2451.eval F.assign = true := by
  apply local_rup F.assign c2451 [c2, c5, c1, c3, c1251]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p1251 F) (rfl)))))
  · decide +kernel
def c2452 : CNF.Clause Nat := [(27,false), (39,false), (9,false), (75,false), (77,false), (110,false), (21,false)]
theorem p2452 (F : Frame G 3) : c2452.eval F.assign = true := by
  apply local_rup F.assign c2452 [c3, c1, c5, c1252]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p1252 F) (rfl))))
  · decide +kernel
def c2453 : CNF.Clause Nat := [(39,false), (38,false), (87,false), (110,false), (11,false), (75,false)]
theorem p2453 (F : Frame G 3) : c2453.eval F.assign = true := by
  apply local_rup F.assign c2453 [c3, c2, c5, c4, c1253]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1253 F) (rfl)))))
  · decide +kernel
def c2454 : CNF.Clause Nat := [(27,false), (38,false), (39,false), (17,false), (21,false), (87,false), (86,false), (9,false), (77,false)]
theorem p2454 (F : Frame G 3) : c2454.eval F.assign = true := by
  apply local_rup F.assign c2454 [c4, c1254]
  · exact sat_cons (p4 F) ( sat_cons (p1254 F) (rfl))
  · decide +kernel
def c2455 : CNF.Clause Nat := [(27,false), (39,false), (15,false), (74,false), (9,false), (99,false), (110,false)]
theorem p2455 (F : Frame G 3) : c2455.eval F.assign = true := by
  apply local_rup F.assign c2455 [c3, c5, c4, c1255]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1255 F) (rfl))))
  · decide +kernel
def c2456 : CNF.Clause Nat := [(38,false), (39,false), (20,false), (74,false), (10,false), (110,false)]
theorem p2456 (F : Frame G 3) : c2456.eval F.assign = true := by
  apply local_rup F.assign c2456 [c3, c6, c5, c4, c1256]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1256 F) (rfl)))))
  · decide +kernel
def c2457 : CNF.Clause Nat := [(27,false), (39,false), (9,false), (99,false), (77,false), (74,false), (87,false)]
theorem p2457 (F : Frame G 3) : c2457.eval F.assign = true := by
  apply local_rup F.assign c2457 [c2, c3, c1, c1257]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p1257 F) (rfl))))
  · decide +kernel
def c2458 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (77,false), (110,false), (21,false), (86,false)]
theorem p2458 (F : Frame G 3) : c2458.eval F.assign = true := by
  apply local_rup F.assign c2458 [c3, c4, c5, c1258]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1258 F) (rfl))))
  · decide +kernel
def c2459 : CNF.Clause Nat := [(77,false), (110,false), (87,false), (86,false), (20,false), (27,false), (26,false), (39,false)]
theorem p2459 (F : Frame G 3) : c2459.eval F.assign = true := by
  apply local_rup F.assign c2459 [c4, c2, c1259]
  · exact sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p1259 F) (rfl)))
  · decide +kernel
def c2460 : CNF.Clause Nat := [(77,false), (110,false), (87,false), (86,false), (27,false), (15,false), (39,false)]
theorem p2460 (F : Frame G 3) : c2460.eval F.assign = true := by
  apply local_rup F.assign c2460 [c4, c6, c2, c1260]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p1260 F) (rfl))))
  · decide +kernel
def c2461 : CNF.Clause Nat := [(9,false), (77,false), (110,false), (87,false), (15,false), (38,false), (50,false)]
theorem p2461 (F : Frame G 3) : c2461.eval F.assign = true := by
  apply local_rup F.assign c2461 [c6, c4, c5, c1261]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1261 F) (rfl))))
  · decide +kernel
def c2462 : CNF.Clause Nat := [(39,false), (5,false), (20,false), (75,false), (74,false), (87,false), (110,false)]
theorem p2462 (F : Frame G 3) : c2462.eval F.assign = true := by
  apply local_rup F.assign c2462 [c3, c1, c2, c1262]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p1262 F) (rfl))))
  · decide +kernel
def c2463 : CNF.Clause Nat := [(38,false), (27,false), (17,false), (21,false), (110,false), (77,false), (74,false), (86,false)]
theorem p2463 (F : Frame G 3) : c2463.eval F.assign = true := by
  apply local_rup F.assign c2463 [c1, c3, c1263]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p1263 F) (rfl)))
  · decide +kernel
def c2464 : CNF.Clause Nat := [(38,false), (17,false), (32,false), (110,false), (88,false), (74,false), (75,false)]
theorem p2464 (F : Frame G 3) : c2464.eval F.assign = true := by
  apply local_rup F.assign c2464 [c1, c2, c3, c1264]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1264 F) (rfl))))
  · decide +kernel
def c2465 : CNF.Clause Nat := [(50,false), (39,false), (10,false), (87,false), (30,false), (75,false), (77,false)]
theorem p2465 (F : Frame G 3) : c2465.eval F.assign = true := by
  apply local_rup F.assign c2465 [c2, c1, c6, c1265]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p1265 F) (rfl))))
  · decide +kernel
def c2466 : CNF.Clause Nat := [(38,false), (39,false), (99,false), (77,false), (8,false), (87,false)]
theorem p2466 (F : Frame G 3) : c2466.eval F.assign = true := by
  apply local_rup F.assign c2466 [c2, c3, c6, c4, c1266]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1266 F) (rfl)))))
  · decide +kernel
def c2467 : CNF.Clause Nat := [(38,false), (17,false), (29,false), (11,false), (99,false), (86,false), (87,false)]
theorem p2467 (F : Frame G 3) : c2467.eval F.assign = true := by
  apply local_rup F.assign c2467 [c2, c3, c4, c1267]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1267 F) (rfl))))
  · decide +kernel
def c2468 : CNF.Clause Nat := [(38,false), (26,false), (6,false), (75,false), (98,false), (87,false), (88,false)]
theorem p2468 (F : Frame G 3) : c2468.eval F.assign = true := by
  apply local_rup F.assign c2468 [c2, c3, c4, c1268]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1268 F) (rfl))))
  · decide +kernel
def c2469 : CNF.Clause Nat := [(38,false), (26,false), (6,false), (9,false), (75,false), (74,false), (87,false), (110,false)]
theorem p2469 (F : Frame G 3) : c2469.eval F.assign = true := by
  apply local_rup F.assign c2469 [c2, c3, c1269]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1269 F) (rfl)))
  · decide +kernel
def c2470 : CNF.Clause Nat := [(38,false), (26,false), (6,false), (75,false), (86,false), (87,false), (110,false)]
theorem p2470 (F : Frame G 3) : c2470.eval F.assign = true := by
  apply local_rup F.assign c2470 [c2, c3, c4, c1270]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1270 F) (rfl))))
  · decide +kernel
def c2471 : CNF.Clause Nat := [(26,false), (50,false), (5,false), (75,false), (20,false), (87,false), (110,false)]
theorem p2471 (F : Frame G 3) : c2471.eval F.assign = true := by
  apply local_rup F.assign c2471 [c3, c4, c5, c1271]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1271 F) (rfl))))
  · decide +kernel
def c2472 : CNF.Clause Nat := [(38,false), (50,false), (75,false), (8,false), (21,false), (110,false)]
theorem p2472 (F : Frame G 3) : c2472.eval F.assign = true := by
  apply local_rup F.assign c2472 [c3, c6, c4, c5, c1272]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1272 F) (rfl)))))
  · decide +kernel
def c2473 : CNF.Clause Nat := [(15,false), (50,false), (33,false), (110,false), (10,false), (74,false), (86,false)]
theorem p2473 (F : Frame G 3) : c2473.eval F.assign = true := by
  apply local_rup F.assign c2473 [c2, c3, c4, c1273]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1273 F) (rfl))))
  · decide +kernel
def c2474 : CNF.Clause Nat := [(38,false), (50,false), (75,false), (11,false), (22,false), (87,false)]
theorem p2474 (F : Frame G 3) : c2474.eval F.assign = true := by
  apply local_rup F.assign c2474 [c3, c6, c4, c5, c1274]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1274 F) (rfl)))))
  · decide +kernel
def c2475 : CNF.Clause Nat := [(15,false), (39,false), (50,false), (27,false), (99,false), (11,false), (74,false), (87,false)]
theorem p2475 (F : Frame G 3) : c2475.eval F.assign = true := by
  apply local_rup F.assign c2475 [c6, c4, c1275]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1275 F) (rfl)))
  · decide +kernel
def c2476 : CNF.Clause Nat := [(74,false), (86,false), (98,false), (110,false), (22,false), (27,false)]
theorem p2476 (F : Frame G 3) : c2476.eval F.assign = true := by
  apply local_rup F.assign c2476 [c1, c4, c2, c3, c1276]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1276 F) (rfl)))))
  · decide +kernel
def c2477 : CNF.Clause Nat := [(50,false), (39,false), (26,false), (9,false), (11,false), (110,false), (76,false), (74,false)]
theorem p2477 (F : Frame G 3) : c2477.eval F.assign = true := by
  apply local_rup F.assign c2477 [c2, c6, c1277]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p1277 F) (rfl)))
  · decide +kernel
def c2478 : CNF.Clause Nat := [(27,false), (50,false), (39,false), (11,false), (22,false), (74,false), (75,false), (98,false)]
theorem p2478 (F : Frame G 3) : c2478.eval F.assign = true := by
  apply local_rup F.assign c2478 [c1, c5, c1278]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p1278 F) (rfl)))
  · decide +kernel
def c2479 : CNF.Clause Nat := [(50,false), (38,false), (15,false), (18,false), (74,false), (86,false), (9,false), (10,false), (110,false)]
theorem p2479 (F : Frame G 3) : c2479.eval F.assign = true := by
  apply local_rup F.assign c2479 [c3, c1279]
  · exact sat_cons (p3 F) ( sat_cons (p1279 F) (rfl))
  · decide +kernel
def c2480 : CNF.Clause Nat := [(74,false), (87,false), (110,false), (99,false), (20,false), (27,false)]
theorem p2480 (F : Frame G 3) : c2480.eval F.assign = true := by
  apply local_rup F.assign c2480 [c1, c4, c2, c3, c1280]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1280 F) (rfl)))))
  · decide +kernel
def c2481 : CNF.Clause Nat := [(50,false), (38,false), (18,false), (86,false), (99,false), (110,false)]
theorem p2481 (F : Frame G 3) : c2481.eval F.assign = true := by
  apply local_rup F.assign c2481 [c3, c1, c4, c5, c1281]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1281 F) (rfl)))))
  · decide +kernel
def c2482 : CNF.Clause Nat := [(38,false), (17,false), (29,false), (74,false), (86,false), (99,false), (110,false)]
theorem p2482 (F : Frame G 3) : c2482.eval F.assign = true := by
  apply local_rup F.assign c2482 [c1, c2, c3, c1282]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1282 F) (rfl))))
  · decide +kernel
def c2483 : CNF.Clause Nat := [(15,false), (38,false), (50,false), (6,false), (74,false), (86,false), (32,false), (110,false)]
theorem p2483 (F : Frame G 3) : c2483.eval F.assign = true := by
  apply local_rup F.assign c2483 [c4, c6, c1283]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1283 F) (rfl)))
  · decide +kernel
def c2484 : CNF.Clause Nat := [(38,false), (6,false), (86,false), (74,false), (77,false), (110,false)]
theorem p2484 (F : Frame G 3) : c2484.eval F.assign = true := by
  apply local_rup F.assign c2484 [c2, c1, c3, c6, c1284]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p1284 F) (rfl)))))
  · decide +kernel
def c2485 : CNF.Clause Nat := [(38,false), (17,false), (29,false), (77,false), (99,false), (86,false), (87,false)]
theorem p2485 (F : Frame G 3) : c2485.eval F.assign = true := by
  apply local_rup F.assign c2485 [c1, c2, c3, c1285]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1285 F) (rfl))))
  · decide +kernel
def c2486 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (74,false), (9,false), (32,false), (110,false)]
theorem p2486 (F : Frame G 3) : c2486.eval F.assign = true := by
  apply local_rup F.assign c2486 [c5, c4, c6, c1286]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1286 F) (rfl))))
  · decide +kernel
def c2487 : CNF.Clause Nat := [(15,false), (38,false), (50,false), (6,false), (29,false), (99,false), (88,false), (87,false)]
theorem p2487 (F : Frame G 3) : c2487.eval F.assign = true := by
  apply local_rup F.assign c2487 [c4, c6, c1287]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1287 F) (rfl)))
  · decide +kernel
def c2488 : CNF.Clause Nat := [(15,false), (38,false), (50,false), (6,false), (74,false), (87,false), (32,false), (99,false)]
theorem p2488 (F : Frame G 3) : c2488.eval F.assign = true := by
  apply local_rup F.assign c2488 [c4, c6, c1288]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1288 F) (rfl)))
  · decide +kernel
def c2489 : CNF.Clause Nat := [(20,false), (26,false), (38,false), (50,false), (6,false), (74,false), (87,false), (110,false)]
theorem p2489 (F : Frame G 3) : c2489.eval F.assign = true := by
  apply local_rup F.assign c2489 [c6, c4, c1289]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1289 F) (rfl)))
  · decide +kernel
def c2490 : CNF.Clause Nat := [(38,false), (26,false), (6,false), (9,false), (99,false), (77,false), (74,false), (87,false)]
theorem p2490 (F : Frame G 3) : c2490.eval F.assign = true := by
  apply local_rup F.assign c2490 [c2, c3, c1290]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1290 F) (rfl)))
  · decide +kernel
def c2491 : CNF.Clause Nat := [(38,false), (6,false), (30,false), (87,false), (110,false), (77,false), (75,false)]
theorem p2491 (F : Frame G 3) : c2491.eval F.assign = true := by
  apply local_rup F.assign c2491 [c2, c1, c3, c1291]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p1291 F) (rfl))))
  · decide +kernel
def c2492 : CNF.Clause Nat := [(87,false), (110,false), (77,false), (75,false), (26,false), (6,false), (50,false)]
theorem p2492 (F : Frame G 3) : c2492.eval F.assign = true := by
  apply local_rup F.assign c2492 [c5, c6, c1, c1292]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p1292 F) (rfl))))
  · decide +kernel
def c2493 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (87,false), (32,false), (29,false), (77,false), (99,false)]
theorem p2493 (F : Frame G 3) : c2493.eval F.assign = true := by
  apply local_rup F.assign c2493 [c1, c5, c1293]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p1293 F) (rfl)))
  · decide +kernel
def c2494 : CNF.Clause Nat := [(39,false), (5,false), (86,false), (75,false), (76,false), (110,false)]
theorem p2494 (F : Frame G 3) : c2494.eval F.assign = true := by
  apply local_rup F.assign c2494 [c3, c1, c2, c5, c1294]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1294 F) (rfl)))))
  · decide +kernel
def c2495 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (29,false), (30,false), (20,false), (99,false), (110,false)]
theorem p2495 (F : Frame G 3) : c2495.eval F.assign = true := by
  apply local_rup F.assign c2495 [c4, c5, c1295]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1295 F) (rfl)))
  · decide +kernel
def c2496 : CNF.Clause Nat := [(6,false), (50,false), (87,false), (110,false), (99,false), (29,false)]
theorem p2496 (F : Frame G 3) : c2496.eval F.assign = true := by
  apply local_rup F.assign c2496 [c1, c2, c5, c6, c1296]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1296 F) (rfl)))))
  · decide +kernel
def c2497 : CNF.Clause Nat := [(39,false), (50,false), (87,false), (110,false), (99,false), (29,false)]
theorem p2497 (F : Frame G 3) : c2497.eval F.assign = true := by
  apply local_rup F.assign c2497 [c1, c2, c5, c6, c1297]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1297 F) (rfl)))))
  · decide +kernel
def c2498 : CNF.Clause Nat := [(39,false), (27,false), (86,false), (75,false), (76,false), (110,false)]
theorem p2498 (F : Frame G 3) : c2498.eval F.assign = true := by
  apply local_rup F.assign c2498 [c1, c3, c2, c5, c1298]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1298 F) (rfl)))))
  · decide +kernel
def c2499 : CNF.Clause Nat := [(39,false), (15,false), (5,false), (76,false), (87,false), (86,false), (99,false)]
theorem p2499 (F : Frame G 3) : c2499.eval F.assign = true := by
  apply local_rup F.assign c2499 [c3, c2, c4, c1299]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1299 F) (rfl))))
  · decide +kernel
def c2500 : CNF.Clause Nat := [(38,false), (17,false), (30,false), (87,false), (98,false), (75,false), (77,false)]
theorem p2500 (F : Frame G 3) : c2500.eval F.assign = true := by
  apply local_rup F.assign c2500 [c1, c2, c3, c1300]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1300 F) (rfl))))
  · decide +kernel
def c2501 : CNF.Clause Nat := [(26,false), (50,false), (5,false), (75,false), (86,false), (21,false), (110,false)]
theorem p2501 (F : Frame G 3) : c2501.eval F.assign = true := by
  apply local_rup F.assign c2501 [c3, c4, c5, c1301]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1301 F) (rfl))))
  · decide +kernel
def c2502 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (75,false), (30,false), (21,false), (110,false)]
theorem p2502 (F : Frame G 3) : c2502.eval F.assign = true := by
  apply local_rup F.assign c2502 [c4, c6, c5, c1302]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1302 F) (rfl))))
  · decide +kernel
def c2503 : CNF.Clause Nat := [(50,false), (39,false), (75,false), (86,false), (30,false), (32,false), (110,false)]
theorem p2503 (F : Frame G 3) : c2503.eval F.assign = true := by
  apply local_rup F.assign c2503 [c2, c1, c4, c1303]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p1303 F) (rfl))))
  · decide +kernel
def c2504 : CNF.Clause Nat := [(50,false), (39,false), (75,false), (30,false), (87,false), (110,false)]
theorem p2504 (F : Frame G 3) : c2504.eval F.assign = true := by
  apply local_rup F.assign c2504 [c2, c1, c4, c6, c1304]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1304 F) (rfl)))))
  · decide +kernel
def c2505 : CNF.Clause Nat := [(18,false), (39,false), (30,false), (86,false), (98,false), (110,false)]
theorem p2505 (F : Frame G 3) : c2505.eval F.assign = true := by
  apply local_rup F.assign c2505 [c2, c4, c1, c3, c1305]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p1305 F) (rfl)))))
  · decide +kernel
def c2506 : CNF.Clause Nat := [(5,false), (38,false), (39,false), (17,false), (87,false), (110,false), (33,false), (29,false), (75,false)]
theorem p2506 (F : Frame G 3) : c2506.eval F.assign = true := by
  apply local_rup F.assign c2506 [c5, c1306]
  · exact sat_cons (p5 F) ( sat_cons (p1306 F) (rfl))
  · decide +kernel
def c2507 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (75,false), (30,false), (87,false), (110,false)]
theorem p2507 (F : Frame G 3) : c2507.eval F.assign = true := by
  apply local_rup F.assign c2507 [c2, c4, c6, c1307]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1307 F) (rfl))))
  · decide +kernel
def c2508 : CNF.Clause Nat := [(5,false), (38,false), (39,false), (17,false), (18,false), (75,false), (30,false), (87,false), (110,false)]
theorem p2508 (F : Frame G 3) : c2508.eval F.assign = true := by
  apply local_rup F.assign c2508 [c6, c1308]
  · exact sat_cons (p6 F) ( sat_cons (p1308 F) (rfl))
  · decide +kernel
def c2509 : CNF.Clause Nat := [(30,false), (26,false), (38,false), (50,false), (6,false), (75,false), (98,false), (110,false)]
theorem p2509 (F : Frame G 3) : c2509.eval F.assign = true := by
  apply local_rup F.assign c2509 [c5, c4, c1309]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1309 F) (rfl)))
  · decide +kernel
def c2510 : CNF.Clause Nat := [(75,false), (99,false), (110,false), (87,false), (27,false), (26,false), (39,false)]
theorem p2510 (F : Frame G 3) : c2510.eval F.assign = true := by
  apply local_rup F.assign c2510 [c4, c5, c2, c1310]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p1310 F) (rfl))))
  · decide +kernel
def c2511 : CNF.Clause Nat := [(75,false), (99,false), (110,false), (87,false), (30,false), (27,false), (15,false), (39,false)]
theorem p2511 (F : Frame G 3) : c2511.eval F.assign = true := by
  apply local_rup F.assign c2511 [c4, c2, c1311]
  · exact sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p1311 F) (rfl)))
  · decide +kernel
def c2512 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (87,false), (110,false), (33,false), (29,false), (75,false)]
theorem p2512 (F : Frame G 3) : c2512.eval F.assign = true := by
  apply local_rup F.assign c2512 [c1, c5, c1312]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p1312 F) (rfl)))
  · decide +kernel
def c2513 : CNF.Clause Nat := [(75,false), (86,false), (21,false), (110,false), (33,false), (27,false), (50,false)]
theorem p2513 (F : Frame G 3) : c2513.eval F.assign = true := by
  apply local_rup F.assign c2513 [c1, c4, c5, c1313]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1313 F) (rfl))))
  · decide +kernel
def c2514 : CNF.Clause Nat := [(75,false), (86,false), (30,false), (27,false), (50,false), (17,false), (21,false), (110,false)]
theorem p2514 (F : Frame G 3) : c2514.eval F.assign = true := by
  apply local_rup F.assign c2514 [c1, c4, c1314]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p1314 F) (rfl)))
  · decide +kernel
def c2515 : CNF.Clause Nat := [(39,false), (50,false), (30,false), (29,false), (9,false), (99,false), (110,false)]
theorem p2515 (F : Frame G 3) : c2515.eval F.assign = true := by
  apply local_rup F.assign c2515 [c2, c5, c4, c1315]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1315 F) (rfl))))
  · decide +kernel
def c2516 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (29,false), (75,false), (99,false), (88,false), (21,false)]
theorem p2516 (F : Frame G 3) : c2516.eval F.assign = true := by
  apply local_rup F.assign c2516 [c1, c5, c1316]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p1316 F) (rfl)))
  · decide +kernel
def c2517 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (30,false), (88,false), (110,false), (21,false), (18,false), (75,false)]
theorem p2517 (F : Frame G 3) : c2517.eval F.assign = true := by
  apply local_rup F.assign c2517 [c1, c1317]
  · exact sat_cons (p1 F) ( sat_cons (p1317 F) (rfl))
  · decide +kernel
def c2518 : CNF.Clause Nat := [(75,false), (30,false), (88,false), (110,false), (21,false), (15,false), (38,false), (50,false)]
theorem p2518 (F : Frame G 3) : c2518.eval F.assign = true := by
  apply local_rup F.assign c2518 [c4, c6, c1318]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1318 F) (rfl)))
  · decide +kernel
def c2519 : CNF.Clause Nat := [(75,false), (99,false), (88,false), (21,false), (32,false), (26,false), (38,false), (50,false)]
theorem p2519 (F : Frame G 3) : c2519.eval F.assign = true := by
  apply local_rup F.assign c2519 [c4, c5, c1319]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1319 F) (rfl)))
  · decide +kernel
def c2520 : CNF.Clause Nat := [(5,false), (38,false), (39,false), (17,false), (30,false), (29,false), (75,false), (98,false), (110,false)]
theorem p2520 (F : Frame G 3) : c2520.eval F.assign = true := by
  apply local_rup F.assign c2520 [c5, c1320]
  · exact sat_cons (p5 F) ( sat_cons (p1320 F) (rfl))
  · decide +kernel
def c2521 : CNF.Clause Nat := [(75,false), (98,false), (110,false), (88,false), (30,false), (27,false), (15,false), (39,false)]
theorem p2521 (F : Frame G 3) : c2521.eval F.assign = true := by
  apply local_rup F.assign c2521 [c4, c2, c1321]
  · exact sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p1321 F) (rfl)))
  · decide +kernel
def c2522 : CNF.Clause Nat := [(38,false), (39,false), (30,false), (18,false), (75,false), (98,false), (10,false), (11,false)]
theorem p2522 (F : Frame G 3) : c2522.eval F.assign = true := by
  apply local_rup F.assign c2522 [c3, c5, c1322]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p1322 F) (rfl)))
  · decide +kernel
def c2523 : CNF.Clause Nat := [(88,false), (110,false), (98,false), (75,false), (26,false)]
theorem p2523 (F : Frame G 3) : c2523.eval F.assign = true := by
  apply local_rup F.assign c2523 [c2, c5, c4, c1, c3, c1323]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p1323 F) (rfl))))))
  · decide +kernel
def c2524 : CNF.Clause Nat := [(39,false), (50,false), (30,false), (29,false), (9,false), (98,false), (110,false)]
theorem p2524 (F : Frame G 3) : c2524.eval F.assign = true := by
  apply local_rup F.assign c2524 [c2, c5, c4, c1324]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1324 F) (rfl))))
  · decide +kernel
def c2525 : CNF.Clause Nat := [(5,false), (50,false), (29,false), (77,false), (110,false), (21,false), (86,false)]
theorem p2525 (F : Frame G 3) : c2525.eval F.assign = true := by
  apply local_rup F.assign c2525 [c1, c3, c5, c1325]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p1325 F) (rfl))))
  · decide +kernel
def c2526 : CNF.Clause Nat := [(39,false), (15,false), (5,false), (8,false), (86,false), (75,false), (77,false), (110,false)]
theorem p2526 (F : Frame G 3) : c2526.eval F.assign = true := by
  apply local_rup F.assign c2526 [c3, c2, c1326]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p1326 F) (rfl)))
  · decide +kernel
def c2527 : CNF.Clause Nat := [(39,false), (50,false), (86,false), (98,false), (110,false), (33,false), (29,false)]
theorem p2527 (F : Frame G 3) : c2527.eval F.assign = true := by
  apply local_rup F.assign c2527 [c1, c2, c5, c1327]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1327 F) (rfl))))
  · decide +kernel
def c2528 : CNF.Clause Nat := [(27,false), (50,false), (39,false), (15,false), (8,false), (76,false), (98,false), (99,false)]
theorem p2528 (F : Frame G 3) : c2528.eval F.assign = true := by
  apply local_rup F.assign c2528 [c5, c4, c1328]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1328 F) (rfl)))
  · decide +kernel
def c2529 : CNF.Clause Nat := [(18,false), (86,false), (99,false), (110,false), (32,false), (27,false), (50,false)]
theorem p2529 (F : Frame G 3) : c2529.eval F.assign = true := by
  apply local_rup F.assign c2529 [c1, c4, c5, c1329]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1329 F) (rfl))))
  · decide +kernel
def c2530 : CNF.Clause Nat := [(39,false), (50,false), (8,false), (29,false), (98,false), (110,false)]
theorem p2530 (F : Frame G 3) : c2530.eval F.assign = true := by
  apply local_rup F.assign c2530 [c2, c5, c4, c6, c1330]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1330 F) (rfl)))))
  · decide +kernel
def c2531 : CNF.Clause Nat := [(39,false), (50,false), (8,false), (75,false), (32,false), (110,false)]
theorem p2531 (F : Frame G 3) : c2531.eval F.assign = true := by
  apply local_rup F.assign c2531 [c2, c5, c4, c6, c1331]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1331 F) (rfl)))))
  · decide +kernel
def c2532 : CNF.Clause Nat := [(38,false), (39,false), (75,false), (74,false), (8,false), (10,false), (110,false)]
theorem p2532 (F : Frame G 3) : c2532.eval F.assign = true := by
  apply local_rup F.assign c2532 [c2, c3, c6, c1332]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p1332 F) (rfl))))
  · decide +kernel
def c2533 : CNF.Clause Nat := [(74,false), (75,false), (99,false), (110,false), (32,false), (26,false), (6,false)]
theorem p2533 (F : Frame G 3) : c2533.eval F.assign = true := by
  apply local_rup F.assign c2533 [c2, c5, c1, c1333]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p1333 F) (rfl))))
  · decide +kernel
def c2534 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (8,false), (21,false), (110,false), (99,false), (29,false)]
theorem p2534 (F : Frame G 3) : c2534.eval F.assign = true := by
  apply local_rup F.assign c2534 [c5, c6, c1334]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1334 F) (rfl)))
  · decide +kernel
def c2535 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (8,false), (29,false), (99,false), (110,false)]
theorem p2535 (F : Frame G 3) : c2535.eval F.assign = true := by
  apply local_rup F.assign c2535 [c5, c4, c6, c1335]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1335 F) (rfl))))
  · decide +kernel
def c2536 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (29,false), (86,false), (21,false), (110,false)]
theorem p2536 (F : Frame G 3) : c2536.eval F.assign = true := by
  apply local_rup F.assign c2536 [c4, c6, c5, c1336]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1336 F) (rfl))))
  · decide +kernel
def c2537 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (18,false), (74,false), (8,false), (11,false), (33,false), (98,false)]
theorem p2537 (F : Frame G 3) : c2537.eval F.assign = true := by
  apply local_rup F.assign c2537 [c6, c1337]
  · exact sat_cons (p6 F) ( sat_cons (p1337 F) (rfl))
  · decide +kernel
def c2538 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (74,false), (86,false), (32,false), (110,false)]
theorem p2538 (F : Frame G 3) : c2538.eval F.assign = true := by
  apply local_rup F.assign c2538 [c2, c4, c6, c1338]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1338 F) (rfl))))
  · decide +kernel
def c2539 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (22,false), (11,false), (74,false), (86,false), (32,false)]
theorem p2539 (F : Frame G 3) : c2539.eval F.assign = true := by
  apply local_rup F.assign c2539 [c4, c6, c1339]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1339 F) (rfl)))
  · decide +kernel
def c2540 : CNF.Clause Nat := [(17,false), (39,false), (74,false), (86,false), (32,false), (110,false)]
theorem p2540 (F : Frame G 3) : c2540.eval F.assign = true := by
  apply local_rup F.assign c2540 [c2, c1, c4, c6, c1340]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1340 F) (rfl)))))
  · decide +kernel
def c2541 : CNF.Clause Nat := [(38,false), (39,false), (29,false), (74,false), (88,false), (11,false), (9,false), (98,false)]
theorem p2541 (F : Frame G 3) : c2541.eval F.assign = true := by
  apply local_rup F.assign c2541 [c2, c3, c1341]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1341 F) (rfl)))
  · decide +kernel
def c2542 : CNF.Clause Nat := [(39,false), (38,false), (27,false), (9,false), (18,false), (88,false), (110,false)]
theorem p2542 (F : Frame G 3) : c2542.eval F.assign = true := by
  apply local_rup F.assign c2542 [c6, c4, c5, c1342]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1342 F) (rfl))))
  · decide +kernel
def c2543 : CNF.Clause Nat := [(39,false), (38,false), (27,false), (20,false), (21,false), (110,false), (11,false), (74,false)]
theorem p2543 (F : Frame G 3) : c2543.eval F.assign = true := by
  apply local_rup F.assign c2543 [c6, c4, c1343]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1343 F) (rfl)))
  · decide +kernel
def c2544 : CNF.Clause Nat := [(50,false), (39,false), (74,false), (86,false), (32,false), (110,false)]
theorem p2544 (F : Frame G 3) : c2544.eval F.assign = true := by
  apply local_rup F.assign c2544 [c2, c1, c4, c6, c1344]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1344 F) (rfl)))))
  · decide +kernel
def c2545 : CNF.Clause Nat := [(20,false), (98,false), (110,false), (88,false), (74,false), (29,false), (26,false), (5,false), (50,false)]
theorem p2545 (F : Frame G 3) : c2545.eval F.assign = true := by
  apply local_rup F.assign c2545 [c1, c1345]
  · exact sat_cons (p1 F) ( sat_cons (p1345 F) (rfl))
  · decide +kernel
def c2546 : CNF.Clause Nat := [(74,false), (88,false), (110,false), (98,false), (20,false), (27,false)]
theorem p2546 (F : Frame G 3) : c2546.eval F.assign = true := by
  apply local_rup F.assign c2546 [c1, c4, c2, c3, c1346]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1346 F) (rfl)))))
  · decide +kernel
def c2547 : CNF.Clause Nat := [(15,false), (50,false), (6,false), (74,false), (88,false), (99,false), (32,false)]
theorem p2547 (F : Frame G 3) : c2547.eval F.assign = true := by
  apply local_rup F.assign c2547 [c2, c4, c6, c1347]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1347 F) (rfl))))
  · decide +kernel
def c2548 : CNF.Clause Nat := [(5,false), (50,false), (99,false), (110,false), (21,false), (18,false), (74,false)]
theorem p2548 (F : Frame G 3) : c2548.eval F.assign = true := by
  apply local_rup F.assign c2548 [c1, c3, c6, c1348]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p1348 F) (rfl))))
  · decide +kernel
def c2549 : CNF.Clause Nat := [(38,false), (50,false), (99,false), (110,false), (21,false), (18,false), (74,false)]
theorem p2549 (F : Frame G 3) : c2549.eval F.assign = true := by
  apply local_rup F.assign c2549 [c1, c3, c6, c1349]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p1349 F) (rfl))))
  · decide +kernel
def c2550 : CNF.Clause Nat := [(38,false), (26,false), (6,false), (74,false), (86,false), (98,false), (110,false)]
theorem p2550 (F : Frame G 3) : c2550.eval F.assign = true := by
  apply local_rup F.assign c2550 [c2, c3, c4, c1350]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1350 F) (rfl))))
  · decide +kernel
def c2551 : CNF.Clause Nat := [(38,false), (50,false), (29,false), (74,false), (8,false), (10,false), (98,false), (20,false), (22,false)]
theorem p2551 (F : Frame G 3) : c2551.eval F.assign = true := by
  apply local_rup F.assign c2551 [c3, c1351]
  · exact sat_cons (p3 F) ( sat_cons (p1351 F) (rfl))
  · decide +kernel
def c2552 : CNF.Clause Nat := [(74,false), (75,false), (26,false), (38,false), (50,false), (6,false), (10,false), (110,false)]
theorem p2552 (F : Frame G 3) : c2552.eval F.assign = true := by
  apply local_rup F.assign c2552 [c5, c6, c1352]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1352 F) (rfl)))
  · decide +kernel
def c2553 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (74,false), (22,false), (110,false), (32,false)]
theorem p2553 (F : Frame G 3) : c2553.eval F.assign = true := by
  apply local_rup F.assign c2553 [c4, c5, c6, c1353]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1353 F) (rfl))))
  · decide +kernel
def c2554 : CNF.Clause Nat := [(17,false), (50,false), (38,false), (26,false), (98,false), (76,false), (8,false), (88,false)]
theorem p2554 (F : Frame G 3) : c2554.eval F.assign = true := by
  apply local_rup F.assign c2554 [c6, c4, c1354]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1354 F) (rfl)))
  · decide +kernel
def c2555 : CNF.Clause Nat := [(17,false), (50,false), (38,false), (74,false), (86,false), (32,false), (110,false)]
theorem p2555 (F : Frame G 3) : c2555.eval F.assign = true := by
  apply local_rup F.assign c2555 [c1, c4, c6, c1355]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1355 F) (rfl))))
  · decide +kernel
def c2556 : CNF.Clause Nat := [(8,false), (74,false), (18,false), (50,false), (98,false), (110,false)]
theorem p2556 (F : Frame G 3) : c2556.eval F.assign = true := by
  apply local_rup F.assign c2556 [c1, c2, c3, c6, c1356]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p1356 F) (rfl)))))
  · decide +kernel
def c2557 : CNF.Clause Nat := [(8,false), (74,false), (76,false), (110,false), (22,false), (20,false), (27,false), (50,false)]
theorem p2557 (F : Frame G 3) : c2557.eval F.assign = true := by
  apply local_rup F.assign c2557 [c1, c6, c1357]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p1357 F) (rfl)))
  · decide +kernel
def c2558 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (8,false), (74,false), (29,false), (98,false), (110,false)]
theorem p2558 (F : Frame G 3) : c2558.eval F.assign = true := by
  apply local_rup F.assign c2558 [c2, c6, c1358]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p1358 F) (rfl)))
  · decide +kernel
def c2559 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (74,false), (30,false), (98,false), (110,false)]
theorem p2559 (F : Frame G 3) : c2559.eval F.assign = true := by
  apply local_rup F.assign c2559 [c2, c4, c6, c1359]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1359 F) (rfl))))
  · decide +kernel
def c2560 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (8,false), (74,false), (76,false), (32,false), (99,false)]
theorem p2560 (F : Frame G 3) : c2560.eval F.assign = true := by
  apply local_rup F.assign c2560 [c2, c6, c1360]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p1360 F) (rfl)))
  · decide +kernel
def c2561 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (8,false), (29,false), (98,false), (110,false)]
theorem p2561 (F : Frame G 3) : c2561.eval F.assign = true := by
  apply local_rup F.assign c2561 [c5, c4, c6, c1361]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1361 F) (rfl))))
  · decide +kernel
def c2562 : CNF.Clause Nat := [(39,false), (50,false), (86,false), (29,false), (10,false), (110,false)]
theorem p2562 (F : Frame G 3) : c2562.eval F.assign = true := by
  apply local_rup F.assign c2562 [c2, c5, c6, c4, c1362]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1362 F) (rfl)))))
  · decide +kernel
def c2563 : CNF.Clause Nat := [(39,false), (50,false), (87,false), (110,false), (11,false), (29,false)]
theorem p2563 (F : Frame G 3) : c2563.eval F.assign = true := by
  apply local_rup F.assign c2563 [c2, c5, c4, c6, c1363]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1363 F) (rfl)))))
  · decide +kernel
def c2564 : CNF.Clause Nat := [(39,false), (50,false), (87,false), (10,false), (9,false), (29,false), (77,false)]
theorem p2564 (F : Frame G 3) : c2564.eval F.assign = true := by
  apply local_rup F.assign c2564 [c2, c5, c6, c1364]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1364 F) (rfl))))
  · decide +kernel
def c2565 : CNF.Clause Nat := [(5,false), (50,false), (30,false), (87,false), (98,false), (20,false), (18,false), (77,false)]
theorem p2565 (F : Frame G 3) : c2565.eval F.assign = true := by
  apply local_rup F.assign c2565 [c1, c3, c1365]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p1365 F) (rfl)))
  · decide +kernel
def c2566 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (20,false), (18,false), (77,false), (11,false), (8,false), (87,false)]
theorem p2566 (F : Frame G 3) : c2566.eval F.assign = true := by
  apply local_rup F.assign c2566 [c6, c1366]
  · exact sat_cons (p6 F) ( sat_cons (p1366 F) (rfl))
  · decide +kernel
def c2567 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (30,false), (87,false), (21,false), (18,false), (77,false), (99,false)]
theorem p2567 (F : Frame G 3) : c2567.eval F.assign = true := by
  apply local_rup F.assign c2567 [c1, c1367]
  · exact sat_cons (p1 F) ( sat_cons (p1367 F) (rfl))
  · decide +kernel
def c2568 : CNF.Clause Nat := [(77,false), (99,false), (27,false), (50,false), (17,false), (87,false)]
theorem p2568 (F : Frame G 3) : c2568.eval F.assign = true := by
  apply local_rup F.assign c2568 [c1, c4, c6, c5, c1368]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1368 F) (rfl)))))
  · decide +kernel
def c2569 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (99,false), (77,false), (8,false), (21,false)]
theorem p2569 (F : Frame G 3) : c2569.eval F.assign = true := by
  apply local_rup F.assign c2569 [c6, c4, c5, c1369]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1369 F) (rfl))))
  · decide +kernel
def c2570 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (30,false), (75,false), (10,false), (110,false)]
theorem p2570 (F : Frame G 3) : c2570.eval F.assign = true := by
  apply local_rup F.assign c2570 [c5, c6, c4, c1370]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1370 F) (rfl))))
  · decide +kernel
def c2571 : CNF.Clause Nat := [(77,false), (99,false), (26,false), (38,false), (50,false), (17,false), (87,false)]
theorem p2571 (F : Frame G 3) : c2571.eval F.assign = true := by
  apply local_rup F.assign c2571 [c4, c6, c5, c1371]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1371 F) (rfl))))
  · decide +kernel
def c2572 : CNF.Clause Nat := [(8,false), (38,false), (50,false), (29,false), (77,false), (99,false), (98,false)]
theorem p2572 (F : Frame G 3) : c2572.eval F.assign = true := by
  apply local_rup F.assign c2572 [c5, c1, c3, c1372]
  · exact sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p1372 F) (rfl))))
  · decide +kernel
def c2573 : CNF.Clause Nat := [(76,false), (87,false), (50,false), (99,false)]
theorem p2573 (F : Frame G 3) : c2573.eval F.assign = true := by
  apply local_rup F.assign c2573 [c1, c4, c5, c2, c3, c6, c1373]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p1373 F) (rfl)))))))
  · decide +kernel
def c2574 : CNF.Clause Nat := [(17,false), (39,false), (26,false), (99,false), (110,false), (10,false), (74,false)]
theorem p2574 (F : Frame G 3) : c2574.eval F.assign = true := by
  apply local_rup F.assign c2574 [c2, c6, c4, c1374]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1374 F) (rfl))))
  · decide +kernel
def c2575 : CNF.Clause Nat := [(39,false), (38,false), (18,false), (8,false), (86,false), (99,false), (110,false)]
theorem p2575 (F : Frame G 3) : c2575.eval F.assign = true := by
  apply local_rup F.assign c2575 [c3, c2, c4, c1375]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1375 F) (rfl))))
  · decide +kernel
def c2576 : CNF.Clause Nat := [(39,false), (38,false), (18,false), (10,false), (87,false), (86,false), (99,false)]
theorem p2576 (F : Frame G 3) : c2576.eval F.assign = true := by
  apply local_rup F.assign c2576 [c3, c2, c4, c1376]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1376 F) (rfl))))
  · decide +kernel
def c2577 : CNF.Clause Nat := [(27,false), (38,false), (39,false), (6,false), (75,false), (98,false), (21,false), (88,false)]
theorem p2577 (F : Frame G 3) : c2577.eval F.assign = true := by
  apply local_rup F.assign c2577 [c4, c5, c1377]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1377 F) (rfl)))
  · decide +kernel
def c2578 : CNF.Clause Nat := [(86,false), (27,false), (38,false), (39,false), (6,false), (76,false), (110,false)]
theorem p2578 (F : Frame G 3) : c2578.eval F.assign = true := by
  apply local_rup F.assign c2578 [c5, c6, c4, c1378]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1378 F) (rfl))))
  · decide +kernel
def c2579 : CNF.Clause Nat := [(86,false), (27,false), (50,false), (39,false), (76,false), (110,false)]
theorem p2579 (F : Frame G 3) : c2579.eval F.assign = true := by
  apply local_rup F.assign c2579 [c5, c6, c1, c4, c1379]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p1379 F) (rfl)))))
  · decide +kernel
def c2580 : CNF.Clause Nat := [(5,false), (17,false), (29,false), (76,false), (110,false), (99,false), (86,false)]
theorem p2580 (F : Frame G 3) : c2580.eval F.assign = true := by
  apply local_rup F.assign c2580 [c1, c2, c3, c1380]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1380 F) (rfl))))
  · decide +kernel
def c2581 : CNF.Clause Nat := [(50,false), (39,false), (29,false), (30,false), (86,false), (98,false), (110,false)]
theorem p2581 (F : Frame G 3) : c2581.eval F.assign = true := by
  apply local_rup F.assign c2581 [c2, c1, c4, c1381]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p1381 F) (rfl))))
  · decide +kernel
def c2582 : CNF.Clause Nat := [(50,false), (26,false), (8,false), (74,false), (75,false), (98,false), (110,false)]
theorem p2582 (F : Frame G 3) : c2582.eval F.assign = true := by
  apply local_rup F.assign c2582 [c2, c3, c1, c1382]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p1382 F) (rfl))))
  · decide +kernel
def c2583 : CNF.Clause Nat := [(75,false), (74,false), (15,false), (39,false), (50,false), (5,false), (10,false), (110,false)]
theorem p2583 (F : Frame G 3) : c2583.eval F.assign = true := by
  apply local_rup F.assign c2583 [c6, c5, c1383]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1383 F) (rfl)))
  · decide +kernel
def c2584 : CNF.Clause Nat := [(50,false), (15,false), (75,false), (86,false), (88,false), (110,false)]
theorem p2584 (F : Frame G 3) : c2584.eval F.assign = true := by
  apply local_rup F.assign c2584 [c3, c2, c1, c4, c1384]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p1384 F) (rfl)))))
  · decide +kernel
def c2585 : CNF.Clause Nat := [(15,false), (50,false), (29,false), (76,false), (110,false), (99,false), (86,false)]
theorem p2585 (F : Frame G 3) : c2585.eval F.assign = true := by
  apply local_rup F.assign c2585 [c1, c2, c3, c1385]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1385 F) (rfl))))
  · decide +kernel
def c2586 : CNF.Clause Nat := [(15,false), (50,false), (86,false), (74,false), (76,false), (110,false)]
theorem p2586 (F : Frame G 3) : c2586.eval F.assign = true := by
  apply local_rup F.assign c2586 [c1, c2, c3, c6, c1386]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p1386 F) (rfl)))))
  · decide +kernel
def c2587 : CNF.Clause Nat := [(15,false), (50,false), (6,false), (76,false), (98,false), (30,false), (88,false)]
theorem p2587 (F : Frame G 3) : c2587.eval F.assign = true := by
  apply local_rup F.assign c2587 [c2, c4, c6, c1387]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1387 F) (rfl))))
  · decide +kernel
def c2588 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (74,false), (29,false), (98,false), (110,false)]
theorem p2588 (F : Frame G 3) : c2588.eval F.assign = true := by
  apply local_rup F.assign c2588 [c1, c5, c6, c1388]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1388 F) (rfl))))
  · decide +kernel
def c2589 : CNF.Clause Nat := [(15,false), (50,false), (98,false), (76,false), (74,false), (88,false)]
theorem p2589 (F : Frame G 3) : c2589.eval F.assign = true := by
  apply local_rup F.assign c2589 [c1, c2, c3, c6, c1389]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p1389 F) (rfl)))))
  · decide +kernel
def c2590 : CNF.Clause Nat := [(15,false), (39,false), (6,false), (74,false), (30,false), (99,false), (110,false)]
theorem p2590 (F : Frame G 3) : c2590.eval F.assign = true := by
  apply local_rup F.assign c2590 [c2, c4, c6, c1390]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1390 F) (rfl))))
  · decide +kernel
def c2591 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (9,false), (30,false), (74,false), (76,false), (110,false)]
theorem p2591 (F : Frame G 3) : c2591.eval F.assign = true := by
  apply local_rup F.assign c2591 [c2, c6, c1391]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p1391 F) (rfl)))
  · decide +kernel
def c2592 : CNF.Clause Nat := [(74,false), (75,false), (9,false), (39,false), (32,false), (110,false)]
theorem p2592 (F : Frame G 3) : c2592.eval F.assign = true := by
  apply local_rup F.assign c2592 [c2, c5, c1, c3, c1392]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p1392 F) (rfl)))))
  · decide +kernel
def c2593 : CNF.Clause Nat := [(38,false), (17,false), (30,false), (74,false), (75,false), (98,false), (110,false)]
theorem p2593 (F : Frame G 3) : c2593.eval F.assign = true := by
  apply local_rup F.assign c2593 [c1, c2, c3, c1393]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1393 F) (rfl))))
  · decide +kernel
def c2594 : CNF.Clause Nat := [(5,false), (39,false), (17,false), (74,false), (29,false), (98,false), (110,false)]
theorem p2594 (F : Frame G 3) : c2594.eval F.assign = true := by
  apply local_rup F.assign c2594 [c1, c5, c6, c1394]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1394 F) (rfl))))
  · decide +kernel
def c2595 : CNF.Clause Nat := [(39,false), (38,false), (22,false), (110,false), (76,false), (8,false), (86,false)]
theorem p2595 (F : Frame G 3) : c2595.eval F.assign = true := by
  apply local_rup F.assign c2595 [c3, c2, c4, c1395]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1395 F) (rfl))))
  · decide +kernel
def c2596 : CNF.Clause Nat := [(27,false), (39,false), (15,false), (86,false), (9,false), (76,false), (110,false)]
theorem p2596 (F : Frame G 3) : c2596.eval F.assign = true := by
  apply local_rup F.assign c2596 [c3, c5, c4, c1396]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1396 F) (rfl))))
  · decide +kernel
def c2597 : CNF.Clause Nat := [(17,false), (26,false), (9,false), (86,false), (74,false), (76,false), (110,false)]
theorem p2597 (F : Frame G 3) : c2597.eval F.assign = true := by
  apply local_rup F.assign c2597 [c2, c3, c1, c1397]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p1397 F) (rfl))))
  · decide +kernel
def c2598 : CNF.Clause Nat := [(39,false), (5,false), (20,false), (86,false), (74,false), (76,false), (110,false)]
theorem p2598 (F : Frame G 3) : c2598.eval F.assign = true := by
  apply local_rup F.assign c2598 [c3, c1, c2, c1398]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p1398 F) (rfl))))
  · decide +kernel
def c2599 : CNF.Clause Nat := [(39,false), (38,false), (21,false), (110,false), (11,false), (74,false), (86,false)]
theorem p2599 (F : Frame G 3) : c2599.eval F.assign = true := by
  apply local_rup F.assign c2599 [c3, c2, c4, c1399]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1399 F) (rfl))))
  · decide +kernel
def c2600 : CNF.Clause Nat := [(10,false), (76,false), (77,false), (88,false), (86,false), (27,false), (15,false), (39,false)]
theorem p2600 (F : Frame G 3) : c2600.eval F.assign = true := by
  apply local_rup F.assign c2600 [c6, c2, c1400]
  · exact sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p1400 F) (rfl)))
  · decide +kernel
def c2601 : CNF.Clause Nat := [(10,false), (76,false), (77,false), (88,false), (86,false), (20,false), (27,false), (26,false), (39,false)]
theorem p2601 (F : Frame G 3) : c2601.eval F.assign = true := by
  apply local_rup F.assign c2601 [c2, c1401]
  · exact sat_cons (p2 F) ( sat_cons (p1401 F) (rfl))
  · decide +kernel
def c2602 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (20,false), (30,false), (87,false), (76,false), (11,false)]
theorem p2602 (F : Frame G 3) : c2602.eval F.assign = true := by
  apply local_rup F.assign c2602 [c6, c4, c1402]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1402 F) (rfl)))
  · decide +kernel
def c2603 : CNF.Clause Nat := [(38,false), (39,false), (20,false), (18,false), (8,false), (87,false), (110,false)]
theorem p2603 (F : Frame G 3) : c2603.eval F.assign = true := by
  apply local_rup F.assign c2603 [c3, c6, c4, c1403]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1403 F) (rfl))))
  · decide +kernel
def c2604 : CNF.Clause Nat := [(5,false), (38,false), (39,false), (17,false), (20,false), (29,false), (76,false), (87,false), (88,false)]
theorem p2604 (F : Frame G 3) : c2604.eval F.assign = true := by
  apply local_rup F.assign c2604 [c6, c1404]
  · exact sat_cons (p6 F) ( sat_cons (p1404 F) (rfl))
  · decide +kernel
def c2605 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (29,false), (20,false), (87,false), (110,false)]
theorem p2605 (F : Frame G 3) : c2605.eval F.assign = true := by
  apply local_rup F.assign c2605 [c4, c6, c5, c1405]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1405 F) (rfl))))
  · decide +kernel
def c2606 : CNF.Clause Nat := [(15,false), (39,false), (86,false), (8,false), (76,false), (110,false)]
theorem p2606 (F : Frame G 3) : c2606.eval F.assign = true := by
  apply local_rup F.assign c2606 [c2, c3, c6, c4, c1406]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1406 F) (rfl)))))
  · decide +kernel
def c2607 : CNF.Clause Nat := [(38,false), (39,false), (33,false), (11,false), (76,false), (21,false), (86,false)]
theorem p2607 (F : Frame G 3) : c2607.eval F.assign = true := by
  apply local_rup F.assign c2607 [c3, c4, c5, c1407]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1407 F) (rfl))))
  · decide +kernel
def c2608 : CNF.Clause Nat := [(38,false), (17,false), (30,false), (74,false), (77,false), (99,false), (98,false)]
theorem p2608 (F : Frame G 3) : c2608.eval F.assign = true := by
  apply local_rup F.assign c2608 [c1, c2, c3, c1408]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1408 F) (rfl))))
  · decide +kernel
def c2609 : CNF.Clause Nat := [(38,false), (17,false), (86,false), (74,false), (76,false), (110,false)]
theorem p2609 (F : Frame G 3) : c2609.eval F.assign = true := by
  apply local_rup F.assign c2609 [c1, c2, c3, c6, c1409]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p1409 F) (rfl)))))
  · decide +kernel
def c2610 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (18,false), (86,false), (98,false), (110,false)]
theorem p2610 (F : Frame G 3) : c2610.eval F.assign = true := by
  apply local_rup F.assign c2610 [c3, c4, c5, c1410]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1410 F) (rfl))))
  · decide +kernel
def c2611 : CNF.Clause Nat := [(10,false), (110,false), (77,false), (74,false), (86,false), (27,false), (15,false), (39,false)]
theorem p2611 (F : Frame G 3) : c2611.eval F.assign = true := by
  apply local_rup F.assign c2611 [c6, c2, c1411]
  · exact sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p1411 F) (rfl)))
  · decide +kernel
def c2612 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (8,false), (74,false), (76,false), (98,false), (33,false)]
theorem p2612 (F : Frame G 3) : c2612.eval F.assign = true := by
  apply local_rup F.assign c2612 [c2, c6, c1412]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p1412 F) (rfl)))
  · decide +kernel
def c2613 : CNF.Clause Nat := [(50,false), (39,false), (26,false), (9,false), (10,false), (76,false), (74,false), (88,false)]
theorem p2613 (F : Frame G 3) : c2613.eval F.assign = true := by
  apply local_rup F.assign c2613 [c2, c6, c1413]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p1413 F) (rfl)))
  · decide +kernel
def c2614 : CNF.Clause Nat := [(99,false), (88,false), (74,false), (76,false), (21,false), (38,false), (6,false)]
theorem p2614 (F : Frame G 3) : c2614.eval F.assign = true := by
  apply local_rup F.assign c2614 [c6, c2, c1, c1414]
  · exact sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p1414 F) (rfl))))
  · decide +kernel
def c2615 : CNF.Clause Nat := [(27,false), (39,false), (74,false), (88,false), (99,false), (98,false)]
theorem p2615 (F : Frame G 3) : c2615.eval F.assign = true := by
  apply local_rup F.assign c2615 [c2, c3, c1, c4, c1415]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p1415 F) (rfl)))))
  · decide +kernel
def c2616 : CNF.Clause Nat := [(76,false), (110,false), (99,false), (86,false), (30,false), (27,false), (15,false), (39,false)]
theorem p2616 (F : Frame G 3) : c2616.eval F.assign = true := by
  apply local_rup F.assign c2616 [c4, c2, c1416]
  · exact sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p1416 F) (rfl)))
  · decide +kernel
def c2617 : CNF.Clause Nat := [(76,false), (110,false), (99,false), (86,false), (27,false), (26,false), (39,false)]
theorem p2617 (F : Frame G 3) : c2617.eval F.assign = true := by
  apply local_rup F.assign c2617 [c4, c5, c2, c1417]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p1417 F) (rfl))))
  · decide +kernel
def c2618 : CNF.Clause Nat := [(29,false), (27,false), (38,false), (39,false), (17,false), (22,false), (110,false), (87,false), (86,false)]
theorem p2618 (F : Frame G 3) : c2618.eval F.assign = true := by
  apply local_rup F.assign c2618 [c4, c1418]
  · exact sat_cons (p4 F) ( sat_cons (p1418 F) (rfl))
  · decide +kernel
def c2619 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (29,false), (86,false), (21,false), (110,false)]
theorem p2619 (F : Frame G 3) : c2619.eval F.assign = true := by
  apply local_rup F.assign c2619 [c4, c6, c5, c1419]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1419 F) (rfl))))
  · decide +kernel
def c2620 : CNF.Clause Nat := [(33,false), (11,false), (39,false), (50,false), (18,false), (76,false), (87,false), (86,false)]
theorem p2620 (F : Frame G 3) : c2620.eval F.assign = true := by
  apply local_rup F.assign c2620 [c1, c2, c1420]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p1420 F) (rfl)))
  · decide +kernel
def c2621 : CNF.Clause Nat := [(76,false), (110,false), (22,false), (38,false), (39,false), (30,false), (86,false)]
theorem p2621 (F : Frame G 3) : c2621.eval F.assign = true := by
  apply local_rup F.assign c2621 [c4, c2, c3, c1421]
  · exact sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1421 F) (rfl))))
  · decide +kernel
def c2622 : CNF.Clause Nat := [(50,false), (38,false), (76,false), (110,false), (22,false), (86,false)]
theorem p2622 (F : Frame G 3) : c2622.eval F.assign = true := by
  apply local_rup F.assign c2622 [c3, c1, c4, c5, c1422]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1422 F) (rfl)))))
  · decide +kernel
def c2623 : CNF.Clause Nat := [(76,false), (110,false), (33,false), (86,false), (50,false)]
theorem p2623 (F : Frame G 3) : c2623.eval F.assign = true := by
  apply local_rup F.assign c2623 [c1, c4, c6, c5, c2, c1423]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p1423 F) (rfl))))))
  · decide +kernel
def c2624 : CNF.Clause Nat := [(86,false), (74,false), (39,false), (50,false), (21,false), (110,false)]
theorem p2624 (F : Frame G 3) : c2624.eval F.assign = true := by
  apply local_rup F.assign c2624 [c6, c4, c1, c2, c1424]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p1424 F) (rfl)))))
  · decide +kernel
def c2625 : CNF.Clause Nat := [(38,false), (50,false), (29,false), (11,false), (110,false), (21,false), (86,false)]
theorem p2625 (F : Frame G 3) : c2625.eval F.assign = true := by
  apply local_rup F.assign c2625 [c3, c4, c5, c1425]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1425 F) (rfl))))
  · decide +kernel
def c2626 : CNF.Clause Nat := [(50,false), (38,false), (74,false), (86,false), (20,false), (21,false), (110,false)]
theorem p2626 (F : Frame G 3) : c2626.eval F.assign = true := by
  apply local_rup F.assign c2626 [c3, c1, c4, c1426]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p1426 F) (rfl))))
  · decide +kernel
def c2627 : CNF.Clause Nat := [(74,false), (86,false), (27,false), (38,false), (39,false), (17,false), (21,false), (110,false)]
theorem p2627 (F : Frame G 3) : c2627.eval F.assign = true := by
  apply local_rup F.assign c2627 [c4, c6, c1428]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1428 F) (rfl)))
  · decide +kernel
def c2628 : CNF.Clause Nat := [(6,false), (39,false), (38,false), (27,false), (20,false), (18,false), (74,false), (87,false), (110,false)]
theorem p2628 (F : Frame G 3) : c2628.eval F.assign = true := by
  apply local_rup F.assign c2628 [c6, c1429]
  · exact sat_cons (p6 F) ( sat_cons (p1429 F) (rfl))
  · decide +kernel
def c2629 : CNF.Clause Nat := [(5,false), (39,false), (20,false), (18,false), (74,false), (87,false), (110,false)]
theorem p2629 (F : Frame G 3) : c2629.eval F.assign = true := by
  apply local_rup F.assign c2629 [c1, c3, c6, c1430]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p1430 F) (rfl))))
  · decide +kernel
def c2630 : CNF.Clause Nat := [(5,false), (38,false), (39,false), (29,false), (74,false), (86,false), (20,false), (21,false), (110,false)]
theorem p2630 (F : Frame G 3) : c2630.eval F.assign = true := by
  apply local_rup F.assign c2630 [c3, c1431]
  · exact sat_cons (p3 F) ( sat_cons (p1431 F) (rfl))
  · decide +kernel
def c2631 : CNF.Clause Nat := [(50,false), (38,false), (9,false), (86,false), (74,false), (18,false), (21,false), (110,false)]
theorem p2631 (F : Frame G 3) : c2631.eval F.assign = true := by
  apply local_rup F.assign c2631 [c3, c1, c1432]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p1432 F) (rfl)))
  · decide +kernel
def c2632 : CNF.Clause Nat := [(21,false), (110,false), (88,false), (86,false), (29,false), (38,false), (50,false)]
theorem p2632 (F : Frame G 3) : c2632.eval F.assign = true := by
  apply local_rup F.assign c2632 [c6, c4, c1, c1433]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1 F) ( sat_cons (p1433 F) (rfl))))
  · decide +kernel
def c2633 : CNF.Clause Nat := [(39,false), (15,false), (5,false), (76,false), (110,false), (88,false), (86,false)]
theorem p2633 (F : Frame G 3) : c2633.eval F.assign = true := by
  apply local_rup F.assign c2633 [c3, c2, c4, c1434]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1434 F) (rfl))))
  · decide +kernel
def c2634 : CNF.Clause Nat := [(75,false), (27,false), (50,false), (17,false), (88,false), (110,false)]
theorem p2634 (F : Frame G 3) : c2634.eval F.assign = true := by
  apply local_rup F.assign c2634 [c1, c4, c6, c5, c1435]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1435 F) (rfl)))))
  · decide +kernel
def c2635 : CNF.Clause Nat := [(29,false), (27,false), (38,false), (39,false), (17,false), (86,false), (98,false), (110,false)]
theorem p2635 (F : Frame G 3) : c2635.eval F.assign = true := by
  apply local_rup F.assign c2635 [c4, c5, c1436]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1436 F) (rfl)))
  · decide +kernel
def c2636 : CNF.Clause Nat := [(75,false), (27,false), (38,false), (39,false), (17,false), (87,false), (110,false)]
theorem p2636 (F : Frame G 3) : c2636.eval F.assign = true := by
  apply local_rup F.assign c2636 [c4, c6, c5, c1437]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1437 F) (rfl))))
  · decide +kernel
def c2637 : CNF.Clause Nat := [(50,false), (38,false), (76,false), (110,false), (88,false), (20,false)]
theorem p2637 (F : Frame G 3) : c2637.eval F.assign = true := by
  apply local_rup F.assign c2637 [c3, c1, c4, c5, c1438]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1438 F) (rfl)))))
  · decide +kernel
def c2638 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (29,false), (20,false), (87,false), (110,false)]
theorem p2638 (F : Frame G 3) : c2638.eval F.assign = true := by
  apply local_rup F.assign c2638 [c4, c6, c5, c1439]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1439 F) (rfl))))
  · decide +kernel
def c2639 : CNF.Clause Nat := [(38,false), (50,false), (20,false), (18,false), (8,false), (87,false), (110,false)]
theorem p2639 (F : Frame G 3) : c2639.eval F.assign = true := by
  apply local_rup F.assign c2639 [c3, c6, c4, c1440]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1440 F) (rfl))))
  · decide +kernel
def c2640 : CNF.Clause Nat := [(9,false), (75,false), (76,false), (110,false), (33,false), (30,false), (50,false)]
theorem p2640 (F : Frame G 3) : c2640.eval F.assign = true := by
  apply local_rup F.assign c2640 [c1, c5, c2, c1441]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p1441 F) (rfl))))
  · decide +kernel
def c2641 : CNF.Clause Nat := [(39,false), (38,false), (18,false), (9,false), (30,false), (87,false), (110,false)]
theorem p2641 (F : Frame G 3) : c2641.eval F.assign = true := by
  apply local_rup F.assign c2641 [c2, c4, c6, c1442]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1442 F) (rfl))))
  · decide +kernel
def c2642 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (18,false), (30,false), (98,false), (110,false)]
theorem p2642 (F : Frame G 3) : c2642.eval F.assign = true := by
  apply local_rup F.assign c2642 [c4, c5, c6, c1443]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1443 F) (rfl))))
  · decide +kernel
def c2643 : CNF.Clause Nat := [(98,false), (76,false), (74,false), (8,false), (11,false), (22,false), (15,false), (38,false), (50,false)]
theorem p2643 (F : Frame G 3) : c2643.eval F.assign = true := by
  apply local_rup F.assign c2643 [c6, c1444]
  · exact sat_cons (p6 F) ( sat_cons (p1444 F) (rfl))
  · decide +kernel
def c2644 : CNF.Clause Nat := [(98,false), (76,false), (74,false), (8,false), (11,false), (22,false), (38,false), (39,false)]
theorem p2644 (F : Frame G 3) : c2644.eval F.assign = true := by
  apply local_rup F.assign c2644 [c6, c2, c1445]
  · exact sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p1445 F) (rfl)))
  · decide +kernel
def c2645 : CNF.Clause Nat := [(27,false), (38,false), (39,false), (17,false), (86,false), (75,false), (10,false), (110,false)]
theorem p2645 (F : Frame G 3) : c2645.eval F.assign = true := by
  apply local_rup F.assign c2645 [c5, c4, c1446]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1446 F) (rfl)))
  · decide +kernel
def c2646 : CNF.Clause Nat := [(38,false), (39,false), (29,false), (8,false), (86,false), (98,false), (110,false)]
theorem p2646 (F : Frame G 3) : c2646.eval F.assign = true := by
  apply local_rup F.assign c2646 [c2, c3, c4, c1447]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1447 F) (rfl))))
  · decide +kernel
def c2647 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (76,false), (110,false), (33,false), (30,false), (86,false)]
theorem p2647 (F : Frame G 3) : c2647.eval F.assign = true := by
  apply local_rup F.assign c2647 [c2, c4, c1448]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1448 F) (rfl)))
  · decide +kernel
def c2648 : CNF.Clause Nat := [(27,false), (39,false), (18,false), (86,false), (98,false), (110,false)]
theorem p2648 (F : Frame G 3) : c2648.eval F.assign = true := by
  apply local_rup F.assign c2648 [c3, c1, c4, c5, c1449]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1449 F) (rfl)))))
  · decide +kernel
def c2649 : CNF.Clause Nat := [(5,false), (39,false), (17,false), (86,false), (29,false), (76,false), (110,false)]
theorem p2649 (F : Frame G 3) : c2649.eval F.assign = true := by
  apply local_rup F.assign c2649 [c1, c5, c6, c1450]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1450 F) (rfl))))
  · decide +kernel
def c2650 : CNF.Clause Nat := [(38,false), (39,false), (33,false), (99,false), (75,false), (8,false), (87,false)]
theorem p2650 (F : Frame G 3) : c2650.eval F.assign = true := by
  apply local_rup F.assign c2650 [c2, c3, c4, c1451]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1451 F) (rfl))))
  · decide +kernel
def c2651 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (18,false), (87,false), (98,false), (99,false)]
theorem p2651 (F : Frame G 3) : c2651.eval F.assign = true := by
  apply local_rup F.assign c2651 [c3, c4, c5, c1452]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1452 F) (rfl))))
  · decide +kernel
def c2652 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (74,false), (22,false), (99,false), (98,false)]
theorem p2652 (F : Frame G 3) : c2652.eval F.assign = true := by
  apply local_rup F.assign c2652 [c3, c4, c5, c1453]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1453 F) (rfl))))
  · decide +kernel
def c2653 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (75,false), (99,false), (22,false), (87,false)]
theorem p2653 (F : Frame G 3) : c2653.eval F.assign = true := by
  apply local_rup F.assign c2653 [c3, c4, c5, c1454]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1454 F) (rfl))))
  · decide +kernel
def c2654 : CNF.Clause Nat := [(38,false), (39,false), (29,false), (9,false), (99,false), (88,false), (87,false)]
theorem p2654 (F : Frame G 3) : c2654.eval F.assign = true := by
  apply local_rup F.assign c2654 [c2, c3, c4, c1455]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1455 F) (rfl))))
  · decide +kernel
def c2655 : CNF.Clause Nat := [(77,false), (99,false), (30,false), (87,false), (21,false), (15,false), (38,false), (50,false)]
theorem p2655 (F : Frame G 3) : c2655.eval F.assign = true := by
  apply local_rup F.assign c2655 [c4, c6, c1456]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1456 F) (rfl)))
  · decide +kernel
def c2656 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (77,false), (99,false), (30,false), (87,false)]
theorem p2656 (F : Frame G 3) : c2656.eval F.assign = true := by
  apply local_rup F.assign c2656 [c2, c4, c6, c1457]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1457 F) (rfl))))
  · decide +kernel
def c2657 : CNF.Clause Nat := [(38,false), (39,false), (20,false), (18,false), (8,false), (88,false), (110,false)]
theorem p2657 (F : Frame G 3) : c2657.eval F.assign = true := by
  apply local_rup F.assign c2657 [c3, c6, c4, c1458]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1458 F) (rfl))))
  · decide +kernel
def c2658 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (18,false), (30,false), (99,false), (110,false)]
theorem p2658 (F : Frame G 3) : c2658.eval F.assign = true := by
  apply local_rup F.assign c2658 [c4, c5, c6, c1459]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1459 F) (rfl))))
  · decide +kernel
def c2659 : CNF.Clause Nat := [(39,false), (38,false), (30,false), (99,false), (77,false), (10,false)]
theorem p2659 (F : Frame G 3) : c2659.eval F.assign = true := by
  apply local_rup F.assign c2659 [c2, c5, c6, c4, c1460]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1460 F) (rfl)))))
  · decide +kernel
def c2660 : CNF.Clause Nat := [(38,false), (39,false), (9,false), (74,false), (21,false), (110,false)]
theorem p2660 (F : Frame G 3) : c2660.eval F.assign = true := by
  apply local_rup F.assign c2660 [c3, c6, c4, c5, c1461]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1461 F) (rfl)))))
  · decide +kernel
def c2661 : CNF.Clause Nat := [(18,false), (74,false), (87,false), (110,false), (11,false), (9,false), (26,false), (39,false)]
theorem p2661 (F : Frame G 3) : c2661.eval F.assign = true := by
  apply local_rup F.assign c2661 [c2, c6, c1462]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p1462 F) (rfl)))
  · decide +kernel
def c2662 : CNF.Clause Nat := [(38,false), (50,false), (98,false), (110,false), (22,false), (18,false), (74,false)]
theorem p2662 (F : Frame G 3) : c2662.eval F.assign = true := by
  apply local_rup F.assign c2662 [c1, c3, c6, c1463]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p1463 F) (rfl))))
  · decide +kernel
def c2663 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (18,false), (74,false), (30,false), (98,false), (110,false)]
theorem p2663 (F : Frame G 3) : c2663.eval F.assign = true := by
  apply local_rup F.assign c2663 [c1, c6, c1464]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p1464 F) (rfl)))
  · decide +kernel
def c2664 : CNF.Clause Nat := [(5,false), (39,false), (17,false), (74,false), (75,false), (32,false), (110,false)]
theorem p2664 (F : Frame G 3) : c2664.eval F.assign = true := by
  apply local_rup F.assign c2664 [c1, c5, c6, c1465]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1465 F) (rfl))))
  · decide +kernel
def c2665 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (74,false), (75,false), (32,false), (110,false)]
theorem p2665 (F : Frame G 3) : c2665.eval F.assign = true := by
  apply local_rup F.assign c2665 [c1, c5, c6, c1466]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1466 F) (rfl))))
  · decide +kernel
def c2666 : CNF.Clause Nat := [(39,false), (50,false), (18,false), (10,false), (32,false), (86,false), (88,false)]
theorem p2666 (F : Frame G 3) : c2666.eval F.assign = true := by
  apply local_rup F.assign c2666 [c2, c4, c6, c1467]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1467 F) (rfl))))
  · decide +kernel
def c2667 : CNF.Clause Nat := [(38,false), (39,false), (99,false), (110,false), (10,false), (74,false)]
theorem p2667 (F : Frame G 3) : c2667.eval F.assign = true := by
  apply local_rup F.assign c2667 [c2, c3, c6, c4, c1468]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1468 F) (rfl)))))
  · decide +kernel
def c2668 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (8,false), (74,false), (18,false), (20,false), (32,false), (110,false)]
theorem p2668 (F : Frame G 3) : c2668.eval F.assign = true := by
  apply local_rup F.assign c2668 [c6, c1469]
  · exact sat_cons (p6 F) ( sat_cons (p1469 F) (rfl))
  · decide +kernel
def c2669 : CNF.Clause Nat := [(8,false), (74,false), (75,false), (99,false), (110,false), (21,false), (27,false), (26,false), (39,false)]
theorem p2669 (F : Frame G 3) : c2669.eval F.assign = true := by
  apply local_rup F.assign c2669 [c2, c1470]
  · exact sat_cons (p2 F) ( sat_cons (p1470 F) (rfl))
  · decide +kernel
def c2670 : CNF.Clause Nat := [(8,false), (74,false), (75,false), (99,false), (110,false), (32,false), (27,false), (15,false), (39,false)]
theorem p2670 (F : Frame G 3) : c2670.eval F.assign = true := by
  apply local_rup F.assign c2670 [c2, c1471]
  · exact sat_cons (p2 F) ( sat_cons (p1471 F) (rfl))
  · decide +kernel
def c2671 : CNF.Clause Nat := [(27,false), (38,false), (39,false), (17,false), (8,false), (75,false), (98,false), (110,false)]
theorem p2671 (F : Frame G 3) : c2671.eval F.assign = true := by
  apply local_rup F.assign c2671 [c5, c4, c1472]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1472 F) (rfl)))
  · decide +kernel
def c2672 : CNF.Clause Nat := [(26,false), (50,false), (20,false), (99,false), (110,false), (10,false), (74,false)]
theorem p2672 (F : Frame G 3) : c2672.eval F.assign = true := by
  apply local_rup F.assign c2672 [c3, c2, c4, c1473]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1473 F) (rfl))))
  · decide +kernel
def c2673 : CNF.Clause Nat := [(39,false), (15,false), (5,false), (74,false), (87,false), (98,false), (99,false)]
theorem p2673 (F : Frame G 3) : c2673.eval F.assign = true := by
  apply local_rup F.assign c2673 [c3, c2, c4, c1474]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1474 F) (rfl))))
  · decide +kernel
def c2674 : CNF.Clause Nat := [(50,false), (26,false), (74,false), (86,false), (98,false), (110,false)]
theorem p2674 (F : Frame G 3) : c2674.eval F.assign = true := by
  apply local_rup F.assign c2674 [c2, c3, c1, c4, c1475]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p1475 F) (rfl)))))
  · decide +kernel
def c2675 : CNF.Clause Nat := [(6,false), (50,false), (27,false), (99,false), (110,false), (87,false), (18,false)]
theorem p2675 (F : Frame G 3) : c2675.eval F.assign = true := by
  apply local_rup F.assign c2675 [c1, c6, c5, c1476]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1476 F) (rfl))))
  · decide +kernel
def c2676 : CNF.Clause Nat := [(50,false), (26,false), (74,false), (86,false), (99,false), (110,false)]
theorem p2676 (F : Frame G 3) : c2676.eval F.assign = true := by
  apply local_rup F.assign c2676 [c2, c3, c1, c4, c1477]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p1477 F) (rfl)))))
  · decide +kernel
def c2677 : CNF.Clause Nat := [(86,false), (74,false), (10,false), (110,false), (22,false), (15,false), (39,false), (50,false)]
theorem p2677 (F : Frame G 3) : c2677.eval F.assign = true := by
  apply local_rup F.assign c2677 [c6, c4, c1478]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1478 F) (rfl)))
  · decide +kernel
def c2678 : CNF.Clause Nat := [(99,false), (110,false), (87,false), (74,false), (18,false), (15,false), (5,false), (50,false)]
theorem p2678 (F : Frame G 3) : c2678.eval F.assign = true := by
  apply local_rup F.assign c2678 [c6, c1, c1479]
  · exact sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p1479 F) (rfl)))
  · decide +kernel
def c2679 : CNF.Clause Nat := [(50,false), (26,false), (74,false), (87,false), (98,false), (99,false)]
theorem p2679 (F : Frame G 3) : c2679.eval F.assign = true := by
  apply local_rup F.assign c2679 [c2, c3, c1, c4, c1480]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p1480 F) (rfl)))))
  · decide +kernel
def c2680 : CNF.Clause Nat := [(10,false), (76,false), (29,false), (27,false), (38,false), (39,false), (17,false), (86,false), (99,false)]
theorem p2680 (F : Frame G 3) : c2680.eval F.assign = true := by
  apply local_rup F.assign c2680 [c5, c1481]
  · exact sat_cons (p5 F) ( sat_cons (p1481 F) (rfl))
  · decide +kernel
def c2681 : CNF.Clause Nat := [(39,false), (38,false), (88,false), (110,false), (10,false), (75,false)]
theorem p2681 (F : Frame G 3) : c2681.eval F.assign = true := by
  apply local_rup F.assign c2681 [c3, c2, c5, c4, c1482]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1482 F) (rfl)))))
  · decide +kernel
def c2682 : CNF.Clause Nat := [(5,false), (39,false), (17,false), (88,false), (110,false), (32,false), (29,false), (75,false)]
theorem p2682 (F : Frame G 3) : c2682.eval F.assign = true := by
  apply local_rup F.assign c2682 [c1, c5, c1483]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p1483 F) (rfl)))
  · decide +kernel
def c2683 : CNF.Clause Nat := [(38,false), (17,false), (30,false), (88,false), (99,false), (75,false), (76,false)]
theorem p2683 (F : Frame G 3) : c2683.eval F.assign = true := by
  apply local_rup F.assign c2683 [c1, c2, c3, c1484]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1484 F) (rfl))))
  · decide +kernel
def c2684 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (75,false), (99,false), (88,false), (21,false)]
theorem p2684 (F : Frame G 3) : c2684.eval F.assign = true := by
  apply local_rup F.assign c2684 [c3, c4, c5, c1485]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1485 F) (rfl))))
  · decide +kernel
def c2685 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (20,false), (29,false), (8,false), (88,false), (110,false)]
theorem p2685 (F : Frame G 3) : c2685.eval F.assign = true := by
  apply local_rup F.assign c2685 [c6, c4, c1486]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1486 F) (rfl)))
  · decide +kernel
def c2686 : CNF.Clause Nat := [(38,false), (39,false), (29,false), (9,false), (86,false), (21,false), (110,false)]
theorem p2686 (F : Frame G 3) : c2686.eval F.assign = true := by
  apply local_rup F.assign c2686 [c3, c4, c5, c1487]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1487 F) (rfl))))
  · decide +kernel
def c2687 : CNF.Clause Nat := [(77,false), (110,false), (21,false), (38,false), (39,false), (30,false), (86,false)]
theorem p2687 (F : Frame G 3) : c2687.eval F.assign = true := by
  apply local_rup F.assign c2687 [c4, c2, c3, c1488]
  · exact sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1488 F) (rfl))))
  · decide +kernel
def c2688 : CNF.Clause Nat := [(38,false), (39,false), (9,false), (8,false), (88,false), (77,false), (76,false)]
theorem p2688 (F : Frame G 3) : c2688.eval F.assign = true := by
  apply local_rup F.assign c2688 [c2, c3, c6, c1489]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p1489 F) (rfl))))
  · decide +kernel
def c2689 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (30,false), (18,false), (9,false), (99,false), (110,false)]
theorem p2689 (F : Frame G 3) : c2689.eval F.assign = true := by
  apply local_rup F.assign c2689 [c5, c4, c1490]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1490 F) (rfl)))
  · decide +kernel
def c2690 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (18,false), (30,false), (99,false), (110,false)]
theorem p2690 (F : Frame G 3) : c2690.eval F.assign = true := by
  apply local_rup F.assign c2690 [c4, c5, c6, c1491]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1491 F) (rfl))))
  · decide +kernel
def c2691 : CNF.Clause Nat := [(39,false), (50,false), (30,false), (29,false), (77,false), (99,false), (98,false)]
theorem p2691 (F : Frame G 3) : c2691.eval F.assign = true := by
  apply local_rup F.assign c2691 [c1, c2, c5, c1492]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1492 F) (rfl))))
  · decide +kernel
def c2692 : CNF.Clause Nat := [(39,false), (50,false), (18,false), (77,false), (88,false), (30,false), (98,false)]
theorem p2692 (F : Frame G 3) : c2692.eval F.assign = true := by
  apply local_rup F.assign c2692 [c1, c2, c6, c1493]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p1493 F) (rfl))))
  · decide +kernel
def c2693 : CNF.Clause Nat := [(5,false), (39,false), (17,false), (20,false), (29,false), (77,false), (88,false), (87,false)]
theorem p2693 (F : Frame G 3) : c2693.eval F.assign = true := by
  apply local_rup F.assign c2693 [c1, c6, c1494]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p1494 F) (rfl)))
  · decide +kernel
def c2694 : CNF.Clause Nat := [(50,false), (39,false), (76,false), (32,false), (30,false), (88,false), (99,false)]
theorem p2694 (F : Frame G 3) : c2694.eval F.assign = true := by
  apply local_rup F.assign c2694 [c2, c1, c4, c1495]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p1495 F) (rfl))))
  · decide +kernel
def c2695 : CNF.Clause Nat := [(15,false), (50,false), (29,false), (76,false), (10,false), (9,false), (86,false), (88,false)]
theorem p2695 (F : Frame G 3) : c2695.eval F.assign = true := by
  apply local_rup F.assign c2695 [c2, c3, c1496]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1496 F) (rfl)))
  · decide +kernel
def c2696 : CNF.Clause Nat := [(17,false), (50,false), (38,false), (76,false), (110,false), (88,false), (30,false)]
theorem p2696 (F : Frame G 3) : c2696.eval F.assign = true := by
  apply local_rup F.assign c2696 [c1, c4, c6, c1497]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1497 F) (rfl))))
  · decide +kernel
def c2697 : CNF.Clause Nat := [(50,false), (38,false), (15,false), (18,false), (76,false), (10,false), (8,false), (88,false), (99,false)]
theorem p2697 (F : Frame G 3) : c2697.eval F.assign = true := by
  apply local_rup F.assign c2697 [c3, c1499]
  · exact sat_cons (p3 F) ( sat_cons (p1499 F) (rfl))
  · decide +kernel
def c2698 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (18,false), (76,false), (32,false), (9,false), (8,false), (88,false)]
theorem p2698 (F : Frame G 3) : c2698.eval F.assign = true := by
  apply local_rup F.assign c2698 [c6, c1500]
  · exact sat_cons (p6 F) ( sat_cons (p1500 F) (rfl))
  · decide +kernel
def c2699 : CNF.Clause Nat := [(38,false), (50,false), (30,false), (21,false), (76,false), (75,false), (99,false)]
theorem p2699 (F : Frame G 3) : c2699.eval F.assign = true := by
  apply local_rup F.assign c2699 [c1, c3, c5, c1501]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p1501 F) (rfl))))
  · decide +kernel
def c2700 : CNF.Clause Nat := [(8,false), (74,false), (76,false), (98,false), (99,false), (33,false), (27,false), (15,false), (39,false)]
theorem p2700 (F : Frame G 3) : c2700.eval F.assign = true := by
  apply local_rup F.assign c2700 [c2, c1502]
  · exact sat_cons (p2 F) ( sat_cons (p1502 F) (rfl))
  · decide +kernel
end Cert35Steps
end Graffiti199Depleted.Catalogue.OrderEleven
