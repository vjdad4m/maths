import LocalRup
namespace Graffiti199Depleted.Catalogue.OrderEleven
namespace Cert44Steps
open Std.Sat
set_option maxRecDepth 4096
set_option maxHeartbeats 0
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj]
def c1 : CNF.Clause Nat := [(4,true)]
theorem p1 (F : Frame G 4) : c1.eval F.assign = true := by
  exact Rule.sound F (.matched true 0 3) (by decide +kernel)
def c2 : CNF.Clause Nat := [(16,true)]
theorem p2 (F : Frame G 4) : c2.eval F.assign = true := by
  exact Rule.sound F (.matched true 1 4) (by decide +kernel)
def c3 : CNF.Clause Nat := [(28,true)]
theorem p3 (F : Frame G 4) : c3.eval F.assign = true := by
  exact Rule.sound F (.matched true 2 5) (by decide +kernel)
def c4 : CNF.Clause Nat := [(8,true)]
theorem p4 (F : Frame G 4) : c4.eval F.assign = true := by
  exact Rule.sound F (.matched false 0 7) (by decide +kernel)
def c5 : CNF.Clause Nat := [(20,true)]
theorem p5 (F : Frame G 4) : c5.eval F.assign = true := by
  exact Rule.sound F (.matched false 1 8) (by decide +kernel)
def c6 : CNF.Clause Nat := [(32,true)]
theorem p6 (F : Frame G 4) : c6.eval F.assign = true := by
  exact Rule.sound F (.matched false 2 9) (by decide +kernel)
def c7 : CNF.Clause Nat := [(26,true), (38,true), (39,true), (40,true)]
theorem p7 (F : Frame G 4) : c7.eval F.assign = true := by
  exact Rule.sound F (.degree 3 [0, 1]) (by decide +kernel)
def c8 : CNF.Clause Nat := [(15,true), (26,true), (39,true), (40,true)]
theorem p8 (F : Frame G 4) : c8.eval F.assign = true := by
  exact Rule.sound F (.degree 3 [0, 4]) (by decide +kernel)
def c9 : CNF.Clause Nat := [(15,true), (26,true), (38,true), (40,true)]
theorem p9 (F : Frame G 4) : c9.eval F.assign = true := by
  exact Rule.sound F (.degree 3 [0, 5]) (by decide +kernel)
def c10 : CNF.Clause Nat := [(15,true), (26,true), (38,true), (39,true)]
theorem p10 (F : Frame G 4) : c10.eval F.assign = true := by
  exact Rule.sound F (.degree 3 [0, 6]) (by decide +kernel)
def c11 : CNF.Clause Nat := [(5,true), (38,true), (50,true), (51,true)]
theorem p11 (F : Frame G 4) : c11.eval F.assign = true := by
  exact Rule.sound F (.degree 4 [1, 2]) (by decide +kernel)
def c12 : CNF.Clause Nat := [(5,true), (27,true), (50,true), (51,true)]
theorem p12 (F : Frame G 4) : c12.eval F.assign = true := by
  exact Rule.sound F (.degree 4 [1, 3]) (by decide +kernel)
def c13 : CNF.Clause Nat := [(5,true), (27,true), (38,true), (51,true)]
theorem p13 (F : Frame G 4) : c13.eval F.assign = true := by
  exact Rule.sound F (.degree 4 [1, 5]) (by decide +kernel)
def c14 : CNF.Clause Nat := [(5,true), (27,true), (38,true), (50,true)]
theorem p14 (F : Frame G 4) : c14.eval F.assign = true := by
  exact Rule.sound F (.degree 4 [1, 6]) (by decide +kernel)
def c15 : CNF.Clause Nat := [(6,true), (17,true), (50,true), (62,true)]
theorem p15 (F : Frame G 4) : c15.eval F.assign = true := by
  exact Rule.sound F (.degree 5 [2, 3]) (by decide +kernel)
def c16 : CNF.Clause Nat := [(6,true), (17,true), (39,true), (62,true)]
theorem p16 (F : Frame G 4) : c16.eval F.assign = true := by
  exact Rule.sound F (.degree 5 [2, 4]) (by decide +kernel)
def c17 : CNF.Clause Nat := [(6,true), (17,true), (39,true), (50,true)]
theorem p17 (F : Frame G 4) : c17.eval F.assign = true := by
  exact Rule.sound F (.degree 5 [2, 6]) (by decide +kernel)
def c18 : CNF.Clause Nat := [(18,true), (29,true), (51,true), (62,true)]
theorem p18 (F : Frame G 4) : c18.eval F.assign = true := by
  exact Rule.sound F (.degree 6 [0, 3]) (by decide +kernel)
def c19 : CNF.Clause Nat := [(18,true), (29,true), (40,true), (62,true)]
theorem p19 (F : Frame G 4) : c19.eval F.assign = true := by
  exact Rule.sound F (.degree 6 [0, 4]) (by decide +kernel)
def c20 : CNF.Clause Nat := [(18,true), (29,true), (40,true), (51,true)]
theorem p20 (F : Frame G 4) : c20.eval F.assign = true := by
  exact Rule.sound F (.degree 6 [0, 5]) (by decide +kernel)
def c21 : CNF.Clause Nat := [(7,true), (29,true), (51,true), (62,true)]
theorem p21 (F : Frame G 4) : c21.eval F.assign = true := by
  exact Rule.sound F (.degree 6 [1, 3]) (by decide +kernel)
def c22 : CNF.Clause Nat := [(7,true), (29,true), (40,true), (62,true)]
theorem p22 (F : Frame G 4) : c22.eval F.assign = true := by
  exact Rule.sound F (.degree 6 [1, 4]) (by decide +kernel)
def c23 : CNF.Clause Nat := [(7,true), (29,true), (40,true), (51,true)]
theorem p23 (F : Frame G 4) : c23.eval F.assign = true := by
  exact Rule.sound F (.degree 6 [1, 5]) (by decide +kernel)
def c24 : CNF.Clause Nat := [(7,true), (18,true), (51,true), (62,true)]
theorem p24 (F : Frame G 4) : c24.eval F.assign = true := by
  exact Rule.sound F (.degree 6 [2, 3]) (by decide +kernel)
def c25 : CNF.Clause Nat := [(7,true), (18,true), (40,true), (62,true)]
theorem p25 (F : Frame G 4) : c25.eval F.assign = true := by
  exact Rule.sound F (.degree 6 [2, 4]) (by decide +kernel)
def c26 : CNF.Clause Nat := [(7,true), (18,true), (40,true), (51,true)]
theorem p26 (F : Frame G 4) : c26.eval F.assign = true := by
  exact Rule.sound F (.degree 6 [2, 5]) (by decide +kernel)
def c27 : CNF.Clause Nat := [(7,true), (18,true), (29,true), (62,true)]
theorem p27 (F : Frame G 4) : c27.eval F.assign = true := by
  exact Rule.sound F (.degree 6 [3, 4]) (by decide +kernel)
def c28 : CNF.Clause Nat := [(7,true), (18,true), (29,true), (51,true)]
theorem p28 (F : Frame G 4) : c28.eval F.assign = true := by
  exact Rule.sound F (.degree 6 [3, 5]) (by decide +kernel)
def c29 : CNF.Clause Nat := [(7,true), (18,true), (29,true), (40,true)]
theorem p29 (F : Frame G 4) : c29.eval F.assign = true := by
  exact Rule.sound F (.degree 6 [4, 5]) (by decide +kernel)
def c30 : CNF.Clause Nat := [(38,false), (26,true), (39,true), (40,true), (5,true), (27,true), (51,true)]
theorem p30 (F : Frame G 4) : c30.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 4 [0, 1, 4] [1, 3, 5]) (by decide +kernel)
def c31 : CNF.Clause Nat := [(38,false), (26,true), (39,true), (40,true), (5,true), (27,true), (50,true)]
theorem p31 (F : Frame G 4) : c31.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 4 [0, 1, 4] [1, 3, 6]) (by decide +kernel)
def c32 : CNF.Clause Nat := [(38,false), (15,true), (39,true), (40,true), (5,true), (27,true), (51,true)]
theorem p32 (F : Frame G 4) : c32.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 4 [0, 2, 4] [1, 3, 5]) (by decide +kernel)
def c33 : CNF.Clause Nat := [(38,false), (15,true), (39,true), (40,true), (5,true), (27,true), (50,true)]
theorem p33 (F : Frame G 4) : c33.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 4 [0, 2, 4] [1, 3, 6]) (by decide +kernel)
def c34 : CNF.Clause Nat := [(38,false), (15,true), (26,true), (40,true), (27,true), (50,true), (51,true)]
theorem p34 (F : Frame G 4) : c34.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 4 [0, 4, 5] [0, 1, 3]) (by decide +kernel)
def c35 : CNF.Clause Nat := [(38,false), (15,true), (26,true), (40,true), (5,true), (50,true), (51,true)]
theorem p35 (F : Frame G 4) : c35.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 4 [0, 4, 5] [1, 2, 3]) (by decide +kernel)
def c36 : CNF.Clause Nat := [(38,false), (15,true), (26,true), (40,true), (5,true), (27,true), (51,true)]
theorem p36 (F : Frame G 4) : c36.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 4 [0, 4, 5] [1, 3, 5]) (by decide +kernel)
def c37 : CNF.Clause Nat := [(38,false), (15,true), (26,true), (39,true), (5,true), (50,true), (51,true)]
theorem p37 (F : Frame G 4) : c37.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 4 [0, 4, 6] [1, 2, 3]) (by decide +kernel)
def c38 : CNF.Clause Nat := [(38,false), (15,true), (26,true), (39,true), (5,true), (27,true), (51,true)]
theorem p38 (F : Frame G 4) : c38.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 4 [0, 4, 6] [1, 3, 5]) (by decide +kernel)
def c39 : CNF.Clause Nat := [(38,false), (15,true), (26,true), (39,true), (5,true), (27,true), (50,true)]
theorem p39 (F : Frame G 4) : c39.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 4 [0, 4, 6] [1, 3, 6]) (by decide +kernel)
def c40 : CNF.Clause Nat := [(39,false), (26,true), (38,true), (40,true), (6,true), (17,true), (62,true)]
theorem p40 (F : Frame G 4) : c40.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 5 [0, 1, 5] [2, 3, 4]) (by decide +kernel)
def c41 : CNF.Clause Nat := [(39,false), (26,true), (38,true), (40,true), (6,true), (17,true), (50,true)]
theorem p41 (F : Frame G 4) : c41.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 5 [0, 1, 5] [2, 3, 6]) (by decide +kernel)
def c42 : CNF.Clause Nat := [(39,false), (15,true), (38,true), (40,true), (6,true), (17,true), (62,true)]
theorem p42 (F : Frame G 4) : c42.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 5 [0, 2, 5] [2, 3, 4]) (by decide +kernel)
def c43 : CNF.Clause Nat := [(39,false), (15,true), (38,true), (40,true), (6,true), (17,true), (50,true)]
theorem p43 (F : Frame G 4) : c43.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 5 [0, 2, 5] [2, 3, 6]) (by decide +kernel)
def c44 : CNF.Clause Nat := [(39,false), (15,true), (26,true), (40,true), (6,true), (50,true), (62,true)]
theorem p44 (F : Frame G 4) : c44.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 5 [0, 4, 5] [1, 2, 3]) (by decide +kernel)
def c45 : CNF.Clause Nat := [(39,false), (15,true), (26,true), (40,true), (6,true), (17,true), (62,true)]
theorem p45 (F : Frame G 4) : c45.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 5 [0, 4, 5] [2, 3, 4]) (by decide +kernel)
def c46 : CNF.Clause Nat := [(39,false), (15,true), (26,true), (38,true), (17,true), (50,true), (62,true)]
theorem p46 (F : Frame G 4) : c46.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 5 [0, 5, 6] [0, 2, 3]) (by decide +kernel)
def c47 : CNF.Clause Nat := [(39,false), (15,true), (26,true), (38,true), (6,true), (50,true), (62,true)]
theorem p47 (F : Frame G 4) : c47.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 5 [0, 5, 6] [1, 2, 3]) (by decide +kernel)
def c48 : CNF.Clause Nat := [(39,false), (15,true), (26,true), (38,true), (6,true), (17,true), (62,true)]
theorem p48 (F : Frame G 4) : c48.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 5 [0, 5, 6] [2, 3, 4]) (by decide +kernel)
def c49 : CNF.Clause Nat := [(40,false), (26,true), (38,true), (39,true), (18,true), (29,true), (62,true)]
theorem p49 (F : Frame G 4) : c49.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 1, 6] [0, 3, 4]) (by decide +kernel)
def c50 : CNF.Clause Nat := [(40,false), (26,true), (38,true), (39,true), (18,true), (29,true), (51,true)]
theorem p50 (F : Frame G 4) : c50.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 1, 6] [0, 3, 5]) (by decide +kernel)
def c51 : CNF.Clause Nat := [(40,false), (26,true), (38,true), (39,true), (7,true), (29,true), (62,true)]
theorem p51 (F : Frame G 4) : c51.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 1, 6] [1, 3, 4]) (by decide +kernel)
def c52 : CNF.Clause Nat := [(40,false), (26,true), (38,true), (39,true), (7,true), (29,true), (51,true)]
theorem p52 (F : Frame G 4) : c52.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 1, 6] [1, 3, 5]) (by decide +kernel)
def c53 : CNF.Clause Nat := [(40,false), (26,true), (38,true), (39,true), (7,true), (18,true), (62,true)]
theorem p53 (F : Frame G 4) : c53.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 1, 6] [2, 3, 4]) (by decide +kernel)
def c54 : CNF.Clause Nat := [(40,false), (26,true), (38,true), (39,true), (7,true), (18,true), (51,true)]
theorem p54 (F : Frame G 4) : c54.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 1, 6] [2, 3, 5]) (by decide +kernel)
def c55 : CNF.Clause Nat := [(40,false), (26,true), (38,true), (39,true), (7,true), (18,true), (29,true)]
theorem p55 (F : Frame G 4) : c55.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 1, 6] [3, 4, 5]) (by decide +kernel)
def c56 : CNF.Clause Nat := [(40,false), (15,true), (38,true), (39,true), (18,true), (29,true), (62,true)]
theorem p56 (F : Frame G 4) : c56.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 2, 6] [0, 3, 4]) (by decide +kernel)
def c57 : CNF.Clause Nat := [(40,false), (15,true), (38,true), (39,true), (18,true), (29,true), (51,true)]
theorem p57 (F : Frame G 4) : c57.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 2, 6] [0, 3, 5]) (by decide +kernel)
def c58 : CNF.Clause Nat := [(40,false), (15,true), (38,true), (39,true), (7,true), (29,true), (62,true)]
theorem p58 (F : Frame G 4) : c58.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 2, 6] [1, 3, 4]) (by decide +kernel)
def c59 : CNF.Clause Nat := [(40,false), (15,true), (38,true), (39,true), (7,true), (29,true), (51,true)]
theorem p59 (F : Frame G 4) : c59.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 2, 6] [1, 3, 5]) (by decide +kernel)
def c60 : CNF.Clause Nat := [(40,false), (15,true), (38,true), (39,true), (7,true), (18,true), (62,true)]
theorem p60 (F : Frame G 4) : c60.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 2, 6] [2, 3, 4]) (by decide +kernel)
def c61 : CNF.Clause Nat := [(40,false), (15,true), (38,true), (39,true), (7,true), (18,true), (29,true)]
theorem p61 (F : Frame G 4) : c61.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 2, 6] [3, 4, 5]) (by decide +kernel)
def c62 : CNF.Clause Nat := [(40,false), (15,true), (26,true), (39,true), (18,true), (51,true), (62,true)]
theorem p62 (F : Frame G 4) : c62.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 4, 6] [0, 2, 3]) (by decide +kernel)
def c63 : CNF.Clause Nat := [(40,false), (15,true), (26,true), (39,true), (18,true), (29,true), (62,true)]
theorem p63 (F : Frame G 4) : c63.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 4, 6] [0, 3, 4]) (by decide +kernel)
def c64 : CNF.Clause Nat := [(40,false), (15,true), (26,true), (39,true), (7,true), (51,true), (62,true)]
theorem p64 (F : Frame G 4) : c64.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 4, 6] [1, 2, 3]) (by decide +kernel)
def c65 : CNF.Clause Nat := [(40,false), (15,true), (26,true), (39,true), (7,true), (18,true), (62,true)]
theorem p65 (F : Frame G 4) : c65.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 4, 6] [2, 3, 4]) (by decide +kernel)
def c66 : CNF.Clause Nat := [(40,false), (15,true), (26,true), (39,true), (7,true), (18,true), (51,true)]
theorem p66 (F : Frame G 4) : c66.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 4, 6] [2, 3, 5]) (by decide +kernel)
def c67 : CNF.Clause Nat := [(40,false), (15,true), (26,true), (39,true), (7,true), (18,true), (29,true)]
theorem p67 (F : Frame G 4) : c67.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 4, 6] [3, 4, 5]) (by decide +kernel)
def c68 : CNF.Clause Nat := [(40,false), (15,true), (26,true), (38,true), (29,true), (51,true), (62,true)]
theorem p68 (F : Frame G 4) : c68.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 5, 6] [0, 1, 3]) (by decide +kernel)
def c69 : CNF.Clause Nat := [(40,false), (15,true), (26,true), (38,true), (18,true), (51,true), (62,true)]
theorem p69 (F : Frame G 4) : c69.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 5, 6] [0, 2, 3]) (by decide +kernel)
def c70 : CNF.Clause Nat := [(40,false), (15,true), (26,true), (38,true), (18,true), (29,true), (51,true)]
theorem p70 (F : Frame G 4) : c70.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 5, 6] [0, 3, 5]) (by decide +kernel)
def c71 : CNF.Clause Nat := [(40,false), (15,true), (26,true), (38,true), (7,true), (51,true), (62,true)]
theorem p71 (F : Frame G 4) : c71.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 5, 6] [1, 2, 3]) (by decide +kernel)
def c72 : CNF.Clause Nat := [(40,false), (15,true), (26,true), (38,true), (7,true), (29,true), (62,true)]
theorem p72 (F : Frame G 4) : c72.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 5, 6] [1, 3, 4]) (by decide +kernel)
def c73 : CNF.Clause Nat := [(40,false), (15,true), (26,true), (38,true), (7,true), (29,true), (51,true)]
theorem p73 (F : Frame G 4) : c73.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 5, 6] [1, 3, 5]) (by decide +kernel)
def c74 : CNF.Clause Nat := [(40,false), (15,true), (26,true), (38,true), (7,true), (18,true), (62,true)]
theorem p74 (F : Frame G 4) : c74.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 5, 6] [2, 3, 4]) (by decide +kernel)
def c75 : CNF.Clause Nat := [(40,false), (15,true), (26,true), (38,true), (7,true), (18,true), (51,true)]
theorem p75 (F : Frame G 4) : c75.eval F.assign = true := by
  exact Rule.sound F (.cubic 3 6 [0, 5, 6] [2, 3, 5]) (by decide +kernel)
def c76 : CNF.Clause Nat := [(50,false), (27,true), (38,true), (51,true), (6,true), (39,true), (62,true)]
theorem p76 (F : Frame G 4) : c76.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 5 [0, 1, 5] [1, 2, 4]) (by decide +kernel)
def c77 : CNF.Clause Nat := [(50,false), (27,true), (38,true), (51,true), (6,true), (17,true), (62,true)]
theorem p77 (F : Frame G 4) : c77.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 5 [0, 1, 5] [2, 3, 4]) (by decide +kernel)
def c78 : CNF.Clause Nat := [(50,false), (5,true), (38,true), (51,true), (6,true), (17,true), (62,true)]
theorem p78 (F : Frame G 4) : c78.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 5 [1, 2, 5] [2, 3, 4]) (by decide +kernel)
def c79 : CNF.Clause Nat := [(50,false), (5,true), (38,true), (51,true), (6,true), (17,true), (39,true)]
theorem p79 (F : Frame G 4) : c79.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 5 [1, 2, 5] [2, 4, 6]) (by decide +kernel)
def c80 : CNF.Clause Nat := [(50,false), (5,true), (27,true), (51,true), (17,true), (39,true), (62,true)]
theorem p80 (F : Frame G 4) : c80.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 5 [1, 3, 5] [0, 2, 4]) (by decide +kernel)
def c81 : CNF.Clause Nat := [(50,false), (5,true), (27,true), (51,true), (6,true), (39,true), (62,true)]
theorem p81 (F : Frame G 4) : c81.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 5 [1, 3, 5] [1, 2, 4]) (by decide +kernel)
def c82 : CNF.Clause Nat := [(50,false), (5,true), (27,true), (51,true), (6,true), (17,true), (62,true)]
theorem p82 (F : Frame G 4) : c82.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 5 [1, 3, 5] [2, 3, 4]) (by decide +kernel)
def c83 : CNF.Clause Nat := [(50,false), (5,true), (27,true), (51,true), (6,true), (17,true), (39,true)]
theorem p83 (F : Frame G 4) : c83.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 5 [1, 3, 5] [2, 4, 6]) (by decide +kernel)
def c84 : CNF.Clause Nat := [(50,false), (5,true), (27,true), (38,true), (17,true), (39,true), (62,true)]
theorem p84 (F : Frame G 4) : c84.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 5 [1, 5, 6] [0, 2, 4]) (by decide +kernel)
def c85 : CNF.Clause Nat := [(50,false), (5,true), (27,true), (38,true), (6,true), (39,true), (62,true)]
theorem p85 (F : Frame G 4) : c85.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 5 [1, 5, 6] [1, 2, 4]) (by decide +kernel)
def c86 : CNF.Clause Nat := [(50,false), (5,true), (27,true), (38,true), (6,true), (17,true), (62,true)]
theorem p86 (F : Frame G 4) : c86.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 5 [1, 5, 6] [2, 3, 4]) (by decide +kernel)
def c87 : CNF.Clause Nat := [(50,false), (5,true), (27,true), (38,true), (6,true), (17,true), (39,true)]
theorem p87 (F : Frame G 4) : c87.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 5 [1, 5, 6] [2, 4, 6]) (by decide +kernel)
def c88 : CNF.Clause Nat := [(51,false), (27,true), (38,true), (50,true), (18,true), (29,true), (62,true)]
theorem p88 (F : Frame G 4) : c88.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 6 [0, 1, 6] [0, 3, 4]) (by decide +kernel)
def c89 : CNF.Clause Nat := [(51,false), (27,true), (38,true), (50,true), (18,true), (29,true), (40,true)]
theorem p89 (F : Frame G 4) : c89.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 6 [0, 1, 6] [0, 4, 5]) (by decide +kernel)
def c90 : CNF.Clause Nat := [(51,false), (27,true), (38,true), (50,true), (7,true), (29,true), (62,true)]
theorem p90 (F : Frame G 4) : c90.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 6 [0, 1, 6] [1, 3, 4]) (by decide +kernel)
def c91 : CNF.Clause Nat := [(51,false), (27,true), (38,true), (50,true), (7,true), (29,true), (40,true)]
theorem p91 (F : Frame G 4) : c91.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 6 [0, 1, 6] [1, 4, 5]) (by decide +kernel)
def c92 : CNF.Clause Nat := [(51,false), (27,true), (38,true), (50,true), (7,true), (18,true), (62,true)]
theorem p92 (F : Frame G 4) : c92.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 6 [0, 1, 6] [2, 3, 4]) (by decide +kernel)
def c93 : CNF.Clause Nat := [(51,false), (27,true), (38,true), (50,true), (7,true), (18,true), (40,true)]
theorem p93 (F : Frame G 4) : c93.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 6 [0, 1, 6] [2, 4, 5]) (by decide +kernel)
def c94 : CNF.Clause Nat := [(51,false), (5,true), (38,true), (50,true), (18,true), (29,true), (62,true)]
theorem p94 (F : Frame G 4) : c94.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 6 [1, 2, 6] [0, 3, 4]) (by decide +kernel)
def c95 : CNF.Clause Nat := [(51,false), (5,true), (38,true), (50,true), (7,true), (29,true), (62,true)]
theorem p95 (F : Frame G 4) : c95.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 6 [1, 2, 6] [1, 3, 4]) (by decide +kernel)
def c96 : CNF.Clause Nat := [(51,false), (5,true), (38,true), (50,true), (7,true), (29,true), (40,true)]
theorem p96 (F : Frame G 4) : c96.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 6 [1, 2, 6] [1, 4, 5]) (by decide +kernel)
def c97 : CNF.Clause Nat := [(51,false), (5,true), (38,true), (50,true), (7,true), (18,true), (62,true)]
theorem p97 (F : Frame G 4) : c97.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 6 [1, 2, 6] [2, 3, 4]) (by decide +kernel)
def c98 : CNF.Clause Nat := [(51,false), (5,true), (38,true), (50,true), (7,true), (18,true), (40,true)]
theorem p98 (F : Frame G 4) : c98.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 6 [1, 2, 6] [2, 4, 5]) (by decide +kernel)
def c99 : CNF.Clause Nat := [(51,false), (5,true), (38,true), (50,true), (7,true), (18,true), (29,true)]
theorem p99 (F : Frame G 4) : c99.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 6 [1, 2, 6] [3, 4, 5]) (by decide +kernel)
def c100 : CNF.Clause Nat := [(51,false), (5,true), (27,true), (50,true), (29,true), (40,true), (62,true)]
theorem p100 (F : Frame G 4) : c100.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 6 [1, 3, 6] [0, 1, 4]) (by decide +kernel)
def c101 : CNF.Clause Nat := [(51,false), (5,true), (27,true), (50,true), (18,true), (40,true), (62,true)]
theorem p101 (F : Frame G 4) : c101.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 6 [1, 3, 6] [0, 2, 4]) (by decide +kernel)
def c102 : CNF.Clause Nat := [(51,false), (5,true), (27,true), (50,true), (18,true), (29,true), (62,true)]
theorem p102 (F : Frame G 4) : c102.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 6 [1, 3, 6] [0, 3, 4]) (by decide +kernel)
def c103 : CNF.Clause Nat := [(51,false), (5,true), (27,true), (50,true), (7,true), (40,true), (62,true)]
theorem p103 (F : Frame G 4) : c103.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 6 [1, 3, 6] [1, 2, 4]) (by decide +kernel)
def c104 : CNF.Clause Nat := [(51,false), (5,true), (27,true), (50,true), (7,true), (29,true), (62,true)]
theorem p104 (F : Frame G 4) : c104.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 6 [1, 3, 6] [1, 3, 4]) (by decide +kernel)
def c105 : CNF.Clause Nat := [(51,false), (5,true), (27,true), (50,true), (7,true), (29,true), (40,true)]
theorem p105 (F : Frame G 4) : c105.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 6 [1, 3, 6] [1, 4, 5]) (by decide +kernel)
def c106 : CNF.Clause Nat := [(51,false), (5,true), (27,true), (50,true), (7,true), (18,true), (62,true)]
theorem p106 (F : Frame G 4) : c106.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 6 [1, 3, 6] [2, 3, 4]) (by decide +kernel)
def c107 : CNF.Clause Nat := [(51,false), (5,true), (27,true), (50,true), (7,true), (18,true), (40,true)]
theorem p107 (F : Frame G 4) : c107.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 6 [1, 3, 6] [2, 4, 5]) (by decide +kernel)
def c108 : CNF.Clause Nat := [(51,false), (5,true), (27,true), (38,true), (29,true), (40,true), (62,true)]
theorem p108 (F : Frame G 4) : c108.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 6 [1, 5, 6] [0, 1, 4]) (by decide +kernel)
def c109 : CNF.Clause Nat := [(51,false), (5,true), (27,true), (38,true), (7,true), (40,true), (62,true)]
theorem p109 (F : Frame G 4) : c109.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 6 [1, 5, 6] [1, 2, 4]) (by decide +kernel)
def c110 : CNF.Clause Nat := [(51,false), (5,true), (27,true), (38,true), (7,true), (29,true), (62,true)]
theorem p110 (F : Frame G 4) : c110.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 6 [1, 5, 6] [1, 3, 4]) (by decide +kernel)
def c111 : CNF.Clause Nat := [(51,false), (5,true), (27,true), (38,true), (7,true), (29,true), (40,true)]
theorem p111 (F : Frame G 4) : c111.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 6 [1, 5, 6] [1, 4, 5]) (by decide +kernel)
def c112 : CNF.Clause Nat := [(51,false), (5,true), (27,true), (38,true), (7,true), (18,true), (29,true)]
theorem p112 (F : Frame G 4) : c112.eval F.assign = true := by
  exact Rule.sound F (.cubic 4 6 [1, 5, 6] [3, 4, 5]) (by decide +kernel)
def c113 : CNF.Clause Nat := [(62,false), (17,true), (39,true), (50,true), (18,true), (29,true), (51,true)]
theorem p113 (F : Frame G 4) : c113.eval F.assign = true := by
  exact Rule.sound F (.cubic 5 6 [0, 2, 6] [0, 3, 5]) (by decide +kernel)
def c114 : CNF.Clause Nat := [(62,false), (17,true), (39,true), (50,true), (7,true), (29,true), (40,true)]
theorem p114 (F : Frame G 4) : c114.eval F.assign = true := by
  exact Rule.sound F (.cubic 5 6 [0, 2, 6] [1, 4, 5]) (by decide +kernel)
def c115 : CNF.Clause Nat := [(62,false), (17,true), (39,true), (50,true), (7,true), (18,true), (51,true)]
theorem p115 (F : Frame G 4) : c115.eval F.assign = true := by
  exact Rule.sound F (.cubic 5 6 [0, 2, 6] [2, 3, 5]) (by decide +kernel)
def c116 : CNF.Clause Nat := [(62,false), (17,true), (39,true), (50,true), (7,true), (18,true), (40,true)]
theorem p116 (F : Frame G 4) : c116.eval F.assign = true := by
  exact Rule.sound F (.cubic 5 6 [0, 2, 6] [2, 4, 5]) (by decide +kernel)
def c117 : CNF.Clause Nat := [(62,false), (6,true), (39,true), (50,true), (18,true), (29,true), (51,true)]
theorem p117 (F : Frame G 4) : c117.eval F.assign = true := by
  exact Rule.sound F (.cubic 5 6 [1, 2, 6] [0, 3, 5]) (by decide +kernel)
def c118 : CNF.Clause Nat := [(62,false), (6,true), (39,true), (50,true), (7,true), (29,true), (51,true)]
theorem p118 (F : Frame G 4) : c118.eval F.assign = true := by
  exact Rule.sound F (.cubic 5 6 [1, 2, 6] [1, 3, 5]) (by decide +kernel)
def c119 : CNF.Clause Nat := [(62,false), (6,true), (39,true), (50,true), (7,true), (29,true), (40,true)]
theorem p119 (F : Frame G 4) : c119.eval F.assign = true := by
  exact Rule.sound F (.cubic 5 6 [1, 2, 6] [1, 4, 5]) (by decide +kernel)
def c120 : CNF.Clause Nat := [(62,false), (6,true), (39,true), (50,true), (7,true), (18,true), (51,true)]
theorem p120 (F : Frame G 4) : c120.eval F.assign = true := by
  exact Rule.sound F (.cubic 5 6 [1, 2, 6] [2, 3, 5]) (by decide +kernel)
def c121 : CNF.Clause Nat := [(62,false), (6,true), (39,true), (50,true), (7,true), (18,true), (40,true)]
theorem p121 (F : Frame G 4) : c121.eval F.assign = true := by
  exact Rule.sound F (.cubic 5 6 [1, 2, 6] [2, 4, 5]) (by decide +kernel)
def c122 : CNF.Clause Nat := [(62,false), (6,true), (39,true), (50,true), (7,true), (18,true), (29,true)]
theorem p122 (F : Frame G 4) : c122.eval F.assign = true := by
  exact Rule.sound F (.cubic 5 6 [1, 2, 6] [3, 4, 5]) (by decide +kernel)
def c123 : CNF.Clause Nat := [(62,false), (6,true), (17,true), (50,true), (18,true), (40,true), (51,true)]
theorem p123 (F : Frame G 4) : c123.eval F.assign = true := by
  exact Rule.sound F (.cubic 5 6 [2, 3, 6] [0, 2, 5]) (by decide +kernel)
def c124 : CNF.Clause Nat := [(62,false), (6,true), (17,true), (50,true), (18,true), (29,true), (51,true)]
theorem p124 (F : Frame G 4) : c124.eval F.assign = true := by
  exact Rule.sound F (.cubic 5 6 [2, 3, 6] [0, 3, 5]) (by decide +kernel)
def c125 : CNF.Clause Nat := [(62,false), (6,true), (17,true), (50,true), (7,true), (40,true), (51,true)]
theorem p125 (F : Frame G 4) : c125.eval F.assign = true := by
  exact Rule.sound F (.cubic 5 6 [2, 3, 6] [1, 2, 5]) (by decide +kernel)
def c126 : CNF.Clause Nat := [(62,false), (6,true), (17,true), (50,true), (7,true), (29,true), (51,true)]
theorem p126 (F : Frame G 4) : c126.eval F.assign = true := by
  exact Rule.sound F (.cubic 5 6 [2, 3, 6] [1, 3, 5]) (by decide +kernel)
def c127 : CNF.Clause Nat := [(62,false), (6,true), (17,true), (50,true), (7,true), (18,true), (51,true)]
theorem p127 (F : Frame G 4) : c127.eval F.assign = true := by
  exact Rule.sound F (.cubic 5 6 [2, 3, 6] [2, 3, 5]) (by decide +kernel)
def c128 : CNF.Clause Nat := [(62,false), (6,true), (17,true), (50,true), (7,true), (18,true), (40,true)]
theorem p128 (F : Frame G 4) : c128.eval F.assign = true := by
  exact Rule.sound F (.cubic 5 6 [2, 3, 6] [2, 4, 5]) (by decide +kernel)
def c129 : CNF.Clause Nat := [(62,false), (6,true), (17,true), (39,true), (18,true), (29,true), (40,true)]
theorem p129 (F : Frame G 4) : c129.eval F.assign = true := by
  exact Rule.sound F (.cubic 5 6 [2, 4, 6] [0, 4, 5]) (by decide +kernel)
def c130 : CNF.Clause Nat := [(62,false), (6,true), (17,true), (39,true), (7,true), (40,true), (51,true)]
theorem p130 (F : Frame G 4) : c130.eval F.assign = true := by
  exact Rule.sound F (.cubic 5 6 [2, 4, 6] [1, 2, 5]) (by decide +kernel)
def c131 : CNF.Clause Nat := [(62,false), (6,true), (17,true), (39,true), (7,true), (29,true), (40,true)]
theorem p131 (F : Frame G 4) : c131.eval F.assign = true := by
  exact Rule.sound F (.cubic 5 6 [2, 4, 6] [1, 4, 5]) (by decide +kernel)
def c132 : CNF.Clause Nat := [(62,false), (6,true), (17,true), (39,true), (7,true), (18,true), (51,true)]
theorem p132 (F : Frame G 4) : c132.eval F.assign = true := by
  exact Rule.sound F (.cubic 5 6 [2, 4, 6] [2, 3, 5]) (by decide +kernel)
def c133 : CNF.Clause Nat := [(62,false), (6,true), (17,true), (39,true), (7,true), (18,true), (40,true)]
theorem p133 (F : Frame G 4) : c133.eval F.assign = true := by
  exact Rule.sound F (.cubic 5 6 [2, 4, 6] [2, 4, 5]) (by decide +kernel)
def c134 : CNF.Clause Nat := [(38,true), (39,true), (40,true)]
theorem p134 (F : Frame G 4) : c134.eval F.assign = true := by
  exact Rule.sound F (.connected true [3]) (by decide +kernel)
def c135 : CNF.Clause Nat := [(39,true), (40,true), (50,true), (51,true)]
theorem p135 (F : Frame G 4) : c135.eval F.assign = true := by
  exact Rule.sound F (.connected true [3, 4]) (by decide +kernel)
def c136 : CNF.Clause Nat := [(38,true), (40,true), (50,true), (62,true)]
theorem p136 (F : Frame G 4) : c136.eval F.assign = true := by
  exact Rule.sound F (.connected true [3, 5]) (by decide +kernel)
def c137 : CNF.Clause Nat := [(38,true), (39,true), (51,true), (62,true)]
theorem p137 (F : Frame G 4) : c137.eval F.assign = true := by
  exact Rule.sound F (.connected true [3, 6]) (by decide +kernel)
def c138 : CNF.Clause Nat := [(40,true), (51,true), (62,true)]
theorem p138 (F : Frame G 4) : c138.eval F.assign = true := by
  exact Rule.sound F (.connected true [3, 4, 5]) (by decide +kernel)
def c139 : CNF.Clause Nat := [(39,true), (50,true), (62,true)]
theorem p139 (F : Frame G 4) : c139.eval F.assign = true := by
  exact Rule.sound F (.connected true [3, 4, 6]) (by decide +kernel)
def c140 : CNF.Clause Nat := [(38,true), (50,true), (51,true)]
theorem p140 (F : Frame G 4) : c140.eval F.assign = true := by
  exact Rule.sound F (.connected true [3, 5, 6]) (by decide +kernel)
def c141 : CNF.Clause Nat := [(30,true), (86,true), (87,true), (88,true)]
theorem p141 (F : Frame G 4) : c141.eval F.assign = true := by
  exact Rule.sound F (.degree 7 [0, 1]) (by decide +kernel)
def c142 : CNF.Clause Nat := [(19,true), (30,true), (87,true), (88,true)]
theorem p142 (F : Frame G 4) : c142.eval F.assign = true := by
  exact Rule.sound F (.degree 7 [0, 8]) (by decide +kernel)
def c143 : CNF.Clause Nat := [(19,true), (30,true), (86,true), (88,true)]
theorem p143 (F : Frame G 4) : c143.eval F.assign = true := by
  exact Rule.sound F (.degree 7 [0, 9]) (by decide +kernel)
def c144 : CNF.Clause Nat := [(19,true), (30,true), (86,true), (87,true)]
theorem p144 (F : Frame G 4) : c144.eval F.assign = true := by
  exact Rule.sound F (.degree 7 [0, 10]) (by decide +kernel)
def c145 : CNF.Clause Nat := [(9,true), (31,true), (98,true), (99,true)]
theorem p145 (F : Frame G 4) : c145.eval F.assign = true := by
  exact Rule.sound F (.degree 8 [1, 7]) (by decide +kernel)
def c146 : CNF.Clause Nat := [(9,true), (31,true), (86,true), (99,true)]
theorem p146 (F : Frame G 4) : c146.eval F.assign = true := by
  exact Rule.sound F (.degree 8 [1, 9]) (by decide +kernel)
def c147 : CNF.Clause Nat := [(9,true), (31,true), (86,true), (98,true)]
theorem p147 (F : Frame G 4) : c147.eval F.assign = true := by
  exact Rule.sound F (.degree 8 [1, 10]) (by decide +kernel)
def c148 : CNF.Clause Nat := [(10,true), (21,true), (98,true), (110,true)]
theorem p148 (F : Frame G 4) : c148.eval F.assign = true := by
  exact Rule.sound F (.degree 9 [2, 7]) (by decide +kernel)
def c149 : CNF.Clause Nat := [(10,true), (21,true), (87,true), (110,true)]
theorem p149 (F : Frame G 4) : c149.eval F.assign = true := by
  exact Rule.sound F (.degree 9 [2, 8]) (by decide +kernel)
def c150 : CNF.Clause Nat := [(10,true), (21,true), (87,true), (98,true)]
theorem p150 (F : Frame G 4) : c150.eval F.assign = true := by
  exact Rule.sound F (.degree 9 [2, 10]) (by decide +kernel)
def c151 : CNF.Clause Nat := [(22,true), (88,true), (99,true), (110,true)]
theorem p151 (F : Frame G 4) : c151.eval F.assign = true := by
  exact Rule.sound F (.degree 10 [0, 2]) (by decide +kernel)
def c152 : CNF.Clause Nat := [(22,true), (33,true), (99,true), (110,true)]
theorem p152 (F : Frame G 4) : c152.eval F.assign = true := by
  exact Rule.sound F (.degree 10 [0, 7]) (by decide +kernel)
def c153 : CNF.Clause Nat := [(22,true), (33,true), (88,true), (110,true)]
theorem p153 (F : Frame G 4) : c153.eval F.assign = true := by
  exact Rule.sound F (.degree 10 [0, 8]) (by decide +kernel)
def c154 : CNF.Clause Nat := [(22,true), (33,true), (88,true), (99,true)]
theorem p154 (F : Frame G 4) : c154.eval F.assign = true := by
  exact Rule.sound F (.degree 10 [0, 9]) (by decide +kernel)
def c155 : CNF.Clause Nat := [(11,true), (33,true), (99,true), (110,true)]
theorem p155 (F : Frame G 4) : c155.eval F.assign = true := by
  exact Rule.sound F (.degree 10 [1, 7]) (by decide +kernel)
def c156 : CNF.Clause Nat := [(11,true), (33,true), (88,true), (110,true)]
theorem p156 (F : Frame G 4) : c156.eval F.assign = true := by
  exact Rule.sound F (.degree 10 [1, 8]) (by decide +kernel)
def c157 : CNF.Clause Nat := [(11,true), (33,true), (88,true), (99,true)]
theorem p157 (F : Frame G 4) : c157.eval F.assign = true := by
  exact Rule.sound F (.degree 10 [1, 9]) (by decide +kernel)
def c158 : CNF.Clause Nat := [(11,true), (22,true), (99,true), (110,true)]
theorem p158 (F : Frame G 4) : c158.eval F.assign = true := by
  exact Rule.sound F (.degree 10 [2, 7]) (by decide +kernel)
def c159 : CNF.Clause Nat := [(11,true), (22,true), (88,true), (110,true)]
theorem p159 (F : Frame G 4) : c159.eval F.assign = true := by
  exact Rule.sound F (.degree 10 [2, 8]) (by decide +kernel)
def c160 : CNF.Clause Nat := [(11,true), (22,true), (88,true), (99,true)]
theorem p160 (F : Frame G 4) : c160.eval F.assign = true := by
  exact Rule.sound F (.degree 10 [2, 9]) (by decide +kernel)
def c161 : CNF.Clause Nat := [(11,true), (22,true), (33,true), (110,true)]
theorem p161 (F : Frame G 4) : c161.eval F.assign = true := by
  exact Rule.sound F (.degree 10 [7, 8]) (by decide +kernel)
def c162 : CNF.Clause Nat := [(11,true), (22,true), (33,true), (99,true)]
theorem p162 (F : Frame G 4) : c162.eval F.assign = true := by
  exact Rule.sound F (.degree 10 [7, 9]) (by decide +kernel)
def c163 : CNF.Clause Nat := [(11,true), (22,true), (33,true), (88,true)]
theorem p163 (F : Frame G 4) : c163.eval F.assign = true := by
  exact Rule.sound F (.degree 10 [8, 9]) (by decide +kernel)
def c164 : CNF.Clause Nat := [(86,false), (30,true), (87,true), (88,true), (9,true), (31,true), (99,true)]
theorem p164 (F : Frame G 4) : c164.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 8 [0, 1, 8] [1, 7, 9]) (by decide +kernel)
def c165 : CNF.Clause Nat := [(86,false), (30,true), (87,true), (88,true), (9,true), (31,true), (98,true)]
theorem p165 (F : Frame G 4) : c165.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 8 [0, 1, 8] [1, 7, 10]) (by decide +kernel)
def c166 : CNF.Clause Nat := [(86,false), (19,true), (87,true), (88,true), (9,true), (31,true), (99,true)]
theorem p166 (F : Frame G 4) : c166.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 8 [0, 2, 8] [1, 7, 9]) (by decide +kernel)
def c167 : CNF.Clause Nat := [(86,false), (19,true), (87,true), (88,true), (9,true), (31,true), (98,true)]
theorem p167 (F : Frame G 4) : c167.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 8 [0, 2, 8] [1, 7, 10]) (by decide +kernel)
def c168 : CNF.Clause Nat := [(86,false), (19,true), (30,true), (88,true), (31,true), (98,true), (99,true)]
theorem p168 (F : Frame G 4) : c168.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 8 [0, 8, 9] [0, 1, 7]) (by decide +kernel)
def c169 : CNF.Clause Nat := [(86,false), (19,true), (30,true), (88,true), (9,true), (98,true), (99,true)]
theorem p169 (F : Frame G 4) : c169.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 8 [0, 8, 9] [1, 2, 7]) (by decide +kernel)
def c170 : CNF.Clause Nat := [(86,false), (19,true), (30,true), (87,true), (31,true), (98,true), (99,true)]
theorem p170 (F : Frame G 4) : c170.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 8 [0, 8, 10] [0, 1, 7]) (by decide +kernel)
def c171 : CNF.Clause Nat := [(86,false), (19,true), (30,true), (87,true), (9,true), (98,true), (99,true)]
theorem p171 (F : Frame G 4) : c171.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 8 [0, 8, 10] [1, 2, 7]) (by decide +kernel)
def c172 : CNF.Clause Nat := [(86,false), (19,true), (30,true), (87,true), (9,true), (31,true), (98,true)]
theorem p172 (F : Frame G 4) : c172.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 8 [0, 8, 10] [1, 7, 10]) (by decide +kernel)
def c173 : CNF.Clause Nat := [(87,false), (30,true), (86,true), (88,true), (10,true), (21,true), (110,true)]
theorem p173 (F : Frame G 4) : c173.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 9 [0, 1, 9] [2, 7, 8]) (by decide +kernel)
def c174 : CNF.Clause Nat := [(87,false), (30,true), (86,true), (88,true), (10,true), (21,true), (98,true)]
theorem p174 (F : Frame G 4) : c174.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 9 [0, 1, 9] [2, 7, 10]) (by decide +kernel)
def c175 : CNF.Clause Nat := [(87,false), (19,true), (86,true), (88,true), (10,true), (21,true), (110,true)]
theorem p175 (F : Frame G 4) : c175.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 9 [0, 2, 9] [2, 7, 8]) (by decide +kernel)
def c176 : CNF.Clause Nat := [(87,false), (19,true), (30,true), (88,true), (21,true), (98,true), (110,true)]
theorem p176 (F : Frame G 4) : c176.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 9 [0, 8, 9] [0, 2, 7]) (by decide +kernel)
def c177 : CNF.Clause Nat := [(87,false), (19,true), (30,true), (88,true), (10,true), (21,true), (110,true)]
theorem p177 (F : Frame G 4) : c177.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 9 [0, 8, 9] [2, 7, 8]) (by decide +kernel)
def c178 : CNF.Clause Nat := [(87,false), (19,true), (30,true), (88,true), (10,true), (21,true), (98,true)]
theorem p178 (F : Frame G 4) : c178.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 9 [0, 8, 9] [2, 7, 10]) (by decide +kernel)
def c179 : CNF.Clause Nat := [(87,false), (19,true), (30,true), (86,true), (21,true), (98,true), (110,true)]
theorem p179 (F : Frame G 4) : c179.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 9 [0, 9, 10] [0, 2, 7]) (by decide +kernel)
def c180 : CNF.Clause Nat := [(87,false), (19,true), (30,true), (86,true), (10,true), (21,true), (110,true)]
theorem p180 (F : Frame G 4) : c180.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 9 [0, 9, 10] [2, 7, 8]) (by decide +kernel)
def c181 : CNF.Clause Nat := [(87,false), (19,true), (30,true), (86,true), (10,true), (21,true), (98,true)]
theorem p181 (F : Frame G 4) : c181.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 9 [0, 9, 10] [2, 7, 10]) (by decide +kernel)
def c182 : CNF.Clause Nat := [(88,false), (30,true), (86,true), (87,true), (22,true), (33,true), (99,true)]
theorem p182 (F : Frame G 4) : c182.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 10 [0, 1, 10] [0, 7, 9]) (by decide +kernel)
def c183 : CNF.Clause Nat := [(88,false), (30,true), (86,true), (87,true), (11,true), (33,true), (110,true)]
theorem p183 (F : Frame G 4) : c183.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 10 [0, 1, 10] [1, 7, 8]) (by decide +kernel)
def c184 : CNF.Clause Nat := [(88,false), (30,true), (86,true), (87,true), (11,true), (33,true), (99,true)]
theorem p184 (F : Frame G 4) : c184.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 10 [0, 1, 10] [1, 7, 9]) (by decide +kernel)
def c185 : CNF.Clause Nat := [(88,false), (30,true), (86,true), (87,true), (11,true), (22,true), (99,true)]
theorem p185 (F : Frame G 4) : c185.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 10 [0, 1, 10] [2, 7, 9]) (by decide +kernel)
def c186 : CNF.Clause Nat := [(88,false), (19,true), (86,true), (87,true), (22,true), (33,true), (110,true)]
theorem p186 (F : Frame G 4) : c186.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 10 [0, 2, 10] [0, 7, 8]) (by decide +kernel)
def c187 : CNF.Clause Nat := [(88,false), (19,true), (86,true), (87,true), (22,true), (33,true), (99,true)]
theorem p187 (F : Frame G 4) : c187.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 10 [0, 2, 10] [0, 7, 9]) (by decide +kernel)
def c188 : CNF.Clause Nat := [(88,false), (19,true), (86,true), (87,true), (11,true), (33,true), (110,true)]
theorem p188 (F : Frame G 4) : c188.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 10 [0, 2, 10] [1, 7, 8]) (by decide +kernel)
def c189 : CNF.Clause Nat := [(88,false), (19,true), (86,true), (87,true), (11,true), (22,true), (110,true)]
theorem p189 (F : Frame G 4) : c189.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 10 [0, 2, 10] [2, 7, 8]) (by decide +kernel)
def c190 : CNF.Clause Nat := [(88,false), (19,true), (30,true), (87,true), (33,true), (99,true), (110,true)]
theorem p190 (F : Frame G 4) : c190.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 10 [0, 8, 10] [0, 1, 7]) (by decide +kernel)
def c191 : CNF.Clause Nat := [(88,false), (19,true), (30,true), (87,true), (22,true), (99,true), (110,true)]
theorem p191 (F : Frame G 4) : c191.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 10 [0, 8, 10] [0, 2, 7]) (by decide +kernel)
def c192 : CNF.Clause Nat := [(88,false), (19,true), (30,true), (87,true), (22,true), (33,true), (110,true)]
theorem p192 (F : Frame G 4) : c192.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 10 [0, 8, 10] [0, 7, 8]) (by decide +kernel)
def c193 : CNF.Clause Nat := [(88,false), (19,true), (30,true), (87,true), (22,true), (33,true), (99,true)]
theorem p193 (F : Frame G 4) : c193.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 10 [0, 8, 10] [0, 7, 9]) (by decide +kernel)
def c194 : CNF.Clause Nat := [(88,false), (19,true), (30,true), (87,true), (11,true), (99,true), (110,true)]
theorem p194 (F : Frame G 4) : c194.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 10 [0, 8, 10] [1, 2, 7]) (by decide +kernel)
def c195 : CNF.Clause Nat := [(88,false), (19,true), (30,true), (87,true), (11,true), (33,true), (110,true)]
theorem p195 (F : Frame G 4) : c195.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 10 [0, 8, 10] [1, 7, 8]) (by decide +kernel)
def c196 : CNF.Clause Nat := [(88,false), (19,true), (30,true), (87,true), (11,true), (22,true), (110,true)]
theorem p196 (F : Frame G 4) : c196.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 10 [0, 8, 10] [2, 7, 8]) (by decide +kernel)
def c197 : CNF.Clause Nat := [(88,false), (19,true), (30,true), (87,true), (11,true), (22,true), (33,true)]
theorem p197 (F : Frame G 4) : c197.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 10 [0, 8, 10] [7, 8, 9]) (by decide +kernel)
def c198 : CNF.Clause Nat := [(88,false), (19,true), (30,true), (86,true), (33,true), (99,true), (110,true)]
theorem p198 (F : Frame G 4) : c198.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 10 [0, 9, 10] [0, 1, 7]) (by decide +kernel)
def c199 : CNF.Clause Nat := [(88,false), (19,true), (30,true), (86,true), (22,true), (99,true), (110,true)]
theorem p199 (F : Frame G 4) : c199.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 10 [0, 9, 10] [0, 2, 7]) (by decide +kernel)
def c200 : CNF.Clause Nat := [(88,false), (19,true), (30,true), (86,true), (22,true), (33,true), (110,true)]
theorem p200 (F : Frame G 4) : c200.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 10 [0, 9, 10] [0, 7, 8]) (by decide +kernel)
def c201 : CNF.Clause Nat := [(88,false), (19,true), (30,true), (86,true), (22,true), (33,true), (99,true)]
theorem p201 (F : Frame G 4) : c201.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 10 [0, 9, 10] [0, 7, 9]) (by decide +kernel)
def c202 : CNF.Clause Nat := [(88,false), (19,true), (30,true), (86,true), (11,true), (99,true), (110,true)]
theorem p202 (F : Frame G 4) : c202.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 10 [0, 9, 10] [1, 2, 7]) (by decide +kernel)
def c203 : CNF.Clause Nat := [(88,false), (19,true), (30,true), (86,true), (11,true), (22,true), (110,true)]
theorem p203 (F : Frame G 4) : c203.eval F.assign = true := by
  exact Rule.sound F (.cubic 7 10 [0, 9, 10] [2, 7, 8]) (by decide +kernel)
def c204 : CNF.Clause Nat := [(98,false), (31,true), (86,true), (99,true), (10,true), (21,true), (110,true)]
theorem p204 (F : Frame G 4) : c204.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 9 [0, 1, 9] [2, 7, 8]) (by decide +kernel)
def c205 : CNF.Clause Nat := [(98,false), (31,true), (86,true), (99,true), (10,true), (21,true), (87,true)]
theorem p205 (F : Frame G 4) : c205.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 9 [0, 1, 9] [2, 8, 10]) (by decide +kernel)
def c206 : CNF.Clause Nat := [(98,false), (9,true), (86,true), (99,true), (10,true), (21,true), (110,true)]
theorem p206 (F : Frame G 4) : c206.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 9 [1, 2, 9] [2, 7, 8]) (by decide +kernel)
def c207 : CNF.Clause Nat := [(98,false), (9,true), (86,true), (99,true), (10,true), (21,true), (87,true)]
theorem p207 (F : Frame G 4) : c207.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 9 [1, 2, 9] [2, 8, 10]) (by decide +kernel)
def c208 : CNF.Clause Nat := [(98,false), (9,true), (31,true), (99,true), (10,true), (87,true), (110,true)]
theorem p208 (F : Frame G 4) : c208.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 9 [1, 7, 9] [1, 2, 8]) (by decide +kernel)
def c209 : CNF.Clause Nat := [(98,false), (9,true), (31,true), (86,true), (21,true), (87,true), (110,true)]
theorem p209 (F : Frame G 4) : c209.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 9 [1, 9, 10] [0, 2, 8]) (by decide +kernel)
def c210 : CNF.Clause Nat := [(98,false), (9,true), (31,true), (86,true), (10,true), (87,true), (110,true)]
theorem p210 (F : Frame G 4) : c210.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 9 [1, 9, 10] [1, 2, 8]) (by decide +kernel)
def c211 : CNF.Clause Nat := [(98,false), (9,true), (31,true), (86,true), (10,true), (21,true), (110,true)]
theorem p211 (F : Frame G 4) : c211.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 9 [1, 9, 10] [2, 7, 8]) (by decide +kernel)
def c212 : CNF.Clause Nat := [(98,false), (9,true), (31,true), (86,true), (10,true), (21,true), (87,true)]
theorem p212 (F : Frame G 4) : c212.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 9 [1, 9, 10] [2, 8, 10]) (by decide +kernel)
def c213 : CNF.Clause Nat := [(99,false), (31,true), (86,true), (98,true), (22,true), (33,true), (110,true)]
theorem p213 (F : Frame G 4) : c213.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 10 [0, 1, 10] [0, 7, 8]) (by decide +kernel)
def c214 : CNF.Clause Nat := [(99,false), (31,true), (86,true), (98,true), (22,true), (33,true), (88,true)]
theorem p214 (F : Frame G 4) : c214.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 10 [0, 1, 10] [0, 8, 9]) (by decide +kernel)
def c215 : CNF.Clause Nat := [(99,false), (31,true), (86,true), (98,true), (11,true), (33,true), (88,true)]
theorem p215 (F : Frame G 4) : c215.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 10 [0, 1, 10] [1, 8, 9]) (by decide +kernel)
def c216 : CNF.Clause Nat := [(99,false), (31,true), (86,true), (98,true), (11,true), (22,true), (110,true)]
theorem p216 (F : Frame G 4) : c216.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 10 [0, 1, 10] [2, 7, 8]) (by decide +kernel)
def c217 : CNF.Clause Nat := [(99,false), (9,true), (86,true), (98,true), (22,true), (33,true), (88,true)]
theorem p217 (F : Frame G 4) : c217.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 10 [1, 2, 10] [0, 8, 9]) (by decide +kernel)
def c218 : CNF.Clause Nat := [(99,false), (9,true), (86,true), (98,true), (11,true), (22,true), (88,true)]
theorem p218 (F : Frame G 4) : c218.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 10 [1, 2, 10] [2, 8, 9]) (by decide +kernel)
def c219 : CNF.Clause Nat := [(99,false), (9,true), (31,true), (98,true), (33,true), (88,true), (110,true)]
theorem p219 (F : Frame G 4) : c219.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 10 [1, 7, 10] [0, 1, 8]) (by decide +kernel)
def c220 : CNF.Clause Nat := [(99,false), (9,true), (31,true), (98,true), (22,true), (33,true), (110,true)]
theorem p220 (F : Frame G 4) : c220.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 10 [1, 7, 10] [0, 7, 8]) (by decide +kernel)
def c221 : CNF.Clause Nat := [(99,false), (9,true), (31,true), (98,true), (22,true), (33,true), (88,true)]
theorem p221 (F : Frame G 4) : c221.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 10 [1, 7, 10] [0, 8, 9]) (by decide +kernel)
def c222 : CNF.Clause Nat := [(99,false), (9,true), (31,true), (98,true), (11,true), (88,true), (110,true)]
theorem p222 (F : Frame G 4) : c222.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 10 [1, 7, 10] [1, 2, 8]) (by decide +kernel)
def c223 : CNF.Clause Nat := [(99,false), (9,true), (31,true), (98,true), (11,true), (33,true), (110,true)]
theorem p223 (F : Frame G 4) : c223.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 10 [1, 7, 10] [1, 7, 8]) (by decide +kernel)
def c224 : CNF.Clause Nat := [(99,false), (9,true), (31,true), (98,true), (11,true), (33,true), (88,true)]
theorem p224 (F : Frame G 4) : c224.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 10 [1, 7, 10] [1, 8, 9]) (by decide +kernel)
def c225 : CNF.Clause Nat := [(99,false), (9,true), (31,true), (98,true), (11,true), (22,true), (110,true)]
theorem p225 (F : Frame G 4) : c225.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 10 [1, 7, 10] [2, 7, 8]) (by decide +kernel)
def c226 : CNF.Clause Nat := [(99,false), (9,true), (31,true), (98,true), (11,true), (22,true), (88,true)]
theorem p226 (F : Frame G 4) : c226.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 10 [1, 7, 10] [2, 8, 9]) (by decide +kernel)
def c227 : CNF.Clause Nat := [(99,false), (9,true), (31,true), (98,true), (11,true), (22,true), (33,true)]
theorem p227 (F : Frame G 4) : c227.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 10 [1, 7, 10] [7, 8, 9]) (by decide +kernel)
def c228 : CNF.Clause Nat := [(99,false), (9,true), (31,true), (86,true), (33,true), (88,true), (110,true)]
theorem p228 (F : Frame G 4) : c228.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 10 [1, 9, 10] [0, 1, 8]) (by decide +kernel)
def c229 : CNF.Clause Nat := [(99,false), (9,true), (31,true), (86,true), (22,true), (88,true), (110,true)]
theorem p229 (F : Frame G 4) : c229.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 10 [1, 9, 10] [0, 2, 8]) (by decide +kernel)
def c230 : CNF.Clause Nat := [(99,false), (9,true), (31,true), (86,true), (22,true), (33,true), (110,true)]
theorem p230 (F : Frame G 4) : c230.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 10 [1, 9, 10] [0, 7, 8]) (by decide +kernel)
def c231 : CNF.Clause Nat := [(99,false), (9,true), (31,true), (86,true), (22,true), (33,true), (88,true)]
theorem p231 (F : Frame G 4) : c231.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 10 [1, 9, 10] [0, 8, 9]) (by decide +kernel)
def c232 : CNF.Clause Nat := [(99,false), (9,true), (31,true), (86,true), (11,true), (88,true), (110,true)]
theorem p232 (F : Frame G 4) : c232.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 10 [1, 9, 10] [1, 2, 8]) (by decide +kernel)
def c233 : CNF.Clause Nat := [(99,false), (9,true), (31,true), (86,true), (11,true), (33,true), (110,true)]
theorem p233 (F : Frame G 4) : c233.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 10 [1, 9, 10] [1, 7, 8]) (by decide +kernel)
def c234 : CNF.Clause Nat := [(99,false), (9,true), (31,true), (86,true), (11,true), (33,true), (88,true)]
theorem p234 (F : Frame G 4) : c234.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 10 [1, 9, 10] [1, 8, 9]) (by decide +kernel)
def c235 : CNF.Clause Nat := [(99,false), (9,true), (31,true), (86,true), (11,true), (22,true), (110,true)]
theorem p235 (F : Frame G 4) : c235.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 10 [1, 9, 10] [2, 7, 8]) (by decide +kernel)
def c236 : CNF.Clause Nat := [(99,false), (9,true), (31,true), (86,true), (11,true), (22,true), (88,true)]
theorem p236 (F : Frame G 4) : c236.eval F.assign = true := by
  exact Rule.sound F (.cubic 8 10 [1, 9, 10] [2, 8, 9]) (by decide +kernel)
def c237 : CNF.Clause Nat := [(110,false), (21,true), (87,true), (98,true), (22,true), (33,true), (99,true)]
theorem p237 (F : Frame G 4) : c237.eval F.assign = true := by
  exact Rule.sound F (.cubic 9 10 [0, 2, 10] [0, 7, 9]) (by decide +kernel)
def c238 : CNF.Clause Nat := [(110,false), (21,true), (87,true), (98,true), (22,true), (33,true), (88,true)]
theorem p238 (F : Frame G 4) : c238.eval F.assign = true := by
  exact Rule.sound F (.cubic 9 10 [0, 2, 10] [0, 8, 9]) (by decide +kernel)
def c239 : CNF.Clause Nat := [(110,false), (21,true), (87,true), (98,true), (11,true), (33,true), (88,true)]
theorem p239 (F : Frame G 4) : c239.eval F.assign = true := by
  exact Rule.sound F (.cubic 9 10 [0, 2, 10] [1, 8, 9]) (by decide +kernel)
def c240 : CNF.Clause Nat := [(110,false), (21,true), (87,true), (98,true), (11,true), (22,true), (99,true)]
theorem p240 (F : Frame G 4) : c240.eval F.assign = true := by
  exact Rule.sound F (.cubic 9 10 [0, 2, 10] [2, 7, 9]) (by decide +kernel)
def c241 : CNF.Clause Nat := [(110,false), (21,true), (87,true), (98,true), (11,true), (22,true), (88,true)]
theorem p241 (F : Frame G 4) : c241.eval F.assign = true := by
  exact Rule.sound F (.cubic 9 10 [0, 2, 10] [2, 8, 9]) (by decide +kernel)
def c242 : CNF.Clause Nat := [(110,false), (10,true), (87,true), (98,true), (22,true), (33,true), (88,true)]
theorem p242 (F : Frame G 4) : c242.eval F.assign = true := by
  exact Rule.sound F (.cubic 9 10 [1, 2, 10] [0, 8, 9]) (by decide +kernel)
def c243 : CNF.Clause Nat := [(110,false), (10,true), (87,true), (98,true), (11,true), (33,true), (99,true)]
theorem p243 (F : Frame G 4) : c243.eval F.assign = true := by
  exact Rule.sound F (.cubic 9 10 [1, 2, 10] [1, 7, 9]) (by decide +kernel)
def c244 : CNF.Clause Nat := [(110,false), (10,true), (87,true), (98,true), (11,true), (33,true), (88,true)]
theorem p244 (F : Frame G 4) : c244.eval F.assign = true := by
  exact Rule.sound F (.cubic 9 10 [1, 2, 10] [1, 8, 9]) (by decide +kernel)
def c245 : CNF.Clause Nat := [(110,false), (10,true), (87,true), (98,true), (11,true), (22,true), (99,true)]
theorem p245 (F : Frame G 4) : c245.eval F.assign = true := by
  exact Rule.sound F (.cubic 9 10 [1, 2, 10] [2, 7, 9]) (by decide +kernel)
def c246 : CNF.Clause Nat := [(110,false), (10,true), (87,true), (98,true), (11,true), (22,true), (88,true)]
theorem p246 (F : Frame G 4) : c246.eval F.assign = true := by
  exact Rule.sound F (.cubic 9 10 [1, 2, 10] [2, 8, 9]) (by decide +kernel)
def c247 : CNF.Clause Nat := [(110,false), (10,true), (87,true), (98,true), (11,true), (22,true), (33,true)]
theorem p247 (F : Frame G 4) : c247.eval F.assign = true := by
  exact Rule.sound F (.cubic 9 10 [1, 2, 10] [7, 8, 9]) (by decide +kernel)
def c248 : CNF.Clause Nat := [(110,false), (10,true), (21,true), (98,true), (33,true), (88,true), (99,true)]
theorem p248 (F : Frame G 4) : c248.eval F.assign = true := by
  exact Rule.sound F (.cubic 9 10 [2, 7, 10] [0, 1, 9]) (by decide +kernel)
def c249 : CNF.Clause Nat := [(110,false), (10,true), (21,true), (98,true), (22,true), (88,true), (99,true)]
theorem p249 (F : Frame G 4) : c249.eval F.assign = true := by
  exact Rule.sound F (.cubic 9 10 [2, 7, 10] [0, 2, 9]) (by decide +kernel)
def c250 : CNF.Clause Nat := [(110,false), (10,true), (21,true), (98,true), (22,true), (33,true), (99,true)]
theorem p250 (F : Frame G 4) : c250.eval F.assign = true := by
  exact Rule.sound F (.cubic 9 10 [2, 7, 10] [0, 7, 9]) (by decide +kernel)
def c251 : CNF.Clause Nat := [(110,false), (10,true), (21,true), (98,true), (22,true), (33,true), (88,true)]
theorem p251 (F : Frame G 4) : c251.eval F.assign = true := by
  exact Rule.sound F (.cubic 9 10 [2, 7, 10] [0, 8, 9]) (by decide +kernel)
def c252 : CNF.Clause Nat := [(110,false), (10,true), (21,true), (98,true), (11,true), (88,true), (99,true)]
theorem p252 (F : Frame G 4) : c252.eval F.assign = true := by
  exact Rule.sound F (.cubic 9 10 [2, 7, 10] [1, 2, 9]) (by decide +kernel)
def c253 : CNF.Clause Nat := [(110,false), (10,true), (21,true), (98,true), (11,true), (22,true), (99,true)]
theorem p253 (F : Frame G 4) : c253.eval F.assign = true := by
  exact Rule.sound F (.cubic 9 10 [2, 7, 10] [2, 7, 9]) (by decide +kernel)
def c254 : CNF.Clause Nat := [(110,false), (10,true), (21,true), (87,true), (33,true), (88,true), (99,true)]
theorem p254 (F : Frame G 4) : c254.eval F.assign = true := by
  exact Rule.sound F (.cubic 9 10 [2, 8, 10] [0, 1, 9]) (by decide +kernel)
def c255 : CNF.Clause Nat := [(110,false), (10,true), (21,true), (87,true), (22,true), (88,true), (99,true)]
theorem p255 (F : Frame G 4) : c255.eval F.assign = true := by
  exact Rule.sound F (.cubic 9 10 [2, 8, 10] [0, 2, 9]) (by decide +kernel)
def c256 : CNF.Clause Nat := [(110,false), (10,true), (21,true), (87,true), (22,true), (33,true), (99,true)]
theorem p256 (F : Frame G 4) : c256.eval F.assign = true := by
  exact Rule.sound F (.cubic 9 10 [2, 8, 10] [0, 7, 9]) (by decide +kernel)
def c257 : CNF.Clause Nat := [(110,false), (10,true), (21,true), (87,true), (22,true), (33,true), (88,true)]
theorem p257 (F : Frame G 4) : c257.eval F.assign = true := by
  exact Rule.sound F (.cubic 9 10 [2, 8, 10] [0, 8, 9]) (by decide +kernel)
def c258 : CNF.Clause Nat := [(110,false), (10,true), (21,true), (87,true), (11,true), (88,true), (99,true)]
theorem p258 (F : Frame G 4) : c258.eval F.assign = true := by
  exact Rule.sound F (.cubic 9 10 [2, 8, 10] [1, 2, 9]) (by decide +kernel)
def c259 : CNF.Clause Nat := [(110,false), (10,true), (21,true), (87,true), (11,true), (33,true), (88,true)]
theorem p259 (F : Frame G 4) : c259.eval F.assign = true := by
  exact Rule.sound F (.cubic 9 10 [2, 8, 10] [1, 8, 9]) (by decide +kernel)
def c260 : CNF.Clause Nat := [(110,false), (10,true), (21,true), (87,true), (11,true), (22,true), (88,true)]
theorem p260 (F : Frame G 4) : c260.eval F.assign = true := by
  exact Rule.sound F (.cubic 9 10 [2, 8, 10] [2, 8, 9]) (by decide +kernel)
def c261 : CNF.Clause Nat := [(86,true), (87,true), (88,true)]
theorem p261 (F : Frame G 4) : c261.eval F.assign = true := by
  exact Rule.sound F (.connected false [7]) (by decide +kernel)
def c262 : CNF.Clause Nat := [(87,true), (88,true), (98,true), (99,true)]
theorem p262 (F : Frame G 4) : c262.eval F.assign = true := by
  exact Rule.sound F (.connected false [7, 8]) (by decide +kernel)
def c263 : CNF.Clause Nat := [(86,true), (88,true), (98,true), (110,true)]
theorem p263 (F : Frame G 4) : c263.eval F.assign = true := by
  exact Rule.sound F (.connected false [7, 9]) (by decide +kernel)
def c264 : CNF.Clause Nat := [(86,true), (87,true), (99,true), (110,true)]
theorem p264 (F : Frame G 4) : c264.eval F.assign = true := by
  exact Rule.sound F (.connected false [7, 10]) (by decide +kernel)
def c265 : CNF.Clause Nat := [(88,true), (99,true), (110,true)]
theorem p265 (F : Frame G 4) : c265.eval F.assign = true := by
  exact Rule.sound F (.connected false [7, 8, 9]) (by decide +kernel)
def c266 : CNF.Clause Nat := [(87,true), (98,true), (110,true)]
theorem p266 (F : Frame G 4) : c266.eval F.assign = true := by
  exact Rule.sound F (.connected false [7, 8, 10]) (by decide +kernel)
def c267 : CNF.Clause Nat := [(86,true), (98,true), (99,true)]
theorem p267 (F : Frame G 4) : c267.eval F.assign = true := by
  exact Rule.sound F (.connected false [7, 9, 10]) (by decide +kernel)
def c268 : CNF.Clause Nat := [(4,false), (5,false), (6,false), (8,false), (9,false), (38,true), (39,true), (50,true), (86,true)]
theorem p268 (F : Frame G 4) : c268.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 4, 5, 7, 8]) (by decide +kernel)
def c269 : CNF.Clause Nat := [(4,false), (5,false), (6,false), (8,false), (10,false), (38,true), (39,true), (50,true), (87,true)]
theorem p269 (F : Frame G 4) : c269.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 4, 5, 7, 9]) (by decide +kernel)
def c270 : CNF.Clause Nat := [(4,false), (5,false), (6,false), (8,false), (11,false), (38,true), (39,true), (50,true), (88,true)]
theorem p270 (F : Frame G 4) : c270.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 4, 5, 7, 10]) (by decide +kernel)
def c271 : CNF.Clause Nat := [(4,false), (5,false), (7,false), (8,false), (9,false), (38,true), (40,true), (51,true), (86,true)]
theorem p271 (F : Frame G 4) : c271.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 4, 6, 7, 8]) (by decide +kernel)
def c272 : CNF.Clause Nat := [(4,false), (5,false), (7,false), (8,false), (10,false), (38,true), (40,true), (51,true), (87,true)]
theorem p272 (F : Frame G 4) : c272.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 4, 6, 7, 9]) (by decide +kernel)
def c273 : CNF.Clause Nat := [(4,false), (5,false), (7,false), (8,false), (11,false), (38,true), (40,true), (51,true), (88,true)]
theorem p273 (F : Frame G 4) : c273.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 4, 6, 7, 10]) (by decide +kernel)
def c274 : CNF.Clause Nat := [(4,false), (5,false), (7,false), (9,false), (10,false), (38,true), (40,true), (51,true), (98,true)]
theorem p274 (F : Frame G 4) : c274.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 4, 6, 8, 9]) (by decide +kernel)
def c275 : CNF.Clause Nat := [(4,false), (5,false), (7,false), (9,false), (11,false), (38,true), (40,true), (51,true), (99,true)]
theorem p275 (F : Frame G 4) : c275.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 4, 6, 8, 10]) (by decide +kernel)
def c276 : CNF.Clause Nat := [(4,false), (5,false), (7,false), (10,false), (11,false), (38,true), (40,true), (51,true), (110,true)]
theorem p276 (F : Frame G 4) : c276.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 4, 6, 9, 10]) (by decide +kernel)
def c277 : CNF.Clause Nat := [(4,false), (5,false), (8,false), (9,false), (10,false), (38,true), (86,true), (87,true), (98,true)]
theorem p277 (F : Frame G 4) : c277.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 4, 7, 8, 9]) (by decide +kernel)
def c278 : CNF.Clause Nat := [(4,false), (5,false), (8,false), (9,false), (11,false), (38,true), (86,true), (88,true), (99,true)]
theorem p278 (F : Frame G 4) : c278.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 4, 7, 8, 10]) (by decide +kernel)
def c279 : CNF.Clause Nat := [(4,false), (5,false), (8,false), (10,false), (11,false), (38,true), (87,true), (88,true), (110,true)]
theorem p279 (F : Frame G 4) : c279.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 4, 7, 9, 10]) (by decide +kernel)
def c280 : CNF.Clause Nat := [(4,false), (5,false), (9,false), (10,false), (11,false), (38,true), (98,true), (99,true), (110,true)]
theorem p280 (F : Frame G 4) : c280.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 4, 8, 9, 10]) (by decide +kernel)
def c281 : CNF.Clause Nat := [(4,false), (6,false), (7,false), (8,false), (9,false), (39,true), (40,true), (62,true), (86,true)]
theorem p281 (F : Frame G 4) : c281.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 5, 6, 7, 8]) (by decide +kernel)
def c282 : CNF.Clause Nat := [(4,false), (6,false), (7,false), (8,false), (10,false), (39,true), (40,true), (62,true), (87,true)]
theorem p282 (F : Frame G 4) : c282.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 5, 6, 7, 9]) (by decide +kernel)
def c283 : CNF.Clause Nat := [(4,false), (6,false), (7,false), (8,false), (11,false), (39,true), (40,true), (62,true), (88,true)]
theorem p283 (F : Frame G 4) : c283.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 5, 6, 7, 10]) (by decide +kernel)
def c284 : CNF.Clause Nat := [(4,false), (6,false), (7,false), (9,false), (10,false), (39,true), (40,true), (62,true), (98,true)]
theorem p284 (F : Frame G 4) : c284.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 5, 6, 8, 9]) (by decide +kernel)
def c285 : CNF.Clause Nat := [(4,false), (6,false), (7,false), (9,false), (11,false), (39,true), (40,true), (62,true), (99,true)]
theorem p285 (F : Frame G 4) : c285.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 5, 6, 8, 10]) (by decide +kernel)
def c286 : CNF.Clause Nat := [(4,false), (6,false), (7,false), (10,false), (11,false), (39,true), (40,true), (62,true), (110,true)]
theorem p286 (F : Frame G 4) : c286.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 5, 6, 9, 10]) (by decide +kernel)
def c287 : CNF.Clause Nat := [(4,false), (6,false), (8,false), (9,false), (10,false), (39,true), (86,true), (87,true), (98,true)]
theorem p287 (F : Frame G 4) : c287.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 5, 7, 8, 9]) (by decide +kernel)
def c288 : CNF.Clause Nat := [(4,false), (6,false), (8,false), (9,false), (11,false), (39,true), (86,true), (88,true), (99,true)]
theorem p288 (F : Frame G 4) : c288.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 5, 7, 8, 10]) (by decide +kernel)
def c289 : CNF.Clause Nat := [(4,false), (6,false), (8,false), (10,false), (11,false), (39,true), (87,true), (88,true), (110,true)]
theorem p289 (F : Frame G 4) : c289.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 5, 7, 9, 10]) (by decide +kernel)
def c290 : CNF.Clause Nat := [(4,false), (6,false), (9,false), (10,false), (11,false), (39,true), (98,true), (99,true), (110,true)]
theorem p290 (F : Frame G 4) : c290.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 5, 8, 9, 10]) (by decide +kernel)
def c291 : CNF.Clause Nat := [(4,false), (7,false), (8,false), (9,false), (10,false), (40,true), (86,true), (87,true), (98,true)]
theorem p291 (F : Frame G 4) : c291.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 6, 7, 8, 9]) (by decide +kernel)
def c292 : CNF.Clause Nat := [(4,false), (7,false), (8,false), (9,false), (11,false), (40,true), (86,true), (88,true), (99,true)]
theorem p292 (F : Frame G 4) : c292.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 6, 7, 8, 10]) (by decide +kernel)
def c293 : CNF.Clause Nat := [(4,false), (7,false), (8,false), (10,false), (11,false), (40,true), (87,true), (88,true), (110,true)]
theorem p293 (F : Frame G 4) : c293.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 6, 7, 9, 10]) (by decide +kernel)
def c294 : CNF.Clause Nat := [(4,false), (7,false), (9,false), (10,false), (11,false), (40,true), (98,true), (99,true), (110,true)]
theorem p294 (F : Frame G 4) : c294.eval F.assign = true := by
  exact Rule.sound F (.star 0 [3, 6, 8, 9, 10]) (by decide +kernel)
def c295 : CNF.Clause Nat := [(5,false), (6,false), (7,false), (8,false), (9,false), (50,true), (51,true), (62,true), (86,true)]
theorem p295 (F : Frame G 4) : c295.eval F.assign = true := by
  exact Rule.sound F (.star 0 [4, 5, 6, 7, 8]) (by decide +kernel)
def c296 : CNF.Clause Nat := [(5,false), (6,false), (7,false), (8,false), (10,false), (50,true), (51,true), (62,true), (87,true)]
theorem p296 (F : Frame G 4) : c296.eval F.assign = true := by
  exact Rule.sound F (.star 0 [4, 5, 6, 7, 9]) (by decide +kernel)
def c297 : CNF.Clause Nat := [(5,false), (6,false), (7,false), (8,false), (11,false), (50,true), (51,true), (62,true), (88,true)]
theorem p297 (F : Frame G 4) : c297.eval F.assign = true := by
  exact Rule.sound F (.star 0 [4, 5, 6, 7, 10]) (by decide +kernel)
def c298 : CNF.Clause Nat := [(5,false), (6,false), (7,false), (9,false), (10,false), (50,true), (51,true), (62,true), (98,true)]
theorem p298 (F : Frame G 4) : c298.eval F.assign = true := by
  exact Rule.sound F (.star 0 [4, 5, 6, 8, 9]) (by decide +kernel)
def c299 : CNF.Clause Nat := [(5,false), (6,false), (7,false), (10,false), (11,false), (50,true), (51,true), (62,true), (110,true)]
theorem p299 (F : Frame G 4) : c299.eval F.assign = true := by
  exact Rule.sound F (.star 0 [4, 5, 6, 9, 10]) (by decide +kernel)
def c300 : CNF.Clause Nat := [(5,false), (6,false), (8,false), (9,false), (10,false), (50,true), (86,true), (87,true), (98,true)]
theorem p300 (F : Frame G 4) : c300.eval F.assign = true := by
  exact Rule.sound F (.star 0 [4, 5, 7, 8, 9]) (by decide +kernel)
end Cert44Steps
end Graffiti199Depleted.Catalogue.OrderEleven
