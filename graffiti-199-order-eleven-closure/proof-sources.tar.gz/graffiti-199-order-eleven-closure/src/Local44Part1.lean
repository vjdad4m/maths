import Local44Part0
namespace Graffiti199Depleted.Catalogue.OrderEleven
namespace Cert44Steps
open Std.Sat
set_option maxRecDepth 4096
set_option maxHeartbeats 0
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj]
def c301 : CNF.Clause Nat := [(5,false), (7,false), (8,false), (9,false), (10,false), (51,true), (86,true), (87,true), (98,true)]
theorem p301 (F : Frame G 4) : c301.eval F.assign = true := by
  exact Rule.sound F (.star 0 [4, 6, 7, 8, 9]) (by decide +kernel)
def c302 : CNF.Clause Nat := [(5,false), (7,false), (8,false), (9,false), (11,false), (51,true), (86,true), (88,true), (99,true)]
theorem p302 (F : Frame G 4) : c302.eval F.assign = true := by
  exact Rule.sound F (.star 0 [4, 6, 7, 8, 10]) (by decide +kernel)
def c303 : CNF.Clause Nat := [(5,false), (7,false), (8,false), (10,false), (11,false), (51,true), (87,true), (88,true), (110,true)]
theorem p303 (F : Frame G 4) : c303.eval F.assign = true := by
  exact Rule.sound F (.star 0 [4, 6, 7, 9, 10]) (by decide +kernel)
def c304 : CNF.Clause Nat := [(6,false), (7,false), (8,false), (9,false), (10,false), (62,true), (86,true), (87,true), (98,true)]
theorem p304 (F : Frame G 4) : c304.eval F.assign = true := by
  exact Rule.sound F (.star 0 [5, 6, 7, 8, 9]) (by decide +kernel)
def c305 : CNF.Clause Nat := [(6,false), (7,false), (8,false), (10,false), (11,false), (62,true), (87,true), (88,true), (110,true)]
theorem p305 (F : Frame G 4) : c305.eval F.assign = true := by
  exact Rule.sound F (.star 0 [5, 6, 7, 9, 10]) (by decide +kernel)
def c306 : CNF.Clause Nat := [(15,false), (16,false), (17,false), (19,false), (20,false), (38,true), (39,true), (50,true), (86,true)]
theorem p306 (F : Frame G 4) : c306.eval F.assign = true := by
  exact Rule.sound F (.star 1 [3, 4, 5, 7, 8]) (by decide +kernel)
def c307 : CNF.Clause Nat := [(15,false), (16,false), (17,false), (20,false), (22,false), (38,true), (39,true), (50,true), (99,true)]
theorem p307 (F : Frame G 4) : c307.eval F.assign = true := by
  exact Rule.sound F (.star 1 [3, 4, 5, 8, 10]) (by decide +kernel)
def c308 : CNF.Clause Nat := [(15,false), (16,false), (18,false), (19,false), (20,false), (38,true), (40,true), (51,true), (86,true)]
theorem p308 (F : Frame G 4) : c308.eval F.assign = true := by
  exact Rule.sound F (.star 1 [3, 4, 6, 7, 8]) (by decide +kernel)
def c309 : CNF.Clause Nat := [(15,false), (16,false), (18,false), (20,false), (21,false), (38,true), (40,true), (51,true), (98,true)]
theorem p309 (F : Frame G 4) : c309.eval F.assign = true := by
  exact Rule.sound F (.star 1 [3, 4, 6, 8, 9]) (by decide +kernel)
def c310 : CNF.Clause Nat := [(15,false), (16,false), (18,false), (20,false), (22,false), (38,true), (40,true), (51,true), (99,true)]
theorem p310 (F : Frame G 4) : c310.eval F.assign = true := by
  exact Rule.sound F (.star 1 [3, 4, 6, 8, 10]) (by decide +kernel)
def c311 : CNF.Clause Nat := [(15,false), (16,false), (19,false), (20,false), (21,false), (38,true), (86,true), (87,true), (98,true)]
theorem p311 (F : Frame G 4) : c311.eval F.assign = true := by
  exact Rule.sound F (.star 1 [3, 4, 7, 8, 9]) (by decide +kernel)
def c312 : CNF.Clause Nat := [(15,false), (16,false), (19,false), (20,false), (22,false), (38,true), (86,true), (88,true), (99,true)]
theorem p312 (F : Frame G 4) : c312.eval F.assign = true := by
  exact Rule.sound F (.star 1 [3, 4, 7, 8, 10]) (by decide +kernel)
def c313 : CNF.Clause Nat := [(15,false), (16,false), (19,false), (21,false), (22,false), (38,true), (87,true), (88,true), (110,true)]
theorem p313 (F : Frame G 4) : c313.eval F.assign = true := by
  exact Rule.sound F (.star 1 [3, 4, 7, 9, 10]) (by decide +kernel)
def c314 : CNF.Clause Nat := [(15,false), (16,false), (20,false), (21,false), (22,false), (38,true), (98,true), (99,true), (110,true)]
theorem p314 (F : Frame G 4) : c314.eval F.assign = true := by
  exact Rule.sound F (.star 1 [3, 4, 8, 9, 10]) (by decide +kernel)
def c315 : CNF.Clause Nat := [(15,false), (17,false), (18,false), (19,false), (20,false), (39,true), (40,true), (62,true), (86,true)]
theorem p315 (F : Frame G 4) : c315.eval F.assign = true := by
  exact Rule.sound F (.star 1 [3, 5, 6, 7, 8]) (by decide +kernel)
def c316 : CNF.Clause Nat := [(15,false), (17,false), (18,false), (19,false), (21,false), (39,true), (40,true), (62,true), (87,true)]
theorem p316 (F : Frame G 4) : c316.eval F.assign = true := by
  exact Rule.sound F (.star 1 [3, 5, 6, 7, 9]) (by decide +kernel)
def c317 : CNF.Clause Nat := [(15,false), (17,false), (18,false), (19,false), (22,false), (39,true), (40,true), (62,true), (88,true)]
theorem p317 (F : Frame G 4) : c317.eval F.assign = true := by
  exact Rule.sound F (.star 1 [3, 5, 6, 7, 10]) (by decide +kernel)
def c318 : CNF.Clause Nat := [(15,false), (17,false), (18,false), (20,false), (21,false), (39,true), (40,true), (62,true), (98,true)]
theorem p318 (F : Frame G 4) : c318.eval F.assign = true := by
  exact Rule.sound F (.star 1 [3, 5, 6, 8, 9]) (by decide +kernel)
def c319 : CNF.Clause Nat := [(15,false), (17,false), (18,false), (20,false), (22,false), (39,true), (40,true), (62,true), (99,true)]
theorem p319 (F : Frame G 4) : c319.eval F.assign = true := by
  exact Rule.sound F (.star 1 [3, 5, 6, 8, 10]) (by decide +kernel)
def c320 : CNF.Clause Nat := [(15,false), (18,false), (19,false), (20,false), (22,false), (40,true), (86,true), (88,true), (99,true)]
theorem p320 (F : Frame G 4) : c320.eval F.assign = true := by
  exact Rule.sound F (.star 1 [3, 6, 7, 8, 10]) (by decide +kernel)
def c321 : CNF.Clause Nat := [(15,false), (18,false), (20,false), (21,false), (22,false), (40,true), (98,true), (99,true), (110,true)]
theorem p321 (F : Frame G 4) : c321.eval F.assign = true := by
  exact Rule.sound F (.star 1 [3, 6, 8, 9, 10]) (by decide +kernel)
def c322 : CNF.Clause Nat := [(16,false), (17,false), (18,false), (19,false), (20,false), (50,true), (51,true), (62,true), (86,true)]
theorem p322 (F : Frame G 4) : c322.eval F.assign = true := by
  exact Rule.sound F (.star 1 [4, 5, 6, 7, 8]) (by decide +kernel)
def c323 : CNF.Clause Nat := [(16,false), (17,false), (18,false), (19,false), (22,false), (50,true), (51,true), (62,true), (88,true)]
theorem p323 (F : Frame G 4) : c323.eval F.assign = true := by
  exact Rule.sound F (.star 1 [4, 5, 6, 7, 10]) (by decide +kernel)
def c324 : CNF.Clause Nat := [(16,false), (17,false), (18,false), (20,false), (21,false), (50,true), (51,true), (62,true), (98,true)]
theorem p324 (F : Frame G 4) : c324.eval F.assign = true := by
  exact Rule.sound F (.star 1 [4, 5, 6, 8, 9]) (by decide +kernel)
def c325 : CNF.Clause Nat := [(16,false), (17,false), (18,false), (20,false), (22,false), (50,true), (51,true), (62,true), (99,true)]
theorem p325 (F : Frame G 4) : c325.eval F.assign = true := by
  exact Rule.sound F (.star 1 [4, 5, 6, 8, 10]) (by decide +kernel)
def c326 : CNF.Clause Nat := [(16,false), (17,false), (19,false), (20,false), (21,false), (50,true), (86,true), (87,true), (98,true)]
theorem p326 (F : Frame G 4) : c326.eval F.assign = true := by
  exact Rule.sound F (.star 1 [4, 5, 7, 8, 9]) (by decide +kernel)
def c327 : CNF.Clause Nat := [(16,false), (17,false), (19,false), (20,false), (22,false), (50,true), (86,true), (88,true), (99,true)]
theorem p327 (F : Frame G 4) : c327.eval F.assign = true := by
  exact Rule.sound F (.star 1 [4, 5, 7, 8, 10]) (by decide +kernel)
def c328 : CNF.Clause Nat := [(16,false), (17,false), (20,false), (21,false), (22,false), (50,true), (98,true), (99,true), (110,true)]
theorem p328 (F : Frame G 4) : c328.eval F.assign = true := by
  exact Rule.sound F (.star 1 [4, 5, 8, 9, 10]) (by decide +kernel)
def c329 : CNF.Clause Nat := [(16,false), (18,false), (19,false), (20,false), (21,false), (51,true), (86,true), (87,true), (98,true)]
theorem p329 (F : Frame G 4) : c329.eval F.assign = true := by
  exact Rule.sound F (.star 1 [4, 6, 7, 8, 9]) (by decide +kernel)
def c330 : CNF.Clause Nat := [(16,false), (18,false), (19,false), (20,false), (22,false), (51,true), (86,true), (88,true), (99,true)]
theorem p330 (F : Frame G 4) : c330.eval F.assign = true := by
  exact Rule.sound F (.star 1 [4, 6, 7, 8, 10]) (by decide +kernel)
def c331 : CNF.Clause Nat := [(16,false), (18,false), (19,false), (21,false), (22,false), (51,true), (87,true), (88,true), (110,true)]
theorem p331 (F : Frame G 4) : c331.eval F.assign = true := by
  exact Rule.sound F (.star 1 [4, 6, 7, 9, 10]) (by decide +kernel)
def c332 : CNF.Clause Nat := [(16,false), (18,false), (20,false), (21,false), (22,false), (51,true), (98,true), (99,true), (110,true)]
theorem p332 (F : Frame G 4) : c332.eval F.assign = true := by
  exact Rule.sound F (.star 1 [4, 6, 8, 9, 10]) (by decide +kernel)
def c333 : CNF.Clause Nat := [(17,false), (18,false), (19,false), (20,false), (21,false), (62,true), (86,true), (87,true), (98,true)]
theorem p333 (F : Frame G 4) : c333.eval F.assign = true := by
  exact Rule.sound F (.star 1 [5, 6, 7, 8, 9]) (by decide +kernel)
def c334 : CNF.Clause Nat := [(17,false), (18,false), (19,false), (21,false), (22,false), (62,true), (87,true), (88,true), (110,true)]
theorem p334 (F : Frame G 4) : c334.eval F.assign = true := by
  exact Rule.sound F (.star 1 [5, 6, 7, 9, 10]) (by decide +kernel)
def c335 : CNF.Clause Nat := [(17,false), (18,false), (20,false), (21,false), (22,false), (62,true), (98,true), (99,true), (110,true)]
theorem p335 (F : Frame G 4) : c335.eval F.assign = true := by
  exact Rule.sound F (.star 1 [5, 6, 8, 9, 10]) (by decide +kernel)
def c336 : CNF.Clause Nat := [(26,false), (27,false), (28,false), (30,false), (31,false), (38,true), (39,true), (50,true), (86,true)]
theorem p336 (F : Frame G 4) : c336.eval F.assign = true := by
  exact Rule.sound F (.star 2 [3, 4, 5, 7, 8]) (by decide +kernel)
def c337 : CNF.Clause Nat := [(26,false), (27,false), (28,false), (30,false), (32,false), (38,true), (39,true), (50,true), (87,true)]
theorem p337 (F : Frame G 4) : c337.eval F.assign = true := by
  exact Rule.sound F (.star 2 [3, 4, 5, 7, 9]) (by decide +kernel)
def c338 : CNF.Clause Nat := [(26,false), (27,false), (28,false), (31,false), (32,false), (38,true), (39,true), (50,true), (98,true)]
theorem p338 (F : Frame G 4) : c338.eval F.assign = true := by
  exact Rule.sound F (.star 2 [3, 4, 5, 8, 9]) (by decide +kernel)
def c339 : CNF.Clause Nat := [(26,false), (27,false), (28,false), (31,false), (33,false), (38,true), (39,true), (50,true), (99,true)]
theorem p339 (F : Frame G 4) : c339.eval F.assign = true := by
  exact Rule.sound F (.star 2 [3, 4, 5, 8, 10]) (by decide +kernel)
def c340 : CNF.Clause Nat := [(26,false), (27,false), (29,false), (30,false), (32,false), (38,true), (40,true), (51,true), (87,true)]
theorem p340 (F : Frame G 4) : c340.eval F.assign = true := by
  exact Rule.sound F (.star 2 [3, 4, 6, 7, 9]) (by decide +kernel)
def c341 : CNF.Clause Nat := [(26,false), (27,false), (29,false), (30,false), (33,false), (38,true), (40,true), (51,true), (88,true)]
theorem p341 (F : Frame G 4) : c341.eval F.assign = true := by
  exact Rule.sound F (.star 2 [3, 4, 6, 7, 10]) (by decide +kernel)
def c342 : CNF.Clause Nat := [(26,false), (27,false), (29,false), (32,false), (33,false), (38,true), (40,true), (51,true), (110,true)]
theorem p342 (F : Frame G 4) : c342.eval F.assign = true := by
  exact Rule.sound F (.star 2 [3, 4, 6, 9, 10]) (by decide +kernel)
def c343 : CNF.Clause Nat := [(26,false), (27,false), (30,false), (31,false), (33,false), (38,true), (86,true), (88,true), (99,true)]
theorem p343 (F : Frame G 4) : c343.eval F.assign = true := by
  exact Rule.sound F (.star 2 [3, 4, 7, 8, 10]) (by decide +kernel)
def c344 : CNF.Clause Nat := [(26,false), (27,false), (30,false), (32,false), (33,false), (38,true), (87,true), (88,true), (110,true)]
theorem p344 (F : Frame G 4) : c344.eval F.assign = true := by
  exact Rule.sound F (.star 2 [3, 4, 7, 9, 10]) (by decide +kernel)
def c345 : CNF.Clause Nat := [(26,false), (28,false), (29,false), (30,false), (32,false), (39,true), (40,true), (62,true), (87,true)]
theorem p345 (F : Frame G 4) : c345.eval F.assign = true := by
  exact Rule.sound F (.star 2 [3, 5, 6, 7, 9]) (by decide +kernel)
def c346 : CNF.Clause Nat := [(26,false), (28,false), (29,false), (30,false), (33,false), (39,true), (40,true), (62,true), (88,true)]
theorem p346 (F : Frame G 4) : c346.eval F.assign = true := by
  exact Rule.sound F (.star 2 [3, 5, 6, 7, 10]) (by decide +kernel)
def c347 : CNF.Clause Nat := [(26,false), (28,false), (29,false), (31,false), (32,false), (39,true), (40,true), (62,true), (98,true)]
theorem p347 (F : Frame G 4) : c347.eval F.assign = true := by
  exact Rule.sound F (.star 2 [3, 5, 6, 8, 9]) (by decide +kernel)
def c348 : CNF.Clause Nat := [(26,false), (28,false), (29,false), (32,false), (33,false), (39,true), (40,true), (62,true), (110,true)]
theorem p348 (F : Frame G 4) : c348.eval F.assign = true := by
  exact Rule.sound F (.star 2 [3, 5, 6, 9, 10]) (by decide +kernel)
def c349 : CNF.Clause Nat := [(26,false), (28,false), (30,false), (31,false), (32,false), (39,true), (86,true), (87,true), (98,true)]
theorem p349 (F : Frame G 4) : c349.eval F.assign = true := by
  exact Rule.sound F (.star 2 [3, 5, 7, 8, 9]) (by decide +kernel)
def c350 : CNF.Clause Nat := [(26,false), (28,false), (30,false), (31,false), (33,false), (39,true), (86,true), (88,true), (99,true)]
theorem p350 (F : Frame G 4) : c350.eval F.assign = true := by
  exact Rule.sound F (.star 2 [3, 5, 7, 8, 10]) (by decide +kernel)
def c351 : CNF.Clause Nat := [(26,false), (28,false), (30,false), (32,false), (33,false), (39,true), (87,true), (88,true), (110,true)]
theorem p351 (F : Frame G 4) : c351.eval F.assign = true := by
  exact Rule.sound F (.star 2 [3, 5, 7, 9, 10]) (by decide +kernel)
def c352 : CNF.Clause Nat := [(26,false), (28,false), (31,false), (32,false), (33,false), (39,true), (98,true), (99,true), (110,true)]
theorem p352 (F : Frame G 4) : c352.eval F.assign = true := by
  exact Rule.sound F (.star 2 [3, 5, 8, 9, 10]) (by decide +kernel)
def c353 : CNF.Clause Nat := [(26,false), (29,false), (30,false), (31,false), (32,false), (40,true), (86,true), (87,true), (98,true)]
theorem p353 (F : Frame G 4) : c353.eval F.assign = true := by
  exact Rule.sound F (.star 2 [3, 6, 7, 8, 9]) (by decide +kernel)
def c354 : CNF.Clause Nat := [(26,false), (29,false), (31,false), (32,false), (33,false), (40,true), (98,true), (99,true), (110,true)]
theorem p354 (F : Frame G 4) : c354.eval F.assign = true := by
  exact Rule.sound F (.star 2 [3, 6, 8, 9, 10]) (by decide +kernel)
def c355 : CNF.Clause Nat := [(27,false), (28,false), (29,false), (30,false), (31,false), (50,true), (51,true), (62,true), (86,true)]
theorem p355 (F : Frame G 4) : c355.eval F.assign = true := by
  exact Rule.sound F (.star 2 [4, 5, 6, 7, 8]) (by decide +kernel)
def c356 : CNF.Clause Nat := [(27,false), (28,false), (29,false), (30,false), (32,false), (50,true), (51,true), (62,true), (87,true)]
theorem p356 (F : Frame G 4) : c356.eval F.assign = true := by
  exact Rule.sound F (.star 2 [4, 5, 6, 7, 9]) (by decide +kernel)
def c357 : CNF.Clause Nat := [(27,false), (28,false), (29,false), (30,false), (33,false), (50,true), (51,true), (62,true), (88,true)]
theorem p357 (F : Frame G 4) : c357.eval F.assign = true := by
  exact Rule.sound F (.star 2 [4, 5, 6, 7, 10]) (by decide +kernel)
def c358 : CNF.Clause Nat := [(27,false), (28,false), (29,false), (31,false), (32,false), (50,true), (51,true), (62,true), (98,true)]
theorem p358 (F : Frame G 4) : c358.eval F.assign = true := by
  exact Rule.sound F (.star 2 [4, 5, 6, 8, 9]) (by decide +kernel)
def c359 : CNF.Clause Nat := [(27,false), (28,false), (29,false), (31,false), (33,false), (50,true), (51,true), (62,true), (99,true)]
theorem p359 (F : Frame G 4) : c359.eval F.assign = true := by
  exact Rule.sound F (.star 2 [4, 5, 6, 8, 10]) (by decide +kernel)
def c360 : CNF.Clause Nat := [(27,false), (28,false), (29,false), (32,false), (33,false), (50,true), (51,true), (62,true), (110,true)]
theorem p360 (F : Frame G 4) : c360.eval F.assign = true := by
  exact Rule.sound F (.star 2 [4, 5, 6, 9, 10]) (by decide +kernel)
def c361 : CNF.Clause Nat := [(27,false), (28,false), (30,false), (31,false), (32,false), (50,true), (86,true), (87,true), (98,true)]
theorem p361 (F : Frame G 4) : c361.eval F.assign = true := by
  exact Rule.sound F (.star 2 [4, 5, 7, 8, 9]) (by decide +kernel)
def c362 : CNF.Clause Nat := [(27,false), (28,false), (30,false), (31,false), (33,false), (50,true), (86,true), (88,true), (99,true)]
theorem p362 (F : Frame G 4) : c362.eval F.assign = true := by
  exact Rule.sound F (.star 2 [4, 5, 7, 8, 10]) (by decide +kernel)
def c363 : CNF.Clause Nat := [(27,false), (28,false), (31,false), (32,false), (33,false), (50,true), (98,true), (99,true), (110,true)]
theorem p363 (F : Frame G 4) : c363.eval F.assign = true := by
  exact Rule.sound F (.star 2 [4, 5, 8, 9, 10]) (by decide +kernel)
def c364 : CNF.Clause Nat := [(27,false), (29,false), (30,false), (31,false), (32,false), (51,true), (86,true), (87,true), (98,true)]
theorem p364 (F : Frame G 4) : c364.eval F.assign = true := by
  exact Rule.sound F (.star 2 [4, 6, 7, 8, 9]) (by decide +kernel)
def c365 : CNF.Clause Nat := [(27,false), (29,false), (30,false), (31,false), (33,false), (51,true), (86,true), (88,true), (99,true)]
theorem p365 (F : Frame G 4) : c365.eval F.assign = true := by
  exact Rule.sound F (.star 2 [4, 6, 7, 8, 10]) (by decide +kernel)
def c366 : CNF.Clause Nat := [(27,false), (29,false), (30,false), (32,false), (33,false), (51,true), (87,true), (88,true), (110,true)]
theorem p366 (F : Frame G 4) : c366.eval F.assign = true := by
  exact Rule.sound F (.star 2 [4, 6, 7, 9, 10]) (by decide +kernel)
def c367 : CNF.Clause Nat := [(27,false), (29,false), (31,false), (32,false), (33,false), (51,true), (98,true), (99,true), (110,true)]
theorem p367 (F : Frame G 4) : c367.eval F.assign = true := by
  exact Rule.sound F (.star 2 [4, 6, 8, 9, 10]) (by decide +kernel)
def c368 : CNF.Clause Nat := [(28,false), (29,false), (30,false), (31,false), (32,false), (62,true), (86,true), (87,true), (98,true)]
theorem p368 (F : Frame G 4) : c368.eval F.assign = true := by
  exact Rule.sound F (.star 2 [5, 6, 7, 8, 9]) (by decide +kernel)
def c369 : CNF.Clause Nat := [(28,false), (29,false), (30,false), (31,false), (33,false), (62,true), (86,true), (88,true), (99,true)]
theorem p369 (F : Frame G 4) : c369.eval F.assign = true := by
  exact Rule.sound F (.star 2 [5, 6, 7, 8, 10]) (by decide +kernel)
def c370 : CNF.Clause Nat := [(28,false), (29,false), (30,false), (32,false), (33,false), (62,true), (87,true), (88,true), (110,true)]
theorem p370 (F : Frame G 4) : c370.eval F.assign = true := by
  exact Rule.sound F (.star 2 [5, 6, 7, 9, 10]) (by decide +kernel)
def c371 : CNF.Clause Nat := [(28,false), (29,false), (31,false), (32,false), (33,false), (62,true), (98,true), (99,true), (110,true)]
theorem p371 (F : Frame G 4) : c371.eval F.assign = true := by
  exact Rule.sound F (.star 2 [5, 6, 8, 9, 10]) (by decide +kernel)
def c372 : CNF.Clause Nat := [(38,false), (50,false), (62,false), (7,false), (8,false), (19,false), (20,false), (31,false), (32,false), (110,false)]
theorem p372 (F : Frame G 4) : c372.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 6, 0, 7, 1, 8, 2, 9, 10]) (by decide +kernel)
def c373 : CNF.Clause Nat := [(62,false), (28,false), (27,false), (16,false), (15,false), (4,false), (11,false), (99,false), (86,false), (87,false)]
theorem p373 (F : Frame G 4) : c373.eval F.assign = true := by
  exact Rule.sound F (.path [6, 5, 2, 4, 1, 3, 0, 10, 8, 7, 9]) (by decide +kernel)
def c374 : CNF.Clause Nat := [(4,false), (40,false), (51,false), (16,false), (20,false), (86,false), (88,false), (110,false), (32,false), (28,false)]
theorem p374 (F : Frame G 4) : c374.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 6, 4, 1, 8, 7, 10, 9, 2, 5]) (by decide +kernel)
def c375 : CNF.Clause Nat := [(4,false), (5,false), (50,false), (62,false), (18,false), (20,false), (31,false), (30,false), (87,false), (110,false)]
theorem p375 (F : Frame G 4) : c375.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 4, 5, 6, 1, 8, 2, 7, 9, 10]) (by decide +kernel)
def c376 : CNF.Clause Nat := [(7,false), (4,false), (38,false), (50,false), (17,false), (20,false), (31,false), (30,false), (87,false), (110,false)]
theorem p376 (F : Frame G 4) : c376.eval F.assign = true := by
  exact Rule.sound F (.path [6, 0, 3, 4, 5, 1, 8, 2, 7, 9, 10]) (by decide +kernel)
def c377 : CNF.Clause Nat := [(51,false), (5,false), (4,false), (39,false), (17,false), (20,false), (31,false), (30,false), (87,false), (110,false)]
theorem p377 (F : Frame G 4) : c377.eval F.assign = true := by
  exact Rule.sound F (.path [6, 4, 0, 3, 5, 1, 8, 2, 7, 9, 10]) (by decide +kernel)
def c378 : CNF.Clause Nat := [(4,false), (38,false), (51,false), (62,false), (17,false), (20,false), (31,false), (30,false), (87,false), (110,false)]
theorem p378 (F : Frame G 4) : c378.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 6, 5, 1, 8, 2, 7, 9, 10]) (by decide +kernel)
def c379 : CNF.Clause Nat := [(62,false), (6,false), (4,false), (38,false), (16,false), (20,false), (31,false), (30,false), (87,false), (110,false)]
theorem p379 (F : Frame G 4) : c379.eval F.assign = true := by
  exact Rule.sound F (.path [6, 5, 0, 3, 4, 1, 8, 2, 7, 9, 10]) (by decide +kernel)
def c380 : CNF.Clause Nat := [(62,false), (7,false), (4,false), (38,false), (16,false), (20,false), (31,false), (30,false), (87,false), (110,false)]
theorem p380 (F : Frame G 4) : c380.eval F.assign = true := by
  exact Rule.sound F (.path [5, 6, 0, 3, 4, 1, 8, 2, 7, 9, 10]) (by decide +kernel)
def c381 : CNF.Clause Nat := [(62,false), (39,false), (4,false), (5,false), (16,false), (20,false), (31,false), (30,false), (87,false), (110,false)]
theorem p381 (F : Frame G 4) : c381.eval F.assign = true := by
  exact Rule.sound F (.path [6, 5, 3, 0, 4, 1, 8, 2, 7, 9, 10]) (by decide +kernel)
def c382 : CNF.Clause Nat := [(4,false), (39,false), (62,false), (51,false), (16,false), (20,false), (31,false), (30,false), (87,false), (110,false)]
theorem p382 (F : Frame G 4) : c382.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 6, 4, 1, 8, 2, 7, 9, 10]) (by decide +kernel)
def c383 : CNF.Clause Nat := [(51,false), (5,false), (4,false), (39,false), (28,false), (31,false), (20,false), (19,false), (87,false), (110,false)]
theorem p383 (F : Frame G 4) : c383.eval F.assign = true := by
  exact Rule.sound F (.path [6, 4, 0, 3, 5, 2, 8, 1, 7, 9, 10]) (by decide +kernel)
def c384 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (62,false), (29,false), (31,false), (20,false), (19,false), (87,false), (110,false)]
theorem p384 (F : Frame G 4) : c384.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 6, 2, 8, 1, 7, 9, 10]) (by decide +kernel)
def c385 : CNF.Clause Nat := [(62,false), (28,false), (27,false), (16,false), (15,false), (4,false), (9,false), (99,false), (110,false), (87,false)]
theorem p385 (F : Frame G 4) : c385.eval F.assign = true := by
  exact Rule.sound F (.path [6, 5, 2, 4, 1, 3, 0, 8, 10, 9, 7]) (by decide +kernel)
def c386 : CNF.Clause Nat := [(8,false), (4,false), (38,false), (50,false), (62,false), (18,false), (20,false), (31,false), (32,false), (110,false)]
theorem p386 (F : Frame G 4) : c386.eval F.assign = true := by
  exact Rule.sound F (.path [7, 0, 3, 4, 5, 6, 1, 8, 2, 9, 10]) (by decide +kernel)
def c387 : CNF.Clause Nat := [(51,false), (5,false), (4,false), (39,false), (17,false), (20,false), (31,false), (32,false), (87,false), (88,false)]
theorem p387 (F : Frame G 4) : c387.eval F.assign = true := by
  exact Rule.sound F (.path [6, 4, 0, 3, 5, 1, 8, 2, 9, 7, 10]) (by decide +kernel)
def c388 : CNF.Clause Nat := [(38,false), (51,false), (62,false), (17,false), (20,false), (31,false), (32,false), (10,false), (8,false), (88,false)]
theorem p388 (F : Frame G 4) : c388.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 6, 5, 1, 8, 2, 9, 0, 7, 10]) (by decide +kernel)
def c389 : CNF.Clause Nat := [(38,false), (51,false), (62,false), (6,false), (8,false), (86,false), (20,false), (21,false), (32,false), (33,false)]
theorem p389 (F : Frame G 4) : c389.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 6, 5, 0, 7, 8, 1, 9, 2, 10]) (by decide +kernel)
def c390 : CNF.Clause Nat := [(62,false), (28,false), (27,false), (16,false), (15,false), (4,false), (11,false), (99,false), (98,false), (87,false)]
theorem p390 (F : Frame G 4) : c390.eval F.assign = true := by
  exact Rule.sound F (.path [6, 5, 2, 4, 1, 3, 0, 10, 8, 9, 7]) (by decide +kernel)
def c391 : CNF.Clause Nat := [(4,false), (7,false), (51,false), (50,false), (17,false), (20,false), (31,false), (32,false), (87,false), (88,false)]
theorem p391 (F : Frame G 4) : c391.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 4, 5, 1, 8, 2, 9, 7, 10]) (by decide +kernel)
def c392 : CNF.Clause Nat := [(4,false), (38,false), (51,false), (62,false), (17,false), (20,false), (31,false), (32,false), (87,false), (88,false)]
theorem p392 (F : Frame G 4) : c392.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 6, 5, 1, 8, 2, 9, 7, 10]) (by decide +kernel)
def c393 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (62,false), (29,false), (31,false), (9,false), (8,false), (87,false), (110,false)]
theorem p393 (F : Frame G 4) : c393.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 6, 2, 8, 0, 7, 9, 10]) (by decide +kernel)
def c394 : CNF.Clause Nat := [(20,false), (86,false), (88,false), (110,false), (10,false), (4,false), (26,false), (27,false), (50,false), (62,false)]
theorem p394 (F : Frame G 4) : c394.eval F.assign = true := by
  exact Rule.sound F (.path [1, 8, 7, 10, 9, 0, 3, 2, 4, 5, 6]) (by decide +kernel)
def c395 : CNF.Clause Nat := [(4,false), (39,false), (62,false), (51,false), (16,false), (20,false), (31,false), (32,false), (87,false), (88,false)]
theorem p395 (F : Frame G 4) : c395.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 6, 4, 1, 8, 2, 9, 7, 10]) (by decide +kernel)
def c396 : CNF.Clause Nat := [(4,false), (7,false), (51,false), (50,false), (17,false), (20,false), (86,false), (30,false), (32,false), (110,false)]
theorem p396 (F : Frame G 4) : c396.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 4, 5, 1, 8, 7, 2, 9, 10]) (by decide +kernel)
def c397 : CNF.Clause Nat := [(62,false), (39,false), (4,false), (5,false), (16,false), (20,false), (86,false), (30,false), (32,false), (110,false)]
theorem p397 (F : Frame G 4) : c397.eval F.assign = true := by
  exact Rule.sound F (.path [6, 5, 3, 0, 4, 1, 8, 7, 2, 9, 10]) (by decide +kernel)
def c398 : CNF.Clause Nat := [(4,false), (38,false), (51,false), (62,false), (17,false), (20,false), (86,false), (30,false), (32,false), (110,false)]
theorem p398 (F : Frame G 4) : c398.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 6, 5, 1, 8, 7, 2, 9, 10]) (by decide +kernel)
def c399 : CNF.Clause Nat := [(4,false), (39,false), (62,false), (51,false), (16,false), (20,false), (86,false), (30,false), (32,false), (110,false)]
theorem p399 (F : Frame G 4) : c399.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 6, 4, 1, 8, 7, 2, 9, 10]) (by decide +kernel)
def c400 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (62,false), (29,false), (32,false), (21,false), (19,false), (86,false), (99,false)]
theorem p400 (F : Frame G 4) : c400.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 6, 2, 9, 1, 7, 8, 10]) (by decide +kernel)
def c401 : CNF.Clause Nat := [(4,false), (8,false), (86,false), (98,false), (110,false), (22,false), (16,false), (27,false), (28,false), (62,false)]
theorem p401 (F : Frame G 4) : c401.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 7, 8, 9, 10, 1, 4, 2, 5, 6]) (by decide +kernel)
def c402 : CNF.Clause Nat := [(4,false), (8,false), (86,false), (99,false), (110,false), (21,false), (16,false), (27,false), (28,false), (62,false)]
theorem p402 (F : Frame G 4) : c402.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 7, 8, 10, 9, 1, 4, 2, 5, 6]) (by decide +kernel)
def c403 : CNF.Clause Nat := [(62,false), (28,false), (27,false), (16,false), (15,false), (4,false), (8,false), (88,false), (110,false), (98,false)]
theorem p403 (F : Frame G 4) : c403.eval F.assign = true := by
  exact Rule.sound F (.path [6, 5, 2, 4, 1, 3, 0, 7, 10, 9, 8]) (by decide +kernel)
def c404 : CNF.Clause Nat := [(4,false), (5,false), (50,false), (62,false), (18,false), (19,false), (86,false), (98,false), (32,false), (33,false)]
theorem p404 (F : Frame G 4) : c404.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 4, 5, 6, 1, 7, 8, 9, 2, 10]) (by decide +kernel)
def c405 : CNF.Clause Nat := [(4,false), (6,false), (50,false), (51,false), (18,false), (19,false), (86,false), (98,false), (32,false), (33,false)]
theorem p405 (F : Frame G 4) : c405.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 5, 4, 6, 1, 7, 8, 9, 2, 10]) (by decide +kernel)
def c406 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (62,false), (18,false), (19,false), (86,false), (98,false), (32,false), (33,false)]
theorem p406 (F : Frame G 4) : c406.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 6, 1, 7, 8, 9, 2, 10]) (by decide +kernel)
def c407 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (62,false), (7,false), (8,false), (86,false), (98,false), (32,false), (33,false)]
theorem p407 (F : Frame G 4) : c407.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 6, 0, 7, 8, 9, 2, 10]) (by decide +kernel)
def c408 : CNF.Clause Nat := [(51,false), (16,false), (17,false), (39,false), (4,false), (8,false), (86,false), (98,false), (32,false), (33,false)]
theorem p408 (F : Frame G 4) : c408.eval F.assign = true := by
  exact Rule.sound F (.path [6, 4, 1, 5, 3, 0, 7, 8, 9, 2, 10]) (by decide +kernel)
def c409 : CNF.Clause Nat := [(16,false), (51,false), (62,false), (39,false), (4,false), (8,false), (86,false), (98,false), (32,false), (33,false)]
theorem p409 (F : Frame G 4) : c409.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 6, 5, 3, 0, 7, 8, 9, 2, 10]) (by decide +kernel)
def c410 : CNF.Clause Nat := [(62,false), (17,false), (16,false), (27,false), (26,false), (4,false), (8,false), (87,false), (98,false), (99,false)]
theorem p410 (F : Frame G 4) : c410.eval F.assign = true := by
  exact Rule.sound F (.path [6, 5, 1, 4, 2, 3, 0, 7, 9, 8, 10]) (by decide +kernel)
def c411 : CNF.Clause Nat := [(50,false), (5,false), (4,false), (26,false), (29,false), (18,false), (20,false), (86,false), (87,false), (110,false)]
theorem p411 (F : Frame G 4) : c411.eval F.assign = true := by
  exact Rule.sound F (.path [5, 4, 0, 3, 2, 6, 1, 8, 7, 9, 10]) (by decide +kernel)
def c412 : CNF.Clause Nat := [(18,false), (16,false), (50,false), (28,false), (26,false), (4,false), (9,false), (86,false), (87,false), (110,false)]
theorem p412 (F : Frame G 4) : c412.eval F.assign = true := by
  exact Rule.sound F (.path [6, 1, 4, 5, 2, 3, 0, 8, 7, 9, 10]) (by decide +kernel)
def c413 : CNF.Clause Nat := [(4,false), (39,false), (28,false), (27,false), (51,false), (18,false), (19,false), (86,false), (98,false), (110,false)]
theorem p413 (F : Frame G 4) : c413.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 2, 4, 6, 1, 7, 8, 9, 10]) (by decide +kernel)
def c414 : CNF.Clause Nat := [(19,false), (88,false), (99,false), (98,false), (32,false), (26,false), (4,false), (5,false), (50,false), (62,false)]
theorem p414 (F : Frame G 4) : c414.eval F.assign = true := by
  exact Rule.sound F (.path [1, 7, 10, 8, 9, 2, 3, 0, 4, 5, 6]) (by decide +kernel)
def c415 : CNF.Clause Nat := [(16,false), (38,false), (26,false), (28,false), (62,false), (7,false), (8,false), (86,false), (98,false), (110,false)]
theorem p415 (F : Frame G 4) : c415.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 2, 5, 6, 0, 7, 8, 9, 10]) (by decide +kernel)
def c416 : CNF.Clause Nat := [(4,false), (39,false), (28,false), (27,false), (51,false), (18,false), (20,false), (86,false), (87,false), (110,false)]
theorem p416 (F : Frame G 4) : c416.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 2, 4, 6, 1, 8, 7, 9, 10]) (by decide +kernel)
def c417 : CNF.Clause Nat := [(20,false), (99,false), (88,false), (87,false), (32,false), (29,false), (62,false), (39,false), (4,false), (5,false)]
theorem p417 (F : Frame G 4) : c417.eval F.assign = true := by
  exact Rule.sound F (.path [1, 8, 10, 7, 9, 2, 6, 5, 3, 0, 4]) (by decide +kernel)
def c418 : CNF.Clause Nat := [(16,false), (51,false), (62,false), (28,false), (26,false), (4,false), (8,false), (86,false), (98,false), (110,false)]
theorem p418 (F : Frame G 4) : c418.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 6, 5, 2, 3, 0, 7, 8, 9, 10]) (by decide +kernel)
def c419 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (28,false), (29,false), (7,false), (8,false), (86,false), (98,false), (110,false)]
theorem p419 (F : Frame G 4) : c419.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 2, 6, 0, 7, 8, 9, 10]) (by decide +kernel)
def c420 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (62,false), (29,false), (32,false), (10,false), (8,false), (86,false), (99,false)]
theorem p420 (F : Frame G 4) : c420.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 6, 2, 9, 0, 7, 8, 10]) (by decide +kernel)
def c421 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (62,false), (29,false), (32,false), (87,false), (8,false), (9,false), (99,false)]
theorem p421 (F : Frame G 4) : c421.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 6, 2, 9, 7, 0, 8, 10]) (by decide +kernel)
def c422 : CNF.Clause Nat := [(20,false), (86,false), (87,false), (110,false), (11,false), (4,false), (38,false), (27,false), (28,false), (62,false)]
theorem p422 (F : Frame G 4) : c422.eval F.assign = true := by
  exact Rule.sound F (.path [1, 8, 7, 9, 10, 0, 3, 4, 2, 5, 6]) (by decide +kernel)
def c423 : CNF.Clause Nat := [(4,false), (38,false), (16,false), (17,false), (62,false), (29,false), (32,false), (87,false), (86,false), (99,false)]
theorem p423 (F : Frame G 4) : c423.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 1, 5, 6, 2, 9, 7, 8, 10]) (by decide +kernel)
def c424 : CNF.Clause Nat := [(4,false), (39,false), (62,false), (29,false), (27,false), (16,false), (20,false), (86,false), (87,false), (110,false)]
theorem p424 (F : Frame G 4) : c424.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 6, 2, 4, 1, 8, 7, 9, 10]) (by decide +kernel)
def c425 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (28,false), (29,false), (18,false), (20,false), (86,false), (87,false), (110,false)]
theorem p425 (F : Frame G 4) : c425.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 2, 6, 1, 8, 7, 9, 10]) (by decide +kernel)
def c426 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (62,false), (29,false), (32,false), (21,false), (20,false), (86,false), (88,false)]
theorem p426 (F : Frame G 4) : c426.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 6, 2, 9, 1, 8, 7, 10]) (by decide +kernel)
def c427 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (62,false), (29,false), (32,false), (87,false), (19,false), (20,false), (99,false)]
theorem p427 (F : Frame G 4) : c427.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 6, 2, 9, 7, 1, 8, 10]) (by decide +kernel)
def c428 : CNF.Clause Nat := [(4,false), (15,false), (16,false), (50,false), (62,false), (29,false), (32,false), (87,false), (86,false), (99,false)]
theorem p428 (F : Frame G 4) : c428.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 1, 4, 5, 6, 2, 9, 7, 8, 10]) (by decide +kernel)
def c429 : CNF.Clause Nat := [(4,false), (38,false), (16,false), (20,false), (86,false), (88,false), (110,false), (32,false), (28,false), (62,false)]
theorem p429 (F : Frame G 4) : c429.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 1, 8, 7, 10, 9, 2, 5, 6]) (by decide +kernel)
def c430 : CNF.Clause Nat := [(28,false), (39,false), (4,false), (5,false), (51,false), (18,false), (19,false), (86,false), (98,false), (110,false)]
theorem p430 (F : Frame G 4) : c430.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 0, 4, 6, 1, 7, 8, 9, 10]) (by decide +kernel)
def c431 : CNF.Clause Nat := [(28,false), (39,false), (4,false), (7,false), (51,false), (16,false), (19,false), (86,false), (98,false), (110,false)]
theorem p431 (F : Frame G 4) : c431.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 0, 6, 4, 1, 7, 8, 9, 10]) (by decide +kernel)
def c432 : CNF.Clause Nat := [(40,false), (38,false), (50,false), (6,false), (8,false), (19,false), (21,false), (32,false), (31,false), (99,false)]
theorem p432 (F : Frame G 4) : c432.eval F.assign = true := by
  exact Rule.sound F (.path [6, 3, 4, 5, 0, 7, 1, 9, 2, 8, 10]) (by decide +kernel)
def c433 : CNF.Clause Nat := [(29,false), (26,false), (38,false), (50,false), (17,false), (22,false), (11,false), (8,false), (86,false), (98,false)]
theorem p433 (F : Frame G 4) : c433.eval F.assign = true := by
  exact Rule.sound F (.path [6, 2, 3, 4, 5, 1, 10, 0, 7, 8, 9]) (by decide +kernel)
def c434 : CNF.Clause Nat := [(50,false), (16,false), (15,false), (4,false), (11,false), (99,false), (86,false), (87,false), (32,false), (29,false)]
theorem p434 (F : Frame G 4) : c434.eval F.assign = true := by
  exact Rule.sound F (.path [5, 4, 1, 3, 0, 10, 8, 7, 9, 2, 6]) (by decide +kernel)
def c435 : CNF.Clause Nat := [(16,false), (18,false), (40,false), (39,false), (28,false), (32,false), (10,false), (9,false), (86,false), (88,false)]
theorem p435 (F : Frame G 4) : c435.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 6, 3, 5, 2, 9, 0, 8, 7, 10]) (by decide +kernel)
def c436 : CNF.Clause Nat := [(16,false), (17,false), (39,false), (40,false), (29,false), (32,false), (10,false), (9,false), (86,false), (88,false)]
theorem p436 (F : Frame G 4) : c436.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 5, 3, 6, 2, 9, 0, 8, 7, 10]) (by decide +kernel)
def c437 : CNF.Clause Nat := [(16,false), (20,false), (86,false), (87,false), (32,false), (28,false), (39,false), (40,false), (7,false), (11,false)]
theorem p437 (F : Frame G 4) : c437.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 8, 7, 9, 2, 5, 3, 6, 0, 10]) (by decide +kernel)
def c438 : CNF.Clause Nat := [(16,false), (18,false), (40,false), (39,false), (28,false), (31,false), (86,false), (87,false), (10,false), (11,false)]
theorem p438 (F : Frame G 4) : c438.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 6, 3, 5, 2, 8, 7, 9, 0, 10]) (by decide +kernel)
def c439 : CNF.Clause Nat := [(16,false), (20,false), (9,false), (6,false), (39,false), (40,false), (29,false), (32,false), (87,false), (88,false)]
theorem p439 (F : Frame G 4) : c439.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 8, 0, 5, 3, 6, 2, 9, 7, 10]) (by decide +kernel)
def c440 : CNF.Clause Nat := [(39,false), (40,false), (7,false), (5,false), (16,false), (20,false), (31,false), (32,false), (87,false), (88,false)]
theorem p440 (F : Frame G 4) : c440.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 6, 0, 4, 1, 8, 2, 9, 7, 10]) (by decide +kernel)
def c441 : CNF.Clause Nat := [(50,false), (28,false), (31,false), (20,false), (22,false), (88,false), (87,false), (10,false), (4,false), (40,false)]
theorem p441 (F : Frame G 4) : c441.eval F.assign = true := by
  exact Rule.sound F (.path [4, 5, 2, 8, 1, 10, 7, 9, 0, 3, 6]) (by decide +kernel)
def c442 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (18,false), (29,false), (32,false), (87,false), (86,false), (9,false), (11,false)]
theorem p442 (F : Frame G 4) : c442.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 1, 6, 2, 9, 7, 8, 0, 10]) (by decide +kernel)
def c443 : CNF.Clause Nat := [(50,false), (16,false), (20,false), (9,false), (4,false), (40,false), (29,false), (32,false), (87,false), (88,false)]
theorem p443 (F : Frame G 4) : c443.eval F.assign = true := by
  exact Rule.sound F (.path [5, 4, 1, 8, 0, 3, 6, 2, 9, 7, 10]) (by decide +kernel)
def c444 : CNF.Clause Nat := [(32,false), (87,false), (88,false), (22,false), (20,false), (9,false), (6,false), (50,false), (38,false), (40,false)]
theorem p444 (F : Frame G 4) : c444.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 7, 10, 1, 8, 0, 5, 4, 3, 6]) (by decide +kernel)
def c445 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (40,false), (18,false), (22,false), (88,false), (86,false), (9,false), (10,false)]
theorem p445 (F : Frame G 4) : c445.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 6, 1, 10, 7, 8, 0, 9]) (by decide +kernel)
def c446 : CNF.Clause Nat := [(32,false), (87,false), (88,false), (11,false), (9,false), (20,false), (17,false), (50,false), (38,false), (40,false)]
theorem p446 (F : Frame G 4) : c446.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 7, 10, 0, 8, 1, 5, 4, 3, 6]) (by decide +kernel)
def c447 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (40,false), (18,false), (21,false), (87,false), (86,false), (9,false), (11,false)]
theorem p447 (F : Frame G 4) : c447.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 6, 1, 9, 7, 8, 0, 10]) (by decide +kernel)
def c448 : CNF.Clause Nat := [(28,false), (31,false), (20,false), (16,false), (38,false), (40,false), (7,false), (10,false), (87,false), (88,false)]
theorem p448 (F : Frame G 4) : c448.eval F.assign = true := by
  exact Rule.sound F (.path [5, 2, 8, 1, 4, 3, 6, 0, 9, 7, 10]) (by decide +kernel)
def c449 : CNF.Clause Nat := [(38,false), (40,false), (7,false), (6,false), (28,false), (31,false), (20,false), (21,false), (87,false), (88,false)]
theorem p449 (F : Frame G 4) : c449.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 6, 0, 5, 2, 8, 1, 9, 7, 10]) (by decide +kernel)
def c450 : CNF.Clause Nat := [(11,false), (88,false), (86,false), (20,false), (21,false), (32,false), (28,false), (50,false), (38,false), (40,false)]
theorem p450 (F : Frame G 4) : c450.eval F.assign = true := by
  exact Rule.sound F (.path [0, 10, 7, 8, 1, 9, 2, 5, 4, 3, 6]) (by decide +kernel)
def c451 : CNF.Clause Nat := [(26,false), (28,false), (50,false), (51,false), (7,false), (11,false), (22,false), (20,false), (86,false), (87,false)]
theorem p451 (F : Frame G 4) : c451.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 4, 6, 0, 10, 1, 8, 7, 9]) (by decide +kernel)
def c452 : CNF.Clause Nat := [(40,false), (29,false), (28,false), (50,false), (5,false), (11,false), (22,false), (20,false), (86,false), (87,false)]
theorem p452 (F : Frame G 4) : c452.eval F.assign = true := by
  exact Rule.sound F (.path [3, 6, 2, 5, 4, 0, 10, 1, 8, 7, 9]) (by decide +kernel)
def c453 : CNF.Clause Nat := [(28,false), (26,false), (40,false), (51,false), (5,false), (11,false), (22,false), (20,false), (86,false), (87,false)]
theorem p453 (F : Frame G 4) : c453.eval F.assign = true := by
  exact Rule.sound F (.path [5, 2, 3, 6, 4, 0, 10, 1, 8, 7, 9]) (by decide +kernel)
def c454 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (51,false), (18,false), (20,false), (31,false), (32,false), (87,false), (88,false)]
theorem p454 (F : Frame G 4) : c454.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 6, 1, 8, 2, 9, 7, 10]) (by decide +kernel)
def c455 : CNF.Clause Nat := [(7,false), (40,false), (39,false), (50,false), (16,false), (20,false), (31,false), (32,false), (87,false), (88,false)]
theorem p455 (F : Frame G 4) : c455.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 3, 5, 4, 1, 8, 2, 9, 7, 10]) (by decide +kernel)
def c456 : CNF.Clause Nat := [(28,false), (31,false), (20,false), (16,false), (51,false), (40,false), (4,false), (10,false), (87,false), (88,false)]
theorem p456 (F : Frame G 4) : c456.eval F.assign = true := by
  exact Rule.sound F (.path [5, 2, 8, 1, 4, 6, 3, 0, 9, 7, 10]) (by decide +kernel)
def c457 : CNF.Clause Nat := [(26,false), (28,false), (50,false), (51,false), (18,false), (21,false), (87,false), (86,false), (9,false), (11,false)]
theorem p457 (F : Frame G 4) : c457.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 4, 6, 1, 9, 7, 8, 0, 10]) (by decide +kernel)
def c458 : CNF.Clause Nat := [(40,false), (18,false), (16,false), (50,false), (28,false), (32,false), (10,false), (9,false), (86,false), (88,false)]
theorem p458 (F : Frame G 4) : c458.eval F.assign = true := by
  exact Rule.sound F (.path [3, 6, 1, 4, 5, 2, 9, 0, 8, 7, 10]) (by decide +kernel)
def c459 : CNF.Clause Nat := [(51,false), (40,false), (4,false), (9,false), (20,false), (22,false), (88,false), (87,false), (32,false), (28,false)]
theorem p459 (F : Frame G 4) : c459.eval F.assign = true := by
  exact Rule.sound F (.path [4, 6, 3, 0, 8, 1, 10, 7, 9, 2, 5]) (by decide +kernel)
def c460 : CNF.Clause Nat := [(32,false), (87,false), (88,false), (11,false), (9,false), (20,false), (15,false), (39,false), (50,false), (51,false)]
theorem p460 (F : Frame G 4) : c460.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 7, 10, 0, 8, 1, 3, 5, 4, 6]) (by decide +kernel)
def c461 : CNF.Clause Nat := [(26,false), (28,false), (50,false), (51,false), (7,false), (9,false), (20,false), (21,false), (87,false), (88,false)]
theorem p461 (F : Frame G 4) : c461.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 4, 6, 0, 8, 1, 9, 7, 10]) (by decide +kernel)
def c462 : CNF.Clause Nat := [(4,false), (6,false), (50,false), (51,false), (29,false), (32,false), (21,false), (20,false), (86,false), (88,false)]
theorem p462 (F : Frame G 4) : c462.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 5, 4, 6, 2, 9, 1, 8, 7, 10]) (by decide +kernel)
def c463 : CNF.Clause Nat := [(9,false), (86,false), (87,false), (21,false), (22,false), (33,false), (29,false), (51,false), (38,false), (39,false)]
theorem p463 (F : Frame G 4) : c463.eval F.assign = true := by
  exact Rule.sound F (.path [0, 8, 7, 9, 1, 10, 2, 6, 4, 3, 5]) (by decide +kernel)
def c464 : CNF.Clause Nat := [(29,false), (51,false), (38,false), (39,false), (17,false), (21,false), (87,false), (86,false), (9,false), (11,false)]
theorem p464 (F : Frame G 4) : c464.eval F.assign = true := by
  exact Rule.sound F (.path [2, 6, 4, 3, 5, 1, 9, 7, 8, 0, 10]) (by decide +kernel)
def c465 : CNF.Clause Nat := [(32,false), (87,false), (88,false), (22,false), (20,false), (9,false), (7,false), (51,false), (38,false), (39,false)]
theorem p465 (F : Frame G 4) : c465.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 7, 10, 1, 8, 0, 6, 4, 3, 5]) (by decide +kernel)
def c466 : CNF.Clause Nat := [(32,false), (87,false), (88,false), (11,false), (9,false), (20,false), (18,false), (51,false), (38,false), (39,false)]
theorem p466 (F : Frame G 4) : c466.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 7, 10, 0, 8, 1, 6, 4, 3, 5]) (by decide +kernel)
def c467 : CNF.Clause Nat := [(28,false), (29,false), (51,false), (38,false), (4,false), (11,false), (22,false), (20,false), (86,false), (87,false)]
theorem p467 (F : Frame G 4) : c467.eval F.assign = true := by
  exact Rule.sound F (.path [5, 2, 6, 4, 3, 0, 10, 1, 8, 7, 9]) (by decide +kernel)
def c468 : CNF.Clause Nat := [(39,false), (28,false), (29,false), (51,false), (16,false), (22,false), (88,false), (86,false), (9,false), (10,false)]
theorem p468 (F : Frame G 4) : c468.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 2, 6, 4, 1, 10, 7, 8, 0, 9]) (by decide +kernel)
def c469 : CNF.Clause Nat := [(39,false), (17,false), (16,false), (51,false), (29,false), (32,false), (10,false), (9,false), (86,false), (88,false)]
theorem p469 (F : Frame G 4) : c469.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 1, 4, 6, 2, 9, 0, 8, 7, 10]) (by decide +kernel)
def c470 : CNF.Clause Nat := [(18,false), (51,false), (50,false), (39,false), (26,false), (32,false), (10,false), (9,false), (86,false), (88,false)]
theorem p470 (F : Frame G 4) : c470.eval F.assign = true := by
  exact Rule.sound F (.path [1, 6, 4, 5, 3, 2, 9, 0, 8, 7, 10]) (by decide +kernel)
def c471 : CNF.Clause Nat := [(32,false), (87,false), (88,false), (22,false), (20,false), (9,false), (4,false), (39,false), (50,false), (51,false)]
theorem p471 (F : Frame G 4) : c471.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 7, 10, 1, 8, 0, 3, 5, 4, 6]) (by decide +kernel)
def c472 : CNF.Clause Nat := [(15,false), (20,false), (86,false), (88,false), (11,false), (10,false), (32,false), (28,false), (50,false), (51,false)]
theorem p472 (F : Frame G 4) : c472.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 8, 7, 10, 0, 9, 2, 5, 4, 6]) (by decide +kernel)
def c473 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (20,false), (9,false), (7,false), (29,false), (32,false), (87,false), (88,false)]
theorem p473 (F : Frame G 4) : c473.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 1, 8, 0, 6, 2, 9, 7, 10]) (by decide +kernel)
def c474 : CNF.Clause Nat := [(26,false), (28,false), (50,false), (51,false), (18,false), (22,false), (88,false), (86,false), (9,false), (10,false)]
theorem p474 (F : Frame G 4) : c474.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 4, 6, 1, 10, 7, 8, 0, 9]) (by decide +kernel)
def c475 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (9,false), (20,false), (18,false), (29,false), (32,false), (87,false), (88,false)]
theorem p475 (F : Frame G 4) : c475.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 0, 8, 1, 6, 2, 9, 7, 10]) (by decide +kernel)
def c476 : CNF.Clause Nat := [(20,false), (86,false), (87,false), (32,false), (33,false), (11,false), (6,false), (39,false), (38,false), (51,false)]
theorem p476 (F : Frame G 4) : c476.eval F.assign = true := by
  exact Rule.sound F (.path [1, 8, 7, 9, 2, 10, 0, 5, 3, 4, 6]) (by decide +kernel)
def c477 : CNF.Clause Nat := [(39,false), (4,false), (5,false), (51,false), (18,false), (20,false), (31,false), (32,false), (87,false), (88,false)]
theorem p477 (F : Frame G 4) : c477.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 0, 4, 6, 1, 8, 2, 9, 7, 10]) (by decide +kernel)
def c478 : CNF.Clause Nat := [(6,false), (4,false), (40,false), (51,false), (27,false), (31,false), (20,false), (21,false), (87,false), (88,false)]
theorem p478 (F : Frame G 4) : c478.eval F.assign = true := by
  exact Rule.sound F (.path [5, 0, 3, 6, 4, 2, 8, 1, 9, 7, 10]) (by decide +kernel)
def c479 : CNF.Clause Nat := [(51,false), (40,false), (4,false), (11,false), (33,false), (32,false), (87,false), (86,false), (20,false), (17,false)]
theorem p479 (F : Frame G 4) : c479.eval F.assign = true := by
  exact Rule.sound F (.path [4, 6, 3, 0, 10, 2, 9, 7, 8, 1, 5]) (by decide +kernel)
def c480 : CNF.Clause Nat := [(16,false), (20,false), (9,false), (11,false), (88,false), (87,false), (32,false), (26,false), (39,false), (62,false)]
theorem p480 (F : Frame G 4) : c480.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 8, 0, 10, 7, 9, 2, 3, 5, 6]) (by decide +kernel)
def c481 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (62,false), (29,false), (32,false), (10,false), (9,false), (86,false), (88,false)]
theorem p481 (F : Frame G 4) : c481.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 6, 2, 9, 0, 8, 7, 10]) (by decide +kernel)
def c482 : CNF.Clause Nat := [(15,false), (16,false), (51,false), (62,false), (28,false), (32,false), (87,false), (86,false), (9,false), (11,false)]
theorem p482 (F : Frame G 4) : c482.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 6, 5, 2, 9, 7, 8, 0, 10]) (by decide +kernel)
def c483 : CNF.Clause Nat := [(16,false), (20,false), (9,false), (4,false), (40,false), (62,false), (28,false), (32,false), (87,false), (88,false)]
theorem p483 (F : Frame G 4) : c483.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 8, 0, 3, 6, 5, 2, 9, 7, 10]) (by decide +kernel)
def c484 : CNF.Clause Nat := [(4,false), (40,false), (51,false), (50,false), (28,false), (31,false), (20,false), (21,false), (87,false), (88,false)]
theorem p484 (F : Frame G 4) : c484.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 6, 4, 5, 2, 8, 1, 9, 7, 10]) (by decide +kernel)
def c485 : CNF.Clause Nat := [(16,false), (20,false), (86,false), (87,false), (32,false), (33,false), (11,false), (4,false), (39,false), (62,false)]
theorem p485 (F : Frame G 4) : c485.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 8, 7, 9, 2, 10, 0, 3, 5, 6]) (by decide +kernel)
def c486 : CNF.Clause Nat := [(5,false), (4,false), (39,false), (62,false), (29,false), (31,false), (20,false), (21,false), (87,false), (88,false)]
theorem p486 (F : Frame G 4) : c486.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 3, 5, 6, 2, 8, 1, 9, 7, 10]) (by decide +kernel)
def c487 : CNF.Clause Nat := [(16,false), (20,false), (86,false), (87,false), (32,false), (29,false), (40,false), (39,false), (6,false), (11,false)]
theorem p487 (F : Frame G 4) : c487.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 8, 7, 9, 2, 6, 3, 5, 0, 10]) (by decide +kernel)
def c488 : CNF.Clause Nat := [(40,false), (7,false), (10,false), (87,false), (88,false), (33,false), (31,false), (20,false), (16,false), (50,false)]
theorem p488 (F : Frame G 4) : c488.eval F.assign = true := by
  exact Rule.sound F (.path [3, 6, 0, 9, 7, 10, 2, 8, 1, 4, 5]) (by decide +kernel)
def c489 : CNF.Clause Nat := [(5,false), (4,false), (40,false), (62,false), (17,false), (20,false), (31,false), (32,false), (87,false), (88,false)]
theorem p489 (F : Frame G 4) : c489.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 3, 6, 5, 1, 8, 2, 9, 7, 10]) (by decide +kernel)
def c490 : CNF.Clause Nat := [(28,false), (62,false), (51,false), (38,false), (4,false), (11,false), (22,false), (20,false), (86,false), (87,false)]
theorem p490 (F : Frame G 4) : c490.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 6, 4, 3, 0, 10, 1, 8, 7, 9]) (by decide +kernel)
def c491 : CNF.Clause Nat := [(16,false), (20,false), (86,false), (88,false), (11,false), (10,false), (32,false), (26,false), (40,false), (62,false)]
theorem p491 (F : Frame G 4) : c491.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 8, 7, 10, 0, 9, 2, 3, 6, 5]) (by decide +kernel)
def c492 : CNF.Clause Nat := [(16,false), (20,false), (31,false), (28,false), (62,false), (40,false), (4,false), (10,false), (87,false), (88,false)]
theorem p492 (F : Frame G 4) : c492.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 8, 2, 5, 6, 3, 0, 9, 7, 10]) (by decide +kernel)
def c493 : CNF.Clause Nat := [(4,false), (11,false), (88,false), (86,false), (31,false), (32,false), (21,false), (16,false), (50,false), (62,false)]
theorem p493 (F : Frame G 4) : c493.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 10, 7, 8, 2, 9, 1, 4, 5, 6]) (by decide +kernel)
def c494 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (62,false), (7,false), (10,false), (32,false), (31,false), (86,false), (88,false)]
theorem p494 (F : Frame G 4) : c494.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 6, 0, 9, 2, 8, 7, 10]) (by decide +kernel)
def c495 : CNF.Clause Nat := [(4,false), (9,false), (86,false), (88,false), (33,false), (32,false), (21,false), (16,false), (51,false), (62,false)]
theorem p495 (F : Frame G 4) : c495.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 8, 7, 10, 2, 9, 1, 4, 6, 5]) (by decide +kernel)
def c496 : CNF.Clause Nat := [(26,false), (32,false), (87,false), (88,false), (11,false), (9,false), (20,false), (16,false), (50,false), (62,false)]
theorem p496 (F : Frame G 4) : c496.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 9, 7, 10, 0, 8, 1, 4, 5, 6]) (by decide +kernel)
def c497 : CNF.Clause Nat := [(32,false), (87,false), (88,false), (11,false), (9,false), (20,false), (15,false), (38,false), (50,false), (62,false)]
theorem p497 (F : Frame G 4) : c497.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 7, 10, 0, 8, 1, 3, 4, 5, 6]) (by decide +kernel)
def c498 : CNF.Clause Nat := [(38,false), (15,false), (20,false), (31,false), (32,false), (87,false), (88,false), (11,false), (6,false), (62,false)]
theorem p498 (F : Frame G 4) : c498.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 1, 8, 2, 9, 7, 10, 0, 5, 6]) (by decide +kernel)
def c499 : CNF.Clause Nat := [(16,false), (20,false), (86,false), (87,false), (32,false), (26,false), (39,false), (62,false), (7,false), (11,false)]
theorem p499 (F : Frame G 4) : c499.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 8, 7, 9, 2, 3, 5, 6, 0, 10]) (by decide +kernel)
def c500 : CNF.Clause Nat := [(38,false), (4,false), (10,false), (87,false), (88,false), (22,false), (20,false), (31,false), (28,false), (62,false)]
theorem p500 (F : Frame G 4) : c500.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 0, 9, 7, 10, 1, 8, 2, 5, 6]) (by decide +kernel)
def c501 : CNF.Clause Nat := [(38,false), (16,false), (18,false), (62,false), (28,false), (33,false), (88,false), (86,false), (9,false), (10,false)]
theorem p501 (F : Frame G 4) : c501.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 1, 6, 5, 2, 10, 7, 8, 0, 9]) (by decide +kernel)
def c502 : CNF.Clause Nat := [(38,false), (51,false), (62,false), (17,false), (20,false), (9,false), (8,false), (87,false), (32,false), (33,false)]
theorem p502 (F : Frame G 4) : c502.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 6, 5, 1, 8, 0, 7, 9, 2, 10]) (by decide +kernel)
def c503 : CNF.Clause Nat := [(20,false), (86,false), (88,false), (33,false), (32,false), (10,false), (4,false), (38,false), (50,false), (62,false)]
theorem p503 (F : Frame G 4) : c503.eval F.assign = true := by
  exact Rule.sound F (.path [1, 8, 7, 10, 2, 9, 0, 3, 4, 5, 6]) (by decide +kernel)
def c504 : CNF.Clause Nat := [(20,false), (86,false), (88,false), (33,false), (32,false), (10,false), (4,false), (39,false), (62,false), (51,false)]
theorem p504 (F : Frame G 4) : c504.eval F.assign = true := by
  exact Rule.sound F (.path [1, 8, 7, 10, 2, 9, 0, 3, 5, 6, 4]) (by decide +kernel)
def c505 : CNF.Clause Nat := [(26,false), (29,false), (62,false), (50,false), (16,false), (20,false), (86,false), (87,false), (10,false), (11,false)]
theorem p505 (F : Frame G 4) : c505.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 6, 5, 4, 1, 8, 7, 9, 0, 10]) (by decide +kernel)
def c506 : CNF.Clause Nat := [(26,false), (29,false), (62,false), (50,false), (5,false), (8,false), (88,false), (22,false), (20,false), (98,false)]
theorem p506 (F : Frame G 4) : c506.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 6, 5, 4, 0, 7, 10, 1, 8, 9]) (by decide +kernel)
def c507 : CNF.Clause Nat := [(4,false), (11,false), (88,false), (86,false), (98,false), (21,false), (16,false), (27,false), (28,false), (62,false)]
theorem p507 (F : Frame G 4) : c507.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 10, 7, 8, 9, 1, 4, 2, 5, 6]) (by decide +kernel)
def c508 : CNF.Clause Nat := [(4,false), (7,false), (62,false), (50,false), (16,false), (20,false), (86,false), (87,false), (32,false), (33,false)]
theorem p508 (F : Frame G 4) : c508.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 5, 4, 1, 8, 7, 9, 2, 10]) (by decide +kernel)
def c509 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (16,false), (18,false), (7,false), (11,false), (88,false), (86,false), (98,false)]
theorem p509 (F : Frame G 4) : c509.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 1, 6, 0, 10, 7, 8, 9]) (by decide +kernel)
def c510 : CNF.Clause Nat := [(26,false), (38,false), (50,false), (62,false), (18,false), (20,false), (98,false), (10,false), (8,false), (88,false)]
theorem p510 (F : Frame G 4) : c510.eval F.assign = true := by
  exact Rule.sound F (.path [2, 3, 4, 5, 6, 1, 8, 9, 0, 7, 10]) (by decide +kernel)
def c511 : CNF.Clause Nat := [(28,false), (62,false), (18,false), (15,false), (38,false), (5,false), (9,false), (98,false), (87,false), (88,false)]
theorem p511 (F : Frame G 4) : c511.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 6, 1, 3, 4, 0, 8, 9, 7, 10]) (by decide +kernel)
def c512 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (16,false), (18,false), (7,false), (9,false), (98,false), (87,false), (88,false)]
theorem p512 (F : Frame G 4) : c512.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 1, 6, 0, 8, 9, 7, 10]) (by decide +kernel)
def c513 : CNF.Clause Nat := [(26,false), (38,false), (51,false), (62,false), (17,false), (20,false), (98,false), (10,false), (8,false), (88,false)]
theorem p513 (F : Frame G 4) : c513.eval F.assign = true := by
  exact Rule.sound F (.path [2, 3, 4, 6, 5, 1, 8, 9, 0, 7, 10]) (by decide +kernel)
def c514 : CNF.Clause Nat := [(32,false), (98,false), (86,false), (88,false), (22,false), (18,false), (51,false), (5,false), (4,false), (39,false)]
theorem p514 (F : Frame G 4) : c514.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 8, 7, 10, 1, 6, 4, 0, 3, 5]) (by decide +kernel)
def c515 : CNF.Clause Nat := [(32,false), (98,false), (86,false), (88,false), (11,false), (4,false), (39,false), (50,false), (16,false), (18,false)]
theorem p515 (F : Frame G 4) : c515.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 8, 7, 10, 0, 3, 5, 4, 1, 6]) (by decide +kernel)
def c516 : CNF.Clause Nat := [(22,false), (88,false), (86,false), (98,false), (32,false), (26,false), (4,false), (6,false), (50,false), (51,false)]
theorem p516 (F : Frame G 4) : c516.eval F.assign = true := by
  exact Rule.sound F (.path [1, 10, 7, 8, 9, 2, 3, 0, 5, 4, 6]) (by decide +kernel)
def c517 : CNF.Clause Nat := [(32,false), (98,false), (20,false), (19,false), (88,false), (11,false), (4,false), (38,false), (50,false), (62,false)]
theorem p517 (F : Frame G 4) : c517.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 8, 1, 7, 10, 0, 3, 4, 5, 6]) (by decide +kernel)
def c518 : CNF.Clause Nat := [(32,false), (98,false), (86,false), (88,false), (22,false), (16,false), (38,false), (4,false), (6,false), (62,false)]
theorem p518 (F : Frame G 4) : c518.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 8, 7, 10, 1, 4, 3, 0, 5, 6]) (by decide +kernel)
def c519 : CNF.Clause Nat := [(32,false), (98,false), (86,false), (88,false), (11,false), (4,false), (38,false), (16,false), (17,false), (62,false)]
theorem p519 (F : Frame G 4) : c519.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 8, 7, 10, 0, 3, 4, 1, 5, 6]) (by decide +kernel)
def c520 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (51,false), (7,false), (8,false), (88,false), (22,false), (20,false), (98,false)]
theorem p520 (F : Frame G 4) : c520.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 6, 0, 7, 10, 1, 8, 9]) (by decide +kernel)
def c521 : CNF.Clause Nat := [(20,false), (98,false), (32,false), (33,false), (88,false), (8,false), (4,false), (38,false), (51,false), (62,false)]
theorem p521 (F : Frame G 4) : c521.eval F.assign = true := by
  exact Rule.sound F (.path [1, 8, 9, 2, 10, 7, 0, 3, 4, 6, 5]) (by decide +kernel)
def c522 : CNF.Clause Nat := [(4,false), (7,false), (62,false), (50,false), (16,false), (20,false), (31,false), (32,false), (87,false), (88,false)]
theorem p522 (F : Frame G 4) : c522.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 5, 4, 1, 8, 2, 9, 7, 10]) (by decide +kernel)
def c523 : CNF.Clause Nat := [(4,false), (11,false), (88,false), (87,false), (98,false), (20,false), (16,false), (27,false), (28,false), (62,false)]
theorem p523 (F : Frame G 4) : c523.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 10, 7, 9, 8, 1, 4, 2, 5, 6]) (by decide +kernel)
def c524 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (16,false), (18,false), (29,false), (33,false), (88,false), (86,false), (98,false)]
theorem p524 (F : Frame G 4) : c524.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 1, 6, 2, 10, 7, 8, 9]) (by decide +kernel)
def c525 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (27,false), (29,false), (18,false), (20,false), (98,false), (87,false), (88,false)]
theorem p525 (F : Frame G 4) : c525.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 2, 6, 1, 8, 9, 7, 10]) (by decide +kernel)
def c526 : CNF.Clause Nat := [(29,false), (62,false), (39,false), (4,false), (5,false), (16,false), (21,false), (98,false), (86,false), (88,false)]
theorem p526 (F : Frame G 4) : c526.eval F.assign = true := by
  exact Rule.sound F (.path [2, 6, 5, 3, 0, 4, 1, 9, 8, 7, 10]) (by decide +kernel)
def c527 : CNF.Clause Nat := [(32,false), (98,false), (86,false), (88,false), (22,false), (15,false), (4,false), (5,false), (50,false), (62,false)]
theorem p527 (F : Frame G 4) : c527.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 8, 7, 10, 1, 3, 0, 4, 5, 6]) (by decide +kernel)
def c528 : CNF.Clause Nat := [(28,false), (39,false), (4,false), (7,false), (51,false), (16,false), (20,false), (86,false), (87,false), (110,false)]
theorem p528 (F : Frame G 4) : c528.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 0, 6, 4, 1, 8, 7, 9, 10]) (by decide +kernel)
def c529 : CNF.Clause Nat := [(28,false), (39,false), (4,false), (5,false), (51,false), (18,false), (20,false), (86,false), (87,false), (110,false)]
theorem p529 (F : Frame G 4) : c529.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 0, 4, 6, 1, 8, 7, 9, 10]) (by decide +kernel)
def c530 : CNF.Clause Nat := [(32,false), (98,false), (86,false), (88,false), (11,false), (4,false), (15,false), (16,false), (50,false), (62,false)]
theorem p530 (F : Frame G 4) : c530.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 8, 7, 10, 0, 3, 1, 4, 5, 6]) (by decide +kernel)
def c531 : CNF.Clause Nat := [(26,false), (28,false), (62,false), (51,false), (5,false), (8,false), (88,false), (22,false), (20,false), (98,false)]
theorem p531 (F : Frame G 4) : c531.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 6, 4, 0, 7, 10, 1, 8, 9]) (by decide +kernel)
def c532 : CNF.Clause Nat := [(39,false), (50,false), (51,false), (29,false), (30,false), (8,false), (11,false), (22,false), (20,false), (98,false)]
theorem p532 (F : Frame G 4) : c532.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 6, 2, 7, 0, 10, 1, 8, 9]) (by decide +kernel)
def c533 : CNF.Clause Nat := [(28,false), (39,false), (4,false), (5,false), (51,false), (18,false), (20,false), (98,false), (87,false), (88,false)]
theorem p533 (F : Frame G 4) : c533.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 0, 4, 6, 1, 8, 9, 7, 10]) (by decide +kernel)
def c534 : CNF.Clause Nat := [(39,false), (62,false), (51,false), (16,false), (20,false), (9,false), (10,false), (32,false), (30,false), (88,false)]
theorem p534 (F : Frame G 4) : c534.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 6, 4, 1, 8, 0, 9, 2, 7, 10]) (by decide +kernel)
def c535 : CNF.Clause Nat := [(4,false), (9,false), (98,false), (87,false), (88,false), (22,false), (16,false), (27,false), (28,false), (62,false)]
theorem p535 (F : Frame G 4) : c535.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 8, 9, 7, 10, 1, 4, 2, 5, 6]) (by decide +kernel)
def c536 : CNF.Clause Nat := [(28,false), (39,false), (40,false), (51,false), (16,false), (20,false), (98,false), (10,false), (8,false), (88,false)]
theorem p536 (F : Frame G 4) : c536.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 6, 4, 1, 8, 9, 0, 7, 10]) (by decide +kernel)
def c537 : CNF.Clause Nat := [(4,false), (40,false), (51,false), (50,false), (28,false), (32,false), (98,false), (20,false), (19,false), (88,false)]
theorem p537 (F : Frame G 4) : c537.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 6, 4, 5, 2, 9, 8, 1, 7, 10]) (by decide +kernel)
def c538 : CNF.Clause Nat := [(4,false), (40,false), (51,false), (50,false), (17,false), (20,false), (98,false), (32,false), (30,false), (88,false)]
theorem p538 (F : Frame G 4) : c538.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 6, 4, 5, 1, 8, 9, 2, 7, 10]) (by decide +kernel)
def c539 : CNF.Clause Nat := [(4,false), (6,false), (50,false), (51,false), (18,false), (20,false), (98,false), (32,false), (30,false), (88,false)]
theorem p539 (F : Frame G 4) : c539.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 5, 4, 6, 1, 8, 9, 2, 7, 10]) (by decide +kernel)
def c540 : CNF.Clause Nat := [(40,false), (51,false), (50,false), (6,false), (8,false), (30,false), (33,false), (22,false), (20,false), (98,false)]
theorem p540 (F : Frame G 4) : c540.eval F.assign = true := by
  exact Rule.sound F (.path [3, 6, 4, 5, 0, 7, 2, 10, 1, 8, 9]) (by decide +kernel)
def c541 : CNF.Clause Nat := [(32,false), (21,false), (16,false), (50,false), (39,false), (40,false), (7,false), (9,false), (86,false), (88,false)]
theorem p541 (F : Frame G 4) : c541.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 1, 4, 5, 3, 6, 0, 8, 7, 10]) (by decide +kernel)
def c542 : CNF.Clause Nat := [(38,false), (39,false), (62,false), (29,false), (32,false), (21,false), (20,false), (9,false), (8,false), (88,false)]
theorem p542 (F : Frame G 4) : c542.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 6, 2, 9, 1, 8, 0, 7, 10]) (by decide +kernel)
def c543 : CNF.Clause Nat := [(4,false), (38,false), (16,false), (18,false), (62,false), (28,false), (31,false), (98,false), (87,false), (88,false)]
theorem p543 (F : Frame G 4) : c543.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 1, 6, 5, 2, 8, 9, 7, 10]) (by decide +kernel)
def c544 : CNF.Clause Nat := [(20,false), (98,false), (87,false), (88,false), (33,false), (29,false), (7,false), (4,false), (38,false), (50,false)]
theorem p544 (F : Frame G 4) : c544.eval F.assign = true := by
  exact Rule.sound F (.path [1, 8, 9, 7, 10, 2, 6, 0, 3, 4, 5]) (by decide +kernel)
def c545 : CNF.Clause Nat := [(16,false), (20,false), (98,false), (10,false), (4,false), (39,false), (62,false), (29,false), (30,false), (88,false)]
theorem p545 (F : Frame G 4) : c545.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 8, 9, 0, 3, 5, 6, 2, 7, 10]) (by decide +kernel)
def c546 : CNF.Clause Nat := [(4,false), (38,false), (16,false), (20,false), (98,false), (87,false), (88,false), (33,false), (28,false), (62,false)]
theorem p546 (F : Frame G 4) : c546.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 1, 8, 9, 7, 10, 2, 5, 6]) (by decide +kernel)
def c547 : CNF.Clause Nat := [(28,false), (32,false), (98,false), (86,false), (88,false), (11,false), (5,false), (16,false), (15,false), (40,false)]
theorem p547 (F : Frame G 4) : c547.eval F.assign = true := by
  exact Rule.sound F (.path [5, 2, 9, 8, 7, 10, 0, 4, 1, 3, 6]) (by decide +kernel)
def c548 : CNF.Clause Nat := [(50,false), (16,false), (18,false), (40,false), (4,false), (8,false), (88,false), (33,false), (31,false), (98,false)]
theorem p548 (F : Frame G 4) : c548.eval F.assign = true := by
  exact Rule.sound F (.path [5, 4, 1, 6, 3, 0, 7, 10, 2, 8, 9]) (by decide +kernel)
def c549 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (40,false), (7,false), (10,false), (87,false), (86,false), (20,false), (22,false)]
theorem p549 (F : Frame G 4) : c549.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 6, 0, 9, 7, 8, 1, 10]) (by decide +kernel)
def c550 : CNF.Clause Nat := [(17,false), (16,false), (38,false), (40,false), (7,false), (11,false), (33,false), (32,false), (87,false), (86,false)]
theorem p550 (F : Frame G 4) : c550.eval F.assign = true := by
  exact Rule.sound F (.path [5, 1, 4, 3, 6, 0, 10, 2, 9, 7, 8]) (by decide +kernel)
def c551 : CNF.Clause Nat := [(18,false), (40,false), (38,false), (50,false), (28,false), (33,false), (11,false), (8,false), (86,false), (98,false)]
theorem p551 (F : Frame G 4) : c551.eval F.assign = true := by
  exact Rule.sound F (.path [1, 6, 3, 4, 5, 2, 10, 0, 7, 8, 9]) (by decide +kernel)
def c552 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (40,false), (7,false), (8,false), (87,false), (98,false), (20,false), (22,false)]
theorem p552 (F : Frame G 4) : c552.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 6, 0, 7, 9, 8, 1, 10]) (by decide +kernel)
def c553 : CNF.Clause Nat := [(16,false), (18,false), (40,false), (39,false), (6,false), (8,false), (86,false), (98,false), (32,false), (33,false)]
theorem p553 (F : Frame G 4) : c553.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 6, 3, 5, 0, 7, 8, 9, 2, 10]) (by decide +kernel)
def c554 : CNF.Clause Nat := [(16,false), (17,false), (39,false), (40,false), (29,false), (31,false), (98,false), (87,false), (8,false), (11,false)]
theorem p554 (F : Frame G 4) : c554.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 5, 3, 6, 2, 8, 9, 7, 0, 10]) (by decide +kernel)
def c555 : CNF.Clause Nat := [(16,false), (17,false), (39,false), (40,false), (29,false), (33,false), (11,false), (8,false), (86,false), (98,false)]
theorem p555 (F : Frame G 4) : c555.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 5, 3, 6, 2, 10, 0, 7, 8, 9]) (by decide +kernel)
def c556 : CNF.Clause Nat := [(16,false), (17,false), (39,false), (40,false), (7,false), (8,false), (86,false), (98,false), (32,false), (33,false)]
theorem p556 (F : Frame G 4) : c556.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 5, 3, 6, 0, 7, 8, 9, 2, 10]) (by decide +kernel)
def c557 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (40,false), (29,false), (32,false), (98,false), (9,false), (8,false), (88,false)]
theorem p557 (F : Frame G 4) : c557.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 6, 2, 9, 8, 0, 7, 10]) (by decide +kernel)
def c558 : CNF.Clause Nat := [(28,false), (29,false), (40,false), (38,false), (5,false), (10,false), (87,false), (86,false), (20,false), (22,false)]
theorem p558 (F : Frame G 4) : c558.eval F.assign = true := by
  exact Rule.sound F (.path [5, 2, 6, 3, 4, 0, 9, 7, 8, 1, 10]) (by decide +kernel)
def c559 : CNF.Clause Nat := [(6,false), (4,false), (38,false), (16,false), (18,false), (29,false), (33,false), (88,false), (86,false), (98,false)]
theorem p559 (F : Frame G 4) : c559.eval F.assign = true := by
  exact Rule.sound F (.path [5, 0, 3, 4, 1, 6, 2, 10, 7, 8, 9]) (by decide +kernel)
def c560 : CNF.Clause Nat := [(4,false), (40,false), (18,false), (16,false), (50,false), (28,false), (33,false), (88,false), (86,false), (98,false)]
theorem p560 (F : Frame G 4) : c560.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 6, 1, 4, 5, 2, 10, 7, 8, 9]) (by decide +kernel)
def c561 : CNF.Clause Nat := [(28,false), (29,false), (40,false), (38,false), (5,false), (10,false), (98,false), (20,false), (19,false), (88,false)]
theorem p561 (F : Frame G 4) : c561.eval F.assign = true := by
  exact Rule.sound F (.path [5, 2, 6, 3, 4, 0, 9, 8, 1, 7, 10]) (by decide +kernel)
def c562 : CNF.Clause Nat := [(39,false), (38,false), (16,false), (20,false), (98,false), (10,false), (7,false), (29,false), (30,false), (88,false)]
theorem p562 (F : Frame G 4) : c562.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 4, 1, 8, 9, 0, 6, 2, 7, 10]) (by decide +kernel)
def c563 : CNF.Clause Nat := [(38,false), (40,false), (7,false), (6,false), (28,false), (32,false), (98,false), (20,false), (19,false), (88,false)]
theorem p563 (F : Frame G 4) : c563.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 6, 0, 5, 2, 9, 8, 1, 7, 10]) (by decide +kernel)
def c564 : CNF.Clause Nat := [(50,false), (38,false), (40,false), (7,false), (8,false), (30,false), (33,false), (22,false), (20,false), (98,false)]
theorem p564 (F : Frame G 4) : c564.eval F.assign = true := by
  exact Rule.sound F (.path [5, 4, 3, 6, 0, 7, 2, 10, 1, 8, 9]) (by decide +kernel)
def c565 : CNF.Clause Nat := [(22,false), (88,false), (86,false), (98,false), (32,false), (29,false), (7,false), (4,false), (38,false), (50,false)]
theorem p565 (F : Frame G 4) : c565.eval F.assign = true := by
  exact Rule.sound F (.path [1, 10, 7, 8, 9, 2, 6, 0, 3, 4, 5]) (by decide +kernel)
def c566 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (62,false), (29,false), (32,false), (98,false), (86,false), (8,false), (11,false)]
theorem p566 (F : Frame G 4) : c566.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 6, 2, 9, 8, 7, 0, 10]) (by decide +kernel)
def c567 : CNF.Clause Nat := [(22,false), (88,false), (86,false), (31,false), (32,false), (10,false), (4,false), (38,false), (50,false), (62,false)]
theorem p567 (F : Frame G 4) : c567.eval F.assign = true := by
  exact Rule.sound F (.path [1, 10, 7, 8, 2, 9, 0, 3, 4, 5, 6]) (by decide +kernel)
def c568 : CNF.Clause Nat := [(28,false), (62,false), (51,false), (38,false), (4,false), (8,false), (88,false), (22,false), (20,false), (98,false)]
theorem p568 (F : Frame G 4) : c568.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 6, 4, 3, 0, 7, 10, 1, 8, 9]) (by decide +kernel)
def c569 : CNF.Clause Nat := [(8,false), (88,false), (22,false), (16,false), (38,false), (39,false), (62,false), (29,false), (31,false), (98,false)]
theorem p569 (F : Frame G 4) : c569.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 10, 1, 4, 3, 5, 6, 2, 8, 9]) (by decide +kernel)
def c570 : CNF.Clause Nat := [(29,false), (62,false), (39,false), (38,false), (16,false), (20,false), (98,false), (10,false), (8,false), (88,false)]
theorem p570 (F : Frame G 4) : c570.eval F.assign = true := by
  exact Rule.sound F (.path [2, 6, 5, 3, 4, 1, 8, 9, 0, 7, 10]) (by decide +kernel)
def c571 : CNF.Clause Nat := [(11,false), (88,false), (87,false), (98,false), (31,false), (28,false), (17,false), (15,false), (38,false), (51,false)]
theorem p571 (F : Frame G 4) : c571.eval F.assign = true := by
  exact Rule.sound F (.path [0, 10, 7, 9, 8, 2, 5, 1, 3, 4, 6]) (by decide +kernel)
def c572 : CNF.Clause Nat := [(11,false), (88,false), (87,false), (98,false), (31,false), (28,false), (17,false), (16,false), (38,false), (40,false)]
theorem p572 (F : Frame G 4) : c572.eval F.assign = true := by
  exact Rule.sound F (.path [0, 10, 7, 9, 8, 2, 5, 1, 4, 3, 6]) (by decide +kernel)
def c573 : CNF.Clause Nat := [(8,false), (88,false), (33,false), (28,false), (39,false), (38,false), (51,false), (18,false), (20,false), (98,false)]
theorem p573 (F : Frame G 4) : c573.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 10, 2, 5, 3, 4, 6, 1, 8, 9]) (by decide +kernel)
def c574 : CNF.Clause Nat := [(28,false), (33,false), (88,false), (87,false), (21,false), (20,false), (9,false), (4,false), (38,false), (51,false)]
theorem p574 (F : Frame G 4) : c574.eval F.assign = true := by
  exact Rule.sound F (.path [5, 2, 10, 7, 9, 1, 8, 0, 3, 4, 6]) (by decide +kernel)
def c575 : CNF.Clause Nat := [(4,false), (40,false), (62,false), (50,false), (27,false), (32,false), (98,false), (20,false), (19,false), (88,false)]
theorem p575 (F : Frame G 4) : c575.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 6, 5, 4, 2, 9, 8, 1, 7, 10]) (by decide +kernel)
def c576 : CNF.Clause Nat := [(26,false), (40,false), (62,false), (50,false), (5,false), (11,false), (22,false), (20,false), (86,false), (87,false)]
theorem p576 (F : Frame G 4) : c576.eval F.assign = true := by
  exact Rule.sound F (.path [2, 3, 6, 5, 4, 0, 10, 1, 8, 7, 9]) (by decide +kernel)
def c577 : CNF.Clause Nat := [(40,false), (62,false), (50,false), (16,false), (21,false), (32,false), (33,false), (11,false), (8,false), (86,false)]
theorem p577 (F : Frame G 4) : c577.eval F.assign = true := by
  exact Rule.sound F (.path [3, 6, 5, 4, 1, 9, 2, 10, 0, 7, 8]) (by decide +kernel)
def c578 : CNF.Clause Nat := [(26,false), (40,false), (62,false), (50,false), (5,false), (11,false), (88,false), (19,false), (20,false), (98,false)]
theorem p578 (F : Frame G 4) : c578.eval F.assign = true := by
  exact Rule.sound F (.path [2, 3, 6, 5, 4, 0, 10, 7, 1, 8, 9]) (by decide +kernel)
def c579 : CNF.Clause Nat := [(4,false), (7,false), (62,false), (50,false), (16,false), (20,false), (98,false), (32,false), (30,false), (88,false)]
theorem p579 (F : Frame G 4) : c579.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 5, 4, 1, 8, 9, 2, 7, 10]) (by decide +kernel)
def c580 : CNF.Clause Nat := [(4,false), (40,false), (62,false), (50,false), (16,false), (20,false), (98,false), (32,false), (30,false), (88,false)]
theorem p580 (F : Frame G 4) : c580.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 6, 5, 4, 1, 8, 9, 2, 7, 10]) (by decide +kernel)
def c581 : CNF.Clause Nat := [(4,false), (7,false), (62,false), (50,false), (27,false), (32,false), (98,false), (20,false), (19,false), (88,false)]
theorem p581 (F : Frame G 4) : c581.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 5, 4, 2, 9, 8, 1, 7, 10]) (by decide +kernel)
def c582 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (9,false), (20,false), (18,false), (29,false), (32,false), (87,false), (88,false)]
theorem p582 (F : Frame G 4) : c582.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 0, 8, 1, 6, 2, 9, 7, 10]) (by decide +kernel)
def c583 : CNF.Clause Nat := [(32,false), (98,false), (20,false), (16,false), (51,false), (40,false), (39,false), (6,false), (8,false), (88,false)]
theorem p583 (F : Frame G 4) : c583.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 8, 1, 4, 6, 3, 5, 0, 7, 10]) (by decide +kernel)
def c584 : CNF.Clause Nat := [(4,false), (6,false), (62,false), (51,false), (27,false), (32,false), (98,false), (20,false), (19,false), (88,false)]
theorem p584 (F : Frame G 4) : c584.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 5, 6, 4, 2, 9, 8, 1, 7, 10]) (by decide +kernel)
def c585 : CNF.Clause Nat := [(40,false), (51,false), (5,false), (6,false), (28,false), (31,false), (20,false), (21,false), (87,false), (88,false)]
theorem p585 (F : Frame G 4) : c585.eval F.assign = true := by
  exact Rule.sound F (.path [3, 6, 4, 0, 5, 2, 8, 1, 9, 7, 10]) (by decide +kernel)
def c586 : CNF.Clause Nat := [(4,false), (6,false), (62,false), (51,false), (16,false), (20,false), (98,false), (32,false), (30,false), (88,false)]
theorem p586 (F : Frame G 4) : c586.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 5, 6, 4, 1, 8, 9, 2, 7, 10]) (by decide +kernel)
def c587 : CNF.Clause Nat := [(40,false), (51,false), (5,false), (6,false), (28,false), (32,false), (98,false), (20,false), (19,false), (88,false)]
theorem p587 (F : Frame G 4) : c587.eval F.assign = true := by
  exact Rule.sound F (.path [3, 6, 4, 0, 5, 2, 9, 8, 1, 7, 10]) (by decide +kernel)
def c588 : CNF.Clause Nat := [(15,false), (16,false), (51,false), (7,false), (6,false), (28,false), (33,false), (88,false), (86,false), (98,false)]
theorem p588 (F : Frame G 4) : c588.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 6, 0, 5, 2, 10, 7, 8, 9]) (by decide +kernel)
def c589 : CNF.Clause Nat := [(16,false), (51,false), (40,false), (4,false), (6,false), (28,false), (33,false), (88,false), (86,false), (98,false)]
theorem p589 (F : Frame G 4) : c589.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 6, 3, 0, 5, 2, 10, 7, 8, 9]) (by decide +kernel)
def c590 : CNF.Clause Nat := [(4,false), (39,false), (28,false), (29,false), (51,false), (16,false), (22,false), (88,false), (86,false), (98,false)]
theorem p590 (F : Frame G 4) : c590.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 2, 6, 4, 1, 10, 7, 8, 9]) (by decide +kernel)
def c591 : CNF.Clause Nat := [(4,false), (26,false), (32,false), (98,false), (86,false), (88,false), (22,false), (16,false), (50,false), (62,false)]
theorem p591 (F : Frame G 4) : c591.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 2, 9, 8, 7, 10, 1, 4, 5, 6]) (by decide +kernel)
def c592 : CNF.Clause Nat := [(4,false), (40,false), (51,false), (50,false), (17,false), (20,false), (86,false), (87,false), (32,false), (33,false)]
theorem p592 (F : Frame G 4) : c592.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 6, 4, 5, 1, 8, 7, 9, 2, 10]) (by decide +kernel)
def c593 : CNF.Clause Nat := [(39,false), (40,false), (7,false), (5,false), (16,false), (20,false), (98,false), (32,false), (30,false), (88,false)]
theorem p593 (F : Frame G 4) : c593.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 6, 0, 4, 1, 8, 9, 2, 7, 10]) (by decide +kernel)
def c594 : CNF.Clause Nat := [(7,false), (40,false), (39,false), (50,false), (27,false), (33,false), (22,false), (20,false), (86,false), (87,false)]
theorem p594 (F : Frame G 4) : c594.eval F.assign = true := by
  exact Rule.sound F (.path [0, 6, 3, 5, 4, 2, 10, 1, 8, 7, 9]) (by decide +kernel)
def c595 : CNF.Clause Nat := [(28,false), (39,false), (40,false), (7,false), (5,false), (16,false), (22,false), (88,false), (86,false), (98,false)]
theorem p595 (F : Frame G 4) : c595.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 6, 0, 4, 1, 10, 7, 8, 9]) (by decide +kernel)
def c596 : CNF.Clause Nat := [(4,false), (39,false), (17,false), (16,false), (51,false), (29,false), (31,false), (98,false), (87,false), (88,false)]
theorem p596 (F : Frame G 4) : c596.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 1, 4, 6, 2, 8, 9, 7, 10]) (by decide +kernel)
def c597 : CNF.Clause Nat := [(51,false), (40,false), (39,false), (28,false), (33,false), (11,false), (8,false), (19,false), (20,false), (98,false)]
theorem p597 (F : Frame G 4) : c597.eval F.assign = true := by
  exact Rule.sound F (.path [4, 6, 3, 5, 2, 10, 0, 7, 1, 8, 9]) (by decide +kernel)
def c598 : CNF.Clause Nat := [(20,false), (98,false), (87,false), (88,false), (11,false), (4,false), (39,false), (28,false), (27,false), (51,false)]
theorem p598 (F : Frame G 4) : c598.eval F.assign = true := by
  exact Rule.sound F (.path [1, 8, 9, 7, 10, 0, 3, 5, 2, 4, 6]) (by decide +kernel)
def c599 : CNF.Clause Nat := [(20,false), (98,false), (87,false), (88,false), (11,false), (4,false), (26,false), (28,false), (50,false), (51,false)]
theorem p599 (F : Frame G 4) : c599.eval F.assign = true := by
  exact Rule.sound F (.path [1, 8, 9, 7, 10, 0, 3, 2, 5, 4, 6]) (by decide +kernel)
def c600 : CNF.Clause Nat := [(39,false), (28,false), (29,false), (51,false), (5,false), (10,false), (98,false), (20,false), (19,false), (88,false)]
theorem p600 (F : Frame G 4) : c600.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 2, 6, 4, 0, 9, 8, 1, 7, 10]) (by decide +kernel)
end Cert44Steps
end Graffiti199Depleted.Catalogue.OrderEleven
