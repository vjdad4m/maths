import Local44Part1
namespace Graffiti199Depleted.Catalogue.OrderEleven
namespace Cert44Steps
open Std.Sat
set_option maxRecDepth 4096
set_option maxHeartbeats 0
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj]
def c601 : CNF.Clause Nat := [(39,false), (28,false), (29,false), (51,false), (5,false), (11,false), (88,false), (19,false), (20,false), (98,false)]
theorem p601 (F : Frame G 4) : c601.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 2, 6, 4, 0, 10, 7, 1, 8, 9]) (by decide +kernel)
def c602 : CNF.Clause Nat := [(26,false), (39,false), (50,false), (5,false), (7,false), (18,false), (20,false), (98,false), (87,false), (88,false)]
theorem p602 (F : Frame G 4) : c602.eval F.assign = true := by
  exact Rule.sound F (.path [2, 3, 5, 4, 0, 6, 1, 8, 9, 7, 10]) (by decide +kernel)
def c603 : CNF.Clause Nat := [(4,false), (6,false), (50,false), (51,false), (18,false), (22,false), (88,false), (86,false), (31,false), (32,false)]
theorem p603 (F : Frame G 4) : c603.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 5, 4, 6, 1, 10, 7, 8, 2, 9]) (by decide +kernel)
def c604 : CNF.Clause Nat := [(51,false), (7,false), (4,false), (39,false), (28,false), (32,false), (98,false), (20,false), (19,false), (88,false)]
theorem p604 (F : Frame G 4) : c604.eval F.assign = true := by
  exact Rule.sound F (.path [4, 6, 0, 3, 5, 2, 9, 8, 1, 7, 10]) (by decide +kernel)
def c605 : CNF.Clause Nat := [(5,false), (6,false), (39,false), (40,false), (18,false), (20,false), (98,false), (32,false), (30,false), (88,false)]
theorem p605 (F : Frame G 4) : c605.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 5, 3, 6, 1, 8, 9, 2, 7, 10]) (by decide +kernel)
def c606 : CNF.Clause Nat := [(16,false), (17,false), (39,false), (40,false), (29,false), (32,false), (98,false), (9,false), (8,false), (88,false)]
theorem p606 (F : Frame G 4) : c606.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 5, 3, 6, 2, 9, 8, 0, 7, 10]) (by decide +kernel)
def c607 : CNF.Clause Nat := [(15,false), (22,false), (11,false), (6,false), (50,false), (51,false), (29,false), (30,false), (86,false), (98,false)]
theorem p607 (F : Frame G 4) : c607.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 10, 0, 5, 4, 6, 2, 7, 8, 9]) (by decide +kernel)
def c608 : CNF.Clause Nat := [(15,false), (22,false), (11,false), (6,false), (50,false), (51,false), (29,false), (31,false), (86,false), (87,false)]
theorem p608 (F : Frame G 4) : c608.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 10, 0, 5, 4, 6, 2, 8, 7, 9]) (by decide +kernel)
def c609 : CNF.Clause Nat := [(28,false), (50,false), (51,false), (40,false), (4,false), (11,false), (22,false), (20,false), (86,false), (87,false)]
theorem p609 (F : Frame G 4) : c609.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 6, 3, 0, 10, 1, 8, 7, 9]) (by decide +kernel)
def c610 : CNF.Clause Nat := [(28,false), (50,false), (5,false), (4,false), (40,false), (18,false), (20,false), (98,false), (87,false), (88,false)]
theorem p610 (F : Frame G 4) : c610.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 0, 3, 6, 1, 8, 9, 7, 10]) (by decide +kernel)
def c611 : CNF.Clause Nat := [(20,false), (98,false), (87,false), (88,false), (33,false), (28,false), (39,false), (4,false), (5,false), (51,false)]
theorem p611 (F : Frame G 4) : c611.eval F.assign = true := by
  exact Rule.sound F (.path [1, 8, 9, 7, 10, 2, 5, 3, 0, 4, 6]) (by decide +kernel)
def c612 : CNF.Clause Nat := [(4,false), (7,false), (51,false), (50,false), (28,false), (33,false), (88,false), (19,false), (20,false), (98,false)]
theorem p612 (F : Frame G 4) : c612.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 4, 5, 2, 10, 7, 1, 8, 9]) (by decide +kernel)
def c613 : CNF.Clause Nat := [(4,false), (7,false), (51,false), (50,false), (17,false), (20,false), (98,false), (32,false), (30,false), (88,false)]
theorem p613 (F : Frame G 4) : c613.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 4, 5, 1, 8, 9, 2, 7, 10]) (by decide +kernel)
def c614 : CNF.Clause Nat := [(4,false), (11,false), (88,false), (86,false), (98,false), (32,false), (28,false), (17,false), (16,false), (51,false)]
theorem p614 (F : Frame G 4) : c614.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 10, 7, 8, 9, 2, 5, 1, 4, 6]) (by decide +kernel)
def c615 : CNF.Clause Nat := [(15,false), (17,false), (50,false), (51,false), (29,false), (33,false), (88,false), (8,false), (9,false), (98,false)]
theorem p615 (F : Frame G 4) : c615.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 5, 4, 6, 2, 10, 7, 0, 8, 9]) (by decide +kernel)
def c616 : CNF.Clause Nat := [(15,false), (40,false), (51,false), (50,false), (6,false), (9,false), (98,false), (32,false), (30,false), (88,false)]
theorem p616 (F : Frame G 4) : c616.eval F.assign = true := by
  exact Rule.sound F (.path [1, 3, 6, 4, 5, 0, 8, 9, 2, 7, 10]) (by decide +kernel)
def c617 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (40,false), (29,false), (31,false), (98,false), (87,false), (8,false), (11,false)]
theorem p617 (F : Frame G 4) : c617.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 6, 2, 8, 9, 7, 0, 10]) (by decide +kernel)
def c618 : CNF.Clause Nat := [(4,false), (7,false), (51,false), (50,false), (17,false), (20,false), (86,false), (87,false), (32,false), (33,false)]
theorem p618 (F : Frame G 4) : c618.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 4, 5, 1, 8, 7, 9, 2, 10]) (by decide +kernel)
def c619 : CNF.Clause Nat := [(16,false), (51,false), (7,false), (4,false), (39,false), (28,false), (32,false), (98,false), (86,false), (88,false)]
theorem p619 (F : Frame G 4) : c619.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 6, 0, 3, 5, 2, 9, 8, 7, 10]) (by decide +kernel)
def c620 : CNF.Clause Nat := [(50,false), (28,false), (26,false), (40,false), (7,false), (8,false), (88,false), (22,false), (20,false), (98,false)]
theorem p620 (F : Frame G 4) : c620.eval F.assign = true := by
  exact Rule.sound F (.path [4, 5, 2, 3, 6, 0, 7, 10, 1, 8, 9]) (by decide +kernel)
def c621 : CNF.Clause Nat := [(27,false), (28,false), (39,false), (40,false), (7,false), (8,false), (88,false), (22,false), (20,false), (98,false)]
theorem p621 (F : Frame G 4) : c621.eval F.assign = true := by
  exact Rule.sound F (.path [4, 2, 5, 3, 6, 0, 7, 10, 1, 8, 9]) (by decide +kernel)
def c622 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (4,false), (7,false), (18,false), (22,false), (88,false), (86,false), (98,false)]
theorem p622 (F : Frame G 4) : c622.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 0, 6, 1, 10, 7, 8, 9]) (by decide +kernel)
def c623 : CNF.Clause Nat := [(50,false), (16,false), (18,false), (40,false), (26,false), (32,false), (98,false), (86,false), (8,false), (11,false)]
theorem p623 (F : Frame G 4) : c623.eval F.assign = true := by
  exact Rule.sound F (.path [5, 4, 1, 6, 3, 2, 9, 8, 7, 0, 10]) (by decide +kernel)
def c624 : CNF.Clause Nat := [(38,false), (40,false), (18,false), (17,false), (28,false), (32,false), (98,false), (86,false), (8,false), (11,false)]
theorem p624 (F : Frame G 4) : c624.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 6, 1, 5, 2, 9, 8, 7, 0, 10]) (by decide +kernel)
def c625 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (8,false), (87,false), (98,false), (20,false), (18,false), (29,false), (33,false)]
theorem p625 (F : Frame G 4) : c625.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 0, 7, 9, 8, 1, 6, 2, 10]) (by decide +kernel)
def c626 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (7,false), (29,false), (30,false), (88,false), (22,false), (20,false), (98,false)]
theorem p626 (F : Frame G 4) : c626.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 0, 6, 2, 7, 10, 1, 8, 9]) (by decide +kernel)
def c627 : CNF.Clause Nat := [(28,false), (39,false), (40,false), (18,false), (16,false), (5,false), (11,false), (88,false), (86,false), (98,false)]
theorem p627 (F : Frame G 4) : c627.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 6, 1, 4, 0, 10, 7, 8, 9]) (by decide +kernel)
def c628 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (21,false), (32,false), (29,false), (7,false), (8,false), (86,false), (99,false)]
theorem p628 (F : Frame G 4) : c628.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 1, 9, 2, 6, 0, 7, 8, 10]) (by decide +kernel)
def c629 : CNF.Clause Nat := [(27,false), (28,false), (39,false), (40,false), (18,false), (21,false), (98,false), (86,false), (8,false), (11,false)]
theorem p629 (F : Frame G 4) : c629.eval F.assign = true := by
  exact Rule.sound F (.path [4, 2, 5, 3, 6, 1, 9, 8, 7, 0, 10]) (by decide +kernel)
def c630 : CNF.Clause Nat := [(4,false), (39,false), (28,false), (27,false), (51,false), (18,false), (22,false), (88,false), (86,false), (98,false)]
theorem p630 (F : Frame G 4) : c630.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 2, 4, 6, 1, 10, 7, 8, 9]) (by decide +kernel)
def c631 : CNF.Clause Nat := [(8,false), (87,false), (98,false), (99,false), (22,false), (16,false), (27,false), (28,false), (39,false), (40,false)]
theorem p631 (F : Frame G 4) : c631.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 9, 8, 10, 1, 4, 2, 5, 3, 6]) (by decide +kernel)
def c632 : CNF.Clause Nat := [(28,false), (29,false), (51,false), (38,false), (15,false), (19,false), (8,false), (10,false), (98,false), (99,false)]
theorem p632 (F : Frame G 4) : c632.eval F.assign = true := by
  exact Rule.sound F (.path [5, 2, 6, 4, 3, 1, 7, 0, 9, 8, 10]) (by decide +kernel)
def c633 : CNF.Clause Nat := [(39,false), (4,false), (10,false), (32,false), (27,false), (51,false), (18,false), (19,false), (86,false), (99,false)]
theorem p633 (F : Frame G 4) : c633.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 0, 9, 2, 4, 6, 1, 7, 8, 10]) (by decide +kernel)
def c634 : CNF.Clause Nat := [(39,false), (4,false), (10,false), (32,false), (27,false), (51,false), (18,false), (20,false), (86,false), (88,false)]
theorem p634 (F : Frame G 4) : c634.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 0, 9, 2, 4, 6, 1, 8, 7, 10]) (by decide +kernel)
def c635 : CNF.Clause Nat := [(18,false), (51,false), (38,false), (39,false), (28,false), (32,false), (10,false), (8,false), (86,false), (99,false)]
theorem p635 (F : Frame G 4) : c635.eval F.assign = true := by
  exact Rule.sound F (.path [1, 6, 4, 3, 5, 2, 9, 0, 7, 8, 10]) (by decide +kernel)
def c636 : CNF.Clause Nat := [(32,false), (98,false), (99,false), (88,false), (19,false), (18,false), (51,false), (5,false), (4,false), (39,false)]
theorem p636 (F : Frame G 4) : c636.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 8, 10, 7, 1, 6, 4, 0, 3, 5]) (by decide +kernel)
def c637 : CNF.Clause Nat := [(28,false), (39,false), (4,false), (11,false), (88,false), (86,false), (98,false), (21,false), (16,false), (51,false)]
theorem p637 (F : Frame G 4) : c637.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 0, 10, 7, 8, 9, 1, 4, 6]) (by decide +kernel)
def c638 : CNF.Clause Nat := [(8,false), (88,false), (99,false), (98,false), (32,false), (28,false), (17,false), (15,false), (38,false), (51,false)]
theorem p638 (F : Frame G 4) : c638.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 10, 8, 9, 2, 5, 1, 3, 4, 6]) (by decide +kernel)
def c639 : CNF.Clause Nat := [(8,false), (88,false), (99,false), (98,false), (32,false), (28,false), (17,false), (16,false), (38,false), (40,false)]
theorem p639 (F : Frame G 4) : c639.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 10, 8, 9, 2, 5, 1, 4, 3, 6]) (by decide +kernel)
def c640 : CNF.Clause Nat := [(39,false), (40,false), (51,false), (5,false), (8,false), (30,false), (32,false), (21,false), (20,false), (99,false)]
theorem p640 (F : Frame G 4) : c640.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 6, 4, 0, 7, 2, 9, 1, 8, 10]) (by decide +kernel)
def c641 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (51,false), (18,false), (20,false), (98,false), (32,false), (30,false), (88,false)]
theorem p641 (F : Frame G 4) : c641.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 6, 1, 8, 9, 2, 7, 10]) (by decide +kernel)
def c642 : CNF.Clause Nat := [(8,false), (88,false), (99,false), (98,false), (32,false), (28,false), (39,false), (15,false), (16,false), (51,false)]
theorem p642 (F : Frame G 4) : c642.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 10, 8, 9, 2, 5, 3, 1, 4, 6]) (by decide +kernel)
def c643 : CNF.Clause Nat := [(16,false), (20,false), (98,false), (87,false), (88,false), (33,false), (28,false), (6,false), (4,false), (40,false)]
theorem p643 (F : Frame G 4) : c643.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 8, 9, 7, 10, 2, 5, 0, 3, 6]) (by decide +kernel)
def c644 : CNF.Clause Nat := [(40,false), (18,false), (16,false), (27,false), (28,false), (6,false), (10,false), (98,false), (86,false), (88,false)]
theorem p644 (F : Frame G 4) : c644.eval F.assign = true := by
  exact Rule.sound F (.path [3, 6, 1, 4, 2, 5, 0, 9, 8, 7, 10]) (by decide +kernel)
def c645 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (40,false), (29,false), (32,false), (10,false), (8,false), (86,false), (99,false)]
theorem p645 (F : Frame G 4) : c645.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 6, 2, 9, 0, 7, 8, 10]) (by decide +kernel)
def c646 : CNF.Clause Nat := [(16,false), (21,false), (98,false), (86,false), (88,false), (33,false), (28,false), (6,false), (4,false), (40,false)]
theorem p646 (F : Frame G 4) : c646.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 9, 8, 7, 10, 2, 5, 0, 3, 6]) (by decide +kernel)
def c647 : CNF.Clause Nat := [(28,false), (29,false), (7,false), (4,false), (38,false), (16,false), (21,false), (98,false), (86,false), (88,false)]
theorem p647 (F : Frame G 4) : c647.eval F.assign = true := by
  exact Rule.sound F (.path [5, 2, 6, 0, 3, 4, 1, 9, 8, 7, 10]) (by decide +kernel)
def c648 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (4,false), (7,false), (29,false), (32,false), (87,false), (86,false), (99,false)]
theorem p648 (F : Frame G 4) : c648.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 0, 6, 2, 9, 7, 8, 10]) (by decide +kernel)
def c649 : CNF.Clause Nat := [(16,false), (50,false), (28,false), (29,false), (40,false), (4,false), (11,false), (88,false), (86,false), (98,false)]
theorem p649 (F : Frame G 4) : c649.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 2, 6, 3, 0, 10, 7, 8, 9]) (by decide +kernel)
def c650 : CNF.Clause Nat := [(17,false), (20,false), (99,false), (11,false), (4,false), (38,false), (51,false), (29,false), (30,false), (87,false)]
theorem p650 (F : Frame G 4) : c650.eval F.assign = true := by
  exact Rule.sound F (.path [5, 1, 8, 10, 0, 3, 4, 6, 2, 7, 9]) (by decide +kernel)
def c651 : CNF.Clause Nat := [(17,false), (20,false), (99,false), (88,false), (87,false), (10,false), (4,false), (26,false), (27,false), (51,false)]
theorem p651 (F : Frame G 4) : c651.eval F.assign = true := by
  exact Rule.sound F (.path [5, 1, 8, 10, 7, 9, 0, 3, 2, 4, 6]) (by decide +kernel)
def c652 : CNF.Clause Nat := [(17,false), (15,false), (38,false), (51,false), (29,false), (32,false), (10,false), (8,false), (86,false), (99,false)]
theorem p652 (F : Frame G 4) : c652.eval F.assign = true := by
  exact Rule.sound F (.path [5, 1, 3, 4, 6, 2, 9, 0, 7, 8, 10]) (by decide +kernel)
def c653 : CNF.Clause Nat := [(16,false), (17,false), (39,false), (40,false), (7,false), (8,false), (87,false), (32,false), (31,false), (99,false)]
theorem p653 (F : Frame G 4) : c653.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 5, 3, 6, 0, 7, 9, 2, 8, 10]) (by decide +kernel)
def c654 : CNF.Clause Nat := [(39,false), (40,false), (51,false), (27,false), (32,false), (21,false), (19,false), (8,false), (9,false), (99,false)]
theorem p654 (F : Frame G 4) : c654.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 6, 4, 2, 9, 1, 7, 0, 8, 10]) (by decide +kernel)
def c655 : CNF.Clause Nat := [(20,false), (99,false), (88,false), (87,false), (32,false), (27,false), (51,false), (7,false), (4,false), (39,false)]
theorem p655 (F : Frame G 4) : c655.eval F.assign = true := by
  exact Rule.sound F (.path [1, 8, 10, 7, 9, 2, 4, 6, 0, 3, 5]) (by decide +kernel)
def c656 : CNF.Clause Nat := [(16,false), (51,false), (40,false), (39,false), (28,false), (32,false), (10,false), (8,false), (86,false), (99,false)]
theorem p656 (F : Frame G 4) : c656.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 6, 3, 5, 2, 9, 0, 7, 8, 10]) (by decide +kernel)
def c657 : CNF.Clause Nat := [(20,false), (99,false), (88,false), (87,false), (32,false), (28,false), (6,false), (4,false), (38,false), (51,false)]
theorem p657 (F : Frame G 4) : c657.eval F.assign = true := by
  exact Rule.sound F (.path [1, 8, 10, 7, 9, 2, 5, 0, 3, 4, 6]) (by decide +kernel)
def c658 : CNF.Clause Nat := [(17,false), (28,false), (32,false), (87,false), (88,false), (99,false), (9,false), (4,false), (38,false), (51,false)]
theorem p658 (F : Frame G 4) : c658.eval F.assign = true := by
  exact Rule.sound F (.path [1, 5, 2, 9, 7, 10, 8, 0, 3, 4, 6]) (by decide +kernel)
def c659 : CNF.Clause Nat := [(16,false), (17,false), (39,false), (40,false), (7,false), (9,false), (86,false), (87,false), (32,false), (33,false)]
theorem p659 (F : Frame G 4) : c659.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 5, 3, 6, 0, 8, 7, 9, 2, 10]) (by decide +kernel)
def c660 : CNF.Clause Nat := [(6,false), (50,false), (51,false), (40,false), (15,false), (22,false), (88,false), (30,false), (31,false), (98,false)]
theorem p660 (F : Frame G 4) : c660.eval F.assign = true := by
  exact Rule.sound F (.path [0, 5, 4, 6, 3, 1, 10, 7, 2, 8, 9]) (by decide +kernel)
def c661 : CNF.Clause Nat := [(16,false), (50,false), (6,false), (4,false), (40,false), (29,false), (30,false), (87,false), (98,false), (99,false)]
theorem p661 (F : Frame G 4) : c661.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 0, 3, 6, 2, 7, 9, 8, 10]) (by decide +kernel)
def c662 : CNF.Clause Nat := [(6,false), (8,false), (88,false), (99,false), (98,false), (32,false), (27,false), (16,false), (15,false), (40,false)]
theorem p662 (F : Frame G 4) : c662.eval F.assign = true := by
  exact Rule.sound F (.path [5, 0, 7, 10, 8, 9, 2, 4, 1, 3, 6]) (by decide +kernel)
def c663 : CNF.Clause Nat := [(6,false), (50,false), (38,false), (40,false), (29,false), (32,false), (87,false), (19,false), (20,false), (99,false)]
theorem p663 (F : Frame G 4) : c663.eval F.assign = true := by
  exact Rule.sound F (.path [0, 5, 4, 3, 6, 2, 9, 7, 1, 8, 10]) (by decide +kernel)
def c664 : CNF.Clause Nat := [(4,false), (40,false), (29,false), (28,false), (50,false), (16,false), (22,false), (88,false), (86,false), (98,false)]
theorem p664 (F : Frame G 4) : c664.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 6, 2, 5, 4, 1, 10, 7, 8, 9]) (by decide +kernel)
def c665 : CNF.Clause Nat := [(16,false), (38,false), (40,false), (62,false), (28,false), (32,false), (10,false), (8,false), (86,false), (99,false)]
theorem p665 (F : Frame G 4) : c665.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 6, 5, 2, 9, 0, 7, 8, 10]) (by decide +kernel)
def c666 : CNF.Clause Nat := [(38,false), (4,false), (6,false), (62,false), (29,false), (32,false), (21,false), (19,false), (86,false), (99,false)]
theorem p666 (F : Frame G 4) : c666.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 0, 5, 6, 2, 9, 1, 7, 8, 10]) (by decide +kernel)
def c667 : CNF.Clause Nat := [(5,false), (4,false), (40,false), (62,false), (28,false), (33,false), (22,false), (19,false), (86,false), (98,false)]
theorem p667 (F : Frame G 4) : c667.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 3, 6, 5, 2, 10, 1, 7, 8, 9]) (by decide +kernel)
def c668 : CNF.Clause Nat := [(16,false), (38,false), (40,false), (62,false), (6,false), (8,false), (86,false), (98,false), (32,false), (33,false)]
theorem p668 (F : Frame G 4) : c668.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 6, 5, 0, 7, 8, 9, 2, 10]) (by decide +kernel)
def c669 : CNF.Clause Nat := [(38,false), (4,false), (7,false), (62,false), (17,false), (22,false), (99,false), (86,false), (30,false), (32,false)]
theorem p669 (F : Frame G 4) : c669.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 0, 6, 5, 1, 10, 8, 7, 2, 9]) (by decide +kernel)
def c670 : CNF.Clause Nat := [(8,false), (86,false), (98,false), (32,false), (33,false), (22,false), (17,false), (62,false), (40,false), (38,false)]
theorem p670 (F : Frame G 4) : c670.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 8, 9, 2, 10, 1, 5, 6, 3, 4]) (by decide +kernel)
def c671 : CNF.Clause Nat := [(4,false), (5,false), (51,false), (62,false), (17,false), (22,false), (99,false), (86,false), (30,false), (32,false)]
theorem p671 (F : Frame G 4) : c671.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 4, 6, 5, 1, 10, 8, 7, 2, 9]) (by decide +kernel)
def c672 : CNF.Clause Nat := [(8,false), (86,false), (99,false), (22,false), (21,false), (32,false), (28,false), (62,false), (40,false), (38,false)]
theorem p672 (F : Frame G 4) : c672.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 8, 10, 1, 9, 2, 5, 6, 3, 4]) (by decide +kernel)
def c673 : CNF.Clause Nat := [(38,false), (5,false), (8,false), (19,false), (22,false), (99,false), (98,false), (32,false), (28,false), (62,false)]
theorem p673 (F : Frame G 4) : c673.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 0, 7, 1, 10, 8, 9, 2, 5, 6]) (by decide +kernel)
def c674 : CNF.Clause Nat := [(4,false), (8,false), (86,false), (98,false), (32,false), (27,false), (51,false), (62,false), (17,false), (22,false)]
theorem p674 (F : Frame G 4) : c674.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 7, 8, 9, 2, 4, 6, 5, 1, 10]) (by decide +kernel)
def c675 : CNF.Clause Nat := [(38,false), (40,false), (62,false), (28,false), (32,false), (10,false), (8,false), (19,false), (20,false), (99,false)]
theorem p675 (F : Frame G 4) : c675.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 6, 5, 2, 9, 0, 7, 1, 8, 10]) (by decide +kernel)
def c676 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (40,false), (18,false), (20,false), (98,false), (87,false), (8,false), (11,false)]
theorem p676 (F : Frame G 4) : c676.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 6, 1, 8, 9, 7, 0, 10]) (by decide +kernel)
def c677 : CNF.Clause Nat := [(20,false), (98,false), (32,false), (27,false), (38,false), (40,false), (62,false), (6,false), (8,false), (88,false)]
theorem p677 (F : Frame G 4) : c677.eval F.assign = true := by
  exact Rule.sound F (.path [1, 8, 9, 2, 4, 3, 6, 5, 0, 7, 10]) (by decide +kernel)
def c678 : CNF.Clause Nat := [(16,false), (38,false), (40,false), (62,false), (6,false), (8,false), (30,false), (32,false), (98,false), (99,false)]
theorem p678 (F : Frame G 4) : c678.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 6, 5, 0, 7, 2, 9, 8, 10]) (by decide +kernel)
def c679 : CNF.Clause Nat := [(28,false), (62,false), (40,false), (38,false), (5,false), (8,false), (87,false), (21,false), (20,false), (99,false)]
theorem p679 (F : Frame G 4) : c679.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 6, 3, 4, 0, 7, 9, 1, 8, 10]) (by decide +kernel)
def c680 : CNF.Clause Nat := [(28,false), (62,false), (40,false), (38,false), (16,false), (20,false), (98,false), (10,false), (8,false), (88,false)]
theorem p680 (F : Frame G 4) : c680.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 6, 3, 4, 1, 8, 9, 0, 7, 10]) (by decide +kernel)
def c681 : CNF.Clause Nat := [(28,false), (62,false), (7,false), (4,false), (38,false), (16,false), (20,false), (98,false), (87,false), (88,false)]
theorem p681 (F : Frame G 4) : c681.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 6, 0, 3, 4, 1, 8, 9, 7, 10]) (by decide +kernel)
def c682 : CNF.Clause Nat := [(6,false), (4,false), (38,false), (51,false), (18,false), (19,false), (88,false), (99,false), (31,false), (32,false)]
theorem p682 (F : Frame G 4) : c682.eval F.assign = true := by
  exact Rule.sound F (.path [5, 0, 3, 4, 6, 1, 7, 10, 8, 2, 9]) (by decide +kernel)
def c683 : CNF.Clause Nat := [(38,false), (5,false), (8,false), (87,false), (32,false), (28,false), (62,false), (18,false), (20,false), (99,false)]
theorem p683 (F : Frame G 4) : c683.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 0, 7, 9, 2, 5, 6, 1, 8, 10]) (by decide +kernel)
def c684 : CNF.Clause Nat := [(8,false), (88,false), (99,false), (98,false), (32,false), (29,false), (18,false), (15,false), (38,false), (50,false)]
theorem p684 (F : Frame G 4) : c684.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 10, 8, 9, 2, 6, 1, 3, 4, 5]) (by decide +kernel)
def c685 : CNF.Clause Nat := [(8,false), (88,false), (99,false), (20,false), (21,false), (32,false), (29,false), (40,false), (38,false), (50,false)]
theorem p685 (F : Frame G 4) : c685.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 10, 8, 1, 9, 2, 6, 3, 4, 5]) (by decide +kernel)
def c686 : CNF.Clause Nat := [(4,false), (8,false), (88,false), (99,false), (98,false), (21,false), (16,false), (50,false), (28,false), (29,false)]
theorem p686 (F : Frame G 4) : c686.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 7, 10, 8, 9, 1, 4, 5, 2, 6]) (by decide +kernel)
def c687 : CNF.Clause Nat := [(4,false), (8,false), (88,false), (22,false), (16,false), (50,false), (62,false), (29,false), (31,false), (98,false)]
theorem p687 (F : Frame G 4) : c687.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 7, 10, 1, 4, 5, 6, 2, 8, 9]) (by decide +kernel)
def c688 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (8,false), (88,false), (33,false), (29,false), (18,false), (20,false), (98,false)]
theorem p688 (F : Frame G 4) : c688.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 0, 7, 10, 2, 6, 1, 8, 9]) (by decide +kernel)
def c689 : CNF.Clause Nat := [(28,false), (39,false), (40,false), (7,false), (5,false), (16,false), (20,false), (98,false), (87,false), (88,false)]
theorem p689 (F : Frame G 4) : c689.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 6, 0, 4, 1, 8, 9, 7, 10]) (by decide +kernel)
def c690 : CNF.Clause Nat := [(4,false), (40,false), (51,false), (50,false), (28,false), (32,false), (21,false), (20,false), (86,false), (88,false)]
theorem p690 (F : Frame G 4) : c690.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 6, 4, 5, 2, 9, 1, 8, 7, 10]) (by decide +kernel)
def c691 : CNF.Clause Nat := [(32,false), (87,false), (86,false), (99,false), (22,false), (15,false), (4,false), (6,false), (50,false), (51,false)]
theorem p691 (F : Frame G 4) : c691.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 7, 8, 10, 1, 3, 0, 5, 4, 6]) (by decide +kernel)
def c692 : CNF.Clause Nat := [(28,false), (50,false), (51,false), (40,false), (4,false), (10,false), (98,false), (20,false), (22,false), (88,false)]
theorem p692 (F : Frame G 4) : c692.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 6, 3, 0, 9, 8, 1, 10, 7]) (by decide +kernel)
def c693 : CNF.Clause Nat := [(40,false), (7,false), (6,false), (50,false), (16,false), (20,false), (86,false), (87,false), (32,false), (33,false)]
theorem p693 (F : Frame G 4) : c693.eval F.assign = true := by
  exact Rule.sound F (.path [3, 6, 0, 5, 4, 1, 8, 7, 9, 2, 10]) (by decide +kernel)
def c694 : CNF.Clause Nat := [(4,false), (6,false), (50,false), (51,false), (18,false), (20,false), (86,false), (87,false), (32,false), (33,false)]
theorem p694 (F : Frame G 4) : c694.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 5, 4, 6, 1, 8, 7, 9, 2, 10]) (by decide +kernel)
def c695 : CNF.Clause Nat := [(20,false), (98,false), (10,false), (6,false), (50,false), (38,false), (40,false), (29,false), (30,false), (88,false)]
theorem p695 (F : Frame G 4) : c695.eval F.assign = true := by
  exact Rule.sound F (.path [1, 8, 9, 0, 5, 4, 3, 6, 2, 7, 10]) (by decide +kernel)
def c696 : CNF.Clause Nat := [(15,false), (40,false), (51,false), (50,false), (6,false), (8,false), (88,false), (33,false), (31,false), (98,false)]
theorem p696 (F : Frame G 4) : c696.eval F.assign = true := by
  exact Rule.sound F (.path [1, 3, 6, 4, 5, 0, 7, 10, 2, 8, 9]) (by decide +kernel)
def c697 : CNF.Clause Nat := [(8,false), (87,false), (98,false), (99,false), (33,false), (26,false), (40,false), (18,false), (16,false), (50,false)]
theorem p697 (F : Frame G 4) : c697.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 9, 8, 10, 2, 3, 6, 1, 4, 5]) (by decide +kernel)
def c698 : CNF.Clause Nat := [(4,false), (26,false), (28,false), (50,false), (51,false), (18,false), (20,false), (98,false), (87,false), (88,false)]
theorem p698 (F : Frame G 4) : c698.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 2, 5, 4, 6, 1, 8, 9, 7, 10]) (by decide +kernel)
def c699 : CNF.Clause Nat := [(40,false), (7,false), (8,false), (87,false), (98,false), (99,false), (33,false), (27,false), (16,false), (17,false)]
theorem p699 (F : Frame G 4) : c699.eval F.assign = true := by
  exact Rule.sound F (.path [3, 6, 0, 7, 9, 8, 10, 2, 4, 1, 5]) (by decide +kernel)
def c700 : CNF.Clause Nat := [(32,false), (98,false), (99,false), (88,false), (19,false), (16,false), (50,false), (6,false), (4,false), (40,false)]
theorem p700 (F : Frame G 4) : c700.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 8, 10, 7, 1, 4, 5, 0, 3, 6]) (by decide +kernel)
def c701 : CNF.Clause Nat := [(32,false), (98,false), (99,false), (88,false), (8,false), (5,false), (50,false), (17,false), (15,false), (40,false)]
theorem p701 (F : Frame G 4) : c701.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 8, 10, 7, 0, 4, 5, 1, 3, 6]) (by decide +kernel)
def c702 : CNF.Clause Nat := [(50,false), (28,false), (26,false), (40,false), (7,false), (8,false), (88,false), (99,false), (20,false), (21,false)]
theorem p702 (F : Frame G 4) : c702.eval F.assign = true := by
  exact Rule.sound F (.path [4, 5, 2, 3, 6, 0, 7, 10, 8, 1, 9]) (by decide +kernel)
def c703 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (40,false), (7,false), (8,false), (88,false), (22,false), (20,false), (98,false)]
theorem p703 (F : Frame G 4) : c703.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 6, 0, 7, 10, 1, 8, 9]) (by decide +kernel)
def c704 : CNF.Clause Nat := [(11,false), (88,false), (86,false), (98,false), (32,false), (28,false), (39,false), (38,false), (16,false), (18,false)]
theorem p704 (F : Frame G 4) : c704.eval F.assign = true := by
  exact Rule.sound F (.path [0, 10, 7, 8, 9, 2, 5, 3, 4, 1, 6]) (by decide +kernel)
def c705 : CNF.Clause Nat := [(28,false), (62,false), (40,false), (4,false), (5,false), (16,false), (19,false), (88,false), (99,false), (98,false)]
theorem p705 (F : Frame G 4) : c705.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 6, 3, 0, 4, 1, 7, 10, 8, 9]) (by decide +kernel)
def c706 : CNF.Clause Nat := [(4,false), (40,false), (51,false), (16,false), (17,false), (28,false), (32,false), (98,false), (86,false), (88,false)]
theorem p706 (F : Frame G 4) : c706.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 6, 4, 1, 5, 2, 9, 8, 7, 10]) (by decide +kernel)
def c707 : CNF.Clause Nat := [(26,false), (28,false), (50,false), (51,false), (18,false), (19,false), (8,false), (10,false), (98,false), (99,false)]
theorem p707 (F : Frame G 4) : c707.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 4, 6, 1, 7, 0, 9, 8, 10]) (by decide +kernel)
def c708 : CNF.Clause Nat := [(26,false), (28,false), (50,false), (51,false), (7,false), (8,false), (88,false), (99,false), (20,false), (21,false)]
theorem p708 (F : Frame G 4) : c708.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 4, 6, 0, 7, 10, 8, 1, 9]) (by decide +kernel)
def c709 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (4,false), (7,false), (18,false), (21,false), (98,false), (86,false), (88,false)]
theorem p709 (F : Frame G 4) : c709.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 0, 6, 1, 9, 8, 7, 10]) (by decide +kernel)
def c710 : CNF.Clause Nat := [(16,false), (50,false), (6,false), (7,false), (40,false), (26,false), (30,false), (88,false), (99,false), (98,false)]
theorem p710 (F : Frame G 4) : c710.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 0, 6, 3, 2, 7, 10, 8, 9]) (by decide +kernel)
def c711 : CNF.Clause Nat := [(28,false), (50,false), (51,false), (40,false), (4,false), (8,false), (87,false), (21,false), (20,false), (99,false)]
theorem p711 (F : Frame G 4) : c711.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 6, 3, 0, 7, 9, 1, 8, 10]) (by decide +kernel)
def c712 : CNF.Clause Nat := [(16,false), (15,false), (40,false), (7,false), (10,false), (98,false), (99,false), (88,false), (30,false), (28,false)]
theorem p712 (F : Frame G 4) : c712.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 3, 6, 0, 9, 8, 10, 7, 2, 5]) (by decide +kernel)
def c713 : CNF.Clause Nat := [(20,false), (99,false), (88,false), (87,false), (32,false), (26,false), (40,false), (7,false), (5,false), (50,false)]
theorem p713 (F : Frame G 4) : c713.eval F.assign = true := by
  exact Rule.sound F (.path [1, 8, 10, 7, 9, 2, 3, 6, 0, 4, 5]) (by decide +kernel)
def c714 : CNF.Clause Nat := [(20,false), (99,false), (88,false), (87,false), (10,false), (4,false), (40,false), (51,false), (27,false), (28,false)]
theorem p714 (F : Frame G 4) : c714.eval F.assign = true := by
  exact Rule.sound F (.path [1, 8, 10, 7, 9, 0, 3, 6, 4, 2, 5]) (by decide +kernel)
def c715 : CNF.Clause Nat := [(40,false), (51,false), (16,false), (17,false), (28,false), (32,false), (87,false), (8,false), (9,false), (99,false)]
theorem p715 (F : Frame G 4) : c715.eval F.assign = true := by
  exact Rule.sound F (.path [3, 6, 4, 1, 5, 2, 9, 7, 0, 8, 10]) (by decide +kernel)
def c716 : CNF.Clause Nat := [(28,false), (32,false), (87,false), (88,false), (99,false), (9,false), (4,false), (15,false), (16,false), (51,false)]
theorem p716 (F : Frame G 4) : c716.eval F.assign = true := by
  exact Rule.sound F (.path [5, 2, 9, 7, 10, 8, 0, 3, 1, 4, 6]) (by decide +kernel)
def c717 : CNF.Clause Nat := [(4,false), (10,false), (87,false), (88,false), (99,false), (31,false), (28,false), (17,false), (16,false), (51,false)]
theorem p717 (F : Frame G 4) : c717.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 9, 7, 10, 8, 2, 5, 1, 4, 6]) (by decide +kernel)
def c718 : CNF.Clause Nat := [(4,false), (9,false), (20,false), (16,false), (50,false), (62,false), (29,false), (32,false), (87,false), (88,false)]
theorem p718 (F : Frame G 4) : c718.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 8, 1, 4, 5, 6, 2, 9, 7, 10]) (by decide +kernel)
def c719 : CNF.Clause Nat := [(29,false), (51,false), (38,false), (39,false), (17,false), (20,false), (98,false), (10,false), (8,false), (88,false)]
theorem p719 (F : Frame G 4) : c719.eval F.assign = true := by
  exact Rule.sound F (.path [2, 6, 4, 3, 5, 1, 8, 9, 0, 7, 10]) (by decide +kernel)
def c720 : CNF.Clause Nat := [(26,false), (28,false), (50,false), (51,false), (18,false), (20,false), (99,false), (11,false), (8,false), (87,false)]
theorem p720 (F : Frame G 4) : c720.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 4, 6, 1, 8, 10, 0, 7, 9]) (by decide +kernel)
def c721 : CNF.Clause Nat := [(39,false), (17,false), (16,false), (51,false), (29,false), (32,false), (87,false), (8,false), (9,false), (99,false)]
theorem p721 (F : Frame G 4) : c721.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 1, 4, 6, 2, 9, 7, 0, 8, 10]) (by decide +kernel)
def c722 : CNF.Clause Nat := [(20,false), (99,false), (88,false), (87,false), (32,false), (26,false), (39,false), (6,false), (5,false), (51,false)]
theorem p722 (F : Frame G 4) : c722.eval F.assign = true := by
  exact Rule.sound F (.path [1, 8, 10, 7, 9, 2, 3, 5, 0, 4, 6]) (by decide +kernel)
def c723 : CNF.Clause Nat := [(4,false), (10,false), (87,false), (88,false), (99,false), (20,false), (16,false), (50,false), (28,false), (29,false)]
theorem p723 (F : Frame G 4) : c723.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 9, 7, 10, 8, 1, 4, 5, 2, 6]) (by decide +kernel)
def c724 : CNF.Clause Nat := [(38,false), (26,false), (28,false), (62,false), (7,false), (10,false), (87,false), (19,false), (20,false), (99,false)]
theorem p724 (F : Frame G 4) : c724.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 2, 5, 6, 0, 9, 7, 1, 8, 10]) (by decide +kernel)
def c725 : CNF.Clause Nat := [(38,false), (26,false), (28,false), (62,false), (7,false), (8,false), (87,false), (21,false), (20,false), (99,false)]
theorem p725 (F : Frame G 4) : c725.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 2, 5, 6, 0, 7, 9, 1, 8, 10]) (by decide +kernel)
def c726 : CNF.Clause Nat := [(38,false), (16,false), (18,false), (62,false), (28,false), (32,false), (87,false), (8,false), (9,false), (99,false)]
theorem p726 (F : Frame G 4) : c726.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 1, 6, 5, 2, 9, 7, 0, 8, 10]) (by decide +kernel)
def c727 : CNF.Clause Nat := [(4,false), (7,false), (62,false), (50,false), (16,false), (20,false), (98,false), (32,false), (33,false), (88,false)]
theorem p727 (F : Frame G 4) : c727.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 5, 4, 1, 8, 9, 2, 10, 7]) (by decide +kernel)
def c728 : CNF.Clause Nat := [(28,false), (6,false), (11,false), (88,false), (86,false), (98,false), (21,false), (15,false), (38,false), (51,false)]
theorem p728 (F : Frame G 4) : c728.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 0, 10, 7, 8, 9, 1, 3, 4, 6]) (by decide +kernel)
def c729 : CNF.Clause Nat := [(17,false), (21,false), (98,false), (99,false), (88,false), (8,false), (4,false), (26,false), (27,false), (51,false)]
theorem p729 (F : Frame G 4) : c729.eval F.assign = true := by
  exact Rule.sound F (.path [5, 1, 9, 8, 10, 7, 0, 3, 2, 4, 6]) (by decide +kernel)
def c730 : CNF.Clause Nat := [(38,false), (39,false), (28,false), (29,false), (18,false), (21,false), (98,false), (9,false), (8,false), (88,false)]
theorem p730 (F : Frame G 4) : c730.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 2, 6, 1, 9, 8, 0, 7, 10]) (by decide +kernel)
def c731 : CNF.Clause Nat := [(38,false), (39,false), (62,false), (18,false), (20,false), (98,false), (10,false), (8,false), (30,false), (33,false)]
theorem p731 (F : Frame G 4) : c731.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 6, 1, 8, 9, 0, 7, 2, 10]) (by decide +kernel)
def c732 : CNF.Clause Nat := [(16,false), (51,false), (62,false), (39,false), (4,false), (8,false), (30,false), (32,false), (98,false), (99,false)]
theorem p732 (F : Frame G 4) : c732.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 6, 5, 3, 0, 7, 2, 9, 8, 10]) (by decide +kernel)
def c733 : CNF.Clause Nat := [(4,false), (8,false), (88,false), (99,false), (98,false), (21,false), (16,false), (27,false), (28,false), (62,false)]
theorem p733 (F : Frame G 4) : c733.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 7, 10, 8, 9, 1, 4, 2, 5, 6]) (by decide +kernel)
def c734 : CNF.Clause Nat := [(4,false), (8,false), (88,false), (99,false), (98,false), (32,false), (27,false), (16,false), (17,false), (62,false)]
theorem p734 (F : Frame G 4) : c734.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 7, 10, 8, 9, 2, 4, 1, 5, 6]) (by decide +kernel)
def c735 : CNF.Clause Nat := [(40,false), (51,false), (16,false), (17,false), (28,false), (30,false), (8,false), (10,false), (98,false), (99,false)]
theorem p735 (F : Frame G 4) : c735.eval F.assign = true := by
  exact Rule.sound F (.path [3, 6, 4, 1, 5, 2, 7, 0, 9, 8, 10]) (by decide +kernel)
def c736 : CNF.Clause Nat := [(4,false), (40,false), (62,false), (50,false), (16,false), (20,false), (86,false), (87,false), (32,false), (33,false)]
theorem p736 (F : Frame G 4) : c736.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 6, 5, 4, 1, 8, 7, 9, 2, 10]) (by decide +kernel)
def c737 : CNF.Clause Nat := [(4,false), (39,false), (28,false), (32,false), (87,false), (86,false), (99,false), (22,false), (16,false), (51,false)]
theorem p737 (F : Frame G 4) : c737.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 2, 9, 7, 8, 10, 1, 4, 6]) (by decide +kernel)
def c738 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (16,false), (20,false), (98,false), (87,false), (88,false), (33,false), (29,false)]
theorem p738 (F : Frame G 4) : c738.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 1, 8, 9, 7, 10, 2, 6]) (by decide +kernel)
def c739 : CNF.Clause Nat := [(28,false), (29,false), (51,false), (38,false), (4,false), (11,false), (99,false), (20,false), (19,false), (87,false)]
theorem p739 (F : Frame G 4) : c739.eval F.assign = true := by
  exact Rule.sound F (.path [5, 2, 6, 4, 3, 0, 10, 8, 1, 7, 9]) (by decide +kernel)
def c740 : CNF.Clause Nat := [(39,false), (26,false), (32,false), (87,false), (19,false), (16,false), (51,false), (7,false), (9,false), (99,false)]
theorem p740 (F : Frame G 4) : c740.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 2, 9, 7, 1, 4, 6, 0, 8, 10]) (by decide +kernel)
def c741 : CNF.Clause Nat := [(15,false), (38,false), (51,false), (29,false), (28,false), (6,false), (8,false), (87,false), (98,false), (99,false)]
theorem p741 (F : Frame G 4) : c741.eval F.assign = true := by
  exact Rule.sound F (.path [1, 3, 4, 6, 2, 5, 0, 7, 9, 8, 10]) (by decide +kernel)
def c742 : CNF.Clause Nat := [(33,false), (99,false), (98,false), (87,false), (19,false), (17,false), (39,false), (4,false), (5,false), (51,false)]
theorem p742 (F : Frame G 4) : c742.eval F.assign = true := by
  exact Rule.sound F (.path [2, 10, 8, 9, 7, 1, 5, 3, 0, 4, 6]) (by decide +kernel)
def c743 : CNF.Clause Nat := [(38,false), (51,false), (18,false), (17,false), (28,false), (33,false), (99,false), (9,false), (8,false), (87,false)]
theorem p743 (F : Frame G 4) : c743.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 6, 1, 5, 2, 10, 8, 0, 7, 9]) (by decide +kernel)
def c744 : CNF.Clause Nat := [(39,false), (38,false), (51,false), (18,false), (20,false), (99,false), (11,false), (8,false), (30,false), (32,false)]
theorem p744 (F : Frame G 4) : c744.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 4, 6, 1, 8, 10, 0, 7, 2, 9]) (by decide +kernel)
def c745 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (51,false), (7,false), (8,false), (87,false), (21,false), (20,false), (99,false)]
theorem p745 (F : Frame G 4) : c745.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 6, 0, 7, 9, 1, 8, 10]) (by decide +kernel)
def c746 : CNF.Clause Nat := [(8,false), (87,false), (98,false), (99,false), (33,false), (28,false), (39,false), (15,false), (16,false), (51,false)]
theorem p746 (F : Frame G 4) : c746.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 9, 8, 10, 2, 5, 3, 1, 4, 6]) (by decide +kernel)
def c747 : CNF.Clause Nat := [(4,false), (39,false), (17,false), (16,false), (51,false), (29,false), (32,false), (87,false), (86,false), (99,false)]
theorem p747 (F : Frame G 4) : c747.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 1, 4, 6, 2, 9, 7, 8, 10]) (by decide +kernel)
def c748 : CNF.Clause Nat := [(26,false), (28,false), (62,false), (51,false), (5,false), (8,false), (87,false), (21,false), (20,false), (99,false)]
theorem p748 (F : Frame G 4) : c748.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 6, 4, 0, 7, 9, 1, 8, 10]) (by decide +kernel)
def c749 : CNF.Clause Nat := [(38,false), (15,false), (17,false), (62,false), (7,false), (10,false), (32,false), (30,false), (86,false), (99,false)]
theorem p749 (F : Frame G 4) : c749.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 1, 5, 6, 0, 9, 2, 7, 8, 10]) (by decide +kernel)
def c750 : CNF.Clause Nat := [(22,false), (99,false), (86,false), (87,false), (10,false), (4,false), (38,false), (27,false), (28,false), (62,false)]
theorem p750 (F : Frame G 4) : c750.eval F.assign = true := by
  exact Rule.sound F (.path [1, 10, 8, 7, 9, 0, 3, 4, 2, 5, 6]) (by decide +kernel)
def c751 : CNF.Clause Nat := [(16,false), (38,false), (4,false), (7,false), (62,false), (28,false), (32,false), (87,false), (86,false), (99,false)]
theorem p751 (F : Frame G 4) : c751.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 0, 6, 5, 2, 9, 7, 8, 10]) (by decide +kernel)
def c752 : CNF.Clause Nat := [(16,false), (38,false), (4,false), (6,false), (62,false), (29,false), (32,false), (87,false), (86,false), (99,false)]
theorem p752 (F : Frame G 4) : c752.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 0, 5, 6, 2, 9, 7, 8, 10]) (by decide +kernel)
def c753 : CNF.Clause Nat := [(38,false), (39,false), (62,false), (7,false), (8,false), (87,false), (21,false), (20,false), (31,false), (33,false)]
theorem p753 (F : Frame G 4) : c753.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 6, 0, 7, 9, 1, 8, 2, 10]) (by decide +kernel)
def c754 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (28,false), (32,false), (87,false), (86,false), (99,false), (22,false), (18,false)]
theorem p754 (F : Frame G 4) : c754.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 2, 9, 7, 8, 10, 1, 6]) (by decide +kernel)
def c755 : CNF.Clause Nat := [(4,false), (39,false), (62,false), (18,false), (16,false), (27,false), (32,false), (87,false), (86,false), (99,false)]
theorem p755 (F : Frame G 4) : c755.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 6, 1, 4, 2, 9, 7, 8, 10]) (by decide +kernel)
def c756 : CNF.Clause Nat := [(28,false), (6,false), (5,false), (38,false), (40,false), (18,false), (20,false), (98,false), (87,false), (88,false)]
theorem p756 (F : Frame G 4) : c756.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 0, 4, 3, 6, 1, 8, 9, 7, 10]) (by decide +kernel)
def c757 : CNF.Clause Nat := [(20,false), (98,false), (32,false), (28,false), (62,false), (40,false), (38,false), (5,false), (8,false), (88,false)]
theorem p757 (F : Frame G 4) : c757.eval F.assign = true := by
  exact Rule.sound F (.path [1, 8, 9, 2, 5, 6, 3, 4, 0, 7, 10]) (by decide +kernel)
def c758 : CNF.Clause Nat := [(28,false), (39,false), (40,false), (18,false), (16,false), (5,false), (8,false), (88,false), (99,false), (98,false)]
theorem p758 (F : Frame G 4) : c758.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 6, 1, 4, 0, 7, 10, 8, 9]) (by decide +kernel)
def c759 : CNF.Clause Nat := [(4,false), (5,false), (51,false), (62,false), (17,false), (20,false), (98,false), (32,false), (33,false), (88,false)]
theorem p759 (F : Frame G 4) : c759.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 4, 6, 5, 1, 8, 9, 2, 10, 7]) (by decide +kernel)
def c760 : CNF.Clause Nat := [(28,false), (62,false), (40,false), (15,false), (16,false), (5,false), (8,false), (87,false), (98,false), (99,false)]
theorem p760 (F : Frame G 4) : c760.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 6, 3, 1, 4, 0, 7, 9, 8, 10]) (by decide +kernel)
def c761 : CNF.Clause Nat := [(16,false), (51,false), (40,false), (26,false), (28,false), (6,false), (11,false), (88,false), (86,false), (98,false)]
theorem p761 (F : Frame G 4) : c761.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 6, 3, 2, 5, 0, 10, 7, 8, 9]) (by decide +kernel)
def c762 : CNF.Clause Nat := [(20,false), (98,false), (110,false), (88,false), (8,false), (4,false), (26,false), (28,false), (50,false), (51,false)]
theorem p762 (F : Frame G 4) : c762.eval F.assign = true := by
  exact Rule.sound F (.path [1, 8, 9, 10, 7, 0, 3, 2, 5, 4, 6]) (by decide +kernel)
def c763 : CNF.Clause Nat := [(15,false), (40,false), (51,false), (50,false), (6,false), (8,false), (30,false), (31,false), (98,false), (110,false)]
theorem p763 (F : Frame G 4) : c763.eval F.assign = true := by
  exact Rule.sound F (.path [1, 3, 6, 4, 5, 0, 7, 2, 8, 9, 10]) (by decide +kernel)
def c764 : CNF.Clause Nat := [(16,false), (38,false), (40,false), (7,false), (6,false), (28,false), (30,false), (88,false), (99,false), (98,false)]
theorem p764 (F : Frame G 4) : c764.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 6, 0, 5, 2, 7, 10, 8, 9]) (by decide +kernel)
def c765 : CNF.Clause Nat := [(28,false), (50,false), (51,false), (18,false), (15,false), (4,false), (8,false), (87,false), (98,false), (99,false)]
theorem p765 (F : Frame G 4) : c765.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 6, 1, 3, 0, 7, 9, 8, 10]) (by decide +kernel)
def c766 : CNF.Clause Nat := [(16,false), (51,false), (40,false), (39,false), (28,false), (32,false), (98,false), (86,false), (8,false), (11,false)]
theorem p766 (F : Frame G 4) : c766.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 6, 3, 5, 2, 9, 8, 7, 0, 10]) (by decide +kernel)
def c767 : CNF.Clause Nat := [(16,false), (20,false), (99,false), (11,false), (4,false), (39,false), (62,false), (29,false), (30,false), (87,false)]
theorem p767 (F : Frame G 4) : c767.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 8, 10, 0, 3, 5, 6, 2, 7, 9]) (by decide +kernel)
def c768 : CNF.Clause Nat := [(27,false), (28,false), (62,false), (40,false), (4,false), (8,false), (87,false), (21,false), (20,false), (99,false)]
theorem p768 (F : Frame G 4) : c768.eval F.assign = true := by
  exact Rule.sound F (.path [4, 2, 5, 6, 3, 0, 7, 9, 1, 8, 10]) (by decide +kernel)
def c769 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (20,false), (99,false), (33,false), (29,false), (7,false), (8,false), (87,false)]
theorem p769 (F : Frame G 4) : c769.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 1, 8, 10, 2, 6, 0, 7, 9]) (by decide +kernel)
def c770 : CNF.Clause Nat := [(16,false), (17,false), (39,false), (40,false), (29,false), (32,false), (87,false), (8,false), (9,false), (99,false)]
theorem p770 (F : Frame G 4) : c770.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 5, 3, 6, 2, 9, 7, 0, 8, 10]) (by decide +kernel)
def c771 : CNF.Clause Nat := [(5,false), (6,false), (39,false), (40,false), (29,false), (32,false), (21,false), (20,false), (86,false), (88,false)]
theorem p771 (F : Frame G 4) : c771.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 5, 3, 6, 2, 9, 1, 8, 7, 10]) (by decide +kernel)
def c772 : CNF.Clause Nat := [(28,false), (62,false), (40,false), (15,false), (16,false), (5,false), (10,false), (87,false), (86,false), (99,false)]
theorem p772 (F : Frame G 4) : c772.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 6, 3, 1, 4, 0, 9, 7, 8, 10]) (by decide +kernel)
def c773 : CNF.Clause Nat := [(16,false), (51,false), (40,false), (4,false), (6,false), (28,false), (32,false), (87,false), (86,false), (99,false)]
theorem p773 (F : Frame G 4) : c773.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 6, 3, 0, 5, 2, 9, 7, 8, 10]) (by decide +kernel)
def c774 : CNF.Clause Nat := [(16,false), (18,false), (62,false), (39,false), (4,false), (8,false), (87,false), (32,false), (31,false), (99,false)]
theorem p774 (F : Frame G 4) : c774.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 6, 5, 3, 0, 7, 9, 2, 8, 10]) (by decide +kernel)
def c775 : CNF.Clause Nat := [(5,false), (7,false), (40,false), (39,false), (17,false), (20,false), (86,false), (87,false), (32,false), (33,false)]
theorem p775 (F : Frame G 4) : c775.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 6, 3, 5, 1, 8, 7, 9, 2, 10]) (by decide +kernel)
def c776 : CNF.Clause Nat := [(5,false), (6,false), (39,false), (40,false), (18,false), (20,false), (86,false), (87,false), (32,false), (33,false)]
theorem p776 (F : Frame G 4) : c776.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 5, 3, 6, 1, 8, 7, 9, 2, 10]) (by decide +kernel)
def c777 : CNF.Clause Nat := [(4,false), (40,false), (62,false), (28,false), (27,false), (16,false), (22,false), (88,false), (86,false), (98,false)]
theorem p777 (F : Frame G 4) : c777.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 6, 5, 2, 4, 1, 10, 7, 8, 9]) (by decide +kernel)
def c778 : CNF.Clause Nat := [(20,false), (99,false), (33,false), (32,false), (87,false), (8,false), (4,false), (38,false), (50,false), (62,false)]
theorem p778 (F : Frame G 4) : c778.eval F.assign = true := by
  exact Rule.sound F (.path [1, 8, 10, 2, 9, 7, 0, 3, 4, 5, 6]) (by decide +kernel)
def c779 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (32,false), (87,false), (8,false), (7,false), (18,false), (20,false), (99,false)]
theorem p779 (F : Frame G 4) : c779.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 2, 9, 7, 0, 6, 1, 8, 10]) (by decide +kernel)
def c780 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (62,false), (18,false), (19,false), (87,false), (32,false), (31,false), (99,false)]
theorem p780 (F : Frame G 4) : c780.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 6, 1, 7, 9, 2, 8, 10]) (by decide +kernel)
def c781 : CNF.Clause Nat := [(38,false), (40,false), (62,false), (6,false), (8,false), (30,false), (32,false), (21,false), (20,false), (99,false)]
theorem p781 (F : Frame G 4) : c781.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 6, 5, 0, 7, 2, 9, 1, 8, 10]) (by decide +kernel)
def c782 : CNF.Clause Nat := [(26,false), (39,false), (50,false), (5,false), (7,false), (18,false), (21,false), (87,false), (86,false), (99,false)]
theorem p782 (F : Frame G 4) : c782.eval F.assign = true := by
  exact Rule.sound F (.path [2, 3, 5, 4, 0, 6, 1, 9, 7, 8, 10]) (by decide +kernel)
def c783 : CNF.Clause Nat := [(20,false), (99,false), (33,false), (28,false), (50,false), (38,false), (40,false), (7,false), (8,false), (87,false)]
theorem p783 (F : Frame G 4) : c783.eval F.assign = true := by
  exact Rule.sound F (.path [1, 8, 10, 2, 5, 4, 3, 6, 0, 7, 9]) (by decide +kernel)
def c784 : CNF.Clause Nat := [(32,false), (87,false), (88,false), (99,false), (20,false), (16,false), (50,false), (6,false), (4,false), (40,false)]
theorem p784 (F : Frame G 4) : c784.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 7, 10, 8, 1, 4, 5, 0, 3, 6]) (by decide +kernel)
def c785 : CNF.Clause Nat := [(16,false), (17,false), (39,false), (40,false), (29,false), (31,false), (99,false), (11,false), (8,false), (87,false)]
theorem p785 (F : Frame G 4) : c785.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 5, 3, 6, 2, 8, 10, 0, 7, 9]) (by decide +kernel)
def c786 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (16,false), (18,false), (7,false), (9,false), (99,false), (88,false), (87,false)]
theorem p786 (F : Frame G 4) : c786.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 1, 6, 0, 8, 10, 7, 9]) (by decide +kernel)
def c787 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (40,false), (7,false), (8,false), (87,false), (21,false), (20,false), (99,false)]
theorem p787 (F : Frame G 4) : c787.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 6, 0, 7, 9, 1, 8, 10]) (by decide +kernel)
def c788 : CNF.Clause Nat := [(32,false), (87,false), (86,false), (99,false), (11,false), (4,false), (40,false), (18,false), (16,false), (50,false)]
theorem p788 (F : Frame G 4) : c788.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 7, 8, 10, 0, 3, 6, 1, 4, 5]) (by decide +kernel)
def c789 : CNF.Clause Nat := [(5,false), (4,false), (39,false), (17,false), (18,false), (29,false), (32,false), (87,false), (86,false), (99,false)]
theorem p789 (F : Frame G 4) : c789.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 3, 5, 1, 6, 2, 9, 7, 8, 10]) (by decide +kernel)
def c790 : CNF.Clause Nat := [(16,false), (17,false), (28,false), (29,false), (40,false), (4,false), (10,false), (87,false), (86,false), (99,false)]
theorem p790 (F : Frame G 4) : c790.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 5, 2, 6, 3, 0, 9, 7, 8, 10]) (by decide +kernel)
def c791 : CNF.Clause Nat := [(27,false), (28,false), (39,false), (40,false), (7,false), (10,false), (87,false), (86,false), (20,false), (22,false)]
theorem p791 (F : Frame G 4) : c791.eval F.assign = true := by
  exact Rule.sound F (.path [4, 2, 5, 3, 6, 0, 9, 7, 8, 1, 10]) (by decide +kernel)
def c792 : CNF.Clause Nat := [(28,false), (26,false), (38,false), (51,false), (7,false), (11,false), (99,false), (86,false), (19,false), (21,false)]
theorem p792 (F : Frame G 4) : c792.eval F.assign = true := by
  exact Rule.sound F (.path [5, 2, 3, 4, 6, 0, 10, 8, 7, 1, 9]) (by decide +kernel)
def c793 : CNF.Clause Nat := [(28,false), (26,false), (38,false), (51,false), (7,false), (8,false), (19,false), (21,false), (98,false), (99,false)]
theorem p793 (F : Frame G 4) : c793.eval F.assign = true := by
  exact Rule.sound F (.path [5, 2, 3, 4, 6, 0, 7, 1, 9, 8, 10]) (by decide +kernel)
def c794 : CNF.Clause Nat := [(39,false), (26,false), (29,false), (51,false), (5,false), (8,false), (86,false), (98,false), (21,false), (22,false)]
theorem p794 (F : Frame G 4) : c794.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 2, 6, 4, 0, 7, 8, 9, 1, 10]) (by decide +kernel)
def c795 : CNF.Clause Nat := [(39,false), (4,false), (7,false), (51,false), (27,false), (30,false), (86,false), (98,false), (21,false), (22,false)]
theorem p795 (F : Frame G 4) : c795.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 0, 6, 4, 2, 7, 8, 9, 1, 10]) (by decide +kernel)
def c796 : CNF.Clause Nat := [(28,false), (29,false), (51,false), (38,false), (4,false), (8,false), (86,false), (98,false), (21,false), (22,false)]
theorem p796 (F : Frame G 4) : c796.eval F.assign = true := by
  exact Rule.sound F (.path [5, 2, 6, 4, 3, 0, 7, 8, 9, 1, 10]) (by decide +kernel)
def c797 : CNF.Clause Nat := [(39,false), (4,false), (7,false), (51,false), (27,false), (32,false), (98,false), (86,false), (19,false), (22,false)]
theorem p797 (F : Frame G 4) : c797.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 0, 6, 4, 2, 9, 8, 7, 1, 10]) (by decide +kernel)
def c798 : CNF.Clause Nat := [(39,false), (4,false), (10,false), (32,false), (33,false), (99,false), (86,false), (19,false), (16,false), (51,false)]
theorem p798 (F : Frame G 4) : c798.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 0, 9, 2, 10, 8, 7, 1, 4, 6]) (by decide +kernel)
def c799 : CNF.Clause Nat := [(32,false), (98,false), (86,false), (8,false), (11,false), (22,false), (18,false), (51,false), (38,false), (39,false)]
theorem p799 (F : Frame G 4) : c799.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 8, 7, 0, 10, 1, 6, 4, 3, 5]) (by decide +kernel)
def c800 : CNF.Clause Nat := [(28,false), (39,false), (40,false), (51,false), (5,false), (8,false), (19,false), (21,false), (98,false), (99,false)]
theorem p800 (F : Frame G 4) : c800.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 6, 4, 0, 7, 1, 9, 8, 10]) (by decide +kernel)
def c801 : CNF.Clause Nat := [(32,false), (98,false), (99,false), (22,false), (19,false), (8,false), (6,false), (39,false), (38,false), (51,false)]
theorem p801 (F : Frame G 4) : c801.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 8, 10, 1, 7, 0, 5, 3, 4, 6]) (by decide +kernel)
def c802 : CNF.Clause Nat := [(4,false), (39,false), (28,false), (30,false), (86,false), (98,false), (110,false), (22,false), (16,false), (51,false)]
theorem p802 (F : Frame G 4) : c802.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 2, 7, 8, 9, 10, 1, 4, 6]) (by decide +kernel)
def c803 : CNF.Clause Nat := [(6,false), (39,false), (40,false), (51,false), (16,false), (22,false), (33,false), (31,false), (86,false), (87,false)]
theorem p803 (F : Frame G 4) : c803.eval F.assign = true := by
  exact Rule.sound F (.path [0, 5, 3, 6, 4, 1, 10, 2, 8, 7, 9]) (by decide +kernel)
def c804 : CNF.Clause Nat := [(22,false), (110,false), (87,false), (86,false), (9,false), (6,false), (28,false), (27,false), (38,false), (40,false)]
theorem p804 (F : Frame G 4) : c804.eval F.assign = true := by
  exact Rule.sound F (.path [1, 10, 9, 7, 8, 0, 5, 2, 4, 3, 6]) (by decide +kernel)
def c805 : CNF.Clause Nat := [(6,false), (39,false), (40,false), (51,false), (27,false), (33,false), (22,false), (19,false), (86,false), (98,false)]
theorem p805 (F : Frame G 4) : c805.eval F.assign = true := by
  exact Rule.sound F (.path [0, 5, 3, 6, 4, 2, 10, 1, 7, 8, 9]) (by decide +kernel)
def c806 : CNF.Clause Nat := [(4,false), (8,false), (86,false), (20,false), (22,false), (110,false), (32,false), (28,false), (50,false), (51,false)]
theorem p806 (F : Frame G 4) : c806.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 7, 8, 1, 10, 9, 2, 5, 4, 6]) (by decide +kernel)
def c807 : CNF.Clause Nat := [(28,false), (39,false), (4,false), (8,false), (87,false), (110,false), (99,false), (20,false), (16,false), (51,false)]
theorem p807 (F : Frame G 4) : c807.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 0, 7, 9, 10, 8, 1, 4, 6]) (by decide +kernel)
def c808 : CNF.Clause Nat := [(4,false), (5,false), (51,false), (62,false), (17,false), (21,false), (32,false), (30,false), (86,false), (99,false)]
theorem p808 (F : Frame G 4) : c808.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 4, 6, 5, 1, 9, 2, 7, 8, 10]) (by decide +kernel)
def c809 : CNF.Clause Nat := [(15,false), (16,false), (51,false), (62,false), (6,false), (8,false), (30,false), (32,false), (98,false), (99,false)]
theorem p809 (F : Frame G 4) : c809.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 6, 5, 0, 7, 2, 9, 8, 10]) (by decide +kernel)
def c810 : CNF.Clause Nat := [(4,false), (8,false), (19,false), (16,false), (51,false), (62,false), (28,false), (32,false), (98,false), (99,false)]
theorem p810 (F : Frame G 4) : c810.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 7, 1, 4, 6, 5, 2, 9, 8, 10]) (by decide +kernel)
def c811 : CNF.Clause Nat := [(4,false), (38,false), (51,false), (62,false), (17,false), (22,false), (99,false), (31,false), (30,false), (87,false)]
theorem p811 (F : Frame G 4) : c811.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 6, 5, 1, 10, 8, 2, 7, 9]) (by decide +kernel)
def c812 : CNF.Clause Nat := [(38,false), (16,false), (18,false), (62,false), (6,false), (8,false), (30,false), (32,false), (98,false), (99,false)]
theorem p812 (F : Frame G 4) : c812.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 1, 6, 5, 0, 7, 2, 9, 8, 10]) (by decide +kernel)
def c813 : CNF.Clause Nat := [(22,false), (99,false), (98,false), (87,false), (30,false), (26,false), (38,false), (5,false), (6,false), (62,false)]
theorem p813 (F : Frame G 4) : c813.eval F.assign = true := by
  exact Rule.sound F (.path [1, 10, 8, 9, 7, 2, 3, 4, 0, 5, 6]) (by decide +kernel)
def c814 : CNF.Clause Nat := [(22,false), (99,false), (98,false), (87,false), (8,false), (4,false), (38,false), (27,false), (28,false), (62,false)]
theorem p814 (F : Frame G 4) : c814.eval F.assign = true := by
  exact Rule.sound F (.path [1, 10, 8, 9, 7, 0, 3, 4, 2, 5, 6]) (by decide +kernel)
def c815 : CNF.Clause Nat := [(39,false), (50,false), (16,false), (18,false), (29,false), (33,false), (99,false), (9,false), (8,false), (87,false)]
theorem p815 (F : Frame G 4) : c815.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 4, 1, 6, 2, 10, 8, 0, 7, 9]) (by decide +kernel)
def c816 : CNF.Clause Nat := [(33,false), (99,false), (98,false), (87,false), (19,false), (16,false), (5,false), (4,false), (39,false), (62,false)]
theorem p816 (F : Frame G 4) : c816.eval F.assign = true := by
  exact Rule.sound F (.path [2, 10, 8, 9, 7, 1, 4, 0, 3, 5, 6]) (by decide +kernel)
def c817 : CNF.Clause Nat := [(16,false), (50,false), (62,false), (40,false), (4,false), (8,false), (87,false), (32,false), (31,false), (99,false)]
theorem p817 (F : Frame G 4) : c817.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 6, 3, 0, 7, 9, 2, 8, 10]) (by decide +kernel)
def c818 : CNF.Clause Nat := [(16,false), (50,false), (62,false), (40,false), (4,false), (8,false), (30,false), (32,false), (98,false), (99,false)]
theorem p818 (F : Frame G 4) : c818.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 6, 3, 0, 7, 2, 9, 8, 10]) (by decide +kernel)
def c819 : CNF.Clause Nat := [(30,false), (87,false), (98,false), (99,false), (22,false), (16,false), (5,false), (4,false), (39,false), (62,false)]
theorem p819 (F : Frame G 4) : c819.eval F.assign = true := by
  exact Rule.sound F (.path [2, 7, 9, 8, 10, 1, 4, 0, 3, 5, 6]) (by decide +kernel)
def c820 : CNF.Clause Nat := [(26,false), (28,false), (62,false), (18,false), (16,false), (5,false), (8,false), (87,false), (98,false), (99,false)]
theorem p820 (F : Frame G 4) : c820.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 6, 1, 4, 0, 7, 9, 8, 10]) (by decide +kernel)
def c821 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (62,false), (7,false), (8,false), (30,false), (32,false), (98,false), (99,false)]
theorem p821 (F : Frame G 4) : c821.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 6, 0, 7, 2, 9, 8, 10]) (by decide +kernel)
def c822 : CNF.Clause Nat := [(22,false), (99,false), (98,false), (87,false), (8,false), (4,false), (26,false), (28,false), (50,false), (51,false)]
theorem p822 (F : Frame G 4) : c822.eval F.assign = true := by
  exact Rule.sound F (.path [1, 10, 8, 9, 7, 0, 3, 2, 5, 4, 6]) (by decide +kernel)
def c823 : CNF.Clause Nat := [(38,false), (16,false), (21,false), (32,false), (28,false), (62,false), (7,false), (8,false), (86,false), (99,false)]
theorem p823 (F : Frame G 4) : c823.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 1, 9, 2, 5, 6, 0, 7, 8, 10]) (by decide +kernel)
def c824 : CNF.Clause Nat := [(4,false), (5,false), (50,false), (62,false), (18,false), (21,false), (32,false), (30,false), (86,false), (99,false)]
theorem p824 (F : Frame G 4) : c824.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 4, 5, 6, 1, 9, 2, 7, 8, 10]) (by decide +kernel)
def c825 : CNF.Clause Nat := [(4,false), (7,false), (62,false), (50,false), (16,false), (19,false), (86,false), (98,false), (32,false), (33,false)]
theorem p825 (F : Frame G 4) : c825.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 5, 4, 1, 7, 8, 9, 2, 10]) (by decide +kernel)
def c826 : CNF.Clause Nat := [(4,false), (8,false), (19,false), (16,false), (50,false), (62,false), (29,false), (32,false), (98,false), (99,false)]
theorem p826 (F : Frame G 4) : c826.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 7, 1, 4, 5, 6, 2, 9, 8, 10]) (by decide +kernel)
def c827 : CNF.Clause Nat := [(4,false), (5,false), (50,false), (62,false), (18,false), (22,false), (33,false), (30,false), (86,false), (98,false)]
theorem p827 (F : Frame G 4) : c827.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 4, 5, 6, 1, 10, 2, 7, 8, 9]) (by decide +kernel)
def c828 : CNF.Clause Nat := [(4,false), (7,false), (62,false), (50,false), (16,false), (22,false), (99,false), (86,false), (30,false), (32,false)]
theorem p828 (F : Frame G 4) : c828.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 5, 4, 1, 10, 8, 7, 2, 9]) (by decide +kernel)
def c829 : CNF.Clause Nat := [(4,false), (8,false), (86,false), (98,false), (32,false), (27,false), (50,false), (62,false), (18,false), (22,false)]
theorem p829 (F : Frame G 4) : c829.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 7, 8, 9, 2, 4, 5, 6, 1, 10]) (by decide +kernel)
def c830 : CNF.Clause Nat := [(38,false), (16,false), (17,false), (62,false), (29,false), (30,false), (8,false), (10,false), (98,false), (99,false)]
theorem p830 (F : Frame G 4) : c830.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 1, 5, 6, 2, 7, 0, 9, 8, 10]) (by decide +kernel)
def c831 : CNF.Clause Nat := [(38,false), (50,false), (62,false), (18,false), (22,false), (11,false), (8,false), (30,false), (32,false), (98,false)]
theorem p831 (F : Frame G 4) : c831.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 6, 1, 10, 0, 7, 2, 9, 8]) (by decide +kernel)
def c832 : CNF.Clause Nat := [(4,false), (39,false), (50,false), (16,false), (18,false), (29,false), (32,false), (87,false), (86,false), (99,false)]
theorem p832 (F : Frame G 4) : c832.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 5, 4, 1, 6, 2, 9, 7, 8, 10]) (by decide +kernel)
def c833 : CNF.Clause Nat := [(4,false), (40,false), (18,false), (16,false), (50,false), (28,false), (31,false), (99,false), (88,false), (87,false)]
theorem p833 (F : Frame G 4) : c833.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 6, 1, 4, 5, 2, 8, 10, 7, 9]) (by decide +kernel)
def c834 : CNF.Clause Nat := [(32,false), (87,false), (88,false), (99,false), (9,false), (5,false), (50,false), (17,false), (15,false), (40,false)]
theorem p834 (F : Frame G 4) : c834.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 7, 10, 8, 0, 4, 5, 1, 3, 6]) (by decide +kernel)
def c835 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (7,false), (29,false), (32,false), (21,false), (19,false), (86,false), (99,false)]
theorem p835 (F : Frame G 4) : c835.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 0, 6, 2, 9, 1, 7, 8, 10]) (by decide +kernel)
def c836 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (19,false), (8,false), (7,false), (29,false), (32,false), (98,false), (99,false)]
theorem p836 (F : Frame G 4) : c836.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 1, 7, 0, 6, 2, 9, 8, 10]) (by decide +kernel)
def c837 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (8,false), (19,false), (18,false), (29,false), (32,false), (98,false), (99,false)]
theorem p837 (F : Frame G 4) : c837.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 0, 7, 1, 6, 2, 9, 8, 10]) (by decide +kernel)
def c838 : CNF.Clause Nat := [(16,false), (18,false), (40,false), (39,false), (6,false), (8,false), (87,false), (32,false), (31,false), (99,false)]
theorem p838 (F : Frame G 4) : c838.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 6, 3, 5, 0, 7, 9, 2, 8, 10]) (by decide +kernel)
def c839 : CNF.Clause Nat := [(4,false), (7,false), (51,false), (50,false), (28,false), (33,false), (99,false), (20,false), (19,false), (87,false)]
theorem p839 (F : Frame G 4) : c839.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 4, 5, 2, 10, 8, 1, 7, 9]) (by decide +kernel)
def c840 : CNF.Clause Nat := [(15,false), (17,false), (50,false), (51,false), (7,false), (8,false), (30,false), (32,false), (98,false), (99,false)]
theorem p840 (F : Frame G 4) : c840.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 5, 4, 6, 0, 7, 2, 9, 8, 10]) (by decide +kernel)
def c841 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (17,false), (18,false), (29,false), (33,false), (99,false), (98,false), (87,false)]
theorem p841 (F : Frame G 4) : c841.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 1, 6, 2, 10, 8, 9, 7]) (by decide +kernel)
def c842 : CNF.Clause Nat := [(39,false), (28,false), (27,false), (51,false), (7,false), (8,false), (87,false), (98,false), (20,false), (22,false)]
theorem p842 (F : Frame G 4) : c842.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 2, 4, 6, 0, 7, 9, 8, 1, 10]) (by decide +kernel)
def c843 : CNF.Clause Nat := [(29,false), (51,false), (50,false), (39,false), (4,false), (8,false), (87,false), (21,false), (20,false), (99,false)]
theorem p843 (F : Frame G 4) : c843.eval F.assign = true := by
  exact Rule.sound F (.path [2, 6, 4, 5, 3, 0, 7, 9, 1, 8, 10]) (by decide +kernel)
def c844 : CNF.Clause Nat := [(28,false), (39,false), (38,false), (16,false), (18,false), (7,false), (8,false), (87,false), (98,false), (99,false)]
theorem p844 (F : Frame G 4) : c844.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 4, 1, 6, 0, 7, 9, 8, 10]) (by decide +kernel)
def c845 : CNF.Clause Nat := [(50,false), (6,false), (4,false), (40,false), (29,false), (33,false), (99,false), (20,false), (19,false), (87,false)]
theorem p845 (F : Frame G 4) : c845.eval F.assign = true := by
  exact Rule.sound F (.path [4, 5, 0, 3, 6, 2, 10, 8, 1, 7, 9]) (by decide +kernel)
def c846 : CNF.Clause Nat := [(8,false), (87,false), (98,false), (99,false), (33,false), (28,false), (50,false), (16,false), (15,false), (40,false)]
theorem p846 (F : Frame G 4) : c846.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 9, 8, 10, 2, 5, 4, 1, 3, 6]) (by decide +kernel)
def c847 : CNF.Clause Nat := [(8,false), (87,false), (98,false), (99,false), (22,false), (16,false), (38,false), (39,false), (28,false), (29,false)]
theorem p847 (F : Frame G 4) : c847.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 9, 8, 10, 1, 4, 3, 5, 2, 6]) (by decide +kernel)
def c848 : CNF.Clause Nat := [(8,false), (86,false), (98,false), (32,false), (33,false), (22,false), (18,false), (62,false), (39,false), (38,false)]
theorem p848 (F : Frame G 4) : c848.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 8, 9, 2, 10, 1, 6, 5, 3, 4]) (by decide +kernel)
def c849 : CNF.Clause Nat := [(4,false), (38,false), (51,false), (62,false), (17,false), (21,false), (32,false), (30,false), (86,false), (99,false)]
theorem p849 (F : Frame G 4) : c849.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 6, 5, 1, 9, 2, 7, 8, 10]) (by decide +kernel)
def c850 : CNF.Clause Nat := [(38,false), (51,false), (18,false), (17,false), (28,false), (30,false), (8,false), (10,false), (98,false), (99,false)]
theorem p850 (F : Frame G 4) : c850.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 6, 1, 5, 2, 7, 0, 9, 8, 10]) (by decide +kernel)
def c851 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (62,false), (18,false), (21,false), (32,false), (30,false), (86,false), (99,false)]
theorem p851 (F : Frame G 4) : c851.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 6, 1, 9, 2, 7, 8, 10]) (by decide +kernel)
def c852 : CNF.Clause Nat := [(4,false), (38,false), (50,false), (62,false), (18,false), (22,false), (33,false), (30,false), (86,false), (98,false)]
theorem p852 (F : Frame G 4) : c852.eval F.assign = true := by
  exact Rule.sound F (.path [0, 3, 4, 5, 6, 1, 10, 2, 7, 8, 9]) (by decide +kernel)
def c853 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (62,false), (29,false), (30,false), (8,false), (10,false), (98,false), (99,false)]
theorem p853 (F : Frame G 4) : c853.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 6, 2, 7, 0, 9, 8, 10]) (by decide +kernel)
def c854 : CNF.Clause Nat := [(4,false), (6,false), (50,false), (51,false), (18,false), (21,false), (32,false), (30,false), (86,false), (99,false)]
theorem p854 (F : Frame G 4) : c854.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 5, 4, 6, 1, 9, 2, 7, 8, 10]) (by decide +kernel)
def c855 : CNF.Clause Nat := [(4,false), (7,false), (51,false), (50,false), (17,false), (22,false), (99,false), (86,false), (30,false), (32,false)]
theorem p855 (F : Frame G 4) : c855.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 4, 5, 1, 10, 8, 7, 2, 9]) (by decide +kernel)
def c856 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (4,false), (7,false), (29,false), (30,false), (87,false), (98,false), (99,false)]
theorem p856 (F : Frame G 4) : c856.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 0, 6, 2, 7, 9, 8, 10]) (by decide +kernel)
def c857 : CNF.Clause Nat := [(26,false), (28,false), (50,false), (51,false), (7,false), (8,false), (19,false), (21,false), (98,false), (99,false)]
theorem p857 (F : Frame G 4) : c857.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 4, 6, 0, 7, 1, 9, 8, 10]) (by decide +kernel)
def c858 : CNF.Clause Nat := [(39,false), (6,false), (8,false), (86,false), (99,false), (22,false), (21,false), (32,false), (27,false), (51,false)]
theorem p858 (F : Frame G 4) : c858.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 0, 7, 8, 10, 1, 9, 2, 4, 6]) (by decide +kernel)
def c859 : CNF.Clause Nat := [(39,false), (26,false), (30,false), (8,false), (5,false), (51,false), (18,false), (21,false), (98,false), (99,false)]
theorem p859 (F : Frame G 4) : c859.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 2, 7, 0, 4, 6, 1, 9, 8, 10]) (by decide +kernel)
def c860 : CNF.Clause Nat := [(39,false), (28,false), (30,false), (8,false), (10,false), (98,false), (99,false), (22,false), (16,false), (51,false)]
theorem p860 (F : Frame G 4) : c860.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 2, 7, 0, 9, 8, 10, 1, 4, 6]) (by decide +kernel)
def c861 : CNF.Clause Nat := [(39,false), (4,false), (8,false), (86,false), (99,false), (33,false), (32,false), (21,false), (16,false), (51,false)]
theorem p861 (F : Frame G 4) : c861.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 0, 7, 8, 10, 2, 9, 1, 4, 6]) (by decide +kernel)
def c862 : CNF.Clause Nat := [(8,false), (30,false), (28,false), (50,false), (38,false), (40,false), (18,false), (21,false), (98,false), (99,false)]
theorem p862 (F : Frame G 4) : c862.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 2, 5, 4, 3, 6, 1, 9, 8, 10]) (by decide +kernel)
def c863 : CNF.Clause Nat := [(28,false), (50,false), (51,false), (40,false), (4,false), (8,false), (19,false), (21,false), (98,false), (99,false)]
theorem p863 (F : Frame G 4) : c863.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 6, 3, 0, 7, 1, 9, 8, 10]) (by decide +kernel)
def c864 : CNF.Clause Nat := [(28,false), (50,false), (51,false), (40,false), (4,false), (10,false), (98,false), (86,false), (19,false), (22,false)]
theorem p864 (F : Frame G 4) : c864.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 6, 3, 0, 9, 8, 7, 1, 10]) (by decide +kernel)
def c865 : CNF.Clause Nat := [(40,false), (51,false), (50,false), (17,false), (19,false), (8,false), (9,false), (98,false), (32,false), (33,false)]
theorem p865 (F : Frame G 4) : c865.eval F.assign = true := by
  exact Rule.sound F (.path [3, 6, 4, 5, 1, 7, 0, 8, 9, 2, 10]) (by decide +kernel)
def c866 : CNF.Clause Nat := [(4,false), (8,false), (19,false), (17,false), (50,false), (51,false), (29,false), (32,false), (98,false), (99,false)]
theorem p866 (F : Frame G 4) : c866.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 7, 1, 5, 4, 6, 2, 9, 8, 10]) (by decide +kernel)
def c867 : CNF.Clause Nat := [(20,false), (99,false), (11,false), (8,false), (87,false), (32,false), (28,false), (39,false), (38,false), (51,false)]
theorem p867 (F : Frame G 4) : c867.eval F.assign = true := by
  exact Rule.sound F (.path [1, 8, 10, 0, 7, 9, 2, 5, 3, 4, 6]) (by decide +kernel)
def c868 : CNF.Clause Nat := [(16,false), (18,false), (40,false), (39,false), (6,false), (8,false), (30,false), (32,false), (98,false), (99,false)]
theorem p868 (F : Frame G 4) : c868.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 6, 3, 5, 0, 7, 2, 9, 8, 10]) (by decide +kernel)
def c869 : CNF.Clause Nat := [(28,false), (39,false), (40,false), (51,false), (16,false), (19,false), (87,false), (10,false), (9,false), (99,false)]
theorem p869 (F : Frame G 4) : c869.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 3, 6, 4, 1, 7, 9, 0, 8, 10]) (by decide +kernel)
def c870 : CNF.Clause Nat := [(51,false), (29,false), (28,false), (39,false), (4,false), (8,false), (87,false), (98,false), (20,false), (22,false)]
theorem p870 (F : Frame G 4) : c870.eval F.assign = true := by
  exact Rule.sound F (.path [4, 6, 2, 5, 3, 0, 7, 9, 8, 1, 10]) (by decide +kernel)
def c871 : CNF.Clause Nat := [(28,false), (27,false), (38,false), (40,false), (7,false), (8,false), (19,false), (21,false), (98,false), (99,false)]
theorem p871 (F : Frame G 4) : c871.eval F.assign = true := by
  exact Rule.sound F (.path [5, 2, 4, 3, 6, 0, 7, 1, 9, 8, 10]) (by decide +kernel)
def c872 : CNF.Clause Nat := [(50,false), (16,false), (21,false), (98,false), (99,false), (11,false), (8,false), (30,false), (26,false), (40,false)]
theorem p872 (F : Frame G 4) : c872.eval F.assign = true := by
  exact Rule.sound F (.path [5, 4, 1, 9, 8, 10, 0, 7, 2, 3, 6]) (by decide +kernel)
def c873 : CNF.Clause Nat := [(50,false), (27,false), (29,false), (40,false), (4,false), (8,false), (86,false), (98,false), (21,false), (22,false)]
theorem p873 (F : Frame G 4) : c873.eval F.assign = true := by
  exact Rule.sound F (.path [5, 4, 2, 6, 3, 0, 7, 8, 9, 1, 10]) (by decide +kernel)
def c874 : CNF.Clause Nat := [(38,false), (40,false), (7,false), (6,false), (28,false), (30,false), (86,false), (98,false), (21,false), (22,false)]
theorem p874 (F : Frame G 4) : c874.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 6, 0, 5, 2, 7, 8, 9, 1, 10]) (by decide +kernel)
def c875 : CNF.Clause Nat := [(28,false), (29,false), (40,false), (38,false), (5,false), (8,false), (86,false), (98,false), (21,false), (22,false)]
theorem p875 (F : Frame G 4) : c875.eval F.assign = true := by
  exact Rule.sound F (.path [5, 2, 6, 3, 4, 0, 7, 8, 9, 1, 10]) (by decide +kernel)
def c876 : CNF.Clause Nat := [(50,false), (16,false), (15,false), (40,false), (29,false), (30,false), (8,false), (10,false), (98,false), (99,false)]
theorem p876 (F : Frame G 4) : c876.eval F.assign = true := by
  exact Rule.sound F (.path [5, 4, 1, 3, 6, 2, 7, 0, 9, 8, 10]) (by decide +kernel)
def c877 : CNF.Clause Nat := [(8,false), (86,false), (98,false), (32,false), (33,false), (22,false), (17,false), (50,false), (38,false), (40,false)]
theorem p877 (F : Frame G 4) : c877.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 8, 9, 2, 10, 1, 5, 4, 3, 6]) (by decide +kernel)
def c878 : CNF.Clause Nat := [(6,false), (8,false), (86,false), (98,false), (32,false), (33,false), (22,false), (16,false), (38,false), (40,false)]
theorem p878 (F : Frame G 4) : c878.eval F.assign = true := by
  exact Rule.sound F (.path [5, 0, 7, 8, 9, 2, 10, 1, 4, 3, 6]) (by decide +kernel)
def c879 : CNF.Clause Nat := [(28,false), (27,false), (38,false), (40,false), (7,false), (8,false), (86,false), (20,false), (21,false), (110,false)]
theorem p879 (F : Frame G 4) : c879.eval F.assign = true := by
  exact Rule.sound F (.path [5, 2, 4, 3, 6, 0, 7, 8, 1, 9, 10]) (by decide +kernel)
def c880 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (40,false), (7,false), (8,false), (86,false), (20,false), (21,false), (110,false)]
theorem p880 (F : Frame G 4) : c880.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 6, 0, 7, 8, 1, 9, 10]) (by decide +kernel)
def c881 : CNF.Clause Nat := [(8,false), (86,false), (99,false), (110,false), (32,false), (28,false), (50,false), (16,false), (15,false), (40,false)]
theorem p881 (F : Frame G 4) : c881.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 8, 10, 9, 2, 5, 4, 1, 3, 6]) (by decide +kernel)
def c882 : CNF.Clause Nat := [(8,false), (86,false), (99,false), (110,false), (21,false), (16,false), (50,false), (28,false), (26,false), (40,false)]
theorem p882 (F : Frame G 4) : c882.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 8, 10, 9, 1, 4, 5, 2, 3, 6]) (by decide +kernel)
def c883 : CNF.Clause Nat := [(38,false), (40,false), (29,false), (28,false), (6,false), (8,false), (19,false), (20,false), (98,false), (110,false)]
theorem p883 (F : Frame G 4) : c883.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 6, 2, 5, 0, 7, 1, 8, 9, 10]) (by decide +kernel)
def c884 : CNF.Clause Nat := [(4,false), (7,false), (18,false), (16,false), (50,false), (28,false), (30,false), (86,false), (98,false), (110,false)]
theorem p884 (F : Frame G 4) : c884.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 6, 1, 4, 5, 2, 7, 8, 9, 10]) (by decide +kernel)
def c885 : CNF.Clause Nat := [(50,false), (5,false), (4,false), (40,false), (18,false), (22,false), (99,false), (86,false), (30,false), (32,false)]
theorem p885 (F : Frame G 4) : c885.eval F.assign = true := by
  exact Rule.sound F (.path [5, 4, 0, 3, 6, 1, 10, 8, 7, 2, 9]) (by decide +kernel)
def c886 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (40,false), (7,false), (8,false), (19,false), (20,false), (98,false), (110,false)]
theorem p886 (F : Frame G 4) : c886.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 6, 0, 7, 1, 8, 9, 10]) (by decide +kernel)
def c887 : CNF.Clause Nat := [(28,false), (29,false), (40,false), (38,false), (5,false), (8,false), (19,false), (20,false), (98,false), (110,false)]
theorem p887 (F : Frame G 4) : c887.eval F.assign = true := by
  exact Rule.sound F (.path [5, 2, 6, 3, 4, 0, 7, 1, 8, 9, 10]) (by decide +kernel)
def c888 : CNF.Clause Nat := [(28,false), (29,false), (40,false), (38,false), (16,false), (22,false), (110,false), (10,false), (8,false), (86,false)]
theorem p888 (F : Frame G 4) : c888.eval F.assign = true := by
  exact Rule.sound F (.path [5, 2, 6, 3, 4, 1, 10, 9, 0, 7, 8]) (by decide +kernel)
def c889 : CNF.Clause Nat := [(16,false), (50,false), (6,false), (4,false), (40,false), (29,false), (30,false), (86,false), (98,false), (110,false)]
theorem p889 (F : Frame G 4) : c889.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 0, 3, 6, 2, 7, 8, 9, 10]) (by decide +kernel)
def c890 : CNF.Clause Nat := [(28,false), (50,false), (38,false), (40,false), (18,false), (19,false), (8,false), (9,false), (98,false), (110,false)]
theorem p890 (F : Frame G 4) : c890.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 3, 6, 1, 7, 0, 8, 9, 10]) (by decide +kernel)
def c891 : CNF.Clause Nat := [(30,false), (86,false), (98,false), (110,false), (11,false), (7,false), (40,false), (15,false), (16,false), (50,false)]
theorem p891 (F : Frame G 4) : c891.eval F.assign = true := by
  exact Rule.sound F (.path [2, 7, 8, 9, 10, 0, 6, 3, 1, 4, 5]) (by decide +kernel)
def c892 : CNF.Clause Nat := [(8,false), (86,false), (31,false), (29,false), (40,false), (38,false), (50,false), (17,false), (21,false), (110,false)]
theorem p892 (F : Frame G 4) : c892.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 8, 2, 6, 3, 4, 5, 1, 9, 10]) (by decide +kernel)
def c893 : CNF.Clause Nat := [(29,false), (62,false), (50,false), (38,false), (4,false), (8,false), (86,false), (20,false), (21,false), (110,false)]
theorem p893 (F : Frame G 4) : c893.eval F.assign = true := by
  exact Rule.sound F (.path [2, 6, 5, 4, 3, 0, 7, 8, 1, 9, 10]) (by decide +kernel)
def c894 : CNF.Clause Nat := [(29,false), (62,false), (50,false), (38,false), (15,false), (22,false), (11,false), (8,false), (86,false), (98,false)]
theorem p894 (F : Frame G 4) : c894.eval F.assign = true := by
  exact Rule.sound F (.path [2, 6, 5, 4, 3, 1, 10, 0, 7, 8, 9]) (by decide +kernel)
def c895 : CNF.Clause Nat := [(16,false), (38,false), (40,false), (29,false), (28,false), (6,false), (11,false), (110,false), (87,false), (86,false)]
theorem p895 (F : Frame G 4) : c895.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 6, 2, 5, 0, 10, 9, 7, 8]) (by decide +kernel)
def c896 : CNF.Clause Nat := [(16,false), (50,false), (6,false), (4,false), (40,false), (29,false), (32,false), (87,false), (86,false), (99,false)]
theorem p896 (F : Frame G 4) : c896.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 0, 3, 6, 2, 9, 7, 8, 10]) (by decide +kernel)
def c897 : CNF.Clause Nat := [(4,false), (5,false), (16,false), (17,false), (62,false), (29,false), (32,false), (87,false), (86,false), (99,false)]
theorem p897 (F : Frame G 4) : c897.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 4, 1, 5, 6, 2, 9, 7, 8, 10]) (by decide +kernel)
def c898 : CNF.Clause Nat := [(50,false), (62,false), (29,false), (26,false), (4,false), (8,false), (86,false), (20,false), (21,false), (110,false)]
theorem p898 (F : Frame G 4) : c898.eval F.assign = true := by
  exact Rule.sound F (.path [4, 5, 6, 2, 3, 0, 7, 8, 1, 9, 10]) (by decide +kernel)
def c899 : CNF.Clause Nat := [(28,false), (50,false), (5,false), (4,false), (40,false), (18,false), (19,false), (86,false), (98,false), (110,false)]
theorem p899 (F : Frame G 4) : c899.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 0, 3, 6, 1, 7, 8, 9, 10]) (by decide +kernel)
def c900 : CNF.Clause Nat := [(40,false), (29,false), (28,false), (50,false), (5,false), (8,false), (19,false), (20,false), (98,false), (110,false)]
theorem p900 (F : Frame G 4) : c900.eval F.assign = true := by
  exact Rule.sound F (.path [3, 6, 2, 5, 4, 0, 7, 1, 8, 9, 10]) (by decide +kernel)
end Cert44Steps
end Graffiti199Depleted.Catalogue.OrderEleven
