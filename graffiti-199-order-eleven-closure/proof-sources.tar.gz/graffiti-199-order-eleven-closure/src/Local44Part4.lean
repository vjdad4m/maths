import Local44Part3
namespace Graffiti199Depleted.Catalogue.OrderEleven
namespace Cert44Steps
open Std.Sat
set_option maxRecDepth 4096
set_option maxHeartbeats 0
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj]
def c1201 : CNF.Clause Nat := [(39,false), (6,false), (8,false), (88,false), (99,false), (20,false), (16,false), (51,false), (29,false), (32,false)]
theorem p1201 (F : Frame G 4) : c1201.eval F.assign = true := by
  exact Rule.sound F (.path [3, 5, 0, 7, 10, 8, 1, 4, 6, 2, 9]) (by decide +kernel)
def c1202 : CNF.Clause Nat := [(28,false), (62,false), (40,false), (4,false), (5,false), (16,false), (20,false), (98,false), (87,false), (88,false)]
theorem p1202 (F : Frame G 4) : c1202.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 6, 3, 0, 4, 1, 8, 9, 7, 10]) (by decide +kernel)
def c1203 : CNF.Clause Nat := [(38,false), (39,false), (62,false), (7,false), (8,false), (30,false), (31,false), (20,false), (21,false), (110,false)]
theorem p1203 (F : Frame G 4) : c1203.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 5, 6, 0, 7, 2, 8, 1, 9, 10]) (by decide +kernel)
def c1204 : CNF.Clause Nat := [(16,false), (38,false), (39,false), (62,false), (7,false), (8,false), (30,false), (31,false), (99,false), (110,false)]
theorem p1204 (F : Frame G 4) : c1204.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 5, 6, 0, 7, 2, 8, 10, 9]) (by decide +kernel)
def c1205 : CNF.Clause Nat := [(28,false), (62,false), (40,false), (38,false), (5,false), (8,false), (19,false), (20,false), (99,false), (110,false)]
theorem p1205 (F : Frame G 4) : c1205.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 6, 3, 4, 0, 7, 1, 8, 10, 9]) (by decide +kernel)
def c1206 : CNF.Clause Nat := [(26,false), (28,false), (62,false), (51,false), (5,false), (8,false), (19,false), (20,false), (99,false), (110,false)]
theorem p1206 (F : Frame G 4) : c1206.eval F.assign = true := by
  exact Rule.sound F (.path [3, 2, 5, 6, 4, 0, 7, 1, 8, 10, 9]) (by decide +kernel)
def c1207 : CNF.Clause Nat := [(4,false), (8,false), (88,false), (110,false), (32,false), (31,false), (20,false), (16,false), (51,false), (62,false)]
theorem p1207 (F : Frame G 4) : c1207.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 7, 10, 9, 2, 8, 1, 4, 6, 5]) (by decide +kernel)
def c1208 : CNF.Clause Nat := [(50,false), (17,false), (15,false), (40,false), (7,false), (8,false), (30,false), (31,false), (98,false), (110,false)]
theorem p1208 (F : Frame G 4) : c1208.eval F.assign = true := by
  exact Rule.sound F (.path [4, 5, 1, 3, 6, 0, 7, 2, 8, 9, 10]) (by decide +kernel)
def c1209 : CNF.Clause Nat := [(16,false), (18,false), (40,false), (39,false), (6,false), (8,false), (30,false), (31,false), (98,false), (110,false)]
theorem p1209 (F : Frame G 4) : c1209.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 6, 3, 5, 0, 7, 2, 8, 9, 10]) (by decide +kernel)
def c1210 : CNF.Clause Nat := [(50,false), (17,false), (18,false), (40,false), (4,false), (11,false), (110,false), (87,false), (30,false), (31,false)]
theorem p1210 (F : Frame G 4) : c1210.eval F.assign = true := by
  exact Rule.sound F (.path [4, 5, 1, 6, 3, 0, 10, 9, 7, 2, 8]) (by decide +kernel)
def c1211 : CNF.Clause Nat := [(16,false), (50,false), (39,false), (40,false), (7,false), (9,false), (98,false), (87,false), (30,false), (33,false)]
theorem p1211 (F : Frame G 4) : c1211.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 5, 3, 6, 0, 8, 9, 7, 2, 10]) (by decide +kernel)
def c1212 : CNF.Clause Nat := [(39,false), (40,false), (7,false), (5,false), (16,false), (20,false), (31,false), (30,false), (87,false), (110,false)]
theorem p1212 (F : Frame G 4) : c1212.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 6, 0, 4, 1, 8, 2, 7, 9, 10]) (by decide +kernel)
def c1213 : CNF.Clause Nat := [(8,false), (87,false), (110,false), (33,false), (31,false), (20,false), (15,false), (40,false), (51,false), (50,false)]
theorem p1213 (F : Frame G 4) : c1213.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 9, 10, 2, 8, 1, 3, 6, 4, 5]) (by decide +kernel)
def c1214 : CNF.Clause Nat := [(17,false), (50,false), (51,false), (40,false), (4,false), (9,false), (98,false), (87,false), (30,false), (33,false)]
theorem p1214 (F : Frame G 4) : c1214.eval F.assign = true := by
  exact Rule.sound F (.path [1, 5, 4, 6, 3, 0, 8, 9, 7, 2, 10]) (by decide +kernel)
def c1215 : CNF.Clause Nat := [(8,false), (19,false), (17,false), (50,false), (38,false), (40,false), (29,false), (31,false), (98,false), (110,false)]
theorem p1215 (F : Frame G 4) : c1215.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 1, 5, 4, 3, 6, 2, 8, 9, 10]) (by decide +kernel)
def c1216 : CNF.Clause Nat := [(28,false), (62,false), (40,false), (38,false), (5,false), (8,false), (19,false), (20,false), (98,false), (110,false)]
theorem p1216 (F : Frame G 4) : c1216.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 6, 3, 4, 0, 7, 1, 8, 9, 10]) (by decide +kernel)
def c1217 : CNF.Clause Nat := [(38,false), (40,false), (62,false), (6,false), (8,false), (19,false), (22,false), (110,false), (32,false), (31,false)]
theorem p1217 (F : Frame G 4) : c1217.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 6, 5, 0, 7, 1, 10, 9, 2, 8]) (by decide +kernel)
def c1218 : CNF.Clause Nat := [(27,false), (28,false), (62,false), (40,false), (4,false), (8,false), (19,false), (20,false), (98,false), (110,false)]
theorem p1218 (F : Frame G 4) : c1218.eval F.assign = true := by
  exact Rule.sound F (.path [4, 2, 5, 6, 3, 0, 7, 1, 8, 9, 10]) (by decide +kernel)
def c1219 : CNF.Clause Nat := [(16,false), (18,false), (40,false), (39,false), (6,false), (8,false), (88,false), (99,false), (31,false), (32,false)]
theorem p1219 (F : Frame G 4) : c1219.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 6, 3, 5, 0, 7, 10, 8, 2, 9]) (by decide +kernel)
def c1220 : CNF.Clause Nat := [(17,false), (50,false), (38,false), (40,false), (29,false), (30,false), (8,false), (9,false), (98,false), (110,false)]
theorem p1220 (F : Frame G 4) : c1220.eval F.assign = true := by
  exact Rule.sound F (.path [1, 5, 4, 3, 6, 2, 7, 0, 8, 9, 10]) (by decide +kernel)
def c1221 : CNF.Clause Nat := [(5,false), (6,false), (39,false), (40,false), (18,false), (20,false), (98,false), (87,false), (30,false), (33,false)]
theorem p1221 (F : Frame G 4) : c1221.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 5, 3, 6, 1, 8, 9, 7, 2, 10]) (by decide +kernel)
def c1222 : CNF.Clause Nat := [(5,false), (8,false), (87,false), (98,false), (20,false), (17,false), (39,false), (40,false), (29,false), (33,false)]
theorem p1222 (F : Frame G 4) : c1222.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 7, 9, 8, 1, 5, 3, 6, 2, 10]) (by decide +kernel)
def c1223 : CNF.Clause Nat := [(40,false), (7,false), (8,false), (87,false), (110,false), (99,false), (20,false), (16,false), (27,false), (28,false)]
theorem p1223 (F : Frame G 4) : c1223.eval F.assign = true := by
  exact Rule.sound F (.path [3, 6, 0, 7, 9, 10, 8, 1, 4, 2, 5]) (by decide +kernel)
def c1224 : CNF.Clause Nat := [(40,false), (18,false), (16,false), (50,false), (28,false), (31,false), (99,false), (11,false), (8,false), (87,false)]
theorem p1224 (F : Frame G 4) : c1224.eval F.assign = true := by
  exact Rule.sound F (.path [3, 6, 1, 4, 5, 2, 8, 10, 0, 7, 9]) (by decide +kernel)
def c1225 : CNF.Clause Nat := [(28,false), (50,false), (51,false), (40,false), (4,false), (8,false), (87,false), (110,false), (22,false), (20,false)]
theorem p1225 (F : Frame G 4) : c1225.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 6, 3, 0, 7, 9, 10, 1, 8]) (by decide +kernel)
def c1226 : CNF.Clause Nat := [(16,false), (20,false), (9,false), (11,false), (110,false), (87,false), (30,false), (28,false), (39,false), (40,false)]
theorem p1226 (F : Frame G 4) : c1226.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 8, 0, 10, 9, 7, 2, 5, 3, 6]) (by decide +kernel)
def c1227 : CNF.Clause Nat := [(16,false), (17,false), (62,false), (40,false), (26,false), (30,false), (8,false), (9,false), (98,false), (110,false)]
theorem p1227 (F : Frame G 4) : c1227.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 5, 6, 3, 2, 7, 0, 8, 9, 10]) (by decide +kernel)
def c1228 : CNF.Clause Nat := [(38,false), (15,false), (17,false), (62,false), (29,false), (30,false), (8,false), (9,false), (98,false), (110,false)]
theorem p1228 (F : Frame G 4) : c1228.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 1, 5, 6, 2, 7, 0, 8, 9, 10]) (by decide +kernel)
def c1229 : CNF.Clause Nat := [(16,false), (38,false), (40,false), (62,false), (6,false), (9,false), (98,false), (87,false), (30,false), (33,false)]
theorem p1229 (F : Frame G 4) : c1229.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 6, 5, 0, 8, 9, 7, 2, 10]) (by decide +kernel)
def c1230 : CNF.Clause Nat := [(8,false), (87,false), (98,false), (20,false), (22,false), (33,false), (27,false), (38,false), (39,false), (62,false)]
theorem p1230 (F : Frame G 4) : c1230.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 9, 8, 1, 10, 2, 4, 3, 5, 6]) (by decide +kernel)
def c1231 : CNF.Clause Nat := [(38,false), (5,false), (7,false), (62,false), (17,false), (20,false), (98,false), (87,false), (30,false), (33,false)]
theorem p1231 (F : Frame G 4) : c1231.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 0, 6, 5, 1, 8, 9, 7, 2, 10]) (by decide +kernel)
def c1232 : CNF.Clause Nat := [(16,false), (18,false), (40,false), (39,false), (6,false), (8,false), (87,false), (98,false), (31,false), (33,false)]
theorem p1232 (F : Frame G 4) : c1232.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 6, 3, 5, 0, 7, 9, 8, 2, 10]) (by decide +kernel)
def c1233 : CNF.Clause Nat := [(32,false), (110,false), (88,false), (19,false), (20,false), (9,false), (4,false), (39,false), (50,false), (51,false)]
theorem p1233 (F : Frame G 4) : c1233.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 10, 7, 1, 8, 0, 3, 5, 4, 6]) (by decide +kernel)
def c1234 : CNF.Clause Nat := [(39,false), (4,false), (8,false), (30,false), (32,false), (110,false), (99,false), (20,false), (16,false), (51,false)]
theorem p1234 (F : Frame G 4) : c1234.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 0, 7, 2, 9, 10, 8, 1, 4, 6]) (by decide +kernel)
def c1235 : CNF.Clause Nat := [(15,false), (16,false), (51,false), (62,false), (28,false), (30,false), (8,false), (9,false), (99,false), (110,false)]
theorem p1235 (F : Frame G 4) : c1235.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 6, 5, 2, 7, 0, 8, 10, 9]) (by decide +kernel)
def c1236 : CNF.Clause Nat := [(32,false), (110,false), (88,false), (8,false), (9,false), (20,false), (15,false), (40,false), (51,false), (50,false)]
theorem p1236 (F : Frame G 4) : c1236.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 10, 7, 0, 8, 1, 3, 6, 4, 5]) (by decide +kernel)
def c1237 : CNF.Clause Nat := [(32,false), (110,false), (88,false), (19,false), (20,false), (9,false), (5,false), (51,false), (40,false), (39,false)]
theorem p1237 (F : Frame G 4) : c1237.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 10, 7, 1, 8, 0, 4, 6, 3, 5]) (by decide +kernel)
def c1238 : CNF.Clause Nat := [(4,false), (5,false), (51,false), (62,false), (17,false), (20,false), (99,false), (88,false), (30,false), (32,false)]
theorem p1238 (F : Frame G 4) : c1238.eval F.assign = true := by
  exact Rule.sound F (.path [3, 0, 4, 6, 5, 1, 8, 10, 7, 2, 9]) (by decide +kernel)
def c1239 : CNF.Clause Nat := [(16,false), (38,false), (40,false), (62,false), (6,false), (8,false), (30,false), (31,false), (99,false), (110,false)]
theorem p1239 (F : Frame G 4) : c1239.eval F.assign = true := by
  exact Rule.sound F (.path [1, 4, 3, 6, 5, 0, 7, 2, 8, 10, 9]) (by decide +kernel)
def c1240 : CNF.Clause Nat := [(5,false), (4,false), (40,false), (62,false), (17,false), (20,false), (31,false), (30,false), (88,false), (110,false)]
theorem p1240 (F : Frame G 4) : c1240.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 3, 6, 5, 1, 8, 2, 7, 10, 9]) (by decide +kernel)
def c1241 : CNF.Clause Nat := [(5,false), (4,false), (39,false), (62,false), (18,false), (20,false), (31,false), (30,false), (88,false), (110,false)]
theorem p1241 (F : Frame G 4) : c1241.eval F.assign = true := by
  exact Rule.sound F (.path [4, 0, 3, 5, 6, 1, 8, 2, 7, 10, 9]) (by decide +kernel)
def c1242 : CNF.Clause Nat := [(38,false), (51,false), (62,false), (6,false), (8,false), (19,false), (20,false), (99,false), (33,false), (32,false)]
theorem p1242 (F : Frame G 4) : c1242.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 6, 5, 0, 7, 1, 8, 10, 2, 9]) (by decide +kernel)
def c1243 : CNF.Clause Nat := [(32,false), (110,false), (88,false), (8,false), (9,false), (20,false), (18,false), (40,false), (38,false), (50,false)]
theorem p1243 (F : Frame G 4) : c1243.eval F.assign = true := by
  exact Rule.sound F (.path [2, 9, 10, 7, 0, 8, 1, 6, 3, 4, 5]) (by decide +kernel)
def c1244 : CNF.Clause Nat := [(16,false), (19,false), (8,false), (6,false), (39,false), (40,false), (29,false), (31,false), (99,false), (110,false)]
theorem p1244 (F : Frame G 4) : c1244.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 7, 0, 5, 3, 6, 2, 8, 10, 9]) (by decide +kernel)
def c1245 : CNF.Clause Nat := [(16,false), (19,false), (88,false), (99,false), (9,false), (6,false), (39,false), (40,false), (29,false), (32,false)]
theorem p1245 (F : Frame G 4) : c1245.eval F.assign = true := by
  exact Rule.sound F (.path [4, 1, 7, 10, 8, 0, 5, 3, 6, 2, 9]) (by decide +kernel)
def c1246 : CNF.Clause Nat := [(38,false), (26,false), (28,false), (62,false), (7,false), (8,false), (19,false), (20,false), (99,false), (110,false)]
theorem p1246 (F : Frame G 4) : c1246.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 2, 5, 6, 0, 7, 1, 8, 10, 9]) (by decide +kernel)
def c1247 : CNF.Clause Nat := [(40,false), (29,false), (28,false), (50,false), (16,false), (19,false), (87,false), (10,false), (9,false), (99,false)]
theorem p1247 (F : Frame G 4) : c1247.eval F.assign = true := by
  exact Rule.sound F (.path [3, 6, 2, 5, 4, 1, 7, 9, 0, 8, 10]) (by decide +kernel)
def c1248 : CNF.Clause Nat := [(40,false), (29,false), (28,false), (50,false), (5,false), (8,false), (19,false), (20,false), (99,false), (110,false)]
theorem p1248 (F : Frame G 4) : c1248.eval F.assign = true := by
  exact Rule.sound F (.path [3, 6, 2, 5, 4, 0, 7, 1, 8, 10, 9]) (by decide +kernel)
def c1249 : CNF.Clause Nat := [(38,false), (15,false), (19,false), (8,false), (9,false), (99,false), (110,false), (32,false), (28,false), (62,false)]
theorem p1249 (F : Frame G 4) : c1249.eval F.assign = true := by
  exact Rule.sound F (.path [4, 3, 1, 7, 0, 8, 10, 9, 2, 5, 6]) (by decide +kernel)
def c1250 : CNF.Clause Nat := [(28,false), (62,false), (40,false), (38,false), (16,false), (21,false), (110,false), (88,false), (8,false), (9,false)]
theorem p1250 (F : Frame G 4) : c1250.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 6, 3, 4, 1, 9, 10, 7, 0, 8]) (by decide +kernel)
def c1251 : CNF.Clause Nat := [(38,false), (51,false), (18,false), (17,false), (28,false), (30,false), (8,false), (9,false), (99,false), (110,false)]
theorem p1251 (F : Frame G 4) : c1251.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 6, 1, 5, 2, 7, 0, 8, 10, 9]) (by decide +kernel)
def c1252 : CNF.Clause Nat := [(8,false), (88,false), (99,false), (31,false), (32,false), (21,false), (17,false), (50,false), (38,false), (40,false)]
theorem p1252 (F : Frame G 4) : c1252.eval F.assign = true := by
  exact Rule.sound F (.path [0, 7, 10, 8, 2, 9, 1, 5, 4, 3, 6]) (by decide +kernel)
def c1253 : CNF.Clause Nat := [(28,false), (29,false), (51,false), (38,false), (15,false), (19,false), (8,false), (9,false), (99,false), (110,false)]
theorem p1253 (F : Frame G 4) : c1253.eval F.assign = true := by
  exact Rule.sound F (.path [5, 2, 6, 4, 3, 1, 7, 0, 8, 10, 9]) (by decide +kernel)
def c1254 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (20,false), (99,false), (33,false), (29,false), (7,false), (8,false), (87,false)]
theorem p1254 (F : Frame G 4) : c1254.eval F.assign = true := by
  exact Rule.sound F (.path [3, 4, 5, 1, 8, 10, 2, 6, 0, 7, 9]) (by decide +kernel)
def c1255 : CNF.Clause Nat := [(15,false), (16,false), (50,false), (6,false), (7,false), (29,false), (30,false), (87,false), (110,false), (99,false)]
theorem p1255 (F : Frame G 4) : c1255.eval F.assign = true := by
  exact Rule.sound F (.path [3, 1, 4, 5, 0, 6, 2, 7, 9, 10, 8]) (by decide +kernel)
def c1256 : CNF.Clause Nat := [(28,false), (50,false), (16,false), (15,false), (40,false), (7,false), (8,false), (87,false), (110,false), (99,false)]
theorem p1256 (F : Frame G 4) : c1256.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 1, 3, 6, 0, 7, 9, 10, 8]) (by decide +kernel)
def c1257 : CNF.Clause Nat := [(28,false), (50,false), (51,false), (40,false), (15,false), (19,false), (87,false), (10,false), (9,false), (99,false)]
theorem p1257 (F : Frame G 4) : c1257.eval F.assign = true := by
  exact Rule.sound F (.path [2, 5, 4, 6, 3, 1, 7, 9, 0, 8, 10]) (by decide +kernel)
def c1258 : CNF.Clause Nat := [(51,false), (62,false), (17,false), (15,false), (4,false), (8,false), (87,false), (32,false), (31,false), (99,false)]
theorem p1258 (F : Frame G 4) : c1258.eval F.assign = true := by
  exact Rule.sound F (.path [4, 6, 5, 1, 3, 0, 7, 9, 2, 8, 10]) (by decide +kernel)
def c1259 : CNF.Clause Nat := [(40,false), (51,false), (16,false), (17,false), (28,false), (31,false), (99,false), (11,false), (8,false), (87,false)]
theorem p1259 (F : Frame G 4) : c1259.eval F.assign = true := by
  exact Rule.sound F (.path [3, 6, 4, 1, 5, 2, 8, 10, 0, 7, 9]) (by decide +kernel)
def c1260 : CNF.Clause Nat := [(27,false), (28,false), (39,false), (40,false), (7,false), (10,false), (110,false), (88,false), (19,false), (20,false)]
theorem p1260 (F : Frame G 4) : c1260.eval F.assign = true := by
  exact Rule.sound F (.path [4, 2, 5, 3, 6, 0, 9, 10, 7, 1, 8]) (by decide +kernel)
def c1261 : CNF.Clause Nat := [(50,false), (17,false), (18,false), (40,false), (4,false), (9,false), (99,false), (88,false), (30,false), (32,false)]
theorem p1261 (F : Frame G 4) : c1261.eval F.assign = true := by
  exact Rule.sound F (.path [4, 5, 1, 6, 3, 0, 8, 10, 7, 2, 9]) (by decide +kernel)
def c1262 : CNF.Clause Nat := [(40,false), (51,false), (5,false), (6,false), (28,false), (31,false), (20,false), (19,false), (87,false), (110,false)]
theorem p1262 (F : Frame G 4) : c1262.eval F.assign = true := by
  exact Rule.sound F (.path [3, 6, 4, 0, 5, 2, 8, 1, 7, 9, 10]) (by decide +kernel)
def c1263 : CNF.Clause Nat := [(40,false), (29,false), (27,false), (50,false), (6,false), (8,false), (19,false), (20,false), (99,false), (110,false)]
theorem p1263 (F : Frame G 4) : c1263.eval F.assign = true := by
  exact Rule.sound F (.path [3, 6, 2, 4, 5, 0, 7, 1, 8, 10, 9]) (by decide +kernel)
def c1264 : CNF.Clause Nat := [(39,false), (40,false), (7,false), (5,false), (27,false), (31,false), (20,false), (19,false), (88,false), (110,false)]
theorem p1264 (F : Frame G 4) : c1264.eval F.assign = true := by
  exact Rule.sound F (.path [5, 3, 6, 0, 4, 2, 8, 1, 7, 10, 9]) (by decide +kernel)
def c1265 : CNF.Clause Nat := [(50,false), (51,false), (29,false), (26,false), (15,false), (20,false), (99,false), (88,false), (8,false), (10,false)]
theorem p1265 (F : Frame G 4) : c1265.eval F.assign = true := by
  exact Rule.sound F (.path [5, 4, 6, 2, 3, 1, 8, 10, 7, 0, 9]) (by decide +kernel)
def c1266 : CNF.Clause Nat := [(17,false), (50,false), (51,false), (40,false), (26,false), (30,false), (8,false), (9,false), (99,false), (110,false)]
theorem p1266 (F : Frame G 4) : c1266.eval F.assign = true := by
  exact Rule.sound F (.path [1, 5, 4, 6, 3, 2, 7, 0, 8, 10, 9]) (by decide +kernel)
def c1267 : CNF.Clause Nat := [(40,false), (29,false), (27,false), (50,false), (17,false), (19,false), (8,false), (9,false), (99,false), (110,false)]
theorem p1267 (F : Frame G 4) : c1267.eval F.assign = true := by
  exact Rule.sound F (.path [3, 6, 2, 4, 5, 1, 7, 0, 8, 10, 9]) (by decide +kernel)
def c1268 : CNF.Clause Nat := [(5,false), (6,false), (9,false), (38,true), (39,true), (50,true), (86,true)]
theorem p1268 (F : Frame G 4) : c1268.eval F.assign = true := by
  apply local_rup F.assign c1268 [c1, c4, c268]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p268 F) (rfl)))
  · decide +kernel
def c1269 : CNF.Clause Nat := [(5,false), (6,false), (10,false), (38,true), (39,true), (50,true), (87,true)]
theorem p1269 (F : Frame G 4) : c1269.eval F.assign = true := by
  apply local_rup F.assign c1269 [c1, c4, c269]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p269 F) (rfl)))
  · decide +kernel
def c1270 : CNF.Clause Nat := [(5,false), (6,false), (11,false), (38,true), (39,true), (50,true), (88,true)]
theorem p1270 (F : Frame G 4) : c1270.eval F.assign = true := by
  apply local_rup F.assign c1270 [c1, c4, c270]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p270 F) (rfl)))
  · decide +kernel
def c1271 : CNF.Clause Nat := [(5,false), (7,false), (9,false), (38,true), (40,true), (51,true), (86,true)]
theorem p1271 (F : Frame G 4) : c1271.eval F.assign = true := by
  apply local_rup F.assign c1271 [c1, c4, c271]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p271 F) (rfl)))
  · decide +kernel
def c1272 : CNF.Clause Nat := [(5,false), (7,false), (10,false), (38,true), (40,true), (51,true), (87,true)]
theorem p1272 (F : Frame G 4) : c1272.eval F.assign = true := by
  apply local_rup F.assign c1272 [c1, c4, c272]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p272 F) (rfl)))
  · decide +kernel
def c1273 : CNF.Clause Nat := [(5,false), (7,false), (11,false), (38,true), (40,true), (51,true), (88,true)]
theorem p1273 (F : Frame G 4) : c1273.eval F.assign = true := by
  apply local_rup F.assign c1273 [c1, c4, c273]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p273 F) (rfl)))
  · decide +kernel
def c1274 : CNF.Clause Nat := [(5,false), (7,false), (9,false), (10,false), (38,true), (40,true), (51,true), (98,true)]
theorem p1274 (F : Frame G 4) : c1274.eval F.assign = true := by
  apply local_rup F.assign c1274 [c1, c274]
  · exact sat_cons (p1 F) ( sat_cons (p274 F) (rfl))
  · decide +kernel
def c1275 : CNF.Clause Nat := [(5,false), (7,false), (9,false), (11,false), (38,true), (40,true), (51,true), (99,true)]
theorem p1275 (F : Frame G 4) : c1275.eval F.assign = true := by
  apply local_rup F.assign c1275 [c1, c275]
  · exact sat_cons (p1 F) ( sat_cons (p275 F) (rfl))
  · decide +kernel
def c1276 : CNF.Clause Nat := [(5,false), (7,false), (10,false), (11,false), (38,true), (40,true), (51,true), (110,true)]
theorem p1276 (F : Frame G 4) : c1276.eval F.assign = true := by
  apply local_rup F.assign c1276 [c1, c276]
  · exact sat_cons (p1 F) ( sat_cons (p276 F) (rfl))
  · decide +kernel
def c1277 : CNF.Clause Nat := [(5,false), (9,false), (10,false), (38,true), (86,true), (87,true), (98,true)]
theorem p1277 (F : Frame G 4) : c1277.eval F.assign = true := by
  apply local_rup F.assign c1277 [c1, c4, c277]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p277 F) (rfl)))
  · decide +kernel
def c1278 : CNF.Clause Nat := [(5,false), (9,false), (11,false), (38,true), (86,true), (88,true), (99,true)]
theorem p1278 (F : Frame G 4) : c1278.eval F.assign = true := by
  apply local_rup F.assign c1278 [c1, c4, c278]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p278 F) (rfl)))
  · decide +kernel
def c1279 : CNF.Clause Nat := [(5,false), (10,false), (11,false), (38,true), (87,true), (88,true), (110,true)]
theorem p1279 (F : Frame G 4) : c1279.eval F.assign = true := by
  apply local_rup F.assign c1279 [c1, c4, c279]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p279 F) (rfl)))
  · decide +kernel
def c1280 : CNF.Clause Nat := [(5,false), (9,false), (10,false), (11,false), (38,true), (98,true), (99,true), (110,true)]
theorem p1280 (F : Frame G 4) : c1280.eval F.assign = true := by
  apply local_rup F.assign c1280 [c1, c280]
  · exact sat_cons (p1 F) ( sat_cons (p280 F) (rfl))
  · decide +kernel
def c1281 : CNF.Clause Nat := [(6,false), (7,false), (9,false), (39,true), (40,true), (62,true), (86,true)]
theorem p1281 (F : Frame G 4) : c1281.eval F.assign = true := by
  apply local_rup F.assign c1281 [c1, c4, c281]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p281 F) (rfl)))
  · decide +kernel
def c1282 : CNF.Clause Nat := [(6,false), (7,false), (10,false), (39,true), (40,true), (62,true), (87,true)]
theorem p1282 (F : Frame G 4) : c1282.eval F.assign = true := by
  apply local_rup F.assign c1282 [c1, c4, c282]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p282 F) (rfl)))
  · decide +kernel
def c1283 : CNF.Clause Nat := [(6,false), (7,false), (11,false), (39,true), (40,true), (62,true), (88,true)]
theorem p1283 (F : Frame G 4) : c1283.eval F.assign = true := by
  apply local_rup F.assign c1283 [c1, c4, c283]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p283 F) (rfl)))
  · decide +kernel
def c1284 : CNF.Clause Nat := [(6,false), (7,false), (9,false), (10,false), (39,true), (40,true), (62,true), (98,true)]
theorem p1284 (F : Frame G 4) : c1284.eval F.assign = true := by
  apply local_rup F.assign c1284 [c1, c284]
  · exact sat_cons (p1 F) ( sat_cons (p284 F) (rfl))
  · decide +kernel
def c1285 : CNF.Clause Nat := [(6,false), (7,false), (9,false), (11,false), (39,true), (40,true), (62,true), (99,true)]
theorem p1285 (F : Frame G 4) : c1285.eval F.assign = true := by
  apply local_rup F.assign c1285 [c1, c285]
  · exact sat_cons (p1 F) ( sat_cons (p285 F) (rfl))
  · decide +kernel
def c1286 : CNF.Clause Nat := [(6,false), (7,false), (10,false), (11,false), (39,true), (40,true), (62,true), (110,true)]
theorem p1286 (F : Frame G 4) : c1286.eval F.assign = true := by
  apply local_rup F.assign c1286 [c1, c286]
  · exact sat_cons (p1 F) ( sat_cons (p286 F) (rfl))
  · decide +kernel
def c1287 : CNF.Clause Nat := [(6,false), (9,false), (10,false), (39,true), (86,true), (87,true), (98,true)]
theorem p1287 (F : Frame G 4) : c1287.eval F.assign = true := by
  apply local_rup F.assign c1287 [c1, c4, c287]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p287 F) (rfl)))
  · decide +kernel
def c1288 : CNF.Clause Nat := [(6,false), (9,false), (11,false), (39,true), (86,true), (88,true), (99,true)]
theorem p1288 (F : Frame G 4) : c1288.eval F.assign = true := by
  apply local_rup F.assign c1288 [c1, c4, c288]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p288 F) (rfl)))
  · decide +kernel
def c1289 : CNF.Clause Nat := [(6,false), (10,false), (11,false), (39,true), (87,true), (88,true), (110,true)]
theorem p1289 (F : Frame G 4) : c1289.eval F.assign = true := by
  apply local_rup F.assign c1289 [c1, c4, c289]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p289 F) (rfl)))
  · decide +kernel
def c1290 : CNF.Clause Nat := [(6,false), (9,false), (10,false), (11,false), (39,true), (98,true), (99,true), (110,true)]
theorem p1290 (F : Frame G 4) : c1290.eval F.assign = true := by
  apply local_rup F.assign c1290 [c1, c290]
  · exact sat_cons (p1 F) ( sat_cons (p290 F) (rfl))
  · decide +kernel
def c1291 : CNF.Clause Nat := [(7,false), (9,false), (10,false), (40,true), (86,true), (87,true), (98,true)]
theorem p1291 (F : Frame G 4) : c1291.eval F.assign = true := by
  apply local_rup F.assign c1291 [c1, c4, c291]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p291 F) (rfl)))
  · decide +kernel
def c1292 : CNF.Clause Nat := [(7,false), (9,false), (11,false), (40,true), (86,true), (88,true), (99,true)]
theorem p1292 (F : Frame G 4) : c1292.eval F.assign = true := by
  apply local_rup F.assign c1292 [c1, c4, c292]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p292 F) (rfl)))
  · decide +kernel
def c1293 : CNF.Clause Nat := [(7,false), (10,false), (11,false), (40,true), (87,true), (88,true), (110,true)]
theorem p1293 (F : Frame G 4) : c1293.eval F.assign = true := by
  apply local_rup F.assign c1293 [c1, c4, c293]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p293 F) (rfl)))
  · decide +kernel
def c1294 : CNF.Clause Nat := [(7,false), (9,false), (10,false), (11,false), (40,true), (98,true), (99,true), (110,true)]
theorem p1294 (F : Frame G 4) : c1294.eval F.assign = true := by
  apply local_rup F.assign c1294 [c1, c294]
  · exact sat_cons (p1 F) ( sat_cons (p294 F) (rfl))
  · decide +kernel
def c1295 : CNF.Clause Nat := [(5,false), (6,false), (7,false), (9,false), (50,true), (51,true), (62,true), (86,true)]
theorem p1295 (F : Frame G 4) : c1295.eval F.assign = true := by
  apply local_rup F.assign c1295 [c4, c295]
  · exact sat_cons (p4 F) ( sat_cons (p295 F) (rfl))
  · decide +kernel
def c1296 : CNF.Clause Nat := [(5,false), (6,false), (7,false), (10,false), (50,true), (51,true), (62,true), (87,true)]
theorem p1296 (F : Frame G 4) : c1296.eval F.assign = true := by
  apply local_rup F.assign c1296 [c4, c296]
  · exact sat_cons (p4 F) ( sat_cons (p296 F) (rfl))
  · decide +kernel
def c1297 : CNF.Clause Nat := [(5,false), (6,false), (7,false), (11,false), (50,true), (51,true), (62,true), (88,true)]
theorem p1297 (F : Frame G 4) : c1297.eval F.assign = true := by
  apply local_rup F.assign c1297 [c4, c297]
  · exact sat_cons (p4 F) ( sat_cons (p297 F) (rfl))
  · decide +kernel
def c1298 : CNF.Clause Nat := [(5,false), (6,false), (9,false), (10,false), (50,true), (86,true), (87,true), (98,true)]
theorem p1298 (F : Frame G 4) : c1298.eval F.assign = true := by
  apply local_rup F.assign c1298 [c4, c300]
  · exact sat_cons (p4 F) ( sat_cons (p300 F) (rfl))
  · decide +kernel
def c1299 : CNF.Clause Nat := [(5,false), (7,false), (9,false), (10,false), (51,true), (86,true), (87,true), (98,true)]
theorem p1299 (F : Frame G 4) : c1299.eval F.assign = true := by
  apply local_rup F.assign c1299 [c4, c301]
  · exact sat_cons (p4 F) ( sat_cons (p301 F) (rfl))
  · decide +kernel
def c1300 : CNF.Clause Nat := [(5,false), (7,false), (9,false), (11,false), (51,true), (86,true), (88,true), (99,true)]
theorem p1300 (F : Frame G 4) : c1300.eval F.assign = true := by
  apply local_rup F.assign c1300 [c4, c302]
  · exact sat_cons (p4 F) ( sat_cons (p302 F) (rfl))
  · decide +kernel
def c1301 : CNF.Clause Nat := [(5,false), (7,false), (10,false), (11,false), (51,true), (87,true), (88,true), (110,true)]
theorem p1301 (F : Frame G 4) : c1301.eval F.assign = true := by
  apply local_rup F.assign c1301 [c4, c303]
  · exact sat_cons (p4 F) ( sat_cons (p303 F) (rfl))
  · decide +kernel
def c1302 : CNF.Clause Nat := [(6,false), (7,false), (9,false), (10,false), (62,true), (86,true), (87,true), (98,true)]
theorem p1302 (F : Frame G 4) : c1302.eval F.assign = true := by
  apply local_rup F.assign c1302 [c4, c304]
  · exact sat_cons (p4 F) ( sat_cons (p304 F) (rfl))
  · decide +kernel
def c1303 : CNF.Clause Nat := [(6,false), (7,false), (10,false), (11,false), (62,true), (87,true), (88,true), (110,true)]
theorem p1303 (F : Frame G 4) : c1303.eval F.assign = true := by
  apply local_rup F.assign c1303 [c4, c305]
  · exact sat_cons (p4 F) ( sat_cons (p305 F) (rfl))
  · decide +kernel
def c1304 : CNF.Clause Nat := [(15,false), (17,false), (19,false), (38,true), (39,true), (50,true), (86,true)]
theorem p1304 (F : Frame G 4) : c1304.eval F.assign = true := by
  apply local_rup F.assign c1304 [c2, c5, c306]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p306 F) (rfl)))
  · decide +kernel
def c1305 : CNF.Clause Nat := [(15,false), (17,false), (22,false), (38,true), (39,true), (50,true), (99,true)]
theorem p1305 (F : Frame G 4) : c1305.eval F.assign = true := by
  apply local_rup F.assign c1305 [c2, c5, c307]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p307 F) (rfl)))
  · decide +kernel
def c1306 : CNF.Clause Nat := [(15,false), (18,false), (19,false), (38,true), (40,true), (51,true), (86,true)]
theorem p1306 (F : Frame G 4) : c1306.eval F.assign = true := by
  apply local_rup F.assign c1306 [c2, c5, c308]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p308 F) (rfl)))
  · decide +kernel
def c1307 : CNF.Clause Nat := [(15,false), (18,false), (21,false), (38,true), (40,true), (51,true), (98,true)]
theorem p1307 (F : Frame G 4) : c1307.eval F.assign = true := by
  apply local_rup F.assign c1307 [c2, c5, c309]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p309 F) (rfl)))
  · decide +kernel
def c1308 : CNF.Clause Nat := [(15,false), (18,false), (22,false), (38,true), (40,true), (51,true), (99,true)]
theorem p1308 (F : Frame G 4) : c1308.eval F.assign = true := by
  apply local_rup F.assign c1308 [c2, c5, c310]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p310 F) (rfl)))
  · decide +kernel
def c1309 : CNF.Clause Nat := [(15,false), (19,false), (21,false), (38,true), (86,true), (87,true), (98,true)]
theorem p1309 (F : Frame G 4) : c1309.eval F.assign = true := by
  apply local_rup F.assign c1309 [c2, c5, c311]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p311 F) (rfl)))
  · decide +kernel
def c1310 : CNF.Clause Nat := [(15,false), (19,false), (22,false), (38,true), (86,true), (88,true), (99,true)]
theorem p1310 (F : Frame G 4) : c1310.eval F.assign = true := by
  apply local_rup F.assign c1310 [c2, c5, c312]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p312 F) (rfl)))
  · decide +kernel
def c1311 : CNF.Clause Nat := [(15,false), (19,false), (21,false), (22,false), (38,true), (87,true), (88,true), (110,true)]
theorem p1311 (F : Frame G 4) : c1311.eval F.assign = true := by
  apply local_rup F.assign c1311 [c2, c313]
  · exact sat_cons (p2 F) ( sat_cons (p313 F) (rfl))
  · decide +kernel
def c1312 : CNF.Clause Nat := [(15,false), (21,false), (22,false), (38,true), (98,true), (99,true), (110,true)]
theorem p1312 (F : Frame G 4) : c1312.eval F.assign = true := by
  apply local_rup F.assign c1312 [c2, c5, c314]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p314 F) (rfl)))
  · decide +kernel
def c1313 : CNF.Clause Nat := [(15,false), (17,false), (18,false), (19,false), (39,true), (40,true), (62,true), (86,true)]
theorem p1313 (F : Frame G 4) : c1313.eval F.assign = true := by
  apply local_rup F.assign c1313 [c5, c315]
  · exact sat_cons (p5 F) ( sat_cons (p315 F) (rfl))
  · decide +kernel
def c1314 : CNF.Clause Nat := [(15,false), (17,false), (18,false), (21,false), (39,true), (40,true), (62,true), (98,true)]
theorem p1314 (F : Frame G 4) : c1314.eval F.assign = true := by
  apply local_rup F.assign c1314 [c5, c318]
  · exact sat_cons (p5 F) ( sat_cons (p318 F) (rfl))
  · decide +kernel
def c1315 : CNF.Clause Nat := [(15,false), (17,false), (18,false), (22,false), (39,true), (40,true), (62,true), (99,true)]
theorem p1315 (F : Frame G 4) : c1315.eval F.assign = true := by
  apply local_rup F.assign c1315 [c5, c319]
  · exact sat_cons (p5 F) ( sat_cons (p319 F) (rfl))
  · decide +kernel
def c1316 : CNF.Clause Nat := [(15,false), (18,false), (19,false), (22,false), (40,true), (86,true), (88,true), (99,true)]
theorem p1316 (F : Frame G 4) : c1316.eval F.assign = true := by
  apply local_rup F.assign c1316 [c5, c320]
  · exact sat_cons (p5 F) ( sat_cons (p320 F) (rfl))
  · decide +kernel
def c1317 : CNF.Clause Nat := [(15,false), (18,false), (21,false), (22,false), (40,true), (98,true), (99,true), (110,true)]
theorem p1317 (F : Frame G 4) : c1317.eval F.assign = true := by
  apply local_rup F.assign c1317 [c5, c321]
  · exact sat_cons (p5 F) ( sat_cons (p321 F) (rfl))
  · decide +kernel
def c1318 : CNF.Clause Nat := [(17,false), (18,false), (19,false), (50,true), (51,true), (62,true), (86,true)]
theorem p1318 (F : Frame G 4) : c1318.eval F.assign = true := by
  apply local_rup F.assign c1318 [c2, c5, c322]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p322 F) (rfl)))
  · decide +kernel
def c1319 : CNF.Clause Nat := [(17,false), (18,false), (19,false), (22,false), (50,true), (51,true), (62,true), (88,true)]
theorem p1319 (F : Frame G 4) : c1319.eval F.assign = true := by
  apply local_rup F.assign c1319 [c2, c323]
  · exact sat_cons (p2 F) ( sat_cons (p323 F) (rfl))
  · decide +kernel
def c1320 : CNF.Clause Nat := [(17,false), (18,false), (21,false), (50,true), (51,true), (62,true), (98,true)]
theorem p1320 (F : Frame G 4) : c1320.eval F.assign = true := by
  apply local_rup F.assign c1320 [c2, c5, c324]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p324 F) (rfl)))
  · decide +kernel
def c1321 : CNF.Clause Nat := [(17,false), (18,false), (22,false), (50,true), (51,true), (62,true), (99,true)]
theorem p1321 (F : Frame G 4) : c1321.eval F.assign = true := by
  apply local_rup F.assign c1321 [c2, c5, c325]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p325 F) (rfl)))
  · decide +kernel
def c1322 : CNF.Clause Nat := [(17,false), (19,false), (21,false), (50,true), (86,true), (87,true), (98,true)]
theorem p1322 (F : Frame G 4) : c1322.eval F.assign = true := by
  apply local_rup F.assign c1322 [c2, c5, c326]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p326 F) (rfl)))
  · decide +kernel
def c1323 : CNF.Clause Nat := [(17,false), (19,false), (22,false), (50,true), (86,true), (88,true), (99,true)]
theorem p1323 (F : Frame G 4) : c1323.eval F.assign = true := by
  apply local_rup F.assign c1323 [c2, c5, c327]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p327 F) (rfl)))
  · decide +kernel
def c1324 : CNF.Clause Nat := [(17,false), (21,false), (22,false), (50,true), (98,true), (99,true), (110,true)]
theorem p1324 (F : Frame G 4) : c1324.eval F.assign = true := by
  apply local_rup F.assign c1324 [c2, c5, c328]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p328 F) (rfl)))
  · decide +kernel
def c1325 : CNF.Clause Nat := [(18,false), (19,false), (21,false), (51,true), (86,true), (87,true), (98,true)]
theorem p1325 (F : Frame G 4) : c1325.eval F.assign = true := by
  apply local_rup F.assign c1325 [c2, c5, c329]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p329 F) (rfl)))
  · decide +kernel
def c1326 : CNF.Clause Nat := [(18,false), (19,false), (22,false), (51,true), (86,true), (88,true), (99,true)]
theorem p1326 (F : Frame G 4) : c1326.eval F.assign = true := by
  apply local_rup F.assign c1326 [c2, c5, c330]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p330 F) (rfl)))
  · decide +kernel
def c1327 : CNF.Clause Nat := [(18,false), (19,false), (21,false), (22,false), (51,true), (87,true), (88,true), (110,true)]
theorem p1327 (F : Frame G 4) : c1327.eval F.assign = true := by
  apply local_rup F.assign c1327 [c2, c331]
  · exact sat_cons (p2 F) ( sat_cons (p331 F) (rfl))
  · decide +kernel
def c1328 : CNF.Clause Nat := [(18,false), (21,false), (22,false), (51,true), (98,true), (99,true), (110,true)]
theorem p1328 (F : Frame G 4) : c1328.eval F.assign = true := by
  apply local_rup F.assign c1328 [c2, c5, c332]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p332 F) (rfl)))
  · decide +kernel
def c1329 : CNF.Clause Nat := [(17,false), (18,false), (19,false), (21,false), (62,true), (86,true), (87,true), (98,true)]
theorem p1329 (F : Frame G 4) : c1329.eval F.assign = true := by
  apply local_rup F.assign c1329 [c5, c333]
  · exact sat_cons (p5 F) ( sat_cons (p333 F) (rfl))
  · decide +kernel
def c1330 : CNF.Clause Nat := [(17,false), (18,false), (21,false), (22,false), (62,true), (98,true), (99,true), (110,true)]
theorem p1330 (F : Frame G 4) : c1330.eval F.assign = true := by
  apply local_rup F.assign c1330 [c5, c335]
  · exact sat_cons (p5 F) ( sat_cons (p335 F) (rfl))
  · decide +kernel
def c1331 : CNF.Clause Nat := [(26,false), (27,false), (30,false), (31,false), (38,true), (39,true), (50,true), (86,true)]
theorem p1331 (F : Frame G 4) : c1331.eval F.assign = true := by
  apply local_rup F.assign c1331 [c3, c336]
  · exact sat_cons (p3 F) ( sat_cons (p336 F) (rfl))
  · decide +kernel
def c1332 : CNF.Clause Nat := [(26,false), (27,false), (30,false), (38,true), (39,true), (50,true), (87,true)]
theorem p1332 (F : Frame G 4) : c1332.eval F.assign = true := by
  apply local_rup F.assign c1332 [c3, c6, c337]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p337 F) (rfl)))
  · decide +kernel
def c1333 : CNF.Clause Nat := [(26,false), (27,false), (31,false), (38,true), (39,true), (50,true), (98,true)]
theorem p1333 (F : Frame G 4) : c1333.eval F.assign = true := by
  apply local_rup F.assign c1333 [c3, c6, c338]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p338 F) (rfl)))
  · decide +kernel
def c1334 : CNF.Clause Nat := [(26,false), (27,false), (31,false), (33,false), (38,true), (39,true), (50,true), (99,true)]
theorem p1334 (F : Frame G 4) : c1334.eval F.assign = true := by
  apply local_rup F.assign c1334 [c3, c339]
  · exact sat_cons (p3 F) ( sat_cons (p339 F) (rfl))
  · decide +kernel
def c1335 : CNF.Clause Nat := [(26,false), (27,false), (29,false), (30,false), (38,true), (40,true), (51,true), (87,true)]
theorem p1335 (F : Frame G 4) : c1335.eval F.assign = true := by
  apply local_rup F.assign c1335 [c6, c340]
  · exact sat_cons (p6 F) ( sat_cons (p340 F) (rfl))
  · decide +kernel
def c1336 : CNF.Clause Nat := [(26,false), (27,false), (29,false), (33,false), (38,true), (40,true), (51,true), (110,true)]
theorem p1336 (F : Frame G 4) : c1336.eval F.assign = true := by
  apply local_rup F.assign c1336 [c6, c342]
  · exact sat_cons (p6 F) ( sat_cons (p342 F) (rfl))
  · decide +kernel
def c1337 : CNF.Clause Nat := [(26,false), (27,false), (30,false), (33,false), (38,true), (87,true), (88,true), (110,true)]
theorem p1337 (F : Frame G 4) : c1337.eval F.assign = true := by
  apply local_rup F.assign c1337 [c6, c344]
  · exact sat_cons (p6 F) ( sat_cons (p344 F) (rfl))
  · decide +kernel
def c1338 : CNF.Clause Nat := [(26,false), (29,false), (30,false), (39,true), (40,true), (62,true), (87,true)]
theorem p1338 (F : Frame G 4) : c1338.eval F.assign = true := by
  apply local_rup F.assign c1338 [c3, c6, c345]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p345 F) (rfl)))
  · decide +kernel
def c1339 : CNF.Clause Nat := [(26,false), (29,false), (30,false), (33,false), (39,true), (40,true), (62,true), (88,true)]
theorem p1339 (F : Frame G 4) : c1339.eval F.assign = true := by
  apply local_rup F.assign c1339 [c3, c346]
  · exact sat_cons (p3 F) ( sat_cons (p346 F) (rfl))
  · decide +kernel
def c1340 : CNF.Clause Nat := [(26,false), (29,false), (31,false), (39,true), (40,true), (62,true), (98,true)]
theorem p1340 (F : Frame G 4) : c1340.eval F.assign = true := by
  apply local_rup F.assign c1340 [c3, c6, c347]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p347 F) (rfl)))
  · decide +kernel
def c1341 : CNF.Clause Nat := [(26,false), (29,false), (33,false), (39,true), (40,true), (62,true), (110,true)]
theorem p1341 (F : Frame G 4) : c1341.eval F.assign = true := by
  apply local_rup F.assign c1341 [c3, c6, c348]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p348 F) (rfl)))
  · decide +kernel
def c1342 : CNF.Clause Nat := [(26,false), (30,false), (31,false), (39,true), (86,true), (87,true), (98,true)]
theorem p1342 (F : Frame G 4) : c1342.eval F.assign = true := by
  apply local_rup F.assign c1342 [c3, c6, c349]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p349 F) (rfl)))
  · decide +kernel
def c1343 : CNF.Clause Nat := [(26,false), (30,false), (31,false), (33,false), (39,true), (86,true), (88,true), (99,true)]
theorem p1343 (F : Frame G 4) : c1343.eval F.assign = true := by
  apply local_rup F.assign c1343 [c3, c350]
  · exact sat_cons (p3 F) ( sat_cons (p350 F) (rfl))
  · decide +kernel
def c1344 : CNF.Clause Nat := [(26,false), (30,false), (33,false), (39,true), (87,true), (88,true), (110,true)]
theorem p1344 (F : Frame G 4) : c1344.eval F.assign = true := by
  apply local_rup F.assign c1344 [c3, c6, c351]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p351 F) (rfl)))
  · decide +kernel
def c1345 : CNF.Clause Nat := [(26,false), (31,false), (33,false), (39,true), (98,true), (99,true), (110,true)]
theorem p1345 (F : Frame G 4) : c1345.eval F.assign = true := by
  apply local_rup F.assign c1345 [c3, c6, c352]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p352 F) (rfl)))
  · decide +kernel
def c1346 : CNF.Clause Nat := [(26,false), (29,false), (30,false), (31,false), (40,true), (86,true), (87,true), (98,true)]
theorem p1346 (F : Frame G 4) : c1346.eval F.assign = true := by
  apply local_rup F.assign c1346 [c6, c353]
  · exact sat_cons (p6 F) ( sat_cons (p353 F) (rfl))
  · decide +kernel
def c1347 : CNF.Clause Nat := [(26,false), (29,false), (31,false), (33,false), (40,true), (98,true), (99,true), (110,true)]
theorem p1347 (F : Frame G 4) : c1347.eval F.assign = true := by
  apply local_rup F.assign c1347 [c6, c354]
  · exact sat_cons (p6 F) ( sat_cons (p354 F) (rfl))
  · decide +kernel
def c1348 : CNF.Clause Nat := [(27,false), (29,false), (30,false), (31,false), (50,true), (51,true), (62,true), (86,true)]
theorem p1348 (F : Frame G 4) : c1348.eval F.assign = true := by
  apply local_rup F.assign c1348 [c3, c355]
  · exact sat_cons (p3 F) ( sat_cons (p355 F) (rfl))
  · decide +kernel
def c1349 : CNF.Clause Nat := [(27,false), (29,false), (30,false), (50,true), (51,true), (62,true), (87,true)]
theorem p1349 (F : Frame G 4) : c1349.eval F.assign = true := by
  apply local_rup F.assign c1349 [c3, c6, c356]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p356 F) (rfl)))
  · decide +kernel
def c1350 : CNF.Clause Nat := [(27,false), (29,false), (30,false), (33,false), (50,true), (51,true), (62,true), (88,true)]
theorem p1350 (F : Frame G 4) : c1350.eval F.assign = true := by
  apply local_rup F.assign c1350 [c3, c357]
  · exact sat_cons (p3 F) ( sat_cons (p357 F) (rfl))
  · decide +kernel
def c1351 : CNF.Clause Nat := [(27,false), (29,false), (31,false), (50,true), (51,true), (62,true), (98,true)]
theorem p1351 (F : Frame G 4) : c1351.eval F.assign = true := by
  apply local_rup F.assign c1351 [c3, c6, c358]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p358 F) (rfl)))
  · decide +kernel
def c1352 : CNF.Clause Nat := [(27,false), (29,false), (31,false), (33,false), (50,true), (51,true), (62,true), (99,true)]
theorem p1352 (F : Frame G 4) : c1352.eval F.assign = true := by
  apply local_rup F.assign c1352 [c3, c359]
  · exact sat_cons (p3 F) ( sat_cons (p359 F) (rfl))
  · decide +kernel
def c1353 : CNF.Clause Nat := [(27,false), (29,false), (33,false), (50,true), (51,true), (62,true), (110,true)]
theorem p1353 (F : Frame G 4) : c1353.eval F.assign = true := by
  apply local_rup F.assign c1353 [c3, c6, c360]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p360 F) (rfl)))
  · decide +kernel
def c1354 : CNF.Clause Nat := [(27,false), (30,false), (31,false), (50,true), (86,true), (87,true), (98,true)]
theorem p1354 (F : Frame G 4) : c1354.eval F.assign = true := by
  apply local_rup F.assign c1354 [c3, c6, c361]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p361 F) (rfl)))
  · decide +kernel
def c1355 : CNF.Clause Nat := [(27,false), (30,false), (31,false), (33,false), (50,true), (86,true), (88,true), (99,true)]
theorem p1355 (F : Frame G 4) : c1355.eval F.assign = true := by
  apply local_rup F.assign c1355 [c3, c362]
  · exact sat_cons (p3 F) ( sat_cons (p362 F) (rfl))
  · decide +kernel
def c1356 : CNF.Clause Nat := [(27,false), (31,false), (33,false), (50,true), (98,true), (99,true), (110,true)]
theorem p1356 (F : Frame G 4) : c1356.eval F.assign = true := by
  apply local_rup F.assign c1356 [c3, c6, c363]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p363 F) (rfl)))
  · decide +kernel
def c1357 : CNF.Clause Nat := [(27,false), (29,false), (30,false), (31,false), (51,true), (86,true), (87,true), (98,true)]
theorem p1357 (F : Frame G 4) : c1357.eval F.assign = true := by
  apply local_rup F.assign c1357 [c6, c364]
  · exact sat_cons (p6 F) ( sat_cons (p364 F) (rfl))
  · decide +kernel
def c1358 : CNF.Clause Nat := [(27,false), (29,false), (30,false), (33,false), (51,true), (87,true), (88,true), (110,true)]
theorem p1358 (F : Frame G 4) : c1358.eval F.assign = true := by
  apply local_rup F.assign c1358 [c6, c366]
  · exact sat_cons (p6 F) ( sat_cons (p366 F) (rfl))
  · decide +kernel
def c1359 : CNF.Clause Nat := [(27,false), (29,false), (31,false), (33,false), (51,true), (98,true), (99,true), (110,true)]
theorem p1359 (F : Frame G 4) : c1359.eval F.assign = true := by
  apply local_rup F.assign c1359 [c6, c367]
  · exact sat_cons (p6 F) ( sat_cons (p367 F) (rfl))
  · decide +kernel
def c1360 : CNF.Clause Nat := [(29,false), (30,false), (31,false), (62,true), (86,true), (87,true), (98,true)]
theorem p1360 (F : Frame G 4) : c1360.eval F.assign = true := by
  apply local_rup F.assign c1360 [c3, c6, c368]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p368 F) (rfl)))
  · decide +kernel
def c1361 : CNF.Clause Nat := [(29,false), (30,false), (31,false), (33,false), (62,true), (86,true), (88,true), (99,true)]
theorem p1361 (F : Frame G 4) : c1361.eval F.assign = true := by
  apply local_rup F.assign c1361 [c3, c369]
  · exact sat_cons (p3 F) ( sat_cons (p369 F) (rfl))
  · decide +kernel
def c1362 : CNF.Clause Nat := [(29,false), (30,false), (33,false), (62,true), (87,true), (88,true), (110,true)]
theorem p1362 (F : Frame G 4) : c1362.eval F.assign = true := by
  apply local_rup F.assign c1362 [c3, c6, c370]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p370 F) (rfl)))
  · decide +kernel
def c1363 : CNF.Clause Nat := [(29,false), (31,false), (33,false), (62,true), (98,true), (99,true), (110,true)]
theorem p1363 (F : Frame G 4) : c1363.eval F.assign = true := by
  apply local_rup F.assign c1363 [c3, c6, c371]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p371 F) (rfl)))
  · decide +kernel
def c1364 : CNF.Clause Nat := [(38,false), (50,false), (62,false), (7,false), (19,false), (31,false), (110,false)]
theorem p1364 (F : Frame G 4) : c1364.eval F.assign = true := by
  apply local_rup F.assign c1364 [c4, c5, c6, c372]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p372 F) (rfl))))
  · decide +kernel
def c1365 : CNF.Clause Nat := [(62,false), (27,false), (15,false), (11,false), (99,false), (86,false), (87,false)]
theorem p1365 (F : Frame G 4) : c1365.eval F.assign = true := by
  apply local_rup F.assign c1365 [c3, c2, c1, c373]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p373 F) (rfl))))
  · decide +kernel
def c1366 : CNF.Clause Nat := [(40,false), (51,false), (86,false), (88,false), (110,false)]
theorem p1366 (F : Frame G 4) : c1366.eval F.assign = true := by
  apply local_rup F.assign c1366 [c1, c2, c5, c6, c3, c374]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p374 F) (rfl))))))
  · decide +kernel
def c1367 : CNF.Clause Nat := [(5,false), (50,false), (62,false), (18,false), (31,false), (30,false), (87,false), (110,false)]
theorem p1367 (F : Frame G 4) : c1367.eval F.assign = true := by
  apply local_rup F.assign c1367 [c1, c5, c375]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p375 F) (rfl)))
  · decide +kernel
def c1368 : CNF.Clause Nat := [(7,false), (38,false), (50,false), (17,false), (31,false), (30,false), (87,false), (110,false)]
theorem p1368 (F : Frame G 4) : c1368.eval F.assign = true := by
  apply local_rup F.assign c1368 [c1, c5, c376]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p376 F) (rfl)))
  · decide +kernel
def c1369 : CNF.Clause Nat := [(51,false), (5,false), (39,false), (17,false), (31,false), (30,false), (87,false), (110,false)]
theorem p1369 (F : Frame G 4) : c1369.eval F.assign = true := by
  apply local_rup F.assign c1369 [c1, c5, c377]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p377 F) (rfl)))
  · decide +kernel
def c1370 : CNF.Clause Nat := [(38,false), (51,false), (62,false), (17,false), (31,false), (30,false), (87,false), (110,false)]
theorem p1370 (F : Frame G 4) : c1370.eval F.assign = true := by
  apply local_rup F.assign c1370 [c1, c5, c378]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p378 F) (rfl)))
  · decide +kernel
def c1371 : CNF.Clause Nat := [(62,false), (6,false), (38,false), (31,false), (30,false), (87,false), (110,false)]
theorem p1371 (F : Frame G 4) : c1371.eval F.assign = true := by
  apply local_rup F.assign c1371 [c1, c2, c5, c379]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p379 F) (rfl))))
  · decide +kernel
def c1372 : CNF.Clause Nat := [(62,false), (7,false), (38,false), (31,false), (30,false), (87,false), (110,false)]
theorem p1372 (F : Frame G 4) : c1372.eval F.assign = true := by
  apply local_rup F.assign c1372 [c1, c2, c5, c380]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p380 F) (rfl))))
  · decide +kernel
def c1373 : CNF.Clause Nat := [(62,false), (39,false), (5,false), (31,false), (30,false), (87,false), (110,false)]
theorem p1373 (F : Frame G 4) : c1373.eval F.assign = true := by
  apply local_rup F.assign c1373 [c1, c2, c5, c381]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p381 F) (rfl))))
  · decide +kernel
def c1374 : CNF.Clause Nat := [(39,false), (62,false), (51,false), (31,false), (30,false), (87,false), (110,false)]
theorem p1374 (F : Frame G 4) : c1374.eval F.assign = true := by
  apply local_rup F.assign c1374 [c1, c2, c5, c382]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p382 F) (rfl))))
  · decide +kernel
def c1375 : CNF.Clause Nat := [(51,false), (5,false), (39,false), (31,false), (19,false), (87,false), (110,false)]
theorem p1375 (F : Frame G 4) : c1375.eval F.assign = true := by
  apply local_rup F.assign c1375 [c1, c3, c5, c383]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p383 F) (rfl))))
  · decide +kernel
def c1376 : CNF.Clause Nat := [(38,false), (50,false), (62,false), (29,false), (31,false), (19,false), (87,false), (110,false)]
theorem p1376 (F : Frame G 4) : c1376.eval F.assign = true := by
  apply local_rup F.assign c1376 [c1, c5, c384]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p384 F) (rfl)))
  · decide +kernel
def c1377 : CNF.Clause Nat := [(62,false), (27,false), (15,false), (9,false), (99,false), (110,false), (87,false)]
theorem p1377 (F : Frame G 4) : c1377.eval F.assign = true := by
  apply local_rup F.assign c1377 [c3, c2, c1, c385]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p385 F) (rfl))))
  · decide +kernel
def c1378 : CNF.Clause Nat := [(38,false), (50,false), (62,false), (18,false), (31,false), (110,false)]
theorem p1378 (F : Frame G 4) : c1378.eval F.assign = true := by
  apply local_rup F.assign c1378 [c4, c1, c5, c6, c386]
  · exact sat_cons (p4 F) ( sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p386 F) (rfl)))))
  · decide +kernel
def c1379 : CNF.Clause Nat := [(51,false), (5,false), (39,false), (17,false), (31,false), (87,false), (88,false)]
theorem p1379 (F : Frame G 4) : c1379.eval F.assign = true := by
  apply local_rup F.assign c1379 [c1, c5, c6, c387]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p387 F) (rfl))))
  · decide +kernel
def c1380 : CNF.Clause Nat := [(38,false), (51,false), (62,false), (17,false), (31,false), (10,false), (88,false)]
theorem p1380 (F : Frame G 4) : c1380.eval F.assign = true := by
  apply local_rup F.assign c1380 [c5, c6, c4, c388]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p388 F) (rfl))))
  · decide +kernel
def c1381 : CNF.Clause Nat := [(38,false), (51,false), (62,false), (6,false), (86,false), (21,false), (33,false)]
theorem p1381 (F : Frame G 4) : c1381.eval F.assign = true := by
  apply local_rup F.assign c1381 [c4, c5, c6, c389]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p389 F) (rfl))))
  · decide +kernel
def c1382 : CNF.Clause Nat := [(62,false), (27,false), (15,false), (11,false), (99,false), (98,false), (87,false)]
theorem p1382 (F : Frame G 4) : c1382.eval F.assign = true := by
  apply local_rup F.assign c1382 [c3, c2, c1, c390]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p390 F) (rfl))))
  · decide +kernel
def c1383 : CNF.Clause Nat := [(7,false), (51,false), (50,false), (17,false), (31,false), (87,false), (88,false)]
theorem p1383 (F : Frame G 4) : c1383.eval F.assign = true := by
  apply local_rup F.assign c1383 [c1, c5, c6, c391]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p391 F) (rfl))))
  · decide +kernel
def c1384 : CNF.Clause Nat := [(38,false), (51,false), (62,false), (17,false), (31,false), (87,false), (88,false)]
theorem p1384 (F : Frame G 4) : c1384.eval F.assign = true := by
  apply local_rup F.assign c1384 [c1, c5, c6, c392]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p392 F) (rfl))))
  · decide +kernel
def c1385 : CNF.Clause Nat := [(38,false), (39,false), (62,false), (29,false), (31,false), (9,false), (87,false), (110,false)]
theorem p1385 (F : Frame G 4) : c1385.eval F.assign = true := by
  apply local_rup F.assign c1385 [c2, c4, c393]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p393 F) (rfl)))
  · decide +kernel
def c1386 : CNF.Clause Nat := [(86,false), (88,false), (110,false), (10,false), (26,false), (27,false), (50,false), (62,false)]
theorem p1386 (F : Frame G 4) : c1386.eval F.assign = true := by
  apply local_rup F.assign c1386 [c5, c1, c394]
  · exact sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p394 F) (rfl)))
  · decide +kernel
def c1387 : CNF.Clause Nat := [(39,false), (62,false), (51,false), (31,false), (87,false), (88,false)]
theorem p1387 (F : Frame G 4) : c1387.eval F.assign = true := by
  apply local_rup F.assign c1387 [c1, c2, c5, c6, c395]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p395 F) (rfl)))))
  · decide +kernel
def c1388 : CNF.Clause Nat := [(7,false), (51,false), (50,false), (17,false), (86,false), (30,false), (110,false)]
theorem p1388 (F : Frame G 4) : c1388.eval F.assign = true := by
  apply local_rup F.assign c1388 [c1, c5, c6, c396]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p396 F) (rfl))))
  · decide +kernel
def c1389 : CNF.Clause Nat := [(62,false), (39,false), (5,false), (86,false), (30,false), (110,false)]
theorem p1389 (F : Frame G 4) : c1389.eval F.assign = true := by
  apply local_rup F.assign c1389 [c1, c2, c5, c6, c397]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p397 F) (rfl)))))
  · decide +kernel
def c1390 : CNF.Clause Nat := [(38,false), (51,false), (62,false), (17,false), (86,false), (30,false), (110,false)]
theorem p1390 (F : Frame G 4) : c1390.eval F.assign = true := by
  apply local_rup F.assign c1390 [c1, c5, c6, c398]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p398 F) (rfl))))
  · decide +kernel
def c1391 : CNF.Clause Nat := [(39,false), (62,false), (51,false), (86,false), (30,false), (110,false)]
theorem p1391 (F : Frame G 4) : c1391.eval F.assign = true := by
  apply local_rup F.assign c1391 [c1, c2, c5, c6, c399]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p399 F) (rfl)))))
  · decide +kernel
def c1392 : CNF.Clause Nat := [(38,false), (50,false), (62,false), (29,false), (21,false), (19,false), (86,false), (99,false)]
theorem p1392 (F : Frame G 4) : c1392.eval F.assign = true := by
  apply local_rup F.assign c1392 [c1, c6, c400]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p400 F) (rfl)))
  · decide +kernel
def c1393 : CNF.Clause Nat := [(86,false), (98,false), (110,false), (22,false), (27,false), (62,false)]
theorem p1393 (F : Frame G 4) : c1393.eval F.assign = true := by
  apply local_rup F.assign c1393 [c1, c4, c2, c3, c401]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p401 F) (rfl)))))
  · decide +kernel
def c1394 : CNF.Clause Nat := [(86,false), (99,false), (110,false), (21,false), (27,false), (62,false)]
theorem p1394 (F : Frame G 4) : c1394.eval F.assign = true := by
  apply local_rup F.assign c1394 [c1, c4, c2, c3, c402]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p402 F) (rfl)))))
  · decide +kernel
def c1395 : CNF.Clause Nat := [(62,false), (27,false), (15,false), (88,false), (110,false), (98,false)]
theorem p1395 (F : Frame G 4) : c1395.eval F.assign = true := by
  apply local_rup F.assign c1395 [c3, c2, c1, c4, c403]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p403 F) (rfl)))))
  · decide +kernel
def c1396 : CNF.Clause Nat := [(5,false), (50,false), (62,false), (18,false), (19,false), (86,false), (98,false), (33,false)]
theorem p1396 (F : Frame G 4) : c1396.eval F.assign = true := by
  apply local_rup F.assign c1396 [c1, c6, c404]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p404 F) (rfl)))
  · decide +kernel
def c1397 : CNF.Clause Nat := [(6,false), (50,false), (51,false), (18,false), (19,false), (86,false), (98,false), (33,false)]
theorem p1397 (F : Frame G 4) : c1397.eval F.assign = true := by
  apply local_rup F.assign c1397 [c1, c6, c405]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p405 F) (rfl)))
  · decide +kernel
def c1398 : CNF.Clause Nat := [(38,false), (50,false), (62,false), (18,false), (19,false), (86,false), (98,false), (33,false)]
theorem p1398 (F : Frame G 4) : c1398.eval F.assign = true := by
  apply local_rup F.assign c1398 [c1, c6, c406]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p406 F) (rfl)))
  · decide +kernel
def c1399 : CNF.Clause Nat := [(38,false), (39,false), (62,false), (7,false), (86,false), (98,false), (33,false)]
theorem p1399 (F : Frame G 4) : c1399.eval F.assign = true := by
  apply local_rup F.assign c1399 [c2, c4, c6, c407]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p407 F) (rfl))))
  · decide +kernel
def c1400 : CNF.Clause Nat := [(51,false), (17,false), (39,false), (86,false), (98,false), (33,false)]
theorem p1400 (F : Frame G 4) : c1400.eval F.assign = true := by
  apply local_rup F.assign c1400 [c2, c1, c4, c6, c408]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p408 F) (rfl)))))
  · decide +kernel
def c1401 : CNF.Clause Nat := [(51,false), (62,false), (39,false), (86,false), (98,false), (33,false)]
theorem p1401 (F : Frame G 4) : c1401.eval F.assign = true := by
  apply local_rup F.assign c1401 [c2, c1, c4, c6, c409]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p409 F) (rfl)))))
  · decide +kernel
def c1402 : CNF.Clause Nat := [(62,false), (17,false), (27,false), (26,false), (87,false), (98,false), (99,false)]
theorem p1402 (F : Frame G 4) : c1402.eval F.assign = true := by
  apply local_rup F.assign c1402 [c2, c1, c4, c410]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p410 F) (rfl))))
  · decide +kernel
def c1403 : CNF.Clause Nat := [(50,false), (5,false), (26,false), (29,false), (18,false), (86,false), (87,false), (110,false)]
theorem p1403 (F : Frame G 4) : c1403.eval F.assign = true := by
  apply local_rup F.assign c1403 [c1, c5, c411]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p411 F) (rfl)))
  · decide +kernel
def c1404 : CNF.Clause Nat := [(18,false), (50,false), (26,false), (9,false), (86,false), (87,false), (110,false)]
theorem p1404 (F : Frame G 4) : c1404.eval F.assign = true := by
  apply local_rup F.assign c1404 [c2, c3, c1, c412]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p412 F) (rfl))))
  · decide +kernel
def c1405 : CNF.Clause Nat := [(39,false), (27,false), (51,false), (18,false), (19,false), (86,false), (98,false), (110,false)]
theorem p1405 (F : Frame G 4) : c1405.eval F.assign = true := by
  apply local_rup F.assign c1405 [c1, c3, c413]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p413 F) (rfl)))
  · decide +kernel
def c1406 : CNF.Clause Nat := [(19,false), (88,false), (99,false), (98,false), (26,false), (5,false), (50,false), (62,false)]
theorem p1406 (F : Frame G 4) : c1406.eval F.assign = true := by
  apply local_rup F.assign c1406 [c6, c1, c414]
  · exact sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p414 F) (rfl)))
  · decide +kernel
def c1407 : CNF.Clause Nat := [(38,false), (26,false), (62,false), (7,false), (86,false), (98,false), (110,false)]
theorem p1407 (F : Frame G 4) : c1407.eval F.assign = true := by
  apply local_rup F.assign c1407 [c2, c3, c4, c415]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p415 F) (rfl))))
  · decide +kernel
def c1408 : CNF.Clause Nat := [(39,false), (27,false), (51,false), (18,false), (86,false), (87,false), (110,false)]
theorem p1408 (F : Frame G 4) : c1408.eval F.assign = true := by
  apply local_rup F.assign c1408 [c1, c3, c5, c416]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p416 F) (rfl))))
  · decide +kernel
def c1409 : CNF.Clause Nat := [(99,false), (88,false), (87,false), (29,false), (62,false), (39,false), (5,false)]
theorem p1409 (F : Frame G 4) : c1409.eval F.assign = true := by
  apply local_rup F.assign c1409 [c5, c6, c1, c417]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p417 F) (rfl))))
  · decide +kernel
def c1410 : CNF.Clause Nat := [(51,false), (62,false), (26,false), (86,false), (98,false), (110,false)]
theorem p1410 (F : Frame G 4) : c1410.eval F.assign = true := by
  apply local_rup F.assign c1410 [c2, c3, c1, c4, c418]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p418 F) (rfl)))))
  · decide +kernel
def c1411 : CNF.Clause Nat := [(38,false), (39,false), (29,false), (7,false), (86,false), (98,false), (110,false)]
theorem p1411 (F : Frame G 4) : c1411.eval F.assign = true := by
  apply local_rup F.assign c1411 [c2, c3, c4, c419]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p419 F) (rfl))))
  · decide +kernel
def c1412 : CNF.Clause Nat := [(38,false), (39,false), (62,false), (29,false), (10,false), (86,false), (99,false)]
theorem p1412 (F : Frame G 4) : c1412.eval F.assign = true := by
  apply local_rup F.assign c1412 [c2, c6, c4, c420]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p420 F) (rfl))))
  · decide +kernel
def c1413 : CNF.Clause Nat := [(38,false), (39,false), (62,false), (29,false), (87,false), (9,false), (99,false)]
theorem p1413 (F : Frame G 4) : c1413.eval F.assign = true := by
  apply local_rup F.assign c1413 [c2, c6, c4, c421]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p421 F) (rfl))))
  · decide +kernel
def c1414 : CNF.Clause Nat := [(86,false), (87,false), (110,false), (11,false), (38,false), (27,false), (62,false)]
theorem p1414 (F : Frame G 4) : c1414.eval F.assign = true := by
  apply local_rup F.assign c1414 [c5, c1, c3, c422]
  · exact sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p422 F) (rfl))))
  · decide +kernel
def c1415 : CNF.Clause Nat := [(38,false), (17,false), (62,false), (29,false), (87,false), (86,false), (99,false)]
theorem p1415 (F : Frame G 4) : c1415.eval F.assign = true := by
  apply local_rup F.assign c1415 [c1, c2, c6, c423]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p423 F) (rfl))))
  · decide +kernel
def c1416 : CNF.Clause Nat := [(39,false), (62,false), (29,false), (27,false), (86,false), (87,false), (110,false)]
theorem p1416 (F : Frame G 4) : c1416.eval F.assign = true := by
  apply local_rup F.assign c1416 [c1, c2, c5, c424]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p424 F) (rfl))))
  · decide +kernel
def c1417 : CNF.Clause Nat := [(38,false), (50,false), (29,false), (18,false), (86,false), (87,false), (110,false)]
theorem p1417 (F : Frame G 4) : c1417.eval F.assign = true := by
  apply local_rup F.assign c1417 [c1, c3, c5, c425]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p425 F) (rfl))))
  · decide +kernel
def c1418 : CNF.Clause Nat := [(38,false), (50,false), (62,false), (29,false), (21,false), (86,false), (88,false)]
theorem p1418 (F : Frame G 4) : c1418.eval F.assign = true := by
  apply local_rup F.assign c1418 [c1, c6, c5, c426]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p426 F) (rfl))))
  · decide +kernel
def c1419 : CNF.Clause Nat := [(38,false), (50,false), (62,false), (29,false), (87,false), (19,false), (99,false)]
theorem p1419 (F : Frame G 4) : c1419.eval F.assign = true := by
  apply local_rup F.assign c1419 [c1, c6, c5, c427]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p427 F) (rfl))))
  · decide +kernel
def c1420 : CNF.Clause Nat := [(15,false), (50,false), (62,false), (29,false), (87,false), (86,false), (99,false)]
theorem p1420 (F : Frame G 4) : c1420.eval F.assign = true := by
  apply local_rup F.assign c1420 [c1, c2, c6, c428]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p428 F) (rfl))))
  · decide +kernel
def c1421 : CNF.Clause Nat := [(38,false), (86,false), (88,false), (110,false), (62,false)]
theorem p1421 (F : Frame G 4) : c1421.eval F.assign = true := by
  apply local_rup F.assign c1421 [c1, c2, c5, c6, c3, c429]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p429 F) (rfl))))))
  · decide +kernel
def c1422 : CNF.Clause Nat := [(39,false), (5,false), (51,false), (18,false), (19,false), (86,false), (98,false), (110,false)]
theorem p1422 (F : Frame G 4) : c1422.eval F.assign = true := by
  apply local_rup F.assign c1422 [c3, c1, c430]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p430 F) (rfl)))
  · decide +kernel
def c1423 : CNF.Clause Nat := [(39,false), (7,false), (51,false), (19,false), (86,false), (98,false), (110,false)]
theorem p1423 (F : Frame G 4) : c1423.eval F.assign = true := by
  apply local_rup F.assign c1423 [c3, c1, c2, c431]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p431 F) (rfl))))
  · decide +kernel
def c1424 : CNF.Clause Nat := [(40,false), (38,false), (50,false), (6,false), (19,false), (21,false), (31,false), (99,false)]
theorem p1424 (F : Frame G 4) : c1424.eval F.assign = true := by
  apply local_rup F.assign c1424 [c4, c6, c432]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p432 F) (rfl)))
  · decide +kernel
def c1425 : CNF.Clause Nat := [(29,false), (26,false), (38,false), (50,false), (17,false), (22,false), (11,false), (86,false), (98,false)]
theorem p1425 (F : Frame G 4) : c1425.eval F.assign = true := by
  apply local_rup F.assign c1425 [c4, c433]
  · exact sat_cons (p4 F) ( sat_cons (p433 F) (rfl))
  · decide +kernel
def c1426 : CNF.Clause Nat := [(50,false), (15,false), (11,false), (99,false), (86,false), (87,false), (29,false)]
theorem p1426 (F : Frame G 4) : c1426.eval F.assign = true := by
  apply local_rup F.assign c1426 [c2, c1, c6, c434]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p434 F) (rfl))))
  · decide +kernel
def c1427 : CNF.Clause Nat := [(18,false), (40,false), (39,false), (10,false), (9,false), (86,false), (88,false)]
theorem p1427 (F : Frame G 4) : c1427.eval F.assign = true := by
  apply local_rup F.assign c1427 [c2, c3, c6, c435]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p435 F) (rfl))))
  · decide +kernel
def c1428 : CNF.Clause Nat := [(17,false), (39,false), (40,false), (29,false), (10,false), (9,false), (86,false), (88,false)]
theorem p1428 (F : Frame G 4) : c1428.eval F.assign = true := by
  apply local_rup F.assign c1428 [c2, c6, c436]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p436 F) (rfl)))
  · decide +kernel
def c1429 : CNF.Clause Nat := [(86,false), (87,false), (39,false), (40,false), (7,false), (11,false)]
theorem p1429 (F : Frame G 4) : c1429.eval F.assign = true := by
  apply local_rup F.assign c1429 [c2, c5, c6, c3, c437]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p437 F) (rfl)))))
  · decide +kernel
def c1430 : CNF.Clause Nat := [(18,false), (40,false), (39,false), (31,false), (86,false), (87,false), (10,false), (11,false)]
theorem p1430 (F : Frame G 4) : c1430.eval F.assign = true := by
  apply local_rup F.assign c1430 [c2, c3, c438]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p438 F) (rfl)))
  · decide +kernel
def c1431 : CNF.Clause Nat := [(9,false), (6,false), (39,false), (40,false), (29,false), (87,false), (88,false)]
theorem p1431 (F : Frame G 4) : c1431.eval F.assign = true := by
  apply local_rup F.assign c1431 [c2, c5, c6, c439]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p439 F) (rfl))))
  · decide +kernel
def c1432 : CNF.Clause Nat := [(39,false), (40,false), (7,false), (5,false), (31,false), (87,false), (88,false)]
theorem p1432 (F : Frame G 4) : c1432.eval F.assign = true := by
  apply local_rup F.assign c1432 [c2, c5, c6, c440]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p440 F) (rfl))))
  · decide +kernel
def c1433 : CNF.Clause Nat := [(50,false), (31,false), (22,false), (88,false), (87,false), (10,false), (40,false)]
theorem p1433 (F : Frame G 4) : c1433.eval F.assign = true := by
  apply local_rup F.assign c1433 [c3, c5, c1, c441]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p441 F) (rfl))))
  · decide +kernel
def c1434 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (18,false), (29,false), (87,false), (86,false), (9,false), (11,false)]
theorem p1434 (F : Frame G 4) : c1434.eval F.assign = true := by
  apply local_rup F.assign c1434 [c6, c442]
  · exact sat_cons (p6 F) ( sat_cons (p442 F) (rfl))
  · decide +kernel
def c1435 : CNF.Clause Nat := [(50,false), (9,false), (40,false), (29,false), (87,false), (88,false)]
theorem p1435 (F : Frame G 4) : c1435.eval F.assign = true := by
  apply local_rup F.assign c1435 [c2, c5, c1, c6, c443]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p443 F) (rfl)))))
  · decide +kernel
def c1436 : CNF.Clause Nat := [(87,false), (88,false), (22,false), (9,false), (6,false), (50,false), (38,false), (40,false)]
theorem p1436 (F : Frame G 4) : c1436.eval F.assign = true := by
  apply local_rup F.assign c1436 [c6, c5, c444]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p444 F) (rfl)))
  · decide +kernel
def c1437 : CNF.Clause Nat := [(50,false), (38,false), (40,false), (18,false), (22,false), (88,false), (86,false), (9,false), (10,false)]
theorem p1437 (F : Frame G 4) : c1437.eval F.assign = true := by
  apply local_rup F.assign c1437 [c3, c445]
  · exact sat_cons (p3 F) ( sat_cons (p445 F) (rfl))
  · decide +kernel
def c1438 : CNF.Clause Nat := [(87,false), (88,false), (11,false), (9,false), (17,false), (50,false), (38,false), (40,false)]
theorem p1438 (F : Frame G 4) : c1438.eval F.assign = true := by
  apply local_rup F.assign c1438 [c6, c5, c446]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p446 F) (rfl)))
  · decide +kernel
def c1439 : CNF.Clause Nat := [(50,false), (38,false), (40,false), (18,false), (21,false), (87,false), (86,false), (9,false), (11,false)]
theorem p1439 (F : Frame G 4) : c1439.eval F.assign = true := by
  apply local_rup F.assign c1439 [c3, c447]
  · exact sat_cons (p3 F) ( sat_cons (p447 F) (rfl))
  · decide +kernel
def c1440 : CNF.Clause Nat := [(31,false), (38,false), (40,false), (7,false), (10,false), (87,false), (88,false)]
theorem p1440 (F : Frame G 4) : c1440.eval F.assign = true := by
  apply local_rup F.assign c1440 [c3, c5, c2, c448]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p448 F) (rfl))))
  · decide +kernel
def c1441 : CNF.Clause Nat := [(38,false), (40,false), (7,false), (6,false), (31,false), (21,false), (87,false), (88,false)]
theorem p1441 (F : Frame G 4) : c1441.eval F.assign = true := by
  apply local_rup F.assign c1441 [c3, c5, c449]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p449 F) (rfl)))
  · decide +kernel
def c1442 : CNF.Clause Nat := [(11,false), (88,false), (86,false), (21,false), (50,false), (38,false), (40,false)]
theorem p1442 (F : Frame G 4) : c1442.eval F.assign = true := by
  apply local_rup F.assign c1442 [c5, c6, c3, c450]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p450 F) (rfl))))
  · decide +kernel
def c1443 : CNF.Clause Nat := [(26,false), (50,false), (51,false), (7,false), (11,false), (22,false), (86,false), (87,false)]
theorem p1443 (F : Frame G 4) : c1443.eval F.assign = true := by
  apply local_rup F.assign c1443 [c3, c5, c451]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p451 F) (rfl)))
  · decide +kernel
def c1444 : CNF.Clause Nat := [(40,false), (29,false), (50,false), (5,false), (11,false), (22,false), (86,false), (87,false)]
theorem p1444 (F : Frame G 4) : c1444.eval F.assign = true := by
  apply local_rup F.assign c1444 [c3, c5, c452]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p452 F) (rfl)))
  · decide +kernel
def c1445 : CNF.Clause Nat := [(26,false), (40,false), (51,false), (5,false), (11,false), (22,false), (86,false), (87,false)]
theorem p1445 (F : Frame G 4) : c1445.eval F.assign = true := by
  apply local_rup F.assign c1445 [c3, c5, c453]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p453 F) (rfl)))
  · decide +kernel
def c1446 : CNF.Clause Nat := [(39,false), (50,false), (51,false), (18,false), (31,false), (87,false), (88,false)]
theorem p1446 (F : Frame G 4) : c1446.eval F.assign = true := by
  apply local_rup F.assign c1446 [c1, c5, c6, c454]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p454 F) (rfl))))
  · decide +kernel
def c1447 : CNF.Clause Nat := [(7,false), (40,false), (39,false), (50,false), (31,false), (87,false), (88,false)]
theorem p1447 (F : Frame G 4) : c1447.eval F.assign = true := by
  apply local_rup F.assign c1447 [c2, c5, c6, c455]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p455 F) (rfl))))
  · decide +kernel
def c1448 : CNF.Clause Nat := [(31,false), (51,false), (40,false), (10,false), (87,false), (88,false)]
theorem p1448 (F : Frame G 4) : c1448.eval F.assign = true := by
  apply local_rup F.assign c1448 [c3, c5, c2, c1, c456]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p456 F) (rfl)))))
  · decide +kernel
def c1449 : CNF.Clause Nat := [(26,false), (50,false), (51,false), (18,false), (21,false), (87,false), (86,false), (9,false), (11,false)]
theorem p1449 (F : Frame G 4) : c1449.eval F.assign = true := by
  apply local_rup F.assign c1449 [c3, c457]
  · exact sat_cons (p3 F) ( sat_cons (p457 F) (rfl))
  · decide +kernel
def c1450 : CNF.Clause Nat := [(40,false), (18,false), (50,false), (10,false), (9,false), (86,false), (88,false)]
theorem p1450 (F : Frame G 4) : c1450.eval F.assign = true := by
  apply local_rup F.assign c1450 [c2, c3, c6, c458]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p458 F) (rfl))))
  · decide +kernel
def c1451 : CNF.Clause Nat := [(51,false), (40,false), (9,false), (22,false), (88,false), (87,false)]
theorem p1451 (F : Frame G 4) : c1451.eval F.assign = true := by
  apply local_rup F.assign c1451 [c1, c5, c6, c3, c459]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p459 F) (rfl)))))
  · decide +kernel
def c1452 : CNF.Clause Nat := [(87,false), (88,false), (11,false), (9,false), (15,false), (39,false), (50,false), (51,false)]
theorem p1452 (F : Frame G 4) : c1452.eval F.assign = true := by
  apply local_rup F.assign c1452 [c6, c5, c460]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p460 F) (rfl)))
  · decide +kernel
def c1453 : CNF.Clause Nat := [(26,false), (50,false), (51,false), (7,false), (9,false), (21,false), (87,false), (88,false)]
theorem p1453 (F : Frame G 4) : c1453.eval F.assign = true := by
  apply local_rup F.assign c1453 [c3, c5, c461]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p461 F) (rfl)))
  · decide +kernel
def c1454 : CNF.Clause Nat := [(6,false), (50,false), (51,false), (29,false), (21,false), (86,false), (88,false)]
theorem p1454 (F : Frame G 4) : c1454.eval F.assign = true := by
  apply local_rup F.assign c1454 [c1, c6, c5, c462]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p462 F) (rfl))))
  · decide +kernel
def c1455 : CNF.Clause Nat := [(87,false), (88,false), (22,false), (9,false), (7,false), (51,false), (38,false), (39,false)]
theorem p1455 (F : Frame G 4) : c1455.eval F.assign = true := by
  apply local_rup F.assign c1455 [c6, c5, c465]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p465 F) (rfl)))
  · decide +kernel
def c1456 : CNF.Clause Nat := [(87,false), (88,false), (11,false), (9,false), (18,false), (51,false), (38,false), (39,false)]
theorem p1456 (F : Frame G 4) : c1456.eval F.assign = true := by
  apply local_rup F.assign c1456 [c6, c5, c466]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p466 F) (rfl)))
  · decide +kernel
def c1457 : CNF.Clause Nat := [(29,false), (51,false), (38,false), (11,false), (22,false), (86,false), (87,false)]
theorem p1457 (F : Frame G 4) : c1457.eval F.assign = true := by
  apply local_rup F.assign c1457 [c3, c1, c5, c467]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p467 F) (rfl))))
  · decide +kernel
def c1458 : CNF.Clause Nat := [(39,false), (29,false), (51,false), (22,false), (88,false), (86,false), (9,false), (10,false)]
theorem p1458 (F : Frame G 4) : c1458.eval F.assign = true := by
  apply local_rup F.assign c1458 [c3, c2, c468]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p468 F) (rfl)))
  · decide +kernel
def c1459 : CNF.Clause Nat := [(39,false), (17,false), (51,false), (29,false), (10,false), (9,false), (86,false), (88,false)]
theorem p1459 (F : Frame G 4) : c1459.eval F.assign = true := by
  apply local_rup F.assign c1459 [c2, c6, c469]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p469 F) (rfl)))
  · decide +kernel
def c1460 : CNF.Clause Nat := [(18,false), (51,false), (50,false), (39,false), (26,false), (10,false), (9,false), (86,false), (88,false)]
theorem p1460 (F : Frame G 4) : c1460.eval F.assign = true := by
  apply local_rup F.assign c1460 [c6, c470]
  · exact sat_cons (p6 F) ( sat_cons (p470 F) (rfl))
  · decide +kernel
def c1461 : CNF.Clause Nat := [(87,false), (88,false), (22,false), (9,false), (39,false), (50,false), (51,false)]
theorem p1461 (F : Frame G 4) : c1461.eval F.assign = true := by
  apply local_rup F.assign c1461 [c6, c5, c1, c471]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p471 F) (rfl))))
  · decide +kernel
def c1462 : CNF.Clause Nat := [(15,false), (86,false), (88,false), (11,false), (10,false), (50,false), (51,false)]
theorem p1462 (F : Frame G 4) : c1462.eval F.assign = true := by
  apply local_rup F.assign c1462 [c5, c6, c3, c472]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p472 F) (rfl))))
  · decide +kernel
def c1463 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (9,false), (7,false), (29,false), (87,false), (88,false)]
theorem p1463 (F : Frame G 4) : c1463.eval F.assign = true := by
  apply local_rup F.assign c1463 [c5, c6, c473]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p473 F) (rfl)))
  · decide +kernel
def c1464 : CNF.Clause Nat := [(26,false), (50,false), (51,false), (18,false), (22,false), (88,false), (86,false), (9,false), (10,false)]
theorem p1464 (F : Frame G 4) : c1464.eval F.assign = true := by
  apply local_rup F.assign c1464 [c3, c474]
  · exact sat_cons (p3 F) ( sat_cons (p474 F) (rfl))
  · decide +kernel
def c1465 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (9,false), (18,false), (29,false), (87,false), (88,false)]
theorem p1465 (F : Frame G 4) : c1465.eval F.assign = true := by
  apply local_rup F.assign c1465 [c5, c6, c475]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p475 F) (rfl)))
  · decide +kernel
def c1466 : CNF.Clause Nat := [(86,false), (87,false), (33,false), (11,false), (6,false), (39,false), (38,false), (51,false)]
theorem p1466 (F : Frame G 4) : c1466.eval F.assign = true := by
  apply local_rup F.assign c1466 [c5, c6, c476]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p476 F) (rfl)))
  · decide +kernel
def c1467 : CNF.Clause Nat := [(39,false), (5,false), (51,false), (18,false), (31,false), (87,false), (88,false)]
theorem p1467 (F : Frame G 4) : c1467.eval F.assign = true := by
  apply local_rup F.assign c1467 [c1, c5, c6, c477]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p477 F) (rfl))))
  · decide +kernel
def c1468 : CNF.Clause Nat := [(6,false), (40,false), (51,false), (27,false), (31,false), (21,false), (87,false), (88,false)]
theorem p1468 (F : Frame G 4) : c1468.eval F.assign = true := by
  apply local_rup F.assign c1468 [c1, c5, c478]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p478 F) (rfl)))
  · decide +kernel
def c1469 : CNF.Clause Nat := [(51,false), (40,false), (11,false), (33,false), (87,false), (86,false), (17,false)]
theorem p1469 (F : Frame G 4) : c1469.eval F.assign = true := by
  apply local_rup F.assign c1469 [c1, c6, c5, c479]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p479 F) (rfl))))
  · decide +kernel
def c1470 : CNF.Clause Nat := [(9,false), (11,false), (88,false), (87,false), (26,false), (39,false), (62,false)]
theorem p1470 (F : Frame G 4) : c1470.eval F.assign = true := by
  apply local_rup F.assign c1470 [c2, c5, c6, c480]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p480 F) (rfl))))
  · decide +kernel
def c1471 : CNF.Clause Nat := [(38,false), (39,false), (62,false), (29,false), (10,false), (9,false), (86,false), (88,false)]
theorem p1471 (F : Frame G 4) : c1471.eval F.assign = true := by
  apply local_rup F.assign c1471 [c2, c6, c481]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p481 F) (rfl)))
  · decide +kernel
def c1472 : CNF.Clause Nat := [(15,false), (51,false), (62,false), (87,false), (86,false), (9,false), (11,false)]
theorem p1472 (F : Frame G 4) : c1472.eval F.assign = true := by
  apply local_rup F.assign c1472 [c2, c3, c6, c482]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p482 F) (rfl))))
  · decide +kernel
def c1473 : CNF.Clause Nat := [(9,false), (40,false), (62,false), (87,false), (88,false)]
theorem p1473 (F : Frame G 4) : c1473.eval F.assign = true := by
  apply local_rup F.assign c1473 [c2, c5, c1, c3, c6, c483]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p483 F) (rfl))))))
  · decide +kernel
def c1474 : CNF.Clause Nat := [(40,false), (51,false), (50,false), (31,false), (21,false), (87,false), (88,false)]
theorem p1474 (F : Frame G 4) : c1474.eval F.assign = true := by
  apply local_rup F.assign c1474 [c1, c3, c5, c484]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p484 F) (rfl))))
  · decide +kernel
def c1475 : CNF.Clause Nat := [(86,false), (87,false), (33,false), (11,false), (39,false), (62,false)]
theorem p1475 (F : Frame G 4) : c1475.eval F.assign = true := by
  apply local_rup F.assign c1475 [c2, c5, c6, c1, c485]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p485 F) (rfl)))))
  · decide +kernel
def c1476 : CNF.Clause Nat := [(5,false), (39,false), (62,false), (29,false), (31,false), (21,false), (87,false), (88,false)]
theorem p1476 (F : Frame G 4) : c1476.eval F.assign = true := by
  apply local_rup F.assign c1476 [c1, c5, c486]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p486 F) (rfl)))
  · decide +kernel
def c1477 : CNF.Clause Nat := [(86,false), (87,false), (29,false), (40,false), (39,false), (6,false), (11,false)]
theorem p1477 (F : Frame G 4) : c1477.eval F.assign = true := by
  apply local_rup F.assign c1477 [c2, c5, c6, c487]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p487 F) (rfl))))
  · decide +kernel
def c1478 : CNF.Clause Nat := [(40,false), (7,false), (10,false), (87,false), (88,false), (33,false), (31,false), (50,false)]
theorem p1478 (F : Frame G 4) : c1478.eval F.assign = true := by
  apply local_rup F.assign c1478 [c5, c2, c488]
  · exact sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p488 F) (rfl)))
  · decide +kernel
def c1479 : CNF.Clause Nat := [(5,false), (40,false), (62,false), (17,false), (31,false), (87,false), (88,false)]
theorem p1479 (F : Frame G 4) : c1479.eval F.assign = true := by
  apply local_rup F.assign c1479 [c1, c5, c6, c489]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p489 F) (rfl))))
  · decide +kernel
def c1480 : CNF.Clause Nat := [(62,false), (51,false), (38,false), (11,false), (22,false), (86,false), (87,false)]
theorem p1480 (F : Frame G 4) : c1480.eval F.assign = true := by
  apply local_rup F.assign c1480 [c3, c1, c5, c490]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p490 F) (rfl))))
  · decide +kernel
def c1481 : CNF.Clause Nat := [(86,false), (88,false), (11,false), (10,false), (26,false), (40,false), (62,false)]
theorem p1481 (F : Frame G 4) : c1481.eval F.assign = true := by
  apply local_rup F.assign c1481 [c2, c5, c6, c491]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p491 F) (rfl))))
  · decide +kernel
def c1482 : CNF.Clause Nat := [(31,false), (62,false), (40,false), (10,false), (87,false), (88,false)]
theorem p1482 (F : Frame G 4) : c1482.eval F.assign = true := by
  apply local_rup F.assign c1482 [c2, c5, c3, c1, c492]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p492 F) (rfl)))))
  · decide +kernel
def c1483 : CNF.Clause Nat := [(11,false), (88,false), (86,false), (31,false), (21,false), (50,false), (62,false)]
theorem p1483 (F : Frame G 4) : c1483.eval F.assign = true := by
  apply local_rup F.assign c1483 [c1, c6, c2, c493]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p493 F) (rfl))))
  · decide +kernel
def c1484 : CNF.Clause Nat := [(15,false), (50,false), (62,false), (7,false), (10,false), (31,false), (86,false), (88,false)]
theorem p1484 (F : Frame G 4) : c1484.eval F.assign = true := by
  apply local_rup F.assign c1484 [c2, c6, c494]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p494 F) (rfl)))
  · decide +kernel
def c1485 : CNF.Clause Nat := [(9,false), (86,false), (88,false), (33,false), (21,false), (51,false), (62,false)]
theorem p1485 (F : Frame G 4) : c1485.eval F.assign = true := by
  apply local_rup F.assign c1485 [c1, c6, c2, c495]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p495 F) (rfl))))
  · decide +kernel
def c1486 : CNF.Clause Nat := [(26,false), (87,false), (88,false), (11,false), (9,false), (50,false), (62,false)]
theorem p1486 (F : Frame G 4) : c1486.eval F.assign = true := by
  apply local_rup F.assign c1486 [c6, c5, c2, c496]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p496 F) (rfl))))
  · decide +kernel
def c1487 : CNF.Clause Nat := [(87,false), (88,false), (11,false), (9,false), (15,false), (38,false), (50,false), (62,false)]
theorem p1487 (F : Frame G 4) : c1487.eval F.assign = true := by
  apply local_rup F.assign c1487 [c6, c5, c497]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p497 F) (rfl)))
  · decide +kernel
def c1488 : CNF.Clause Nat := [(38,false), (15,false), (31,false), (87,false), (88,false), (11,false), (6,false), (62,false)]
theorem p1488 (F : Frame G 4) : c1488.eval F.assign = true := by
  apply local_rup F.assign c1488 [c5, c6, c498]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p498 F) (rfl)))
  · decide +kernel
def c1489 : CNF.Clause Nat := [(86,false), (87,false), (26,false), (39,false), (62,false), (7,false), (11,false)]
theorem p1489 (F : Frame G 4) : c1489.eval F.assign = true := by
  apply local_rup F.assign c1489 [c2, c5, c6, c499]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p499 F) (rfl))))
  · decide +kernel
def c1490 : CNF.Clause Nat := [(38,false), (10,false), (87,false), (88,false), (22,false), (31,false), (62,false)]
theorem p1490 (F : Frame G 4) : c1490.eval F.assign = true := by
  apply local_rup F.assign c1490 [c1, c5, c3, c500]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p3 F) ( sat_cons (p500 F) (rfl))))
  · decide +kernel
def c1491 : CNF.Clause Nat := [(38,false), (18,false), (62,false), (33,false), (88,false), (86,false), (9,false), (10,false)]
theorem p1491 (F : Frame G 4) : c1491.eval F.assign = true := by
  apply local_rup F.assign c1491 [c2, c3, c501]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p501 F) (rfl)))
  · decide +kernel
def c1492 : CNF.Clause Nat := [(38,false), (51,false), (62,false), (17,false), (9,false), (87,false), (33,false)]
theorem p1492 (F : Frame G 4) : c1492.eval F.assign = true := by
  apply local_rup F.assign c1492 [c5, c4, c6, c502]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p502 F) (rfl))))
  · decide +kernel
def c1493 : CNF.Clause Nat := [(86,false), (88,false), (33,false), (10,false), (38,false), (50,false), (62,false)]
theorem p1493 (F : Frame G 4) : c1493.eval F.assign = true := by
  apply local_rup F.assign c1493 [c5, c6, c1, c503]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p503 F) (rfl))))
  · decide +kernel
def c1494 : CNF.Clause Nat := [(86,false), (88,false), (33,false), (10,false), (39,false), (62,false), (51,false)]
theorem p1494 (F : Frame G 4) : c1494.eval F.assign = true := by
  apply local_rup F.assign c1494 [c5, c6, c1, c504]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p504 F) (rfl))))
  · decide +kernel
def c1495 : CNF.Clause Nat := [(26,false), (29,false), (62,false), (50,false), (86,false), (87,false), (10,false), (11,false)]
theorem p1495 (F : Frame G 4) : c1495.eval F.assign = true := by
  apply local_rup F.assign c1495 [c2, c5, c505]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p505 F) (rfl)))
  · decide +kernel
def c1496 : CNF.Clause Nat := [(26,false), (29,false), (62,false), (50,false), (5,false), (88,false), (22,false), (98,false)]
theorem p1496 (F : Frame G 4) : c1496.eval F.assign = true := by
  apply local_rup F.assign c1496 [c4, c5, c506]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p506 F) (rfl)))
  · decide +kernel
def c1497 : CNF.Clause Nat := [(11,false), (88,false), (86,false), (98,false), (21,false), (27,false), (62,false)]
theorem p1497 (F : Frame G 4) : c1497.eval F.assign = true := by
  apply local_rup F.assign c1497 [c1, c2, c3, c507]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p507 F) (rfl))))
  · decide +kernel
def c1498 : CNF.Clause Nat := [(7,false), (62,false), (50,false), (86,false), (87,false), (33,false)]
theorem p1498 (F : Frame G 4) : c1498.eval F.assign = true := by
  apply local_rup F.assign c1498 [c1, c2, c5, c6, c508]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p508 F) (rfl)))))
  · decide +kernel
def c1499 : CNF.Clause Nat := [(39,false), (38,false), (18,false), (7,false), (11,false), (88,false), (86,false), (98,false)]
theorem p1499 (F : Frame G 4) : c1499.eval F.assign = true := by
  apply local_rup F.assign c1499 [c3, c2, c509]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p509 F) (rfl)))
  · decide +kernel
def c1500 : CNF.Clause Nat := [(26,false), (38,false), (50,false), (62,false), (18,false), (98,false), (10,false), (88,false)]
theorem p1500 (F : Frame G 4) : c1500.eval F.assign = true := by
  apply local_rup F.assign c1500 [c5, c4, c510]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p510 F) (rfl)))
  · decide +kernel
end Cert44Steps
end Graffiti199Depleted.Catalogue.OrderEleven
