import Local44Part4
namespace Graffiti199Depleted.Catalogue.OrderEleven
namespace Cert44Steps
open Std.Sat
set_option maxRecDepth 4096
set_option maxHeartbeats 0
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj]
def c1501 : CNF.Clause Nat := [(62,false), (18,false), (15,false), (38,false), (5,false), (9,false), (98,false), (87,false), (88,false)]
theorem p1501 (F : Frame G 4) : c1501.eval F.assign = true := by
  apply local_rup F.assign c1501 [c3, c511]
  · exact sat_cons (p3 F) ( sat_cons (p511 F) (rfl))
  · decide +kernel
def c1502 : CNF.Clause Nat := [(39,false), (38,false), (18,false), (7,false), (9,false), (98,false), (87,false), (88,false)]
theorem p1502 (F : Frame G 4) : c1502.eval F.assign = true := by
  apply local_rup F.assign c1502 [c3, c2, c512]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p512 F) (rfl)))
  · decide +kernel
def c1503 : CNF.Clause Nat := [(26,false), (38,false), (51,false), (62,false), (17,false), (98,false), (10,false), (88,false)]
theorem p1503 (F : Frame G 4) : c1503.eval F.assign = true := by
  apply local_rup F.assign c1503 [c5, c4, c513]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p513 F) (rfl)))
  · decide +kernel
def c1504 : CNF.Clause Nat := [(98,false), (86,false), (88,false), (22,false), (18,false), (51,false), (5,false), (39,false)]
theorem p1504 (F : Frame G 4) : c1504.eval F.assign = true := by
  apply local_rup F.assign c1504 [c6, c1, c514]
  · exact sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p514 F) (rfl)))
  · decide +kernel
def c1505 : CNF.Clause Nat := [(98,false), (86,false), (88,false), (11,false), (39,false), (50,false), (18,false)]
theorem p1505 (F : Frame G 4) : c1505.eval F.assign = true := by
  apply local_rup F.assign c1505 [c6, c1, c2, c515]
  · exact sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p515 F) (rfl))))
  · decide +kernel
def c1506 : CNF.Clause Nat := [(22,false), (88,false), (86,false), (98,false), (26,false), (6,false), (50,false), (51,false)]
theorem p1506 (F : Frame G 4) : c1506.eval F.assign = true := by
  apply local_rup F.assign c1506 [c6, c1, c516]
  · exact sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p516 F) (rfl)))
  · decide +kernel
def c1507 : CNF.Clause Nat := [(98,false), (19,false), (88,false), (11,false), (38,false), (50,false), (62,false)]
theorem p1507 (F : Frame G 4) : c1507.eval F.assign = true := by
  apply local_rup F.assign c1507 [c6, c5, c1, c517]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p517 F) (rfl))))
  · decide +kernel
def c1508 : CNF.Clause Nat := [(98,false), (86,false), (88,false), (22,false), (38,false), (6,false), (62,false)]
theorem p1508 (F : Frame G 4) : c1508.eval F.assign = true := by
  apply local_rup F.assign c1508 [c6, c2, c1, c518]
  · exact sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p518 F) (rfl))))
  · decide +kernel
def c1509 : CNF.Clause Nat := [(98,false), (86,false), (88,false), (11,false), (38,false), (17,false), (62,false)]
theorem p1509 (F : Frame G 4) : c1509.eval F.assign = true := by
  apply local_rup F.assign c1509 [c6, c1, c2, c519]
  · exact sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p519 F) (rfl))))
  · decide +kernel
def c1510 : CNF.Clause Nat := [(39,false), (38,false), (51,false), (7,false), (88,false), (22,false), (98,false)]
theorem p1510 (F : Frame G 4) : c1510.eval F.assign = true := by
  apply local_rup F.assign c1510 [c3, c4, c5, c520]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p520 F) (rfl))))
  · decide +kernel
def c1511 : CNF.Clause Nat := [(98,false), (33,false), (88,false), (38,false), (51,false), (62,false)]
theorem p1511 (F : Frame G 4) : c1511.eval F.assign = true := by
  apply local_rup F.assign c1511 [c5, c6, c4, c1, c521]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1 F) ( sat_cons (p521 F) (rfl)))))
  · decide +kernel
def c1512 : CNF.Clause Nat := [(7,false), (62,false), (50,false), (31,false), (87,false), (88,false)]
theorem p1512 (F : Frame G 4) : c1512.eval F.assign = true := by
  apply local_rup F.assign c1512 [c1, c2, c5, c6, c522]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p522 F) (rfl)))))
  · decide +kernel
def c1513 : CNF.Clause Nat := [(11,false), (88,false), (87,false), (98,false), (27,false), (62,false)]
theorem p1513 (F : Frame G 4) : c1513.eval F.assign = true := by
  apply local_rup F.assign c1513 [c1, c5, c2, c3, c523]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p523 F) (rfl)))))
  · decide +kernel
def c1514 : CNF.Clause Nat := [(39,false), (50,false), (18,false), (29,false), (33,false), (88,false), (86,false), (98,false)]
theorem p1514 (F : Frame G 4) : c1514.eval F.assign = true := by
  apply local_rup F.assign c1514 [c1, c2, c524]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p524 F) (rfl)))
  · decide +kernel
def c1515 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (29,false), (18,false), (98,false), (87,false), (88,false)]
theorem p1515 (F : Frame G 4) : c1515.eval F.assign = true := by
  apply local_rup F.assign c1515 [c1, c5, c525]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p525 F) (rfl)))
  · decide +kernel
def c1516 : CNF.Clause Nat := [(29,false), (62,false), (39,false), (5,false), (21,false), (98,false), (86,false), (88,false)]
theorem p1516 (F : Frame G 4) : c1516.eval F.assign = true := by
  apply local_rup F.assign c1516 [c1, c2, c526]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p526 F) (rfl)))
  · decide +kernel
def c1517 : CNF.Clause Nat := [(98,false), (86,false), (88,false), (22,false), (15,false), (5,false), (50,false), (62,false)]
theorem p1517 (F : Frame G 4) : c1517.eval F.assign = true := by
  apply local_rup F.assign c1517 [c6, c1, c527]
  · exact sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p527 F) (rfl)))
  · decide +kernel
def c1518 : CNF.Clause Nat := [(39,false), (7,false), (51,false), (86,false), (87,false), (110,false)]
theorem p1518 (F : Frame G 4) : c1518.eval F.assign = true := by
  apply local_rup F.assign c1518 [c3, c1, c2, c5, c528]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p528 F) (rfl)))))
  · decide +kernel
def c1519 : CNF.Clause Nat := [(39,false), (5,false), (51,false), (18,false), (86,false), (87,false), (110,false)]
theorem p1519 (F : Frame G 4) : c1519.eval F.assign = true := by
  apply local_rup F.assign c1519 [c3, c1, c5, c529]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p529 F) (rfl))))
  · decide +kernel
def c1520 : CNF.Clause Nat := [(98,false), (86,false), (88,false), (11,false), (15,false), (50,false), (62,false)]
theorem p1520 (F : Frame G 4) : c1520.eval F.assign = true := by
  apply local_rup F.assign c1520 [c6, c1, c2, c530]
  · exact sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p530 F) (rfl))))
  · decide +kernel
def c1521 : CNF.Clause Nat := [(26,false), (62,false), (51,false), (5,false), (88,false), (22,false), (98,false)]
theorem p1521 (F : Frame G 4) : c1521.eval F.assign = true := by
  apply local_rup F.assign c1521 [c3, c4, c5, c531]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p531 F) (rfl))))
  · decide +kernel
def c1522 : CNF.Clause Nat := [(39,false), (50,false), (51,false), (29,false), (30,false), (11,false), (22,false), (98,false)]
theorem p1522 (F : Frame G 4) : c1522.eval F.assign = true := by
  apply local_rup F.assign c1522 [c4, c5, c532]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p532 F) (rfl)))
  · decide +kernel
def c1523 : CNF.Clause Nat := [(39,false), (5,false), (51,false), (18,false), (98,false), (87,false), (88,false)]
theorem p1523 (F : Frame G 4) : c1523.eval F.assign = true := by
  apply local_rup F.assign c1523 [c3, c1, c5, c533]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p533 F) (rfl))))
  · decide +kernel
def c1524 : CNF.Clause Nat := [(39,false), (62,false), (51,false), (9,false), (10,false), (30,false), (88,false)]
theorem p1524 (F : Frame G 4) : c1524.eval F.assign = true := by
  apply local_rup F.assign c1524 [c2, c5, c6, c534]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p534 F) (rfl))))
  · decide +kernel
def c1525 : CNF.Clause Nat := [(9,false), (98,false), (87,false), (88,false), (22,false), (27,false), (62,false)]
theorem p1525 (F : Frame G 4) : c1525.eval F.assign = true := by
  apply local_rup F.assign c1525 [c1, c2, c3, c535]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p535 F) (rfl))))
  · decide +kernel
def c1526 : CNF.Clause Nat := [(39,false), (40,false), (51,false), (98,false), (10,false), (88,false)]
theorem p1526 (F : Frame G 4) : c1526.eval F.assign = true := by
  apply local_rup F.assign c1526 [c3, c2, c5, c4, c536]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p536 F) (rfl)))))
  · decide +kernel
def c1527 : CNF.Clause Nat := [(40,false), (51,false), (50,false), (98,false), (19,false), (88,false)]
theorem p1527 (F : Frame G 4) : c1527.eval F.assign = true := by
  apply local_rup F.assign c1527 [c1, c3, c6, c5, c537]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p537 F) (rfl)))))
  · decide +kernel
def c1528 : CNF.Clause Nat := [(40,false), (51,false), (50,false), (17,false), (98,false), (30,false), (88,false)]
theorem p1528 (F : Frame G 4) : c1528.eval F.assign = true := by
  apply local_rup F.assign c1528 [c1, c5, c6, c538]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p538 F) (rfl))))
  · decide +kernel
def c1529 : CNF.Clause Nat := [(6,false), (50,false), (51,false), (18,false), (98,false), (30,false), (88,false)]
theorem p1529 (F : Frame G 4) : c1529.eval F.assign = true := by
  apply local_rup F.assign c1529 [c1, c5, c6, c539]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p539 F) (rfl))))
  · decide +kernel
def c1530 : CNF.Clause Nat := [(40,false), (51,false), (50,false), (6,false), (30,false), (33,false), (22,false), (98,false)]
theorem p1530 (F : Frame G 4) : c1530.eval F.assign = true := by
  apply local_rup F.assign c1530 [c4, c5, c540]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p540 F) (rfl)))
  · decide +kernel
def c1531 : CNF.Clause Nat := [(21,false), (50,false), (39,false), (40,false), (7,false), (9,false), (86,false), (88,false)]
theorem p1531 (F : Frame G 4) : c1531.eval F.assign = true := by
  apply local_rup F.assign c1531 [c6, c2, c541]
  · exact sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p541 F) (rfl)))
  · decide +kernel
def c1532 : CNF.Clause Nat := [(38,false), (39,false), (62,false), (29,false), (21,false), (9,false), (88,false)]
theorem p1532 (F : Frame G 4) : c1532.eval F.assign = true := by
  apply local_rup F.assign c1532 [c6, c5, c4, c542]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p542 F) (rfl))))
  · decide +kernel
def c1533 : CNF.Clause Nat := [(38,false), (18,false), (62,false), (31,false), (98,false), (87,false), (88,false)]
theorem p1533 (F : Frame G 4) : c1533.eval F.assign = true := by
  apply local_rup F.assign c1533 [c1, c2, c3, c543]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p543 F) (rfl))))
  · decide +kernel
def c1534 : CNF.Clause Nat := [(98,false), (87,false), (88,false), (33,false), (29,false), (7,false), (38,false), (50,false)]
theorem p1534 (F : Frame G 4) : c1534.eval F.assign = true := by
  apply local_rup F.assign c1534 [c5, c1, c544]
  · exact sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p544 F) (rfl)))
  · decide +kernel
def c1535 : CNF.Clause Nat := [(98,false), (10,false), (39,false), (62,false), (29,false), (30,false), (88,false)]
theorem p1535 (F : Frame G 4) : c1535.eval F.assign = true := by
  apply local_rup F.assign c1535 [c2, c5, c1, c545]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p545 F) (rfl))))
  · decide +kernel
def c1536 : CNF.Clause Nat := [(38,false), (98,false), (87,false), (88,false), (33,false), (62,false)]
theorem p1536 (F : Frame G 4) : c1536.eval F.assign = true := by
  apply local_rup F.assign c1536 [c1, c2, c5, c3, c546]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p3 F) ( sat_cons (p546 F) (rfl)))))
  · decide +kernel
def c1537 : CNF.Clause Nat := [(98,false), (86,false), (88,false), (11,false), (5,false), (15,false), (40,false)]
theorem p1537 (F : Frame G 4) : c1537.eval F.assign = true := by
  apply local_rup F.assign c1537 [c3, c6, c2, c547]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p547 F) (rfl))))
  · decide +kernel
def c1538 : CNF.Clause Nat := [(50,false), (18,false), (40,false), (88,false), (33,false), (31,false), (98,false)]
theorem p1538 (F : Frame G 4) : c1538.eval F.assign = true := by
  apply local_rup F.assign c1538 [c2, c1, c4, c548]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p548 F) (rfl))))
  · decide +kernel
def c1539 : CNF.Clause Nat := [(50,false), (38,false), (40,false), (7,false), (10,false), (87,false), (86,false), (22,false)]
theorem p1539 (F : Frame G 4) : c1539.eval F.assign = true := by
  apply local_rup F.assign c1539 [c3, c5, c549]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p549 F) (rfl)))
  · decide +kernel
def c1540 : CNF.Clause Nat := [(17,false), (38,false), (40,false), (7,false), (11,false), (33,false), (87,false), (86,false)]
theorem p1540 (F : Frame G 4) : c1540.eval F.assign = true := by
  apply local_rup F.assign c1540 [c2, c6, c550]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p550 F) (rfl)))
  · decide +kernel
def c1541 : CNF.Clause Nat := [(18,false), (40,false), (38,false), (50,false), (33,false), (11,false), (86,false), (98,false)]
theorem p1541 (F : Frame G 4) : c1541.eval F.assign = true := by
  apply local_rup F.assign c1541 [c3, c4, c551]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p551 F) (rfl)))
  · decide +kernel
def c1542 : CNF.Clause Nat := [(50,false), (38,false), (40,false), (7,false), (87,false), (98,false), (22,false)]
theorem p1542 (F : Frame G 4) : c1542.eval F.assign = true := by
  apply local_rup F.assign c1542 [c3, c4, c5, c552]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p552 F) (rfl))))
  · decide +kernel
def c1543 : CNF.Clause Nat := [(18,false), (40,false), (39,false), (6,false), (86,false), (98,false), (33,false)]
theorem p1543 (F : Frame G 4) : c1543.eval F.assign = true := by
  apply local_rup F.assign c1543 [c2, c4, c6, c553]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p553 F) (rfl))))
  · decide +kernel
def c1544 : CNF.Clause Nat := [(17,false), (39,false), (40,false), (29,false), (31,false), (98,false), (87,false), (11,false)]
theorem p1544 (F : Frame G 4) : c1544.eval F.assign = true := by
  apply local_rup F.assign c1544 [c2, c4, c554]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p554 F) (rfl)))
  · decide +kernel
def c1545 : CNF.Clause Nat := [(17,false), (39,false), (40,false), (29,false), (33,false), (11,false), (86,false), (98,false)]
theorem p1545 (F : Frame G 4) : c1545.eval F.assign = true := by
  apply local_rup F.assign c1545 [c2, c4, c555]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p555 F) (rfl)))
  · decide +kernel
def c1546 : CNF.Clause Nat := [(17,false), (39,false), (40,false), (7,false), (86,false), (98,false), (33,false)]
theorem p1546 (F : Frame G 4) : c1546.eval F.assign = true := by
  apply local_rup F.assign c1546 [c2, c4, c6, c556]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p556 F) (rfl))))
  · decide +kernel
def c1547 : CNF.Clause Nat := [(50,false), (39,false), (40,false), (29,false), (98,false), (9,false), (88,false)]
theorem p1547 (F : Frame G 4) : c1547.eval F.assign = true := by
  apply local_rup F.assign c1547 [c2, c6, c4, c557]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p557 F) (rfl))))
  · decide +kernel
def c1548 : CNF.Clause Nat := [(29,false), (40,false), (38,false), (5,false), (10,false), (87,false), (86,false), (22,false)]
theorem p1548 (F : Frame G 4) : c1548.eval F.assign = true := by
  apply local_rup F.assign c1548 [c3, c5, c558]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p558 F) (rfl)))
  · decide +kernel
def c1549 : CNF.Clause Nat := [(6,false), (38,false), (18,false), (29,false), (33,false), (88,false), (86,false), (98,false)]
theorem p1549 (F : Frame G 4) : c1549.eval F.assign = true := by
  apply local_rup F.assign c1549 [c1, c2, c559]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p559 F) (rfl)))
  · decide +kernel
def c1550 : CNF.Clause Nat := [(40,false), (18,false), (50,false), (33,false), (88,false), (86,false), (98,false)]
theorem p1550 (F : Frame G 4) : c1550.eval F.assign = true := by
  apply local_rup F.assign c1550 [c1, c2, c3, c560]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p560 F) (rfl))))
  · decide +kernel
def c1551 : CNF.Clause Nat := [(29,false), (40,false), (38,false), (5,false), (10,false), (98,false), (19,false), (88,false)]
theorem p1551 (F : Frame G 4) : c1551.eval F.assign = true := by
  apply local_rup F.assign c1551 [c3, c5, c561]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p561 F) (rfl)))
  · decide +kernel
def c1552 : CNF.Clause Nat := [(39,false), (38,false), (98,false), (10,false), (7,false), (29,false), (30,false), (88,false)]
theorem p1552 (F : Frame G 4) : c1552.eval F.assign = true := by
  apply local_rup F.assign c1552 [c2, c5, c562]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p562 F) (rfl)))
  · decide +kernel
def c1553 : CNF.Clause Nat := [(38,false), (40,false), (7,false), (6,false), (98,false), (19,false), (88,false)]
theorem p1553 (F : Frame G 4) : c1553.eval F.assign = true := by
  apply local_rup F.assign c1553 [c3, c6, c5, c563]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p563 F) (rfl))))
  · decide +kernel
def c1554 : CNF.Clause Nat := [(50,false), (38,false), (40,false), (7,false), (30,false), (33,false), (22,false), (98,false)]
theorem p1554 (F : Frame G 4) : c1554.eval F.assign = true := by
  apply local_rup F.assign c1554 [c4, c5, c564]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p564 F) (rfl)))
  · decide +kernel
def c1555 : CNF.Clause Nat := [(22,false), (88,false), (86,false), (98,false), (29,false), (7,false), (38,false), (50,false)]
theorem p1555 (F : Frame G 4) : c1555.eval F.assign = true := by
  apply local_rup F.assign c1555 [c6, c1, c565]
  · exact sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p565 F) (rfl)))
  · decide +kernel
def c1556 : CNF.Clause Nat := [(38,false), (39,false), (62,false), (29,false), (98,false), (86,false), (11,false)]
theorem p1556 (F : Frame G 4) : c1556.eval F.assign = true := by
  apply local_rup F.assign c1556 [c2, c6, c4, c566]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p566 F) (rfl))))
  · decide +kernel
def c1557 : CNF.Clause Nat := [(22,false), (88,false), (86,false), (31,false), (10,false), (38,false), (50,false), (62,false)]
theorem p1557 (F : Frame G 4) : c1557.eval F.assign = true := by
  apply local_rup F.assign c1557 [c6, c1, c567]
  · exact sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p567 F) (rfl)))
  · decide +kernel
def c1558 : CNF.Clause Nat := [(62,false), (51,false), (38,false), (88,false), (22,false), (98,false)]
theorem p1558 (F : Frame G 4) : c1558.eval F.assign = true := by
  apply local_rup F.assign c1558 [c3, c1, c4, c5, c568]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p568 F) (rfl)))))
  · decide +kernel
def c1559 : CNF.Clause Nat := [(88,false), (22,false), (38,false), (39,false), (62,false), (29,false), (31,false), (98,false)]
theorem p1559 (F : Frame G 4) : c1559.eval F.assign = true := by
  apply local_rup F.assign c1559 [c4, c2, c569]
  · exact sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p569 F) (rfl)))
  · decide +kernel
def c1560 : CNF.Clause Nat := [(29,false), (62,false), (39,false), (38,false), (98,false), (10,false), (88,false)]
theorem p1560 (F : Frame G 4) : c1560.eval F.assign = true := by
  apply local_rup F.assign c1560 [c2, c5, c4, c570]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p570 F) (rfl))))
  · decide +kernel
def c1561 : CNF.Clause Nat := [(11,false), (88,false), (87,false), (98,false), (31,false), (17,false), (15,false), (38,false), (51,false)]
theorem p1561 (F : Frame G 4) : c1561.eval F.assign = true := by
  apply local_rup F.assign c1561 [c3, c571]
  · exact sat_cons (p3 F) ( sat_cons (p571 F) (rfl))
  · decide +kernel
def c1562 : CNF.Clause Nat := [(11,false), (88,false), (87,false), (98,false), (31,false), (17,false), (38,false), (40,false)]
theorem p1562 (F : Frame G 4) : c1562.eval F.assign = true := by
  apply local_rup F.assign c1562 [c3, c2, c572]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p572 F) (rfl)))
  · decide +kernel
def c1563 : CNF.Clause Nat := [(88,false), (33,false), (39,false), (38,false), (51,false), (18,false), (98,false)]
theorem p1563 (F : Frame G 4) : c1563.eval F.assign = true := by
  apply local_rup F.assign c1563 [c4, c3, c5, c573]
  · exact sat_cons (p4 F) ( sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p573 F) (rfl))))
  · decide +kernel
def c1564 : CNF.Clause Nat := [(33,false), (88,false), (87,false), (21,false), (9,false), (38,false), (51,false)]
theorem p1564 (F : Frame G 4) : c1564.eval F.assign = true := by
  apply local_rup F.assign c1564 [c3, c5, c1, c574]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p574 F) (rfl))))
  · decide +kernel
def c1565 : CNF.Clause Nat := [(40,false), (62,false), (50,false), (27,false), (98,false), (19,false), (88,false)]
theorem p1565 (F : Frame G 4) : c1565.eval F.assign = true := by
  apply local_rup F.assign c1565 [c1, c6, c5, c575]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p575 F) (rfl))))
  · decide +kernel
def c1566 : CNF.Clause Nat := [(26,false), (40,false), (62,false), (50,false), (5,false), (11,false), (22,false), (86,false), (87,false)]
theorem p1566 (F : Frame G 4) : c1566.eval F.assign = true := by
  apply local_rup F.assign c1566 [c5, c576]
  · exact sat_cons (p5 F) ( sat_cons (p576 F) (rfl))
  · decide +kernel
def c1567 : CNF.Clause Nat := [(40,false), (62,false), (50,false), (21,false), (33,false), (11,false), (86,false)]
theorem p1567 (F : Frame G 4) : c1567.eval F.assign = true := by
  apply local_rup F.assign c1567 [c2, c6, c4, c577]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p577 F) (rfl))))
  · decide +kernel
def c1568 : CNF.Clause Nat := [(26,false), (40,false), (62,false), (50,false), (5,false), (11,false), (88,false), (19,false), (98,false)]
theorem p1568 (F : Frame G 4) : c1568.eval F.assign = true := by
  apply local_rup F.assign c1568 [c5, c578]
  · exact sat_cons (p5 F) ( sat_cons (p578 F) (rfl))
  · decide +kernel
def c1569 : CNF.Clause Nat := [(7,false), (62,false), (50,false), (98,false), (30,false), (88,false)]
theorem p1569 (F : Frame G 4) : c1569.eval F.assign = true := by
  apply local_rup F.assign c1569 [c1, c2, c5, c6, c579]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p579 F) (rfl)))))
  · decide +kernel
def c1570 : CNF.Clause Nat := [(40,false), (62,false), (50,false), (98,false), (30,false), (88,false)]
theorem p1570 (F : Frame G 4) : c1570.eval F.assign = true := by
  apply local_rup F.assign c1570 [c1, c2, c5, c6, c580]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p580 F) (rfl)))))
  · decide +kernel
def c1571 : CNF.Clause Nat := [(7,false), (62,false), (50,false), (27,false), (98,false), (19,false), (88,false)]
theorem p1571 (F : Frame G 4) : c1571.eval F.assign = true := by
  apply local_rup F.assign c1571 [c1, c6, c5, c581]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p581 F) (rfl))))
  · decide +kernel
def c1572 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (9,false), (18,false), (29,false), (87,false), (88,false)]
theorem p1572 (F : Frame G 4) : c1572.eval F.assign = true := by
  apply local_rup F.assign c1572 [c5, c6, c582]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p582 F) (rfl)))
  · decide +kernel
def c1573 : CNF.Clause Nat := [(98,false), (51,false), (40,false), (39,false), (6,false), (88,false)]
theorem p1573 (F : Frame G 4) : c1573.eval F.assign = true := by
  apply local_rup F.assign c1573 [c6, c5, c2, c4, c583]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p583 F) (rfl)))))
  · decide +kernel
def c1574 : CNF.Clause Nat := [(6,false), (62,false), (51,false), (27,false), (98,false), (19,false), (88,false)]
theorem p1574 (F : Frame G 4) : c1574.eval F.assign = true := by
  apply local_rup F.assign c1574 [c1, c6, c5, c584]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p584 F) (rfl))))
  · decide +kernel
def c1575 : CNF.Clause Nat := [(40,false), (51,false), (5,false), (6,false), (31,false), (21,false), (87,false), (88,false)]
theorem p1575 (F : Frame G 4) : c1575.eval F.assign = true := by
  apply local_rup F.assign c1575 [c3, c5, c585]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p585 F) (rfl)))
  · decide +kernel
def c1576 : CNF.Clause Nat := [(6,false), (62,false), (51,false), (98,false), (30,false), (88,false)]
theorem p1576 (F : Frame G 4) : c1576.eval F.assign = true := by
  apply local_rup F.assign c1576 [c1, c2, c5, c6, c586]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p586 F) (rfl)))))
  · decide +kernel
def c1577 : CNF.Clause Nat := [(40,false), (51,false), (5,false), (6,false), (98,false), (19,false), (88,false)]
theorem p1577 (F : Frame G 4) : c1577.eval F.assign = true := by
  apply local_rup F.assign c1577 [c3, c6, c5, c587]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p587 F) (rfl))))
  · decide +kernel
def c1578 : CNF.Clause Nat := [(15,false), (51,false), (7,false), (6,false), (33,false), (88,false), (86,false), (98,false)]
theorem p1578 (F : Frame G 4) : c1578.eval F.assign = true := by
  apply local_rup F.assign c1578 [c2, c3, c588]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p588 F) (rfl)))
  · decide +kernel
def c1579 : CNF.Clause Nat := [(51,false), (40,false), (6,false), (33,false), (88,false), (86,false), (98,false)]
theorem p1579 (F : Frame G 4) : c1579.eval F.assign = true := by
  apply local_rup F.assign c1579 [c2, c1, c3, c589]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p589 F) (rfl))))
  · decide +kernel
def c1580 : CNF.Clause Nat := [(39,false), (29,false), (51,false), (22,false), (88,false), (86,false), (98,false)]
theorem p1580 (F : Frame G 4) : c1580.eval F.assign = true := by
  apply local_rup F.assign c1580 [c1, c3, c2, c590]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p590 F) (rfl))))
  · decide +kernel
def c1581 : CNF.Clause Nat := [(26,false), (98,false), (86,false), (88,false), (22,false), (50,false), (62,false)]
theorem p1581 (F : Frame G 4) : c1581.eval F.assign = true := by
  apply local_rup F.assign c1581 [c1, c6, c2, c591]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p591 F) (rfl))))
  · decide +kernel
def c1582 : CNF.Clause Nat := [(40,false), (51,false), (50,false), (17,false), (86,false), (87,false), (33,false)]
theorem p1582 (F : Frame G 4) : c1582.eval F.assign = true := by
  apply local_rup F.assign c1582 [c1, c5, c6, c592]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p592 F) (rfl))))
  · decide +kernel
def c1583 : CNF.Clause Nat := [(39,false), (40,false), (7,false), (5,false), (98,false), (30,false), (88,false)]
theorem p1583 (F : Frame G 4) : c1583.eval F.assign = true := by
  apply local_rup F.assign c1583 [c2, c5, c6, c593]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p593 F) (rfl))))
  · decide +kernel
def c1584 : CNF.Clause Nat := [(7,false), (40,false), (39,false), (50,false), (27,false), (33,false), (22,false), (86,false), (87,false)]
theorem p1584 (F : Frame G 4) : c1584.eval F.assign = true := by
  apply local_rup F.assign c1584 [c5, c594]
  · exact sat_cons (p5 F) ( sat_cons (p594 F) (rfl))
  · decide +kernel
def c1585 : CNF.Clause Nat := [(39,false), (40,false), (7,false), (5,false), (22,false), (88,false), (86,false), (98,false)]
theorem p1585 (F : Frame G 4) : c1585.eval F.assign = true := by
  apply local_rup F.assign c1585 [c3, c2, c595]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p595 F) (rfl)))
  · decide +kernel
def c1586 : CNF.Clause Nat := [(39,false), (17,false), (51,false), (29,false), (31,false), (98,false), (87,false), (88,false)]
theorem p1586 (F : Frame G 4) : c1586.eval F.assign = true := by
  apply local_rup F.assign c1586 [c1, c2, c596]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p596 F) (rfl)))
  · decide +kernel
def c1587 : CNF.Clause Nat := [(51,false), (40,false), (39,false), (33,false), (11,false), (19,false), (98,false)]
theorem p1587 (F : Frame G 4) : c1587.eval F.assign = true := by
  apply local_rup F.assign c1587 [c3, c4, c5, c597]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p597 F) (rfl))))
  · decide +kernel
def c1588 : CNF.Clause Nat := [(98,false), (87,false), (88,false), (11,false), (39,false), (27,false), (51,false)]
theorem p1588 (F : Frame G 4) : c1588.eval F.assign = true := by
  apply local_rup F.assign c1588 [c5, c1, c3, c598]
  · exact sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p598 F) (rfl))))
  · decide +kernel
def c1589 : CNF.Clause Nat := [(98,false), (87,false), (88,false), (11,false), (26,false), (50,false), (51,false)]
theorem p1589 (F : Frame G 4) : c1589.eval F.assign = true := by
  apply local_rup F.assign c1589 [c5, c1, c3, c599]
  · exact sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p599 F) (rfl))))
  · decide +kernel
def c1590 : CNF.Clause Nat := [(39,false), (29,false), (51,false), (5,false), (10,false), (98,false), (19,false), (88,false)]
theorem p1590 (F : Frame G 4) : c1590.eval F.assign = true := by
  apply local_rup F.assign c1590 [c3, c5, c600]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p600 F) (rfl)))
  · decide +kernel
def c1591 : CNF.Clause Nat := [(39,false), (29,false), (51,false), (5,false), (11,false), (88,false), (19,false), (98,false)]
theorem p1591 (F : Frame G 4) : c1591.eval F.assign = true := by
  apply local_rup F.assign c1591 [c3, c5, c601]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p601 F) (rfl)))
  · decide +kernel
def c1592 : CNF.Clause Nat := [(26,false), (39,false), (50,false), (5,false), (7,false), (18,false), (98,false), (87,false), (88,false)]
theorem p1592 (F : Frame G 4) : c1592.eval F.assign = true := by
  apply local_rup F.assign c1592 [c5, c602]
  · exact sat_cons (p5 F) ( sat_cons (p602 F) (rfl))
  · decide +kernel
def c1593 : CNF.Clause Nat := [(6,false), (50,false), (51,false), (18,false), (22,false), (88,false), (86,false), (31,false)]
theorem p1593 (F : Frame G 4) : c1593.eval F.assign = true := by
  apply local_rup F.assign c1593 [c1, c6, c603]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p603 F) (rfl)))
  · decide +kernel
def c1594 : CNF.Clause Nat := [(51,false), (7,false), (39,false), (98,false), (19,false), (88,false)]
theorem p1594 (F : Frame G 4) : c1594.eval F.assign = true := by
  apply local_rup F.assign c1594 [c1, c3, c6, c5, c604]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p604 F) (rfl)))))
  · decide +kernel
def c1595 : CNF.Clause Nat := [(5,false), (6,false), (39,false), (40,false), (18,false), (98,false), (30,false), (88,false)]
theorem p1595 (F : Frame G 4) : c1595.eval F.assign = true := by
  apply local_rup F.assign c1595 [c5, c6, c605]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p605 F) (rfl)))
  · decide +kernel
def c1596 : CNF.Clause Nat := [(17,false), (39,false), (40,false), (29,false), (98,false), (9,false), (88,false)]
theorem p1596 (F : Frame G 4) : c1596.eval F.assign = true := by
  apply local_rup F.assign c1596 [c2, c6, c4, c606]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p606 F) (rfl))))
  · decide +kernel
def c1597 : CNF.Clause Nat := [(50,false), (51,false), (40,false), (11,false), (22,false), (86,false), (87,false)]
theorem p1597 (F : Frame G 4) : c1597.eval F.assign = true := by
  apply local_rup F.assign c1597 [c3, c1, c5, c609]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p609 F) (rfl))))
  · decide +kernel
def c1598 : CNF.Clause Nat := [(50,false), (5,false), (40,false), (18,false), (98,false), (87,false), (88,false)]
theorem p1598 (F : Frame G 4) : c1598.eval F.assign = true := by
  apply local_rup F.assign c1598 [c3, c1, c5, c610]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p610 F) (rfl))))
  · decide +kernel
def c1599 : CNF.Clause Nat := [(98,false), (87,false), (88,false), (33,false), (39,false), (5,false), (51,false)]
theorem p1599 (F : Frame G 4) : c1599.eval F.assign = true := by
  apply local_rup F.assign c1599 [c5, c3, c1, c611]
  · exact sat_cons (p5 F) ( sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p611 F) (rfl))))
  · decide +kernel
def c1600 : CNF.Clause Nat := [(7,false), (51,false), (50,false), (33,false), (88,false), (19,false), (98,false)]
theorem p1600 (F : Frame G 4) : c1600.eval F.assign = true := by
  apply local_rup F.assign c1600 [c1, c3, c5, c612]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p612 F) (rfl))))
  · decide +kernel
def c1601 : CNF.Clause Nat := [(7,false), (51,false), (50,false), (17,false), (98,false), (30,false), (88,false)]
theorem p1601 (F : Frame G 4) : c1601.eval F.assign = true := by
  apply local_rup F.assign c1601 [c1, c5, c6, c613]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p613 F) (rfl))))
  · decide +kernel
def c1602 : CNF.Clause Nat := [(11,false), (88,false), (86,false), (98,false), (17,false), (51,false)]
theorem p1602 (F : Frame G 4) : c1602.eval F.assign = true := by
  apply local_rup F.assign c1602 [c1, c6, c3, c2, c614]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p614 F) (rfl)))))
  · decide +kernel
def c1603 : CNF.Clause Nat := [(15,false), (17,false), (50,false), (51,false), (29,false), (33,false), (88,false), (9,false), (98,false)]
theorem p1603 (F : Frame G 4) : c1603.eval F.assign = true := by
  apply local_rup F.assign c1603 [c4, c615]
  · exact sat_cons (p4 F) ( sat_cons (p615 F) (rfl))
  · decide +kernel
def c1604 : CNF.Clause Nat := [(15,false), (40,false), (51,false), (50,false), (6,false), (9,false), (98,false), (30,false), (88,false)]
theorem p1604 (F : Frame G 4) : c1604.eval F.assign = true := by
  apply local_rup F.assign c1604 [c6, c616]
  · exact sat_cons (p6 F) ( sat_cons (p616 F) (rfl))
  · decide +kernel
def c1605 : CNF.Clause Nat := [(50,false), (39,false), (40,false), (29,false), (31,false), (98,false), (87,false), (11,false)]
theorem p1605 (F : Frame G 4) : c1605.eval F.assign = true := by
  apply local_rup F.assign c1605 [c2, c4, c617]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p617 F) (rfl)))
  · decide +kernel
def c1606 : CNF.Clause Nat := [(7,false), (51,false), (50,false), (17,false), (86,false), (87,false), (33,false)]
theorem p1606 (F : Frame G 4) : c1606.eval F.assign = true := by
  apply local_rup F.assign c1606 [c1, c5, c6, c618]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p618 F) (rfl))))
  · decide +kernel
def c1607 : CNF.Clause Nat := [(51,false), (7,false), (39,false), (98,false), (86,false), (88,false)]
theorem p1607 (F : Frame G 4) : c1607.eval F.assign = true := by
  apply local_rup F.assign c1607 [c2, c1, c3, c6, c619]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p619 F) (rfl)))))
  · decide +kernel
def c1608 : CNF.Clause Nat := [(50,false), (26,false), (40,false), (7,false), (88,false), (22,false), (98,false)]
theorem p1608 (F : Frame G 4) : c1608.eval F.assign = true := by
  apply local_rup F.assign c1608 [c3, c4, c5, c620]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p620 F) (rfl))))
  · decide +kernel
def c1609 : CNF.Clause Nat := [(27,false), (39,false), (40,false), (7,false), (88,false), (22,false), (98,false)]
theorem p1609 (F : Frame G 4) : c1609.eval F.assign = true := by
  apply local_rup F.assign c1609 [c3, c4, c5, c621]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p621 F) (rfl))))
  · decide +kernel
def c1610 : CNF.Clause Nat := [(50,false), (38,false), (7,false), (18,false), (22,false), (88,false), (86,false), (98,false)]
theorem p1610 (F : Frame G 4) : c1610.eval F.assign = true := by
  apply local_rup F.assign c1610 [c3, c1, c622]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p622 F) (rfl)))
  · decide +kernel
def c1611 : CNF.Clause Nat := [(50,false), (18,false), (40,false), (26,false), (98,false), (86,false), (11,false)]
theorem p1611 (F : Frame G 4) : c1611.eval F.assign = true := by
  apply local_rup F.assign c1611 [c2, c6, c4, c623]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p623 F) (rfl))))
  · decide +kernel
def c1612 : CNF.Clause Nat := [(38,false), (40,false), (18,false), (17,false), (98,false), (86,false), (11,false)]
theorem p1612 (F : Frame G 4) : c1612.eval F.assign = true := by
  apply local_rup F.assign c1612 [c3, c6, c4, c624]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p624 F) (rfl))))
  · decide +kernel
def c1613 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (87,false), (98,false), (18,false), (29,false), (33,false)]
theorem p1613 (F : Frame G 4) : c1613.eval F.assign = true := by
  apply local_rup F.assign c1613 [c4, c5, c625]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p625 F) (rfl)))
  · decide +kernel
def c1614 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (7,false), (29,false), (30,false), (88,false), (22,false), (98,false)]
theorem p1614 (F : Frame G 4) : c1614.eval F.assign = true := by
  apply local_rup F.assign c1614 [c5, c626]
  · exact sat_cons (p5 F) ( sat_cons (p626 F) (rfl))
  · decide +kernel
def c1615 : CNF.Clause Nat := [(39,false), (40,false), (18,false), (5,false), (11,false), (88,false), (86,false), (98,false)]
theorem p1615 (F : Frame G 4) : c1615.eval F.assign = true := by
  apply local_rup F.assign c1615 [c3, c2, c627]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p627 F) (rfl)))
  · decide +kernel
def c1616 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (21,false), (29,false), (7,false), (86,false), (99,false)]
theorem p1616 (F : Frame G 4) : c1616.eval F.assign = true := by
  apply local_rup F.assign c1616 [c6, c4, c628]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p628 F) (rfl)))
  · decide +kernel
def c1617 : CNF.Clause Nat := [(27,false), (39,false), (40,false), (18,false), (21,false), (98,false), (86,false), (11,false)]
theorem p1617 (F : Frame G 4) : c1617.eval F.assign = true := by
  apply local_rup F.assign c1617 [c3, c4, c629]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p629 F) (rfl)))
  · decide +kernel
def c1618 : CNF.Clause Nat := [(39,false), (27,false), (51,false), (18,false), (22,false), (88,false), (86,false), (98,false)]
theorem p1618 (F : Frame G 4) : c1618.eval F.assign = true := by
  apply local_rup F.assign c1618 [c1, c3, c630]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p630 F) (rfl)))
  · decide +kernel
def c1619 : CNF.Clause Nat := [(87,false), (98,false), (99,false), (22,false), (27,false), (39,false), (40,false)]
theorem p1619 (F : Frame G 4) : c1619.eval F.assign = true := by
  apply local_rup F.assign c1619 [c4, c2, c3, c631]
  · exact sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p631 F) (rfl))))
  · decide +kernel
def c1620 : CNF.Clause Nat := [(29,false), (51,false), (38,false), (15,false), (19,false), (10,false), (98,false), (99,false)]
theorem p1620 (F : Frame G 4) : c1620.eval F.assign = true := by
  apply local_rup F.assign c1620 [c3, c4, c632]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p632 F) (rfl)))
  · decide +kernel
def c1621 : CNF.Clause Nat := [(39,false), (10,false), (27,false), (51,false), (18,false), (19,false), (86,false), (99,false)]
theorem p1621 (F : Frame G 4) : c1621.eval F.assign = true := by
  apply local_rup F.assign c1621 [c1, c6, c633]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p633 F) (rfl)))
  · decide +kernel
def c1622 : CNF.Clause Nat := [(39,false), (10,false), (27,false), (51,false), (18,false), (86,false), (88,false)]
theorem p1622 (F : Frame G 4) : c1622.eval F.assign = true := by
  apply local_rup F.assign c1622 [c1, c6, c5, c634]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p634 F) (rfl))))
  · decide +kernel
def c1623 : CNF.Clause Nat := [(18,false), (51,false), (38,false), (39,false), (10,false), (86,false), (99,false)]
theorem p1623 (F : Frame G 4) : c1623.eval F.assign = true := by
  apply local_rup F.assign c1623 [c3, c6, c4, c635]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p635 F) (rfl))))
  · decide +kernel
def c1624 : CNF.Clause Nat := [(98,false), (99,false), (88,false), (19,false), (18,false), (51,false), (5,false), (39,false)]
theorem p1624 (F : Frame G 4) : c1624.eval F.assign = true := by
  apply local_rup F.assign c1624 [c6, c1, c636]
  · exact sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p636 F) (rfl)))
  · decide +kernel
def c1625 : CNF.Clause Nat := [(39,false), (11,false), (88,false), (86,false), (98,false), (21,false), (51,false)]
theorem p1625 (F : Frame G 4) : c1625.eval F.assign = true := by
  apply local_rup F.assign c1625 [c3, c1, c2, c637]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p637 F) (rfl))))
  · decide +kernel
def c1626 : CNF.Clause Nat := [(88,false), (99,false), (98,false), (17,false), (15,false), (38,false), (51,false)]
theorem p1626 (F : Frame G 4) : c1626.eval F.assign = true := by
  apply local_rup F.assign c1626 [c4, c6, c3, c638]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p638 F) (rfl))))
  · decide +kernel
def c1627 : CNF.Clause Nat := [(88,false), (99,false), (98,false), (17,false), (38,false), (40,false)]
theorem p1627 (F : Frame G 4) : c1627.eval F.assign = true := by
  apply local_rup F.assign c1627 [c4, c6, c3, c2, c639]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p639 F) (rfl)))))
  · decide +kernel
def c1628 : CNF.Clause Nat := [(39,false), (40,false), (51,false), (5,false), (30,false), (21,false), (99,false)]
theorem p1628 (F : Frame G 4) : c1628.eval F.assign = true := by
  apply local_rup F.assign c1628 [c4, c6, c5, c640]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p640 F) (rfl))))
  · decide +kernel
def c1629 : CNF.Clause Nat := [(39,false), (50,false), (51,false), (18,false), (98,false), (30,false), (88,false)]
theorem p1629 (F : Frame G 4) : c1629.eval F.assign = true := by
  apply local_rup F.assign c1629 [c1, c5, c6, c641]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p641 F) (rfl))))
  · decide +kernel
def c1630 : CNF.Clause Nat := [(88,false), (99,false), (98,false), (39,false), (15,false), (51,false)]
theorem p1630 (F : Frame G 4) : c1630.eval F.assign = true := by
  apply local_rup F.assign c1630 [c4, c6, c3, c2, c642]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p642 F) (rfl)))))
  · decide +kernel
def c1631 : CNF.Clause Nat := [(98,false), (87,false), (88,false), (33,false), (6,false), (40,false)]
theorem p1631 (F : Frame G 4) : c1631.eval F.assign = true := by
  apply local_rup F.assign c1631 [c2, c5, c3, c1, c643]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p643 F) (rfl)))))
  · decide +kernel
def c1632 : CNF.Clause Nat := [(40,false), (18,false), (27,false), (6,false), (10,false), (98,false), (86,false), (88,false)]
theorem p1632 (F : Frame G 4) : c1632.eval F.assign = true := by
  apply local_rup F.assign c1632 [c2, c3, c644]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p644 F) (rfl)))
  · decide +kernel
def c1633 : CNF.Clause Nat := [(50,false), (39,false), (40,false), (29,false), (10,false), (86,false), (99,false)]
theorem p1633 (F : Frame G 4) : c1633.eval F.assign = true := by
  apply local_rup F.assign c1633 [c2, c6, c4, c645]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p645 F) (rfl))))
  · decide +kernel
def c1634 : CNF.Clause Nat := [(21,false), (98,false), (86,false), (88,false), (33,false), (6,false), (40,false)]
theorem p1634 (F : Frame G 4) : c1634.eval F.assign = true := by
  apply local_rup F.assign c1634 [c2, c3, c1, c646]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p646 F) (rfl))))
  · decide +kernel
def c1635 : CNF.Clause Nat := [(29,false), (7,false), (38,false), (21,false), (98,false), (86,false), (88,false)]
theorem p1635 (F : Frame G 4) : c1635.eval F.assign = true := by
  apply local_rup F.assign c1635 [c3, c1, c2, c647]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p647 F) (rfl))))
  · decide +kernel
def c1636 : CNF.Clause Nat := [(50,false), (39,false), (7,false), (29,false), (87,false), (86,false), (99,false)]
theorem p1636 (F : Frame G 4) : c1636.eval F.assign = true := by
  apply local_rup F.assign c1636 [c2, c1, c6, c648]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p648 F) (rfl))))
  · decide +kernel
def c1637 : CNF.Clause Nat := [(50,false), (29,false), (40,false), (11,false), (88,false), (86,false), (98,false)]
theorem p1637 (F : Frame G 4) : c1637.eval F.assign = true := by
  apply local_rup F.assign c1637 [c2, c3, c1, c649]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p649 F) (rfl))))
  · decide +kernel
def c1638 : CNF.Clause Nat := [(17,false), (99,false), (11,false), (38,false), (51,false), (29,false), (30,false), (87,false)]
theorem p1638 (F : Frame G 4) : c1638.eval F.assign = true := by
  apply local_rup F.assign c1638 [c5, c1, c650]
  · exact sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p650 F) (rfl)))
  · decide +kernel
def c1639 : CNF.Clause Nat := [(17,false), (99,false), (88,false), (87,false), (10,false), (26,false), (27,false), (51,false)]
theorem p1639 (F : Frame G 4) : c1639.eval F.assign = true := by
  apply local_rup F.assign c1639 [c5, c1, c651]
  · exact sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p651 F) (rfl)))
  · decide +kernel
def c1640 : CNF.Clause Nat := [(17,false), (15,false), (38,false), (51,false), (29,false), (10,false), (86,false), (99,false)]
theorem p1640 (F : Frame G 4) : c1640.eval F.assign = true := by
  apply local_rup F.assign c1640 [c6, c4, c652]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p652 F) (rfl)))
  · decide +kernel
def c1641 : CNF.Clause Nat := [(17,false), (39,false), (40,false), (7,false), (87,false), (31,false), (99,false)]
theorem p1641 (F : Frame G 4) : c1641.eval F.assign = true := by
  apply local_rup F.assign c1641 [c2, c4, c6, c653]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p653 F) (rfl))))
  · decide +kernel
def c1642 : CNF.Clause Nat := [(39,false), (40,false), (51,false), (27,false), (21,false), (19,false), (9,false), (99,false)]
theorem p1642 (F : Frame G 4) : c1642.eval F.assign = true := by
  apply local_rup F.assign c1642 [c6, c4, c654]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p654 F) (rfl)))
  · decide +kernel
def c1643 : CNF.Clause Nat := [(99,false), (88,false), (87,false), (27,false), (51,false), (7,false), (39,false)]
theorem p1643 (F : Frame G 4) : c1643.eval F.assign = true := by
  apply local_rup F.assign c1643 [c5, c6, c1, c655]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p655 F) (rfl))))
  · decide +kernel
def c1644 : CNF.Clause Nat := [(51,false), (40,false), (39,false), (10,false), (86,false), (99,false)]
theorem p1644 (F : Frame G 4) : c1644.eval F.assign = true := by
  apply local_rup F.assign c1644 [c2, c3, c6, c4, c656]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p656 F) (rfl)))))
  · decide +kernel
def c1645 : CNF.Clause Nat := [(99,false), (88,false), (87,false), (6,false), (38,false), (51,false)]
theorem p1645 (F : Frame G 4) : c1645.eval F.assign = true := by
  apply local_rup F.assign c1645 [c5, c6, c3, c1, c657]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p657 F) (rfl)))))
  · decide +kernel
def c1646 : CNF.Clause Nat := [(17,false), (87,false), (88,false), (99,false), (9,false), (38,false), (51,false)]
theorem p1646 (F : Frame G 4) : c1646.eval F.assign = true := by
  apply local_rup F.assign c1646 [c3, c6, c1, c658]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p658 F) (rfl))))
  · decide +kernel
def c1647 : CNF.Clause Nat := [(17,false), (39,false), (40,false), (7,false), (9,false), (86,false), (87,false), (33,false)]
theorem p1647 (F : Frame G 4) : c1647.eval F.assign = true := by
  apply local_rup F.assign c1647 [c2, c6, c659]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p659 F) (rfl)))
  · decide +kernel
def c1648 : CNF.Clause Nat := [(50,false), (6,false), (40,false), (29,false), (30,false), (87,false), (98,false), (99,false)]
theorem p1648 (F : Frame G 4) : c1648.eval F.assign = true := by
  apply local_rup F.assign c1648 [c2, c1, c661]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p661 F) (rfl)))
  · decide +kernel
def c1649 : CNF.Clause Nat := [(6,false), (88,false), (99,false), (98,false), (27,false), (15,false), (40,false)]
theorem p1649 (F : Frame G 4) : c1649.eval F.assign = true := by
  apply local_rup F.assign c1649 [c4, c6, c2, c662]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p662 F) (rfl))))
  · decide +kernel
def c1650 : CNF.Clause Nat := [(6,false), (50,false), (38,false), (40,false), (29,false), (87,false), (19,false), (99,false)]
theorem p1650 (F : Frame G 4) : c1650.eval F.assign = true := by
  apply local_rup F.assign c1650 [c6, c5, c663]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p663 F) (rfl)))
  · decide +kernel
def c1651 : CNF.Clause Nat := [(40,false), (29,false), (50,false), (22,false), (88,false), (86,false), (98,false)]
theorem p1651 (F : Frame G 4) : c1651.eval F.assign = true := by
  apply local_rup F.assign c1651 [c1, c3, c2, c664]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p664 F) (rfl))))
  · decide +kernel
def c1652 : CNF.Clause Nat := [(38,false), (40,false), (62,false), (10,false), (86,false), (99,false)]
theorem p1652 (F : Frame G 4) : c1652.eval F.assign = true := by
  apply local_rup F.assign c1652 [c2, c3, c6, c4, c665]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p665 F) (rfl)))))
  · decide +kernel
def c1653 : CNF.Clause Nat := [(38,false), (6,false), (62,false), (29,false), (21,false), (19,false), (86,false), (99,false)]
theorem p1653 (F : Frame G 4) : c1653.eval F.assign = true := by
  apply local_rup F.assign c1653 [c1, c6, c666]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p666 F) (rfl)))
  · decide +kernel
def c1654 : CNF.Clause Nat := [(5,false), (40,false), (62,false), (33,false), (22,false), (19,false), (86,false), (98,false)]
theorem p1654 (F : Frame G 4) : c1654.eval F.assign = true := by
  apply local_rup F.assign c1654 [c1, c3, c667]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p667 F) (rfl)))
  · decide +kernel
def c1655 : CNF.Clause Nat := [(38,false), (40,false), (62,false), (6,false), (86,false), (98,false), (33,false)]
theorem p1655 (F : Frame G 4) : c1655.eval F.assign = true := by
  apply local_rup F.assign c1655 [c2, c4, c6, c668]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p668 F) (rfl))))
  · decide +kernel
def c1656 : CNF.Clause Nat := [(38,false), (7,false), (62,false), (17,false), (22,false), (99,false), (86,false), (30,false)]
theorem p1656 (F : Frame G 4) : c1656.eval F.assign = true := by
  apply local_rup F.assign c1656 [c1, c6, c669]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p669 F) (rfl)))
  · decide +kernel
def c1657 : CNF.Clause Nat := [(86,false), (98,false), (33,false), (22,false), (17,false), (62,false), (40,false), (38,false)]
theorem p1657 (F : Frame G 4) : c1657.eval F.assign = true := by
  apply local_rup F.assign c1657 [c4, c6, c670]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p670 F) (rfl)))
  · decide +kernel
def c1658 : CNF.Clause Nat := [(5,false), (51,false), (62,false), (17,false), (22,false), (99,false), (86,false), (30,false)]
theorem p1658 (F : Frame G 4) : c1658.eval F.assign = true := by
  apply local_rup F.assign c1658 [c1, c6, c671]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p671 F) (rfl)))
  · decide +kernel
def c1659 : CNF.Clause Nat := [(86,false), (99,false), (22,false), (21,false), (62,false), (40,false), (38,false)]
theorem p1659 (F : Frame G 4) : c1659.eval F.assign = true := by
  apply local_rup F.assign c1659 [c4, c6, c3, c672]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p672 F) (rfl))))
  · decide +kernel
def c1660 : CNF.Clause Nat := [(38,false), (5,false), (19,false), (22,false), (99,false), (98,false), (62,false)]
theorem p1660 (F : Frame G 4) : c1660.eval F.assign = true := by
  apply local_rup F.assign c1660 [c4, c6, c3, c673]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p673 F) (rfl))))
  · decide +kernel
def c1661 : CNF.Clause Nat := [(86,false), (98,false), (27,false), (51,false), (62,false), (17,false), (22,false)]
theorem p1661 (F : Frame G 4) : c1661.eval F.assign = true := by
  apply local_rup F.assign c1661 [c1, c4, c6, c674]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p674 F) (rfl))))
  · decide +kernel
def c1662 : CNF.Clause Nat := [(38,false), (40,false), (62,false), (10,false), (19,false), (99,false)]
theorem p1662 (F : Frame G 4) : c1662.eval F.assign = true := by
  apply local_rup F.assign c1662 [c3, c6, c4, c5, c675]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p675 F) (rfl)))))
  · decide +kernel
def c1663 : CNF.Clause Nat := [(50,false), (38,false), (40,false), (18,false), (98,false), (87,false), (11,false)]
theorem p1663 (F : Frame G 4) : c1663.eval F.assign = true := by
  apply local_rup F.assign c1663 [c3, c5, c4, c676]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p676 F) (rfl))))
  · decide +kernel
def c1664 : CNF.Clause Nat := [(98,false), (27,false), (38,false), (40,false), (62,false), (6,false), (88,false)]
theorem p1664 (F : Frame G 4) : c1664.eval F.assign = true := by
  apply local_rup F.assign c1664 [c5, c6, c4, c677]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p677 F) (rfl))))
  · decide +kernel
def c1665 : CNF.Clause Nat := [(38,false), (40,false), (62,false), (6,false), (30,false), (98,false), (99,false)]
theorem p1665 (F : Frame G 4) : c1665.eval F.assign = true := by
  apply local_rup F.assign c1665 [c2, c4, c6, c678]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p678 F) (rfl))))
  · decide +kernel
def c1666 : CNF.Clause Nat := [(62,false), (40,false), (38,false), (5,false), (87,false), (21,false), (99,false)]
theorem p1666 (F : Frame G 4) : c1666.eval F.assign = true := by
  apply local_rup F.assign c1666 [c3, c4, c5, c679]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p679 F) (rfl))))
  · decide +kernel
def c1667 : CNF.Clause Nat := [(62,false), (40,false), (38,false), (98,false), (10,false), (88,false)]
theorem p1667 (F : Frame G 4) : c1667.eval F.assign = true := by
  apply local_rup F.assign c1667 [c3, c2, c5, c4, c680]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p680 F) (rfl)))))
  · decide +kernel
def c1668 : CNF.Clause Nat := [(62,false), (7,false), (38,false), (98,false), (87,false), (88,false)]
theorem p1668 (F : Frame G 4) : c1668.eval F.assign = true := by
  apply local_rup F.assign c1668 [c3, c1, c2, c5, c681]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p681 F) (rfl)))))
  · decide +kernel
def c1669 : CNF.Clause Nat := [(6,false), (38,false), (51,false), (18,false), (19,false), (88,false), (99,false), (31,false)]
theorem p1669 (F : Frame G 4) : c1669.eval F.assign = true := by
  apply local_rup F.assign c1669 [c1, c6, c682]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p682 F) (rfl)))
  · decide +kernel
def c1670 : CNF.Clause Nat := [(38,false), (5,false), (87,false), (62,false), (18,false), (99,false)]
theorem p1670 (F : Frame G 4) : c1670.eval F.assign = true := by
  apply local_rup F.assign c1670 [c4, c6, c3, c5, c683]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p683 F) (rfl)))))
  · decide +kernel
def c1671 : CNF.Clause Nat := [(88,false), (99,false), (98,false), (29,false), (18,false), (15,false), (38,false), (50,false)]
theorem p1671 (F : Frame G 4) : c1671.eval F.assign = true := by
  apply local_rup F.assign c1671 [c4, c6, c684]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p684 F) (rfl)))
  · decide +kernel
def c1672 : CNF.Clause Nat := [(88,false), (99,false), (21,false), (29,false), (40,false), (38,false), (50,false)]
theorem p1672 (F : Frame G 4) : c1672.eval F.assign = true := by
  apply local_rup F.assign c1672 [c4, c5, c6, c685]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p685 F) (rfl))))
  · decide +kernel
def c1673 : CNF.Clause Nat := [(88,false), (99,false), (98,false), (21,false), (50,false), (29,false)]
theorem p1673 (F : Frame G 4) : c1673.eval F.assign = true := by
  apply local_rup F.assign c1673 [c1, c4, c2, c3, c686]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p686 F) (rfl)))))
  · decide +kernel
def c1674 : CNF.Clause Nat := [(88,false), (22,false), (50,false), (62,false), (29,false), (31,false), (98,false)]
theorem p1674 (F : Frame G 4) : c1674.eval F.assign = true := by
  apply local_rup F.assign c1674 [c1, c4, c2, c687]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p687 F) (rfl))))
  · decide +kernel
def c1675 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (88,false), (33,false), (29,false), (18,false), (98,false)]
theorem p1675 (F : Frame G 4) : c1675.eval F.assign = true := by
  apply local_rup F.assign c1675 [c4, c5, c688]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p688 F) (rfl)))
  · decide +kernel
def c1676 : CNF.Clause Nat := [(39,false), (40,false), (7,false), (5,false), (98,false), (87,false), (88,false)]
theorem p1676 (F : Frame G 4) : c1676.eval F.assign = true := by
  apply local_rup F.assign c1676 [c3, c2, c5, c689]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p689 F) (rfl))))
  · decide +kernel
def c1677 : CNF.Clause Nat := [(40,false), (51,false), (50,false), (21,false), (86,false), (88,false)]
theorem p1677 (F : Frame G 4) : c1677.eval F.assign = true := by
  apply local_rup F.assign c1677 [c1, c3, c6, c5, c690]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p690 F) (rfl)))))
  · decide +kernel
def c1678 : CNF.Clause Nat := [(87,false), (86,false), (99,false), (22,false), (15,false), (6,false), (50,false), (51,false)]
theorem p1678 (F : Frame G 4) : c1678.eval F.assign = true := by
  apply local_rup F.assign c1678 [c6, c1, c691]
  · exact sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p691 F) (rfl)))
  · decide +kernel
def c1679 : CNF.Clause Nat := [(50,false), (51,false), (40,false), (10,false), (98,false), (22,false), (88,false)]
theorem p1679 (F : Frame G 4) : c1679.eval F.assign = true := by
  apply local_rup F.assign c1679 [c3, c1, c5, c692]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p692 F) (rfl))))
  · decide +kernel
def c1680 : CNF.Clause Nat := [(40,false), (7,false), (6,false), (50,false), (86,false), (87,false), (33,false)]
theorem p1680 (F : Frame G 4) : c1680.eval F.assign = true := by
  apply local_rup F.assign c1680 [c2, c5, c6, c693]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p693 F) (rfl))))
  · decide +kernel
def c1681 : CNF.Clause Nat := [(6,false), (50,false), (51,false), (18,false), (86,false), (87,false), (33,false)]
theorem p1681 (F : Frame G 4) : c1681.eval F.assign = true := by
  apply local_rup F.assign c1681 [c1, c5, c6, c694]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p694 F) (rfl))))
  · decide +kernel
def c1682 : CNF.Clause Nat := [(98,false), (10,false), (6,false), (50,false), (38,false), (40,false), (29,false), (30,false), (88,false)]
theorem p1682 (F : Frame G 4) : c1682.eval F.assign = true := by
  apply local_rup F.assign c1682 [c5, c695]
  · exact sat_cons (p5 F) ( sat_cons (p695 F) (rfl))
  · decide +kernel
def c1683 : CNF.Clause Nat := [(15,false), (40,false), (51,false), (50,false), (6,false), (88,false), (33,false), (31,false), (98,false)]
theorem p1683 (F : Frame G 4) : c1683.eval F.assign = true := by
  apply local_rup F.assign c1683 [c4, c696]
  · exact sat_cons (p4 F) ( sat_cons (p696 F) (rfl))
  · decide +kernel
def c1684 : CNF.Clause Nat := [(87,false), (98,false), (99,false), (33,false), (26,false), (40,false), (18,false), (50,false)]
theorem p1684 (F : Frame G 4) : c1684.eval F.assign = true := by
  apply local_rup F.assign c1684 [c4, c2, c697]
  · exact sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p697 F) (rfl)))
  · decide +kernel
def c1685 : CNF.Clause Nat := [(26,false), (50,false), (51,false), (18,false), (98,false), (87,false), (88,false)]
theorem p1685 (F : Frame G 4) : c1685.eval F.assign = true := by
  apply local_rup F.assign c1685 [c1, c3, c5, c698]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p698 F) (rfl))))
  · decide +kernel
def c1686 : CNF.Clause Nat := [(40,false), (7,false), (87,false), (98,false), (99,false), (33,false), (27,false), (17,false)]
theorem p1686 (F : Frame G 4) : c1686.eval F.assign = true := by
  apply local_rup F.assign c1686 [c4, c2, c699]
  · exact sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p699 F) (rfl)))
  · decide +kernel
def c1687 : CNF.Clause Nat := [(98,false), (99,false), (88,false), (19,false), (50,false), (6,false), (40,false)]
theorem p1687 (F : Frame G 4) : c1687.eval F.assign = true := by
  apply local_rup F.assign c1687 [c6, c2, c1, c700]
  · exact sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p700 F) (rfl))))
  · decide +kernel
def c1688 : CNF.Clause Nat := [(98,false), (99,false), (88,false), (5,false), (50,false), (17,false), (15,false), (40,false)]
theorem p1688 (F : Frame G 4) : c1688.eval F.assign = true := by
  apply local_rup F.assign c1688 [c6, c4, c701]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p701 F) (rfl)))
  · decide +kernel
def c1689 : CNF.Clause Nat := [(50,false), (26,false), (40,false), (7,false), (88,false), (99,false), (21,false)]
theorem p1689 (F : Frame G 4) : c1689.eval F.assign = true := by
  apply local_rup F.assign c1689 [c3, c4, c5, c702]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p702 F) (rfl))))
  · decide +kernel
def c1690 : CNF.Clause Nat := [(50,false), (38,false), (40,false), (7,false), (88,false), (22,false), (98,false)]
theorem p1690 (F : Frame G 4) : c1690.eval F.assign = true := by
  apply local_rup F.assign c1690 [c3, c4, c5, c703]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p703 F) (rfl))))
  · decide +kernel
def c1691 : CNF.Clause Nat := [(11,false), (88,false), (86,false), (98,false), (39,false), (38,false), (18,false)]
theorem p1691 (F : Frame G 4) : c1691.eval F.assign = true := by
  apply local_rup F.assign c1691 [c6, c3, c2, c704]
  · exact sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p704 F) (rfl))))
  · decide +kernel
def c1692 : CNF.Clause Nat := [(62,false), (40,false), (5,false), (19,false), (88,false), (99,false), (98,false)]
theorem p1692 (F : Frame G 4) : c1692.eval F.assign = true := by
  apply local_rup F.assign c1692 [c3, c1, c2, c705]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p705 F) (rfl))))
  · decide +kernel
def c1693 : CNF.Clause Nat := [(40,false), (51,false), (17,false), (98,false), (86,false), (88,false)]
theorem p1693 (F : Frame G 4) : c1693.eval F.assign = true := by
  apply local_rup F.assign c1693 [c1, c2, c3, c6, c706]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p706 F) (rfl)))))
  · decide +kernel
def c1694 : CNF.Clause Nat := [(26,false), (50,false), (51,false), (18,false), (19,false), (10,false), (98,false), (99,false)]
theorem p1694 (F : Frame G 4) : c1694.eval F.assign = true := by
  apply local_rup F.assign c1694 [c3, c4, c707]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p707 F) (rfl)))
  · decide +kernel
def c1695 : CNF.Clause Nat := [(26,false), (50,false), (51,false), (7,false), (88,false), (99,false), (21,false)]
theorem p1695 (F : Frame G 4) : c1695.eval F.assign = true := by
  apply local_rup F.assign c1695 [c3, c4, c5, c708]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p708 F) (rfl))))
  · decide +kernel
def c1696 : CNF.Clause Nat := [(50,false), (38,false), (7,false), (18,false), (21,false), (98,false), (86,false), (88,false)]
theorem p1696 (F : Frame G 4) : c1696.eval F.assign = true := by
  apply local_rup F.assign c1696 [c3, c1, c709]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p709 F) (rfl)))
  · decide +kernel
def c1697 : CNF.Clause Nat := [(50,false), (6,false), (7,false), (40,false), (26,false), (30,false), (88,false), (99,false), (98,false)]
theorem p1697 (F : Frame G 4) : c1697.eval F.assign = true := by
  apply local_rup F.assign c1697 [c2, c710]
  · exact sat_cons (p2 F) ( sat_cons (p710 F) (rfl))
  · decide +kernel
def c1698 : CNF.Clause Nat := [(50,false), (51,false), (40,false), (87,false), (21,false), (99,false)]
theorem p1698 (F : Frame G 4) : c1698.eval F.assign = true := by
  apply local_rup F.assign c1698 [c3, c1, c4, c5, c711]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p711 F) (rfl)))))
  · decide +kernel
def c1699 : CNF.Clause Nat := [(15,false), (40,false), (7,false), (10,false), (98,false), (99,false), (88,false), (30,false)]
theorem p1699 (F : Frame G 4) : c1699.eval F.assign = true := by
  apply local_rup F.assign c1699 [c2, c3, c712]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p712 F) (rfl)))
  · decide +kernel
def c1700 : CNF.Clause Nat := [(99,false), (88,false), (87,false), (26,false), (40,false), (7,false), (5,false), (50,false)]
theorem p1700 (F : Frame G 4) : c1700.eval F.assign = true := by
  apply local_rup F.assign c1700 [c5, c6, c713]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p713 F) (rfl)))
  · decide +kernel
def c1701 : CNF.Clause Nat := [(99,false), (88,false), (87,false), (10,false), (40,false), (51,false), (27,false)]
theorem p1701 (F : Frame G 4) : c1701.eval F.assign = true := by
  apply local_rup F.assign c1701 [c5, c1, c3, c714]
  · exact sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p714 F) (rfl))))
  · decide +kernel
def c1702 : CNF.Clause Nat := [(40,false), (51,false), (17,false), (87,false), (9,false), (99,false)]
theorem p1702 (F : Frame G 4) : c1702.eval F.assign = true := by
  apply local_rup F.assign c1702 [c2, c3, c6, c4, c715]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p715 F) (rfl)))))
  · decide +kernel
def c1703 : CNF.Clause Nat := [(87,false), (88,false), (99,false), (9,false), (15,false), (51,false)]
theorem p1703 (F : Frame G 4) : c1703.eval F.assign = true := by
  apply local_rup F.assign c1703 [c3, c6, c1, c2, c716]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p716 F) (rfl)))))
  · decide +kernel
def c1704 : CNF.Clause Nat := [(10,false), (87,false), (88,false), (99,false), (31,false), (17,false), (51,false)]
theorem p1704 (F : Frame G 4) : c1704.eval F.assign = true := by
  apply local_rup F.assign c1704 [c1, c3, c2, c717]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p717 F) (rfl))))
  · decide +kernel
def c1705 : CNF.Clause Nat := [(9,false), (50,false), (62,false), (29,false), (87,false), (88,false)]
theorem p1705 (F : Frame G 4) : c1705.eval F.assign = true := by
  apply local_rup F.assign c1705 [c1, c5, c2, c6, c718]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p718 F) (rfl)))))
  · decide +kernel
def c1706 : CNF.Clause Nat := [(29,false), (51,false), (38,false), (39,false), (17,false), (98,false), (10,false), (88,false)]
theorem p1706 (F : Frame G 4) : c1706.eval F.assign = true := by
  apply local_rup F.assign c1706 [c5, c4, c719]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p719 F) (rfl)))
  · decide +kernel
def c1707 : CNF.Clause Nat := [(26,false), (50,false), (51,false), (18,false), (99,false), (11,false), (87,false)]
theorem p1707 (F : Frame G 4) : c1707.eval F.assign = true := by
  apply local_rup F.assign c1707 [c3, c5, c4, c720]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p720 F) (rfl))))
  · decide +kernel
def c1708 : CNF.Clause Nat := [(39,false), (17,false), (51,false), (29,false), (87,false), (9,false), (99,false)]
theorem p1708 (F : Frame G 4) : c1708.eval F.assign = true := by
  apply local_rup F.assign c1708 [c2, c6, c4, c721]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p721 F) (rfl))))
  · decide +kernel
def c1709 : CNF.Clause Nat := [(99,false), (88,false), (87,false), (26,false), (39,false), (6,false), (5,false), (51,false)]
theorem p1709 (F : Frame G 4) : c1709.eval F.assign = true := by
  apply local_rup F.assign c1709 [c5, c6, c722]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p722 F) (rfl)))
  · decide +kernel
def c1710 : CNF.Clause Nat := [(10,false), (87,false), (88,false), (99,false), (50,false), (29,false)]
theorem p1710 (F : Frame G 4) : c1710.eval F.assign = true := by
  apply local_rup F.assign c1710 [c1, c5, c2, c3, c723]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p723 F) (rfl)))))
  · decide +kernel
def c1711 : CNF.Clause Nat := [(38,false), (26,false), (62,false), (7,false), (10,false), (87,false), (19,false), (99,false)]
theorem p1711 (F : Frame G 4) : c1711.eval F.assign = true := by
  apply local_rup F.assign c1711 [c3, c5, c724]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p724 F) (rfl)))
  · decide +kernel
def c1712 : CNF.Clause Nat := [(38,false), (26,false), (62,false), (7,false), (87,false), (21,false), (99,false)]
theorem p1712 (F : Frame G 4) : c1712.eval F.assign = true := by
  apply local_rup F.assign c1712 [c3, c4, c5, c725]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p725 F) (rfl))))
  · decide +kernel
def c1713 : CNF.Clause Nat := [(38,false), (18,false), (62,false), (87,false), (9,false), (99,false)]
theorem p1713 (F : Frame G 4) : c1713.eval F.assign = true := by
  apply local_rup F.assign c1713 [c2, c3, c6, c4, c726]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p726 F) (rfl)))))
  · decide +kernel
def c1714 : CNF.Clause Nat := [(7,false), (62,false), (50,false), (98,false), (33,false), (88,false)]
theorem p1714 (F : Frame G 4) : c1714.eval F.assign = true := by
  apply local_rup F.assign c1714 [c1, c2, c5, c6, c727]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p727 F) (rfl)))))
  · decide +kernel
def c1715 : CNF.Clause Nat := [(6,false), (11,false), (88,false), (86,false), (98,false), (21,false), (15,false), (38,false), (51,false)]
theorem p1715 (F : Frame G 4) : c1715.eval F.assign = true := by
  apply local_rup F.assign c1715 [c3, c728]
  · exact sat_cons (p3 F) ( sat_cons (p728 F) (rfl))
  · decide +kernel
def c1716 : CNF.Clause Nat := [(17,false), (21,false), (98,false), (99,false), (88,false), (26,false), (27,false), (51,false)]
theorem p1716 (F : Frame G 4) : c1716.eval F.assign = true := by
  apply local_rup F.assign c1716 [c4, c1, c729]
  · exact sat_cons (p4 F) ( sat_cons (p1 F) ( sat_cons (p729 F) (rfl)))
  · decide +kernel
def c1717 : CNF.Clause Nat := [(38,false), (39,false), (29,false), (18,false), (21,false), (98,false), (9,false), (88,false)]
theorem p1717 (F : Frame G 4) : c1717.eval F.assign = true := by
  apply local_rup F.assign c1717 [c3, c4, c730]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p730 F) (rfl)))
  · decide +kernel
def c1718 : CNF.Clause Nat := [(38,false), (39,false), (62,false), (18,false), (98,false), (10,false), (30,false), (33,false)]
theorem p1718 (F : Frame G 4) : c1718.eval F.assign = true := by
  apply local_rup F.assign c1718 [c5, c4, c731]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p731 F) (rfl)))
  · decide +kernel
def c1719 : CNF.Clause Nat := [(51,false), (62,false), (39,false), (30,false), (98,false), (99,false)]
theorem p1719 (F : Frame G 4) : c1719.eval F.assign = true := by
  apply local_rup F.assign c1719 [c2, c1, c4, c6, c732]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p732 F) (rfl)))))
  · decide +kernel
def c1720 : CNF.Clause Nat := [(88,false), (99,false), (98,false), (21,false), (27,false), (62,false)]
theorem p1720 (F : Frame G 4) : c1720.eval F.assign = true := by
  apply local_rup F.assign c1720 [c1, c4, c2, c3, c733]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p733 F) (rfl)))))
  · decide +kernel
def c1721 : CNF.Clause Nat := [(88,false), (99,false), (98,false), (27,false), (17,false), (62,false)]
theorem p1721 (F : Frame G 4) : c1721.eval F.assign = true := by
  apply local_rup F.assign c1721 [c1, c4, c6, c2, c734]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p734 F) (rfl)))))
  · decide +kernel
def c1722 : CNF.Clause Nat := [(40,false), (51,false), (17,false), (30,false), (10,false), (98,false), (99,false)]
theorem p1722 (F : Frame G 4) : c1722.eval F.assign = true := by
  apply local_rup F.assign c1722 [c2, c3, c4, c735]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p735 F) (rfl))))
  · decide +kernel
def c1723 : CNF.Clause Nat := [(40,false), (62,false), (50,false), (86,false), (87,false), (33,false)]
theorem p1723 (F : Frame G 4) : c1723.eval F.assign = true := by
  apply local_rup F.assign c1723 [c1, c2, c5, c6, c736]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p736 F) (rfl)))))
  · decide +kernel
def c1724 : CNF.Clause Nat := [(39,false), (87,false), (86,false), (99,false), (22,false), (51,false)]
theorem p1724 (F : Frame G 4) : c1724.eval F.assign = true := by
  apply local_rup F.assign c1724 [c1, c3, c6, c2, c737]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p737 F) (rfl)))))
  · decide +kernel
def c1725 : CNF.Clause Nat := [(39,false), (50,false), (98,false), (87,false), (88,false), (33,false), (29,false)]
theorem p1725 (F : Frame G 4) : c1725.eval F.assign = true := by
  apply local_rup F.assign c1725 [c1, c2, c5, c738]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p738 F) (rfl))))
  · decide +kernel
def c1726 : CNF.Clause Nat := [(29,false), (51,false), (38,false), (11,false), (99,false), (19,false), (87,false)]
theorem p1726 (F : Frame G 4) : c1726.eval F.assign = true := by
  apply local_rup F.assign c1726 [c3, c1, c5, c739]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p739 F) (rfl))))
  · decide +kernel
def c1727 : CNF.Clause Nat := [(39,false), (26,false), (87,false), (19,false), (51,false), (7,false), (9,false), (99,false)]
theorem p1727 (F : Frame G 4) : c1727.eval F.assign = true := by
  apply local_rup F.assign c1727 [c6, c2, c740]
  · exact sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p740 F) (rfl)))
  · decide +kernel
def c1728 : CNF.Clause Nat := [(15,false), (38,false), (51,false), (29,false), (6,false), (87,false), (98,false), (99,false)]
theorem p1728 (F : Frame G 4) : c1728.eval F.assign = true := by
  apply local_rup F.assign c1728 [c3, c4, c741]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p741 F) (rfl)))
  · decide +kernel
def c1729 : CNF.Clause Nat := [(33,false), (99,false), (98,false), (87,false), (19,false), (17,false), (39,false), (5,false), (51,false)]
theorem p1729 (F : Frame G 4) : c1729.eval F.assign = true := by
  apply local_rup F.assign c1729 [c1, c742]
  · exact sat_cons (p1 F) ( sat_cons (p742 F) (rfl))
  · decide +kernel
def c1730 : CNF.Clause Nat := [(38,false), (51,false), (18,false), (17,false), (33,false), (99,false), (9,false), (87,false)]
theorem p1730 (F : Frame G 4) : c1730.eval F.assign = true := by
  apply local_rup F.assign c1730 [c3, c4, c743]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p743 F) (rfl)))
  · decide +kernel
def c1731 : CNF.Clause Nat := [(39,false), (38,false), (51,false), (18,false), (99,false), (11,false), (30,false)]
theorem p1731 (F : Frame G 4) : c1731.eval F.assign = true := by
  apply local_rup F.assign c1731 [c5, c4, c6, c744]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p744 F) (rfl))))
  · decide +kernel
def c1732 : CNF.Clause Nat := [(39,false), (38,false), (51,false), (7,false), (87,false), (21,false), (99,false)]
theorem p1732 (F : Frame G 4) : c1732.eval F.assign = true := by
  apply local_rup F.assign c1732 [c3, c4, c5, c745]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p745 F) (rfl))))
  · decide +kernel
def c1733 : CNF.Clause Nat := [(87,false), (98,false), (99,false), (33,false), (39,false), (15,false), (51,false)]
theorem p1733 (F : Frame G 4) : c1733.eval F.assign = true := by
  apply local_rup F.assign c1733 [c4, c3, c2, c746]
  · exact sat_cons (p4 F) ( sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p746 F) (rfl))))
  · decide +kernel
def c1734 : CNF.Clause Nat := [(39,false), (17,false), (51,false), (29,false), (87,false), (86,false), (99,false)]
theorem p1734 (F : Frame G 4) : c1734.eval F.assign = true := by
  apply local_rup F.assign c1734 [c1, c2, c6, c747]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p747 F) (rfl))))
  · decide +kernel
def c1735 : CNF.Clause Nat := [(26,false), (62,false), (51,false), (5,false), (87,false), (21,false), (99,false)]
theorem p1735 (F : Frame G 4) : c1735.eval F.assign = true := by
  apply local_rup F.assign c1735 [c3, c4, c5, c748]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p748 F) (rfl))))
  · decide +kernel
def c1736 : CNF.Clause Nat := [(38,false), (15,false), (17,false), (62,false), (7,false), (10,false), (30,false), (86,false), (99,false)]
theorem p1736 (F : Frame G 4) : c1736.eval F.assign = true := by
  apply local_rup F.assign c1736 [c6, c749]
  · exact sat_cons (p6 F) ( sat_cons (p749 F) (rfl))
  · decide +kernel
def c1737 : CNF.Clause Nat := [(22,false), (99,false), (86,false), (87,false), (10,false), (38,false), (27,false), (62,false)]
theorem p1737 (F : Frame G 4) : c1737.eval F.assign = true := by
  apply local_rup F.assign c1737 [c1, c3, c750]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p750 F) (rfl)))
  · decide +kernel
def c1738 : CNF.Clause Nat := [(38,false), (7,false), (62,false), (87,false), (86,false), (99,false)]
theorem p1738 (F : Frame G 4) : c1738.eval F.assign = true := by
  apply local_rup F.assign c1738 [c2, c1, c3, c6, c751]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p751 F) (rfl)))))
  · decide +kernel
def c1739 : CNF.Clause Nat := [(38,false), (6,false), (62,false), (29,false), (87,false), (86,false), (99,false)]
theorem p1739 (F : Frame G 4) : c1739.eval F.assign = true := by
  apply local_rup F.assign c1739 [c2, c1, c6, c752]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p752 F) (rfl))))
  · decide +kernel
def c1740 : CNF.Clause Nat := [(38,false), (39,false), (62,false), (7,false), (87,false), (21,false), (31,false), (33,false)]
theorem p1740 (F : Frame G 4) : c1740.eval F.assign = true := by
  apply local_rup F.assign c1740 [c4, c5, c753]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p753 F) (rfl)))
  · decide +kernel
def c1741 : CNF.Clause Nat := [(38,false), (50,false), (87,false), (86,false), (99,false), (22,false), (18,false)]
theorem p1741 (F : Frame G 4) : c1741.eval F.assign = true := by
  apply local_rup F.assign c1741 [c1, c3, c6, c754]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p754 F) (rfl))))
  · decide +kernel
def c1742 : CNF.Clause Nat := [(39,false), (62,false), (18,false), (27,false), (87,false), (86,false), (99,false)]
theorem p1742 (F : Frame G 4) : c1742.eval F.assign = true := by
  apply local_rup F.assign c1742 [c1, c2, c6, c755]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p755 F) (rfl))))
  · decide +kernel
def c1743 : CNF.Clause Nat := [(6,false), (5,false), (38,false), (40,false), (18,false), (98,false), (87,false), (88,false)]
theorem p1743 (F : Frame G 4) : c1743.eval F.assign = true := by
  apply local_rup F.assign c1743 [c3, c5, c756]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p756 F) (rfl)))
  · decide +kernel
def c1744 : CNF.Clause Nat := [(98,false), (62,false), (40,false), (38,false), (5,false), (88,false)]
theorem p1744 (F : Frame G 4) : c1744.eval F.assign = true := by
  apply local_rup F.assign c1744 [c5, c6, c3, c4, c757]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p757 F) (rfl)))))
  · decide +kernel
def c1745 : CNF.Clause Nat := [(39,false), (40,false), (18,false), (5,false), (88,false), (99,false), (98,false)]
theorem p1745 (F : Frame G 4) : c1745.eval F.assign = true := by
  apply local_rup F.assign c1745 [c3, c2, c4, c758]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p758 F) (rfl))))
  · decide +kernel
def c1746 : CNF.Clause Nat := [(5,false), (51,false), (62,false), (17,false), (98,false), (33,false), (88,false)]
theorem p1746 (F : Frame G 4) : c1746.eval F.assign = true := by
  apply local_rup F.assign c1746 [c1, c5, c6, c759]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p759 F) (rfl))))
  · decide +kernel
def c1747 : CNF.Clause Nat := [(62,false), (40,false), (15,false), (5,false), (87,false), (98,false), (99,false)]
theorem p1747 (F : Frame G 4) : c1747.eval F.assign = true := by
  apply local_rup F.assign c1747 [c3, c2, c4, c760]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p760 F) (rfl))))
  · decide +kernel
def c1748 : CNF.Clause Nat := [(51,false), (40,false), (26,false), (6,false), (11,false), (88,false), (86,false), (98,false)]
theorem p1748 (F : Frame G 4) : c1748.eval F.assign = true := by
  apply local_rup F.assign c1748 [c2, c3, c761]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p761 F) (rfl)))
  · decide +kernel
def c1749 : CNF.Clause Nat := [(98,false), (110,false), (88,false), (26,false), (50,false), (51,false)]
theorem p1749 (F : Frame G 4) : c1749.eval F.assign = true := by
  apply local_rup F.assign c1749 [c5, c4, c1, c3, c762]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p762 F) (rfl)))))
  · decide +kernel
def c1750 : CNF.Clause Nat := [(15,false), (40,false), (51,false), (50,false), (6,false), (30,false), (31,false), (98,false), (110,false)]
theorem p1750 (F : Frame G 4) : c1750.eval F.assign = true := by
  apply local_rup F.assign c1750 [c4, c763]
  · exact sat_cons (p4 F) ( sat_cons (p763 F) (rfl))
  · decide +kernel
def c1751 : CNF.Clause Nat := [(38,false), (40,false), (7,false), (6,false), (30,false), (88,false), (99,false), (98,false)]
theorem p1751 (F : Frame G 4) : c1751.eval F.assign = true := by
  apply local_rup F.assign c1751 [c2, c3, c764]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p764 F) (rfl)))
  · decide +kernel
def c1752 : CNF.Clause Nat := [(50,false), (51,false), (18,false), (15,false), (87,false), (98,false), (99,false)]
theorem p1752 (F : Frame G 4) : c1752.eval F.assign = true := by
  apply local_rup F.assign c1752 [c3, c1, c4, c765]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p765 F) (rfl))))
  · decide +kernel
def c1753 : CNF.Clause Nat := [(51,false), (40,false), (39,false), (98,false), (86,false), (11,false)]
theorem p1753 (F : Frame G 4) : c1753.eval F.assign = true := by
  apply local_rup F.assign c1753 [c2, c3, c6, c4, c766]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p766 F) (rfl)))))
  · decide +kernel
def c1754 : CNF.Clause Nat := [(99,false), (11,false), (39,false), (62,false), (29,false), (30,false), (87,false)]
theorem p1754 (F : Frame G 4) : c1754.eval F.assign = true := by
  apply local_rup F.assign c1754 [c2, c5, c1, c767]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p767 F) (rfl))))
  · decide +kernel
def c1755 : CNF.Clause Nat := [(27,false), (62,false), (40,false), (87,false), (21,false), (99,false)]
theorem p1755 (F : Frame G 4) : c1755.eval F.assign = true := by
  apply local_rup F.assign c1755 [c3, c1, c4, c5, c768]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p768 F) (rfl)))))
  · decide +kernel
def c1756 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (99,false), (33,false), (29,false), (7,false), (87,false)]
theorem p1756 (F : Frame G 4) : c1756.eval F.assign = true := by
  apply local_rup F.assign c1756 [c5, c4, c769]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p769 F) (rfl)))
  · decide +kernel
def c1757 : CNF.Clause Nat := [(17,false), (39,false), (40,false), (29,false), (87,false), (9,false), (99,false)]
theorem p1757 (F : Frame G 4) : c1757.eval F.assign = true := by
  apply local_rup F.assign c1757 [c2, c6, c4, c770]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p770 F) (rfl))))
  · decide +kernel
def c1758 : CNF.Clause Nat := [(5,false), (6,false), (39,false), (40,false), (29,false), (21,false), (86,false), (88,false)]
theorem p1758 (F : Frame G 4) : c1758.eval F.assign = true := by
  apply local_rup F.assign c1758 [c6, c5, c771]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p771 F) (rfl)))
  · decide +kernel
def c1759 : CNF.Clause Nat := [(62,false), (40,false), (15,false), (5,false), (10,false), (87,false), (86,false), (99,false)]
theorem p1759 (F : Frame G 4) : c1759.eval F.assign = true := by
  apply local_rup F.assign c1759 [c3, c2, c772]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p772 F) (rfl)))
  · decide +kernel
def c1760 : CNF.Clause Nat := [(51,false), (40,false), (6,false), (87,false), (86,false), (99,false)]
theorem p1760 (F : Frame G 4) : c1760.eval F.assign = true := by
  apply local_rup F.assign c1760 [c2, c1, c3, c6, c773]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p773 F) (rfl)))))
  · decide +kernel
def c1761 : CNF.Clause Nat := [(18,false), (62,false), (39,false), (87,false), (31,false), (99,false)]
theorem p1761 (F : Frame G 4) : c1761.eval F.assign = true := by
  apply local_rup F.assign c1761 [c2, c1, c4, c6, c774]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p774 F) (rfl)))))
  · decide +kernel
def c1762 : CNF.Clause Nat := [(5,false), (7,false), (40,false), (39,false), (17,false), (86,false), (87,false), (33,false)]
theorem p1762 (F : Frame G 4) : c1762.eval F.assign = true := by
  apply local_rup F.assign c1762 [c5, c6, c775]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p775 F) (rfl)))
  · decide +kernel
def c1763 : CNF.Clause Nat := [(5,false), (6,false), (39,false), (40,false), (18,false), (86,false), (87,false), (33,false)]
theorem p1763 (F : Frame G 4) : c1763.eval F.assign = true := by
  apply local_rup F.assign c1763 [c5, c6, c776]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p776 F) (rfl)))
  · decide +kernel
def c1764 : CNF.Clause Nat := [(40,false), (62,false), (27,false), (22,false), (88,false), (86,false), (98,false)]
theorem p1764 (F : Frame G 4) : c1764.eval F.assign = true := by
  apply local_rup F.assign c1764 [c1, c3, c2, c777]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p777 F) (rfl))))
  · decide +kernel
def c1765 : CNF.Clause Nat := [(99,false), (33,false), (87,false), (38,false), (50,false), (62,false)]
theorem p1765 (F : Frame G 4) : c1765.eval F.assign = true := by
  apply local_rup F.assign c1765 [c5, c6, c4, c1, c778]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1 F) ( sat_cons (p778 F) (rfl)))))
  · decide +kernel
def c1766 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (87,false), (7,false), (18,false), (99,false)]
theorem p1766 (F : Frame G 4) : c1766.eval F.assign = true := by
  apply local_rup F.assign c1766 [c6, c4, c5, c779]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p779 F) (rfl))))
  · decide +kernel
def c1767 : CNF.Clause Nat := [(38,false), (50,false), (62,false), (18,false), (19,false), (87,false), (31,false), (99,false)]
theorem p1767 (F : Frame G 4) : c1767.eval F.assign = true := by
  apply local_rup F.assign c1767 [c1, c6, c780]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p780 F) (rfl)))
  · decide +kernel
def c1768 : CNF.Clause Nat := [(38,false), (40,false), (62,false), (6,false), (30,false), (21,false), (99,false)]
theorem p1768 (F : Frame G 4) : c1768.eval F.assign = true := by
  apply local_rup F.assign c1768 [c4, c6, c5, c781]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p781 F) (rfl))))
  · decide +kernel
def c1769 : CNF.Clause Nat := [(99,false), (33,false), (50,false), (38,false), (40,false), (7,false), (87,false)]
theorem p1769 (F : Frame G 4) : c1769.eval F.assign = true := by
  apply local_rup F.assign c1769 [c5, c3, c4, c783]
  · exact sat_cons (p5 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p783 F) (rfl))))
  · decide +kernel
def c1770 : CNF.Clause Nat := [(87,false), (88,false), (99,false), (50,false), (6,false), (40,false)]
theorem p1770 (F : Frame G 4) : c1770.eval F.assign = true := by
  apply local_rup F.assign c1770 [c6, c5, c2, c1, c784]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p784 F) (rfl)))))
  · decide +kernel
def c1771 : CNF.Clause Nat := [(17,false), (39,false), (40,false), (29,false), (31,false), (99,false), (11,false), (87,false)]
theorem p1771 (F : Frame G 4) : c1771.eval F.assign = true := by
  apply local_rup F.assign c1771 [c2, c4, c785]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p785 F) (rfl)))
  · decide +kernel
def c1772 : CNF.Clause Nat := [(39,false), (38,false), (18,false), (7,false), (9,false), (99,false), (88,false), (87,false)]
theorem p1772 (F : Frame G 4) : c1772.eval F.assign = true := by
  apply local_rup F.assign c1772 [c3, c2, c786]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p786 F) (rfl)))
  · decide +kernel
def c1773 : CNF.Clause Nat := [(50,false), (38,false), (40,false), (7,false), (87,false), (21,false), (99,false)]
theorem p1773 (F : Frame G 4) : c1773.eval F.assign = true := by
  apply local_rup F.assign c1773 [c3, c4, c5, c787]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p787 F) (rfl))))
  · decide +kernel
def c1774 : CNF.Clause Nat := [(87,false), (86,false), (99,false), (11,false), (40,false), (18,false), (50,false)]
theorem p1774 (F : Frame G 4) : c1774.eval F.assign = true := by
  apply local_rup F.assign c1774 [c6, c1, c2, c788]
  · exact sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p788 F) (rfl))))
  · decide +kernel
def c1775 : CNF.Clause Nat := [(5,false), (39,false), (17,false), (18,false), (29,false), (87,false), (86,false), (99,false)]
theorem p1775 (F : Frame G 4) : c1775.eval F.assign = true := by
  apply local_rup F.assign c1775 [c1, c6, c789]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p789 F) (rfl)))
  · decide +kernel
def c1776 : CNF.Clause Nat := [(17,false), (29,false), (40,false), (10,false), (87,false), (86,false), (99,false)]
theorem p1776 (F : Frame G 4) : c1776.eval F.assign = true := by
  apply local_rup F.assign c1776 [c2, c3, c1, c790]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p790 F) (rfl))))
  · decide +kernel
def c1777 : CNF.Clause Nat := [(27,false), (39,false), (40,false), (7,false), (10,false), (87,false), (86,false), (22,false)]
theorem p1777 (F : Frame G 4) : c1777.eval F.assign = true := by
  apply local_rup F.assign c1777 [c3, c5, c791]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p791 F) (rfl)))
  · decide +kernel
def c1778 : CNF.Clause Nat := [(26,false), (38,false), (51,false), (7,false), (11,false), (99,false), (86,false), (19,false), (21,false)]
theorem p1778 (F : Frame G 4) : c1778.eval F.assign = true := by
  apply local_rup F.assign c1778 [c3, c792]
  · exact sat_cons (p3 F) ( sat_cons (p792 F) (rfl))
  · decide +kernel
def c1779 : CNF.Clause Nat := [(26,false), (38,false), (51,false), (7,false), (19,false), (21,false), (98,false), (99,false)]
theorem p1779 (F : Frame G 4) : c1779.eval F.assign = true := by
  apply local_rup F.assign c1779 [c3, c4, c793]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p793 F) (rfl)))
  · decide +kernel
def c1780 : CNF.Clause Nat := [(39,false), (26,false), (29,false), (51,false), (5,false), (86,false), (98,false), (21,false), (22,false)]
theorem p1780 (F : Frame G 4) : c1780.eval F.assign = true := by
  apply local_rup F.assign c1780 [c4, c794]
  · exact sat_cons (p4 F) ( sat_cons (p794 F) (rfl))
  · decide +kernel
def c1781 : CNF.Clause Nat := [(39,false), (7,false), (51,false), (27,false), (30,false), (86,false), (98,false), (21,false), (22,false)]
theorem p1781 (F : Frame G 4) : c1781.eval F.assign = true := by
  apply local_rup F.assign c1781 [c1, c795]
  · exact sat_cons (p1 F) ( sat_cons (p795 F) (rfl))
  · decide +kernel
def c1782 : CNF.Clause Nat := [(29,false), (51,false), (38,false), (86,false), (98,false), (21,false), (22,false)]
theorem p1782 (F : Frame G 4) : c1782.eval F.assign = true := by
  apply local_rup F.assign c1782 [c3, c1, c4, c796]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p796 F) (rfl))))
  · decide +kernel
def c1783 : CNF.Clause Nat := [(39,false), (7,false), (51,false), (27,false), (98,false), (86,false), (19,false), (22,false)]
theorem p1783 (F : Frame G 4) : c1783.eval F.assign = true := by
  apply local_rup F.assign c1783 [c1, c6, c797]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p797 F) (rfl)))
  · decide +kernel
def c1784 : CNF.Clause Nat := [(39,false), (10,false), (33,false), (99,false), (86,false), (19,false), (51,false)]
theorem p1784 (F : Frame G 4) : c1784.eval F.assign = true := by
  apply local_rup F.assign c1784 [c1, c6, c2, c798]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p798 F) (rfl))))
  · decide +kernel
def c1785 : CNF.Clause Nat := [(98,false), (86,false), (11,false), (22,false), (18,false), (51,false), (38,false), (39,false)]
theorem p1785 (F : Frame G 4) : c1785.eval F.assign = true := by
  apply local_rup F.assign c1785 [c6, c4, c799]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p799 F) (rfl)))
  · decide +kernel
def c1786 : CNF.Clause Nat := [(39,false), (40,false), (51,false), (5,false), (19,false), (21,false), (98,false), (99,false)]
theorem p1786 (F : Frame G 4) : c1786.eval F.assign = true := by
  apply local_rup F.assign c1786 [c3, c4, c800]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p800 F) (rfl)))
  · decide +kernel
def c1787 : CNF.Clause Nat := [(98,false), (99,false), (22,false), (19,false), (6,false), (39,false), (38,false), (51,false)]
theorem p1787 (F : Frame G 4) : c1787.eval F.assign = true := by
  apply local_rup F.assign c1787 [c6, c4, c801]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p801 F) (rfl)))
  · decide +kernel
def c1788 : CNF.Clause Nat := [(39,false), (30,false), (86,false), (98,false), (110,false), (22,false), (51,false)]
theorem p1788 (F : Frame G 4) : c1788.eval F.assign = true := by
  apply local_rup F.assign c1788 [c1, c3, c2, c802]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p802 F) (rfl))))
  · decide +kernel
def c1789 : CNF.Clause Nat := [(6,false), (39,false), (40,false), (51,false), (22,false), (33,false), (31,false), (86,false), (87,false)]
theorem p1789 (F : Frame G 4) : c1789.eval F.assign = true := by
  apply local_rup F.assign c1789 [c2, c803]
  · exact sat_cons (p2 F) ( sat_cons (p803 F) (rfl))
  · decide +kernel
def c1790 : CNF.Clause Nat := [(22,false), (110,false), (87,false), (86,false), (9,false), (6,false), (27,false), (38,false), (40,false)]
theorem p1790 (F : Frame G 4) : c1790.eval F.assign = true := by
  apply local_rup F.assign c1790 [c3, c804]
  · exact sat_cons (p3 F) ( sat_cons (p804 F) (rfl))
  · decide +kernel
def c1791 : CNF.Clause Nat := [(86,false), (22,false), (110,false), (50,false), (51,false)]
theorem p1791 (F : Frame G 4) : c1791.eval F.assign = true := by
  apply local_rup F.assign c1791 [c1, c4, c5, c6, c3, c806]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p806 F) (rfl))))))
  · decide +kernel
def c1792 : CNF.Clause Nat := [(39,false), (87,false), (110,false), (99,false), (51,false)]
theorem p1792 (F : Frame G 4) : c1792.eval F.assign = true := by
  apply local_rup F.assign c1792 [c3, c1, c4, c5, c2, c807]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p807 F) (rfl))))))
  · decide +kernel
def c1793 : CNF.Clause Nat := [(5,false), (51,false), (62,false), (17,false), (21,false), (30,false), (86,false), (99,false)]
theorem p1793 (F : Frame G 4) : c1793.eval F.assign = true := by
  apply local_rup F.assign c1793 [c1, c6, c808]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p808 F) (rfl)))
  · decide +kernel
def c1794 : CNF.Clause Nat := [(15,false), (51,false), (62,false), (6,false), (30,false), (98,false), (99,false)]
theorem p1794 (F : Frame G 4) : c1794.eval F.assign = true := by
  apply local_rup F.assign c1794 [c2, c4, c6, c809]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p809 F) (rfl))))
  · decide +kernel
def c1795 : CNF.Clause Nat := [(19,false), (51,false), (62,false), (98,false), (99,false)]
theorem p1795 (F : Frame G 4) : c1795.eval F.assign = true := by
  apply local_rup F.assign c1795 [c1, c4, c2, c3, c6, c810]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p810 F) (rfl))))))
  · decide +kernel
def c1796 : CNF.Clause Nat := [(38,false), (51,false), (62,false), (17,false), (22,false), (99,false), (31,false), (30,false), (87,false)]
theorem p1796 (F : Frame G 4) : c1796.eval F.assign = true := by
  apply local_rup F.assign c1796 [c1, c811]
  · exact sat_cons (p1 F) ( sat_cons (p811 F) (rfl))
  · decide +kernel
def c1797 : CNF.Clause Nat := [(38,false), (18,false), (62,false), (6,false), (30,false), (98,false), (99,false)]
theorem p1797 (F : Frame G 4) : c1797.eval F.assign = true := by
  apply local_rup F.assign c1797 [c2, c4, c6, c812]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p812 F) (rfl))))
  · decide +kernel
def c1798 : CNF.Clause Nat := [(22,false), (99,false), (98,false), (87,false), (38,false), (27,false), (62,false)]
theorem p1798 (F : Frame G 4) : c1798.eval F.assign = true := by
  apply local_rup F.assign c1798 [c4, c1, c3, c814]
  · exact sat_cons (p4 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p814 F) (rfl))))
  · decide +kernel
def c1799 : CNF.Clause Nat := [(39,false), (50,false), (18,false), (29,false), (33,false), (99,false), (9,false), (87,false)]
theorem p1799 (F : Frame G 4) : c1799.eval F.assign = true := by
  apply local_rup F.assign c1799 [c2, c4, c815]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p815 F) (rfl)))
  · decide +kernel
def c1800 : CNF.Clause Nat := [(33,false), (99,false), (98,false), (87,false), (19,false), (5,false), (39,false), (62,false)]
theorem p1800 (F : Frame G 4) : c1800.eval F.assign = true := by
  apply local_rup F.assign c1800 [c2, c1, c816]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p816 F) (rfl)))
  · decide +kernel
end Cert44Steps
end Graffiti199Depleted.Catalogue.OrderEleven
