import Local44Part5
namespace Graffiti199Depleted.Catalogue.OrderEleven
namespace Cert44Steps
open Std.Sat
set_option maxRecDepth 4096
set_option maxHeartbeats 0
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj]
def c1801 : CNF.Clause Nat := [(50,false), (62,false), (40,false), (87,false), (31,false), (99,false)]
theorem p1801 (F : Frame G 4) : c1801.eval F.assign = true := by
  apply local_rup F.assign c1801 [c2, c1, c4, c6, c817]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p817 F) (rfl)))))
  · decide +kernel
def c1802 : CNF.Clause Nat := [(50,false), (62,false), (40,false), (30,false), (98,false), (99,false)]
theorem p1802 (F : Frame G 4) : c1802.eval F.assign = true := by
  apply local_rup F.assign c1802 [c2, c1, c4, c6, c818]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p818 F) (rfl)))))
  · decide +kernel
def c1803 : CNF.Clause Nat := [(30,false), (87,false), (98,false), (99,false), (22,false), (5,false), (39,false), (62,false)]
theorem p1803 (F : Frame G 4) : c1803.eval F.assign = true := by
  apply local_rup F.assign c1803 [c2, c1, c819]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p819 F) (rfl)))
  · decide +kernel
def c1804 : CNF.Clause Nat := [(26,false), (62,false), (18,false), (5,false), (87,false), (98,false), (99,false)]
theorem p1804 (F : Frame G 4) : c1804.eval F.assign = true := by
  apply local_rup F.assign c1804 [c3, c2, c4, c820]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p820 F) (rfl))))
  · decide +kernel
def c1805 : CNF.Clause Nat := [(15,false), (50,false), (62,false), (7,false), (30,false), (98,false), (99,false)]
theorem p1805 (F : Frame G 4) : c1805.eval F.assign = true := by
  apply local_rup F.assign c1805 [c2, c4, c6, c821]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p821 F) (rfl))))
  · decide +kernel
def c1806 : CNF.Clause Nat := [(22,false), (99,false), (98,false), (87,false), (26,false), (50,false), (51,false)]
theorem p1806 (F : Frame G 4) : c1806.eval F.assign = true := by
  apply local_rup F.assign c1806 [c4, c1, c3, c822]
  · exact sat_cons (p4 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p822 F) (rfl))))
  · decide +kernel
def c1807 : CNF.Clause Nat := [(38,false), (21,false), (62,false), (7,false), (86,false), (99,false)]
theorem p1807 (F : Frame G 4) : c1807.eval F.assign = true := by
  apply local_rup F.assign c1807 [c2, c6, c3, c4, c823]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p823 F) (rfl)))))
  · decide +kernel
def c1808 : CNF.Clause Nat := [(5,false), (50,false), (62,false), (18,false), (21,false), (30,false), (86,false), (99,false)]
theorem p1808 (F : Frame G 4) : c1808.eval F.assign = true := by
  apply local_rup F.assign c1808 [c1, c6, c824]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p824 F) (rfl)))
  · decide +kernel
def c1809 : CNF.Clause Nat := [(7,false), (62,false), (50,false), (19,false), (86,false), (98,false), (33,false)]
theorem p1809 (F : Frame G 4) : c1809.eval F.assign = true := by
  apply local_rup F.assign c1809 [c1, c2, c6, c825]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p825 F) (rfl))))
  · decide +kernel
def c1810 : CNF.Clause Nat := [(19,false), (50,false), (62,false), (29,false), (98,false), (99,false)]
theorem p1810 (F : Frame G 4) : c1810.eval F.assign = true := by
  apply local_rup F.assign c1810 [c1, c4, c2, c6, c826]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p826 F) (rfl)))))
  · decide +kernel
def c1811 : CNF.Clause Nat := [(5,false), (50,false), (62,false), (18,false), (22,false), (33,false), (30,false), (86,false), (98,false)]
theorem p1811 (F : Frame G 4) : c1811.eval F.assign = true := by
  apply local_rup F.assign c1811 [c1, c827]
  · exact sat_cons (p1 F) ( sat_cons (p827 F) (rfl))
  · decide +kernel
def c1812 : CNF.Clause Nat := [(7,false), (62,false), (50,false), (22,false), (99,false), (86,false), (30,false)]
theorem p1812 (F : Frame G 4) : c1812.eval F.assign = true := by
  apply local_rup F.assign c1812 [c1, c2, c6, c828]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p828 F) (rfl))))
  · decide +kernel
def c1813 : CNF.Clause Nat := [(86,false), (98,false), (27,false), (50,false), (62,false), (18,false), (22,false)]
theorem p1813 (F : Frame G 4) : c1813.eval F.assign = true := by
  apply local_rup F.assign c1813 [c1, c4, c6, c829]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p829 F) (rfl))))
  · decide +kernel
def c1814 : CNF.Clause Nat := [(38,false), (17,false), (62,false), (29,false), (30,false), (10,false), (98,false), (99,false)]
theorem p1814 (F : Frame G 4) : c1814.eval F.assign = true := by
  apply local_rup F.assign c1814 [c2, c4, c830]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p830 F) (rfl)))
  · decide +kernel
def c1815 : CNF.Clause Nat := [(38,false), (50,false), (62,false), (18,false), (22,false), (11,false), (30,false), (98,false)]
theorem p1815 (F : Frame G 4) : c1815.eval F.assign = true := by
  apply local_rup F.assign c1815 [c4, c6, c831]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p831 F) (rfl)))
  · decide +kernel
def c1816 : CNF.Clause Nat := [(39,false), (50,false), (18,false), (29,false), (87,false), (86,false), (99,false)]
theorem p1816 (F : Frame G 4) : c1816.eval F.assign = true := by
  apply local_rup F.assign c1816 [c1, c2, c6, c832]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p832 F) (rfl))))
  · decide +kernel
def c1817 : CNF.Clause Nat := [(40,false), (18,false), (50,false), (31,false), (99,false), (88,false), (87,false)]
theorem p1817 (F : Frame G 4) : c1817.eval F.assign = true := by
  apply local_rup F.assign c1817 [c1, c2, c3, c833]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p833 F) (rfl))))
  · decide +kernel
def c1818 : CNF.Clause Nat := [(87,false), (88,false), (99,false), (9,false), (5,false), (50,false), (17,false), (15,false), (40,false)]
theorem p1818 (F : Frame G 4) : c1818.eval F.assign = true := by
  apply local_rup F.assign c1818 [c6, c834]
  · exact sat_cons (p6 F) ( sat_cons (p834 F) (rfl))
  · decide +kernel
def c1819 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (7,false), (29,false), (21,false), (19,false), (86,false), (99,false)]
theorem p1819 (F : Frame G 4) : c1819.eval F.assign = true := by
  apply local_rup F.assign c1819 [c6, c835]
  · exact sat_cons (p6 F) ( sat_cons (p835 F) (rfl))
  · decide +kernel
def c1820 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (19,false), (7,false), (29,false), (98,false), (99,false)]
theorem p1820 (F : Frame G 4) : c1820.eval F.assign = true := by
  apply local_rup F.assign c1820 [c4, c6, c836]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p836 F) (rfl)))
  · decide +kernel
def c1821 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (19,false), (18,false), (29,false), (98,false), (99,false)]
theorem p1821 (F : Frame G 4) : c1821.eval F.assign = true := by
  apply local_rup F.assign c1821 [c4, c6, c837]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p837 F) (rfl)))
  · decide +kernel
def c1822 : CNF.Clause Nat := [(18,false), (40,false), (39,false), (6,false), (87,false), (31,false), (99,false)]
theorem p1822 (F : Frame G 4) : c1822.eval F.assign = true := by
  apply local_rup F.assign c1822 [c2, c4, c6, c838]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p838 F) (rfl))))
  · decide +kernel
def c1823 : CNF.Clause Nat := [(7,false), (51,false), (50,false), (33,false), (99,false), (19,false), (87,false)]
theorem p1823 (F : Frame G 4) : c1823.eval F.assign = true := by
  apply local_rup F.assign c1823 [c1, c3, c5, c839]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p839 F) (rfl))))
  · decide +kernel
def c1824 : CNF.Clause Nat := [(15,false), (17,false), (50,false), (51,false), (7,false), (30,false), (98,false), (99,false)]
theorem p1824 (F : Frame G 4) : c1824.eval F.assign = true := by
  apply local_rup F.assign c1824 [c4, c6, c840]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p840 F) (rfl)))
  · decide +kernel
def c1825 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (18,false), (29,false), (33,false), (99,false), (98,false), (87,false)]
theorem p1825 (F : Frame G 4) : c1825.eval F.assign = true := by
  apply local_rup F.assign c1825 [c1, c841]
  · exact sat_cons (p1 F) ( sat_cons (p841 F) (rfl))
  · decide +kernel
def c1826 : CNF.Clause Nat := [(39,false), (27,false), (51,false), (7,false), (87,false), (98,false), (22,false)]
theorem p1826 (F : Frame G 4) : c1826.eval F.assign = true := by
  apply local_rup F.assign c1826 [c3, c4, c5, c842]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p842 F) (rfl))))
  · decide +kernel
def c1827 : CNF.Clause Nat := [(29,false), (51,false), (50,false), (39,false), (87,false), (21,false), (99,false)]
theorem p1827 (F : Frame G 4) : c1827.eval F.assign = true := by
  apply local_rup F.assign c1827 [c1, c4, c5, c843]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p843 F) (rfl))))
  · decide +kernel
def c1828 : CNF.Clause Nat := [(39,false), (38,false), (18,false), (7,false), (87,false), (98,false), (99,false)]
theorem p1828 (F : Frame G 4) : c1828.eval F.assign = true := by
  apply local_rup F.assign c1828 [c3, c2, c4, c844]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p844 F) (rfl))))
  · decide +kernel
def c1829 : CNF.Clause Nat := [(50,false), (6,false), (40,false), (29,false), (33,false), (99,false), (19,false), (87,false)]
theorem p1829 (F : Frame G 4) : c1829.eval F.assign = true := by
  apply local_rup F.assign c1829 [c1, c5, c845]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p845 F) (rfl)))
  · decide +kernel
def c1830 : CNF.Clause Nat := [(87,false), (98,false), (99,false), (33,false), (50,false), (15,false), (40,false)]
theorem p1830 (F : Frame G 4) : c1830.eval F.assign = true := by
  apply local_rup F.assign c1830 [c4, c3, c2, c846]
  · exact sat_cons (p4 F) ( sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p846 F) (rfl))))
  · decide +kernel
def c1831 : CNF.Clause Nat := [(87,false), (98,false), (99,false), (22,false), (38,false), (39,false), (29,false)]
theorem p1831 (F : Frame G 4) : c1831.eval F.assign = true := by
  apply local_rup F.assign c1831 [c4, c2, c3, c847]
  · exact sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p847 F) (rfl))))
  · decide +kernel
def c1832 : CNF.Clause Nat := [(86,false), (98,false), (33,false), (22,false), (18,false), (62,false), (39,false), (38,false)]
theorem p1832 (F : Frame G 4) : c1832.eval F.assign = true := by
  apply local_rup F.assign c1832 [c4, c6, c848]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p848 F) (rfl)))
  · decide +kernel
def c1833 : CNF.Clause Nat := [(38,false), (51,false), (62,false), (17,false), (21,false), (30,false), (86,false), (99,false)]
theorem p1833 (F : Frame G 4) : c1833.eval F.assign = true := by
  apply local_rup F.assign c1833 [c1, c6, c849]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p849 F) (rfl)))
  · decide +kernel
def c1834 : CNF.Clause Nat := [(38,false), (51,false), (18,false), (17,false), (30,false), (10,false), (98,false), (99,false)]
theorem p1834 (F : Frame G 4) : c1834.eval F.assign = true := by
  apply local_rup F.assign c1834 [c3, c4, c850]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p850 F) (rfl)))
  · decide +kernel
def c1835 : CNF.Clause Nat := [(38,false), (50,false), (62,false), (18,false), (21,false), (30,false), (86,false), (99,false)]
theorem p1835 (F : Frame G 4) : c1835.eval F.assign = true := by
  apply local_rup F.assign c1835 [c1, c6, c851]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p851 F) (rfl)))
  · decide +kernel
def c1836 : CNF.Clause Nat := [(38,false), (50,false), (62,false), (18,false), (22,false), (33,false), (30,false), (86,false), (98,false)]
theorem p1836 (F : Frame G 4) : c1836.eval F.assign = true := by
  apply local_rup F.assign c1836 [c1, c852]
  · exact sat_cons (p1 F) ( sat_cons (p852 F) (rfl))
  · decide +kernel
def c1837 : CNF.Clause Nat := [(15,false), (50,false), (62,false), (29,false), (30,false), (10,false), (98,false), (99,false)]
theorem p1837 (F : Frame G 4) : c1837.eval F.assign = true := by
  apply local_rup F.assign c1837 [c2, c4, c853]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p853 F) (rfl)))
  · decide +kernel
def c1838 : CNF.Clause Nat := [(6,false), (50,false), (51,false), (18,false), (21,false), (30,false), (86,false), (99,false)]
theorem p1838 (F : Frame G 4) : c1838.eval F.assign = true := by
  apply local_rup F.assign c1838 [c1, c6, c854]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p854 F) (rfl)))
  · decide +kernel
def c1839 : CNF.Clause Nat := [(7,false), (51,false), (50,false), (17,false), (22,false), (99,false), (86,false), (30,false)]
theorem p1839 (F : Frame G 4) : c1839.eval F.assign = true := by
  apply local_rup F.assign c1839 [c1, c6, c855]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p855 F) (rfl)))
  · decide +kernel
def c1840 : CNF.Clause Nat := [(50,false), (39,false), (7,false), (29,false), (30,false), (87,false), (98,false), (99,false)]
theorem p1840 (F : Frame G 4) : c1840.eval F.assign = true := by
  apply local_rup F.assign c1840 [c2, c1, c856]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p856 F) (rfl)))
  · decide +kernel
def c1841 : CNF.Clause Nat := [(26,false), (50,false), (51,false), (7,false), (19,false), (21,false), (98,false), (99,false)]
theorem p1841 (F : Frame G 4) : c1841.eval F.assign = true := by
  apply local_rup F.assign c1841 [c3, c4, c857]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p857 F) (rfl)))
  · decide +kernel
def c1842 : CNF.Clause Nat := [(39,false), (6,false), (86,false), (99,false), (22,false), (21,false), (27,false), (51,false)]
theorem p1842 (F : Frame G 4) : c1842.eval F.assign = true := by
  apply local_rup F.assign c1842 [c4, c6, c858]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p858 F) (rfl)))
  · decide +kernel
def c1843 : CNF.Clause Nat := [(39,false), (26,false), (30,false), (5,false), (51,false), (18,false), (21,false), (98,false), (99,false)]
theorem p1843 (F : Frame G 4) : c1843.eval F.assign = true := by
  apply local_rup F.assign c1843 [c4, c859]
  · exact sat_cons (p4 F) ( sat_cons (p859 F) (rfl))
  · decide +kernel
def c1844 : CNF.Clause Nat := [(39,false), (30,false), (10,false), (98,false), (99,false), (22,false), (51,false)]
theorem p1844 (F : Frame G 4) : c1844.eval F.assign = true := by
  apply local_rup F.assign c1844 [c3, c4, c2, c860]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p860 F) (rfl))))
  · decide +kernel
def c1845 : CNF.Clause Nat := [(39,false), (86,false), (99,false), (33,false), (21,false), (51,false)]
theorem p1845 (F : Frame G 4) : c1845.eval F.assign = true := by
  apply local_rup F.assign c1845 [c1, c4, c6, c2, c861]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p861 F) (rfl)))))
  · decide +kernel
def c1846 : CNF.Clause Nat := [(30,false), (50,false), (38,false), (40,false), (18,false), (21,false), (98,false), (99,false)]
theorem p1846 (F : Frame G 4) : c1846.eval F.assign = true := by
  apply local_rup F.assign c1846 [c4, c3, c862]
  · exact sat_cons (p4 F) ( sat_cons (p3 F) ( sat_cons (p862 F) (rfl)))
  · decide +kernel
def c1847 : CNF.Clause Nat := [(50,false), (51,false), (40,false), (19,false), (21,false), (98,false), (99,false)]
theorem p1847 (F : Frame G 4) : c1847.eval F.assign = true := by
  apply local_rup F.assign c1847 [c3, c1, c4, c863]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p863 F) (rfl))))
  · decide +kernel
def c1848 : CNF.Clause Nat := [(50,false), (51,false), (40,false), (10,false), (98,false), (86,false), (19,false), (22,false)]
theorem p1848 (F : Frame G 4) : c1848.eval F.assign = true := by
  apply local_rup F.assign c1848 [c3, c1, c864]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p864 F) (rfl)))
  · decide +kernel
def c1849 : CNF.Clause Nat := [(40,false), (51,false), (50,false), (17,false), (19,false), (9,false), (98,false), (33,false)]
theorem p1849 (F : Frame G 4) : c1849.eval F.assign = true := by
  apply local_rup F.assign c1849 [c4, c6, c865]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p865 F) (rfl)))
  · decide +kernel
def c1850 : CNF.Clause Nat := [(19,false), (17,false), (50,false), (51,false), (29,false), (98,false), (99,false)]
theorem p1850 (F : Frame G 4) : c1850.eval F.assign = true := by
  apply local_rup F.assign c1850 [c1, c4, c6, c866]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p866 F) (rfl))))
  · decide +kernel
def c1851 : CNF.Clause Nat := [(99,false), (11,false), (87,false), (39,false), (38,false), (51,false)]
theorem p1851 (F : Frame G 4) : c1851.eval F.assign = true := by
  apply local_rup F.assign c1851 [c5, c4, c6, c3, c867]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p867 F) (rfl)))))
  · decide +kernel
def c1852 : CNF.Clause Nat := [(18,false), (40,false), (39,false), (6,false), (30,false), (98,false), (99,false)]
theorem p1852 (F : Frame G 4) : c1852.eval F.assign = true := by
  apply local_rup F.assign c1852 [c2, c4, c6, c868]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p868 F) (rfl))))
  · decide +kernel
def c1853 : CNF.Clause Nat := [(39,false), (40,false), (51,false), (19,false), (87,false), (10,false), (9,false), (99,false)]
theorem p1853 (F : Frame G 4) : c1853.eval F.assign = true := by
  apply local_rup F.assign c1853 [c3, c2, c869]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p869 F) (rfl)))
  · decide +kernel
def c1854 : CNF.Clause Nat := [(51,false), (29,false), (39,false), (87,false), (98,false), (22,false)]
theorem p1854 (F : Frame G 4) : c1854.eval F.assign = true := by
  apply local_rup F.assign c1854 [c3, c1, c4, c5, c870]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p870 F) (rfl)))))
  · decide +kernel
def c1855 : CNF.Clause Nat := [(27,false), (38,false), (40,false), (7,false), (19,false), (21,false), (98,false), (99,false)]
theorem p1855 (F : Frame G 4) : c1855.eval F.assign = true := by
  apply local_rup F.assign c1855 [c3, c4, c871]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p871 F) (rfl)))
  · decide +kernel
def c1856 : CNF.Clause Nat := [(50,false), (21,false), (98,false), (99,false), (11,false), (30,false), (26,false), (40,false)]
theorem p1856 (F : Frame G 4) : c1856.eval F.assign = true := by
  apply local_rup F.assign c1856 [c2, c4, c872]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p872 F) (rfl)))
  · decide +kernel
def c1857 : CNF.Clause Nat := [(50,false), (27,false), (29,false), (40,false), (86,false), (98,false), (21,false), (22,false)]
theorem p1857 (F : Frame G 4) : c1857.eval F.assign = true := by
  apply local_rup F.assign c1857 [c1, c4, c873]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p873 F) (rfl)))
  · decide +kernel
def c1858 : CNF.Clause Nat := [(38,false), (40,false), (7,false), (6,false), (30,false), (86,false), (98,false), (21,false), (22,false)]
theorem p1858 (F : Frame G 4) : c1858.eval F.assign = true := by
  apply local_rup F.assign c1858 [c3, c874]
  · exact sat_cons (p3 F) ( sat_cons (p874 F) (rfl))
  · decide +kernel
def c1859 : CNF.Clause Nat := [(29,false), (40,false), (38,false), (5,false), (86,false), (98,false), (21,false), (22,false)]
theorem p1859 (F : Frame G 4) : c1859.eval F.assign = true := by
  apply local_rup F.assign c1859 [c3, c4, c875]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p875 F) (rfl)))
  · decide +kernel
def c1860 : CNF.Clause Nat := [(50,false), (15,false), (40,false), (29,false), (30,false), (10,false), (98,false), (99,false)]
theorem p1860 (F : Frame G 4) : c1860.eval F.assign = true := by
  apply local_rup F.assign c1860 [c2, c4, c876]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p876 F) (rfl)))
  · decide +kernel
def c1861 : CNF.Clause Nat := [(86,false), (98,false), (33,false), (22,false), (17,false), (50,false), (38,false), (40,false)]
theorem p1861 (F : Frame G 4) : c1861.eval F.assign = true := by
  apply local_rup F.assign c1861 [c4, c6, c877]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p877 F) (rfl)))
  · decide +kernel
def c1862 : CNF.Clause Nat := [(6,false), (86,false), (98,false), (33,false), (22,false), (38,false), (40,false)]
theorem p1862 (F : Frame G 4) : c1862.eval F.assign = true := by
  apply local_rup F.assign c1862 [c4, c6, c2, c878]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p878 F) (rfl))))
  · decide +kernel
def c1863 : CNF.Clause Nat := [(27,false), (38,false), (40,false), (7,false), (86,false), (21,false), (110,false)]
theorem p1863 (F : Frame G 4) : c1863.eval F.assign = true := by
  apply local_rup F.assign c1863 [c3, c4, c5, c879]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p879 F) (rfl))))
  · decide +kernel
def c1864 : CNF.Clause Nat := [(50,false), (38,false), (40,false), (7,false), (86,false), (21,false), (110,false)]
theorem p1864 (F : Frame G 4) : c1864.eval F.assign = true := by
  apply local_rup F.assign c1864 [c3, c4, c5, c880]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p880 F) (rfl))))
  · decide +kernel
def c1865 : CNF.Clause Nat := [(86,false), (99,false), (110,false), (50,false), (15,false), (40,false)]
theorem p1865 (F : Frame G 4) : c1865.eval F.assign = true := by
  apply local_rup F.assign c1865 [c4, c6, c3, c2, c881]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p881 F) (rfl)))))
  · decide +kernel
def c1866 : CNF.Clause Nat := [(86,false), (99,false), (110,false), (21,false), (50,false), (26,false), (40,false)]
theorem p1866 (F : Frame G 4) : c1866.eval F.assign = true := by
  apply local_rup F.assign c1866 [c4, c2, c3, c882]
  · exact sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p882 F) (rfl))))
  · decide +kernel
def c1867 : CNF.Clause Nat := [(38,false), (40,false), (29,false), (6,false), (19,false), (98,false), (110,false)]
theorem p1867 (F : Frame G 4) : c1867.eval F.assign = true := by
  apply local_rup F.assign c1867 [c3, c4, c5, c883]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p883 F) (rfl))))
  · decide +kernel
def c1868 : CNF.Clause Nat := [(7,false), (18,false), (50,false), (30,false), (86,false), (98,false), (110,false)]
theorem p1868 (F : Frame G 4) : c1868.eval F.assign = true := by
  apply local_rup F.assign c1868 [c1, c2, c3, c884]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p884 F) (rfl))))
  · decide +kernel
def c1869 : CNF.Clause Nat := [(50,false), (5,false), (40,false), (18,false), (22,false), (99,false), (86,false), (30,false)]
theorem p1869 (F : Frame G 4) : c1869.eval F.assign = true := by
  apply local_rup F.assign c1869 [c1, c6, c885]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p885 F) (rfl)))
  · decide +kernel
def c1870 : CNF.Clause Nat := [(50,false), (38,false), (40,false), (7,false), (19,false), (98,false), (110,false)]
theorem p1870 (F : Frame G 4) : c1870.eval F.assign = true := by
  apply local_rup F.assign c1870 [c3, c4, c5, c886]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p886 F) (rfl))))
  · decide +kernel
def c1871 : CNF.Clause Nat := [(29,false), (40,false), (38,false), (5,false), (19,false), (98,false), (110,false)]
theorem p1871 (F : Frame G 4) : c1871.eval F.assign = true := by
  apply local_rup F.assign c1871 [c3, c4, c5, c887]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p887 F) (rfl))))
  · decide +kernel
def c1872 : CNF.Clause Nat := [(29,false), (40,false), (38,false), (22,false), (110,false), (10,false), (86,false)]
theorem p1872 (F : Frame G 4) : c1872.eval F.assign = true := by
  apply local_rup F.assign c1872 [c3, c2, c4, c888]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p888 F) (rfl))))
  · decide +kernel
def c1873 : CNF.Clause Nat := [(50,false), (6,false), (40,false), (29,false), (30,false), (86,false), (98,false), (110,false)]
theorem p1873 (F : Frame G 4) : c1873.eval F.assign = true := by
  apply local_rup F.assign c1873 [c2, c1, c889]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p889 F) (rfl)))
  · decide +kernel
def c1874 : CNF.Clause Nat := [(50,false), (38,false), (40,false), (18,false), (19,false), (9,false), (98,false), (110,false)]
theorem p1874 (F : Frame G 4) : c1874.eval F.assign = true := by
  apply local_rup F.assign c1874 [c3, c4, c890]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p890 F) (rfl)))
  · decide +kernel
def c1875 : CNF.Clause Nat := [(30,false), (86,false), (98,false), (110,false), (11,false), (7,false), (40,false), (15,false), (50,false)]
theorem p1875 (F : Frame G 4) : c1875.eval F.assign = true := by
  apply local_rup F.assign c1875 [c2, c891]
  · exact sat_cons (p2 F) ( sat_cons (p891 F) (rfl))
  · decide +kernel
def c1876 : CNF.Clause Nat := [(86,false), (31,false), (29,false), (40,false), (38,false), (50,false), (17,false), (21,false), (110,false)]
theorem p1876 (F : Frame G 4) : c1876.eval F.assign = true := by
  apply local_rup F.assign c1876 [c4, c892]
  · exact sat_cons (p4 F) ( sat_cons (p892 F) (rfl))
  · decide +kernel
def c1877 : CNF.Clause Nat := [(29,false), (62,false), (50,false), (38,false), (86,false), (21,false), (110,false)]
theorem p1877 (F : Frame G 4) : c1877.eval F.assign = true := by
  apply local_rup F.assign c1877 [c1, c4, c5, c893]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p893 F) (rfl))))
  · decide +kernel
def c1878 : CNF.Clause Nat := [(29,false), (62,false), (50,false), (38,false), (15,false), (22,false), (11,false), (86,false), (98,false)]
theorem p1878 (F : Frame G 4) : c1878.eval F.assign = true := by
  apply local_rup F.assign c1878 [c4, c894]
  · exact sat_cons (p4 F) ( sat_cons (p894 F) (rfl))
  · decide +kernel
def c1879 : CNF.Clause Nat := [(38,false), (40,false), (29,false), (6,false), (11,false), (110,false), (87,false), (86,false)]
theorem p1879 (F : Frame G 4) : c1879.eval F.assign = true := by
  apply local_rup F.assign c1879 [c2, c3, c895]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p895 F) (rfl)))
  · decide +kernel
def c1880 : CNF.Clause Nat := [(50,false), (6,false), (40,false), (29,false), (87,false), (86,false), (99,false)]
theorem p1880 (F : Frame G 4) : c1880.eval F.assign = true := by
  apply local_rup F.assign c1880 [c2, c1, c6, c896]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p896 F) (rfl))))
  · decide +kernel
def c1881 : CNF.Clause Nat := [(5,false), (17,false), (62,false), (29,false), (87,false), (86,false), (99,false)]
theorem p1881 (F : Frame G 4) : c1881.eval F.assign = true := by
  apply local_rup F.assign c1881 [c1, c2, c6, c897]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p897 F) (rfl))))
  · decide +kernel
def c1882 : CNF.Clause Nat := [(50,false), (62,false), (29,false), (26,false), (86,false), (21,false), (110,false)]
theorem p1882 (F : Frame G 4) : c1882.eval F.assign = true := by
  apply local_rup F.assign c1882 [c1, c4, c5, c898]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p898 F) (rfl))))
  · decide +kernel
def c1883 : CNF.Clause Nat := [(50,false), (5,false), (40,false), (18,false), (19,false), (86,false), (98,false), (110,false)]
theorem p1883 (F : Frame G 4) : c1883.eval F.assign = true := by
  apply local_rup F.assign c1883 [c3, c1, c899]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p899 F) (rfl)))
  · decide +kernel
def c1884 : CNF.Clause Nat := [(40,false), (29,false), (50,false), (5,false), (19,false), (98,false), (110,false)]
theorem p1884 (F : Frame G 4) : c1884.eval F.assign = true := by
  apply local_rup F.assign c1884 [c3, c4, c5, c900]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p900 F) (rfl))))
  · decide +kernel
def c1885 : CNF.Clause Nat := [(40,false), (29,false), (50,false), (22,false), (110,false), (10,false), (86,false)]
theorem p1885 (F : Frame G 4) : c1885.eval F.assign = true := by
  apply local_rup F.assign c1885 [c3, c2, c4, c901]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p901 F) (rfl))))
  · decide +kernel
def c1886 : CNF.Clause Nat := [(50,false), (62,false), (40,false), (26,false), (31,false), (19,false), (10,false), (110,false)]
theorem p1886 (F : Frame G 4) : c1886.eval F.assign = true := by
  apply local_rup F.assign c1886 [c5, c4, c902]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p902 F) (rfl)))
  · decide +kernel
def c1887 : CNF.Clause Nat := [(50,false), (15,false), (40,false), (7,false), (11,false), (110,false), (87,false), (86,false)]
theorem p1887 (F : Frame G 4) : c1887.eval F.assign = true := by
  apply local_rup F.assign c1887 [c3, c2, c903]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p903 F) (rfl)))
  · decide +kernel
def c1888 : CNF.Clause Nat := [(62,false), (40,false), (38,false), (22,false), (11,false), (86,false), (98,false)]
theorem p1888 (F : Frame G 4) : c1888.eval F.assign = true := by
  apply local_rup F.assign c1888 [c3, c2, c4, c904]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p904 F) (rfl))))
  · decide +kernel
def c1889 : CNF.Clause Nat := [(87,false), (33,false), (99,false), (17,false), (62,false), (40,false), (38,false)]
theorem p1889 (F : Frame G 4) : c1889.eval F.assign = true := by
  apply local_rup F.assign c1889 [c4, c6, c5, c905]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p905 F) (rfl))))
  · decide +kernel
def c1890 : CNF.Clause Nat := [(51,false), (40,false), (6,false), (30,false), (87,false), (98,false), (99,false)]
theorem p1890 (F : Frame G 4) : c1890.eval F.assign = true := by
  apply local_rup F.assign c1890 [c2, c1, c3, c906]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p906 F) (rfl))))
  · decide +kernel
def c1891 : CNF.Clause Nat := [(40,false), (51,false), (17,false), (87,false), (86,false), (99,false)]
theorem p1891 (F : Frame G 4) : c1891.eval F.assign = true := by
  apply local_rup F.assign c1891 [c1, c2, c3, c6, c907]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p907 F) (rfl)))))
  · decide +kernel
def c1892 : CNF.Clause Nat := [(21,false), (87,false), (86,false), (99,false), (33,false), (6,false), (40,false)]
theorem p1892 (F : Frame G 4) : c1892.eval F.assign = true := by
  apply local_rup F.assign c1892 [c2, c3, c1, c908]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p908 F) (rfl))))
  · decide +kernel
def c1893 : CNF.Clause Nat := [(19,false), (87,false), (98,false), (99,false), (11,false), (5,false), (50,false), (26,false), (40,false)]
theorem p1893 (F : Frame G 4) : c1893.eval F.assign = true := by
  apply local_rup F.assign c1893 [c3, c909]
  · exact sat_cons (p3 F) ( sat_cons (p909 F) (rfl))
  · decide +kernel
def c1894 : CNF.Clause Nat := [(29,false), (40,false), (39,false), (50,false), (19,false), (87,false), (10,false), (9,false), (99,false)]
theorem p1894 (F : Frame G 4) : c1894.eval F.assign = true := by
  apply local_rup F.assign c1894 [c2, c910]
  · exact sat_cons (p2 F) ( sat_cons (p910 F) (rfl))
  · decide +kernel
def c1895 : CNF.Clause Nat := [(29,false), (40,false), (39,false), (50,false), (5,false), (87,false), (21,false), (99,false)]
theorem p1895 (F : Frame G 4) : c1895.eval F.assign = true := by
  apply local_rup F.assign c1895 [c4, c5, c911]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p911 F) (rfl)))
  · decide +kernel
def c1896 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (7,false), (29,false), (87,false), (19,false), (99,false)]
theorem p1896 (F : Frame G 4) : c1896.eval F.assign = true := by
  apply local_rup F.assign c1896 [c6, c5, c912]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p912 F) (rfl)))
  · decide +kernel
def c1897 : CNF.Clause Nat := [(50,false), (15,false), (40,false), (7,false), (87,false), (98,false), (99,false)]
theorem p1897 (F : Frame G 4) : c1897.eval F.assign = true := by
  apply local_rup F.assign c1897 [c3, c2, c4, c913]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p913 F) (rfl))))
  · decide +kernel
def c1898 : CNF.Clause Nat := [(39,false), (40,false), (7,false), (5,false), (19,false), (87,false), (98,false), (99,false)]
theorem p1898 (F : Frame G 4) : c1898.eval F.assign = true := by
  apply local_rup F.assign c1898 [c3, c2, c914]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p914 F) (rfl)))
  · decide +kernel
def c1899 : CNF.Clause Nat := [(50,false), (39,false), (40,false), (7,false), (30,false), (98,false), (99,false)]
theorem p1899 (F : Frame G 4) : c1899.eval F.assign = true := by
  apply local_rup F.assign c1899 [c2, c4, c6, c915]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p915 F) (rfl))))
  · decide +kernel
def c1900 : CNF.Clause Nat := [(50,false), (39,false), (40,false), (29,false), (30,false), (87,false), (10,false), (9,false), (99,false)]
theorem p1900 (F : Frame G 4) : c1900.eval F.assign = true := by
  apply local_rup F.assign c1900 [c2, c916]
  · exact sat_cons (p2 F) ( sat_cons (p916 F) (rfl))
  · decide +kernel
def c1901 : CNF.Clause Nat := [(50,false), (51,false), (40,false), (30,false), (33,false), (99,false), (21,false)]
theorem p1901 (F : Frame G 4) : c1901.eval F.assign = true := by
  apply local_rup F.assign c1901 [c1, c4, c5, c917]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p917 F) (rfl))))
  · decide +kernel
def c1902 : CNF.Clause Nat := [(40,false), (7,false), (19,false), (50,false), (98,false), (99,false)]
theorem p1902 (F : Frame G 4) : c1902.eval F.assign = true := by
  apply local_rup F.assign c1902 [c4, c2, c3, c6, c918]
  · exact sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p918 F) (rfl)))))
  · decide +kernel
def c1903 : CNF.Clause Nat := [(27,false), (62,false), (40,false), (15,false), (19,false), (10,false), (98,false), (99,false)]
theorem p1903 (F : Frame G 4) : c1903.eval F.assign = true := by
  apply local_rup F.assign c1903 [c3, c4, c919]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p919 F) (rfl)))
  · decide +kernel
def c1904 : CNF.Clause Nat := [(50,false), (29,false), (40,false), (87,false), (110,false), (22,false)]
theorem p1904 (F : Frame G 4) : c1904.eval F.assign = true := by
  apply local_rup F.assign c1904 [c3, c1, c4, c5, c920]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p920 F) (rfl)))))
  · decide +kernel
def c1905 : CNF.Clause Nat := [(39,false), (40,false), (18,false), (27,false), (30,false), (9,false), (98,false), (110,false)]
theorem p1905 (F : Frame G 4) : c1905.eval F.assign = true := by
  apply local_rup F.assign c1905 [c2, c4, c921]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p921 F) (rfl)))
  · decide +kernel
def c1906 : CNF.Clause Nat := [(50,false), (39,false), (40,false), (7,false), (30,false), (31,false), (99,false), (110,false)]
theorem p1906 (F : Frame G 4) : c1906.eval F.assign = true := by
  apply local_rup F.assign c1906 [c2, c4, c922]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p922 F) (rfl)))
  · decide +kernel
def c1907 : CNF.Clause Nat := [(50,false), (39,false), (40,false), (7,false), (9,false), (99,false), (33,false), (30,false), (87,false)]
theorem p1907 (F : Frame G 4) : c1907.eval F.assign = true := by
  apply local_rup F.assign c1907 [c2, c923]
  · exact sat_cons (p2 F) ( sat_cons (p923 F) (rfl))
  · decide +kernel
def c1908 : CNF.Clause Nat := [(18,false), (29,false), (39,false), (86,false), (98,false), (110,false)]
theorem p1908 (F : Frame G 4) : c1908.eval F.assign = true := by
  apply local_rup F.assign c1908 [c2, c3, c1, c4, c924]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p924 F) (rfl)))))
  · decide +kernel
def c1909 : CNF.Clause Nat := [(50,false), (6,false), (40,false), (29,false), (98,false), (86,false), (88,false)]
theorem p1909 (F : Frame G 4) : c1909.eval F.assign = true := by
  apply local_rup F.assign c1909 [c2, c1, c6, c925]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p925 F) (rfl))))
  · decide +kernel
def c1910 : CNF.Clause Nat := [(17,false), (50,false), (38,false), (40,false), (7,false), (86,false), (31,false), (110,false)]
theorem p1910 (F : Frame G 4) : c1910.eval F.assign = true := by
  apply local_rup F.assign c1910 [c4, c6, c926]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p926 F) (rfl)))
  · decide +kernel
def c1911 : CNF.Clause Nat := [(17,false), (38,false), (26,false), (29,false), (7,false), (10,false), (110,false), (88,false), (86,false)]
theorem p1911 (F : Frame G 4) : c1911.eval F.assign = true := by
  apply local_rup F.assign c1911 [c2, c927]
  · exact sat_cons (p2 F) ( sat_cons (p927 F) (rfl))
  · decide +kernel
def c1912 : CNF.Clause Nat := [(86,false), (88,false), (110,false), (50,false), (5,false), (40,false)]
theorem p1912 (F : Frame G 4) : c1912.eval F.assign = true := by
  apply local_rup F.assign c1912 [c5, c6, c3, c1, c928]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p928 F) (rfl)))))
  · decide +kernel
def c1913 : CNF.Clause Nat := [(86,false), (6,false), (50,false), (38,false), (40,false), (29,false), (110,false)]
theorem p1913 (F : Frame G 4) : c1913.eval F.assign = true := by
  apply local_rup F.assign c1913 [c5, c4, c6, c929]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p929 F) (rfl))))
  · decide +kernel
def c1914 : CNF.Clause Nat := [(17,false), (38,false), (40,false), (7,false), (86,false), (99,false), (33,false)]
theorem p1914 (F : Frame G 4) : c1914.eval F.assign = true := by
  apply local_rup F.assign c1914 [c2, c4, c6, c930]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p930 F) (rfl))))
  · decide +kernel
def c1915 : CNF.Clause Nat := [(86,false), (6,false), (50,false), (51,false), (40,false), (26,false), (110,false)]
theorem p1915 (F : Frame G 4) : c1915.eval F.assign = true := by
  apply local_rup F.assign c1915 [c5, c4, c6, c931]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p931 F) (rfl))))
  · decide +kernel
def c1916 : CNF.Clause Nat := [(40,false), (18,false), (50,false), (6,false), (86,false), (99,false), (33,false)]
theorem p1916 (F : Frame G 4) : c1916.eval F.assign = true := by
  apply local_rup F.assign c1916 [c2, c4, c6, c932]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p932 F) (rfl))))
  · decide +kernel
def c1917 : CNF.Clause Nat := [(38,false), (50,false), (29,false), (18,false), (86,false), (10,false), (110,false)]
theorem p1917 (F : Frame G 4) : c1917.eval F.assign = true := by
  apply local_rup F.assign c1917 [c3, c5, c4, c933]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p933 F) (rfl))))
  · decide +kernel
def c1918 : CNF.Clause Nat := [(110,false), (99,false), (86,false), (40,false), (18,false), (50,false)]
theorem p1918 (F : Frame G 4) : c1918.eval F.assign = true := by
  apply local_rup F.assign c1918 [c6, c4, c1, c2, c934]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p934 F) (rfl)))))
  · decide +kernel
def c1919 : CNF.Clause Nat := [(17,false), (50,false), (51,false), (40,false), (86,false), (31,false), (110,false)]
theorem p1919 (F : Frame G 4) : c1919.eval F.assign = true := by
  apply local_rup F.assign c1919 [c1, c4, c6, c935]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p935 F) (rfl))))
  · decide +kernel
def c1920 : CNF.Clause Nat := [(17,false), (51,false), (40,false), (86,false), (99,false), (33,false)]
theorem p1920 (F : Frame G 4) : c1920.eval F.assign = true := by
  apply local_rup F.assign c1920 [c2, c1, c4, c6, c936]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p936 F) (rfl)))))
  · decide +kernel
def c1921 : CNF.Clause Nat := [(27,false), (98,false), (86,false), (88,false), (11,false), (39,false), (62,false)]
theorem p1921 (F : Frame G 4) : c1921.eval F.assign = true := by
  apply local_rup F.assign c1921 [c2, c6, c1, c937]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p937 F) (rfl))))
  · decide +kernel
def c1922 : CNF.Clause Nat := [(31,false), (98,false), (110,false), (88,false), (19,false), (5,false), (39,false), (62,false)]
theorem p1922 (F : Frame G 4) : c1922.eval F.assign = true := by
  apply local_rup F.assign c1922 [c2, c1, c938]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p938 F) (rfl)))
  · decide +kernel
def c1923 : CNF.Clause Nat := [(98,false), (50,false), (39,false), (40,false), (7,false), (88,false)]
theorem p1923 (F : Frame G 4) : c1923.eval F.assign = true := by
  apply local_rup F.assign c1923 [c6, c5, c2, c4, c939]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p939 F) (rfl)))))
  · decide +kernel
def c1924 : CNF.Clause Nat := [(38,false), (51,false), (29,false), (17,false), (86,false), (87,false), (110,false)]
theorem p1924 (F : Frame G 4) : c1924.eval F.assign = true := by
  apply local_rup F.assign c1924 [c1, c3, c5, c940]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p940 F) (rfl))))
  · decide +kernel
def c1925 : CNF.Clause Nat := [(86,false), (99,false), (110,false), (27,false), (17,false), (39,false), (40,false)]
theorem p1925 (F : Frame G 4) : c1925.eval F.assign = true := by
  apply local_rup F.assign c1925 [c4, c6, c2, c941]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p941 F) (rfl))))
  · decide +kernel
def c1926 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (18,false), (29,false), (110,false), (11,false), (86,false)]
theorem p1926 (F : Frame G 4) : c1926.eval F.assign = true := by
  apply local_rup F.assign c1926 [c6, c4, c942]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p942 F) (rfl)))
  · decide +kernel
def c1927 : CNF.Clause Nat := [(5,false), (86,false), (99,false), (110,false), (17,false), (15,false), (40,false)]
theorem p1927 (F : Frame G 4) : c1927.eval F.assign = true := by
  apply local_rup F.assign c1927 [c4, c6, c3, c943]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p943 F) (rfl))))
  · decide +kernel
def c1928 : CNF.Clause Nat := [(5,false), (86,false), (99,false), (110,false), (21,false), (17,false), (26,false), (40,false)]
theorem p1928 (F : Frame G 4) : c1928.eval F.assign = true := by
  apply local_rup F.assign c1928 [c4, c3, c944]
  · exact sat_cons (p4 F) ( sat_cons (p3 F) ( sat_cons (p944 F) (rfl)))
  · decide +kernel
def c1929 : CNF.Clause Nat := [(39,false), (29,false), (51,false), (5,false), (86,false), (21,false), (110,false)]
theorem p1929 (F : Frame G 4) : c1929.eval F.assign = true := by
  apply local_rup F.assign c1929 [c3, c4, c5, c945]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p945 F) (rfl))))
  · decide +kernel
def c1930 : CNF.Clause Nat := [(39,false), (38,false), (5,false), (7,false), (18,false), (22,false), (110,false), (98,false), (86,false)]
theorem p1930 (F : Frame G 4) : c1930.eval F.assign = true := by
  apply local_rup F.assign c1930 [c3, c946]
  · exact sat_cons (p3 F) ( sat_cons (p946 F) (rfl))
  · decide +kernel
def c1931 : CNF.Clause Nat := [(110,false), (99,false), (86,false), (19,false), (51,false), (7,false), (39,false)]
theorem p1931 (F : Frame G 4) : c1931.eval F.assign = true := by
  apply local_rup F.assign c1931 [c6, c2, c1, c947]
  · exact sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p947 F) (rfl))))
  · decide +kernel
def c1932 : CNF.Clause Nat := [(39,false), (40,false), (51,false), (5,false), (86,false), (21,false), (110,false)]
theorem p1932 (F : Frame G 4) : c1932.eval F.assign = true := by
  apply local_rup F.assign c1932 [c3, c4, c5, c948]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p948 F) (rfl))))
  · decide +kernel
def c1933 : CNF.Clause Nat := [(39,false), (38,false), (18,false), (7,false), (86,false), (99,false), (110,false)]
theorem p1933 (F : Frame G 4) : c1933.eval F.assign = true := by
  apply local_rup F.assign c1933 [c3, c2, c4, c949]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p949 F) (rfl))))
  · decide +kernel
def c1934 : CNF.Clause Nat := [(38,false), (39,false), (29,false), (7,false), (10,false), (110,false), (88,false), (86,false)]
theorem p1934 (F : Frame G 4) : c1934.eval F.assign = true := by
  apply local_rup F.assign c1934 [c2, c3, c950]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p950 F) (rfl)))
  · decide +kernel
def c1935 : CNF.Clause Nat := [(17,false), (39,false), (40,false), (7,false), (86,false), (31,false), (110,false)]
theorem p1935 (F : Frame G 4) : c1935.eval F.assign = true := by
  apply local_rup F.assign c1935 [c2, c4, c6, c951]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p951 F) (rfl))))
  · decide +kernel
def c1936 : CNF.Clause Nat := [(39,false), (40,false), (7,false), (5,false), (86,false), (87,false), (110,false)]
theorem p1936 (F : Frame G 4) : c1936.eval F.assign = true := by
  apply local_rup F.assign c1936 [c3, c2, c5, c952]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p952 F) (rfl))))
  · decide +kernel
def c1937 : CNF.Clause Nat := [(5,false), (39,false), (17,false), (18,false), (29,false), (110,false), (88,false), (86,false)]
theorem p1937 (F : Frame G 4) : c1937.eval F.assign = true := by
  apply local_rup F.assign c1937 [c1, c6, c953]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p953 F) (rfl)))
  · decide +kernel
def c1938 : CNF.Clause Nat := [(38,false), (39,false), (29,false), (7,false), (9,false), (86,false), (19,false), (21,false), (110,false)]
theorem p1938 (F : Frame G 4) : c1938.eval F.assign = true := by
  apply local_rup F.assign c1938 [c3, c954]
  · exact sat_cons (p3 F) ( sat_cons (p954 F) (rfl))
  · decide +kernel
def c1939 : CNF.Clause Nat := [(38,false), (39,false), (17,false), (9,false), (7,false), (29,false), (30,false), (88,false), (110,false)]
theorem p1939 (F : Frame G 4) : c1939.eval F.assign = true := by
  apply local_rup F.assign c1939 [c5, c955]
  · exact sat_cons (p5 F) ( sat_cons (p955 F) (rfl))
  · decide +kernel
def c1940 : CNF.Clause Nat := [(18,false), (40,false), (39,false), (6,false), (11,false), (110,false), (30,false), (86,false)]
theorem p1940 (F : Frame G 4) : c1940.eval F.assign = true := by
  apply local_rup F.assign c1940 [c2, c6, c957]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p957 F) (rfl)))
  · decide +kernel
def c1941 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (9,false), (86,false), (19,false), (18,false), (29,false), (110,false)]
theorem p1941 (F : Frame G 4) : c1941.eval F.assign = true := by
  apply local_rup F.assign c1941 [c6, c958]
  · exact sat_cons (p6 F) ( sat_cons (p958 F) (rfl))
  · decide +kernel
def c1942 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (7,false), (18,false), (31,false), (87,false), (88,false)]
theorem p1942 (F : Frame G 4) : c1942.eval F.assign = true := by
  apply local_rup F.assign c1942 [c5, c6, c959]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p959 F) (rfl)))
  · decide +kernel
def c1943 : CNF.Clause Nat := [(86,false), (99,false), (110,false), (27,false), (18,false), (62,false)]
theorem p1943 (F : Frame G 4) : c1943.eval F.assign = true := by
  apply local_rup F.assign c1943 [c1, c4, c6, c2, c960]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p960 F) (rfl)))))
  · decide +kernel
def c1944 : CNF.Clause Nat := [(39,false), (50,false), (5,false), (30,false), (29,false), (18,false), (99,false), (110,false)]
theorem p1944 (F : Frame G 4) : c1944.eval F.assign = true := by
  apply local_rup F.assign c1944 [c4, c5, c961]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p961 F) (rfl)))
  · decide +kernel
def c1945 : CNF.Clause Nat := [(39,false), (50,false), (18,false), (29,false), (30,false), (9,false), (99,false), (110,false)]
theorem p1945 (F : Frame G 4) : c1945.eval F.assign = true := by
  apply local_rup F.assign c1945 [c2, c4, c962]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p962 F) (rfl)))
  · decide +kernel
def c1946 : CNF.Clause Nat := [(39,false), (50,false), (18,false), (29,false), (30,false), (9,false), (98,false), (110,false)]
theorem p1946 (F : Frame G 4) : c1946.eval F.assign = true := by
  apply local_rup F.assign c1946 [c2, c4, c963]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p963 F) (rfl)))
  · decide +kernel
def c1947 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (21,false), (18,false), (7,false), (9,false), (86,false), (88,false)]
theorem p1947 (F : Frame G 4) : c1947.eval F.assign = true := by
  apply local_rup F.assign c1947 [c6, c964]
  · exact sat_cons (p6 F) ( sat_cons (p964 F) (rfl))
  · decide +kernel
def c1948 : CNF.Clause Nat := [(17,false), (50,false), (51,false), (40,false), (30,false), (31,false), (98,false), (110,false)]
theorem p1948 (F : Frame G 4) : c1948.eval F.assign = true := by
  apply local_rup F.assign c1948 [c1, c4, c965]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p965 F) (rfl)))
  · decide +kernel
def c1949 : CNF.Clause Nat := [(51,false), (62,false), (26,false), (88,false), (99,false), (98,false)]
theorem p1949 (F : Frame G 4) : c1949.eval F.assign = true := by
  apply local_rup F.assign c1949 [c2, c3, c1, c4, c966]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p966 F) (rfl)))))
  · decide +kernel
def c1950 : CNF.Clause Nat := [(86,false), (87,false), (110,false), (11,false), (38,false), (50,false), (29,false)]
theorem p1950 (F : Frame G 4) : c1950.eval F.assign = true := by
  apply local_rup F.assign c1950 [c5, c1, c3, c967]
  · exact sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p967 F) (rfl))))
  · decide +kernel
def c1951 : CNF.Clause Nat := [(39,false), (40,false), (51,false), (86,false), (10,false), (110,false)]
theorem p1951 (F : Frame G 4) : c1951.eval F.assign = true := by
  apply local_rup F.assign c1951 [c3, c2, c5, c4, c968]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p968 F) (rfl)))))
  · decide +kernel
def c1952 : CNF.Clause Nat := [(9,false), (86,false), (87,false), (33,false), (22,false), (38,false), (39,false), (62,false)]
theorem p1952 (F : Frame G 4) : c1952.eval F.assign = true := by
  apply local_rup F.assign c1952 [c6, c2, c969]
  · exact sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p969 F) (rfl)))
  · decide +kernel
def c1953 : CNF.Clause Nat := [(7,false), (62,false), (50,false), (31,false), (30,false), (87,false), (110,false)]
theorem p1953 (F : Frame G 4) : c1953.eval F.assign = true := by
  apply local_rup F.assign c1953 [c1, c2, c5, c970]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p970 F) (rfl))))
  · decide +kernel
def c1954 : CNF.Clause Nat := [(7,false), (62,false), (50,false), (19,false), (87,false), (98,false), (31,false), (33,false)]
theorem p1954 (F : Frame G 4) : c1954.eval F.assign = true := by
  apply local_rup F.assign c1954 [c1, c2, c971]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p971 F) (rfl)))
  · decide +kernel
def c1955 : CNF.Clause Nat := [(7,false), (62,false), (50,false), (98,false), (87,false), (30,false), (33,false)]
theorem p1955 (F : Frame G 4) : c1955.eval F.assign = true := by
  apply local_rup F.assign c1955 [c1, c2, c5, c972]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p972 F) (rfl))))
  · decide +kernel
def c1956 : CNF.Clause Nat := [(87,false), (88,false), (99,false), (15,false), (5,false), (50,false), (62,false)]
theorem p1956 (F : Frame G 4) : c1956.eval F.assign = true := by
  apply local_rup F.assign c1956 [c6, c5, c1, c973]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p973 F) (rfl))))
  · decide +kernel
def c1957 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (18,false), (29,false), (31,false), (99,false), (88,false), (87,false)]
theorem p1957 (F : Frame G 4) : c1957.eval F.assign = true := by
  apply local_rup F.assign c1957 [c1, c974]
  · exact sat_cons (p1 F) ( sat_cons (p974 F) (rfl))
  · decide +kernel
def c1958 : CNF.Clause Nat := [(6,false), (50,false), (51,false), (18,false), (99,false), (110,false), (30,false)]
theorem p1958 (F : Frame G 4) : c1958.eval F.assign = true := by
  apply local_rup F.assign c1958 [c1, c5, c6, c975]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p975 F) (rfl))))
  · decide +kernel
def c1959 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (18,false), (29,false), (30,false), (87,false), (110,false), (99,false)]
theorem p1959 (F : Frame G 4) : c1959.eval F.assign = true := by
  apply local_rup F.assign c1959 [c1, c976]
  · exact sat_cons (p1 F) ( sat_cons (p976 F) (rfl))
  · decide +kernel
def c1960 : CNF.Clause Nat := [(38,false), (50,false), (29,false), (18,false), (19,false), (87,false), (110,false), (99,false)]
theorem p1960 (F : Frame G 4) : c1960.eval F.assign = true := by
  apply local_rup F.assign c1960 [c1, c3, c977]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p977 F) (rfl)))
  · decide +kernel
def c1961 : CNF.Clause Nat := [(7,false), (51,false), (50,false), (31,false), (99,false), (22,false), (19,false), (87,false)]
theorem p1961 (F : Frame G 4) : c1961.eval F.assign = true := by
  apply local_rup F.assign c1961 [c1, c3, c978]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p978 F) (rfl)))
  · decide +kernel
def c1962 : CNF.Clause Nat := [(50,false), (38,false), (15,false), (18,false), (7,false), (87,false), (110,false), (99,false)]
theorem p1962 (F : Frame G 4) : c1962.eval F.assign = true := by
  apply local_rup F.assign c1962 [c3, c4, c979]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p979 F) (rfl)))
  · decide +kernel
def c1963 : CNF.Clause Nat := [(87,false), (50,false), (38,false), (40,false), (18,false), (99,false)]
theorem p1963 (F : Frame G 4) : c1963.eval F.assign = true := by
  apply local_rup F.assign c1963 [c4, c6, c3, c5, c980]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p980 F) (rfl)))))
  · decide +kernel
def c1964 : CNF.Clause Nat := [(26,false), (40,false), (62,false), (50,false), (5,false), (87,false), (21,false), (99,false)]
theorem p1964 (F : Frame G 4) : c1964.eval F.assign = true := by
  apply local_rup F.assign c1964 [c4, c5, c981]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p981 F) (rfl)))
  · decide +kernel
def c1965 : CNF.Clause Nat := [(26,false), (40,false), (62,false), (50,false), (19,false), (87,false), (10,false), (9,false), (99,false)]
theorem p1965 (F : Frame G 4) : c1965.eval F.assign = true := by
  apply local_rup F.assign c1965 [c2, c982]
  · exact sat_cons (p2 F) ( sat_cons (p982 F) (rfl))
  · decide +kernel
def c1966 : CNF.Clause Nat := [(50,false), (62,false), (40,false), (26,false), (87,false), (9,false), (22,false)]
theorem p1966 (F : Frame G 4) : c1966.eval F.assign = true := by
  apply local_rup F.assign c1966 [c6, c4, c5, c983]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p983 F) (rfl))))
  · decide +kernel
def c1967 : CNF.Clause Nat := [(15,false), (5,false), (7,false), (62,false), (30,false), (88,false), (99,false), (98,false)]
theorem p1967 (F : Frame G 4) : c1967.eval F.assign = true := by
  apply local_rup F.assign c1967 [c2, c3, c984]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p984 F) (rfl)))
  · decide +kernel
def c1968 : CNF.Clause Nat := [(51,false), (62,false), (30,false), (15,false), (98,false), (110,false)]
theorem p1968 (F : Frame G 4) : c1968.eval F.assign = true := by
  apply local_rup F.assign c1968 [c3, c4, c1, c5, c985]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p985 F) (rfl)))))
  · decide +kernel
def c1969 : CNF.Clause Nat := [(39,false), (40,false), (51,false), (5,false), (88,false), (22,false), (98,false)]
theorem p1969 (F : Frame G 4) : c1969.eval F.assign = true := by
  apply local_rup F.assign c1969 [c3, c4, c5, c986]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p986 F) (rfl))))
  · decide +kernel
def c1970 : CNF.Clause Nat := [(87,false), (86,false), (99,false), (22,false), (15,false), (5,false), (50,false), (62,false)]
theorem p1970 (F : Frame G 4) : c1970.eval F.assign = true := by
  apply local_rup F.assign c1970 [c6, c1, c987]
  · exact sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p987 F) (rfl)))
  · decide +kernel
def c1971 : CNF.Clause Nat := [(38,false), (7,false), (62,false), (30,false), (87,false), (98,false), (99,false)]
theorem p1971 (F : Frame G 4) : c1971.eval F.assign = true := by
  apply local_rup F.assign c1971 [c2, c1, c3, c988]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p988 F) (rfl))))
  · decide +kernel
def c1972 : CNF.Clause Nat := [(62,false), (51,false), (38,false), (87,false), (21,false), (99,false)]
theorem p1972 (F : Frame G 4) : c1972.eval F.assign = true := by
  apply local_rup F.assign c1972 [c3, c1, c4, c5, c989]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p989 F) (rfl)))))
  · decide +kernel
def c1973 : CNF.Clause Nat := [(50,false), (38,false), (15,false), (18,false), (7,false), (86,false), (98,false), (110,false)]
theorem p1973 (F : Frame G 4) : c1973.eval F.assign = true := by
  apply local_rup F.assign c1973 [c3, c4, c990]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p990 F) (rfl)))
  · decide +kernel
def c1974 : CNF.Clause Nat := [(15,false), (38,false), (50,false), (29,false), (7,false), (86,false), (98,false), (110,false)]
theorem p1974 (F : Frame G 4) : c1974.eval F.assign = true := by
  apply local_rup F.assign c1974 [c3, c4, c991]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p991 F) (rfl)))
  · decide +kernel
def c1975 : CNF.Clause Nat := [(15,false), (50,false), (6,false), (7,false), (29,false), (31,false), (98,false), (110,false), (88,false)]
theorem p1975 (F : Frame G 4) : c1975.eval F.assign = true := by
  apply local_rup F.assign c1975 [c2, c992]
  · exact sat_cons (p2 F) ( sat_cons (p992 F) (rfl))
  · decide +kernel
def c1976 : CNF.Clause Nat := [(50,false), (38,false), (7,false), (18,false), (19,false), (88,false), (99,false), (98,false)]
theorem p1976 (F : Frame G 4) : c1976.eval F.assign = true := by
  apply local_rup F.assign c1976 [c3, c1, c993]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p993 F) (rfl)))
  · decide +kernel
def c1977 : CNF.Clause Nat := [(7,false), (40,false), (39,false), (27,false), (86,false), (87,false), (110,false)]
theorem p1977 (F : Frame G 4) : c1977.eval F.assign = true := by
  apply local_rup F.assign c1977 [c3, c2, c5, c994]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p994 F) (rfl))))
  · decide +kernel
def c1978 : CNF.Clause Nat := [(50,false), (5,false), (40,false), (18,false), (86,false), (87,false), (110,false)]
theorem p1978 (F : Frame G 4) : c1978.eval F.assign = true := by
  apply local_rup F.assign c1978 [c3, c1, c5, c995]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p995 F) (rfl))))
  · decide +kernel
def c1979 : CNF.Clause Nat := [(50,false), (38,false), (40,false), (7,false), (87,false), (110,false), (22,false)]
theorem p1979 (F : Frame G 4) : c1979.eval F.assign = true := by
  apply local_rup F.assign c1979 [c3, c4, c5, c996]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p996 F) (rfl))))
  · decide +kernel
def c1980 : CNF.Clause Nat := [(99,false), (110,false), (87,false), (6,false), (26,false), (40,false)]
theorem p1980 (F : Frame G 4) : c1980.eval F.assign = true := by
  apply local_rup F.assign c1980 [c2, c5, c4, c3, c997]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p3 F) ( sat_cons (p997 F) (rfl)))))
  · decide +kernel
def c1981 : CNF.Clause Nat := [(99,false), (110,false), (87,false), (30,false), (6,false), (40,false)]
theorem p1981 (F : Frame G 4) : c1981.eval F.assign = true := by
  apply local_rup F.assign c1981 [c2, c5, c3, c1, c998]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p998 F) (rfl)))))
  · decide +kernel
def c1982 : CNF.Clause Nat := [(27,false), (39,false), (40,false), (7,false), (87,false), (21,false), (99,false)]
theorem p1982 (F : Frame G 4) : c1982.eval F.assign = true := by
  apply local_rup F.assign c1982 [c3, c4, c5, c999]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p999 F) (rfl))))
  · decide +kernel
def c1983 : CNF.Clause Nat := [(19,false), (87,false), (39,false), (40,false), (7,false), (9,false), (99,false)]
theorem p1983 (F : Frame G 4) : c1983.eval F.assign = true := by
  apply local_rup F.assign c1983 [c2, c6, c3, c1000]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p1000 F) (rfl))))
  · decide +kernel
def c1984 : CNF.Clause Nat := [(39,false), (38,false), (18,false), (7,false), (87,false), (110,false), (99,false)]
theorem p1984 (F : Frame G 4) : c1984.eval F.assign = true := by
  apply local_rup F.assign c1984 [c3, c2, c4, c1001]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1001 F) (rfl))))
  · decide +kernel
def c1985 : CNF.Clause Nat := [(39,false), (40,false), (18,false), (5,false), (87,false), (110,false), (99,false)]
theorem p1985 (F : Frame G 4) : c1985.eval F.assign = true := by
  apply local_rup F.assign c1985 [c3, c2, c4, c1002]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1002 F) (rfl))))
  · decide +kernel
def c1986 : CNF.Clause Nat := [(38,false), (39,false), (6,false), (87,false), (29,false), (18,false), (99,false)]
theorem p1986 (F : Frame G 4) : c1986.eval F.assign = true := by
  apply local_rup F.assign c1986 [c4, c6, c5, c1003]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1003 F) (rfl))))
  · decide +kernel
def c1987 : CNF.Clause Nat := [(88,false), (110,false), (98,false), (50,false), (26,false), (40,false)]
theorem p1987 (F : Frame G 4) : c1987.eval F.assign = true := by
  apply local_rup F.assign c1987 [c4, c5, c2, c3, c1004]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1004 F) (rfl)))))
  · decide +kernel
def c1988 : CNF.Clause Nat := [(31,false), (98,false), (110,false), (88,false), (40,false), (18,false), (50,false)]
theorem p1988 (F : Frame G 4) : c1988.eval F.assign = true := by
  apply local_rup F.assign c1988 [c4, c1, c2, c1005]
  · exact sat_cons (p4 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p1005 F) (rfl))))
  · decide +kernel
def c1989 : CNF.Clause Nat := [(50,false), (5,false), (40,false), (18,false), (19,false), (88,false), (110,false), (98,false)]
theorem p1989 (F : Frame G 4) : c1989.eval F.assign = true := by
  apply local_rup F.assign c1989 [c3, c1, c1006]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p1006 F) (rfl)))
  · decide +kernel
def c1990 : CNF.Clause Nat := [(38,false), (40,false), (29,false), (6,false), (88,false), (22,false), (98,false)]
theorem p1990 (F : Frame G 4) : c1990.eval F.assign = true := by
  apply local_rup F.assign c1990 [c3, c4, c5, c1007]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1007 F) (rfl))))
  · decide +kernel
def c1991 : CNF.Clause Nat := [(50,false), (39,false), (40,false), (7,false), (19,false), (31,false), (110,false)]
theorem p1991 (F : Frame G 4) : c1991.eval F.assign = true := by
  apply local_rup F.assign c1991 [c4, c5, c6, c1008]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1008 F) (rfl))))
  · decide +kernel
def c1992 : CNF.Clause Nat := [(88,false), (110,false), (98,false), (27,false), (26,false), (39,false), (62,false)]
theorem p1992 (F : Frame G 4) : c1992.eval F.assign = true := by
  apply local_rup F.assign c1992 [c4, c5, c2, c1009]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p1009 F) (rfl))))
  · decide +kernel
def c1993 : CNF.Clause Nat := [(88,false), (110,false), (98,false), (27,false), (39,false), (40,false)]
theorem p1993 (F : Frame G 4) : c1993.eval F.assign = true := by
  apply local_rup F.assign c1993 [c4, c5, c2, c3, c1010]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1010 F) (rfl)))))
  · decide +kernel
def c1994 : CNF.Clause Nat := [(88,false), (110,false), (98,false), (31,false), (17,false), (38,false), (40,false)]
theorem p1994 (F : Frame G 4) : c1994.eval F.assign = true := by
  apply local_rup F.assign c1994 [c4, c3, c2, c1011]
  · exact sat_cons (p4 F) ( sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p1011 F) (rfl))))
  · decide +kernel
def c1995 : CNF.Clause Nat := [(5,false), (51,false), (62,false), (33,false), (22,false), (86,false), (87,false)]
theorem p1995 (F : Frame G 4) : c1995.eval F.assign = true := by
  apply local_rup F.assign c1995 [c1, c3, c5, c1012]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p1012 F) (rfl))))
  · decide +kernel
def c1996 : CNF.Clause Nat := [(6,false), (62,false), (51,false), (27,false), (33,false), (110,false), (21,false), (19,false), (86,false)]
theorem p1996 (F : Frame G 4) : c1996.eval F.assign = true := by
  apply local_rup F.assign c1996 [c1, c1013]
  · exact sat_cons (p1 F) ( sat_cons (p1013 F) (rfl))
  · decide +kernel
def c1997 : CNF.Clause Nat := [(86,false), (98,false), (110,false), (33,false), (27,false), (17,false), (62,false)]
theorem p1997 (F : Frame G 4) : c1997.eval F.assign = true := by
  apply local_rup F.assign c1997 [c1, c4, c2, c1014]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p1014 F) (rfl))))
  · decide +kernel
def c1998 : CNF.Clause Nat := [(40,false), (51,false), (5,false), (19,false), (17,false), (31,false), (98,false), (110,false)]
theorem p1998 (F : Frame G 4) : c1998.eval F.assign = true := by
  apply local_rup F.assign c1998 [c4, c3, c1015]
  · exact sat_cons (p4 F) ( sat_cons (p3 F) ( sat_cons (p1015 F) (rfl)))
  · decide +kernel
def c1999 : CNF.Clause Nat := [(62,false), (40,false), (15,false), (5,false), (86,false), (98,false), (110,false)]
theorem p1999 (F : Frame G 4) : c1999.eval F.assign = true := by
  apply local_rup F.assign c1999 [c3, c2, c4, c1016]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1016 F) (rfl))))
  · decide +kernel
def c2000 : CNF.Clause Nat := [(38,false), (40,false), (62,false), (33,false), (11,false), (19,false), (98,false)]
theorem p2000 (F : Frame G 4) : c2000.eval F.assign = true := by
  apply local_rup F.assign c2000 [c3, c4, c5, c1017]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1017 F) (rfl))))
  · decide +kernel
def c2001 : CNF.Clause Nat := [(86,false), (87,false), (110,false), (33,false), (26,false), (6,false), (50,false), (51,false)]
theorem p2001 (F : Frame G 4) : c2001.eval F.assign = true := by
  apply local_rup F.assign c2001 [c5, c1, c1018]
  · exact sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p1018 F) (rfl)))
  · decide +kernel
def c2002 : CNF.Clause Nat := [(15,false), (50,false), (6,false), (7,false), (29,false), (87,false), (86,false), (99,false)]
theorem p2002 (F : Frame G 4) : c2002.eval F.assign = true := by
  apply local_rup F.assign c2002 [c2, c6, c1019]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p1019 F) (rfl)))
  · decide +kernel
def c2003 : CNF.Clause Nat := [(50,false), (38,false), (7,false), (18,false), (86,false), (87,false), (110,false)]
theorem p2003 (F : Frame G 4) : c2003.eval F.assign = true := by
  apply local_rup F.assign c2003 [c3, c1, c5, c1021]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p1021 F) (rfl))))
  · decide +kernel
def c2004 : CNF.Clause Nat := [(38,false), (39,false), (62,false), (7,false), (19,false), (31,false), (110,false)]
theorem p2004 (F : Frame G 4) : c2004.eval F.assign = true := by
  apply local_rup F.assign c2004 [c4, c5, c6, c1022]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1022 F) (rfl))))
  · decide +kernel
def c2005 : CNF.Clause Nat := [(62,false), (18,false), (15,false), (38,false), (5,false), (9,false), (86,false), (87,false), (110,false)]
theorem p2005 (F : Frame G 4) : c2005.eval F.assign = true := by
  apply local_rup F.assign c2005 [c3, c1023]
  · exact sat_cons (p3 F) ( sat_cons (p1023 F) (rfl))
  · decide +kernel
def c2006 : CNF.Clause Nat := [(38,false), (39,false), (62,false), (29,false), (31,false), (19,false), (10,false), (110,false)]
theorem p2006 (F : Frame G 4) : c2006.eval F.assign = true := by
  apply local_rup F.assign c2006 [c5, c4, c1024]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1024 F) (rfl)))
  · decide +kernel
def c2007 : CNF.Clause Nat := [(38,false), (6,false), (62,false), (29,false), (31,false), (86,false), (19,false), (21,false), (110,false)]
theorem p2007 (F : Frame G 4) : c2007.eval F.assign = true := by
  apply local_rup F.assign c2007 [c1, c1025]
  · exact sat_cons (p1 F) ( sat_cons (p1025 F) (rfl))
  · decide +kernel
def c2008 : CNF.Clause Nat := [(5,false), (50,false), (62,false), (18,false), (31,false), (87,false), (88,false)]
theorem p2008 (F : Frame G 4) : c2008.eval F.assign = true := by
  apply local_rup F.assign c2008 [c1, c5, c6, c1026]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1026 F) (rfl))))
  · decide +kernel
def c2009 : CNF.Clause Nat := [(50,false), (6,false), (40,false), (18,false), (86,false), (30,false), (110,false)]
theorem p2009 (F : Frame G 4) : c2009.eval F.assign = true := by
  apply local_rup F.assign c2009 [c1, c5, c6, c1027]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1027 F) (rfl))))
  · decide +kernel
def c2010 : CNF.Clause Nat := [(50,false), (39,false), (40,false), (29,false), (31,false), (86,false), (10,false), (110,false)]
theorem p2010 (F : Frame G 4) : c2010.eval F.assign = true := by
  apply local_rup F.assign c2010 [c2, c4, c1028]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1028 F) (rfl)))
  · decide +kernel
def c2011 : CNF.Clause Nat := [(86,false), (88,false), (110,false), (6,false), (40,false)]
theorem p2011 (F : Frame G 4) : c2011.eval F.assign = true := by
  apply local_rup F.assign c2011 [c2, c5, c6, c3, c1, c1029]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p1029 F) (rfl))))))
  · decide +kernel
def c2012 : CNF.Clause Nat := [(99,false), (110,false), (30,false), (6,false), (39,false), (40,false)]
theorem p2012 (F : Frame G 4) : c2012.eval F.assign = true := by
  apply local_rup F.assign c2012 [c2, c5, c6, c4, c1030]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1030 F) (rfl)))))
  · decide +kernel
def c2013 : CNF.Clause Nat := [(50,false), (17,false), (15,false), (40,false), (29,false), (110,false), (88,false), (9,false)]
theorem p2013 (F : Frame G 4) : c2013.eval F.assign = true := by
  apply local_rup F.assign c2013 [c6, c4, c1031]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1031 F) (rfl)))
  · decide +kernel
def c2014 : CNF.Clause Nat := [(17,false), (39,false), (40,false), (29,false), (10,false), (88,false), (99,false)]
theorem p2014 (F : Frame G 4) : c2014.eval F.assign = true := by
  apply local_rup F.assign c2014 [c2, c6, c4, c1032]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1032 F) (rfl))))
  · decide +kernel
def c2015 : CNF.Clause Nat := [(110,false), (88,false), (9,false), (38,false), (39,false), (62,false)]
theorem p2015 (F : Frame G 4) : c2015.eval F.assign = true := by
  apply local_rup F.assign c2015 [c6, c4, c5, c2, c1033]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p1033 F) (rfl)))))
  · decide +kernel
def c2016 : CNF.Clause Nat := [(110,false), (88,false), (19,false), (9,false), (38,false), (50,false), (62,false)]
theorem p2016 (F : Frame G 4) : c2016.eval F.assign = true := by
  apply local_rup F.assign c2016 [c6, c5, c1, c1034]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p1034 F) (rfl))))
  · decide +kernel
def c2017 : CNF.Clause Nat := [(38,false), (40,false), (7,false), (30,false), (17,false), (99,false), (110,false)]
theorem p2017 (F : Frame G 4) : c2017.eval F.assign = true := by
  apply local_rup F.assign c2017 [c4, c3, c5, c1035]
  · exact sat_cons (p4 F) ( sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p1035 F) (rfl))))
  · decide +kernel
def c2018 : CNF.Clause Nat := [(7,false), (62,false), (50,false), (31,false), (30,false), (88,false), (110,false)]
theorem p2018 (F : Frame G 4) : c2018.eval F.assign = true := by
  apply local_rup F.assign c2018 [c1, c2, c5, c1036]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1036 F) (rfl))))
  · decide +kernel
def c2019 : CNF.Clause Nat := [(88,false), (99,false), (31,false), (21,false), (50,false), (39,false), (40,false)]
theorem p2019 (F : Frame G 4) : c2019.eval F.assign = true := by
  apply local_rup F.assign c2019 [c4, c6, c2, c1037]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p1037 F) (rfl))))
  · decide +kernel
def c2020 : CNF.Clause Nat := [(40,false), (7,false), (88,false), (99,false), (21,false), (27,false), (50,false)]
theorem p2020 (F : Frame G 4) : c2020.eval F.assign = true := by
  apply local_rup F.assign c2020 [c4, c5, c6, c1038]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1038 F) (rfl))))
  · decide +kernel
def c2021 : CNF.Clause Nat := [(110,false), (88,false), (19,false), (9,false), (5,false), (50,false), (39,false), (40,false)]
theorem p2021 (F : Frame G 4) : c2021.eval F.assign = true := by
  apply local_rup F.assign c2021 [c6, c5, c1039]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1039 F) (rfl)))
  · decide +kernel
def c2022 : CNF.Clause Nat := [(27,false), (29,false), (40,false), (39,false), (17,false), (21,false), (110,false), (88,false), (9,false)]
theorem p2022 (F : Frame G 4) : c2022.eval F.assign = true := by
  apply local_rup F.assign c2022 [c4, c1040]
  · exact sat_cons (p4 F) ( sat_cons (p1040 F) (rfl))
  · decide +kernel
def c2023 : CNF.Clause Nat := [(50,false), (62,false), (29,false), (26,false), (19,false), (99,false), (110,false)]
theorem p2023 (F : Frame G 4) : c2023.eval F.assign = true := by
  apply local_rup F.assign c2023 [c1, c4, c5, c1041]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1041 F) (rfl))))
  · decide +kernel
def c2024 : CNF.Clause Nat := [(5,false), (30,false), (26,false), (39,false), (62,false), (18,false), (99,false), (110,false)]
theorem p2024 (F : Frame G 4) : c2024.eval F.assign = true := by
  apply local_rup F.assign c2024 [c4, c5, c1042]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1042 F) (rfl)))
  · decide +kernel
def c2025 : CNF.Clause Nat := [(27,false), (30,false), (39,false), (62,false), (18,false), (99,false), (110,false)]
theorem p2025 (F : Frame G 4) : c2025.eval F.assign = true := by
  apply local_rup F.assign c2025 [c4, c1, c5, c1043]
  · exact sat_cons (p4 F) ( sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p1043 F) (rfl))))
  · decide +kernel
def c2026 : CNF.Clause Nat := [(30,false), (88,false), (110,false), (21,false), (9,false), (5,false), (50,false), (39,false), (40,false)]
theorem p2026 (F : Frame G 4) : c2026.eval F.assign = true := by
  apply local_rup F.assign c2026 [c5, c1044]
  · exact sat_cons (p5 F) ( sat_cons (p1044 F) (rfl))
  · decide +kernel
def c2027 : CNF.Clause Nat := [(7,false), (62,false), (50,false), (86,false), (88,false), (33,false)]
theorem p2027 (F : Frame G 4) : c2027.eval F.assign = true := by
  apply local_rup F.assign c2027 [c1, c2, c5, c6, c1045]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1045 F) (rfl)))))
  · decide +kernel
def c2028 : CNF.Clause Nat := [(86,false), (50,false), (62,false), (40,false), (26,false), (110,false)]
theorem p2028 (F : Frame G 4) : c2028.eval F.assign = true := by
  apply local_rup F.assign c2028 [c4, c5, c2, c6, c1046]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p1046 F) (rfl)))))
  · decide +kernel
def c2029 : CNF.Clause Nat := [(86,false), (31,false), (27,false), (50,false), (39,false), (40,false), (18,false), (21,false), (110,false)]
theorem p2029 (F : Frame G 4) : c2029.eval F.assign = true := by
  apply local_rup F.assign c2029 [c4, c1047]
  · exact sat_cons (p4 F) ( sat_cons (p1047 F) (rfl))
  · decide +kernel
def c2030 : CNF.Clause Nat := [(86,false), (15,false), (40,false), (62,false), (50,false), (27,false), (110,false)]
theorem p2030 (F : Frame G 4) : c2030.eval F.assign = true := by
  apply local_rup F.assign c2030 [c4, c5, c6, c1048]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1048 F) (rfl))))
  · decide +kernel
def c2031 : CNF.Clause Nat := [(40,false), (7,false), (88,false), (110,false), (31,false), (50,false)]
theorem p2031 (F : Frame G 4) : c2031.eval F.assign = true := by
  apply local_rup F.assign c2031 [c4, c6, c5, c2, c1049]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p1049 F) (rfl)))))
  · decide +kernel
def c2032 : CNF.Clause Nat := [(50,false), (39,false), (40,false), (29,false), (30,false), (9,false), (99,false), (110,false)]
theorem p2032 (F : Frame G 4) : c2032.eval F.assign = true := by
  apply local_rup F.assign c2032 [c2, c4, c1050]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1050 F) (rfl)))
  · decide +kernel
def c2033 : CNF.Clause Nat := [(50,false), (39,false), (40,false), (29,false), (10,false), (88,false), (99,false)]
theorem p2033 (F : Frame G 4) : c2033.eval F.assign = true := by
  apply local_rup F.assign c2033 [c2, c6, c4, c1051]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1051 F) (rfl))))
  · decide +kernel
def c2034 : CNF.Clause Nat := [(38,false), (51,false), (62,false), (87,false), (9,false), (22,false)]
theorem p2034 (F : Frame G 4) : c2034.eval F.assign = true := by
  apply local_rup F.assign c2034 [c3, c6, c4, c5, c1052]
  · exact sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1052 F) (rfl)))))
  · decide +kernel
def c2035 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (19,false), (86,false), (9,false), (7,false), (29,false), (110,false)]
theorem p2035 (F : Frame G 4) : c2035.eval F.assign = true := by
  apply local_rup F.assign c2035 [c6, c1054]
  · exact sat_cons (p6 F) ( sat_cons (p1054 F) (rfl))
  · decide +kernel
def c2036 : CNF.Clause Nat := [(86,false), (98,false), (110,false), (33,false), (17,false), (51,false)]
theorem p2036 (F : Frame G 4) : c2036.eval F.assign = true := by
  apply local_rup F.assign c2036 [c1, c4, c3, c2, c1055]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p1055 F) (rfl)))))
  · decide +kernel
def c2037 : CNF.Clause Nat := [(6,false), (50,false), (51,false), (18,false), (86,false), (30,false), (110,false)]
theorem p2037 (F : Frame G 4) : c2037.eval F.assign = true := by
  apply local_rup F.assign c2037 [c1, c5, c6, c1056]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1056 F) (rfl))))
  · decide +kernel
def c2038 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (18,false), (7,false), (86,false), (31,false), (110,false)]
theorem p2038 (F : Frame G 4) : c2038.eval F.assign = true := by
  apply local_rup F.assign c2038 [c4, c6, c1057]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1057 F) (rfl)))
  · decide +kernel
def c2039 : CNF.Clause Nat := [(50,false), (38,false), (15,false), (18,false), (7,false), (86,false), (99,false), (110,false)]
theorem p2039 (F : Frame G 4) : c2039.eval F.assign = true := by
  apply local_rup F.assign c2039 [c3, c4, c1058]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1058 F) (rfl)))
  · decide +kernel
def c2040 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (7,false), (18,false), (19,false), (86,false), (31,false), (110,false)]
theorem p2040 (F : Frame G 4) : c2040.eval F.assign = true := by
  apply local_rup F.assign c2040 [c6, c1059]
  · exact sat_cons (p6 F) ( sat_cons (p1059 F) (rfl))
  · decide +kernel
def c2041 : CNF.Clause Nat := [(26,false), (50,false), (51,false), (7,false), (9,false), (19,false), (88,false), (110,false)]
theorem p2041 (F : Frame G 4) : c2041.eval F.assign = true := by
  apply local_rup F.assign c2041 [c3, c5, c1060]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p1060 F) (rfl)))
  · decide +kernel
def c2042 : CNF.Clause Nat := [(26,false), (50,false), (51,false), (18,false), (86,false), (10,false), (110,false)]
theorem p2042 (F : Frame G 4) : c2042.eval F.assign = true := by
  apply local_rup F.assign c2042 [c3, c5, c4, c1061]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1061 F) (rfl))))
  · decide +kernel
def c2043 : CNF.Clause Nat := [(39,false), (7,false), (51,false), (86,false), (30,false), (110,false)]
theorem p2043 (F : Frame G 4) : c2043.eval F.assign = true := by
  apply local_rup F.assign c2043 [c1, c2, c5, c6, c1062]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1062 F) (rfl)))))
  · decide +kernel
def c2044 : CNF.Clause Nat := [(39,false), (38,false), (51,false), (7,false), (19,false), (31,false), (110,false)]
theorem p2044 (F : Frame G 4) : c2044.eval F.assign = true := by
  apply local_rup F.assign c2044 [c4, c5, c6, c1063]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1063 F) (rfl))))
  · decide +kernel
def c2045 : CNF.Clause Nat := [(39,false), (50,false), (51,false), (29,false), (21,false), (9,false), (88,false)]
theorem p2045 (F : Frame G 4) : c2045.eval F.assign = true := by
  apply local_rup F.assign c2045 [c6, c5, c4, c1064]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1064 F) (rfl))))
  · decide +kernel
def c2046 : CNF.Clause Nat := [(39,false), (50,false), (19,false), (86,false), (9,false), (7,false), (29,false), (110,false)]
theorem p2046 (F : Frame G 4) : c2046.eval F.assign = true := by
  apply local_rup F.assign c2046 [c2, c6, c1065]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p1065 F) (rfl)))
  · decide +kernel
def c2047 : CNF.Clause Nat := [(7,false), (62,false), (50,false), (19,false), (86,false), (31,false), (110,false)]
theorem p2047 (F : Frame G 4) : c2047.eval F.assign = true := by
  apply local_rup F.assign c2047 [c1, c2, c6, c1066]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p1066 F) (rfl))))
  · decide +kernel
def c2048 : CNF.Clause Nat := [(15,false), (50,false), (62,false), (7,false), (86,false), (99,false), (33,false)]
theorem p2048 (F : Frame G 4) : c2048.eval F.assign = true := by
  apply local_rup F.assign c2048 [c2, c4, c6, c1067]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1067 F) (rfl))))
  · decide +kernel
def c2049 : CNF.Clause Nat := [(15,false), (39,false), (50,false), (27,false), (29,false), (7,false), (86,false), (98,false), (110,false)]
theorem p2049 (F : Frame G 4) : c2049.eval F.assign = true := by
  apply local_rup F.assign c2049 [c4, c1068]
  · exact sat_cons (p4 F) ( sat_cons (p1068 F) (rfl))
  · decide +kernel
def c2050 : CNF.Clause Nat := [(38,false), (7,false), (62,false), (30,false), (86,false), (99,false), (110,false)]
theorem p2050 (F : Frame G 4) : c2050.eval F.assign = true := by
  apply local_rup F.assign c2050 [c2, c1, c3, c1069]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p1069 F) (rfl))))
  · decide +kernel
def c2051 : CNF.Clause Nat := [(38,false), (19,false), (86,false), (99,false), (110,false), (10,false), (6,false), (29,false)]
theorem p2051 (F : Frame G 4) : c2051.eval F.assign = true := by
  apply local_rup F.assign c2051 [c2, c3, c1070]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1070 F) (rfl)))
  · decide +kernel
def c2052 : CNF.Clause Nat := [(5,false), (39,false), (62,false), (29,false), (110,false), (22,false), (19,false), (86,false)]
theorem p2052 (F : Frame G 4) : c2052.eval F.assign = true := by
  apply local_rup F.assign c2052 [c1, c6, c1071]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p1071 F) (rfl)))
  · decide +kernel
def c2053 : CNF.Clause Nat := [(39,false), (50,false), (18,false), (29,false), (110,false), (11,false), (86,false)]
theorem p2053 (F : Frame G 4) : c2053.eval F.assign = true := by
  apply local_rup F.assign c2053 [c2, c6, c4, c1072]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1072 F) (rfl))))
  · decide +kernel
def c2054 : CNF.Clause Nat := [(38,false), (11,false), (110,false), (87,false), (86,false), (17,false), (29,false)]
theorem p2054 (F : Frame G 4) : c2054.eval F.assign = true := by
  apply local_rup F.assign c2054 [c1, c5, c3, c1073]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p3 F) ( sat_cons (p1073 F) (rfl))))
  · decide +kernel
def c2055 : CNF.Clause Nat := [(38,false), (27,false), (62,false), (18,false), (86,false), (87,false), (110,false)]
theorem p2055 (F : Frame G 4) : c2055.eval F.assign = true := by
  apply local_rup F.assign c2055 [c1, c3, c5, c1074]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p1074 F) (rfl))))
  · decide +kernel
def c2056 : CNF.Clause Nat := [(5,false), (40,false), (62,false), (17,false), (86,false), (87,false), (33,false)]
theorem p2056 (F : Frame G 4) : c2056.eval F.assign = true := by
  apply local_rup F.assign c2056 [c1, c5, c6, c1075]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1075 F) (rfl))))
  · decide +kernel
def c2057 : CNF.Clause Nat := [(38,false), (6,false), (62,false), (18,false), (86,false), (87,false), (33,false)]
theorem p2057 (F : Frame G 4) : c2057.eval F.assign = true := by
  apply local_rup F.assign c2057 [c1, c5, c6, c1076]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1076 F) (rfl))))
  · decide +kernel
def c2058 : CNF.Clause Nat := [(40,false), (62,false), (50,false), (9,false), (30,false), (110,false)]
theorem p2058 (F : Frame G 4) : c2058.eval F.assign = true := by
  apply local_rup F.assign c2058 [c2, c5, c4, c6, c1077]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1077 F) (rfl)))))
  · decide +kernel
def c2059 : CNF.Clause Nat := [(62,false), (40,false), (5,false), (99,false), (88,false), (87,false)]
theorem p2059 (F : Frame G 4) : c2059.eval F.assign = true := by
  apply local_rup F.assign c2059 [c3, c1, c2, c5, c1078]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1078 F) (rfl)))))
  · decide +kernel
def c2060 : CNF.Clause Nat := [(50,false), (39,false), (40,false), (7,false), (86,false), (98,false), (33,false)]
theorem p2060 (F : Frame G 4) : c2060.eval F.assign = true := by
  apply local_rup F.assign c2060 [c2, c4, c6, c1079]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1079 F) (rfl))))
  · decide +kernel
def c2061 : CNF.Clause Nat := [(50,false), (17,false), (22,false), (110,false), (98,false), (86,false), (26,false), (29,false)]
theorem p2061 (F : Frame G 4) : c2061.eval F.assign = true := by
  apply local_rup F.assign c2061 [c4, c1, c1081]
  · exact sat_cons (p4 F) ( sat_cons (p1 F) ( sat_cons (p1081 F) (rfl)))
  · decide +kernel
def c2062 : CNF.Clause Nat := [(87,false), (98,false), (50,false), (62,false), (29,false), (33,false)]
theorem p2062 (F : Frame G 4) : c2062.eval F.assign = true := by
  apply local_rup F.assign c2062 [c1, c4, c5, c2, c1082]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p1082 F) (rfl)))))
  · decide +kernel
def c2063 : CNF.Clause Nat := [(26,false), (50,false), (51,false), (18,false), (19,false), (9,false), (98,false), (110,false)]
theorem p2063 (F : Frame G 4) : c2063.eval F.assign = true := by
  apply local_rup F.assign c2063 [c3, c4, c1083]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1083 F) (rfl)))
  · decide +kernel
def c2064 : CNF.Clause Nat := [(87,false), (110,false), (22,false), (31,false), (27,false), (50,false), (62,false)]
theorem p2064 (F : Frame G 4) : c2064.eval F.assign = true := by
  apply local_rup F.assign c2064 [c1, c4, c5, c1084]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1084 F) (rfl))))
  · decide +kernel
def c2065 : CNF.Clause Nat := [(19,false), (18,false), (51,false), (50,false), (31,false), (98,false), (110,false)]
theorem p2065 (F : Frame G 4) : c2065.eval F.assign = true := by
  apply local_rup F.assign c2065 [c1, c4, c3, c1085]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p3 F) ( sat_cons (p1085 F) (rfl))))
  · decide +kernel
def c2066 : CNF.Clause Nat := [(39,false), (62,false), (51,false), (19,false), (9,false), (98,false), (33,false)]
theorem p2066 (F : Frame G 4) : c2066.eval F.assign = true := by
  apply local_rup F.assign c2066 [c2, c4, c6, c1086]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1086 F) (rfl))))
  · decide +kernel
def c2067 : CNF.Clause Nat := [(39,false), (88,false), (110,false), (98,false), (51,false)]
theorem p2067 (F : Frame G 4) : c2067.eval F.assign = true := by
  apply local_rup F.assign c2067 [c3, c1, c4, c5, c2, c1087]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p1087 F) (rfl))))))
  · decide +kernel
def c2068 : CNF.Clause Nat := [(39,false), (26,false), (31,false), (98,false), (110,false), (11,false), (19,false), (51,false)]
theorem p2068 (F : Frame G 4) : c2068.eval F.assign = true := by
  apply local_rup F.assign c2068 [c4, c2, c1088]
  · exact sat_cons (p4 F) ( sat_cons (p2 F) ( sat_cons (p1088 F) (rfl)))
  · decide +kernel
def c2069 : CNF.Clause Nat := [(38,false), (51,false), (62,false), (31,false), (19,false), (10,false), (110,false)]
theorem p2069 (F : Frame G 4) : c2069.eval F.assign = true := by
  apply local_rup F.assign c2069 [c3, c5, c4, c1089]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1089 F) (rfl))))
  · decide +kernel
def c2070 : CNF.Clause Nat := [(6,false), (62,false), (51,false), (27,false), (31,false), (19,false), (87,false), (110,false)]
theorem p2070 (F : Frame G 4) : c2070.eval F.assign = true := by
  apply local_rup F.assign c2070 [c1, c5, c1090]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p1090 F) (rfl)))
  · decide +kernel
def c2071 : CNF.Clause Nat := [(87,false), (110,false), (33,false), (31,false), (15,false), (38,false), (51,false), (62,false)]
theorem p2071 (F : Frame G 4) : c2071.eval F.assign = true := by
  apply local_rup F.assign c2071 [c4, c5, c1091]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1091 F) (rfl)))
  · decide +kernel
def c2072 : CNF.Clause Nat := [(39,false), (62,false), (51,false), (19,false), (87,false), (98,false), (31,false), (33,false)]
theorem p2072 (F : Frame G 4) : c2072.eval F.assign = true := by
  apply local_rup F.assign c2072 [c1, c2, c1092]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p1092 F) (rfl)))
  · decide +kernel
def c2073 : CNF.Clause Nat := [(26,false), (62,false), (51,false), (9,false), (87,false), (110,false)]
theorem p2073 (F : Frame G 4) : c2073.eval F.assign = true := by
  apply local_rup F.assign c2073 [c3, c2, c5, c4, c1093]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1093 F) (rfl)))))
  · decide +kernel
def c2074 : CNF.Clause Nat := [(38,false), (15,false), (19,false), (11,false), (110,false), (98,false), (31,false), (62,false)]
theorem p2074 (F : Frame G 4) : c2074.eval F.assign = true := by
  apply local_rup F.assign c2074 [c4, c3, c1094]
  · exact sat_cons (p4 F) ( sat_cons (p3 F) ( sat_cons (p1094 F) (rfl)))
  · decide +kernel
def c2075 : CNF.Clause Nat := [(5,false), (51,false), (62,false), (17,false), (22,false), (110,false), (87,false), (30,false), (31,false)]
theorem p2075 (F : Frame G 4) : c2075.eval F.assign = true := by
  apply local_rup F.assign c2075 [c1, c1095]
  · exact sat_cons (p1 F) ( sat_cons (p1095 F) (rfl))
  · decide +kernel
def c2076 : CNF.Clause Nat := [(30,false), (50,false), (51,false), (18,false), (98,false), (110,false)]
theorem p2076 (F : Frame G 4) : c2076.eval F.assign = true := by
  apply local_rup F.assign c2076 [c1, c4, c3, c5, c1096]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p1096 F) (rfl)))))
  · decide +kernel
def c2077 : CNF.Clause Nat := [(29,false), (51,false), (38,false), (15,false), (19,false), (9,false), (98,false), (110,false)]
theorem p2077 (F : Frame G 4) : c2077.eval F.assign = true := by
  apply local_rup F.assign c2077 [c3, c4, c1097]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1097 F) (rfl)))
  · decide +kernel
def c2078 : CNF.Clause Nat := [(39,false), (29,false), (51,false), (19,false), (9,false), (98,false), (110,false)]
theorem p2078 (F : Frame G 4) : c2078.eval F.assign = true := by
  apply local_rup F.assign c2078 [c3, c2, c4, c1098]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1098 F) (rfl))))
  · decide +kernel
def c2079 : CNF.Clause Nat := [(33,false), (110,false), (87,false), (19,false), (9,false), (7,false), (51,false), (38,false), (39,false)]
theorem p2079 (F : Frame G 4) : c2079.eval F.assign = true := by
  apply local_rup F.assign c2079 [c5, c1099]
  · exact sat_cons (p5 F) ( sat_cons (p1099 F) (rfl))
  · decide +kernel
def c2080 : CNF.Clause Nat := [(17,false), (15,false), (38,false), (51,false), (7,false), (9,false), (98,false), (87,false), (88,false)]
theorem p2080 (F : Frame G 4) : c2080.eval F.assign = true := by
  apply local_rup F.assign c2080 [c3, c1100]
  · exact sat_cons (p3 F) ( sat_cons (p1100 F) (rfl))
  · decide +kernel
def c2081 : CNF.Clause Nat := [(6,false), (50,false), (51,false), (18,false), (31,false), (87,false), (88,false)]
theorem p2081 (F : Frame G 4) : c2081.eval F.assign = true := by
  apply local_rup F.assign c2081 [c1, c5, c6, c1101]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1101 F) (rfl))))
  · decide +kernel
def c2082 : CNF.Clause Nat := [(7,false), (51,false), (50,false), (17,false), (98,false), (87,false), (30,false), (33,false)]
theorem p2082 (F : Frame G 4) : c2082.eval F.assign = true := by
  apply local_rup F.assign c2082 [c1, c5, c1102]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p1102 F) (rfl)))
  · decide +kernel
def c2083 : CNF.Clause Nat := [(7,false), (51,false), (50,false), (33,false), (22,false), (19,false), (87,false), (98,false)]
theorem p2083 (F : Frame G 4) : c2083.eval F.assign = true := by
  apply local_rup F.assign c2083 [c1, c3, c1103]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p1103 F) (rfl)))
  · decide +kernel
def c2084 : CNF.Clause Nat := [(7,false), (51,false), (50,false), (31,false), (19,false), (87,false), (110,false)]
theorem p2084 (F : Frame G 4) : c2084.eval F.assign = true := by
  apply local_rup F.assign c2084 [c1, c3, c5, c1104]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p1104 F) (rfl))))
  · decide +kernel
def c2085 : CNF.Clause Nat := [(7,false), (51,false), (50,false), (31,false), (98,false), (21,false), (19,false), (88,false)]
theorem p2085 (F : Frame G 4) : c2085.eval F.assign = true := by
  apply local_rup F.assign c2085 [c1, c3, c1105]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p1105 F) (rfl)))
  · decide +kernel
def c2086 : CNF.Clause Nat := [(50,false), (39,false), (26,false), (29,false), (7,false), (86,false), (98,false), (110,false)]
theorem p2086 (F : Frame G 4) : c2086.eval F.assign = true := by
  apply local_rup F.assign c2086 [c2, c4, c1107]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1107 F) (rfl)))
  · decide +kernel
def c2087 : CNF.Clause Nat := [(15,false), (50,false), (62,false), (7,false), (87,false), (31,false), (99,false)]
theorem p2087 (F : Frame G 4) : c2087.eval F.assign = true := by
  apply local_rup F.assign c2087 [c2, c4, c6, c1108]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1108 F) (rfl))))
  · decide +kernel
def c2088 : CNF.Clause Nat := [(38,false), (88,false), (99,false), (98,false), (62,false)]
theorem p2088 (F : Frame G 4) : c2088.eval F.assign = true := by
  apply local_rup F.assign c2088 [c2, c1, c4, c6, c3, c1109]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p1109 F) (rfl))))))
  · decide +kernel
def c2089 : CNF.Clause Nat := [(38,false), (19,false), (87,false), (110,false), (99,false), (31,false), (62,false)]
theorem p2089 (F : Frame G 4) : c2089.eval F.assign = true := by
  apply local_rup F.assign c2089 [c1, c2, c3, c1110]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1110 F) (rfl))))
  · decide +kernel
def c2090 : CNF.Clause Nat := [(38,false), (39,false), (62,false), (7,false), (87,false), (31,false), (99,false)]
theorem p2090 (F : Frame G 4) : c2090.eval F.assign = true := by
  apply local_rup F.assign c2090 [c2, c4, c6, c1111]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1111 F) (rfl))))
  · decide +kernel
def c2091 : CNF.Clause Nat := [(19,false), (22,false), (110,false), (98,false), (31,false), (39,false), (38,false), (51,false)]
theorem p2091 (F : Frame G 4) : c2091.eval F.assign = true := by
  apply local_rup F.assign c2091 [c4, c3, c1112]
  · exact sat_cons (p4 F) ( sat_cons (p3 F) ( sat_cons (p1112 F) (rfl)))
  · decide +kernel
def c2092 : CNF.Clause Nat := [(39,false), (40,false), (51,false), (19,false), (9,false), (98,false), (110,false)]
theorem p2092 (F : Frame G 4) : c2092.eval F.assign = true := by
  apply local_rup F.assign c2092 [c3, c2, c4, c1113]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1113 F) (rfl))))
  · decide +kernel
def c2093 : CNF.Clause Nat := [(99,false), (110,false), (87,false), (38,false), (27,false), (62,false)]
theorem p2093 (F : Frame G 4) : c2093.eval F.assign = true := by
  apply local_rup F.assign c2093 [c5, c4, c1, c3, c1114]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p1114 F) (rfl)))))
  · decide +kernel
def c2094 : CNF.Clause Nat := [(99,false), (110,false), (87,false), (30,false), (26,false), (38,false), (5,false), (6,false), (62,false)]
theorem p2094 (F : Frame G 4) : c2094.eval F.assign = true := by
  apply local_rup F.assign c2094 [c5, c1115]
  · exact sat_cons (p5 F) ( sat_cons (p1115 F) (rfl))
  · decide +kernel
def c2095 : CNF.Clause Nat := [(39,false), (5,false), (51,false), (18,false), (19,false), (86,false), (99,false), (110,false)]
theorem p2095 (F : Frame G 4) : c2095.eval F.assign = true := by
  apply local_rup F.assign c2095 [c3, c1, c1116]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p1116 F) (rfl)))
  · decide +kernel
def c2096 : CNF.Clause Nat := [(19,false), (86,false), (99,false), (110,false), (26,false), (6,false), (50,false), (51,false)]
theorem p2096 (F : Frame G 4) : c2096.eval F.assign = true := by
  apply local_rup F.assign c2096 [c6, c1, c1117]
  · exact sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p1117 F) (rfl)))
  · decide +kernel
def c2097 : CNF.Clause Nat := [(110,false), (99,false), (86,false), (15,false), (50,false), (62,false)]
theorem p2097 (F : Frame G 4) : c2097.eval F.assign = true := by
  apply local_rup F.assign c2097 [c6, c4, c1, c2, c1118]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p1118 F) (rfl)))))
  · decide +kernel
def c2098 : CNF.Clause Nat := [(5,false), (19,false), (18,false), (40,false), (39,false), (31,false), (98,false), (110,false)]
theorem p2098 (F : Frame G 4) : c2098.eval F.assign = true := by
  apply local_rup F.assign c2098 [c4, c3, c1119]
  · exact sat_cons (p4 F) ( sat_cons (p3 F) ( sat_cons (p1119 F) (rfl)))
  · decide +kernel
def c2099 : CNF.Clause Nat := [(50,false), (62,false), (18,false), (15,false), (87,false), (98,false), (31,false), (33,false)]
theorem p2099 (F : Frame G 4) : c2099.eval F.assign = true := by
  apply local_rup F.assign c2099 [c1, c4, c1120]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p1120 F) (rfl)))
  · decide +kernel
def c2100 : CNF.Clause Nat := [(50,false), (62,false), (40,false), (26,false), (33,false), (11,false), (87,false), (98,false)]
theorem p2100 (F : Frame G 4) : c2100.eval F.assign = true := by
  apply local_rup F.assign c2100 [c2, c4, c1121]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1121 F) (rfl)))
  · decide +kernel
end Cert44Steps
end Graffiti199Depleted.Catalogue.OrderEleven
