import Local44Part6
namespace Graffiti199Depleted.Catalogue.OrderEleven
namespace Cert44Steps
open Std.Sat
set_option maxRecDepth 4096
set_option maxHeartbeats 0
variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj]
def c2101 : CNF.Clause Nat := [(19,false), (87,false), (98,false), (9,false), (11,false), (33,false), (39,false), (40,false)]
theorem p2101 (F : Frame G 4) : c2101.eval F.assign = true := by
  apply local_rup F.assign c2101 [c2, c3, c1122]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1122 F) (rfl)))
  · decide +kernel
def c2102 : CNF.Clause Nat := [(40,false), (7,false), (19,false), (98,false), (110,false), (33,false), (27,false), (50,false)]
theorem p2102 (F : Frame G 4) : c2102.eval F.assign = true := by
  apply local_rup F.assign c2102 [c4, c5, c1123]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1123 F) (rfl)))
  · decide +kernel
def c2103 : CNF.Clause Nat := [(87,false), (110,false), (22,false), (31,false), (26,false), (38,false), (50,false), (62,false)]
theorem p2103 (F : Frame G 4) : c2103.eval F.assign = true := by
  apply local_rup F.assign c2103 [c4, c5, c1124]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1124 F) (rfl)))
  · decide +kernel
def c2104 : CNF.Clause Nat := [(19,false), (98,false), (110,false), (33,false), (27,false), (50,false), (62,false)]
theorem p2104 (F : Frame G 4) : c2104.eval F.assign = true := by
  apply local_rup F.assign c2104 [c1, c4, c5, c1125]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1125 F) (rfl))))
  · decide +kernel
def c2105 : CNF.Clause Nat := [(26,false), (29,false), (62,false), (50,false), (19,false), (88,false), (11,false), (9,false), (98,false)]
theorem p2105 (F : Frame G 4) : c2105.eval F.assign = true := by
  apply local_rup F.assign c2105 [c2, c1126]
  · exact sat_cons (p2 F) ( sat_cons (p1126 F) (rfl))
  · decide +kernel
def c2106 : CNF.Clause Nat := [(15,false), (50,false), (62,false), (29,false), (87,false), (88,false), (99,false)]
theorem p2106 (F : Frame G 4) : c2106.eval F.assign = true := by
  apply local_rup F.assign c2106 [c1, c2, c6, c1127]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p1127 F) (rfl))))
  · decide +kernel
def c2107 : CNF.Clause Nat := [(98,false), (110,false), (88,false), (30,false), (6,false), (38,false), (51,false)]
theorem p2107 (F : Frame G 4) : c2107.eval F.assign = true := by
  apply local_rup F.assign c2107 [c5, c3, c1, c1128]
  · exact sat_cons (p5 F) ( sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p1128 F) (rfl))))
  · decide +kernel
def c2108 : CNF.Clause Nat := [(50,false), (15,false), (40,false), (7,false), (9,false), (98,false), (30,false), (88,false)]
theorem p2108 (F : Frame G 4) : c2108.eval F.assign = true := by
  apply local_rup F.assign c2108 [c2, c6, c1129]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p1129 F) (rfl)))
  · decide +kernel
def c2109 : CNF.Clause Nat := [(62,false), (51,false), (38,false), (86,false), (21,false), (110,false)]
theorem p2109 (F : Frame G 4) : c2109.eval F.assign = true := by
  apply local_rup F.assign c2109 [c3, c1, c4, c5, c1130]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1130 F) (rfl)))))
  · decide +kernel
def c2110 : CNF.Clause Nat := [(26,false), (62,false), (51,false), (5,false), (19,false), (98,false), (110,false)]
theorem p2110 (F : Frame G 4) : c2110.eval F.assign = true := by
  apply local_rup F.assign c2110 [c3, c4, c5, c1131]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1131 F) (rfl))))
  · decide +kernel
def c2111 : CNF.Clause Nat := [(38,false), (17,false), (62,false), (29,false), (110,false), (11,false), (86,false)]
theorem p2111 (F : Frame G 4) : c2111.eval F.assign = true := by
  apply local_rup F.assign c2111 [c2, c6, c4, c1132]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1132 F) (rfl))))
  · decide +kernel
def c2112 : CNF.Clause Nat := [(38,false), (39,false), (62,false), (7,false), (9,false), (98,false), (87,false), (30,false), (33,false)]
theorem p2112 (F : Frame G 4) : c2112.eval F.assign = true := by
  apply local_rup F.assign c2112 [c2, c1133]
  · exact sat_cons (p2 F) ( sat_cons (p1133 F) (rfl))
  · decide +kernel
def c2113 : CNF.Clause Nat := [(38,false), (30,false), (62,false), (18,false), (98,false), (110,false)]
theorem p2113 (F : Frame G 4) : c2113.eval F.assign = true := by
  apply local_rup F.assign c2113 [c1, c4, c3, c5, c1134]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p1134 F) (rfl)))))
  · decide +kernel
def c2114 : CNF.Clause Nat := [(38,false), (19,false), (98,false), (110,false), (33,false), (62,false)]
theorem p2114 (F : Frame G 4) : c2114.eval F.assign = true := by
  apply local_rup F.assign c2114 [c1, c4, c5, c3, c1135]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p3 F) ( sat_cons (p1135 F) (rfl)))))
  · decide +kernel
def c2115 : CNF.Clause Nat := [(6,false), (38,false), (51,false), (18,false), (19,false), (87,false), (98,false), (31,false), (33,false)]
theorem p2115 (F : Frame G 4) : c2115.eval F.assign = true := by
  apply local_rup F.assign c2115 [c1, c1136]
  · exact sat_cons (p1 F) ( sat_cons (p1136 F) (rfl))
  · decide +kernel
def c2116 : CNF.Clause Nat := [(87,false), (110,false), (33,false), (31,false), (17,false), (39,false), (38,false), (51,false)]
theorem p2116 (F : Frame G 4) : c2116.eval F.assign = true := by
  apply local_rup F.assign c2116 [c4, c5, c1137]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1137 F) (rfl)))
  · decide +kernel
def c2117 : CNF.Clause Nat := [(39,false), (30,false), (33,false), (110,false), (98,false), (51,false)]
theorem p2117 (F : Frame G 4) : c2117.eval F.assign = true := by
  apply local_rup F.assign c2117 [c1, c4, c5, c2, c1138]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p1138 F) (rfl)))))
  · decide +kernel
def c2118 : CNF.Clause Nat := [(30,false), (87,false), (98,false), (22,false), (11,false), (38,false), (51,false)]
theorem p2118 (F : Frame G 4) : c2118.eval F.assign = true := by
  apply local_rup F.assign c2118 [c3, c5, c1, c1139]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p1139 F) (rfl))))
  · decide +kernel
def c2119 : CNF.Clause Nat := [(38,false), (88,false), (110,false), (98,false), (17,false), (29,false)]
theorem p2119 (F : Frame G 4) : c2119.eval F.assign = true := by
  apply local_rup F.assign c2119 [c1, c4, c5, c3, c1140]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p3 F) ( sat_cons (p1140 F) (rfl)))))
  · decide +kernel
def c2120 : CNF.Clause Nat := [(40,false), (51,false), (27,false), (17,false), (98,false), (87,false), (88,false)]
theorem p2120 (F : Frame G 4) : c2120.eval F.assign = true := by
  apply local_rup F.assign c2120 [c1, c3, c5, c1141]
  · exact sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p1141 F) (rfl))))
  · decide +kernel
def c2121 : CNF.Clause Nat := [(5,false), (40,false), (62,false), (30,false), (87,false), (98,false), (99,false)]
theorem p2121 (F : Frame G 4) : c2121.eval F.assign = true := by
  apply local_rup F.assign c2121 [c2, c1, c3, c1142]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p1142 F) (rfl))))
  · decide +kernel
def c2122 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (9,false), (7,false), (29,false), (30,false), (88,false), (110,false)]
theorem p2122 (F : Frame G 4) : c2122.eval F.assign = true := by
  apply local_rup F.assign c2122 [c5, c1143]
  · exact sat_cons (p5 F) ( sat_cons (p1143 F) (rfl))
  · decide +kernel
def c2123 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (19,false), (7,false), (29,false), (31,false), (99,false), (110,false)]
theorem p2123 (F : Frame G 4) : c2123.eval F.assign = true := by
  apply local_rup F.assign c2123 [c4, c1144]
  · exact sat_cons (p4 F) ( sat_cons (p1144 F) (rfl))
  · decide +kernel
def c2124 : CNF.Clause Nat := [(38,false), (19,false), (6,false), (62,false), (29,false), (31,false), (99,false), (110,false)]
theorem p2124 (F : Frame G 4) : c2124.eval F.assign = true := by
  apply local_rup F.assign c2124 [c2, c4, c1145]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1145 F) (rfl)))
  · decide +kernel
def c2125 : CNF.Clause Nat := [(26,false), (62,false), (51,false), (19,false), (9,false), (99,false), (110,false)]
theorem p2125 (F : Frame G 4) : c2125.eval F.assign = true := by
  apply local_rup F.assign c2125 [c3, c2, c4, c1146]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1146 F) (rfl))))
  · decide +kernel
def c2126 : CNF.Clause Nat := [(15,false), (51,false), (62,false), (6,false), (30,false), (31,false), (99,false), (110,false)]
theorem p2126 (F : Frame G 4) : c2126.eval F.assign = true := by
  apply local_rup F.assign c2126 [c2, c4, c1147]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1147 F) (rfl)))
  · decide +kernel
def c2127 : CNF.Clause Nat := [(38,false), (17,false), (62,false), (29,false), (110,false), (88,false), (9,false)]
theorem p2127 (F : Frame G 4) : c2127.eval F.assign = true := by
  apply local_rup F.assign c2127 [c2, c6, c4, c1148]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1148 F) (rfl))))
  · decide +kernel
def c2128 : CNF.Clause Nat := [(15,false), (50,false), (62,false), (29,false), (110,false), (88,false), (9,false)]
theorem p2128 (F : Frame G 4) : c2128.eval F.assign = true := by
  apply local_rup F.assign c2128 [c2, c6, c4, c1149]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1149 F) (rfl))))
  · decide +kernel
def c2129 : CNF.Clause Nat := [(99,false), (110,false), (30,false), (38,false), (50,false), (62,false)]
theorem p2129 (F : Frame G 4) : c2129.eval F.assign = true := by
  apply local_rup F.assign c2129 [c5, c6, c4, c1, c1150]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1 F) ( sat_cons (p1150 F) (rfl)))))
  · decide +kernel
def c2130 : CNF.Clause Nat := [(38,false), (51,false), (62,false), (30,false), (9,false), (21,false), (110,false)]
theorem p2130 (F : Frame G 4) : c2130.eval F.assign = true := by
  apply local_rup F.assign c2130 [c3, c4, c5, c1151]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1151 F) (rfl))))
  · decide +kernel
def c2131 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (18,false), (7,false), (30,false), (31,false), (99,false), (110,false)]
theorem p2131 (F : Frame G 4) : c2131.eval F.assign = true := by
  apply local_rup F.assign c2131 [c4, c1152]
  · exact sat_cons (p4 F) ( sat_cons (p1152 F) (rfl))
  · decide +kernel
def c2132 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (18,false), (7,false), (88,false), (99,false), (31,false)]
theorem p2132 (F : Frame G 4) : c2132.eval F.assign = true := by
  apply local_rup F.assign c2132 [c4, c6, c1153]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1153 F) (rfl)))
  · decide +kernel
def c2133 : CNF.Clause Nat := [(38,false), (50,false), (6,false), (19,false), (18,false), (29,false), (110,false), (99,false)]
theorem p2133 (F : Frame G 4) : c2133.eval F.assign = true := by
  apply local_rup F.assign c2133 [c4, c6, c1154]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1154 F) (rfl)))
  · decide +kernel
def c2134 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (18,false), (29,false), (10,false), (88,false), (99,false)]
theorem p2134 (F : Frame G 4) : c2134.eval F.assign = true := by
  apply local_rup F.assign c2134 [c6, c4, c1155]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1155 F) (rfl)))
  · decide +kernel
def c2135 : CNF.Clause Nat := [(27,false), (38,false), (40,false), (18,false), (19,false), (9,false), (99,false), (110,false)]
theorem p2135 (F : Frame G 4) : c2135.eval F.assign = true := by
  apply local_rup F.assign c2135 [c3, c4, c1156]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1156 F) (rfl)))
  · decide +kernel
def c2136 : CNF.Clause Nat := [(17,false), (38,false), (40,false), (29,false), (10,false), (88,false), (99,false)]
theorem p2136 (F : Frame G 4) : c2136.eval F.assign = true := by
  apply local_rup F.assign c2136 [c2, c6, c4, c1157]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1157 F) (rfl))))
  · decide +kernel
def c2137 : CNF.Clause Nat := [(40,false), (18,false), (50,false), (31,false), (99,false), (88,false), (10,false)]
theorem p2137 (F : Frame G 4) : c2137.eval F.assign = true := by
  apply local_rup F.assign c2137 [c2, c3, c4, c1158]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1158 F) (rfl))))
  · decide +kernel
def c2138 : CNF.Clause Nat := [(9,false), (87,false), (110,false), (33,false), (26,false), (39,false), (50,false), (51,false)]
theorem p2138 (F : Frame G 4) : c2138.eval F.assign = true := by
  apply local_rup F.assign c2138 [c5, c4, c1159]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1159 F) (rfl)))
  · decide +kernel
def c2139 : CNF.Clause Nat := [(11,false), (110,false), (87,false), (86,false), (15,false), (39,false), (27,false), (51,false)]
theorem p2139 (F : Frame G 4) : c2139.eval F.assign = true := by
  apply local_rup F.assign c2139 [c5, c3, c1160]
  · exact sat_cons (p5 F) ( sat_cons (p3 F) ( sat_cons (p1160 F) (rfl)))
  · decide +kernel
def c2140 : CNF.Clause Nat := [(11,false), (110,false), (21,false), (86,false), (30,false), (26,false), (39,false), (50,false), (51,false)]
theorem p2140 (F : Frame G 4) : c2140.eval F.assign = true := by
  apply local_rup F.assign c2140 [c5, c1161]
  · exact sat_cons (p5 F) ( sat_cons (p1161 F) (rfl))
  · decide +kernel
def c2141 : CNF.Clause Nat := [(11,false), (110,false), (87,false), (19,false), (31,false), (26,false), (39,false), (50,false), (51,false)]
theorem p2141 (F : Frame G 4) : c2141.eval F.assign = true := by
  apply local_rup F.assign c2141 [c5, c1162]
  · exact sat_cons (p5 F) ( sat_cons (p1162 F) (rfl))
  · decide +kernel
def c2142 : CNF.Clause Nat := [(11,false), (33,false), (39,false), (38,false), (51,false), (18,false), (86,false), (87,false)]
theorem p2142 (F : Frame G 4) : c2142.eval F.assign = true := by
  apply local_rup F.assign c2142 [c3, c5, c1163]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p1163 F) (rfl)))
  · decide +kernel
def c2143 : CNF.Clause Nat := [(9,false), (86,false), (88,false), (110,false), (29,false), (18,false), (38,false), (39,false)]
theorem p2143 (F : Frame G 4) : c2143.eval F.assign = true := by
  apply local_rup F.assign c2143 [c6, c2, c1165]
  · exact sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p1165 F) (rfl)))
  · decide +kernel
def c2144 : CNF.Clause Nat := [(40,false), (51,false), (5,false), (6,false), (30,false), (86,false), (21,false), (110,false)]
theorem p2144 (F : Frame G 4) : c2144.eval F.assign = true := by
  apply local_rup F.assign c2144 [c3, c5, c1166]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p1166 F) (rfl)))
  · decide +kernel
def c2145 : CNF.Clause Nat := [(40,false), (51,false), (5,false), (19,false), (17,false), (31,false), (99,false), (110,false)]
theorem p2145 (F : Frame G 4) : c2145.eval F.assign = true := by
  apply local_rup F.assign c2145 [c4, c3, c1167]
  · exact sat_cons (p4 F) ( sat_cons (p3 F) ( sat_cons (p1167 F) (rfl)))
  · decide +kernel
def c2146 : CNF.Clause Nat := [(86,false), (99,false), (110,false), (27,false), (17,false), (62,false)]
theorem p2146 (F : Frame G 4) : c2146.eval F.assign = true := by
  apply local_rup F.assign c2146 [c1, c4, c6, c2, c1168]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p1168 F) (rfl)))))
  · decide +kernel
def c2147 : CNF.Clause Nat := [(40,false), (51,false), (27,false), (6,false), (10,false), (110,false), (22,false), (19,false), (86,false)]
theorem p2147 (F : Frame G 4) : c2147.eval F.assign = true := by
  apply local_rup F.assign c2147 [c3, c1169]
  · exact sat_cons (p3 F) ( sat_cons (p1169 F) (rfl))
  · decide +kernel
def c2148 : CNF.Clause Nat := [(15,false), (51,false), (62,false), (110,false), (11,false), (86,false)]
theorem p2148 (F : Frame G 4) : c2148.eval F.assign = true := by
  apply local_rup F.assign c2148 [c2, c3, c6, c4, c1170]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1170 F) (rfl)))))
  · decide +kernel
def c2149 : CNF.Clause Nat := [(15,false), (51,false), (62,false), (6,false), (86,false), (99,false), (33,false)]
theorem p2149 (F : Frame G 4) : c2149.eval F.assign = true := by
  apply local_rup F.assign c2149 [c2, c4, c6, c1171]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1171 F) (rfl))))
  · decide +kernel
def c2150 : CNF.Clause Nat := [(62,false), (40,false), (38,false), (86,false), (10,false), (110,false)]
theorem p2150 (F : Frame G 4) : c2150.eval F.assign = true := by
  apply local_rup F.assign c2150 [c3, c2, c5, c4, c1172]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1172 F) (rfl)))))
  · decide +kernel
def c2151 : CNF.Clause Nat := [(62,false), (40,false), (38,false), (5,false), (86,false), (21,false), (110,false)]
theorem p2151 (F : Frame G 4) : c2151.eval F.assign = true := by
  apply local_rup F.assign c2151 [c3, c4, c5, c1173]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1173 F) (rfl))))
  · decide +kernel
def c2152 : CNF.Clause Nat := [(15,false), (51,false), (62,false), (6,false), (9,false), (86,false), (30,false), (110,false)]
theorem p2152 (F : Frame G 4) : c2152.eval F.assign = true := by
  apply local_rup F.assign c2152 [c2, c6, c1174]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p1174 F) (rfl)))
  · decide +kernel
def c2153 : CNF.Clause Nat := [(15,false), (51,false), (62,false), (6,false), (86,false), (31,false), (110,false)]
theorem p2153 (F : Frame G 4) : c2153.eval F.assign = true := by
  apply local_rup F.assign c2153 [c2, c4, c6, c1175]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1175 F) (rfl))))
  · decide +kernel
def c2154 : CNF.Clause Nat := [(26,false), (39,false), (50,false), (18,false), (7,false), (86,false), (99,false), (110,false)]
theorem p2154 (F : Frame G 4) : c2154.eval F.assign = true := by
  apply local_rup F.assign c2154 [c2, c4, c1176]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1176 F) (rfl)))
  · decide +kernel
def c2155 : CNF.Clause Nat := [(50,false), (62,false), (29,false), (26,false), (10,false), (110,false), (88,false), (86,false)]
theorem p2155 (F : Frame G 4) : c2155.eval F.assign = true := by
  apply local_rup F.assign c2155 [c2, c1, c1177]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p1177 F) (rfl)))
  · decide +kernel
def c2156 : CNF.Clause Nat := [(26,false), (62,false), (51,false), (86,false), (10,false), (110,false)]
theorem p2156 (F : Frame G 4) : c2156.eval F.assign = true := by
  apply local_rup F.assign c2156 [c3, c2, c5, c4, c1178]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1178 F) (rfl)))))
  · decide +kernel
def c2157 : CNF.Clause Nat := [(26,false), (39,false), (62,false), (51,false), (21,false), (110,false), (11,false), (86,false)]
theorem p2157 (F : Frame G 4) : c2157.eval F.assign = true := by
  apply local_rup F.assign c2157 [c2, c4, c1179]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1179 F) (rfl)))
  · decide +kernel
def c2158 : CNF.Clause Nat := [(39,false), (38,false), (51,false), (7,false), (9,false), (19,false), (88,false), (110,false)]
theorem p2158 (F : Frame G 4) : c2158.eval F.assign = true := by
  apply local_rup F.assign c2158 [c3, c5, c1180]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p1180 F) (rfl)))
  · decide +kernel
def c2159 : CNF.Clause Nat := [(29,false), (51,false), (38,false), (86,false), (21,false), (110,false)]
theorem p2159 (F : Frame G 4) : c2159.eval F.assign = true := by
  apply local_rup F.assign c2159 [c3, c1, c4, c5, c1181]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1181 F) (rfl)))))
  · decide +kernel
def c2160 : CNF.Clause Nat := [(15,false), (39,false), (50,false), (51,false), (29,false), (10,false), (86,false), (99,false)]
theorem p2160 (F : Frame G 4) : c2160.eval F.assign = true := by
  apply local_rup F.assign c2160 [c6, c4, c1182]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1182 F) (rfl)))
  · decide +kernel
def c2161 : CNF.Clause Nat := [(51,false), (7,false), (39,false), (110,false), (88,false), (86,false)]
theorem p2161 (F : Frame G 4) : c2161.eval F.assign = true := by
  apply local_rup F.assign c2161 [c2, c1, c3, c6, c1183]
  · exact sat_cons (p2 F) ( sat_cons (p1 F) ( sat_cons (p3 F) ( sat_cons (p6 F) ( sat_cons (p1183 F) (rfl)))))
  · decide +kernel
def c2162 : CNF.Clause Nat := [(29,false), (51,false), (38,false), (10,false), (110,false), (22,false), (19,false), (86,false)]
theorem p2162 (F : Frame G 4) : c2162.eval F.assign = true := by
  apply local_rup F.assign c2162 [c3, c1, c1184]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p1184 F) (rfl)))
  · decide +kernel
def c2163 : CNF.Clause Nat := [(39,false), (38,false), (51,false), (18,false), (31,false), (10,false), (88,false)]
theorem p2163 (F : Frame G 4) : c2163.eval F.assign = true := by
  apply local_rup F.assign c2163 [c5, c6, c4, c1185]
  · exact sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p1185 F) (rfl))))
  · decide +kernel
def c2164 : CNF.Clause Nat := [(88,false), (99,false), (21,false), (26,false), (38,false), (51,false), (62,false)]
theorem p2164 (F : Frame G 4) : c2164.eval F.assign = true := by
  apply local_rup F.assign c2164 [c4, c5, c6, c1186]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1186 F) (rfl))))
  · decide +kernel
def c2165 : CNF.Clause Nat := [(88,false), (99,false), (21,false), (39,false), (38,false), (51,false)]
theorem p2165 (F : Frame G 4) : c2165.eval F.assign = true := by
  apply local_rup F.assign c2165 [c4, c5, c6, c3, c1187]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p1187 F) (rfl)))))
  · decide +kernel
def c2166 : CNF.Clause Nat := [(39,false), (50,false), (27,false), (31,false), (18,false), (7,false), (88,false), (110,false)]
theorem p2166 (F : Frame G 4) : c2166.eval F.assign = true := by
  apply local_rup F.assign c2166 [c5, c4, c1188]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1188 F) (rfl)))
  · decide +kernel
def c2167 : CNF.Clause Nat := [(15,false), (50,false), (62,false), (29,false), (31,false), (99,false), (88,false), (10,false)]
theorem p2167 (F : Frame G 4) : c2167.eval F.assign = true := by
  apply local_rup F.assign c2167 [c2, c4, c1189]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1189 F) (rfl)))
  · decide +kernel
def c2168 : CNF.Clause Nat := [(27,false), (50,false), (62,false), (40,false), (15,false), (19,false), (9,false), (99,false), (110,false)]
theorem p2168 (F : Frame G 4) : c2168.eval F.assign = true := by
  apply local_rup F.assign c2168 [c4, c1190]
  · exact sat_cons (p4 F) ( sat_cons (p1190 F) (rfl))
  · decide +kernel
def c2169 : CNF.Clause Nat := [(26,false), (27,false), (50,false), (62,false), (18,false), (19,false), (9,false), (99,false), (110,false)]
theorem p2169 (F : Frame G 4) : c2169.eval F.assign = true := by
  apply local_rup F.assign c2169 [c4, c1191]
  · exact sat_cons (p4 F) ( sat_cons (p1191 F) (rfl))
  · decide +kernel
def c2170 : CNF.Clause Nat := [(27,false), (110,false), (88,false), (19,false), (9,false), (39,false), (62,false)]
theorem p2170 (F : Frame G 4) : c2170.eval F.assign = true := by
  apply local_rup F.assign c2170 [c6, c5, c1, c1192]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p1192 F) (rfl))))
  · decide +kernel
def c2171 : CNF.Clause Nat := [(40,false), (62,false), (50,false), (31,false), (30,false), (88,false), (110,false)]
theorem p2171 (F : Frame G 4) : c2171.eval F.assign = true := by
  apply local_rup F.assign c2171 [c1, c2, c5, c1193]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1193 F) (rfl))))
  · decide +kernel
def c2172 : CNF.Clause Nat := [(10,false), (88,false), (99,false), (15,false), (39,false), (50,false), (51,false)]
theorem p2172 (F : Frame G 4) : c2172.eval F.assign = true := by
  apply local_rup F.assign c2172 [c6, c4, c5, c1194]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1194 F) (rfl))))
  · decide +kernel
def c2173 : CNF.Clause Nat := [(40,false), (51,false), (50,false), (17,false), (19,false), (87,false), (31,false), (99,false)]
theorem p2173 (F : Frame G 4) : c2173.eval F.assign = true := by
  apply local_rup F.assign c2173 [c1, c6, c1195]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p1195 F) (rfl)))
  · decide +kernel
def c2174 : CNF.Clause Nat := [(40,false), (51,false), (17,false), (31,false), (99,false), (88,false), (87,false)]
theorem p2174 (F : Frame G 4) : c2174.eval F.assign = true := by
  apply local_rup F.assign c2174 [c1, c2, c3, c1196]
  · exact sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1196 F) (rfl))))
  · decide +kernel
def c2175 : CNF.Clause Nat := [(19,false), (88,false), (99,false), (31,false), (10,false), (39,false), (50,false), (51,false)]
theorem p2175 (F : Frame G 4) : c2175.eval F.assign = true := by
  apply local_rup F.assign c2175 [c6, c1, c1197]
  · exact sat_cons (p6 F) ( sat_cons (p1 F) ( sat_cons (p1197 F) (rfl)))
  · decide +kernel
def c2176 : CNF.Clause Nat := [(88,false), (99,false), (31,false), (21,false), (50,false), (62,false)]
theorem p2176 (F : Frame G 4) : c2176.eval F.assign = true := by
  apply local_rup F.assign c2176 [c1, c4, c6, c2, c1198]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p2 F) ( sat_cons (p1198 F) (rfl)))))
  · decide +kernel
def c2177 : CNF.Clause Nat := [(26,false), (38,false), (51,false), (18,false), (19,false), (9,false), (99,false), (110,false)]
theorem p2177 (F : Frame G 4) : c2177.eval F.assign = true := by
  apply local_rup F.assign c2177 [c3, c4, c1199]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1199 F) (rfl)))
  · decide +kernel
def c2178 : CNF.Clause Nat := [(6,false), (50,false), (51,false), (29,false), (31,false), (19,false), (88,false), (110,false)]
theorem p2178 (F : Frame G 4) : c2178.eval F.assign = true := by
  apply local_rup F.assign c2178 [c1, c5, c1200]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p1200 F) (rfl)))
  · decide +kernel
def c2179 : CNF.Clause Nat := [(39,false), (6,false), (88,false), (99,false), (51,false), (29,false)]
theorem p2179 (F : Frame G 4) : c2179.eval F.assign = true := by
  apply local_rup F.assign c2179 [c4, c5, c2, c6, c1201]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p1201 F) (rfl)))))
  · decide +kernel
def c2180 : CNF.Clause Nat := [(62,false), (40,false), (5,false), (98,false), (87,false), (88,false)]
theorem p2180 (F : Frame G 4) : c2180.eval F.assign = true := by
  apply local_rup F.assign c2180 [c3, c1, c2, c5, c1202]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1202 F) (rfl)))))
  · decide +kernel
def c2181 : CNF.Clause Nat := [(38,false), (39,false), (62,false), (7,false), (30,false), (31,false), (21,false), (110,false)]
theorem p2181 (F : Frame G 4) : c2181.eval F.assign = true := by
  apply local_rup F.assign c2181 [c4, c5, c1203]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1203 F) (rfl)))
  · decide +kernel
def c2182 : CNF.Clause Nat := [(38,false), (39,false), (62,false), (7,false), (30,false), (31,false), (99,false), (110,false)]
theorem p2182 (F : Frame G 4) : c2182.eval F.assign = true := by
  apply local_rup F.assign c2182 [c2, c4, c1204]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1204 F) (rfl)))
  · decide +kernel
def c2183 : CNF.Clause Nat := [(62,false), (40,false), (38,false), (5,false), (19,false), (99,false), (110,false)]
theorem p2183 (F : Frame G 4) : c2183.eval F.assign = true := by
  apply local_rup F.assign c2183 [c3, c4, c5, c1205]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1205 F) (rfl))))
  · decide +kernel
def c2184 : CNF.Clause Nat := [(26,false), (62,false), (51,false), (5,false), (19,false), (99,false), (110,false)]
theorem p2184 (F : Frame G 4) : c2184.eval F.assign = true := by
  apply local_rup F.assign c2184 [c3, c4, c5, c1206]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1206 F) (rfl))))
  · decide +kernel
def c2185 : CNF.Clause Nat := [(88,false), (110,false), (31,false), (51,false), (62,false)]
theorem p2185 (F : Frame G 4) : c2185.eval F.assign = true := by
  apply local_rup F.assign c2185 [c1, c4, c6, c5, c2, c1207]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p1207 F) (rfl))))))
  · decide +kernel
def c2186 : CNF.Clause Nat := [(50,false), (17,false), (15,false), (40,false), (7,false), (30,false), (31,false), (98,false), (110,false)]
theorem p2186 (F : Frame G 4) : c2186.eval F.assign = true := by
  apply local_rup F.assign c2186 [c4, c1208]
  · exact sat_cons (p4 F) ( sat_cons (p1208 F) (rfl))
  · decide +kernel
def c2187 : CNF.Clause Nat := [(18,false), (40,false), (39,false), (6,false), (30,false), (31,false), (98,false), (110,false)]
theorem p2187 (F : Frame G 4) : c2187.eval F.assign = true := by
  apply local_rup F.assign c2187 [c2, c4, c1209]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1209 F) (rfl)))
  · decide +kernel
def c2188 : CNF.Clause Nat := [(50,false), (17,false), (18,false), (40,false), (11,false), (110,false), (87,false), (30,false), (31,false)]
theorem p2188 (F : Frame G 4) : c2188.eval F.assign = true := by
  apply local_rup F.assign c2188 [c1, c1210]
  · exact sat_cons (p1 F) ( sat_cons (p1210 F) (rfl))
  · decide +kernel
def c2189 : CNF.Clause Nat := [(50,false), (39,false), (40,false), (7,false), (9,false), (98,false), (87,false), (30,false), (33,false)]
theorem p2189 (F : Frame G 4) : c2189.eval F.assign = true := by
  apply local_rup F.assign c2189 [c2, c1211]
  · exact sat_cons (p2 F) ( sat_cons (p1211 F) (rfl))
  · decide +kernel
def c2190 : CNF.Clause Nat := [(39,false), (40,false), (7,false), (5,false), (31,false), (30,false), (87,false), (110,false)]
theorem p2190 (F : Frame G 4) : c2190.eval F.assign = true := by
  apply local_rup F.assign c2190 [c2, c5, c1212]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p1212 F) (rfl)))
  · decide +kernel
def c2191 : CNF.Clause Nat := [(87,false), (110,false), (33,false), (31,false), (15,false), (40,false), (51,false), (50,false)]
theorem p2191 (F : Frame G 4) : c2191.eval F.assign = true := by
  apply local_rup F.assign c2191 [c4, c5, c1213]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1213 F) (rfl)))
  · decide +kernel
def c2192 : CNF.Clause Nat := [(17,false), (50,false), (51,false), (40,false), (9,false), (98,false), (87,false), (30,false), (33,false)]
theorem p2192 (F : Frame G 4) : c2192.eval F.assign = true := by
  apply local_rup F.assign c2192 [c1, c1214]
  · exact sat_cons (p1 F) ( sat_cons (p1214 F) (rfl))
  · decide +kernel
def c2193 : CNF.Clause Nat := [(19,false), (17,false), (50,false), (38,false), (40,false), (29,false), (31,false), (98,false), (110,false)]
theorem p2193 (F : Frame G 4) : c2193.eval F.assign = true := by
  apply local_rup F.assign c2193 [c4, c1215]
  · exact sat_cons (p4 F) ( sat_cons (p1215 F) (rfl))
  · decide +kernel
def c2194 : CNF.Clause Nat := [(62,false), (40,false), (38,false), (5,false), (19,false), (98,false), (110,false)]
theorem p2194 (F : Frame G 4) : c2194.eval F.assign = true := by
  apply local_rup F.assign c2194 [c3, c4, c5, c1216]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1216 F) (rfl))))
  · decide +kernel
def c2195 : CNF.Clause Nat := [(38,false), (40,false), (62,false), (6,false), (19,false), (22,false), (110,false), (31,false)]
theorem p2195 (F : Frame G 4) : c2195.eval F.assign = true := by
  apply local_rup F.assign c2195 [c4, c6, c1217]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1217 F) (rfl)))
  · decide +kernel
def c2196 : CNF.Clause Nat := [(27,false), (62,false), (40,false), (19,false), (98,false), (110,false)]
theorem p2196 (F : Frame G 4) : c2196.eval F.assign = true := by
  apply local_rup F.assign c2196 [c3, c1, c4, c5, c1218]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1218 F) (rfl)))))
  · decide +kernel
def c2197 : CNF.Clause Nat := [(18,false), (40,false), (39,false), (6,false), (88,false), (99,false), (31,false)]
theorem p2197 (F : Frame G 4) : c2197.eval F.assign = true := by
  apply local_rup F.assign c2197 [c2, c4, c6, c1219]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1219 F) (rfl))))
  · decide +kernel
def c2198 : CNF.Clause Nat := [(17,false), (50,false), (38,false), (40,false), (29,false), (30,false), (9,false), (98,false), (110,false)]
theorem p2198 (F : Frame G 4) : c2198.eval F.assign = true := by
  apply local_rup F.assign c2198 [c4, c1220]
  · exact sat_cons (p4 F) ( sat_cons (p1220 F) (rfl))
  · decide +kernel
def c2199 : CNF.Clause Nat := [(5,false), (6,false), (39,false), (40,false), (18,false), (98,false), (87,false), (30,false), (33,false)]
theorem p2199 (F : Frame G 4) : c2199.eval F.assign = true := by
  apply local_rup F.assign c2199 [c5, c1221]
  · exact sat_cons (p5 F) ( sat_cons (p1221 F) (rfl))
  · decide +kernel
def c2200 : CNF.Clause Nat := [(5,false), (87,false), (98,false), (17,false), (39,false), (40,false), (29,false), (33,false)]
theorem p2200 (F : Frame G 4) : c2200.eval F.assign = true := by
  apply local_rup F.assign c2200 [c4, c5, c1222]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1222 F) (rfl)))
  · decide +kernel
def c2201 : CNF.Clause Nat := [(40,false), (7,false), (87,false), (110,false), (99,false), (27,false)]
theorem p2201 (F : Frame G 4) : c2201.eval F.assign = true := by
  apply local_rup F.assign c2201 [c4, c5, c2, c3, c1223]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p1223 F) (rfl)))))
  · decide +kernel
def c2202 : CNF.Clause Nat := [(40,false), (18,false), (50,false), (31,false), (99,false), (11,false), (87,false)]
theorem p2202 (F : Frame G 4) : c2202.eval F.assign = true := by
  apply local_rup F.assign c2202 [c2, c3, c4, c1224]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1224 F) (rfl))))
  · decide +kernel
def c2203 : CNF.Clause Nat := [(50,false), (51,false), (40,false), (87,false), (110,false), (22,false)]
theorem p2203 (F : Frame G 4) : c2203.eval F.assign = true := by
  apply local_rup F.assign c2203 [c3, c1, c4, c5, c1225]
  · exact sat_cons (p3 F) ( sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1225 F) (rfl)))))
  · decide +kernel
def c2204 : CNF.Clause Nat := [(9,false), (11,false), (110,false), (87,false), (30,false), (39,false), (40,false)]
theorem p2204 (F : Frame G 4) : c2204.eval F.assign = true := by
  apply local_rup F.assign c2204 [c2, c5, c3, c1226]
  · exact sat_cons (p2 F) ( sat_cons (p5 F) ( sat_cons (p3 F) ( sat_cons (p1226 F) (rfl))))
  · decide +kernel
def c2205 : CNF.Clause Nat := [(17,false), (62,false), (40,false), (26,false), (30,false), (9,false), (98,false), (110,false)]
theorem p2205 (F : Frame G 4) : c2205.eval F.assign = true := by
  apply local_rup F.assign c2205 [c2, c4, c1227]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1227 F) (rfl)))
  · decide +kernel
def c2206 : CNF.Clause Nat := [(38,false), (15,false), (17,false), (62,false), (29,false), (30,false), (9,false), (98,false), (110,false)]
theorem p2206 (F : Frame G 4) : c2206.eval F.assign = true := by
  apply local_rup F.assign c2206 [c4, c1228]
  · exact sat_cons (p4 F) ( sat_cons (p1228 F) (rfl))
  · decide +kernel
def c2207 : CNF.Clause Nat := [(38,false), (40,false), (62,false), (6,false), (9,false), (98,false), (87,false), (30,false), (33,false)]
theorem p2207 (F : Frame G 4) : c2207.eval F.assign = true := by
  apply local_rup F.assign c2207 [c2, c1229]
  · exact sat_cons (p2 F) ( sat_cons (p1229 F) (rfl))
  · decide +kernel
def c2208 : CNF.Clause Nat := [(87,false), (98,false), (22,false), (33,false), (27,false), (38,false), (39,false), (62,false)]
theorem p2208 (F : Frame G 4) : c2208.eval F.assign = true := by
  apply local_rup F.assign c2208 [c4, c5, c1230]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1230 F) (rfl)))
  · decide +kernel
def c2209 : CNF.Clause Nat := [(38,false), (5,false), (7,false), (62,false), (17,false), (98,false), (87,false), (30,false), (33,false)]
theorem p2209 (F : Frame G 4) : c2209.eval F.assign = true := by
  apply local_rup F.assign c2209 [c5, c1231]
  · exact sat_cons (p5 F) ( sat_cons (p1231 F) (rfl))
  · decide +kernel
def c2210 : CNF.Clause Nat := [(18,false), (40,false), (39,false), (6,false), (87,false), (98,false), (31,false), (33,false)]
theorem p2210 (F : Frame G 4) : c2210.eval F.assign = true := by
  apply local_rup F.assign c2210 [c2, c4, c1232]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1232 F) (rfl)))
  · decide +kernel
def c2211 : CNF.Clause Nat := [(110,false), (88,false), (19,false), (9,false), (39,false), (50,false), (51,false)]
theorem p2211 (F : Frame G 4) : c2211.eval F.assign = true := by
  apply local_rup F.assign c2211 [c6, c5, c1, c1233]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1 F) ( sat_cons (p1233 F) (rfl))))
  · decide +kernel
def c2212 : CNF.Clause Nat := [(39,false), (30,false), (110,false), (99,false), (51,false)]
theorem p2212 (F : Frame G 4) : c2212.eval F.assign = true := by
  apply local_rup F.assign c2212 [c1, c4, c6, c5, c2, c1234]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p2 F) ( sat_cons (p1234 F) (rfl))))))
  · decide +kernel
def c2213 : CNF.Clause Nat := [(15,false), (51,false), (62,false), (30,false), (9,false), (99,false), (110,false)]
theorem p2213 (F : Frame G 4) : c2213.eval F.assign = true := by
  apply local_rup F.assign c2213 [c2, c3, c4, c1235]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1235 F) (rfl))))
  · decide +kernel
def c2214 : CNF.Clause Nat := [(110,false), (88,false), (9,false), (15,false), (40,false), (51,false), (50,false)]
theorem p2214 (F : Frame G 4) : c2214.eval F.assign = true := by
  apply local_rup F.assign c2214 [c6, c4, c5, c1236]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1236 F) (rfl))))
  · decide +kernel
def c2215 : CNF.Clause Nat := [(110,false), (88,false), (19,false), (9,false), (5,false), (51,false), (40,false), (39,false)]
theorem p2215 (F : Frame G 4) : c2215.eval F.assign = true := by
  apply local_rup F.assign c2215 [c6, c5, c1237]
  · exact sat_cons (p6 F) ( sat_cons (p5 F) ( sat_cons (p1237 F) (rfl)))
  · decide +kernel
def c2216 : CNF.Clause Nat := [(5,false), (51,false), (62,false), (17,false), (99,false), (88,false), (30,false)]
theorem p2216 (F : Frame G 4) : c2216.eval F.assign = true := by
  apply local_rup F.assign c2216 [c1, c5, c6, c1238]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1238 F) (rfl))))
  · decide +kernel
def c2217 : CNF.Clause Nat := [(38,false), (40,false), (62,false), (6,false), (30,false), (31,false), (99,false), (110,false)]
theorem p2217 (F : Frame G 4) : c2217.eval F.assign = true := by
  apply local_rup F.assign c2217 [c2, c4, c1239]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1239 F) (rfl)))
  · decide +kernel
def c2218 : CNF.Clause Nat := [(5,false), (40,false), (62,false), (17,false), (31,false), (30,false), (88,false), (110,false)]
theorem p2218 (F : Frame G 4) : c2218.eval F.assign = true := by
  apply local_rup F.assign c2218 [c1, c5, c1240]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p1240 F) (rfl)))
  · decide +kernel
def c2219 : CNF.Clause Nat := [(5,false), (39,false), (62,false), (18,false), (31,false), (30,false), (88,false), (110,false)]
theorem p2219 (F : Frame G 4) : c2219.eval F.assign = true := by
  apply local_rup F.assign c2219 [c1, c5, c1241]
  · exact sat_cons (p1 F) ( sat_cons (p5 F) ( sat_cons (p1241 F) (rfl)))
  · decide +kernel
def c2220 : CNF.Clause Nat := [(38,false), (51,false), (62,false), (6,false), (19,false), (99,false), (33,false)]
theorem p2220 (F : Frame G 4) : c2220.eval F.assign = true := by
  apply local_rup F.assign c2220 [c4, c5, c6, c1242]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p6 F) ( sat_cons (p1242 F) (rfl))))
  · decide +kernel
def c2221 : CNF.Clause Nat := [(110,false), (88,false), (9,false), (18,false), (40,false), (38,false), (50,false)]
theorem p2221 (F : Frame G 4) : c2221.eval F.assign = true := by
  apply local_rup F.assign c2221 [c6, c4, c5, c1243]
  · exact sat_cons (p6 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1243 F) (rfl))))
  · decide +kernel
def c2222 : CNF.Clause Nat := [(19,false), (6,false), (39,false), (40,false), (29,false), (31,false), (99,false), (110,false)]
theorem p2222 (F : Frame G 4) : c2222.eval F.assign = true := by
  apply local_rup F.assign c2222 [c2, c4, c1244]
  · exact sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1244 F) (rfl)))
  · decide +kernel
def c2223 : CNF.Clause Nat := [(19,false), (88,false), (99,false), (9,false), (6,false), (39,false), (40,false), (29,false)]
theorem p2223 (F : Frame G 4) : c2223.eval F.assign = true := by
  apply local_rup F.assign c2223 [c2, c6, c1245]
  · exact sat_cons (p2 F) ( sat_cons (p6 F) ( sat_cons (p1245 F) (rfl)))
  · decide +kernel
def c2224 : CNF.Clause Nat := [(38,false), (26,false), (62,false), (7,false), (19,false), (99,false), (110,false)]
theorem p2224 (F : Frame G 4) : c2224.eval F.assign = true := by
  apply local_rup F.assign c2224 [c3, c4, c5, c1246]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1246 F) (rfl))))
  · decide +kernel
def c2225 : CNF.Clause Nat := [(40,false), (29,false), (50,false), (19,false), (87,false), (10,false), (9,false), (99,false)]
theorem p2225 (F : Frame G 4) : c2225.eval F.assign = true := by
  apply local_rup F.assign c2225 [c3, c2, c1247]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p1247 F) (rfl)))
  · decide +kernel
def c2226 : CNF.Clause Nat := [(40,false), (29,false), (50,false), (5,false), (19,false), (99,false), (110,false)]
theorem p2226 (F : Frame G 4) : c2226.eval F.assign = true := by
  apply local_rup F.assign c2226 [c3, c4, c5, c1248]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1248 F) (rfl))))
  · decide +kernel
def c2227 : CNF.Clause Nat := [(38,false), (15,false), (19,false), (9,false), (99,false), (110,false), (62,false)]
theorem p2227 (F : Frame G 4) : c2227.eval F.assign = true := by
  apply local_rup F.assign c2227 [c4, c6, c3, c1249]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p3 F) ( sat_cons (p1249 F) (rfl))))
  · decide +kernel
def c2228 : CNF.Clause Nat := [(62,false), (40,false), (38,false), (21,false), (110,false), (88,false), (9,false)]
theorem p2228 (F : Frame G 4) : c2228.eval F.assign = true := by
  apply local_rup F.assign c2228 [c3, c2, c4, c1250]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1250 F) (rfl))))
  · decide +kernel
def c2229 : CNF.Clause Nat := [(38,false), (51,false), (18,false), (17,false), (30,false), (9,false), (99,false), (110,false)]
theorem p2229 (F : Frame G 4) : c2229.eval F.assign = true := by
  apply local_rup F.assign c2229 [c3, c4, c1251]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1251 F) (rfl)))
  · decide +kernel
def c2230 : CNF.Clause Nat := [(88,false), (99,false), (31,false), (21,false), (17,false), (50,false), (38,false), (40,false)]
theorem p2230 (F : Frame G 4) : c2230.eval F.assign = true := by
  apply local_rup F.assign c2230 [c4, c6, c1252]
  · exact sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1252 F) (rfl)))
  · decide +kernel
def c2231 : CNF.Clause Nat := [(29,false), (51,false), (38,false), (15,false), (19,false), (9,false), (99,false), (110,false)]
theorem p2231 (F : Frame G 4) : c2231.eval F.assign = true := by
  apply local_rup F.assign c2231 [c3, c4, c1253]
  · exact sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1253 F) (rfl)))
  · decide +kernel
def c2232 : CNF.Clause Nat := [(38,false), (50,false), (17,false), (99,false), (33,false), (29,false), (7,false), (87,false)]
theorem p2232 (F : Frame G 4) : c2232.eval F.assign = true := by
  apply local_rup F.assign c2232 [c5, c4, c1254]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1254 F) (rfl)))
  · decide +kernel
def c2233 : CNF.Clause Nat := [(15,false), (50,false), (6,false), (7,false), (29,false), (30,false), (87,false), (110,false), (99,false)]
theorem p2233 (F : Frame G 4) : c2233.eval F.assign = true := by
  apply local_rup F.assign c2233 [c2, c1255]
  · exact sat_cons (p2 F) ( sat_cons (p1255 F) (rfl))
  · decide +kernel
def c2234 : CNF.Clause Nat := [(50,false), (15,false), (40,false), (7,false), (87,false), (110,false), (99,false)]
theorem p2234 (F : Frame G 4) : c2234.eval F.assign = true := by
  apply local_rup F.assign c2234 [c3, c2, c4, c1256]
  · exact sat_cons (p3 F) ( sat_cons (p2 F) ( sat_cons (p4 F) ( sat_cons (p1256 F) (rfl))))
  · decide +kernel
def c2235 : CNF.Clause Nat := [(50,false), (51,false), (40,false), (15,false), (19,false), (87,false), (10,false), (9,false), (99,false)]
theorem p2235 (F : Frame G 4) : c2235.eval F.assign = true := by
  apply local_rup F.assign c2235 [c3, c1257]
  · exact sat_cons (p3 F) ( sat_cons (p1257 F) (rfl))
  · decide +kernel
def c2236 : CNF.Clause Nat := [(51,false), (62,false), (17,false), (15,false), (87,false), (31,false), (99,false)]
theorem p2236 (F : Frame G 4) : c2236.eval F.assign = true := by
  apply local_rup F.assign c2236 [c1, c4, c6, c1258]
  · exact sat_cons (p1 F) ( sat_cons (p4 F) ( sat_cons (p6 F) ( sat_cons (p1258 F) (rfl))))
  · decide +kernel
def c2237 : CNF.Clause Nat := [(40,false), (51,false), (17,false), (31,false), (99,false), (11,false), (87,false)]
theorem p2237 (F : Frame G 4) : c2237.eval F.assign = true := by
  apply local_rup F.assign c2237 [c2, c3, c4, c1259]
  · exact sat_cons (p2 F) ( sat_cons (p3 F) ( sat_cons (p4 F) ( sat_cons (p1259 F) (rfl))))
  · decide +kernel
def c2238 : CNF.Clause Nat := [(27,false), (39,false), (40,false), (7,false), (10,false), (110,false), (88,false), (19,false)]
theorem p2238 (F : Frame G 4) : c2238.eval F.assign = true := by
  apply local_rup F.assign c2238 [c3, c5, c1260]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p1260 F) (rfl)))
  · decide +kernel
def c2239 : CNF.Clause Nat := [(50,false), (17,false), (18,false), (40,false), (9,false), (99,false), (88,false), (30,false)]
theorem p2239 (F : Frame G 4) : c2239.eval F.assign = true := by
  apply local_rup F.assign c2239 [c1, c6, c1261]
  · exact sat_cons (p1 F) ( sat_cons (p6 F) ( sat_cons (p1261 F) (rfl)))
  · decide +kernel
def c2240 : CNF.Clause Nat := [(40,false), (51,false), (5,false), (6,false), (31,false), (19,false), (87,false), (110,false)]
theorem p2240 (F : Frame G 4) : c2240.eval F.assign = true := by
  apply local_rup F.assign c2240 [c3, c5, c1262]
  · exact sat_cons (p3 F) ( sat_cons (p5 F) ( sat_cons (p1262 F) (rfl)))
  · decide +kernel
def c2241 : CNF.Clause Nat := [(40,false), (29,false), (27,false), (50,false), (6,false), (19,false), (99,false), (110,false)]
theorem p2241 (F : Frame G 4) : c2241.eval F.assign = true := by
  apply local_rup F.assign c2241 [c4, c5, c1263]
  · exact sat_cons (p4 F) ( sat_cons (p5 F) ( sat_cons (p1263 F) (rfl)))
  · decide +kernel
def c2242 : CNF.Clause Nat := [(39,false), (40,false), (7,false), (5,false), (27,false), (31,false), (19,false), (88,false), (110,false)]
theorem p2242 (F : Frame G 4) : c2242.eval F.assign = true := by
  apply local_rup F.assign c2242 [c5, c1264]
  · exact sat_cons (p5 F) ( sat_cons (p1264 F) (rfl))
  · decide +kernel
def c2243 : CNF.Clause Nat := [(50,false), (51,false), (29,false), (26,false), (15,false), (99,false), (88,false), (10,false)]
theorem p2243 (F : Frame G 4) : c2243.eval F.assign = true := by
  apply local_rup F.assign c2243 [c5, c4, c1265]
  · exact sat_cons (p5 F) ( sat_cons (p4 F) ( sat_cons (p1265 F) (rfl)))
  · decide +kernel
def c2244 : CNF.Clause Nat := [(17,false), (50,false), (51,false), (40,false), (26,false), (30,false), (9,false), (99,false), (110,false)]
theorem p2244 (F : Frame G 4) : c2244.eval F.assign = true := by
  apply local_rup F.assign c2244 [c4, c1266]
  · exact sat_cons (p4 F) ( sat_cons (p1266 F) (rfl))
  · decide +kernel
def c2245 : CNF.Clause Nat := [(40,false), (29,false), (27,false), (50,false), (17,false), (19,false), (9,false), (99,false), (110,false)]
theorem p2245 (F : Frame G 4) : c2245.eval F.assign = true := by
  apply local_rup F.assign c2245 [c4, c1267]
  · exact sat_cons (p4 F) ( sat_cons (p1267 F) (rfl))
  · decide +kernel
def c2246 : CNF.Clause Nat := [(51,false), (38,true), (62,false), (86,false), (88,false), (98,false), (110,false)]
theorem p2246 (F : Frame G 4) : c2246.eval F.assign = true := by
  apply local_rup F.assign c2246 [c1410, c1366, c2067, c7]
  · exact sat_cons (p1410 F) ( sat_cons (p1366 F) ( sat_cons (p2067 F) ( sat_cons (p7 F) (rfl))))
  · decide +kernel
def c2247 : CNF.Clause Nat := [(40,true), (15,true), (51,true), (62,false), (87,false), (88,false), (98,false), (99,false), (110,false)]
theorem p2247 (F : Frame G 4) : c2247.eval F.assign = true := by
  apply local_rup F.assign c2247 [c2088, c9, c134, c1992, c13, c1409, c1804, c20]
  · exact sat_cons (p2088 F) ( sat_cons (p9 F) ( sat_cons (p134 F) ( sat_cons (p1992 F) ( sat_cons (p13 F) ( sat_cons (p1409 F) ( sat_cons (p1804 F) ( sat_cons (p20 F) (rfl))))))))
  · decide +kernel
def c2248 : CNF.Clause Nat := [(38,true), (27,true), (40,false), (51,true), (86,false), (88,false), (110,false)]
theorem p2248 (F : Frame G 4) : c2248.eval F.assign = true := by
  apply local_rup F.assign c2248 [c140, c13, c1912]
  · exact sat_cons (p140 F) ( sat_cons (p13 F) ( sat_cons (p1912 F) (rfl)))
  · decide +kernel
def c2249 : CNF.Clause Nat := [(27,true), (51,true), (62,true), (86,false), (88,false), (98,false), (99,false), (110,false)]
theorem p2249 (F : Frame G 4) : c2249.eval F.assign = true := by
  apply local_rup F.assign c2249 [c138, c2011, c2248, c1627, c15, c82, c1912]
  · exact sat_cons (p138 F) ( sat_cons (p2011 F) ( sat_cons (p2248 F) ( sat_cons (p1627 F) ( sat_cons (p15 F) ( sat_cons (p82 F) ( sat_cons (p1912 F) (rfl)))))))
  · decide +kernel
def c2250 : CNF.Clause Nat := [(40,true), (26,true), (39,true), (51,false), (62,true), (87,false), (88,false), (98,false), (99,false)]
theorem p2250 (F : Frame G 4) : c2250.eval F.assign = true := by
  apply local_rup F.assign c2250 [c134, c8, c1645, c1626, c16]
  · exact sat_cons (p134 F) ( sat_cons (p8 F) ( sat_cons (p1645 F) ( sat_cons (p1626 F) ( sat_cons (p16 F) (rfl)))))
  · decide +kernel
def c2251 : CNF.Clause Nat := [(51,false), (62,true), (87,false), (88,false), (98,false), (99,false), (110,false)]
theorem p2251 (F : Frame G 4) : c2251.eval F.assign = true := by
  apply local_rup F.assign c2251 [c2067, c139, c1749, c2250, c1770, c16, c2120, c1627, c85, c10, c1688]
  · exact sat_cons (p2067 F) ( sat_cons (p139 F) ( sat_cons (p1749 F) ( sat_cons (p2250 F) ( sat_cons (p1770 F) ( sat_cons (p16 F) ( sat_cons (p2120 F) ( sat_cons (p1627 F) ( sat_cons (p85 F) ( sat_cons (p10 F) ( sat_cons (p1688 F) (rfl)))))))))))
  · decide +kernel
def c2252 : CNF.Clause Nat := [(39,true), (51,true), (62,true), (87,false), (88,false), (98,false), (99,false)]
theorem p2252 (F : Frame G 4) : c2252.eval F.assign = true := by
  apply local_rup F.assign c2252 [c138, c137, c139, c1627, c1770, c16]
  · exact sat_cons (p138 F) ( sat_cons (p137 F) ( sat_cons (p139 F) ( sat_cons (p1627 F) ( sat_cons (p1770 F) ( sat_cons (p16 F) (rfl))))))
  · decide +kernel
def c2253 : CNF.Clause Nat := [(50,false), (38,false), (51,true), (62,true), (87,false), (88,false), (98,false), (99,false)]
theorem p2253 (F : Frame G 4) : c2253.eval F.assign = true := by
  apply local_rup F.assign c2253 [c2252, c138, c1923, c1963, c24]
  · exact sat_cons (p2252 F) ( sat_cons (p138 F) ( sat_cons (p1923 F) ( sat_cons (p1963 F) ( sat_cons (p24 F) (rfl)))))
  · decide +kernel
def c2254 : CNF.Clause Nat := [(5,false), (51,true), (62,true), (87,false), (88,false), (98,false), (99,false)]
theorem p2254 (F : Frame G 4) : c2254.eval F.assign = true := by
  apply local_rup F.assign c2254 [c2252, c138, c1745, c1676, c24]
  · exact sat_cons (p2252 F) ( sat_cons (p138 F) ( sat_cons (p1745 F) ( sat_cons (p1676 F) ( sat_cons (p24 F) (rfl)))))
  · decide +kernel
def c2255 : CNF.Clause Nat := [(62,true), (87,false), (110,false), (88,false), (98,false), (99,false)]
theorem p2255 (F : Frame G 4) : c2255.eval F.assign = true := by
  apply local_rup F.assign c2255 [c2251, c138, c2252, c1993, c2254, c12, c13, c2253]
  · exact sat_cons (p2251 F) ( sat_cons (p138 F) ( sat_cons (p2252 F) ( sat_cons (p1993 F) ( sat_cons (p2254 F) ( sat_cons (p12 F) ( sat_cons (p13 F) ( sat_cons (p2253 F) (rfl))))))))
  · decide +kernel
def c2256 : CNF.Clause Nat := [(40,false), (51,true), (87,false), (88,false), (98,false), (99,false), (110,false)]
theorem p2256 (F : Frame G 4) : c2256.eval F.assign = true := by
  apply local_rup F.assign c2256 [c2255, c2088, c140, c2059, c1770, c13, c1721, c1993, c79]
  · exact sat_cons (p2255 F) ( sat_cons (p2088 F) ( sat_cons (p140 F) ( sat_cons (p2059 F) ( sat_cons (p1770 F) ( sat_cons (p13 F) ( sat_cons (p1721 F) ( sat_cons (p1993 F) ( sat_cons (p79 F) (rfl)))))))))
  · decide +kernel
def c2257 : CNF.Clause Nat := [(51,true), (87,false), (88,false), (98,false), (99,false), (110,false)]
theorem p2257 (F : Frame G 4) : c2257.eval F.assign = true := by
  apply local_rup F.assign c2257 [c2255, c2088, c140, c2256, c2247, c1956, c1395, c13]
  · exact sat_cons (p2255 F) ( sat_cons (p2088 F) ( sat_cons (p140 F) ( sat_cons (p2256 F) ( sat_cons (p2247 F) ( sat_cons (p1956 F) ( sat_cons (p1395 F) ( sat_cons (p13 F) (rfl))))))))
  · decide +kernel
def c2258 : CNF.Clause Nat := [(87,false), (88,false), (110,false), (99,false), (98,false)]
theorem p2258 (F : Frame G 4) : c2258.eval F.assign = true := by
  apply local_rup F.assign c2258 [c2255, c2088, c2257, c1949, c2067, c7, c10, c2059, c1395, c14, c1752, c2106, c2234, c55]
  · exact sat_cons (p2255 F) ( sat_cons (p2088 F) ( sat_cons (p2257 F) ( sat_cons (p1949 F) ( sat_cons (p2067 F) ( sat_cons (p7 F) ( sat_cons (p10 F) ( sat_cons (p2059 F) ( sat_cons (p1395 F) ( sat_cons (p14 F) ( sat_cons (p1752 F) ( sat_cons (p2106 F) ( sat_cons (p2234 F) ( sat_cons (p55 F) (rfl))))))))))))))
  · decide +kernel
def c2259 : CNF.Clause Nat := [(51,false), (62,false), (88,false), (98,false), (99,false), (110,false)]
theorem p2259 (F : Frame G 4) : c2259.eval F.assign = true := by
  apply local_rup F.assign c2259 [c2088, c2258, c1795, c1949, c2067, c2246, c10, c144, c1968]
  · exact sat_cons (p2088 F) ( sat_cons (p2258 F) ( sat_cons (p1795 F) ( sat_cons (p1949 F) ( sat_cons (p2067 F) ( sat_cons (p2246 F) ( sat_cons (p10 F) ( sat_cons (p144 F) ( sat_cons (p1968 F) (rfl)))))))))
  · decide +kernel
def c2260 : CNF.Clause Nat := [(40,false), (5,false), (86,true), (50,false), (62,false), (87,true), (88,false), (98,false), (99,false)]
theorem p2260 (F : Frame G 4) : c2260.eval F.assign = true := by
  apply local_rup F.assign c2260 [c1802, c1692, c144]
  · exact sat_cons (p1802 F) ( sat_cons (p1692 F) ( sat_cons (p144 F) (rfl)))
  · decide +kernel
def c2261 : CNF.Clause Nat := [(19,false), (40,true), (86,true), (15,false), (51,true), (38,true), (62,false), (98,false), (99,false)]
theorem p2261 (F : Frame G 4) : c2261.eval F.assign = true := by
  apply local_rup F.assign c2261 [c140, c1810, c1306, c20]
  · exact sat_cons (p140 F) ( sat_cons (p1810 F) ( sat_cons (p1306 F) ( sat_cons (p20 F) (rfl))))
  · decide +kernel
def c2262 : CNF.Clause Nat := [(15,false), (62,false), (88,false), (98,false), (99,false), (110,false)]
theorem p2262 (F : Frame G 4) : c2262.eval F.assign = true := by
  apply local_rup F.assign c2262 [c2088, c2259, c140, c2258, c1395, c2097, c13, c2260, c134, c2261, c144, c1967, c23, c26, c1944]
  · exact sat_cons (p2088 F) ( sat_cons (p2259 F) ( sat_cons (p140 F) ( sat_cons (p2258 F) ( sat_cons (p1395 F) ( sat_cons (p2097 F) ( sat_cons (p13 F) ( sat_cons (p2260 F) ( sat_cons (p134 F) ( sat_cons (p2261 F) ( sat_cons (p144 F) ( sat_cons (p1967 F) ( sat_cons (p23 F) ( sat_cons (p26 F) ( sat_cons (p1944 F) (rfl)))))))))))))))
  · decide +kernel
def c2263 : CNF.Clause Nat := [(30,false), (62,false), (88,false), (98,false), (99,false), (110,false)]
theorem p2263 (F : Frame G 4) : c2263.eval F.assign = true := by
  apply local_rup F.assign c2263 [c2262, c2088, c2259, c140, c1570, c1569, c134, c9, c26, c1992, c2024, c13]
  · exact sat_cons (p2262 F) ( sat_cons (p2088 F) ( sat_cons (p2259 F) ( sat_cons (p140 F) ( sat_cons (p1570 F) ( sat_cons (p1569 F) ( sat_cons (p134 F) ( sat_cons (p9 F) ( sat_cons (p26 F) ( sat_cons (p1992 F) ( sat_cons (p2024 F) ( sat_cons (p13 F) (rfl))))))))))))
  · decide +kernel
def c2264 : CNF.Clause Nat := [(40,true), (19,false), (62,false), (88,false), (98,false), (99,false), (110,false)]
theorem p2264 (F : Frame G 4) : c2264.eval F.assign = true := by
  apply local_rup F.assign c2264 [c2262, c2088, c2259, c140, c134, c9, c1992, c1406, c13]
  · exact sat_cons (p2262 F) ( sat_cons (p2088 F) ( sat_cons (p2259 F) ( sat_cons (p140 F) ( sat_cons (p134 F) ( sat_cons (p9 F) ( sat_cons (p1992 F) ( sat_cons (p1406 F) ( sat_cons (p13 F) (rfl)))))))))
  · decide +kernel
def c2265 : CNF.Clause Nat := [(19,false), (62,false), (88,false), (98,false), (99,false), (110,false)]
theorem p2265 (F : Frame G 4) : c2265.eval F.assign = true := by
  apply local_rup F.assign c2265 [c2262, c2088, c2259, c140, c1810, c2264, c1987, c1902, c73]
  · exact sat_cons (p2262 F) ( sat_cons (p2088 F) ( sat_cons (p2259 F) ( sat_cons (p140 F) ( sat_cons (p1810 F) ( sat_cons (p2264 F) ( sat_cons (p1987 F) ( sat_cons (p1902 F) ( sat_cons (p73 F) (rfl)))))))))
  · decide +kernel
def c2266 : CNF.Clause Nat := [(40,false), (86,false), (15,true), (51,true), (38,true), (88,false), (98,false), (110,false)]
theorem p2266 (F : Frame G 4) : c2266.eval F.assign = true := by
  apply local_rup F.assign c2266 [c140, c1987, c2248, c10, c1993]
  · exact sat_cons (p140 F) ( sat_cons (p1987 F) ( sat_cons (p2248 F) ( sat_cons (p10 F) ( sat_cons (p1993 F) (rfl)))))
  · decide +kernel
def c2267 : CNF.Clause Nat := [(7,false), (26,false), (39,false), (40,true), (86,false), (50,false), (51,true), (98,false), (99,false), (110,false)]
theorem p2267 (F : Frame G 4) : c2267.eval F.assign = true := by
  apply local_rup F.assign c2267 [c2086, c2154, c20]
  · exact sat_cons (p2086 F) ( sat_cons (p2154 F) ( sat_cons (p20 F) (rfl)))
  · decide +kernel
def c2268 : CNF.Clause Nat := [(26,false), (39,false), (110,false), (40,true), (86,false), (50,false), (51,true), (98,false), (99,false)]
theorem p2268 (F : Frame G 4) : c2268.eval F.assign = true := by
  apply local_rup F.assign c2268 [c2267, c23, c26, c1908]
  · exact sat_cons (p2267 F) ( sat_cons (p23 F) ( sat_cons (p26 F) ( sat_cons (p1908 F) (rfl))))
  · decide +kernel
def c2269 : CNF.Clause Nat := [(62,false), (88,false), (98,false), (99,false), (110,false)]
theorem p2269 (F : Frame G 4) : c2269.eval F.assign = true := by
  apply local_rup F.assign c2269 [c2258, c2088, c2259, c140, c2262, c2263, c2265, c144, c2266, c134, c9, c2268]
  · exact sat_cons (p2258 F) ( sat_cons (p2088 F) ( sat_cons (p2259 F) ( sat_cons (p140 F) ( sat_cons (p2262 F) ( sat_cons (p2263 F) ( sat_cons (p2265 F) ( sat_cons (p144 F) ( sat_cons (p2266 F) ( sat_cons (p134 F) ( sat_cons (p9 F) ( sat_cons (p2268 F) (rfl))))))))))))
  · decide +kernel
def c2270 : CNF.Clause Nat := [(86,false), (50,false), (51,true), (88,false), (98,false), (99,false), (110,false)]
theorem p2270 (F : Frame G 4) : c2270.eval F.assign = true := by
  apply local_rup F.assign c2270 [c2269, c138, c1987, c2249, c1918, c1865, c1993, c62]
  · exact sat_cons (p2269 F) ( sat_cons (p138 F) ( sat_cons (p1987 F) ( sat_cons (p2249 F) ( sat_cons (p1918 F) ( sat_cons (p1865 F) ( sat_cons (p1993 F) ( sat_cons (p62 F) (rfl))))))))
  · decide +kernel
def c2271 : CNF.Clause Nat := [(39,true), (86,true), (26,true), (50,false), (51,true), (62,true), (87,true), (88,false), (98,false), (99,false)]
theorem p2271 (F : Frame G 4) : c2271.eval F.assign = true := by
  apply local_rup F.assign c2271 [c138, c137, c1627, c16, c1687, c144, c1751, c21, c24, c64, c1671]
  · exact sat_cons (p138 F) ( sat_cons (p137 F) ( sat_cons (p1627 F) ( sat_cons (p16 F) ( sat_cons (p1687 F) ( sat_cons (p144 F) ( sat_cons (p1751 F) ( sat_cons (p21 F) ( sat_cons (p24 F) ( sat_cons (p64 F) ( sat_cons (p1671 F) (rfl)))))))))))
  · decide +kernel
def c2272 : CNF.Clause Nat := [(50,false), (51,true), (88,false), (98,false), (99,false), (110,false)]
theorem p2272 (F : Frame G 4) : c2272.eval F.assign = true := by
  apply local_rup F.assign c2272 [c2269, c138, c2258, c1987, c2270, c2271, c1923, c21, c24, c1673, c2033, c1547, c1988, c212]
  · exact sat_cons (p2269 F) ( sat_cons (p138 F) ( sat_cons (p2258 F) ( sat_cons (p1987 F) ( sat_cons (p2270 F) ( sat_cons (p2271 F) ( sat_cons (p1923 F) ( sat_cons (p21 F) ( sat_cons (p24 F) ( sat_cons (p1673 F) ( sat_cons (p2033 F) ( sat_cons (p1547 F) ( sat_cons (p1988 F) ( sat_cons (p212 F) (rfl))))))))))))))
  · decide +kernel
def c2273 : CNF.Clause Nat := [(51,true), (88,false), (98,false), (99,false), (110,false)]
theorem p2273 (F : Frame G 4) : c2273.eval F.assign = true := by
  apply local_rup F.assign c2273 [c2269, c2258, c138, c2272, c139, c140, c1993, c1627, c2249, c12, c15, c1745, c2012, c24, c144, c1553]
  · exact sat_cons (p2269 F) ( sat_cons (p2258 F) ( sat_cons (p138 F) ( sat_cons (p2272 F) ( sat_cons (p139 F) ( sat_cons (p140 F) ( sat_cons (p1993 F) ( sat_cons (p1627 F) ( sat_cons (p2249 F) ( sat_cons (p12 F) ( sat_cons (p15 F) ( sat_cons (p1745 F) ( sat_cons (p2012 F) ( sat_cons (p24 F) ( sat_cons (p144 F) ( sat_cons (p1553 F) (rfl))))))))))))))))
  · decide +kernel
def c2274 : CNF.Clause Nat := [(40,false), (88,false), (98,false), (99,false), (110,false)]
theorem p2274 (F : Frame G 4) : c2274.eval F.assign = true := by
  apply local_rup F.assign c2274 [c2273, c2269, c2067, c139, c1749, c2258, c1366, c1527, c144, c2076, c1528, c16, c2107, c10, c53, c49, c1604, c1750, c1699, c1673, c212]
  · exact sat_cons (p2273 F) ( sat_cons (p2269 F) ( sat_cons (p2067 F) ( sat_cons (p139 F) ( sat_cons (p1749 F) ( sat_cons (p2258 F) ( sat_cons (p1366 F) ( sat_cons (p1527 F) ( sat_cons (p144 F) ( sat_cons (p2076 F) ( sat_cons (p1528 F) ( sat_cons (p16 F) ( sat_cons (p2107 F) ( sat_cons (p10 F) ( sat_cons (p53 F) ( sat_cons (p49 F) ( sat_cons (p1604 F) ( sat_cons (p1750 F) ( sat_cons (p1699 F) ( sat_cons (p1673 F) ( sat_cons (p212 F) (rfl)))))))))))))))))))))
  · decide +kernel
def c2275 : CNF.Clause Nat := [(18,true), (86,true), (88,false), (98,false), (99,false), (110,false)]
theorem p2275 (F : Frame G 4) : c2275.eval F.assign = true := by
  apply local_rup F.assign c2275 [c2269, c2273, c2067, c2274, c134, c139, c1749, c8, c1626, c16, c2258, c25, c19, c1975, c1281, c1282, c1673, c212]
  · exact sat_cons (p2269 F) ( sat_cons (p2273 F) ( sat_cons (p2067 F) ( sat_cons (p2274 F) ( sat_cons (p134 F) ( sat_cons (p139 F) ( sat_cons (p1749 F) ( sat_cons (p8 F) ( sat_cons (p1626 F) ( sat_cons (p16 F) ( sat_cons (p2258 F) ( sat_cons (p25 F) ( sat_cons (p19 F) ( sat_cons (p1975 F) ( sat_cons (p1281 F) ( sat_cons (p1282 F) ( sat_cons (p1673 F) ( sat_cons (p212 F) (rfl))))))))))))))))))
  · decide +kernel
def c2276 : CNF.Clause Nat := [(86,true), (88,false), (98,false), (99,false), (110,false)]
theorem p2276 (F : Frame G 4) : c2276.eval F.assign = true := by
  apply local_rup F.assign c2276 [c2273, c2067, c2274, c134, c2269, c139, c1749, c8, c1626, c16, c2107, c2258, c144, c2275, c1671, c1976, c22]
  · exact sat_cons (p2273 F) ( sat_cons (p2067 F) ( sat_cons (p2274 F) ( sat_cons (p134 F) ( sat_cons (p2269 F) ( sat_cons (p139 F) ( sat_cons (p1749 F) ( sat_cons (p8 F) ( sat_cons (p1626 F) ( sat_cons (p16 F) ( sat_cons (p2107 F) ( sat_cons (p2258 F) ( sat_cons (p144 F) ( sat_cons (p2275 F) ( sat_cons (p1671 F) ( sat_cons (p1976 F) ( sat_cons (p22 F) (rfl)))))))))))))))))
  · decide +kernel
def c2277 : CNF.Clause Nat := [(18,false), (88,false), (98,false), (99,false), (110,false)]
theorem p2277 (F : Frame G 4) : c2277.eval F.assign = true := by
  apply local_rup F.assign c2277 [c2276, c2273, c2269, c2067, c139, c1749, c2274, c8, c134, c2039, c1671, c22]
  · exact sat_cons (p2276 F) ( sat_cons (p2273 F) ( sat_cons (p2269 F) ( sat_cons (p2067 F) ( sat_cons (p139 F) ( sat_cons (p1749 F) ( sat_cons (p2274 F) ( sat_cons (p8 F) ( sat_cons (p134 F) ( sat_cons (p2039 F) ( sat_cons (p1671 F) ( sat_cons (p22 F) (rfl))))))))))))
  · decide +kernel
def c2278 : CNF.Clause Nat := [(88,false), (98,false), (110,false), (99,false)]
theorem p2278 (F : Frame G 4) : c2278.eval F.assign = true := by
  apply local_rup F.assign c2278 [c2269, c2273, c2067, c139, c1749, c2274, c134, c8, c2276, c2277, c25, c19, c1974]
  · exact sat_cons (p2269 F) ( sat_cons (p2273 F) ( sat_cons (p2067 F) ( sat_cons (p139 F) ( sat_cons (p1749 F) ( sat_cons (p2274 F) ( sat_cons (p134 F) ( sat_cons (p8 F) ( sat_cons (p2276 F) ( sat_cons (p2277 F) ( sat_cons (p25 F) ( sat_cons (p19 F) ( sat_cons (p1974 F) (rfl)))))))))))))
  · decide +kernel
def c2279 : CNF.Clause Nat := [(39,false), (7,false), (51,false), (86,false), (98,false), (99,false), (110,false)]
theorem p2279 (F : Frame G 4) : c2279.eval F.assign = true := by
  apply local_rup F.assign c2279 [c2278, c1792, c1423, c2043, c142]
  · exact sat_cons (p2278 F) ( sat_cons (p1792 F) ( sat_cons (p1423 F) ( sat_cons (p2043 F) ( sat_cons (p142 F) (rfl)))))
  · decide +kernel
def c2280 : CNF.Clause Nat := [(19,false), (26,false), (39,true), (29,false), (51,false), (62,true), (86,false), (50,false), (98,false), (99,false), (110,false)]
theorem p2280 (F : Frame G 4) : c2280.eval F.assign = true := by
  apply local_rup F.assign c2280 [c2096, c1850, c16]
  · exact sat_cons (p2096 F) ( sat_cons (p1850 F) ( sat_cons (p16 F) (rfl)))
  · decide +kernel
def c2281 : CNF.Clause Nat := [(87,true), (19,true), (26,false), (39,true), (29,false), (62,true), (40,true), (88,true)]
theorem p2281 (F : Frame G 4) : c2281.eval F.assign = true := by
  apply local_rup F.assign c2281 [c1338, c142]
  · exact sat_cons (p1338 F) ( sat_cons (p142 F) (rfl))
  · decide +kernel
def c2282 : CNF.Clause Nat := [(18,true), (62,true), (86,false), (50,false), (40,true), (98,false), (99,false), (110,false)]
theorem p2282 (F : Frame G 4) : c2282.eval F.assign = true := by
  apply local_rup F.assign c2282 [c138, c1791, c2278, c25, c19, c2279, c134, c1974, c8, c2280, c2281, c1950, c1924, c163, c16, c2001]
  · exact sat_cons (p138 F) ( sat_cons (p1791 F) ( sat_cons (p2278 F) ( sat_cons (p25 F) ( sat_cons (p19 F) ( sat_cons (p2279 F) ( sat_cons (p134 F) ( sat_cons (p1974 F) ( sat_cons (p8 F) ( sat_cons (p2280 F) ( sat_cons (p2281 F) ( sat_cons (p1950 F) ( sat_cons (p1924 F) ( sat_cons (p163 F) ( sat_cons (p16 F) ( sat_cons (p2001 F) (rfl))))))))))))))))
  · decide +kernel
def c2283 : CNF.Clause Nat := [(7,false), (62,true), (86,false), (50,false), (40,true), (98,false), (99,false), (110,false)]
theorem p2283 (F : Frame G 4) : c2283.eval F.assign = true := by
  apply local_rup F.assign c2283 [c138, c2282, c2076, c1791, c2278, c2279, c134, c2003, c1973, c142, c8, c2096, c1694, c1779, c16, c257, c2036]
  · exact sat_cons (p138 F) ( sat_cons (p2282 F) ( sat_cons (p2076 F) ( sat_cons (p1791 F) ( sat_cons (p2278 F) ( sat_cons (p2279 F) ( sat_cons (p134 F) ( sat_cons (p2003 F) ( sat_cons (p1973 F) ( sat_cons (p142 F) ( sat_cons (p8 F) ( sat_cons (p2096 F) ( sat_cons (p1694 F) ( sat_cons (p1779 F) ( sat_cons (p16 F) ( sat_cons (p257 F) ( sat_cons (p2036 F) (rfl)))))))))))))))))
  · decide +kernel
def c2284 : CNF.Clause Nat := [(62,true), (86,false), (50,false), (40,true), (98,false), (99,false), (110,false)]
theorem p2284 (F : Frame G 4) : c2284.eval F.assign = true := by
  apply local_rup F.assign c2284 [c2278, c138, c2282, c2076, c2283, c22, c1908, c134, c1417, c142, c2133, c1850, c16]
  · exact sat_cons (p2278 F) ( sat_cons (p138 F) ( sat_cons (p2282 F) ( sat_cons (p2076 F) ( sat_cons (p2283 F) ( sat_cons (p22 F) ( sat_cons (p1908 F) ( sat_cons (p134 F) ( sat_cons (p1417 F) ( sat_cons (p142 F) ( sat_cons (p2133 F) ( sat_cons (p1850 F) ( sat_cons (p16 F) (rfl)))))))))))))
  · decide +kernel
def c2285 : CNF.Clause Nat := [(39,true), (7,true), (18,false), (86,false), (50,false), (40,true), (98,false), (99,false), (110,false)]
theorem p2285 (F : Frame G 4) : c2285.eval F.assign = true := by
  apply local_rup F.assign c2285 [c2284, c1943, c2097, c2278, c134, c8, c2129, c1410, c32, c23, c1804, c1810, c142]
  · exact sat_cons (p2284 F) ( sat_cons (p1943 F) ( sat_cons (p2097 F) ( sat_cons (p2278 F) ( sat_cons (p134 F) ( sat_cons (p8 F) ( sat_cons (p2129 F) ( sat_cons (p1410 F) ( sat_cons (p32 F) ( sat_cons (p23 F) ( sat_cons (p1804 F) ( sat_cons (p1810 F) ( sat_cons (p142 F) (rfl)))))))))))))
  · decide +kernel
def c2286 : CNF.Clause Nat := [(7,true), (18,false), (86,false), (50,false), (40,true), (98,false), (99,false), (110,false)]
theorem p2286 (F : Frame G 4) : c2286.eval F.assign = true := by
  apply local_rup F.assign c2286 [c2284, c2278, c2285, c1908, c23, c1795, c2076, c1792, c142]
  · exact sat_cons (p2284 F) ( sat_cons (p2278 F) ( sat_cons (p2285 F) ( sat_cons (p1908 F) ( sat_cons (p23 F) ( sat_cons (p1795 F) ( sat_cons (p2076 F) ( sat_cons (p1792 F) ( sat_cons (p142 F) (rfl)))))))))
  · decide +kernel
def c2287 : CNF.Clause Nat := [(39,false), (7,false), (18,false), (15,true), (86,false), (50,false), (40,true), (99,false), (110,false)]
theorem p2287 (F : Frame G 4) : c2287.eval F.assign = true := by
  apply local_rup F.assign c2287 [c1933, c2154, c9]
  · exact sat_cons (p1933 F) ( sat_cons (p2154 F) ( sat_cons (p9 F) (rfl)))
  · decide +kernel
def c2288 : CNF.Clause Nat := [(18,false), (86,false), (50,false), (40,true), (98,false), (99,false), (110,false)]
theorem p2288 (F : Frame G 4) : c2288.eval F.assign = true := by
  apply local_rup F.assign c2288 [c2284, c2097, c2286, c2287, c134, c8, c1407]
  · exact sat_cons (p2284 F) ( sat_cons (p2097 F) ( sat_cons (p2286 F) ( sat_cons (p2287 F) ( sat_cons (p134 F) ( sat_cons (p8 F) ( sat_cons (p1407 F) (rfl)))))))
  · decide +kernel
def c2289 : CNF.Clause Nat := [(39,true), (7,false), (15,true), (62,false), (86,false), (40,true), (98,false), (110,false)]
theorem p2289 (F : Frame G 4) : c2289.eval F.assign = true := by
  apply local_rup F.assign c2289 [c134, c8, c1407]
  · exact sat_cons (p134 F) ( sat_cons (p8 F) ( sat_cons (p1407 F) (rfl)))
  · decide +kernel
def c2290 : CNF.Clause Nat := [(7,false), (86,false), (50,false), (40,true), (98,false), (99,false), (110,false)]
theorem p2290 (F : Frame G 4) : c2290.eval F.assign = true := by
  apply local_rup F.assign c2290 [c2288, c2284, c2097, c2289, c2279, c2268, c20, c9, c1411]
  · exact sat_cons (p2288 F) ( sat_cons (p2284 F) ( sat_cons (p2097 F) ( sat_cons (p2289 F) ( sat_cons (p2279 F) ( sat_cons (p2268 F) ( sat_cons (p20 F) ( sat_cons (p9 F) ( sat_cons (p1411 F) (rfl)))))))))
  · decide +kernel
def c2291 : CNF.Clause Nat := [(86,false), (50,false), (40,true), (98,false), (99,false), (110,false)]
theorem p2291 (F : Frame G 4) : c2291.eval F.assign = true := by
  apply local_rup F.assign c2291 [c2278, c2284, c2097, c2288, c2290, c26, c1795, c1410, c8, c1792, c2212, c142]
  · exact sat_cons (p2278 F) ( sat_cons (p2284 F) ( sat_cons (p2097 F) ( sat_cons (p2288 F) ( sat_cons (p2290 F) ( sat_cons (p26 F) ( sat_cons (p1795 F) ( sat_cons (p1410 F) ( sat_cons (p8 F) ( sat_cons (p1792 F) ( sat_cons (p2212 F) ( sat_cons (p142 F) (rfl))))))))))))
  · decide +kernel
def c2292 : CNF.Clause Nat := [(39,false), (7,true), (62,false), (50,false), (40,true), (98,false), (99,false), (110,false)]
theorem p2292 (F : Frame G 4) : c2292.eval F.assign = true := by
  apply local_rup F.assign c2292 [c2278, c2291, c261, c1792, c23, c26, c1810, c143, c2129, c1944, c2025, c13]
  · exact sat_cons (p2278 F) ( sat_cons (p2291 F) ( sat_cons (p261 F) ( sat_cons (p1792 F) ( sat_cons (p23 F) ( sat_cons (p26 F) ( sat_cons (p1810 F) ( sat_cons (p143 F) ( sat_cons (p2129 F) ( sat_cons (p1944 F) ( sat_cons (p2025 F) ( sat_cons (p13 F) (rfl))))))))))))
  · decide +kernel
def c2293 : CNF.Clause Nat := [(7,true), (62,false), (50,false), (40,true), (98,false), (99,false), (110,false)]
theorem p2293 (F : Frame G 4) : c2293.eval F.assign = true := by
  apply local_rup F.assign c2293 [c2278, c2291, c261, c2292, c134, c2129, c143, c1419, c1795, c23]
  · exact sat_cons (p2278 F) ( sat_cons (p2291 F) ( sat_cons (p261 F) ( sat_cons (p2292 F) ( sat_cons (p134 F) ( sat_cons (p2129 F) ( sat_cons (p143 F) ( sat_cons (p1419 F) ( sat_cons (p1795 F) ( sat_cons (p23 F) (rfl))))))))))
  · decide +kernel
def c2294 : CNF.Clause Nat := [(39,true), (62,false), (50,false), (40,true), (98,false), (99,false), (110,false)]
theorem p2294 (F : Frame G 4) : c2294.eval F.assign = true := by
  apply local_rup F.assign c2294 [c2293, c2278, c2291, c261, c134, c2129, c2093, c143, c1419, c1795, c2224, c20, c30, c1670]
  · exact sat_cons (p2293 F) ( sat_cons (p2278 F) ( sat_cons (p2291 F) ( sat_cons (p261 F) ( sat_cons (p134 F) ( sat_cons (p2129 F) ( sat_cons (p2093 F) ( sat_cons (p143 F) ( sat_cons (p1419 F) ( sat_cons (p1795 F) ( sat_cons (p2224 F) ( sat_cons (p20 F) ( sat_cons (p30 F) ( sat_cons (p1670 F) (rfl))))))))))))))
  · decide +kernel
def c2295 : CNF.Clause Nat := [(19,false), (62,false), (50,false), (40,true), (98,false), (99,false), (110,false)]
theorem p2295 (F : Frame G 4) : c2295.eval F.assign = true := by
  apply local_rup F.assign c2295 [c2278, c2291, c261, c2294, c1792, c2293, c1810, c20, c1766, c1984, c1306, c13, c9, c1804]
  · exact sat_cons (p2278 F) ( sat_cons (p2291 F) ( sat_cons (p261 F) ( sat_cons (p2294 F) ( sat_cons (p1792 F) ( sat_cons (p2293 F) ( sat_cons (p1810 F) ( sat_cons (p20 F) ( sat_cons (p1766 F) ( sat_cons (p1984 F) ( sat_cons (p1306 F) ( sat_cons (p13 F) ( sat_cons (p9 F) ( sat_cons (p1804 F) (rfl))))))))))))))
  · decide +kernel
def c2296 : CNF.Clause Nat := [(62,false), (50,false), (40,true), (98,false), (99,false), (110,false)]
theorem p2296 (F : Frame G 4) : c2296.eval F.assign = true := by
  apply local_rup F.assign c2296 [c2278, c2291, c261, c2293, c2294, c1792, c2295, c143, c2129, c1840, c1805, c20, c9, c1766, c1804, c13]
  · exact sat_cons (p2278 F) ( sat_cons (p2291 F) ( sat_cons (p261 F) ( sat_cons (p2293 F) ( sat_cons (p2294 F) ( sat_cons (p1792 F) ( sat_cons (p2295 F) ( sat_cons (p143 F) ( sat_cons (p2129 F) ( sat_cons (p1840 F) ( sat_cons (p1805 F) ( sat_cons (p20 F) ( sat_cons (p9 F) ( sat_cons (p1766 F) ( sat_cons (p1804 F) ( sat_cons (p13 F) (rfl))))))))))))))))
  · decide +kernel
def c2297 : CNF.Clause Nat := [(11,false), (29,false), (30,false), (7,false), (39,true), (62,true), (87,false), (40,true), (88,true), (99,false)]
theorem p2297 (F : Frame G 4) : c2297.eval F.assign = true := by
  apply local_rup F.assign c2297 [c134, c138, c1283, c1638, c16]
  · exact sat_cons (p134 F) ( sat_cons (p138 F) ( sat_cons (p1283 F) ( sat_cons (p1638 F) ( sat_cons (p16 F) (rfl)))))
  · decide +kernel
def c2298 : CNF.Clause Nat := [(17,false), (11,true), (30,false), (7,false), (39,true), (51,false), (87,false), (50,false), (40,true), (88,true), (98,false), (99,false)]
theorem p2298 (F : Frame G 4) : c2298.eval F.assign = true := by
  apply local_rup F.assign c2298 [c1824, c2082, c8, c163, c1806]
  · exact sat_cons (p1824 F) ( sat_cons (p2082 F) ( sat_cons (p8 F) ( sat_cons (p163 F) ( sat_cons (p1806 F) (rfl)))))
  · decide +kernel
def c2299 : CNF.Clause Nat := [(30,false), (7,false), (50,false), (40,true), (98,false), (99,false), (110,false)]
theorem p2299 (F : Frame G 4) : c2299.eval F.assign = true := by
  apply local_rup F.assign c2299 [c2278, c2291, c261, c2296, c138, c1792, c134, c2076, c19, c2297, c2298, c16, c1728, c8, c1806, c1339, c163]
  · exact sat_cons (p2278 F) ( sat_cons (p2291 F) ( sat_cons (p261 F) ( sat_cons (p2296 F) ( sat_cons (p138 F) ( sat_cons (p1792 F) ( sat_cons (p134 F) ( sat_cons (p2076 F) ( sat_cons (p19 F) ( sat_cons (p2297 F) ( sat_cons (p2298 F) ( sat_cons (p16 F) ( sat_cons (p1728 F) ( sat_cons (p8 F) ( sat_cons (p1806 F) ( sat_cons (p1339 F) ( sat_cons (p163 F) (rfl)))))))))))))))))
  · decide +kernel
def c2300 : CNF.Clause Nat := [(29,false), (31,true), (19,false), (7,false), (39,true), (62,true), (86,true), (50,false), (40,true), (88,true), (98,false), (99,false)]
theorem p2300 (F : Frame G 4) : c2300.eval F.assign = true := by
  apply local_rup F.assign c2300 [c138, c261, c1823, c134, c1726, c1850, c234, c16, c1281]
  · exact sat_cons (p138 F) ( sat_cons (p261 F) ( sat_cons (p1823 F) ( sat_cons (p134 F) ( sat_cons (p1726 F) ( sat_cons (p1850 F) ( sat_cons (p234 F) ( sat_cons (p16 F) ( sat_cons (p1281 F) (rfl)))))))))
  · decide +kernel
def c2301 : CNF.Clause Nat := [(7,false), (50,false), (40,true), (98,false), (99,false), (110,false)]
theorem p2301 (F : Frame G 4) : c2301.eval F.assign = true := by
  apply local_rup F.assign c2301 [c2278, c2291, c261, c2296, c138, c1792, c2299, c143, c2084, c1823, c2300, c19, c1752, c8, c2063, c1707, c234]
  · exact sat_cons (p2278 F) ( sat_cons (p2291 F) ( sat_cons (p261 F) ( sat_cons (p2296 F) ( sat_cons (p138 F) ( sat_cons (p1792 F) ( sat_cons (p2299 F) ( sat_cons (p143 F) ( sat_cons (p2084 F) ( sat_cons (p1823 F) ( sat_cons (p2300 F) ( sat_cons (p19 F) ( sat_cons (p1752 F) ( sat_cons (p8 F) ( sat_cons (p2063 F) ( sat_cons (p1707 F) ( sat_cons (p234 F) (rfl)))))))))))))))))
  · decide +kernel
def c2302 : CNF.Clause Nat := [(50,false), (40,true), (98,false), (99,false), (110,false)]
theorem p2302 (F : Frame G 4) : c2302.eval F.assign = true := by
  apply local_rup F.assign c2302 [c2278, c2291, c261, c2296, c138, c1792, c134, c2301, c22, c25, c2076, c1960, c143]
  · exact sat_cons (p2278 F) ( sat_cons (p2291 F) ( sat_cons (p261 F) ( sat_cons (p2296 F) ( sat_cons (p138 F) ( sat_cons (p1792 F) ( sat_cons (p134 F) ( sat_cons (p2301 F) ( sat_cons (p22 F) ( sat_cons (p25 F) ( sat_cons (p2076 F) ( sat_cons (p1960 F) ( sat_cons (p143 F) (rfl)))))))))))))
  · decide +kernel
def c2303 : CNF.Clause Nat := [(62,true), (87,false), (50,true), (40,true), (99,false), (110,false)]
theorem p2303 (F : Frame G 4) : c2303.eval F.assign = true := by
  apply local_rup F.assign c2303 [c138, c139, c1792]
  · exact sat_cons (p138 F) ( sat_cons (p139 F) ( sat_cons (p1792 F) (rfl)))
  · decide +kernel
def c2304 : CNF.Clause Nat := [(39,false), (86,true), (40,true), (98,false), (99,false), (110,false)]
theorem p2304 (F : Frame G 4) : c2304.eval F.assign = true := by
  apply local_rup F.assign c2304 [c2302, c2278, c261, c2303, c1792, c140, c2093, c12, c1670, c26, c20, c1971, c2090, c1831, c1413, c143, c231, c2114]
  · exact sat_cons (p2302 F) ( sat_cons (p2278 F) ( sat_cons (p261 F) ( sat_cons (p2303 F) ( sat_cons (p1792 F) ( sat_cons (p140 F) ( sat_cons (p2093 F) ( sat_cons (p12 F) ( sat_cons (p1670 F) ( sat_cons (p26 F) ( sat_cons (p20 F) ( sat_cons (p1971 F) ( sat_cons (p2090 F) ( sat_cons (p1831 F) ( sat_cons (p1413 F) ( sat_cons (p143 F) ( sat_cons (p231 F) ( sat_cons (p2114 F) (rfl))))))))))))))))))
  · decide +kernel
def c2305 : CNF.Clause Nat := [(86,true), (40,true), (98,false), (99,false), (110,false)]
theorem p2305 (F : Frame G 4) : c2305.eval F.assign = true := by
  apply local_rup F.assign c2305 [c2302, c2278, c261, c2303, c2304, c134, c135, c2093, c1795, c143, c1968, c2113, c1971, c33, c8, c121, c2094]
  · exact sat_cons (p2302 F) ( sat_cons (p2278 F) ( sat_cons (p261 F) ( sat_cons (p2303 F) ( sat_cons (p2304 F) ( sat_cons (p134 F) ( sat_cons (p135 F) ( sat_cons (p2093 F) ( sat_cons (p1795 F) ( sat_cons (p143 F) ( sat_cons (p1968 F) ( sat_cons (p2113 F) ( sat_cons (p1971 F) ( sat_cons (p33 F) ( sat_cons (p8 F) ( sat_cons (p121 F) ( sat_cons (p2094 F) (rfl)))))))))))))))))
  · decide +kernel
def c2306 : CNF.Clause Nat := [(39,true), (62,false), (40,true), (98,false), (99,false), (110,false)]
theorem p2306 (F : Frame G 4) : c2306.eval F.assign = true := by
  apply local_rup F.assign c2306 [c2305, c2302, c2278, c134, c135, c1795, c1410, c8, c1968, c142, c1738, c2093, c31, c1670, c29, c121, c1739]
  · exact sat_cons (p2305 F) ( sat_cons (p2302 F) ( sat_cons (p2278 F) ( sat_cons (p134 F) ( sat_cons (p135 F) ( sat_cons (p1795 F) ( sat_cons (p1410 F) ( sat_cons (p8 F) ( sat_cons (p1968 F) ( sat_cons (p142 F) ( sat_cons (p1738 F) ( sat_cons (p2093 F) ( sat_cons (p31 F) ( sat_cons (p1670 F) ( sat_cons (p29 F) ( sat_cons (p121 F) ( sat_cons (p1739 F) (rfl)))))))))))))))))
  · decide +kernel
def c2307 : CNF.Clause Nat := [(51,false), (39,false), (62,false), (98,false), (99,false), (110,false)]
theorem p2307 (F : Frame G 4) : c2307.eval F.assign = true := by
  apply local_rup F.assign c2307 [c2278, c1795, c1792, c2212, c142]
  · exact sat_cons (p2278 F) ( sat_cons (p1795 F) ( sat_cons (p1792 F) ( sat_cons (p2212 F) ( sat_cons (p142 F) (rfl)))))
  · decide +kernel
def c2308 : CNF.Clause Nat := [(7,true), (51,true), (39,false), (86,false), (40,true), (98,false), (110,false)]
theorem p2308 (F : Frame G 4) : c2308.eval F.assign = true := by
  apply local_rup F.assign c2308 [c23, c26, c1908]
  · exact sat_cons (p23 F) ( sat_cons (p26 F) ( sat_cons (p1908 F) (rfl)))
  · decide +kernel
def c2309 : CNF.Clause Nat := [(62,false), (40,true), (98,false), (99,false), (110,false)]
theorem p2309 (F : Frame G 4) : c2309.eval F.assign = true := by
  apply local_rup F.assign c2309 [c2305, c2302, c2306, c2307, c140, c2308, c1411, c1933, c20]
  · exact sat_cons (p2305 F) ( sat_cons (p2302 F) ( sat_cons (p2306 F) ( sat_cons (p2307 F) ( sat_cons (p140 F) ( sat_cons (p2308 F) ( sat_cons (p1411 F) ( sat_cons (p1933 F) ( sat_cons (p20 F) (rfl)))))))))
  · decide +kernel
def c2310 : CNF.Clause Nat := [(40,true), (98,false), (110,false), (99,false)]
theorem p2310 (F : Frame G 4) : c2310.eval F.assign = true := by
  apply local_rup F.assign c2310 [c2302, c2305, c2309, c138, c139, c2279, c22, c25, c1908]
  · exact sat_cons (p2302 F) ( sat_cons (p2305 F) ( sat_cons (p2309 F) ( sat_cons (p138 F) ( sat_cons (p139 F) ( sat_cons (p2279 F) ( sat_cons (p22 F) ( sat_cons (p25 F) ( sat_cons (p1908 F) (rfl)))))))))
  · decide +kernel
def c2311 : CNF.Clause Nat := [(18,false), (7,true), (86,false), (51,false), (62,true), (98,false), (99,false), (110,false)]
theorem p2311 (F : Frame G 4) : c2311.eval F.assign = true := by
  apply local_rup F.assign c2311 [c2310, c2278, c1918, c139, c1792, c2212, c1908, c142, c1405, c1422, c104]
  · exact sat_cons (p2310 F) ( sat_cons (p2278 F) ( sat_cons (p1918 F) ( sat_cons (p139 F) ( sat_cons (p1792 F) ( sat_cons (p2212 F) ( sat_cons (p1908 F) ( sat_cons (p142 F) ( sat_cons (p1405 F) ( sat_cons (p1422 F) ( sat_cons (p104 F) (rfl)))))))))))
  · decide +kernel
def c2312 : CNF.Clause Nat := [(27,true), (50,true), (19,false), (18,true), (7,true), (51,false), (62,true), (40,false), (98,false), (110,false)]
theorem p2312 (F : Frame G 4) : c2312.eval F.assign = true := by
  apply local_rup F.assign c2312 [c27, c92, c106, c1871]
  · exact sat_cons (p27 F) ( sat_cons (p92 F) ( sat_cons (p106 F) ( sat_cons (p1871 F) (rfl))))
  · decide +kernel
def c2313 : CNF.Clause Nat := [(50,true), (39,false), (7,true), (86,false), (51,false), (62,true), (98,false), (99,false), (110,false)]
theorem p2313 (F : Frame G 4) : c2313.eval F.assign = true := by
  apply local_rup F.assign c2313 [c2278, c1792, c2212, c142, c2310, c1753, c1644, c2311, c27, c2312, c1925, c15, c1867, c97, c1786, c259, c260, c805]
  · exact sat_cons (p2278 F) ( sat_cons (p1792 F) ( sat_cons (p2212 F) ( sat_cons (p142 F) ( sat_cons (p2310 F) ( sat_cons (p1753 F) ( sat_cons (p1644 F) ( sat_cons (p2311 F) ( sat_cons (p27 F) ( sat_cons (p2312 F) ( sat_cons (p1925 F) ( sat_cons (p15 F) ( sat_cons (p1867 F) ( sat_cons (p97 F) ( sat_cons (p1786 F) ( sat_cons (p259 F) ( sat_cons (p260 F) ( sat_cons (p805 F) (rfl))))))))))))))))))
  · decide +kernel
def c2314 : CNF.Clause Nat := [(39,false), (7,true), (86,false), (51,false), (62,true), (98,false), (99,false), (110,false)]
theorem p2314 (F : Frame G 4) : c2314.eval F.assign = true := by
  apply local_rup F.assign c2314 [c2310, c2278, c1644, c1753, c1792, c2212, c142, c2313, c1791, c1847, c260]
  · exact sat_cons (p2310 F) ( sat_cons (p2278 F) ( sat_cons (p1644 F) ( sat_cons (p1753 F) ( sat_cons (p1792 F) ( sat_cons (p2212 F) ( sat_cons (p142 F) ( sat_cons (p2313 F) ( sat_cons (p1791 F) ( sat_cons (p1847 F) ( sat_cons (p260 F) (rfl)))))))))))
  · decide +kernel
def c2315 : CNF.Clause Nat := [(7,true), (86,false), (51,false), (62,true), (98,false), (99,false), (110,false)]
theorem p2315 (F : Frame G 4) : c2315.eval F.assign = true := by
  apply local_rup F.assign c2315 [c2310, c2278, c2311, c27, c2314, c139, c1791, c1865, c60, c65, c1913, c2159, c2280, c16, c1924, c2036, c142, c257, c1722]
  · exact sat_cons (p2310 F) ( sat_cons (p2278 F) ( sat_cons (p2311 F) ( sat_cons (p27 F) ( sat_cons (p2314 F) ( sat_cons (p139 F) ( sat_cons (p1791 F) ( sat_cons (p1865 F) ( sat_cons (p60 F) ( sat_cons (p65 F) ( sat_cons (p1913 F) ( sat_cons (p2159 F) ( sat_cons (p2280 F) ( sat_cons (p16 F) ( sat_cons (p1924 F) ( sat_cons (p2036 F) ( sat_cons (p142 F) ( sat_cons (p257 F) ( sat_cons (p1722 F) (rfl)))))))))))))))))))
  · decide +kernel
def c2316 : CNF.Clause Nat := [(30,false), (15,true), (18,true), (39,true), (7,false), (86,false), (51,false), (62,true), (40,false), (98,false), (110,false)]
theorem p2316 (F : Frame G 4) : c2316.eval F.assign = true := by
  apply local_rup F.assign c2316 [c139, c1388, c16, c1873, c1915, c63]
  · exact sat_cons (p139 F) ( sat_cons (p1388 F) ( sat_cons (p16 F) ( sat_cons (p1873 F) ( sat_cons (p1915 F) ( sat_cons (p63 F) (rfl))))))
  · decide +kernel
def c2317 : CNF.Clause Nat := [(86,false), (51,false), (62,true), (98,false), (99,false), (110,false)]
theorem p2317 (F : Frame G 4) : c2317.eval F.assign = true := by
  apply local_rup F.assign c2317 [c2310, c2278, c2315, c2279, c139, c1918, c1865, c1902, c2316, c142, c1891, c1760, c16]
  · exact sat_cons (p2310 F) ( sat_cons (p2278 F) ( sat_cons (p2315 F) ( sat_cons (p2279 F) ( sat_cons (p139 F) ( sat_cons (p1918 F) ( sat_cons (p1865 F) ( sat_cons (p1902 F) ( sat_cons (p2316 F) ( sat_cons (p142 F) ( sat_cons (p1891 F) ( sat_cons (p1760 F) ( sat_cons (p16 F) (rfl)))))))))))))
  · decide +kernel
def c2318 : CNF.Clause Nat := [(7,false), (51,false), (62,true), (98,false), (99,false), (110,false)]
theorem p2318 (F : Frame G 4) : c2318.eval F.assign = true := by
  apply local_rup F.assign c2318 [c2310, c2278, c2317, c261, c1792, c139, c2203, c1902, c143, c1981, c16, c1702, c1948, c2082, c231]
  · exact sat_cons (p2310 F) ( sat_cons (p2278 F) ( sat_cons (p2317 F) ( sat_cons (p261 F) ( sat_cons (p1792 F) ( sat_cons (p139 F) ( sat_cons (p2203 F) ( sat_cons (p1902 F) ( sat_cons (p143 F) ( sat_cons (p1981 F) ( sat_cons (p16 F) ( sat_cons (p1702 F) ( sat_cons (p1948 F) ( sat_cons (p2082 F) ( sat_cons (p231 F) (rfl)))))))))))))))
  · decide +kernel
def c2319 : CNF.Clause Nat := [(30,false), (51,false), (62,true), (98,false), (99,false), (110,false)]
theorem p2319 (F : Frame G 4) : c2319.eval F.assign = true := by
  apply local_rup F.assign c2319 [c2318, c2310, c2278, c2317, c261, c1792, c139, c2203, c1981, c2076, c16, c27, c1702, c1948, c231, c236, c1830, c1638, c60]
  · exact sat_cons (p2318 F) ( sat_cons (p2310 F) ( sat_cons (p2278 F) ( sat_cons (p2317 F) ( sat_cons (p261 F) ( sat_cons (p1792 F) ( sat_cons (p139 F) ( sat_cons (p2203 F) ( sat_cons (p1981 F) ( sat_cons (p2076 F) ( sat_cons (p16 F) ( sat_cons (p27 F) ( sat_cons (p1702 F) ( sat_cons (p1948 F) ( sat_cons (p231 F) ( sat_cons (p236 F) ( sat_cons (p1830 F) ( sat_cons (p1638 F) ( sat_cons (p60 F) (rfl)))))))))))))))))))
  · decide +kernel
def c2320 : CNF.Clause Nat := [(17,false), (19,false), (7,true), (22,true), (50,false), (86,true), (51,false), (62,true), (40,false), (88,true), (98,false), (99,false)]
theorem p2320 (F : Frame G 4) : c2320.eval F.assign = true := by
  apply local_rup F.assign c2320 [c261, c1702, c2173, c1850, c231, c27, c1684, c1830, c1963, c72]
  · exact sat_cons (p261 F) ( sat_cons (p1702 F) ( sat_cons (p2173 F) ( sat_cons (p1850 F) ( sat_cons (p231 F) ( sat_cons (p27 F) ( sat_cons (p1684 F) ( sat_cons (p1830 F) ( sat_cons (p1963 F) ( sat_cons (p72 F) (rfl))))))))))
  · decide +kernel
def c2321 : CNF.Clause Nat := [(15,true), (26,true), (7,true), (39,true), (87,false), (62,true), (40,false), (99,false)]
theorem p2321 (F : Frame G 4) : c2321.eval F.assign = true := by
  apply local_rup F.assign c2321 [c139, c65, c10, c1963]
  · exact sat_cons (p139 F) ( sat_cons (p65 F) ( sat_cons (p10 F) ( sat_cons (p1963 F) (rfl))))
  · decide +kernel
def c2322 : CNF.Clause Nat := [(51,false), (62,true), (98,false), (99,false), (110,false)]
theorem p2322 (F : Frame G 4) : c2322.eval F.assign = true := by
  apply local_rup F.assign c2322 [c2310, c2278, c2317, c261, c1792, c139, c2203, c2318, c2319, c143, c2320, c16, c1980, c2321, c1752, c27, c53, c1650]
  · exact sat_cons (p2310 F) ( sat_cons (p2278 F) ( sat_cons (p2317 F) ( sat_cons (p261 F) ( sat_cons (p1792 F) ( sat_cons (p139 F) ( sat_cons (p2203 F) ( sat_cons (p2318 F) ( sat_cons (p2319 F) ( sat_cons (p143 F) ( sat_cons (p2320 F) ( sat_cons (p16 F) ( sat_cons (p1980 F) ( sat_cons (p2321 F) ( sat_cons (p1752 F) ( sat_cons (p27 F) ( sat_cons (p53 F) ( sat_cons (p1650 F) (rfl))))))))))))))))))
  · decide +kernel
def c2323 : CNF.Clause Nat := [(6,false), (27,false), (50,false), (29,false), (86,true), (98,false), (99,false), (110,false)]
theorem p2323 (F : Frame G 4) : c2323.eval F.assign = true := by
  apply local_rup F.assign c2323 [c2278, c261, c2310, c1981, c2241, c143]
  · exact sat_cons (p2278 F) ( sat_cons (p261 F) ( sat_cons (p2310 F) ( sat_cons (p1981 F) ( sat_cons (p2241 F) ( sat_cons (p143 F) (rfl))))))
  · decide +kernel
def c2324 : CNF.Clause Nat := [(33,true), (17,false), (39,false), (22,true), (29,false), (86,true), (40,false), (88,true), (98,false), (99,false)]
theorem p2324 (F : Frame G 4) : c2324.eval F.assign = true := by
  apply local_rup F.assign c2324 [c261, c1757, c163, c231, c1544]
  · exact sat_cons (p261 F) ( sat_cons (p1757 F) ( sat_cons (p163 F) ( sat_cons (p231 F) ( sat_cons (p1544 F) (rfl)))))
  · decide +kernel
def c2325 : CNF.Clause Nat := [(50,false), (7,true), (86,true), (62,true), (98,false), (99,false), (110,false)]
theorem p2325 (F : Frame G 4) : c2325.eval F.assign = true := by
  apply local_rup F.assign c2325 [c2322, c21, c24, c2278, c261, c2310, c1963, c1904, c137, c1985, c13, c2323, c78, c2324, c1684, c1830, c71]
  · exact sat_cons (p2322 F) ( sat_cons (p21 F) ( sat_cons (p24 F) ( sat_cons (p2278 F) ( sat_cons (p261 F) ( sat_cons (p2310 F) ( sat_cons (p1963 F) ( sat_cons (p1904 F) ( sat_cons (p137 F) ( sat_cons (p1985 F) ( sat_cons (p13 F) ( sat_cons (p2323 F) ( sat_cons (p78 F) ( sat_cons (p2324 F) ( sat_cons (p1684 F) ( sat_cons (p1830 F) ( sat_cons (p71 F) (rfl)))))))))))))))))
  · decide +kernel
def c2326 : CNF.Clause Nat := [(7,true), (86,true), (62,true), (98,false), (99,false), (110,false)]
theorem p2326 (F : Frame G 4) : c2326.eval F.assign = true := by
  apply local_rup F.assign c2326 [c2278, c261, c2322, c2310, c24, c21, c2325, c139, c140, c1985, c1986, c1831, c12, c15, c1318, c2324, c143, c1350]
  · exact sat_cons (p2278 F) ( sat_cons (p261 F) ( sat_cons (p2322 F) ( sat_cons (p2310 F) ( sat_cons (p24 F) ( sat_cons (p21 F) ( sat_cons (p2325 F) ( sat_cons (p139 F) ( sat_cons (p140 F) ( sat_cons (p1985 F) ( sat_cons (p1986 F) ( sat_cons (p1831 F) ( sat_cons (p12 F) ( sat_cons (p15 F) ( sat_cons (p1318 F) ( sat_cons (p2324 F) ( sat_cons (p143 F) ( sat_cons (p1350 F) (rfl))))))))))))))))))
  · decide +kernel
def c2327 : CNF.Clause Nat := [(50,true), (86,true), (62,true), (98,false), (99,false), (110,false)]
theorem p2327 (F : Frame G 4) : c2327.eval F.assign = true := by
  apply local_rup F.assign c2327 [c2278, c261, c2310, c2326, c2201, c2322, c139, c140, c12, c1898, c143, c1981, c2017, c15]
  · exact sat_cons (p2278 F) ( sat_cons (p261 F) ( sat_cons (p2310 F) ( sat_cons (p2326 F) ( sat_cons (p2201 F) ( sat_cons (p2322 F) ( sat_cons (p139 F) ( sat_cons (p140 F) ( sat_cons (p12 F) ( sat_cons (p1898 F) ( sat_cons (p143 F) ( sat_cons (p1981 F) ( sat_cons (p2017 F) ( sat_cons (p15 F) (rfl))))))))))))))
  · decide +kernel
def c2328 : CNF.Clause Nat := [(86,true), (62,true), (98,false), (99,false), (110,false)]
theorem p2328 (F : Frame G 4) : c2328.eval F.assign = true := by
  apply local_rup F.assign c2328 [c2322, c2310, c2278, c261, c2326, c2201, c2327, c1902, c143, c1981, c1899, c76, c16, c2017]
  · exact sat_cons (p2322 F) ( sat_cons (p2310 F) ( sat_cons (p2278 F) ( sat_cons (p261 F) ( sat_cons (p2326 F) ( sat_cons (p2201 F) ( sat_cons (p2327 F) ( sat_cons (p1902 F) ( sat_cons (p143 F) ( sat_cons (p1981 F) ( sat_cons (p1899 F) ( sat_cons (p76 F) ( sat_cons (p16 F) ( sat_cons (p2017 F) (rfl))))))))))))))
  · decide +kernel
def c2329 : CNF.Clause Nat := [(87,false), (50,false), (7,false), (62,true), (98,false), (99,false), (110,false)]
theorem p2329 (F : Frame G 4) : c2329.eval F.assign = true := by
  apply local_rup F.assign c2329 [c2322, c2310, c2328, c1918, c18, c2278, c1636, c1904, c137, c1769, c1950, c163]
  · exact sat_cons (p2322 F) ( sat_cons (p2310 F) ( sat_cons (p2328 F) ( sat_cons (p1918 F) ( sat_cons (p18 F) ( sat_cons (p2278 F) ( sat_cons (p1636 F) ( sat_cons (p1904 F) ( sat_cons (p137 F) ( sat_cons (p1769 F) ( sat_cons (p1950 F) ( sat_cons (p163 F) (rfl))))))))))))
  · decide +kernel
def c2330 : CNF.Clause Nat := [(50,false), (7,false), (62,true), (98,false), (99,false), (110,false)]
theorem p2330 (F : Frame G 4) : c2330.eval F.assign = true := by
  apply local_rup F.assign c2330 [c2328, c2322, c2310, c2278, c1918, c1902, c18, c2329, c142, c1899, c1873, c137, c16, c2017]
  · exact sat_cons (p2328 F) ( sat_cons (p2322 F) ( sat_cons (p2310 F) ( sat_cons (p2278 F) ( sat_cons (p1918 F) ( sat_cons (p1902 F) ( sat_cons (p18 F) ( sat_cons (p2329 F) ( sat_cons (p142 F) ( sat_cons (p1899 F) ( sat_cons (p1873 F) ( sat_cons (p137 F) ( sat_cons (p16 F) ( sat_cons (p2017 F) (rfl))))))))))))))
  · decide +kernel
def c2331 : CNF.Clause Nat := [(7,false), (62,true), (98,false), (99,false), (110,false)]
theorem p2331 (F : Frame G 4) : c2331.eval F.assign = true := by
  apply local_rup F.assign c2331 [c2328, c2322, c2330, c139, c140, c1411, c1933, c18]
  · exact sat_cons (p2328 F) ( sat_cons (p2322 F) ( sat_cons (p2330 F) ( sat_cons (p139 F) ( sat_cons (p140 F) ( sat_cons (p1411 F) ( sat_cons (p1933 F) ( sat_cons (p18 F) (rfl))))))))
  · decide +kernel
def c2332 : CNF.Clause Nat := [(62,true), (98,false), (99,false), (110,false)]
theorem p2332 (F : Frame G 4) : c2332.eval F.assign = true := by
  apply local_rup F.assign c2332 [c2310, c2322, c2328, c2331, c24, c21, c1918, c1908, c139]
  · exact sat_cons (p2310 F) ( sat_cons (p2322 F) ( sat_cons (p2328 F) ( sat_cons (p2331 F) ( sat_cons (p24 F) ( sat_cons (p21 F) ( sat_cons (p1918 F) ( sat_cons (p1908 F) ( sat_cons (p139 F) (rfl)))))))))
  · decide +kernel
def c2333 : CNF.Clause Nat := [(18,false), (50,true), (86,false), (51,true), (98,false), (99,false), (110,false)]
theorem p2333 (F : Frame G 4) : c2333.eval F.assign = true := by
  apply local_rup F.assign c2333 [c140, c2332, c2310, c2278, c1943, c2113, c12, c1670, c2183, c142]
  · exact sat_cons (p140 F) ( sat_cons (p2332 F) ( sat_cons (p2310 F) ( sat_cons (p2278 F) ( sat_cons (p1943 F) ( sat_cons (p2113 F) ( sat_cons (p12 F) ( sat_cons (p1670 F) ( sat_cons (p2183 F) ( sat_cons (p142 F) (rfl))))))))))
  · decide +kernel
def c2334 : CNF.Clause Nat := [(30,false), (50,true), (7,true), (86,false), (51,true), (98,false), (99,false), (110,false)]
theorem p2334 (F : Frame G 4) : c2334.eval F.assign = true := by
  apply local_rup F.assign c2334 [c2333, c140, c2332, c2310, c1665, c127, c120, c2146, c1389, c12]
  · exact sat_cons (p2333 F) ( sat_cons (p140 F) ( sat_cons (p2332 F) ( sat_cons (p2310 F) ( sat_cons (p1665 F) ( sat_cons (p127 F) ( sat_cons (p120 F) ( sat_cons (p2146 F) ( sat_cons (p1389 F) ( sat_cons (p12 F) (rfl))))))))))
  · decide +kernel
def c2335 : CNF.Clause Nat := [(19,false), (29,false), (50,true), (51,true), (62,false), (40,false), (98,false), (110,false)]
theorem p2335 (F : Frame G 4) : c2335.eval F.assign = true := by
  apply local_rup F.assign c2335 [c140, c2196, c1871, c12]
  · exact sat_cons (p140 F) ( sat_cons (p2196 F) ( sat_cons (p1871 F) ( sat_cons (p12 F) (rfl))))
  · decide +kernel
def c2336 : CNF.Clause Nat := [(50,true), (7,true), (86,false), (51,true), (98,false), (99,false), (110,false)]
theorem p2336 (F : Frame G 4) : c2336.eval F.assign = true := by
  apply local_rup F.assign c2336 [c2332, c2310, c2278, c140, c2333, c28, c2334, c2335, c142, c1415, c1739, c127]
  · exact sat_cons (p2332 F) ( sat_cons (p2310 F) ( sat_cons (p2278 F) ( sat_cons (p140 F) ( sat_cons (p2333 F) ( sat_cons (p28 F) ( sat_cons (p2334 F) ( sat_cons (p2335 F) ( sat_cons (p142 F) ( sat_cons (p1415 F) ( sat_cons (p1739 F) ( sat_cons (p127 F) (rfl))))))))))))
  · decide +kernel
def c2337 : CNF.Clause Nat := [(7,true), (86,false), (51,true), (98,false), (99,false), (110,false)]
theorem p2337 (F : Frame G 4) : c2337.eval F.assign = true := by
  apply local_rup F.assign c2337 [c2332, c2310, c2278, c2336, c2028, c1918, c1865, c1802, c28, c75, c66, c1810, c1556, c142, c1723, c1904, c163]
  · exact sat_cons (p2332 F) ( sat_cons (p2310 F) ( sat_cons (p2278 F) ( sat_cons (p2336 F) ( sat_cons (p2028 F) ( sat_cons (p1918 F) ( sat_cons (p1865 F) ( sat_cons (p1802 F) ( sat_cons (p28 F) ( sat_cons (p75 F) ( sat_cons (p66 F) ( sat_cons (p1810 F) ( sat_cons (p1556 F) ( sat_cons (p142 F) ( sat_cons (p1723 F) ( sat_cons (p1904 F) ( sat_cons (p163 F) (rfl)))))))))))))))))
  · decide +kernel
def c2338 : CNF.Clause Nat := [(50,false), (86,false), (51,true), (98,false), (99,false), (110,false)]
theorem p2338 (F : Frame G 4) : c2338.eval F.assign = true := by
  apply local_rup F.assign c2338 [c2337, c2332, c2310, c2278, c2028, c1918, c1865, c1902, c1802, c142, c1738, c10, c70, c1636]
  · exact sat_cons (p2337 F) ( sat_cons (p2332 F) ( sat_cons (p2310 F) ( sat_cons (p2278 F) ( sat_cons (p2028 F) ( sat_cons (p1918 F) ( sat_cons (p1865 F) ( sat_cons (p1902 F) ( sat_cons (p1802 F) ( sat_cons (p142 F) ( sat_cons (p1738 F) ( sat_cons (p10 F) ( sat_cons (p70 F) ( sat_cons (p1636 F) (rfl))))))))))))))
  · decide +kernel
def c2339 : CNF.Clause Nat := [(86,false), (51,true), (98,false), (99,false), (110,false)]
theorem p2339 (F : Frame G 4) : c2339.eval F.assign = true := by
  apply local_rup F.assign c2339 [c2332, c2310, c2278, c2337, c2338, c140, c1738, c2050, c142, c2196, c2183, c12]
  · exact sat_cons (p2332 F) ( sat_cons (p2310 F) ( sat_cons (p2278 F) ( sat_cons (p2337 F) ( sat_cons (p2338 F) ( sat_cons (p140 F) ( sat_cons (p1738 F) ( sat_cons (p2050 F) ( sat_cons (p142 F) ( sat_cons (p2196 F) ( sat_cons (p2183 F) ( sat_cons (p12 F) (rfl))))))))))))
  · decide +kernel
def c2340 : CNF.Clause Nat := [(50,true), (51,true), (98,false), (99,false), (110,false)]
theorem p2340 (F : Frame G 4) : c2340.eval F.assign = true := by
  apply local_rup F.assign c2340 [c2278, c2339, c261, c2332, c2310, c140, c2093, c12, c2121, c2183, c143]
  · exact sat_cons (p2278 F) ( sat_cons (p2339 F) ( sat_cons (p261 F) ( sat_cons (p2332 F) ( sat_cons (p2310 F) ( sat_cons (p140 F) ( sat_cons (p2093 F) ( sat_cons (p12 F) ( sat_cons (p2121 F) ( sat_cons (p2183 F) ( sat_cons (p143 F) (rfl)))))))))))
  · decide +kernel
def c2341 : CNF.Clause Nat := [(51,true), (98,false), (99,false), (110,false)]
theorem p2341 (F : Frame G 4) : c2341.eval F.assign = true := by
  apply local_rup F.assign c2341 [c2332, c2310, c2278, c2339, c261, c2340, c1802, c143, c1810, c2196, c1902, c28, c1963, c13, c1804, c1985, c1747, c10]
  · exact sat_cons (p2332 F) ( sat_cons (p2310 F) ( sat_cons (p2278 F) ( sat_cons (p2339 F) ( sat_cons (p261 F) ( sat_cons (p2340 F) ( sat_cons (p1802 F) ( sat_cons (p143 F) ( sat_cons (p1810 F) ( sat_cons (p2196 F) ( sat_cons (p1902 F) ( sat_cons (p28 F) ( sat_cons (p1963 F) ( sat_cons (p13 F) ( sat_cons (p1804 F) ( sat_cons (p1985 F) ( sat_cons (p1747 F) ( sat_cons (p10 F) (rfl))))))))))))))))))
  · decide +kernel
def c2342 : CNF.Clause Nat := [(50,false), (98,false), (99,false), (110,false)]
theorem p2342 (F : Frame G 4) : c2342.eval F.assign = true := by
  apply local_rup F.assign c2342 [c2332, c2341, c2307, c1795, c2310, c2278, c1802, c143, c142, c1410, c1791, c1918, c1865, c1723, c10, c163, c1738, c1950, c67]
  · exact sat_cons (p2332 F) ( sat_cons (p2341 F) ( sat_cons (p2307 F) ( sat_cons (p1795 F) ( sat_cons (p2310 F) ( sat_cons (p2278 F) ( sat_cons (p1802 F) ( sat_cons (p143 F) ( sat_cons (p142 F) ( sat_cons (p1410 F) ( sat_cons (p1791 F) ( sat_cons (p1918 F) ( sat_cons (p1865 F) ( sat_cons (p1723 F) ( sat_cons (p10 F) ( sat_cons (p163 F) ( sat_cons (p1738 F) ( sat_cons (p1950 F) ( sat_cons (p67 F) (rfl)))))))))))))))))))
  · decide +kernel
def c2343 : CNF.Clause Nat := [(86,false), (87,false), (50,true), (39,true), (51,false), (40,false), (99,false)]
theorem p2343 (F : Frame G 4) : c2343.eval F.assign = true := by
  apply local_rup F.assign c2343 [c1891, c1760, c17]
  · exact sat_cons (p1891 F) ( sat_cons (p1760 F) ( sat_cons (p17 F) (rfl)))
  · decide +kernel
def c2344 : CNF.Clause Nat := [(87,false), (38,false), (98,false), (99,false), (110,false)]
theorem p2344 (F : Frame G 4) : c2344.eval F.assign = true := by
  apply local_rup F.assign c2344 [c2342, c2332, c2341, c2307, c1795, c2310, c2278, c2343, c143, c1981, c2113, c1971, c17, c122, c1702, c1889, c1638, c1370, c234]
  · exact sat_cons (p2342 F) ( sat_cons (p2332 F) ( sat_cons (p2341 F) ( sat_cons (p2307 F) ( sat_cons (p1795 F) ( sat_cons (p2310 F) ( sat_cons (p2278 F) ( sat_cons (p2343 F) ( sat_cons (p143 F) ( sat_cons (p1981 F) ( sat_cons (p2113 F) ( sat_cons (p1971 F) ( sat_cons (p17 F) ( sat_cons (p122 F) ( sat_cons (p1702 F) ( sat_cons (p1889 F) ( sat_cons (p1638 F) ( sat_cons (p1370 F) ( sat_cons (p234 F) (rfl)))))))))))))))))))
  · decide +kernel
def c2345 : CNF.Clause Nat := [(38,false), (98,false), (99,false), (110,false)]
theorem p2345 (F : Frame G 4) : c2345.eval F.assign = true := by
  apply local_rup F.assign c2345 [c2342, c2332, c2341, c2307, c1795, c2310, c2278, c2344, c261, c142, c1390, c1665, c17]
  · exact sat_cons (p2342 F) ( sat_cons (p2332 F) ( sat_cons (p2341 F) ( sat_cons (p2307 F) ( sat_cons (p1795 F) ( sat_cons (p2310 F) ( sat_cons (p2278 F) ( sat_cons (p2344 F) ( sat_cons (p261 F) ( sat_cons (p142 F) ( sat_cons (p1390 F) ( sat_cons (p1665 F) ( sat_cons (p17 F) (rfl)))))))))))))
  · decide +kernel
def c2346 : CNF.Clause Nat := [(87,true), (38,true), (39,true), (19,true), (51,false), (62,false), (88,true), (98,false), (110,false)]
theorem p2346 (F : Frame G 4) : c2346.eval F.assign = true := by
  apply local_rup F.assign c2346 [c261, c142, c1410, c1968, c10]
  · exact sat_cons (p261 F) ( sat_cons (p142 F) ( sat_cons (p1410 F) ( sat_cons (p1968 F) ( sat_cons (p10 F) (rfl)))))
  · decide +kernel
def c2347 : CNF.Clause Nat := [(98,false), (99,false), (110,false)]
theorem p2347 (F : Frame G 4) : c2347.eval F.assign = true := by
  apply local_rup F.assign c2347 [c2278, c2310, c2332, c2341, c1795, c2307, c2342, c2345, c2346, c2343, c143, c1968, c1981, c2121, c10, c17, c14, c1402]
  · exact sat_cons (p2278 F) ( sat_cons (p2310 F) ( sat_cons (p2332 F) ( sat_cons (p2341 F) ( sat_cons (p1795 F) ( sat_cons (p2307 F) ( sat_cons (p2342 F) ( sat_cons (p2345 F) ( sat_cons (p2346 F) ( sat_cons (p2343 F) ( sat_cons (p143 F) ( sat_cons (p1968 F) ( sat_cons (p1981 F) ( sat_cons (p2121 F) ( sat_cons (p10 F) ( sat_cons (p17 F) ( sat_cons (p14 F) ( sat_cons (p1402 F) (rfl))))))))))))))))))
  · decide +kernel
def c2348 : CNF.Clause Nat := [(26,false), (38,true), (86,true), (30,false), (88,true), (87,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2348 (F : Frame G 4) : c2348.eval F.assign = true := by
  apply local_rup F.assign c2348 [c1792, c134, c1981, c2347, c2073, c147, c1801, c1333, c17, c14, c2237, c2075, c218]
  · exact sat_cons (p1792 F) ( sat_cons (p134 F) ( sat_cons (p1981 F) ( sat_cons (p2347 F) ( sat_cons (p2073 F) ( sat_cons (p147 F) ( sat_cons (p1801 F) ( sat_cons (p1333 F) ( sat_cons (p17 F) ( sat_cons (p14 F) ( sat_cons (p2237 F) ( sat_cons (p2075 F) ( sat_cons (p218 F) (rfl)))))))))))))
  · decide +kernel
def c2349 : CNF.Clause Nat := [(38,true), (86,true), (30,false), (88,true), (87,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2349 (F : Frame G 4) : c2349.eval F.assign = true := by
  apply local_rup F.assign c2349 [c1792, c2347, c134, c1981, c2348, c10, c2213, c147, c1801, c2236, c17]
  · exact sat_cons (p1792 F) ( sat_cons (p2347 F) ( sat_cons (p134 F) ( sat_cons (p1981 F) ( sat_cons (p2348 F) ( sat_cons (p10 F) ( sat_cons (p2213 F) ( sat_cons (p147 F) ( sat_cons (p1801 F) ( sat_cons (p2236 F) ( sat_cons (p17 F) (rfl)))))))))))
  · decide +kernel
def c2350 : CNF.Clause Nat := [(15,false), (38,false), (86,true), (30,false), (87,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2350 (F : Frame G 4) : c2350.eval F.assign = true := by
  apply local_rup F.assign c2350 [c2129, c1792, c2347, c2213, c147, c1370, c2126, c17]
  · exact sat_cons (p2129 F) ( sat_cons (p1792 F) ( sat_cons (p2347 F) ( sat_cons (p2213 F) ( sat_cons (p147 F) ( sat_cons (p1370 F) ( sat_cons (p2126 F) ( sat_cons (p17 F) (rfl))))))))
  · decide +kernel
def c2351 : CNF.Clause Nat := [(17,false), (38,false), (86,true), (30,false), (87,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2351 (F : Frame G 4) : c2351.eval F.assign = true := by
  apply local_rup F.assign c2351 [c2350, c1792, c2347, c1370, c147, c1702, c2073, c8]
  · exact sat_cons (p2350 F) ( sat_cons (p1792 F) ( sat_cons (p2347 F) ( sat_cons (p1370 F) ( sat_cons (p147 F) ( sat_cons (p1702 F) ( sat_cons (p2073 F) ( sat_cons (p8 F) (rfl))))))))
  · decide +kernel
def c2352 : CNF.Clause Nat := [(86,true), (30,false), (88,true), (87,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2352 (F : Frame G 4) : c2352.eval F.assign = true := by
  apply local_rup F.assign c2352 [c1792, c2347, c2349, c2129, c2350, c2351, c17, c1981, c1371, c8, c147, c2073]
  · exact sat_cons (p1792 F) ( sat_cons (p2347 F) ( sat_cons (p2349 F) ( sat_cons (p2129 F) ( sat_cons (p2350 F) ( sat_cons (p2351 F) ( sat_cons (p17 F) ( sat_cons (p1981 F) ( sat_cons (p1371 F) ( sat_cons (p8 F) ( sat_cons (p147 F) ( sat_cons (p2073 F) (rfl))))))))))))
  · decide +kernel
def c2353 : CNF.Clause Nat := [(38,false), (86,false), (30,false), (87,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2353 (F : Frame G 4) : c2353.eval F.assign = true := by
  apply local_rup F.assign c2353 [c1792, c2129, c1390, c2050, c2343, c17, c114, c1739]
  · exact sat_cons (p1792 F) ( sat_cons (p2129 F) ( sat_cons (p1390 F) ( sat_cons (p2050 F) ( sat_cons (p2343 F) ( sat_cons (p17 F) ( sat_cons (p114 F) ( sat_cons (p1739 F) (rfl))))))))
  · decide +kernel
def c2354 : CNF.Clause Nat := [(30,false), (88,true), (87,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2354 (F : Frame G 4) : c2354.eval F.assign = true := by
  apply local_rup F.assign c2354 [c1792, c2347, c2352, c2353, c134, c2343, c2203, c1801, c2058, c1723, c221]
  · exact sat_cons (p1792 F) ( sat_cons (p2347 F) ( sat_cons (p2352 F) ( sat_cons (p2353 F) ( sat_cons (p134 F) ( sat_cons (p2343 F) ( sat_cons (p2203 F) ( sat_cons (p1801 F) ( sat_cons (p2058 F) ( sat_cons (p1723 F) ( sat_cons (p221 F) (rfl)))))))))))
  · decide +kernel
def c2355 : CNF.Clause Nat := [(38,true), (86,false), (87,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2355 (F : Frame G 4) : c2355.eval F.assign = true := by
  apply local_rup F.assign c2355 [c1792, c134, c2343, c2028, c1865, c10]
  · exact sat_cons (p1792 F) ( sat_cons (p134 F) ( sat_cons (p2343 F) ( sat_cons (p2028 F) ( sat_cons (p1865 F) ( sat_cons (p10 F) (rfl))))))
  · decide +kernel
def c2356 : CNF.Clause Nat := [(19,true), (88,true), (87,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2356 (F : Frame G 4) : c2356.eval F.assign = true := by
  apply local_rup F.assign c2356 [c2354, c1792, c2347, c143, c2355, c1972, c2093, c1738, c178, c2150, c2156, c8, c2097, c31, c1670, c29, c121, c1739]
  · exact sat_cons (p2354 F) ( sat_cons (p1792 F) ( sat_cons (p2347 F) ( sat_cons (p143 F) ( sat_cons (p2355 F) ( sat_cons (p1972 F) ( sat_cons (p2093 F) ( sat_cons (p1738 F) ( sat_cons (p178 F) ( sat_cons (p2150 F) ( sat_cons (p2156 F) ( sat_cons (p8 F) ( sat_cons (p2097 F) ( sat_cons (p31 F) ( sat_cons (p1670 F) ( sat_cons (p29 F) ( sat_cons (p121 F) ( sat_cons (p1739 F) (rfl))))))))))))))))))
  · decide +kernel
def c2357 : CNF.Clause Nat := [(15,false), (50,true), (86,false), (88,true), (87,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2357 (F : Frame G 4) : c2357.eval F.assign = true := by
  apply local_rup F.assign c2357 [c1792, c2343, c2356, c2355, c2089, c1738, c2093, c2347, c2227, c2148, c226, c224, c1995, c2220, c105, c17, c1924]
  · exact sat_cons (p1792 F) ( sat_cons (p2343 F) ( sat_cons (p2356 F) ( sat_cons (p2355 F) ( sat_cons (p2089 F) ( sat_cons (p1738 F) ( sat_cons (p2093 F) ( sat_cons (p2347 F) ( sat_cons (p2227 F) ( sat_cons (p2148 F) ( sat_cons (p226 F) ( sat_cons (p224 F) ( sat_cons (p1995 F) ( sat_cons (p2220 F) ( sat_cons (p105 F) ( sat_cons (p17 F) ( sat_cons (p1924 F) (rfl)))))))))))))))))
  · decide +kernel
def c2358 : CNF.Clause Nat := [(50,true), (86,false), (88,true), (87,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2358 (F : Frame G 4) : c2358.eval F.assign = true := by
  apply local_rup F.assign c2358 [c2355, c2093, c2356, c1792, c2343, c2357, c8, c33, c2184]
  · exact sat_cons (p2355 F) ( sat_cons (p2093 F) ( sat_cons (p2356 F) ( sat_cons (p1792 F) ( sat_cons (p2343 F) ( sat_cons (p2357 F) ( sat_cons (p8 F) ( sat_cons (p33 F) ( sat_cons (p2184 F) (rfl)))))))))
  · decide +kernel
def c2359 : CNF.Clause Nat := [(86,false), (88,true), (87,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2359 (F : Frame G 4) : c2359.eval F.assign = true := by
  apply local_rup F.assign c2359 [c1792, c2347, c2355, c1972, c2358, c1791, c2097, c1765, c251, c2150, c2156, c8]
  · exact sat_cons (p1792 F) ( sat_cons (p2347 F) ( sat_cons (p2355 F) ( sat_cons (p1972 F) ( sat_cons (p2358 F) ( sat_cons (p1791 F) ( sat_cons (p2097 F) ( sat_cons (p1765 F) ( sat_cons (p251 F) ( sat_cons (p2150 F) ( sat_cons (p2156 F) ( sat_cons (p8 F) (rfl))))))))))))
  · decide +kernel
def c2360 : CNF.Clause Nat := [(38,false), (88,true), (87,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2360 (F : Frame G 4) : c2360.eval F.assign = true := by
  apply local_rup F.assign c2360 [c2359, c2356, c2354, c1792, c2347, c1972, c2089, c174, c147, c1662, c2227, c2073, c8]
  · exact sat_cons (p2359 F) ( sat_cons (p2356 F) ( sat_cons (p2354 F) ( sat_cons (p1792 F) ( sat_cons (p2347 F) ( sat_cons (p1972 F) ( sat_cons (p2089 F) ( sat_cons (p174 F) ( sat_cons (p147 F) ( sat_cons (p1662 F) ( sat_cons (p2227 F) ( sat_cons (p2073 F) ( sat_cons (p8 F) (rfl)))))))))))))
  · decide +kernel
def c2361 : CNF.Clause Nat := [(26,false), (88,true), (87,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2361 (F : Frame G 4) : c2361.eval F.assign = true := by
  apply local_rup F.assign c2361 [c1792, c2360, c134, c2359, c2356, c2347, c2073, c2184, c147, c1801, c1333, c14]
  · exact sat_cons (p1792 F) ( sat_cons (p2360 F) ( sat_cons (p134 F) ( sat_cons (p2359 F) ( sat_cons (p2356 F) ( sat_cons (p2347 F) ( sat_cons (p2073 F) ( sat_cons (p2184 F) ( sat_cons (p147 F) ( sat_cons (p1801 F) ( sat_cons (p1333 F) ( sat_cons (p14 F) (rfl))))))))))))
  · decide +kernel
def c2362 : CNF.Clause Nat := [(31,false), (88,true), (87,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2362 (F : Frame G 4) : c2362.eval F.assign = true := by
  apply local_rup F.assign c2362 [c2360, c1792, c2361, c10, c134, c2356, c1801, c2236, c17, c2070, c2240, c14]
  · exact sat_cons (p2360 F) ( sat_cons (p1792 F) ( sat_cons (p2361 F) ( sat_cons (p10 F) ( sat_cons (p134 F) ( sat_cons (p2356 F) ( sat_cons (p1801 F) ( sat_cons (p2236 F) ( sat_cons (p17 F) ( sat_cons (p2070 F) ( sat_cons (p2240 F) ( sat_cons (p14 F) (rfl))))))))))))
  · decide +kernel
def c2363 : CNF.Clause Nat := [(50,true), (27,true), (17,true), (9,false), (38,true), (86,true), (39,true)]
theorem p2363 (F : Frame G 4) : c2363.eval F.assign = true := by
  apply local_rup F.assign c2363 [c17, c14, c1268]
  · exact sat_cons (p17 F) ( sat_cons (p14 F) ( sat_cons (p1268 F) (rfl)))
  · decide +kernel
def c2364 : CNF.Clause Nat := [(88,true), (87,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2364 (F : Frame G 4) : c2364.eval F.assign = true := by
  apply local_rup F.assign c2364 [c1792, c2347, c2354, c2356, c2359, c2360, c134, c2361, c10, c2362, c147, c1702, c1377, c2363, c1698, c2235, c174]
  · exact sat_cons (p1792 F) ( sat_cons (p2347 F) ( sat_cons (p2354 F) ( sat_cons (p2356 F) ( sat_cons (p2359 F) ( sat_cons (p2360 F) ( sat_cons (p134 F) ( sat_cons (p2361 F) ( sat_cons (p10 F) ( sat_cons (p2362 F) ( sat_cons (p147 F) ( sat_cons (p1702 F) ( sat_cons (p1377 F) ( sat_cons (p2363 F) ( sat_cons (p1698 F) ( sat_cons (p2235 F) ( sat_cons (p174 F) (rfl)))))))))))))))))
  · decide +kernel
def c2365 : CNF.Clause Nat := [(38,true), (87,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2365 (F : Frame G 4) : c2365.eval F.assign = true := by
  apply local_rup F.assign c2365 [c2364, c2185, c1792, c2347, c134, c2355, c1473, c147]
  · exact sat_cons (p2364 F) ( sat_cons (p2185 F) ( sat_cons (p1792 F) ( sat_cons (p2347 F) ( sat_cons (p134 F) ( sat_cons (p2355 F) ( sat_cons (p1473 F) ( sat_cons (p147 F) (rfl))))))))
  · decide +kernel
def c2366 : CNF.Clause Nat := [(87,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2366 (F : Frame G 4) : c2366.eval F.assign = true := by
  apply local_rup F.assign c2366 [c2347, c1792, c2364, c2185, c2365, c1421, c147, c1703, c1473, c2073, c8]
  · exact sat_cons (p2347 F) ( sat_cons (p1792 F) ( sat_cons (p2364 F) ( sat_cons (p2185 F) ( sat_cons (p2365 F) ( sat_cons (p1421 F) ( sat_cons (p147 F) ( sat_cons (p1703 F) ( sat_cons (p1473 F) ( sat_cons (p2073 F) ( sat_cons (p8 F) (rfl)))))))))))
  · decide +kernel
def c2367 : CNF.Clause Nat := [(26,false), (40,true), (38,false), (39,true), (88,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2367 (F : Frame G 4) : c2367.eval F.assign = true := by
  apply local_rup F.assign c2367 [c2347, c2185, c1421, c147, c2366, c2125, c2164, c144, c150, c2129, c1287, c1291, c17, c119, c2127]
  · exact sat_cons (p2347 F) ( sat_cons (p2185 F) ( sat_cons (p1421 F) ( sat_cons (p147 F) ( sat_cons (p2366 F) ( sat_cons (p2125 F) ( sat_cons (p2164 F) ( sat_cons (p144 F) ( sat_cons (p150 F) ( sat_cons (p2129 F) ( sat_cons (p1287 F) ( sat_cons (p1291 F) ( sat_cons (p17 F) ( sat_cons (p119 F) ( sat_cons (p2127 F) (rfl)))))))))))))))
  · decide +kernel
def c2368 : CNF.Clause Nat := [(15,false), (9,false), (86,true), (38,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2368 (F : Frame G 4) : c2368.eval F.assign = true := by
  apply local_rup F.assign c2368 [c2366, c2213, c2227, c144]
  · exact sat_cons (p2366 F) ( sat_cons (p2213 F) ( sat_cons (p2227 F) ( sat_cons (p144 F) (rfl))))
  · decide +kernel
def c2369 : CNF.Clause Nat := [(40,true), (38,false), (39,true), (88,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2369 (F : Frame G 4) : c2369.eval F.assign = true := by
  apply local_rup F.assign c2369 [c1421, c2347, c2185, c147, c2368, c2367, c8]
  · exact sat_cons (p1421 F) ( sat_cons (p2347 F) ( sat_cons (p2185 F) ( sat_cons (p147 F) ( sat_cons (p2368 F) ( sat_cons (p2367 F) ( sat_cons (p8 F) (rfl)))))))
  · decide +kernel
def c2370 : CNF.Clause Nat := [(38,false), (39,true), (88,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2370 (F : Frame G 4) : c2370.eval F.assign = true := by
  apply local_rup F.assign c2370 [c2185, c2366, c2347, c1421, c147, c2369, c2228, c150, c1662, c1287, c144, c2129, c17, c2127, c2017, c2229, c122]
  · exact sat_cons (p2185 F) ( sat_cons (p2366 F) ( sat_cons (p2347 F) ( sat_cons (p1421 F) ( sat_cons (p147 F) ( sat_cons (p2369 F) ( sat_cons (p2228 F) ( sat_cons (p150 F) ( sat_cons (p1662 F) ( sat_cons (p1287 F) ( sat_cons (p144 F) ( sat_cons (p2129 F) ( sat_cons (p17 F) ( sat_cons (p2127 F) ( sat_cons (p2017 F) ( sat_cons (p2229 F) ( sat_cons (p122 F) (rfl)))))))))))))))))
  · decide +kernel
def c2371 : CNF.Clause Nat := [(30,false), (39,true), (88,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2371 (F : Frame G 4) : c2371.eval F.assign = true := by
  apply local_rup F.assign c2371 [c2347, c2185, c2370, c134, c1366, c147, c2366, c2058, c2213, c10, c1332, c14, c2363, c2216]
  · exact sat_cons (p2347 F) ( sat_cons (p2185 F) ( sat_cons (p2370 F) ( sat_cons (p134 F) ( sat_cons (p1366 F) ( sat_cons (p147 F) ( sat_cons (p2366 F) ( sat_cons (p2058 F) ( sat_cons (p2213 F) ( sat_cons (p10 F) ( sat_cons (p1332 F) ( sat_cons (p14 F) ( sat_cons (p2363 F) ( sat_cons (p2216 F) (rfl))))))))))))))
  · decide +kernel
def c2372 : CNF.Clause Nat := [(39,true), (88,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2372 (F : Frame G 4) : c2372.eval F.assign = true := by
  apply local_rup F.assign c2372 [c2185, c2366, c2347, c2370, c134, c1366, c147, c2371, c144, c2125, c10, c2214, c1309, c1304, c150, c17, c1287]
  · exact sat_cons (p2185 F) ( sat_cons (p2366 F) ( sat_cons (p2347 F) ( sat_cons (p2370 F) ( sat_cons (p134 F) ( sat_cons (p1366 F) ( sat_cons (p147 F) ( sat_cons (p2371 F) ( sat_cons (p144 F) ( sat_cons (p2125 F) ( sat_cons (p10 F) ( sat_cons (p2214 F) ( sat_cons (p1309 F) ( sat_cons (p1304 F) ( sat_cons (p150 F) ( sat_cons (p17 F) ( sat_cons (p1287 F) (rfl)))))))))))))))))
  · decide +kernel
def c2373 : CNF.Clause Nat := [(40,false), (38,true), (30,true), (39,false), (88,false), (87,true), (51,false), (62,false), (98,true), (110,false)]
theorem p2373 (F : Frame G 4) : c2373.eval F.assign = true := by
  apply local_rup F.assign c2373 [c2185, c1366, c147, c144, c2211, c2215, c2170, c14]
  · exact sat_cons (p2185 F) ( sat_cons (p1366 F) ( sat_cons (p147 F) ( sat_cons (p144 F) ( sat_cons (p2211 F) ( sat_cons (p2215 F) ( sat_cons (p2170 F) ( sat_cons (p14 F) (rfl))))))))
  · decide +kernel
def c2374 : CNF.Clause Nat := [(86,true), (38,true), (88,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2374 (F : Frame G 4) : c2374.eval F.assign = true := by
  apply local_rup F.assign c2374 [c2347, c2366, c2372, c2212, c2373, c2185, c147, c144, c2211, c2170, c2125, c14, c9, c1277, c1309, c150]
  · exact sat_cons (p2347 F) ( sat_cons (p2366 F) ( sat_cons (p2372 F) ( sat_cons (p2212 F) ( sat_cons (p2373 F) ( sat_cons (p2185 F) ( sat_cons (p147 F) ( sat_cons (p144 F) ( sat_cons (p2211 F) ( sat_cons (p2170 F) ( sat_cons (p2125 F) ( sat_cons (p14 F) ( sat_cons (p9 F) ( sat_cons (p1277 F) ( sat_cons (p1309 F) ( sat_cons (p150 F) (rfl))))))))))))))))
  · decide +kernel
def c2375 : CNF.Clause Nat := [(27,true), (50,true), (38,true), (88,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2375 (F : Frame G 4) : c2375.eval F.assign = true := by
  apply local_rup F.assign c2375 [c2372, c2374, c2161, c2347, c2366, c2212, c2373, c14, c93, c91, c1937, c1929, c2179, c150, c41, c2156]
  · exact sat_cons (p2372 F) ( sat_cons (p2374 F) ( sat_cons (p2161 F) ( sat_cons (p2347 F) ( sat_cons (p2366 F) ( sat_cons (p2212 F) ( sat_cons (p2373 F) ( sat_cons (p14 F) ( sat_cons (p93 F) ( sat_cons (p91 F) ( sat_cons (p1937 F) ( sat_cons (p1929 F) ( sat_cons (p2179 F) ( sat_cons (p150 F) ( sat_cons (p41 F) ( sat_cons (p2156 F) (rfl))))))))))))))))
  · decide +kernel
def c2376 : CNF.Clause Nat := [(50,true), (38,true), (88,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2376 (F : Frame G 4) : c2376.eval F.assign = true := by
  apply local_rup F.assign c2376 [c2372, c2374, c2161, c2347, c2366, c2212, c2373, c2375, c1943, c2146, c29, c128, c2179]
  · exact sat_cons (p2372 F) ( sat_cons (p2374 F) ( sat_cons (p2161 F) ( sat_cons (p2347 F) ( sat_cons (p2366 F) ( sat_cons (p2212 F) ( sat_cons (p2373 F) ( sat_cons (p2375 F) ( sat_cons (p1943 F) ( sat_cons (p2146 F) ( sat_cons (p29 F) ( sat_cons (p128 F) ( sat_cons (p2179 F) (rfl)))))))))))))
  · decide +kernel
def c2377 : CNF.Clause Nat := [(38,true), (88,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2377 (F : Frame G 4) : c2377.eval F.assign = true := by
  apply local_rup F.assign c2377 [c2372, c2212, c2366, c2347, c2373, c2374, c2161, c2376, c1791, c2097, c9, c2156, c150, c1882, c1394, c2157, c1845, c111, c197, c2184]
  · exact sat_cons (p2372 F) ( sat_cons (p2212 F) ( sat_cons (p2366 F) ( sat_cons (p2347 F) ( sat_cons (p2373 F) ( sat_cons (p2374 F) ( sat_cons (p2161 F) ( sat_cons (p2376 F) ( sat_cons (p1791 F) ( sat_cons (p2097 F) ( sat_cons (p9 F) ( sat_cons (p2156 F) ( sat_cons (p150 F) ( sat_cons (p1882 F) ( sat_cons (p1394 F) ( sat_cons (p2157 F) ( sat_cons (p1845 F) ( sat_cons (p111 F) ( sat_cons (p197 F) ( sat_cons (p2184 F) (rfl))))))))))))))))))))
  · decide +kernel
def c2378 : CNF.Clause Nat := [(88,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2378 (F : Frame G 4) : c2378.eval F.assign = true := by
  apply local_rup F.assign c2378 [c2347, c2185, c2372, c2377, c1421, c2015, c147]
  · exact sat_cons (p2347 F) ( sat_cons (p2185 F) ( sat_cons (p2372 F) ( sat_cons (p2377 F) ( sat_cons (p1421 F) ( sat_cons (p2015 F) ( sat_cons (p147 F) (rfl)))))))
  · decide +kernel
def c2379 : CNF.Clause Nat := [(38,false), (39,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2379 (F : Frame G 4) : c2379.eval F.assign = true := by
  apply local_rup F.assign c2379 [c2366, c2378, c261, c2212, c142, c1931, c2347, c2109, c150, c1951, c1412, c1623, c29]
  · exact sat_cons (p2366 F) ( sat_cons (p2378 F) ( sat_cons (p261 F) ( sat_cons (p2212 F) ( sat_cons (p142 F) ( sat_cons (p1931 F) ( sat_cons (p2347 F) ( sat_cons (p2109 F) ( sat_cons (p150 F) ( sat_cons (p1951 F) ( sat_cons (p1412 F) ( sat_cons (p1623 F) ( sat_cons (p29 F) (rfl)))))))))))))
  · decide +kernel
def c2380 : CNF.Clause Nat := [(29,true), (40,true), (39,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2380 (F : Frame G 4) : c2380.eval F.assign = true := by
  apply local_rup F.assign c2380 [c2379, c2366, c2378, c261, c2212, c142, c1931, c29, c1943, c2095, c111]
  · exact sat_cons (p2379 F) ( sat_cons (p2366 F) ( sat_cons (p2378 F) ( sat_cons (p261 F) ( sat_cons (p2212 F) ( sat_cons (p142 F) ( sat_cons (p1931 F) ( sat_cons (p29 F) ( sat_cons (p1943 F) ( sat_cons (p2095 F) ( sat_cons (p111 F) (rfl)))))))))))
  · decide +kernel
def c2381 : CNF.Clause Nat := [(50,false), (29,false), (40,true), (38,true), (19,false), (86,false), (62,false), (99,false), (110,false)]
theorem p2381 (F : Frame G 4) : c2381.eval F.assign = true := by
  apply local_rup F.assign c2381 [c2097, c2023, c9]
  · exact sat_cons (p2097 F) ( sat_cons (p2023 F) ( sat_cons (p9 F) (rfl)))
  · decide +kernel
def c2382 : CNF.Clause Nat := [(27,true), (50,true), (40,true), (38,true), (19,false), (39,false), (86,false), (51,false), (99,false), (110,false)]
theorem p2382 (F : Frame G 4) : c2382.eval F.assign = true := by
  apply local_rup F.assign c2382 [c1931, c93, c14, c2095]
  · exact sat_cons (p1931 F) ( sat_cons (p93 F) ( sat_cons (p14 F) ( sat_cons (p2095 F) (rfl))))
  · decide +kernel
def c2383 : CNF.Clause Nat := [(40,true), (39,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2383 (F : Frame G 4) : c2383.eval F.assign = true := by
  apply local_rup F.assign c2383 [c2379, c2366, c2378, c261, c2212, c142, c1931, c2347, c2380, c2381, c2382, c1943, c1394, c98, c150, c2052, c1784, c238]
  · exact sat_cons (p2379 F) ( sat_cons (p2366 F) ( sat_cons (p2378 F) ( sat_cons (p261 F) ( sat_cons (p2212 F) ( sat_cons (p142 F) ( sat_cons (p1931 F) ( sat_cons (p2347 F) ( sat_cons (p2380 F) ( sat_cons (p2381 F) ( sat_cons (p2382 F) ( sat_cons (p1943 F) ( sat_cons (p1394 F) ( sat_cons (p98 F) ( sat_cons (p150 F) ( sat_cons (p2052 F) ( sat_cons (p1784 F) ( sat_cons (p238 F) (rfl))))))))))))))))))
  · decide +kernel
def c2384 : CNF.Clause Nat := [(39,false), (51,false), (62,false), (99,false), (110,false)]
theorem p2384 (F : Frame G 4) : c2384.eval F.assign = true := by
  apply local_rup F.assign c2384 [c2366, c2378, c261, c2347, c2379, c2383, c1644, c150, c1932, c1394, c1845, c14, c242, c1791]
  · exact sat_cons (p2366 F) ( sat_cons (p2378 F) ( sat_cons (p261 F) ( sat_cons (p2347 F) ( sat_cons (p2379 F) ( sat_cons (p2383 F) ( sat_cons (p1644 F) ( sat_cons (p150 F) ( sat_cons (p1932 F) ( sat_cons (p1394 F) ( sat_cons (p1845 F) ( sat_cons (p14 F) ( sat_cons (p242 F) ( sat_cons (p1791 F) (rfl))))))))))))))
  · decide +kernel
def c2385 : CNF.Clause Nat := [(50,false), (38,true), (51,false), (62,false), (99,false), (110,false)]
theorem p2385 (F : Frame G 4) : c2385.eval F.assign = true := by
  apply local_rup F.assign c2385 [c2384, c134, c2366, c2378, c261, c2097, c2028, c10]
  · exact sat_cons (p2384 F) ( sat_cons (p134 F) ( sat_cons (p2366 F) ( sat_cons (p2378 F) ( sat_cons (p261 F) ( sat_cons (p2097 F) ( sat_cons (p2028 F) ( sat_cons (p10 F) (rfl))))))))
  · decide +kernel
def c2386 : CNF.Clause Nat := [(15,false), (5,false), (38,true), (51,false), (62,false), (99,false), (110,false)]
theorem p2386 (F : Frame G 4) : c2386.eval F.assign = true := by
  apply local_rup F.assign c2386 [c2385, c2384, c134, c2366, c2378, c261, c2347, c2148, c1927, c17, c1269, c2149, c244]
  · exact sat_cons (p2385 F) ( sat_cons (p2384 F) ( sat_cons (p134 F) ( sat_cons (p2366 F) ( sat_cons (p2378 F) ( sat_cons (p261 F) ( sat_cons (p2347 F) ( sat_cons (p2148 F) ( sat_cons (p1927 F) ( sat_cons (p17 F) ( sat_cons (p1269 F) ( sat_cons (p2149 F) ( sat_cons (p244 F) (rfl)))))))))))))
  · decide +kernel
def c2387 : CNF.Clause Nat := [(5,false), (38,true), (51,false), (62,false), (99,false), (110,false)]
theorem p2387 (F : Frame G 4) : c2387.eval F.assign = true := by
  apply local_rup F.assign c2387 [c2385, c2384, c134, c2366, c2378, c261, c2347, c2386, c10, c2156, c2184, c150, c142, c1793, c2144, c17]
  · exact sat_cons (p2385 F) ( sat_cons (p2384 F) ( sat_cons (p134 F) ( sat_cons (p2366 F) ( sat_cons (p2378 F) ( sat_cons (p261 F) ( sat_cons (p2347 F) ( sat_cons (p2386 F) ( sat_cons (p10 F) ( sat_cons (p2156 F) ( sat_cons (p2184 F) ( sat_cons (p150 F) ( sat_cons (p142 F) ( sat_cons (p1793 F) ( sat_cons (p2144 F) ( sat_cons (p17 F) (rfl))))))))))))))))
  · decide +kernel
def c2388 : CNF.Clause Nat := [(38,true), (51,false), (62,false), (99,false), (110,false)]
theorem p2388 (F : Frame G 4) : c2388.eval F.assign = true := by
  apply local_rup F.assign c2388 [c2384, c2366, c2378, c261, c2347, c2385, c2387, c14, c2146, c1394, c17, c150, c2156, c10, c2148, c2149, c239]
  · exact sat_cons (p2384 F) ( sat_cons (p2366 F) ( sat_cons (p2378 F) ( sat_cons (p261 F) ( sat_cons (p2347 F) ( sat_cons (p2385 F) ( sat_cons (p2387 F) ( sat_cons (p14 F) ( sat_cons (p2146 F) ( sat_cons (p1394 F) ( sat_cons (p17 F) ( sat_cons (p150 F) ( sat_cons (p2156 F) ( sat_cons (p10 F) ( sat_cons (p2148 F) ( sat_cons (p2149 F) ( sat_cons (p239 F) (rfl)))))))))))))))))
  · decide +kernel
def c2389 : CNF.Clause Nat := [(51,false), (62,false), (99,false), (110,false)]
theorem p2389 (F : Frame G 4) : c2389.eval F.assign = true := by
  apply local_rup F.assign c2389 [c2347, c2366, c2378, c261, c2384, c2388, c2109, c150, c2150, c2156, c8, c2097, c2148, c239, c2149, c17, c1390, c142, c2069, c2227, c165]
  · exact sat_cons (p2347 F) ( sat_cons (p2366 F) ( sat_cons (p2378 F) ( sat_cons (p261 F) ( sat_cons (p2384 F) ( sat_cons (p2388 F) ( sat_cons (p2109 F) ( sat_cons (p150 F) ( sat_cons (p2150 F) ( sat_cons (p2156 F) ( sat_cons (p8 F) ( sat_cons (p2097 F) ( sat_cons (p2148 F) ( sat_cons (p239 F) ( sat_cons (p2149 F) ( sat_cons (p17 F) ( sat_cons (p1390 F) ( sat_cons (p142 F) ( sat_cons (p2069 F) ( sat_cons (p2227 F) ( sat_cons (p165 F) (rfl)))))))))))))))))))))
  · decide +kernel
def c2390 : CNF.Clause Nat := [(21,false), (40,false), (50,true), (86,false), (38,false), (62,false), (99,false), (110,false)]
theorem p2390 (F : Frame G 4) : c2390.eval F.assign = true := by
  apply local_rup F.assign c2390 [c2389, c2151, c1394, c12]
  · exact sat_cons (p2389 F) ( sat_cons (p2151 F) ( sat_cons (p1394 F) ( sat_cons (p12 F) (rfl))))
  · decide +kernel
def c2391 : CNF.Clause Nat := [(50,true), (86,false), (38,false), (39,true), (62,false), (99,false), (110,false)]
theorem p2391 (F : Frame G 4) : c2391.eval F.assign = true := by
  apply local_rup F.assign c2391 [c2389, c2347, c135, c1652, c2390, c150, c2093, c1738, c12, c1670, c115, c1881, c28]
  · exact sat_cons (p2389 F) ( sat_cons (p2347 F) ( sat_cons (p135 F) ( sat_cons (p1652 F) ( sat_cons (p2390 F) ( sat_cons (p150 F) ( sat_cons (p2093 F) ( sat_cons (p1738 F) ( sat_cons (p12 F) ( sat_cons (p1670 F) ( sat_cons (p115 F) ( sat_cons (p1881 F) ( sat_cons (p28 F) (rfl)))))))))))))
  · decide +kernel
def c2392 : CNF.Clause Nat := [(21,true), (10,true), (87,false), (50,false), (86,false), (38,false), (62,false), (99,false), (110,false)]
theorem p2392 (F : Frame G 4) : c2392.eval F.assign = true := by
  apply local_rup F.assign c2392 [c1765, c1738, c2129, c1421, c2389, c2347, c178, c251, c1419, c1741, c28]
  · exact sat_cons (p1765 F) ( sat_cons (p1738 F) ( sat_cons (p2129 F) ( sat_cons (p1421 F) ( sat_cons (p2389 F) ( sat_cons (p2347 F) ( sat_cons (p178 F) ( sat_cons (p251 F) ( sat_cons (p1419 F) ( sat_cons (p1741 F) ( sat_cons (p28 F) (rfl)))))))))))
  · decide +kernel
def c2393 : CNF.Clause Nat := [(29,true), (7,true), (50,false), (86,false), (51,true), (99,false), (110,false)]
theorem p2393 (F : Frame G 4) : c2393.eval F.assign = true := by
  apply local_rup F.assign c2393 [c23, c28, c1918]
  · exact sat_cons (p23 F) ( sat_cons (p28 F) ( sat_cons (p1918 F) (rfl)))
  · decide +kernel
def c2394 : CNF.Clause Nat := [(87,false), (86,false), (38,false), (39,true), (62,false), (99,false), (110,false)]
theorem p2394 (F : Frame G 4) : c2394.eval F.assign = true := by
  apply local_rup F.assign c2394 [c2391, c2389, c1738, c2393, c1739, c1415, c1417, c132]
  · exact sat_cons (p2391 F) ( sat_cons (p2389 F) ( sat_cons (p1738 F) ( sat_cons (p2393 F) ( sat_cons (p1739 F) ( sat_cons (p1415 F) ( sat_cons (p1417 F) ( sat_cons (p132 F) (rfl))))))))
  · decide +kernel
def c2395 : CNF.Clause Nat := [(29,false), (86,false), (38,false), (39,true), (62,false), (99,false), (110,false)]
theorem p2395 (F : Frame G 4) : c2395.eval F.assign = true := by
  apply local_rup F.assign c2395 [c1421, c2391, c2129, c2394, c142, c2097, c2347, c1392, c2023, c150, c8, c2150]
  · exact sat_cons (p1421 F) ( sat_cons (p2391 F) ( sat_cons (p2129 F) ( sat_cons (p2394 F) ( sat_cons (p142 F) ( sat_cons (p2097 F) ( sat_cons (p2347 F) ( sat_cons (p1392 F) ( sat_cons (p2023 F) ( sat_cons (p150 F) ( sat_cons (p8 F) ( sat_cons (p2150 F) (rfl))))))))))))
  · decide +kernel
def c2396 : CNF.Clause Nat := [(86,false), (38,false), (39,true), (62,false), (99,false), (110,false)]
theorem p2396 (F : Frame G 4) : c2396.eval F.assign = true := by
  apply local_rup F.assign c2396 [c2389, c2347, c1421, c2391, c2129, c2097, c2394, c142, c2395, c2393, c1807, c2224, c150, c8, c2150]
  · exact sat_cons (p2389 F) ( sat_cons (p2347 F) ( sat_cons (p1421 F) ( sat_cons (p2391 F) ( sat_cons (p2129 F) ( sat_cons (p2097 F) ( sat_cons (p2394 F) ( sat_cons (p142 F) ( sat_cons (p2395 F) ( sat_cons (p2393 F) ( sat_cons (p1807 F) ( sat_cons (p2224 F) ( sat_cons (p150 F) ( sat_cons (p8 F) ( sat_cons (p2150 F) (rfl)))))))))))))))
  · decide +kernel
def c2397 : CNF.Clause Nat := [(87,true), (50,false), (86,true), (38,false), (62,false), (99,false), (110,false)]
theorem p2397 (F : Frame G 4) : c2397.eval F.assign = true := by
  apply local_rup F.assign c2397 [c2129, c2389, c2347, c261, c144, c2016, c147, c2176, c1378, c1364, c150, c26, c1662]
  · exact sat_cons (p2129 F) ( sat_cons (p2389 F) ( sat_cons (p2347 F) ( sat_cons (p261 F) ( sat_cons (p144 F) ( sat_cons (p2016 F) ( sat_cons (p147 F) ( sat_cons (p2176 F) ( sat_cons (p1378 F) ( sat_cons (p1364 F) ( sat_cons (p150 F) ( sat_cons (p26 F) ( sat_cons (p1662 F) (rfl)))))))))))))
  · decide +kernel
def c2398 : CNF.Clause Nat := [(40,false), (21,true), (87,false), (30,true), (50,false), (86,true), (38,false), (62,false), (98,true), (99,false)]
theorem p2398 (F : Frame G 4) : c2398.eval F.assign = true := by
  apply local_rup F.assign c2398 [c1801, c147, c1473, c143, c174, c1662]
  · exact sat_cons (p1801 F) ( sat_cons (p147 F) ( sat_cons (p1473 F) ( sat_cons (p143 F) ( sat_cons (p174 F) ( sat_cons (p1662 F) (rfl))))))
  · decide +kernel
def c2399 : CNF.Clause Nat := [(19,false), (40,true), (50,false), (86,true), (38,false), (62,false), (99,false), (110,false)]
theorem p2399 (F : Frame G 4) : c2399.eval F.assign = true := by
  apply local_rup F.assign c2399 [c2397, c2389, c2347, c2089, c1419, c147, c20, c1713]
  · exact sat_cons (p2397 F) ( sat_cons (p2389 F) ( sat_cons (p2347 F) ( sat_cons (p2089 F) ( sat_cons (p1419 F) ( sat_cons (p147 F) ( sat_cons (p20 F) ( sat_cons (p1713 F) (rfl))))))))
  · decide +kernel
def c2400 : CNF.Clause Nat := [(29,true), (88,false), (40,true), (87,false), (50,false), (86,true), (38,false), (51,true), (62,false), (98,true), (99,false)]
theorem p2400 (F : Frame G 4) : c2400.eval F.assign = true := by
  apply local_rup F.assign c2400 [c23, c20, c1512, c1713, c147]
  · exact sat_cons (p23 F) ( sat_cons (p20 F) ( sat_cons (p1512 F) ( sat_cons (p1713 F) ( sat_cons (p147 F) (rfl)))))
  · decide +kernel
end Cert44Steps
end Graffiti199Depleted.Catalogue.OrderEleven
