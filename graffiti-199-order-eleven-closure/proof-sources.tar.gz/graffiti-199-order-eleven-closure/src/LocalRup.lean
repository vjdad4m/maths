import RuleSound

namespace Graffiti199Depleted.Catalogue.OrderEleven

open Std.Sat

def negateLiteral (l : Literal Nat) : Literal Nat := (l.1,!l.2)

def reduceClause (units : List (Literal Nat)) (c : CNF.Clause Nat) : CNF.Clause Nat :=
  c.filter (fun l => !units.contains (negateLiteral l))

def refuteByUnits (units : List (Literal Nat)) : CNF Nat → Bool
  | [] => false
  | c :: cs =>
    match reduceClause units c with
    | [] => true
    | [l] => refuteByUnits (l :: units) cs
    | _ => false

private theorem reduce_preserves_truth {a : Nat → Bool} {units : List (Literal Nat)}
    (known : ∀ l ∈ units, a l.1 = l.2) {c : CNF.Clause Nat}
    (hc : c.eval a = true) : (reduceClause units c).eval a = true := by
  obtain ⟨⟨v,b⟩,mem,yes⟩ := List.any_eq_true.mp hc
  have e : a v = b := by simpa using yes
  apply List.any_eq_true.mpr
  refine ⟨(v,b),List.mem_filter.mpr ⟨mem,?_⟩,yes⟩
  simp only [Bool.not_eq_true',List.contains_eq_mem,decide_eq_false_iff_not]
  intro h
  have bad := known _ h
  change a v = !b at bad
  cases b <;> simp_all

private theorem refute_sound (a : Nat → Bool) (parents : CNF Nat)
    (units : List (Literal Nat)) (known : ∀ l ∈ units, a l.1 = l.2)
    (sat : parents.eval a = true) (refuted : refuteByUnits units parents = true) : False := by
  induction parents generalizing units with
  | nil => simp [refuteByUnits] at refuted
  | cons c cs ih =>
    have h : c.eval a = true ∧ CNF.eval a cs = true := by simpa using sat
    have truth := reduce_preserves_truth known h.1
    simp only [refuteByUnits] at refuted
    split at refuted
    · next eq => rw [eq] at truth; contradiction
    · next l eq =>
      rw [eq] at truth
      have leq : a l.1 = l.2 := by simpa using truth
      apply ih (l :: units) _ h.2 refuted
      intro t ht
      rcases List.mem_cons.mp ht with rfl|old
      · exact leq
      · exact known t old
    · contradiction

/-- Reverse unit propagation, with one parent clause per propagation hint.
The numerical computation uses ordinary Lean reduction. -/
theorem local_rup (a : Nat → Bool) (c : CNF.Clause Nat) (parents : CNF Nat)
    (sat : parents.eval a = true)
    (checkStep : refuteByUnits (c.map negateLiteral) parents = true) :
    c.eval a = true := by
  by_contra! bad
  apply refute_sound a parents _ _ sat checkStep
  intro l hl
  obtain ⟨⟨v,b⟩,mem,rfl⟩ := List.mem_map.mp hl
  change a v = !b
  have neq : ¬ a v = b := by
    intro yes
    apply bad
    exact List.any_eq_true.mpr ⟨(v,b),mem,by simp [yes]⟩
  cases h : a v <;> cases b <;> simp_all

theorem sat_cons {a : Nat → Bool} {c : CNF.Clause Nat} {cs : CNF Nat}
    (hc : c.eval a = true) (hcs : cs.eval a = true) :
    CNF.eval a (c :: cs) = true := by simp [hc,hcs]

#print axioms local_rup
end Graffiti199Depleted.Catalogue.OrderEleven
