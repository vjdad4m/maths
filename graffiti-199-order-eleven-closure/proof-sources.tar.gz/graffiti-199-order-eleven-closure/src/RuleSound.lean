import CutCNF

open private six_le_treeNumber_of_five_independent_neighbors from CubicEdgeCuts

namespace Graffiti199Depleted.Catalogue.OrderEleven

open SimpleGraph Std.Sat

variable {V : Type*} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj]
variable {k : Nat}

private theorem sat_of_literal {assignment : Nat → Bool} {C : CNF.Clause Nat}
    {l : Literal Nat} (mem : l ∈ C) (yes : assignment l.1 = l.2) :
    C.eval assignment = true := by
  unfold CNF.Clause.eval
  exact List.any_eq_true.mpr ⟨l,mem,by simpa using yes⟩

private theorem Frame.true_of_edge (F : Frame G k) {u v : Vertex}
    (hu : ¬ IsPort u) (edge : G.Adj (F.name u) (F.name v)) :
    F.assign (edgeVar u v) = true :=
  (F.assign_edge u v).mpr ⟨F.allowed _ _ hu edge,edge⟩

private theorem Frame.degree_le_exceptions (F : Frame G k) {u : Vertex}
    (hu : ¬ IsPort u) (X : List Vertex)
    (h : ∀ x ∈ beyond k u X, F.assign (edgeVar u x) ≠ true) :
    G.degree (F.name u) ≤ X.length := by
  classical
  have bound : G.neighborFinset (F.name u) ⊆ X.toFinset.map F.name.toEmbedding := by
    intro v hv
    obtain ⟨x,rfl⟩ := F.name.surjective v
    have edge := (G.mem_neighborFinset _ _).mp hv
    have mem : x ∈ X := by
      by_contra off
      exact h x (mem_beyond.mpr ⟨F.allowed _ _ hu edge,off⟩) (F.true_of_edge hu edge)
    exact Finset.mem_map.mpr ⟨x,List.mem_toFinset.mpr mem,rfl⟩
  have cap := Finset.card_le_card bound
  rw [G.card_neighborFinset_eq_degree,Finset.card_map] at cap
  exact cap.trans (List.toFinset_card_le X)

private theorem sound_degree (F : Frame G k) (v : Vertex) (X : List Vertex)
    (hv : ¬ IsPort v) (count : X.length ≤ 2) :
    ((Rule.degree v X).clause k).eval F.assign = true := by
  apply Classical.byContradiction
  intro bad
  have cap := F.degree_le_exceptions hv X (by
    intro x hx yes
    exact bad (sat_of_literal (List.mem_map.mpr ⟨x,hx,rfl⟩ :
      positive v x ∈ (Rule.degree v X).clause k) yes))
  have lower := F.lower v hv
  omega

private theorem sound_cubic (F : Frame G k) (u v : Vertex) (X Y : List Vertex)
    (hu : ¬ IsPort u) (hv : ¬ IsPort v) (countX : X.length ≤ 3) (countY : Y.length ≤ 3) :
    ((Rule.cubic u v X Y).clause k).eval F.assign = true := by
  apply Classical.byContradiction
  intro bad
  have yes : F.assign (edgeVar u v) = true := by
    cases eq : F.assign (edgeVar u v)
    · exact (bad (sat_of_literal (show negative u v ∈ (Rule.cubic u v X Y).clause k from
        List.mem_cons_self ..) eq)).elim
    · rfl
  have edge := ((F.assign_edge u v).mp yes).2
  have capX := F.degree_le_exceptions hu X (by
    intro x hx hit
    exact bad (sat_of_literal (List.mem_cons_of_mem _ (List.mem_append_left _
      (List.mem_map.mpr ⟨x,hx,rfl⟩)) : positive u x ∈ (Rule.cubic u v X Y).clause k) hit))
  have capY := F.degree_le_exceptions hv Y (by
    intro y hy hit
    exact bad (sat_of_literal (List.mem_cons_of_mem _ (List.mem_append_right _
      (List.mem_map.mpr ⟨y,hy,rfl⟩)) : positive v y ∈ (Rule.cubic u v X Y).clause k) hit))
  have minX := F.lower u hu
  have minY := F.lower v hv
  exact F.cubic _ _ (by omega) (by omega) edge

private theorem sound_hall (F : Frame G k) (b : Bool) (selected : List Port) (X : List Vertex)
    (distinct : selected.Nodup) (count : X.length < selected.length) :
    ((Rule.hall b selected X).clause k).eval F.assign = true := by
  apply Classical.byContradiction
  intro bad
  obtain ⟨g,range,hg⟩ := F.matchPorts b
  have sub : selected.toFinset.map g ⊆ X.toFinset := by
    intro x hx
    obtain ⟨p,hp,rfl⟩ := Finset.mem_map.mp hx
    apply List.mem_toFinset.mpr
    by_contra off
    have h : positive (port p) (g p) ∈ (Rule.hall b selected X).clause k := by
      apply List.mem_flatMap.mpr
      refine ⟨p,List.mem_toFinset.mp hp,?_⟩
      exact List.mem_map.mpr ⟨g p,List.mem_filter.mpr ⟨mem_sideVertices.mpr (range p),by simp [off]⟩,rfl⟩
    exact bad (sat_of_literal h ((F.assign_edge _ _).mpr ⟨allowed_port_side (range p),hg p⟩))
  have cap := Finset.card_le_card sub
  rw [Finset.card_map,List.toFinset_card_of_nodup distinct] at cap
  exact (Nat.not_lt_of_ge (cap.trans (List.toFinset_card_le X))) count

private theorem sound_connected (F : Frame G k) (b : Bool) (selected : List Vertex)
    (someIn : ∃ v ∈ sideVertices k b, v ∈ selected)
    (someOut : ∃ v ∈ sideVertices k b, v ∉ selected) :
    ((Rule.connected b selected).clause k).eval F.assign = true := by
  obtain ⟨u,hu,yes⟩ := someIn
  obtain ⟨v,hv,no⟩ := someOut
  let A : Set V := {x | InSide k b (F.name.symm x)}
  have uA : F.name u ∈ A := by simpa [A] using mem_sideVertices.mp hu
  have vA : F.name v ∈ A := by simpa [A] using mem_sideVertices.mp hv
  obtain ⟨w⟩ := (F.sidesConnected b).preconnected ⟨F.name u,uA⟩ ⟨F.name v,vA⟩
  let region : Set A := {x | F.name.symm x.val ∈ selected}
  have src : (⟨F.name u,uA⟩ : A) ∈ region := by simpa [region] using yes
  have dst : (⟨F.name v,vA⟩ : A) ∉ region := by simpa [region] using no
  obtain ⟨x,hx,y,hy,xy⟩ := crossingOnWalk (U := region) w src dst
  let a := F.name.symm x.val
  let c := F.name.symm y.val
  have e : G.Adj (F.name a) (F.name c) := by
    have h : G.Adj x.val y.val := xy
    simpa [a,c] using h
  have aSide : InSide k b a := x.property
  have cSide : InSide k b c := y.property
  have ne : a ≠ c := fun eq => e.ne (congrArg F.name eq)
  have lit : positive a c ∈ (Rule.connected b selected).clause k := by
    apply List.mem_flatMap.mpr
    refine ⟨a,hx,?_⟩
    exact List.mem_map.mpr ⟨c,List.mem_filter.mpr ⟨mem_sideVertices.mpr cSide,by simpa [region] using hy⟩,rfl⟩
  exact sat_of_literal lit ((F.assign_edge _ _).mpr ⟨allowed_same_side aSide cSide ne,e⟩)

private theorem sound_star (F : Frame G k) (p : Port) (leaves : List Vertex)
    (count : leaves.length = 5) (distinct : leaves.Nodup) (off : ∀ v ∈ leaves, ¬ IsPort v) :
    ((Rule.star p leaves).clause k).eval F.assign = true := by
  classical
  apply Classical.byContradiction
  intro bad
  let T := leaves.toFinset.map F.name.toEmbedding
  have cardT : 5 ≤ T.card := by
    change 5 ≤ (leaves.toFinset.map F.name.toEmbedding).card
    rw [Finset.card_map,List.toFinset_card_of_nodup distinct,count]
  have touches (v : V) (hv : v ∈ T) : G.Adj (F.name (port p)) v := by
    obtain ⟨x,hx,rfl⟩ := Finset.mem_map.mp hv
    have lit : negative (port p) x ∈ (Rule.star p leaves).clause k :=
      List.mem_append_left _ (List.mem_map.mpr ⟨x,List.mem_toFinset.mp hx,rfl⟩)
    have yes : F.assign (edgeVar (port p) x) = true := by
      cases eq : F.assign (edgeVar (port p) x)
      · exact (bad (sat_of_literal lit eq)).elim
      · rfl
    exact ((F.assign_edge _ _).mp yes).2
  have noPair {x y : Vertex} (hx : x ∈ leaves) (hy : y ∈ leaves) (lt : x.val < y.val) :
      ¬ G.Adj (F.name x) (F.name y) := by
    intro edge
    have ltEdge : Allowed k x y := F.allowed _ _ (off _ hx) edge
    have lit : positive x y ∈ (Rule.star p leaves).clause k := by
      apply List.mem_append_right
      apply List.mem_flatMap.mpr
      refine ⟨x,hx,?_⟩
      exact List.mem_map.mpr ⟨y,List.mem_filter.mpr ⟨hy,by simp [lt,ltEdge]⟩,rfl⟩
    exact bad (sat_of_literal lit ((F.assign_edge _ _).mpr ⟨ltEdge,edge⟩))
  have stable (a : V) (ha : a ∈ T) (b : V) (hb : b ∈ T) : ¬ G.Adj a b := by
    obtain ⟨x,hx,rfl⟩ := Finset.mem_map.mp ha
    obtain ⟨y,hy,rfl⟩ := Finset.mem_map.mp hb
    have hx' := List.mem_toFinset.mp hx
    have hy' := List.mem_toFinset.mp hy
    rcases lt_trichotomy x.val y.val with lt|eq|lt
    · exact noPair hx' hy' lt
    · have e : x = y := Fin.ext eq
      rw [e]
      exact G.loopless _
    · exact fun edge => noPair hy' hx' lt edge.symm
  have six := six_le_treeNumber_of_five_independent_neighbors T _ cardT touches stable
  have budget := F.budget
  omega

private theorem chain_of_zip {X : Type*} {R : X → X → Prop} {L : List X}
    (h : ∀ uv ∈ L.zip L.tail, R uv.1 uv.2) : L.Chain' R := by
  induction L with
  | nil => simp
  | cons x L ih =>
    cases L with
    | nil => exact List.chain'_singleton x
    | cons y ys =>
      refine List.chain'_cons.mpr ⟨h (x,y) (by simp),ih ?_⟩
      intro uv huv
      exact h uv (List.mem_cons_of_mem _ huv)

private theorem sound_path (F : Frame G k) (L : List Vertex)
    (count : L.length = 11) (distinct : L.Nodup) :
    ((Rule.path L).clause k).eval F.assign = true := by
  classical
  apply Classical.byContradiction
  intro bad
  have chain : L.Chain' (fun u v => G.Adj (F.name u) (F.name v)) := by
    apply chain_of_zip
    intro uv h
    have lit : negative uv.1 uv.2 ∈ (Rule.path L).clause k := List.mem_map.mpr ⟨uv,h,rfl⟩
    have yes : F.assign (edgeVar uv.1 uv.2) = true := by
      cases eq : F.assign (edgeVar uv.1 uv.2)
      · exact (bad (sat_of_literal lit eq)).elim
      · rfl
    exact ((F.assign_edge _ _).mp yes).2
  have full : L.toFinset = Finset.univ := Finset.eq_of_subset_of_card_le
    (Finset.subset_univ _) (by rw [Finset.card_univ,List.toFinset_card_of_nodup distinct,count]; decide)
  have all (v : V) : v ∈ L.map F.name := by
    obtain ⟨x,rfl⟩ := F.name.surjective v
    exact List.mem_map.mpr ⟨x,List.mem_toFinset.mp (full.symm ▸ Finset.mem_univ x),rfl⟩
  have ne : L.map F.name ≠ [] := fun e => List.not_mem_nil (e ▸ all (F.name 0))
  let W : PathOn G Set.univ := ⟨L.map F.name,ne,(List.chain'_map _).mpr chain,
    distinct.map F.name.injective,fun v => iff_of_true (all v) trivial⟩
  exact F.noPath (traceable_iff_hamiltonian_walk.mpr (pathOn_univ_iff_hamiltonian_walk.mp ⟨W⟩))

theorem Rule.sound (F : Frame G k) (r : Rule) (valid : r.Valid k) :
    (r.clause k).eval F.assign = true := by
  cases r with
  | matched b p v =>
      exact sat_of_literal (show positive (port p) v ∈ (Rule.matched b p v).clause k from by
        simp [Rule.clause]) ((F.assign_edge _ _).mpr ⟨allowed_port_side valid.1,F.fixedMatching b p v valid.2⟩)
  | degree v X => exact sound_degree F v X valid.1 valid.2
  | cubic u v X Y => exact sound_cubic F u v X Y valid.1 valid.2.1 valid.2.2.1 valid.2.2.2
  | hall b selected X => exact sound_hall F b selected X valid.1 valid.2
  | connected b selected => exact sound_connected F b selected valid.1 valid.2.1
  | star p leaves => exact sound_star F p leaves valid.1 valid.2.1 valid.2.2
  | path L => exact sound_path F L valid.1 valid.2

/-- If the finite clause set has a kernel-verified LRAT refutation,
no input graph can satisfy all the cut hypotheses and be nontraceable. -/
theorem unsat_excludes_frame {G : SimpleGraph V} [DecidableRel G.Adj] (F : Frame G k)
    (rules : List Rule) (valid : ∀ r ∈ rules, r.Valid k) (unsat : (rulesCNF k rules).Unsat) : False := by
  have yes : (rulesCNF k rules).eval F.assign = true := by
    unfold CNF.eval rulesCNF
    apply List.all_eq_true.mpr
    intro c hc
    obtain ⟨r,hr,rfl⟩ := List.mem_map.mp hc
    exact r.sound F (valid r hr)
  rw [unsat F.assign] at yes
  contradiction

#print axioms Rule.sound
#print axioms unsat_excludes_frame

end Graffiti199Depleted.Catalogue.OrderEleven
