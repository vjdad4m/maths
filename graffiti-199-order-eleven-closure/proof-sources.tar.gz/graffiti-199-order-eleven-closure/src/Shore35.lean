import GraphLift
import Conclusion35

namespace Graffiti199Depleted.Catalogue.OrderEleven

open SimpleGraph

universe u
variable {V : Type u} {G : SimpleGraph V} [Fintype V] [DecidableRel G.Adj]
variable {D : Finset V} {A B : Set V}

/-- The 3+5 case allows any spanning path through the two sides, including
paths that enter the five-vertex side more than once. -/
theorem traceable_of_three_five_shores
    (conn : ConnectivityAtLeast G 3) (order : Fintype.card V = 11)
    (cut : D.card = 3) (cardA : Nat.card A = 3) (cardB : Nat.card B = 5)
    (offA : ∀ x ∈ D, x ∉ A) (offB : ∀ x ∈ D, x ∉ B)
    (apart : Disjoint A B) (cover : ∀ v, v ∈ A ∨ v ∈ B ∨ v ∈ D)
    (ba : ShoreBoundary G D A) (bb : ShoreBoundary G D B)
    (ca : (G.induce A).Connected) (cb : (G.induce B).Connected)
    (cubic : ∀ x y : V, G.degree x = 3 → G.degree y = 3 → ¬ G.Adj x y)
    (budget : treeNumber G ≤ 5) : Traceable G := by
  classical
  by_contra no
  obtain ⟨F⟩ := frame_of_two_shores conn order cut (k := 3) (by decide) (by decide)
    cardA cardB offA offB apart cover ba bb ca cb cubic budget no
  exact caseContradiction35 F

#print axioms traceable_of_three_five_shores

end Graffiti199Depleted.Catalogue.OrderEleven
