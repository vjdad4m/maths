import csv
import hashlib
import re
from pathlib import Path

root = Path(__file__).resolve().parent
with (root / "Manifest.tsv").open() as f:
    manifest = list(csv.DictReader(f, delimiter="\t"))
seen = set()
full = (root / "StrictReplay.log").read_text()
baseline = b''.join((root / "Manifest.tsv").read_bytes().splitlines(keepends=True)[:133])
assert hashlib.sha256(baseline).hexdigest() == "60b23973c0940fe1d453147817cae49029211528119498a42b371f4081ce5fc9"
assert full.startswith("Lean (version 4.19.0,")
assert "\nMathlib c44e0c8ee63ca166450922a373c7409c5d26b00b\n" in full
assert full.endswith("Strict clean-source replay passed.\n")
checked = re.findall(r"(?m)^.*?/src/([^/]+\.lean): OK$", full)
assert checked == [row["file"] for row in manifest]
assert len(checked) == len(set(checked)) == 155
assert not re.search(r"(?m)(?:error|warning):|sorryAx", full)

def lean_code(source):
    # Remove nested Lean comments before scanning tokens.
    code, n, i = [], 0, 0
    while i < len(source):
        if source.startswith("/-", i):
            n += 1
            i += 2
        elif n and source.startswith("-/", i):
            n -= 1
            code.append(" ")
            i += 2
        elif n:
            i += 1
        elif source.startswith("--", i):
            i = source.find("\n", i)
            if i < 0:
                break
        else:
            code.append(source[i])
            i += 1
    assert n == 0
    return "".join(code)

allowed = {'propext', 'Classical.choice', 'Quot.sound'}
all_lists = re.findall(r"'[^']+' depends on axioms: \[([^\]]+)\]", full)
for axiom_list in all_lists:
    assert {a.strip() for a in axiom_list.split(',')} <= allowed, axiom_list
assert set(p.name for p in (root / 'src').glob('*.lean')) == set(checked)
for row in manifest:
    path = root / "src" / row["file"]
    body = path.read_bytes()
    assert hashlib.sha256(body).hexdigest() == row["sha256"]
    assert not re.search(r"\b(sorry|admit|native_decide|axiom|sorryAx)\b", lean_code(body.decode())), path
    for line in re.findall(r"^import\s+([^\n]+)", body.decode(), re.M):
        for dep in line.split():
            if dep + ".lean" in checked:
                assert dep in seen, (row["file"], dep)
    seen.add(path.stem)
namespace = "Graffiti199Depleted.Catalogue.Incomplete."
names = ["traceable_of_three_or_more_components","SingletonCut.traceable_of_small_root","all_ports_have_rooted_four","SingletonCut.quartet_contacts","SingletonCut.port_miss_dichotomy","catalogue_minimum_singleton_profile","SingletonCut.exchange_unique_miss","SingletonCut.unique_miss_degree_and_contacts","SingletonCut.traceable_of_two_almost_complete","SingletonCut.port_pair_profile","catalogue_minimum_port_deficiency","SingletonCut.single_miss_core"]
names.extend([
    "SingletonCut.traceable_of_one_almost_complete",
    "catalogue_minimum_all_ports_miss_two",
    "SingletonCut.traceable_of_routable_nonneighbors",
    "SingletonCut.traceable_of_terminal_closure",
    "SingletonCut.traceable_of_two_neighbor_parts",
    "SingletonCut.three_cliques_of_cycle",
    "ThreeCliques.splice",
    "ThreeCliques.complete_to_another",
    "SingletonCut.traceable_of_matched_two_misses",
    "catalogue_minimum_misses_and_matching",
])
names = [namespace + x for x in names]
names += ["Graffiti199Depleted.Catalogue.Anchored." + x for x in
          ["large_independent_of_omission", "spanning_path_from_root", "exterior_three", "traceable_via_exterior"]]
names += ["Graffiti189LongestPath.CrossSaturation.terminal_ore_closure"]
for name in names:
    sig = re.search(r"'" + re.escape(name) + r"' depends on axioms: \[([^]]+)\]", full)
    assert sig, name
    axs = [a.strip() for a in sig.group(1).split(",")]
    assert axs == ["propext", "Classical.choice", "Quot.sound"], (name, axs)
    print(name, axs)
print("The first 132 ordered source entries match the frozen singleton-cut manifest.")
print(len(checked), "sources matched compilation order and SHA-256 digests")
print("Strict clean-source replay, source-token audit, and final transitive axiom audit passed.")




