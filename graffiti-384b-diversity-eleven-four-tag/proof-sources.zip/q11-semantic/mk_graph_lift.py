#!/usr/bin/env python3
from pathlib import Path
from argparse import ArgumentParser
import json,re
ap=ArgumentParser()
ap.add_argument('dir',type=Path)
ap.add_argument('base',type=Path)
ap.add_argument('k',type=int,choices=[4,5,6])
a=ap.parse_args(); k=a.k; dn={4:'Four',5:'Five',6:'Six'}[k]
p=a.dir
meta=json.loads(a.base.with_suffix('.semantics.json').read_text())
E={tuple((i,j)):v for i,j,v in meta['edges']}
ctx=(p/f'DiversityElevenPendantSemanticRoots{k}384b.lean').read_text()
ctx=ctx.split('theorem have_triple_of_exact_counts',1)[1].split(': HasTriple E := by',1)[0]
ds=list(map(int,re.findall(r'\(d(\d)',ctx)))
ss=list(map(int,re.findall(r'\(s(\d)',ctx)))
os=[tuple(map(int,pr)) for pr in re.findall(r'\(o(\d)(\d)',ctx)]
ps=[tuple(map(int,pr)) for pr in re.findall(r'\(p(\d)(\d)',ctx)]
sc=sorted(set(ss)|{i for row in os for i in row})
src_cnt=(p/'DiversityElevenPendantCounterThree384b.lean').read_text().split('theorem degree0_graphWires')[0]
src_cnt=src_cnt.replace('SemanticRoots3384b',f'SemanticRoots{k}384b').replace('PendantCircuit.K3',f'PendantCircuit.K{k}')
for g in [*(f'degree{i}' for i in ds),*(f'score{i}' for i in sc)]:
  j=int(g[-1]); vals=meta['tracks'][g]['inputs']
  src_cnt+=f'theorem {g}_graphWires (G : SimpleGraph (Fin 8)) [DecidableRel G.Adj] :\n    {g}_count (graphWires G) = {"G.degree" if g.startswith("degree") else "trianglesAt G"} {j} := by\n'
  if g.startswith('degree'):
    src_cnt+=f'  exact degree_count G {j}\n\n'
  else:
    def edge(a,b):return f'g{E[tuple(sorted((a,b)))]} (graphWires G)'
    bals=[(a,b) for a,b,_ in meta['edges'] if j not in (a,b)][::-1]
    rearranged=', '.join(' && '.join(f'({x})' for x in [edge(j,a),edge(j,b),edge(a,b)]) for a,b in bals)
    src_cnt+=f'''  change countTrue [{', '.join('g'+str(i)+' (graphWires G)' for i in reversed(vals))}] = _
  calc
    _ = countTrue [{rearranged}] := by
      simp only [{', '.join('g'+str(i) for i in vals)}, Bool.and_comm,Bool.and_left_comm,Bool.and_assoc]
    _ = _ := tri_count G {j}

'''
src_cnt+=f'end Graffiti384b.DiversityEleven.PendantCircuit.K{k}\n'
(p/f'DiversityElevenPendantCounter{dn}384b.lean').write_text(src_cnt)
s=(p/'DiversityElevenExactThreeSelector384b.lean').read_text()
s=s.replace('PendantCounterThree384b',f'PendantCounter{dn}384b').replace('NormalizeThree384b','NormalizeTags384b')
s=s.replace('PendantCircuit.K3',f'PendantCircuit.K{k}').replace('K3.countTrue_map',f'K{k}.countTrue_map')
s=s.replace('exact_three',f'exact_{dn.lower()}').replace('three-tag','tagged')
s=s.replace('(deg : ∀ i,3≤G.degree i) (small : 2≤trianglesAt G 0)\n    (up₁ : trianglesAt G 0 < trianglesAt G 1) (up₂ : trianglesAt G 1 < trianglesAt G 2)',
f'''(deg : ∀ i,3≤G.degree i) (small : ∀ i : Fin 8,i.val<{k} → 2≤trianglesAt G i)
    (up : ∀ i j : Fin 8,i<j → j.val<{k} → trianglesAt G i<trianglesAt G j)''')
s=s.replace('(3 : Nat) ≤ i.val',f'({k} : Nat) ≤ i.val').replace('v.val<3',f'v.val<{k}').replace('(sz : Z.card=3)',f'(sz : Z.card={k})')
s=s[:s.index('  obtain ⟨a,b,c,ab,bc,h⟩')] + '  obtain ⟨a,b,c,ab,bc,h⟩ := have_triple_of_exact_counts E\n'+''.join(
  [f'    (by rw [degree{i}_graphWires]; exact deg {i})\n' for i in ds]+
  [f'    (by rw [score{i}_graphWires]; exact small {i} (by decide))\n' for i in ss]+
  [f'    (by rw [score{i}_graphWires,score{j}_graphWires]; exact up {i} {j} (by decide) (by decide))\n' for i,j in os]+
  [f'    (port {i} {j} (by decide) (by decide))\n' for i,j in ps])+s[s.index('  let K : Finset'):]
s=s.replace('order_three_tags G Z sz inj',f'order_tags_at G Z {k} sz (by decide) (by decide) inj')
lo=s.index('  have h₀'); hi=s.index('  let M := K.map',lo)
s=s[:lo]+f'''  have small (i : Fin 8) (iz : i.val<{k}) : 2≤trianglesAt H i :=
    (tr i).symm ▸ mn _ ((tag i).mpr iz)
  have up (i j : Fin 8) (ij : i<j) (jz : j.val<{k}) :
      trianglesAt H i<trianglesAt H j := by
    rw [tr,tr]
    exact order i j ij jz
  obtain ⟨K,k3,good⟩ := exact_{dn.lower()}_on_ordered_graph H hd small up ports
'''+s[hi:]
(p/f'DiversityElevenExact{dn}Selector384b.lean').write_text(s)
print(f'{dn} graph qualifiers',ds,ss,os,ps)
