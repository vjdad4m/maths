#!/usr/bin/env python3
"""Untrusted emitter: Lean checks every generated gate-clause proof and the exact LRAT formula."""
from pathlib import Path
import json, argparse
ap=argparse.ArgumentParser()
ap.add_argument('base',type=Path)
ap.add_argument('dir',type=Path)
ap.add_argument('--k',type=int,default=3)
a=ap.parse_args()
b=a.base; dest=a.dir
N=a.k
K=f'K{N}'
G=json.loads(b.with_suffix('.gates.json').read_text())
lines=b.with_name(b.name+'_slice').with_suffix('.cnf').read_text().splitlines()
C=[tuple(map(int,line.split()[:-1])) for line in lines[1:]]
V=f'DiversityElevenPendantWires{N}384b'
M=f'DiversityElevenPendantWireClauses{N}384b'
proofname={3:'pendant_three_rup',4:'pendant_four_rup',5:'pendant_five_rup',6:'pendant_six_rup'}[N]
proofmodule={3:'Three',4:'Four',5:'Five',6:'Six'}[N]
namespace=f'Graffiti384b.DiversityEleven.PendantCircuit.{K}'
def leanLit(x):return f'.{"pos" if x>0 else "neg"} {abs(x)-1}'
def clause(C): return '['+', '.join(map(leanLit,C))+']'
def gateId(i): return f'g{abs(i)}'
def bl(i,arg='E'):return ('' if i>0 else '!')+f'{gateId(i)} {arg}'
def evalterm(i,arg='E'):return f'({bl(i,arg)} = true)'
def negterm(i):return f'(¬ {evalterm(i)})' if i>0 else evalterm(-i)
def canon(row):
    return tuple(sorted(set(row)-{-1}))
gates={}
for k,ga in enumerate(G[1:],1):
    typ,*xs=ga
    if typ=='true':
        gates[(1,)]=k
    if typ=='and':
        for row in [(-k,x) for x in xs]+[(k,*map(int.__neg__,xs))]:
            gates[canon(row)]=k
    if typ=='xor':
        x,y=xs
        for row in [(x,y,-k),(-x,-y,-k),(x,-y,k),(-x,y,k)]:
            gates[canon(row)]=k
def tree(lo,hi):
    if hi==lo+1:return f'{gateId(lo)} E'
    mid=(lo+hi)//2
    return f'(if i < {mid-1} then {tree(lo,mid)} else {tree(mid,hi)})'
settings='set_option maxRecDepth 32768\nset_option maxHeartbeats 20000000\n'
with (dest/(V+'.lean')).open('w') as fp:
    def w(s):fp.write(s+'\n')
    w(f'import DiversityElevenCircuitBits384b\nnamespace {namespace}\nopen Sat\n{settings}')
    for k,ga in enumerate(G[1:],1):
        typ,*xs=ga
        if typ=='true':f='true'
        elif typ=='edge':f=f'E {k}'
        elif typ=='and':f=' && '.join(f'({bl(i)})' for i in xs)
        elif typ=='xor':f=f'({bl(xs[0])}) ^^ ({bl(xs[1])})'
        else:raise ValueError(ga)
        w(f'def g{k} ({"_E" if typ=="true" else "E"} : Nat → Bool) : Bool := {f}')
    w(f'def wire (E : Nat → Bool) (i : Nat) : Bool := {tree(1,len(G))}')
    w('def valuation (E : Nat → Bool) : Valuation := fun i => wire E i = true')
    w(f'end {namespace}')
roots=[]
with (dest/(M+'.lean')).open('w') as fp:
    def w(s):fp.write(s+'\n')
    w(f'import {V}\nimport DiversityElevenPendantRup{proofmodule}384b')
    w(f'namespace {namespace}\nopen Sat\n{settings}')
    patterns={}
    for k,row in enumerate(C):
        n=gates.get(row)
        if n is None:
            roots.append(k)
            continue
        typ,*children=G[n]
        letters=sorted(set(map(abs,children)))
        vmap={c:f'x{i}' for i,c in enumerate(letters)}
        def virt(s):
            return ('!' if s<0 else '')+vmap[abs(s)]
        if typ=='true': exp='true'
        else: exp=(' && ' if typ=='and' else ' ^^ ').join(f'({virt(s)})' for s in children)
        def virtarg(lit):
            x=abs(lit)
            exp0=f'({exp})' if x==n else vmap[x]
            return f'(¬ ({exp0}=true))' if lit>0 else f'({exp0}=true)'
        pattern=' → '.join([*(virtarg(x) for x in row),'False'])
        patKey=(pattern,len(letters))
        if patKey not in patterns:
            idx=len(patterns)
            patterns[patKey]=idx
            args=' '.join(vmap[c] for c in letters)
            b=f' ({args} : Bool)' if args else ''
            proof=' <;> '.join([*(f'cases {vmap[c]}' for c in letters),'decide'])
            w(f'private theorem pattern_{idx}{b} : {pattern} := by {proof}')
        w(f'private theorem sat_{k} (E : Nat → Bool) : (valuation E).satisfies {clause(row)} := by')
        goal=' → '.join([*(negterm(x) for x in row),'False'])
        w(f'  change {goal}')
        w(f'  exact pattern_{patterns[patKey]} '+' '.join(f'(g{c} E)' for c in letters))
    def proof(lo,hi):
        if hi==lo+1:
            if lo not in roots:return f'(fmla_one _ _ (sat_{lo} E))'
            return f'(fmla_one _ _ h_{lo})'
        m=(hi+lo)//2
        return f'(fmla_and _ _ _ {proof(lo,m)} {proof(m,hi)})'
    w('theorem contradiction_of_semantic_roots (E : Nat → Bool)')
    for k in roots:
        w(f'    (h_{k} : (valuation E).satisfies {clause(C[k])})')
    w('    : False := by')
    # Form the proof tree exactly like the Mathlib checker builds the balanced context.
    w(f'  exact {proofname} (valuation E) {proof(0,len(C))}')
    w('#print axioms contradiction_of_semantic_roots')
    w(f'end {namespace}')
print(f'{len(C)} formula rows: {len(C)-len(roots)} gate rows, {len(roots)} semantic roots')
