from pathlib import Path
import json, sys, tempfile
base=Path(sys.argv[1])
k=int(sys.argv[2])
src=Path(__file__).parent.parent/'q11-study/pendant_dp.py'
prefix='/tmp/graffiti384b-pendant-inspect'+str(k)
sys.argv=[str(src),prefix,str(k)]
s=src.read_text()
s=s.replace('def sort_bits(vec):','''tracks={}
meta={}
def semantic(kind,*args):
    meta[len(rows)]=(kind,*args)
def sort_bits(vec,group):''')
s=s.replace('''    for x in vec:
        s=[or_(s[k] if k<len(s) else -T,and_(x,T if k==0 else s[k-1])) for k in range(len(s)+1)]
    return s''','''    stage=[]
    for x in vec:
        out=[]
        steps=[]
        for j in range(len(s)+1):
            prev=s[j] if j<len(s) else -T
            below=T if j==0 else s[j-1]
            start=len(gates)
            both=and_(x,below)
            res=or_(prev,both)
            steps.append((res,x,prev,below,both,list(range(start,len(gates)))))
            out.append(res)
        stage.append(steps)
        s=out
    tracks[group]={'inputs':vec,'steps':stage,'threshold':s}
    return s''')
s=s.replace('for i in Q:req(sort_bits([edge(i,j) for j in Q if i!=j])[2])','''for i in Q:
    d=sort_bits([edge(i,j) for j in Q if i!=j],'degree'+str(i))[2]
    semantic('degree',i)
    req(d)''')
s=s.replace('S={i:sort_bits([v for q,v in C.items() if i in q]) for i in Z}','S={i:sort_bits([v for q,v in C.items() if i in q],\'score\'+str(i)) for i in Z}')
s=s.replace('for i in Z:req(S[i][1])','''for i in Z:
    semantic('score',i)
    req(S[i][1])''')
s=s.replace('    for k in range(len(S[i])):clause(-S[i][k],S[j][k+1] if k+1<len(S[j]) else -T)','''    for k in range(len(S[i])):
        semantic('ordering',i,j,k)
        clause(-S[i][k],S[j][k+1] if k+1<len(S[j]) else -T)''')
s=s.replace('    req(-lt(B,A))','''    start=len(gates)
    q=lt(B,A)
    semantic('port',i,j,A,B,list(range(start,len(gates))))
    req(-q)''')
s=s.replace('    hits=[]','    hits=[]\n    start=len(gates)')
s=s.replace('    clause(*(-v for v in hits))','''    semantic('cover',A,hits,list(range(start,len(gates))))
    clause(*(-v for v in hits))''')
ns={}
exec(s,ns)
for ext in ['.cnf','.gates.json']:
    assert base.with_suffix(ext).read_bytes()==Path(prefix).with_suffix(ext).read_bytes(),ext
res={'meta':ns['meta'],'tracks':ns['tracks'],'edges':[(i,j,v) for (i,j),v in ns['E'].items()], 'triangles':[(list(t),v) for t,v in ns['C'].items()]}
base.with_suffix('.semantics.json').write_text(json.dumps(res,separators=(',',':')))
print('Verified generator byte equality; wrote',base.with_suffix('.semantics.json'))
