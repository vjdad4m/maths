# Discovery-only CNF for the q11 pendant-selector residual min degree >=3.
from itertools import combinations
from pathlib import Path
import argparse, json
p=argparse.ArgumentParser(); p.add_argument('output');p.add_argument('k',type=int,choices=[3,4,5,6]); a=p.parse_args()
N=8; Q=list(range(N)); Z=list(range(a.k)); rows=[]; gates=[None]
def atom(kind,*arg):
    gates.append((kind,*arg));return len(gates)-1
def clause(*v):
    if 1 in v:return
    v=sorted(set(v)-{-1})
    if any(-x in v for x in v):return
    rows.append(tuple(v))
T=atom('true')
# Require unit before constant simplification.
rows.append((T,))
def and_(*v):
    if -T in v:return -T
    v=tuple(sorted(set(v)-{T}))
    if any(-x in v for x in v):return -T
    if not v:return T
    if len(v)==1:return v[0]
    q=atom('and',*v)
    for x in v:clause(-q,x)
    clause(q,*(-x for x in v))
    return q
def or_(*v):return -and_(*(-x for x in v))
def xor_(x,y):
    if x==y:return -T
    if x==-y:return T
    if x==T:return -y
    if y==T:return -x
    if x==-T:return y
    if y==-T:return x
    q=atom('xor',x,y)
    clause(x,y,-q);clause(-x,-y,-q)
    clause(x,-y,q);clause(-x,y,q)
    return q
def pop(xs,w=5):
    s=[-T]*w
    for x in xs:
        c=x
        for i in range(w):
            j=xor_(s[i],c)
            c=and_(s[i],c)
            s[i]=j
    return s
def bits(n,w):return [T if n>>i&1 else -T for i in range(w)]
def lt(A,B):
    s=-T
    for x,y in zip(A,B): s=or_(and_(-x,y),and_(-xor_(x,y),s))
    return s
def sort_bits(vec):
    # Exact threshold recurrence, easier to formalize than a sorting network.
    s=[]
    for x in vec:
        s=[or_(s[k] if k<len(s) else -T,and_(x,T if k==0 else s[k-1])) for k in range(len(s)+1)]
    return s
def req(x):clause(x)
E={e:atom('edge',*e) for e in combinations(Q,2)}
def edge(i,j):return E[tuple(sorted((i,j)))]
for i in Q:req(sort_bits([edge(i,j) for j in Q if i!=j])[2])
C={q:and_(*(E[e] for e in combinations(q,2))) for q in combinations(Q,3)}
S={i:sort_bits([v for q,v in C.items() if i in q]) for i in Z}
for i in Z:req(S[i][1])
for i,j in zip(Z,Z[1:]):
    for k in range(len(S[i])):clause(-S[i][k],S[j][k+1] if k+1<len(S[j]) else -T)
for i in range(a.k,N-1):
    j=i+1; A=[edge(1,i),edge(0,i)];B=[edge(1,j),edge(0,j)]
    req(-lt(B,A))
for A in combinations(Q,3):
    hits=[]
    for v in Q:
        if v in A:continue
        x,y,z=[edge(v,u) for u in A]
        hits.append(or_(and_(x,y),and_(x,z),and_(y,z)) if v in Z else or_(x,y,z))
    clause(*(-v for v in hits))
out=Path(a.output)
out.with_suffix('.cnf').write_text(f'p cnf {len(gates)-1} {len(rows)}\n'+''.join(' '.join(map(str,c))+' 0\n' for c in rows))
out.with_suffix('.gates.json').write_text(json.dumps(gates,separators=(',',':')))
print({'variables':len(gates)-1,'clauses':len(rows),'zeroTags':a.k})
