"""Trim a positive-RUP LRAT DAG, audit each propagation, and write renumbered files.

This is a Python diagnostic, not Lean checking.
"""
from pathlib import Path
import argparse
p=argparse.ArgumentParser()
p.add_argument('prefix',type=Path)
a=p.parse_args()
base=a.prefix
cnf=base.with_suffix('.cnf')
lrat=base.with_suffix('.lrat')
with cnf.open() as f:
    p,kind,natom,ninput=next(f).split()
    assert p=='p' and kind=='cnf'
    inputs=[tuple(map(int,L.split()[:-1])) for L in f]
    assert len(inputs)==int(ninput)
trace={}
empty=None
for line in lrat.open():
    s=line.split()
    if not s or s[0]=='c' or s[1]=='d':continue
    ns=list(map(int,s));k=ns.index(0)
    trace[ns[0]]=(tuple(ns[1:k]),tuple(ns[k+1:-1]))
    if k==1:empty=ns[0]
assert empty is not None
used=set()
leaves=set()
todo=[empty]
while todo:
    i=todo.pop()
    if i in used or i in leaves:continue
    if i not in trace:
        assert 1<=i<=len(inputs)
        leaves.add(i)
        continue
    used.add(i)
    _,hs=trace[i]
    assert all(0<j<i for j in hs)
    todo.extend(hs)
ren={old:i for i,old in enumerate(sorted(leaves)+sorted(used),1)}
db={i:inputs[i-1] for i in leaves}
for i in sorted(used):
    clause,hints=trace[i]
    value={}
    conflict=False
    for q in clause:
        f=q<0
        bit=abs(q)
        if bit in value and value[bit]!=f:conflict=True;break
        value[bit]=f
    if not conflict:
        for j in hints:
            assert j in db,(i,j)
            c=db[j]
            assert not any(value.get(abs(q))== (q>0) for q in c),(i,j,'already true')
            u=[q for q in c if abs(q) not in value]
            if not u:conflict=True;break
            assert len(u)==1,(i,j,'not unit',u)
            q=u[0]
            value[abs(q)]=q>0
    assert conflict,(i,'no conflict')
    db[i]=clause
assert db[empty]==()
def row(C): return ' '.join(map(str,C))+' 0\n'
mk=lambda ext:base.with_name(base.name+'_slice').with_suffix(ext)
mk('.cnf').write_text(f'p cnf {natom} {len(leaves)}\n'+''.join(row(db[i]) for i in sorted(leaves)))
mk('.lrat').write_text(''.join(row((ren[i],)+db[i]).rstrip()+' '+row([ren[j] for j in trace[i][1]]) for i in sorted(used)))
mk('.roots').write_text(''.join(f'{j}\n' for j in sorted(leaves)))
print(base.name,{'rup_steps':len(used),'initial_clauses':len(leaves),'audit':'all verified by Python'})
