import DiversityElevenPendantSemanticRoots4384b
import EffectiveSearchScore384b

namespace Graffiti384b.DiversityEleven.PendantCircuit.K4
open Finset SimpleGraph
set_option maxRecDepth 32768
set_option maxHeartbeats 6000000

private def edges : List (Fin 8 × Fin 8) := EffectiveSearch.orderedPairs 8
private def verts : List (Fin 8) := [0,1,2,3,4,5,6,7]
private theorem verts_nodup : verts.Nodup := by decide
private theorem verts_mem : ∀ i : Fin 8, i∈verts := by decide

/-- Assign every edge atom its exact graph adjacency. -/
def graphWires (G : SimpleGraph (Fin 8)) [DecidableRel G.Adj] (k : Nat) : Bool :=
  ((edges.map fun (i,j) => decide (G.Adj i j)).getD (k-2) false)

theorem edge_graphWires (G : SimpleGraph (Fin 8)) [DecidableRel G.Adj] (i j : Fin 8) :
    edge (graphWires G) i j=true ↔ G.Adj i j := by
  fin_cases i <;> fin_cases j
  all_goals first
    | rfl
    | exact ⟨fun _ => by contradiction,fun h => (G.loopless _ h).elim⟩
    | exact decide_eq_true_iff
    | exact decide_eq_true_iff.trans (G.adj_comm _ _)

theorem countTrue_map {A : Type*} (f : A → Bool) (l : List A) :
    countTrue (l.map f)=(l.filter f).length := by
  induction l with
  | nil => rfl
  | cons a l ih =>
    cases e : f a <;> simp [countTrue,e,ih,List.filter_cons]

private theorem degree_count (G : SimpleGraph (Fin 8)) [DecidableRel G.Adj] (i : Fin 8) :
    countTrue (((verts.erase i).reverse).map (edge (graphWires G) i))=G.degree i := by
  rw [countTrue_map,List.filter_reverse,List.length_reverse]
  let L := (verts.erase i).filter (edge (graphWires G) i)
  have e : L.toFinset=G.neighborFinset i := by
    ext j
    simp only [L,List.mem_toFinset,List.mem_filter,edge_graphWires,G.mem_neighborFinset]
    exact ⟨And.right,fun adj => ⟨(List.mem_erase_of_ne adj.ne.symm).mpr (verts_mem j),adj⟩⟩
  change L.length = G.degree i
  rw [←List.toFinset_card_of_nodup ((verts_nodup.erase i).filter _),e,G.card_neighborFinset_eq_degree]

private theorem tri_count (G : SimpleGraph (Fin 8)) [DecidableRel G.Adj] (i : Fin 8) :
    countTrue (((edges.filter fun x => decide (x.1≠i ∧ x.2≠i)).reverse).map
      (fun (x,y) => edge (graphWires G) i x && edge (graphWires G) i y &&
        edge (graphWires G) x y))=trianglesAt G i := by
  rw [countTrue_map,List.filter_reverse,List.length_reverse,List.filter_filter]
  let E := edge (graphWires G)
  have keep : (edges.filter fun (x,y) => E i x && E i y && E x y &&
      decide (x≠i ∧ y≠i))=(edges.filter fun (x,y) => E i x && E i y && E x y) := by
    apply List.filter_congr
    intro w _
    obtain ⟨x,y⟩ := w
    apply Bool.eq_iff_iff.mpr
    simp only [Bool.and_eq_true,decide_eq_true_eq]
    exact ⟨And.left,fun h => ⟨h,(edge_graphWires G i x |>.mp h.1.1).ne.symm,
      (edge_graphWires G i y |>.mp h.1.2).ne.symm⟩⟩
  rw [keep]
  exact EffectiveSearch.score_eq_triangles G (Equiv.refl _) E
    (by decide) (by decide) (edge_graphWires G) i

theorem degree0_graphWires (G : SimpleGraph (Fin 8)) [DecidableRel G.Adj] :
    degree0_count (graphWires G) = G.degree 0 := by
  exact degree_count G 0

theorem degree1_graphWires (G : SimpleGraph (Fin 8)) [DecidableRel G.Adj] :
    degree1_count (graphWires G) = G.degree 1 := by
  exact degree_count G 1

theorem degree2_graphWires (G : SimpleGraph (Fin 8)) [DecidableRel G.Adj] :
    degree2_count (graphWires G) = G.degree 2 := by
  exact degree_count G 2

theorem degree3_graphWires (G : SimpleGraph (Fin 8)) [DecidableRel G.Adj] :
    degree3_count (graphWires G) = G.degree 3 := by
  exact degree_count G 3

theorem degree4_graphWires (G : SimpleGraph (Fin 8)) [DecidableRel G.Adj] :
    degree4_count (graphWires G) = G.degree 4 := by
  exact degree_count G 4

theorem degree5_graphWires (G : SimpleGraph (Fin 8)) [DecidableRel G.Adj] :
    degree5_count (graphWires G) = G.degree 5 := by
  exact degree_count G 5

theorem degree6_graphWires (G : SimpleGraph (Fin 8)) [DecidableRel G.Adj] :
    degree6_count (graphWires G) = G.degree 6 := by
  exact degree_count G 6

theorem degree7_graphWires (G : SimpleGraph (Fin 8)) [DecidableRel G.Adj] :
    degree7_count (graphWires G) = G.degree 7 := by
  exact degree_count G 7

theorem score0_graphWires (G : SimpleGraph (Fin 8)) [DecidableRel G.Adj] :
    score0_count (graphWires G) = trianglesAt G 0 := by
  change countTrue [g386 (graphWires G), g385 (graphWires G), g384 (graphWires G), g383 (graphWires G), g382 (graphWires G), g381 (graphWires G), g380 (graphWires G), g379 (graphWires G), g378 (graphWires G), g377 (graphWires G), g376 (graphWires G), g375 (graphWires G), g374 (graphWires G), g373 (graphWires G), g372 (graphWires G), g371 (graphWires G), g370 (graphWires G), g369 (graphWires G), g368 (graphWires G), g367 (graphWires G), g366 (graphWires G)] = _
  calc
    _ = countTrue [(g7 (graphWires G)) && (g8 (graphWires G)) && (g29 (graphWires G)), (g6 (graphWires G)) && (g8 (graphWires G)) && (g28 (graphWires G)), (g6 (graphWires G)) && (g7 (graphWires G)) && (g27 (graphWires G)), (g5 (graphWires G)) && (g8 (graphWires G)) && (g26 (graphWires G)), (g5 (graphWires G)) && (g7 (graphWires G)) && (g25 (graphWires G)), (g5 (graphWires G)) && (g6 (graphWires G)) && (g24 (graphWires G)), (g4 (graphWires G)) && (g8 (graphWires G)) && (g23 (graphWires G)), (g4 (graphWires G)) && (g7 (graphWires G)) && (g22 (graphWires G)), (g4 (graphWires G)) && (g6 (graphWires G)) && (g21 (graphWires G)), (g4 (graphWires G)) && (g5 (graphWires G)) && (g20 (graphWires G)), (g3 (graphWires G)) && (g8 (graphWires G)) && (g19 (graphWires G)), (g3 (graphWires G)) && (g7 (graphWires G)) && (g18 (graphWires G)), (g3 (graphWires G)) && (g6 (graphWires G)) && (g17 (graphWires G)), (g3 (graphWires G)) && (g5 (graphWires G)) && (g16 (graphWires G)), (g3 (graphWires G)) && (g4 (graphWires G)) && (g15 (graphWires G)), (g2 (graphWires G)) && (g8 (graphWires G)) && (g14 (graphWires G)), (g2 (graphWires G)) && (g7 (graphWires G)) && (g13 (graphWires G)), (g2 (graphWires G)) && (g6 (graphWires G)) && (g12 (graphWires G)), (g2 (graphWires G)) && (g5 (graphWires G)) && (g11 (graphWires G)), (g2 (graphWires G)) && (g4 (graphWires G)) && (g10 (graphWires G)), (g2 (graphWires G)) && (g3 (graphWires G)) && (g9 (graphWires G))] := by
      simp only [g366, g367, g368, g369, g370, g371, g372, g373, g374, g375, g376, g377, g378, g379, g380, g381, g382, g383, g384, g385, g386, Bool.and_comm,Bool.and_left_comm,Bool.and_assoc]
    _ = _ := tri_count G 0

theorem score1_graphWires (G : SimpleGraph (Fin 8)) [DecidableRel G.Adj] :
    score1_count (graphWires G) = trianglesAt G 1 := by
  change countTrue [g401 (graphWires G), g400 (graphWires G), g399 (graphWires G), g398 (graphWires G), g397 (graphWires G), g396 (graphWires G), g395 (graphWires G), g394 (graphWires G), g393 (graphWires G), g392 (graphWires G), g391 (graphWires G), g390 (graphWires G), g389 (graphWires G), g388 (graphWires G), g387 (graphWires G), g371 (graphWires G), g370 (graphWires G), g369 (graphWires G), g368 (graphWires G), g367 (graphWires G), g366 (graphWires G)] = _
  calc
    _ = countTrue [(g13 (graphWires G)) && (g14 (graphWires G)) && (g29 (graphWires G)), (g12 (graphWires G)) && (g14 (graphWires G)) && (g28 (graphWires G)), (g12 (graphWires G)) && (g13 (graphWires G)) && (g27 (graphWires G)), (g11 (graphWires G)) && (g14 (graphWires G)) && (g26 (graphWires G)), (g11 (graphWires G)) && (g13 (graphWires G)) && (g25 (graphWires G)), (g11 (graphWires G)) && (g12 (graphWires G)) && (g24 (graphWires G)), (g10 (graphWires G)) && (g14 (graphWires G)) && (g23 (graphWires G)), (g10 (graphWires G)) && (g13 (graphWires G)) && (g22 (graphWires G)), (g10 (graphWires G)) && (g12 (graphWires G)) && (g21 (graphWires G)), (g10 (graphWires G)) && (g11 (graphWires G)) && (g20 (graphWires G)), (g9 (graphWires G)) && (g14 (graphWires G)) && (g19 (graphWires G)), (g9 (graphWires G)) && (g13 (graphWires G)) && (g18 (graphWires G)), (g9 (graphWires G)) && (g12 (graphWires G)) && (g17 (graphWires G)), (g9 (graphWires G)) && (g11 (graphWires G)) && (g16 (graphWires G)), (g9 (graphWires G)) && (g10 (graphWires G)) && (g15 (graphWires G)), (g2 (graphWires G)) && (g14 (graphWires G)) && (g8 (graphWires G)), (g2 (graphWires G)) && (g13 (graphWires G)) && (g7 (graphWires G)), (g2 (graphWires G)) && (g12 (graphWires G)) && (g6 (graphWires G)), (g2 (graphWires G)) && (g11 (graphWires G)) && (g5 (graphWires G)), (g2 (graphWires G)) && (g10 (graphWires G)) && (g4 (graphWires G)), (g2 (graphWires G)) && (g9 (graphWires G)) && (g3 (graphWires G))] := by
      simp only [g366, g367, g368, g369, g370, g371, g387, g388, g389, g390, g391, g392, g393, g394, g395, g396, g397, g398, g399, g400, g401, Bool.and_comm,Bool.and_left_comm,Bool.and_assoc]
    _ = _ := tri_count G 1

theorem score2_graphWires (G : SimpleGraph (Fin 8)) [DecidableRel G.Adj] :
    score2_count (graphWires G) = trianglesAt G 2 := by
  change countTrue [g411 (graphWires G), g410 (graphWires G), g409 (graphWires G), g408 (graphWires G), g407 (graphWires G), g406 (graphWires G), g405 (graphWires G), g404 (graphWires G), g403 (graphWires G), g402 (graphWires G), g391 (graphWires G), g390 (graphWires G), g389 (graphWires G), g388 (graphWires G), g387 (graphWires G), g376 (graphWires G), g375 (graphWires G), g374 (graphWires G), g373 (graphWires G), g372 (graphWires G), g366 (graphWires G)] = _
  calc
    _ = countTrue [(g18 (graphWires G)) && (g19 (graphWires G)) && (g29 (graphWires G)), (g17 (graphWires G)) && (g19 (graphWires G)) && (g28 (graphWires G)), (g17 (graphWires G)) && (g18 (graphWires G)) && (g27 (graphWires G)), (g16 (graphWires G)) && (g19 (graphWires G)) && (g26 (graphWires G)), (g16 (graphWires G)) && (g18 (graphWires G)) && (g25 (graphWires G)), (g16 (graphWires G)) && (g17 (graphWires G)) && (g24 (graphWires G)), (g15 (graphWires G)) && (g19 (graphWires G)) && (g23 (graphWires G)), (g15 (graphWires G)) && (g18 (graphWires G)) && (g22 (graphWires G)), (g15 (graphWires G)) && (g17 (graphWires G)) && (g21 (graphWires G)), (g15 (graphWires G)) && (g16 (graphWires G)) && (g20 (graphWires G)), (g9 (graphWires G)) && (g19 (graphWires G)) && (g14 (graphWires G)), (g9 (graphWires G)) && (g18 (graphWires G)) && (g13 (graphWires G)), (g9 (graphWires G)) && (g17 (graphWires G)) && (g12 (graphWires G)), (g9 (graphWires G)) && (g16 (graphWires G)) && (g11 (graphWires G)), (g9 (graphWires G)) && (g15 (graphWires G)) && (g10 (graphWires G)), (g3 (graphWires G)) && (g19 (graphWires G)) && (g8 (graphWires G)), (g3 (graphWires G)) && (g18 (graphWires G)) && (g7 (graphWires G)), (g3 (graphWires G)) && (g17 (graphWires G)) && (g6 (graphWires G)), (g3 (graphWires G)) && (g16 (graphWires G)) && (g5 (graphWires G)), (g3 (graphWires G)) && (g15 (graphWires G)) && (g4 (graphWires G)), (g3 (graphWires G)) && (g9 (graphWires G)) && (g2 (graphWires G))] := by
      simp only [g366, g372, g373, g374, g375, g376, g387, g388, g389, g390, g391, g402, g403, g404, g405, g406, g407, g408, g409, g410, g411, Bool.and_comm,Bool.and_left_comm,Bool.and_assoc]
    _ = _ := tri_count G 2

theorem score3_graphWires (G : SimpleGraph (Fin 8)) [DecidableRel G.Adj] :
    score3_count (graphWires G) = trianglesAt G 3 := by
  change countTrue [g417 (graphWires G), g416 (graphWires G), g415 (graphWires G), g414 (graphWires G), g413 (graphWires G), g412 (graphWires G), g405 (graphWires G), g404 (graphWires G), g403 (graphWires G), g402 (graphWires G), g395 (graphWires G), g394 (graphWires G), g393 (graphWires G), g392 (graphWires G), g387 (graphWires G), g380 (graphWires G), g379 (graphWires G), g378 (graphWires G), g377 (graphWires G), g372 (graphWires G), g367 (graphWires G)] = _
  calc
    _ = countTrue [(g22 (graphWires G)) && (g23 (graphWires G)) && (g29 (graphWires G)), (g21 (graphWires G)) && (g23 (graphWires G)) && (g28 (graphWires G)), (g21 (graphWires G)) && (g22 (graphWires G)) && (g27 (graphWires G)), (g20 (graphWires G)) && (g23 (graphWires G)) && (g26 (graphWires G)), (g20 (graphWires G)) && (g22 (graphWires G)) && (g25 (graphWires G)), (g20 (graphWires G)) && (g21 (graphWires G)) && (g24 (graphWires G)), (g15 (graphWires G)) && (g23 (graphWires G)) && (g19 (graphWires G)), (g15 (graphWires G)) && (g22 (graphWires G)) && (g18 (graphWires G)), (g15 (graphWires G)) && (g21 (graphWires G)) && (g17 (graphWires G)), (g15 (graphWires G)) && (g20 (graphWires G)) && (g16 (graphWires G)), (g10 (graphWires G)) && (g23 (graphWires G)) && (g14 (graphWires G)), (g10 (graphWires G)) && (g22 (graphWires G)) && (g13 (graphWires G)), (g10 (graphWires G)) && (g21 (graphWires G)) && (g12 (graphWires G)), (g10 (graphWires G)) && (g20 (graphWires G)) && (g11 (graphWires G)), (g10 (graphWires G)) && (g15 (graphWires G)) && (g9 (graphWires G)), (g4 (graphWires G)) && (g23 (graphWires G)) && (g8 (graphWires G)), (g4 (graphWires G)) && (g22 (graphWires G)) && (g7 (graphWires G)), (g4 (graphWires G)) && (g21 (graphWires G)) && (g6 (graphWires G)), (g4 (graphWires G)) && (g20 (graphWires G)) && (g5 (graphWires G)), (g4 (graphWires G)) && (g15 (graphWires G)) && (g3 (graphWires G)), (g4 (graphWires G)) && (g10 (graphWires G)) && (g2 (graphWires G))] := by
      simp only [g367, g372, g377, g378, g379, g380, g387, g392, g393, g394, g395, g402, g403, g404, g405, g412, g413, g414, g415, g416, g417, Bool.and_comm,Bool.and_left_comm,Bool.and_assoc]
    _ = _ := tri_count G 3

end Graffiti384b.DiversityEleven.PendantCircuit.K4
