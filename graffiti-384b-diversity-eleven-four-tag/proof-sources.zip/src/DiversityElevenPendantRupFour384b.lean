import DiversityElevenMathlibRup384b

namespace Graffiti384b.DiversityEleven
set_option maxRecDepth 32768
set_option maxHeartbeats 100000000

packed_rup pendant_four_rup
  (include_str "../q11-study/dp4_slice.cnf")
  (include_str "../q11-study/dp4_slice.lrat")

#print axioms pendant_four_rup
end Graffiti384b.DiversityEleven
