import DiversityElevenPendantThresholds4384b
import DiversityElevenPendantWireClauses4384b
import Mathlib.Data.Finset.Card
import Mathlib.Tactic.FinCases
namespace Graffiti384b.DiversityEleven.PendantCircuit.K4
open Sat Finset
set_option maxRecDepth 32768
set_option maxHeartbeats 15000000
def edgeNumber (i j : Fin 8) : Nat :=
  let a := min i.val j.val
  let b := max i.val j.val
  2 + (a*(15-a))/2 + (b-a-1)
def edge (E : Nat→Bool) (i j : Fin 8) : Bool := if i=j then false else E (edgeNumber i j)
def portRank (E : Nat→Bool) (i : Fin 8) : Nat :=
  (if edge E 1 i then 1 else 0)+(if edge E 0 i then 2 else 0)
private theorem negWire (b : Bool) : ((!b)=true) ↔ ¬b=true := by cases b <;> decide
def HasTriple (E : Nat→Bool) : Prop :=
  ∃ a b c : Fin 8, a<b ∧ b<c ∧ ∀ v : Fin 8, v≠a → v≠b → v≠c →
    (if v.val < 4 then 2 else 1)≤countTrue [edge E v a,edge E v b,edge E v c]
private theorem root_28 (E : Nat→Bool) (h : 3≤degree0_count E) : (valuation E).satisfies [.neg 63] := by
  change ((g64 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree0_threshold7_2 E).mpr h) hn
private theorem root_73 (E : Nat→Bool) (h : 3≤degree1_count E) : (valuation E).satisfies [.neg 105] := by
  change ((g106 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree1_threshold7_2 E).mpr h) hn
private theorem root_104 (E : Nat→Bool) (h : 3≤degree2_count E) : (valuation E).satisfies [.neg 147] := by
  change ((g148 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree2_threshold7_2 E).mpr h) hn
private theorem root_131 (E : Nat→Bool) (h : 3≤degree3_count E) : (valuation E).satisfies [.neg 189] := by
  change ((g190 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree3_threshold7_2 E).mpr h) hn
private theorem root_169 (E : Nat→Bool) (h : 3≤degree4_count E) : (valuation E).satisfies [.neg 231] := by
  change ((g232 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree4_threshold7_2 E).mpr h) hn
private theorem root_201 (E : Nat→Bool) (h : 3≤degree5_count E) : (valuation E).satisfies [.neg 273] := by
  change ((g274 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree5_threshold7_2 E).mpr h) hn
private theorem root_233 (E : Nat→Bool) (h : 3≤degree6_count E) : (valuation E).satisfies [.neg 315] := by
  change ((g316 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree6_threshold7_2 E).mpr h) hn
private theorem root_254 (E : Nat→Bool) (h : 3≤degree7_count E) : (valuation E).satisfies [.neg 357] := by
  change ((g358 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree7_threshold7_2 E).mpr h) hn
private theorem root_1484 (E : Nat→Bool) (h : 2≤score0_count E) : (valuation E).satisfies [.neg 803] := by
  change ((g804 E)=true) → False
  intro hn
  exact (negWire _).mp ((score0_threshold21_1 E).mpr h) hn
private theorem root_1485 (E : Nat→Bool) (h : score0_count E<score1_count E) : (valuation E).satisfies [.neg 1225, .pos 803] := by
  change ((g1226 E)=true) → (¬ ((g804 E)=true)) → False
  intro fail old
  have oldScore := (score0_threshold21_1 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 1 h oldScore
  exact (negWire _).mp ((score1_threshold21_2 E).mpr newScore) fail
private theorem root_1486 (E : Nat→Bool) (h : score0_count E<score1_count E) : (valuation E).satisfies [.neg 1227, .pos 805] := by
  change ((g1228 E)=true) → (¬ ((g806 E)=true)) → False
  intro fail old
  have oldScore := (score0_threshold21_2 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 2 h oldScore
  exact (negWire _).mp ((score1_threshold21_3 E).mpr newScore) fail
private theorem root_1487 (E : Nat→Bool) (h : score0_count E<score1_count E) : (valuation E).satisfies [.neg 1229, .pos 807] := by
  change ((g1230 E)=true) → (¬ ((g808 E)=true)) → False
  intro fail old
  have oldScore := (score0_threshold21_3 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 3 h oldScore
  exact (negWire _).mp ((score1_threshold21_4 E).mpr newScore) fail
private theorem root_1488 (E : Nat→Bool) (h : score0_count E<score1_count E) : (valuation E).satisfies [.neg 1231, .pos 809] := by
  change ((g1232 E)=true) → (¬ ((g810 E)=true)) → False
  intro fail old
  have oldScore := (score0_threshold21_4 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 4 h oldScore
  exact (negWire _).mp ((score1_threshold21_5 E).mpr newScore) fail
private theorem root_1489 (E : Nat→Bool) (h : score1_count E<score2_count E) : (valuation E).satisfies [.neg 1647, .pos 1225] := by
  change ((g1648 E)=true) → (¬ ((g1226 E)=true)) → False
  intro fail old
  have oldScore := (score1_threshold21_2 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 2 h oldScore
  exact (negWire _).mp ((score2_threshold21_3 E).mpr newScore) fail
private theorem root_1490 (E : Nat→Bool) (h : score1_count E<score2_count E) : (valuation E).satisfies [.neg 1649, .pos 1227] := by
  change ((g1650 E)=true) → (¬ ((g1228 E)=true)) → False
  intro fail old
  have oldScore := (score1_threshold21_3 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 3 h oldScore
  exact (negWire _).mp ((score2_threshold21_4 E).mpr newScore) fail
private theorem root_1491 (E : Nat→Bool) (h : score1_count E<score2_count E) : (valuation E).satisfies [.neg 1651, .pos 1229] := by
  change ((g1652 E)=true) → (¬ ((g1230 E)=true)) → False
  intro fail old
  have oldScore := (score1_threshold21_4 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 4 h oldScore
  exact (negWire _).mp ((score2_threshold21_5 E).mpr newScore) fail
private theorem root_1492 (E : Nat→Bool) (h : score1_count E<score2_count E) : (valuation E).satisfies [.neg 1653, .pos 1231] := by
  change ((g1654 E)=true) → (¬ ((g1232 E)=true)) → False
  intro fail old
  have oldScore := (score1_threshold21_5 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 5 h oldScore
  exact (negWire _).mp ((score2_threshold21_6 E).mpr newScore) fail
private theorem root_1493 (E : Nat→Bool) (h : score2_count E<score3_count E) : (valuation E).satisfies [.neg 2069, .pos 1647] := by
  change ((g2070 E)=true) → (¬ ((g1648 E)=true)) → False
  intro fail old
  have oldScore := (score2_threshold21_3 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 3 h oldScore
  exact (negWire _).mp ((score3_threshold21_4 E).mpr newScore) fail
private theorem root_1494 (E : Nat→Bool) (h : score2_count E<score3_count E) : (valuation E).satisfies [.neg 2071, .pos 1649] := by
  change ((g2072 E)=true) → (¬ ((g1650 E)=true)) → False
  intro fail old
  have oldScore := (score2_threshold21_4 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 4 h oldScore
  exact (negWire _).mp ((score3_threshold21_5 E).mpr newScore) fail
private theorem root_1495 (E : Nat→Bool) (h : score2_count E<score3_count E) : (valuation E).satisfies [.neg 2073, .pos 1651] := by
  change ((g2074 E)=true) → (¬ ((g1652 E)=true)) → False
  intro fail old
  have oldScore := (score2_threshold21_5 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 5 h oldScore
  exact (negWire _).mp ((score3_threshold21_6 E).mpr newScore) fail
private theorem root_1496 (E : Nat→Bool) (h : score2_count E<score3_count E) : (valuation E).satisfies [.neg 2075, .pos 1653] := by
  change ((g2076 E)=true) → (¬ ((g1654 E)=true)) → False
  intro fail old
  have oldScore := (score2_threshold21_6 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 6 h oldScore
  exact (negWire _).mp ((score3_threshold21_7 E).mpr newScore) fail
private theorem root_1505 (E : Nat→Bool) (h : portRank E 4≤portRank E 5) : (valuation E).satisfies [.pos 2106] := by
  change (¬ ((g2107 E)=true)) → False
  intro contrary
  change (if (g11 E) then 1 else 0) + (if (g5 E) then 2 else 0) ≤ (if (g12 E) then 1 else 0) + (if (g6 E) then 2 else 0) at h
  cases q11 : g11 E <;> cases q5 : g5 E <;> cases q12 : g12 E <;> cases q6 : g6 E <;> simp [g2102,g2103,g2104,g2105,g2106,g2107,q11,q5,q12,q6] at h contrary
private theorem root_1515 (E : Nat→Bool) (h : portRank E 5≤portRank E 6) : (valuation E).satisfies [.pos 2112] := by
  change (¬ ((g2113 E)=true)) → False
  intro contrary
  change (if (g12 E) then 1 else 0) + (if (g6 E) then 2 else 0) ≤ (if (g13 E) then 1 else 0) + (if (g7 E) then 2 else 0) at h
  cases q12 : g12 E <;> cases q6 : g6 E <;> cases q13 : g13 E <;> cases q7 : g7 E <;> simp [g2108,g2109,g2110,g2111,g2112,g2113,q12,q6,q13,q7] at h contrary
private theorem root_1525 (E : Nat→Bool) (h : portRank E 6≤portRank E 7) : (valuation E).satisfies [.pos 2118] := by
  change (¬ ((g2119 E)=true)) → False
  intro contrary
  change (if (g13 E) then 1 else 0) + (if (g7 E) then 2 else 0) ≤ (if (g14 E) then 1 else 0) + (if (g8 E) then 2 else 0) at h
  cases q13 : g13 E <;> cases q7 : g7 E <;> cases q14 : g14 E <;> cases q8 : g8 E <;> simp [g2114,g2115,g2116,g2117,g2118,g2119,q13,q7,q14,q8] at h contrary
private theorem root_1553 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2122, .pos 2123, .pos 2124, .pos 2125, .pos 2126] := by
  change (¬ ((g2123 E)=true)) → (¬ ((g2124 E)=true)) → (¬ ((g2125 E)=true)) → (¬ ((g2126 E)=true)) → (¬ ((g2127 E)=true)) → False
  intro c3 c4 c5 c6 c7
  apply h
  refine ⟨0,1,2,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 2≤countTrue [edge E 3 0, edge E 3 1, edge E 3 2]
    apply (mask_ge_two (edge E 3 0) (edge E 3 1) (edge E 3 2)).mp
    change (((g4 E) && (g10 E)) || ((g4 E) && (g15 E)) || ((g10 E) && (g15 E)))=true
    simpa [g2120, g2121, g2122, g2123, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 0, edge E 4 1, edge E 4 2]
    apply (mask_ge_one (edge E 4 0) (edge E 4 1) (edge E 4 2)).mp
    change ((g5 E) || (g11 E) || (g16 E))=true
    simpa [g2124, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 1, edge E 5 2]
    apply (mask_ge_one (edge E 5 0) (edge E 5 1) (edge E 5 2)).mp
    change ((g6 E) || (g12 E) || (g17 E))=true
    simpa [g2125, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 1, edge E 6 2]
    apply (mask_ge_one (edge E 6 0) (edge E 6 1) (edge E 6 2)).mp
    change ((g7 E) || (g13 E) || (g18 E))=true
    simpa [g2126, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 1, edge E 7 2]
    apply (mask_ge_one (edge E 7 0) (edge E 7 1) (edge E 7 2)).mp
    change ((g8 E) || (g14 E) || (g19 E))=true
    simpa [g2127, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1575 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2130, .pos 2131, .pos 2132, .pos 2133, .pos 2134] := by
  change (¬ ((g2131 E)=true)) → (¬ ((g2132 E)=true)) → (¬ ((g2133 E)=true)) → (¬ ((g2134 E)=true)) → (¬ ((g2135 E)=true)) → False
  intro c2 c4 c5 c6 c7
  apply h
  refine ⟨0,1,3,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 2 0, edge E 2 1, edge E 2 3]
    apply (mask_ge_two (edge E 2 0) (edge E 2 1) (edge E 2 3)).mp
    change (((g3 E) && (g9 E)) || ((g3 E) && (g15 E)) || ((g9 E) && (g15 E)))=true
    simpa [g2128, g2129, g2130, g2131, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 4 0, edge E 4 1, edge E 4 3]
    apply (mask_ge_one (edge E 4 0) (edge E 4 1) (edge E 4 3)).mp
    change ((g5 E) || (g11 E) || (g20 E))=true
    simpa [g2132, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 1, edge E 5 3]
    apply (mask_ge_one (edge E 5 0) (edge E 5 1) (edge E 5 3)).mp
    change ((g6 E) || (g12 E) || (g21 E))=true
    simpa [g2133, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 1, edge E 6 3]
    apply (mask_ge_one (edge E 6 0) (edge E 6 1) (edge E 6 3)).mp
    change ((g7 E) || (g13 E) || (g22 E))=true
    simpa [g2134, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 1, edge E 7 3]
    apply (mask_ge_one (edge E 7 0) (edge E 7 1) (edge E 7 3)).mp
    change ((g8 E) || (g14 E) || (g23 E))=true
    simpa [g2135, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1600 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2138, .pos 2142, .pos 2143, .pos 2144, .pos 2145] := by
  change (¬ ((g2139 E)=true)) → (¬ ((g2143 E)=true)) → (¬ ((g2144 E)=true)) → (¬ ((g2145 E)=true)) → (¬ ((g2146 E)=true)) → False
  intro c2 c3 c5 c6 c7
  apply h
  refine ⟨0,1,4,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 2 0, edge E 2 1, edge E 2 4]
    apply (mask_ge_two (edge E 2 0) (edge E 2 1) (edge E 2 4)).mp
    change (((g3 E) && (g9 E)) || ((g3 E) && (g16 E)) || ((g9 E) && (g16 E)))=true
    simpa [g2136, g2137, g2138, g2139, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 1, edge E 3 4]
    apply (mask_ge_two (edge E 3 0) (edge E 3 1) (edge E 3 4)).mp
    change (((g4 E) && (g10 E)) || ((g4 E) && (g20 E)) || ((g10 E) && (g20 E)))=true
    simpa [g2140, g2141, g2142, g2143, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 5 0, edge E 5 1, edge E 5 4]
    apply (mask_ge_one (edge E 5 0) (edge E 5 1) (edge E 5 4)).mp
    change ((g6 E) || (g12 E) || (g24 E))=true
    simpa [g2144, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 1, edge E 6 4]
    apply (mask_ge_one (edge E 6 0) (edge E 6 1) (edge E 6 4)).mp
    change ((g7 E) || (g13 E) || (g25 E))=true
    simpa [g2145, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 1, edge E 7 4]
    apply (mask_ge_one (edge E 7 0) (edge E 7 1) (edge E 7 4)).mp
    change ((g8 E) || (g14 E) || (g26 E))=true
    simpa [g2146, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1620 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2149, .pos 2153, .pos 2154, .pos 2155, .pos 2156] := by
  change (¬ ((g2150 E)=true)) → (¬ ((g2154 E)=true)) → (¬ ((g2155 E)=true)) → (¬ ((g2156 E)=true)) → (¬ ((g2157 E)=true)) → False
  intro c2 c3 c4 c6 c7
  apply h
  refine ⟨0,1,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 2 0, edge E 2 1, edge E 2 5]
    apply (mask_ge_two (edge E 2 0) (edge E 2 1) (edge E 2 5)).mp
    change (((g3 E) && (g9 E)) || ((g3 E) && (g17 E)) || ((g9 E) && (g17 E)))=true
    simpa [g2147, g2148, g2149, g2150, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 1, edge E 3 5]
    apply (mask_ge_two (edge E 3 0) (edge E 3 1) (edge E 3 5)).mp
    change (((g4 E) && (g10 E)) || ((g4 E) && (g21 E)) || ((g10 E) && (g21 E)))=true
    simpa [g2151, g2152, g2153, g2154, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 0, edge E 4 1, edge E 4 5]
    apply (mask_ge_one (edge E 4 0) (edge E 4 1) (edge E 4 5)).mp
    change ((g5 E) || (g11 E) || (g24 E))=true
    simpa [g2155, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 0, edge E 6 1, edge E 6 5]
    apply (mask_ge_one (edge E 6 0) (edge E 6 1) (edge E 6 5)).mp
    change ((g7 E) || (g13 E) || (g27 E))=true
    simpa [g2156, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 1, edge E 7 5]
    apply (mask_ge_one (edge E 7 0) (edge E 7 1) (edge E 7 5)).mp
    change ((g8 E) || (g14 E) || (g28 E))=true
    simpa [g2157, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1636 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2160, .pos 2164, .pos 2165, .pos 2166, .pos 2167] := by
  change (¬ ((g2161 E)=true)) → (¬ ((g2165 E)=true)) → (¬ ((g2166 E)=true)) → (¬ ((g2167 E)=true)) → (¬ ((g2168 E)=true)) → False
  intro c2 c3 c4 c5 c7
  apply h
  refine ⟨0,1,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 2 0, edge E 2 1, edge E 2 6]
    apply (mask_ge_two (edge E 2 0) (edge E 2 1) (edge E 2 6)).mp
    change (((g3 E) && (g9 E)) || ((g3 E) && (g18 E)) || ((g9 E) && (g18 E)))=true
    simpa [g2158, g2159, g2160, g2161, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 1, edge E 3 6]
    apply (mask_ge_two (edge E 3 0) (edge E 3 1) (edge E 3 6)).mp
    change (((g4 E) && (g10 E)) || ((g4 E) && (g22 E)) || ((g10 E) && (g22 E)))=true
    simpa [g2162, g2163, g2164, g2165, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 0, edge E 4 1, edge E 4 6]
    apply (mask_ge_one (edge E 4 0) (edge E 4 1) (edge E 4 6)).mp
    change ((g5 E) || (g11 E) || (g25 E))=true
    simpa [g2166, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 1, edge E 5 6]
    apply (mask_ge_one (edge E 5 0) (edge E 5 1) (edge E 5 6)).mp
    change ((g6 E) || (g12 E) || (g27 E))=true
    simpa [g2167, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 0, edge E 7 1, edge E 7 6]
    apply (mask_ge_one (edge E 7 0) (edge E 7 1) (edge E 7 6)).mp
    change ((g8 E) || (g14 E) || (g29 E))=true
    simpa [g2168, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1661 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2171, .pos 2175, .pos 2176, .pos 2177, .pos 2178] := by
  change (¬ ((g2172 E)=true)) → (¬ ((g2176 E)=true)) → (¬ ((g2177 E)=true)) → (¬ ((g2178 E)=true)) → (¬ ((g2179 E)=true)) → False
  intro c2 c3 c4 c5 c6
  apply h
  refine ⟨0,1,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 2 0, edge E 2 1, edge E 2 7]
    apply (mask_ge_two (edge E 2 0) (edge E 2 1) (edge E 2 7)).mp
    change (((g3 E) && (g9 E)) || ((g3 E) && (g19 E)) || ((g9 E) && (g19 E)))=true
    simpa [g2169, g2170, g2171, g2172, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 1, edge E 3 7]
    apply (mask_ge_two (edge E 3 0) (edge E 3 1) (edge E 3 7)).mp
    change (((g4 E) && (g10 E)) || ((g4 E) && (g23 E)) || ((g10 E) && (g23 E)))=true
    simpa [g2173, g2174, g2175, g2176, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 0, edge E 4 1, edge E 4 7]
    apply (mask_ge_one (edge E 4 0) (edge E 4 1) (edge E 4 7)).mp
    change ((g5 E) || (g11 E) || (g26 E))=true
    simpa [g2177, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 1, edge E 5 7]
    apply (mask_ge_one (edge E 5 0) (edge E 5 1) (edge E 5 7)).mp
    change ((g6 E) || (g12 E) || (g28 E))=true
    simpa [g2178, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 1, edge E 6 7]
    apply (mask_ge_one (edge E 6 0) (edge E 6 1) (edge E 6 7)).mp
    change ((g7 E) || (g13 E) || (g29 E))=true
    simpa [g2179, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_1685 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2182, .pos 2183, .pos 2184, .pos 2185, .pos 2186] := by
  change (¬ ((g2183 E)=true)) → (¬ ((g2184 E)=true)) → (¬ ((g2185 E)=true)) → (¬ ((g2186 E)=true)) → (¬ ((g2187 E)=true)) → False
  intro c1 c4 c5 c6 c7
  apply h
  refine ⟨0,2,3,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 2, edge E 1 3]
    apply (mask_ge_two (edge E 1 0) (edge E 1 2) (edge E 1 3)).mp
    change (((g2 E) && (g9 E)) || ((g2 E) && (g10 E)) || ((g9 E) && (g10 E)))=true
    simpa [g2180, g2181, g2182, g2183, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 4 0, edge E 4 2, edge E 4 3]
    apply (mask_ge_one (edge E 4 0) (edge E 4 2) (edge E 4 3)).mp
    change ((g5 E) || (g16 E) || (g20 E))=true
    simpa [g2184, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 2, edge E 5 3]
    apply (mask_ge_one (edge E 5 0) (edge E 5 2) (edge E 5 3)).mp
    change ((g6 E) || (g17 E) || (g21 E))=true
    simpa [g2185, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 2, edge E 6 3]
    apply (mask_ge_one (edge E 6 0) (edge E 6 2) (edge E 6 3)).mp
    change ((g7 E) || (g18 E) || (g22 E))=true
    simpa [g2186, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 2, edge E 7 3]
    apply (mask_ge_one (edge E 7 0) (edge E 7 2) (edge E 7 3)).mp
    change ((g8 E) || (g19 E) || (g23 E))=true
    simpa [g2187, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1704 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2190, .pos 2194, .pos 2195, .pos 2196, .pos 2197] := by
  change (¬ ((g2191 E)=true)) → (¬ ((g2195 E)=true)) → (¬ ((g2196 E)=true)) → (¬ ((g2197 E)=true)) → (¬ ((g2198 E)=true)) → False
  intro c1 c3 c5 c6 c7
  apply h
  refine ⟨0,2,4,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 2, edge E 1 4]
    apply (mask_ge_two (edge E 1 0) (edge E 1 2) (edge E 1 4)).mp
    change (((g2 E) && (g9 E)) || ((g2 E) && (g11 E)) || ((g9 E) && (g11 E)))=true
    simpa [g2188, g2189, g2190, g2191, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 3 0, edge E 3 2, edge E 3 4]
    apply (mask_ge_two (edge E 3 0) (edge E 3 2) (edge E 3 4)).mp
    change (((g4 E) && (g15 E)) || ((g4 E) && (g20 E)) || ((g15 E) && (g20 E)))=true
    simpa [g2192, g2193, g2194, g2195, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 5 0, edge E 5 2, edge E 5 4]
    apply (mask_ge_one (edge E 5 0) (edge E 5 2) (edge E 5 4)).mp
    change ((g6 E) || (g17 E) || (g24 E))=true
    simpa [g2196, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 2, edge E 6 4]
    apply (mask_ge_one (edge E 6 0) (edge E 6 2) (edge E 6 4)).mp
    change ((g7 E) || (g18 E) || (g25 E))=true
    simpa [g2197, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 2, edge E 7 4]
    apply (mask_ge_one (edge E 7 0) (edge E 7 2) (edge E 7 4)).mp
    change ((g8 E) || (g19 E) || (g26 E))=true
    simpa [g2198, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1722 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2201, .pos 2205, .pos 2206, .pos 2207, .pos 2208] := by
  change (¬ ((g2202 E)=true)) → (¬ ((g2206 E)=true)) → (¬ ((g2207 E)=true)) → (¬ ((g2208 E)=true)) → (¬ ((g2209 E)=true)) → False
  intro c1 c3 c4 c6 c7
  apply h
  refine ⟨0,2,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 2, edge E 1 5]
    apply (mask_ge_two (edge E 1 0) (edge E 1 2) (edge E 1 5)).mp
    change (((g2 E) && (g9 E)) || ((g2 E) && (g12 E)) || ((g9 E) && (g12 E)))=true
    simpa [g2199, g2200, g2201, g2202, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 3 0, edge E 3 2, edge E 3 5]
    apply (mask_ge_two (edge E 3 0) (edge E 3 2) (edge E 3 5)).mp
    change (((g4 E) && (g15 E)) || ((g4 E) && (g21 E)) || ((g15 E) && (g21 E)))=true
    simpa [g2203, g2204, g2205, g2206, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 0, edge E 4 2, edge E 4 5]
    apply (mask_ge_one (edge E 4 0) (edge E 4 2) (edge E 4 5)).mp
    change ((g5 E) || (g16 E) || (g24 E))=true
    simpa [g2207, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 0, edge E 6 2, edge E 6 5]
    apply (mask_ge_one (edge E 6 0) (edge E 6 2) (edge E 6 5)).mp
    change ((g7 E) || (g18 E) || (g27 E))=true
    simpa [g2208, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 2, edge E 7 5]
    apply (mask_ge_one (edge E 7 0) (edge E 7 2) (edge E 7 5)).mp
    change ((g8 E) || (g19 E) || (g28 E))=true
    simpa [g2209, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1739 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2212, .pos 2216, .pos 2217, .pos 2218, .pos 2219] := by
  change (¬ ((g2213 E)=true)) → (¬ ((g2217 E)=true)) → (¬ ((g2218 E)=true)) → (¬ ((g2219 E)=true)) → (¬ ((g2220 E)=true)) → False
  intro c1 c3 c4 c5 c7
  apply h
  refine ⟨0,2,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 2, edge E 1 6]
    apply (mask_ge_two (edge E 1 0) (edge E 1 2) (edge E 1 6)).mp
    change (((g2 E) && (g9 E)) || ((g2 E) && (g13 E)) || ((g9 E) && (g13 E)))=true
    simpa [g2210, g2211, g2212, g2213, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 3 0, edge E 3 2, edge E 3 6]
    apply (mask_ge_two (edge E 3 0) (edge E 3 2) (edge E 3 6)).mp
    change (((g4 E) && (g15 E)) || ((g4 E) && (g22 E)) || ((g15 E) && (g22 E)))=true
    simpa [g2214, g2215, g2216, g2217, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 0, edge E 4 2, edge E 4 6]
    apply (mask_ge_one (edge E 4 0) (edge E 4 2) (edge E 4 6)).mp
    change ((g5 E) || (g16 E) || (g25 E))=true
    simpa [g2218, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 2, edge E 5 6]
    apply (mask_ge_one (edge E 5 0) (edge E 5 2) (edge E 5 6)).mp
    change ((g6 E) || (g17 E) || (g27 E))=true
    simpa [g2219, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 0, edge E 7 2, edge E 7 6]
    apply (mask_ge_one (edge E 7 0) (edge E 7 2) (edge E 7 6)).mp
    change ((g8 E) || (g19 E) || (g29 E))=true
    simpa [g2220, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1757 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2223, .pos 2227, .pos 2228, .pos 2229, .pos 2230] := by
  change (¬ ((g2224 E)=true)) → (¬ ((g2228 E)=true)) → (¬ ((g2229 E)=true)) → (¬ ((g2230 E)=true)) → (¬ ((g2231 E)=true)) → False
  intro c1 c3 c4 c5 c6
  apply h
  refine ⟨0,2,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 2, edge E 1 7]
    apply (mask_ge_two (edge E 1 0) (edge E 1 2) (edge E 1 7)).mp
    change (((g2 E) && (g9 E)) || ((g2 E) && (g14 E)) || ((g9 E) && (g14 E)))=true
    simpa [g2221, g2222, g2223, g2224, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 3 0, edge E 3 2, edge E 3 7]
    apply (mask_ge_two (edge E 3 0) (edge E 3 2) (edge E 3 7)).mp
    change (((g4 E) && (g15 E)) || ((g4 E) && (g23 E)) || ((g15 E) && (g23 E)))=true
    simpa [g2225, g2226, g2227, g2228, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 0, edge E 4 2, edge E 4 7]
    apply (mask_ge_one (edge E 4 0) (edge E 4 2) (edge E 4 7)).mp
    change ((g5 E) || (g16 E) || (g26 E))=true
    simpa [g2229, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 2, edge E 5 7]
    apply (mask_ge_one (edge E 5 0) (edge E 5 2) (edge E 5 7)).mp
    change ((g6 E) || (g17 E) || (g28 E))=true
    simpa [g2230, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 2, edge E 6 7]
    apply (mask_ge_one (edge E 6 0) (edge E 6 2) (edge E 6 7)).mp
    change ((g7 E) || (g18 E) || (g29 E))=true
    simpa [g2231, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_1775 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2234, .pos 2238, .pos 2239, .pos 2240, .pos 2241] := by
  change (¬ ((g2235 E)=true)) → (¬ ((g2239 E)=true)) → (¬ ((g2240 E)=true)) → (¬ ((g2241 E)=true)) → (¬ ((g2242 E)=true)) → False
  intro c1 c2 c5 c6 c7
  apply h
  refine ⟨0,3,4,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 3, edge E 1 4]
    apply (mask_ge_two (edge E 1 0) (edge E 1 3) (edge E 1 4)).mp
    change (((g2 E) && (g10 E)) || ((g2 E) && (g11 E)) || ((g10 E) && (g11 E)))=true
    simpa [g2232, g2233, g2234, g2235, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 3, edge E 2 4]
    apply (mask_ge_two (edge E 2 0) (edge E 2 3) (edge E 2 4)).mp
    change (((g3 E) && (g15 E)) || ((g3 E) && (g16 E)) || ((g15 E) && (g16 E)))=true
    simpa [g2236, g2237, g2238, g2239, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 5 0, edge E 5 3, edge E 5 4]
    apply (mask_ge_one (edge E 5 0) (edge E 5 3) (edge E 5 4)).mp
    change ((g6 E) || (g21 E) || (g24 E))=true
    simpa [g2240, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 3, edge E 6 4]
    apply (mask_ge_one (edge E 6 0) (edge E 6 3) (edge E 6 4)).mp
    change ((g7 E) || (g22 E) || (g25 E))=true
    simpa [g2241, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 3, edge E 7 4]
    apply (mask_ge_one (edge E 7 0) (edge E 7 3) (edge E 7 4)).mp
    change ((g8 E) || (g23 E) || (g26 E))=true
    simpa [g2242, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1797 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2245, .pos 2249, .pos 2250, .pos 2251, .pos 2252] := by
  change (¬ ((g2246 E)=true)) → (¬ ((g2250 E)=true)) → (¬ ((g2251 E)=true)) → (¬ ((g2252 E)=true)) → (¬ ((g2253 E)=true)) → False
  intro c1 c2 c4 c6 c7
  apply h
  refine ⟨0,3,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 3, edge E 1 5]
    apply (mask_ge_two (edge E 1 0) (edge E 1 3) (edge E 1 5)).mp
    change (((g2 E) && (g10 E)) || ((g2 E) && (g12 E)) || ((g10 E) && (g12 E)))=true
    simpa [g2243, g2244, g2245, g2246, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 3, edge E 2 5]
    apply (mask_ge_two (edge E 2 0) (edge E 2 3) (edge E 2 5)).mp
    change (((g3 E) && (g15 E)) || ((g3 E) && (g17 E)) || ((g15 E) && (g17 E)))=true
    simpa [g2247, g2248, g2249, g2250, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 4 0, edge E 4 3, edge E 4 5]
    apply (mask_ge_one (edge E 4 0) (edge E 4 3) (edge E 4 5)).mp
    change ((g5 E) || (g20 E) || (g24 E))=true
    simpa [g2251, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 0, edge E 6 3, edge E 6 5]
    apply (mask_ge_one (edge E 6 0) (edge E 6 3) (edge E 6 5)).mp
    change ((g7 E) || (g22 E) || (g27 E))=true
    simpa [g2252, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 3, edge E 7 5]
    apply (mask_ge_one (edge E 7 0) (edge E 7 3) (edge E 7 5)).mp
    change ((g8 E) || (g23 E) || (g28 E))=true
    simpa [g2253, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1820 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2256, .pos 2260, .pos 2261, .pos 2262, .pos 2263] := by
  change (¬ ((g2257 E)=true)) → (¬ ((g2261 E)=true)) → (¬ ((g2262 E)=true)) → (¬ ((g2263 E)=true)) → (¬ ((g2264 E)=true)) → False
  intro c1 c2 c4 c5 c7
  apply h
  refine ⟨0,3,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 3, edge E 1 6]
    apply (mask_ge_two (edge E 1 0) (edge E 1 3) (edge E 1 6)).mp
    change (((g2 E) && (g10 E)) || ((g2 E) && (g13 E)) || ((g10 E) && (g13 E)))=true
    simpa [g2254, g2255, g2256, g2257, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 3, edge E 2 6]
    apply (mask_ge_two (edge E 2 0) (edge E 2 3) (edge E 2 6)).mp
    change (((g3 E) && (g15 E)) || ((g3 E) && (g18 E)) || ((g15 E) && (g18 E)))=true
    simpa [g2258, g2259, g2260, g2261, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 4 0, edge E 4 3, edge E 4 6]
    apply (mask_ge_one (edge E 4 0) (edge E 4 3) (edge E 4 6)).mp
    change ((g5 E) || (g20 E) || (g25 E))=true
    simpa [g2262, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 3, edge E 5 6]
    apply (mask_ge_one (edge E 5 0) (edge E 5 3) (edge E 5 6)).mp
    change ((g6 E) || (g21 E) || (g27 E))=true
    simpa [g2263, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 0, edge E 7 3, edge E 7 6]
    apply (mask_ge_one (edge E 7 0) (edge E 7 3) (edge E 7 6)).mp
    change ((g8 E) || (g23 E) || (g29 E))=true
    simpa [g2264, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1851 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2267, .pos 2271, .pos 2272, .pos 2273, .pos 2274] := by
  change (¬ ((g2268 E)=true)) → (¬ ((g2272 E)=true)) → (¬ ((g2273 E)=true)) → (¬ ((g2274 E)=true)) → (¬ ((g2275 E)=true)) → False
  intro c1 c2 c4 c5 c6
  apply h
  refine ⟨0,3,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 3, edge E 1 7]
    apply (mask_ge_two (edge E 1 0) (edge E 1 3) (edge E 1 7)).mp
    change (((g2 E) && (g10 E)) || ((g2 E) && (g14 E)) || ((g10 E) && (g14 E)))=true
    simpa [g2265, g2266, g2267, g2268, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 3, edge E 2 7]
    apply (mask_ge_two (edge E 2 0) (edge E 2 3) (edge E 2 7)).mp
    change (((g3 E) && (g15 E)) || ((g3 E) && (g19 E)) || ((g15 E) && (g19 E)))=true
    simpa [g2269, g2270, g2271, g2272, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 4 0, edge E 4 3, edge E 4 7]
    apply (mask_ge_one (edge E 4 0) (edge E 4 3) (edge E 4 7)).mp
    change ((g5 E) || (g20 E) || (g26 E))=true
    simpa [g2273, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 3, edge E 5 7]
    apply (mask_ge_one (edge E 5 0) (edge E 5 3) (edge E 5 7)).mp
    change ((g6 E) || (g21 E) || (g28 E))=true
    simpa [g2274, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 3, edge E 6 7]
    apply (mask_ge_one (edge E 6 0) (edge E 6 3) (edge E 6 7)).mp
    change ((g7 E) || (g22 E) || (g29 E))=true
    simpa [g2275, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_1872 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2278, .pos 2282, .pos 2286, .pos 2287, .pos 2288] := by
  change (¬ ((g2279 E)=true)) → (¬ ((g2283 E)=true)) → (¬ ((g2287 E)=true)) → (¬ ((g2288 E)=true)) → (¬ ((g2289 E)=true)) → False
  intro c1 c2 c3 c6 c7
  apply h
  refine ⟨0,4,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 4, edge E 1 5]
    apply (mask_ge_two (edge E 1 0) (edge E 1 4) (edge E 1 5)).mp
    change (((g2 E) && (g11 E)) || ((g2 E) && (g12 E)) || ((g11 E) && (g12 E)))=true
    simpa [g2276, g2277, g2278, g2279, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 4, edge E 2 5]
    apply (mask_ge_two (edge E 2 0) (edge E 2 4) (edge E 2 5)).mp
    change (((g3 E) && (g16 E)) || ((g3 E) && (g17 E)) || ((g16 E) && (g17 E)))=true
    simpa [g2280, g2281, g2282, g2283, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 4, edge E 3 5]
    apply (mask_ge_two (edge E 3 0) (edge E 3 4) (edge E 3 5)).mp
    change (((g4 E) && (g20 E)) || ((g4 E) && (g21 E)) || ((g20 E) && (g21 E)))=true
    simpa [g2284, g2285, g2286, g2287, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 0, edge E 6 4, edge E 6 5]
    apply (mask_ge_one (edge E 6 0) (edge E 6 4) (edge E 6 5)).mp
    change ((g7 E) || (g25 E) || (g27 E))=true
    simpa [g2288, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 4, edge E 7 5]
    apply (mask_ge_one (edge E 7 0) (edge E 7 4) (edge E 7 5)).mp
    change ((g8 E) || (g26 E) || (g28 E))=true
    simpa [g2289, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1885 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2292, .pos 2296, .pos 2300, .pos 2301, .pos 2302] := by
  change (¬ ((g2293 E)=true)) → (¬ ((g2297 E)=true)) → (¬ ((g2301 E)=true)) → (¬ ((g2302 E)=true)) → (¬ ((g2303 E)=true)) → False
  intro c1 c2 c3 c5 c7
  apply h
  refine ⟨0,4,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 4, edge E 1 6]
    apply (mask_ge_two (edge E 1 0) (edge E 1 4) (edge E 1 6)).mp
    change (((g2 E) && (g11 E)) || ((g2 E) && (g13 E)) || ((g11 E) && (g13 E)))=true
    simpa [g2290, g2291, g2292, g2293, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 4, edge E 2 6]
    apply (mask_ge_two (edge E 2 0) (edge E 2 4) (edge E 2 6)).mp
    change (((g3 E) && (g16 E)) || ((g3 E) && (g18 E)) || ((g16 E) && (g18 E)))=true
    simpa [g2294, g2295, g2296, g2297, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 4, edge E 3 6]
    apply (mask_ge_two (edge E 3 0) (edge E 3 4) (edge E 3 6)).mp
    change (((g4 E) && (g20 E)) || ((g4 E) && (g22 E)) || ((g20 E) && (g22 E)))=true
    simpa [g2298, g2299, g2300, g2301, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 5 0, edge E 5 4, edge E 5 6]
    apply (mask_ge_one (edge E 5 0) (edge E 5 4) (edge E 5 6)).mp
    change ((g6 E) || (g24 E) || (g27 E))=true
    simpa [g2302, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 0, edge E 7 4, edge E 7 6]
    apply (mask_ge_one (edge E 7 0) (edge E 7 4) (edge E 7 6)).mp
    change ((g8 E) || (g26 E) || (g29 E))=true
    simpa [g2303, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1901 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2306, .pos 2310, .pos 2314, .pos 2315, .pos 2316] := by
  change (¬ ((g2307 E)=true)) → (¬ ((g2311 E)=true)) → (¬ ((g2315 E)=true)) → (¬ ((g2316 E)=true)) → (¬ ((g2317 E)=true)) → False
  intro c1 c2 c3 c5 c6
  apply h
  refine ⟨0,4,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 4, edge E 1 7]
    apply (mask_ge_two (edge E 1 0) (edge E 1 4) (edge E 1 7)).mp
    change (((g2 E) && (g11 E)) || ((g2 E) && (g14 E)) || ((g11 E) && (g14 E)))=true
    simpa [g2304, g2305, g2306, g2307, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 4, edge E 2 7]
    apply (mask_ge_two (edge E 2 0) (edge E 2 4) (edge E 2 7)).mp
    change (((g3 E) && (g16 E)) || ((g3 E) && (g19 E)) || ((g16 E) && (g19 E)))=true
    simpa [g2308, g2309, g2310, g2311, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 4, edge E 3 7]
    apply (mask_ge_two (edge E 3 0) (edge E 3 4) (edge E 3 7)).mp
    change (((g4 E) && (g20 E)) || ((g4 E) && (g23 E)) || ((g20 E) && (g23 E)))=true
    simpa [g2312, g2313, g2314, g2315, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 5 0, edge E 5 4, edge E 5 7]
    apply (mask_ge_one (edge E 5 0) (edge E 5 4) (edge E 5 7)).mp
    change ((g6 E) || (g24 E) || (g28 E))=true
    simpa [g2316, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 4, edge E 6 7]
    apply (mask_ge_one (edge E 6 0) (edge E 6 4) (edge E 6 7)).mp
    change ((g7 E) || (g25 E) || (g29 E))=true
    simpa [g2317, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_1912 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2320, .pos 2324, .pos 2328, .pos 2329, .pos 2330] := by
  change (¬ ((g2321 E)=true)) → (¬ ((g2325 E)=true)) → (¬ ((g2329 E)=true)) → (¬ ((g2330 E)=true)) → (¬ ((g2331 E)=true)) → False
  intro c1 c2 c3 c4 c7
  apply h
  refine ⟨0,5,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 5, edge E 1 6]
    apply (mask_ge_two (edge E 1 0) (edge E 1 5) (edge E 1 6)).mp
    change (((g2 E) && (g12 E)) || ((g2 E) && (g13 E)) || ((g12 E) && (g13 E)))=true
    simpa [g2318, g2319, g2320, g2321, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 5, edge E 2 6]
    apply (mask_ge_two (edge E 2 0) (edge E 2 5) (edge E 2 6)).mp
    change (((g3 E) && (g17 E)) || ((g3 E) && (g18 E)) || ((g17 E) && (g18 E)))=true
    simpa [g2322, g2323, g2324, g2325, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 5, edge E 3 6]
    apply (mask_ge_two (edge E 3 0) (edge E 3 5) (edge E 3 6)).mp
    change (((g4 E) && (g21 E)) || ((g4 E) && (g22 E)) || ((g21 E) && (g22 E)))=true
    simpa [g2326, g2327, g2328, g2329, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 0, edge E 4 5, edge E 4 6]
    apply (mask_ge_one (edge E 4 0) (edge E 4 5) (edge E 4 6)).mp
    change ((g5 E) || (g24 E) || (g25 E))=true
    simpa [g2330, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 0, edge E 7 5, edge E 7 6]
    apply (mask_ge_one (edge E 7 0) (edge E 7 5) (edge E 7 6)).mp
    change ((g8 E) || (g28 E) || (g29 E))=true
    simpa [g2331, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1932 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2334, .pos 2338, .pos 2342, .pos 2343, .pos 2344] := by
  change (¬ ((g2335 E)=true)) → (¬ ((g2339 E)=true)) → (¬ ((g2343 E)=true)) → (¬ ((g2344 E)=true)) → (¬ ((g2345 E)=true)) → False
  intro c1 c2 c3 c4 c6
  apply h
  refine ⟨0,5,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 5, edge E 1 7]
    apply (mask_ge_two (edge E 1 0) (edge E 1 5) (edge E 1 7)).mp
    change (((g2 E) && (g12 E)) || ((g2 E) && (g14 E)) || ((g12 E) && (g14 E)))=true
    simpa [g2332, g2333, g2334, g2335, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 5, edge E 2 7]
    apply (mask_ge_two (edge E 2 0) (edge E 2 5) (edge E 2 7)).mp
    change (((g3 E) && (g17 E)) || ((g3 E) && (g19 E)) || ((g17 E) && (g19 E)))=true
    simpa [g2336, g2337, g2338, g2339, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 5, edge E 3 7]
    apply (mask_ge_two (edge E 3 0) (edge E 3 5) (edge E 3 7)).mp
    change (((g4 E) && (g21 E)) || ((g4 E) && (g23 E)) || ((g21 E) && (g23 E)))=true
    simpa [g2340, g2341, g2342, g2343, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 0, edge E 4 5, edge E 4 7]
    apply (mask_ge_one (edge E 4 0) (edge E 4 5) (edge E 4 7)).mp
    change ((g5 E) || (g24 E) || (g26 E))=true
    simpa [g2344, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 6 0, edge E 6 5, edge E 6 7]
    apply (mask_ge_one (edge E 6 0) (edge E 6 5) (edge E 6 7)).mp
    change ((g7 E) || (g27 E) || (g29 E))=true
    simpa [g2345, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_1958 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2348, .pos 2352, .pos 2356, .pos 2357, .pos 2358] := by
  change (¬ ((g2349 E)=true)) → (¬ ((g2353 E)=true)) → (¬ ((g2357 E)=true)) → (¬ ((g2358 E)=true)) → (¬ ((g2359 E)=true)) → False
  intro c1 c2 c3 c4 c5
  apply h
  refine ⟨0,6,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 6, edge E 1 7]
    apply (mask_ge_two (edge E 1 0) (edge E 1 6) (edge E 1 7)).mp
    change (((g2 E) && (g13 E)) || ((g2 E) && (g14 E)) || ((g13 E) && (g14 E)))=true
    simpa [g2346, g2347, g2348, g2349, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 6, edge E 2 7]
    apply (mask_ge_two (edge E 2 0) (edge E 2 6) (edge E 2 7)).mp
    change (((g3 E) && (g18 E)) || ((g3 E) && (g19 E)) || ((g18 E) && (g19 E)))=true
    simpa [g2350, g2351, g2352, g2353, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 6, edge E 3 7]
    apply (mask_ge_two (edge E 3 0) (edge E 3 6) (edge E 3 7)).mp
    change (((g4 E) && (g22 E)) || ((g4 E) && (g23 E)) || ((g22 E) && (g23 E)))=true
    simpa [g2354, g2355, g2356, g2357, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 0, edge E 4 6, edge E 4 7]
    apply (mask_ge_one (edge E 4 0) (edge E 4 6) (edge E 4 7)).mp
    change ((g5 E) || (g25 E) || (g26 E))=true
    simpa [g2358, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 6, edge E 5 7]
    apply (mask_ge_one (edge E 5 0) (edge E 5 6) (edge E 5 7)).mp
    change ((g6 E) || (g27 E) || (g28 E))=true
    simpa [g2359, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
private theorem root_1985 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2362, .pos 2363, .pos 2364, .pos 2365, .pos 2366] := by
  change (¬ ((g2363 E)=true)) → (¬ ((g2364 E)=true)) → (¬ ((g2365 E)=true)) → (¬ ((g2366 E)=true)) → (¬ ((g2367 E)=true)) → False
  intro c0 c4 c5 c6 c7
  apply h
  refine ⟨1,2,3,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 2, edge E 0 3]
    apply (mask_ge_two (edge E 0 1) (edge E 0 2) (edge E 0 3)).mp
    change (((g2 E) && (g3 E)) || ((g2 E) && (g4 E)) || ((g3 E) && (g4 E)))=true
    simpa [g2360, g2361, g2362, g2363, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 4 1, edge E 4 2, edge E 4 3]
    apply (mask_ge_one (edge E 4 1) (edge E 4 2) (edge E 4 3)).mp
    change ((g11 E) || (g16 E) || (g20 E))=true
    simpa [g2364, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 1, edge E 5 2, edge E 5 3]
    apply (mask_ge_one (edge E 5 1) (edge E 5 2) (edge E 5 3)).mp
    change ((g12 E) || (g17 E) || (g21 E))=true
    simpa [g2365, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 1, edge E 6 2, edge E 6 3]
    apply (mask_ge_one (edge E 6 1) (edge E 6 2) (edge E 6 3)).mp
    change ((g13 E) || (g18 E) || (g22 E))=true
    simpa [g2366, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 1, edge E 7 2, edge E 7 3]
    apply (mask_ge_one (edge E 7 1) (edge E 7 2) (edge E 7 3)).mp
    change ((g14 E) || (g19 E) || (g23 E))=true
    simpa [g2367, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1998 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2370, .pos 2374, .pos 2375, .pos 2376, .pos 2377] := by
  change (¬ ((g2371 E)=true)) → (¬ ((g2375 E)=true)) → (¬ ((g2376 E)=true)) → (¬ ((g2377 E)=true)) → (¬ ((g2378 E)=true)) → False
  intro c0 c3 c5 c6 c7
  apply h
  refine ⟨1,2,4,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 2, edge E 0 4]
    apply (mask_ge_two (edge E 0 1) (edge E 0 2) (edge E 0 4)).mp
    change (((g2 E) && (g3 E)) || ((g2 E) && (g5 E)) || ((g3 E) && (g5 E)))=true
    simpa [g2368, g2369, g2370, g2371, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 3 1, edge E 3 2, edge E 3 4]
    apply (mask_ge_two (edge E 3 1) (edge E 3 2) (edge E 3 4)).mp
    change (((g10 E) && (g15 E)) || ((g10 E) && (g20 E)) || ((g15 E) && (g20 E)))=true
    simpa [g2372, g2373, g2374, g2375, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 5 1, edge E 5 2, edge E 5 4]
    apply (mask_ge_one (edge E 5 1) (edge E 5 2) (edge E 5 4)).mp
    change ((g12 E) || (g17 E) || (g24 E))=true
    simpa [g2376, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 1, edge E 6 2, edge E 6 4]
    apply (mask_ge_one (edge E 6 1) (edge E 6 2) (edge E 6 4)).mp
    change ((g13 E) || (g18 E) || (g25 E))=true
    simpa [g2377, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 1, edge E 7 2, edge E 7 4]
    apply (mask_ge_one (edge E 7 1) (edge E 7 2) (edge E 7 4)).mp
    change ((g14 E) || (g19 E) || (g26 E))=true
    simpa [g2378, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2020 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2381, .pos 2385, .pos 2386, .pos 2387, .pos 2388] := by
  change (¬ ((g2382 E)=true)) → (¬ ((g2386 E)=true)) → (¬ ((g2387 E)=true)) → (¬ ((g2388 E)=true)) → (¬ ((g2389 E)=true)) → False
  intro c0 c3 c4 c6 c7
  apply h
  refine ⟨1,2,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 2, edge E 0 5]
    apply (mask_ge_two (edge E 0 1) (edge E 0 2) (edge E 0 5)).mp
    change (((g2 E) && (g3 E)) || ((g2 E) && (g6 E)) || ((g3 E) && (g6 E)))=true
    simpa [g2379, g2380, g2381, g2382, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 3 1, edge E 3 2, edge E 3 5]
    apply (mask_ge_two (edge E 3 1) (edge E 3 2) (edge E 3 5)).mp
    change (((g10 E) && (g15 E)) || ((g10 E) && (g21 E)) || ((g15 E) && (g21 E)))=true
    simpa [g2383, g2384, g2385, g2386, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 1, edge E 4 2, edge E 4 5]
    apply (mask_ge_one (edge E 4 1) (edge E 4 2) (edge E 4 5)).mp
    change ((g11 E) || (g16 E) || (g24 E))=true
    simpa [g2387, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 1, edge E 6 2, edge E 6 5]
    apply (mask_ge_one (edge E 6 1) (edge E 6 2) (edge E 6 5)).mp
    change ((g13 E) || (g18 E) || (g27 E))=true
    simpa [g2388, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 1, edge E 7 2, edge E 7 5]
    apply (mask_ge_one (edge E 7 1) (edge E 7 2) (edge E 7 5)).mp
    change ((g14 E) || (g19 E) || (g28 E))=true
    simpa [g2389, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2050 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2392, .pos 2396, .pos 2397, .pos 2398, .pos 2399] := by
  change (¬ ((g2393 E)=true)) → (¬ ((g2397 E)=true)) → (¬ ((g2398 E)=true)) → (¬ ((g2399 E)=true)) → (¬ ((g2400 E)=true)) → False
  intro c0 c3 c4 c5 c7
  apply h
  refine ⟨1,2,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 2, edge E 0 6]
    apply (mask_ge_two (edge E 0 1) (edge E 0 2) (edge E 0 6)).mp
    change (((g2 E) && (g3 E)) || ((g2 E) && (g7 E)) || ((g3 E) && (g7 E)))=true
    simpa [g2390, g2391, g2392, g2393, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 3 1, edge E 3 2, edge E 3 6]
    apply (mask_ge_two (edge E 3 1) (edge E 3 2) (edge E 3 6)).mp
    change (((g10 E) && (g15 E)) || ((g10 E) && (g22 E)) || ((g15 E) && (g22 E)))=true
    simpa [g2394, g2395, g2396, g2397, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 1, edge E 4 2, edge E 4 6]
    apply (mask_ge_one (edge E 4 1) (edge E 4 2) (edge E 4 6)).mp
    change ((g11 E) || (g16 E) || (g25 E))=true
    simpa [g2398, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 1, edge E 5 2, edge E 5 6]
    apply (mask_ge_one (edge E 5 1) (edge E 5 2) (edge E 5 6)).mp
    change ((g12 E) || (g17 E) || (g27 E))=true
    simpa [g2399, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 1, edge E 7 2, edge E 7 6]
    apply (mask_ge_one (edge E 7 1) (edge E 7 2) (edge E 7 6)).mp
    change ((g14 E) || (g19 E) || (g29 E))=true
    simpa [g2400, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2080 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2403, .pos 2407, .pos 2408, .pos 2409, .pos 2410] := by
  change (¬ ((g2404 E)=true)) → (¬ ((g2408 E)=true)) → (¬ ((g2409 E)=true)) → (¬ ((g2410 E)=true)) → (¬ ((g2411 E)=true)) → False
  intro c0 c3 c4 c5 c6
  apply h
  refine ⟨1,2,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 2, edge E 0 7]
    apply (mask_ge_two (edge E 0 1) (edge E 0 2) (edge E 0 7)).mp
    change (((g2 E) && (g3 E)) || ((g2 E) && (g8 E)) || ((g3 E) && (g8 E)))=true
    simpa [g2401, g2402, g2403, g2404, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 3 1, edge E 3 2, edge E 3 7]
    apply (mask_ge_two (edge E 3 1) (edge E 3 2) (edge E 3 7)).mp
    change (((g10 E) && (g15 E)) || ((g10 E) && (g23 E)) || ((g15 E) && (g23 E)))=true
    simpa [g2405, g2406, g2407, g2408, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 1, edge E 4 2, edge E 4 7]
    apply (mask_ge_one (edge E 4 1) (edge E 4 2) (edge E 4 7)).mp
    change ((g11 E) || (g16 E) || (g26 E))=true
    simpa [g2409, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 1, edge E 5 2, edge E 5 7]
    apply (mask_ge_one (edge E 5 1) (edge E 5 2) (edge E 5 7)).mp
    change ((g12 E) || (g17 E) || (g28 E))=true
    simpa [g2410, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 1, edge E 6 2, edge E 6 7]
    apply (mask_ge_one (edge E 6 1) (edge E 6 2) (edge E 6 7)).mp
    change ((g13 E) || (g18 E) || (g29 E))=true
    simpa [g2411, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_2090 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2414, .pos 2418, .pos 2419, .pos 2420, .pos 2421] := by
  change (¬ ((g2415 E)=true)) → (¬ ((g2419 E)=true)) → (¬ ((g2420 E)=true)) → (¬ ((g2421 E)=true)) → (¬ ((g2422 E)=true)) → False
  intro c0 c2 c5 c6 c7
  apply h
  refine ⟨1,3,4,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 3, edge E 0 4]
    apply (mask_ge_two (edge E 0 1) (edge E 0 3) (edge E 0 4)).mp
    change (((g2 E) && (g4 E)) || ((g2 E) && (g5 E)) || ((g4 E) && (g5 E)))=true
    simpa [g2412, g2413, g2414, g2415, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 3, edge E 2 4]
    apply (mask_ge_two (edge E 2 1) (edge E 2 3) (edge E 2 4)).mp
    change (((g9 E) && (g15 E)) || ((g9 E) && (g16 E)) || ((g15 E) && (g16 E)))=true
    simpa [g2416, g2417, g2418, g2419, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 5 1, edge E 5 3, edge E 5 4]
    apply (mask_ge_one (edge E 5 1) (edge E 5 3) (edge E 5 4)).mp
    change ((g12 E) || (g21 E) || (g24 E))=true
    simpa [g2420, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 1, edge E 6 3, edge E 6 4]
    apply (mask_ge_one (edge E 6 1) (edge E 6 3) (edge E 6 4)).mp
    change ((g13 E) || (g22 E) || (g25 E))=true
    simpa [g2421, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 1, edge E 7 3, edge E 7 4]
    apply (mask_ge_one (edge E 7 1) (edge E 7 3) (edge E 7 4)).mp
    change ((g14 E) || (g23 E) || (g26 E))=true
    simpa [g2422, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2108 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2425, .pos 2429, .pos 2430, .pos 2431, .pos 2432] := by
  change (¬ ((g2426 E)=true)) → (¬ ((g2430 E)=true)) → (¬ ((g2431 E)=true)) → (¬ ((g2432 E)=true)) → (¬ ((g2433 E)=true)) → False
  intro c0 c2 c4 c6 c7
  apply h
  refine ⟨1,3,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 3, edge E 0 5]
    apply (mask_ge_two (edge E 0 1) (edge E 0 3) (edge E 0 5)).mp
    change (((g2 E) && (g4 E)) || ((g2 E) && (g6 E)) || ((g4 E) && (g6 E)))=true
    simpa [g2423, g2424, g2425, g2426, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 3, edge E 2 5]
    apply (mask_ge_two (edge E 2 1) (edge E 2 3) (edge E 2 5)).mp
    change (((g9 E) && (g15 E)) || ((g9 E) && (g17 E)) || ((g15 E) && (g17 E)))=true
    simpa [g2427, g2428, g2429, g2430, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 4 1, edge E 4 3, edge E 4 5]
    apply (mask_ge_one (edge E 4 1) (edge E 4 3) (edge E 4 5)).mp
    change ((g11 E) || (g20 E) || (g24 E))=true
    simpa [g2431, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 1, edge E 6 3, edge E 6 5]
    apply (mask_ge_one (edge E 6 1) (edge E 6 3) (edge E 6 5)).mp
    change ((g13 E) || (g22 E) || (g27 E))=true
    simpa [g2432, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 1, edge E 7 3, edge E 7 5]
    apply (mask_ge_one (edge E 7 1) (edge E 7 3) (edge E 7 5)).mp
    change ((g14 E) || (g23 E) || (g28 E))=true
    simpa [g2433, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2134 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2436, .pos 2440, .pos 2441, .pos 2442, .pos 2443] := by
  change (¬ ((g2437 E)=true)) → (¬ ((g2441 E)=true)) → (¬ ((g2442 E)=true)) → (¬ ((g2443 E)=true)) → (¬ ((g2444 E)=true)) → False
  intro c0 c2 c4 c5 c7
  apply h
  refine ⟨1,3,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 3, edge E 0 6]
    apply (mask_ge_two (edge E 0 1) (edge E 0 3) (edge E 0 6)).mp
    change (((g2 E) && (g4 E)) || ((g2 E) && (g7 E)) || ((g4 E) && (g7 E)))=true
    simpa [g2434, g2435, g2436, g2437, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 3, edge E 2 6]
    apply (mask_ge_two (edge E 2 1) (edge E 2 3) (edge E 2 6)).mp
    change (((g9 E) && (g15 E)) || ((g9 E) && (g18 E)) || ((g15 E) && (g18 E)))=true
    simpa [g2438, g2439, g2440, g2441, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 4 1, edge E 4 3, edge E 4 6]
    apply (mask_ge_one (edge E 4 1) (edge E 4 3) (edge E 4 6)).mp
    change ((g11 E) || (g20 E) || (g25 E))=true
    simpa [g2442, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 1, edge E 5 3, edge E 5 6]
    apply (mask_ge_one (edge E 5 1) (edge E 5 3) (edge E 5 6)).mp
    change ((g12 E) || (g21 E) || (g27 E))=true
    simpa [g2443, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 1, edge E 7 3, edge E 7 6]
    apply (mask_ge_one (edge E 7 1) (edge E 7 3) (edge E 7 6)).mp
    change ((g14 E) || (g23 E) || (g29 E))=true
    simpa [g2444, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2155 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2447, .pos 2451, .pos 2452, .pos 2453, .pos 2454] := by
  change (¬ ((g2448 E)=true)) → (¬ ((g2452 E)=true)) → (¬ ((g2453 E)=true)) → (¬ ((g2454 E)=true)) → (¬ ((g2455 E)=true)) → False
  intro c0 c2 c4 c5 c6
  apply h
  refine ⟨1,3,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 3, edge E 0 7]
    apply (mask_ge_two (edge E 0 1) (edge E 0 3) (edge E 0 7)).mp
    change (((g2 E) && (g4 E)) || ((g2 E) && (g8 E)) || ((g4 E) && (g8 E)))=true
    simpa [g2445, g2446, g2447, g2448, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 3, edge E 2 7]
    apply (mask_ge_two (edge E 2 1) (edge E 2 3) (edge E 2 7)).mp
    change (((g9 E) && (g15 E)) || ((g9 E) && (g19 E)) || ((g15 E) && (g19 E)))=true
    simpa [g2449, g2450, g2451, g2452, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 4 1, edge E 4 3, edge E 4 7]
    apply (mask_ge_one (edge E 4 1) (edge E 4 3) (edge E 4 7)).mp
    change ((g11 E) || (g20 E) || (g26 E))=true
    simpa [g2453, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 1, edge E 5 3, edge E 5 7]
    apply (mask_ge_one (edge E 5 1) (edge E 5 3) (edge E 5 7)).mp
    change ((g12 E) || (g21 E) || (g28 E))=true
    simpa [g2454, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 1, edge E 6 3, edge E 6 7]
    apply (mask_ge_one (edge E 6 1) (edge E 6 3) (edge E 6 7)).mp
    change ((g13 E) || (g22 E) || (g29 E))=true
    simpa [g2455, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_2164 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2458, .pos 2462, .pos 2466, .pos 2467, .pos 2468] := by
  change (¬ ((g2459 E)=true)) → (¬ ((g2463 E)=true)) → (¬ ((g2467 E)=true)) → (¬ ((g2468 E)=true)) → (¬ ((g2469 E)=true)) → False
  intro c0 c2 c3 c6 c7
  apply h
  refine ⟨1,4,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 4, edge E 0 5]
    apply (mask_ge_two (edge E 0 1) (edge E 0 4) (edge E 0 5)).mp
    change (((g2 E) && (g5 E)) || ((g2 E) && (g6 E)) || ((g5 E) && (g6 E)))=true
    simpa [g2456, g2457, g2458, g2459, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 4, edge E 2 5]
    apply (mask_ge_two (edge E 2 1) (edge E 2 4) (edge E 2 5)).mp
    change (((g9 E) && (g16 E)) || ((g9 E) && (g17 E)) || ((g16 E) && (g17 E)))=true
    simpa [g2460, g2461, g2462, g2463, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 1, edge E 3 4, edge E 3 5]
    apply (mask_ge_two (edge E 3 1) (edge E 3 4) (edge E 3 5)).mp
    change (((g10 E) && (g20 E)) || ((g10 E) && (g21 E)) || ((g20 E) && (g21 E)))=true
    simpa [g2464, g2465, g2466, g2467, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 1, edge E 6 4, edge E 6 5]
    apply (mask_ge_one (edge E 6 1) (edge E 6 4) (edge E 6 5)).mp
    change ((g13 E) || (g25 E) || (g27 E))=true
    simpa [g2468, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 1, edge E 7 4, edge E 7 5]
    apply (mask_ge_one (edge E 7 1) (edge E 7 4) (edge E 7 5)).mp
    change ((g14 E) || (g26 E) || (g28 E))=true
    simpa [g2469, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2175 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2472, .pos 2476, .pos 2480, .pos 2481, .pos 2482] := by
  change (¬ ((g2473 E)=true)) → (¬ ((g2477 E)=true)) → (¬ ((g2481 E)=true)) → (¬ ((g2482 E)=true)) → (¬ ((g2483 E)=true)) → False
  intro c0 c2 c3 c5 c7
  apply h
  refine ⟨1,4,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 4, edge E 0 6]
    apply (mask_ge_two (edge E 0 1) (edge E 0 4) (edge E 0 6)).mp
    change (((g2 E) && (g5 E)) || ((g2 E) && (g7 E)) || ((g5 E) && (g7 E)))=true
    simpa [g2470, g2471, g2472, g2473, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 4, edge E 2 6]
    apply (mask_ge_two (edge E 2 1) (edge E 2 4) (edge E 2 6)).mp
    change (((g9 E) && (g16 E)) || ((g9 E) && (g18 E)) || ((g16 E) && (g18 E)))=true
    simpa [g2474, g2475, g2476, g2477, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 1, edge E 3 4, edge E 3 6]
    apply (mask_ge_two (edge E 3 1) (edge E 3 4) (edge E 3 6)).mp
    change (((g10 E) && (g20 E)) || ((g10 E) && (g22 E)) || ((g20 E) && (g22 E)))=true
    simpa [g2478, g2479, g2480, g2481, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 5 1, edge E 5 4, edge E 5 6]
    apply (mask_ge_one (edge E 5 1) (edge E 5 4) (edge E 5 6)).mp
    change ((g12 E) || (g24 E) || (g27 E))=true
    simpa [g2482, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 1, edge E 7 4, edge E 7 6]
    apply (mask_ge_one (edge E 7 1) (edge E 7 4) (edge E 7 6)).mp
    change ((g14 E) || (g26 E) || (g29 E))=true
    simpa [g2483, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2187 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2486, .pos 2490, .pos 2494, .pos 2495, .pos 2496] := by
  change (¬ ((g2487 E)=true)) → (¬ ((g2491 E)=true)) → (¬ ((g2495 E)=true)) → (¬ ((g2496 E)=true)) → (¬ ((g2497 E)=true)) → False
  intro c0 c2 c3 c5 c6
  apply h
  refine ⟨1,4,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 4, edge E 0 7]
    apply (mask_ge_two (edge E 0 1) (edge E 0 4) (edge E 0 7)).mp
    change (((g2 E) && (g5 E)) || ((g2 E) && (g8 E)) || ((g5 E) && (g8 E)))=true
    simpa [g2484, g2485, g2486, g2487, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 4, edge E 2 7]
    apply (mask_ge_two (edge E 2 1) (edge E 2 4) (edge E 2 7)).mp
    change (((g9 E) && (g16 E)) || ((g9 E) && (g19 E)) || ((g16 E) && (g19 E)))=true
    simpa [g2488, g2489, g2490, g2491, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 1, edge E 3 4, edge E 3 7]
    apply (mask_ge_two (edge E 3 1) (edge E 3 4) (edge E 3 7)).mp
    change (((g10 E) && (g20 E)) || ((g10 E) && (g23 E)) || ((g20 E) && (g23 E)))=true
    simpa [g2492, g2493, g2494, g2495, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 5 1, edge E 5 4, edge E 5 7]
    apply (mask_ge_one (edge E 5 1) (edge E 5 4) (edge E 5 7)).mp
    change ((g12 E) || (g24 E) || (g28 E))=true
    simpa [g2496, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 1, edge E 6 4, edge E 6 7]
    apply (mask_ge_one (edge E 6 1) (edge E 6 4) (edge E 6 7)).mp
    change ((g13 E) || (g25 E) || (g29 E))=true
    simpa [g2497, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_2204 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2500, .pos 2504, .pos 2508, .pos 2509, .pos 2510] := by
  change (¬ ((g2501 E)=true)) → (¬ ((g2505 E)=true)) → (¬ ((g2509 E)=true)) → (¬ ((g2510 E)=true)) → (¬ ((g2511 E)=true)) → False
  intro c0 c2 c3 c4 c7
  apply h
  refine ⟨1,5,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 5, edge E 0 6]
    apply (mask_ge_two (edge E 0 1) (edge E 0 5) (edge E 0 6)).mp
    change (((g2 E) && (g6 E)) || ((g2 E) && (g7 E)) || ((g6 E) && (g7 E)))=true
    simpa [g2498, g2499, g2500, g2501, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 5, edge E 2 6]
    apply (mask_ge_two (edge E 2 1) (edge E 2 5) (edge E 2 6)).mp
    change (((g9 E) && (g17 E)) || ((g9 E) && (g18 E)) || ((g17 E) && (g18 E)))=true
    simpa [g2502, g2503, g2504, g2505, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 1, edge E 3 5, edge E 3 6]
    apply (mask_ge_two (edge E 3 1) (edge E 3 5) (edge E 3 6)).mp
    change (((g10 E) && (g21 E)) || ((g10 E) && (g22 E)) || ((g21 E) && (g22 E)))=true
    simpa [g2506, g2507, g2508, g2509, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 1, edge E 4 5, edge E 4 6]
    apply (mask_ge_one (edge E 4 1) (edge E 4 5) (edge E 4 6)).mp
    change ((g11 E) || (g24 E) || (g25 E))=true
    simpa [g2510, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 1, edge E 7 5, edge E 7 6]
    apply (mask_ge_one (edge E 7 1) (edge E 7 5) (edge E 7 6)).mp
    change ((g14 E) || (g28 E) || (g29 E))=true
    simpa [g2511, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2226 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2514, .pos 2518, .pos 2522, .pos 2523, .pos 2524] := by
  change (¬ ((g2515 E)=true)) → (¬ ((g2519 E)=true)) → (¬ ((g2523 E)=true)) → (¬ ((g2524 E)=true)) → (¬ ((g2525 E)=true)) → False
  intro c0 c2 c3 c4 c6
  apply h
  refine ⟨1,5,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 5, edge E 0 7]
    apply (mask_ge_two (edge E 0 1) (edge E 0 5) (edge E 0 7)).mp
    change (((g2 E) && (g6 E)) || ((g2 E) && (g8 E)) || ((g6 E) && (g8 E)))=true
    simpa [g2512, g2513, g2514, g2515, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 5, edge E 2 7]
    apply (mask_ge_two (edge E 2 1) (edge E 2 5) (edge E 2 7)).mp
    change (((g9 E) && (g17 E)) || ((g9 E) && (g19 E)) || ((g17 E) && (g19 E)))=true
    simpa [g2516, g2517, g2518, g2519, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 1, edge E 3 5, edge E 3 7]
    apply (mask_ge_two (edge E 3 1) (edge E 3 5) (edge E 3 7)).mp
    change (((g10 E) && (g21 E)) || ((g10 E) && (g23 E)) || ((g21 E) && (g23 E)))=true
    simpa [g2520, g2521, g2522, g2523, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 1, edge E 4 5, edge E 4 7]
    apply (mask_ge_one (edge E 4 1) (edge E 4 5) (edge E 4 7)).mp
    change ((g11 E) || (g24 E) || (g26 E))=true
    simpa [g2524, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 6 1, edge E 6 5, edge E 6 7]
    apply (mask_ge_one (edge E 6 1) (edge E 6 5) (edge E 6 7)).mp
    change ((g13 E) || (g27 E) || (g29 E))=true
    simpa [g2525, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_2243 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2528, .pos 2532, .pos 2536, .pos 2537, .pos 2538] := by
  change (¬ ((g2529 E)=true)) → (¬ ((g2533 E)=true)) → (¬ ((g2537 E)=true)) → (¬ ((g2538 E)=true)) → (¬ ((g2539 E)=true)) → False
  intro c0 c2 c3 c4 c5
  apply h
  refine ⟨1,6,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 6, edge E 0 7]
    apply (mask_ge_two (edge E 0 1) (edge E 0 6) (edge E 0 7)).mp
    change (((g2 E) && (g7 E)) || ((g2 E) && (g8 E)) || ((g7 E) && (g8 E)))=true
    simpa [g2526, g2527, g2528, g2529, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 6, edge E 2 7]
    apply (mask_ge_two (edge E 2 1) (edge E 2 6) (edge E 2 7)).mp
    change (((g9 E) && (g18 E)) || ((g9 E) && (g19 E)) || ((g18 E) && (g19 E)))=true
    simpa [g2530, g2531, g2532, g2533, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 1, edge E 3 6, edge E 3 7]
    apply (mask_ge_two (edge E 3 1) (edge E 3 6) (edge E 3 7)).mp
    change (((g10 E) && (g22 E)) || ((g10 E) && (g23 E)) || ((g22 E) && (g23 E)))=true
    simpa [g2534, g2535, g2536, g2537, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 1, edge E 4 6, edge E 4 7]
    apply (mask_ge_one (edge E 4 1) (edge E 4 6) (edge E 4 7)).mp
    change ((g11 E) || (g25 E) || (g26 E))=true
    simpa [g2538, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 1, edge E 5 6, edge E 5 7]
    apply (mask_ge_one (edge E 5 1) (edge E 5 6) (edge E 5 7)).mp
    change ((g12 E) || (g27 E) || (g28 E))=true
    simpa [g2539, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
private theorem root_2251 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2542, .pos 2546, .pos 2547, .pos 2548, .pos 2549] := by
  change (¬ ((g2543 E)=true)) → (¬ ((g2547 E)=true)) → (¬ ((g2548 E)=true)) → (¬ ((g2549 E)=true)) → (¬ ((g2550 E)=true)) → False
  intro c0 c1 c5 c6 c7
  apply h
  refine ⟨2,3,4,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 3, edge E 0 4]
    apply (mask_ge_two (edge E 0 2) (edge E 0 3) (edge E 0 4)).mp
    change (((g3 E) && (g4 E)) || ((g3 E) && (g5 E)) || ((g4 E) && (g5 E)))=true
    simpa [g2540, g2541, g2542, g2543, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 3, edge E 1 4]
    apply (mask_ge_two (edge E 1 2) (edge E 1 3) (edge E 1 4)).mp
    change (((g9 E) && (g10 E)) || ((g9 E) && (g11 E)) || ((g10 E) && (g11 E)))=true
    simpa [g2544, g2545, g2546, g2547, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 5 2, edge E 5 3, edge E 5 4]
    apply (mask_ge_one (edge E 5 2) (edge E 5 3) (edge E 5 4)).mp
    change ((g17 E) || (g21 E) || (g24 E))=true
    simpa [g2548, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 2, edge E 6 3, edge E 6 4]
    apply (mask_ge_one (edge E 6 2) (edge E 6 3) (edge E 6 4)).mp
    change ((g18 E) || (g22 E) || (g25 E))=true
    simpa [g2549, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 2, edge E 7 3, edge E 7 4]
    apply (mask_ge_one (edge E 7 2) (edge E 7 3) (edge E 7 4)).mp
    change ((g19 E) || (g23 E) || (g26 E))=true
    simpa [g2550, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2268 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2553, .pos 2557, .pos 2558, .pos 2559, .pos 2560] := by
  change (¬ ((g2554 E)=true)) → (¬ ((g2558 E)=true)) → (¬ ((g2559 E)=true)) → (¬ ((g2560 E)=true)) → (¬ ((g2561 E)=true)) → False
  intro c0 c1 c4 c6 c7
  apply h
  refine ⟨2,3,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 3, edge E 0 5]
    apply (mask_ge_two (edge E 0 2) (edge E 0 3) (edge E 0 5)).mp
    change (((g3 E) && (g4 E)) || ((g3 E) && (g6 E)) || ((g4 E) && (g6 E)))=true
    simpa [g2551, g2552, g2553, g2554, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 3, edge E 1 5]
    apply (mask_ge_two (edge E 1 2) (edge E 1 3) (edge E 1 5)).mp
    change (((g9 E) && (g10 E)) || ((g9 E) && (g12 E)) || ((g10 E) && (g12 E)))=true
    simpa [g2555, g2556, g2557, g2558, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 4 2, edge E 4 3, edge E 4 5]
    apply (mask_ge_one (edge E 4 2) (edge E 4 3) (edge E 4 5)).mp
    change ((g16 E) || (g20 E) || (g24 E))=true
    simpa [g2559, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 2, edge E 6 3, edge E 6 5]
    apply (mask_ge_one (edge E 6 2) (edge E 6 3) (edge E 6 5)).mp
    change ((g18 E) || (g22 E) || (g27 E))=true
    simpa [g2560, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 2, edge E 7 3, edge E 7 5]
    apply (mask_ge_one (edge E 7 2) (edge E 7 3) (edge E 7 5)).mp
    change ((g19 E) || (g23 E) || (g28 E))=true
    simpa [g2561, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2297 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2564, .pos 2568, .pos 2569, .pos 2570, .pos 2571] := by
  change (¬ ((g2565 E)=true)) → (¬ ((g2569 E)=true)) → (¬ ((g2570 E)=true)) → (¬ ((g2571 E)=true)) → (¬ ((g2572 E)=true)) → False
  intro c0 c1 c4 c5 c7
  apply h
  refine ⟨2,3,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 3, edge E 0 6]
    apply (mask_ge_two (edge E 0 2) (edge E 0 3) (edge E 0 6)).mp
    change (((g3 E) && (g4 E)) || ((g3 E) && (g7 E)) || ((g4 E) && (g7 E)))=true
    simpa [g2562, g2563, g2564, g2565, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 3, edge E 1 6]
    apply (mask_ge_two (edge E 1 2) (edge E 1 3) (edge E 1 6)).mp
    change (((g9 E) && (g10 E)) || ((g9 E) && (g13 E)) || ((g10 E) && (g13 E)))=true
    simpa [g2566, g2567, g2568, g2569, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 4 2, edge E 4 3, edge E 4 6]
    apply (mask_ge_one (edge E 4 2) (edge E 4 3) (edge E 4 6)).mp
    change ((g16 E) || (g20 E) || (g25 E))=true
    simpa [g2570, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 2, edge E 5 3, edge E 5 6]
    apply (mask_ge_one (edge E 5 2) (edge E 5 3) (edge E 5 6)).mp
    change ((g17 E) || (g21 E) || (g27 E))=true
    simpa [g2571, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 2, edge E 7 3, edge E 7 6]
    apply (mask_ge_one (edge E 7 2) (edge E 7 3) (edge E 7 6)).mp
    change ((g19 E) || (g23 E) || (g29 E))=true
    simpa [g2572, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2333 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2575, .pos 2579, .pos 2580, .pos 2581, .pos 2582] := by
  change (¬ ((g2576 E)=true)) → (¬ ((g2580 E)=true)) → (¬ ((g2581 E)=true)) → (¬ ((g2582 E)=true)) → (¬ ((g2583 E)=true)) → False
  intro c0 c1 c4 c5 c6
  apply h
  refine ⟨2,3,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 3, edge E 0 7]
    apply (mask_ge_two (edge E 0 2) (edge E 0 3) (edge E 0 7)).mp
    change (((g3 E) && (g4 E)) || ((g3 E) && (g8 E)) || ((g4 E) && (g8 E)))=true
    simpa [g2573, g2574, g2575, g2576, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 3, edge E 1 7]
    apply (mask_ge_two (edge E 1 2) (edge E 1 3) (edge E 1 7)).mp
    change (((g9 E) && (g10 E)) || ((g9 E) && (g14 E)) || ((g10 E) && (g14 E)))=true
    simpa [g2577, g2578, g2579, g2580, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 4 2, edge E 4 3, edge E 4 7]
    apply (mask_ge_one (edge E 4 2) (edge E 4 3) (edge E 4 7)).mp
    change ((g16 E) || (g20 E) || (g26 E))=true
    simpa [g2581, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 2, edge E 5 3, edge E 5 7]
    apply (mask_ge_one (edge E 5 2) (edge E 5 3) (edge E 5 7)).mp
    change ((g17 E) || (g21 E) || (g28 E))=true
    simpa [g2582, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 2, edge E 6 3, edge E 6 7]
    apply (mask_ge_one (edge E 6 2) (edge E 6 3) (edge E 6 7)).mp
    change ((g18 E) || (g22 E) || (g29 E))=true
    simpa [g2583, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_2342 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2600, .pos 2604, .pos 2608, .pos 2609, .pos 2610] := by
  change (¬ ((g2601 E)=true)) → (¬ ((g2605 E)=true)) → (¬ ((g2609 E)=true)) → (¬ ((g2610 E)=true)) → (¬ ((g2611 E)=true)) → False
  intro c0 c1 c3 c5 c7
  apply h
  refine ⟨2,4,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 4, edge E 0 6]
    apply (mask_ge_two (edge E 0 2) (edge E 0 4) (edge E 0 6)).mp
    change (((g3 E) && (g5 E)) || ((g3 E) && (g7 E)) || ((g5 E) && (g7 E)))=true
    simpa [g2598, g2599, g2600, g2601, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 4, edge E 1 6]
    apply (mask_ge_two (edge E 1 2) (edge E 1 4) (edge E 1 6)).mp
    change (((g9 E) && (g11 E)) || ((g9 E) && (g13 E)) || ((g11 E) && (g13 E)))=true
    simpa [g2602, g2603, g2604, g2605, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 3 2, edge E 3 4, edge E 3 6]
    apply (mask_ge_two (edge E 3 2) (edge E 3 4) (edge E 3 6)).mp
    change (((g15 E) && (g20 E)) || ((g15 E) && (g22 E)) || ((g20 E) && (g22 E)))=true
    simpa [g2606, g2607, g2608, g2609, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 5 2, edge E 5 4, edge E 5 6]
    apply (mask_ge_one (edge E 5 2) (edge E 5 4) (edge E 5 6)).mp
    change ((g17 E) || (g24 E) || (g27 E))=true
    simpa [g2610, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 2, edge E 7 4, edge E 7 6]
    apply (mask_ge_one (edge E 7 2) (edge E 7 4) (edge E 7 6)).mp
    change ((g19 E) || (g26 E) || (g29 E))=true
    simpa [g2611, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2359 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2628, .pos 2632, .pos 2636, .pos 2637, .pos 2638] := by
  change (¬ ((g2629 E)=true)) → (¬ ((g2633 E)=true)) → (¬ ((g2637 E)=true)) → (¬ ((g2638 E)=true)) → (¬ ((g2639 E)=true)) → False
  intro c0 c1 c3 c4 c7
  apply h
  refine ⟨2,5,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 5, edge E 0 6]
    apply (mask_ge_two (edge E 0 2) (edge E 0 5) (edge E 0 6)).mp
    change (((g3 E) && (g6 E)) || ((g3 E) && (g7 E)) || ((g6 E) && (g7 E)))=true
    simpa [g2626, g2627, g2628, g2629, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 5, edge E 1 6]
    apply (mask_ge_two (edge E 1 2) (edge E 1 5) (edge E 1 6)).mp
    change (((g9 E) && (g12 E)) || ((g9 E) && (g13 E)) || ((g12 E) && (g13 E)))=true
    simpa [g2630, g2631, g2632, g2633, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 3 2, edge E 3 5, edge E 3 6]
    apply (mask_ge_two (edge E 3 2) (edge E 3 5) (edge E 3 6)).mp
    change (((g15 E) && (g21 E)) || ((g15 E) && (g22 E)) || ((g21 E) && (g22 E)))=true
    simpa [g2634, g2635, g2636, g2637, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 2, edge E 4 5, edge E 4 6]
    apply (mask_ge_one (edge E 4 2) (edge E 4 5) (edge E 4 6)).mp
    change ((g16 E) || (g24 E) || (g25 E))=true
    simpa [g2638, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 2, edge E 7 5, edge E 7 6]
    apply (mask_ge_one (edge E 7 2) (edge E 7 5) (edge E 7 6)).mp
    change ((g19 E) || (g28 E) || (g29 E))=true
    simpa [g2639, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2374 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2642, .pos 2646, .pos 2650, .pos 2651, .pos 2652] := by
  change (¬ ((g2643 E)=true)) → (¬ ((g2647 E)=true)) → (¬ ((g2651 E)=true)) → (¬ ((g2652 E)=true)) → (¬ ((g2653 E)=true)) → False
  intro c0 c1 c3 c4 c6
  apply h
  refine ⟨2,5,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 5, edge E 0 7]
    apply (mask_ge_two (edge E 0 2) (edge E 0 5) (edge E 0 7)).mp
    change (((g3 E) && (g6 E)) || ((g3 E) && (g8 E)) || ((g6 E) && (g8 E)))=true
    simpa [g2640, g2641, g2642, g2643, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 5, edge E 1 7]
    apply (mask_ge_two (edge E 1 2) (edge E 1 5) (edge E 1 7)).mp
    change (((g9 E) && (g12 E)) || ((g9 E) && (g14 E)) || ((g12 E) && (g14 E)))=true
    simpa [g2644, g2645, g2646, g2647, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 3 2, edge E 3 5, edge E 3 7]
    apply (mask_ge_two (edge E 3 2) (edge E 3 5) (edge E 3 7)).mp
    change (((g15 E) && (g21 E)) || ((g15 E) && (g23 E)) || ((g21 E) && (g23 E)))=true
    simpa [g2648, g2649, g2650, g2651, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 2, edge E 4 5, edge E 4 7]
    apply (mask_ge_one (edge E 4 2) (edge E 4 5) (edge E 4 7)).mp
    change ((g16 E) || (g24 E) || (g26 E))=true
    simpa [g2652, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 6 2, edge E 6 5, edge E 6 7]
    apply (mask_ge_one (edge E 6 2) (edge E 6 5) (edge E 6 7)).mp
    change ((g18 E) || (g27 E) || (g29 E))=true
    simpa [g2653, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_2411 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2656, .pos 2660, .pos 2664, .pos 2665, .pos 2666] := by
  change (¬ ((g2657 E)=true)) → (¬ ((g2661 E)=true)) → (¬ ((g2665 E)=true)) → (¬ ((g2666 E)=true)) → (¬ ((g2667 E)=true)) → False
  intro c0 c1 c3 c4 c5
  apply h
  refine ⟨2,6,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 6, edge E 0 7]
    apply (mask_ge_two (edge E 0 2) (edge E 0 6) (edge E 0 7)).mp
    change (((g3 E) && (g7 E)) || ((g3 E) && (g8 E)) || ((g7 E) && (g8 E)))=true
    simpa [g2654, g2655, g2656, g2657, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 6, edge E 1 7]
    apply (mask_ge_two (edge E 1 2) (edge E 1 6) (edge E 1 7)).mp
    change (((g9 E) && (g13 E)) || ((g9 E) && (g14 E)) || ((g13 E) && (g14 E)))=true
    simpa [g2658, g2659, g2660, g2661, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 3 2, edge E 3 6, edge E 3 7]
    apply (mask_ge_two (edge E 3 2) (edge E 3 6) (edge E 3 7)).mp
    change (((g15 E) && (g22 E)) || ((g15 E) && (g23 E)) || ((g22 E) && (g23 E)))=true
    simpa [g2662, g2663, g2664, g2665, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 2, edge E 4 6, edge E 4 7]
    apply (mask_ge_one (edge E 4 2) (edge E 4 6) (edge E 4 7)).mp
    change ((g16 E) || (g25 E) || (g26 E))=true
    simpa [g2666, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 2, edge E 5 6, edge E 5 7]
    apply (mask_ge_one (edge E 5 2) (edge E 5 6) (edge E 5 7)).mp
    change ((g17 E) || (g27 E) || (g28 E))=true
    simpa [g2667, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
private theorem root_2420 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2698, .pos 2702, .pos 2706, .pos 2707, .pos 2708] := by
  change (¬ ((g2699 E)=true)) → (¬ ((g2703 E)=true)) → (¬ ((g2707 E)=true)) → (¬ ((g2708 E)=true)) → (¬ ((g2709 E)=true)) → False
  intro c0 c1 c2 c5 c6
  apply h
  refine ⟨3,4,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 3, edge E 0 4, edge E 0 7]
    apply (mask_ge_two (edge E 0 3) (edge E 0 4) (edge E 0 7)).mp
    change (((g4 E) && (g5 E)) || ((g4 E) && (g8 E)) || ((g5 E) && (g8 E)))=true
    simpa [g2696, g2697, g2698, g2699, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 3, edge E 1 4, edge E 1 7]
    apply (mask_ge_two (edge E 1 3) (edge E 1 4) (edge E 1 7)).mp
    change (((g10 E) && (g11 E)) || ((g10 E) && (g14 E)) || ((g11 E) && (g14 E)))=true
    simpa [g2700, g2701, g2702, g2703, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 3, edge E 2 4, edge E 2 7]
    apply (mask_ge_two (edge E 2 3) (edge E 2 4) (edge E 2 7)).mp
    change (((g15 E) && (g16 E)) || ((g15 E) && (g19 E)) || ((g16 E) && (g19 E)))=true
    simpa [g2704, g2705, g2706, g2707, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 5 3, edge E 5 4, edge E 5 7]
    apply (mask_ge_one (edge E 5 3) (edge E 5 4) (edge E 5 7)).mp
    change ((g21 E) || (g24 E) || (g28 E))=true
    simpa [g2708, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 3, edge E 6 4, edge E 6 7]
    apply (mask_ge_one (edge E 6 3) (edge E 6 4) (edge E 6 7)).mp
    change ((g22 E) || (g25 E) || (g29 E))=true
    simpa [g2709, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_2429 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2712, .pos 2716, .pos 2720, .pos 2721, .pos 2722] := by
  change (¬ ((g2713 E)=true)) → (¬ ((g2717 E)=true)) → (¬ ((g2721 E)=true)) → (¬ ((g2722 E)=true)) → (¬ ((g2723 E)=true)) → False
  intro c0 c1 c2 c4 c7
  apply h
  refine ⟨3,5,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 3, edge E 0 5, edge E 0 6]
    apply (mask_ge_two (edge E 0 3) (edge E 0 5) (edge E 0 6)).mp
    change (((g4 E) && (g6 E)) || ((g4 E) && (g7 E)) || ((g6 E) && (g7 E)))=true
    simpa [g2710, g2711, g2712, g2713, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 3, edge E 1 5, edge E 1 6]
    apply (mask_ge_two (edge E 1 3) (edge E 1 5) (edge E 1 6)).mp
    change (((g10 E) && (g12 E)) || ((g10 E) && (g13 E)) || ((g12 E) && (g13 E)))=true
    simpa [g2714, g2715, g2716, g2717, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 3, edge E 2 5, edge E 2 6]
    apply (mask_ge_two (edge E 2 3) (edge E 2 5) (edge E 2 6)).mp
    change (((g15 E) && (g17 E)) || ((g15 E) && (g18 E)) || ((g17 E) && (g18 E)))=true
    simpa [g2718, g2719, g2720, g2721, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (va rfl).elim
  · change 1≤countTrue [edge E 4 3, edge E 4 5, edge E 4 6]
    apply (mask_ge_one (edge E 4 3) (edge E 4 5) (edge E 4 6)).mp
    change ((g20 E) || (g24 E) || (g25 E))=true
    simpa [g2722, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 3, edge E 7 5, edge E 7 6]
    apply (mask_ge_one (edge E 7 3) (edge E 7 5) (edge E 7 6)).mp
    change ((g23 E) || (g28 E) || (g29 E))=true
    simpa [g2723, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2448 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2726, .pos 2730, .pos 2734, .pos 2735, .pos 2736] := by
  change (¬ ((g2727 E)=true)) → (¬ ((g2731 E)=true)) → (¬ ((g2735 E)=true)) → (¬ ((g2736 E)=true)) → (¬ ((g2737 E)=true)) → False
  intro c0 c1 c2 c4 c6
  apply h
  refine ⟨3,5,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 3, edge E 0 5, edge E 0 7]
    apply (mask_ge_two (edge E 0 3) (edge E 0 5) (edge E 0 7)).mp
    change (((g4 E) && (g6 E)) || ((g4 E) && (g8 E)) || ((g6 E) && (g8 E)))=true
    simpa [g2724, g2725, g2726, g2727, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 3, edge E 1 5, edge E 1 7]
    apply (mask_ge_two (edge E 1 3) (edge E 1 5) (edge E 1 7)).mp
    change (((g10 E) && (g12 E)) || ((g10 E) && (g14 E)) || ((g12 E) && (g14 E)))=true
    simpa [g2728, g2729, g2730, g2731, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 3, edge E 2 5, edge E 2 7]
    apply (mask_ge_two (edge E 2 3) (edge E 2 5) (edge E 2 7)).mp
    change (((g15 E) && (g17 E)) || ((g15 E) && (g19 E)) || ((g17 E) && (g19 E)))=true
    simpa [g2732, g2733, g2734, g2735, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (va rfl).elim
  · change 1≤countTrue [edge E 4 3, edge E 4 5, edge E 4 7]
    apply (mask_ge_one (edge E 4 3) (edge E 4 5) (edge E 4 7)).mp
    change ((g20 E) || (g24 E) || (g26 E))=true
    simpa [g2736, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 6 3, edge E 6 5, edge E 6 7]
    apply (mask_ge_one (edge E 6 3) (edge E 6 5) (edge E 6 7)).mp
    change ((g22 E) || (g27 E) || (g29 E))=true
    simpa [g2737, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_2481 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2740, .pos 2744, .pos 2748, .pos 2749, .pos 2750] := by
  change (¬ ((g2741 E)=true)) → (¬ ((g2745 E)=true)) → (¬ ((g2749 E)=true)) → (¬ ((g2750 E)=true)) → (¬ ((g2751 E)=true)) → False
  intro c0 c1 c2 c4 c5
  apply h
  refine ⟨3,6,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 3, edge E 0 6, edge E 0 7]
    apply (mask_ge_two (edge E 0 3) (edge E 0 6) (edge E 0 7)).mp
    change (((g4 E) && (g7 E)) || ((g4 E) && (g8 E)) || ((g7 E) && (g8 E)))=true
    simpa [g2738, g2739, g2740, g2741, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 3, edge E 1 6, edge E 1 7]
    apply (mask_ge_two (edge E 1 3) (edge E 1 6) (edge E 1 7)).mp
    change (((g10 E) && (g13 E)) || ((g10 E) && (g14 E)) || ((g13 E) && (g14 E)))=true
    simpa [g2742, g2743, g2744, g2745, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 3, edge E 2 6, edge E 2 7]
    apply (mask_ge_two (edge E 2 3) (edge E 2 6) (edge E 2 7)).mp
    change (((g15 E) && (g18 E)) || ((g15 E) && (g19 E)) || ((g18 E) && (g19 E)))=true
    simpa [g2746, g2747, g2748, g2749, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (va rfl).elim
  · change 1≤countTrue [edge E 4 3, edge E 4 6, edge E 4 7]
    apply (mask_ge_one (edge E 4 3) (edge E 4 6) (edge E 4 7)).mp
    change ((g20 E) || (g25 E) || (g26 E))=true
    simpa [g2750, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 3, edge E 5 6, edge E 5 7]
    apply (mask_ge_one (edge E 5 3) (edge E 5 6) (edge E 5 7)).mp
    change ((g21 E) || (g27 E) || (g28 E))=true
    simpa [g2751, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
private theorem root_2497 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2771, .pos 2775, .pos 2779, .pos 2783, .pos 2784] := by
  change (¬ ((g2772 E)=true)) → (¬ ((g2776 E)=true)) → (¬ ((g2780 E)=true)) → (¬ ((g2784 E)=true)) → (¬ ((g2785 E)=true)) → False
  intro c0 c1 c2 c3 c6
  apply h
  refine ⟨4,5,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 4, edge E 0 5, edge E 0 7]
    apply (mask_ge_two (edge E 0 4) (edge E 0 5) (edge E 0 7)).mp
    change (((g5 E) && (g6 E)) || ((g5 E) && (g8 E)) || ((g6 E) && (g8 E)))=true
    simpa [g2769, g2770, g2771, g2772, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 4, edge E 1 5, edge E 1 7]
    apply (mask_ge_two (edge E 1 4) (edge E 1 5) (edge E 1 7)).mp
    change (((g11 E) && (g12 E)) || ((g11 E) && (g14 E)) || ((g12 E) && (g14 E)))=true
    simpa [g2773, g2774, g2775, g2776, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 4, edge E 2 5, edge E 2 7]
    apply (mask_ge_two (edge E 2 4) (edge E 2 5) (edge E 2 7)).mp
    change (((g16 E) && (g17 E)) || ((g16 E) && (g19 E)) || ((g17 E) && (g19 E)))=true
    simpa [g2777, g2778, g2779, g2780, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 4, edge E 3 5, edge E 3 7]
    apply (mask_ge_two (edge E 3 4) (edge E 3 5) (edge E 3 7)).mp
    change (((g20 E) && (g21 E)) || ((g20 E) && (g23 E)) || ((g21 E) && (g23 E)))=true
    simpa [g2781, g2782, g2783, g2784, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 6 4, edge E 6 5, edge E 6 7]
    apply (mask_ge_one (edge E 6 4) (edge E 6 5) (edge E 6 7)).mp
    change ((g25 E) || (g27 E) || (g29 E))=true
    simpa [g2785, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_2519 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2788, .pos 2792, .pos 2796, .pos 2800, .pos 2801] := by
  change (¬ ((g2789 E)=true)) → (¬ ((g2793 E)=true)) → (¬ ((g2797 E)=true)) → (¬ ((g2801 E)=true)) → (¬ ((g2802 E)=true)) → False
  intro c0 c1 c2 c3 c5
  apply h
  refine ⟨4,6,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 4, edge E 0 6, edge E 0 7]
    apply (mask_ge_two (edge E 0 4) (edge E 0 6) (edge E 0 7)).mp
    change (((g5 E) && (g7 E)) || ((g5 E) && (g8 E)) || ((g7 E) && (g8 E)))=true
    simpa [g2786, g2787, g2788, g2789, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 4, edge E 1 6, edge E 1 7]
    apply (mask_ge_two (edge E 1 4) (edge E 1 6) (edge E 1 7)).mp
    change (((g11 E) && (g13 E)) || ((g11 E) && (g14 E)) || ((g13 E) && (g14 E)))=true
    simpa [g2790, g2791, g2792, g2793, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 4, edge E 2 6, edge E 2 7]
    apply (mask_ge_two (edge E 2 4) (edge E 2 6) (edge E 2 7)).mp
    change (((g16 E) && (g18 E)) || ((g16 E) && (g19 E)) || ((g18 E) && (g19 E)))=true
    simpa [g2794, g2795, g2796, g2797, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 4, edge E 3 6, edge E 3 7]
    apply (mask_ge_two (edge E 3 4) (edge E 3 6) (edge E 3 7)).mp
    change (((g20 E) && (g22 E)) || ((g20 E) && (g23 E)) || ((g22 E) && (g23 E)))=true
    simpa [g2798, g2799, g2800, g2801, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (va rfl).elim
  · change 1≤countTrue [edge E 5 4, edge E 5 6, edge E 5 7]
    apply (mask_ge_one (edge E 5 4) (edge E 5 6) (edge E 5 7)).mp
    change ((g24 E) || (g27 E) || (g28 E))=true
    simpa [g2802, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
private theorem root_2564 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2805, .pos 2809, .pos 2813, .pos 2817, .pos 2818] := by
  change (¬ ((g2806 E)=true)) → (¬ ((g2810 E)=true)) → (¬ ((g2814 E)=true)) → (¬ ((g2818 E)=true)) → (¬ ((g2819 E)=true)) → False
  intro c0 c1 c2 c3 c4
  apply h
  refine ⟨5,6,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 5, edge E 0 6, edge E 0 7]
    apply (mask_ge_two (edge E 0 5) (edge E 0 6) (edge E 0 7)).mp
    change (((g6 E) && (g7 E)) || ((g6 E) && (g8 E)) || ((g7 E) && (g8 E)))=true
    simpa [g2803, g2804, g2805, g2806, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 5, edge E 1 6, edge E 1 7]
    apply (mask_ge_two (edge E 1 5) (edge E 1 6) (edge E 1 7)).mp
    change (((g12 E) && (g13 E)) || ((g12 E) && (g14 E)) || ((g13 E) && (g14 E)))=true
    simpa [g2807, g2808, g2809, g2810, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 5, edge E 2 6, edge E 2 7]
    apply (mask_ge_two (edge E 2 5) (edge E 2 6) (edge E 2 7)).mp
    change (((g17 E) && (g18 E)) || ((g17 E) && (g19 E)) || ((g18 E) && (g19 E)))=true
    simpa [g2811, g2812, g2813, g2814, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 5, edge E 3 6, edge E 3 7]
    apply (mask_ge_two (edge E 3 5) (edge E 3 6) (edge E 3 7)).mp
    change (((g21 E) && (g22 E)) || ((g21 E) && (g23 E)) || ((g22 E) && (g23 E)))=true
    simpa [g2815, g2816, g2817, g2818, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 5, edge E 4 6, edge E 4 7]
    apply (mask_ge_one (edge E 4 5) (edge E 4 6) (edge E 4 7)).mp
    change ((g24 E) || (g25 E) || (g26 E))=true
    simpa [g2819, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · exact (vc rfl).elim
theorem have_triple_of_exact_counts (E : Nat→Bool)
    (d0 : 3≤degree0_count E)
    (d1 : 3≤degree1_count E)
    (d2 : 3≤degree2_count E)
    (d3 : 3≤degree3_count E)
    (d4 : 3≤degree4_count E)
    (d5 : 3≤degree5_count E)
    (d6 : 3≤degree6_count E)
    (d7 : 3≤degree7_count E)
    (s0 : 2≤score0_count E)
    (o01 : score0_count E<score1_count E)
    (o12 : score1_count E<score2_count E)
    (o23 : score2_count E<score3_count E)
    (p45 : portRank E 4≤portRank E 5)
    (p56 : portRank E 5≤portRank E 6)
    (p67 : portRank E 6≤portRank E 7)
    : HasTriple E := by
  by_contra n
  apply contradiction_of_semantic_roots E
  · exact root_28 E d0
  · exact root_73 E d1
  · exact root_104 E d2
  · exact root_131 E d3
  · exact root_169 E d4
  · exact root_201 E d5
  · exact root_233 E d6
  · exact root_254 E d7
  · exact root_1484 E s0
  · exact root_1485 E o01
  · exact root_1486 E o01
  · exact root_1487 E o01
  · exact root_1488 E o01
  · exact root_1489 E o12
  · exact root_1490 E o12
  · exact root_1491 E o12
  · exact root_1492 E o12
  · exact root_1493 E o23
  · exact root_1494 E o23
  · exact root_1495 E o23
  · exact root_1496 E o23
  · exact root_1505 E p45
  · exact root_1515 E p56
  · exact root_1525 E p67
  · exact root_1553 E n
  · exact root_1575 E n
  · exact root_1600 E n
  · exact root_1620 E n
  · exact root_1636 E n
  · exact root_1661 E n
  · exact root_1685 E n
  · exact root_1704 E n
  · exact root_1722 E n
  · exact root_1739 E n
  · exact root_1757 E n
  · exact root_1775 E n
  · exact root_1797 E n
  · exact root_1820 E n
  · exact root_1851 E n
  · exact root_1872 E n
  · exact root_1885 E n
  · exact root_1901 E n
  · exact root_1912 E n
  · exact root_1932 E n
  · exact root_1958 E n
  · exact root_1985 E n
  · exact root_1998 E n
  · exact root_2020 E n
  · exact root_2050 E n
  · exact root_2080 E n
  · exact root_2090 E n
  · exact root_2108 E n
  · exact root_2134 E n
  · exact root_2155 E n
  · exact root_2164 E n
  · exact root_2175 E n
  · exact root_2187 E n
  · exact root_2204 E n
  · exact root_2226 E n
  · exact root_2243 E n
  · exact root_2251 E n
  · exact root_2268 E n
  · exact root_2297 E n
  · exact root_2333 E n
  · exact root_2342 E n
  · exact root_2359 E n
  · exact root_2374 E n
  · exact root_2411 E n
  · exact root_2420 E n
  · exact root_2429 E n
  · exact root_2448 E n
  · exact root_2481 E n
  · exact root_2497 E n
  · exact root_2519 E n
  · exact root_2564 E n
#print axioms have_triple_of_exact_counts
end Graffiti384b.DiversityEleven.PendantCircuit.K4
