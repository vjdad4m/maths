import DiversityElevenPendantWires4384b
import DiversityElevenPendantRupFour384b
namespace Graffiti384b.DiversityEleven.PendantCircuit.K4
open Sat
set_option maxRecDepth 32768
set_option maxHeartbeats 20000000

private theorem pattern_0 (x0 x1 : Bool) : (¬ (x0=true)) → (¬ (x1=true)) → (¬ (((!x1) && (!x0))=true)) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_0 (E : Nat → Bool) : (valuation E).satisfies [.pos 1, .pos 2, .pos 29] := by
  change (¬ (g2 E = true)) → (¬ (g3 E = true)) → (¬ (g30 E = true)) → False
  exact pattern_0 (g2 E) (g3 E)
private theorem pattern_1 (x0 x1 : Bool) : (((x0) && (x1))=true) → (¬ (x0=true)) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_1 (E : Nat → Bool) : (valuation E).satisfies [.neg 30, .pos 1] := by
  change (g31 E = true) → (¬ (g2 E = true)) → False
  exact pattern_1 (g2 E) (g3 E)
private theorem pattern_2 (x0 x1 : Bool) : (((x0) && (x1))=true) → (¬ (x1=true)) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_2 (E : Nat → Bool) : (valuation E).satisfies [.neg 30, .pos 2] := by
  change (g31 E = true) → (¬ (g3 E = true)) → False
  exact pattern_2 (g2 E) (g3 E)
private theorem pattern_3 (x0 x1 : Bool) : (x1=true) → (¬ (x0=true)) → (¬ (((!x0) && (x1))=true)) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_3 (E : Nat → Bool) : (valuation E).satisfies [.neg 29, .pos 3, .pos 31] := by
  change (g30 E = true) → (¬ (g4 E = true)) → (¬ (g32 E = true)) → False
  exact pattern_3 (g4 E) (g30 E)
private theorem pattern_4 (x0 x1 : Bool) : (((!x1) && (x0))=true) → (x1=true) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_4 (E : Nat → Bool) : (valuation E).satisfies [.neg 32, .neg 29] := by
  change (g33 E = true) → (g30 E = true) → False
  exact pattern_4 (g4 E) (g30 E)
private theorem pattern_5 (x0 x1 : Bool) : (((!x1) && (x0))=true) → (¬ (x0=true)) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_5 (E : Nat → Bool) : (valuation E).satisfies [.neg 32, .pos 3] := by
  change (g33 E = true) → (¬ (g4 E = true)) → False
  exact pattern_5 (g4 E) (g30 E)
private theorem sat_6 (E : Nat → Bool) : (valuation E).satisfies [.pos 30, .pos 32, .pos 33] := by
  change (¬ (g31 E = true)) → (¬ (g33 E = true)) → (¬ (g34 E = true)) → False
  exact pattern_0 (g31 E) (g33 E)
private theorem sat_7 (E : Nat → Bool) : (valuation E).satisfies [.neg 34, .pos 3] := by
  change (g35 E = true) → (¬ (g4 E = true)) → False
  exact pattern_1 (g4 E) (g31 E)
private theorem sat_8 (E : Nat → Bool) : (valuation E).satisfies [.neg 34, .pos 30] := by
  change (g35 E = true) → (¬ (g31 E = true)) → False
  exact pattern_2 (g4 E) (g31 E)
private theorem sat_9 (E : Nat → Bool) : (valuation E).satisfies [.neg 31, .pos 4, .pos 35] := by
  change (g32 E = true) → (¬ (g5 E = true)) → (¬ (g36 E = true)) → False
  exact pattern_3 (g5 E) (g32 E)
private theorem sat_10 (E : Nat → Bool) : (valuation E).satisfies [.neg 36, .pos 4] := by
  change (g37 E = true) → (¬ (g5 E = true)) → False
  exact pattern_5 (g5 E) (g32 E)
private theorem pattern_6 (x0 x1 : Bool) : (x0=true) → (¬ (x1=true)) → (¬ (((!x1) && (x0))=true)) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_11 (E : Nat → Bool) : (valuation E).satisfies [.neg 33, .pos 36, .pos 37] := by
  change (g34 E = true) → (¬ (g37 E = true)) → (¬ (g38 E = true)) → False
  exact pattern_6 (g34 E) (g37 E)
private theorem sat_12 (E : Nat → Bool) : (valuation E).satisfies [.neg 38, .pos 4] := by
  change (g39 E = true) → (¬ (g5 E = true)) → False
  exact pattern_5 (g5 E) (g34 E)
private theorem sat_13 (E : Nat → Bool) : (valuation E).satisfies [.pos 34, .pos 38, .pos 39] := by
  change (¬ (g35 E = true)) → (¬ (g39 E = true)) → (¬ (g40 E = true)) → False
  exact pattern_0 (g35 E) (g39 E)
private theorem sat_14 (E : Nat → Bool) : (valuation E).satisfies [.neg 35, .pos 5, .pos 41] := by
  change (g36 E = true) → (¬ (g6 E = true)) → (¬ (g42 E = true)) → False
  exact pattern_3 (g6 E) (g36 E)
private theorem sat_15 (E : Nat → Bool) : (valuation E).satisfies [.neg 42, .pos 5] := by
  change (g43 E = true) → (¬ (g6 E = true)) → False
  exact pattern_5 (g6 E) (g36 E)
private theorem sat_16 (E : Nat → Bool) : (valuation E).satisfies [.neg 37, .pos 42, .pos 43] := by
  change (g38 E = true) → (¬ (g43 E = true)) → (¬ (g44 E = true)) → False
  exact pattern_6 (g38 E) (g43 E)
private theorem sat_17 (E : Nat → Bool) : (valuation E).satisfies [.neg 44, .pos 5] := by
  change (g45 E = true) → (¬ (g6 E = true)) → False
  exact pattern_5 (g6 E) (g38 E)
private theorem sat_18 (E : Nat → Bool) : (valuation E).satisfies [.neg 39, .pos 44, .pos 45] := by
  change (g40 E = true) → (¬ (g45 E = true)) → (¬ (g46 E = true)) → False
  exact pattern_6 (g40 E) (g45 E)
private theorem sat_19 (E : Nat → Bool) : (valuation E).satisfies [.neg 50, .neg 41] := by
  change (g51 E = true) → (g42 E = true) → False
  exact pattern_4 (g7 E) (g42 E)
private theorem sat_20 (E : Nat → Bool) : (valuation E).satisfies [.neg 50, .pos 6] := by
  change (g51 E = true) → (¬ (g7 E = true)) → False
  exact pattern_5 (g7 E) (g42 E)
private theorem sat_21 (E : Nat → Bool) : (valuation E).satisfies [.neg 43, .pos 50, .pos 51] := by
  change (g44 E = true) → (¬ (g51 E = true)) → (¬ (g52 E = true)) → False
  exact pattern_6 (g44 E) (g51 E)
private theorem sat_22 (E : Nat → Bool) : (valuation E).satisfies [.neg 52, .neg 43] := by
  change (g53 E = true) → (g44 E = true) → False
  exact pattern_4 (g7 E) (g44 E)
private theorem sat_23 (E : Nat → Bool) : (valuation E).satisfies [.neg 52, .pos 6] := by
  change (g53 E = true) → (¬ (g7 E = true)) → False
  exact pattern_5 (g7 E) (g44 E)
private theorem sat_24 (E : Nat → Bool) : (valuation E).satisfies [.neg 45, .pos 52, .pos 53] := by
  change (g46 E = true) → (¬ (g53 E = true)) → (¬ (g54 E = true)) → False
  exact pattern_6 (g46 E) (g53 E)
private theorem sat_25 (E : Nat → Bool) : (valuation E).satisfies [.neg 62, .neg 51] := by
  change (g63 E = true) → (g52 E = true) → False
  exact pattern_4 (g8 E) (g52 E)
private theorem sat_26 (E : Nat → Bool) : (valuation E).satisfies [.neg 62, .pos 7] := by
  change (g63 E = true) → (¬ (g8 E = true)) → False
  exact pattern_5 (g8 E) (g52 E)
private theorem sat_27 (E : Nat → Bool) : (valuation E).satisfies [.neg 53, .pos 62, .pos 63] := by
  change (g54 E = true) → (¬ (g63 E = true)) → (¬ (g64 E = true)) → False
  exact pattern_6 (g54 E) (g63 E)
private theorem pattern_7 (x0 x1 : Bool) : (((!x1) && (!x0))=true) → (x0=true) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_29 (E : Nat → Bool) : (valuation E).satisfies [.neg 71, .neg 1] := by
  change (g72 E = true) → (g2 E = true) → False
  exact pattern_7 (g2 E) (g9 E)
private theorem sat_30 (E : Nat → Bool) : (valuation E).satisfies [.pos 1, .pos 8, .pos 71] := by
  change (¬ (g2 E = true)) → (¬ (g9 E = true)) → (¬ (g72 E = true)) → False
  exact pattern_0 (g2 E) (g9 E)
private theorem sat_31 (E : Nat → Bool) : (valuation E).satisfies [.neg 72, .pos 1] := by
  change (g73 E = true) → (¬ (g2 E = true)) → False
  exact pattern_1 (g2 E) (g9 E)
private theorem sat_32 (E : Nat → Bool) : (valuation E).satisfies [.neg 72, .pos 8] := by
  change (g73 E = true) → (¬ (g9 E = true)) → False
  exact pattern_2 (g2 E) (g9 E)
private theorem pattern_8 (x0 x1 : Bool) : (((!x0) && (x1))=true) → (x0=true) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_33 (E : Nat → Bool) : (valuation E).satisfies [.neg 73, .neg 9] := by
  change (g74 E = true) → (g10 E = true) → False
  exact pattern_8 (g10 E) (g72 E)
private theorem sat_34 (E : Nat → Bool) : (valuation E).satisfies [.neg 71, .pos 9, .pos 73] := by
  change (g72 E = true) → (¬ (g10 E = true)) → (¬ (g74 E = true)) → False
  exact pattern_3 (g10 E) (g72 E)
private theorem sat_35 (E : Nat → Bool) : (valuation E).satisfies [.neg 74, .neg 71] := by
  change (g75 E = true) → (g72 E = true) → False
  exact pattern_4 (g10 E) (g72 E)
private theorem sat_36 (E : Nat → Bool) : (valuation E).satisfies [.neg 74, .pos 9] := by
  change (g75 E = true) → (¬ (g10 E = true)) → False
  exact pattern_5 (g10 E) (g72 E)
private theorem sat_37 (E : Nat → Bool) : (valuation E).satisfies [.neg 9, .pos 71, .pos 74] := by
  change (g10 E = true) → (¬ (g72 E = true)) → (¬ (g75 E = true)) → False
  exact pattern_6 (g10 E) (g72 E)
private theorem pattern_9 (x0 x1 : Bool) : (((!x1) && (!x0))=true) → (x1=true) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_38 (E : Nat → Bool) : (valuation E).satisfies [.neg 75, .neg 74] := by
  change (g76 E = true) → (g75 E = true) → False
  exact pattern_9 (g73 E) (g75 E)
private theorem sat_39 (E : Nat → Bool) : (valuation E).satisfies [.pos 72, .pos 74, .pos 75] := by
  change (¬ (g73 E = true)) → (¬ (g75 E = true)) → (¬ (g76 E = true)) → False
  exact pattern_0 (g73 E) (g75 E)
private theorem sat_40 (E : Nat → Bool) : (valuation E).satisfies [.neg 76, .pos 9] := by
  change (g77 E = true) → (¬ (g10 E = true)) → False
  exact pattern_1 (g10 E) (g73 E)
private theorem sat_41 (E : Nat → Bool) : (valuation E).satisfies [.neg 76, .pos 72] := by
  change (g77 E = true) → (¬ (g73 E = true)) → False
  exact pattern_2 (g10 E) (g73 E)
private theorem sat_42 (E : Nat → Bool) : (valuation E).satisfies [.neg 73, .pos 10, .pos 77] := by
  change (g74 E = true) → (¬ (g11 E = true)) → (¬ (g78 E = true)) → False
  exact pattern_3 (g11 E) (g74 E)
private theorem sat_43 (E : Nat → Bool) : (valuation E).satisfies [.neg 78, .neg 73] := by
  change (g79 E = true) → (g74 E = true) → False
  exact pattern_4 (g11 E) (g74 E)
private theorem sat_44 (E : Nat → Bool) : (valuation E).satisfies [.neg 78, .pos 10] := by
  change (g79 E = true) → (¬ (g11 E = true)) → False
  exact pattern_5 (g11 E) (g74 E)
private theorem sat_45 (E : Nat → Bool) : (valuation E).satisfies [.neg 10, .pos 73, .pos 78] := by
  change (g11 E = true) → (¬ (g74 E = true)) → (¬ (g79 E = true)) → False
  exact pattern_6 (g11 E) (g74 E)
private theorem sat_46 (E : Nat → Bool) : (valuation E).satisfies [.neg 79, .neg 78] := by
  change (g80 E = true) → (g79 E = true) → False
  exact pattern_4 (g76 E) (g79 E)
private theorem sat_47 (E : Nat → Bool) : (valuation E).satisfies [.neg 79, .pos 75] := by
  change (g80 E = true) → (¬ (g76 E = true)) → False
  exact pattern_5 (g76 E) (g79 E)
private theorem sat_48 (E : Nat → Bool) : (valuation E).satisfies [.neg 75, .pos 78, .pos 79] := by
  change (g76 E = true) → (¬ (g79 E = true)) → (¬ (g80 E = true)) → False
  exact pattern_6 (g76 E) (g79 E)
private theorem sat_49 (E : Nat → Bool) : (valuation E).satisfies [.neg 80, .neg 75] := by
  change (g81 E = true) → (g76 E = true) → False
  exact pattern_4 (g11 E) (g76 E)
private theorem sat_50 (E : Nat → Bool) : (valuation E).satisfies [.neg 80, .pos 10] := by
  change (g81 E = true) → (¬ (g11 E = true)) → False
  exact pattern_5 (g11 E) (g76 E)
private theorem sat_51 (E : Nat → Bool) : (valuation E).satisfies [.neg 10, .pos 75, .pos 80] := by
  change (g11 E = true) → (¬ (g76 E = true)) → (¬ (g81 E = true)) → False
  exact pattern_6 (g11 E) (g76 E)
private theorem sat_52 (E : Nat → Bool) : (valuation E).satisfies [.neg 81, .neg 80] := by
  change (g82 E = true) → (g81 E = true) → False
  exact pattern_9 (g77 E) (g81 E)
private theorem sat_53 (E : Nat → Bool) : (valuation E).satisfies [.pos 76, .pos 80, .pos 81] := by
  change (¬ (g77 E = true)) → (¬ (g81 E = true)) → (¬ (g82 E = true)) → False
  exact pattern_0 (g77 E) (g81 E)
private theorem sat_54 (E : Nat → Bool) : (valuation E).satisfies [.neg 77, .pos 11, .pos 83] := by
  change (g78 E = true) → (¬ (g12 E = true)) → (¬ (g84 E = true)) → False
  exact pattern_3 (g12 E) (g78 E)
private theorem sat_55 (E : Nat → Bool) : (valuation E).satisfies [.neg 84, .neg 77] := by
  change (g85 E = true) → (g78 E = true) → False
  exact pattern_4 (g12 E) (g78 E)
private theorem sat_56 (E : Nat → Bool) : (valuation E).satisfies [.neg 84, .pos 11] := by
  change (g85 E = true) → (¬ (g12 E = true)) → False
  exact pattern_5 (g12 E) (g78 E)
private theorem sat_57 (E : Nat → Bool) : (valuation E).satisfies [.neg 79, .pos 84, .pos 85] := by
  change (g80 E = true) → (¬ (g85 E = true)) → (¬ (g86 E = true)) → False
  exact pattern_6 (g80 E) (g85 E)
private theorem sat_58 (E : Nat → Bool) : (valuation E).satisfies [.neg 86, .neg 79] := by
  change (g87 E = true) → (g80 E = true) → False
  exact pattern_4 (g12 E) (g80 E)
private theorem sat_59 (E : Nat → Bool) : (valuation E).satisfies [.neg 86, .pos 11] := by
  change (g87 E = true) → (¬ (g12 E = true)) → False
  exact pattern_5 (g12 E) (g80 E)
private theorem sat_60 (E : Nat → Bool) : (valuation E).satisfies [.neg 11, .pos 79, .pos 86] := by
  change (g12 E = true) → (¬ (g80 E = true)) → (¬ (g87 E = true)) → False
  exact pattern_6 (g12 E) (g80 E)
private theorem sat_61 (E : Nat → Bool) : (valuation E).satisfies [.neg 87, .neg 86] := by
  change (g88 E = true) → (g87 E = true) → False
  exact pattern_4 (g82 E) (g87 E)
private theorem sat_62 (E : Nat → Bool) : (valuation E).satisfies [.neg 87, .pos 81] := by
  change (g88 E = true) → (¬ (g82 E = true)) → False
  exact pattern_5 (g82 E) (g87 E)
private theorem sat_63 (E : Nat → Bool) : (valuation E).satisfies [.neg 81, .pos 86, .pos 87] := by
  change (g82 E = true) → (¬ (g87 E = true)) → (¬ (g88 E = true)) → False
  exact pattern_6 (g82 E) (g87 E)
private theorem sat_64 (E : Nat → Bool) : (valuation E).satisfies [.neg 92, .neg 83] := by
  change (g93 E = true) → (g84 E = true) → False
  exact pattern_4 (g13 E) (g84 E)
private theorem sat_65 (E : Nat → Bool) : (valuation E).satisfies [.neg 92, .pos 12] := by
  change (g93 E = true) → (¬ (g13 E = true)) → False
  exact pattern_5 (g13 E) (g84 E)
private theorem sat_66 (E : Nat → Bool) : (valuation E).satisfies [.neg 85, .pos 92, .pos 93] := by
  change (g86 E = true) → (¬ (g93 E = true)) → (¬ (g94 E = true)) → False
  exact pattern_6 (g86 E) (g93 E)
private theorem sat_67 (E : Nat → Bool) : (valuation E).satisfies [.neg 94, .neg 85] := by
  change (g95 E = true) → (g86 E = true) → False
  exact pattern_4 (g13 E) (g86 E)
private theorem sat_68 (E : Nat → Bool) : (valuation E).satisfies [.neg 94, .pos 12] := by
  change (g95 E = true) → (¬ (g13 E = true)) → False
  exact pattern_5 (g13 E) (g86 E)
private theorem sat_69 (E : Nat → Bool) : (valuation E).satisfies [.neg 87, .pos 94, .pos 95] := by
  change (g88 E = true) → (¬ (g95 E = true)) → (¬ (g96 E = true)) → False
  exact pattern_6 (g88 E) (g95 E)
private theorem sat_70 (E : Nat → Bool) : (valuation E).satisfies [.neg 104, .neg 93] := by
  change (g105 E = true) → (g94 E = true) → False
  exact pattern_4 (g14 E) (g94 E)
private theorem sat_71 (E : Nat → Bool) : (valuation E).satisfies [.neg 104, .pos 13] := by
  change (g105 E = true) → (¬ (g14 E = true)) → False
  exact pattern_5 (g14 E) (g94 E)
private theorem sat_72 (E : Nat → Bool) : (valuation E).satisfies [.neg 95, .pos 104, .pos 105] := by
  change (g96 E = true) → (¬ (g105 E = true)) → (¬ (g106 E = true)) → False
  exact pattern_6 (g96 E) (g105 E)
private theorem sat_74 (E : Nat → Bool) : (valuation E).satisfies [.pos 2, .pos 8, .pos 113] := by
  change (¬ (g3 E = true)) → (¬ (g9 E = true)) → (¬ (g114 E = true)) → False
  exact pattern_0 (g3 E) (g9 E)
private theorem sat_75 (E : Nat → Bool) : (valuation E).satisfies [.neg 114, .pos 2] := by
  change (g115 E = true) → (¬ (g3 E = true)) → False
  exact pattern_1 (g3 E) (g9 E)
private theorem sat_76 (E : Nat → Bool) : (valuation E).satisfies [.neg 114, .pos 8] := by
  change (g115 E = true) → (¬ (g9 E = true)) → False
  exact pattern_2 (g3 E) (g9 E)
private theorem sat_77 (E : Nat → Bool) : (valuation E).satisfies [.neg 113, .pos 14, .pos 115] := by
  change (g114 E = true) → (¬ (g15 E = true)) → (¬ (g116 E = true)) → False
  exact pattern_3 (g15 E) (g114 E)
private theorem sat_78 (E : Nat → Bool) : (valuation E).satisfies [.neg 116, .neg 113] := by
  change (g117 E = true) → (g114 E = true) → False
  exact pattern_4 (g15 E) (g114 E)
private theorem sat_79 (E : Nat → Bool) : (valuation E).satisfies [.neg 116, .pos 14] := by
  change (g117 E = true) → (¬ (g15 E = true)) → False
  exact pattern_5 (g15 E) (g114 E)
private theorem sat_80 (E : Nat → Bool) : (valuation E).satisfies [.pos 114, .pos 116, .pos 117] := by
  change (¬ (g115 E = true)) → (¬ (g117 E = true)) → (¬ (g118 E = true)) → False
  exact pattern_0 (g115 E) (g117 E)
private theorem sat_81 (E : Nat → Bool) : (valuation E).satisfies [.neg 118, .pos 14] := by
  change (g119 E = true) → (¬ (g15 E = true)) → False
  exact pattern_1 (g15 E) (g115 E)
private theorem sat_82 (E : Nat → Bool) : (valuation E).satisfies [.neg 118, .pos 114] := by
  change (g119 E = true) → (¬ (g115 E = true)) → False
  exact pattern_2 (g15 E) (g115 E)
private theorem sat_83 (E : Nat → Bool) : (valuation E).satisfies [.neg 115, .pos 15, .pos 119] := by
  change (g116 E = true) → (¬ (g16 E = true)) → (¬ (g120 E = true)) → False
  exact pattern_3 (g16 E) (g116 E)
private theorem sat_84 (E : Nat → Bool) : (valuation E).satisfies [.neg 120, .neg 115] := by
  change (g121 E = true) → (g116 E = true) → False
  exact pattern_4 (g16 E) (g116 E)
private theorem sat_85 (E : Nat → Bool) : (valuation E).satisfies [.neg 120, .pos 15] := by
  change (g121 E = true) → (¬ (g16 E = true)) → False
  exact pattern_5 (g16 E) (g116 E)
private theorem sat_86 (E : Nat → Bool) : (valuation E).satisfies [.neg 117, .pos 120, .pos 121] := by
  change (g118 E = true) → (¬ (g121 E = true)) → (¬ (g122 E = true)) → False
  exact pattern_6 (g118 E) (g121 E)
private theorem sat_87 (E : Nat → Bool) : (valuation E).satisfies [.neg 122, .neg 117] := by
  change (g123 E = true) → (g118 E = true) → False
  exact pattern_4 (g16 E) (g118 E)
private theorem sat_88 (E : Nat → Bool) : (valuation E).satisfies [.neg 122, .pos 15] := by
  change (g123 E = true) → (¬ (g16 E = true)) → False
  exact pattern_5 (g16 E) (g118 E)
private theorem sat_89 (E : Nat → Bool) : (valuation E).satisfies [.pos 118, .pos 122, .pos 123] := by
  change (¬ (g119 E = true)) → (¬ (g123 E = true)) → (¬ (g124 E = true)) → False
  exact pattern_0 (g119 E) (g123 E)
private theorem sat_90 (E : Nat → Bool) : (valuation E).satisfies [.neg 126, .neg 119] := by
  change (g127 E = true) → (g120 E = true) → False
  exact pattern_4 (g17 E) (g120 E)
private theorem sat_91 (E : Nat → Bool) : (valuation E).satisfies [.neg 126, .pos 16] := by
  change (g127 E = true) → (¬ (g17 E = true)) → False
  exact pattern_5 (g17 E) (g120 E)
private theorem sat_92 (E : Nat → Bool) : (valuation E).satisfies [.neg 121, .pos 126, .pos 127] := by
  change (g122 E = true) → (¬ (g127 E = true)) → (¬ (g128 E = true)) → False
  exact pattern_6 (g122 E) (g127 E)
private theorem sat_93 (E : Nat → Bool) : (valuation E).satisfies [.neg 128, .neg 121] := by
  change (g129 E = true) → (g122 E = true) → False
  exact pattern_4 (g17 E) (g122 E)
private theorem sat_94 (E : Nat → Bool) : (valuation E).satisfies [.neg 128, .pos 16] := by
  change (g129 E = true) → (¬ (g17 E = true)) → False
  exact pattern_5 (g17 E) (g122 E)
private theorem sat_95 (E : Nat → Bool) : (valuation E).satisfies [.neg 123, .pos 128, .pos 129] := by
  change (g124 E = true) → (¬ (g129 E = true)) → (¬ (g130 E = true)) → False
  exact pattern_6 (g124 E) (g129 E)
private theorem sat_96 (E : Nat → Bool) : (valuation E).satisfies [.neg 134, .pos 17] := by
  change (g135 E = true) → (¬ (g18 E = true)) → False
  exact pattern_5 (g18 E) (g126 E)
private theorem sat_97 (E : Nat → Bool) : (valuation E).satisfies [.neg 127, .pos 134, .pos 135] := by
  change (g128 E = true) → (¬ (g135 E = true)) → (¬ (g136 E = true)) → False
  exact pattern_6 (g128 E) (g135 E)
private theorem sat_98 (E : Nat → Bool) : (valuation E).satisfies [.neg 136, .neg 127] := by
  change (g137 E = true) → (g128 E = true) → False
  exact pattern_4 (g18 E) (g128 E)
private theorem sat_99 (E : Nat → Bool) : (valuation E).satisfies [.neg 136, .pos 17] := by
  change (g137 E = true) → (¬ (g18 E = true)) → False
  exact pattern_5 (g18 E) (g128 E)
private theorem sat_100 (E : Nat → Bool) : (valuation E).satisfies [.neg 129, .pos 136, .pos 137] := by
  change (g130 E = true) → (¬ (g137 E = true)) → (¬ (g138 E = true)) → False
  exact pattern_6 (g130 E) (g137 E)
private theorem sat_101 (E : Nat → Bool) : (valuation E).satisfies [.neg 146, .neg 135] := by
  change (g147 E = true) → (g136 E = true) → False
  exact pattern_4 (g19 E) (g136 E)
private theorem sat_102 (E : Nat → Bool) : (valuation E).satisfies [.neg 146, .pos 18] := by
  change (g147 E = true) → (¬ (g19 E = true)) → False
  exact pattern_5 (g19 E) (g136 E)
private theorem sat_103 (E : Nat → Bool) : (valuation E).satisfies [.neg 137, .pos 146, .pos 147] := by
  change (g138 E = true) → (¬ (g147 E = true)) → (¬ (g148 E = true)) → False
  exact pattern_6 (g138 E) (g147 E)
private theorem sat_105 (E : Nat → Bool) : (valuation E).satisfies [.pos 3, .pos 9, .pos 155] := by
  change (¬ (g4 E = true)) → (¬ (g10 E = true)) → (¬ (g156 E = true)) → False
  exact pattern_0 (g4 E) (g10 E)
private theorem sat_106 (E : Nat → Bool) : (valuation E).satisfies [.neg 156, .pos 9] := by
  change (g157 E = true) → (¬ (g10 E = true)) → False
  exact pattern_2 (g4 E) (g10 E)
private theorem sat_107 (E : Nat → Bool) : (valuation E).satisfies [.neg 155, .pos 14, .pos 157] := by
  change (g156 E = true) → (¬ (g15 E = true)) → (¬ (g158 E = true)) → False
  exact pattern_3 (g15 E) (g156 E)
private theorem sat_108 (E : Nat → Bool) : (valuation E).satisfies [.neg 158, .neg 155] := by
  change (g159 E = true) → (g156 E = true) → False
  exact pattern_4 (g15 E) (g156 E)
private theorem sat_109 (E : Nat → Bool) : (valuation E).satisfies [.neg 158, .pos 14] := by
  change (g159 E = true) → (¬ (g15 E = true)) → False
  exact pattern_5 (g15 E) (g156 E)
private theorem sat_110 (E : Nat → Bool) : (valuation E).satisfies [.pos 156, .pos 158, .pos 159] := by
  change (¬ (g157 E = true)) → (¬ (g159 E = true)) → (¬ (g160 E = true)) → False
  exact pattern_0 (g157 E) (g159 E)
private theorem sat_111 (E : Nat → Bool) : (valuation E).satisfies [.neg 160, .pos 14] := by
  change (g161 E = true) → (¬ (g15 E = true)) → False
  exact pattern_1 (g15 E) (g157 E)
private theorem sat_112 (E : Nat → Bool) : (valuation E).satisfies [.neg 160, .pos 156] := by
  change (g161 E = true) → (¬ (g157 E = true)) → False
  exact pattern_2 (g15 E) (g157 E)
private theorem sat_113 (E : Nat → Bool) : (valuation E).satisfies [.neg 157, .pos 19, .pos 161] := by
  change (g158 E = true) → (¬ (g20 E = true)) → (¬ (g162 E = true)) → False
  exact pattern_3 (g20 E) (g158 E)
private theorem sat_114 (E : Nat → Bool) : (valuation E).satisfies [.neg 162, .neg 157] := by
  change (g163 E = true) → (g158 E = true) → False
  exact pattern_4 (g20 E) (g158 E)
private theorem sat_115 (E : Nat → Bool) : (valuation E).satisfies [.neg 162, .pos 19] := by
  change (g163 E = true) → (¬ (g20 E = true)) → False
  exact pattern_5 (g20 E) (g158 E)
private theorem sat_116 (E : Nat → Bool) : (valuation E).satisfies [.neg 159, .pos 162, .pos 163] := by
  change (g160 E = true) → (¬ (g163 E = true)) → (¬ (g164 E = true)) → False
  exact pattern_6 (g160 E) (g163 E)
private theorem sat_117 (E : Nat → Bool) : (valuation E).satisfies [.neg 164, .neg 159] := by
  change (g165 E = true) → (g160 E = true) → False
  exact pattern_4 (g20 E) (g160 E)
private theorem sat_118 (E : Nat → Bool) : (valuation E).satisfies [.neg 164, .pos 19] := by
  change (g165 E = true) → (¬ (g20 E = true)) → False
  exact pattern_5 (g20 E) (g160 E)
private theorem sat_119 (E : Nat → Bool) : (valuation E).satisfies [.pos 160, .pos 164, .pos 165] := by
  change (¬ (g161 E = true)) → (¬ (g165 E = true)) → (¬ (g166 E = true)) → False
  exact pattern_0 (g161 E) (g165 E)
private theorem sat_120 (E : Nat → Bool) : (valuation E).satisfies [.neg 168, .neg 161] := by
  change (g169 E = true) → (g162 E = true) → False
  exact pattern_4 (g21 E) (g162 E)
private theorem sat_121 (E : Nat → Bool) : (valuation E).satisfies [.neg 163, .pos 168, .pos 169] := by
  change (g164 E = true) → (¬ (g169 E = true)) → (¬ (g170 E = true)) → False
  exact pattern_6 (g164 E) (g169 E)
private theorem sat_122 (E : Nat → Bool) : (valuation E).satisfies [.neg 170, .neg 163] := by
  change (g171 E = true) → (g164 E = true) → False
  exact pattern_4 (g21 E) (g164 E)
private theorem sat_123 (E : Nat → Bool) : (valuation E).satisfies [.neg 165, .pos 170, .pos 171] := by
  change (g166 E = true) → (¬ (g171 E = true)) → (¬ (g172 E = true)) → False
  exact pattern_6 (g166 E) (g171 E)
private theorem sat_124 (E : Nat → Bool) : (valuation E).satisfies [.neg 176, .pos 21] := by
  change (g177 E = true) → (¬ (g22 E = true)) → False
  exact pattern_5 (g22 E) (g168 E)
private theorem sat_125 (E : Nat → Bool) : (valuation E).satisfies [.neg 169, .pos 176, .pos 177] := by
  change (g170 E = true) → (¬ (g177 E = true)) → (¬ (g178 E = true)) → False
  exact pattern_6 (g170 E) (g177 E)
private theorem sat_126 (E : Nat → Bool) : (valuation E).satisfies [.neg 178, .pos 21] := by
  change (g179 E = true) → (¬ (g22 E = true)) → False
  exact pattern_5 (g22 E) (g170 E)
private theorem sat_127 (E : Nat → Bool) : (valuation E).satisfies [.neg 171, .pos 178, .pos 179] := by
  change (g172 E = true) → (¬ (g179 E = true)) → (¬ (g180 E = true)) → False
  exact pattern_6 (g172 E) (g179 E)
private theorem sat_128 (E : Nat → Bool) : (valuation E).satisfies [.neg 188, .neg 177] := by
  change (g189 E = true) → (g178 E = true) → False
  exact pattern_4 (g23 E) (g178 E)
private theorem sat_129 (E : Nat → Bool) : (valuation E).satisfies [.neg 188, .pos 22] := by
  change (g189 E = true) → (¬ (g23 E = true)) → False
  exact pattern_5 (g23 E) (g178 E)
private theorem sat_130 (E : Nat → Bool) : (valuation E).satisfies [.neg 179, .pos 188, .pos 189] := by
  change (g180 E = true) → (¬ (g189 E = true)) → (¬ (g190 E = true)) → False
  exact pattern_6 (g180 E) (g189 E)
private theorem sat_132 (E : Nat → Bool) : (valuation E).satisfies [.neg 197, .neg 10] := by
  change (g198 E = true) → (g11 E = true) → False
  exact pattern_9 (g5 E) (g11 E)
private theorem sat_133 (E : Nat → Bool) : (valuation E).satisfies [.pos 4, .pos 10, .pos 197] := by
  change (¬ (g5 E = true)) → (¬ (g11 E = true)) → (¬ (g198 E = true)) → False
  exact pattern_0 (g5 E) (g11 E)
private theorem sat_134 (E : Nat → Bool) : (valuation E).satisfies [.neg 198, .pos 4] := by
  change (g199 E = true) → (¬ (g5 E = true)) → False
  exact pattern_1 (g5 E) (g11 E)
private theorem sat_135 (E : Nat → Bool) : (valuation E).satisfies [.neg 198, .pos 10] := by
  change (g199 E = true) → (¬ (g11 E = true)) → False
  exact pattern_2 (g5 E) (g11 E)
private theorem sat_136 (E : Nat → Bool) : (valuation E).satisfies [.neg 199, .neg 15] := by
  change (g200 E = true) → (g16 E = true) → False
  exact pattern_8 (g16 E) (g198 E)
private theorem pattern_10 (x0 x1 : Bool) : (((!x0) && (x1))=true) → (¬ (x1=true)) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_137 (E : Nat → Bool) : (valuation E).satisfies [.neg 199, .pos 197] := by
  change (g200 E = true) → (¬ (g198 E = true)) → False
  exact pattern_10 (g16 E) (g198 E)
private theorem sat_138 (E : Nat → Bool) : (valuation E).satisfies [.neg 197, .pos 15, .pos 199] := by
  change (g198 E = true) → (¬ (g16 E = true)) → (¬ (g200 E = true)) → False
  exact pattern_3 (g16 E) (g198 E)
private theorem sat_139 (E : Nat → Bool) : (valuation E).satisfies [.neg 200, .neg 197] := by
  change (g201 E = true) → (g198 E = true) → False
  exact pattern_4 (g16 E) (g198 E)
private theorem sat_140 (E : Nat → Bool) : (valuation E).satisfies [.neg 200, .pos 15] := by
  change (g201 E = true) → (¬ (g16 E = true)) → False
  exact pattern_5 (g16 E) (g198 E)
private theorem sat_141 (E : Nat → Bool) : (valuation E).satisfies [.neg 15, .pos 197, .pos 200] := by
  change (g16 E = true) → (¬ (g198 E = true)) → (¬ (g201 E = true)) → False
  exact pattern_6 (g16 E) (g198 E)
private theorem sat_142 (E : Nat → Bool) : (valuation E).satisfies [.pos 198, .pos 200, .pos 201] := by
  change (¬ (g199 E = true)) → (¬ (g201 E = true)) → (¬ (g202 E = true)) → False
  exact pattern_0 (g199 E) (g201 E)
private theorem sat_143 (E : Nat → Bool) : (valuation E).satisfies [.neg 202, .pos 15] := by
  change (g203 E = true) → (¬ (g16 E = true)) → False
  exact pattern_1 (g16 E) (g199 E)
private theorem sat_144 (E : Nat → Bool) : (valuation E).satisfies [.neg 202, .pos 198] := by
  change (g203 E = true) → (¬ (g199 E = true)) → False
  exact pattern_2 (g16 E) (g199 E)
private theorem sat_145 (E : Nat → Bool) : (valuation E).satisfies [.neg 203, .pos 199] := by
  change (g204 E = true) → (¬ (g200 E = true)) → False
  exact pattern_10 (g20 E) (g200 E)
private theorem sat_146 (E : Nat → Bool) : (valuation E).satisfies [.neg 199, .pos 19, .pos 203] := by
  change (g200 E = true) → (¬ (g20 E = true)) → (¬ (g204 E = true)) → False
  exact pattern_3 (g20 E) (g200 E)
private theorem sat_147 (E : Nat → Bool) : (valuation E).satisfies [.neg 204, .neg 199] := by
  change (g205 E = true) → (g200 E = true) → False
  exact pattern_4 (g20 E) (g200 E)
private theorem sat_148 (E : Nat → Bool) : (valuation E).satisfies [.neg 204, .pos 19] := by
  change (g205 E = true) → (¬ (g20 E = true)) → False
  exact pattern_5 (g20 E) (g200 E)
private theorem sat_149 (E : Nat → Bool) : (valuation E).satisfies [.neg 201, .pos 204, .pos 205] := by
  change (g202 E = true) → (¬ (g205 E = true)) → (¬ (g206 E = true)) → False
  exact pattern_6 (g202 E) (g205 E)
private theorem sat_150 (E : Nat → Bool) : (valuation E).satisfies [.neg 206, .neg 201] := by
  change (g207 E = true) → (g202 E = true) → False
  exact pattern_4 (g20 E) (g202 E)
private theorem sat_151 (E : Nat → Bool) : (valuation E).satisfies [.neg 206, .pos 19] := by
  change (g207 E = true) → (¬ (g20 E = true)) → False
  exact pattern_5 (g20 E) (g202 E)
private theorem sat_152 (E : Nat → Bool) : (valuation E).satisfies [.pos 202, .pos 206, .pos 207] := by
  change (¬ (g203 E = true)) → (¬ (g207 E = true)) → (¬ (g208 E = true)) → False
  exact pattern_0 (g203 E) (g207 E)
private theorem sat_153 (E : Nat → Bool) : (valuation E).satisfies [.neg 203, .pos 23, .pos 209] := by
  change (g204 E = true) → (¬ (g24 E = true)) → (¬ (g210 E = true)) → False
  exact pattern_3 (g24 E) (g204 E)
private theorem sat_154 (E : Nat → Bool) : (valuation E).satisfies [.neg 210, .neg 203] := by
  change (g211 E = true) → (g204 E = true) → False
  exact pattern_4 (g24 E) (g204 E)
private theorem sat_155 (E : Nat → Bool) : (valuation E).satisfies [.neg 210, .pos 23] := by
  change (g211 E = true) → (¬ (g24 E = true)) → False
  exact pattern_5 (g24 E) (g204 E)
private theorem sat_156 (E : Nat → Bool) : (valuation E).satisfies [.neg 205, .pos 210, .pos 211] := by
  change (g206 E = true) → (¬ (g211 E = true)) → (¬ (g212 E = true)) → False
  exact pattern_6 (g206 E) (g211 E)
private theorem sat_157 (E : Nat → Bool) : (valuation E).satisfies [.neg 212, .neg 205] := by
  change (g213 E = true) → (g206 E = true) → False
  exact pattern_4 (g24 E) (g206 E)
private theorem sat_158 (E : Nat → Bool) : (valuation E).satisfies [.neg 212, .pos 23] := by
  change (g213 E = true) → (¬ (g24 E = true)) → False
  exact pattern_5 (g24 E) (g206 E)
private theorem sat_159 (E : Nat → Bool) : (valuation E).satisfies [.neg 207, .pos 212, .pos 213] := by
  change (g208 E = true) → (¬ (g213 E = true)) → (¬ (g214 E = true)) → False
  exact pattern_6 (g208 E) (g213 E)
private theorem sat_160 (E : Nat → Bool) : (valuation E).satisfies [.neg 218, .neg 209] := by
  change (g219 E = true) → (g210 E = true) → False
  exact pattern_4 (g25 E) (g210 E)
private theorem sat_161 (E : Nat → Bool) : (valuation E).satisfies [.neg 218, .pos 24] := by
  change (g219 E = true) → (¬ (g25 E = true)) → False
  exact pattern_5 (g25 E) (g210 E)
private theorem sat_162 (E : Nat → Bool) : (valuation E).satisfies [.neg 211, .pos 218, .pos 219] := by
  change (g212 E = true) → (¬ (g219 E = true)) → (¬ (g220 E = true)) → False
  exact pattern_6 (g212 E) (g219 E)
private theorem sat_163 (E : Nat → Bool) : (valuation E).satisfies [.neg 220, .neg 211] := by
  change (g221 E = true) → (g212 E = true) → False
  exact pattern_4 (g25 E) (g212 E)
private theorem sat_164 (E : Nat → Bool) : (valuation E).satisfies [.neg 220, .pos 24] := by
  change (g221 E = true) → (¬ (g25 E = true)) → False
  exact pattern_5 (g25 E) (g212 E)
private theorem sat_165 (E : Nat → Bool) : (valuation E).satisfies [.neg 213, .pos 220, .pos 221] := by
  change (g214 E = true) → (¬ (g221 E = true)) → (¬ (g222 E = true)) → False
  exact pattern_6 (g214 E) (g221 E)
private theorem sat_166 (E : Nat → Bool) : (valuation E).satisfies [.neg 230, .neg 219] := by
  change (g231 E = true) → (g220 E = true) → False
  exact pattern_4 (g26 E) (g220 E)
private theorem sat_167 (E : Nat → Bool) : (valuation E).satisfies [.neg 230, .pos 25] := by
  change (g231 E = true) → (¬ (g26 E = true)) → False
  exact pattern_5 (g26 E) (g220 E)
private theorem sat_168 (E : Nat → Bool) : (valuation E).satisfies [.neg 221, .pos 230, .pos 231] := by
  change (g222 E = true) → (¬ (g231 E = true)) → (¬ (g232 E = true)) → False
  exact pattern_6 (g222 E) (g231 E)
private theorem sat_170 (E : Nat → Bool) : (valuation E).satisfies [.pos 5, .pos 11, .pos 239] := by
  change (¬ (g6 E = true)) → (¬ (g12 E = true)) → (¬ (g240 E = true)) → False
  exact pattern_0 (g6 E) (g12 E)
private theorem sat_171 (E : Nat → Bool) : (valuation E).satisfies [.neg 240, .pos 5] := by
  change (g241 E = true) → (¬ (g6 E = true)) → False
  exact pattern_1 (g6 E) (g12 E)
private theorem sat_172 (E : Nat → Bool) : (valuation E).satisfies [.neg 240, .pos 11] := by
  change (g241 E = true) → (¬ (g12 E = true)) → False
  exact pattern_2 (g6 E) (g12 E)
private theorem sat_173 (E : Nat → Bool) : (valuation E).satisfies [.neg 239, .pos 16, .pos 241] := by
  change (g240 E = true) → (¬ (g17 E = true)) → (¬ (g242 E = true)) → False
  exact pattern_3 (g17 E) (g240 E)
private theorem sat_174 (E : Nat → Bool) : (valuation E).satisfies [.neg 242, .neg 239] := by
  change (g243 E = true) → (g240 E = true) → False
  exact pattern_4 (g17 E) (g240 E)
private theorem sat_175 (E : Nat → Bool) : (valuation E).satisfies [.neg 242, .pos 16] := by
  change (g243 E = true) → (¬ (g17 E = true)) → False
  exact pattern_5 (g17 E) (g240 E)
private theorem sat_176 (E : Nat → Bool) : (valuation E).satisfies [.pos 240, .pos 242, .pos 243] := by
  change (¬ (g241 E = true)) → (¬ (g243 E = true)) → (¬ (g244 E = true)) → False
  exact pattern_0 (g241 E) (g243 E)
private theorem sat_177 (E : Nat → Bool) : (valuation E).satisfies [.neg 244, .pos 16] := by
  change (g245 E = true) → (¬ (g17 E = true)) → False
  exact pattern_1 (g17 E) (g241 E)
private theorem sat_178 (E : Nat → Bool) : (valuation E).satisfies [.neg 244, .pos 240] := by
  change (g245 E = true) → (¬ (g241 E = true)) → False
  exact pattern_2 (g17 E) (g241 E)
private theorem sat_179 (E : Nat → Bool) : (valuation E).satisfies [.neg 241, .pos 20, .pos 245] := by
  change (g242 E = true) → (¬ (g21 E = true)) → (¬ (g246 E = true)) → False
  exact pattern_3 (g21 E) (g242 E)
private theorem sat_180 (E : Nat → Bool) : (valuation E).satisfies [.neg 246, .neg 241] := by
  change (g247 E = true) → (g242 E = true) → False
  exact pattern_4 (g21 E) (g242 E)
private theorem sat_181 (E : Nat → Bool) : (valuation E).satisfies [.neg 246, .pos 20] := by
  change (g247 E = true) → (¬ (g21 E = true)) → False
  exact pattern_5 (g21 E) (g242 E)
private theorem sat_182 (E : Nat → Bool) : (valuation E).satisfies [.neg 243, .pos 246, .pos 247] := by
  change (g244 E = true) → (¬ (g247 E = true)) → (¬ (g248 E = true)) → False
  exact pattern_6 (g244 E) (g247 E)
private theorem sat_183 (E : Nat → Bool) : (valuation E).satisfies [.neg 248, .neg 243] := by
  change (g249 E = true) → (g244 E = true) → False
  exact pattern_4 (g21 E) (g244 E)
private theorem sat_184 (E : Nat → Bool) : (valuation E).satisfies [.neg 248, .pos 20] := by
  change (g249 E = true) → (¬ (g21 E = true)) → False
  exact pattern_5 (g21 E) (g244 E)
private theorem sat_185 (E : Nat → Bool) : (valuation E).satisfies [.pos 244, .pos 248, .pos 249] := by
  change (¬ (g245 E = true)) → (¬ (g249 E = true)) → (¬ (g250 E = true)) → False
  exact pattern_0 (g245 E) (g249 E)
private theorem sat_186 (E : Nat → Bool) : (valuation E).satisfies [.neg 245, .pos 23, .pos 251] := by
  change (g246 E = true) → (¬ (g24 E = true)) → (¬ (g252 E = true)) → False
  exact pattern_3 (g24 E) (g246 E)
private theorem sat_187 (E : Nat → Bool) : (valuation E).satisfies [.neg 252, .neg 245] := by
  change (g253 E = true) → (g246 E = true) → False
  exact pattern_4 (g24 E) (g246 E)
private theorem sat_188 (E : Nat → Bool) : (valuation E).satisfies [.neg 247, .pos 252, .pos 253] := by
  change (g248 E = true) → (¬ (g253 E = true)) → (¬ (g254 E = true)) → False
  exact pattern_6 (g248 E) (g253 E)
private theorem sat_189 (E : Nat → Bool) : (valuation E).satisfies [.neg 254, .neg 247] := by
  change (g255 E = true) → (g248 E = true) → False
  exact pattern_4 (g24 E) (g248 E)
private theorem sat_190 (E : Nat → Bool) : (valuation E).satisfies [.neg 254, .pos 23] := by
  change (g255 E = true) → (¬ (g24 E = true)) → False
  exact pattern_5 (g24 E) (g248 E)
private theorem sat_191 (E : Nat → Bool) : (valuation E).satisfies [.neg 249, .pos 254, .pos 255] := by
  change (g250 E = true) → (¬ (g255 E = true)) → (¬ (g256 E = true)) → False
  exact pattern_6 (g250 E) (g255 E)
private theorem sat_192 (E : Nat → Bool) : (valuation E).satisfies [.neg 260, .neg 251] := by
  change (g261 E = true) → (g252 E = true) → False
  exact pattern_4 (g27 E) (g252 E)
private theorem sat_193 (E : Nat → Bool) : (valuation E).satisfies [.neg 260, .pos 26] := by
  change (g261 E = true) → (¬ (g27 E = true)) → False
  exact pattern_5 (g27 E) (g252 E)
private theorem sat_194 (E : Nat → Bool) : (valuation E).satisfies [.neg 253, .pos 260, .pos 261] := by
  change (g254 E = true) → (¬ (g261 E = true)) → (¬ (g262 E = true)) → False
  exact pattern_6 (g254 E) (g261 E)
private theorem sat_195 (E : Nat → Bool) : (valuation E).satisfies [.neg 262, .neg 253] := by
  change (g263 E = true) → (g254 E = true) → False
  exact pattern_4 (g27 E) (g254 E)
private theorem sat_196 (E : Nat → Bool) : (valuation E).satisfies [.neg 262, .pos 26] := by
  change (g263 E = true) → (¬ (g27 E = true)) → False
  exact pattern_5 (g27 E) (g254 E)
private theorem sat_197 (E : Nat → Bool) : (valuation E).satisfies [.neg 255, .pos 262, .pos 263] := by
  change (g256 E = true) → (¬ (g263 E = true)) → (¬ (g264 E = true)) → False
  exact pattern_6 (g256 E) (g263 E)
private theorem sat_198 (E : Nat → Bool) : (valuation E).satisfies [.neg 272, .neg 261] := by
  change (g273 E = true) → (g262 E = true) → False
  exact pattern_4 (g28 E) (g262 E)
private theorem sat_199 (E : Nat → Bool) : (valuation E).satisfies [.neg 272, .pos 27] := by
  change (g273 E = true) → (¬ (g28 E = true)) → False
  exact pattern_5 (g28 E) (g262 E)
private theorem sat_200 (E : Nat → Bool) : (valuation E).satisfies [.neg 263, .pos 272, .pos 273] := by
  change (g264 E = true) → (¬ (g273 E = true)) → (¬ (g274 E = true)) → False
  exact pattern_6 (g264 E) (g273 E)
private theorem sat_202 (E : Nat → Bool) : (valuation E).satisfies [.pos 6, .pos 12, .pos 281] := by
  change (¬ (g7 E = true)) → (¬ (g13 E = true)) → (¬ (g282 E = true)) → False
  exact pattern_0 (g7 E) (g13 E)
private theorem sat_203 (E : Nat → Bool) : (valuation E).satisfies [.neg 282, .pos 6] := by
  change (g283 E = true) → (¬ (g7 E = true)) → False
  exact pattern_1 (g7 E) (g13 E)
private theorem sat_204 (E : Nat → Bool) : (valuation E).satisfies [.neg 282, .pos 12] := by
  change (g283 E = true) → (¬ (g13 E = true)) → False
  exact pattern_2 (g7 E) (g13 E)
private theorem sat_205 (E : Nat → Bool) : (valuation E).satisfies [.neg 281, .pos 17, .pos 283] := by
  change (g282 E = true) → (¬ (g18 E = true)) → (¬ (g284 E = true)) → False
  exact pattern_3 (g18 E) (g282 E)
private theorem sat_206 (E : Nat → Bool) : (valuation E).satisfies [.neg 284, .neg 281] := by
  change (g285 E = true) → (g282 E = true) → False
  exact pattern_4 (g18 E) (g282 E)
private theorem sat_207 (E : Nat → Bool) : (valuation E).satisfies [.neg 284, .pos 17] := by
  change (g285 E = true) → (¬ (g18 E = true)) → False
  exact pattern_5 (g18 E) (g282 E)
private theorem sat_208 (E : Nat → Bool) : (valuation E).satisfies [.pos 282, .pos 284, .pos 285] := by
  change (¬ (g283 E = true)) → (¬ (g285 E = true)) → (¬ (g286 E = true)) → False
  exact pattern_0 (g283 E) (g285 E)
private theorem sat_209 (E : Nat → Bool) : (valuation E).satisfies [.neg 286, .pos 17] := by
  change (g287 E = true) → (¬ (g18 E = true)) → False
  exact pattern_1 (g18 E) (g283 E)
private theorem sat_210 (E : Nat → Bool) : (valuation E).satisfies [.neg 286, .pos 282] := by
  change (g287 E = true) → (¬ (g283 E = true)) → False
  exact pattern_2 (g18 E) (g283 E)
private theorem sat_211 (E : Nat → Bool) : (valuation E).satisfies [.neg 283, .pos 21, .pos 287] := by
  change (g284 E = true) → (¬ (g22 E = true)) → (¬ (g288 E = true)) → False
  exact pattern_3 (g22 E) (g284 E)
private theorem sat_212 (E : Nat → Bool) : (valuation E).satisfies [.neg 288, .pos 21] := by
  change (g289 E = true) → (¬ (g22 E = true)) → False
  exact pattern_5 (g22 E) (g284 E)
private theorem sat_213 (E : Nat → Bool) : (valuation E).satisfies [.neg 285, .pos 288, .pos 289] := by
  change (g286 E = true) → (¬ (g289 E = true)) → (¬ (g290 E = true)) → False
  exact pattern_6 (g286 E) (g289 E)
private theorem sat_214 (E : Nat → Bool) : (valuation E).satisfies [.neg 290, .neg 285] := by
  change (g291 E = true) → (g286 E = true) → False
  exact pattern_4 (g22 E) (g286 E)
private theorem sat_215 (E : Nat → Bool) : (valuation E).satisfies [.neg 290, .pos 21] := by
  change (g291 E = true) → (¬ (g22 E = true)) → False
  exact pattern_5 (g22 E) (g286 E)
private theorem sat_216 (E : Nat → Bool) : (valuation E).satisfies [.pos 286, .pos 290, .pos 291] := by
  change (¬ (g287 E = true)) → (¬ (g291 E = true)) → (¬ (g292 E = true)) → False
  exact pattern_0 (g287 E) (g291 E)
private theorem sat_217 (E : Nat → Bool) : (valuation E).satisfies [.neg 287, .pos 24, .pos 293] := by
  change (g288 E = true) → (¬ (g25 E = true)) → (¬ (g294 E = true)) → False
  exact pattern_3 (g25 E) (g288 E)
private theorem sat_218 (E : Nat → Bool) : (valuation E).satisfies [.neg 294, .neg 287] := by
  change (g295 E = true) → (g288 E = true) → False
  exact pattern_4 (g25 E) (g288 E)
private theorem sat_219 (E : Nat → Bool) : (valuation E).satisfies [.neg 294, .pos 24] := by
  change (g295 E = true) → (¬ (g25 E = true)) → False
  exact pattern_5 (g25 E) (g288 E)
private theorem sat_220 (E : Nat → Bool) : (valuation E).satisfies [.neg 289, .pos 294, .pos 295] := by
  change (g290 E = true) → (¬ (g295 E = true)) → (¬ (g296 E = true)) → False
  exact pattern_6 (g290 E) (g295 E)
private theorem sat_221 (E : Nat → Bool) : (valuation E).satisfies [.neg 296, .neg 289] := by
  change (g297 E = true) → (g290 E = true) → False
  exact pattern_4 (g25 E) (g290 E)
private theorem sat_222 (E : Nat → Bool) : (valuation E).satisfies [.neg 296, .pos 24] := by
  change (g297 E = true) → (¬ (g25 E = true)) → False
  exact pattern_5 (g25 E) (g290 E)
private theorem sat_223 (E : Nat → Bool) : (valuation E).satisfies [.neg 291, .pos 296, .pos 297] := by
  change (g292 E = true) → (¬ (g297 E = true)) → (¬ (g298 E = true)) → False
  exact pattern_6 (g292 E) (g297 E)
private theorem sat_224 (E : Nat → Bool) : (valuation E).satisfies [.neg 302, .neg 293] := by
  change (g303 E = true) → (g294 E = true) → False
  exact pattern_4 (g27 E) (g294 E)
private theorem sat_225 (E : Nat → Bool) : (valuation E).satisfies [.neg 302, .pos 26] := by
  change (g303 E = true) → (¬ (g27 E = true)) → False
  exact pattern_5 (g27 E) (g294 E)
private theorem sat_226 (E : Nat → Bool) : (valuation E).satisfies [.neg 295, .pos 302, .pos 303] := by
  change (g296 E = true) → (¬ (g303 E = true)) → (¬ (g304 E = true)) → False
  exact pattern_6 (g296 E) (g303 E)
private theorem sat_227 (E : Nat → Bool) : (valuation E).satisfies [.neg 304, .neg 295] := by
  change (g305 E = true) → (g296 E = true) → False
  exact pattern_4 (g27 E) (g296 E)
private theorem sat_228 (E : Nat → Bool) : (valuation E).satisfies [.neg 304, .pos 26] := by
  change (g305 E = true) → (¬ (g27 E = true)) → False
  exact pattern_5 (g27 E) (g296 E)
private theorem sat_229 (E : Nat → Bool) : (valuation E).satisfies [.neg 297, .pos 304, .pos 305] := by
  change (g298 E = true) → (¬ (g305 E = true)) → (¬ (g306 E = true)) → False
  exact pattern_6 (g298 E) (g305 E)
private theorem sat_230 (E : Nat → Bool) : (valuation E).satisfies [.neg 314, .neg 303] := by
  change (g315 E = true) → (g304 E = true) → False
  exact pattern_4 (g29 E) (g304 E)
private theorem sat_231 (E : Nat → Bool) : (valuation E).satisfies [.neg 314, .pos 28] := by
  change (g315 E = true) → (¬ (g29 E = true)) → False
  exact pattern_5 (g29 E) (g304 E)
private theorem sat_232 (E : Nat → Bool) : (valuation E).satisfies [.neg 305, .pos 314, .pos 315] := by
  change (g306 E = true) → (¬ (g315 E = true)) → (¬ (g316 E = true)) → False
  exact pattern_6 (g306 E) (g315 E)
private theorem sat_234 (E : Nat → Bool) : (valuation E).satisfies [.pos 7, .pos 13, .pos 323] := by
  change (¬ (g8 E = true)) → (¬ (g14 E = true)) → (¬ (g324 E = true)) → False
  exact pattern_0 (g8 E) (g14 E)
private theorem sat_235 (E : Nat → Bool) : (valuation E).satisfies [.neg 324, .pos 13] := by
  change (g325 E = true) → (¬ (g14 E = true)) → False
  exact pattern_2 (g8 E) (g14 E)
private theorem sat_236 (E : Nat → Bool) : (valuation E).satisfies [.neg 323, .pos 18, .pos 325] := by
  change (g324 E = true) → (¬ (g19 E = true)) → (¬ (g326 E = true)) → False
  exact pattern_3 (g19 E) (g324 E)
private theorem sat_237 (E : Nat → Bool) : (valuation E).satisfies [.neg 326, .pos 18] := by
  change (g327 E = true) → (¬ (g19 E = true)) → False
  exact pattern_5 (g19 E) (g324 E)
private theorem sat_238 (E : Nat → Bool) : (valuation E).satisfies [.pos 324, .pos 326, .pos 327] := by
  change (¬ (g325 E = true)) → (¬ (g327 E = true)) → (¬ (g328 E = true)) → False
  exact pattern_0 (g325 E) (g327 E)
private theorem sat_239 (E : Nat → Bool) : (valuation E).satisfies [.neg 328, .pos 18] := by
  change (g329 E = true) → (¬ (g19 E = true)) → False
  exact pattern_1 (g19 E) (g325 E)
private theorem sat_240 (E : Nat → Bool) : (valuation E).satisfies [.neg 325, .pos 22, .pos 329] := by
  change (g326 E = true) → (¬ (g23 E = true)) → (¬ (g330 E = true)) → False
  exact pattern_3 (g23 E) (g326 E)
private theorem sat_241 (E : Nat → Bool) : (valuation E).satisfies [.neg 330, .pos 22] := by
  change (g331 E = true) → (¬ (g23 E = true)) → False
  exact pattern_5 (g23 E) (g326 E)
private theorem sat_242 (E : Nat → Bool) : (valuation E).satisfies [.neg 327, .pos 330, .pos 331] := by
  change (g328 E = true) → (¬ (g331 E = true)) → (¬ (g332 E = true)) → False
  exact pattern_6 (g328 E) (g331 E)
private theorem sat_243 (E : Nat → Bool) : (valuation E).satisfies [.neg 332, .pos 22] := by
  change (g333 E = true) → (¬ (g23 E = true)) → False
  exact pattern_5 (g23 E) (g328 E)
private theorem sat_244 (E : Nat → Bool) : (valuation E).satisfies [.pos 328, .pos 332, .pos 333] := by
  change (¬ (g329 E = true)) → (¬ (g333 E = true)) → (¬ (g334 E = true)) → False
  exact pattern_0 (g329 E) (g333 E)
private theorem sat_245 (E : Nat → Bool) : (valuation E).satisfies [.neg 336, .neg 329] := by
  change (g337 E = true) → (g330 E = true) → False
  exact pattern_4 (g26 E) (g330 E)
private theorem sat_246 (E : Nat → Bool) : (valuation E).satisfies [.neg 331, .pos 336, .pos 337] := by
  change (g332 E = true) → (¬ (g337 E = true)) → (¬ (g338 E = true)) → False
  exact pattern_6 (g332 E) (g337 E)
private theorem sat_247 (E : Nat → Bool) : (valuation E).satisfies [.neg 338, .neg 331] := by
  change (g339 E = true) → (g332 E = true) → False
  exact pattern_4 (g26 E) (g332 E)
private theorem sat_248 (E : Nat → Bool) : (valuation E).satisfies [.neg 333, .pos 338, .pos 339] := by
  change (g334 E = true) → (¬ (g339 E = true)) → (¬ (g340 E = true)) → False
  exact pattern_6 (g334 E) (g339 E)
private theorem sat_249 (E : Nat → Bool) : (valuation E).satisfies [.neg 346, .neg 337] := by
  change (g347 E = true) → (g338 E = true) → False
  exact pattern_4 (g28 E) (g338 E)
private theorem sat_250 (E : Nat → Bool) : (valuation E).satisfies [.neg 346, .pos 27] := by
  change (g347 E = true) → (¬ (g28 E = true)) → False
  exact pattern_5 (g28 E) (g338 E)
private theorem sat_251 (E : Nat → Bool) : (valuation E).satisfies [.neg 339, .pos 346, .pos 347] := by
  change (g340 E = true) → (¬ (g347 E = true)) → (¬ (g348 E = true)) → False
  exact pattern_6 (g340 E) (g347 E)
private theorem sat_252 (E : Nat → Bool) : (valuation E).satisfies [.neg 356, .pos 28] := by
  change (g357 E = true) → (¬ (g29 E = true)) → False
  exact pattern_5 (g29 E) (g346 E)
private theorem sat_253 (E : Nat → Bool) : (valuation E).satisfies [.neg 347, .pos 356, .pos 357] := by
  change (g348 E = true) → (¬ (g357 E = true)) → (¬ (g358 E = true)) → False
  exact pattern_6 (g348 E) (g357 E)
private theorem pattern_11 (x0 x1 x2 : Bool) : (((x0) && (x1) && (x2))=true) → (¬ (x0=true)) → False := by cases x0 <;> cases x1 <;> cases x2 <;> decide
private theorem sat_255 (E : Nat → Bool) : (valuation E).satisfies [.neg 365, .pos 1] := by
  change (g366 E = true) → (¬ (g2 E = true)) → False
  exact pattern_11 (g2 E) (g3 E) (g9 E)
private theorem pattern_12 (x0 x1 x2 : Bool) : (((x0) && (x1) && (x2))=true) → (¬ (x1=true)) → False := by cases x0 <;> cases x1 <;> cases x2 <;> decide
private theorem sat_256 (E : Nat → Bool) : (valuation E).satisfies [.neg 365, .pos 2] := by
  change (g366 E = true) → (¬ (g3 E = true)) → False
  exact pattern_12 (g2 E) (g3 E) (g9 E)
private theorem pattern_13 (x0 x1 x2 : Bool) : (((x0) && (x1) && (x2))=true) → (¬ (x2=true)) → False := by cases x0 <;> cases x1 <;> cases x2 <;> decide
private theorem sat_257 (E : Nat → Bool) : (valuation E).satisfies [.neg 365, .pos 8] := by
  change (g366 E = true) → (¬ (g9 E = true)) → False
  exact pattern_13 (g2 E) (g3 E) (g9 E)
private theorem pattern_14 (x0 x1 x2 : Bool) : (x2=true) → (x1=true) → (x0=true) → (¬ (((x0) && (x1) && (x2))=true)) → False := by cases x0 <;> cases x1 <;> cases x2 <;> decide
private theorem sat_258 (E : Nat → Bool) : (valuation E).satisfies [.neg 8, .neg 2, .neg 1, .pos 365] := by
  change (g9 E = true) → (g3 E = true) → (g2 E = true) → (¬ (g366 E = true)) → False
  exact pattern_14 (g2 E) (g3 E) (g9 E)
private theorem sat_259 (E : Nat → Bool) : (valuation E).satisfies [.neg 366, .pos 1] := by
  change (g367 E = true) → (¬ (g2 E = true)) → False
  exact pattern_11 (g2 E) (g4 E) (g10 E)
private theorem sat_260 (E : Nat → Bool) : (valuation E).satisfies [.neg 366, .pos 3] := by
  change (g367 E = true) → (¬ (g4 E = true)) → False
  exact pattern_12 (g2 E) (g4 E) (g10 E)
private theorem sat_261 (E : Nat → Bool) : (valuation E).satisfies [.neg 366, .pos 9] := by
  change (g367 E = true) → (¬ (g10 E = true)) → False
  exact pattern_13 (g2 E) (g4 E) (g10 E)
private theorem sat_262 (E : Nat → Bool) : (valuation E).satisfies [.neg 9, .neg 3, .neg 1, .pos 366] := by
  change (g10 E = true) → (g4 E = true) → (g2 E = true) → (¬ (g367 E = true)) → False
  exact pattern_14 (g2 E) (g4 E) (g10 E)
private theorem sat_263 (E : Nat → Bool) : (valuation E).satisfies [.neg 367, .pos 1] := by
  change (g368 E = true) → (¬ (g2 E = true)) → False
  exact pattern_11 (g2 E) (g5 E) (g11 E)
private theorem sat_264 (E : Nat → Bool) : (valuation E).satisfies [.neg 367, .pos 4] := by
  change (g368 E = true) → (¬ (g5 E = true)) → False
  exact pattern_12 (g2 E) (g5 E) (g11 E)
private theorem sat_265 (E : Nat → Bool) : (valuation E).satisfies [.neg 367, .pos 10] := by
  change (g368 E = true) → (¬ (g11 E = true)) → False
  exact pattern_13 (g2 E) (g5 E) (g11 E)
private theorem sat_266 (E : Nat → Bool) : (valuation E).satisfies [.neg 368, .pos 1] := by
  change (g369 E = true) → (¬ (g2 E = true)) → False
  exact pattern_11 (g2 E) (g6 E) (g12 E)
private theorem sat_267 (E : Nat → Bool) : (valuation E).satisfies [.neg 368, .pos 5] := by
  change (g369 E = true) → (¬ (g6 E = true)) → False
  exact pattern_12 (g2 E) (g6 E) (g12 E)
private theorem sat_268 (E : Nat → Bool) : (valuation E).satisfies [.neg 368, .pos 11] := by
  change (g369 E = true) → (¬ (g12 E = true)) → False
  exact pattern_13 (g2 E) (g6 E) (g12 E)
private theorem sat_269 (E : Nat → Bool) : (valuation E).satisfies [.neg 11, .neg 5, .neg 1, .pos 368] := by
  change (g12 E = true) → (g6 E = true) → (g2 E = true) → (¬ (g369 E = true)) → False
  exact pattern_14 (g2 E) (g6 E) (g12 E)
private theorem sat_270 (E : Nat → Bool) : (valuation E).satisfies [.neg 369, .pos 1] := by
  change (g370 E = true) → (¬ (g2 E = true)) → False
  exact pattern_11 (g2 E) (g7 E) (g13 E)
private theorem sat_271 (E : Nat → Bool) : (valuation E).satisfies [.neg 369, .pos 6] := by
  change (g370 E = true) → (¬ (g7 E = true)) → False
  exact pattern_12 (g2 E) (g7 E) (g13 E)
private theorem sat_272 (E : Nat → Bool) : (valuation E).satisfies [.neg 369, .pos 12] := by
  change (g370 E = true) → (¬ (g13 E = true)) → False
  exact pattern_13 (g2 E) (g7 E) (g13 E)
private theorem sat_273 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 6, .neg 1, .pos 369] := by
  change (g13 E = true) → (g7 E = true) → (g2 E = true) → (¬ (g370 E = true)) → False
  exact pattern_14 (g2 E) (g7 E) (g13 E)
private theorem sat_274 (E : Nat → Bool) : (valuation E).satisfies [.neg 370, .pos 1] := by
  change (g371 E = true) → (¬ (g2 E = true)) → False
  exact pattern_11 (g2 E) (g8 E) (g14 E)
private theorem sat_275 (E : Nat → Bool) : (valuation E).satisfies [.neg 370, .pos 7] := by
  change (g371 E = true) → (¬ (g8 E = true)) → False
  exact pattern_12 (g2 E) (g8 E) (g14 E)
private theorem sat_276 (E : Nat → Bool) : (valuation E).satisfies [.neg 370, .pos 13] := by
  change (g371 E = true) → (¬ (g14 E = true)) → False
  exact pattern_13 (g2 E) (g8 E) (g14 E)
private theorem sat_277 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 7, .neg 1, .pos 370] := by
  change (g14 E = true) → (g8 E = true) → (g2 E = true) → (¬ (g371 E = true)) → False
  exact pattern_14 (g2 E) (g8 E) (g14 E)
private theorem sat_278 (E : Nat → Bool) : (valuation E).satisfies [.neg 371, .pos 2] := by
  change (g372 E = true) → (¬ (g3 E = true)) → False
  exact pattern_11 (g3 E) (g4 E) (g15 E)
private theorem sat_279 (E : Nat → Bool) : (valuation E).satisfies [.neg 371, .pos 3] := by
  change (g372 E = true) → (¬ (g4 E = true)) → False
  exact pattern_12 (g3 E) (g4 E) (g15 E)
private theorem sat_280 (E : Nat → Bool) : (valuation E).satisfies [.neg 371, .pos 14] := by
  change (g372 E = true) → (¬ (g15 E = true)) → False
  exact pattern_13 (g3 E) (g4 E) (g15 E)
private theorem sat_281 (E : Nat → Bool) : (valuation E).satisfies [.neg 14, .neg 3, .neg 2, .pos 371] := by
  change (g15 E = true) → (g4 E = true) → (g3 E = true) → (¬ (g372 E = true)) → False
  exact pattern_14 (g3 E) (g4 E) (g15 E)
private theorem sat_282 (E : Nat → Bool) : (valuation E).satisfies [.neg 372, .pos 2] := by
  change (g373 E = true) → (¬ (g3 E = true)) → False
  exact pattern_11 (g3 E) (g5 E) (g16 E)
private theorem sat_283 (E : Nat → Bool) : (valuation E).satisfies [.neg 372, .pos 4] := by
  change (g373 E = true) → (¬ (g5 E = true)) → False
  exact pattern_12 (g3 E) (g5 E) (g16 E)
private theorem sat_284 (E : Nat → Bool) : (valuation E).satisfies [.neg 372, .pos 15] := by
  change (g373 E = true) → (¬ (g16 E = true)) → False
  exact pattern_13 (g3 E) (g5 E) (g16 E)
private theorem sat_285 (E : Nat → Bool) : (valuation E).satisfies [.neg 373, .pos 2] := by
  change (g374 E = true) → (¬ (g3 E = true)) → False
  exact pattern_11 (g3 E) (g6 E) (g17 E)
private theorem sat_286 (E : Nat → Bool) : (valuation E).satisfies [.neg 373, .pos 5] := by
  change (g374 E = true) → (¬ (g6 E = true)) → False
  exact pattern_12 (g3 E) (g6 E) (g17 E)
private theorem sat_287 (E : Nat → Bool) : (valuation E).satisfies [.neg 373, .pos 16] := by
  change (g374 E = true) → (¬ (g17 E = true)) → False
  exact pattern_13 (g3 E) (g6 E) (g17 E)
private theorem sat_288 (E : Nat → Bool) : (valuation E).satisfies [.neg 374, .pos 2] := by
  change (g375 E = true) → (¬ (g3 E = true)) → False
  exact pattern_11 (g3 E) (g7 E) (g18 E)
private theorem sat_289 (E : Nat → Bool) : (valuation E).satisfies [.neg 374, .pos 6] := by
  change (g375 E = true) → (¬ (g7 E = true)) → False
  exact pattern_12 (g3 E) (g7 E) (g18 E)
private theorem sat_290 (E : Nat → Bool) : (valuation E).satisfies [.neg 374, .pos 17] := by
  change (g375 E = true) → (¬ (g18 E = true)) → False
  exact pattern_13 (g3 E) (g7 E) (g18 E)
private theorem sat_291 (E : Nat → Bool) : (valuation E).satisfies [.neg 375, .pos 2] := by
  change (g376 E = true) → (¬ (g3 E = true)) → False
  exact pattern_11 (g3 E) (g8 E) (g19 E)
private theorem sat_292 (E : Nat → Bool) : (valuation E).satisfies [.neg 375, .pos 7] := by
  change (g376 E = true) → (¬ (g8 E = true)) → False
  exact pattern_12 (g3 E) (g8 E) (g19 E)
private theorem sat_293 (E : Nat → Bool) : (valuation E).satisfies [.neg 375, .pos 18] := by
  change (g376 E = true) → (¬ (g19 E = true)) → False
  exact pattern_13 (g3 E) (g8 E) (g19 E)
private theorem sat_294 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 7, .neg 2, .pos 375] := by
  change (g19 E = true) → (g8 E = true) → (g3 E = true) → (¬ (g376 E = true)) → False
  exact pattern_14 (g3 E) (g8 E) (g19 E)
private theorem sat_295 (E : Nat → Bool) : (valuation E).satisfies [.neg 376, .pos 3] := by
  change (g377 E = true) → (¬ (g4 E = true)) → False
  exact pattern_11 (g4 E) (g5 E) (g20 E)
private theorem sat_296 (E : Nat → Bool) : (valuation E).satisfies [.neg 376, .pos 4] := by
  change (g377 E = true) → (¬ (g5 E = true)) → False
  exact pattern_12 (g4 E) (g5 E) (g20 E)
private theorem sat_297 (E : Nat → Bool) : (valuation E).satisfies [.neg 376, .pos 19] := by
  change (g377 E = true) → (¬ (g20 E = true)) → False
  exact pattern_13 (g4 E) (g5 E) (g20 E)
private theorem sat_298 (E : Nat → Bool) : (valuation E).satisfies [.neg 377, .pos 3] := by
  change (g378 E = true) → (¬ (g4 E = true)) → False
  exact pattern_11 (g4 E) (g6 E) (g21 E)
private theorem sat_299 (E : Nat → Bool) : (valuation E).satisfies [.neg 377, .pos 5] := by
  change (g378 E = true) → (¬ (g6 E = true)) → False
  exact pattern_12 (g4 E) (g6 E) (g21 E)
private theorem sat_300 (E : Nat → Bool) : (valuation E).satisfies [.neg 377, .pos 20] := by
  change (g378 E = true) → (¬ (g21 E = true)) → False
  exact pattern_13 (g4 E) (g6 E) (g21 E)
private theorem sat_301 (E : Nat → Bool) : (valuation E).satisfies [.neg 20, .neg 5, .neg 3, .pos 377] := by
  change (g21 E = true) → (g6 E = true) → (g4 E = true) → (¬ (g378 E = true)) → False
  exact pattern_14 (g4 E) (g6 E) (g21 E)
private theorem sat_302 (E : Nat → Bool) : (valuation E).satisfies [.neg 378, .pos 3] := by
  change (g379 E = true) → (¬ (g4 E = true)) → False
  exact pattern_11 (g4 E) (g7 E) (g22 E)
private theorem sat_303 (E : Nat → Bool) : (valuation E).satisfies [.neg 378, .pos 6] := by
  change (g379 E = true) → (¬ (g7 E = true)) → False
  exact pattern_12 (g4 E) (g7 E) (g22 E)
private theorem sat_304 (E : Nat → Bool) : (valuation E).satisfies [.neg 378, .pos 21] := by
  change (g379 E = true) → (¬ (g22 E = true)) → False
  exact pattern_13 (g4 E) (g7 E) (g22 E)
private theorem sat_305 (E : Nat → Bool) : (valuation E).satisfies [.neg 21, .neg 6, .neg 3, .pos 378] := by
  change (g22 E = true) → (g7 E = true) → (g4 E = true) → (¬ (g379 E = true)) → False
  exact pattern_14 (g4 E) (g7 E) (g22 E)
private theorem sat_306 (E : Nat → Bool) : (valuation E).satisfies [.neg 379, .pos 3] := by
  change (g380 E = true) → (¬ (g4 E = true)) → False
  exact pattern_11 (g4 E) (g8 E) (g23 E)
private theorem sat_307 (E : Nat → Bool) : (valuation E).satisfies [.neg 379, .pos 7] := by
  change (g380 E = true) → (¬ (g8 E = true)) → False
  exact pattern_12 (g4 E) (g8 E) (g23 E)
private theorem sat_308 (E : Nat → Bool) : (valuation E).satisfies [.neg 379, .pos 22] := by
  change (g380 E = true) → (¬ (g23 E = true)) → False
  exact pattern_13 (g4 E) (g8 E) (g23 E)
private theorem sat_309 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 7, .neg 3, .pos 379] := by
  change (g23 E = true) → (g8 E = true) → (g4 E = true) → (¬ (g380 E = true)) → False
  exact pattern_14 (g4 E) (g8 E) (g23 E)
private theorem sat_310 (E : Nat → Bool) : (valuation E).satisfies [.neg 380, .pos 5] := by
  change (g381 E = true) → (¬ (g6 E = true)) → False
  exact pattern_12 (g5 E) (g6 E) (g24 E)
private theorem sat_311 (E : Nat → Bool) : (valuation E).satisfies [.neg 380, .pos 23] := by
  change (g381 E = true) → (¬ (g24 E = true)) → False
  exact pattern_13 (g5 E) (g6 E) (g24 E)
private theorem sat_312 (E : Nat → Bool) : (valuation E).satisfies [.neg 381, .pos 4] := by
  change (g382 E = true) → (¬ (g5 E = true)) → False
  exact pattern_11 (g5 E) (g7 E) (g25 E)
private theorem sat_313 (E : Nat → Bool) : (valuation E).satisfies [.neg 381, .pos 6] := by
  change (g382 E = true) → (¬ (g7 E = true)) → False
  exact pattern_12 (g5 E) (g7 E) (g25 E)
private theorem sat_314 (E : Nat → Bool) : (valuation E).satisfies [.neg 381, .pos 24] := by
  change (g382 E = true) → (¬ (g25 E = true)) → False
  exact pattern_13 (g5 E) (g7 E) (g25 E)
private theorem sat_315 (E : Nat → Bool) : (valuation E).satisfies [.neg 382, .pos 4] := by
  change (g383 E = true) → (¬ (g5 E = true)) → False
  exact pattern_11 (g5 E) (g8 E) (g26 E)
private theorem sat_316 (E : Nat → Bool) : (valuation E).satisfies [.neg 382, .pos 7] := by
  change (g383 E = true) → (¬ (g8 E = true)) → False
  exact pattern_12 (g5 E) (g8 E) (g26 E)
private theorem sat_317 (E : Nat → Bool) : (valuation E).satisfies [.neg 382, .pos 25] := by
  change (g383 E = true) → (¬ (g26 E = true)) → False
  exact pattern_13 (g5 E) (g8 E) (g26 E)
private theorem sat_318 (E : Nat → Bool) : (valuation E).satisfies [.neg 383, .pos 5] := by
  change (g384 E = true) → (¬ (g6 E = true)) → False
  exact pattern_11 (g6 E) (g7 E) (g27 E)
private theorem sat_319 (E : Nat → Bool) : (valuation E).satisfies [.neg 383, .pos 6] := by
  change (g384 E = true) → (¬ (g7 E = true)) → False
  exact pattern_12 (g6 E) (g7 E) (g27 E)
private theorem sat_320 (E : Nat → Bool) : (valuation E).satisfies [.neg 26, .neg 6, .neg 5, .pos 383] := by
  change (g27 E = true) → (g7 E = true) → (g6 E = true) → (¬ (g384 E = true)) → False
  exact pattern_14 (g6 E) (g7 E) (g27 E)
private theorem sat_321 (E : Nat → Bool) : (valuation E).satisfies [.neg 384, .pos 5] := by
  change (g385 E = true) → (¬ (g6 E = true)) → False
  exact pattern_11 (g6 E) (g8 E) (g28 E)
private theorem sat_322 (E : Nat → Bool) : (valuation E).satisfies [.neg 384, .pos 7] := by
  change (g385 E = true) → (¬ (g8 E = true)) → False
  exact pattern_12 (g6 E) (g8 E) (g28 E)
private theorem sat_323 (E : Nat → Bool) : (valuation E).satisfies [.neg 27, .neg 7, .neg 5, .pos 384] := by
  change (g28 E = true) → (g8 E = true) → (g6 E = true) → (¬ (g385 E = true)) → False
  exact pattern_14 (g6 E) (g8 E) (g28 E)
private theorem sat_324 (E : Nat → Bool) : (valuation E).satisfies [.neg 385, .pos 6] := by
  change (g386 E = true) → (¬ (g7 E = true)) → False
  exact pattern_11 (g7 E) (g8 E) (g29 E)
private theorem sat_325 (E : Nat → Bool) : (valuation E).satisfies [.neg 385, .pos 7] := by
  change (g386 E = true) → (¬ (g8 E = true)) → False
  exact pattern_12 (g7 E) (g8 E) (g29 E)
private theorem sat_326 (E : Nat → Bool) : (valuation E).satisfies [.neg 385, .pos 28] := by
  change (g386 E = true) → (¬ (g29 E = true)) → False
  exact pattern_13 (g7 E) (g8 E) (g29 E)
private theorem sat_327 (E : Nat → Bool) : (valuation E).satisfies [.neg 28, .neg 7, .neg 6, .pos 385] := by
  change (g29 E = true) → (g8 E = true) → (g7 E = true) → (¬ (g386 E = true)) → False
  exact pattern_14 (g7 E) (g8 E) (g29 E)
private theorem sat_328 (E : Nat → Bool) : (valuation E).satisfies [.neg 386, .pos 8] := by
  change (g387 E = true) → (¬ (g9 E = true)) → False
  exact pattern_11 (g9 E) (g10 E) (g15 E)
private theorem sat_329 (E : Nat → Bool) : (valuation E).satisfies [.neg 386, .pos 9] := by
  change (g387 E = true) → (¬ (g10 E = true)) → False
  exact pattern_12 (g9 E) (g10 E) (g15 E)
private theorem sat_330 (E : Nat → Bool) : (valuation E).satisfies [.neg 386, .pos 14] := by
  change (g387 E = true) → (¬ (g15 E = true)) → False
  exact pattern_13 (g9 E) (g10 E) (g15 E)
private theorem sat_331 (E : Nat → Bool) : (valuation E).satisfies [.neg 14, .neg 9, .neg 8, .pos 386] := by
  change (g15 E = true) → (g10 E = true) → (g9 E = true) → (¬ (g387 E = true)) → False
  exact pattern_14 (g9 E) (g10 E) (g15 E)
private theorem sat_332 (E : Nat → Bool) : (valuation E).satisfies [.neg 387, .pos 8] := by
  change (g388 E = true) → (¬ (g9 E = true)) → False
  exact pattern_11 (g9 E) (g11 E) (g16 E)
private theorem sat_333 (E : Nat → Bool) : (valuation E).satisfies [.neg 387, .pos 10] := by
  change (g388 E = true) → (¬ (g11 E = true)) → False
  exact pattern_12 (g9 E) (g11 E) (g16 E)
private theorem sat_334 (E : Nat → Bool) : (valuation E).satisfies [.neg 387, .pos 15] := by
  change (g388 E = true) → (¬ (g16 E = true)) → False
  exact pattern_13 (g9 E) (g11 E) (g16 E)
private theorem sat_335 (E : Nat → Bool) : (valuation E).satisfies [.neg 15, .neg 10, .neg 8, .pos 387] := by
  change (g16 E = true) → (g11 E = true) → (g9 E = true) → (¬ (g388 E = true)) → False
  exact pattern_14 (g9 E) (g11 E) (g16 E)
private theorem sat_336 (E : Nat → Bool) : (valuation E).satisfies [.neg 388, .pos 8] := by
  change (g389 E = true) → (¬ (g9 E = true)) → False
  exact pattern_11 (g9 E) (g12 E) (g17 E)
private theorem sat_337 (E : Nat → Bool) : (valuation E).satisfies [.neg 388, .pos 11] := by
  change (g389 E = true) → (¬ (g12 E = true)) → False
  exact pattern_12 (g9 E) (g12 E) (g17 E)
private theorem sat_338 (E : Nat → Bool) : (valuation E).satisfies [.neg 388, .pos 16] := by
  change (g389 E = true) → (¬ (g17 E = true)) → False
  exact pattern_13 (g9 E) (g12 E) (g17 E)
private theorem sat_339 (E : Nat → Bool) : (valuation E).satisfies [.neg 389, .pos 8] := by
  change (g390 E = true) → (¬ (g9 E = true)) → False
  exact pattern_11 (g9 E) (g13 E) (g18 E)
private theorem sat_340 (E : Nat → Bool) : (valuation E).satisfies [.neg 389, .pos 12] := by
  change (g390 E = true) → (¬ (g13 E = true)) → False
  exact pattern_12 (g9 E) (g13 E) (g18 E)
private theorem sat_341 (E : Nat → Bool) : (valuation E).satisfies [.neg 389, .pos 17] := by
  change (g390 E = true) → (¬ (g18 E = true)) → False
  exact pattern_13 (g9 E) (g13 E) (g18 E)
private theorem sat_342 (E : Nat → Bool) : (valuation E).satisfies [.neg 17, .neg 12, .neg 8, .pos 389] := by
  change (g18 E = true) → (g13 E = true) → (g9 E = true) → (¬ (g390 E = true)) → False
  exact pattern_14 (g9 E) (g13 E) (g18 E)
private theorem sat_343 (E : Nat → Bool) : (valuation E).satisfies [.neg 390, .pos 8] := by
  change (g391 E = true) → (¬ (g9 E = true)) → False
  exact pattern_11 (g9 E) (g14 E) (g19 E)
private theorem sat_344 (E : Nat → Bool) : (valuation E).satisfies [.neg 390, .pos 13] := by
  change (g391 E = true) → (¬ (g14 E = true)) → False
  exact pattern_12 (g9 E) (g14 E) (g19 E)
private theorem sat_345 (E : Nat → Bool) : (valuation E).satisfies [.neg 390, .pos 18] := by
  change (g391 E = true) → (¬ (g19 E = true)) → False
  exact pattern_13 (g9 E) (g14 E) (g19 E)
private theorem sat_346 (E : Nat → Bool) : (valuation E).satisfies [.neg 391, .pos 9] := by
  change (g392 E = true) → (¬ (g10 E = true)) → False
  exact pattern_11 (g10 E) (g11 E) (g20 E)
private theorem sat_347 (E : Nat → Bool) : (valuation E).satisfies [.neg 391, .pos 10] := by
  change (g392 E = true) → (¬ (g11 E = true)) → False
  exact pattern_12 (g10 E) (g11 E) (g20 E)
private theorem sat_348 (E : Nat → Bool) : (valuation E).satisfies [.neg 391, .pos 19] := by
  change (g392 E = true) → (¬ (g20 E = true)) → False
  exact pattern_13 (g10 E) (g11 E) (g20 E)
private theorem sat_349 (E : Nat → Bool) : (valuation E).satisfies [.neg 19, .neg 10, .neg 9, .pos 391] := by
  change (g20 E = true) → (g11 E = true) → (g10 E = true) → (¬ (g392 E = true)) → False
  exact pattern_14 (g10 E) (g11 E) (g20 E)
private theorem sat_350 (E : Nat → Bool) : (valuation E).satisfies [.neg 392, .pos 9] := by
  change (g393 E = true) → (¬ (g10 E = true)) → False
  exact pattern_11 (g10 E) (g12 E) (g21 E)
private theorem sat_351 (E : Nat → Bool) : (valuation E).satisfies [.neg 392, .pos 11] := by
  change (g393 E = true) → (¬ (g12 E = true)) → False
  exact pattern_12 (g10 E) (g12 E) (g21 E)
private theorem sat_352 (E : Nat → Bool) : (valuation E).satisfies [.neg 392, .pos 20] := by
  change (g393 E = true) → (¬ (g21 E = true)) → False
  exact pattern_13 (g10 E) (g12 E) (g21 E)
private theorem sat_353 (E : Nat → Bool) : (valuation E).satisfies [.neg 20, .neg 11, .neg 9, .pos 392] := by
  change (g21 E = true) → (g12 E = true) → (g10 E = true) → (¬ (g393 E = true)) → False
  exact pattern_14 (g10 E) (g12 E) (g21 E)
private theorem sat_354 (E : Nat → Bool) : (valuation E).satisfies [.neg 393, .pos 9] := by
  change (g394 E = true) → (¬ (g10 E = true)) → False
  exact pattern_11 (g10 E) (g13 E) (g22 E)
private theorem sat_355 (E : Nat → Bool) : (valuation E).satisfies [.neg 393, .pos 12] := by
  change (g394 E = true) → (¬ (g13 E = true)) → False
  exact pattern_12 (g10 E) (g13 E) (g22 E)
private theorem sat_356 (E : Nat → Bool) : (valuation E).satisfies [.neg 393, .pos 21] := by
  change (g394 E = true) → (¬ (g22 E = true)) → False
  exact pattern_13 (g10 E) (g13 E) (g22 E)
private theorem sat_357 (E : Nat → Bool) : (valuation E).satisfies [.neg 21, .neg 12, .neg 9, .pos 393] := by
  change (g22 E = true) → (g13 E = true) → (g10 E = true) → (¬ (g394 E = true)) → False
  exact pattern_14 (g10 E) (g13 E) (g22 E)
private theorem sat_358 (E : Nat → Bool) : (valuation E).satisfies [.neg 394, .pos 9] := by
  change (g395 E = true) → (¬ (g10 E = true)) → False
  exact pattern_11 (g10 E) (g14 E) (g23 E)
private theorem sat_359 (E : Nat → Bool) : (valuation E).satisfies [.neg 394, .pos 13] := by
  change (g395 E = true) → (¬ (g14 E = true)) → False
  exact pattern_12 (g10 E) (g14 E) (g23 E)
private theorem sat_360 (E : Nat → Bool) : (valuation E).satisfies [.neg 394, .pos 22] := by
  change (g395 E = true) → (¬ (g23 E = true)) → False
  exact pattern_13 (g10 E) (g14 E) (g23 E)
private theorem sat_361 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 13, .neg 9, .pos 394] := by
  change (g23 E = true) → (g14 E = true) → (g10 E = true) → (¬ (g395 E = true)) → False
  exact pattern_14 (g10 E) (g14 E) (g23 E)
private theorem sat_362 (E : Nat → Bool) : (valuation E).satisfies [.neg 395, .pos 10] := by
  change (g396 E = true) → (¬ (g11 E = true)) → False
  exact pattern_11 (g11 E) (g12 E) (g24 E)
private theorem sat_363 (E : Nat → Bool) : (valuation E).satisfies [.neg 395, .pos 11] := by
  change (g396 E = true) → (¬ (g12 E = true)) → False
  exact pattern_12 (g11 E) (g12 E) (g24 E)
private theorem sat_364 (E : Nat → Bool) : (valuation E).satisfies [.neg 395, .pos 23] := by
  change (g396 E = true) → (¬ (g24 E = true)) → False
  exact pattern_13 (g11 E) (g12 E) (g24 E)
private theorem sat_365 (E : Nat → Bool) : (valuation E).satisfies [.neg 396, .pos 10] := by
  change (g397 E = true) → (¬ (g11 E = true)) → False
  exact pattern_11 (g11 E) (g13 E) (g25 E)
private theorem sat_366 (E : Nat → Bool) : (valuation E).satisfies [.neg 396, .pos 12] := by
  change (g397 E = true) → (¬ (g13 E = true)) → False
  exact pattern_12 (g11 E) (g13 E) (g25 E)
private theorem sat_367 (E : Nat → Bool) : (valuation E).satisfies [.neg 396, .pos 24] := by
  change (g397 E = true) → (¬ (g25 E = true)) → False
  exact pattern_13 (g11 E) (g13 E) (g25 E)
private theorem sat_368 (E : Nat → Bool) : (valuation E).satisfies [.neg 397, .pos 10] := by
  change (g398 E = true) → (¬ (g11 E = true)) → False
  exact pattern_11 (g11 E) (g14 E) (g26 E)
private theorem sat_369 (E : Nat → Bool) : (valuation E).satisfies [.neg 397, .pos 13] := by
  change (g398 E = true) → (¬ (g14 E = true)) → False
  exact pattern_12 (g11 E) (g14 E) (g26 E)
private theorem sat_370 (E : Nat → Bool) : (valuation E).satisfies [.neg 397, .pos 25] := by
  change (g398 E = true) → (¬ (g26 E = true)) → False
  exact pattern_13 (g11 E) (g14 E) (g26 E)
private theorem sat_371 (E : Nat → Bool) : (valuation E).satisfies [.neg 398, .pos 11] := by
  change (g399 E = true) → (¬ (g12 E = true)) → False
  exact pattern_11 (g12 E) (g13 E) (g27 E)
private theorem sat_372 (E : Nat → Bool) : (valuation E).satisfies [.neg 398, .pos 12] := by
  change (g399 E = true) → (¬ (g13 E = true)) → False
  exact pattern_12 (g12 E) (g13 E) (g27 E)
private theorem sat_373 (E : Nat → Bool) : (valuation E).satisfies [.neg 398, .pos 26] := by
  change (g399 E = true) → (¬ (g27 E = true)) → False
  exact pattern_13 (g12 E) (g13 E) (g27 E)
private theorem sat_374 (E : Nat → Bool) : (valuation E).satisfies [.neg 26, .neg 12, .neg 11, .pos 398] := by
  change (g27 E = true) → (g13 E = true) → (g12 E = true) → (¬ (g399 E = true)) → False
  exact pattern_14 (g12 E) (g13 E) (g27 E)
private theorem sat_375 (E : Nat → Bool) : (valuation E).satisfies [.neg 399, .pos 11] := by
  change (g400 E = true) → (¬ (g12 E = true)) → False
  exact pattern_11 (g12 E) (g14 E) (g28 E)
private theorem sat_376 (E : Nat → Bool) : (valuation E).satisfies [.neg 399, .pos 13] := by
  change (g400 E = true) → (¬ (g14 E = true)) → False
  exact pattern_12 (g12 E) (g14 E) (g28 E)
private theorem sat_377 (E : Nat → Bool) : (valuation E).satisfies [.neg 399, .pos 27] := by
  change (g400 E = true) → (¬ (g28 E = true)) → False
  exact pattern_13 (g12 E) (g14 E) (g28 E)
private theorem sat_378 (E : Nat → Bool) : (valuation E).satisfies [.neg 27, .neg 13, .neg 11, .pos 399] := by
  change (g28 E = true) → (g14 E = true) → (g12 E = true) → (¬ (g400 E = true)) → False
  exact pattern_14 (g12 E) (g14 E) (g28 E)
private theorem sat_379 (E : Nat → Bool) : (valuation E).satisfies [.neg 400, .pos 12] := by
  change (g401 E = true) → (¬ (g13 E = true)) → False
  exact pattern_11 (g13 E) (g14 E) (g29 E)
private theorem sat_380 (E : Nat → Bool) : (valuation E).satisfies [.neg 400, .pos 13] := by
  change (g401 E = true) → (¬ (g14 E = true)) → False
  exact pattern_12 (g13 E) (g14 E) (g29 E)
private theorem sat_381 (E : Nat → Bool) : (valuation E).satisfies [.neg 400, .pos 28] := by
  change (g401 E = true) → (¬ (g29 E = true)) → False
  exact pattern_13 (g13 E) (g14 E) (g29 E)
private theorem sat_382 (E : Nat → Bool) : (valuation E).satisfies [.neg 28, .neg 13, .neg 12, .pos 400] := by
  change (g29 E = true) → (g14 E = true) → (g13 E = true) → (¬ (g401 E = true)) → False
  exact pattern_14 (g13 E) (g14 E) (g29 E)
private theorem sat_383 (E : Nat → Bool) : (valuation E).satisfies [.neg 401, .pos 14] := by
  change (g402 E = true) → (¬ (g15 E = true)) → False
  exact pattern_11 (g15 E) (g16 E) (g20 E)
private theorem sat_384 (E : Nat → Bool) : (valuation E).satisfies [.neg 401, .pos 15] := by
  change (g402 E = true) → (¬ (g16 E = true)) → False
  exact pattern_12 (g15 E) (g16 E) (g20 E)
private theorem sat_385 (E : Nat → Bool) : (valuation E).satisfies [.neg 401, .pos 19] := by
  change (g402 E = true) → (¬ (g20 E = true)) → False
  exact pattern_13 (g15 E) (g16 E) (g20 E)
private theorem sat_386 (E : Nat → Bool) : (valuation E).satisfies [.neg 19, .neg 15, .neg 14, .pos 401] := by
  change (g20 E = true) → (g16 E = true) → (g15 E = true) → (¬ (g402 E = true)) → False
  exact pattern_14 (g15 E) (g16 E) (g20 E)
private theorem sat_387 (E : Nat → Bool) : (valuation E).satisfies [.neg 402, .pos 14] := by
  change (g403 E = true) → (¬ (g15 E = true)) → False
  exact pattern_11 (g15 E) (g17 E) (g21 E)
private theorem sat_388 (E : Nat → Bool) : (valuation E).satisfies [.neg 402, .pos 16] := by
  change (g403 E = true) → (¬ (g17 E = true)) → False
  exact pattern_12 (g15 E) (g17 E) (g21 E)
private theorem sat_389 (E : Nat → Bool) : (valuation E).satisfies [.neg 402, .pos 20] := by
  change (g403 E = true) → (¬ (g21 E = true)) → False
  exact pattern_13 (g15 E) (g17 E) (g21 E)
private theorem sat_390 (E : Nat → Bool) : (valuation E).satisfies [.neg 20, .neg 16, .neg 14, .pos 402] := by
  change (g21 E = true) → (g17 E = true) → (g15 E = true) → (¬ (g403 E = true)) → False
  exact pattern_14 (g15 E) (g17 E) (g21 E)
private theorem sat_391 (E : Nat → Bool) : (valuation E).satisfies [.neg 403, .pos 14] := by
  change (g404 E = true) → (¬ (g15 E = true)) → False
  exact pattern_11 (g15 E) (g18 E) (g22 E)
private theorem sat_392 (E : Nat → Bool) : (valuation E).satisfies [.neg 403, .pos 17] := by
  change (g404 E = true) → (¬ (g18 E = true)) → False
  exact pattern_12 (g15 E) (g18 E) (g22 E)
private theorem sat_393 (E : Nat → Bool) : (valuation E).satisfies [.neg 403, .pos 21] := by
  change (g404 E = true) → (¬ (g22 E = true)) → False
  exact pattern_13 (g15 E) (g18 E) (g22 E)
private theorem sat_394 (E : Nat → Bool) : (valuation E).satisfies [.neg 21, .neg 17, .neg 14, .pos 403] := by
  change (g22 E = true) → (g18 E = true) → (g15 E = true) → (¬ (g404 E = true)) → False
  exact pattern_14 (g15 E) (g18 E) (g22 E)
private theorem sat_395 (E : Nat → Bool) : (valuation E).satisfies [.neg 404, .pos 14] := by
  change (g405 E = true) → (¬ (g15 E = true)) → False
  exact pattern_11 (g15 E) (g19 E) (g23 E)
private theorem sat_396 (E : Nat → Bool) : (valuation E).satisfies [.neg 404, .pos 18] := by
  change (g405 E = true) → (¬ (g19 E = true)) → False
  exact pattern_12 (g15 E) (g19 E) (g23 E)
private theorem sat_397 (E : Nat → Bool) : (valuation E).satisfies [.neg 404, .pos 22] := by
  change (g405 E = true) → (¬ (g23 E = true)) → False
  exact pattern_13 (g15 E) (g19 E) (g23 E)
private theorem sat_398 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 18, .neg 14, .pos 404] := by
  change (g23 E = true) → (g19 E = true) → (g15 E = true) → (¬ (g405 E = true)) → False
  exact pattern_14 (g15 E) (g19 E) (g23 E)
private theorem sat_399 (E : Nat → Bool) : (valuation E).satisfies [.neg 405, .pos 15] := by
  change (g406 E = true) → (¬ (g16 E = true)) → False
  exact pattern_11 (g16 E) (g17 E) (g24 E)
private theorem sat_400 (E : Nat → Bool) : (valuation E).satisfies [.neg 405, .pos 16] := by
  change (g406 E = true) → (¬ (g17 E = true)) → False
  exact pattern_12 (g16 E) (g17 E) (g24 E)
private theorem sat_401 (E : Nat → Bool) : (valuation E).satisfies [.neg 405, .pos 23] := by
  change (g406 E = true) → (¬ (g24 E = true)) → False
  exact pattern_13 (g16 E) (g17 E) (g24 E)
private theorem sat_402 (E : Nat → Bool) : (valuation E).satisfies [.neg 406, .pos 15] := by
  change (g407 E = true) → (¬ (g16 E = true)) → False
  exact pattern_11 (g16 E) (g18 E) (g25 E)
private theorem sat_403 (E : Nat → Bool) : (valuation E).satisfies [.neg 406, .pos 17] := by
  change (g407 E = true) → (¬ (g18 E = true)) → False
  exact pattern_12 (g16 E) (g18 E) (g25 E)
private theorem sat_404 (E : Nat → Bool) : (valuation E).satisfies [.neg 406, .pos 24] := by
  change (g407 E = true) → (¬ (g25 E = true)) → False
  exact pattern_13 (g16 E) (g18 E) (g25 E)
private theorem sat_405 (E : Nat → Bool) : (valuation E).satisfies [.neg 407, .pos 15] := by
  change (g408 E = true) → (¬ (g16 E = true)) → False
  exact pattern_11 (g16 E) (g19 E) (g26 E)
private theorem sat_406 (E : Nat → Bool) : (valuation E).satisfies [.neg 407, .pos 18] := by
  change (g408 E = true) → (¬ (g19 E = true)) → False
  exact pattern_12 (g16 E) (g19 E) (g26 E)
private theorem sat_407 (E : Nat → Bool) : (valuation E).satisfies [.neg 407, .pos 25] := by
  change (g408 E = true) → (¬ (g26 E = true)) → False
  exact pattern_13 (g16 E) (g19 E) (g26 E)
private theorem sat_408 (E : Nat → Bool) : (valuation E).satisfies [.neg 408, .pos 16] := by
  change (g409 E = true) → (¬ (g17 E = true)) → False
  exact pattern_11 (g17 E) (g18 E) (g27 E)
private theorem sat_409 (E : Nat → Bool) : (valuation E).satisfies [.neg 408, .pos 17] := by
  change (g409 E = true) → (¬ (g18 E = true)) → False
  exact pattern_12 (g17 E) (g18 E) (g27 E)
private theorem sat_410 (E : Nat → Bool) : (valuation E).satisfies [.neg 408, .pos 26] := by
  change (g409 E = true) → (¬ (g27 E = true)) → False
  exact pattern_13 (g17 E) (g18 E) (g27 E)
private theorem sat_411 (E : Nat → Bool) : (valuation E).satisfies [.neg 26, .neg 17, .neg 16, .pos 408] := by
  change (g27 E = true) → (g18 E = true) → (g17 E = true) → (¬ (g409 E = true)) → False
  exact pattern_14 (g17 E) (g18 E) (g27 E)
private theorem sat_412 (E : Nat → Bool) : (valuation E).satisfies [.neg 409, .pos 16] := by
  change (g410 E = true) → (¬ (g17 E = true)) → False
  exact pattern_11 (g17 E) (g19 E) (g28 E)
private theorem sat_413 (E : Nat → Bool) : (valuation E).satisfies [.neg 409, .pos 18] := by
  change (g410 E = true) → (¬ (g19 E = true)) → False
  exact pattern_12 (g17 E) (g19 E) (g28 E)
private theorem sat_414 (E : Nat → Bool) : (valuation E).satisfies [.neg 409, .pos 27] := by
  change (g410 E = true) → (¬ (g28 E = true)) → False
  exact pattern_13 (g17 E) (g19 E) (g28 E)
private theorem sat_415 (E : Nat → Bool) : (valuation E).satisfies [.neg 27, .neg 18, .neg 16, .pos 409] := by
  change (g28 E = true) → (g19 E = true) → (g17 E = true) → (¬ (g410 E = true)) → False
  exact pattern_14 (g17 E) (g19 E) (g28 E)
private theorem sat_416 (E : Nat → Bool) : (valuation E).satisfies [.neg 410, .pos 17] := by
  change (g411 E = true) → (¬ (g18 E = true)) → False
  exact pattern_11 (g18 E) (g19 E) (g29 E)
private theorem sat_417 (E : Nat → Bool) : (valuation E).satisfies [.neg 410, .pos 18] := by
  change (g411 E = true) → (¬ (g19 E = true)) → False
  exact pattern_12 (g18 E) (g19 E) (g29 E)
private theorem sat_418 (E : Nat → Bool) : (valuation E).satisfies [.neg 410, .pos 28] := by
  change (g411 E = true) → (¬ (g29 E = true)) → False
  exact pattern_13 (g18 E) (g19 E) (g29 E)
private theorem sat_419 (E : Nat → Bool) : (valuation E).satisfies [.neg 28, .neg 18, .neg 17, .pos 410] := by
  change (g29 E = true) → (g19 E = true) → (g18 E = true) → (¬ (g411 E = true)) → False
  exact pattern_14 (g18 E) (g19 E) (g29 E)
private theorem sat_420 (E : Nat → Bool) : (valuation E).satisfies [.neg 411, .pos 19] := by
  change (g412 E = true) → (¬ (g20 E = true)) → False
  exact pattern_11 (g20 E) (g21 E) (g24 E)
private theorem sat_421 (E : Nat → Bool) : (valuation E).satisfies [.neg 411, .pos 20] := by
  change (g412 E = true) → (¬ (g21 E = true)) → False
  exact pattern_12 (g20 E) (g21 E) (g24 E)
private theorem sat_422 (E : Nat → Bool) : (valuation E).satisfies [.neg 411, .pos 23] := by
  change (g412 E = true) → (¬ (g24 E = true)) → False
  exact pattern_13 (g20 E) (g21 E) (g24 E)
private theorem sat_423 (E : Nat → Bool) : (valuation E).satisfies [.neg 412, .pos 19] := by
  change (g413 E = true) → (¬ (g20 E = true)) → False
  exact pattern_11 (g20 E) (g22 E) (g25 E)
private theorem sat_424 (E : Nat → Bool) : (valuation E).satisfies [.neg 412, .pos 21] := by
  change (g413 E = true) → (¬ (g22 E = true)) → False
  exact pattern_12 (g20 E) (g22 E) (g25 E)
private theorem sat_425 (E : Nat → Bool) : (valuation E).satisfies [.neg 412, .pos 24] := by
  change (g413 E = true) → (¬ (g25 E = true)) → False
  exact pattern_13 (g20 E) (g22 E) (g25 E)
private theorem sat_426 (E : Nat → Bool) : (valuation E).satisfies [.neg 413, .pos 19] := by
  change (g414 E = true) → (¬ (g20 E = true)) → False
  exact pattern_11 (g20 E) (g23 E) (g26 E)
private theorem sat_427 (E : Nat → Bool) : (valuation E).satisfies [.neg 413, .pos 22] := by
  change (g414 E = true) → (¬ (g23 E = true)) → False
  exact pattern_12 (g20 E) (g23 E) (g26 E)
private theorem sat_428 (E : Nat → Bool) : (valuation E).satisfies [.neg 413, .pos 25] := by
  change (g414 E = true) → (¬ (g26 E = true)) → False
  exact pattern_13 (g20 E) (g23 E) (g26 E)
private theorem sat_429 (E : Nat → Bool) : (valuation E).satisfies [.neg 414, .pos 20] := by
  change (g415 E = true) → (¬ (g21 E = true)) → False
  exact pattern_11 (g21 E) (g22 E) (g27 E)
private theorem sat_430 (E : Nat → Bool) : (valuation E).satisfies [.neg 414, .pos 21] := by
  change (g415 E = true) → (¬ (g22 E = true)) → False
  exact pattern_12 (g21 E) (g22 E) (g27 E)
private theorem sat_431 (E : Nat → Bool) : (valuation E).satisfies [.neg 414, .pos 26] := by
  change (g415 E = true) → (¬ (g27 E = true)) → False
  exact pattern_13 (g21 E) (g22 E) (g27 E)
private theorem sat_432 (E : Nat → Bool) : (valuation E).satisfies [.neg 26, .neg 21, .neg 20, .pos 414] := by
  change (g27 E = true) → (g22 E = true) → (g21 E = true) → (¬ (g415 E = true)) → False
  exact pattern_14 (g21 E) (g22 E) (g27 E)
private theorem sat_433 (E : Nat → Bool) : (valuation E).satisfies [.neg 415, .pos 20] := by
  change (g416 E = true) → (¬ (g21 E = true)) → False
  exact pattern_11 (g21 E) (g23 E) (g28 E)
private theorem sat_434 (E : Nat → Bool) : (valuation E).satisfies [.neg 415, .pos 22] := by
  change (g416 E = true) → (¬ (g23 E = true)) → False
  exact pattern_12 (g21 E) (g23 E) (g28 E)
private theorem sat_435 (E : Nat → Bool) : (valuation E).satisfies [.neg 415, .pos 27] := by
  change (g416 E = true) → (¬ (g28 E = true)) → False
  exact pattern_13 (g21 E) (g23 E) (g28 E)
private theorem sat_436 (E : Nat → Bool) : (valuation E).satisfies [.neg 27, .neg 22, .neg 20, .pos 415] := by
  change (g28 E = true) → (g23 E = true) → (g21 E = true) → (¬ (g416 E = true)) → False
  exact pattern_14 (g21 E) (g23 E) (g28 E)
private theorem sat_437 (E : Nat → Bool) : (valuation E).satisfies [.neg 416, .pos 21] := by
  change (g417 E = true) → (¬ (g22 E = true)) → False
  exact pattern_11 (g22 E) (g23 E) (g29 E)
private theorem sat_438 (E : Nat → Bool) : (valuation E).satisfies [.neg 416, .pos 22] := by
  change (g417 E = true) → (¬ (g23 E = true)) → False
  exact pattern_12 (g22 E) (g23 E) (g29 E)
private theorem sat_439 (E : Nat → Bool) : (valuation E).satisfies [.neg 416, .pos 28] := by
  change (g417 E = true) → (¬ (g29 E = true)) → False
  exact pattern_13 (g22 E) (g23 E) (g29 E)
private theorem sat_440 (E : Nat → Bool) : (valuation E).satisfies [.neg 28, .neg 22, .neg 21, .pos 416] := by
  change (g29 E = true) → (g23 E = true) → (g22 E = true) → (¬ (g417 E = true)) → False
  exact pattern_14 (g22 E) (g23 E) (g29 E)
private theorem sat_441 (E : Nat → Bool) : (valuation E).satisfies [.neg 421, .neg 366] := by
  change (g422 E = true) → (g367 E = true) → False
  exact pattern_9 (g366 E) (g367 E)
private theorem sat_442 (E : Nat → Bool) : (valuation E).satisfies [.neg 421, .neg 365] := by
  change (g422 E = true) → (g366 E = true) → False
  exact pattern_7 (g366 E) (g367 E)
private theorem sat_443 (E : Nat → Bool) : (valuation E).satisfies [.pos 365, .pos 366, .pos 421] := by
  change (¬ (g366 E = true)) → (¬ (g367 E = true)) → (¬ (g422 E = true)) → False
  exact pattern_0 (g366 E) (g367 E)
private theorem sat_444 (E : Nat → Bool) : (valuation E).satisfies [.neg 422, .pos 365] := by
  change (g423 E = true) → (¬ (g366 E = true)) → False
  exact pattern_1 (g366 E) (g367 E)
private theorem sat_445 (E : Nat → Bool) : (valuation E).satisfies [.neg 422, .pos 366] := by
  change (g423 E = true) → (¬ (g367 E = true)) → False
  exact pattern_2 (g366 E) (g367 E)
private theorem pattern_15 (x0 x1 : Bool) : (x1=true) → (x0=true) → (¬ (((x0) && (x1))=true)) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_446 (E : Nat → Bool) : (valuation E).satisfies [.neg 366, .neg 365, .pos 422] := by
  change (g367 E = true) → (g366 E = true) → (¬ (g423 E = true)) → False
  exact pattern_15 (g366 E) (g367 E)
private theorem sat_447 (E : Nat → Bool) : (valuation E).satisfies [.neg 423, .neg 367] := by
  change (g424 E = true) → (g368 E = true) → False
  exact pattern_8 (g368 E) (g422 E)
private theorem sat_448 (E : Nat → Bool) : (valuation E).satisfies [.neg 423, .pos 421] := by
  change (g424 E = true) → (¬ (g422 E = true)) → False
  exact pattern_10 (g368 E) (g422 E)
private theorem sat_449 (E : Nat → Bool) : (valuation E).satisfies [.neg 421, .pos 367, .pos 423] := by
  change (g422 E = true) → (¬ (g368 E = true)) → (¬ (g424 E = true)) → False
  exact pattern_3 (g368 E) (g422 E)
private theorem sat_450 (E : Nat → Bool) : (valuation E).satisfies [.neg 424, .pos 367] := by
  change (g425 E = true) → (¬ (g368 E = true)) → False
  exact pattern_5 (g368 E) (g422 E)
private theorem sat_451 (E : Nat → Bool) : (valuation E).satisfies [.neg 425, .neg 422] := by
  change (g426 E = true) → (g423 E = true) → False
  exact pattern_7 (g423 E) (g425 E)
private theorem sat_452 (E : Nat → Bool) : (valuation E).satisfies [.pos 422, .pos 424, .pos 425] := by
  change (¬ (g423 E = true)) → (¬ (g425 E = true)) → (¬ (g426 E = true)) → False
  exact pattern_0 (g423 E) (g425 E)
private theorem sat_453 (E : Nat → Bool) : (valuation E).satisfies [.neg 427, .neg 368] := by
  change (g428 E = true) → (g369 E = true) → False
  exact pattern_8 (g369 E) (g424 E)
private theorem sat_454 (E : Nat → Bool) : (valuation E).satisfies [.neg 427, .pos 423] := by
  change (g428 E = true) → (¬ (g424 E = true)) → False
  exact pattern_10 (g369 E) (g424 E)
private theorem sat_455 (E : Nat → Bool) : (valuation E).satisfies [.neg 423, .pos 368, .pos 427] := by
  change (g424 E = true) → (¬ (g369 E = true)) → (¬ (g428 E = true)) → False
  exact pattern_3 (g369 E) (g424 E)
private theorem sat_456 (E : Nat → Bool) : (valuation E).satisfies [.neg 428, .neg 423] := by
  change (g429 E = true) → (g424 E = true) → False
  exact pattern_4 (g369 E) (g424 E)
private theorem sat_457 (E : Nat → Bool) : (valuation E).satisfies [.neg 428, .pos 368] := by
  change (g429 E = true) → (¬ (g369 E = true)) → False
  exact pattern_5 (g369 E) (g424 E)
private theorem sat_458 (E : Nat → Bool) : (valuation E).satisfies [.neg 429, .pos 425] := by
  change (g430 E = true) → (¬ (g426 E = true)) → False
  exact pattern_5 (g426 E) (g429 E)
private theorem sat_459 (E : Nat → Bool) : (valuation E).satisfies [.neg 425, .pos 428, .pos 429] := by
  change (g426 E = true) → (¬ (g429 E = true)) → (¬ (g430 E = true)) → False
  exact pattern_6 (g426 E) (g429 E)
private theorem sat_460 (E : Nat → Bool) : (valuation E).satisfies [.neg 433, .neg 369] := by
  change (g434 E = true) → (g370 E = true) → False
  exact pattern_8 (g370 E) (g428 E)
private theorem sat_461 (E : Nat → Bool) : (valuation E).satisfies [.neg 433, .pos 427] := by
  change (g434 E = true) → (¬ (g428 E = true)) → False
  exact pattern_10 (g370 E) (g428 E)
private theorem sat_462 (E : Nat → Bool) : (valuation E).satisfies [.neg 427, .pos 369, .pos 433] := by
  change (g428 E = true) → (¬ (g370 E = true)) → (¬ (g434 E = true)) → False
  exact pattern_3 (g370 E) (g428 E)
private theorem sat_463 (E : Nat → Bool) : (valuation E).satisfies [.neg 434, .neg 427] := by
  change (g435 E = true) → (g428 E = true) → False
  exact pattern_4 (g370 E) (g428 E)
private theorem sat_464 (E : Nat → Bool) : (valuation E).satisfies [.neg 434, .pos 369] := by
  change (g435 E = true) → (¬ (g370 E = true)) → False
  exact pattern_5 (g370 E) (g428 E)
private theorem sat_465 (E : Nat → Bool) : (valuation E).satisfies [.neg 369, .pos 427, .pos 434] := by
  change (g370 E = true) → (¬ (g428 E = true)) → (¬ (g435 E = true)) → False
  exact pattern_6 (g370 E) (g428 E)
private theorem sat_466 (E : Nat → Bool) : (valuation E).satisfies [.neg 435, .pos 429] := by
  change (g436 E = true) → (¬ (g430 E = true)) → False
  exact pattern_5 (g430 E) (g435 E)
private theorem sat_467 (E : Nat → Bool) : (valuation E).satisfies [.neg 429, .pos 434, .pos 435] := by
  change (g430 E = true) → (¬ (g435 E = true)) → (¬ (g436 E = true)) → False
  exact pattern_6 (g430 E) (g435 E)
private theorem sat_468 (E : Nat → Bool) : (valuation E).satisfies [.neg 441, .neg 370] := by
  change (g442 E = true) → (g371 E = true) → False
  exact pattern_8 (g371 E) (g434 E)
private theorem sat_469 (E : Nat → Bool) : (valuation E).satisfies [.neg 441, .pos 433] := by
  change (g442 E = true) → (¬ (g434 E = true)) → False
  exact pattern_10 (g371 E) (g434 E)
private theorem sat_470 (E : Nat → Bool) : (valuation E).satisfies [.neg 433, .pos 370, .pos 441] := by
  change (g434 E = true) → (¬ (g371 E = true)) → (¬ (g442 E = true)) → False
  exact pattern_3 (g371 E) (g434 E)
private theorem sat_471 (E : Nat → Bool) : (valuation E).satisfies [.neg 442, .neg 433] := by
  change (g443 E = true) → (g434 E = true) → False
  exact pattern_4 (g371 E) (g434 E)
private theorem sat_472 (E : Nat → Bool) : (valuation E).satisfies [.neg 442, .pos 370] := by
  change (g443 E = true) → (¬ (g371 E = true)) → False
  exact pattern_5 (g371 E) (g434 E)
private theorem sat_473 (E : Nat → Bool) : (valuation E).satisfies [.neg 370, .pos 433, .pos 442] := by
  change (g371 E = true) → (¬ (g434 E = true)) → (¬ (g443 E = true)) → False
  exact pattern_6 (g371 E) (g434 E)
private theorem sat_474 (E : Nat → Bool) : (valuation E).satisfies [.neg 443, .neg 442] := by
  change (g444 E = true) → (g443 E = true) → False
  exact pattern_4 (g436 E) (g443 E)
private theorem sat_475 (E : Nat → Bool) : (valuation E).satisfies [.neg 443, .pos 435] := by
  change (g444 E = true) → (¬ (g436 E = true)) → False
  exact pattern_5 (g436 E) (g443 E)
private theorem sat_476 (E : Nat → Bool) : (valuation E).satisfies [.neg 435, .pos 442, .pos 443] := by
  change (g436 E = true) → (¬ (g443 E = true)) → (¬ (g444 E = true)) → False
  exact pattern_6 (g436 E) (g443 E)
private theorem sat_477 (E : Nat → Bool) : (valuation E).satisfies [.neg 451, .pos 441] := by
  change (g452 E = true) → (¬ (g442 E = true)) → False
  exact pattern_10 (g372 E) (g442 E)
private theorem sat_478 (E : Nat → Bool) : (valuation E).satisfies [.neg 441, .pos 371, .pos 451] := by
  change (g442 E = true) → (¬ (g372 E = true)) → (¬ (g452 E = true)) → False
  exact pattern_3 (g372 E) (g442 E)
private theorem sat_479 (E : Nat → Bool) : (valuation E).satisfies [.neg 452, .neg 441] := by
  change (g453 E = true) → (g442 E = true) → False
  exact pattern_4 (g372 E) (g442 E)
private theorem sat_480 (E : Nat → Bool) : (valuation E).satisfies [.neg 452, .pos 371] := by
  change (g453 E = true) → (¬ (g372 E = true)) → False
  exact pattern_5 (g372 E) (g442 E)
private theorem sat_481 (E : Nat → Bool) : (valuation E).satisfies [.neg 453, .pos 443] := by
  change (g454 E = true) → (¬ (g444 E = true)) → False
  exact pattern_5 (g444 E) (g453 E)
private theorem sat_482 (E : Nat → Bool) : (valuation E).satisfies [.neg 443, .pos 452, .pos 453] := by
  change (g444 E = true) → (¬ (g453 E = true)) → (¬ (g454 E = true)) → False
  exact pattern_6 (g444 E) (g453 E)
private theorem sat_483 (E : Nat → Bool) : (valuation E).satisfies [.neg 371, .pos 443, .pos 454] := by
  change (g372 E = true) → (¬ (g444 E = true)) → (¬ (g455 E = true)) → False
  exact pattern_6 (g372 E) (g444 E)
private theorem sat_484 (E : Nat → Bool) : (valuation E).satisfies [.neg 455, .neg 454] := by
  change (g456 E = true) → (g455 E = true) → False
  exact pattern_4 (g446 E) (g455 E)
private theorem sat_485 (E : Nat → Bool) : (valuation E).satisfies [.neg 463, .neg 372] := by
  change (g464 E = true) → (g373 E = true) → False
  exact pattern_8 (g373 E) (g452 E)
private theorem sat_486 (E : Nat → Bool) : (valuation E).satisfies [.neg 463, .pos 451] := by
  change (g464 E = true) → (¬ (g452 E = true)) → False
  exact pattern_10 (g373 E) (g452 E)
private theorem sat_487 (E : Nat → Bool) : (valuation E).satisfies [.neg 451, .pos 372, .pos 463] := by
  change (g452 E = true) → (¬ (g373 E = true)) → (¬ (g464 E = true)) → False
  exact pattern_3 (g373 E) (g452 E)
private theorem sat_488 (E : Nat → Bool) : (valuation E).satisfies [.neg 464, .pos 372] := by
  change (g465 E = true) → (¬ (g373 E = true)) → False
  exact pattern_5 (g373 E) (g452 E)
private theorem sat_489 (E : Nat → Bool) : (valuation E).satisfies [.neg 465, .pos 453] := by
  change (g466 E = true) → (¬ (g454 E = true)) → False
  exact pattern_5 (g454 E) (g465 E)
private theorem sat_490 (E : Nat → Bool) : (valuation E).satisfies [.neg 453, .pos 464, .pos 465] := by
  change (g454 E = true) → (¬ (g465 E = true)) → (¬ (g466 E = true)) → False
  exact pattern_6 (g454 E) (g465 E)
private theorem sat_491 (E : Nat → Bool) : (valuation E).satisfies [.neg 467, .pos 455] := by
  change (g468 E = true) → (¬ (g456 E = true)) → False
  exact pattern_5 (g456 E) (g467 E)
private theorem sat_492 (E : Nat → Bool) : (valuation E).satisfies [.neg 477, .neg 373] := by
  change (g478 E = true) → (g374 E = true) → False
  exact pattern_8 (g374 E) (g464 E)
private theorem sat_493 (E : Nat → Bool) : (valuation E).satisfies [.neg 477, .pos 463] := by
  change (g478 E = true) → (¬ (g464 E = true)) → False
  exact pattern_10 (g374 E) (g464 E)
private theorem sat_494 (E : Nat → Bool) : (valuation E).satisfies [.neg 463, .pos 373, .pos 477] := by
  change (g464 E = true) → (¬ (g374 E = true)) → (¬ (g478 E = true)) → False
  exact pattern_3 (g374 E) (g464 E)
private theorem sat_495 (E : Nat → Bool) : (valuation E).satisfies [.neg 478, .pos 373] := by
  change (g479 E = true) → (¬ (g374 E = true)) → False
  exact pattern_5 (g374 E) (g464 E)
private theorem sat_496 (E : Nat → Bool) : (valuation E).satisfies [.neg 479, .pos 465] := by
  change (g480 E = true) → (¬ (g466 E = true)) → False
  exact pattern_5 (g466 E) (g479 E)
private theorem sat_497 (E : Nat → Bool) : (valuation E).satisfies [.neg 465, .pos 478, .pos 479] := by
  change (g466 E = true) → (¬ (g479 E = true)) → (¬ (g480 E = true)) → False
  exact pattern_6 (g466 E) (g479 E)
private theorem sat_498 (E : Nat → Bool) : (valuation E).satisfies [.neg 481, .pos 467] := by
  change (g482 E = true) → (¬ (g468 E = true)) → False
  exact pattern_5 (g468 E) (g481 E)
private theorem sat_499 (E : Nat → Bool) : (valuation E).satisfies [.neg 493, .neg 374] := by
  change (g494 E = true) → (g375 E = true) → False
  exact pattern_8 (g375 E) (g478 E)
private theorem sat_500 (E : Nat → Bool) : (valuation E).satisfies [.neg 493, .pos 477] := by
  change (g494 E = true) → (¬ (g478 E = true)) → False
  exact pattern_10 (g375 E) (g478 E)
private theorem sat_501 (E : Nat → Bool) : (valuation E).satisfies [.neg 477, .pos 374, .pos 493] := by
  change (g478 E = true) → (¬ (g375 E = true)) → (¬ (g494 E = true)) → False
  exact pattern_3 (g375 E) (g478 E)
private theorem sat_502 (E : Nat → Bool) : (valuation E).satisfies [.neg 494, .pos 374] := by
  change (g495 E = true) → (¬ (g375 E = true)) → False
  exact pattern_5 (g375 E) (g478 E)
private theorem sat_503 (E : Nat → Bool) : (valuation E).satisfies [.neg 495, .pos 479] := by
  change (g496 E = true) → (¬ (g480 E = true)) → False
  exact pattern_5 (g480 E) (g495 E)
private theorem sat_504 (E : Nat → Bool) : (valuation E).satisfies [.neg 479, .pos 494, .pos 495] := by
  change (g480 E = true) → (¬ (g495 E = true)) → (¬ (g496 E = true)) → False
  exact pattern_6 (g480 E) (g495 E)
private theorem sat_505 (E : Nat → Bool) : (valuation E).satisfies [.neg 497, .pos 481] := by
  change (g498 E = true) → (¬ (g482 E = true)) → False
  exact pattern_5 (g482 E) (g497 E)
private theorem sat_506 (E : Nat → Bool) : (valuation E).satisfies [.neg 511, .neg 375] := by
  change (g512 E = true) → (g376 E = true) → False
  exact pattern_8 (g376 E) (g494 E)
private theorem sat_507 (E : Nat → Bool) : (valuation E).satisfies [.neg 511, .pos 493] := by
  change (g512 E = true) → (¬ (g494 E = true)) → False
  exact pattern_10 (g376 E) (g494 E)
private theorem sat_508 (E : Nat → Bool) : (valuation E).satisfies [.neg 493, .pos 375, .pos 511] := by
  change (g494 E = true) → (¬ (g376 E = true)) → (¬ (g512 E = true)) → False
  exact pattern_3 (g376 E) (g494 E)
private theorem sat_509 (E : Nat → Bool) : (valuation E).satisfies [.neg 512, .pos 375] := by
  change (g513 E = true) → (¬ (g376 E = true)) → False
  exact pattern_5 (g376 E) (g494 E)
private theorem sat_510 (E : Nat → Bool) : (valuation E).satisfies [.neg 513, .pos 495] := by
  change (g514 E = true) → (¬ (g496 E = true)) → False
  exact pattern_5 (g496 E) (g513 E)
private theorem sat_511 (E : Nat → Bool) : (valuation E).satisfies [.neg 495, .pos 512, .pos 513] := by
  change (g496 E = true) → (¬ (g513 E = true)) → (¬ (g514 E = true)) → False
  exact pattern_6 (g496 E) (g513 E)
private theorem sat_512 (E : Nat → Bool) : (valuation E).satisfies [.neg 375, .pos 495, .pos 514] := by
  change (g376 E = true) → (¬ (g496 E = true)) → (¬ (g515 E = true)) → False
  exact pattern_6 (g376 E) (g496 E)
private theorem sat_513 (E : Nat → Bool) : (valuation E).satisfies [.neg 515, .neg 514] := by
  change (g516 E = true) → (g515 E = true) → False
  exact pattern_4 (g498 E) (g515 E)
private theorem sat_514 (E : Nat → Bool) : (valuation E).satisfies [.neg 515, .pos 497] := by
  change (g516 E = true) → (¬ (g498 E = true)) → False
  exact pattern_5 (g498 E) (g515 E)
private theorem sat_515 (E : Nat → Bool) : (valuation E).satisfies [.neg 531, .neg 376] := by
  change (g532 E = true) → (g377 E = true) → False
  exact pattern_8 (g377 E) (g512 E)
private theorem sat_516 (E : Nat → Bool) : (valuation E).satisfies [.neg 531, .pos 511] := by
  change (g532 E = true) → (¬ (g512 E = true)) → False
  exact pattern_10 (g377 E) (g512 E)
private theorem sat_517 (E : Nat → Bool) : (valuation E).satisfies [.neg 511, .pos 376, .pos 531] := by
  change (g512 E = true) → (¬ (g377 E = true)) → (¬ (g532 E = true)) → False
  exact pattern_3 (g377 E) (g512 E)
private theorem sat_518 (E : Nat → Bool) : (valuation E).satisfies [.neg 532, .pos 376] := by
  change (g533 E = true) → (¬ (g377 E = true)) → False
  exact pattern_5 (g377 E) (g512 E)
private theorem sat_519 (E : Nat → Bool) : (valuation E).satisfies [.neg 533, .pos 513] := by
  change (g534 E = true) → (¬ (g514 E = true)) → False
  exact pattern_5 (g514 E) (g533 E)
private theorem sat_520 (E : Nat → Bool) : (valuation E).satisfies [.neg 513, .pos 532, .pos 533] := by
  change (g514 E = true) → (¬ (g533 E = true)) → (¬ (g534 E = true)) → False
  exact pattern_6 (g514 E) (g533 E)
private theorem sat_521 (E : Nat → Bool) : (valuation E).satisfies [.neg 535, .pos 515] := by
  change (g536 E = true) → (¬ (g516 E = true)) → False
  exact pattern_5 (g516 E) (g535 E)
private theorem sat_522 (E : Nat → Bool) : (valuation E).satisfies [.neg 553, .neg 377] := by
  change (g554 E = true) → (g378 E = true) → False
  exact pattern_8 (g378 E) (g532 E)
private theorem sat_523 (E : Nat → Bool) : (valuation E).satisfies [.neg 553, .pos 531] := by
  change (g554 E = true) → (¬ (g532 E = true)) → False
  exact pattern_10 (g378 E) (g532 E)
private theorem sat_524 (E : Nat → Bool) : (valuation E).satisfies [.neg 531, .pos 377, .pos 553] := by
  change (g532 E = true) → (¬ (g378 E = true)) → (¬ (g554 E = true)) → False
  exact pattern_3 (g378 E) (g532 E)
private theorem sat_525 (E : Nat → Bool) : (valuation E).satisfies [.neg 554, .pos 377] := by
  change (g555 E = true) → (¬ (g378 E = true)) → False
  exact pattern_5 (g378 E) (g532 E)
private theorem sat_526 (E : Nat → Bool) : (valuation E).satisfies [.neg 377, .pos 531, .pos 554] := by
  change (g378 E = true) → (¬ (g532 E = true)) → (¬ (g555 E = true)) → False
  exact pattern_6 (g378 E) (g532 E)
private theorem sat_527 (E : Nat → Bool) : (valuation E).satisfies [.neg 555, .neg 554] := by
  change (g556 E = true) → (g555 E = true) → False
  exact pattern_4 (g534 E) (g555 E)
private theorem sat_528 (E : Nat → Bool) : (valuation E).satisfies [.neg 555, .pos 533] := by
  change (g556 E = true) → (¬ (g534 E = true)) → False
  exact pattern_5 (g534 E) (g555 E)
private theorem sat_529 (E : Nat → Bool) : (valuation E).satisfies [.neg 533, .pos 554, .pos 555] := by
  change (g534 E = true) → (¬ (g555 E = true)) → (¬ (g556 E = true)) → False
  exact pattern_6 (g534 E) (g555 E)
private theorem sat_530 (E : Nat → Bool) : (valuation E).satisfies [.neg 557, .pos 535] := by
  change (g558 E = true) → (¬ (g536 E = true)) → False
  exact pattern_5 (g536 E) (g557 E)
private theorem sat_531 (E : Nat → Bool) : (valuation E).satisfies [.neg 577, .neg 378] := by
  change (g578 E = true) → (g379 E = true) → False
  exact pattern_8 (g379 E) (g554 E)
private theorem sat_532 (E : Nat → Bool) : (valuation E).satisfies [.neg 577, .pos 553] := by
  change (g578 E = true) → (¬ (g554 E = true)) → False
  exact pattern_10 (g379 E) (g554 E)
private theorem sat_533 (E : Nat → Bool) : (valuation E).satisfies [.neg 553, .pos 378, .pos 577] := by
  change (g554 E = true) → (¬ (g379 E = true)) → (¬ (g578 E = true)) → False
  exact pattern_3 (g379 E) (g554 E)
private theorem sat_534 (E : Nat → Bool) : (valuation E).satisfies [.neg 578, .pos 378] := by
  change (g579 E = true) → (¬ (g379 E = true)) → False
  exact pattern_5 (g379 E) (g554 E)
private theorem sat_535 (E : Nat → Bool) : (valuation E).satisfies [.neg 378, .pos 553, .pos 578] := by
  change (g379 E = true) → (¬ (g554 E = true)) → (¬ (g579 E = true)) → False
  exact pattern_6 (g379 E) (g554 E)
private theorem sat_536 (E : Nat → Bool) : (valuation E).satisfies [.neg 579, .neg 578] := by
  change (g580 E = true) → (g579 E = true) → False
  exact pattern_4 (g556 E) (g579 E)
private theorem sat_537 (E : Nat → Bool) : (valuation E).satisfies [.neg 579, .pos 555] := by
  change (g580 E = true) → (¬ (g556 E = true)) → False
  exact pattern_5 (g556 E) (g579 E)
private theorem sat_538 (E : Nat → Bool) : (valuation E).satisfies [.neg 555, .pos 578, .pos 579] := by
  change (g556 E = true) → (¬ (g579 E = true)) → (¬ (g580 E = true)) → False
  exact pattern_6 (g556 E) (g579 E)
private theorem sat_539 (E : Nat → Bool) : (valuation E).satisfies [.neg 378, .pos 555, .pos 580] := by
  change (g379 E = true) → (¬ (g556 E = true)) → (¬ (g581 E = true)) → False
  exact pattern_6 (g379 E) (g556 E)
private theorem sat_540 (E : Nat → Bool) : (valuation E).satisfies [.neg 581, .neg 580] := by
  change (g582 E = true) → (g581 E = true) → False
  exact pattern_4 (g558 E) (g581 E)
private theorem sat_541 (E : Nat → Bool) : (valuation E).satisfies [.neg 581, .pos 557] := by
  change (g582 E = true) → (¬ (g558 E = true)) → False
  exact pattern_5 (g558 E) (g581 E)
private theorem sat_542 (E : Nat → Bool) : (valuation E).satisfies [.neg 603, .pos 577] := by
  change (g604 E = true) → (¬ (g578 E = true)) → False
  exact pattern_10 (g380 E) (g578 E)
private theorem sat_543 (E : Nat → Bool) : (valuation E).satisfies [.neg 604, .neg 577] := by
  change (g605 E = true) → (g578 E = true) → False
  exact pattern_4 (g380 E) (g578 E)
private theorem sat_544 (E : Nat → Bool) : (valuation E).satisfies [.neg 604, .pos 379] := by
  change (g605 E = true) → (¬ (g380 E = true)) → False
  exact pattern_5 (g380 E) (g578 E)
private theorem sat_545 (E : Nat → Bool) : (valuation E).satisfies [.neg 379, .pos 577, .pos 604] := by
  change (g380 E = true) → (¬ (g578 E = true)) → (¬ (g605 E = true)) → False
  exact pattern_6 (g380 E) (g578 E)
private theorem sat_546 (E : Nat → Bool) : (valuation E).satisfies [.neg 605, .neg 604] := by
  change (g606 E = true) → (g605 E = true) → False
  exact pattern_4 (g580 E) (g605 E)
private theorem sat_547 (E : Nat → Bool) : (valuation E).satisfies [.neg 605, .pos 579] := by
  change (g606 E = true) → (¬ (g580 E = true)) → False
  exact pattern_5 (g580 E) (g605 E)
private theorem sat_548 (E : Nat → Bool) : (valuation E).satisfies [.neg 579, .pos 604, .pos 605] := by
  change (g580 E = true) → (¬ (g605 E = true)) → (¬ (g606 E = true)) → False
  exact pattern_6 (g580 E) (g605 E)
private theorem sat_549 (E : Nat → Bool) : (valuation E).satisfies [.neg 379, .pos 579, .pos 606] := by
  change (g380 E = true) → (¬ (g580 E = true)) → (¬ (g607 E = true)) → False
  exact pattern_6 (g380 E) (g580 E)
private theorem sat_550 (E : Nat → Bool) : (valuation E).satisfies [.neg 607, .neg 606] := by
  change (g608 E = true) → (g607 E = true) → False
  exact pattern_4 (g582 E) (g607 E)
private theorem sat_551 (E : Nat → Bool) : (valuation E).satisfies [.neg 607, .pos 581] := by
  change (g608 E = true) → (¬ (g582 E = true)) → False
  exact pattern_5 (g582 E) (g607 E)
private theorem sat_552 (E : Nat → Bool) : (valuation E).satisfies [.neg 379, .pos 581, .pos 608] := by
  change (g380 E = true) → (¬ (g582 E = true)) → (¬ (g609 E = true)) → False
  exact pattern_6 (g380 E) (g582 E)
private theorem sat_553 (E : Nat → Bool) : (valuation E).satisfies [.neg 609, .neg 608] := by
  change (g610 E = true) → (g609 E = true) → False
  exact pattern_4 (g584 E) (g609 E)
private theorem sat_554 (E : Nat → Bool) : (valuation E).satisfies [.neg 631, .pos 603] := by
  change (g632 E = true) → (¬ (g604 E = true)) → False
  exact pattern_10 (g381 E) (g604 E)
private theorem sat_555 (E : Nat → Bool) : (valuation E).satisfies [.neg 632, .pos 380] := by
  change (g633 E = true) → (¬ (g381 E = true)) → False
  exact pattern_5 (g381 E) (g604 E)
private theorem sat_556 (E : Nat → Bool) : (valuation E).satisfies [.neg 633, .pos 605] := by
  change (g634 E = true) → (¬ (g606 E = true)) → False
  exact pattern_5 (g606 E) (g633 E)
private theorem sat_557 (E : Nat → Bool) : (valuation E).satisfies [.neg 605, .pos 632, .pos 633] := by
  change (g606 E = true) → (¬ (g633 E = true)) → (¬ (g634 E = true)) → False
  exact pattern_6 (g606 E) (g633 E)
private theorem sat_558 (E : Nat → Bool) : (valuation E).satisfies [.neg 635, .pos 607] := by
  change (g636 E = true) → (¬ (g608 E = true)) → False
  exact pattern_5 (g608 E) (g635 E)
private theorem sat_559 (E : Nat → Bool) : (valuation E).satisfies [.neg 637, .pos 609] := by
  change (g638 E = true) → (¬ (g610 E = true)) → False
  exact pattern_5 (g610 E) (g637 E)
private theorem sat_560 (E : Nat → Bool) : (valuation E).satisfies [.neg 661, .pos 631] := by
  change (g662 E = true) → (¬ (g632 E = true)) → False
  exact pattern_10 (g382 E) (g632 E)
private theorem sat_561 (E : Nat → Bool) : (valuation E).satisfies [.neg 662, .pos 381] := by
  change (g663 E = true) → (¬ (g382 E = true)) → False
  exact pattern_5 (g382 E) (g632 E)
private theorem sat_562 (E : Nat → Bool) : (valuation E).satisfies [.neg 663, .pos 633] := by
  change (g664 E = true) → (¬ (g634 E = true)) → False
  exact pattern_5 (g634 E) (g663 E)
private theorem sat_563 (E : Nat → Bool) : (valuation E).satisfies [.neg 633, .pos 662, .pos 663] := by
  change (g634 E = true) → (¬ (g663 E = true)) → (¬ (g664 E = true)) → False
  exact pattern_6 (g634 E) (g663 E)
private theorem sat_564 (E : Nat → Bool) : (valuation E).satisfies [.neg 665, .pos 635] := by
  change (g666 E = true) → (¬ (g636 E = true)) → False
  exact pattern_5 (g636 E) (g665 E)
private theorem sat_565 (E : Nat → Bool) : (valuation E).satisfies [.neg 667, .pos 637] := by
  change (g668 E = true) → (¬ (g638 E = true)) → False
  exact pattern_5 (g638 E) (g667 E)
private theorem sat_566 (E : Nat → Bool) : (valuation E).satisfies [.neg 693, .pos 661] := by
  change (g694 E = true) → (¬ (g662 E = true)) → False
  exact pattern_10 (g383 E) (g662 E)
private theorem sat_567 (E : Nat → Bool) : (valuation E).satisfies [.neg 694, .pos 382] := by
  change (g695 E = true) → (¬ (g383 E = true)) → False
  exact pattern_5 (g383 E) (g662 E)
private theorem sat_568 (E : Nat → Bool) : (valuation E).satisfies [.neg 695, .pos 663] := by
  change (g696 E = true) → (¬ (g664 E = true)) → False
  exact pattern_5 (g664 E) (g695 E)
private theorem sat_569 (E : Nat → Bool) : (valuation E).satisfies [.neg 663, .pos 694, .pos 695] := by
  change (g664 E = true) → (¬ (g695 E = true)) → (¬ (g696 E = true)) → False
  exact pattern_6 (g664 E) (g695 E)
private theorem sat_570 (E : Nat → Bool) : (valuation E).satisfies [.neg 697, .pos 665] := by
  change (g698 E = true) → (¬ (g666 E = true)) → False
  exact pattern_5 (g666 E) (g697 E)
private theorem sat_571 (E : Nat → Bool) : (valuation E).satisfies [.neg 699, .pos 667] := by
  change (g700 E = true) → (¬ (g668 E = true)) → False
  exact pattern_5 (g668 E) (g699 E)
private theorem sat_572 (E : Nat → Bool) : (valuation E).satisfies [.neg 727, .neg 383] := by
  change (g728 E = true) → (g384 E = true) → False
  exact pattern_8 (g384 E) (g694 E)
private theorem sat_573 (E : Nat → Bool) : (valuation E).satisfies [.neg 728, .pos 383] := by
  change (g729 E = true) → (¬ (g384 E = true)) → False
  exact pattern_5 (g384 E) (g694 E)
private theorem sat_574 (E : Nat → Bool) : (valuation E).satisfies [.neg 383, .pos 693, .pos 728] := by
  change (g384 E = true) → (¬ (g694 E = true)) → (¬ (g729 E = true)) → False
  exact pattern_6 (g384 E) (g694 E)
private theorem sat_575 (E : Nat → Bool) : (valuation E).satisfies [.neg 729, .neg 728] := by
  change (g730 E = true) → (g729 E = true) → False
  exact pattern_4 (g696 E) (g729 E)
private theorem sat_576 (E : Nat → Bool) : (valuation E).satisfies [.neg 729, .pos 695] := by
  change (g730 E = true) → (¬ (g696 E = true)) → False
  exact pattern_5 (g696 E) (g729 E)
private theorem sat_577 (E : Nat → Bool) : (valuation E).satisfies [.neg 695, .pos 728, .pos 729] := by
  change (g696 E = true) → (¬ (g729 E = true)) → (¬ (g730 E = true)) → False
  exact pattern_6 (g696 E) (g729 E)
private theorem sat_578 (E : Nat → Bool) : (valuation E).satisfies [.neg 383, .pos 695, .pos 730] := by
  change (g384 E = true) → (¬ (g696 E = true)) → (¬ (g731 E = true)) → False
  exact pattern_6 (g384 E) (g696 E)
private theorem sat_579 (E : Nat → Bool) : (valuation E).satisfies [.neg 731, .neg 730] := by
  change (g732 E = true) → (g731 E = true) → False
  exact pattern_4 (g698 E) (g731 E)
private theorem sat_580 (E : Nat → Bool) : (valuation E).satisfies [.neg 731, .pos 697] := by
  change (g732 E = true) → (¬ (g698 E = true)) → False
  exact pattern_5 (g698 E) (g731 E)
private theorem sat_581 (E : Nat → Bool) : (valuation E).satisfies [.neg 733, .pos 699] := by
  change (g734 E = true) → (¬ (g700 E = true)) → False
  exact pattern_5 (g700 E) (g733 E)
private theorem sat_582 (E : Nat → Bool) : (valuation E).satisfies [.neg 764, .pos 384] := by
  change (g765 E = true) → (¬ (g385 E = true)) → False
  exact pattern_5 (g385 E) (g728 E)
private theorem sat_583 (E : Nat → Bool) : (valuation E).satisfies [.neg 384, .pos 727, .pos 764] := by
  change (g385 E = true) → (¬ (g728 E = true)) → (¬ (g765 E = true)) → False
  exact pattern_6 (g385 E) (g728 E)
private theorem sat_584 (E : Nat → Bool) : (valuation E).satisfies [.neg 765, .neg 764] := by
  change (g766 E = true) → (g765 E = true) → False
  exact pattern_4 (g730 E) (g765 E)
private theorem sat_585 (E : Nat → Bool) : (valuation E).satisfies [.neg 765, .pos 729] := by
  change (g766 E = true) → (¬ (g730 E = true)) → False
  exact pattern_5 (g730 E) (g765 E)
private theorem sat_586 (E : Nat → Bool) : (valuation E).satisfies [.neg 729, .pos 764, .pos 765] := by
  change (g730 E = true) → (¬ (g765 E = true)) → (¬ (g766 E = true)) → False
  exact pattern_6 (g730 E) (g765 E)
private theorem sat_587 (E : Nat → Bool) : (valuation E).satisfies [.neg 384, .pos 729, .pos 766] := by
  change (g385 E = true) → (¬ (g730 E = true)) → (¬ (g767 E = true)) → False
  exact pattern_6 (g385 E) (g730 E)
private theorem sat_588 (E : Nat → Bool) : (valuation E).satisfies [.neg 767, .neg 766] := by
  change (g768 E = true) → (g767 E = true) → False
  exact pattern_4 (g732 E) (g767 E)
private theorem sat_589 (E : Nat → Bool) : (valuation E).satisfies [.neg 767, .pos 731] := by
  change (g768 E = true) → (¬ (g732 E = true)) → False
  exact pattern_5 (g732 E) (g767 E)
private theorem sat_590 (E : Nat → Bool) : (valuation E).satisfies [.neg 769, .pos 733] := by
  change (g770 E = true) → (¬ (g734 E = true)) → False
  exact pattern_5 (g734 E) (g769 E)
private theorem sat_591 (E : Nat → Bool) : (valuation E).satisfies [.neg 802, .pos 385] := by
  change (g803 E = true) → (¬ (g386 E = true)) → False
  exact pattern_5 (g386 E) (g764 E)
private theorem sat_592 (E : Nat → Bool) : (valuation E).satisfies [.neg 765, .pos 802, .pos 803] := by
  change (g766 E = true) → (¬ (g803 E = true)) → (¬ (g804 E = true)) → False
  exact pattern_6 (g766 E) (g803 E)
private theorem sat_593 (E : Nat → Bool) : (valuation E).satisfies [.neg 385, .pos 765, .pos 804] := by
  change (g386 E = true) → (¬ (g766 E = true)) → (¬ (g805 E = true)) → False
  exact pattern_6 (g386 E) (g766 E)
private theorem sat_594 (E : Nat → Bool) : (valuation E).satisfies [.neg 805, .neg 804] := by
  change (g806 E = true) → (g805 E = true) → False
  exact pattern_4 (g768 E) (g805 E)
private theorem sat_595 (E : Nat → Bool) : (valuation E).satisfies [.neg 805, .pos 767] := by
  change (g806 E = true) → (¬ (g768 E = true)) → False
  exact pattern_5 (g768 E) (g805 E)
private theorem sat_596 (E : Nat → Bool) : (valuation E).satisfies [.neg 385, .pos 767, .pos 806] := by
  change (g386 E = true) → (¬ (g768 E = true)) → (¬ (g807 E = true)) → False
  exact pattern_6 (g386 E) (g768 E)
private theorem sat_597 (E : Nat → Bool) : (valuation E).satisfies [.neg 807, .neg 806] := by
  change (g808 E = true) → (g807 E = true) → False
  exact pattern_4 (g770 E) (g807 E)
private theorem sat_598 (E : Nat → Bool) : (valuation E).satisfies [.neg 807, .pos 769] := by
  change (g808 E = true) → (¬ (g770 E = true)) → False
  exact pattern_5 (g770 E) (g807 E)
private theorem sat_599 (E : Nat → Bool) : (valuation E).satisfies [.neg 385, .pos 769, .pos 808] := by
  change (g386 E = true) → (¬ (g770 E = true)) → (¬ (g809 E = true)) → False
  exact pattern_6 (g386 E) (g770 E)
private theorem sat_600 (E : Nat → Bool) : (valuation E).satisfies [.neg 809, .neg 808] := by
  change (g810 E = true) → (g809 E = true) → False
  exact pattern_4 (g772 E) (g809 E)
private theorem sat_601 (E : Nat → Bool) : (valuation E).satisfies [.neg 841, .neg 366] := by
  change (g842 E = true) → (g367 E = true) → False
  exact pattern_9 (g366 E) (g367 E)
private theorem sat_602 (E : Nat → Bool) : (valuation E).satisfies [.pos 365, .pos 366, .pos 841] := by
  change (¬ (g366 E = true)) → (¬ (g367 E = true)) → (¬ (g842 E = true)) → False
  exact pattern_0 (g366 E) (g367 E)
private theorem sat_603 (E : Nat → Bool) : (valuation E).satisfies [.neg 842, .pos 365] := by
  change (g843 E = true) → (¬ (g366 E = true)) → False
  exact pattern_1 (g366 E) (g367 E)
private theorem sat_604 (E : Nat → Bool) : (valuation E).satisfies [.neg 842, .pos 366] := by
  change (g843 E = true) → (¬ (g367 E = true)) → False
  exact pattern_2 (g366 E) (g367 E)
private theorem sat_605 (E : Nat → Bool) : (valuation E).satisfies [.neg 843, .pos 841] := by
  change (g844 E = true) → (¬ (g842 E = true)) → False
  exact pattern_10 (g368 E) (g842 E)
private theorem sat_606 (E : Nat → Bool) : (valuation E).satisfies [.neg 841, .pos 367, .pos 843] := by
  change (g842 E = true) → (¬ (g368 E = true)) → (¬ (g844 E = true)) → False
  exact pattern_3 (g368 E) (g842 E)
private theorem sat_607 (E : Nat → Bool) : (valuation E).satisfies [.neg 844, .neg 841] := by
  change (g845 E = true) → (g842 E = true) → False
  exact pattern_4 (g368 E) (g842 E)
private theorem sat_608 (E : Nat → Bool) : (valuation E).satisfies [.neg 844, .pos 367] := by
  change (g845 E = true) → (¬ (g368 E = true)) → False
  exact pattern_5 (g368 E) (g842 E)
private theorem sat_609 (E : Nat → Bool) : (valuation E).satisfies [.pos 842, .pos 844, .pos 845] := by
  change (¬ (g843 E = true)) → (¬ (g845 E = true)) → (¬ (g846 E = true)) → False
  exact pattern_0 (g843 E) (g845 E)
private theorem sat_610 (E : Nat → Bool) : (valuation E).satisfies [.neg 846, .pos 367] := by
  change (g847 E = true) → (¬ (g368 E = true)) → False
  exact pattern_1 (g368 E) (g843 E)
private theorem sat_611 (E : Nat → Bool) : (valuation E).satisfies [.neg 846, .pos 842] := by
  change (g847 E = true) → (¬ (g843 E = true)) → False
  exact pattern_2 (g368 E) (g843 E)
private theorem sat_612 (E : Nat → Bool) : (valuation E).satisfies [.neg 847, .pos 843] := by
  change (g848 E = true) → (¬ (g844 E = true)) → False
  exact pattern_10 (g369 E) (g844 E)
private theorem sat_613 (E : Nat → Bool) : (valuation E).satisfies [.neg 843, .pos 368, .pos 847] := by
  change (g844 E = true) → (¬ (g369 E = true)) → (¬ (g848 E = true)) → False
  exact pattern_3 (g369 E) (g844 E)
private theorem sat_614 (E : Nat → Bool) : (valuation E).satisfies [.neg 848, .neg 843] := by
  change (g849 E = true) → (g844 E = true) → False
  exact pattern_4 (g369 E) (g844 E)
private theorem sat_615 (E : Nat → Bool) : (valuation E).satisfies [.neg 848, .pos 368] := by
  change (g849 E = true) → (¬ (g369 E = true)) → False
  exact pattern_5 (g369 E) (g844 E)
private theorem sat_616 (E : Nat → Bool) : (valuation E).satisfies [.neg 368, .pos 843, .pos 848] := by
  change (g369 E = true) → (¬ (g844 E = true)) → (¬ (g849 E = true)) → False
  exact pattern_6 (g369 E) (g844 E)
private theorem sat_617 (E : Nat → Bool) : (valuation E).satisfies [.neg 849, .neg 848] := by
  change (g850 E = true) → (g849 E = true) → False
  exact pattern_4 (g846 E) (g849 E)
private theorem sat_618 (E : Nat → Bool) : (valuation E).satisfies [.neg 845, .pos 848, .pos 849] := by
  change (g846 E = true) → (¬ (g849 E = true)) → (¬ (g850 E = true)) → False
  exact pattern_6 (g846 E) (g849 E)
private theorem sat_619 (E : Nat → Bool) : (valuation E).satisfies [.neg 850, .neg 845] := by
  change (g851 E = true) → (g846 E = true) → False
  exact pattern_4 (g369 E) (g846 E)
private theorem sat_620 (E : Nat → Bool) : (valuation E).satisfies [.neg 850, .pos 368] := by
  change (g851 E = true) → (¬ (g369 E = true)) → False
  exact pattern_5 (g369 E) (g846 E)
private theorem sat_621 (E : Nat → Bool) : (valuation E).satisfies [.pos 846, .pos 850, .pos 851] := by
  change (¬ (g847 E = true)) → (¬ (g851 E = true)) → (¬ (g852 E = true)) → False
  exact pattern_0 (g847 E) (g851 E)
private theorem sat_622 (E : Nat → Bool) : (valuation E).satisfies [.neg 852, .pos 368] := by
  change (g853 E = true) → (¬ (g369 E = true)) → False
  exact pattern_1 (g369 E) (g847 E)
private theorem sat_623 (E : Nat → Bool) : (valuation E).satisfies [.neg 852, .pos 846] := by
  change (g853 E = true) → (¬ (g847 E = true)) → False
  exact pattern_2 (g369 E) (g847 E)
private theorem sat_624 (E : Nat → Bool) : (valuation E).satisfies [.neg 853, .pos 847] := by
  change (g854 E = true) → (¬ (g848 E = true)) → False
  exact pattern_10 (g370 E) (g848 E)
private theorem sat_625 (E : Nat → Bool) : (valuation E).satisfies [.neg 847, .pos 369, .pos 853] := by
  change (g848 E = true) → (¬ (g370 E = true)) → (¬ (g854 E = true)) → False
  exact pattern_3 (g370 E) (g848 E)
private theorem sat_626 (E : Nat → Bool) : (valuation E).satisfies [.neg 854, .neg 847] := by
  change (g855 E = true) → (g848 E = true) → False
  exact pattern_4 (g370 E) (g848 E)
private theorem sat_627 (E : Nat → Bool) : (valuation E).satisfies [.neg 854, .pos 369] := by
  change (g855 E = true) → (¬ (g370 E = true)) → False
  exact pattern_5 (g370 E) (g848 E)
private theorem sat_628 (E : Nat → Bool) : (valuation E).satisfies [.neg 849, .pos 854, .pos 855] := by
  change (g850 E = true) → (¬ (g855 E = true)) → (¬ (g856 E = true)) → False
  exact pattern_6 (g850 E) (g855 E)
private theorem sat_629 (E : Nat → Bool) : (valuation E).satisfies [.neg 856, .neg 849] := by
  change (g857 E = true) → (g850 E = true) → False
  exact pattern_4 (g370 E) (g850 E)
private theorem sat_630 (E : Nat → Bool) : (valuation E).satisfies [.neg 856, .pos 369] := by
  change (g857 E = true) → (¬ (g370 E = true)) → False
  exact pattern_5 (g370 E) (g850 E)
private theorem sat_631 (E : Nat → Bool) : (valuation E).satisfies [.neg 369, .pos 849, .pos 856] := by
  change (g370 E = true) → (¬ (g850 E = true)) → (¬ (g857 E = true)) → False
  exact pattern_6 (g370 E) (g850 E)
private theorem sat_632 (E : Nat → Bool) : (valuation E).satisfies [.neg 857, .neg 856] := by
  change (g858 E = true) → (g857 E = true) → False
  exact pattern_4 (g852 E) (g857 E)
private theorem sat_633 (E : Nat → Bool) : (valuation E).satisfies [.neg 851, .pos 856, .pos 857] := by
  change (g852 E = true) → (¬ (g857 E = true)) → (¬ (g858 E = true)) → False
  exact pattern_6 (g852 E) (g857 E)
private theorem sat_634 (E : Nat → Bool) : (valuation E).satisfies [.neg 858, .neg 851] := by
  change (g859 E = true) → (g852 E = true) → False
  exact pattern_4 (g370 E) (g852 E)
private theorem sat_635 (E : Nat → Bool) : (valuation E).satisfies [.neg 858, .pos 369] := by
  change (g859 E = true) → (¬ (g370 E = true)) → False
  exact pattern_5 (g370 E) (g852 E)
private theorem sat_636 (E : Nat → Bool) : (valuation E).satisfies [.pos 852, .pos 858, .pos 859] := by
  change (¬ (g853 E = true)) → (¬ (g859 E = true)) → (¬ (g860 E = true)) → False
  exact pattern_0 (g853 E) (g859 E)
private theorem sat_637 (E : Nat → Bool) : (valuation E).satisfies [.neg 861, .pos 853] := by
  change (g862 E = true) → (¬ (g854 E = true)) → False
  exact pattern_10 (g371 E) (g854 E)
private theorem sat_638 (E : Nat → Bool) : (valuation E).satisfies [.neg 853, .pos 370, .pos 861] := by
  change (g854 E = true) → (¬ (g371 E = true)) → (¬ (g862 E = true)) → False
  exact pattern_3 (g371 E) (g854 E)
private theorem sat_639 (E : Nat → Bool) : (valuation E).satisfies [.neg 862, .neg 853] := by
  change (g863 E = true) → (g854 E = true) → False
  exact pattern_4 (g371 E) (g854 E)
private theorem sat_640 (E : Nat → Bool) : (valuation E).satisfies [.neg 862, .pos 370] := by
  change (g863 E = true) → (¬ (g371 E = true)) → False
  exact pattern_5 (g371 E) (g854 E)
private theorem sat_641 (E : Nat → Bool) : (valuation E).satisfies [.neg 370, .pos 853, .pos 862] := by
  change (g371 E = true) → (¬ (g854 E = true)) → (¬ (g863 E = true)) → False
  exact pattern_6 (g371 E) (g854 E)
private theorem sat_642 (E : Nat → Bool) : (valuation E).satisfies [.neg 863, .neg 862] := by
  change (g864 E = true) → (g863 E = true) → False
  exact pattern_4 (g856 E) (g863 E)
private theorem sat_643 (E : Nat → Bool) : (valuation E).satisfies [.neg 863, .pos 855] := by
  change (g864 E = true) → (¬ (g856 E = true)) → False
  exact pattern_5 (g856 E) (g863 E)
private theorem sat_644 (E : Nat → Bool) : (valuation E).satisfies [.neg 855, .pos 862, .pos 863] := by
  change (g856 E = true) → (¬ (g863 E = true)) → (¬ (g864 E = true)) → False
  exact pattern_6 (g856 E) (g863 E)
private theorem sat_645 (E : Nat → Bool) : (valuation E).satisfies [.neg 864, .neg 855] := by
  change (g865 E = true) → (g856 E = true) → False
  exact pattern_4 (g371 E) (g856 E)
private theorem sat_646 (E : Nat → Bool) : (valuation E).satisfies [.neg 864, .pos 370] := by
  change (g865 E = true) → (¬ (g371 E = true)) → False
  exact pattern_5 (g371 E) (g856 E)
private theorem sat_647 (E : Nat → Bool) : (valuation E).satisfies [.neg 865, .pos 857] := by
  change (g866 E = true) → (¬ (g858 E = true)) → False
  exact pattern_5 (g858 E) (g865 E)
private theorem sat_648 (E : Nat → Bool) : (valuation E).satisfies [.neg 857, .pos 864, .pos 865] := by
  change (g858 E = true) → (¬ (g865 E = true)) → (¬ (g866 E = true)) → False
  exact pattern_6 (g858 E) (g865 E)
private theorem sat_649 (E : Nat → Bool) : (valuation E).satisfies [.neg 866, .neg 857] := by
  change (g867 E = true) → (g858 E = true) → False
  exact pattern_4 (g371 E) (g858 E)
private theorem sat_650 (E : Nat → Bool) : (valuation E).satisfies [.neg 866, .pos 370] := by
  change (g867 E = true) → (¬ (g371 E = true)) → False
  exact pattern_5 (g371 E) (g858 E)
private theorem sat_651 (E : Nat → Bool) : (valuation E).satisfies [.neg 859, .pos 866, .pos 867] := by
  change (g860 E = true) → (¬ (g867 E = true)) → (¬ (g868 E = true)) → False
  exact pattern_6 (g860 E) (g867 E)
private theorem sat_652 (E : Nat → Bool) : (valuation E).satisfies [.neg 871, .pos 861] := by
  change (g872 E = true) → (¬ (g862 E = true)) → False
  exact pattern_10 (g387 E) (g862 E)
private theorem sat_653 (E : Nat → Bool) : (valuation E).satisfies [.neg 861, .pos 386, .pos 871] := by
  change (g862 E = true) → (¬ (g387 E = true)) → (¬ (g872 E = true)) → False
  exact pattern_3 (g387 E) (g862 E)
private theorem sat_654 (E : Nat → Bool) : (valuation E).satisfies [.neg 872, .neg 861] := by
  change (g873 E = true) → (g862 E = true) → False
  exact pattern_4 (g387 E) (g862 E)
private theorem sat_655 (E : Nat → Bool) : (valuation E).satisfies [.neg 872, .pos 386] := by
  change (g873 E = true) → (¬ (g387 E = true)) → False
  exact pattern_5 (g387 E) (g862 E)
private theorem sat_656 (E : Nat → Bool) : (valuation E).satisfies [.neg 873, .pos 863] := by
  change (g874 E = true) → (¬ (g864 E = true)) → False
  exact pattern_5 (g864 E) (g873 E)
private theorem sat_657 (E : Nat → Bool) : (valuation E).satisfies [.neg 863, .pos 872, .pos 873] := by
  change (g864 E = true) → (¬ (g873 E = true)) → (¬ (g874 E = true)) → False
  exact pattern_6 (g864 E) (g873 E)
private theorem sat_658 (E : Nat → Bool) : (valuation E).satisfies [.neg 874, .neg 863] := by
  change (g875 E = true) → (g864 E = true) → False
  exact pattern_4 (g387 E) (g864 E)
private theorem sat_659 (E : Nat → Bool) : (valuation E).satisfies [.neg 874, .pos 386] := by
  change (g875 E = true) → (¬ (g387 E = true)) → False
  exact pattern_5 (g387 E) (g864 E)
private theorem sat_660 (E : Nat → Bool) : (valuation E).satisfies [.neg 875, .pos 865] := by
  change (g876 E = true) → (¬ (g866 E = true)) → False
  exact pattern_5 (g866 E) (g875 E)
private theorem sat_661 (E : Nat → Bool) : (valuation E).satisfies [.neg 865, .pos 874, .pos 875] := by
  change (g866 E = true) → (¬ (g875 E = true)) → (¬ (g876 E = true)) → False
  exact pattern_6 (g866 E) (g875 E)
private theorem sat_662 (E : Nat → Bool) : (valuation E).satisfies [.neg 876, .neg 865] := by
  change (g877 E = true) → (g866 E = true) → False
  exact pattern_4 (g387 E) (g866 E)
private theorem sat_663 (E : Nat → Bool) : (valuation E).satisfies [.neg 876, .pos 386] := by
  change (g877 E = true) → (¬ (g387 E = true)) → False
  exact pattern_5 (g387 E) (g866 E)
private theorem sat_664 (E : Nat → Bool) : (valuation E).satisfies [.neg 867, .pos 876, .pos 877] := by
  change (g868 E = true) → (¬ (g877 E = true)) → (¬ (g878 E = true)) → False
  exact pattern_6 (g868 E) (g877 E)
private theorem sat_665 (E : Nat → Bool) : (valuation E).satisfies [.neg 883, .pos 871] := by
  change (g884 E = true) → (¬ (g872 E = true)) → False
  exact pattern_10 (g388 E) (g872 E)
private theorem sat_666 (E : Nat → Bool) : (valuation E).satisfies [.neg 871, .pos 387, .pos 883] := by
  change (g872 E = true) → (¬ (g388 E = true)) → (¬ (g884 E = true)) → False
  exact pattern_3 (g388 E) (g872 E)
private theorem sat_667 (E : Nat → Bool) : (valuation E).satisfies [.neg 884, .neg 871] := by
  change (g885 E = true) → (g872 E = true) → False
  exact pattern_4 (g388 E) (g872 E)
private theorem sat_668 (E : Nat → Bool) : (valuation E).satisfies [.neg 884, .pos 387] := by
  change (g885 E = true) → (¬ (g388 E = true)) → False
  exact pattern_5 (g388 E) (g872 E)
private theorem sat_669 (E : Nat → Bool) : (valuation E).satisfies [.neg 885, .pos 873] := by
  change (g886 E = true) → (¬ (g874 E = true)) → False
  exact pattern_5 (g874 E) (g885 E)
private theorem sat_670 (E : Nat → Bool) : (valuation E).satisfies [.neg 873, .pos 884, .pos 885] := by
  change (g874 E = true) → (¬ (g885 E = true)) → (¬ (g886 E = true)) → False
  exact pattern_6 (g874 E) (g885 E)
private theorem sat_671 (E : Nat → Bool) : (valuation E).satisfies [.neg 886, .neg 873] := by
  change (g887 E = true) → (g874 E = true) → False
  exact pattern_4 (g388 E) (g874 E)
private theorem sat_672 (E : Nat → Bool) : (valuation E).satisfies [.neg 886, .pos 387] := by
  change (g887 E = true) → (¬ (g388 E = true)) → False
  exact pattern_5 (g388 E) (g874 E)
private theorem sat_673 (E : Nat → Bool) : (valuation E).satisfies [.neg 887, .pos 875] := by
  change (g888 E = true) → (¬ (g876 E = true)) → False
  exact pattern_5 (g876 E) (g887 E)
private theorem sat_674 (E : Nat → Bool) : (valuation E).satisfies [.neg 875, .pos 886, .pos 887] := by
  change (g876 E = true) → (¬ (g887 E = true)) → (¬ (g888 E = true)) → False
  exact pattern_6 (g876 E) (g887 E)
private theorem sat_675 (E : Nat → Bool) : (valuation E).satisfies [.neg 888, .neg 875] := by
  change (g889 E = true) → (g876 E = true) → False
  exact pattern_4 (g388 E) (g876 E)
private theorem sat_676 (E : Nat → Bool) : (valuation E).satisfies [.neg 888, .pos 387] := by
  change (g889 E = true) → (¬ (g388 E = true)) → False
  exact pattern_5 (g388 E) (g876 E)
private theorem sat_677 (E : Nat → Bool) : (valuation E).satisfies [.neg 877, .pos 888, .pos 889] := by
  change (g878 E = true) → (¬ (g889 E = true)) → (¬ (g890 E = true)) → False
  exact pattern_6 (g878 E) (g889 E)
private theorem sat_678 (E : Nat → Bool) : (valuation E).satisfies [.neg 897, .pos 883] := by
  change (g898 E = true) → (¬ (g884 E = true)) → False
  exact pattern_10 (g389 E) (g884 E)
private theorem sat_679 (E : Nat → Bool) : (valuation E).satisfies [.neg 883, .pos 388, .pos 897] := by
  change (g884 E = true) → (¬ (g389 E = true)) → (¬ (g898 E = true)) → False
  exact pattern_3 (g389 E) (g884 E)
private theorem sat_680 (E : Nat → Bool) : (valuation E).satisfies [.neg 898, .neg 883] := by
  change (g899 E = true) → (g884 E = true) → False
  exact pattern_4 (g389 E) (g884 E)
private theorem sat_681 (E : Nat → Bool) : (valuation E).satisfies [.neg 898, .pos 388] := by
  change (g899 E = true) → (¬ (g389 E = true)) → False
  exact pattern_5 (g389 E) (g884 E)
private theorem sat_682 (E : Nat → Bool) : (valuation E).satisfies [.neg 899, .pos 885] := by
  change (g900 E = true) → (¬ (g886 E = true)) → False
  exact pattern_5 (g886 E) (g899 E)
private theorem sat_683 (E : Nat → Bool) : (valuation E).satisfies [.neg 885, .pos 898, .pos 899] := by
  change (g886 E = true) → (¬ (g899 E = true)) → (¬ (g900 E = true)) → False
  exact pattern_6 (g886 E) (g899 E)
private theorem sat_684 (E : Nat → Bool) : (valuation E).satisfies [.neg 900, .neg 885] := by
  change (g901 E = true) → (g886 E = true) → False
  exact pattern_4 (g389 E) (g886 E)
private theorem sat_685 (E : Nat → Bool) : (valuation E).satisfies [.neg 900, .pos 388] := by
  change (g901 E = true) → (¬ (g389 E = true)) → False
  exact pattern_5 (g389 E) (g886 E)
private theorem sat_686 (E : Nat → Bool) : (valuation E).satisfies [.neg 901, .pos 887] := by
  change (g902 E = true) → (¬ (g888 E = true)) → False
  exact pattern_5 (g888 E) (g901 E)
private theorem sat_687 (E : Nat → Bool) : (valuation E).satisfies [.neg 887, .pos 900, .pos 901] := by
  change (g888 E = true) → (¬ (g901 E = true)) → (¬ (g902 E = true)) → False
  exact pattern_6 (g888 E) (g901 E)
private theorem sat_688 (E : Nat → Bool) : (valuation E).satisfies [.neg 902, .neg 887] := by
  change (g903 E = true) → (g888 E = true) → False
  exact pattern_4 (g389 E) (g888 E)
private theorem sat_689 (E : Nat → Bool) : (valuation E).satisfies [.neg 902, .pos 388] := by
  change (g903 E = true) → (¬ (g389 E = true)) → False
  exact pattern_5 (g389 E) (g888 E)
private theorem sat_690 (E : Nat → Bool) : (valuation E).satisfies [.neg 889, .pos 902, .pos 903] := by
  change (g890 E = true) → (¬ (g903 E = true)) → (¬ (g904 E = true)) → False
  exact pattern_6 (g890 E) (g903 E)
private theorem sat_691 (E : Nat → Bool) : (valuation E).satisfies [.neg 913, .pos 897] := by
  change (g914 E = true) → (¬ (g898 E = true)) → False
  exact pattern_10 (g390 E) (g898 E)
private theorem sat_692 (E : Nat → Bool) : (valuation E).satisfies [.neg 897, .pos 389, .pos 913] := by
  change (g898 E = true) → (¬ (g390 E = true)) → (¬ (g914 E = true)) → False
  exact pattern_3 (g390 E) (g898 E)
private theorem sat_693 (E : Nat → Bool) : (valuation E).satisfies [.neg 914, .neg 897] := by
  change (g915 E = true) → (g898 E = true) → False
  exact pattern_4 (g390 E) (g898 E)
private theorem sat_694 (E : Nat → Bool) : (valuation E).satisfies [.neg 914, .pos 389] := by
  change (g915 E = true) → (¬ (g390 E = true)) → False
  exact pattern_5 (g390 E) (g898 E)
private theorem sat_695 (E : Nat → Bool) : (valuation E).satisfies [.neg 915, .pos 899] := by
  change (g916 E = true) → (¬ (g900 E = true)) → False
  exact pattern_5 (g900 E) (g915 E)
private theorem sat_696 (E : Nat → Bool) : (valuation E).satisfies [.neg 899, .pos 914, .pos 915] := by
  change (g900 E = true) → (¬ (g915 E = true)) → (¬ (g916 E = true)) → False
  exact pattern_6 (g900 E) (g915 E)
private theorem sat_697 (E : Nat → Bool) : (valuation E).satisfies [.neg 916, .neg 899] := by
  change (g917 E = true) → (g900 E = true) → False
  exact pattern_4 (g390 E) (g900 E)
private theorem sat_698 (E : Nat → Bool) : (valuation E).satisfies [.neg 916, .pos 389] := by
  change (g917 E = true) → (¬ (g390 E = true)) → False
  exact pattern_5 (g390 E) (g900 E)
private theorem sat_699 (E : Nat → Bool) : (valuation E).satisfies [.neg 917, .pos 901] := by
  change (g918 E = true) → (¬ (g902 E = true)) → False
  exact pattern_5 (g902 E) (g917 E)
private theorem sat_700 (E : Nat → Bool) : (valuation E).satisfies [.neg 901, .pos 916, .pos 917] := by
  change (g902 E = true) → (¬ (g917 E = true)) → (¬ (g918 E = true)) → False
  exact pattern_6 (g902 E) (g917 E)
private theorem sat_701 (E : Nat → Bool) : (valuation E).satisfies [.neg 918, .neg 901] := by
  change (g919 E = true) → (g902 E = true) → False
  exact pattern_4 (g390 E) (g902 E)
private theorem sat_702 (E : Nat → Bool) : (valuation E).satisfies [.neg 918, .pos 389] := by
  change (g919 E = true) → (¬ (g390 E = true)) → False
  exact pattern_5 (g390 E) (g902 E)
private theorem sat_703 (E : Nat → Bool) : (valuation E).satisfies [.neg 903, .pos 918, .pos 919] := by
  change (g904 E = true) → (¬ (g919 E = true)) → (¬ (g920 E = true)) → False
  exact pattern_6 (g904 E) (g919 E)
private theorem sat_704 (E : Nat → Bool) : (valuation E).satisfies [.neg 931, .pos 913] := by
  change (g932 E = true) → (¬ (g914 E = true)) → False
  exact pattern_10 (g391 E) (g914 E)
private theorem sat_705 (E : Nat → Bool) : (valuation E).satisfies [.neg 913, .pos 390, .pos 931] := by
  change (g914 E = true) → (¬ (g391 E = true)) → (¬ (g932 E = true)) → False
  exact pattern_3 (g391 E) (g914 E)
private theorem sat_706 (E : Nat → Bool) : (valuation E).satisfies [.neg 932, .neg 913] := by
  change (g933 E = true) → (g914 E = true) → False
  exact pattern_4 (g391 E) (g914 E)
private theorem sat_707 (E : Nat → Bool) : (valuation E).satisfies [.neg 932, .pos 390] := by
  change (g933 E = true) → (¬ (g391 E = true)) → False
  exact pattern_5 (g391 E) (g914 E)
private theorem sat_708 (E : Nat → Bool) : (valuation E).satisfies [.neg 933, .pos 915] := by
  change (g934 E = true) → (¬ (g916 E = true)) → False
  exact pattern_5 (g916 E) (g933 E)
private theorem sat_709 (E : Nat → Bool) : (valuation E).satisfies [.neg 915, .pos 932, .pos 933] := by
  change (g916 E = true) → (¬ (g933 E = true)) → (¬ (g934 E = true)) → False
  exact pattern_6 (g916 E) (g933 E)
private theorem sat_710 (E : Nat → Bool) : (valuation E).satisfies [.neg 934, .neg 915] := by
  change (g935 E = true) → (g916 E = true) → False
  exact pattern_4 (g391 E) (g916 E)
private theorem sat_711 (E : Nat → Bool) : (valuation E).satisfies [.neg 934, .pos 390] := by
  change (g935 E = true) → (¬ (g391 E = true)) → False
  exact pattern_5 (g391 E) (g916 E)
private theorem sat_712 (E : Nat → Bool) : (valuation E).satisfies [.neg 935, .pos 917] := by
  change (g936 E = true) → (¬ (g918 E = true)) → False
  exact pattern_5 (g918 E) (g935 E)
private theorem sat_713 (E : Nat → Bool) : (valuation E).satisfies [.neg 917, .pos 934, .pos 935] := by
  change (g918 E = true) → (¬ (g935 E = true)) → (¬ (g936 E = true)) → False
  exact pattern_6 (g918 E) (g935 E)
private theorem sat_714 (E : Nat → Bool) : (valuation E).satisfies [.neg 936, .neg 917] := by
  change (g937 E = true) → (g918 E = true) → False
  exact pattern_4 (g391 E) (g918 E)
private theorem sat_715 (E : Nat → Bool) : (valuation E).satisfies [.neg 936, .pos 390] := by
  change (g937 E = true) → (¬ (g391 E = true)) → False
  exact pattern_5 (g391 E) (g918 E)
private theorem sat_716 (E : Nat → Bool) : (valuation E).satisfies [.neg 919, .pos 936, .pos 937] := by
  change (g920 E = true) → (¬ (g937 E = true)) → (¬ (g938 E = true)) → False
  exact pattern_6 (g920 E) (g937 E)
private theorem sat_717 (E : Nat → Bool) : (valuation E).satisfies [.neg 951, .pos 931] := by
  change (g952 E = true) → (¬ (g932 E = true)) → False
  exact pattern_10 (g392 E) (g932 E)
private theorem sat_718 (E : Nat → Bool) : (valuation E).satisfies [.neg 931, .pos 391, .pos 951] := by
  change (g932 E = true) → (¬ (g392 E = true)) → (¬ (g952 E = true)) → False
  exact pattern_3 (g392 E) (g932 E)
private theorem sat_719 (E : Nat → Bool) : (valuation E).satisfies [.neg 952, .neg 931] := by
  change (g953 E = true) → (g932 E = true) → False
  exact pattern_4 (g392 E) (g932 E)
private theorem sat_720 (E : Nat → Bool) : (valuation E).satisfies [.neg 952, .pos 391] := by
  change (g953 E = true) → (¬ (g392 E = true)) → False
  exact pattern_5 (g392 E) (g932 E)
private theorem sat_721 (E : Nat → Bool) : (valuation E).satisfies [.neg 953, .pos 933] := by
  change (g954 E = true) → (¬ (g934 E = true)) → False
  exact pattern_5 (g934 E) (g953 E)
private theorem sat_722 (E : Nat → Bool) : (valuation E).satisfies [.neg 933, .pos 952, .pos 953] := by
  change (g934 E = true) → (¬ (g953 E = true)) → (¬ (g954 E = true)) → False
  exact pattern_6 (g934 E) (g953 E)
private theorem sat_723 (E : Nat → Bool) : (valuation E).satisfies [.neg 954, .neg 933] := by
  change (g955 E = true) → (g934 E = true) → False
  exact pattern_4 (g392 E) (g934 E)
private theorem sat_724 (E : Nat → Bool) : (valuation E).satisfies [.neg 954, .pos 391] := by
  change (g955 E = true) → (¬ (g392 E = true)) → False
  exact pattern_5 (g392 E) (g934 E)
private theorem sat_725 (E : Nat → Bool) : (valuation E).satisfies [.neg 955, .pos 935] := by
  change (g956 E = true) → (¬ (g936 E = true)) → False
  exact pattern_5 (g936 E) (g955 E)
private theorem sat_726 (E : Nat → Bool) : (valuation E).satisfies [.neg 935, .pos 954, .pos 955] := by
  change (g936 E = true) → (¬ (g955 E = true)) → (¬ (g956 E = true)) → False
  exact pattern_6 (g936 E) (g955 E)
private theorem sat_727 (E : Nat → Bool) : (valuation E).satisfies [.neg 956, .neg 935] := by
  change (g957 E = true) → (g936 E = true) → False
  exact pattern_4 (g392 E) (g936 E)
private theorem sat_728 (E : Nat → Bool) : (valuation E).satisfies [.neg 956, .pos 391] := by
  change (g957 E = true) → (¬ (g392 E = true)) → False
  exact pattern_5 (g392 E) (g936 E)
private theorem sat_729 (E : Nat → Bool) : (valuation E).satisfies [.neg 937, .pos 956, .pos 957] := by
  change (g938 E = true) → (¬ (g957 E = true)) → (¬ (g958 E = true)) → False
  exact pattern_6 (g938 E) (g957 E)
private theorem sat_730 (E : Nat → Bool) : (valuation E).satisfies [.neg 973, .neg 392] := by
  change (g974 E = true) → (g393 E = true) → False
  exact pattern_8 (g393 E) (g952 E)
private theorem sat_731 (E : Nat → Bool) : (valuation E).satisfies [.neg 951, .pos 392, .pos 973] := by
  change (g952 E = true) → (¬ (g393 E = true)) → (¬ (g974 E = true)) → False
  exact pattern_3 (g393 E) (g952 E)
private theorem sat_732 (E : Nat → Bool) : (valuation E).satisfies [.neg 974, .neg 951] := by
  change (g975 E = true) → (g952 E = true) → False
  exact pattern_4 (g393 E) (g952 E)
private theorem sat_733 (E : Nat → Bool) : (valuation E).satisfies [.neg 974, .pos 392] := by
  change (g975 E = true) → (¬ (g393 E = true)) → False
  exact pattern_5 (g393 E) (g952 E)
private theorem sat_734 (E : Nat → Bool) : (valuation E).satisfies [.neg 392, .pos 951, .pos 974] := by
  change (g393 E = true) → (¬ (g952 E = true)) → (¬ (g975 E = true)) → False
  exact pattern_6 (g393 E) (g952 E)
private theorem sat_735 (E : Nat → Bool) : (valuation E).satisfies [.neg 975, .neg 974] := by
  change (g976 E = true) → (g975 E = true) → False
  exact pattern_4 (g954 E) (g975 E)
private theorem sat_736 (E : Nat → Bool) : (valuation E).satisfies [.neg 975, .pos 953] := by
  change (g976 E = true) → (¬ (g954 E = true)) → False
  exact pattern_5 (g954 E) (g975 E)
private theorem sat_737 (E : Nat → Bool) : (valuation E).satisfies [.neg 953, .pos 974, .pos 975] := by
  change (g954 E = true) → (¬ (g975 E = true)) → (¬ (g976 E = true)) → False
  exact pattern_6 (g954 E) (g975 E)
private theorem sat_738 (E : Nat → Bool) : (valuation E).satisfies [.neg 976, .neg 953] := by
  change (g977 E = true) → (g954 E = true) → False
  exact pattern_4 (g393 E) (g954 E)
private theorem sat_739 (E : Nat → Bool) : (valuation E).satisfies [.neg 976, .pos 392] := by
  change (g977 E = true) → (¬ (g393 E = true)) → False
  exact pattern_5 (g393 E) (g954 E)
private theorem sat_740 (E : Nat → Bool) : (valuation E).satisfies [.neg 392, .pos 953, .pos 976] := by
  change (g393 E = true) → (¬ (g954 E = true)) → (¬ (g977 E = true)) → False
  exact pattern_6 (g393 E) (g954 E)
private theorem sat_741 (E : Nat → Bool) : (valuation E).satisfies [.neg 977, .neg 976] := by
  change (g978 E = true) → (g977 E = true) → False
  exact pattern_4 (g956 E) (g977 E)
private theorem sat_742 (E : Nat → Bool) : (valuation E).satisfies [.neg 955, .pos 976, .pos 977] := by
  change (g956 E = true) → (¬ (g977 E = true)) → (¬ (g978 E = true)) → False
  exact pattern_6 (g956 E) (g977 E)
private theorem sat_743 (E : Nat → Bool) : (valuation E).satisfies [.neg 978, .neg 955] := by
  change (g979 E = true) → (g956 E = true) → False
  exact pattern_4 (g393 E) (g956 E)
private theorem sat_744 (E : Nat → Bool) : (valuation E).satisfies [.neg 978, .pos 392] := by
  change (g979 E = true) → (¬ (g393 E = true)) → False
  exact pattern_5 (g393 E) (g956 E)
private theorem sat_745 (E : Nat → Bool) : (valuation E).satisfies [.neg 392, .pos 955, .pos 978] := by
  change (g393 E = true) → (¬ (g956 E = true)) → (¬ (g979 E = true)) → False
  exact pattern_6 (g393 E) (g956 E)
private theorem sat_746 (E : Nat → Bool) : (valuation E).satisfies [.neg 979, .neg 978] := by
  change (g980 E = true) → (g979 E = true) → False
  exact pattern_4 (g958 E) (g979 E)
private theorem sat_747 (E : Nat → Bool) : (valuation E).satisfies [.neg 957, .pos 978, .pos 979] := by
  change (g958 E = true) → (¬ (g979 E = true)) → (¬ (g980 E = true)) → False
  exact pattern_6 (g958 E) (g979 E)
private theorem sat_748 (E : Nat → Bool) : (valuation E).satisfies [.neg 973, .pos 393, .pos 997] := by
  change (g974 E = true) → (¬ (g394 E = true)) → (¬ (g998 E = true)) → False
  exact pattern_3 (g394 E) (g974 E)
private theorem sat_749 (E : Nat → Bool) : (valuation E).satisfies [.neg 998, .pos 393] := by
  change (g999 E = true) → (¬ (g394 E = true)) → False
  exact pattern_5 (g394 E) (g974 E)
private theorem sat_750 (E : Nat → Bool) : (valuation E).satisfies [.neg 393, .pos 973, .pos 998] := by
  change (g394 E = true) → (¬ (g974 E = true)) → (¬ (g999 E = true)) → False
  exact pattern_6 (g394 E) (g974 E)
private theorem sat_751 (E : Nat → Bool) : (valuation E).satisfies [.neg 999, .neg 998] := by
  change (g1000 E = true) → (g999 E = true) → False
  exact pattern_4 (g976 E) (g999 E)
private theorem sat_752 (E : Nat → Bool) : (valuation E).satisfies [.neg 999, .pos 975] := by
  change (g1000 E = true) → (¬ (g976 E = true)) → False
  exact pattern_5 (g976 E) (g999 E)
private theorem sat_753 (E : Nat → Bool) : (valuation E).satisfies [.neg 975, .pos 998, .pos 999] := by
  change (g976 E = true) → (¬ (g999 E = true)) → (¬ (g1000 E = true)) → False
  exact pattern_6 (g976 E) (g999 E)
private theorem sat_754 (E : Nat → Bool) : (valuation E).satisfies [.neg 1000, .neg 975] := by
  change (g1001 E = true) → (g976 E = true) → False
  exact pattern_4 (g394 E) (g976 E)
private theorem sat_755 (E : Nat → Bool) : (valuation E).satisfies [.neg 1000, .pos 393] := by
  change (g1001 E = true) → (¬ (g394 E = true)) → False
  exact pattern_5 (g394 E) (g976 E)
private theorem sat_756 (E : Nat → Bool) : (valuation E).satisfies [.neg 393, .pos 975, .pos 1000] := by
  change (g394 E = true) → (¬ (g976 E = true)) → (¬ (g1001 E = true)) → False
  exact pattern_6 (g394 E) (g976 E)
private theorem sat_757 (E : Nat → Bool) : (valuation E).satisfies [.neg 1001, .neg 1000] := by
  change (g1002 E = true) → (g1001 E = true) → False
  exact pattern_4 (g978 E) (g1001 E)
private theorem sat_758 (E : Nat → Bool) : (valuation E).satisfies [.neg 1001, .pos 977] := by
  change (g1002 E = true) → (¬ (g978 E = true)) → False
  exact pattern_5 (g978 E) (g1001 E)
private theorem sat_759 (E : Nat → Bool) : (valuation E).satisfies [.neg 977, .pos 1000, .pos 1001] := by
  change (g978 E = true) → (¬ (g1001 E = true)) → (¬ (g1002 E = true)) → False
  exact pattern_6 (g978 E) (g1001 E)
private theorem sat_760 (E : Nat → Bool) : (valuation E).satisfies [.neg 1002, .neg 977] := by
  change (g1003 E = true) → (g978 E = true) → False
  exact pattern_4 (g394 E) (g978 E)
private theorem sat_761 (E : Nat → Bool) : (valuation E).satisfies [.neg 1002, .pos 393] := by
  change (g1003 E = true) → (¬ (g394 E = true)) → False
  exact pattern_5 (g394 E) (g978 E)
private theorem sat_762 (E : Nat → Bool) : (valuation E).satisfies [.neg 979, .pos 1002, .pos 1003] := by
  change (g980 E = true) → (¬ (g1003 E = true)) → (¬ (g1004 E = true)) → False
  exact pattern_6 (g980 E) (g1003 E)
private theorem sat_763 (E : Nat → Bool) : (valuation E).satisfies [.neg 393, .pos 979, .pos 1004] := by
  change (g394 E = true) → (¬ (g980 E = true)) → (¬ (g1005 E = true)) → False
  exact pattern_6 (g394 E) (g980 E)
private theorem sat_764 (E : Nat → Bool) : (valuation E).satisfies [.neg 1005, .neg 1004] := by
  change (g1006 E = true) → (g1005 E = true) → False
  exact pattern_4 (g982 E) (g1005 E)
private theorem sat_765 (E : Nat → Bool) : (valuation E).satisfies [.neg 997, .pos 394, .pos 1023] := by
  change (g998 E = true) → (¬ (g395 E = true)) → (¬ (g1024 E = true)) → False
  exact pattern_3 (g395 E) (g998 E)
private theorem sat_766 (E : Nat → Bool) : (valuation E).satisfies [.neg 1024, .neg 997] := by
  change (g1025 E = true) → (g998 E = true) → False
  exact pattern_4 (g395 E) (g998 E)
private theorem sat_767 (E : Nat → Bool) : (valuation E).satisfies [.neg 1024, .pos 394] := by
  change (g1025 E = true) → (¬ (g395 E = true)) → False
  exact pattern_5 (g395 E) (g998 E)
private theorem sat_768 (E : Nat → Bool) : (valuation E).satisfies [.neg 999, .pos 1024, .pos 1025] := by
  change (g1000 E = true) → (¬ (g1025 E = true)) → (¬ (g1026 E = true)) → False
  exact pattern_6 (g1000 E) (g1025 E)
private theorem sat_769 (E : Nat → Bool) : (valuation E).satisfies [.neg 1026, .neg 999] := by
  change (g1027 E = true) → (g1000 E = true) → False
  exact pattern_4 (g395 E) (g1000 E)
private theorem sat_770 (E : Nat → Bool) : (valuation E).satisfies [.neg 1026, .pos 394] := by
  change (g1027 E = true) → (¬ (g395 E = true)) → False
  exact pattern_5 (g395 E) (g1000 E)
private theorem sat_771 (E : Nat → Bool) : (valuation E).satisfies [.neg 394, .pos 999, .pos 1026] := by
  change (g395 E = true) → (¬ (g1000 E = true)) → (¬ (g1027 E = true)) → False
  exact pattern_6 (g395 E) (g1000 E)
private theorem sat_772 (E : Nat → Bool) : (valuation E).satisfies [.neg 1027, .neg 1026] := by
  change (g1028 E = true) → (g1027 E = true) → False
  exact pattern_4 (g1002 E) (g1027 E)
private theorem sat_773 (E : Nat → Bool) : (valuation E).satisfies [.neg 1027, .pos 1001] := by
  change (g1028 E = true) → (¬ (g1002 E = true)) → False
  exact pattern_5 (g1002 E) (g1027 E)
private theorem sat_774 (E : Nat → Bool) : (valuation E).satisfies [.neg 1001, .pos 1026, .pos 1027] := by
  change (g1002 E = true) → (¬ (g1027 E = true)) → (¬ (g1028 E = true)) → False
  exact pattern_6 (g1002 E) (g1027 E)
private theorem sat_775 (E : Nat → Bool) : (valuation E).satisfies [.neg 1028, .neg 1001] := by
  change (g1029 E = true) → (g1002 E = true) → False
  exact pattern_4 (g395 E) (g1002 E)
private theorem sat_776 (E : Nat → Bool) : (valuation E).satisfies [.neg 1028, .pos 394] := by
  change (g1029 E = true) → (¬ (g395 E = true)) → False
  exact pattern_5 (g395 E) (g1002 E)
private theorem sat_777 (E : Nat → Bool) : (valuation E).satisfies [.neg 394, .pos 1001, .pos 1028] := by
  change (g395 E = true) → (¬ (g1002 E = true)) → (¬ (g1029 E = true)) → False
  exact pattern_6 (g395 E) (g1002 E)
private theorem sat_778 (E : Nat → Bool) : (valuation E).satisfies [.neg 1029, .neg 1028] := by
  change (g1030 E = true) → (g1029 E = true) → False
  exact pattern_4 (g1004 E) (g1029 E)
private theorem sat_779 (E : Nat → Bool) : (valuation E).satisfies [.neg 1003, .pos 1028, .pos 1029] := by
  change (g1004 E = true) → (¬ (g1029 E = true)) → (¬ (g1030 E = true)) → False
  exact pattern_6 (g1004 E) (g1029 E)
private theorem sat_780 (E : Nat → Bool) : (valuation E).satisfies [.neg 1031, .pos 1005] := by
  change (g1032 E = true) → (¬ (g1006 E = true)) → False
  exact pattern_5 (g1006 E) (g1031 E)
private theorem sat_781 (E : Nat → Bool) : (valuation E).satisfies [.neg 1023, .pos 395, .pos 1051] := by
  change (g1024 E = true) → (¬ (g396 E = true)) → (¬ (g1052 E = true)) → False
  exact pattern_3 (g396 E) (g1024 E)
private theorem sat_782 (E : Nat → Bool) : (valuation E).satisfies [.neg 1052, .neg 1023] := by
  change (g1053 E = true) → (g1024 E = true) → False
  exact pattern_4 (g396 E) (g1024 E)
private theorem sat_783 (E : Nat → Bool) : (valuation E).satisfies [.neg 1052, .pos 395] := by
  change (g1053 E = true) → (¬ (g396 E = true)) → False
  exact pattern_5 (g396 E) (g1024 E)
private theorem sat_784 (E : Nat → Bool) : (valuation E).satisfies [.neg 1025, .pos 1052, .pos 1053] := by
  change (g1026 E = true) → (¬ (g1053 E = true)) → (¬ (g1054 E = true)) → False
  exact pattern_6 (g1026 E) (g1053 E)
private theorem sat_785 (E : Nat → Bool) : (valuation E).satisfies [.neg 1054, .neg 1025] := by
  change (g1055 E = true) → (g1026 E = true) → False
  exact pattern_4 (g396 E) (g1026 E)
private theorem sat_786 (E : Nat → Bool) : (valuation E).satisfies [.neg 1054, .pos 395] := by
  change (g1055 E = true) → (¬ (g396 E = true)) → False
  exact pattern_5 (g396 E) (g1026 E)
private theorem sat_787 (E : Nat → Bool) : (valuation E).satisfies [.neg 1055, .pos 1027] := by
  change (g1056 E = true) → (¬ (g1028 E = true)) → False
  exact pattern_5 (g1028 E) (g1055 E)
private theorem sat_788 (E : Nat → Bool) : (valuation E).satisfies [.neg 1027, .pos 1054, .pos 1055] := by
  change (g1028 E = true) → (¬ (g1055 E = true)) → (¬ (g1056 E = true)) → False
  exact pattern_6 (g1028 E) (g1055 E)
private theorem sat_789 (E : Nat → Bool) : (valuation E).satisfies [.neg 1056, .neg 1027] := by
  change (g1057 E = true) → (g1028 E = true) → False
  exact pattern_4 (g396 E) (g1028 E)
private theorem sat_790 (E : Nat → Bool) : (valuation E).satisfies [.neg 1056, .pos 395] := by
  change (g1057 E = true) → (¬ (g396 E = true)) → False
  exact pattern_5 (g396 E) (g1028 E)
private theorem sat_791 (E : Nat → Bool) : (valuation E).satisfies [.neg 1057, .pos 1029] := by
  change (g1058 E = true) → (¬ (g1030 E = true)) → False
  exact pattern_5 (g1030 E) (g1057 E)
private theorem sat_792 (E : Nat → Bool) : (valuation E).satisfies [.neg 1029, .pos 1056, .pos 1057] := by
  change (g1030 E = true) → (¬ (g1057 E = true)) → (¬ (g1058 E = true)) → False
  exact pattern_6 (g1030 E) (g1057 E)
private theorem sat_793 (E : Nat → Bool) : (valuation E).satisfies [.neg 1059, .pos 1031] := by
  change (g1060 E = true) → (¬ (g1032 E = true)) → False
  exact pattern_5 (g1032 E) (g1059 E)
private theorem sat_794 (E : Nat → Bool) : (valuation E).satisfies [.neg 1051, .pos 396, .pos 1081] := by
  change (g1052 E = true) → (¬ (g397 E = true)) → (¬ (g1082 E = true)) → False
  exact pattern_3 (g397 E) (g1052 E)
private theorem sat_795 (E : Nat → Bool) : (valuation E).satisfies [.neg 1082, .pos 396] := by
  change (g1083 E = true) → (¬ (g397 E = true)) → False
  exact pattern_5 (g397 E) (g1052 E)
private theorem sat_796 (E : Nat → Bool) : (valuation E).satisfies [.neg 1053, .pos 1082, .pos 1083] := by
  change (g1054 E = true) → (¬ (g1083 E = true)) → (¬ (g1084 E = true)) → False
  exact pattern_6 (g1054 E) (g1083 E)
private theorem sat_797 (E : Nat → Bool) : (valuation E).satisfies [.neg 1084, .neg 1053] := by
  change (g1085 E = true) → (g1054 E = true) → False
  exact pattern_4 (g397 E) (g1054 E)
private theorem sat_798 (E : Nat → Bool) : (valuation E).satisfies [.neg 1084, .pos 396] := by
  change (g1085 E = true) → (¬ (g397 E = true)) → False
  exact pattern_5 (g397 E) (g1054 E)
private theorem sat_799 (E : Nat → Bool) : (valuation E).satisfies [.neg 1085, .pos 1055] := by
  change (g1086 E = true) → (¬ (g1056 E = true)) → False
  exact pattern_5 (g1056 E) (g1085 E)
private theorem sat_800 (E : Nat → Bool) : (valuation E).satisfies [.neg 1055, .pos 1084, .pos 1085] := by
  change (g1056 E = true) → (¬ (g1085 E = true)) → (¬ (g1086 E = true)) → False
  exact pattern_6 (g1056 E) (g1085 E)
private theorem sat_801 (E : Nat → Bool) : (valuation E).satisfies [.neg 1086, .neg 1055] := by
  change (g1087 E = true) → (g1056 E = true) → False
  exact pattern_4 (g397 E) (g1056 E)
private theorem sat_802 (E : Nat → Bool) : (valuation E).satisfies [.neg 1086, .pos 396] := by
  change (g1087 E = true) → (¬ (g397 E = true)) → False
  exact pattern_5 (g397 E) (g1056 E)
private theorem sat_803 (E : Nat → Bool) : (valuation E).satisfies [.neg 1087, .pos 1057] := by
  change (g1088 E = true) → (¬ (g1058 E = true)) → False
  exact pattern_5 (g1058 E) (g1087 E)
private theorem sat_804 (E : Nat → Bool) : (valuation E).satisfies [.neg 1057, .pos 1086, .pos 1087] := by
  change (g1058 E = true) → (¬ (g1087 E = true)) → (¬ (g1088 E = true)) → False
  exact pattern_6 (g1058 E) (g1087 E)
private theorem sat_805 (E : Nat → Bool) : (valuation E).satisfies [.neg 1089, .pos 1059] := by
  change (g1090 E = true) → (¬ (g1060 E = true)) → False
  exact pattern_5 (g1060 E) (g1089 E)
private theorem sat_806 (E : Nat → Bool) : (valuation E).satisfies [.neg 1081, .pos 397, .pos 1113] := by
  change (g1082 E = true) → (¬ (g398 E = true)) → (¬ (g1114 E = true)) → False
  exact pattern_3 (g398 E) (g1082 E)
private theorem sat_807 (E : Nat → Bool) : (valuation E).satisfies [.neg 1114, .pos 397] := by
  change (g1115 E = true) → (¬ (g398 E = true)) → False
  exact pattern_5 (g398 E) (g1082 E)
private theorem sat_808 (E : Nat → Bool) : (valuation E).satisfies [.neg 1083, .pos 1114, .pos 1115] := by
  change (g1084 E = true) → (¬ (g1115 E = true)) → (¬ (g1116 E = true)) → False
  exact pattern_6 (g1084 E) (g1115 E)
private theorem sat_809 (E : Nat → Bool) : (valuation E).satisfies [.neg 1116, .neg 1083] := by
  change (g1117 E = true) → (g1084 E = true) → False
  exact pattern_4 (g398 E) (g1084 E)
private theorem sat_810 (E : Nat → Bool) : (valuation E).satisfies [.neg 1116, .pos 397] := by
  change (g1117 E = true) → (¬ (g398 E = true)) → False
  exact pattern_5 (g398 E) (g1084 E)
private theorem sat_811 (E : Nat → Bool) : (valuation E).satisfies [.neg 1117, .pos 1085] := by
  change (g1118 E = true) → (¬ (g1086 E = true)) → False
  exact pattern_5 (g1086 E) (g1117 E)
private theorem sat_812 (E : Nat → Bool) : (valuation E).satisfies [.neg 1085, .pos 1116, .pos 1117] := by
  change (g1086 E = true) → (¬ (g1117 E = true)) → (¬ (g1118 E = true)) → False
  exact pattern_6 (g1086 E) (g1117 E)
private theorem sat_813 (E : Nat → Bool) : (valuation E).satisfies [.neg 1118, .neg 1085] := by
  change (g1119 E = true) → (g1086 E = true) → False
  exact pattern_4 (g398 E) (g1086 E)
private theorem sat_814 (E : Nat → Bool) : (valuation E).satisfies [.neg 1118, .pos 397] := by
  change (g1119 E = true) → (¬ (g398 E = true)) → False
  exact pattern_5 (g398 E) (g1086 E)
private theorem sat_815 (E : Nat → Bool) : (valuation E).satisfies [.neg 1119, .pos 1087] := by
  change (g1120 E = true) → (¬ (g1088 E = true)) → False
  exact pattern_5 (g1088 E) (g1119 E)
private theorem sat_816 (E : Nat → Bool) : (valuation E).satisfies [.neg 1087, .pos 1118, .pos 1119] := by
  change (g1088 E = true) → (¬ (g1119 E = true)) → (¬ (g1120 E = true)) → False
  exact pattern_6 (g1088 E) (g1119 E)
private theorem sat_817 (E : Nat → Bool) : (valuation E).satisfies [.neg 1121, .pos 1089] := by
  change (g1122 E = true) → (¬ (g1090 E = true)) → False
  exact pattern_5 (g1090 E) (g1121 E)
private theorem sat_818 (E : Nat → Bool) : (valuation E).satisfies [.neg 1113, .pos 398, .pos 1147] := by
  change (g1114 E = true) → (¬ (g399 E = true)) → (¬ (g1148 E = true)) → False
  exact pattern_3 (g399 E) (g1114 E)
private theorem sat_819 (E : Nat → Bool) : (valuation E).satisfies [.neg 1148, .neg 1113] := by
  change (g1149 E = true) → (g1114 E = true) → False
  exact pattern_4 (g399 E) (g1114 E)
private theorem sat_820 (E : Nat → Bool) : (valuation E).satisfies [.neg 1148, .pos 398] := by
  change (g1149 E = true) → (¬ (g399 E = true)) → False
  exact pattern_5 (g399 E) (g1114 E)
private theorem sat_821 (E : Nat → Bool) : (valuation E).satisfies [.neg 1115, .pos 1148, .pos 1149] := by
  change (g1116 E = true) → (¬ (g1149 E = true)) → (¬ (g1150 E = true)) → False
  exact pattern_6 (g1116 E) (g1149 E)
private theorem sat_822 (E : Nat → Bool) : (valuation E).satisfies [.neg 1150, .neg 1115] := by
  change (g1151 E = true) → (g1116 E = true) → False
  exact pattern_4 (g399 E) (g1116 E)
private theorem sat_823 (E : Nat → Bool) : (valuation E).satisfies [.neg 1150, .pos 398] := by
  change (g1151 E = true) → (¬ (g399 E = true)) → False
  exact pattern_5 (g399 E) (g1116 E)
private theorem sat_824 (E : Nat → Bool) : (valuation E).satisfies [.neg 1151, .pos 1117] := by
  change (g1152 E = true) → (¬ (g1118 E = true)) → False
  exact pattern_5 (g1118 E) (g1151 E)
private theorem sat_825 (E : Nat → Bool) : (valuation E).satisfies [.neg 1117, .pos 1150, .pos 1151] := by
  change (g1118 E = true) → (¬ (g1151 E = true)) → (¬ (g1152 E = true)) → False
  exact pattern_6 (g1118 E) (g1151 E)
private theorem sat_826 (E : Nat → Bool) : (valuation E).satisfies [.neg 1152, .neg 1117] := by
  change (g1153 E = true) → (g1118 E = true) → False
  exact pattern_4 (g399 E) (g1118 E)
private theorem sat_827 (E : Nat → Bool) : (valuation E).satisfies [.neg 1152, .pos 398] := by
  change (g1153 E = true) → (¬ (g399 E = true)) → False
  exact pattern_5 (g399 E) (g1118 E)
private theorem sat_828 (E : Nat → Bool) : (valuation E).satisfies [.neg 398, .pos 1117, .pos 1152] := by
  change (g399 E = true) → (¬ (g1118 E = true)) → (¬ (g1153 E = true)) → False
  exact pattern_6 (g399 E) (g1118 E)
private theorem sat_829 (E : Nat → Bool) : (valuation E).satisfies [.neg 1153, .neg 1152] := by
  change (g1154 E = true) → (g1153 E = true) → False
  exact pattern_4 (g1120 E) (g1153 E)
private theorem sat_830 (E : Nat → Bool) : (valuation E).satisfies [.neg 1153, .pos 1119] := by
  change (g1154 E = true) → (¬ (g1120 E = true)) → False
  exact pattern_5 (g1120 E) (g1153 E)
private theorem sat_831 (E : Nat → Bool) : (valuation E).satisfies [.neg 1119, .pos 1152, .pos 1153] := by
  change (g1120 E = true) → (¬ (g1153 E = true)) → (¬ (g1154 E = true)) → False
  exact pattern_6 (g1120 E) (g1153 E)
private theorem sat_832 (E : Nat → Bool) : (valuation E).satisfies [.neg 1155, .pos 1121] := by
  change (g1156 E = true) → (¬ (g1122 E = true)) → False
  exact pattern_5 (g1122 E) (g1155 E)
private theorem sat_833 (E : Nat → Bool) : (valuation E).satisfies [.neg 1184, .neg 1147] := by
  change (g1185 E = true) → (g1148 E = true) → False
  exact pattern_4 (g400 E) (g1148 E)
private theorem sat_834 (E : Nat → Bool) : (valuation E).satisfies [.neg 1184, .pos 399] := by
  change (g1185 E = true) → (¬ (g400 E = true)) → False
  exact pattern_5 (g400 E) (g1148 E)
private theorem sat_835 (E : Nat → Bool) : (valuation E).satisfies [.neg 1149, .pos 1184, .pos 1185] := by
  change (g1150 E = true) → (¬ (g1185 E = true)) → (¬ (g1186 E = true)) → False
  exact pattern_6 (g1150 E) (g1185 E)
private theorem sat_836 (E : Nat → Bool) : (valuation E).satisfies [.neg 1186, .neg 1149] := by
  change (g1187 E = true) → (g1150 E = true) → False
  exact pattern_4 (g400 E) (g1150 E)
private theorem sat_837 (E : Nat → Bool) : (valuation E).satisfies [.neg 1186, .pos 399] := by
  change (g1187 E = true) → (¬ (g400 E = true)) → False
  exact pattern_5 (g400 E) (g1150 E)
private theorem sat_838 (E : Nat → Bool) : (valuation E).satisfies [.neg 1151, .pos 1186, .pos 1187] := by
  change (g1152 E = true) → (¬ (g1187 E = true)) → (¬ (g1188 E = true)) → False
  exact pattern_6 (g1152 E) (g1187 E)
private theorem sat_839 (E : Nat → Bool) : (valuation E).satisfies [.neg 1188, .neg 1151] := by
  change (g1189 E = true) → (g1152 E = true) → False
  exact pattern_4 (g400 E) (g1152 E)
private theorem sat_840 (E : Nat → Bool) : (valuation E).satisfies [.neg 1188, .pos 399] := by
  change (g1189 E = true) → (¬ (g400 E = true)) → False
  exact pattern_5 (g400 E) (g1152 E)
private theorem sat_841 (E : Nat → Bool) : (valuation E).satisfies [.neg 399, .pos 1151, .pos 1188] := by
  change (g400 E = true) → (¬ (g1152 E = true)) → (¬ (g1189 E = true)) → False
  exact pattern_6 (g400 E) (g1152 E)
private theorem sat_842 (E : Nat → Bool) : (valuation E).satisfies [.neg 1189, .neg 1188] := by
  change (g1190 E = true) → (g1189 E = true) → False
  exact pattern_4 (g1154 E) (g1189 E)
private theorem sat_843 (E : Nat → Bool) : (valuation E).satisfies [.neg 1189, .pos 1153] := by
  change (g1190 E = true) → (¬ (g1154 E = true)) → False
  exact pattern_5 (g1154 E) (g1189 E)
private theorem sat_844 (E : Nat → Bool) : (valuation E).satisfies [.neg 1153, .pos 1188, .pos 1189] := by
  change (g1154 E = true) → (¬ (g1189 E = true)) → (¬ (g1190 E = true)) → False
  exact pattern_6 (g1154 E) (g1189 E)
private theorem sat_845 (E : Nat → Bool) : (valuation E).satisfies [.neg 1191, .pos 1155] := by
  change (g1192 E = true) → (¬ (g1156 E = true)) → False
  exact pattern_5 (g1156 E) (g1191 E)
private theorem sat_846 (E : Nat → Bool) : (valuation E).satisfies [.neg 1224, .neg 1185] := by
  change (g1225 E = true) → (g1186 E = true) → False
  exact pattern_4 (g401 E) (g1186 E)
private theorem sat_847 (E : Nat → Bool) : (valuation E).satisfies [.neg 1224, .pos 400] := by
  change (g1225 E = true) → (¬ (g401 E = true)) → False
  exact pattern_5 (g401 E) (g1186 E)
private theorem sat_848 (E : Nat → Bool) : (valuation E).satisfies [.neg 1187, .pos 1224, .pos 1225] := by
  change (g1188 E = true) → (¬ (g1225 E = true)) → (¬ (g1226 E = true)) → False
  exact pattern_6 (g1188 E) (g1225 E)
private theorem sat_849 (E : Nat → Bool) : (valuation E).satisfies [.neg 1226, .neg 1187] := by
  change (g1227 E = true) → (g1188 E = true) → False
  exact pattern_4 (g401 E) (g1188 E)
private theorem sat_850 (E : Nat → Bool) : (valuation E).satisfies [.neg 1226, .pos 400] := by
  change (g1227 E = true) → (¬ (g401 E = true)) → False
  exact pattern_5 (g401 E) (g1188 E)
private theorem sat_851 (E : Nat → Bool) : (valuation E).satisfies [.neg 1227, .pos 1189] := by
  change (g1228 E = true) → (¬ (g1190 E = true)) → False
  exact pattern_5 (g1190 E) (g1227 E)
private theorem sat_852 (E : Nat → Bool) : (valuation E).satisfies [.neg 1189, .pos 1226, .pos 1227] := by
  change (g1190 E = true) → (¬ (g1227 E = true)) → (¬ (g1228 E = true)) → False
  exact pattern_6 (g1190 E) (g1227 E)
private theorem sat_853 (E : Nat → Bool) : (valuation E).satisfies [.neg 400, .pos 1189, .pos 1228] := by
  change (g401 E = true) → (¬ (g1190 E = true)) → (¬ (g1229 E = true)) → False
  exact pattern_6 (g401 E) (g1190 E)
private theorem sat_854 (E : Nat → Bool) : (valuation E).satisfies [.neg 1229, .neg 1228] := by
  change (g1230 E = true) → (g1229 E = true) → False
  exact pattern_4 (g1192 E) (g1229 E)
private theorem sat_855 (E : Nat → Bool) : (valuation E).satisfies [.neg 1229, .pos 1191] := by
  change (g1230 E = true) → (¬ (g1192 E = true)) → False
  exact pattern_5 (g1192 E) (g1229 E)
private theorem sat_856 (E : Nat → Bool) : (valuation E).satisfies [.pos 365, .pos 371, .pos 1261] := by
  change (¬ (g366 E = true)) → (¬ (g372 E = true)) → (¬ (g1262 E = true)) → False
  exact pattern_0 (g366 E) (g372 E)
private theorem sat_857 (E : Nat → Bool) : (valuation E).satisfies [.neg 1262, .pos 365] := by
  change (g1263 E = true) → (¬ (g366 E = true)) → False
  exact pattern_1 (g366 E) (g372 E)
private theorem sat_858 (E : Nat → Bool) : (valuation E).satisfies [.neg 1262, .pos 371] := by
  change (g1263 E = true) → (¬ (g372 E = true)) → False
  exact pattern_2 (g366 E) (g372 E)
private theorem sat_859 (E : Nat → Bool) : (valuation E).satisfies [.neg 1261, .pos 372, .pos 1263] := by
  change (g1262 E = true) → (¬ (g373 E = true)) → (¬ (g1264 E = true)) → False
  exact pattern_3 (g373 E) (g1262 E)
private theorem sat_860 (E : Nat → Bool) : (valuation E).satisfies [.neg 1264, .neg 1261] := by
  change (g1265 E = true) → (g1262 E = true) → False
  exact pattern_4 (g373 E) (g1262 E)
private theorem sat_861 (E : Nat → Bool) : (valuation E).satisfies [.neg 1264, .pos 372] := by
  change (g1265 E = true) → (¬ (g373 E = true)) → False
  exact pattern_5 (g373 E) (g1262 E)
private theorem sat_862 (E : Nat → Bool) : (valuation E).satisfies [.pos 1262, .pos 1264, .pos 1265] := by
  change (¬ (g1263 E = true)) → (¬ (g1265 E = true)) → (¬ (g1266 E = true)) → False
  exact pattern_0 (g1263 E) (g1265 E)
private theorem sat_863 (E : Nat → Bool) : (valuation E).satisfies [.neg 1266, .pos 372] := by
  change (g1267 E = true) → (¬ (g373 E = true)) → False
  exact pattern_1 (g373 E) (g1263 E)
private theorem sat_864 (E : Nat → Bool) : (valuation E).satisfies [.neg 1266, .pos 1262] := by
  change (g1267 E = true) → (¬ (g1263 E = true)) → False
  exact pattern_2 (g373 E) (g1263 E)
private theorem sat_865 (E : Nat → Bool) : (valuation E).satisfies [.neg 1263, .pos 373, .pos 1267] := by
  change (g1264 E = true) → (¬ (g374 E = true)) → (¬ (g1268 E = true)) → False
  exact pattern_3 (g374 E) (g1264 E)
private theorem sat_866 (E : Nat → Bool) : (valuation E).satisfies [.neg 1268, .neg 1263] := by
  change (g1269 E = true) → (g1264 E = true) → False
  exact pattern_4 (g374 E) (g1264 E)
private theorem sat_867 (E : Nat → Bool) : (valuation E).satisfies [.neg 1268, .pos 373] := by
  change (g1269 E = true) → (¬ (g374 E = true)) → False
  exact pattern_5 (g374 E) (g1264 E)
private theorem sat_868 (E : Nat → Bool) : (valuation E).satisfies [.neg 1265, .pos 1268, .pos 1269] := by
  change (g1266 E = true) → (¬ (g1269 E = true)) → (¬ (g1270 E = true)) → False
  exact pattern_6 (g1266 E) (g1269 E)
private theorem sat_869 (E : Nat → Bool) : (valuation E).satisfies [.neg 1270, .neg 1265] := by
  change (g1271 E = true) → (g1266 E = true) → False
  exact pattern_4 (g374 E) (g1266 E)
private theorem sat_870 (E : Nat → Bool) : (valuation E).satisfies [.neg 1270, .pos 373] := by
  change (g1271 E = true) → (¬ (g374 E = true)) → False
  exact pattern_5 (g374 E) (g1266 E)
private theorem sat_871 (E : Nat → Bool) : (valuation E).satisfies [.pos 1266, .pos 1270, .pos 1271] := by
  change (¬ (g1267 E = true)) → (¬ (g1271 E = true)) → (¬ (g1272 E = true)) → False
  exact pattern_0 (g1267 E) (g1271 E)
private theorem sat_872 (E : Nat → Bool) : (valuation E).satisfies [.neg 1272, .pos 373] := by
  change (g1273 E = true) → (¬ (g374 E = true)) → False
  exact pattern_1 (g374 E) (g1267 E)
private theorem sat_873 (E : Nat → Bool) : (valuation E).satisfies [.neg 1272, .pos 1266] := by
  change (g1273 E = true) → (¬ (g1267 E = true)) → False
  exact pattern_2 (g374 E) (g1267 E)
private theorem sat_874 (E : Nat → Bool) : (valuation E).satisfies [.neg 1267, .pos 374, .pos 1273] := by
  change (g1268 E = true) → (¬ (g375 E = true)) → (¬ (g1274 E = true)) → False
  exact pattern_3 (g375 E) (g1268 E)
private theorem sat_875 (E : Nat → Bool) : (valuation E).satisfies [.neg 1274, .neg 1267] := by
  change (g1275 E = true) → (g1268 E = true) → False
  exact pattern_4 (g375 E) (g1268 E)
private theorem sat_876 (E : Nat → Bool) : (valuation E).satisfies [.neg 1274, .pos 374] := by
  change (g1275 E = true) → (¬ (g375 E = true)) → False
  exact pattern_5 (g375 E) (g1268 E)
private theorem sat_877 (E : Nat → Bool) : (valuation E).satisfies [.neg 1269, .pos 1274, .pos 1275] := by
  change (g1270 E = true) → (¬ (g1275 E = true)) → (¬ (g1276 E = true)) → False
  exact pattern_6 (g1270 E) (g1275 E)
private theorem sat_878 (E : Nat → Bool) : (valuation E).satisfies [.neg 1276, .neg 1269] := by
  change (g1277 E = true) → (g1270 E = true) → False
  exact pattern_4 (g375 E) (g1270 E)
private theorem sat_879 (E : Nat → Bool) : (valuation E).satisfies [.neg 1276, .pos 374] := by
  change (g1277 E = true) → (¬ (g375 E = true)) → False
  exact pattern_5 (g375 E) (g1270 E)
private theorem sat_880 (E : Nat → Bool) : (valuation E).satisfies [.neg 1271, .pos 1276, .pos 1277] := by
  change (g1272 E = true) → (¬ (g1277 E = true)) → (¬ (g1278 E = true)) → False
  exact pattern_6 (g1272 E) (g1277 E)
private theorem sat_881 (E : Nat → Bool) : (valuation E).satisfies [.neg 1278, .neg 1271] := by
  change (g1279 E = true) → (g1272 E = true) → False
  exact pattern_4 (g375 E) (g1272 E)
private theorem sat_882 (E : Nat → Bool) : (valuation E).satisfies [.neg 1278, .pos 374] := by
  change (g1279 E = true) → (¬ (g375 E = true)) → False
  exact pattern_5 (g375 E) (g1272 E)
private theorem sat_883 (E : Nat → Bool) : (valuation E).satisfies [.pos 1272, .pos 1278, .pos 1279] := by
  change (¬ (g1273 E = true)) → (¬ (g1279 E = true)) → (¬ (g1280 E = true)) → False
  exact pattern_0 (g1273 E) (g1279 E)
private theorem sat_884 (E : Nat → Bool) : (valuation E).satisfies [.neg 1280, .pos 374] := by
  change (g1281 E = true) → (¬ (g375 E = true)) → False
  exact pattern_1 (g375 E) (g1273 E)
private theorem sat_885 (E : Nat → Bool) : (valuation E).satisfies [.neg 1273, .pos 375, .pos 1281] := by
  change (g1274 E = true) → (¬ (g376 E = true)) → (¬ (g1282 E = true)) → False
  exact pattern_3 (g376 E) (g1274 E)
private theorem sat_886 (E : Nat → Bool) : (valuation E).satisfies [.neg 1282, .neg 1273] := by
  change (g1283 E = true) → (g1274 E = true) → False
  exact pattern_4 (g376 E) (g1274 E)
private theorem sat_887 (E : Nat → Bool) : (valuation E).satisfies [.neg 1282, .pos 375] := by
  change (g1283 E = true) → (¬ (g376 E = true)) → False
  exact pattern_5 (g376 E) (g1274 E)
private theorem sat_888 (E : Nat → Bool) : (valuation E).satisfies [.neg 1275, .pos 1282, .pos 1283] := by
  change (g1276 E = true) → (¬ (g1283 E = true)) → (¬ (g1284 E = true)) → False
  exact pattern_6 (g1276 E) (g1283 E)
private theorem sat_889 (E : Nat → Bool) : (valuation E).satisfies [.neg 1284, .neg 1275] := by
  change (g1285 E = true) → (g1276 E = true) → False
  exact pattern_4 (g376 E) (g1276 E)
private theorem sat_890 (E : Nat → Bool) : (valuation E).satisfies [.neg 1284, .pos 375] := by
  change (g1285 E = true) → (¬ (g376 E = true)) → False
  exact pattern_5 (g376 E) (g1276 E)
private theorem sat_891 (E : Nat → Bool) : (valuation E).satisfies [.neg 1277, .pos 1284, .pos 1285] := by
  change (g1278 E = true) → (¬ (g1285 E = true)) → (¬ (g1286 E = true)) → False
  exact pattern_6 (g1278 E) (g1285 E)
private theorem sat_892 (E : Nat → Bool) : (valuation E).satisfies [.neg 1286, .neg 1277] := by
  change (g1287 E = true) → (g1278 E = true) → False
  exact pattern_4 (g376 E) (g1278 E)
private theorem sat_893 (E : Nat → Bool) : (valuation E).satisfies [.neg 1286, .pos 375] := by
  change (g1287 E = true) → (¬ (g376 E = true)) → False
  exact pattern_5 (g376 E) (g1278 E)
private theorem sat_894 (E : Nat → Bool) : (valuation E).satisfies [.neg 1279, .pos 1286, .pos 1287] := by
  change (g1280 E = true) → (¬ (g1287 E = true)) → (¬ (g1288 E = true)) → False
  exact pattern_6 (g1280 E) (g1287 E)
private theorem sat_895 (E : Nat → Bool) : (valuation E).satisfies [.neg 1288, .pos 375] := by
  change (g1289 E = true) → (¬ (g376 E = true)) → False
  exact pattern_5 (g376 E) (g1280 E)
private theorem sat_896 (E : Nat → Bool) : (valuation E).satisfies [.pos 1280, .pos 1288, .pos 1289] := by
  change (¬ (g1281 E = true)) → (¬ (g1289 E = true)) → (¬ (g1290 E = true)) → False
  exact pattern_0 (g1281 E) (g1289 E)
private theorem sat_897 (E : Nat → Bool) : (valuation E).satisfies [.neg 1281, .pos 386, .pos 1291] := by
  change (g1282 E = true) → (¬ (g387 E = true)) → (¬ (g1292 E = true)) → False
  exact pattern_3 (g387 E) (g1282 E)
private theorem sat_898 (E : Nat → Bool) : (valuation E).satisfies [.neg 1292, .neg 1281] := by
  change (g1293 E = true) → (g1282 E = true) → False
  exact pattern_4 (g387 E) (g1282 E)
private theorem sat_899 (E : Nat → Bool) : (valuation E).satisfies [.neg 1292, .pos 386] := by
  change (g1293 E = true) → (¬ (g387 E = true)) → False
  exact pattern_5 (g387 E) (g1282 E)
private theorem sat_900 (E : Nat → Bool) : (valuation E).satisfies [.neg 1283, .pos 1292, .pos 1293] := by
  change (g1284 E = true) → (¬ (g1293 E = true)) → (¬ (g1294 E = true)) → False
  exact pattern_6 (g1284 E) (g1293 E)
private theorem sat_901 (E : Nat → Bool) : (valuation E).satisfies [.neg 1294, .neg 1283] := by
  change (g1295 E = true) → (g1284 E = true) → False
  exact pattern_4 (g387 E) (g1284 E)
private theorem sat_902 (E : Nat → Bool) : (valuation E).satisfies [.neg 1294, .pos 386] := by
  change (g1295 E = true) → (¬ (g387 E = true)) → False
  exact pattern_5 (g387 E) (g1284 E)
private theorem sat_903 (E : Nat → Bool) : (valuation E).satisfies [.neg 1285, .pos 1294, .pos 1295] := by
  change (g1286 E = true) → (¬ (g1295 E = true)) → (¬ (g1296 E = true)) → False
  exact pattern_6 (g1286 E) (g1295 E)
private theorem sat_904 (E : Nat → Bool) : (valuation E).satisfies [.neg 1296, .neg 1285] := by
  change (g1297 E = true) → (g1286 E = true) → False
  exact pattern_4 (g387 E) (g1286 E)
private theorem sat_905 (E : Nat → Bool) : (valuation E).satisfies [.neg 1296, .pos 386] := by
  change (g1297 E = true) → (¬ (g387 E = true)) → False
  exact pattern_5 (g387 E) (g1286 E)
private theorem sat_906 (E : Nat → Bool) : (valuation E).satisfies [.neg 1287, .pos 1296, .pos 1297] := by
  change (g1288 E = true) → (¬ (g1297 E = true)) → (¬ (g1298 E = true)) → False
  exact pattern_6 (g1288 E) (g1297 E)
private theorem sat_907 (E : Nat → Bool) : (valuation E).satisfies [.neg 1298, .neg 1287] := by
  change (g1299 E = true) → (g1288 E = true) → False
  exact pattern_4 (g387 E) (g1288 E)
private theorem sat_908 (E : Nat → Bool) : (valuation E).satisfies [.neg 1289, .pos 1298, .pos 1299] := by
  change (g1290 E = true) → (¬ (g1299 E = true)) → (¬ (g1300 E = true)) → False
  exact pattern_6 (g1290 E) (g1299 E)
private theorem sat_909 (E : Nat → Bool) : (valuation E).satisfies [.neg 1291, .pos 387, .pos 1303] := by
  change (g1292 E = true) → (¬ (g388 E = true)) → (¬ (g1304 E = true)) → False
  exact pattern_3 (g388 E) (g1292 E)
private theorem sat_910 (E : Nat → Bool) : (valuation E).satisfies [.neg 1304, .neg 1291] := by
  change (g1305 E = true) → (g1292 E = true) → False
  exact pattern_4 (g388 E) (g1292 E)
private theorem sat_911 (E : Nat → Bool) : (valuation E).satisfies [.neg 1304, .pos 387] := by
  change (g1305 E = true) → (¬ (g388 E = true)) → False
  exact pattern_5 (g388 E) (g1292 E)
private theorem sat_912 (E : Nat → Bool) : (valuation E).satisfies [.neg 1293, .pos 1304, .pos 1305] := by
  change (g1294 E = true) → (¬ (g1305 E = true)) → (¬ (g1306 E = true)) → False
  exact pattern_6 (g1294 E) (g1305 E)
private theorem sat_913 (E : Nat → Bool) : (valuation E).satisfies [.neg 1306, .neg 1293] := by
  change (g1307 E = true) → (g1294 E = true) → False
  exact pattern_4 (g388 E) (g1294 E)
private theorem sat_914 (E : Nat → Bool) : (valuation E).satisfies [.neg 1306, .pos 387] := by
  change (g1307 E = true) → (¬ (g388 E = true)) → False
  exact pattern_5 (g388 E) (g1294 E)
private theorem sat_915 (E : Nat → Bool) : (valuation E).satisfies [.neg 1295, .pos 1306, .pos 1307] := by
  change (g1296 E = true) → (¬ (g1307 E = true)) → (¬ (g1308 E = true)) → False
  exact pattern_6 (g1296 E) (g1307 E)
private theorem sat_916 (E : Nat → Bool) : (valuation E).satisfies [.neg 1308, .neg 1295] := by
  change (g1309 E = true) → (g1296 E = true) → False
  exact pattern_4 (g388 E) (g1296 E)
private theorem sat_917 (E : Nat → Bool) : (valuation E).satisfies [.neg 1308, .pos 387] := by
  change (g1309 E = true) → (¬ (g388 E = true)) → False
  exact pattern_5 (g388 E) (g1296 E)
private theorem sat_918 (E : Nat → Bool) : (valuation E).satisfies [.neg 1297, .pos 1308, .pos 1309] := by
  change (g1298 E = true) → (¬ (g1309 E = true)) → (¬ (g1310 E = true)) → False
  exact pattern_6 (g1298 E) (g1309 E)
private theorem sat_919 (E : Nat → Bool) : (valuation E).satisfies [.neg 1310, .neg 1297] := by
  change (g1311 E = true) → (g1298 E = true) → False
  exact pattern_4 (g388 E) (g1298 E)
private theorem sat_920 (E : Nat → Bool) : (valuation E).satisfies [.neg 1299, .pos 1310, .pos 1311] := by
  change (g1300 E = true) → (¬ (g1311 E = true)) → (¬ (g1312 E = true)) → False
  exact pattern_6 (g1300 E) (g1311 E)
private theorem sat_921 (E : Nat → Bool) : (valuation E).satisfies [.neg 1303, .pos 388, .pos 1317] := by
  change (g1304 E = true) → (¬ (g389 E = true)) → (¬ (g1318 E = true)) → False
  exact pattern_3 (g389 E) (g1304 E)
private theorem sat_922 (E : Nat → Bool) : (valuation E).satisfies [.neg 1318, .neg 1303] := by
  change (g1319 E = true) → (g1304 E = true) → False
  exact pattern_4 (g389 E) (g1304 E)
private theorem sat_923 (E : Nat → Bool) : (valuation E).satisfies [.neg 1318, .pos 388] := by
  change (g1319 E = true) → (¬ (g389 E = true)) → False
  exact pattern_5 (g389 E) (g1304 E)
private theorem sat_924 (E : Nat → Bool) : (valuation E).satisfies [.neg 1305, .pos 1318, .pos 1319] := by
  change (g1306 E = true) → (¬ (g1319 E = true)) → (¬ (g1320 E = true)) → False
  exact pattern_6 (g1306 E) (g1319 E)
private theorem sat_925 (E : Nat → Bool) : (valuation E).satisfies [.neg 1320, .neg 1305] := by
  change (g1321 E = true) → (g1306 E = true) → False
  exact pattern_4 (g389 E) (g1306 E)
private theorem sat_926 (E : Nat → Bool) : (valuation E).satisfies [.neg 1320, .pos 388] := by
  change (g1321 E = true) → (¬ (g389 E = true)) → False
  exact pattern_5 (g389 E) (g1306 E)
private theorem sat_927 (E : Nat → Bool) : (valuation E).satisfies [.neg 1307, .pos 1320, .pos 1321] := by
  change (g1308 E = true) → (¬ (g1321 E = true)) → (¬ (g1322 E = true)) → False
  exact pattern_6 (g1308 E) (g1321 E)
private theorem sat_928 (E : Nat → Bool) : (valuation E).satisfies [.neg 1322, .neg 1307] := by
  change (g1323 E = true) → (g1308 E = true) → False
  exact pattern_4 (g389 E) (g1308 E)
private theorem sat_929 (E : Nat → Bool) : (valuation E).satisfies [.neg 1322, .pos 388] := by
  change (g1323 E = true) → (¬ (g389 E = true)) → False
  exact pattern_5 (g389 E) (g1308 E)
private theorem sat_930 (E : Nat → Bool) : (valuation E).satisfies [.neg 1309, .pos 1322, .pos 1323] := by
  change (g1310 E = true) → (¬ (g1323 E = true)) → (¬ (g1324 E = true)) → False
  exact pattern_6 (g1310 E) (g1323 E)
private theorem sat_931 (E : Nat → Bool) : (valuation E).satisfies [.neg 1324, .neg 1309] := by
  change (g1325 E = true) → (g1310 E = true) → False
  exact pattern_4 (g389 E) (g1310 E)
private theorem sat_932 (E : Nat → Bool) : (valuation E).satisfies [.neg 1311, .pos 1324, .pos 1325] := by
  change (g1312 E = true) → (¬ (g1325 E = true)) → (¬ (g1326 E = true)) → False
  exact pattern_6 (g1312 E) (g1325 E)
private theorem sat_933 (E : Nat → Bool) : (valuation E).satisfies [.neg 1317, .pos 389, .pos 1333] := by
  change (g1318 E = true) → (¬ (g390 E = true)) → (¬ (g1334 E = true)) → False
  exact pattern_3 (g390 E) (g1318 E)
private theorem sat_934 (E : Nat → Bool) : (valuation E).satisfies [.neg 1334, .neg 1317] := by
  change (g1335 E = true) → (g1318 E = true) → False
  exact pattern_4 (g390 E) (g1318 E)
private theorem sat_935 (E : Nat → Bool) : (valuation E).satisfies [.neg 1334, .pos 389] := by
  change (g1335 E = true) → (¬ (g390 E = true)) → False
  exact pattern_5 (g390 E) (g1318 E)
private theorem sat_936 (E : Nat → Bool) : (valuation E).satisfies [.neg 1319, .pos 1334, .pos 1335] := by
  change (g1320 E = true) → (¬ (g1335 E = true)) → (¬ (g1336 E = true)) → False
  exact pattern_6 (g1320 E) (g1335 E)
private theorem sat_937 (E : Nat → Bool) : (valuation E).satisfies [.neg 1336, .neg 1319] := by
  change (g1337 E = true) → (g1320 E = true) → False
  exact pattern_4 (g390 E) (g1320 E)
private theorem sat_938 (E : Nat → Bool) : (valuation E).satisfies [.neg 1336, .pos 389] := by
  change (g1337 E = true) → (¬ (g390 E = true)) → False
  exact pattern_5 (g390 E) (g1320 E)
private theorem sat_939 (E : Nat → Bool) : (valuation E).satisfies [.neg 1321, .pos 1336, .pos 1337] := by
  change (g1322 E = true) → (¬ (g1337 E = true)) → (¬ (g1338 E = true)) → False
  exact pattern_6 (g1322 E) (g1337 E)
private theorem sat_940 (E : Nat → Bool) : (valuation E).satisfies [.neg 1338, .neg 1321] := by
  change (g1339 E = true) → (g1322 E = true) → False
  exact pattern_4 (g390 E) (g1322 E)
private theorem sat_941 (E : Nat → Bool) : (valuation E).satisfies [.neg 1338, .pos 389] := by
  change (g1339 E = true) → (¬ (g390 E = true)) → False
  exact pattern_5 (g390 E) (g1322 E)
private theorem sat_942 (E : Nat → Bool) : (valuation E).satisfies [.neg 1323, .pos 1338, .pos 1339] := by
  change (g1324 E = true) → (¬ (g1339 E = true)) → (¬ (g1340 E = true)) → False
  exact pattern_6 (g1324 E) (g1339 E)
private theorem sat_943 (E : Nat → Bool) : (valuation E).satisfies [.neg 1340, .neg 1323] := by
  change (g1341 E = true) → (g1324 E = true) → False
  exact pattern_4 (g390 E) (g1324 E)
private theorem sat_944 (E : Nat → Bool) : (valuation E).satisfies [.neg 1325, .pos 1340, .pos 1341] := by
  change (g1326 E = true) → (¬ (g1341 E = true)) → (¬ (g1342 E = true)) → False
  exact pattern_6 (g1326 E) (g1341 E)
private theorem sat_945 (E : Nat → Bool) : (valuation E).satisfies [.neg 1333, .pos 390, .pos 1351] := by
  change (g1334 E = true) → (¬ (g391 E = true)) → (¬ (g1352 E = true)) → False
  exact pattern_3 (g391 E) (g1334 E)
private theorem sat_946 (E : Nat → Bool) : (valuation E).satisfies [.neg 1352, .neg 1333] := by
  change (g1353 E = true) → (g1334 E = true) → False
  exact pattern_4 (g391 E) (g1334 E)
private theorem sat_947 (E : Nat → Bool) : (valuation E).satisfies [.neg 1352, .pos 390] := by
  change (g1353 E = true) → (¬ (g391 E = true)) → False
  exact pattern_5 (g391 E) (g1334 E)
private theorem sat_948 (E : Nat → Bool) : (valuation E).satisfies [.neg 1335, .pos 1352, .pos 1353] := by
  change (g1336 E = true) → (¬ (g1353 E = true)) → (¬ (g1354 E = true)) → False
  exact pattern_6 (g1336 E) (g1353 E)
private theorem sat_949 (E : Nat → Bool) : (valuation E).satisfies [.neg 1354, .neg 1335] := by
  change (g1355 E = true) → (g1336 E = true) → False
  exact pattern_4 (g391 E) (g1336 E)
private theorem sat_950 (E : Nat → Bool) : (valuation E).satisfies [.neg 1354, .pos 390] := by
  change (g1355 E = true) → (¬ (g391 E = true)) → False
  exact pattern_5 (g391 E) (g1336 E)
private theorem sat_951 (E : Nat → Bool) : (valuation E).satisfies [.neg 1337, .pos 1354, .pos 1355] := by
  change (g1338 E = true) → (¬ (g1355 E = true)) → (¬ (g1356 E = true)) → False
  exact pattern_6 (g1338 E) (g1355 E)
private theorem sat_952 (E : Nat → Bool) : (valuation E).satisfies [.neg 1356, .neg 1337] := by
  change (g1357 E = true) → (g1338 E = true) → False
  exact pattern_4 (g391 E) (g1338 E)
private theorem sat_953 (E : Nat → Bool) : (valuation E).satisfies [.neg 1356, .pos 390] := by
  change (g1357 E = true) → (¬ (g391 E = true)) → False
  exact pattern_5 (g391 E) (g1338 E)
private theorem sat_954 (E : Nat → Bool) : (valuation E).satisfies [.neg 1357, .pos 1339] := by
  change (g1358 E = true) → (¬ (g1340 E = true)) → False
  exact pattern_5 (g1340 E) (g1357 E)
private theorem sat_955 (E : Nat → Bool) : (valuation E).satisfies [.neg 1339, .pos 1356, .pos 1357] := by
  change (g1340 E = true) → (¬ (g1357 E = true)) → (¬ (g1358 E = true)) → False
  exact pattern_6 (g1340 E) (g1357 E)
private theorem sat_956 (E : Nat → Bool) : (valuation E).satisfies [.neg 1358, .neg 1339] := by
  change (g1359 E = true) → (g1340 E = true) → False
  exact pattern_4 (g391 E) (g1340 E)
private theorem sat_957 (E : Nat → Bool) : (valuation E).satisfies [.neg 1341, .pos 1358, .pos 1359] := by
  change (g1342 E = true) → (¬ (g1359 E = true)) → (¬ (g1360 E = true)) → False
  exact pattern_6 (g1342 E) (g1359 E)
private theorem sat_958 (E : Nat → Bool) : (valuation E).satisfies [.neg 1371, .neg 401] := by
  change (g1372 E = true) → (g402 E = true) → False
  exact pattern_8 (g402 E) (g1352 E)
private theorem sat_959 (E : Nat → Bool) : (valuation E).satisfies [.neg 1351, .pos 401, .pos 1371] := by
  change (g1352 E = true) → (¬ (g402 E = true)) → (¬ (g1372 E = true)) → False
  exact pattern_3 (g402 E) (g1352 E)
private theorem sat_960 (E : Nat → Bool) : (valuation E).satisfies [.neg 1372, .neg 1351] := by
  change (g1373 E = true) → (g1352 E = true) → False
  exact pattern_4 (g402 E) (g1352 E)
private theorem sat_961 (E : Nat → Bool) : (valuation E).satisfies [.neg 1372, .pos 401] := by
  change (g1373 E = true) → (¬ (g402 E = true)) → False
  exact pattern_5 (g402 E) (g1352 E)
private theorem sat_962 (E : Nat → Bool) : (valuation E).satisfies [.neg 1353, .pos 1372, .pos 1373] := by
  change (g1354 E = true) → (¬ (g1373 E = true)) → (¬ (g1374 E = true)) → False
  exact pattern_6 (g1354 E) (g1373 E)
private theorem sat_963 (E : Nat → Bool) : (valuation E).satisfies [.neg 1374, .neg 1353] := by
  change (g1375 E = true) → (g1354 E = true) → False
  exact pattern_4 (g402 E) (g1354 E)
private theorem sat_964 (E : Nat → Bool) : (valuation E).satisfies [.neg 1374, .pos 401] := by
  change (g1375 E = true) → (¬ (g402 E = true)) → False
  exact pattern_5 (g402 E) (g1354 E)
private theorem sat_965 (E : Nat → Bool) : (valuation E).satisfies [.neg 401, .pos 1353, .pos 1374] := by
  change (g402 E = true) → (¬ (g1354 E = true)) → (¬ (g1375 E = true)) → False
  exact pattern_6 (g402 E) (g1354 E)
private theorem sat_966 (E : Nat → Bool) : (valuation E).satisfies [.neg 1375, .neg 1374] := by
  change (g1376 E = true) → (g1375 E = true) → False
  exact pattern_4 (g1356 E) (g1375 E)
private theorem sat_967 (E : Nat → Bool) : (valuation E).satisfies [.neg 1355, .pos 1374, .pos 1375] := by
  change (g1356 E = true) → (¬ (g1375 E = true)) → (¬ (g1376 E = true)) → False
  exact pattern_6 (g1356 E) (g1375 E)
private theorem sat_968 (E : Nat → Bool) : (valuation E).satisfies [.neg 1376, .neg 1355] := by
  change (g1377 E = true) → (g1356 E = true) → False
  exact pattern_4 (g402 E) (g1356 E)
private theorem sat_969 (E : Nat → Bool) : (valuation E).satisfies [.neg 1376, .pos 401] := by
  change (g1377 E = true) → (¬ (g402 E = true)) → False
  exact pattern_5 (g402 E) (g1356 E)
private theorem sat_970 (E : Nat → Bool) : (valuation E).satisfies [.neg 1357, .pos 1376, .pos 1377] := by
  change (g1358 E = true) → (¬ (g1377 E = true)) → (¬ (g1378 E = true)) → False
  exact pattern_6 (g1358 E) (g1377 E)
private theorem sat_971 (E : Nat → Bool) : (valuation E).satisfies [.neg 1378, .neg 1357] := by
  change (g1379 E = true) → (g1358 E = true) → False
  exact pattern_4 (g402 E) (g1358 E)
private theorem sat_972 (E : Nat → Bool) : (valuation E).satisfies [.neg 1359, .pos 1378, .pos 1379] := by
  change (g1360 E = true) → (¬ (g1379 E = true)) → (¬ (g1380 E = true)) → False
  exact pattern_6 (g1360 E) (g1379 E)
private theorem sat_973 (E : Nat → Bool) : (valuation E).satisfies [.neg 1393, .neg 402] := by
  change (g1394 E = true) → (g403 E = true) → False
  exact pattern_8 (g403 E) (g1372 E)
private theorem sat_974 (E : Nat → Bool) : (valuation E).satisfies [.neg 1371, .pos 402, .pos 1393] := by
  change (g1372 E = true) → (¬ (g403 E = true)) → (¬ (g1394 E = true)) → False
  exact pattern_3 (g403 E) (g1372 E)
private theorem sat_975 (E : Nat → Bool) : (valuation E).satisfies [.neg 1394, .neg 1371] := by
  change (g1395 E = true) → (g1372 E = true) → False
  exact pattern_4 (g403 E) (g1372 E)
private theorem sat_976 (E : Nat → Bool) : (valuation E).satisfies [.neg 1394, .pos 402] := by
  change (g1395 E = true) → (¬ (g403 E = true)) → False
  exact pattern_5 (g403 E) (g1372 E)
private theorem sat_977 (E : Nat → Bool) : (valuation E).satisfies [.neg 402, .pos 1371, .pos 1394] := by
  change (g403 E = true) → (¬ (g1372 E = true)) → (¬ (g1395 E = true)) → False
  exact pattern_6 (g403 E) (g1372 E)
private theorem sat_978 (E : Nat → Bool) : (valuation E).satisfies [.neg 1395, .neg 1394] := by
  change (g1396 E = true) → (g1395 E = true) → False
  exact pattern_4 (g1374 E) (g1395 E)
private theorem sat_979 (E : Nat → Bool) : (valuation E).satisfies [.neg 1373, .pos 1394, .pos 1395] := by
  change (g1374 E = true) → (¬ (g1395 E = true)) → (¬ (g1396 E = true)) → False
  exact pattern_6 (g1374 E) (g1395 E)
private theorem sat_980 (E : Nat → Bool) : (valuation E).satisfies [.neg 1396, .neg 1373] := by
  change (g1397 E = true) → (g1374 E = true) → False
  exact pattern_4 (g403 E) (g1374 E)
private theorem sat_981 (E : Nat → Bool) : (valuation E).satisfies [.neg 1396, .pos 402] := by
  change (g1397 E = true) → (¬ (g403 E = true)) → False
  exact pattern_5 (g403 E) (g1374 E)
private theorem sat_982 (E : Nat → Bool) : (valuation E).satisfies [.neg 1375, .pos 1396, .pos 1397] := by
  change (g1376 E = true) → (¬ (g1397 E = true)) → (¬ (g1398 E = true)) → False
  exact pattern_6 (g1376 E) (g1397 E)
private theorem sat_983 (E : Nat → Bool) : (valuation E).satisfies [.neg 1398, .neg 1375] := by
  change (g1399 E = true) → (g1376 E = true) → False
  exact pattern_4 (g403 E) (g1376 E)
private theorem sat_984 (E : Nat → Bool) : (valuation E).satisfies [.neg 1398, .pos 402] := by
  change (g1399 E = true) → (¬ (g403 E = true)) → False
  exact pattern_5 (g403 E) (g1376 E)
private theorem sat_985 (E : Nat → Bool) : (valuation E).satisfies [.neg 402, .pos 1375, .pos 1398] := by
  change (g403 E = true) → (¬ (g1376 E = true)) → (¬ (g1399 E = true)) → False
  exact pattern_6 (g403 E) (g1376 E)
private theorem sat_986 (E : Nat → Bool) : (valuation E).satisfies [.neg 1399, .neg 1398] := by
  change (g1400 E = true) → (g1399 E = true) → False
  exact pattern_4 (g1378 E) (g1399 E)
private theorem sat_987 (E : Nat → Bool) : (valuation E).satisfies [.neg 1377, .pos 1398, .pos 1399] := by
  change (g1378 E = true) → (¬ (g1399 E = true)) → (¬ (g1400 E = true)) → False
  exact pattern_6 (g1378 E) (g1399 E)
private theorem sat_988 (E : Nat → Bool) : (valuation E).satisfies [.neg 1400, .neg 1377] := by
  change (g1401 E = true) → (g1378 E = true) → False
  exact pattern_4 (g403 E) (g1378 E)
private theorem sat_989 (E : Nat → Bool) : (valuation E).satisfies [.neg 1379, .pos 1400, .pos 1401] := by
  change (g1380 E = true) → (¬ (g1401 E = true)) → (¬ (g1402 E = true)) → False
  exact pattern_6 (g1380 E) (g1401 E)
private theorem sat_990 (E : Nat → Bool) : (valuation E).satisfies [.neg 1393, .pos 403, .pos 1417] := by
  change (g1394 E = true) → (¬ (g404 E = true)) → (¬ (g1418 E = true)) → False
  exact pattern_3 (g404 E) (g1394 E)
private theorem sat_991 (E : Nat → Bool) : (valuation E).satisfies [.neg 1418, .pos 403] := by
  change (g1419 E = true) → (¬ (g404 E = true)) → False
  exact pattern_5 (g404 E) (g1394 E)
private theorem sat_992 (E : Nat → Bool) : (valuation E).satisfies [.neg 403, .pos 1393, .pos 1418] := by
  change (g404 E = true) → (¬ (g1394 E = true)) → (¬ (g1419 E = true)) → False
  exact pattern_6 (g404 E) (g1394 E)
private theorem sat_993 (E : Nat → Bool) : (valuation E).satisfies [.neg 1419, .neg 1418] := by
  change (g1420 E = true) → (g1419 E = true) → False
  exact pattern_4 (g1396 E) (g1419 E)
private theorem sat_994 (E : Nat → Bool) : (valuation E).satisfies [.neg 1395, .pos 1418, .pos 1419] := by
  change (g1396 E = true) → (¬ (g1419 E = true)) → (¬ (g1420 E = true)) → False
  exact pattern_6 (g1396 E) (g1419 E)
private theorem sat_995 (E : Nat → Bool) : (valuation E).satisfies [.neg 1420, .neg 1395] := by
  change (g1421 E = true) → (g1396 E = true) → False
  exact pattern_4 (g404 E) (g1396 E)
private theorem sat_996 (E : Nat → Bool) : (valuation E).satisfies [.neg 1420, .pos 403] := by
  change (g1421 E = true) → (¬ (g404 E = true)) → False
  exact pattern_5 (g404 E) (g1396 E)
private theorem sat_997 (E : Nat → Bool) : (valuation E).satisfies [.neg 403, .pos 1395, .pos 1420] := by
  change (g404 E = true) → (¬ (g1396 E = true)) → (¬ (g1421 E = true)) → False
  exact pattern_6 (g404 E) (g1396 E)
private theorem sat_998 (E : Nat → Bool) : (valuation E).satisfies [.neg 1421, .neg 1420] := by
  change (g1422 E = true) → (g1421 E = true) → False
  exact pattern_4 (g1398 E) (g1421 E)
private theorem sat_999 (E : Nat → Bool) : (valuation E).satisfies [.neg 1397, .pos 1420, .pos 1421] := by
  change (g1398 E = true) → (¬ (g1421 E = true)) → (¬ (g1422 E = true)) → False
  exact pattern_6 (g1398 E) (g1421 E)
private theorem sat_1000 (E : Nat → Bool) : (valuation E).satisfies [.neg 1422, .neg 1397] := by
  change (g1423 E = true) → (g1398 E = true) → False
  exact pattern_4 (g404 E) (g1398 E)
private theorem sat_1001 (E : Nat → Bool) : (valuation E).satisfies [.neg 1422, .pos 403] := by
  change (g1423 E = true) → (¬ (g404 E = true)) → False
  exact pattern_5 (g404 E) (g1398 E)
private theorem sat_1002 (E : Nat → Bool) : (valuation E).satisfies [.neg 1423, .pos 1399] := by
  change (g1424 E = true) → (¬ (g1400 E = true)) → False
  exact pattern_5 (g1400 E) (g1423 E)
private theorem sat_1003 (E : Nat → Bool) : (valuation E).satisfies [.neg 1399, .pos 1422, .pos 1423] := by
  change (g1400 E = true) → (¬ (g1423 E = true)) → (¬ (g1424 E = true)) → False
  exact pattern_6 (g1400 E) (g1423 E)
private theorem sat_1004 (E : Nat → Bool) : (valuation E).satisfies [.neg 1424, .pos 403] := by
  change (g1425 E = true) → (¬ (g404 E = true)) → False
  exact pattern_5 (g404 E) (g1400 E)
private theorem sat_1005 (E : Nat → Bool) : (valuation E).satisfies [.neg 403, .pos 1399, .pos 1424] := by
  change (g404 E = true) → (¬ (g1400 E = true)) → (¬ (g1425 E = true)) → False
  exact pattern_6 (g404 E) (g1400 E)
private theorem sat_1006 (E : Nat → Bool) : (valuation E).satisfies [.neg 1425, .neg 1424] := by
  change (g1426 E = true) → (g1425 E = true) → False
  exact pattern_4 (g1402 E) (g1425 E)
private theorem sat_1007 (E : Nat → Bool) : (valuation E).satisfies [.neg 1401, .pos 1424, .pos 1425] := by
  change (g1402 E = true) → (¬ (g1425 E = true)) → (¬ (g1426 E = true)) → False
  exact pattern_6 (g1402 E) (g1425 E)
private theorem sat_1008 (E : Nat → Bool) : (valuation E).satisfies [.neg 1417, .pos 404, .pos 1443] := by
  change (g1418 E = true) → (¬ (g405 E = true)) → (¬ (g1444 E = true)) → False
  exact pattern_3 (g405 E) (g1418 E)
private theorem sat_1009 (E : Nat → Bool) : (valuation E).satisfies [.neg 1444, .neg 1417] := by
  change (g1445 E = true) → (g1418 E = true) → False
  exact pattern_4 (g405 E) (g1418 E)
private theorem sat_1010 (E : Nat → Bool) : (valuation E).satisfies [.neg 1444, .pos 404] := by
  change (g1445 E = true) → (¬ (g405 E = true)) → False
  exact pattern_5 (g405 E) (g1418 E)
private theorem sat_1011 (E : Nat → Bool) : (valuation E).satisfies [.neg 1419, .pos 1444, .pos 1445] := by
  change (g1420 E = true) → (¬ (g1445 E = true)) → (¬ (g1446 E = true)) → False
  exact pattern_6 (g1420 E) (g1445 E)
private theorem sat_1012 (E : Nat → Bool) : (valuation E).satisfies [.neg 1446, .neg 1419] := by
  change (g1447 E = true) → (g1420 E = true) → False
  exact pattern_4 (g405 E) (g1420 E)
private theorem sat_1013 (E : Nat → Bool) : (valuation E).satisfies [.neg 1446, .pos 404] := by
  change (g1447 E = true) → (¬ (g405 E = true)) → False
  exact pattern_5 (g405 E) (g1420 E)
private theorem sat_1014 (E : Nat → Bool) : (valuation E).satisfies [.neg 404, .pos 1419, .pos 1446] := by
  change (g405 E = true) → (¬ (g1420 E = true)) → (¬ (g1447 E = true)) → False
  exact pattern_6 (g405 E) (g1420 E)
private theorem sat_1015 (E : Nat → Bool) : (valuation E).satisfies [.neg 1447, .neg 1446] := by
  change (g1448 E = true) → (g1447 E = true) → False
  exact pattern_4 (g1422 E) (g1447 E)
private theorem sat_1016 (E : Nat → Bool) : (valuation E).satisfies [.neg 1421, .pos 1446, .pos 1447] := by
  change (g1422 E = true) → (¬ (g1447 E = true)) → (¬ (g1448 E = true)) → False
  exact pattern_6 (g1422 E) (g1447 E)
private theorem sat_1017 (E : Nat → Bool) : (valuation E).satisfies [.neg 1448, .neg 1421] := by
  change (g1449 E = true) → (g1422 E = true) → False
  exact pattern_4 (g405 E) (g1422 E)
private theorem sat_1018 (E : Nat → Bool) : (valuation E).satisfies [.neg 1448, .pos 404] := by
  change (g1449 E = true) → (¬ (g405 E = true)) → False
  exact pattern_5 (g405 E) (g1422 E)
private theorem sat_1019 (E : Nat → Bool) : (valuation E).satisfies [.neg 404, .pos 1421, .pos 1448] := by
  change (g405 E = true) → (¬ (g1422 E = true)) → (¬ (g1449 E = true)) → False
  exact pattern_6 (g405 E) (g1422 E)
private theorem sat_1020 (E : Nat → Bool) : (valuation E).satisfies [.neg 1449, .neg 1448] := by
  change (g1450 E = true) → (g1449 E = true) → False
  exact pattern_4 (g1424 E) (g1449 E)
private theorem sat_1021 (E : Nat → Bool) : (valuation E).satisfies [.neg 1423, .pos 1448, .pos 1449] := by
  change (g1424 E = true) → (¬ (g1449 E = true)) → (¬ (g1450 E = true)) → False
  exact pattern_6 (g1424 E) (g1449 E)
private theorem sat_1022 (E : Nat → Bool) : (valuation E).satisfies [.neg 1450, .neg 1423] := by
  change (g1451 E = true) → (g1424 E = true) → False
  exact pattern_4 (g405 E) (g1424 E)
private theorem sat_1023 (E : Nat → Bool) : (valuation E).satisfies [.neg 404, .pos 1423, .pos 1450] := by
  change (g405 E = true) → (¬ (g1424 E = true)) → (¬ (g1451 E = true)) → False
  exact pattern_6 (g405 E) (g1424 E)
private theorem sat_1024 (E : Nat → Bool) : (valuation E).satisfies [.neg 1451, .neg 1450] := by
  change (g1452 E = true) → (g1451 E = true) → False
  exact pattern_4 (g1426 E) (g1451 E)
private theorem sat_1025 (E : Nat → Bool) : (valuation E).satisfies [.neg 1451, .pos 1425] := by
  change (g1452 E = true) → (¬ (g1426 E = true)) → False
  exact pattern_5 (g1426 E) (g1451 E)
private theorem sat_1026 (E : Nat → Bool) : (valuation E).satisfies [.neg 1425, .pos 1450, .pos 1451] := by
  change (g1426 E = true) → (¬ (g1451 E = true)) → (¬ (g1452 E = true)) → False
  exact pattern_6 (g1426 E) (g1451 E)
private theorem sat_1027 (E : Nat → Bool) : (valuation E).satisfies [.neg 1443, .pos 405, .pos 1471] := by
  change (g1444 E = true) → (¬ (g406 E = true)) → (¬ (g1472 E = true)) → False
  exact pattern_3 (g406 E) (g1444 E)
private theorem sat_1028 (E : Nat → Bool) : (valuation E).satisfies [.neg 1472, .neg 1443] := by
  change (g1473 E = true) → (g1444 E = true) → False
  exact pattern_4 (g406 E) (g1444 E)
private theorem sat_1029 (E : Nat → Bool) : (valuation E).satisfies [.neg 1472, .pos 405] := by
  change (g1473 E = true) → (¬ (g406 E = true)) → False
  exact pattern_5 (g406 E) (g1444 E)
private theorem sat_1030 (E : Nat → Bool) : (valuation E).satisfies [.neg 1445, .pos 1472, .pos 1473] := by
  change (g1446 E = true) → (¬ (g1473 E = true)) → (¬ (g1474 E = true)) → False
  exact pattern_6 (g1446 E) (g1473 E)
private theorem sat_1031 (E : Nat → Bool) : (valuation E).satisfies [.neg 1474, .neg 1445] := by
  change (g1475 E = true) → (g1446 E = true) → False
  exact pattern_4 (g406 E) (g1446 E)
private theorem sat_1032 (E : Nat → Bool) : (valuation E).satisfies [.neg 1474, .pos 405] := by
  change (g1475 E = true) → (¬ (g406 E = true)) → False
  exact pattern_5 (g406 E) (g1446 E)
private theorem sat_1033 (E : Nat → Bool) : (valuation E).satisfies [.neg 1475, .pos 1447] := by
  change (g1476 E = true) → (¬ (g1448 E = true)) → False
  exact pattern_5 (g1448 E) (g1475 E)
private theorem sat_1034 (E : Nat → Bool) : (valuation E).satisfies [.neg 1447, .pos 1474, .pos 1475] := by
  change (g1448 E = true) → (¬ (g1475 E = true)) → (¬ (g1476 E = true)) → False
  exact pattern_6 (g1448 E) (g1475 E)
private theorem sat_1035 (E : Nat → Bool) : (valuation E).satisfies [.neg 1476, .neg 1447] := by
  change (g1477 E = true) → (g1448 E = true) → False
  exact pattern_4 (g406 E) (g1448 E)
private theorem sat_1036 (E : Nat → Bool) : (valuation E).satisfies [.neg 1476, .pos 405] := by
  change (g1477 E = true) → (¬ (g406 E = true)) → False
  exact pattern_5 (g406 E) (g1448 E)
private theorem sat_1037 (E : Nat → Bool) : (valuation E).satisfies [.neg 1477, .pos 1449] := by
  change (g1478 E = true) → (¬ (g1450 E = true)) → False
  exact pattern_5 (g1450 E) (g1477 E)
private theorem sat_1038 (E : Nat → Bool) : (valuation E).satisfies [.neg 1449, .pos 1476, .pos 1477] := by
  change (g1450 E = true) → (¬ (g1477 E = true)) → (¬ (g1478 E = true)) → False
  exact pattern_6 (g1450 E) (g1477 E)
private theorem sat_1039 (E : Nat → Bool) : (valuation E).satisfies [.neg 1478, .neg 1449] := by
  change (g1479 E = true) → (g1450 E = true) → False
  exact pattern_4 (g406 E) (g1450 E)
private theorem sat_1040 (E : Nat → Bool) : (valuation E).satisfies [.neg 1479, .pos 1451] := by
  change (g1480 E = true) → (¬ (g1452 E = true)) → False
  exact pattern_5 (g1452 E) (g1479 E)
private theorem sat_1041 (E : Nat → Bool) : (valuation E).satisfies [.neg 1451, .pos 1478, .pos 1479] := by
  change (g1452 E = true) → (¬ (g1479 E = true)) → (¬ (g1480 E = true)) → False
  exact pattern_6 (g1452 E) (g1479 E)
private theorem sat_1042 (E : Nat → Bool) : (valuation E).satisfies [.neg 1471, .pos 406, .pos 1501] := by
  change (g1472 E = true) → (¬ (g407 E = true)) → (¬ (g1502 E = true)) → False
  exact pattern_3 (g407 E) (g1472 E)
private theorem sat_1043 (E : Nat → Bool) : (valuation E).satisfies [.neg 1502, .neg 1471] := by
  change (g1503 E = true) → (g1472 E = true) → False
  exact pattern_4 (g407 E) (g1472 E)
private theorem sat_1044 (E : Nat → Bool) : (valuation E).satisfies [.neg 1502, .pos 406] := by
  change (g1503 E = true) → (¬ (g407 E = true)) → False
  exact pattern_5 (g407 E) (g1472 E)
private theorem sat_1045 (E : Nat → Bool) : (valuation E).satisfies [.neg 1473, .pos 1502, .pos 1503] := by
  change (g1474 E = true) → (¬ (g1503 E = true)) → (¬ (g1504 E = true)) → False
  exact pattern_6 (g1474 E) (g1503 E)
private theorem sat_1046 (E : Nat → Bool) : (valuation E).satisfies [.neg 1504, .neg 1473] := by
  change (g1505 E = true) → (g1474 E = true) → False
  exact pattern_4 (g407 E) (g1474 E)
private theorem sat_1047 (E : Nat → Bool) : (valuation E).satisfies [.neg 1504, .pos 406] := by
  change (g1505 E = true) → (¬ (g407 E = true)) → False
  exact pattern_5 (g407 E) (g1474 E)
private theorem sat_1048 (E : Nat → Bool) : (valuation E).satisfies [.neg 1505, .pos 1475] := by
  change (g1506 E = true) → (¬ (g1476 E = true)) → False
  exact pattern_5 (g1476 E) (g1505 E)
private theorem sat_1049 (E : Nat → Bool) : (valuation E).satisfies [.neg 1475, .pos 1504, .pos 1505] := by
  change (g1476 E = true) → (¬ (g1505 E = true)) → (¬ (g1506 E = true)) → False
  exact pattern_6 (g1476 E) (g1505 E)
private theorem sat_1050 (E : Nat → Bool) : (valuation E).satisfies [.neg 1506, .neg 1475] := by
  change (g1507 E = true) → (g1476 E = true) → False
  exact pattern_4 (g407 E) (g1476 E)
private theorem sat_1051 (E : Nat → Bool) : (valuation E).satisfies [.neg 1506, .pos 406] := by
  change (g1507 E = true) → (¬ (g407 E = true)) → False
  exact pattern_5 (g407 E) (g1476 E)
private theorem sat_1052 (E : Nat → Bool) : (valuation E).satisfies [.neg 1507, .pos 1477] := by
  change (g1508 E = true) → (¬ (g1478 E = true)) → False
  exact pattern_5 (g1478 E) (g1507 E)
private theorem sat_1053 (E : Nat → Bool) : (valuation E).satisfies [.neg 1477, .pos 1506, .pos 1507] := by
  change (g1478 E = true) → (¬ (g1507 E = true)) → (¬ (g1508 E = true)) → False
  exact pattern_6 (g1478 E) (g1507 E)
private theorem sat_1054 (E : Nat → Bool) : (valuation E).satisfies [.neg 1508, .pos 406] := by
  change (g1509 E = true) → (¬ (g407 E = true)) → False
  exact pattern_5 (g407 E) (g1478 E)
private theorem sat_1055 (E : Nat → Bool) : (valuation E).satisfies [.neg 1509, .pos 1479] := by
  change (g1510 E = true) → (¬ (g1480 E = true)) → False
  exact pattern_5 (g1480 E) (g1509 E)
private theorem sat_1056 (E : Nat → Bool) : (valuation E).satisfies [.neg 1479, .pos 1508, .pos 1509] := by
  change (g1480 E = true) → (¬ (g1509 E = true)) → (¬ (g1510 E = true)) → False
  exact pattern_6 (g1480 E) (g1509 E)
private theorem sat_1057 (E : Nat → Bool) : (valuation E).satisfies [.neg 1501, .pos 407, .pos 1533] := by
  change (g1502 E = true) → (¬ (g408 E = true)) → (¬ (g1534 E = true)) → False
  exact pattern_3 (g408 E) (g1502 E)
private theorem sat_1058 (E : Nat → Bool) : (valuation E).satisfies [.neg 1534, .pos 407] := by
  change (g1535 E = true) → (¬ (g408 E = true)) → False
  exact pattern_5 (g408 E) (g1502 E)
private theorem sat_1059 (E : Nat → Bool) : (valuation E).satisfies [.neg 1503, .pos 1534, .pos 1535] := by
  change (g1504 E = true) → (¬ (g1535 E = true)) → (¬ (g1536 E = true)) → False
  exact pattern_6 (g1504 E) (g1535 E)
private theorem sat_1060 (E : Nat → Bool) : (valuation E).satisfies [.neg 1536, .neg 1503] := by
  change (g1537 E = true) → (g1504 E = true) → False
  exact pattern_4 (g408 E) (g1504 E)
private theorem sat_1061 (E : Nat → Bool) : (valuation E).satisfies [.neg 1536, .pos 407] := by
  change (g1537 E = true) → (¬ (g408 E = true)) → False
  exact pattern_5 (g408 E) (g1504 E)
private theorem sat_1062 (E : Nat → Bool) : (valuation E).satisfies [.neg 1537, .pos 1505] := by
  change (g1538 E = true) → (¬ (g1506 E = true)) → False
  exact pattern_5 (g1506 E) (g1537 E)
private theorem sat_1063 (E : Nat → Bool) : (valuation E).satisfies [.neg 1505, .pos 1536, .pos 1537] := by
  change (g1506 E = true) → (¬ (g1537 E = true)) → (¬ (g1538 E = true)) → False
  exact pattern_6 (g1506 E) (g1537 E)
private theorem sat_1064 (E : Nat → Bool) : (valuation E).satisfies [.neg 1538, .neg 1505] := by
  change (g1539 E = true) → (g1506 E = true) → False
  exact pattern_4 (g408 E) (g1506 E)
private theorem sat_1065 (E : Nat → Bool) : (valuation E).satisfies [.neg 1538, .pos 407] := by
  change (g1539 E = true) → (¬ (g408 E = true)) → False
  exact pattern_5 (g408 E) (g1506 E)
private theorem sat_1066 (E : Nat → Bool) : (valuation E).satisfies [.neg 1539, .neg 1538] := by
  change (g1540 E = true) → (g1539 E = true) → False
  exact pattern_4 (g1508 E) (g1539 E)
private theorem sat_1067 (E : Nat → Bool) : (valuation E).satisfies [.neg 1539, .pos 1507] := by
  change (g1540 E = true) → (¬ (g1508 E = true)) → False
  exact pattern_5 (g1508 E) (g1539 E)
private theorem sat_1068 (E : Nat → Bool) : (valuation E).satisfies [.neg 1507, .pos 1538, .pos 1539] := by
  change (g1508 E = true) → (¬ (g1539 E = true)) → (¬ (g1540 E = true)) → False
  exact pattern_6 (g1508 E) (g1539 E)
private theorem sat_1069 (E : Nat → Bool) : (valuation E).satisfies [.neg 1540, .pos 407] := by
  change (g1541 E = true) → (¬ (g408 E = true)) → False
  exact pattern_5 (g408 E) (g1508 E)
private theorem sat_1070 (E : Nat → Bool) : (valuation E).satisfies [.neg 1541, .pos 1509] := by
  change (g1542 E = true) → (¬ (g1510 E = true)) → False
  exact pattern_5 (g1510 E) (g1541 E)
private theorem sat_1071 (E : Nat → Bool) : (valuation E).satisfies [.neg 1509, .pos 1540, .pos 1541] := by
  change (g1510 E = true) → (¬ (g1541 E = true)) → (¬ (g1542 E = true)) → False
  exact pattern_6 (g1510 E) (g1541 E)
private theorem sat_1072 (E : Nat → Bool) : (valuation E).satisfies [.neg 1568, .neg 1533] := by
  change (g1569 E = true) → (g1534 E = true) → False
  exact pattern_4 (g409 E) (g1534 E)
private theorem sat_1073 (E : Nat → Bool) : (valuation E).satisfies [.neg 1568, .pos 408] := by
  change (g1569 E = true) → (¬ (g409 E = true)) → False
  exact pattern_5 (g409 E) (g1534 E)
private theorem sat_1074 (E : Nat → Bool) : (valuation E).satisfies [.neg 1535, .pos 1568, .pos 1569] := by
  change (g1536 E = true) → (¬ (g1569 E = true)) → (¬ (g1570 E = true)) → False
  exact pattern_6 (g1536 E) (g1569 E)
private theorem sat_1075 (E : Nat → Bool) : (valuation E).satisfies [.neg 1570, .neg 1535] := by
  change (g1571 E = true) → (g1536 E = true) → False
  exact pattern_4 (g409 E) (g1536 E)
private theorem sat_1076 (E : Nat → Bool) : (valuation E).satisfies [.neg 1570, .pos 408] := by
  change (g1571 E = true) → (¬ (g409 E = true)) → False
  exact pattern_5 (g409 E) (g1536 E)
private theorem sat_1077 (E : Nat → Bool) : (valuation E).satisfies [.neg 1571, .pos 1537] := by
  change (g1572 E = true) → (¬ (g1538 E = true)) → False
  exact pattern_5 (g1538 E) (g1571 E)
private theorem sat_1078 (E : Nat → Bool) : (valuation E).satisfies [.neg 1537, .pos 1570, .pos 1571] := by
  change (g1538 E = true) → (¬ (g1571 E = true)) → (¬ (g1572 E = true)) → False
  exact pattern_6 (g1538 E) (g1571 E)
private theorem sat_1079 (E : Nat → Bool) : (valuation E).satisfies [.neg 1572, .neg 1537] := by
  change (g1573 E = true) → (g1538 E = true) → False
  exact pattern_4 (g409 E) (g1538 E)
private theorem sat_1080 (E : Nat → Bool) : (valuation E).satisfies [.neg 1572, .pos 408] := by
  change (g1573 E = true) → (¬ (g409 E = true)) → False
  exact pattern_5 (g409 E) (g1538 E)
private theorem sat_1081 (E : Nat → Bool) : (valuation E).satisfies [.neg 408, .pos 1537, .pos 1572] := by
  change (g409 E = true) → (¬ (g1538 E = true)) → (¬ (g1573 E = true)) → False
  exact pattern_6 (g409 E) (g1538 E)
private theorem sat_1082 (E : Nat → Bool) : (valuation E).satisfies [.neg 1573, .neg 1572] := by
  change (g1574 E = true) → (g1573 E = true) → False
  exact pattern_4 (g1540 E) (g1573 E)
private theorem sat_1083 (E : Nat → Bool) : (valuation E).satisfies [.neg 1573, .pos 1539] := by
  change (g1574 E = true) → (¬ (g1540 E = true)) → False
  exact pattern_5 (g1540 E) (g1573 E)
private theorem sat_1084 (E : Nat → Bool) : (valuation E).satisfies [.neg 1539, .pos 1572, .pos 1573] := by
  change (g1540 E = true) → (¬ (g1573 E = true)) → (¬ (g1574 E = true)) → False
  exact pattern_6 (g1540 E) (g1573 E)
private theorem sat_1085 (E : Nat → Bool) : (valuation E).satisfies [.neg 1574, .neg 1539] := by
  change (g1575 E = true) → (g1540 E = true) → False
  exact pattern_4 (g409 E) (g1540 E)
private theorem sat_1086 (E : Nat → Bool) : (valuation E).satisfies [.neg 1575, .pos 1541] := by
  change (g1576 E = true) → (¬ (g1542 E = true)) → False
  exact pattern_5 (g1542 E) (g1575 E)
private theorem sat_1087 (E : Nat → Bool) : (valuation E).satisfies [.neg 1541, .pos 1574, .pos 1575] := by
  change (g1542 E = true) → (¬ (g1575 E = true)) → (¬ (g1576 E = true)) → False
  exact pattern_6 (g1542 E) (g1575 E)
private theorem sat_1088 (E : Nat → Bool) : (valuation E).satisfies [.neg 1606, .neg 1569] := by
  change (g1607 E = true) → (g1570 E = true) → False
  exact pattern_4 (g410 E) (g1570 E)
private theorem sat_1089 (E : Nat → Bool) : (valuation E).satisfies [.neg 1606, .pos 409] := by
  change (g1607 E = true) → (¬ (g410 E = true)) → False
  exact pattern_5 (g410 E) (g1570 E)
private theorem sat_1090 (E : Nat → Bool) : (valuation E).satisfies [.neg 1571, .pos 1606, .pos 1607] := by
  change (g1572 E = true) → (¬ (g1607 E = true)) → (¬ (g1608 E = true)) → False
  exact pattern_6 (g1572 E) (g1607 E)
private theorem sat_1091 (E : Nat → Bool) : (valuation E).satisfies [.neg 1608, .neg 1571] := by
  change (g1609 E = true) → (g1572 E = true) → False
  exact pattern_4 (g410 E) (g1572 E)
private theorem sat_1092 (E : Nat → Bool) : (valuation E).satisfies [.neg 1608, .pos 409] := by
  change (g1609 E = true) → (¬ (g410 E = true)) → False
  exact pattern_5 (g410 E) (g1572 E)
private theorem sat_1093 (E : Nat → Bool) : (valuation E).satisfies [.neg 409, .pos 1571, .pos 1608] := by
  change (g410 E = true) → (¬ (g1572 E = true)) → (¬ (g1609 E = true)) → False
  exact pattern_6 (g410 E) (g1572 E)
private theorem sat_1094 (E : Nat → Bool) : (valuation E).satisfies [.neg 1609, .neg 1608] := by
  change (g1610 E = true) → (g1609 E = true) → False
  exact pattern_4 (g1574 E) (g1609 E)
private theorem sat_1095 (E : Nat → Bool) : (valuation E).satisfies [.neg 1609, .pos 1573] := by
  change (g1610 E = true) → (¬ (g1574 E = true)) → False
  exact pattern_5 (g1574 E) (g1609 E)
private theorem sat_1096 (E : Nat → Bool) : (valuation E).satisfies [.neg 1573, .pos 1608, .pos 1609] := by
  change (g1574 E = true) → (¬ (g1609 E = true)) → (¬ (g1610 E = true)) → False
  exact pattern_6 (g1574 E) (g1609 E)
private theorem sat_1097 (E : Nat → Bool) : (valuation E).satisfies [.neg 1610, .neg 1573] := by
  change (g1611 E = true) → (g1574 E = true) → False
  exact pattern_4 (g410 E) (g1574 E)
private theorem sat_1098 (E : Nat → Bool) : (valuation E).satisfies [.neg 409, .pos 1573, .pos 1610] := by
  change (g410 E = true) → (¬ (g1574 E = true)) → (¬ (g1611 E = true)) → False
  exact pattern_6 (g410 E) (g1574 E)
private theorem sat_1099 (E : Nat → Bool) : (valuation E).satisfies [.neg 1611, .neg 1610] := by
  change (g1612 E = true) → (g1611 E = true) → False
  exact pattern_4 (g1576 E) (g1611 E)
private theorem sat_1100 (E : Nat → Bool) : (valuation E).satisfies [.neg 1611, .pos 1575] := by
  change (g1612 E = true) → (¬ (g1576 E = true)) → False
  exact pattern_5 (g1576 E) (g1611 E)
private theorem sat_1101 (E : Nat → Bool) : (valuation E).satisfies [.neg 1575, .pos 1610, .pos 1611] := by
  change (g1576 E = true) → (¬ (g1611 E = true)) → (¬ (g1612 E = true)) → False
  exact pattern_6 (g1576 E) (g1611 E)
private theorem sat_1102 (E : Nat → Bool) : (valuation E).satisfies [.neg 1646, .neg 1607] := by
  change (g1647 E = true) → (g1608 E = true) → False
  exact pattern_4 (g411 E) (g1608 E)
private theorem sat_1103 (E : Nat → Bool) : (valuation E).satisfies [.neg 1646, .pos 410] := by
  change (g1647 E = true) → (¬ (g411 E = true)) → False
  exact pattern_5 (g411 E) (g1608 E)
private theorem sat_1104 (E : Nat → Bool) : (valuation E).satisfies [.neg 1609, .pos 1646, .pos 1647] := by
  change (g1610 E = true) → (¬ (g1647 E = true)) → (¬ (g1648 E = true)) → False
  exact pattern_6 (g1610 E) (g1647 E)
private theorem sat_1105 (E : Nat → Bool) : (valuation E).satisfies [.neg 1648, .neg 1609] := by
  change (g1649 E = true) → (g1610 E = true) → False
  exact pattern_4 (g411 E) (g1610 E)
private theorem sat_1106 (E : Nat → Bool) : (valuation E).satisfies [.neg 410, .pos 1609, .pos 1648] := by
  change (g411 E = true) → (¬ (g1610 E = true)) → (¬ (g1649 E = true)) → False
  exact pattern_6 (g411 E) (g1610 E)
private theorem sat_1107 (E : Nat → Bool) : (valuation E).satisfies [.neg 1649, .neg 1648] := by
  change (g1650 E = true) → (g1649 E = true) → False
  exact pattern_4 (g1612 E) (g1649 E)
private theorem sat_1108 (E : Nat → Bool) : (valuation E).satisfies [.neg 1649, .pos 1611] := by
  change (g1650 E = true) → (¬ (g1612 E = true)) → False
  exact pattern_5 (g1612 E) (g1649 E)
private theorem sat_1109 (E : Nat → Bool) : (valuation E).satisfies [.neg 1611, .pos 1648, .pos 1649] := by
  change (g1612 E = true) → (¬ (g1649 E = true)) → (¬ (g1650 E = true)) → False
  exact pattern_6 (g1612 E) (g1649 E)
private theorem sat_1110 (E : Nat → Bool) : (valuation E).satisfies [.neg 410, .pos 1611, .pos 1650] := by
  change (g411 E = true) → (¬ (g1612 E = true)) → (¬ (g1651 E = true)) → False
  exact pattern_6 (g411 E) (g1612 E)
private theorem sat_1111 (E : Nat → Bool) : (valuation E).satisfies [.neg 1651, .neg 1650] := by
  change (g1652 E = true) → (g1651 E = true) → False
  exact pattern_4 (g1614 E) (g1651 E)
private theorem sat_1112 (E : Nat → Bool) : (valuation E).satisfies [.pos 366, .pos 371, .pos 1681] := by
  change (¬ (g367 E = true)) → (¬ (g372 E = true)) → (¬ (g1682 E = true)) → False
  exact pattern_0 (g367 E) (g372 E)
private theorem sat_1113 (E : Nat → Bool) : (valuation E).satisfies [.neg 1682, .pos 366] := by
  change (g1683 E = true) → (¬ (g367 E = true)) → False
  exact pattern_1 (g367 E) (g372 E)
private theorem sat_1114 (E : Nat → Bool) : (valuation E).satisfies [.neg 1682, .pos 371] := by
  change (g1683 E = true) → (¬ (g372 E = true)) → False
  exact pattern_2 (g367 E) (g372 E)
private theorem sat_1115 (E : Nat → Bool) : (valuation E).satisfies [.neg 1681, .pos 376, .pos 1683] := by
  change (g1682 E = true) → (¬ (g377 E = true)) → (¬ (g1684 E = true)) → False
  exact pattern_3 (g377 E) (g1682 E)
private theorem sat_1116 (E : Nat → Bool) : (valuation E).satisfies [.neg 1684, .neg 1681] := by
  change (g1685 E = true) → (g1682 E = true) → False
  exact pattern_4 (g377 E) (g1682 E)
private theorem sat_1117 (E : Nat → Bool) : (valuation E).satisfies [.neg 1684, .pos 376] := by
  change (g1685 E = true) → (¬ (g377 E = true)) → False
  exact pattern_5 (g377 E) (g1682 E)
private theorem sat_1118 (E : Nat → Bool) : (valuation E).satisfies [.neg 1685, .neg 1682] := by
  change (g1686 E = true) → (g1683 E = true) → False
  exact pattern_7 (g1683 E) (g1685 E)
private theorem sat_1119 (E : Nat → Bool) : (valuation E).satisfies [.pos 1682, .pos 1684, .pos 1685] := by
  change (¬ (g1683 E = true)) → (¬ (g1685 E = true)) → (¬ (g1686 E = true)) → False
  exact pattern_0 (g1683 E) (g1685 E)
private theorem sat_1120 (E : Nat → Bool) : (valuation E).satisfies [.neg 1686, .pos 376] := by
  change (g1687 E = true) → (¬ (g377 E = true)) → False
  exact pattern_1 (g377 E) (g1683 E)
private theorem sat_1121 (E : Nat → Bool) : (valuation E).satisfies [.neg 1686, .pos 1682] := by
  change (g1687 E = true) → (¬ (g1683 E = true)) → False
  exact pattern_2 (g377 E) (g1683 E)
private theorem sat_1122 (E : Nat → Bool) : (valuation E).satisfies [.neg 1683, .pos 377, .pos 1687] := by
  change (g1684 E = true) → (¬ (g378 E = true)) → (¬ (g1688 E = true)) → False
  exact pattern_3 (g378 E) (g1684 E)
private theorem sat_1123 (E : Nat → Bool) : (valuation E).satisfies [.neg 1688, .neg 1683] := by
  change (g1689 E = true) → (g1684 E = true) → False
  exact pattern_4 (g378 E) (g1684 E)
private theorem sat_1124 (E : Nat → Bool) : (valuation E).satisfies [.neg 1688, .pos 377] := by
  change (g1689 E = true) → (¬ (g378 E = true)) → False
  exact pattern_5 (g378 E) (g1684 E)
private theorem sat_1125 (E : Nat → Bool) : (valuation E).satisfies [.neg 1689, .pos 1685] := by
  change (g1690 E = true) → (¬ (g1686 E = true)) → False
  exact pattern_5 (g1686 E) (g1689 E)
private theorem sat_1126 (E : Nat → Bool) : (valuation E).satisfies [.neg 1685, .pos 1688, .pos 1689] := by
  change (g1686 E = true) → (¬ (g1689 E = true)) → (¬ (g1690 E = true)) → False
  exact pattern_6 (g1686 E) (g1689 E)
private theorem sat_1127 (E : Nat → Bool) : (valuation E).satisfies [.neg 1690, .neg 1685] := by
  change (g1691 E = true) → (g1686 E = true) → False
  exact pattern_4 (g378 E) (g1686 E)
private theorem sat_1128 (E : Nat → Bool) : (valuation E).satisfies [.neg 1690, .pos 377] := by
  change (g1691 E = true) → (¬ (g378 E = true)) → False
  exact pattern_5 (g378 E) (g1686 E)
private theorem sat_1129 (E : Nat → Bool) : (valuation E).satisfies [.neg 1691, .neg 1690] := by
  change (g1692 E = true) → (g1691 E = true) → False
  exact pattern_9 (g1687 E) (g1691 E)
private theorem sat_1130 (E : Nat → Bool) : (valuation E).satisfies [.pos 1686, .pos 1690, .pos 1691] := by
  change (¬ (g1687 E = true)) → (¬ (g1691 E = true)) → (¬ (g1692 E = true)) → False
  exact pattern_0 (g1687 E) (g1691 E)
private theorem sat_1131 (E : Nat → Bool) : (valuation E).satisfies [.neg 1692, .pos 377] := by
  change (g1693 E = true) → (¬ (g378 E = true)) → False
  exact pattern_1 (g378 E) (g1687 E)
private theorem sat_1132 (E : Nat → Bool) : (valuation E).satisfies [.neg 1692, .pos 1686] := by
  change (g1693 E = true) → (¬ (g1687 E = true)) → False
  exact pattern_2 (g378 E) (g1687 E)
private theorem sat_1133 (E : Nat → Bool) : (valuation E).satisfies [.neg 1687, .pos 378, .pos 1693] := by
  change (g1688 E = true) → (¬ (g379 E = true)) → (¬ (g1694 E = true)) → False
  exact pattern_3 (g379 E) (g1688 E)
private theorem sat_1134 (E : Nat → Bool) : (valuation E).satisfies [.neg 1694, .neg 1687] := by
  change (g1695 E = true) → (g1688 E = true) → False
  exact pattern_4 (g379 E) (g1688 E)
private theorem sat_1135 (E : Nat → Bool) : (valuation E).satisfies [.neg 1694, .pos 378] := by
  change (g1695 E = true) → (¬ (g379 E = true)) → False
  exact pattern_5 (g379 E) (g1688 E)
private theorem sat_1136 (E : Nat → Bool) : (valuation E).satisfies [.neg 1689, .pos 1694, .pos 1695] := by
  change (g1690 E = true) → (¬ (g1695 E = true)) → (¬ (g1696 E = true)) → False
  exact pattern_6 (g1690 E) (g1695 E)
private theorem sat_1137 (E : Nat → Bool) : (valuation E).satisfies [.neg 1696, .neg 1689] := by
  change (g1697 E = true) → (g1690 E = true) → False
  exact pattern_4 (g379 E) (g1690 E)
private theorem sat_1138 (E : Nat → Bool) : (valuation E).satisfies [.neg 1696, .pos 378] := by
  change (g1697 E = true) → (¬ (g379 E = true)) → False
  exact pattern_5 (g379 E) (g1690 E)
private theorem sat_1139 (E : Nat → Bool) : (valuation E).satisfies [.neg 378, .pos 1689, .pos 1696] := by
  change (g379 E = true) → (¬ (g1690 E = true)) → (¬ (g1697 E = true)) → False
  exact pattern_6 (g379 E) (g1690 E)
private theorem sat_1140 (E : Nat → Bool) : (valuation E).satisfies [.neg 1697, .neg 1696] := by
  change (g1698 E = true) → (g1697 E = true) → False
  exact pattern_4 (g1692 E) (g1697 E)
private theorem sat_1141 (E : Nat → Bool) : (valuation E).satisfies [.neg 1697, .pos 1691] := by
  change (g1698 E = true) → (¬ (g1692 E = true)) → False
  exact pattern_5 (g1692 E) (g1697 E)
private theorem sat_1142 (E : Nat → Bool) : (valuation E).satisfies [.neg 1691, .pos 1696, .pos 1697] := by
  change (g1692 E = true) → (¬ (g1697 E = true)) → (¬ (g1698 E = true)) → False
  exact pattern_6 (g1692 E) (g1697 E)
private theorem sat_1143 (E : Nat → Bool) : (valuation E).satisfies [.neg 1698, .neg 1691] := by
  change (g1699 E = true) → (g1692 E = true) → False
  exact pattern_4 (g379 E) (g1692 E)
private theorem sat_1144 (E : Nat → Bool) : (valuation E).satisfies [.neg 1698, .pos 378] := by
  change (g1699 E = true) → (¬ (g379 E = true)) → False
  exact pattern_5 (g379 E) (g1692 E)
private theorem sat_1145 (E : Nat → Bool) : (valuation E).satisfies [.neg 1699, .neg 1692] := by
  change (g1700 E = true) → (g1693 E = true) → False
  exact pattern_7 (g1693 E) (g1699 E)
private theorem sat_1146 (E : Nat → Bool) : (valuation E).satisfies [.pos 1692, .pos 1698, .pos 1699] := by
  change (¬ (g1693 E = true)) → (¬ (g1699 E = true)) → (¬ (g1700 E = true)) → False
  exact pattern_0 (g1693 E) (g1699 E)
private theorem sat_1147 (E : Nat → Bool) : (valuation E).satisfies [.neg 1700, .pos 378] := by
  change (g1701 E = true) → (¬ (g379 E = true)) → False
  exact pattern_1 (g379 E) (g1693 E)
private theorem sat_1148 (E : Nat → Bool) : (valuation E).satisfies [.neg 1700, .pos 1692] := by
  change (g1701 E = true) → (¬ (g1693 E = true)) → False
  exact pattern_2 (g379 E) (g1693 E)
private theorem sat_1149 (E : Nat → Bool) : (valuation E).satisfies [.neg 1693, .pos 379, .pos 1701] := by
  change (g1694 E = true) → (¬ (g380 E = true)) → (¬ (g1702 E = true)) → False
  exact pattern_3 (g380 E) (g1694 E)
private theorem sat_1150 (E : Nat → Bool) : (valuation E).satisfies [.neg 1702, .neg 1693] := by
  change (g1703 E = true) → (g1694 E = true) → False
  exact pattern_4 (g380 E) (g1694 E)
private theorem sat_1151 (E : Nat → Bool) : (valuation E).satisfies [.neg 1702, .pos 379] := by
  change (g1703 E = true) → (¬ (g380 E = true)) → False
  exact pattern_5 (g380 E) (g1694 E)
private theorem sat_1152 (E : Nat → Bool) : (valuation E).satisfies [.neg 1695, .pos 1702, .pos 1703] := by
  change (g1696 E = true) → (¬ (g1703 E = true)) → (¬ (g1704 E = true)) → False
  exact pattern_6 (g1696 E) (g1703 E)
private theorem sat_1153 (E : Nat → Bool) : (valuation E).satisfies [.neg 1704, .neg 1695] := by
  change (g1705 E = true) → (g1696 E = true) → False
  exact pattern_4 (g380 E) (g1696 E)
private theorem sat_1154 (E : Nat → Bool) : (valuation E).satisfies [.neg 1704, .pos 379] := by
  change (g1705 E = true) → (¬ (g380 E = true)) → False
  exact pattern_5 (g380 E) (g1696 E)
private theorem sat_1155 (E : Nat → Bool) : (valuation E).satisfies [.neg 1697, .pos 1704, .pos 1705] := by
  change (g1698 E = true) → (¬ (g1705 E = true)) → (¬ (g1706 E = true)) → False
  exact pattern_6 (g1698 E) (g1705 E)
private theorem sat_1156 (E : Nat → Bool) : (valuation E).satisfies [.neg 1706, .neg 1697] := by
  change (g1707 E = true) → (g1698 E = true) → False
  exact pattern_4 (g380 E) (g1698 E)
private theorem sat_1157 (E : Nat → Bool) : (valuation E).satisfies [.neg 1706, .pos 379] := by
  change (g1707 E = true) → (¬ (g380 E = true)) → False
  exact pattern_5 (g380 E) (g1698 E)
private theorem sat_1158 (E : Nat → Bool) : (valuation E).satisfies [.neg 1707, .pos 1699] := by
  change (g1708 E = true) → (¬ (g1700 E = true)) → False
  exact pattern_5 (g1700 E) (g1707 E)
private theorem sat_1159 (E : Nat → Bool) : (valuation E).satisfies [.neg 1699, .pos 1706, .pos 1707] := by
  change (g1700 E = true) → (¬ (g1707 E = true)) → (¬ (g1708 E = true)) → False
  exact pattern_6 (g1700 E) (g1707 E)
private theorem sat_1160 (E : Nat → Bool) : (valuation E).satisfies [.neg 1708, .neg 1699] := by
  change (g1709 E = true) → (g1700 E = true) → False
  exact pattern_4 (g380 E) (g1700 E)
private theorem sat_1161 (E : Nat → Bool) : (valuation E).satisfies [.neg 1708, .pos 379] := by
  change (g1709 E = true) → (¬ (g380 E = true)) → False
  exact pattern_5 (g380 E) (g1700 E)
private theorem sat_1162 (E : Nat → Bool) : (valuation E).satisfies [.pos 1700, .pos 1708, .pos 1709] := by
  change (¬ (g1701 E = true)) → (¬ (g1709 E = true)) → (¬ (g1710 E = true)) → False
  exact pattern_0 (g1701 E) (g1709 E)
private theorem sat_1163 (E : Nat → Bool) : (valuation E).satisfies [.neg 1710, .pos 379] := by
  change (g1711 E = true) → (¬ (g380 E = true)) → False
  exact pattern_1 (g380 E) (g1701 E)
private theorem sat_1164 (E : Nat → Bool) : (valuation E).satisfies [.neg 1710, .pos 1700] := by
  change (g1711 E = true) → (¬ (g1701 E = true)) → False
  exact pattern_2 (g380 E) (g1701 E)
private theorem sat_1165 (E : Nat → Bool) : (valuation E).satisfies [.neg 1701, .pos 386, .pos 1711] := by
  change (g1702 E = true) → (¬ (g387 E = true)) → (¬ (g1712 E = true)) → False
  exact pattern_3 (g387 E) (g1702 E)
private theorem sat_1166 (E : Nat → Bool) : (valuation E).satisfies [.neg 1712, .neg 1701] := by
  change (g1713 E = true) → (g1702 E = true) → False
  exact pattern_4 (g387 E) (g1702 E)
private theorem sat_1167 (E : Nat → Bool) : (valuation E).satisfies [.neg 1712, .pos 386] := by
  change (g1713 E = true) → (¬ (g387 E = true)) → False
  exact pattern_5 (g387 E) (g1702 E)
private theorem sat_1168 (E : Nat → Bool) : (valuation E).satisfies [.neg 1703, .pos 1712, .pos 1713] := by
  change (g1704 E = true) → (¬ (g1713 E = true)) → (¬ (g1714 E = true)) → False
  exact pattern_6 (g1704 E) (g1713 E)
private theorem sat_1169 (E : Nat → Bool) : (valuation E).satisfies [.neg 1714, .neg 1703] := by
  change (g1715 E = true) → (g1704 E = true) → False
  exact pattern_4 (g387 E) (g1704 E)
private theorem sat_1170 (E : Nat → Bool) : (valuation E).satisfies [.neg 1714, .pos 386] := by
  change (g1715 E = true) → (¬ (g387 E = true)) → False
  exact pattern_5 (g387 E) (g1704 E)
private theorem sat_1171 (E : Nat → Bool) : (valuation E).satisfies [.neg 1705, .pos 1714, .pos 1715] := by
  change (g1706 E = true) → (¬ (g1715 E = true)) → (¬ (g1716 E = true)) → False
  exact pattern_6 (g1706 E) (g1715 E)
private theorem sat_1172 (E : Nat → Bool) : (valuation E).satisfies [.neg 1716, .neg 1705] := by
  change (g1717 E = true) → (g1706 E = true) → False
  exact pattern_4 (g387 E) (g1706 E)
private theorem sat_1173 (E : Nat → Bool) : (valuation E).satisfies [.neg 1716, .pos 386] := by
  change (g1717 E = true) → (¬ (g387 E = true)) → False
  exact pattern_5 (g387 E) (g1706 E)
private theorem sat_1174 (E : Nat → Bool) : (valuation E).satisfies [.neg 1717, .pos 1707] := by
  change (g1718 E = true) → (¬ (g1708 E = true)) → False
  exact pattern_5 (g1708 E) (g1717 E)
private theorem sat_1175 (E : Nat → Bool) : (valuation E).satisfies [.neg 1707, .pos 1716, .pos 1717] := by
  change (g1708 E = true) → (¬ (g1717 E = true)) → (¬ (g1718 E = true)) → False
  exact pattern_6 (g1708 E) (g1717 E)
private theorem sat_1176 (E : Nat → Bool) : (valuation E).satisfies [.neg 1718, .neg 1707] := by
  change (g1719 E = true) → (g1708 E = true) → False
  exact pattern_4 (g387 E) (g1708 E)
private theorem sat_1177 (E : Nat → Bool) : (valuation E).satisfies [.neg 1718, .pos 386] := by
  change (g1719 E = true) → (¬ (g387 E = true)) → False
  exact pattern_5 (g387 E) (g1708 E)
private theorem sat_1178 (E : Nat → Bool) : (valuation E).satisfies [.neg 1709, .pos 1718, .pos 1719] := by
  change (g1710 E = true) → (¬ (g1719 E = true)) → (¬ (g1720 E = true)) → False
  exact pattern_6 (g1710 E) (g1719 E)
private theorem sat_1179 (E : Nat → Bool) : (valuation E).satisfies [.neg 1720, .neg 1709] := by
  change (g1721 E = true) → (g1710 E = true) → False
  exact pattern_4 (g387 E) (g1710 E)
private theorem sat_1180 (E : Nat → Bool) : (valuation E).satisfies [.neg 1720, .pos 386] := by
  change (g1721 E = true) → (¬ (g387 E = true)) → False
  exact pattern_5 (g387 E) (g1710 E)
private theorem sat_1181 (E : Nat → Bool) : (valuation E).satisfies [.pos 1710, .pos 1720, .pos 1721] := by
  change (¬ (g1711 E = true)) → (¬ (g1721 E = true)) → (¬ (g1722 E = true)) → False
  exact pattern_0 (g1711 E) (g1721 E)
private theorem sat_1182 (E : Nat → Bool) : (valuation E).satisfies [.neg 1722, .pos 1710] := by
  change (g1723 E = true) → (¬ (g1711 E = true)) → False
  exact pattern_2 (g387 E) (g1711 E)
private theorem sat_1183 (E : Nat → Bool) : (valuation E).satisfies [.neg 1711, .pos 391, .pos 1723] := by
  change (g1712 E = true) → (¬ (g392 E = true)) → (¬ (g1724 E = true)) → False
  exact pattern_3 (g392 E) (g1712 E)
private theorem sat_1184 (E : Nat → Bool) : (valuation E).satisfies [.neg 1724, .neg 1711] := by
  change (g1725 E = true) → (g1712 E = true) → False
  exact pattern_4 (g392 E) (g1712 E)
private theorem sat_1185 (E : Nat → Bool) : (valuation E).satisfies [.neg 1724, .pos 391] := by
  change (g1725 E = true) → (¬ (g392 E = true)) → False
  exact pattern_5 (g392 E) (g1712 E)
private theorem sat_1186 (E : Nat → Bool) : (valuation E).satisfies [.neg 1713, .pos 1724, .pos 1725] := by
  change (g1714 E = true) → (¬ (g1725 E = true)) → (¬ (g1726 E = true)) → False
  exact pattern_6 (g1714 E) (g1725 E)
private theorem sat_1187 (E : Nat → Bool) : (valuation E).satisfies [.neg 1726, .neg 1713] := by
  change (g1727 E = true) → (g1714 E = true) → False
  exact pattern_4 (g392 E) (g1714 E)
private theorem sat_1188 (E : Nat → Bool) : (valuation E).satisfies [.neg 1726, .pos 391] := by
  change (g1727 E = true) → (¬ (g392 E = true)) → False
  exact pattern_5 (g392 E) (g1714 E)
private theorem sat_1189 (E : Nat → Bool) : (valuation E).satisfies [.neg 1715, .pos 1726, .pos 1727] := by
  change (g1716 E = true) → (¬ (g1727 E = true)) → (¬ (g1728 E = true)) → False
  exact pattern_6 (g1716 E) (g1727 E)
private theorem sat_1190 (E : Nat → Bool) : (valuation E).satisfies [.neg 1728, .neg 1715] := by
  change (g1729 E = true) → (g1716 E = true) → False
  exact pattern_4 (g392 E) (g1716 E)
private theorem sat_1191 (E : Nat → Bool) : (valuation E).satisfies [.neg 1728, .pos 391] := by
  change (g1729 E = true) → (¬ (g392 E = true)) → False
  exact pattern_5 (g392 E) (g1716 E)
private theorem sat_1192 (E : Nat → Bool) : (valuation E).satisfies [.neg 1729, .pos 1717] := by
  change (g1730 E = true) → (¬ (g1718 E = true)) → False
  exact pattern_5 (g1718 E) (g1729 E)
private theorem sat_1193 (E : Nat → Bool) : (valuation E).satisfies [.neg 1717, .pos 1728, .pos 1729] := by
  change (g1718 E = true) → (¬ (g1729 E = true)) → (¬ (g1730 E = true)) → False
  exact pattern_6 (g1718 E) (g1729 E)
private theorem sat_1194 (E : Nat → Bool) : (valuation E).satisfies [.neg 1730, .neg 1717] := by
  change (g1731 E = true) → (g1718 E = true) → False
  exact pattern_4 (g392 E) (g1718 E)
private theorem sat_1195 (E : Nat → Bool) : (valuation E).satisfies [.neg 1730, .pos 391] := by
  change (g1731 E = true) → (¬ (g392 E = true)) → False
  exact pattern_5 (g392 E) (g1718 E)
private theorem sat_1196 (E : Nat → Bool) : (valuation E).satisfies [.neg 1719, .pos 1730, .pos 1731] := by
  change (g1720 E = true) → (¬ (g1731 E = true)) → (¬ (g1732 E = true)) → False
  exact pattern_6 (g1720 E) (g1731 E)
private theorem sat_1197 (E : Nat → Bool) : (valuation E).satisfies [.neg 1732, .neg 1719] := by
  change (g1733 E = true) → (g1720 E = true) → False
  exact pattern_4 (g392 E) (g1720 E)
private theorem sat_1198 (E : Nat → Bool) : (valuation E).satisfies [.neg 1732, .pos 391] := by
  change (g1733 E = true) → (¬ (g392 E = true)) → False
  exact pattern_5 (g392 E) (g1720 E)
private theorem sat_1199 (E : Nat → Bool) : (valuation E).satisfies [.neg 1721, .pos 1732, .pos 1733] := by
  change (g1722 E = true) → (¬ (g1733 E = true)) → (¬ (g1734 E = true)) → False
  exact pattern_6 (g1722 E) (g1733 E)
private theorem sat_1200 (E : Nat → Bool) : (valuation E).satisfies [.neg 1734, .neg 1721] := by
  change (g1735 E = true) → (g1722 E = true) → False
  exact pattern_4 (g392 E) (g1722 E)
private theorem sat_1201 (E : Nat → Bool) : (valuation E).satisfies [.neg 1734, .pos 391] := by
  change (g1735 E = true) → (¬ (g392 E = true)) → False
  exact pattern_5 (g392 E) (g1722 E)
private theorem sat_1202 (E : Nat → Bool) : (valuation E).satisfies [.pos 1722, .pos 1734, .pos 1735] := by
  change (¬ (g1723 E = true)) → (¬ (g1735 E = true)) → (¬ (g1736 E = true)) → False
  exact pattern_0 (g1723 E) (g1735 E)
private theorem sat_1203 (E : Nat → Bool) : (valuation E).satisfies [.neg 1736, .pos 1722] := by
  change (g1737 E = true) → (¬ (g1723 E = true)) → False
  exact pattern_2 (g392 E) (g1723 E)
private theorem sat_1204 (E : Nat → Bool) : (valuation E).satisfies [.neg 1723, .pos 392, .pos 1737] := by
  change (g1724 E = true) → (¬ (g393 E = true)) → (¬ (g1738 E = true)) → False
  exact pattern_3 (g393 E) (g1724 E)
private theorem sat_1205 (E : Nat → Bool) : (valuation E).satisfies [.neg 1738, .neg 1723] := by
  change (g1739 E = true) → (g1724 E = true) → False
  exact pattern_4 (g393 E) (g1724 E)
private theorem sat_1206 (E : Nat → Bool) : (valuation E).satisfies [.neg 1738, .pos 392] := by
  change (g1739 E = true) → (¬ (g393 E = true)) → False
  exact pattern_5 (g393 E) (g1724 E)
private theorem sat_1207 (E : Nat → Bool) : (valuation E).satisfies [.neg 1725, .pos 1738, .pos 1739] := by
  change (g1726 E = true) → (¬ (g1739 E = true)) → (¬ (g1740 E = true)) → False
  exact pattern_6 (g1726 E) (g1739 E)
private theorem sat_1208 (E : Nat → Bool) : (valuation E).satisfies [.neg 1740, .neg 1725] := by
  change (g1741 E = true) → (g1726 E = true) → False
  exact pattern_4 (g393 E) (g1726 E)
private theorem sat_1209 (E : Nat → Bool) : (valuation E).satisfies [.neg 1740, .pos 392] := by
  change (g1741 E = true) → (¬ (g393 E = true)) → False
  exact pattern_5 (g393 E) (g1726 E)
private theorem sat_1210 (E : Nat → Bool) : (valuation E).satisfies [.neg 1741, .neg 1740] := by
  change (g1742 E = true) → (g1741 E = true) → False
  exact pattern_4 (g1728 E) (g1741 E)
private theorem sat_1211 (E : Nat → Bool) : (valuation E).satisfies [.neg 1741, .pos 1727] := by
  change (g1742 E = true) → (¬ (g1728 E = true)) → False
  exact pattern_5 (g1728 E) (g1741 E)
private theorem sat_1212 (E : Nat → Bool) : (valuation E).satisfies [.neg 1727, .pos 1740, .pos 1741] := by
  change (g1728 E = true) → (¬ (g1741 E = true)) → (¬ (g1742 E = true)) → False
  exact pattern_6 (g1728 E) (g1741 E)
private theorem sat_1213 (E : Nat → Bool) : (valuation E).satisfies [.neg 1742, .neg 1727] := by
  change (g1743 E = true) → (g1728 E = true) → False
  exact pattern_4 (g393 E) (g1728 E)
private theorem sat_1214 (E : Nat → Bool) : (valuation E).satisfies [.neg 1742, .pos 392] := by
  change (g1743 E = true) → (¬ (g393 E = true)) → False
  exact pattern_5 (g393 E) (g1728 E)
private theorem sat_1215 (E : Nat → Bool) : (valuation E).satisfies [.neg 392, .pos 1727, .pos 1742] := by
  change (g393 E = true) → (¬ (g1728 E = true)) → (¬ (g1743 E = true)) → False
  exact pattern_6 (g393 E) (g1728 E)
private theorem sat_1216 (E : Nat → Bool) : (valuation E).satisfies [.neg 1743, .neg 1742] := by
  change (g1744 E = true) → (g1743 E = true) → False
  exact pattern_4 (g1730 E) (g1743 E)
private theorem sat_1217 (E : Nat → Bool) : (valuation E).satisfies [.neg 1743, .pos 1729] := by
  change (g1744 E = true) → (¬ (g1730 E = true)) → False
  exact pattern_5 (g1730 E) (g1743 E)
private theorem sat_1218 (E : Nat → Bool) : (valuation E).satisfies [.neg 1729, .pos 1742, .pos 1743] := by
  change (g1730 E = true) → (¬ (g1743 E = true)) → (¬ (g1744 E = true)) → False
  exact pattern_6 (g1730 E) (g1743 E)
private theorem sat_1219 (E : Nat → Bool) : (valuation E).satisfies [.neg 1744, .neg 1729] := by
  change (g1745 E = true) → (g1730 E = true) → False
  exact pattern_4 (g393 E) (g1730 E)
private theorem sat_1220 (E : Nat → Bool) : (valuation E).satisfies [.neg 1744, .pos 392] := by
  change (g1745 E = true) → (¬ (g393 E = true)) → False
  exact pattern_5 (g393 E) (g1730 E)
private theorem sat_1221 (E : Nat → Bool) : (valuation E).satisfies [.neg 1745, .neg 1744] := by
  change (g1746 E = true) → (g1745 E = true) → False
  exact pattern_4 (g1732 E) (g1745 E)
private theorem sat_1222 (E : Nat → Bool) : (valuation E).satisfies [.neg 1731, .pos 1744, .pos 1745] := by
  change (g1732 E = true) → (¬ (g1745 E = true)) → (¬ (g1746 E = true)) → False
  exact pattern_6 (g1732 E) (g1745 E)
private theorem sat_1223 (E : Nat → Bool) : (valuation E).satisfies [.neg 1746, .neg 1731] := by
  change (g1747 E = true) → (g1732 E = true) → False
  exact pattern_4 (g393 E) (g1732 E)
private theorem sat_1224 (E : Nat → Bool) : (valuation E).satisfies [.neg 1746, .pos 392] := by
  change (g1747 E = true) → (¬ (g393 E = true)) → False
  exact pattern_5 (g393 E) (g1732 E)
private theorem sat_1225 (E : Nat → Bool) : (valuation E).satisfies [.neg 1733, .pos 1746, .pos 1747] := by
  change (g1734 E = true) → (¬ (g1747 E = true)) → (¬ (g1748 E = true)) → False
  exact pattern_6 (g1734 E) (g1747 E)
private theorem sat_1226 (E : Nat → Bool) : (valuation E).satisfies [.neg 1748, .neg 1733] := by
  change (g1749 E = true) → (g1734 E = true) → False
  exact pattern_4 (g393 E) (g1734 E)
private theorem sat_1227 (E : Nat → Bool) : (valuation E).satisfies [.neg 1748, .pos 392] := by
  change (g1749 E = true) → (¬ (g393 E = true)) → False
  exact pattern_5 (g393 E) (g1734 E)
private theorem sat_1228 (E : Nat → Bool) : (valuation E).satisfies [.neg 1735, .pos 1748, .pos 1749] := by
  change (g1736 E = true) → (¬ (g1749 E = true)) → (¬ (g1750 E = true)) → False
  exact pattern_6 (g1736 E) (g1749 E)
private theorem sat_1229 (E : Nat → Bool) : (valuation E).satisfies [.neg 1750, .pos 392] := by
  change (g1751 E = true) → (¬ (g393 E = true)) → False
  exact pattern_5 (g393 E) (g1736 E)
private theorem sat_1230 (E : Nat → Bool) : (valuation E).satisfies [.pos 1736, .pos 1750, .pos 1751] := by
  change (¬ (g1737 E = true)) → (¬ (g1751 E = true)) → (¬ (g1752 E = true)) → False
  exact pattern_0 (g1737 E) (g1751 E)
private theorem sat_1231 (E : Nat → Bool) : (valuation E).satisfies [.neg 1737, .pos 393, .pos 1753] := by
  change (g1738 E = true) → (¬ (g394 E = true)) → (¬ (g1754 E = true)) → False
  exact pattern_3 (g394 E) (g1738 E)
private theorem sat_1232 (E : Nat → Bool) : (valuation E).satisfies [.neg 1754, .neg 1737] := by
  change (g1755 E = true) → (g1738 E = true) → False
  exact pattern_4 (g394 E) (g1738 E)
private theorem sat_1233 (E : Nat → Bool) : (valuation E).satisfies [.neg 1754, .pos 393] := by
  change (g1755 E = true) → (¬ (g394 E = true)) → False
  exact pattern_5 (g394 E) (g1738 E)
private theorem sat_1234 (E : Nat → Bool) : (valuation E).satisfies [.neg 1739, .pos 1754, .pos 1755] := by
  change (g1740 E = true) → (¬ (g1755 E = true)) → (¬ (g1756 E = true)) → False
  exact pattern_6 (g1740 E) (g1755 E)
private theorem sat_1235 (E : Nat → Bool) : (valuation E).satisfies [.neg 1756, .neg 1739] := by
  change (g1757 E = true) → (g1740 E = true) → False
  exact pattern_4 (g394 E) (g1740 E)
private theorem sat_1236 (E : Nat → Bool) : (valuation E).satisfies [.neg 1756, .pos 393] := by
  change (g1757 E = true) → (¬ (g394 E = true)) → False
  exact pattern_5 (g394 E) (g1740 E)
private theorem sat_1237 (E : Nat → Bool) : (valuation E).satisfies [.neg 1757, .pos 1741] := by
  change (g1758 E = true) → (¬ (g1742 E = true)) → False
  exact pattern_5 (g1742 E) (g1757 E)
private theorem sat_1238 (E : Nat → Bool) : (valuation E).satisfies [.neg 1741, .pos 1756, .pos 1757] := by
  change (g1742 E = true) → (¬ (g1757 E = true)) → (¬ (g1758 E = true)) → False
  exact pattern_6 (g1742 E) (g1757 E)
private theorem sat_1239 (E : Nat → Bool) : (valuation E).satisfies [.neg 1758, .neg 1741] := by
  change (g1759 E = true) → (g1742 E = true) → False
  exact pattern_4 (g394 E) (g1742 E)
private theorem sat_1240 (E : Nat → Bool) : (valuation E).satisfies [.neg 1758, .pos 393] := by
  change (g1759 E = true) → (¬ (g394 E = true)) → False
  exact pattern_5 (g394 E) (g1742 E)
private theorem sat_1241 (E : Nat → Bool) : (valuation E).satisfies [.neg 1759, .pos 1743] := by
  change (g1760 E = true) → (¬ (g1744 E = true)) → False
  exact pattern_5 (g1744 E) (g1759 E)
private theorem sat_1242 (E : Nat → Bool) : (valuation E).satisfies [.neg 1743, .pos 1758, .pos 1759] := by
  change (g1744 E = true) → (¬ (g1759 E = true)) → (¬ (g1760 E = true)) → False
  exact pattern_6 (g1744 E) (g1759 E)
private theorem sat_1243 (E : Nat → Bool) : (valuation E).satisfies [.neg 1760, .neg 1743] := by
  change (g1761 E = true) → (g1744 E = true) → False
  exact pattern_4 (g394 E) (g1744 E)
private theorem sat_1244 (E : Nat → Bool) : (valuation E).satisfies [.neg 1760, .pos 393] := by
  change (g1761 E = true) → (¬ (g394 E = true)) → False
  exact pattern_5 (g394 E) (g1744 E)
private theorem sat_1245 (E : Nat → Bool) : (valuation E).satisfies [.neg 393, .pos 1743, .pos 1760] := by
  change (g394 E = true) → (¬ (g1744 E = true)) → (¬ (g1761 E = true)) → False
  exact pattern_6 (g394 E) (g1744 E)
private theorem sat_1246 (E : Nat → Bool) : (valuation E).satisfies [.neg 1761, .neg 1760] := by
  change (g1762 E = true) → (g1761 E = true) → False
  exact pattern_4 (g1746 E) (g1761 E)
private theorem sat_1247 (E : Nat → Bool) : (valuation E).satisfies [.neg 1761, .pos 1745] := by
  change (g1762 E = true) → (¬ (g1746 E = true)) → False
  exact pattern_5 (g1746 E) (g1761 E)
private theorem sat_1248 (E : Nat → Bool) : (valuation E).satisfies [.neg 1745, .pos 1760, .pos 1761] := by
  change (g1746 E = true) → (¬ (g1761 E = true)) → (¬ (g1762 E = true)) → False
  exact pattern_6 (g1746 E) (g1761 E)
private theorem sat_1249 (E : Nat → Bool) : (valuation E).satisfies [.neg 1762, .neg 1745] := by
  change (g1763 E = true) → (g1746 E = true) → False
  exact pattern_4 (g394 E) (g1746 E)
private theorem sat_1250 (E : Nat → Bool) : (valuation E).satisfies [.neg 1762, .pos 393] := by
  change (g1763 E = true) → (¬ (g394 E = true)) → False
  exact pattern_5 (g394 E) (g1746 E)
private theorem sat_1251 (E : Nat → Bool) : (valuation E).satisfies [.neg 1747, .pos 1762, .pos 1763] := by
  change (g1748 E = true) → (¬ (g1763 E = true)) → (¬ (g1764 E = true)) → False
  exact pattern_6 (g1748 E) (g1763 E)
private theorem sat_1252 (E : Nat → Bool) : (valuation E).satisfies [.neg 1764, .neg 1747] := by
  change (g1765 E = true) → (g1748 E = true) → False
  exact pattern_4 (g394 E) (g1748 E)
private theorem sat_1253 (E : Nat → Bool) : (valuation E).satisfies [.neg 1764, .pos 393] := by
  change (g1765 E = true) → (¬ (g394 E = true)) → False
  exact pattern_5 (g394 E) (g1748 E)
private theorem sat_1254 (E : Nat → Bool) : (valuation E).satisfies [.neg 1749, .pos 1764, .pos 1765] := by
  change (g1750 E = true) → (¬ (g1765 E = true)) → (¬ (g1766 E = true)) → False
  exact pattern_6 (g1750 E) (g1765 E)
private theorem sat_1255 (E : Nat → Bool) : (valuation E).satisfies [.neg 1766, .pos 393] := by
  change (g1767 E = true) → (¬ (g394 E = true)) → False
  exact pattern_5 (g394 E) (g1750 E)
private theorem sat_1256 (E : Nat → Bool) : (valuation E).satisfies [.neg 1751, .pos 1766, .pos 1767] := by
  change (g1752 E = true) → (¬ (g1767 E = true)) → (¬ (g1768 E = true)) → False
  exact pattern_6 (g1752 E) (g1767 E)
private theorem sat_1257 (E : Nat → Bool) : (valuation E).satisfies [.neg 1753, .pos 394, .pos 1771] := by
  change (g1754 E = true) → (¬ (g395 E = true)) → (¬ (g1772 E = true)) → False
  exact pattern_3 (g395 E) (g1754 E)
private theorem sat_1258 (E : Nat → Bool) : (valuation E).satisfies [.neg 1772, .neg 1753] := by
  change (g1773 E = true) → (g1754 E = true) → False
  exact pattern_4 (g395 E) (g1754 E)
private theorem sat_1259 (E : Nat → Bool) : (valuation E).satisfies [.neg 1772, .pos 394] := by
  change (g1773 E = true) → (¬ (g395 E = true)) → False
  exact pattern_5 (g395 E) (g1754 E)
private theorem sat_1260 (E : Nat → Bool) : (valuation E).satisfies [.neg 1755, .pos 1772, .pos 1773] := by
  change (g1756 E = true) → (¬ (g1773 E = true)) → (¬ (g1774 E = true)) → False
  exact pattern_6 (g1756 E) (g1773 E)
private theorem sat_1261 (E : Nat → Bool) : (valuation E).satisfies [.neg 1774, .neg 1755] := by
  change (g1775 E = true) → (g1756 E = true) → False
  exact pattern_4 (g395 E) (g1756 E)
private theorem sat_1262 (E : Nat → Bool) : (valuation E).satisfies [.neg 1774, .pos 394] := by
  change (g1775 E = true) → (¬ (g395 E = true)) → False
  exact pattern_5 (g395 E) (g1756 E)
private theorem sat_1263 (E : Nat → Bool) : (valuation E).satisfies [.neg 1775, .neg 1774] := by
  change (g1776 E = true) → (g1775 E = true) → False
  exact pattern_4 (g1758 E) (g1775 E)
private theorem sat_1264 (E : Nat → Bool) : (valuation E).satisfies [.neg 1775, .pos 1757] := by
  change (g1776 E = true) → (¬ (g1758 E = true)) → False
  exact pattern_5 (g1758 E) (g1775 E)
private theorem sat_1265 (E : Nat → Bool) : (valuation E).satisfies [.neg 1757, .pos 1774, .pos 1775] := by
  change (g1758 E = true) → (¬ (g1775 E = true)) → (¬ (g1776 E = true)) → False
  exact pattern_6 (g1758 E) (g1775 E)
private theorem sat_1266 (E : Nat → Bool) : (valuation E).satisfies [.neg 1776, .neg 1757] := by
  change (g1777 E = true) → (g1758 E = true) → False
  exact pattern_4 (g395 E) (g1758 E)
private theorem sat_1267 (E : Nat → Bool) : (valuation E).satisfies [.neg 1776, .pos 394] := by
  change (g1777 E = true) → (¬ (g395 E = true)) → False
  exact pattern_5 (g395 E) (g1758 E)
private theorem sat_1268 (E : Nat → Bool) : (valuation E).satisfies [.neg 1777, .pos 1759] := by
  change (g1778 E = true) → (¬ (g1760 E = true)) → False
  exact pattern_5 (g1760 E) (g1777 E)
private theorem sat_1269 (E : Nat → Bool) : (valuation E).satisfies [.neg 1759, .pos 1776, .pos 1777] := by
  change (g1760 E = true) → (¬ (g1777 E = true)) → (¬ (g1778 E = true)) → False
  exact pattern_6 (g1760 E) (g1777 E)
private theorem sat_1270 (E : Nat → Bool) : (valuation E).satisfies [.neg 1778, .neg 1759] := by
  change (g1779 E = true) → (g1760 E = true) → False
  exact pattern_4 (g395 E) (g1760 E)
private theorem sat_1271 (E : Nat → Bool) : (valuation E).satisfies [.neg 1778, .pos 394] := by
  change (g1779 E = true) → (¬ (g395 E = true)) → False
  exact pattern_5 (g395 E) (g1760 E)
private theorem sat_1272 (E : Nat → Bool) : (valuation E).satisfies [.neg 1779, .pos 1761] := by
  change (g1780 E = true) → (¬ (g1762 E = true)) → False
  exact pattern_5 (g1762 E) (g1779 E)
private theorem sat_1273 (E : Nat → Bool) : (valuation E).satisfies [.neg 1761, .pos 1778, .pos 1779] := by
  change (g1762 E = true) → (¬ (g1779 E = true)) → (¬ (g1780 E = true)) → False
  exact pattern_6 (g1762 E) (g1779 E)
private theorem sat_1274 (E : Nat → Bool) : (valuation E).satisfies [.neg 1780, .neg 1761] := by
  change (g1781 E = true) → (g1762 E = true) → False
  exact pattern_4 (g395 E) (g1762 E)
private theorem sat_1275 (E : Nat → Bool) : (valuation E).satisfies [.neg 1780, .pos 394] := by
  change (g1781 E = true) → (¬ (g395 E = true)) → False
  exact pattern_5 (g395 E) (g1762 E)
private theorem sat_1276 (E : Nat → Bool) : (valuation E).satisfies [.neg 1763, .pos 1780, .pos 1781] := by
  change (g1764 E = true) → (¬ (g1781 E = true)) → (¬ (g1782 E = true)) → False
  exact pattern_6 (g1764 E) (g1781 E)
private theorem sat_1277 (E : Nat → Bool) : (valuation E).satisfies [.neg 1782, .neg 1763] := by
  change (g1783 E = true) → (g1764 E = true) → False
  exact pattern_4 (g395 E) (g1764 E)
private theorem sat_1278 (E : Nat → Bool) : (valuation E).satisfies [.neg 1782, .pos 394] := by
  change (g1783 E = true) → (¬ (g395 E = true)) → False
  exact pattern_5 (g395 E) (g1764 E)
private theorem sat_1279 (E : Nat → Bool) : (valuation E).satisfies [.neg 1765, .pos 1782, .pos 1783] := by
  change (g1766 E = true) → (¬ (g1783 E = true)) → (¬ (g1784 E = true)) → False
  exact pattern_6 (g1766 E) (g1783 E)
private theorem sat_1280 (E : Nat → Bool) : (valuation E).satisfies [.neg 1784, .pos 394] := by
  change (g1785 E = true) → (¬ (g395 E = true)) → False
  exact pattern_5 (g395 E) (g1766 E)
private theorem sat_1281 (E : Nat → Bool) : (valuation E).satisfies [.neg 1767, .pos 1784, .pos 1785] := by
  change (g1768 E = true) → (¬ (g1785 E = true)) → (¬ (g1786 E = true)) → False
  exact pattern_6 (g1768 E) (g1785 E)
private theorem sat_1282 (E : Nat → Bool) : (valuation E).satisfies [.neg 1771, .pos 401, .pos 1791] := by
  change (g1772 E = true) → (¬ (g402 E = true)) → (¬ (g1792 E = true)) → False
  exact pattern_3 (g402 E) (g1772 E)
private theorem sat_1283 (E : Nat → Bool) : (valuation E).satisfies [.neg 1792, .neg 1771] := by
  change (g1793 E = true) → (g1772 E = true) → False
  exact pattern_4 (g402 E) (g1772 E)
private theorem sat_1284 (E : Nat → Bool) : (valuation E).satisfies [.neg 1792, .pos 401] := by
  change (g1793 E = true) → (¬ (g402 E = true)) → False
  exact pattern_5 (g402 E) (g1772 E)
private theorem sat_1285 (E : Nat → Bool) : (valuation E).satisfies [.neg 1773, .pos 1792, .pos 1793] := by
  change (g1774 E = true) → (¬ (g1793 E = true)) → (¬ (g1794 E = true)) → False
  exact pattern_6 (g1774 E) (g1793 E)
private theorem sat_1286 (E : Nat → Bool) : (valuation E).satisfies [.neg 1794, .neg 1773] := by
  change (g1795 E = true) → (g1774 E = true) → False
  exact pattern_4 (g402 E) (g1774 E)
private theorem sat_1287 (E : Nat → Bool) : (valuation E).satisfies [.neg 1794, .pos 401] := by
  change (g1795 E = true) → (¬ (g402 E = true)) → False
  exact pattern_5 (g402 E) (g1774 E)
private theorem sat_1288 (E : Nat → Bool) : (valuation E).satisfies [.neg 1775, .pos 1794, .pos 1795] := by
  change (g1776 E = true) → (¬ (g1795 E = true)) → (¬ (g1796 E = true)) → False
  exact pattern_6 (g1776 E) (g1795 E)
private theorem sat_1289 (E : Nat → Bool) : (valuation E).satisfies [.neg 1796, .neg 1775] := by
  change (g1797 E = true) → (g1776 E = true) → False
  exact pattern_4 (g402 E) (g1776 E)
private theorem sat_1290 (E : Nat → Bool) : (valuation E).satisfies [.neg 1796, .pos 401] := by
  change (g1797 E = true) → (¬ (g402 E = true)) → False
  exact pattern_5 (g402 E) (g1776 E)
private theorem sat_1291 (E : Nat → Bool) : (valuation E).satisfies [.neg 401, .pos 1775, .pos 1796] := by
  change (g402 E = true) → (¬ (g1776 E = true)) → (¬ (g1797 E = true)) → False
  exact pattern_6 (g402 E) (g1776 E)
private theorem sat_1292 (E : Nat → Bool) : (valuation E).satisfies [.neg 1797, .neg 1796] := by
  change (g1798 E = true) → (g1797 E = true) → False
  exact pattern_4 (g1778 E) (g1797 E)
private theorem sat_1293 (E : Nat → Bool) : (valuation E).satisfies [.neg 1797, .pos 1777] := by
  change (g1798 E = true) → (¬ (g1778 E = true)) → False
  exact pattern_5 (g1778 E) (g1797 E)
private theorem sat_1294 (E : Nat → Bool) : (valuation E).satisfies [.neg 1777, .pos 1796, .pos 1797] := by
  change (g1778 E = true) → (¬ (g1797 E = true)) → (¬ (g1798 E = true)) → False
  exact pattern_6 (g1778 E) (g1797 E)
private theorem sat_1295 (E : Nat → Bool) : (valuation E).satisfies [.neg 1798, .neg 1777] := by
  change (g1799 E = true) → (g1778 E = true) → False
  exact pattern_4 (g402 E) (g1778 E)
private theorem sat_1296 (E : Nat → Bool) : (valuation E).satisfies [.neg 1798, .pos 401] := by
  change (g1799 E = true) → (¬ (g402 E = true)) → False
  exact pattern_5 (g402 E) (g1778 E)
private theorem sat_1297 (E : Nat → Bool) : (valuation E).satisfies [.neg 1799, .pos 1779] := by
  change (g1800 E = true) → (¬ (g1780 E = true)) → False
  exact pattern_5 (g1780 E) (g1799 E)
private theorem sat_1298 (E : Nat → Bool) : (valuation E).satisfies [.neg 1779, .pos 1798, .pos 1799] := by
  change (g1780 E = true) → (¬ (g1799 E = true)) → (¬ (g1800 E = true)) → False
  exact pattern_6 (g1780 E) (g1799 E)
private theorem sat_1299 (E : Nat → Bool) : (valuation E).satisfies [.neg 1800, .neg 1779] := by
  change (g1801 E = true) → (g1780 E = true) → False
  exact pattern_4 (g402 E) (g1780 E)
private theorem sat_1300 (E : Nat → Bool) : (valuation E).satisfies [.neg 1800, .pos 401] := by
  change (g1801 E = true) → (¬ (g402 E = true)) → False
  exact pattern_5 (g402 E) (g1780 E)
private theorem sat_1301 (E : Nat → Bool) : (valuation E).satisfies [.neg 1781, .pos 1800, .pos 1801] := by
  change (g1782 E = true) → (¬ (g1801 E = true)) → (¬ (g1802 E = true)) → False
  exact pattern_6 (g1782 E) (g1801 E)
private theorem sat_1302 (E : Nat → Bool) : (valuation E).satisfies [.neg 1802, .neg 1781] := by
  change (g1803 E = true) → (g1782 E = true) → False
  exact pattern_4 (g402 E) (g1782 E)
private theorem sat_1303 (E : Nat → Bool) : (valuation E).satisfies [.neg 1802, .pos 401] := by
  change (g1803 E = true) → (¬ (g402 E = true)) → False
  exact pattern_5 (g402 E) (g1782 E)
private theorem sat_1304 (E : Nat → Bool) : (valuation E).satisfies [.neg 1783, .pos 1802, .pos 1803] := by
  change (g1784 E = true) → (¬ (g1803 E = true)) → (¬ (g1804 E = true)) → False
  exact pattern_6 (g1784 E) (g1803 E)
private theorem sat_1305 (E : Nat → Bool) : (valuation E).satisfies [.neg 1804, .pos 401] := by
  change (g1805 E = true) → (¬ (g402 E = true)) → False
  exact pattern_5 (g402 E) (g1784 E)
private theorem sat_1306 (E : Nat → Bool) : (valuation E).satisfies [.neg 1785, .pos 1804, .pos 1805] := by
  change (g1786 E = true) → (¬ (g1805 E = true)) → (¬ (g1806 E = true)) → False
  exact pattern_6 (g1786 E) (g1805 E)
private theorem sat_1307 (E : Nat → Bool) : (valuation E).satisfies [.neg 1791, .pos 402, .pos 1813] := by
  change (g1792 E = true) → (¬ (g403 E = true)) → (¬ (g1814 E = true)) → False
  exact pattern_3 (g403 E) (g1792 E)
private theorem sat_1308 (E : Nat → Bool) : (valuation E).satisfies [.neg 1814, .neg 1791] := by
  change (g1815 E = true) → (g1792 E = true) → False
  exact pattern_4 (g403 E) (g1792 E)
private theorem sat_1309 (E : Nat → Bool) : (valuation E).satisfies [.neg 1814, .pos 402] := by
  change (g1815 E = true) → (¬ (g403 E = true)) → False
  exact pattern_5 (g403 E) (g1792 E)
private theorem sat_1310 (E : Nat → Bool) : (valuation E).satisfies [.neg 1793, .pos 1814, .pos 1815] := by
  change (g1794 E = true) → (¬ (g1815 E = true)) → (¬ (g1816 E = true)) → False
  exact pattern_6 (g1794 E) (g1815 E)
private theorem sat_1311 (E : Nat → Bool) : (valuation E).satisfies [.neg 1816, .neg 1793] := by
  change (g1817 E = true) → (g1794 E = true) → False
  exact pattern_4 (g403 E) (g1794 E)
private theorem sat_1312 (E : Nat → Bool) : (valuation E).satisfies [.neg 1816, .pos 402] := by
  change (g1817 E = true) → (¬ (g403 E = true)) → False
  exact pattern_5 (g403 E) (g1794 E)
private theorem sat_1313 (E : Nat → Bool) : (valuation E).satisfies [.neg 1795, .pos 1816, .pos 1817] := by
  change (g1796 E = true) → (¬ (g1817 E = true)) → (¬ (g1818 E = true)) → False
  exact pattern_6 (g1796 E) (g1817 E)
private theorem sat_1314 (E : Nat → Bool) : (valuation E).satisfies [.neg 1818, .neg 1795] := by
  change (g1819 E = true) → (g1796 E = true) → False
  exact pattern_4 (g403 E) (g1796 E)
private theorem sat_1315 (E : Nat → Bool) : (valuation E).satisfies [.neg 1818, .pos 402] := by
  change (g1819 E = true) → (¬ (g403 E = true)) → False
  exact pattern_5 (g403 E) (g1796 E)
private theorem sat_1316 (E : Nat → Bool) : (valuation E).satisfies [.neg 1819, .pos 1797] := by
  change (g1820 E = true) → (¬ (g1798 E = true)) → False
  exact pattern_5 (g1798 E) (g1819 E)
private theorem sat_1317 (E : Nat → Bool) : (valuation E).satisfies [.neg 1797, .pos 1818, .pos 1819] := by
  change (g1798 E = true) → (¬ (g1819 E = true)) → (¬ (g1820 E = true)) → False
  exact pattern_6 (g1798 E) (g1819 E)
private theorem sat_1318 (E : Nat → Bool) : (valuation E).satisfies [.neg 1820, .neg 1797] := by
  change (g1821 E = true) → (g1798 E = true) → False
  exact pattern_4 (g403 E) (g1798 E)
private theorem sat_1319 (E : Nat → Bool) : (valuation E).satisfies [.neg 1820, .pos 402] := by
  change (g1821 E = true) → (¬ (g403 E = true)) → False
  exact pattern_5 (g403 E) (g1798 E)
private theorem sat_1320 (E : Nat → Bool) : (valuation E).satisfies [.neg 1821, .pos 1799] := by
  change (g1822 E = true) → (¬ (g1800 E = true)) → False
  exact pattern_5 (g1800 E) (g1821 E)
private theorem sat_1321 (E : Nat → Bool) : (valuation E).satisfies [.neg 1799, .pos 1820, .pos 1821] := by
  change (g1800 E = true) → (¬ (g1821 E = true)) → (¬ (g1822 E = true)) → False
  exact pattern_6 (g1800 E) (g1821 E)
private theorem sat_1322 (E : Nat → Bool) : (valuation E).satisfies [.neg 1822, .neg 1799] := by
  change (g1823 E = true) → (g1800 E = true) → False
  exact pattern_4 (g403 E) (g1800 E)
private theorem sat_1323 (E : Nat → Bool) : (valuation E).satisfies [.neg 1822, .pos 402] := by
  change (g1823 E = true) → (¬ (g403 E = true)) → False
  exact pattern_5 (g403 E) (g1800 E)
private theorem sat_1324 (E : Nat → Bool) : (valuation E).satisfies [.neg 1801, .pos 1822, .pos 1823] := by
  change (g1802 E = true) → (¬ (g1823 E = true)) → (¬ (g1824 E = true)) → False
  exact pattern_6 (g1802 E) (g1823 E)
private theorem sat_1325 (E : Nat → Bool) : (valuation E).satisfies [.neg 1824, .neg 1801] := by
  change (g1825 E = true) → (g1802 E = true) → False
  exact pattern_4 (g403 E) (g1802 E)
private theorem sat_1326 (E : Nat → Bool) : (valuation E).satisfies [.neg 1824, .pos 402] := by
  change (g1825 E = true) → (¬ (g403 E = true)) → False
  exact pattern_5 (g403 E) (g1802 E)
private theorem sat_1327 (E : Nat → Bool) : (valuation E).satisfies [.neg 1803, .pos 1824, .pos 1825] := by
  change (g1804 E = true) → (¬ (g1825 E = true)) → (¬ (g1826 E = true)) → False
  exact pattern_6 (g1804 E) (g1825 E)
private theorem sat_1328 (E : Nat → Bool) : (valuation E).satisfies [.neg 1826, .pos 402] := by
  change (g1827 E = true) → (¬ (g403 E = true)) → False
  exact pattern_5 (g403 E) (g1804 E)
private theorem sat_1329 (E : Nat → Bool) : (valuation E).satisfies [.neg 1805, .pos 1826, .pos 1827] := by
  change (g1806 E = true) → (¬ (g1827 E = true)) → (¬ (g1828 E = true)) → False
  exact pattern_6 (g1806 E) (g1827 E)
private theorem sat_1330 (E : Nat → Bool) : (valuation E).satisfies [.neg 1813, .pos 403, .pos 1837] := by
  change (g1814 E = true) → (¬ (g404 E = true)) → (¬ (g1838 E = true)) → False
  exact pattern_3 (g404 E) (g1814 E)
private theorem sat_1331 (E : Nat → Bool) : (valuation E).satisfies [.neg 1838, .neg 1813] := by
  change (g1839 E = true) → (g1814 E = true) → False
  exact pattern_4 (g404 E) (g1814 E)
private theorem sat_1332 (E : Nat → Bool) : (valuation E).satisfies [.neg 1838, .pos 403] := by
  change (g1839 E = true) → (¬ (g404 E = true)) → False
  exact pattern_5 (g404 E) (g1814 E)
private theorem sat_1333 (E : Nat → Bool) : (valuation E).satisfies [.neg 1815, .pos 1838, .pos 1839] := by
  change (g1816 E = true) → (¬ (g1839 E = true)) → (¬ (g1840 E = true)) → False
  exact pattern_6 (g1816 E) (g1839 E)
private theorem sat_1334 (E : Nat → Bool) : (valuation E).satisfies [.neg 1840, .neg 1815] := by
  change (g1841 E = true) → (g1816 E = true) → False
  exact pattern_4 (g404 E) (g1816 E)
private theorem sat_1335 (E : Nat → Bool) : (valuation E).satisfies [.neg 1840, .pos 403] := by
  change (g1841 E = true) → (¬ (g404 E = true)) → False
  exact pattern_5 (g404 E) (g1816 E)
private theorem sat_1336 (E : Nat → Bool) : (valuation E).satisfies [.neg 1817, .pos 1840, .pos 1841] := by
  change (g1818 E = true) → (¬ (g1841 E = true)) → (¬ (g1842 E = true)) → False
  exact pattern_6 (g1818 E) (g1841 E)
private theorem sat_1337 (E : Nat → Bool) : (valuation E).satisfies [.neg 1842, .neg 1817] := by
  change (g1843 E = true) → (g1818 E = true) → False
  exact pattern_4 (g404 E) (g1818 E)
private theorem sat_1338 (E : Nat → Bool) : (valuation E).satisfies [.neg 1842, .pos 403] := by
  change (g1843 E = true) → (¬ (g404 E = true)) → False
  exact pattern_5 (g404 E) (g1818 E)
private theorem sat_1339 (E : Nat → Bool) : (valuation E).satisfies [.neg 1843, .pos 1819] := by
  change (g1844 E = true) → (¬ (g1820 E = true)) → False
  exact pattern_5 (g1820 E) (g1843 E)
private theorem sat_1340 (E : Nat → Bool) : (valuation E).satisfies [.neg 1819, .pos 1842, .pos 1843] := by
  change (g1820 E = true) → (¬ (g1843 E = true)) → (¬ (g1844 E = true)) → False
  exact pattern_6 (g1820 E) (g1843 E)
private theorem sat_1341 (E : Nat → Bool) : (valuation E).satisfies [.neg 1844, .neg 1819] := by
  change (g1845 E = true) → (g1820 E = true) → False
  exact pattern_4 (g404 E) (g1820 E)
private theorem sat_1342 (E : Nat → Bool) : (valuation E).satisfies [.neg 1844, .pos 403] := by
  change (g1845 E = true) → (¬ (g404 E = true)) → False
  exact pattern_5 (g404 E) (g1820 E)
private theorem sat_1343 (E : Nat → Bool) : (valuation E).satisfies [.neg 403, .pos 1819, .pos 1844] := by
  change (g404 E = true) → (¬ (g1820 E = true)) → (¬ (g1845 E = true)) → False
  exact pattern_6 (g404 E) (g1820 E)
private theorem sat_1344 (E : Nat → Bool) : (valuation E).satisfies [.neg 1845, .pos 1821] := by
  change (g1846 E = true) → (¬ (g1822 E = true)) → False
  exact pattern_5 (g1822 E) (g1845 E)
private theorem sat_1345 (E : Nat → Bool) : (valuation E).satisfies [.neg 1821, .pos 1844, .pos 1845] := by
  change (g1822 E = true) → (¬ (g1845 E = true)) → (¬ (g1846 E = true)) → False
  exact pattern_6 (g1822 E) (g1845 E)
private theorem sat_1346 (E : Nat → Bool) : (valuation E).satisfies [.neg 1846, .neg 1821] := by
  change (g1847 E = true) → (g1822 E = true) → False
  exact pattern_4 (g404 E) (g1822 E)
private theorem sat_1347 (E : Nat → Bool) : (valuation E).satisfies [.neg 1846, .pos 403] := by
  change (g1847 E = true) → (¬ (g404 E = true)) → False
  exact pattern_5 (g404 E) (g1822 E)
private theorem sat_1348 (E : Nat → Bool) : (valuation E).satisfies [.neg 1823, .pos 1846, .pos 1847] := by
  change (g1824 E = true) → (¬ (g1847 E = true)) → (¬ (g1848 E = true)) → False
  exact pattern_6 (g1824 E) (g1847 E)
private theorem sat_1349 (E : Nat → Bool) : (valuation E).satisfies [.neg 1848, .neg 1823] := by
  change (g1849 E = true) → (g1824 E = true) → False
  exact pattern_4 (g404 E) (g1824 E)
private theorem sat_1350 (E : Nat → Bool) : (valuation E).satisfies [.neg 1848, .pos 403] := by
  change (g1849 E = true) → (¬ (g404 E = true)) → False
  exact pattern_5 (g404 E) (g1824 E)
private theorem sat_1351 (E : Nat → Bool) : (valuation E).satisfies [.neg 1825, .pos 1848, .pos 1849] := by
  change (g1826 E = true) → (¬ (g1849 E = true)) → (¬ (g1850 E = true)) → False
  exact pattern_6 (g1826 E) (g1849 E)
private theorem sat_1352 (E : Nat → Bool) : (valuation E).satisfies [.neg 1850, .pos 403] := by
  change (g1851 E = true) → (¬ (g404 E = true)) → False
  exact pattern_5 (g404 E) (g1826 E)
private theorem sat_1353 (E : Nat → Bool) : (valuation E).satisfies [.neg 1827, .pos 1850, .pos 1851] := by
  change (g1828 E = true) → (¬ (g1851 E = true)) → (¬ (g1852 E = true)) → False
  exact pattern_6 (g1828 E) (g1851 E)
private theorem sat_1354 (E : Nat → Bool) : (valuation E).satisfies [.neg 1837, .pos 404, .pos 1863] := by
  change (g1838 E = true) → (¬ (g405 E = true)) → (¬ (g1864 E = true)) → False
  exact pattern_3 (g405 E) (g1838 E)
private theorem sat_1355 (E : Nat → Bool) : (valuation E).satisfies [.neg 1864, .pos 404] := by
  change (g1865 E = true) → (¬ (g405 E = true)) → False
  exact pattern_5 (g405 E) (g1838 E)
private theorem sat_1356 (E : Nat → Bool) : (valuation E).satisfies [.neg 1839, .pos 1864, .pos 1865] := by
  change (g1840 E = true) → (¬ (g1865 E = true)) → (¬ (g1866 E = true)) → False
  exact pattern_6 (g1840 E) (g1865 E)
private theorem sat_1357 (E : Nat → Bool) : (valuation E).satisfies [.neg 1866, .neg 1839] := by
  change (g1867 E = true) → (g1840 E = true) → False
  exact pattern_4 (g405 E) (g1840 E)
private theorem sat_1358 (E : Nat → Bool) : (valuation E).satisfies [.neg 1866, .pos 404] := by
  change (g1867 E = true) → (¬ (g405 E = true)) → False
  exact pattern_5 (g405 E) (g1840 E)
private theorem sat_1359 (E : Nat → Bool) : (valuation E).satisfies [.neg 1841, .pos 1866, .pos 1867] := by
  change (g1842 E = true) → (¬ (g1867 E = true)) → (¬ (g1868 E = true)) → False
  exact pattern_6 (g1842 E) (g1867 E)
private theorem sat_1360 (E : Nat → Bool) : (valuation E).satisfies [.neg 1868, .neg 1841] := by
  change (g1869 E = true) → (g1842 E = true) → False
  exact pattern_4 (g405 E) (g1842 E)
private theorem sat_1361 (E : Nat → Bool) : (valuation E).satisfies [.neg 1868, .pos 404] := by
  change (g1869 E = true) → (¬ (g405 E = true)) → False
  exact pattern_5 (g405 E) (g1842 E)
private theorem sat_1362 (E : Nat → Bool) : (valuation E).satisfies [.neg 404, .pos 1841, .pos 1868] := by
  change (g405 E = true) → (¬ (g1842 E = true)) → (¬ (g1869 E = true)) → False
  exact pattern_6 (g405 E) (g1842 E)
private theorem sat_1363 (E : Nat → Bool) : (valuation E).satisfies [.neg 1869, .neg 1868] := by
  change (g1870 E = true) → (g1869 E = true) → False
  exact pattern_4 (g1844 E) (g1869 E)
private theorem sat_1364 (E : Nat → Bool) : (valuation E).satisfies [.neg 1843, .pos 1868, .pos 1869] := by
  change (g1844 E = true) → (¬ (g1869 E = true)) → (¬ (g1870 E = true)) → False
  exact pattern_6 (g1844 E) (g1869 E)
private theorem sat_1365 (E : Nat → Bool) : (valuation E).satisfies [.neg 1870, .neg 1843] := by
  change (g1871 E = true) → (g1844 E = true) → False
  exact pattern_4 (g405 E) (g1844 E)
private theorem sat_1366 (E : Nat → Bool) : (valuation E).satisfies [.neg 1870, .pos 404] := by
  change (g1871 E = true) → (¬ (g405 E = true)) → False
  exact pattern_5 (g405 E) (g1844 E)
private theorem sat_1367 (E : Nat → Bool) : (valuation E).satisfies [.neg 404, .pos 1843, .pos 1870] := by
  change (g405 E = true) → (¬ (g1844 E = true)) → (¬ (g1871 E = true)) → False
  exact pattern_6 (g405 E) (g1844 E)
private theorem sat_1368 (E : Nat → Bool) : (valuation E).satisfies [.neg 1871, .pos 1845] := by
  change (g1872 E = true) → (¬ (g1846 E = true)) → False
  exact pattern_5 (g1846 E) (g1871 E)
private theorem sat_1369 (E : Nat → Bool) : (valuation E).satisfies [.neg 1845, .pos 1870, .pos 1871] := by
  change (g1846 E = true) → (¬ (g1871 E = true)) → (¬ (g1872 E = true)) → False
  exact pattern_6 (g1846 E) (g1871 E)
private theorem sat_1370 (E : Nat → Bool) : (valuation E).satisfies [.neg 1872, .neg 1845] := by
  change (g1873 E = true) → (g1846 E = true) → False
  exact pattern_4 (g405 E) (g1846 E)
private theorem sat_1371 (E : Nat → Bool) : (valuation E).satisfies [.neg 1872, .pos 404] := by
  change (g1873 E = true) → (¬ (g405 E = true)) → False
  exact pattern_5 (g405 E) (g1846 E)
private theorem sat_1372 (E : Nat → Bool) : (valuation E).satisfies [.neg 1847, .pos 1872, .pos 1873] := by
  change (g1848 E = true) → (¬ (g1873 E = true)) → (¬ (g1874 E = true)) → False
  exact pattern_6 (g1848 E) (g1873 E)
private theorem sat_1373 (E : Nat → Bool) : (valuation E).satisfies [.neg 1874, .neg 1847] := by
  change (g1875 E = true) → (g1848 E = true) → False
  exact pattern_4 (g405 E) (g1848 E)
private theorem sat_1374 (E : Nat → Bool) : (valuation E).satisfies [.neg 1874, .pos 404] := by
  change (g1875 E = true) → (¬ (g405 E = true)) → False
  exact pattern_5 (g405 E) (g1848 E)
private theorem sat_1375 (E : Nat → Bool) : (valuation E).satisfies [.neg 1849, .pos 1874, .pos 1875] := by
  change (g1850 E = true) → (¬ (g1875 E = true)) → (¬ (g1876 E = true)) → False
  exact pattern_6 (g1850 E) (g1875 E)
private theorem sat_1376 (E : Nat → Bool) : (valuation E).satisfies [.neg 1876, .pos 404] := by
  change (g1877 E = true) → (¬ (g405 E = true)) → False
  exact pattern_5 (g405 E) (g1850 E)
private theorem sat_1377 (E : Nat → Bool) : (valuation E).satisfies [.neg 1851, .pos 1876, .pos 1877] := by
  change (g1852 E = true) → (¬ (g1877 E = true)) → (¬ (g1878 E = true)) → False
  exact pattern_6 (g1852 E) (g1877 E)
private theorem sat_1378 (E : Nat → Bool) : (valuation E).satisfies [.neg 1892, .neg 1863] := by
  change (g1893 E = true) → (g1864 E = true) → False
  exact pattern_4 (g412 E) (g1864 E)
private theorem sat_1379 (E : Nat → Bool) : (valuation E).satisfies [.neg 1892, .pos 411] := by
  change (g1893 E = true) → (¬ (g412 E = true)) → False
  exact pattern_5 (g412 E) (g1864 E)
private theorem sat_1380 (E : Nat → Bool) : (valuation E).satisfies [.neg 1865, .pos 1892, .pos 1893] := by
  change (g1866 E = true) → (¬ (g1893 E = true)) → (¬ (g1894 E = true)) → False
  exact pattern_6 (g1866 E) (g1893 E)
private theorem sat_1381 (E : Nat → Bool) : (valuation E).satisfies [.neg 1894, .neg 1865] := by
  change (g1895 E = true) → (g1866 E = true) → False
  exact pattern_4 (g412 E) (g1866 E)
private theorem sat_1382 (E : Nat → Bool) : (valuation E).satisfies [.neg 1894, .pos 411] := by
  change (g1895 E = true) → (¬ (g412 E = true)) → False
  exact pattern_5 (g412 E) (g1866 E)
private theorem sat_1383 (E : Nat → Bool) : (valuation E).satisfies [.neg 1867, .pos 1894, .pos 1895] := by
  change (g1868 E = true) → (¬ (g1895 E = true)) → (¬ (g1896 E = true)) → False
  exact pattern_6 (g1868 E) (g1895 E)
private theorem sat_1384 (E : Nat → Bool) : (valuation E).satisfies [.neg 1896, .neg 1867] := by
  change (g1897 E = true) → (g1868 E = true) → False
  exact pattern_4 (g412 E) (g1868 E)
private theorem sat_1385 (E : Nat → Bool) : (valuation E).satisfies [.neg 1896, .pos 411] := by
  change (g1897 E = true) → (¬ (g412 E = true)) → False
  exact pattern_5 (g412 E) (g1868 E)
private theorem sat_1386 (E : Nat → Bool) : (valuation E).satisfies [.neg 1869, .pos 1896, .pos 1897] := by
  change (g1870 E = true) → (¬ (g1897 E = true)) → (¬ (g1898 E = true)) → False
  exact pattern_6 (g1870 E) (g1897 E)
private theorem sat_1387 (E : Nat → Bool) : (valuation E).satisfies [.neg 1898, .neg 1869] := by
  change (g1899 E = true) → (g1870 E = true) → False
  exact pattern_4 (g412 E) (g1870 E)
private theorem sat_1388 (E : Nat → Bool) : (valuation E).satisfies [.neg 1898, .pos 411] := by
  change (g1899 E = true) → (¬ (g412 E = true)) → False
  exact pattern_5 (g412 E) (g1870 E)
private theorem sat_1389 (E : Nat → Bool) : (valuation E).satisfies [.neg 1899, .pos 1871] := by
  change (g1900 E = true) → (¬ (g1872 E = true)) → False
  exact pattern_5 (g1872 E) (g1899 E)
private theorem sat_1390 (E : Nat → Bool) : (valuation E).satisfies [.neg 1871, .pos 1898, .pos 1899] := by
  change (g1872 E = true) → (¬ (g1899 E = true)) → (¬ (g1900 E = true)) → False
  exact pattern_6 (g1872 E) (g1899 E)
private theorem sat_1391 (E : Nat → Bool) : (valuation E).satisfies [.neg 1900, .neg 1871] := by
  change (g1901 E = true) → (g1872 E = true) → False
  exact pattern_4 (g412 E) (g1872 E)
private theorem sat_1392 (E : Nat → Bool) : (valuation E).satisfies [.neg 1900, .pos 411] := by
  change (g1901 E = true) → (¬ (g412 E = true)) → False
  exact pattern_5 (g412 E) (g1872 E)
private theorem sat_1393 (E : Nat → Bool) : (valuation E).satisfies [.neg 1873, .pos 1900, .pos 1901] := by
  change (g1874 E = true) → (¬ (g1901 E = true)) → (¬ (g1902 E = true)) → False
  exact pattern_6 (g1874 E) (g1901 E)
private theorem sat_1394 (E : Nat → Bool) : (valuation E).satisfies [.neg 1902, .pos 411] := by
  change (g1903 E = true) → (¬ (g412 E = true)) → False
  exact pattern_5 (g412 E) (g1874 E)
private theorem sat_1395 (E : Nat → Bool) : (valuation E).satisfies [.neg 1875, .pos 1902, .pos 1903] := by
  change (g1876 E = true) → (¬ (g1903 E = true)) → (¬ (g1904 E = true)) → False
  exact pattern_6 (g1876 E) (g1903 E)
private theorem sat_1396 (E : Nat → Bool) : (valuation E).satisfies [.neg 1904, .pos 411] := by
  change (g1905 E = true) → (¬ (g412 E = true)) → False
  exact pattern_5 (g412 E) (g1876 E)
private theorem sat_1397 (E : Nat → Bool) : (valuation E).satisfies [.neg 1877, .pos 1904, .pos 1905] := by
  change (g1878 E = true) → (¬ (g1905 E = true)) → (¬ (g1906 E = true)) → False
  exact pattern_6 (g1878 E) (g1905 E)
private theorem sat_1398 (E : Nat → Bool) : (valuation E).satisfies [.neg 1922, .pos 412] := by
  change (g1923 E = true) → (¬ (g413 E = true)) → False
  exact pattern_5 (g413 E) (g1892 E)
private theorem sat_1399 (E : Nat → Bool) : (valuation E).satisfies [.neg 1893, .pos 1922, .pos 1923] := by
  change (g1894 E = true) → (¬ (g1923 E = true)) → (¬ (g1924 E = true)) → False
  exact pattern_6 (g1894 E) (g1923 E)
private theorem sat_1400 (E : Nat → Bool) : (valuation E).satisfies [.neg 1924, .neg 1893] := by
  change (g1925 E = true) → (g1894 E = true) → False
  exact pattern_4 (g413 E) (g1894 E)
private theorem sat_1401 (E : Nat → Bool) : (valuation E).satisfies [.neg 1924, .pos 412] := by
  change (g1925 E = true) → (¬ (g413 E = true)) → False
  exact pattern_5 (g413 E) (g1894 E)
private theorem sat_1402 (E : Nat → Bool) : (valuation E).satisfies [.neg 1895, .pos 1924, .pos 1925] := by
  change (g1896 E = true) → (¬ (g1925 E = true)) → (¬ (g1926 E = true)) → False
  exact pattern_6 (g1896 E) (g1925 E)
private theorem sat_1403 (E : Nat → Bool) : (valuation E).satisfies [.neg 1926, .neg 1895] := by
  change (g1927 E = true) → (g1896 E = true) → False
  exact pattern_4 (g413 E) (g1896 E)
private theorem sat_1404 (E : Nat → Bool) : (valuation E).satisfies [.neg 1926, .pos 412] := by
  change (g1927 E = true) → (¬ (g413 E = true)) → False
  exact pattern_5 (g413 E) (g1896 E)
private theorem sat_1405 (E : Nat → Bool) : (valuation E).satisfies [.neg 1897, .pos 1926, .pos 1927] := by
  change (g1898 E = true) → (¬ (g1927 E = true)) → (¬ (g1928 E = true)) → False
  exact pattern_6 (g1898 E) (g1927 E)
private theorem sat_1406 (E : Nat → Bool) : (valuation E).satisfies [.neg 1928, .neg 1897] := by
  change (g1929 E = true) → (g1898 E = true) → False
  exact pattern_4 (g413 E) (g1898 E)
private theorem sat_1407 (E : Nat → Bool) : (valuation E).satisfies [.neg 1928, .pos 412] := by
  change (g1929 E = true) → (¬ (g413 E = true)) → False
  exact pattern_5 (g413 E) (g1898 E)
private theorem sat_1408 (E : Nat → Bool) : (valuation E).satisfies [.neg 1929, .pos 1899] := by
  change (g1930 E = true) → (¬ (g1900 E = true)) → False
  exact pattern_5 (g1900 E) (g1929 E)
private theorem sat_1409 (E : Nat → Bool) : (valuation E).satisfies [.neg 1899, .pos 1928, .pos 1929] := by
  change (g1900 E = true) → (¬ (g1929 E = true)) → (¬ (g1930 E = true)) → False
  exact pattern_6 (g1900 E) (g1929 E)
private theorem sat_1410 (E : Nat → Bool) : (valuation E).satisfies [.neg 1930, .neg 1899] := by
  change (g1931 E = true) → (g1900 E = true) → False
  exact pattern_4 (g413 E) (g1900 E)
private theorem sat_1411 (E : Nat → Bool) : (valuation E).satisfies [.neg 1930, .pos 412] := by
  change (g1931 E = true) → (¬ (g413 E = true)) → False
  exact pattern_5 (g413 E) (g1900 E)
private theorem sat_1412 (E : Nat → Bool) : (valuation E).satisfies [.neg 1901, .pos 1930, .pos 1931] := by
  change (g1902 E = true) → (¬ (g1931 E = true)) → (¬ (g1932 E = true)) → False
  exact pattern_6 (g1902 E) (g1931 E)
private theorem sat_1413 (E : Nat → Bool) : (valuation E).satisfies [.neg 1932, .pos 412] := by
  change (g1933 E = true) → (¬ (g413 E = true)) → False
  exact pattern_5 (g413 E) (g1902 E)
private theorem sat_1414 (E : Nat → Bool) : (valuation E).satisfies [.neg 1903, .pos 1932, .pos 1933] := by
  change (g1904 E = true) → (¬ (g1933 E = true)) → (¬ (g1934 E = true)) → False
  exact pattern_6 (g1904 E) (g1933 E)
private theorem sat_1415 (E : Nat → Bool) : (valuation E).satisfies [.neg 1934, .pos 412] := by
  change (g1935 E = true) → (¬ (g413 E = true)) → False
  exact pattern_5 (g413 E) (g1904 E)
private theorem sat_1416 (E : Nat → Bool) : (valuation E).satisfies [.neg 1905, .pos 1934, .pos 1935] := by
  change (g1906 E = true) → (¬ (g1935 E = true)) → (¬ (g1936 E = true)) → False
  exact pattern_6 (g1906 E) (g1935 E)
private theorem sat_1417 (E : Nat → Bool) : (valuation E).satisfies [.neg 1954, .pos 413] := by
  change (g1955 E = true) → (¬ (g414 E = true)) → False
  exact pattern_5 (g414 E) (g1922 E)
private theorem sat_1418 (E : Nat → Bool) : (valuation E).satisfies [.neg 1923, .pos 1954, .pos 1955] := by
  change (g1924 E = true) → (¬ (g1955 E = true)) → (¬ (g1956 E = true)) → False
  exact pattern_6 (g1924 E) (g1955 E)
private theorem sat_1419 (E : Nat → Bool) : (valuation E).satisfies [.neg 1956, .pos 413] := by
  change (g1957 E = true) → (¬ (g414 E = true)) → False
  exact pattern_5 (g414 E) (g1924 E)
private theorem sat_1420 (E : Nat → Bool) : (valuation E).satisfies [.neg 1925, .pos 1956, .pos 1957] := by
  change (g1926 E = true) → (¬ (g1957 E = true)) → (¬ (g1958 E = true)) → False
  exact pattern_6 (g1926 E) (g1957 E)
private theorem sat_1421 (E : Nat → Bool) : (valuation E).satisfies [.neg 1958, .neg 1925] := by
  change (g1959 E = true) → (g1926 E = true) → False
  exact pattern_4 (g414 E) (g1926 E)
private theorem sat_1422 (E : Nat → Bool) : (valuation E).satisfies [.neg 1958, .pos 413] := by
  change (g1959 E = true) → (¬ (g414 E = true)) → False
  exact pattern_5 (g414 E) (g1926 E)
private theorem sat_1423 (E : Nat → Bool) : (valuation E).satisfies [.neg 1927, .pos 1958, .pos 1959] := by
  change (g1928 E = true) → (¬ (g1959 E = true)) → (¬ (g1960 E = true)) → False
  exact pattern_6 (g1928 E) (g1959 E)
private theorem sat_1424 (E : Nat → Bool) : (valuation E).satisfies [.neg 1960, .neg 1927] := by
  change (g1961 E = true) → (g1928 E = true) → False
  exact pattern_4 (g414 E) (g1928 E)
private theorem sat_1425 (E : Nat → Bool) : (valuation E).satisfies [.neg 1960, .pos 413] := by
  change (g1961 E = true) → (¬ (g414 E = true)) → False
  exact pattern_5 (g414 E) (g1928 E)
private theorem sat_1426 (E : Nat → Bool) : (valuation E).satisfies [.neg 413, .pos 1927, .pos 1960] := by
  change (g414 E = true) → (¬ (g1928 E = true)) → (¬ (g1961 E = true)) → False
  exact pattern_6 (g414 E) (g1928 E)
private theorem sat_1427 (E : Nat → Bool) : (valuation E).satisfies [.neg 1961, .neg 1960] := by
  change (g1962 E = true) → (g1961 E = true) → False
  exact pattern_4 (g1930 E) (g1961 E)
private theorem sat_1428 (E : Nat → Bool) : (valuation E).satisfies [.neg 1961, .pos 1929] := by
  change (g1962 E = true) → (¬ (g1930 E = true)) → False
  exact pattern_5 (g1930 E) (g1961 E)
private theorem sat_1429 (E : Nat → Bool) : (valuation E).satisfies [.neg 1929, .pos 1960, .pos 1961] := by
  change (g1930 E = true) → (¬ (g1961 E = true)) → (¬ (g1962 E = true)) → False
  exact pattern_6 (g1930 E) (g1961 E)
private theorem sat_1430 (E : Nat → Bool) : (valuation E).satisfies [.neg 1962, .neg 1929] := by
  change (g1963 E = true) → (g1930 E = true) → False
  exact pattern_4 (g414 E) (g1930 E)
private theorem sat_1431 (E : Nat → Bool) : (valuation E).satisfies [.neg 1962, .pos 413] := by
  change (g1963 E = true) → (¬ (g414 E = true)) → False
  exact pattern_5 (g414 E) (g1930 E)
private theorem sat_1432 (E : Nat → Bool) : (valuation E).satisfies [.neg 1931, .pos 1962, .pos 1963] := by
  change (g1932 E = true) → (¬ (g1963 E = true)) → (¬ (g1964 E = true)) → False
  exact pattern_6 (g1932 E) (g1963 E)
private theorem sat_1433 (E : Nat → Bool) : (valuation E).satisfies [.neg 1964, .pos 413] := by
  change (g1965 E = true) → (¬ (g414 E = true)) → False
  exact pattern_5 (g414 E) (g1932 E)
private theorem sat_1434 (E : Nat → Bool) : (valuation E).satisfies [.neg 1933, .pos 1964, .pos 1965] := by
  change (g1934 E = true) → (¬ (g1965 E = true)) → (¬ (g1966 E = true)) → False
  exact pattern_6 (g1934 E) (g1965 E)
private theorem sat_1435 (E : Nat → Bool) : (valuation E).satisfies [.neg 1966, .pos 413] := by
  change (g1967 E = true) → (¬ (g414 E = true)) → False
  exact pattern_5 (g414 E) (g1934 E)
private theorem sat_1436 (E : Nat → Bool) : (valuation E).satisfies [.neg 1935, .pos 1966, .pos 1967] := by
  change (g1936 E = true) → (¬ (g1967 E = true)) → (¬ (g1968 E = true)) → False
  exact pattern_6 (g1936 E) (g1967 E)
private theorem sat_1437 (E : Nat → Bool) : (valuation E).satisfies [.neg 1990, .neg 1955] := by
  change (g1991 E = true) → (g1956 E = true) → False
  exact pattern_4 (g415 E) (g1956 E)
private theorem sat_1438 (E : Nat → Bool) : (valuation E).satisfies [.neg 1990, .pos 414] := by
  change (g1991 E = true) → (¬ (g415 E = true)) → False
  exact pattern_5 (g415 E) (g1956 E)
private theorem sat_1439 (E : Nat → Bool) : (valuation E).satisfies [.neg 1957, .pos 1990, .pos 1991] := by
  change (g1958 E = true) → (¬ (g1991 E = true)) → (¬ (g1992 E = true)) → False
  exact pattern_6 (g1958 E) (g1991 E)
private theorem sat_1440 (E : Nat → Bool) : (valuation E).satisfies [.neg 1992, .neg 1957] := by
  change (g1993 E = true) → (g1958 E = true) → False
  exact pattern_4 (g415 E) (g1958 E)
private theorem sat_1441 (E : Nat → Bool) : (valuation E).satisfies [.neg 1992, .pos 414] := by
  change (g1993 E = true) → (¬ (g415 E = true)) → False
  exact pattern_5 (g415 E) (g1958 E)
private theorem sat_1442 (E : Nat → Bool) : (valuation E).satisfies [.neg 1959, .pos 1992, .pos 1993] := by
  change (g1960 E = true) → (¬ (g1993 E = true)) → (¬ (g1994 E = true)) → False
  exact pattern_6 (g1960 E) (g1993 E)
private theorem sat_1443 (E : Nat → Bool) : (valuation E).satisfies [.neg 1994, .neg 1959] := by
  change (g1995 E = true) → (g1960 E = true) → False
  exact pattern_4 (g415 E) (g1960 E)
private theorem sat_1444 (E : Nat → Bool) : (valuation E).satisfies [.neg 1994, .pos 414] := by
  change (g1995 E = true) → (¬ (g415 E = true)) → False
  exact pattern_5 (g415 E) (g1960 E)
private theorem sat_1445 (E : Nat → Bool) : (valuation E).satisfies [.neg 1995, .pos 1961] := by
  change (g1996 E = true) → (¬ (g1962 E = true)) → False
  exact pattern_5 (g1962 E) (g1995 E)
private theorem sat_1446 (E : Nat → Bool) : (valuation E).satisfies [.neg 1961, .pos 1994, .pos 1995] := by
  change (g1962 E = true) → (¬ (g1995 E = true)) → (¬ (g1996 E = true)) → False
  exact pattern_6 (g1962 E) (g1995 E)
private theorem sat_1447 (E : Nat → Bool) : (valuation E).satisfies [.neg 1996, .neg 1961] := by
  change (g1997 E = true) → (g1962 E = true) → False
  exact pattern_4 (g415 E) (g1962 E)
private theorem sat_1448 (E : Nat → Bool) : (valuation E).satisfies [.neg 1996, .pos 414] := by
  change (g1997 E = true) → (¬ (g415 E = true)) → False
  exact pattern_5 (g415 E) (g1962 E)
private theorem sat_1449 (E : Nat → Bool) : (valuation E).satisfies [.neg 1963, .pos 1996, .pos 1997] := by
  change (g1964 E = true) → (¬ (g1997 E = true)) → (¬ (g1998 E = true)) → False
  exact pattern_6 (g1964 E) (g1997 E)
private theorem sat_1450 (E : Nat → Bool) : (valuation E).satisfies [.neg 1998, .neg 1963] := by
  change (g1999 E = true) → (g1964 E = true) → False
  exact pattern_4 (g415 E) (g1964 E)
private theorem sat_1451 (E : Nat → Bool) : (valuation E).satisfies [.neg 1965, .pos 1998, .pos 1999] := by
  change (g1966 E = true) → (¬ (g1999 E = true)) → (¬ (g2000 E = true)) → False
  exact pattern_6 (g1966 E) (g1999 E)
private theorem sat_1452 (E : Nat → Bool) : (valuation E).satisfies [.neg 2000, .neg 1965] := by
  change (g2001 E = true) → (g1966 E = true) → False
  exact pattern_4 (g415 E) (g1966 E)
private theorem sat_1453 (E : Nat → Bool) : (valuation E).satisfies [.neg 1967, .pos 2000, .pos 2001] := by
  change (g1968 E = true) → (¬ (g2001 E = true)) → (¬ (g2002 E = true)) → False
  exact pattern_6 (g1968 E) (g2001 E)
private theorem sat_1454 (E : Nat → Bool) : (valuation E).satisfies [.neg 2028, .neg 1991] := by
  change (g2029 E = true) → (g1992 E = true) → False
  exact pattern_4 (g416 E) (g1992 E)
private theorem sat_1455 (E : Nat → Bool) : (valuation E).satisfies [.neg 2028, .pos 415] := by
  change (g2029 E = true) → (¬ (g416 E = true)) → False
  exact pattern_5 (g416 E) (g1992 E)
private theorem sat_1456 (E : Nat → Bool) : (valuation E).satisfies [.neg 1993, .pos 2028, .pos 2029] := by
  change (g1994 E = true) → (¬ (g2029 E = true)) → (¬ (g2030 E = true)) → False
  exact pattern_6 (g1994 E) (g2029 E)
private theorem sat_1457 (E : Nat → Bool) : (valuation E).satisfies [.neg 2030, .neg 1993] := by
  change (g2031 E = true) → (g1994 E = true) → False
  exact pattern_4 (g416 E) (g1994 E)
private theorem sat_1458 (E : Nat → Bool) : (valuation E).satisfies [.neg 2030, .pos 415] := by
  change (g2031 E = true) → (¬ (g416 E = true)) → False
  exact pattern_5 (g416 E) (g1994 E)
private theorem sat_1459 (E : Nat → Bool) : (valuation E).satisfies [.neg 415, .pos 1993, .pos 2030] := by
  change (g416 E = true) → (¬ (g1994 E = true)) → (¬ (g2031 E = true)) → False
  exact pattern_6 (g416 E) (g1994 E)
private theorem sat_1460 (E : Nat → Bool) : (valuation E).satisfies [.neg 2031, .neg 2030] := by
  change (g2032 E = true) → (g2031 E = true) → False
  exact pattern_4 (g1996 E) (g2031 E)
private theorem sat_1461 (E : Nat → Bool) : (valuation E).satisfies [.neg 2031, .pos 1995] := by
  change (g2032 E = true) → (¬ (g1996 E = true)) → False
  exact pattern_5 (g1996 E) (g2031 E)
private theorem sat_1462 (E : Nat → Bool) : (valuation E).satisfies [.neg 1995, .pos 2030, .pos 2031] := by
  change (g1996 E = true) → (¬ (g2031 E = true)) → (¬ (g2032 E = true)) → False
  exact pattern_6 (g1996 E) (g2031 E)
private theorem sat_1463 (E : Nat → Bool) : (valuation E).satisfies [.neg 2032, .neg 1995] := by
  change (g2033 E = true) → (g1996 E = true) → False
  exact pattern_4 (g416 E) (g1996 E)
private theorem sat_1464 (E : Nat → Bool) : (valuation E).satisfies [.neg 2032, .pos 415] := by
  change (g2033 E = true) → (¬ (g416 E = true)) → False
  exact pattern_5 (g416 E) (g1996 E)
private theorem sat_1465 (E : Nat → Bool) : (valuation E).satisfies [.neg 2033, .pos 1997] := by
  change (g2034 E = true) → (¬ (g1998 E = true)) → False
  exact pattern_5 (g1998 E) (g2033 E)
private theorem sat_1466 (E : Nat → Bool) : (valuation E).satisfies [.neg 1997, .pos 2032, .pos 2033] := by
  change (g1998 E = true) → (¬ (g2033 E = true)) → (¬ (g2034 E = true)) → False
  exact pattern_6 (g1998 E) (g2033 E)
private theorem sat_1467 (E : Nat → Bool) : (valuation E).satisfies [.neg 2034, .neg 1997] := by
  change (g2035 E = true) → (g1998 E = true) → False
  exact pattern_4 (g416 E) (g1998 E)
private theorem sat_1468 (E : Nat → Bool) : (valuation E).satisfies [.neg 2034, .pos 415] := by
  change (g2035 E = true) → (¬ (g416 E = true)) → False
  exact pattern_5 (g416 E) (g1998 E)
private theorem sat_1469 (E : Nat → Bool) : (valuation E).satisfies [.neg 1999, .pos 2034, .pos 2035] := by
  change (g2000 E = true) → (¬ (g2035 E = true)) → (¬ (g2036 E = true)) → False
  exact pattern_6 (g2000 E) (g2035 E)
private theorem sat_1470 (E : Nat → Bool) : (valuation E).satisfies [.neg 2036, .neg 1999] := by
  change (g2037 E = true) → (g2000 E = true) → False
  exact pattern_4 (g416 E) (g2000 E)
private theorem sat_1471 (E : Nat → Bool) : (valuation E).satisfies [.neg 2001, .pos 2036, .pos 2037] := by
  change (g2002 E = true) → (¬ (g2037 E = true)) → (¬ (g2038 E = true)) → False
  exact pattern_6 (g2002 E) (g2037 E)
private theorem sat_1472 (E : Nat → Bool) : (valuation E).satisfies [.neg 2068, .neg 2029] := by
  change (g2069 E = true) → (g2030 E = true) → False
  exact pattern_4 (g417 E) (g2030 E)
private theorem sat_1473 (E : Nat → Bool) : (valuation E).satisfies [.neg 2068, .pos 416] := by
  change (g2069 E = true) → (¬ (g417 E = true)) → False
  exact pattern_5 (g417 E) (g2030 E)
private theorem sat_1474 (E : Nat → Bool) : (valuation E).satisfies [.neg 2031, .pos 2068, .pos 2069] := by
  change (g2032 E = true) → (¬ (g2069 E = true)) → (¬ (g2070 E = true)) → False
  exact pattern_6 (g2032 E) (g2069 E)
private theorem sat_1475 (E : Nat → Bool) : (valuation E).satisfies [.neg 2070, .neg 2031] := by
  change (g2071 E = true) → (g2032 E = true) → False
  exact pattern_4 (g417 E) (g2032 E)
private theorem sat_1476 (E : Nat → Bool) : (valuation E).satisfies [.neg 2070, .pos 416] := by
  change (g2071 E = true) → (¬ (g417 E = true)) → False
  exact pattern_5 (g417 E) (g2032 E)
private theorem sat_1477 (E : Nat → Bool) : (valuation E).satisfies [.neg 2071, .pos 2033] := by
  change (g2072 E = true) → (¬ (g2034 E = true)) → False
  exact pattern_5 (g2034 E) (g2071 E)
private theorem sat_1478 (E : Nat → Bool) : (valuation E).satisfies [.neg 2033, .pos 2070, .pos 2071] := by
  change (g2034 E = true) → (¬ (g2071 E = true)) → (¬ (g2072 E = true)) → False
  exact pattern_6 (g2034 E) (g2071 E)
private theorem sat_1479 (E : Nat → Bool) : (valuation E).satisfies [.neg 2072, .neg 2033] := by
  change (g2073 E = true) → (g2034 E = true) → False
  exact pattern_4 (g417 E) (g2034 E)
private theorem sat_1480 (E : Nat → Bool) : (valuation E).satisfies [.neg 2072, .pos 416] := by
  change (g2073 E = true) → (¬ (g417 E = true)) → False
  exact pattern_5 (g417 E) (g2034 E)
private theorem sat_1481 (E : Nat → Bool) : (valuation E).satisfies [.neg 2035, .pos 2072, .pos 2073] := by
  change (g2036 E = true) → (¬ (g2073 E = true)) → (¬ (g2074 E = true)) → False
  exact pattern_6 (g2036 E) (g2073 E)
private theorem sat_1482 (E : Nat → Bool) : (valuation E).satisfies [.neg 2074, .neg 2035] := by
  change (g2075 E = true) → (g2036 E = true) → False
  exact pattern_4 (g417 E) (g2036 E)
private theorem sat_1483 (E : Nat → Bool) : (valuation E).satisfies [.neg 2037, .pos 2074, .pos 2075] := by
  change (g2038 E = true) → (¬ (g2075 E = true)) → (¬ (g2076 E = true)) → False
  exact pattern_6 (g2038 E) (g2075 E)
private theorem sat_1497 (E : Nat → Bool) : (valuation E).satisfies [.neg 2101, .neg 11] := by
  change (g2102 E = true) → (g12 E = true) → False
  exact pattern_4 (g11 E) (g12 E)
private theorem sat_1498 (E : Nat → Bool) : (valuation E).satisfies [.neg 10, .pos 11, .pos 2101] := by
  change (g11 E = true) → (¬ (g12 E = true)) → (¬ (g2102 E = true)) → False
  exact pattern_6 (g11 E) (g12 E)
private theorem sat_1499 (E : Nat → Bool) : (valuation E).satisfies [.neg 4, .pos 5, .pos 2103] := by
  change (g5 E = true) → (¬ (g6 E = true)) → (¬ (g2104 E = true)) → False
  exact pattern_6 (g5 E) (g6 E)
private theorem pattern_16 (x0 x1 : Bool) : (((x1) ^^ (x0))=true) → (¬ (x0=true)) → (¬ (x1=true)) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_1500 (E : Nat → Bool) : (valuation E).satisfies [.neg 2104, .pos 4, .pos 5] := by
  change (g2105 E = true) → (¬ (g5 E = true)) → (¬ (g6 E = true)) → False
  exact pattern_16 (g5 E) (g6 E)
private theorem pattern_17 (x0 x1 : Bool) : (((x1) ^^ (x0))=true) → (x1=true) → (x0=true) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_1501 (E : Nat → Bool) : (valuation E).satisfies [.neg 2104, .neg 5, .neg 4] := by
  change (g2105 E = true) → (g6 E = true) → (g5 E = true) → False
  exact pattern_17 (g5 E) (g6 E)
private theorem sat_1502 (E : Nat → Bool) : (valuation E).satisfies [.neg 2101, .pos 2104, .pos 2105] := by
  change (g2102 E = true) → (¬ (g2105 E = true)) → (¬ (g2106 E = true)) → False
  exact pattern_6 (g2102 E) (g2105 E)
private theorem sat_1503 (E : Nat → Bool) : (valuation E).satisfies [.neg 2106, .neg 2105] := by
  change (g2107 E = true) → (g2106 E = true) → False
  exact pattern_9 (g2104 E) (g2106 E)
private theorem sat_1504 (E : Nat → Bool) : (valuation E).satisfies [.neg 2106, .neg 2103] := by
  change (g2107 E = true) → (g2104 E = true) → False
  exact pattern_7 (g2104 E) (g2106 E)
private theorem sat_1506 (E : Nat → Bool) : (valuation E).satisfies [.neg 2107, .neg 12] := by
  change (g2108 E = true) → (g13 E = true) → False
  exact pattern_4 (g12 E) (g13 E)
private theorem sat_1507 (E : Nat → Bool) : (valuation E).satisfies [.neg 2107, .pos 11] := by
  change (g2108 E = true) → (¬ (g12 E = true)) → False
  exact pattern_5 (g12 E) (g13 E)
private theorem sat_1508 (E : Nat → Bool) : (valuation E).satisfies [.neg 11, .pos 12, .pos 2107] := by
  change (g12 E = true) → (¬ (g13 E = true)) → (¬ (g2108 E = true)) → False
  exact pattern_6 (g12 E) (g13 E)
private theorem sat_1509 (E : Nat → Bool) : (valuation E).satisfies [.neg 5, .pos 6, .pos 2109] := by
  change (g6 E = true) → (¬ (g7 E = true)) → (¬ (g2110 E = true)) → False
  exact pattern_6 (g6 E) (g7 E)
private theorem sat_1510 (E : Nat → Bool) : (valuation E).satisfies [.neg 2110, .pos 5, .pos 6] := by
  change (g2111 E = true) → (¬ (g6 E = true)) → (¬ (g7 E = true)) → False
  exact pattern_16 (g6 E) (g7 E)
private theorem sat_1511 (E : Nat → Bool) : (valuation E).satisfies [.neg 2110, .neg 6, .neg 5] := by
  change (g2111 E = true) → (g7 E = true) → (g6 E = true) → False
  exact pattern_17 (g6 E) (g7 E)
private theorem sat_1512 (E : Nat → Bool) : (valuation E).satisfies [.neg 2107, .pos 2110, .pos 2111] := by
  change (g2108 E = true) → (¬ (g2111 E = true)) → (¬ (g2112 E = true)) → False
  exact pattern_6 (g2108 E) (g2111 E)
private theorem sat_1513 (E : Nat → Bool) : (valuation E).satisfies [.neg 2112, .neg 2111] := by
  change (g2113 E = true) → (g2112 E = true) → False
  exact pattern_9 (g2110 E) (g2112 E)
private theorem sat_1514 (E : Nat → Bool) : (valuation E).satisfies [.neg 2112, .neg 2109] := by
  change (g2113 E = true) → (g2110 E = true) → False
  exact pattern_7 (g2110 E) (g2112 E)
private theorem sat_1516 (E : Nat → Bool) : (valuation E).satisfies [.neg 2113, .neg 13] := by
  change (g2114 E = true) → (g14 E = true) → False
  exact pattern_4 (g13 E) (g14 E)
private theorem sat_1517 (E : Nat → Bool) : (valuation E).satisfies [.neg 2113, .pos 12] := by
  change (g2114 E = true) → (¬ (g13 E = true)) → False
  exact pattern_5 (g13 E) (g14 E)
private theorem sat_1518 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .pos 13, .pos 2113] := by
  change (g13 E = true) → (¬ (g14 E = true)) → (¬ (g2114 E = true)) → False
  exact pattern_6 (g13 E) (g14 E)
private theorem sat_1519 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .pos 7, .pos 2115] := by
  change (g7 E = true) → (¬ (g8 E = true)) → (¬ (g2116 E = true)) → False
  exact pattern_6 (g7 E) (g8 E)
private theorem sat_1520 (E : Nat → Bool) : (valuation E).satisfies [.neg 2116, .pos 6, .pos 7] := by
  change (g2117 E = true) → (¬ (g7 E = true)) → (¬ (g8 E = true)) → False
  exact pattern_16 (g7 E) (g8 E)
private theorem sat_1521 (E : Nat → Bool) : (valuation E).satisfies [.neg 2116, .neg 7, .neg 6] := by
  change (g2117 E = true) → (g8 E = true) → (g7 E = true) → False
  exact pattern_17 (g7 E) (g8 E)
private theorem sat_1522 (E : Nat → Bool) : (valuation E).satisfies [.neg 2113, .pos 2116, .pos 2117] := by
  change (g2114 E = true) → (¬ (g2117 E = true)) → (¬ (g2118 E = true)) → False
  exact pattern_6 (g2114 E) (g2117 E)
private theorem sat_1523 (E : Nat → Bool) : (valuation E).satisfies [.neg 2118, .neg 2117] := by
  change (g2119 E = true) → (g2118 E = true) → False
  exact pattern_9 (g2116 E) (g2118 E)
private theorem sat_1524 (E : Nat → Bool) : (valuation E).satisfies [.neg 2118, .neg 2115] := by
  change (g2119 E = true) → (g2116 E = true) → False
  exact pattern_7 (g2116 E) (g2118 E)
private theorem sat_1526 (E : Nat → Bool) : (valuation E).satisfies [.neg 2119, .pos 3] := by
  change (g2120 E = true) → (¬ (g4 E = true)) → False
  exact pattern_1 (g4 E) (g10 E)
private theorem sat_1527 (E : Nat → Bool) : (valuation E).satisfies [.neg 2119, .pos 9] := by
  change (g2120 E = true) → (¬ (g10 E = true)) → False
  exact pattern_2 (g4 E) (g10 E)
private theorem sat_1528 (E : Nat → Bool) : (valuation E).satisfies [.neg 9, .neg 3, .pos 2119] := by
  change (g10 E = true) → (g4 E = true) → (¬ (g2120 E = true)) → False
  exact pattern_15 (g4 E) (g10 E)
private theorem sat_1529 (E : Nat → Bool) : (valuation E).satisfies [.neg 2120, .pos 3] := by
  change (g2121 E = true) → (¬ (g4 E = true)) → False
  exact pattern_1 (g4 E) (g15 E)
private theorem sat_1530 (E : Nat → Bool) : (valuation E).satisfies [.neg 2120, .pos 14] := by
  change (g2121 E = true) → (¬ (g15 E = true)) → False
  exact pattern_2 (g4 E) (g15 E)
private theorem sat_1531 (E : Nat → Bool) : (valuation E).satisfies [.neg 14, .neg 3, .pos 2120] := by
  change (g15 E = true) → (g4 E = true) → (¬ (g2121 E = true)) → False
  exact pattern_15 (g4 E) (g15 E)
private theorem sat_1532 (E : Nat → Bool) : (valuation E).satisfies [.neg 2121, .pos 9] := by
  change (g2122 E = true) → (¬ (g10 E = true)) → False
  exact pattern_1 (g10 E) (g15 E)
private theorem sat_1533 (E : Nat → Bool) : (valuation E).satisfies [.neg 2121, .pos 14] := by
  change (g2122 E = true) → (¬ (g15 E = true)) → False
  exact pattern_2 (g10 E) (g15 E)
private theorem sat_1534 (E : Nat → Bool) : (valuation E).satisfies [.neg 14, .neg 9, .pos 2121] := by
  change (g15 E = true) → (g10 E = true) → (¬ (g2122 E = true)) → False
  exact pattern_15 (g10 E) (g15 E)
private theorem pattern_18 (x0 x1 x2 : Bool) : (((!x2) && (!x1) && (!x0))=true) → (x2=true) → False := by cases x0 <;> cases x1 <;> cases x2 <;> decide
private theorem sat_1535 (E : Nat → Bool) : (valuation E).satisfies [.neg 2122, .neg 2121] := by
  change (g2123 E = true) → (g2122 E = true) → False
  exact pattern_18 (g2120 E) (g2121 E) (g2122 E)
private theorem pattern_19 (x0 x1 x2 : Bool) : (((!x2) && (!x1) && (!x0))=true) → (x1=true) → False := by cases x0 <;> cases x1 <;> cases x2 <;> decide
private theorem sat_1536 (E : Nat → Bool) : (valuation E).satisfies [.neg 2122, .neg 2120] := by
  change (g2123 E = true) → (g2121 E = true) → False
  exact pattern_19 (g2120 E) (g2121 E) (g2122 E)
private theorem pattern_20 (x0 x1 x2 : Bool) : (((!x2) && (!x1) && (!x0))=true) → (x0=true) → False := by cases x0 <;> cases x1 <;> cases x2 <;> decide
private theorem sat_1537 (E : Nat → Bool) : (valuation E).satisfies [.neg 2122, .neg 2119] := by
  change (g2123 E = true) → (g2120 E = true) → False
  exact pattern_20 (g2120 E) (g2121 E) (g2122 E)
private theorem pattern_21 (x0 x1 x2 : Bool) : (¬ (x0=true)) → (¬ (x1=true)) → (¬ (x2=true)) → (¬ (((!x2) && (!x1) && (!x0))=true)) → False := by cases x0 <;> cases x1 <;> cases x2 <;> decide
private theorem sat_1538 (E : Nat → Bool) : (valuation E).satisfies [.pos 2119, .pos 2120, .pos 2121, .pos 2122] := by
  change (¬ (g2120 E = true)) → (¬ (g2121 E = true)) → (¬ (g2122 E = true)) → (¬ (g2123 E = true)) → False
  exact pattern_21 (g2120 E) (g2121 E) (g2122 E)
private theorem sat_1539 (E : Nat → Bool) : (valuation E).satisfies [.neg 2123, .neg 15] := by
  change (g2124 E = true) → (g16 E = true) → False
  exact pattern_18 (g5 E) (g11 E) (g16 E)
private theorem sat_1540 (E : Nat → Bool) : (valuation E).satisfies [.neg 2123, .neg 10] := by
  change (g2124 E = true) → (g11 E = true) → False
  exact pattern_19 (g5 E) (g11 E) (g16 E)
private theorem sat_1541 (E : Nat → Bool) : (valuation E).satisfies [.neg 2123, .neg 4] := by
  change (g2124 E = true) → (g5 E = true) → False
  exact pattern_20 (g5 E) (g11 E) (g16 E)
private theorem sat_1542 (E : Nat → Bool) : (valuation E).satisfies [.pos 4, .pos 10, .pos 15, .pos 2123] := by
  change (¬ (g5 E = true)) → (¬ (g11 E = true)) → (¬ (g16 E = true)) → (¬ (g2124 E = true)) → False
  exact pattern_21 (g5 E) (g11 E) (g16 E)
private theorem sat_1543 (E : Nat → Bool) : (valuation E).satisfies [.neg 2124, .neg 16] := by
  change (g2125 E = true) → (g17 E = true) → False
  exact pattern_18 (g6 E) (g12 E) (g17 E)
private theorem sat_1544 (E : Nat → Bool) : (valuation E).satisfies [.neg 2124, .neg 11] := by
  change (g2125 E = true) → (g12 E = true) → False
  exact pattern_19 (g6 E) (g12 E) (g17 E)
private theorem sat_1545 (E : Nat → Bool) : (valuation E).satisfies [.neg 2124, .neg 5] := by
  change (g2125 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g12 E) (g17 E)
private theorem sat_1546 (E : Nat → Bool) : (valuation E).satisfies [.neg 2125, .neg 17] := by
  change (g2126 E = true) → (g18 E = true) → False
  exact pattern_18 (g7 E) (g13 E) (g18 E)
private theorem sat_1547 (E : Nat → Bool) : (valuation E).satisfies [.neg 2125, .neg 12] := by
  change (g2126 E = true) → (g13 E = true) → False
  exact pattern_19 (g7 E) (g13 E) (g18 E)
private theorem sat_1548 (E : Nat → Bool) : (valuation E).satisfies [.neg 2125, .neg 6] := by
  change (g2126 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g13 E) (g18 E)
private theorem sat_1549 (E : Nat → Bool) : (valuation E).satisfies [.pos 6, .pos 12, .pos 17, .pos 2125] := by
  change (¬ (g7 E = true)) → (¬ (g13 E = true)) → (¬ (g18 E = true)) → (¬ (g2126 E = true)) → False
  exact pattern_21 (g7 E) (g13 E) (g18 E)
private theorem sat_1550 (E : Nat → Bool) : (valuation E).satisfies [.neg 2126, .neg 18] := by
  change (g2127 E = true) → (g19 E = true) → False
  exact pattern_18 (g8 E) (g14 E) (g19 E)
private theorem sat_1551 (E : Nat → Bool) : (valuation E).satisfies [.neg 2126, .neg 13] := by
  change (g2127 E = true) → (g14 E = true) → False
  exact pattern_19 (g8 E) (g14 E) (g19 E)
private theorem sat_1552 (E : Nat → Bool) : (valuation E).satisfies [.neg 2126, .neg 7] := by
  change (g2127 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g14 E) (g19 E)
private theorem sat_1554 (E : Nat → Bool) : (valuation E).satisfies [.neg 2127, .pos 2] := by
  change (g2128 E = true) → (¬ (g3 E = true)) → False
  exact pattern_1 (g3 E) (g9 E)
private theorem sat_1555 (E : Nat → Bool) : (valuation E).satisfies [.neg 2127, .pos 8] := by
  change (g2128 E = true) → (¬ (g9 E = true)) → False
  exact pattern_2 (g3 E) (g9 E)
private theorem sat_1556 (E : Nat → Bool) : (valuation E).satisfies [.neg 8, .neg 2, .pos 2127] := by
  change (g9 E = true) → (g3 E = true) → (¬ (g2128 E = true)) → False
  exact pattern_15 (g3 E) (g9 E)
private theorem sat_1557 (E : Nat → Bool) : (valuation E).satisfies [.neg 2128, .pos 14] := by
  change (g2129 E = true) → (¬ (g15 E = true)) → False
  exact pattern_2 (g3 E) (g15 E)
private theorem sat_1558 (E : Nat → Bool) : (valuation E).satisfies [.neg 14, .neg 2, .pos 2128] := by
  change (g15 E = true) → (g3 E = true) → (¬ (g2129 E = true)) → False
  exact pattern_15 (g3 E) (g15 E)
private theorem sat_1559 (E : Nat → Bool) : (valuation E).satisfies [.neg 2129, .pos 14] := by
  change (g2130 E = true) → (¬ (g15 E = true)) → False
  exact pattern_2 (g9 E) (g15 E)
private theorem sat_1560 (E : Nat → Bool) : (valuation E).satisfies [.neg 14, .neg 8, .pos 2129] := by
  change (g15 E = true) → (g9 E = true) → (¬ (g2130 E = true)) → False
  exact pattern_15 (g9 E) (g15 E)
private theorem sat_1561 (E : Nat → Bool) : (valuation E).satisfies [.neg 2130, .neg 2129] := by
  change (g2131 E = true) → (g2130 E = true) → False
  exact pattern_18 (g2128 E) (g2129 E) (g2130 E)
private theorem sat_1562 (E : Nat → Bool) : (valuation E).satisfies [.neg 2130, .neg 2128] := by
  change (g2131 E = true) → (g2129 E = true) → False
  exact pattern_19 (g2128 E) (g2129 E) (g2130 E)
private theorem sat_1563 (E : Nat → Bool) : (valuation E).satisfies [.neg 2130, .neg 2127] := by
  change (g2131 E = true) → (g2128 E = true) → False
  exact pattern_20 (g2128 E) (g2129 E) (g2130 E)
private theorem sat_1564 (E : Nat → Bool) : (valuation E).satisfies [.neg 2131, .neg 19] := by
  change (g2132 E = true) → (g20 E = true) → False
  exact pattern_18 (g5 E) (g11 E) (g20 E)
private theorem sat_1565 (E : Nat → Bool) : (valuation E).satisfies [.neg 2131, .neg 10] := by
  change (g2132 E = true) → (g11 E = true) → False
  exact pattern_19 (g5 E) (g11 E) (g20 E)
private theorem sat_1566 (E : Nat → Bool) : (valuation E).satisfies [.neg 2131, .neg 4] := by
  change (g2132 E = true) → (g5 E = true) → False
  exact pattern_20 (g5 E) (g11 E) (g20 E)
private theorem sat_1567 (E : Nat → Bool) : (valuation E).satisfies [.neg 2132, .neg 20] := by
  change (g2133 E = true) → (g21 E = true) → False
  exact pattern_18 (g6 E) (g12 E) (g21 E)
private theorem sat_1568 (E : Nat → Bool) : (valuation E).satisfies [.neg 2132, .neg 11] := by
  change (g2133 E = true) → (g12 E = true) → False
  exact pattern_19 (g6 E) (g12 E) (g21 E)
private theorem sat_1569 (E : Nat → Bool) : (valuation E).satisfies [.neg 2132, .neg 5] := by
  change (g2133 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g12 E) (g21 E)
private theorem sat_1570 (E : Nat → Bool) : (valuation E).satisfies [.neg 2133, .neg 21] := by
  change (g2134 E = true) → (g22 E = true) → False
  exact pattern_18 (g7 E) (g13 E) (g22 E)
private theorem sat_1571 (E : Nat → Bool) : (valuation E).satisfies [.neg 2133, .neg 12] := by
  change (g2134 E = true) → (g13 E = true) → False
  exact pattern_19 (g7 E) (g13 E) (g22 E)
private theorem sat_1572 (E : Nat → Bool) : (valuation E).satisfies [.neg 2133, .neg 6] := by
  change (g2134 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g13 E) (g22 E)
private theorem sat_1573 (E : Nat → Bool) : (valuation E).satisfies [.pos 6, .pos 12, .pos 21, .pos 2133] := by
  change (¬ (g7 E = true)) → (¬ (g13 E = true)) → (¬ (g22 E = true)) → (¬ (g2134 E = true)) → False
  exact pattern_21 (g7 E) (g13 E) (g22 E)
private theorem sat_1574 (E : Nat → Bool) : (valuation E).satisfies [.neg 2134, .neg 7] := by
  change (g2135 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g14 E) (g23 E)
private theorem sat_1576 (E : Nat → Bool) : (valuation E).satisfies [.neg 8, .neg 2, .pos 2135] := by
  change (g9 E = true) → (g3 E = true) → (¬ (g2136 E = true)) → False
  exact pattern_15 (g3 E) (g9 E)
private theorem sat_1577 (E : Nat → Bool) : (valuation E).satisfies [.neg 2136, .pos 15] := by
  change (g2137 E = true) → (¬ (g16 E = true)) → False
  exact pattern_2 (g3 E) (g16 E)
private theorem sat_1578 (E : Nat → Bool) : (valuation E).satisfies [.neg 15, .neg 2, .pos 2136] := by
  change (g16 E = true) → (g3 E = true) → (¬ (g2137 E = true)) → False
  exact pattern_15 (g3 E) (g16 E)
private theorem sat_1579 (E : Nat → Bool) : (valuation E).satisfies [.neg 2137, .pos 8] := by
  change (g2138 E = true) → (¬ (g9 E = true)) → False
  exact pattern_1 (g9 E) (g16 E)
private theorem sat_1580 (E : Nat → Bool) : (valuation E).satisfies [.neg 2137, .pos 15] := by
  change (g2138 E = true) → (¬ (g16 E = true)) → False
  exact pattern_2 (g9 E) (g16 E)
private theorem sat_1581 (E : Nat → Bool) : (valuation E).satisfies [.neg 15, .neg 8, .pos 2137] := by
  change (g16 E = true) → (g9 E = true) → (¬ (g2138 E = true)) → False
  exact pattern_15 (g9 E) (g16 E)
private theorem sat_1582 (E : Nat → Bool) : (valuation E).satisfies [.neg 2138, .neg 2137] := by
  change (g2139 E = true) → (g2138 E = true) → False
  exact pattern_18 (g2136 E) (g2137 E) (g2138 E)
private theorem sat_1583 (E : Nat → Bool) : (valuation E).satisfies [.neg 2138, .neg 2136] := by
  change (g2139 E = true) → (g2137 E = true) → False
  exact pattern_19 (g2136 E) (g2137 E) (g2138 E)
private theorem sat_1584 (E : Nat → Bool) : (valuation E).satisfies [.neg 2138, .neg 2135] := by
  change (g2139 E = true) → (g2136 E = true) → False
  exact pattern_20 (g2136 E) (g2137 E) (g2138 E)
private theorem sat_1585 (E : Nat → Bool) : (valuation E).satisfies [.neg 9, .neg 3, .pos 2139] := by
  change (g10 E = true) → (g4 E = true) → (¬ (g2140 E = true)) → False
  exact pattern_15 (g4 E) (g10 E)
private theorem sat_1586 (E : Nat → Bool) : (valuation E).satisfies [.neg 19, .neg 3, .pos 2140] := by
  change (g20 E = true) → (g4 E = true) → (¬ (g2141 E = true)) → False
  exact pattern_15 (g4 E) (g20 E)
private theorem sat_1587 (E : Nat → Bool) : (valuation E).satisfies [.neg 19, .neg 9, .pos 2141] := by
  change (g20 E = true) → (g10 E = true) → (¬ (g2142 E = true)) → False
  exact pattern_15 (g10 E) (g20 E)
private theorem sat_1588 (E : Nat → Bool) : (valuation E).satisfies [.neg 2142, .neg 2141] := by
  change (g2143 E = true) → (g2142 E = true) → False
  exact pattern_18 (g2140 E) (g2141 E) (g2142 E)
private theorem sat_1589 (E : Nat → Bool) : (valuation E).satisfies [.neg 2142, .neg 2140] := by
  change (g2143 E = true) → (g2141 E = true) → False
  exact pattern_19 (g2140 E) (g2141 E) (g2142 E)
private theorem sat_1590 (E : Nat → Bool) : (valuation E).satisfies [.neg 2142, .neg 2139] := by
  change (g2143 E = true) → (g2140 E = true) → False
  exact pattern_20 (g2140 E) (g2141 E) (g2142 E)
private theorem sat_1591 (E : Nat → Bool) : (valuation E).satisfies [.neg 2143, .neg 23] := by
  change (g2144 E = true) → (g24 E = true) → False
  exact pattern_18 (g6 E) (g12 E) (g24 E)
private theorem sat_1592 (E : Nat → Bool) : (valuation E).satisfies [.neg 2143, .neg 11] := by
  change (g2144 E = true) → (g12 E = true) → False
  exact pattern_19 (g6 E) (g12 E) (g24 E)
private theorem sat_1593 (E : Nat → Bool) : (valuation E).satisfies [.neg 2143, .neg 5] := by
  change (g2144 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g12 E) (g24 E)
private theorem sat_1594 (E : Nat → Bool) : (valuation E).satisfies [.neg 2144, .neg 24] := by
  change (g2145 E = true) → (g25 E = true) → False
  exact pattern_18 (g7 E) (g13 E) (g25 E)
private theorem sat_1595 (E : Nat → Bool) : (valuation E).satisfies [.neg 2144, .neg 12] := by
  change (g2145 E = true) → (g13 E = true) → False
  exact pattern_19 (g7 E) (g13 E) (g25 E)
private theorem sat_1596 (E : Nat → Bool) : (valuation E).satisfies [.neg 2144, .neg 6] := by
  change (g2145 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g13 E) (g25 E)
private theorem sat_1597 (E : Nat → Bool) : (valuation E).satisfies [.neg 2145, .neg 25] := by
  change (g2146 E = true) → (g26 E = true) → False
  exact pattern_18 (g8 E) (g14 E) (g26 E)
private theorem sat_1598 (E : Nat → Bool) : (valuation E).satisfies [.neg 2145, .neg 13] := by
  change (g2146 E = true) → (g14 E = true) → False
  exact pattern_19 (g8 E) (g14 E) (g26 E)
private theorem sat_1599 (E : Nat → Bool) : (valuation E).satisfies [.neg 2145, .neg 7] := by
  change (g2146 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g14 E) (g26 E)
private theorem sat_1601 (E : Nat → Bool) : (valuation E).satisfies [.neg 8, .neg 2, .pos 2146] := by
  change (g9 E = true) → (g3 E = true) → (¬ (g2147 E = true)) → False
  exact pattern_15 (g3 E) (g9 E)
private theorem sat_1602 (E : Nat → Bool) : (valuation E).satisfies [.neg 16, .neg 2, .pos 2147] := by
  change (g17 E = true) → (g3 E = true) → (¬ (g2148 E = true)) → False
  exact pattern_15 (g3 E) (g17 E)
private theorem sat_1603 (E : Nat → Bool) : (valuation E).satisfies [.neg 16, .neg 8, .pos 2148] := by
  change (g17 E = true) → (g9 E = true) → (¬ (g2149 E = true)) → False
  exact pattern_15 (g9 E) (g17 E)
private theorem sat_1604 (E : Nat → Bool) : (valuation E).satisfies [.neg 2149, .neg 2148] := by
  change (g2150 E = true) → (g2149 E = true) → False
  exact pattern_18 (g2147 E) (g2148 E) (g2149 E)
private theorem sat_1605 (E : Nat → Bool) : (valuation E).satisfies [.neg 2149, .neg 2147] := by
  change (g2150 E = true) → (g2148 E = true) → False
  exact pattern_19 (g2147 E) (g2148 E) (g2149 E)
private theorem sat_1606 (E : Nat → Bool) : (valuation E).satisfies [.neg 2149, .neg 2146] := by
  change (g2150 E = true) → (g2147 E = true) → False
  exact pattern_20 (g2147 E) (g2148 E) (g2149 E)
private theorem sat_1607 (E : Nat → Bool) : (valuation E).satisfies [.neg 9, .neg 3, .pos 2150] := by
  change (g10 E = true) → (g4 E = true) → (¬ (g2151 E = true)) → False
  exact pattern_15 (g4 E) (g10 E)
private theorem sat_1608 (E : Nat → Bool) : (valuation E).satisfies [.neg 20, .neg 3, .pos 2151] := by
  change (g21 E = true) → (g4 E = true) → (¬ (g2152 E = true)) → False
  exact pattern_15 (g4 E) (g21 E)
private theorem sat_1609 (E : Nat → Bool) : (valuation E).satisfies [.neg 20, .neg 9, .pos 2152] := by
  change (g21 E = true) → (g10 E = true) → (¬ (g2153 E = true)) → False
  exact pattern_15 (g10 E) (g21 E)
private theorem sat_1610 (E : Nat → Bool) : (valuation E).satisfies [.neg 2153, .neg 2152] := by
  change (g2154 E = true) → (g2153 E = true) → False
  exact pattern_18 (g2151 E) (g2152 E) (g2153 E)
private theorem sat_1611 (E : Nat → Bool) : (valuation E).satisfies [.neg 2153, .neg 2151] := by
  change (g2154 E = true) → (g2152 E = true) → False
  exact pattern_19 (g2151 E) (g2152 E) (g2153 E)
private theorem sat_1612 (E : Nat → Bool) : (valuation E).satisfies [.neg 2153, .neg 2150] := by
  change (g2154 E = true) → (g2151 E = true) → False
  exact pattern_20 (g2151 E) (g2152 E) (g2153 E)
private theorem sat_1613 (E : Nat → Bool) : (valuation E).satisfies [.neg 2154, .neg 23] := by
  change (g2155 E = true) → (g24 E = true) → False
  exact pattern_18 (g5 E) (g11 E) (g24 E)
private theorem sat_1614 (E : Nat → Bool) : (valuation E).satisfies [.neg 2154, .neg 10] := by
  change (g2155 E = true) → (g11 E = true) → False
  exact pattern_19 (g5 E) (g11 E) (g24 E)
private theorem sat_1615 (E : Nat → Bool) : (valuation E).satisfies [.neg 2155, .neg 26] := by
  change (g2156 E = true) → (g27 E = true) → False
  exact pattern_18 (g7 E) (g13 E) (g27 E)
private theorem sat_1616 (E : Nat → Bool) : (valuation E).satisfies [.neg 2155, .neg 12] := by
  change (g2156 E = true) → (g13 E = true) → False
  exact pattern_19 (g7 E) (g13 E) (g27 E)
private theorem sat_1617 (E : Nat → Bool) : (valuation E).satisfies [.neg 2155, .neg 6] := by
  change (g2156 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g13 E) (g27 E)
private theorem sat_1618 (E : Nat → Bool) : (valuation E).satisfies [.neg 2156, .neg 27] := by
  change (g2157 E = true) → (g28 E = true) → False
  exact pattern_18 (g8 E) (g14 E) (g28 E)
private theorem sat_1619 (E : Nat → Bool) : (valuation E).satisfies [.neg 2156, .neg 7] := by
  change (g2157 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g14 E) (g28 E)
private theorem sat_1621 (E : Nat → Bool) : (valuation E).satisfies [.neg 8, .neg 2, .pos 2157] := by
  change (g9 E = true) → (g3 E = true) → (¬ (g2158 E = true)) → False
  exact pattern_15 (g3 E) (g9 E)
private theorem sat_1622 (E : Nat → Bool) : (valuation E).satisfies [.neg 17, .neg 2, .pos 2158] := by
  change (g18 E = true) → (g3 E = true) → (¬ (g2159 E = true)) → False
  exact pattern_15 (g3 E) (g18 E)
private theorem sat_1623 (E : Nat → Bool) : (valuation E).satisfies [.neg 17, .neg 8, .pos 2159] := by
  change (g18 E = true) → (g9 E = true) → (¬ (g2160 E = true)) → False
  exact pattern_15 (g9 E) (g18 E)
private theorem sat_1624 (E : Nat → Bool) : (valuation E).satisfies [.neg 2160, .neg 2159] := by
  change (g2161 E = true) → (g2160 E = true) → False
  exact pattern_18 (g2158 E) (g2159 E) (g2160 E)
private theorem sat_1625 (E : Nat → Bool) : (valuation E).satisfies [.neg 2160, .neg 2158] := by
  change (g2161 E = true) → (g2159 E = true) → False
  exact pattern_19 (g2158 E) (g2159 E) (g2160 E)
private theorem sat_1626 (E : Nat → Bool) : (valuation E).satisfies [.neg 2160, .neg 2157] := by
  change (g2161 E = true) → (g2158 E = true) → False
  exact pattern_20 (g2158 E) (g2159 E) (g2160 E)
private theorem sat_1627 (E : Nat → Bool) : (valuation E).satisfies [.neg 21, .neg 3, .pos 2162] := by
  change (g22 E = true) → (g4 E = true) → (¬ (g2163 E = true)) → False
  exact pattern_15 (g4 E) (g22 E)
private theorem sat_1628 (E : Nat → Bool) : (valuation E).satisfies [.neg 21, .neg 9, .pos 2163] := by
  change (g22 E = true) → (g10 E = true) → (¬ (g2164 E = true)) → False
  exact pattern_15 (g10 E) (g22 E)
private theorem sat_1629 (E : Nat → Bool) : (valuation E).satisfies [.neg 2164, .neg 2163] := by
  change (g2165 E = true) → (g2164 E = true) → False
  exact pattern_18 (g2162 E) (g2163 E) (g2164 E)
private theorem sat_1630 (E : Nat → Bool) : (valuation E).satisfies [.neg 2164, .neg 2162] := by
  change (g2165 E = true) → (g2163 E = true) → False
  exact pattern_19 (g2162 E) (g2163 E) (g2164 E)
private theorem sat_1631 (E : Nat → Bool) : (valuation E).satisfies [.neg 2165, .neg 24] := by
  change (g2166 E = true) → (g25 E = true) → False
  exact pattern_18 (g5 E) (g11 E) (g25 E)
private theorem sat_1632 (E : Nat → Bool) : (valuation E).satisfies [.neg 2165, .neg 10] := by
  change (g2166 E = true) → (g11 E = true) → False
  exact pattern_19 (g5 E) (g11 E) (g25 E)
private theorem sat_1633 (E : Nat → Bool) : (valuation E).satisfies [.neg 2166, .neg 26] := by
  change (g2167 E = true) → (g27 E = true) → False
  exact pattern_18 (g6 E) (g12 E) (g27 E)
private theorem sat_1634 (E : Nat → Bool) : (valuation E).satisfies [.neg 2166, .neg 5] := by
  change (g2167 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g12 E) (g27 E)
private theorem sat_1635 (E : Nat → Bool) : (valuation E).satisfies [.neg 2167, .neg 7] := by
  change (g2168 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g14 E) (g29 E)
private theorem sat_1637 (E : Nat → Bool) : (valuation E).satisfies [.neg 8, .neg 2, .pos 2168] := by
  change (g9 E = true) → (g3 E = true) → (¬ (g2169 E = true)) → False
  exact pattern_15 (g3 E) (g9 E)
private theorem sat_1638 (E : Nat → Bool) : (valuation E).satisfies [.neg 2169, .pos 2] := by
  change (g2170 E = true) → (¬ (g3 E = true)) → False
  exact pattern_1 (g3 E) (g19 E)
private theorem sat_1639 (E : Nat → Bool) : (valuation E).satisfies [.neg 2169, .pos 18] := by
  change (g2170 E = true) → (¬ (g19 E = true)) → False
  exact pattern_2 (g3 E) (g19 E)
private theorem sat_1640 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 2, .pos 2169] := by
  change (g19 E = true) → (g3 E = true) → (¬ (g2170 E = true)) → False
  exact pattern_15 (g3 E) (g19 E)
private theorem sat_1641 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 8, .pos 2170] := by
  change (g19 E = true) → (g9 E = true) → (¬ (g2171 E = true)) → False
  exact pattern_15 (g9 E) (g19 E)
private theorem sat_1642 (E : Nat → Bool) : (valuation E).satisfies [.neg 2171, .neg 2170] := by
  change (g2172 E = true) → (g2171 E = true) → False
  exact pattern_18 (g2169 E) (g2170 E) (g2171 E)
private theorem sat_1643 (E : Nat → Bool) : (valuation E).satisfies [.neg 2171, .neg 2169] := by
  change (g2172 E = true) → (g2170 E = true) → False
  exact pattern_19 (g2169 E) (g2170 E) (g2171 E)
private theorem sat_1644 (E : Nat → Bool) : (valuation E).satisfies [.neg 2171, .neg 2168] := by
  change (g2172 E = true) → (g2169 E = true) → False
  exact pattern_20 (g2169 E) (g2170 E) (g2171 E)
private theorem sat_1645 (E : Nat → Bool) : (valuation E).satisfies [.neg 9, .neg 3, .pos 2172] := by
  change (g10 E = true) → (g4 E = true) → (¬ (g2173 E = true)) → False
  exact pattern_15 (g4 E) (g10 E)
private theorem sat_1646 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 3, .pos 2173] := by
  change (g23 E = true) → (g4 E = true) → (¬ (g2174 E = true)) → False
  exact pattern_15 (g4 E) (g23 E)
private theorem sat_1647 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 9, .pos 2174] := by
  change (g23 E = true) → (g10 E = true) → (¬ (g2175 E = true)) → False
  exact pattern_15 (g10 E) (g23 E)
private theorem sat_1648 (E : Nat → Bool) : (valuation E).satisfies [.neg 2175, .neg 2174] := by
  change (g2176 E = true) → (g2175 E = true) → False
  exact pattern_18 (g2173 E) (g2174 E) (g2175 E)
private theorem sat_1649 (E : Nat → Bool) : (valuation E).satisfies [.neg 2175, .neg 2173] := by
  change (g2176 E = true) → (g2174 E = true) → False
  exact pattern_19 (g2173 E) (g2174 E) (g2175 E)
private theorem sat_1650 (E : Nat → Bool) : (valuation E).satisfies [.neg 2175, .neg 2172] := by
  change (g2176 E = true) → (g2173 E = true) → False
  exact pattern_20 (g2173 E) (g2174 E) (g2175 E)
private theorem sat_1651 (E : Nat → Bool) : (valuation E).satisfies [.neg 2176, .neg 25] := by
  change (g2177 E = true) → (g26 E = true) → False
  exact pattern_18 (g5 E) (g11 E) (g26 E)
private theorem sat_1652 (E : Nat → Bool) : (valuation E).satisfies [.neg 2176, .neg 10] := by
  change (g2177 E = true) → (g11 E = true) → False
  exact pattern_19 (g5 E) (g11 E) (g26 E)
private theorem sat_1653 (E : Nat → Bool) : (valuation E).satisfies [.neg 2176, .neg 4] := by
  change (g2177 E = true) → (g5 E = true) → False
  exact pattern_20 (g5 E) (g11 E) (g26 E)
private theorem sat_1654 (E : Nat → Bool) : (valuation E).satisfies [.pos 4, .pos 10, .pos 25, .pos 2176] := by
  change (¬ (g5 E = true)) → (¬ (g11 E = true)) → (¬ (g26 E = true)) → (¬ (g2177 E = true)) → False
  exact pattern_21 (g5 E) (g11 E) (g26 E)
private theorem sat_1655 (E : Nat → Bool) : (valuation E).satisfies [.neg 2177, .neg 27] := by
  change (g2178 E = true) → (g28 E = true) → False
  exact pattern_18 (g6 E) (g12 E) (g28 E)
private theorem sat_1656 (E : Nat → Bool) : (valuation E).satisfies [.neg 2177, .neg 11] := by
  change (g2178 E = true) → (g12 E = true) → False
  exact pattern_19 (g6 E) (g12 E) (g28 E)
private theorem sat_1657 (E : Nat → Bool) : (valuation E).satisfies [.neg 2177, .neg 5] := by
  change (g2178 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g12 E) (g28 E)
private theorem sat_1658 (E : Nat → Bool) : (valuation E).satisfies [.neg 2178, .neg 28] := by
  change (g2179 E = true) → (g29 E = true) → False
  exact pattern_18 (g7 E) (g13 E) (g29 E)
private theorem sat_1659 (E : Nat → Bool) : (valuation E).satisfies [.neg 2178, .neg 12] := by
  change (g2179 E = true) → (g13 E = true) → False
  exact pattern_19 (g7 E) (g13 E) (g29 E)
private theorem sat_1660 (E : Nat → Bool) : (valuation E).satisfies [.neg 2178, .neg 6] := by
  change (g2179 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g13 E) (g29 E)
private theorem sat_1662 (E : Nat → Bool) : (valuation E).satisfies [.neg 2179, .pos 8] := by
  change (g2180 E = true) → (¬ (g9 E = true)) → False
  exact pattern_2 (g2 E) (g9 E)
private theorem sat_1663 (E : Nat → Bool) : (valuation E).satisfies [.neg 8, .neg 1, .pos 2179] := by
  change (g9 E = true) → (g2 E = true) → (¬ (g2180 E = true)) → False
  exact pattern_15 (g2 E) (g9 E)
private theorem sat_1664 (E : Nat → Bool) : (valuation E).satisfies [.neg 2180, .pos 1] := by
  change (g2181 E = true) → (¬ (g2 E = true)) → False
  exact pattern_1 (g2 E) (g10 E)
private theorem sat_1665 (E : Nat → Bool) : (valuation E).satisfies [.neg 2180, .pos 9] := by
  change (g2181 E = true) → (¬ (g10 E = true)) → False
  exact pattern_2 (g2 E) (g10 E)
private theorem sat_1666 (E : Nat → Bool) : (valuation E).satisfies [.neg 9, .neg 1, .pos 2180] := by
  change (g10 E = true) → (g2 E = true) → (¬ (g2181 E = true)) → False
  exact pattern_15 (g2 E) (g10 E)
private theorem sat_1667 (E : Nat → Bool) : (valuation E).satisfies [.neg 2181, .pos 8] := by
  change (g2182 E = true) → (¬ (g9 E = true)) → False
  exact pattern_1 (g9 E) (g10 E)
private theorem sat_1668 (E : Nat → Bool) : (valuation E).satisfies [.neg 9, .neg 8, .pos 2181] := by
  change (g10 E = true) → (g9 E = true) → (¬ (g2182 E = true)) → False
  exact pattern_15 (g9 E) (g10 E)
private theorem sat_1669 (E : Nat → Bool) : (valuation E).satisfies [.neg 2182, .neg 2181] := by
  change (g2183 E = true) → (g2182 E = true) → False
  exact pattern_18 (g2180 E) (g2181 E) (g2182 E)
private theorem sat_1670 (E : Nat → Bool) : (valuation E).satisfies [.neg 2182, .neg 2180] := by
  change (g2183 E = true) → (g2181 E = true) → False
  exact pattern_19 (g2180 E) (g2181 E) (g2182 E)
private theorem sat_1671 (E : Nat → Bool) : (valuation E).satisfies [.neg 2182, .neg 2179] := by
  change (g2183 E = true) → (g2180 E = true) → False
  exact pattern_20 (g2180 E) (g2181 E) (g2182 E)
private theorem sat_1672 (E : Nat → Bool) : (valuation E).satisfies [.pos 2179, .pos 2180, .pos 2181, .pos 2182] := by
  change (¬ (g2180 E = true)) → (¬ (g2181 E = true)) → (¬ (g2182 E = true)) → (¬ (g2183 E = true)) → False
  exact pattern_21 (g2180 E) (g2181 E) (g2182 E)
private theorem sat_1673 (E : Nat → Bool) : (valuation E).satisfies [.neg 2183, .neg 19] := by
  change (g2184 E = true) → (g20 E = true) → False
  exact pattern_18 (g5 E) (g16 E) (g20 E)
private theorem sat_1674 (E : Nat → Bool) : (valuation E).satisfies [.neg 2183, .neg 15] := by
  change (g2184 E = true) → (g16 E = true) → False
  exact pattern_19 (g5 E) (g16 E) (g20 E)
private theorem sat_1675 (E : Nat → Bool) : (valuation E).satisfies [.neg 2183, .neg 4] := by
  change (g2184 E = true) → (g5 E = true) → False
  exact pattern_20 (g5 E) (g16 E) (g20 E)
private theorem sat_1676 (E : Nat → Bool) : (valuation E).satisfies [.pos 4, .pos 15, .pos 19, .pos 2183] := by
  change (¬ (g5 E = true)) → (¬ (g16 E = true)) → (¬ (g20 E = true)) → (¬ (g2184 E = true)) → False
  exact pattern_21 (g5 E) (g16 E) (g20 E)
private theorem sat_1677 (E : Nat → Bool) : (valuation E).satisfies [.neg 2184, .neg 20] := by
  change (g2185 E = true) → (g21 E = true) → False
  exact pattern_18 (g6 E) (g17 E) (g21 E)
private theorem sat_1678 (E : Nat → Bool) : (valuation E).satisfies [.neg 2184, .neg 16] := by
  change (g2185 E = true) → (g17 E = true) → False
  exact pattern_19 (g6 E) (g17 E) (g21 E)
private theorem sat_1679 (E : Nat → Bool) : (valuation E).satisfies [.neg 2184, .neg 5] := by
  change (g2185 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g17 E) (g21 E)
private theorem sat_1680 (E : Nat → Bool) : (valuation E).satisfies [.neg 2185, .neg 21] := by
  change (g2186 E = true) → (g22 E = true) → False
  exact pattern_18 (g7 E) (g18 E) (g22 E)
private theorem sat_1681 (E : Nat → Bool) : (valuation E).satisfies [.neg 2185, .neg 17] := by
  change (g2186 E = true) → (g18 E = true) → False
  exact pattern_19 (g7 E) (g18 E) (g22 E)
private theorem sat_1682 (E : Nat → Bool) : (valuation E).satisfies [.neg 2185, .neg 6] := by
  change (g2186 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g18 E) (g22 E)
private theorem sat_1683 (E : Nat → Bool) : (valuation E).satisfies [.neg 2186, .neg 18] := by
  change (g2187 E = true) → (g19 E = true) → False
  exact pattern_19 (g8 E) (g19 E) (g23 E)
private theorem sat_1684 (E : Nat → Bool) : (valuation E).satisfies [.neg 2186, .neg 7] := by
  change (g2187 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g19 E) (g23 E)
private theorem sat_1686 (E : Nat → Bool) : (valuation E).satisfies [.neg 8, .neg 1, .pos 2187] := by
  change (g9 E = true) → (g2 E = true) → (¬ (g2188 E = true)) → False
  exact pattern_15 (g2 E) (g9 E)
private theorem sat_1687 (E : Nat → Bool) : (valuation E).satisfies [.neg 10, .neg 1, .pos 2188] := by
  change (g11 E = true) → (g2 E = true) → (¬ (g2189 E = true)) → False
  exact pattern_15 (g2 E) (g11 E)
private theorem sat_1688 (E : Nat → Bool) : (valuation E).satisfies [.neg 10, .neg 8, .pos 2189] := by
  change (g11 E = true) → (g9 E = true) → (¬ (g2190 E = true)) → False
  exact pattern_15 (g9 E) (g11 E)
private theorem sat_1689 (E : Nat → Bool) : (valuation E).satisfies [.neg 2190, .neg 2189] := by
  change (g2191 E = true) → (g2190 E = true) → False
  exact pattern_18 (g2188 E) (g2189 E) (g2190 E)
private theorem sat_1690 (E : Nat → Bool) : (valuation E).satisfies [.neg 2190, .neg 2188] := by
  change (g2191 E = true) → (g2189 E = true) → False
  exact pattern_19 (g2188 E) (g2189 E) (g2190 E)
private theorem sat_1691 (E : Nat → Bool) : (valuation E).satisfies [.neg 2190, .neg 2187] := by
  change (g2191 E = true) → (g2188 E = true) → False
  exact pattern_20 (g2188 E) (g2189 E) (g2190 E)
private theorem sat_1692 (E : Nat → Bool) : (valuation E).satisfies [.neg 14, .neg 3, .pos 2191] := by
  change (g15 E = true) → (g4 E = true) → (¬ (g2192 E = true)) → False
  exact pattern_15 (g4 E) (g15 E)
private theorem sat_1693 (E : Nat → Bool) : (valuation E).satisfies [.neg 19, .neg 3, .pos 2192] := by
  change (g20 E = true) → (g4 E = true) → (¬ (g2193 E = true)) → False
  exact pattern_15 (g4 E) (g20 E)
private theorem sat_1694 (E : Nat → Bool) : (valuation E).satisfies [.neg 19, .neg 14, .pos 2193] := by
  change (g20 E = true) → (g15 E = true) → (¬ (g2194 E = true)) → False
  exact pattern_15 (g15 E) (g20 E)
private theorem sat_1695 (E : Nat → Bool) : (valuation E).satisfies [.neg 2194, .neg 2193] := by
  change (g2195 E = true) → (g2194 E = true) → False
  exact pattern_18 (g2192 E) (g2193 E) (g2194 E)
private theorem sat_1696 (E : Nat → Bool) : (valuation E).satisfies [.neg 2194, .neg 2192] := by
  change (g2195 E = true) → (g2193 E = true) → False
  exact pattern_19 (g2192 E) (g2193 E) (g2194 E)
private theorem sat_1697 (E : Nat → Bool) : (valuation E).satisfies [.neg 2194, .neg 2191] := by
  change (g2195 E = true) → (g2192 E = true) → False
  exact pattern_20 (g2192 E) (g2193 E) (g2194 E)
private theorem sat_1698 (E : Nat → Bool) : (valuation E).satisfies [.neg 2195, .neg 23] := by
  change (g2196 E = true) → (g24 E = true) → False
  exact pattern_18 (g6 E) (g17 E) (g24 E)
private theorem sat_1699 (E : Nat → Bool) : (valuation E).satisfies [.neg 2195, .neg 16] := by
  change (g2196 E = true) → (g17 E = true) → False
  exact pattern_19 (g6 E) (g17 E) (g24 E)
private theorem sat_1700 (E : Nat → Bool) : (valuation E).satisfies [.neg 2195, .neg 5] := by
  change (g2196 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g17 E) (g24 E)
private theorem sat_1701 (E : Nat → Bool) : (valuation E).satisfies [.neg 2196, .neg 24] := by
  change (g2197 E = true) → (g25 E = true) → False
  exact pattern_18 (g7 E) (g18 E) (g25 E)
private theorem sat_1702 (E : Nat → Bool) : (valuation E).satisfies [.neg 2196, .neg 6] := by
  change (g2197 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g18 E) (g25 E)
private theorem sat_1703 (E : Nat → Bool) : (valuation E).satisfies [.neg 2197, .neg 7] := by
  change (g2198 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g19 E) (g26 E)
private theorem sat_1705 (E : Nat → Bool) : (valuation E).satisfies [.neg 8, .neg 1, .pos 2198] := by
  change (g9 E = true) → (g2 E = true) → (¬ (g2199 E = true)) → False
  exact pattern_15 (g2 E) (g9 E)
private theorem sat_1706 (E : Nat → Bool) : (valuation E).satisfies [.neg 11, .neg 1, .pos 2199] := by
  change (g12 E = true) → (g2 E = true) → (¬ (g2200 E = true)) → False
  exact pattern_15 (g2 E) (g12 E)
private theorem sat_1707 (E : Nat → Bool) : (valuation E).satisfies [.neg 11, .neg 8, .pos 2200] := by
  change (g12 E = true) → (g9 E = true) → (¬ (g2201 E = true)) → False
  exact pattern_15 (g9 E) (g12 E)
private theorem sat_1708 (E : Nat → Bool) : (valuation E).satisfies [.neg 2201, .neg 2200] := by
  change (g2202 E = true) → (g2201 E = true) → False
  exact pattern_18 (g2199 E) (g2200 E) (g2201 E)
private theorem sat_1709 (E : Nat → Bool) : (valuation E).satisfies [.neg 2201, .neg 2199] := by
  change (g2202 E = true) → (g2200 E = true) → False
  exact pattern_19 (g2199 E) (g2200 E) (g2201 E)
private theorem sat_1710 (E : Nat → Bool) : (valuation E).satisfies [.neg 2201, .neg 2198] := by
  change (g2202 E = true) → (g2199 E = true) → False
  exact pattern_20 (g2199 E) (g2200 E) (g2201 E)
private theorem sat_1711 (E : Nat → Bool) : (valuation E).satisfies [.neg 14, .neg 3, .pos 2202] := by
  change (g15 E = true) → (g4 E = true) → (¬ (g2203 E = true)) → False
  exact pattern_15 (g4 E) (g15 E)
private theorem sat_1712 (E : Nat → Bool) : (valuation E).satisfies [.neg 20, .neg 3, .pos 2203] := by
  change (g21 E = true) → (g4 E = true) → (¬ (g2204 E = true)) → False
  exact pattern_15 (g4 E) (g21 E)
private theorem sat_1713 (E : Nat → Bool) : (valuation E).satisfies [.neg 20, .neg 14, .pos 2204] := by
  change (g21 E = true) → (g15 E = true) → (¬ (g2205 E = true)) → False
  exact pattern_15 (g15 E) (g21 E)
private theorem sat_1714 (E : Nat → Bool) : (valuation E).satisfies [.neg 2205, .neg 2204] := by
  change (g2206 E = true) → (g2205 E = true) → False
  exact pattern_18 (g2203 E) (g2204 E) (g2205 E)
private theorem sat_1715 (E : Nat → Bool) : (valuation E).satisfies [.neg 2205, .neg 2203] := by
  change (g2206 E = true) → (g2204 E = true) → False
  exact pattern_19 (g2203 E) (g2204 E) (g2205 E)
private theorem sat_1716 (E : Nat → Bool) : (valuation E).satisfies [.neg 2205, .neg 2202] := by
  change (g2206 E = true) → (g2203 E = true) → False
  exact pattern_20 (g2203 E) (g2204 E) (g2205 E)
private theorem sat_1717 (E : Nat → Bool) : (valuation E).satisfies [.neg 2206, .neg 23] := by
  change (g2207 E = true) → (g24 E = true) → False
  exact pattern_18 (g5 E) (g16 E) (g24 E)
private theorem sat_1718 (E : Nat → Bool) : (valuation E).satisfies [.neg 2206, .neg 15] := by
  change (g2207 E = true) → (g16 E = true) → False
  exact pattern_19 (g5 E) (g16 E) (g24 E)
private theorem sat_1719 (E : Nat → Bool) : (valuation E).satisfies [.neg 2207, .neg 17] := by
  change (g2208 E = true) → (g18 E = true) → False
  exact pattern_19 (g7 E) (g18 E) (g27 E)
private theorem sat_1720 (E : Nat → Bool) : (valuation E).satisfies [.neg 2207, .neg 6] := by
  change (g2208 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g18 E) (g27 E)
private theorem sat_1721 (E : Nat → Bool) : (valuation E).satisfies [.neg 2208, .neg 7] := by
  change (g2209 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g19 E) (g28 E)
private theorem sat_1723 (E : Nat → Bool) : (valuation E).satisfies [.neg 8, .neg 1, .pos 2209] := by
  change (g9 E = true) → (g2 E = true) → (¬ (g2210 E = true)) → False
  exact pattern_15 (g2 E) (g9 E)
private theorem sat_1724 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 1, .pos 2210] := by
  change (g13 E = true) → (g2 E = true) → (¬ (g2211 E = true)) → False
  exact pattern_15 (g2 E) (g13 E)
private theorem sat_1725 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 8, .pos 2211] := by
  change (g13 E = true) → (g9 E = true) → (¬ (g2212 E = true)) → False
  exact pattern_15 (g9 E) (g13 E)
private theorem sat_1726 (E : Nat → Bool) : (valuation E).satisfies [.neg 2212, .neg 2211] := by
  change (g2213 E = true) → (g2212 E = true) → False
  exact pattern_18 (g2210 E) (g2211 E) (g2212 E)
private theorem sat_1727 (E : Nat → Bool) : (valuation E).satisfies [.neg 2212, .neg 2210] := by
  change (g2213 E = true) → (g2211 E = true) → False
  exact pattern_19 (g2210 E) (g2211 E) (g2212 E)
private theorem sat_1728 (E : Nat → Bool) : (valuation E).satisfies [.neg 2212, .neg 2209] := by
  change (g2213 E = true) → (g2210 E = true) → False
  exact pattern_20 (g2210 E) (g2211 E) (g2212 E)
private theorem sat_1729 (E : Nat → Bool) : (valuation E).satisfies [.neg 21, .neg 3, .pos 2214] := by
  change (g22 E = true) → (g4 E = true) → (¬ (g2215 E = true)) → False
  exact pattern_15 (g4 E) (g22 E)
private theorem sat_1730 (E : Nat → Bool) : (valuation E).satisfies [.neg 21, .neg 14, .pos 2215] := by
  change (g22 E = true) → (g15 E = true) → (¬ (g2216 E = true)) → False
  exact pattern_15 (g15 E) (g22 E)
private theorem sat_1731 (E : Nat → Bool) : (valuation E).satisfies [.neg 2216, .neg 2215] := by
  change (g2217 E = true) → (g2216 E = true) → False
  exact pattern_18 (g2214 E) (g2215 E) (g2216 E)
private theorem sat_1732 (E : Nat → Bool) : (valuation E).satisfies [.neg 2216, .neg 2214] := by
  change (g2217 E = true) → (g2215 E = true) → False
  exact pattern_19 (g2214 E) (g2215 E) (g2216 E)
private theorem sat_1733 (E : Nat → Bool) : (valuation E).satisfies [.neg 2217, .neg 24] := by
  change (g2218 E = true) → (g25 E = true) → False
  exact pattern_18 (g5 E) (g16 E) (g25 E)
private theorem sat_1734 (E : Nat → Bool) : (valuation E).satisfies [.neg 2217, .neg 15] := by
  change (g2218 E = true) → (g16 E = true) → False
  exact pattern_19 (g5 E) (g16 E) (g25 E)
private theorem sat_1735 (E : Nat → Bool) : (valuation E).satisfies [.neg 2217, .neg 4] := by
  change (g2218 E = true) → (g5 E = true) → False
  exact pattern_20 (g5 E) (g16 E) (g25 E)
private theorem sat_1736 (E : Nat → Bool) : (valuation E).satisfies [.neg 2218, .neg 16] := by
  change (g2219 E = true) → (g17 E = true) → False
  exact pattern_19 (g6 E) (g17 E) (g27 E)
private theorem sat_1737 (E : Nat → Bool) : (valuation E).satisfies [.neg 2218, .neg 5] := by
  change (g2219 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g17 E) (g27 E)
private theorem sat_1738 (E : Nat → Bool) : (valuation E).satisfies [.neg 2219, .neg 7] := by
  change (g2220 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g19 E) (g29 E)
private theorem sat_1740 (E : Nat → Bool) : (valuation E).satisfies [.neg 8, .neg 1, .pos 2220] := by
  change (g9 E = true) → (g2 E = true) → (¬ (g2221 E = true)) → False
  exact pattern_15 (g2 E) (g9 E)
private theorem sat_1741 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 1, .pos 2221] := by
  change (g14 E = true) → (g2 E = true) → (¬ (g2222 E = true)) → False
  exact pattern_15 (g2 E) (g14 E)
private theorem sat_1742 (E : Nat → Bool) : (valuation E).satisfies [.neg 2222, .pos 8] := by
  change (g2223 E = true) → (¬ (g9 E = true)) → False
  exact pattern_1 (g9 E) (g14 E)
private theorem sat_1743 (E : Nat → Bool) : (valuation E).satisfies [.neg 2222, .pos 13] := by
  change (g2223 E = true) → (¬ (g14 E = true)) → False
  exact pattern_2 (g9 E) (g14 E)
private theorem sat_1744 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 8, .pos 2222] := by
  change (g14 E = true) → (g9 E = true) → (¬ (g2223 E = true)) → False
  exact pattern_15 (g9 E) (g14 E)
private theorem sat_1745 (E : Nat → Bool) : (valuation E).satisfies [.neg 2223, .neg 2222] := by
  change (g2224 E = true) → (g2223 E = true) → False
  exact pattern_18 (g2221 E) (g2222 E) (g2223 E)
private theorem sat_1746 (E : Nat → Bool) : (valuation E).satisfies [.neg 2223, .neg 2221] := by
  change (g2224 E = true) → (g2222 E = true) → False
  exact pattern_19 (g2221 E) (g2222 E) (g2223 E)
private theorem sat_1747 (E : Nat → Bool) : (valuation E).satisfies [.neg 2223, .neg 2220] := by
  change (g2224 E = true) → (g2221 E = true) → False
  exact pattern_20 (g2221 E) (g2222 E) (g2223 E)
private theorem sat_1748 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 3, .pos 2225] := by
  change (g23 E = true) → (g4 E = true) → (¬ (g2226 E = true)) → False
  exact pattern_15 (g4 E) (g23 E)
private theorem sat_1749 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 14, .pos 2226] := by
  change (g23 E = true) → (g15 E = true) → (¬ (g2227 E = true)) → False
  exact pattern_15 (g15 E) (g23 E)
private theorem sat_1750 (E : Nat → Bool) : (valuation E).satisfies [.neg 2227, .neg 2226] := by
  change (g2228 E = true) → (g2227 E = true) → False
  exact pattern_18 (g2225 E) (g2226 E) (g2227 E)
private theorem sat_1751 (E : Nat → Bool) : (valuation E).satisfies [.neg 2227, .neg 2225] := by
  change (g2228 E = true) → (g2226 E = true) → False
  exact pattern_19 (g2225 E) (g2226 E) (g2227 E)
private theorem sat_1752 (E : Nat → Bool) : (valuation E).satisfies [.neg 2228, .neg 25] := by
  change (g2229 E = true) → (g26 E = true) → False
  exact pattern_18 (g5 E) (g16 E) (g26 E)
private theorem sat_1753 (E : Nat → Bool) : (valuation E).satisfies [.neg 2228, .neg 15] := by
  change (g2229 E = true) → (g16 E = true) → False
  exact pattern_19 (g5 E) (g16 E) (g26 E)
private theorem sat_1754 (E : Nat → Bool) : (valuation E).satisfies [.neg 2229, .neg 16] := by
  change (g2230 E = true) → (g17 E = true) → False
  exact pattern_19 (g6 E) (g17 E) (g28 E)
private theorem sat_1755 (E : Nat → Bool) : (valuation E).satisfies [.neg 2229, .neg 5] := by
  change (g2230 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g17 E) (g28 E)
private theorem sat_1756 (E : Nat → Bool) : (valuation E).satisfies [.neg 2230, .neg 6] := by
  change (g2231 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g18 E) (g29 E)
private theorem sat_1758 (E : Nat → Bool) : (valuation E).satisfies [.neg 9, .neg 1, .pos 2231] := by
  change (g10 E = true) → (g2 E = true) → (¬ (g2232 E = true)) → False
  exact pattern_15 (g2 E) (g10 E)
private theorem sat_1759 (E : Nat → Bool) : (valuation E).satisfies [.neg 10, .neg 1, .pos 2232] := by
  change (g11 E = true) → (g2 E = true) → (¬ (g2233 E = true)) → False
  exact pattern_15 (g2 E) (g11 E)
private theorem sat_1760 (E : Nat → Bool) : (valuation E).satisfies [.neg 10, .neg 9, .pos 2233] := by
  change (g11 E = true) → (g10 E = true) → (¬ (g2234 E = true)) → False
  exact pattern_15 (g10 E) (g11 E)
private theorem sat_1761 (E : Nat → Bool) : (valuation E).satisfies [.neg 2234, .neg 2233] := by
  change (g2235 E = true) → (g2234 E = true) → False
  exact pattern_18 (g2232 E) (g2233 E) (g2234 E)
private theorem sat_1762 (E : Nat → Bool) : (valuation E).satisfies [.neg 2234, .neg 2232] := by
  change (g2235 E = true) → (g2233 E = true) → False
  exact pattern_19 (g2232 E) (g2233 E) (g2234 E)
private theorem sat_1763 (E : Nat → Bool) : (valuation E).satisfies [.neg 2234, .neg 2231] := by
  change (g2235 E = true) → (g2232 E = true) → False
  exact pattern_20 (g2232 E) (g2233 E) (g2234 E)
private theorem sat_1764 (E : Nat → Bool) : (valuation E).satisfies [.neg 14, .neg 2, .pos 2235] := by
  change (g15 E = true) → (g3 E = true) → (¬ (g2236 E = true)) → False
  exact pattern_15 (g3 E) (g15 E)
private theorem sat_1765 (E : Nat → Bool) : (valuation E).satisfies [.neg 15, .neg 2, .pos 2236] := by
  change (g16 E = true) → (g3 E = true) → (¬ (g2237 E = true)) → False
  exact pattern_15 (g3 E) (g16 E)
private theorem sat_1766 (E : Nat → Bool) : (valuation E).satisfies [.neg 15, .neg 14, .pos 2237] := by
  change (g16 E = true) → (g15 E = true) → (¬ (g2238 E = true)) → False
  exact pattern_15 (g15 E) (g16 E)
private theorem sat_1767 (E : Nat → Bool) : (valuation E).satisfies [.neg 2238, .neg 2237] := by
  change (g2239 E = true) → (g2238 E = true) → False
  exact pattern_18 (g2236 E) (g2237 E) (g2238 E)
private theorem sat_1768 (E : Nat → Bool) : (valuation E).satisfies [.neg 2238, .neg 2236] := by
  change (g2239 E = true) → (g2237 E = true) → False
  exact pattern_19 (g2236 E) (g2237 E) (g2238 E)
private theorem sat_1769 (E : Nat → Bool) : (valuation E).satisfies [.neg 2238, .neg 2235] := by
  change (g2239 E = true) → (g2236 E = true) → False
  exact pattern_20 (g2236 E) (g2237 E) (g2238 E)
private theorem sat_1770 (E : Nat → Bool) : (valuation E).satisfies [.neg 2239, .neg 20] := by
  change (g2240 E = true) → (g21 E = true) → False
  exact pattern_19 (g6 E) (g21 E) (g24 E)
private theorem sat_1771 (E : Nat → Bool) : (valuation E).satisfies [.neg 2239, .neg 5] := by
  change (g2240 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g21 E) (g24 E)
private theorem sat_1772 (E : Nat → Bool) : (valuation E).satisfies [.neg 2240, .neg 21] := by
  change (g2241 E = true) → (g22 E = true) → False
  exact pattern_19 (g7 E) (g22 E) (g25 E)
private theorem sat_1773 (E : Nat → Bool) : (valuation E).satisfies [.neg 2240, .neg 6] := by
  change (g2241 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g22 E) (g25 E)
private theorem sat_1774 (E : Nat → Bool) : (valuation E).satisfies [.neg 2241, .neg 7] := by
  change (g2242 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g23 E) (g26 E)
private theorem sat_1776 (E : Nat → Bool) : (valuation E).satisfies [.neg 9, .neg 1, .pos 2242] := by
  change (g10 E = true) → (g2 E = true) → (¬ (g2243 E = true)) → False
  exact pattern_15 (g2 E) (g10 E)
private theorem sat_1777 (E : Nat → Bool) : (valuation E).satisfies [.neg 11, .neg 1, .pos 2243] := by
  change (g12 E = true) → (g2 E = true) → (¬ (g2244 E = true)) → False
  exact pattern_15 (g2 E) (g12 E)
private theorem sat_1778 (E : Nat → Bool) : (valuation E).satisfies [.neg 11, .neg 9, .pos 2244] := by
  change (g12 E = true) → (g10 E = true) → (¬ (g2245 E = true)) → False
  exact pattern_15 (g10 E) (g12 E)
private theorem sat_1779 (E : Nat → Bool) : (valuation E).satisfies [.neg 2245, .neg 2244] := by
  change (g2246 E = true) → (g2245 E = true) → False
  exact pattern_18 (g2243 E) (g2244 E) (g2245 E)
private theorem sat_1780 (E : Nat → Bool) : (valuation E).satisfies [.neg 2245, .neg 2243] := by
  change (g2246 E = true) → (g2244 E = true) → False
  exact pattern_19 (g2243 E) (g2244 E) (g2245 E)
private theorem sat_1781 (E : Nat → Bool) : (valuation E).satisfies [.neg 2245, .neg 2242] := by
  change (g2246 E = true) → (g2243 E = true) → False
  exact pattern_20 (g2243 E) (g2244 E) (g2245 E)
private theorem sat_1782 (E : Nat → Bool) : (valuation E).satisfies [.neg 14, .neg 2, .pos 2246] := by
  change (g15 E = true) → (g3 E = true) → (¬ (g2247 E = true)) → False
  exact pattern_15 (g3 E) (g15 E)
private theorem sat_1783 (E : Nat → Bool) : (valuation E).satisfies [.neg 2247, .pos 16] := by
  change (g2248 E = true) → (¬ (g17 E = true)) → False
  exact pattern_2 (g3 E) (g17 E)
private theorem sat_1784 (E : Nat → Bool) : (valuation E).satisfies [.neg 16, .neg 2, .pos 2247] := by
  change (g17 E = true) → (g3 E = true) → (¬ (g2248 E = true)) → False
  exact pattern_15 (g3 E) (g17 E)
private theorem sat_1785 (E : Nat → Bool) : (valuation E).satisfies [.neg 2248, .pos 14] := by
  change (g2249 E = true) → (¬ (g15 E = true)) → False
  exact pattern_1 (g15 E) (g17 E)
private theorem sat_1786 (E : Nat → Bool) : (valuation E).satisfies [.neg 16, .neg 14, .pos 2248] := by
  change (g17 E = true) → (g15 E = true) → (¬ (g2249 E = true)) → False
  exact pattern_15 (g15 E) (g17 E)
private theorem sat_1787 (E : Nat → Bool) : (valuation E).satisfies [.neg 2249, .neg 2248] := by
  change (g2250 E = true) → (g2249 E = true) → False
  exact pattern_18 (g2247 E) (g2248 E) (g2249 E)
private theorem sat_1788 (E : Nat → Bool) : (valuation E).satisfies [.neg 2249, .neg 2247] := by
  change (g2250 E = true) → (g2248 E = true) → False
  exact pattern_19 (g2247 E) (g2248 E) (g2249 E)
private theorem sat_1789 (E : Nat → Bool) : (valuation E).satisfies [.neg 2249, .neg 2246] := by
  change (g2250 E = true) → (g2247 E = true) → False
  exact pattern_20 (g2247 E) (g2248 E) (g2249 E)
private theorem sat_1790 (E : Nat → Bool) : (valuation E).satisfies [.neg 2250, .neg 23] := by
  change (g2251 E = true) → (g24 E = true) → False
  exact pattern_18 (g5 E) (g20 E) (g24 E)
private theorem sat_1791 (E : Nat → Bool) : (valuation E).satisfies [.neg 2250, .neg 19] := by
  change (g2251 E = true) → (g20 E = true) → False
  exact pattern_19 (g5 E) (g20 E) (g24 E)
private theorem sat_1792 (E : Nat → Bool) : (valuation E).satisfies [.neg 2251, .neg 26] := by
  change (g2252 E = true) → (g27 E = true) → False
  exact pattern_18 (g7 E) (g22 E) (g27 E)
private theorem sat_1793 (E : Nat → Bool) : (valuation E).satisfies [.neg 2251, .neg 21] := by
  change (g2252 E = true) → (g22 E = true) → False
  exact pattern_19 (g7 E) (g22 E) (g27 E)
private theorem sat_1794 (E : Nat → Bool) : (valuation E).satisfies [.neg 2251, .neg 6] := by
  change (g2252 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g22 E) (g27 E)
private theorem sat_1795 (E : Nat → Bool) : (valuation E).satisfies [.neg 2252, .neg 27] := by
  change (g2253 E = true) → (g28 E = true) → False
  exact pattern_18 (g8 E) (g23 E) (g28 E)
private theorem sat_1796 (E : Nat → Bool) : (valuation E).satisfies [.neg 2252, .neg 7] := by
  change (g2253 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g23 E) (g28 E)
private theorem sat_1798 (E : Nat → Bool) : (valuation E).satisfies [.neg 9, .neg 1, .pos 2253] := by
  change (g10 E = true) → (g2 E = true) → (¬ (g2254 E = true)) → False
  exact pattern_15 (g2 E) (g10 E)
private theorem sat_1799 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 1, .pos 2254] := by
  change (g13 E = true) → (g2 E = true) → (¬ (g2255 E = true)) → False
  exact pattern_15 (g2 E) (g13 E)
private theorem sat_1800 (E : Nat → Bool) : (valuation E).satisfies [.neg 2255, .pos 12] := by
  change (g2256 E = true) → (¬ (g13 E = true)) → False
  exact pattern_2 (g10 E) (g13 E)
private theorem sat_1801 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 9, .pos 2255] := by
  change (g13 E = true) → (g10 E = true) → (¬ (g2256 E = true)) → False
  exact pattern_15 (g10 E) (g13 E)
private theorem sat_1802 (E : Nat → Bool) : (valuation E).satisfies [.neg 2256, .neg 2255] := by
  change (g2257 E = true) → (g2256 E = true) → False
  exact pattern_18 (g2254 E) (g2255 E) (g2256 E)
private theorem sat_1803 (E : Nat → Bool) : (valuation E).satisfies [.neg 2256, .neg 2254] := by
  change (g2257 E = true) → (g2255 E = true) → False
  exact pattern_19 (g2254 E) (g2255 E) (g2256 E)
private theorem sat_1804 (E : Nat → Bool) : (valuation E).satisfies [.neg 2256, .neg 2253] := by
  change (g2257 E = true) → (g2254 E = true) → False
  exact pattern_20 (g2254 E) (g2255 E) (g2256 E)
private theorem sat_1805 (E : Nat → Bool) : (valuation E).satisfies [.neg 14, .neg 2, .pos 2257] := by
  change (g15 E = true) → (g3 E = true) → (¬ (g2258 E = true)) → False
  exact pattern_15 (g3 E) (g15 E)
private theorem sat_1806 (E : Nat → Bool) : (valuation E).satisfies [.neg 2258, .pos 2] := by
  change (g2259 E = true) → (¬ (g3 E = true)) → False
  exact pattern_1 (g3 E) (g18 E)
private theorem sat_1807 (E : Nat → Bool) : (valuation E).satisfies [.neg 17, .neg 2, .pos 2258] := by
  change (g18 E = true) → (g3 E = true) → (¬ (g2259 E = true)) → False
  exact pattern_15 (g3 E) (g18 E)
private theorem sat_1808 (E : Nat → Bool) : (valuation E).satisfies [.neg 17, .neg 14, .pos 2259] := by
  change (g18 E = true) → (g15 E = true) → (¬ (g2260 E = true)) → False
  exact pattern_15 (g15 E) (g18 E)
private theorem sat_1809 (E : Nat → Bool) : (valuation E).satisfies [.neg 2260, .neg 2259] := by
  change (g2261 E = true) → (g2260 E = true) → False
  exact pattern_18 (g2258 E) (g2259 E) (g2260 E)
private theorem sat_1810 (E : Nat → Bool) : (valuation E).satisfies [.neg 2260, .neg 2258] := by
  change (g2261 E = true) → (g2259 E = true) → False
  exact pattern_19 (g2258 E) (g2259 E) (g2260 E)
private theorem sat_1811 (E : Nat → Bool) : (valuation E).satisfies [.neg 2260, .neg 2257] := by
  change (g2261 E = true) → (g2258 E = true) → False
  exact pattern_20 (g2258 E) (g2259 E) (g2260 E)
private theorem sat_1812 (E : Nat → Bool) : (valuation E).satisfies [.neg 2261, .neg 24] := by
  change (g2262 E = true) → (g25 E = true) → False
  exact pattern_18 (g5 E) (g20 E) (g25 E)
private theorem sat_1813 (E : Nat → Bool) : (valuation E).satisfies [.neg 2261, .neg 19] := by
  change (g2262 E = true) → (g20 E = true) → False
  exact pattern_19 (g5 E) (g20 E) (g25 E)
private theorem sat_1814 (E : Nat → Bool) : (valuation E).satisfies [.neg 2261, .neg 4] := by
  change (g2262 E = true) → (g5 E = true) → False
  exact pattern_20 (g5 E) (g20 E) (g25 E)
private theorem sat_1815 (E : Nat → Bool) : (valuation E).satisfies [.neg 2262, .neg 26] := by
  change (g2263 E = true) → (g27 E = true) → False
  exact pattern_18 (g6 E) (g21 E) (g27 E)
private theorem sat_1816 (E : Nat → Bool) : (valuation E).satisfies [.neg 2262, .neg 20] := by
  change (g2263 E = true) → (g21 E = true) → False
  exact pattern_19 (g6 E) (g21 E) (g27 E)
private theorem sat_1817 (E : Nat → Bool) : (valuation E).satisfies [.neg 2262, .neg 5] := by
  change (g2263 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g21 E) (g27 E)
private theorem sat_1818 (E : Nat → Bool) : (valuation E).satisfies [.neg 2263, .neg 28] := by
  change (g2264 E = true) → (g29 E = true) → False
  exact pattern_18 (g8 E) (g23 E) (g29 E)
private theorem sat_1819 (E : Nat → Bool) : (valuation E).satisfies [.neg 2263, .neg 7] := by
  change (g2264 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g23 E) (g29 E)
private theorem sat_1821 (E : Nat → Bool) : (valuation E).satisfies [.neg 9, .neg 1, .pos 2264] := by
  change (g10 E = true) → (g2 E = true) → (¬ (g2265 E = true)) → False
  exact pattern_15 (g2 E) (g10 E)
private theorem sat_1822 (E : Nat → Bool) : (valuation E).satisfies [.neg 2265, .pos 1] := by
  change (g2266 E = true) → (¬ (g2 E = true)) → False
  exact pattern_1 (g2 E) (g14 E)
private theorem sat_1823 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 1, .pos 2265] := by
  change (g14 E = true) → (g2 E = true) → (¬ (g2266 E = true)) → False
  exact pattern_15 (g2 E) (g14 E)
private theorem sat_1824 (E : Nat → Bool) : (valuation E).satisfies [.neg 2266, .pos 9] := by
  change (g2267 E = true) → (¬ (g10 E = true)) → False
  exact pattern_1 (g10 E) (g14 E)
private theorem sat_1825 (E : Nat → Bool) : (valuation E).satisfies [.neg 2266, .pos 13] := by
  change (g2267 E = true) → (¬ (g14 E = true)) → False
  exact pattern_2 (g10 E) (g14 E)
private theorem sat_1826 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 9, .pos 2266] := by
  change (g14 E = true) → (g10 E = true) → (¬ (g2267 E = true)) → False
  exact pattern_15 (g10 E) (g14 E)
private theorem sat_1827 (E : Nat → Bool) : (valuation E).satisfies [.neg 2267, .neg 2266] := by
  change (g2268 E = true) → (g2267 E = true) → False
  exact pattern_18 (g2265 E) (g2266 E) (g2267 E)
private theorem sat_1828 (E : Nat → Bool) : (valuation E).satisfies [.neg 2267, .neg 2265] := by
  change (g2268 E = true) → (g2266 E = true) → False
  exact pattern_19 (g2265 E) (g2266 E) (g2267 E)
private theorem sat_1829 (E : Nat → Bool) : (valuation E).satisfies [.neg 2267, .neg 2264] := by
  change (g2268 E = true) → (g2265 E = true) → False
  exact pattern_20 (g2265 E) (g2266 E) (g2267 E)
private theorem sat_1830 (E : Nat → Bool) : (valuation E).satisfies [.neg 2268, .pos 2] := by
  change (g2269 E = true) → (¬ (g3 E = true)) → False
  exact pattern_1 (g3 E) (g15 E)
private theorem sat_1831 (E : Nat → Bool) : (valuation E).satisfies [.neg 2268, .pos 14] := by
  change (g2269 E = true) → (¬ (g15 E = true)) → False
  exact pattern_2 (g3 E) (g15 E)
private theorem sat_1832 (E : Nat → Bool) : (valuation E).satisfies [.neg 14, .neg 2, .pos 2268] := by
  change (g15 E = true) → (g3 E = true) → (¬ (g2269 E = true)) → False
  exact pattern_15 (g3 E) (g15 E)
private theorem sat_1833 (E : Nat → Bool) : (valuation E).satisfies [.neg 2269, .pos 2] := by
  change (g2270 E = true) → (¬ (g3 E = true)) → False
  exact pattern_1 (g3 E) (g19 E)
private theorem sat_1834 (E : Nat → Bool) : (valuation E).satisfies [.neg 2269, .pos 18] := by
  change (g2270 E = true) → (¬ (g19 E = true)) → False
  exact pattern_2 (g3 E) (g19 E)
private theorem sat_1835 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 2, .pos 2269] := by
  change (g19 E = true) → (g3 E = true) → (¬ (g2270 E = true)) → False
  exact pattern_15 (g3 E) (g19 E)
private theorem sat_1836 (E : Nat → Bool) : (valuation E).satisfies [.neg 2270, .pos 14] := by
  change (g2271 E = true) → (¬ (g15 E = true)) → False
  exact pattern_1 (g15 E) (g19 E)
private theorem sat_1837 (E : Nat → Bool) : (valuation E).satisfies [.neg 2270, .pos 18] := by
  change (g2271 E = true) → (¬ (g19 E = true)) → False
  exact pattern_2 (g15 E) (g19 E)
private theorem sat_1838 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 14, .pos 2270] := by
  change (g19 E = true) → (g15 E = true) → (¬ (g2271 E = true)) → False
  exact pattern_15 (g15 E) (g19 E)
private theorem sat_1839 (E : Nat → Bool) : (valuation E).satisfies [.neg 2271, .neg 2270] := by
  change (g2272 E = true) → (g2271 E = true) → False
  exact pattern_18 (g2269 E) (g2270 E) (g2271 E)
private theorem sat_1840 (E : Nat → Bool) : (valuation E).satisfies [.neg 2271, .neg 2269] := by
  change (g2272 E = true) → (g2270 E = true) → False
  exact pattern_19 (g2269 E) (g2270 E) (g2271 E)
private theorem sat_1841 (E : Nat → Bool) : (valuation E).satisfies [.neg 2271, .neg 2268] := by
  change (g2272 E = true) → (g2269 E = true) → False
  exact pattern_20 (g2269 E) (g2270 E) (g2271 E)
private theorem sat_1842 (E : Nat → Bool) : (valuation E).satisfies [.pos 2268, .pos 2269, .pos 2270, .pos 2271] := by
  change (¬ (g2269 E = true)) → (¬ (g2270 E = true)) → (¬ (g2271 E = true)) → (¬ (g2272 E = true)) → False
  exact pattern_21 (g2269 E) (g2270 E) (g2271 E)
private theorem sat_1843 (E : Nat → Bool) : (valuation E).satisfies [.neg 2272, .neg 25] := by
  change (g2273 E = true) → (g26 E = true) → False
  exact pattern_18 (g5 E) (g20 E) (g26 E)
private theorem sat_1844 (E : Nat → Bool) : (valuation E).satisfies [.neg 2272, .neg 19] := by
  change (g2273 E = true) → (g20 E = true) → False
  exact pattern_19 (g5 E) (g20 E) (g26 E)
private theorem sat_1845 (E : Nat → Bool) : (valuation E).satisfies [.neg 2272, .neg 4] := by
  change (g2273 E = true) → (g5 E = true) → False
  exact pattern_20 (g5 E) (g20 E) (g26 E)
private theorem sat_1846 (E : Nat → Bool) : (valuation E).satisfies [.pos 4, .pos 19, .pos 25, .pos 2272] := by
  change (¬ (g5 E = true)) → (¬ (g20 E = true)) → (¬ (g26 E = true)) → (¬ (g2273 E = true)) → False
  exact pattern_21 (g5 E) (g20 E) (g26 E)
private theorem sat_1847 (E : Nat → Bool) : (valuation E).satisfies [.neg 2273, .neg 27] := by
  change (g2274 E = true) → (g28 E = true) → False
  exact pattern_18 (g6 E) (g21 E) (g28 E)
private theorem sat_1848 (E : Nat → Bool) : (valuation E).satisfies [.neg 2273, .neg 20] := by
  change (g2274 E = true) → (g21 E = true) → False
  exact pattern_19 (g6 E) (g21 E) (g28 E)
private theorem sat_1849 (E : Nat → Bool) : (valuation E).satisfies [.neg 2273, .neg 5] := by
  change (g2274 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g21 E) (g28 E)
private theorem sat_1850 (E : Nat → Bool) : (valuation E).satisfies [.neg 2274, .neg 6] := by
  change (g2275 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g22 E) (g29 E)
private theorem sat_1852 (E : Nat → Bool) : (valuation E).satisfies [.neg 11, .neg 1, .pos 2276] := by
  change (g12 E = true) → (g2 E = true) → (¬ (g2277 E = true)) → False
  exact pattern_15 (g2 E) (g12 E)
private theorem sat_1853 (E : Nat → Bool) : (valuation E).satisfies [.neg 11, .neg 10, .pos 2277] := by
  change (g12 E = true) → (g11 E = true) → (¬ (g2278 E = true)) → False
  exact pattern_15 (g11 E) (g12 E)
private theorem sat_1854 (E : Nat → Bool) : (valuation E).satisfies [.neg 2278, .neg 2277] := by
  change (g2279 E = true) → (g2278 E = true) → False
  exact pattern_18 (g2276 E) (g2277 E) (g2278 E)
private theorem sat_1855 (E : Nat → Bool) : (valuation E).satisfies [.neg 2278, .neg 2276] := by
  change (g2279 E = true) → (g2277 E = true) → False
  exact pattern_19 (g2276 E) (g2277 E) (g2278 E)
private theorem sat_1856 (E : Nat → Bool) : (valuation E).satisfies [.neg 15, .neg 2, .pos 2279] := by
  change (g16 E = true) → (g3 E = true) → (¬ (g2280 E = true)) → False
  exact pattern_15 (g3 E) (g16 E)
private theorem sat_1857 (E : Nat → Bool) : (valuation E).satisfies [.neg 16, .neg 2, .pos 2280] := by
  change (g17 E = true) → (g3 E = true) → (¬ (g2281 E = true)) → False
  exact pattern_15 (g3 E) (g17 E)
private theorem sat_1858 (E : Nat → Bool) : (valuation E).satisfies [.neg 2281, .pos 15] := by
  change (g2282 E = true) → (¬ (g16 E = true)) → False
  exact pattern_1 (g16 E) (g17 E)
private theorem sat_1859 (E : Nat → Bool) : (valuation E).satisfies [.neg 2281, .pos 16] := by
  change (g2282 E = true) → (¬ (g17 E = true)) → False
  exact pattern_2 (g16 E) (g17 E)
private theorem sat_1860 (E : Nat → Bool) : (valuation E).satisfies [.neg 16, .neg 15, .pos 2281] := by
  change (g17 E = true) → (g16 E = true) → (¬ (g2282 E = true)) → False
  exact pattern_15 (g16 E) (g17 E)
private theorem sat_1861 (E : Nat → Bool) : (valuation E).satisfies [.neg 2282, .neg 2281] := by
  change (g2283 E = true) → (g2282 E = true) → False
  exact pattern_18 (g2280 E) (g2281 E) (g2282 E)
private theorem sat_1862 (E : Nat → Bool) : (valuation E).satisfies [.neg 2282, .neg 2280] := by
  change (g2283 E = true) → (g2281 E = true) → False
  exact pattern_19 (g2280 E) (g2281 E) (g2282 E)
private theorem sat_1863 (E : Nat → Bool) : (valuation E).satisfies [.neg 2282, .neg 2279] := by
  change (g2283 E = true) → (g2280 E = true) → False
  exact pattern_20 (g2280 E) (g2281 E) (g2282 E)
private theorem sat_1864 (E : Nat → Bool) : (valuation E).satisfies [.neg 19, .neg 3, .pos 2283] := by
  change (g20 E = true) → (g4 E = true) → (¬ (g2284 E = true)) → False
  exact pattern_15 (g4 E) (g20 E)
private theorem sat_1865 (E : Nat → Bool) : (valuation E).satisfies [.neg 20, .neg 3, .pos 2284] := by
  change (g21 E = true) → (g4 E = true) → (¬ (g2285 E = true)) → False
  exact pattern_15 (g4 E) (g21 E)
private theorem sat_1866 (E : Nat → Bool) : (valuation E).satisfies [.neg 20, .neg 19, .pos 2285] := by
  change (g21 E = true) → (g20 E = true) → (¬ (g2286 E = true)) → False
  exact pattern_15 (g20 E) (g21 E)
private theorem sat_1867 (E : Nat → Bool) : (valuation E).satisfies [.neg 2286, .neg 2285] := by
  change (g2287 E = true) → (g2286 E = true) → False
  exact pattern_18 (g2284 E) (g2285 E) (g2286 E)
private theorem sat_1868 (E : Nat → Bool) : (valuation E).satisfies [.neg 2286, .neg 2284] := by
  change (g2287 E = true) → (g2285 E = true) → False
  exact pattern_19 (g2284 E) (g2285 E) (g2286 E)
private theorem sat_1869 (E : Nat → Bool) : (valuation E).satisfies [.neg 2286, .neg 2283] := by
  change (g2287 E = true) → (g2284 E = true) → False
  exact pattern_20 (g2284 E) (g2285 E) (g2286 E)
private theorem sat_1870 (E : Nat → Bool) : (valuation E).satisfies [.neg 2287, .neg 6] := by
  change (g2288 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g25 E) (g27 E)
private theorem sat_1871 (E : Nat → Bool) : (valuation E).satisfies [.neg 2288, .neg 7] := by
  change (g2289 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g26 E) (g28 E)
private theorem sat_1873 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 10, .pos 2291] := by
  change (g13 E = true) → (g11 E = true) → (¬ (g2292 E = true)) → False
  exact pattern_15 (g11 E) (g13 E)
private theorem sat_1874 (E : Nat → Bool) : (valuation E).satisfies [.neg 2292, .neg 2291] := by
  change (g2293 E = true) → (g2292 E = true) → False
  exact pattern_18 (g2290 E) (g2291 E) (g2292 E)
private theorem sat_1875 (E : Nat → Bool) : (valuation E).satisfies [.neg 15, .neg 2, .pos 2293] := by
  change (g16 E = true) → (g3 E = true) → (¬ (g2294 E = true)) → False
  exact pattern_15 (g3 E) (g16 E)
private theorem sat_1876 (E : Nat → Bool) : (valuation E).satisfies [.neg 17, .neg 15, .pos 2295] := by
  change (g18 E = true) → (g16 E = true) → (¬ (g2296 E = true)) → False
  exact pattern_15 (g16 E) (g18 E)
private theorem sat_1877 (E : Nat → Bool) : (valuation E).satisfies [.neg 2296, .neg 2295] := by
  change (g2297 E = true) → (g2296 E = true) → False
  exact pattern_18 (g2294 E) (g2295 E) (g2296 E)
private theorem sat_1878 (E : Nat → Bool) : (valuation E).satisfies [.neg 2296, .neg 2293] := by
  change (g2297 E = true) → (g2294 E = true) → False
  exact pattern_20 (g2294 E) (g2295 E) (g2296 E)
private theorem sat_1879 (E : Nat → Bool) : (valuation E).satisfies [.neg 21, .neg 3, .pos 2298] := by
  change (g22 E = true) → (g4 E = true) → (¬ (g2299 E = true)) → False
  exact pattern_15 (g4 E) (g22 E)
private theorem sat_1880 (E : Nat → Bool) : (valuation E).satisfies [.neg 21, .neg 19, .pos 2299] := by
  change (g22 E = true) → (g20 E = true) → (¬ (g2300 E = true)) → False
  exact pattern_15 (g20 E) (g22 E)
private theorem sat_1881 (E : Nat → Bool) : (valuation E).satisfies [.neg 2300, .neg 2299] := by
  change (g2301 E = true) → (g2300 E = true) → False
  exact pattern_18 (g2298 E) (g2299 E) (g2300 E)
private theorem sat_1882 (E : Nat → Bool) : (valuation E).satisfies [.neg 2300, .neg 2298] := by
  change (g2301 E = true) → (g2299 E = true) → False
  exact pattern_19 (g2298 E) (g2299 E) (g2300 E)
private theorem sat_1883 (E : Nat → Bool) : (valuation E).satisfies [.neg 2301, .neg 5] := by
  change (g2302 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g24 E) (g27 E)
private theorem sat_1884 (E : Nat → Bool) : (valuation E).satisfies [.neg 2302, .neg 7] := by
  change (g2303 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g26 E) (g29 E)
private theorem sat_1886 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 10, .pos 2305] := by
  change (g14 E = true) → (g11 E = true) → (¬ (g2306 E = true)) → False
  exact pattern_15 (g11 E) (g14 E)
private theorem sat_1887 (E : Nat → Bool) : (valuation E).satisfies [.neg 2306, .neg 2305] := by
  change (g2307 E = true) → (g2306 E = true) → False
  exact pattern_18 (g2304 E) (g2305 E) (g2306 E)
private theorem sat_1888 (E : Nat → Bool) : (valuation E).satisfies [.neg 15, .neg 2, .pos 2307] := by
  change (g16 E = true) → (g3 E = true) → (¬ (g2308 E = true)) → False
  exact pattern_15 (g3 E) (g16 E)
private theorem sat_1889 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 2, .pos 2308] := by
  change (g19 E = true) → (g3 E = true) → (¬ (g2309 E = true)) → False
  exact pattern_15 (g3 E) (g19 E)
private theorem sat_1890 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 15, .pos 2309] := by
  change (g19 E = true) → (g16 E = true) → (¬ (g2310 E = true)) → False
  exact pattern_15 (g16 E) (g19 E)
private theorem sat_1891 (E : Nat → Bool) : (valuation E).satisfies [.neg 2310, .neg 2309] := by
  change (g2311 E = true) → (g2310 E = true) → False
  exact pattern_18 (g2308 E) (g2309 E) (g2310 E)
private theorem sat_1892 (E : Nat → Bool) : (valuation E).satisfies [.neg 2310, .neg 2308] := by
  change (g2311 E = true) → (g2309 E = true) → False
  exact pattern_19 (g2308 E) (g2309 E) (g2310 E)
private theorem sat_1893 (E : Nat → Bool) : (valuation E).satisfies [.neg 2310, .neg 2307] := by
  change (g2311 E = true) → (g2308 E = true) → False
  exact pattern_20 (g2308 E) (g2309 E) (g2310 E)
private theorem sat_1894 (E : Nat → Bool) : (valuation E).satisfies [.neg 19, .neg 3, .pos 2311] := by
  change (g20 E = true) → (g4 E = true) → (¬ (g2312 E = true)) → False
  exact pattern_15 (g4 E) (g20 E)
private theorem sat_1895 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 19, .pos 2313] := by
  change (g23 E = true) → (g20 E = true) → (¬ (g2314 E = true)) → False
  exact pattern_15 (g20 E) (g23 E)
private theorem sat_1896 (E : Nat → Bool) : (valuation E).satisfies [.neg 2314, .neg 2313] := by
  change (g2315 E = true) → (g2314 E = true) → False
  exact pattern_18 (g2312 E) (g2313 E) (g2314 E)
private theorem sat_1897 (E : Nat → Bool) : (valuation E).satisfies [.neg 2314, .neg 2311] := by
  change (g2315 E = true) → (g2312 E = true) → False
  exact pattern_20 (g2312 E) (g2313 E) (g2314 E)
private theorem sat_1898 (E : Nat → Bool) : (valuation E).satisfies [.neg 2315, .neg 27] := by
  change (g2316 E = true) → (g28 E = true) → False
  exact pattern_18 (g6 E) (g24 E) (g28 E)
private theorem sat_1899 (E : Nat → Bool) : (valuation E).satisfies [.neg 2315, .neg 5] := by
  change (g2316 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g24 E) (g28 E)
private theorem sat_1900 (E : Nat → Bool) : (valuation E).satisfies [.neg 2316, .neg 6] := by
  change (g2317 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g25 E) (g29 E)
private theorem sat_1902 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 11, .pos 2319] := by
  change (g13 E = true) → (g12 E = true) → (¬ (g2320 E = true)) → False
  exact pattern_15 (g12 E) (g13 E)
private theorem sat_1903 (E : Nat → Bool) : (valuation E).satisfies [.neg 2320, .neg 2319] := by
  change (g2321 E = true) → (g2320 E = true) → False
  exact pattern_18 (g2318 E) (g2319 E) (g2320 E)
private theorem sat_1904 (E : Nat → Bool) : (valuation E).satisfies [.neg 16, .neg 2, .pos 2321] := by
  change (g17 E = true) → (g3 E = true) → (¬ (g2322 E = true)) → False
  exact pattern_15 (g3 E) (g17 E)
private theorem sat_1905 (E : Nat → Bool) : (valuation E).satisfies [.neg 17, .neg 2, .pos 2322] := by
  change (g18 E = true) → (g3 E = true) → (¬ (g2323 E = true)) → False
  exact pattern_15 (g3 E) (g18 E)
private theorem sat_1906 (E : Nat → Bool) : (valuation E).satisfies [.neg 2324, .neg 2322] := by
  change (g2325 E = true) → (g2323 E = true) → False
  exact pattern_19 (g2322 E) (g2323 E) (g2324 E)
private theorem sat_1907 (E : Nat → Bool) : (valuation E).satisfies [.neg 2324, .neg 2321] := by
  change (g2325 E = true) → (g2322 E = true) → False
  exact pattern_20 (g2322 E) (g2323 E) (g2324 E)
private theorem sat_1908 (E : Nat → Bool) : (valuation E).satisfies [.neg 21, .neg 3, .pos 2326] := by
  change (g22 E = true) → (g4 E = true) → (¬ (g2327 E = true)) → False
  exact pattern_15 (g4 E) (g22 E)
private theorem sat_1909 (E : Nat → Bool) : (valuation E).satisfies [.neg 2328, .neg 2326] := by
  change (g2329 E = true) → (g2327 E = true) → False
  exact pattern_19 (g2326 E) (g2327 E) (g2328 E)
private theorem sat_1910 (E : Nat → Bool) : (valuation E).satisfies [.neg 2329, .neg 24] := by
  change (g2330 E = true) → (g25 E = true) → False
  exact pattern_18 (g5 E) (g24 E) (g25 E)
private theorem sat_1911 (E : Nat → Bool) : (valuation E).satisfies [.neg 2330, .neg 7] := by
  change (g2331 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g28 E) (g29 E)
private theorem sat_1913 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 1, .pos 2332] := by
  change (g14 E = true) → (g2 E = true) → (¬ (g2333 E = true)) → False
  exact pattern_15 (g2 E) (g14 E)
private theorem sat_1914 (E : Nat → Bool) : (valuation E).satisfies [.neg 2334, .neg 2332] := by
  change (g2335 E = true) → (g2333 E = true) → False
  exact pattern_19 (g2332 E) (g2333 E) (g2334 E)
private theorem sat_1915 (E : Nat → Bool) : (valuation E).satisfies [.neg 2337, .pos 16] := by
  change (g2338 E = true) → (¬ (g17 E = true)) → False
  exact pattern_1 (g17 E) (g19 E)
private theorem sat_1916 (E : Nat → Bool) : (valuation E).satisfies [.neg 2337, .pos 18] := by
  change (g2338 E = true) → (¬ (g19 E = true)) → False
  exact pattern_2 (g17 E) (g19 E)
private theorem sat_1917 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 16, .pos 2337] := by
  change (g19 E = true) → (g17 E = true) → (¬ (g2338 E = true)) → False
  exact pattern_15 (g17 E) (g19 E)
private theorem sat_1918 (E : Nat → Bool) : (valuation E).satisfies [.neg 2338, .neg 2337] := by
  change (g2339 E = true) → (g2338 E = true) → False
  exact pattern_18 (g2336 E) (g2337 E) (g2338 E)
private theorem sat_1919 (E : Nat → Bool) : (valuation E).satisfies [.neg 2339, .pos 3] := by
  change (g2340 E = true) → (¬ (g4 E = true)) → False
  exact pattern_1 (g4 E) (g21 E)
private theorem sat_1920 (E : Nat → Bool) : (valuation E).satisfies [.neg 2339, .pos 20] := by
  change (g2340 E = true) → (¬ (g21 E = true)) → False
  exact pattern_2 (g4 E) (g21 E)
private theorem sat_1921 (E : Nat → Bool) : (valuation E).satisfies [.neg 20, .neg 3, .pos 2339] := by
  change (g21 E = true) → (g4 E = true) → (¬ (g2340 E = true)) → False
  exact pattern_15 (g4 E) (g21 E)
private theorem sat_1922 (E : Nat → Bool) : (valuation E).satisfies [.neg 2340, .pos 3] := by
  change (g2341 E = true) → (¬ (g4 E = true)) → False
  exact pattern_1 (g4 E) (g23 E)
private theorem sat_1923 (E : Nat → Bool) : (valuation E).satisfies [.neg 2340, .pos 22] := by
  change (g2341 E = true) → (¬ (g23 E = true)) → False
  exact pattern_2 (g4 E) (g23 E)
private theorem sat_1924 (E : Nat → Bool) : (valuation E).satisfies [.neg 2341, .pos 20] := by
  change (g2342 E = true) → (¬ (g21 E = true)) → False
  exact pattern_1 (g21 E) (g23 E)
private theorem sat_1925 (E : Nat → Bool) : (valuation E).satisfies [.neg 2341, .pos 22] := by
  change (g2342 E = true) → (¬ (g23 E = true)) → False
  exact pattern_2 (g21 E) (g23 E)
private theorem sat_1926 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 20, .pos 2341] := by
  change (g23 E = true) → (g21 E = true) → (¬ (g2342 E = true)) → False
  exact pattern_15 (g21 E) (g23 E)
private theorem sat_1927 (E : Nat → Bool) : (valuation E).satisfies [.neg 2342, .neg 2341] := by
  change (g2343 E = true) → (g2342 E = true) → False
  exact pattern_18 (g2340 E) (g2341 E) (g2342 E)
private theorem sat_1928 (E : Nat → Bool) : (valuation E).satisfies [.neg 2342, .neg 2339] := by
  change (g2343 E = true) → (g2340 E = true) → False
  exact pattern_20 (g2340 E) (g2341 E) (g2342 E)
private theorem sat_1929 (E : Nat → Bool) : (valuation E).satisfies [.pos 2339, .pos 2340, .pos 2341, .pos 2342] := by
  change (¬ (g2340 E = true)) → (¬ (g2341 E = true)) → (¬ (g2342 E = true)) → (¬ (g2343 E = true)) → False
  exact pattern_21 (g2340 E) (g2341 E) (g2342 E)
private theorem sat_1930 (E : Nat → Bool) : (valuation E).satisfies [.neg 2343, .neg 25] := by
  change (g2344 E = true) → (g26 E = true) → False
  exact pattern_18 (g5 E) (g24 E) (g26 E)
private theorem sat_1931 (E : Nat → Bool) : (valuation E).satisfies [.neg 2344, .neg 6] := by
  change (g2345 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g27 E) (g29 E)
private theorem sat_1933 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 1, .pos 2346] := by
  change (g14 E = true) → (g2 E = true) → (¬ (g2347 E = true)) → False
  exact pattern_15 (g2 E) (g14 E)
private theorem sat_1934 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 12, .pos 2347] := by
  change (g14 E = true) → (g13 E = true) → (¬ (g2348 E = true)) → False
  exact pattern_15 (g13 E) (g14 E)
private theorem sat_1935 (E : Nat → Bool) : (valuation E).satisfies [.neg 2348, .neg 2347] := by
  change (g2349 E = true) → (g2348 E = true) → False
  exact pattern_18 (g2346 E) (g2347 E) (g2348 E)
private theorem sat_1936 (E : Nat → Bool) : (valuation E).satisfies [.neg 2348, .neg 2346] := by
  change (g2349 E = true) → (g2347 E = true) → False
  exact pattern_19 (g2346 E) (g2347 E) (g2348 E)
private theorem sat_1937 (E : Nat → Bool) : (valuation E).satisfies [.neg 2349, .pos 2] := by
  change (g2350 E = true) → (¬ (g3 E = true)) → False
  exact pattern_1 (g3 E) (g18 E)
private theorem sat_1938 (E : Nat → Bool) : (valuation E).satisfies [.neg 2349, .pos 17] := by
  change (g2350 E = true) → (¬ (g18 E = true)) → False
  exact pattern_2 (g3 E) (g18 E)
private theorem sat_1939 (E : Nat → Bool) : (valuation E).satisfies [.neg 17, .neg 2, .pos 2349] := by
  change (g18 E = true) → (g3 E = true) → (¬ (g2350 E = true)) → False
  exact pattern_15 (g3 E) (g18 E)
private theorem sat_1940 (E : Nat → Bool) : (valuation E).satisfies [.neg 2350, .pos 18] := by
  change (g2351 E = true) → (¬ (g19 E = true)) → False
  exact pattern_2 (g3 E) (g19 E)
private theorem sat_1941 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 2, .pos 2350] := by
  change (g19 E = true) → (g3 E = true) → (¬ (g2351 E = true)) → False
  exact pattern_15 (g3 E) (g19 E)
private theorem sat_1942 (E : Nat → Bool) : (valuation E).satisfies [.neg 2351, .pos 17] := by
  change (g2352 E = true) → (¬ (g18 E = true)) → False
  exact pattern_1 (g18 E) (g19 E)
private theorem sat_1943 (E : Nat → Bool) : (valuation E).satisfies [.neg 2351, .pos 18] := by
  change (g2352 E = true) → (¬ (g19 E = true)) → False
  exact pattern_2 (g18 E) (g19 E)
private theorem sat_1944 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 17, .pos 2351] := by
  change (g19 E = true) → (g18 E = true) → (¬ (g2352 E = true)) → False
  exact pattern_15 (g18 E) (g19 E)
private theorem sat_1945 (E : Nat → Bool) : (valuation E).satisfies [.neg 2352, .neg 2351] := by
  change (g2353 E = true) → (g2352 E = true) → False
  exact pattern_18 (g2350 E) (g2351 E) (g2352 E)
private theorem sat_1946 (E : Nat → Bool) : (valuation E).satisfies [.neg 2352, .neg 2350] := by
  change (g2353 E = true) → (g2351 E = true) → False
  exact pattern_19 (g2350 E) (g2351 E) (g2352 E)
private theorem sat_1947 (E : Nat → Bool) : (valuation E).satisfies [.neg 2352, .neg 2349] := by
  change (g2353 E = true) → (g2350 E = true) → False
  exact pattern_20 (g2350 E) (g2351 E) (g2352 E)
private theorem sat_1948 (E : Nat → Bool) : (valuation E).satisfies [.pos 2349, .pos 2350, .pos 2351, .pos 2352] := by
  change (¬ (g2350 E = true)) → (¬ (g2351 E = true)) → (¬ (g2352 E = true)) → (¬ (g2353 E = true)) → False
  exact pattern_21 (g2350 E) (g2351 E) (g2352 E)
private theorem sat_1949 (E : Nat → Bool) : (valuation E).satisfies [.neg 21, .neg 3, .pos 2353] := by
  change (g22 E = true) → (g4 E = true) → (¬ (g2354 E = true)) → False
  exact pattern_15 (g4 E) (g22 E)
private theorem sat_1950 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 21, .pos 2355] := by
  change (g23 E = true) → (g22 E = true) → (¬ (g2356 E = true)) → False
  exact pattern_15 (g22 E) (g23 E)
private theorem sat_1951 (E : Nat → Bool) : (valuation E).satisfies [.neg 2356, .neg 2355] := by
  change (g2357 E = true) → (g2356 E = true) → False
  exact pattern_18 (g2354 E) (g2355 E) (g2356 E)
private theorem sat_1952 (E : Nat → Bool) : (valuation E).satisfies [.neg 2356, .neg 2353] := by
  change (g2357 E = true) → (g2354 E = true) → False
  exact pattern_20 (g2354 E) (g2355 E) (g2356 E)
private theorem sat_1953 (E : Nat → Bool) : (valuation E).satisfies [.neg 2357, .neg 25] := by
  change (g2358 E = true) → (g26 E = true) → False
  exact pattern_18 (g5 E) (g25 E) (g26 E)
private theorem sat_1954 (E : Nat → Bool) : (valuation E).satisfies [.neg 2357, .neg 24] := by
  change (g2358 E = true) → (g25 E = true) → False
  exact pattern_19 (g5 E) (g25 E) (g26 E)
private theorem sat_1955 (E : Nat → Bool) : (valuation E).satisfies [.neg 2357, .neg 4] := by
  change (g2358 E = true) → (g5 E = true) → False
  exact pattern_20 (g5 E) (g25 E) (g26 E)
private theorem sat_1956 (E : Nat → Bool) : (valuation E).satisfies [.pos 4, .pos 24, .pos 25, .pos 2357] := by
  change (¬ (g5 E = true)) → (¬ (g25 E = true)) → (¬ (g26 E = true)) → (¬ (g2358 E = true)) → False
  exact pattern_21 (g5 E) (g25 E) (g26 E)
private theorem sat_1957 (E : Nat → Bool) : (valuation E).satisfies [.neg 2358, .neg 5] := by
  change (g2359 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g27 E) (g28 E)
private theorem sat_1959 (E : Nat → Bool) : (valuation E).satisfies [.neg 2359, .pos 1] := by
  change (g2360 E = true) → (¬ (g2 E = true)) → False
  exact pattern_1 (g2 E) (g3 E)
private theorem sat_1960 (E : Nat → Bool) : (valuation E).satisfies [.neg 2359, .pos 2] := by
  change (g2360 E = true) → (¬ (g3 E = true)) → False
  exact pattern_2 (g2 E) (g3 E)
private theorem sat_1961 (E : Nat → Bool) : (valuation E).satisfies [.neg 2, .neg 1, .pos 2359] := by
  change (g3 E = true) → (g2 E = true) → (¬ (g2360 E = true)) → False
  exact pattern_15 (g2 E) (g3 E)
private theorem sat_1962 (E : Nat → Bool) : (valuation E).satisfies [.neg 2360, .pos 1] := by
  change (g2361 E = true) → (¬ (g2 E = true)) → False
  exact pattern_1 (g2 E) (g4 E)
private theorem sat_1963 (E : Nat → Bool) : (valuation E).satisfies [.neg 2360, .pos 3] := by
  change (g2361 E = true) → (¬ (g4 E = true)) → False
  exact pattern_2 (g2 E) (g4 E)
private theorem sat_1964 (E : Nat → Bool) : (valuation E).satisfies [.neg 3, .neg 1, .pos 2360] := by
  change (g4 E = true) → (g2 E = true) → (¬ (g2361 E = true)) → False
  exact pattern_15 (g2 E) (g4 E)
private theorem sat_1965 (E : Nat → Bool) : (valuation E).satisfies [.neg 2361, .pos 2] := by
  change (g2362 E = true) → (¬ (g3 E = true)) → False
  exact pattern_1 (g3 E) (g4 E)
private theorem sat_1966 (E : Nat → Bool) : (valuation E).satisfies [.neg 2361, .pos 3] := by
  change (g2362 E = true) → (¬ (g4 E = true)) → False
  exact pattern_2 (g3 E) (g4 E)
private theorem sat_1967 (E : Nat → Bool) : (valuation E).satisfies [.neg 3, .neg 2, .pos 2361] := by
  change (g4 E = true) → (g3 E = true) → (¬ (g2362 E = true)) → False
  exact pattern_15 (g3 E) (g4 E)
private theorem sat_1968 (E : Nat → Bool) : (valuation E).satisfies [.neg 2362, .neg 2361] := by
  change (g2363 E = true) → (g2362 E = true) → False
  exact pattern_18 (g2360 E) (g2361 E) (g2362 E)
private theorem sat_1969 (E : Nat → Bool) : (valuation E).satisfies [.neg 2362, .neg 2360] := by
  change (g2363 E = true) → (g2361 E = true) → False
  exact pattern_19 (g2360 E) (g2361 E) (g2362 E)
private theorem sat_1970 (E : Nat → Bool) : (valuation E).satisfies [.neg 2362, .neg 2359] := by
  change (g2363 E = true) → (g2360 E = true) → False
  exact pattern_20 (g2360 E) (g2361 E) (g2362 E)
private theorem sat_1971 (E : Nat → Bool) : (valuation E).satisfies [.pos 2359, .pos 2360, .pos 2361, .pos 2362] := by
  change (¬ (g2360 E = true)) → (¬ (g2361 E = true)) → (¬ (g2362 E = true)) → (¬ (g2363 E = true)) → False
  exact pattern_21 (g2360 E) (g2361 E) (g2362 E)
private theorem sat_1972 (E : Nat → Bool) : (valuation E).satisfies [.neg 2363, .neg 19] := by
  change (g2364 E = true) → (g20 E = true) → False
  exact pattern_18 (g11 E) (g16 E) (g20 E)
private theorem sat_1973 (E : Nat → Bool) : (valuation E).satisfies [.neg 2363, .neg 15] := by
  change (g2364 E = true) → (g16 E = true) → False
  exact pattern_19 (g11 E) (g16 E) (g20 E)
private theorem sat_1974 (E : Nat → Bool) : (valuation E).satisfies [.neg 2363, .neg 10] := by
  change (g2364 E = true) → (g11 E = true) → False
  exact pattern_20 (g11 E) (g16 E) (g20 E)
private theorem sat_1975 (E : Nat → Bool) : (valuation E).satisfies [.pos 10, .pos 15, .pos 19, .pos 2363] := by
  change (¬ (g11 E = true)) → (¬ (g16 E = true)) → (¬ (g20 E = true)) → (¬ (g2364 E = true)) → False
  exact pattern_21 (g11 E) (g16 E) (g20 E)
private theorem sat_1976 (E : Nat → Bool) : (valuation E).satisfies [.neg 2364, .neg 20] := by
  change (g2365 E = true) → (g21 E = true) → False
  exact pattern_18 (g12 E) (g17 E) (g21 E)
private theorem sat_1977 (E : Nat → Bool) : (valuation E).satisfies [.neg 2364, .neg 16] := by
  change (g2365 E = true) → (g17 E = true) → False
  exact pattern_19 (g12 E) (g17 E) (g21 E)
private theorem sat_1978 (E : Nat → Bool) : (valuation E).satisfies [.neg 2364, .neg 11] := by
  change (g2365 E = true) → (g12 E = true) → False
  exact pattern_20 (g12 E) (g17 E) (g21 E)
private theorem sat_1979 (E : Nat → Bool) : (valuation E).satisfies [.neg 2365, .neg 21] := by
  change (g2366 E = true) → (g22 E = true) → False
  exact pattern_18 (g13 E) (g18 E) (g22 E)
private theorem sat_1980 (E : Nat → Bool) : (valuation E).satisfies [.neg 2365, .neg 17] := by
  change (g2366 E = true) → (g18 E = true) → False
  exact pattern_19 (g13 E) (g18 E) (g22 E)
private theorem sat_1981 (E : Nat → Bool) : (valuation E).satisfies [.neg 2365, .neg 12] := by
  change (g2366 E = true) → (g13 E = true) → False
  exact pattern_20 (g13 E) (g18 E) (g22 E)
private theorem sat_1982 (E : Nat → Bool) : (valuation E).satisfies [.neg 2366, .neg 22] := by
  change (g2367 E = true) → (g23 E = true) → False
  exact pattern_18 (g14 E) (g19 E) (g23 E)
private theorem sat_1983 (E : Nat → Bool) : (valuation E).satisfies [.neg 2366, .neg 18] := by
  change (g2367 E = true) → (g19 E = true) → False
  exact pattern_19 (g14 E) (g19 E) (g23 E)
private theorem sat_1984 (E : Nat → Bool) : (valuation E).satisfies [.neg 2366, .neg 13] := by
  change (g2367 E = true) → (g14 E = true) → False
  exact pattern_20 (g14 E) (g19 E) (g23 E)
private theorem sat_1986 (E : Nat → Bool) : (valuation E).satisfies [.neg 2, .neg 1, .pos 2367] := by
  change (g3 E = true) → (g2 E = true) → (¬ (g2368 E = true)) → False
  exact pattern_15 (g2 E) (g3 E)
private theorem sat_1987 (E : Nat → Bool) : (valuation E).satisfies [.neg 2370, .neg 2367] := by
  change (g2371 E = true) → (g2368 E = true) → False
  exact pattern_20 (g2368 E) (g2369 E) (g2370 E)
private theorem sat_1988 (E : Nat → Bool) : (valuation E).satisfies [.neg 2371, .pos 14] := by
  change (g2372 E = true) → (¬ (g15 E = true)) → False
  exact pattern_2 (g10 E) (g15 E)
private theorem sat_1989 (E : Nat → Bool) : (valuation E).satisfies [.neg 14, .neg 9, .pos 2371] := by
  change (g15 E = true) → (g10 E = true) → (¬ (g2372 E = true)) → False
  exact pattern_15 (g10 E) (g15 E)
private theorem sat_1990 (E : Nat → Bool) : (valuation E).satisfies [.neg 19, .neg 9, .pos 2372] := by
  change (g20 E = true) → (g10 E = true) → (¬ (g2373 E = true)) → False
  exact pattern_15 (g10 E) (g20 E)
private theorem sat_1991 (E : Nat → Bool) : (valuation E).satisfies [.neg 2374, .neg 2372] := by
  change (g2375 E = true) → (g2373 E = true) → False
  exact pattern_19 (g2372 E) (g2373 E) (g2374 E)
private theorem sat_1992 (E : Nat → Bool) : (valuation E).satisfies [.neg 2374, .neg 2371] := by
  change (g2375 E = true) → (g2372 E = true) → False
  exact pattern_20 (g2372 E) (g2373 E) (g2374 E)
private theorem sat_1993 (E : Nat → Bool) : (valuation E).satisfies [.neg 2375, .neg 23] := by
  change (g2376 E = true) → (g24 E = true) → False
  exact pattern_18 (g12 E) (g17 E) (g24 E)
private theorem sat_1994 (E : Nat → Bool) : (valuation E).satisfies [.neg 2376, .neg 24] := by
  change (g2377 E = true) → (g25 E = true) → False
  exact pattern_18 (g13 E) (g18 E) (g25 E)
private theorem sat_1995 (E : Nat → Bool) : (valuation E).satisfies [.neg 2376, .neg 12] := by
  change (g2377 E = true) → (g13 E = true) → False
  exact pattern_20 (g13 E) (g18 E) (g25 E)
private theorem sat_1996 (E : Nat → Bool) : (valuation E).satisfies [.neg 2377, .neg 25] := by
  change (g2378 E = true) → (g26 E = true) → False
  exact pattern_18 (g14 E) (g19 E) (g26 E)
private theorem sat_1997 (E : Nat → Bool) : (valuation E).satisfies [.neg 2377, .neg 13] := by
  change (g2378 E = true) → (g14 E = true) → False
  exact pattern_20 (g14 E) (g19 E) (g26 E)
private theorem sat_1999 (E : Nat → Bool) : (valuation E).satisfies [.neg 2, .neg 1, .pos 2378] := by
  change (g3 E = true) → (g2 E = true) → (¬ (g2379 E = true)) → False
  exact pattern_15 (g2 E) (g3 E)
private theorem sat_2000 (E : Nat → Bool) : (valuation E).satisfies [.neg 5, .neg 1, .pos 2379] := by
  change (g6 E = true) → (g2 E = true) → (¬ (g2380 E = true)) → False
  exact pattern_15 (g2 E) (g6 E)
private theorem sat_2001 (E : Nat → Bool) : (valuation E).satisfies [.neg 5, .neg 2, .pos 2380] := by
  change (g6 E = true) → (g3 E = true) → (¬ (g2381 E = true)) → False
  exact pattern_15 (g3 E) (g6 E)
private theorem sat_2002 (E : Nat → Bool) : (valuation E).satisfies [.neg 2381, .neg 2380] := by
  change (g2382 E = true) → (g2381 E = true) → False
  exact pattern_18 (g2379 E) (g2380 E) (g2381 E)
private theorem sat_2003 (E : Nat → Bool) : (valuation E).satisfies [.neg 2381, .neg 2379] := by
  change (g2382 E = true) → (g2380 E = true) → False
  exact pattern_19 (g2379 E) (g2380 E) (g2381 E)
private theorem sat_2004 (E : Nat → Bool) : (valuation E).satisfies [.neg 2381, .neg 2378] := by
  change (g2382 E = true) → (g2379 E = true) → False
  exact pattern_20 (g2379 E) (g2380 E) (g2381 E)
private theorem sat_2005 (E : Nat → Bool) : (valuation E).satisfies [.neg 14, .neg 9, .pos 2382] := by
  change (g15 E = true) → (g10 E = true) → (¬ (g2383 E = true)) → False
  exact pattern_15 (g10 E) (g15 E)
private theorem sat_2006 (E : Nat → Bool) : (valuation E).satisfies [.neg 20, .neg 9, .pos 2383] := by
  change (g21 E = true) → (g10 E = true) → (¬ (g2384 E = true)) → False
  exact pattern_15 (g10 E) (g21 E)
private theorem sat_2007 (E : Nat → Bool) : (valuation E).satisfies [.neg 20, .neg 14, .pos 2384] := by
  change (g21 E = true) → (g15 E = true) → (¬ (g2385 E = true)) → False
  exact pattern_15 (g15 E) (g21 E)
private theorem sat_2008 (E : Nat → Bool) : (valuation E).satisfies [.neg 2385, .neg 2384] := by
  change (g2386 E = true) → (g2385 E = true) → False
  exact pattern_18 (g2383 E) (g2384 E) (g2385 E)
private theorem sat_2009 (E : Nat → Bool) : (valuation E).satisfies [.neg 2385, .neg 2383] := by
  change (g2386 E = true) → (g2384 E = true) → False
  exact pattern_19 (g2383 E) (g2384 E) (g2385 E)
private theorem sat_2010 (E : Nat → Bool) : (valuation E).satisfies [.neg 2385, .neg 2382] := by
  change (g2386 E = true) → (g2383 E = true) → False
  exact pattern_20 (g2383 E) (g2384 E) (g2385 E)
private theorem sat_2011 (E : Nat → Bool) : (valuation E).satisfies [.neg 2386, .neg 23] := by
  change (g2387 E = true) → (g24 E = true) → False
  exact pattern_18 (g11 E) (g16 E) (g24 E)
private theorem sat_2012 (E : Nat → Bool) : (valuation E).satisfies [.neg 2386, .neg 15] := by
  change (g2387 E = true) → (g16 E = true) → False
  exact pattern_19 (g11 E) (g16 E) (g24 E)
private theorem sat_2013 (E : Nat → Bool) : (valuation E).satisfies [.neg 2386, .neg 10] := by
  change (g2387 E = true) → (g11 E = true) → False
  exact pattern_20 (g11 E) (g16 E) (g24 E)
private theorem sat_2014 (E : Nat → Bool) : (valuation E).satisfies [.neg 2387, .neg 26] := by
  change (g2388 E = true) → (g27 E = true) → False
  exact pattern_18 (g13 E) (g18 E) (g27 E)
private theorem sat_2015 (E : Nat → Bool) : (valuation E).satisfies [.neg 2387, .neg 17] := by
  change (g2388 E = true) → (g18 E = true) → False
  exact pattern_19 (g13 E) (g18 E) (g27 E)
private theorem sat_2016 (E : Nat → Bool) : (valuation E).satisfies [.neg 2387, .neg 12] := by
  change (g2388 E = true) → (g13 E = true) → False
  exact pattern_20 (g13 E) (g18 E) (g27 E)
private theorem sat_2017 (E : Nat → Bool) : (valuation E).satisfies [.neg 2388, .neg 27] := by
  change (g2389 E = true) → (g28 E = true) → False
  exact pattern_18 (g14 E) (g19 E) (g28 E)
private theorem sat_2018 (E : Nat → Bool) : (valuation E).satisfies [.neg 2388, .neg 18] := by
  change (g2389 E = true) → (g19 E = true) → False
  exact pattern_19 (g14 E) (g19 E) (g28 E)
private theorem sat_2019 (E : Nat → Bool) : (valuation E).satisfies [.neg 2388, .neg 13] := by
  change (g2389 E = true) → (g14 E = true) → False
  exact pattern_20 (g14 E) (g19 E) (g28 E)
private theorem sat_2021 (E : Nat → Bool) : (valuation E).satisfies [.neg 2, .neg 1, .pos 2389] := by
  change (g3 E = true) → (g2 E = true) → (¬ (g2390 E = true)) → False
  exact pattern_15 (g2 E) (g3 E)
private theorem sat_2022 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .neg 1, .pos 2390] := by
  change (g7 E = true) → (g2 E = true) → (¬ (g2391 E = true)) → False
  exact pattern_15 (g2 E) (g7 E)
private theorem sat_2023 (E : Nat → Bool) : (valuation E).satisfies [.neg 2391, .pos 2] := by
  change (g2392 E = true) → (¬ (g3 E = true)) → False
  exact pattern_1 (g3 E) (g7 E)
private theorem sat_2024 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .neg 2, .pos 2391] := by
  change (g7 E = true) → (g3 E = true) → (¬ (g2392 E = true)) → False
  exact pattern_15 (g3 E) (g7 E)
private theorem sat_2025 (E : Nat → Bool) : (valuation E).satisfies [.neg 2392, .neg 2391] := by
  change (g2393 E = true) → (g2392 E = true) → False
  exact pattern_18 (g2390 E) (g2391 E) (g2392 E)
private theorem sat_2026 (E : Nat → Bool) : (valuation E).satisfies [.neg 2392, .neg 2390] := by
  change (g2393 E = true) → (g2391 E = true) → False
  exact pattern_19 (g2390 E) (g2391 E) (g2392 E)
private theorem sat_2027 (E : Nat → Bool) : (valuation E).satisfies [.neg 2392, .neg 2389] := by
  change (g2393 E = true) → (g2390 E = true) → False
  exact pattern_20 (g2390 E) (g2391 E) (g2392 E)
private theorem sat_2028 (E : Nat → Bool) : (valuation E).satisfies [.neg 2393, .pos 9] := by
  change (g2394 E = true) → (¬ (g10 E = true)) → False
  exact pattern_1 (g10 E) (g15 E)
private theorem sat_2029 (E : Nat → Bool) : (valuation E).satisfies [.neg 2393, .pos 14] := by
  change (g2394 E = true) → (¬ (g15 E = true)) → False
  exact pattern_2 (g10 E) (g15 E)
private theorem sat_2030 (E : Nat → Bool) : (valuation E).satisfies [.neg 14, .neg 9, .pos 2393] := by
  change (g15 E = true) → (g10 E = true) → (¬ (g2394 E = true)) → False
  exact pattern_15 (g10 E) (g15 E)
private theorem sat_2031 (E : Nat → Bool) : (valuation E).satisfies [.neg 2394, .pos 9] := by
  change (g2395 E = true) → (¬ (g10 E = true)) → False
  exact pattern_1 (g10 E) (g22 E)
private theorem sat_2032 (E : Nat → Bool) : (valuation E).satisfies [.neg 2394, .pos 21] := by
  change (g2395 E = true) → (¬ (g22 E = true)) → False
  exact pattern_2 (g10 E) (g22 E)
private theorem sat_2033 (E : Nat → Bool) : (valuation E).satisfies [.neg 21, .neg 9, .pos 2394] := by
  change (g22 E = true) → (g10 E = true) → (¬ (g2395 E = true)) → False
  exact pattern_15 (g10 E) (g22 E)
private theorem sat_2034 (E : Nat → Bool) : (valuation E).satisfies [.neg 2395, .pos 14] := by
  change (g2396 E = true) → (¬ (g15 E = true)) → False
  exact pattern_1 (g15 E) (g22 E)
private theorem sat_2035 (E : Nat → Bool) : (valuation E).satisfies [.neg 2395, .pos 21] := by
  change (g2396 E = true) → (¬ (g22 E = true)) → False
  exact pattern_2 (g15 E) (g22 E)
private theorem sat_2036 (E : Nat → Bool) : (valuation E).satisfies [.neg 21, .neg 14, .pos 2395] := by
  change (g22 E = true) → (g15 E = true) → (¬ (g2396 E = true)) → False
  exact pattern_15 (g15 E) (g22 E)
private theorem sat_2037 (E : Nat → Bool) : (valuation E).satisfies [.neg 2396, .neg 2395] := by
  change (g2397 E = true) → (g2396 E = true) → False
  exact pattern_18 (g2394 E) (g2395 E) (g2396 E)
private theorem sat_2038 (E : Nat → Bool) : (valuation E).satisfies [.neg 2396, .neg 2394] := by
  change (g2397 E = true) → (g2395 E = true) → False
  exact pattern_19 (g2394 E) (g2395 E) (g2396 E)
private theorem sat_2039 (E : Nat → Bool) : (valuation E).satisfies [.neg 2396, .neg 2393] := by
  change (g2397 E = true) → (g2394 E = true) → False
  exact pattern_20 (g2394 E) (g2395 E) (g2396 E)
private theorem sat_2040 (E : Nat → Bool) : (valuation E).satisfies [.pos 2393, .pos 2394, .pos 2395, .pos 2396] := by
  change (¬ (g2394 E = true)) → (¬ (g2395 E = true)) → (¬ (g2396 E = true)) → (¬ (g2397 E = true)) → False
  exact pattern_21 (g2394 E) (g2395 E) (g2396 E)
private theorem sat_2041 (E : Nat → Bool) : (valuation E).satisfies [.neg 2397, .neg 24] := by
  change (g2398 E = true) → (g25 E = true) → False
  exact pattern_18 (g11 E) (g16 E) (g25 E)
private theorem sat_2042 (E : Nat → Bool) : (valuation E).satisfies [.neg 2397, .neg 15] := by
  change (g2398 E = true) → (g16 E = true) → False
  exact pattern_19 (g11 E) (g16 E) (g25 E)
private theorem sat_2043 (E : Nat → Bool) : (valuation E).satisfies [.neg 2397, .neg 10] := by
  change (g2398 E = true) → (g11 E = true) → False
  exact pattern_20 (g11 E) (g16 E) (g25 E)
private theorem sat_2044 (E : Nat → Bool) : (valuation E).satisfies [.neg 2398, .neg 26] := by
  change (g2399 E = true) → (g27 E = true) → False
  exact pattern_18 (g12 E) (g17 E) (g27 E)
private theorem sat_2045 (E : Nat → Bool) : (valuation E).satisfies [.neg 2398, .neg 16] := by
  change (g2399 E = true) → (g17 E = true) → False
  exact pattern_19 (g12 E) (g17 E) (g27 E)
private theorem sat_2046 (E : Nat → Bool) : (valuation E).satisfies [.neg 2398, .neg 11] := by
  change (g2399 E = true) → (g12 E = true) → False
  exact pattern_20 (g12 E) (g17 E) (g27 E)
private theorem sat_2047 (E : Nat → Bool) : (valuation E).satisfies [.neg 2399, .neg 28] := by
  change (g2400 E = true) → (g29 E = true) → False
  exact pattern_18 (g14 E) (g19 E) (g29 E)
private theorem sat_2048 (E : Nat → Bool) : (valuation E).satisfies [.neg 2399, .neg 18] := by
  change (g2400 E = true) → (g19 E = true) → False
  exact pattern_19 (g14 E) (g19 E) (g29 E)
private theorem sat_2049 (E : Nat → Bool) : (valuation E).satisfies [.neg 2399, .neg 13] := by
  change (g2400 E = true) → (g14 E = true) → False
  exact pattern_20 (g14 E) (g19 E) (g29 E)
private theorem sat_2051 (E : Nat → Bool) : (valuation E).satisfies [.neg 2400, .pos 2] := by
  change (g2401 E = true) → (¬ (g3 E = true)) → False
  exact pattern_2 (g2 E) (g3 E)
private theorem sat_2052 (E : Nat → Bool) : (valuation E).satisfies [.neg 2401, .pos 1] := by
  change (g2402 E = true) → (¬ (g2 E = true)) → False
  exact pattern_1 (g2 E) (g8 E)
private theorem sat_2053 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 1, .pos 2401] := by
  change (g8 E = true) → (g2 E = true) → (¬ (g2402 E = true)) → False
  exact pattern_15 (g2 E) (g8 E)
private theorem sat_2054 (E : Nat → Bool) : (valuation E).satisfies [.neg 2402, .pos 2] := by
  change (g2403 E = true) → (¬ (g3 E = true)) → False
  exact pattern_1 (g3 E) (g8 E)
private theorem sat_2055 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 2, .pos 2402] := by
  change (g8 E = true) → (g3 E = true) → (¬ (g2403 E = true)) → False
  exact pattern_15 (g3 E) (g8 E)
private theorem sat_2056 (E : Nat → Bool) : (valuation E).satisfies [.neg 2403, .neg 2402] := by
  change (g2404 E = true) → (g2403 E = true) → False
  exact pattern_18 (g2401 E) (g2402 E) (g2403 E)
private theorem sat_2057 (E : Nat → Bool) : (valuation E).satisfies [.neg 2403, .neg 2401] := by
  change (g2404 E = true) → (g2402 E = true) → False
  exact pattern_19 (g2401 E) (g2402 E) (g2403 E)
private theorem sat_2058 (E : Nat → Bool) : (valuation E).satisfies [.pos 2400, .pos 2401, .pos 2402, .pos 2403] := by
  change (¬ (g2401 E = true)) → (¬ (g2402 E = true)) → (¬ (g2403 E = true)) → (¬ (g2404 E = true)) → False
  exact pattern_21 (g2401 E) (g2402 E) (g2403 E)
private theorem sat_2059 (E : Nat → Bool) : (valuation E).satisfies [.neg 2404, .pos 9] := by
  change (g2405 E = true) → (¬ (g10 E = true)) → False
  exact pattern_1 (g10 E) (g15 E)
private theorem sat_2060 (E : Nat → Bool) : (valuation E).satisfies [.neg 14, .neg 9, .pos 2404] := by
  change (g15 E = true) → (g10 E = true) → (¬ (g2405 E = true)) → False
  exact pattern_15 (g10 E) (g15 E)
private theorem sat_2061 (E : Nat → Bool) : (valuation E).satisfies [.neg 2405, .pos 9] := by
  change (g2406 E = true) → (¬ (g10 E = true)) → False
  exact pattern_1 (g10 E) (g23 E)
private theorem sat_2062 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 9, .pos 2405] := by
  change (g23 E = true) → (g10 E = true) → (¬ (g2406 E = true)) → False
  exact pattern_15 (g10 E) (g23 E)
private theorem sat_2063 (E : Nat → Bool) : (valuation E).satisfies [.neg 2406, .pos 22] := by
  change (g2407 E = true) → (¬ (g23 E = true)) → False
  exact pattern_2 (g15 E) (g23 E)
private theorem sat_2064 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 14, .pos 2406] := by
  change (g23 E = true) → (g15 E = true) → (¬ (g2407 E = true)) → False
  exact pattern_15 (g15 E) (g23 E)
private theorem sat_2065 (E : Nat → Bool) : (valuation E).satisfies [.neg 2407, .neg 2406] := by
  change (g2408 E = true) → (g2407 E = true) → False
  exact pattern_18 (g2405 E) (g2406 E) (g2407 E)
private theorem sat_2066 (E : Nat → Bool) : (valuation E).satisfies [.neg 2407, .neg 2405] := by
  change (g2408 E = true) → (g2406 E = true) → False
  exact pattern_19 (g2405 E) (g2406 E) (g2407 E)
private theorem sat_2067 (E : Nat → Bool) : (valuation E).satisfies [.neg 2407, .neg 2404] := by
  change (g2408 E = true) → (g2405 E = true) → False
  exact pattern_20 (g2405 E) (g2406 E) (g2407 E)
private theorem sat_2068 (E : Nat → Bool) : (valuation E).satisfies [.pos 2404, .pos 2405, .pos 2406, .pos 2407] := by
  change (¬ (g2405 E = true)) → (¬ (g2406 E = true)) → (¬ (g2407 E = true)) → (¬ (g2408 E = true)) → False
  exact pattern_21 (g2405 E) (g2406 E) (g2407 E)
private theorem sat_2069 (E : Nat → Bool) : (valuation E).satisfies [.neg 2408, .neg 25] := by
  change (g2409 E = true) → (g26 E = true) → False
  exact pattern_18 (g11 E) (g16 E) (g26 E)
private theorem sat_2070 (E : Nat → Bool) : (valuation E).satisfies [.neg 2408, .neg 15] := by
  change (g2409 E = true) → (g16 E = true) → False
  exact pattern_19 (g11 E) (g16 E) (g26 E)
private theorem sat_2071 (E : Nat → Bool) : (valuation E).satisfies [.neg 2408, .neg 10] := by
  change (g2409 E = true) → (g11 E = true) → False
  exact pattern_20 (g11 E) (g16 E) (g26 E)
private theorem sat_2072 (E : Nat → Bool) : (valuation E).satisfies [.pos 10, .pos 15, .pos 25, .pos 2408] := by
  change (¬ (g11 E = true)) → (¬ (g16 E = true)) → (¬ (g26 E = true)) → (¬ (g2409 E = true)) → False
  exact pattern_21 (g11 E) (g16 E) (g26 E)
private theorem sat_2073 (E : Nat → Bool) : (valuation E).satisfies [.neg 2409, .neg 27] := by
  change (g2410 E = true) → (g28 E = true) → False
  exact pattern_18 (g12 E) (g17 E) (g28 E)
private theorem sat_2074 (E : Nat → Bool) : (valuation E).satisfies [.neg 2409, .neg 16] := by
  change (g2410 E = true) → (g17 E = true) → False
  exact pattern_19 (g12 E) (g17 E) (g28 E)
private theorem sat_2075 (E : Nat → Bool) : (valuation E).satisfies [.neg 2409, .neg 11] := by
  change (g2410 E = true) → (g12 E = true) → False
  exact pattern_20 (g12 E) (g17 E) (g28 E)
private theorem sat_2076 (E : Nat → Bool) : (valuation E).satisfies [.neg 2410, .neg 28] := by
  change (g2411 E = true) → (g29 E = true) → False
  exact pattern_18 (g13 E) (g18 E) (g29 E)
private theorem sat_2077 (E : Nat → Bool) : (valuation E).satisfies [.neg 2410, .neg 17] := by
  change (g2411 E = true) → (g18 E = true) → False
  exact pattern_19 (g13 E) (g18 E) (g29 E)
private theorem sat_2078 (E : Nat → Bool) : (valuation E).satisfies [.neg 2410, .neg 12] := by
  change (g2411 E = true) → (g13 E = true) → False
  exact pattern_20 (g13 E) (g18 E) (g29 E)
private theorem sat_2079 (E : Nat → Bool) : (valuation E).satisfies [.pos 12, .pos 17, .pos 28, .pos 2410] := by
  change (¬ (g13 E = true)) → (¬ (g18 E = true)) → (¬ (g29 E = true)) → (¬ (g2411 E = true)) → False
  exact pattern_21 (g13 E) (g18 E) (g29 E)
private theorem sat_2081 (E : Nat → Bool) : (valuation E).satisfies [.neg 3, .neg 1, .pos 2411] := by
  change (g4 E = true) → (g2 E = true) → (¬ (g2412 E = true)) → False
  exact pattern_15 (g2 E) (g4 E)
private theorem sat_2082 (E : Nat → Bool) : (valuation E).satisfies [.neg 2414, .neg 2411] := by
  change (g2415 E = true) → (g2412 E = true) → False
  exact pattern_20 (g2412 E) (g2413 E) (g2414 E)
private theorem sat_2083 (E : Nat → Bool) : (valuation E).satisfies [.neg 14, .neg 8, .pos 2415] := by
  change (g15 E = true) → (g9 E = true) → (¬ (g2416 E = true)) → False
  exact pattern_15 (g9 E) (g15 E)
private theorem sat_2084 (E : Nat → Bool) : (valuation E).satisfies [.neg 2418, .neg 2415] := by
  change (g2419 E = true) → (g2416 E = true) → False
  exact pattern_20 (g2416 E) (g2417 E) (g2418 E)
private theorem sat_2085 (E : Nat → Bool) : (valuation E).satisfies [.neg 2419, .neg 23] := by
  change (g2420 E = true) → (g24 E = true) → False
  exact pattern_18 (g12 E) (g21 E) (g24 E)
private theorem sat_2086 (E : Nat → Bool) : (valuation E).satisfies [.neg 2420, .neg 24] := by
  change (g2421 E = true) → (g25 E = true) → False
  exact pattern_18 (g13 E) (g22 E) (g25 E)
private theorem sat_2087 (E : Nat → Bool) : (valuation E).satisfies [.neg 2420, .neg 12] := by
  change (g2421 E = true) → (g13 E = true) → False
  exact pattern_20 (g13 E) (g22 E) (g25 E)
private theorem sat_2088 (E : Nat → Bool) : (valuation E).satisfies [.neg 2421, .neg 25] := by
  change (g2422 E = true) → (g26 E = true) → False
  exact pattern_18 (g14 E) (g23 E) (g26 E)
private theorem sat_2089 (E : Nat → Bool) : (valuation E).satisfies [.neg 2421, .neg 13] := by
  change (g2422 E = true) → (g14 E = true) → False
  exact pattern_20 (g14 E) (g23 E) (g26 E)
private theorem sat_2091 (E : Nat → Bool) : (valuation E).satisfies [.neg 3, .neg 1, .pos 2422] := by
  change (g4 E = true) → (g2 E = true) → (¬ (g2423 E = true)) → False
  exact pattern_15 (g2 E) (g4 E)
private theorem sat_2092 (E : Nat → Bool) : (valuation E).satisfies [.neg 5, .neg 3, .pos 2424] := by
  change (g6 E = true) → (g4 E = true) → (¬ (g2425 E = true)) → False
  exact pattern_15 (g4 E) (g6 E)
private theorem sat_2093 (E : Nat → Bool) : (valuation E).satisfies [.neg 2425, .neg 2424] := by
  change (g2426 E = true) → (g2425 E = true) → False
  exact pattern_18 (g2423 E) (g2424 E) (g2425 E)
private theorem sat_2094 (E : Nat → Bool) : (valuation E).satisfies [.neg 2425, .neg 2422] := by
  change (g2426 E = true) → (g2423 E = true) → False
  exact pattern_20 (g2423 E) (g2424 E) (g2425 E)
private theorem sat_2095 (E : Nat → Bool) : (valuation E).satisfies [.neg 2426, .pos 8] := by
  change (g2427 E = true) → (¬ (g9 E = true)) → False
  exact pattern_1 (g9 E) (g15 E)
private theorem sat_2096 (E : Nat → Bool) : (valuation E).satisfies [.neg 2426, .pos 14] := by
  change (g2427 E = true) → (¬ (g15 E = true)) → False
  exact pattern_2 (g9 E) (g15 E)
private theorem sat_2097 (E : Nat → Bool) : (valuation E).satisfies [.neg 14, .neg 8, .pos 2426] := by
  change (g15 E = true) → (g9 E = true) → (¬ (g2427 E = true)) → False
  exact pattern_15 (g9 E) (g15 E)
private theorem sat_2098 (E : Nat → Bool) : (valuation E).satisfies [.neg 16, .neg 8, .pos 2427] := by
  change (g17 E = true) → (g9 E = true) → (¬ (g2428 E = true)) → False
  exact pattern_15 (g9 E) (g17 E)
private theorem sat_2099 (E : Nat → Bool) : (valuation E).satisfies [.neg 2429, .neg 2427] := by
  change (g2430 E = true) → (g2428 E = true) → False
  exact pattern_19 (g2427 E) (g2428 E) (g2429 E)
private theorem sat_2100 (E : Nat → Bool) : (valuation E).satisfies [.neg 2429, .neg 2426] := by
  change (g2430 E = true) → (g2427 E = true) → False
  exact pattern_20 (g2427 E) (g2428 E) (g2429 E)
private theorem sat_2101 (E : Nat → Bool) : (valuation E).satisfies [.neg 2430, .neg 19] := by
  change (g2431 E = true) → (g20 E = true) → False
  exact pattern_19 (g11 E) (g20 E) (g24 E)
private theorem sat_2102 (E : Nat → Bool) : (valuation E).satisfies [.neg 2430, .neg 10] := by
  change (g2431 E = true) → (g11 E = true) → False
  exact pattern_20 (g11 E) (g20 E) (g24 E)
private theorem sat_2103 (E : Nat → Bool) : (valuation E).satisfies [.neg 2431, .neg 26] := by
  change (g2432 E = true) → (g27 E = true) → False
  exact pattern_18 (g13 E) (g22 E) (g27 E)
private theorem sat_2104 (E : Nat → Bool) : (valuation E).satisfies [.neg 2431, .neg 21] := by
  change (g2432 E = true) → (g22 E = true) → False
  exact pattern_19 (g13 E) (g22 E) (g27 E)
private theorem sat_2105 (E : Nat → Bool) : (valuation E).satisfies [.neg 2431, .neg 12] := by
  change (g2432 E = true) → (g13 E = true) → False
  exact pattern_20 (g13 E) (g22 E) (g27 E)
private theorem sat_2106 (E : Nat → Bool) : (valuation E).satisfies [.neg 2432, .neg 27] := by
  change (g2433 E = true) → (g28 E = true) → False
  exact pattern_18 (g14 E) (g23 E) (g28 E)
private theorem sat_2107 (E : Nat → Bool) : (valuation E).satisfies [.neg 2432, .neg 13] := by
  change (g2433 E = true) → (g14 E = true) → False
  exact pattern_20 (g14 E) (g23 E) (g28 E)
private theorem sat_2109 (E : Nat → Bool) : (valuation E).satisfies [.neg 3, .neg 1, .pos 2433] := by
  change (g4 E = true) → (g2 E = true) → (¬ (g2434 E = true)) → False
  exact pattern_15 (g2 E) (g4 E)
private theorem sat_2110 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .neg 1, .pos 2434] := by
  change (g7 E = true) → (g2 E = true) → (¬ (g2435 E = true)) → False
  exact pattern_15 (g2 E) (g7 E)
private theorem sat_2111 (E : Nat → Bool) : (valuation E).satisfies [.neg 2435, .pos 3] := by
  change (g2436 E = true) → (¬ (g4 E = true)) → False
  exact pattern_1 (g4 E) (g7 E)
private theorem sat_2112 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .neg 3, .pos 2435] := by
  change (g7 E = true) → (g4 E = true) → (¬ (g2436 E = true)) → False
  exact pattern_15 (g4 E) (g7 E)
private theorem sat_2113 (E : Nat → Bool) : (valuation E).satisfies [.neg 2436, .neg 2435] := by
  change (g2437 E = true) → (g2436 E = true) → False
  exact pattern_18 (g2434 E) (g2435 E) (g2436 E)
private theorem sat_2114 (E : Nat → Bool) : (valuation E).satisfies [.neg 2436, .neg 2434] := by
  change (g2437 E = true) → (g2435 E = true) → False
  exact pattern_19 (g2434 E) (g2435 E) (g2436 E)
private theorem sat_2115 (E : Nat → Bool) : (valuation E).satisfies [.neg 2436, .neg 2433] := by
  change (g2437 E = true) → (g2434 E = true) → False
  exact pattern_20 (g2434 E) (g2435 E) (g2436 E)
private theorem sat_2116 (E : Nat → Bool) : (valuation E).satisfies [.neg 2437, .pos 14] := by
  change (g2438 E = true) → (¬ (g15 E = true)) → False
  exact pattern_2 (g9 E) (g15 E)
private theorem sat_2117 (E : Nat → Bool) : (valuation E).satisfies [.neg 14, .neg 8, .pos 2437] := by
  change (g15 E = true) → (g9 E = true) → (¬ (g2438 E = true)) → False
  exact pattern_15 (g9 E) (g15 E)
private theorem sat_2118 (E : Nat → Bool) : (valuation E).satisfies [.neg 2438, .pos 17] := by
  change (g2439 E = true) → (¬ (g18 E = true)) → False
  exact pattern_2 (g9 E) (g18 E)
private theorem sat_2119 (E : Nat → Bool) : (valuation E).satisfies [.neg 17, .neg 8, .pos 2438] := by
  change (g18 E = true) → (g9 E = true) → (¬ (g2439 E = true)) → False
  exact pattern_15 (g9 E) (g18 E)
private theorem sat_2120 (E : Nat → Bool) : (valuation E).satisfies [.neg 2439, .pos 14] := by
  change (g2440 E = true) → (¬ (g15 E = true)) → False
  exact pattern_1 (g15 E) (g18 E)
private theorem sat_2121 (E : Nat → Bool) : (valuation E).satisfies [.neg 17, .neg 14, .pos 2439] := by
  change (g18 E = true) → (g15 E = true) → (¬ (g2440 E = true)) → False
  exact pattern_15 (g15 E) (g18 E)
private theorem sat_2122 (E : Nat → Bool) : (valuation E).satisfies [.neg 2440, .neg 2439] := by
  change (g2441 E = true) → (g2440 E = true) → False
  exact pattern_18 (g2438 E) (g2439 E) (g2440 E)
private theorem sat_2123 (E : Nat → Bool) : (valuation E).satisfies [.neg 2440, .neg 2438] := by
  change (g2441 E = true) → (g2439 E = true) → False
  exact pattern_19 (g2438 E) (g2439 E) (g2440 E)
private theorem sat_2124 (E : Nat → Bool) : (valuation E).satisfies [.neg 2440, .neg 2437] := by
  change (g2441 E = true) → (g2438 E = true) → False
  exact pattern_20 (g2438 E) (g2439 E) (g2440 E)
private theorem sat_2125 (E : Nat → Bool) : (valuation E).satisfies [.pos 2437, .pos 2438, .pos 2439, .pos 2440] := by
  change (¬ (g2438 E = true)) → (¬ (g2439 E = true)) → (¬ (g2440 E = true)) → (¬ (g2441 E = true)) → False
  exact pattern_21 (g2438 E) (g2439 E) (g2440 E)
private theorem sat_2126 (E : Nat → Bool) : (valuation E).satisfies [.neg 2441, .neg 24] := by
  change (g2442 E = true) → (g25 E = true) → False
  exact pattern_18 (g11 E) (g20 E) (g25 E)
private theorem sat_2127 (E : Nat → Bool) : (valuation E).satisfies [.neg 2441, .neg 19] := by
  change (g2442 E = true) → (g20 E = true) → False
  exact pattern_19 (g11 E) (g20 E) (g25 E)
private theorem sat_2128 (E : Nat → Bool) : (valuation E).satisfies [.neg 2442, .neg 26] := by
  change (g2443 E = true) → (g27 E = true) → False
  exact pattern_18 (g12 E) (g21 E) (g27 E)
private theorem sat_2129 (E : Nat → Bool) : (valuation E).satisfies [.neg 2442, .neg 20] := by
  change (g2443 E = true) → (g21 E = true) → False
  exact pattern_19 (g12 E) (g21 E) (g27 E)
private theorem sat_2130 (E : Nat → Bool) : (valuation E).satisfies [.neg 2442, .neg 11] := by
  change (g2443 E = true) → (g12 E = true) → False
  exact pattern_20 (g12 E) (g21 E) (g27 E)
private theorem sat_2131 (E : Nat → Bool) : (valuation E).satisfies [.neg 2443, .neg 28] := by
  change (g2444 E = true) → (g29 E = true) → False
  exact pattern_18 (g14 E) (g23 E) (g29 E)
private theorem sat_2132 (E : Nat → Bool) : (valuation E).satisfies [.neg 2443, .neg 22] := by
  change (g2444 E = true) → (g23 E = true) → False
  exact pattern_19 (g14 E) (g23 E) (g29 E)
private theorem sat_2133 (E : Nat → Bool) : (valuation E).satisfies [.neg 2443, .neg 13] := by
  change (g2444 E = true) → (g14 E = true) → False
  exact pattern_20 (g14 E) (g23 E) (g29 E)
private theorem sat_2135 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 1, .pos 2445] := by
  change (g8 E = true) → (g2 E = true) → (¬ (g2446 E = true)) → False
  exact pattern_15 (g2 E) (g8 E)
private theorem sat_2136 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 3, .pos 2446] := by
  change (g8 E = true) → (g4 E = true) → (¬ (g2447 E = true)) → False
  exact pattern_15 (g4 E) (g8 E)
private theorem sat_2137 (E : Nat → Bool) : (valuation E).satisfies [.neg 2447, .neg 2446] := by
  change (g2448 E = true) → (g2447 E = true) → False
  exact pattern_18 (g2445 E) (g2446 E) (g2447 E)
private theorem sat_2138 (E : Nat → Bool) : (valuation E).satisfies [.neg 2447, .neg 2445] := by
  change (g2448 E = true) → (g2446 E = true) → False
  exact pattern_19 (g2445 E) (g2446 E) (g2447 E)
private theorem sat_2139 (E : Nat → Bool) : (valuation E).satisfies [.neg 14, .neg 8, .pos 2448] := by
  change (g15 E = true) → (g9 E = true) → (¬ (g2449 E = true)) → False
  exact pattern_15 (g9 E) (g15 E)
private theorem sat_2140 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 8, .pos 2449] := by
  change (g19 E = true) → (g9 E = true) → (¬ (g2450 E = true)) → False
  exact pattern_15 (g9 E) (g19 E)
private theorem sat_2141 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 14, .pos 2450] := by
  change (g19 E = true) → (g15 E = true) → (¬ (g2451 E = true)) → False
  exact pattern_15 (g15 E) (g19 E)
private theorem sat_2142 (E : Nat → Bool) : (valuation E).satisfies [.neg 2451, .neg 2450] := by
  change (g2452 E = true) → (g2451 E = true) → False
  exact pattern_18 (g2449 E) (g2450 E) (g2451 E)
private theorem sat_2143 (E : Nat → Bool) : (valuation E).satisfies [.neg 2451, .neg 2449] := by
  change (g2452 E = true) → (g2450 E = true) → False
  exact pattern_19 (g2449 E) (g2450 E) (g2451 E)
private theorem sat_2144 (E : Nat → Bool) : (valuation E).satisfies [.neg 2451, .neg 2448] := by
  change (g2452 E = true) → (g2449 E = true) → False
  exact pattern_20 (g2449 E) (g2450 E) (g2451 E)
private theorem sat_2145 (E : Nat → Bool) : (valuation E).satisfies [.neg 2452, .neg 25] := by
  change (g2453 E = true) → (g26 E = true) → False
  exact pattern_18 (g11 E) (g20 E) (g26 E)
private theorem sat_2146 (E : Nat → Bool) : (valuation E).satisfies [.neg 2452, .neg 19] := by
  change (g2453 E = true) → (g20 E = true) → False
  exact pattern_19 (g11 E) (g20 E) (g26 E)
private theorem sat_2147 (E : Nat → Bool) : (valuation E).satisfies [.neg 2452, .neg 10] := by
  change (g2453 E = true) → (g11 E = true) → False
  exact pattern_20 (g11 E) (g20 E) (g26 E)
private theorem sat_2148 (E : Nat → Bool) : (valuation E).satisfies [.neg 2453, .neg 27] := by
  change (g2454 E = true) → (g28 E = true) → False
  exact pattern_18 (g12 E) (g21 E) (g28 E)
private theorem sat_2149 (E : Nat → Bool) : (valuation E).satisfies [.neg 2453, .neg 20] := by
  change (g2454 E = true) → (g21 E = true) → False
  exact pattern_19 (g12 E) (g21 E) (g28 E)
private theorem sat_2150 (E : Nat → Bool) : (valuation E).satisfies [.neg 2453, .neg 11] := by
  change (g2454 E = true) → (g12 E = true) → False
  exact pattern_20 (g12 E) (g21 E) (g28 E)
private theorem sat_2151 (E : Nat → Bool) : (valuation E).satisfies [.pos 11, .pos 20, .pos 27, .pos 2453] := by
  change (¬ (g12 E = true)) → (¬ (g21 E = true)) → (¬ (g28 E = true)) → (¬ (g2454 E = true)) → False
  exact pattern_21 (g12 E) (g21 E) (g28 E)
private theorem sat_2152 (E : Nat → Bool) : (valuation E).satisfies [.neg 2454, .neg 28] := by
  change (g2455 E = true) → (g29 E = true) → False
  exact pattern_18 (g13 E) (g22 E) (g29 E)
private theorem sat_2153 (E : Nat → Bool) : (valuation E).satisfies [.neg 2454, .neg 21] := by
  change (g2455 E = true) → (g22 E = true) → False
  exact pattern_19 (g13 E) (g22 E) (g29 E)
private theorem sat_2154 (E : Nat → Bool) : (valuation E).satisfies [.neg 2454, .neg 12] := by
  change (g2455 E = true) → (g13 E = true) → False
  exact pattern_20 (g13 E) (g22 E) (g29 E)
private theorem sat_2156 (E : Nat → Bool) : (valuation E).satisfies [.neg 5, .neg 1, .pos 2456] := by
  change (g6 E = true) → (g2 E = true) → (¬ (g2457 E = true)) → False
  exact pattern_15 (g2 E) (g6 E)
private theorem sat_2157 (E : Nat → Bool) : (valuation E).satisfies [.neg 2458, .neg 2456] := by
  change (g2459 E = true) → (g2457 E = true) → False
  exact pattern_19 (g2456 E) (g2457 E) (g2458 E)
private theorem sat_2158 (E : Nat → Bool) : (valuation E).satisfies [.neg 16, .neg 8, .pos 2460] := by
  change (g17 E = true) → (g9 E = true) → (¬ (g2461 E = true)) → False
  exact pattern_15 (g9 E) (g17 E)
private theorem sat_2159 (E : Nat → Bool) : (valuation E).satisfies [.neg 2462, .neg 2460] := by
  change (g2463 E = true) → (g2461 E = true) → False
  exact pattern_19 (g2460 E) (g2461 E) (g2462 E)
private theorem sat_2160 (E : Nat → Bool) : (valuation E).satisfies [.neg 20, .neg 9, .pos 2464] := by
  change (g21 E = true) → (g10 E = true) → (¬ (g2465 E = true)) → False
  exact pattern_15 (g10 E) (g21 E)
private theorem sat_2161 (E : Nat → Bool) : (valuation E).satisfies [.neg 2466, .neg 2464] := by
  change (g2467 E = true) → (g2465 E = true) → False
  exact pattern_19 (g2464 E) (g2465 E) (g2466 E)
private theorem sat_2162 (E : Nat → Bool) : (valuation E).satisfies [.neg 2467, .neg 24] := by
  change (g2468 E = true) → (g25 E = true) → False
  exact pattern_19 (g13 E) (g25 E) (g27 E)
private theorem sat_2163 (E : Nat → Bool) : (valuation E).satisfies [.neg 2468, .neg 25] := by
  change (g2469 E = true) → (g26 E = true) → False
  exact pattern_19 (g14 E) (g26 E) (g28 E)
private theorem sat_2165 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .neg 1, .pos 2470] := by
  change (g7 E = true) → (g2 E = true) → (¬ (g2471 E = true)) → False
  exact pattern_15 (g2 E) (g7 E)
private theorem sat_2166 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .neg 4, .pos 2471] := by
  change (g7 E = true) → (g5 E = true) → (¬ (g2472 E = true)) → False
  exact pattern_15 (g5 E) (g7 E)
private theorem sat_2167 (E : Nat → Bool) : (valuation E).satisfies [.neg 2472, .neg 2471] := by
  change (g2473 E = true) → (g2472 E = true) → False
  exact pattern_18 (g2470 E) (g2471 E) (g2472 E)
private theorem sat_2168 (E : Nat → Bool) : (valuation E).satisfies [.neg 2472, .neg 2470] := by
  change (g2473 E = true) → (g2471 E = true) → False
  exact pattern_19 (g2470 E) (g2471 E) (g2472 E)
private theorem sat_2169 (E : Nat → Bool) : (valuation E).satisfies [.neg 17, .neg 15, .pos 2475] := by
  change (g18 E = true) → (g16 E = true) → (¬ (g2476 E = true)) → False
  exact pattern_15 (g16 E) (g18 E)
private theorem sat_2170 (E : Nat → Bool) : (valuation E).satisfies [.neg 2476, .neg 2475] := by
  change (g2477 E = true) → (g2476 E = true) → False
  exact pattern_18 (g2474 E) (g2475 E) (g2476 E)
private theorem sat_2171 (E : Nat → Bool) : (valuation E).satisfies [.neg 21, .neg 19, .pos 2479] := by
  change (g22 E = true) → (g20 E = true) → (¬ (g2480 E = true)) → False
  exact pattern_15 (g20 E) (g22 E)
private theorem sat_2172 (E : Nat → Bool) : (valuation E).satisfies [.neg 2480, .neg 2479] := by
  change (g2481 E = true) → (g2480 E = true) → False
  exact pattern_18 (g2478 E) (g2479 E) (g2480 E)
private theorem sat_2173 (E : Nat → Bool) : (valuation E).satisfies [.neg 2481, .neg 26] := by
  change (g2482 E = true) → (g27 E = true) → False
  exact pattern_18 (g12 E) (g24 E) (g27 E)
private theorem sat_2174 (E : Nat → Bool) : (valuation E).satisfies [.neg 2482, .neg 28] := by
  change (g2483 E = true) → (g29 E = true) → False
  exact pattern_18 (g14 E) (g26 E) (g29 E)
private theorem sat_2176 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 1, .pos 2484] := by
  change (g8 E = true) → (g2 E = true) → (¬ (g2485 E = true)) → False
  exact pattern_15 (g2 E) (g8 E)
private theorem sat_2177 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 4, .pos 2485] := by
  change (g8 E = true) → (g5 E = true) → (¬ (g2486 E = true)) → False
  exact pattern_15 (g5 E) (g8 E)
private theorem sat_2178 (E : Nat → Bool) : (valuation E).satisfies [.neg 2486, .neg 2485] := by
  change (g2487 E = true) → (g2486 E = true) → False
  exact pattern_18 (g2484 E) (g2485 E) (g2486 E)
private theorem sat_2179 (E : Nat → Bool) : (valuation E).satisfies [.neg 2486, .neg 2484] := by
  change (g2487 E = true) → (g2485 E = true) → False
  exact pattern_19 (g2484 E) (g2485 E) (g2486 E)
private theorem sat_2180 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 15, .pos 2489] := by
  change (g19 E = true) → (g16 E = true) → (¬ (g2490 E = true)) → False
  exact pattern_15 (g16 E) (g19 E)
private theorem sat_2181 (E : Nat → Bool) : (valuation E).satisfies [.neg 2490, .neg 2489] := by
  change (g2491 E = true) → (g2490 E = true) → False
  exact pattern_18 (g2488 E) (g2489 E) (g2490 E)
private theorem sat_2182 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 19, .pos 2493] := by
  change (g23 E = true) → (g20 E = true) → (¬ (g2494 E = true)) → False
  exact pattern_15 (g20 E) (g23 E)
private theorem sat_2183 (E : Nat → Bool) : (valuation E).satisfies [.neg 2494, .neg 2493] := by
  change (g2495 E = true) → (g2494 E = true) → False
  exact pattern_18 (g2492 E) (g2493 E) (g2494 E)
private theorem sat_2184 (E : Nat → Bool) : (valuation E).satisfies [.neg 2495, .neg 27] := by
  change (g2496 E = true) → (g28 E = true) → False
  exact pattern_18 (g12 E) (g24 E) (g28 E)
private theorem sat_2185 (E : Nat → Bool) : (valuation E).satisfies [.neg 2495, .neg 11] := by
  change (g2496 E = true) → (g12 E = true) → False
  exact pattern_20 (g12 E) (g24 E) (g28 E)
private theorem sat_2186 (E : Nat → Bool) : (valuation E).satisfies [.neg 2496, .neg 28] := by
  change (g2497 E = true) → (g29 E = true) → False
  exact pattern_18 (g13 E) (g25 E) (g29 E)
private theorem sat_2188 (E : Nat → Bool) : (valuation E).satisfies [.neg 2498, .pos 1] := by
  change (g2499 E = true) → (¬ (g2 E = true)) → False
  exact pattern_1 (g2 E) (g7 E)
private theorem sat_2189 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .neg 1, .pos 2498] := by
  change (g7 E = true) → (g2 E = true) → (¬ (g2499 E = true)) → False
  exact pattern_15 (g2 E) (g7 E)
private theorem sat_2190 (E : Nat → Bool) : (valuation E).satisfies [.neg 2499, .pos 5] := by
  change (g2500 E = true) → (¬ (g6 E = true)) → False
  exact pattern_1 (g6 E) (g7 E)
private theorem sat_2191 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .neg 5, .pos 2499] := by
  change (g7 E = true) → (g6 E = true) → (¬ (g2500 E = true)) → False
  exact pattern_15 (g6 E) (g7 E)
private theorem sat_2192 (E : Nat → Bool) : (valuation E).satisfies [.neg 2500, .neg 2499] := by
  change (g2501 E = true) → (g2500 E = true) → False
  exact pattern_18 (g2498 E) (g2499 E) (g2500 E)
private theorem sat_2193 (E : Nat → Bool) : (valuation E).satisfies [.neg 16, .neg 8, .pos 2501] := by
  change (g17 E = true) → (g9 E = true) → (¬ (g2502 E = true)) → False
  exact pattern_15 (g9 E) (g17 E)
private theorem sat_2194 (E : Nat → Bool) : (valuation E).satisfies [.neg 17, .neg 16, .pos 2503] := by
  change (g18 E = true) → (g17 E = true) → (¬ (g2504 E = true)) → False
  exact pattern_15 (g17 E) (g18 E)
private theorem sat_2195 (E : Nat → Bool) : (valuation E).satisfies [.neg 2504, .neg 2503] := by
  change (g2505 E = true) → (g2504 E = true) → False
  exact pattern_18 (g2502 E) (g2503 E) (g2504 E)
private theorem sat_2196 (E : Nat → Bool) : (valuation E).satisfies [.neg 2504, .neg 2501] := by
  change (g2505 E = true) → (g2502 E = true) → False
  exact pattern_20 (g2502 E) (g2503 E) (g2504 E)
private theorem sat_2197 (E : Nat → Bool) : (valuation E).satisfies [.neg 20, .neg 9, .pos 2505] := by
  change (g21 E = true) → (g10 E = true) → (¬ (g2506 E = true)) → False
  exact pattern_15 (g10 E) (g21 E)
private theorem sat_2198 (E : Nat → Bool) : (valuation E).satisfies [.neg 21, .neg 20, .pos 2507] := by
  change (g22 E = true) → (g21 E = true) → (¬ (g2508 E = true)) → False
  exact pattern_15 (g21 E) (g22 E)
private theorem sat_2199 (E : Nat → Bool) : (valuation E).satisfies [.neg 2508, .neg 2507] := by
  change (g2509 E = true) → (g2508 E = true) → False
  exact pattern_18 (g2506 E) (g2507 E) (g2508 E)
private theorem sat_2200 (E : Nat → Bool) : (valuation E).satisfies [.neg 2508, .neg 2505] := by
  change (g2509 E = true) → (g2506 E = true) → False
  exact pattern_20 (g2506 E) (g2507 E) (g2508 E)
private theorem sat_2201 (E : Nat → Bool) : (valuation E).satisfies [.neg 2509, .neg 24] := by
  change (g2510 E = true) → (g25 E = true) → False
  exact pattern_18 (g11 E) (g24 E) (g25 E)
private theorem sat_2202 (E : Nat → Bool) : (valuation E).satisfies [.neg 2509, .neg 10] := by
  change (g2510 E = true) → (g11 E = true) → False
  exact pattern_20 (g11 E) (g24 E) (g25 E)
private theorem sat_2203 (E : Nat → Bool) : (valuation E).satisfies [.neg 2510, .neg 13] := by
  change (g2511 E = true) → (g14 E = true) → False
  exact pattern_20 (g14 E) (g28 E) (g29 E)
private theorem sat_2205 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 1, .pos 2512] := by
  change (g8 E = true) → (g2 E = true) → (¬ (g2513 E = true)) → False
  exact pattern_15 (g2 E) (g8 E)
private theorem sat_2206 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 5, .pos 2513] := by
  change (g8 E = true) → (g6 E = true) → (¬ (g2514 E = true)) → False
  exact pattern_15 (g6 E) (g8 E)
private theorem sat_2207 (E : Nat → Bool) : (valuation E).satisfies [.neg 2514, .neg 2513] := by
  change (g2515 E = true) → (g2514 E = true) → False
  exact pattern_18 (g2512 E) (g2513 E) (g2514 E)
private theorem sat_2208 (E : Nat → Bool) : (valuation E).satisfies [.neg 2514, .neg 2512] := by
  change (g2515 E = true) → (g2513 E = true) → False
  exact pattern_19 (g2512 E) (g2513 E) (g2514 E)
private theorem sat_2209 (E : Nat → Bool) : (valuation E).satisfies [.neg 16, .neg 8, .pos 2515] := by
  change (g17 E = true) → (g9 E = true) → (¬ (g2516 E = true)) → False
  exact pattern_15 (g9 E) (g17 E)
private theorem sat_2210 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 8, .pos 2516] := by
  change (g19 E = true) → (g9 E = true) → (¬ (g2517 E = true)) → False
  exact pattern_15 (g9 E) (g19 E)
private theorem sat_2211 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 16, .pos 2517] := by
  change (g19 E = true) → (g17 E = true) → (¬ (g2518 E = true)) → False
  exact pattern_15 (g17 E) (g19 E)
private theorem sat_2212 (E : Nat → Bool) : (valuation E).satisfies [.neg 2518, .neg 2517] := by
  change (g2519 E = true) → (g2518 E = true) → False
  exact pattern_18 (g2516 E) (g2517 E) (g2518 E)
private theorem sat_2213 (E : Nat → Bool) : (valuation E).satisfies [.neg 2518, .neg 2516] := by
  change (g2519 E = true) → (g2517 E = true) → False
  exact pattern_19 (g2516 E) (g2517 E) (g2518 E)
private theorem sat_2214 (E : Nat → Bool) : (valuation E).satisfies [.neg 2518, .neg 2515] := by
  change (g2519 E = true) → (g2516 E = true) → False
  exact pattern_20 (g2516 E) (g2517 E) (g2518 E)
private theorem sat_2215 (E : Nat → Bool) : (valuation E).satisfies [.neg 20, .neg 9, .pos 2519] := by
  change (g21 E = true) → (g10 E = true) → (¬ (g2520 E = true)) → False
  exact pattern_15 (g10 E) (g21 E)
private theorem sat_2216 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 9, .pos 2520] := by
  change (g23 E = true) → (g10 E = true) → (¬ (g2521 E = true)) → False
  exact pattern_15 (g10 E) (g23 E)
private theorem sat_2217 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 20, .pos 2521] := by
  change (g23 E = true) → (g21 E = true) → (¬ (g2522 E = true)) → False
  exact pattern_15 (g21 E) (g23 E)
private theorem sat_2218 (E : Nat → Bool) : (valuation E).satisfies [.neg 2522, .neg 2521] := by
  change (g2523 E = true) → (g2522 E = true) → False
  exact pattern_18 (g2520 E) (g2521 E) (g2522 E)
private theorem sat_2219 (E : Nat → Bool) : (valuation E).satisfies [.neg 2522, .neg 2520] := by
  change (g2523 E = true) → (g2521 E = true) → False
  exact pattern_19 (g2520 E) (g2521 E) (g2522 E)
private theorem sat_2220 (E : Nat → Bool) : (valuation E).satisfies [.neg 2522, .neg 2519] := by
  change (g2523 E = true) → (g2520 E = true) → False
  exact pattern_20 (g2520 E) (g2521 E) (g2522 E)
private theorem sat_2221 (E : Nat → Bool) : (valuation E).satisfies [.neg 2523, .neg 25] := by
  change (g2524 E = true) → (g26 E = true) → False
  exact pattern_18 (g11 E) (g24 E) (g26 E)
private theorem sat_2222 (E : Nat → Bool) : (valuation E).satisfies [.neg 2523, .neg 10] := by
  change (g2524 E = true) → (g11 E = true) → False
  exact pattern_20 (g11 E) (g24 E) (g26 E)
private theorem sat_2223 (E : Nat → Bool) : (valuation E).satisfies [.neg 2524, .neg 28] := by
  change (g2525 E = true) → (g29 E = true) → False
  exact pattern_18 (g13 E) (g27 E) (g29 E)
private theorem sat_2224 (E : Nat → Bool) : (valuation E).satisfies [.neg 2524, .neg 26] := by
  change (g2525 E = true) → (g27 E = true) → False
  exact pattern_19 (g13 E) (g27 E) (g29 E)
private theorem sat_2225 (E : Nat → Bool) : (valuation E).satisfies [.neg 2524, .neg 12] := by
  change (g2525 E = true) → (g13 E = true) → False
  exact pattern_20 (g13 E) (g27 E) (g29 E)
private theorem sat_2227 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 1, .pos 2526] := by
  change (g8 E = true) → (g2 E = true) → (¬ (g2527 E = true)) → False
  exact pattern_15 (g2 E) (g8 E)
private theorem sat_2228 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 6, .pos 2527] := by
  change (g8 E = true) → (g7 E = true) → (¬ (g2528 E = true)) → False
  exact pattern_15 (g7 E) (g8 E)
private theorem sat_2229 (E : Nat → Bool) : (valuation E).satisfies [.neg 2528, .neg 2527] := by
  change (g2529 E = true) → (g2528 E = true) → False
  exact pattern_18 (g2526 E) (g2527 E) (g2528 E)
private theorem sat_2230 (E : Nat → Bool) : (valuation E).satisfies [.neg 2528, .neg 2526] := by
  change (g2529 E = true) → (g2527 E = true) → False
  exact pattern_19 (g2526 E) (g2527 E) (g2528 E)
private theorem sat_2231 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 8, .pos 2530] := by
  change (g19 E = true) → (g9 E = true) → (¬ (g2531 E = true)) → False
  exact pattern_15 (g9 E) (g19 E)
private theorem sat_2232 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 17, .pos 2531] := by
  change (g19 E = true) → (g18 E = true) → (¬ (g2532 E = true)) → False
  exact pattern_15 (g18 E) (g19 E)
private theorem sat_2233 (E : Nat → Bool) : (valuation E).satisfies [.neg 2532, .neg 2531] := by
  change (g2533 E = true) → (g2532 E = true) → False
  exact pattern_18 (g2530 E) (g2531 E) (g2532 E)
private theorem sat_2234 (E : Nat → Bool) : (valuation E).satisfies [.neg 2532, .neg 2530] := by
  change (g2533 E = true) → (g2531 E = true) → False
  exact pattern_19 (g2530 E) (g2531 E) (g2532 E)
private theorem sat_2235 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 9, .pos 2534] := by
  change (g23 E = true) → (g10 E = true) → (¬ (g2535 E = true)) → False
  exact pattern_15 (g10 E) (g23 E)
private theorem sat_2236 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 21, .pos 2535] := by
  change (g23 E = true) → (g22 E = true) → (¬ (g2536 E = true)) → False
  exact pattern_15 (g22 E) (g23 E)
private theorem sat_2237 (E : Nat → Bool) : (valuation E).satisfies [.neg 2536, .neg 2535] := by
  change (g2537 E = true) → (g2536 E = true) → False
  exact pattern_18 (g2534 E) (g2535 E) (g2536 E)
private theorem sat_2238 (E : Nat → Bool) : (valuation E).satisfies [.neg 2536, .neg 2534] := by
  change (g2537 E = true) → (g2535 E = true) → False
  exact pattern_19 (g2534 E) (g2535 E) (g2536 E)
private theorem sat_2239 (E : Nat → Bool) : (valuation E).satisfies [.neg 2537, .neg 24] := by
  change (g2538 E = true) → (g25 E = true) → False
  exact pattern_19 (g11 E) (g25 E) (g26 E)
private theorem sat_2240 (E : Nat → Bool) : (valuation E).satisfies [.neg 2537, .neg 10] := by
  change (g2538 E = true) → (g11 E = true) → False
  exact pattern_20 (g11 E) (g25 E) (g26 E)
private theorem sat_2241 (E : Nat → Bool) : (valuation E).satisfies [.neg 2538, .neg 26] := by
  change (g2539 E = true) → (g27 E = true) → False
  exact pattern_19 (g12 E) (g27 E) (g28 E)
private theorem sat_2242 (E : Nat → Bool) : (valuation E).satisfies [.neg 2538, .neg 11] := by
  change (g2539 E = true) → (g12 E = true) → False
  exact pattern_20 (g12 E) (g27 E) (g28 E)
private theorem sat_2244 (E : Nat → Bool) : (valuation E).satisfies [.neg 3, .neg 2, .pos 2539] := by
  change (g4 E = true) → (g3 E = true) → (¬ (g2540 E = true)) → False
  exact pattern_15 (g3 E) (g4 E)
private theorem sat_2245 (E : Nat → Bool) : (valuation E).satisfies [.neg 2542, .neg 2539] := by
  change (g2543 E = true) → (g2540 E = true) → False
  exact pattern_20 (g2540 E) (g2541 E) (g2542 E)
private theorem sat_2246 (E : Nat → Bool) : (valuation E).satisfies [.neg 9, .neg 8, .pos 2543] := by
  change (g10 E = true) → (g9 E = true) → (¬ (g2544 E = true)) → False
  exact pattern_15 (g9 E) (g10 E)
private theorem sat_2247 (E : Nat → Bool) : (valuation E).satisfies [.neg 2546, .neg 2543] := by
  change (g2547 E = true) → (g2544 E = true) → False
  exact pattern_20 (g2544 E) (g2545 E) (g2546 E)
private theorem sat_2248 (E : Nat → Bool) : (valuation E).satisfies [.neg 2547, .neg 23] := by
  change (g2548 E = true) → (g24 E = true) → False
  exact pattern_18 (g17 E) (g21 E) (g24 E)
private theorem sat_2249 (E : Nat → Bool) : (valuation E).satisfies [.neg 2548, .neg 24] := by
  change (g2549 E = true) → (g25 E = true) → False
  exact pattern_18 (g18 E) (g22 E) (g25 E)
private theorem sat_2250 (E : Nat → Bool) : (valuation E).satisfies [.neg 2549, .neg 25] := by
  change (g2550 E = true) → (g26 E = true) → False
  exact pattern_18 (g19 E) (g23 E) (g26 E)
private theorem sat_2252 (E : Nat → Bool) : (valuation E).satisfies [.neg 3, .neg 2, .pos 2550] := by
  change (g4 E = true) → (g3 E = true) → (¬ (g2551 E = true)) → False
  exact pattern_15 (g3 E) (g4 E)
private theorem sat_2253 (E : Nat → Bool) : (valuation E).satisfies [.neg 5, .neg 2, .pos 2551] := by
  change (g6 E = true) → (g3 E = true) → (¬ (g2552 E = true)) → False
  exact pattern_15 (g3 E) (g6 E)
private theorem sat_2254 (E : Nat → Bool) : (valuation E).satisfies [.neg 2553, .neg 2551] := by
  change (g2554 E = true) → (g2552 E = true) → False
  exact pattern_19 (g2551 E) (g2552 E) (g2553 E)
private theorem sat_2255 (E : Nat → Bool) : (valuation E).satisfies [.neg 2553, .neg 2550] := by
  change (g2554 E = true) → (g2551 E = true) → False
  exact pattern_20 (g2551 E) (g2552 E) (g2553 E)
private theorem sat_2256 (E : Nat → Bool) : (valuation E).satisfies [.neg 9, .neg 8, .pos 2554] := by
  change (g10 E = true) → (g9 E = true) → (¬ (g2555 E = true)) → False
  exact pattern_15 (g9 E) (g10 E)
private theorem sat_2257 (E : Nat → Bool) : (valuation E).satisfies [.neg 11, .neg 9, .pos 2556] := by
  change (g12 E = true) → (g10 E = true) → (¬ (g2557 E = true)) → False
  exact pattern_15 (g10 E) (g12 E)
private theorem sat_2258 (E : Nat → Bool) : (valuation E).satisfies [.neg 2557, .neg 2556] := by
  change (g2558 E = true) → (g2557 E = true) → False
  exact pattern_18 (g2555 E) (g2556 E) (g2557 E)
private theorem sat_2259 (E : Nat → Bool) : (valuation E).satisfies [.neg 2557, .neg 2554] := by
  change (g2558 E = true) → (g2555 E = true) → False
  exact pattern_20 (g2555 E) (g2556 E) (g2557 E)
private theorem sat_2260 (E : Nat → Bool) : (valuation E).satisfies [.neg 2558, .neg 23] := by
  change (g2559 E = true) → (g24 E = true) → False
  exact pattern_18 (g16 E) (g20 E) (g24 E)
private theorem sat_2261 (E : Nat → Bool) : (valuation E).satisfies [.neg 2558, .neg 19] := by
  change (g2559 E = true) → (g20 E = true) → False
  exact pattern_19 (g16 E) (g20 E) (g24 E)
private theorem sat_2262 (E : Nat → Bool) : (valuation E).satisfies [.neg 2558, .neg 15] := by
  change (g2559 E = true) → (g16 E = true) → False
  exact pattern_20 (g16 E) (g20 E) (g24 E)
private theorem sat_2263 (E : Nat → Bool) : (valuation E).satisfies [.neg 2559, .neg 26] := by
  change (g2560 E = true) → (g27 E = true) → False
  exact pattern_18 (g18 E) (g22 E) (g27 E)
private theorem sat_2264 (E : Nat → Bool) : (valuation E).satisfies [.neg 2559, .neg 21] := by
  change (g2560 E = true) → (g22 E = true) → False
  exact pattern_19 (g18 E) (g22 E) (g27 E)
private theorem sat_2265 (E : Nat → Bool) : (valuation E).satisfies [.neg 2560, .neg 27] := by
  change (g2561 E = true) → (g28 E = true) → False
  exact pattern_18 (g19 E) (g23 E) (g28 E)
private theorem sat_2266 (E : Nat → Bool) : (valuation E).satisfies [.neg 2560, .neg 22] := by
  change (g2561 E = true) → (g23 E = true) → False
  exact pattern_19 (g19 E) (g23 E) (g28 E)
private theorem sat_2267 (E : Nat → Bool) : (valuation E).satisfies [.neg 2560, .neg 18] := by
  change (g2561 E = true) → (g19 E = true) → False
  exact pattern_20 (g19 E) (g23 E) (g28 E)
private theorem sat_2269 (E : Nat → Bool) : (valuation E).satisfies [.neg 2561, .pos 2] := by
  change (g2562 E = true) → (¬ (g3 E = true)) → False
  exact pattern_1 (g3 E) (g4 E)
private theorem sat_2270 (E : Nat → Bool) : (valuation E).satisfies [.neg 2561, .pos 3] := by
  change (g2562 E = true) → (¬ (g4 E = true)) → False
  exact pattern_2 (g3 E) (g4 E)
private theorem sat_2271 (E : Nat → Bool) : (valuation E).satisfies [.neg 3, .neg 2, .pos 2561] := by
  change (g4 E = true) → (g3 E = true) → (¬ (g2562 E = true)) → False
  exact pattern_15 (g3 E) (g4 E)
private theorem sat_2272 (E : Nat → Bool) : (valuation E).satisfies [.neg 2562, .pos 2] := by
  change (g2563 E = true) → (¬ (g3 E = true)) → False
  exact pattern_1 (g3 E) (g7 E)
private theorem sat_2273 (E : Nat → Bool) : (valuation E).satisfies [.neg 2562, .pos 6] := by
  change (g2563 E = true) → (¬ (g7 E = true)) → False
  exact pattern_2 (g3 E) (g7 E)
private theorem sat_2274 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .neg 2, .pos 2562] := by
  change (g7 E = true) → (g3 E = true) → (¬ (g2563 E = true)) → False
  exact pattern_15 (g3 E) (g7 E)
private theorem sat_2275 (E : Nat → Bool) : (valuation E).satisfies [.neg 2563, .pos 3] := by
  change (g2564 E = true) → (¬ (g4 E = true)) → False
  exact pattern_1 (g4 E) (g7 E)
private theorem sat_2276 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .neg 3, .pos 2563] := by
  change (g7 E = true) → (g4 E = true) → (¬ (g2564 E = true)) → False
  exact pattern_15 (g4 E) (g7 E)
private theorem sat_2277 (E : Nat → Bool) : (valuation E).satisfies [.neg 2564, .neg 2563] := by
  change (g2565 E = true) → (g2564 E = true) → False
  exact pattern_18 (g2562 E) (g2563 E) (g2564 E)
private theorem sat_2278 (E : Nat → Bool) : (valuation E).satisfies [.neg 2564, .neg 2562] := by
  change (g2565 E = true) → (g2563 E = true) → False
  exact pattern_19 (g2562 E) (g2563 E) (g2564 E)
private theorem sat_2279 (E : Nat → Bool) : (valuation E).satisfies [.neg 2564, .neg 2561] := by
  change (g2565 E = true) → (g2562 E = true) → False
  exact pattern_20 (g2562 E) (g2563 E) (g2564 E)
private theorem sat_2280 (E : Nat → Bool) : (valuation E).satisfies [.pos 2561, .pos 2562, .pos 2563, .pos 2564] := by
  change (¬ (g2562 E = true)) → (¬ (g2563 E = true)) → (¬ (g2564 E = true)) → (¬ (g2565 E = true)) → False
  exact pattern_21 (g2562 E) (g2563 E) (g2564 E)
private theorem sat_2281 (E : Nat → Bool) : (valuation E).satisfies [.neg 9, .neg 8, .pos 2565] := by
  change (g10 E = true) → (g9 E = true) → (¬ (g2566 E = true)) → False
  exact pattern_15 (g9 E) (g10 E)
private theorem sat_2282 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 8, .pos 2566] := by
  change (g13 E = true) → (g9 E = true) → (¬ (g2567 E = true)) → False
  exact pattern_15 (g9 E) (g13 E)
private theorem sat_2283 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 9, .pos 2567] := by
  change (g13 E = true) → (g10 E = true) → (¬ (g2568 E = true)) → False
  exact pattern_15 (g10 E) (g13 E)
private theorem sat_2284 (E : Nat → Bool) : (valuation E).satisfies [.neg 2568, .neg 2567] := by
  change (g2569 E = true) → (g2568 E = true) → False
  exact pattern_18 (g2566 E) (g2567 E) (g2568 E)
private theorem sat_2285 (E : Nat → Bool) : (valuation E).satisfies [.neg 2568, .neg 2566] := by
  change (g2569 E = true) → (g2567 E = true) → False
  exact pattern_19 (g2566 E) (g2567 E) (g2568 E)
private theorem sat_2286 (E : Nat → Bool) : (valuation E).satisfies [.neg 2568, .neg 2565] := by
  change (g2569 E = true) → (g2566 E = true) → False
  exact pattern_20 (g2566 E) (g2567 E) (g2568 E)
private theorem sat_2287 (E : Nat → Bool) : (valuation E).satisfies [.neg 2569, .neg 24] := by
  change (g2570 E = true) → (g25 E = true) → False
  exact pattern_18 (g16 E) (g20 E) (g25 E)
private theorem sat_2288 (E : Nat → Bool) : (valuation E).satisfies [.neg 2569, .neg 19] := by
  change (g2570 E = true) → (g20 E = true) → False
  exact pattern_19 (g16 E) (g20 E) (g25 E)
private theorem sat_2289 (E : Nat → Bool) : (valuation E).satisfies [.neg 2569, .neg 15] := by
  change (g2570 E = true) → (g16 E = true) → False
  exact pattern_20 (g16 E) (g20 E) (g25 E)
private theorem sat_2290 (E : Nat → Bool) : (valuation E).satisfies [.pos 15, .pos 19, .pos 24, .pos 2569] := by
  change (¬ (g16 E = true)) → (¬ (g20 E = true)) → (¬ (g25 E = true)) → (¬ (g2570 E = true)) → False
  exact pattern_21 (g16 E) (g20 E) (g25 E)
private theorem sat_2291 (E : Nat → Bool) : (valuation E).satisfies [.neg 2570, .neg 26] := by
  change (g2571 E = true) → (g27 E = true) → False
  exact pattern_18 (g17 E) (g21 E) (g27 E)
private theorem sat_2292 (E : Nat → Bool) : (valuation E).satisfies [.neg 2570, .neg 20] := by
  change (g2571 E = true) → (g21 E = true) → False
  exact pattern_19 (g17 E) (g21 E) (g27 E)
private theorem sat_2293 (E : Nat → Bool) : (valuation E).satisfies [.neg 2570, .neg 16] := by
  change (g2571 E = true) → (g17 E = true) → False
  exact pattern_20 (g17 E) (g21 E) (g27 E)
private theorem sat_2294 (E : Nat → Bool) : (valuation E).satisfies [.neg 2571, .neg 28] := by
  change (g2572 E = true) → (g29 E = true) → False
  exact pattern_18 (g19 E) (g23 E) (g29 E)
private theorem sat_2295 (E : Nat → Bool) : (valuation E).satisfies [.neg 2571, .neg 22] := by
  change (g2572 E = true) → (g23 E = true) → False
  exact pattern_19 (g19 E) (g23 E) (g29 E)
private theorem sat_2296 (E : Nat → Bool) : (valuation E).satisfies [.neg 2571, .neg 18] := by
  change (g2572 E = true) → (g19 E = true) → False
  exact pattern_20 (g19 E) (g23 E) (g29 E)
private theorem sat_2298 (E : Nat → Bool) : (valuation E).satisfies [.neg 2572, .pos 2] := by
  change (g2573 E = true) → (¬ (g3 E = true)) → False
  exact pattern_1 (g3 E) (g4 E)
private theorem sat_2299 (E : Nat → Bool) : (valuation E).satisfies [.neg 3, .neg 2, .pos 2572] := by
  change (g4 E = true) → (g3 E = true) → (¬ (g2573 E = true)) → False
  exact pattern_15 (g3 E) (g4 E)
private theorem sat_2300 (E : Nat → Bool) : (valuation E).satisfies [.neg 2573, .pos 2] := by
  change (g2574 E = true) → (¬ (g3 E = true)) → False
  exact pattern_1 (g3 E) (g8 E)
private theorem sat_2301 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 2, .pos 2573] := by
  change (g8 E = true) → (g3 E = true) → (¬ (g2574 E = true)) → False
  exact pattern_15 (g3 E) (g8 E)
private theorem sat_2302 (E : Nat → Bool) : (valuation E).satisfies [.neg 2574, .pos 3] := by
  change (g2575 E = true) → (¬ (g4 E = true)) → False
  exact pattern_1 (g4 E) (g8 E)
private theorem sat_2303 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 3, .pos 2574] := by
  change (g8 E = true) → (g4 E = true) → (¬ (g2575 E = true)) → False
  exact pattern_15 (g4 E) (g8 E)
private theorem sat_2304 (E : Nat → Bool) : (valuation E).satisfies [.neg 2575, .neg 2574] := by
  change (g2576 E = true) → (g2575 E = true) → False
  exact pattern_18 (g2573 E) (g2574 E) (g2575 E)
private theorem sat_2305 (E : Nat → Bool) : (valuation E).satisfies [.neg 2575, .neg 2573] := by
  change (g2576 E = true) → (g2574 E = true) → False
  exact pattern_19 (g2573 E) (g2574 E) (g2575 E)
private theorem sat_2306 (E : Nat → Bool) : (valuation E).satisfies [.neg 2575, .neg 2572] := by
  change (g2576 E = true) → (g2573 E = true) → False
  exact pattern_20 (g2573 E) (g2574 E) (g2575 E)
private theorem sat_2307 (E : Nat → Bool) : (valuation E).satisfies [.pos 2572, .pos 2573, .pos 2574, .pos 2575] := by
  change (¬ (g2573 E = true)) → (¬ (g2574 E = true)) → (¬ (g2575 E = true)) → (¬ (g2576 E = true)) → False
  exact pattern_21 (g2573 E) (g2574 E) (g2575 E)
private theorem sat_2308 (E : Nat → Bool) : (valuation E).satisfies [.neg 2576, .pos 8] := by
  change (g2577 E = true) → (¬ (g9 E = true)) → False
  exact pattern_1 (g9 E) (g10 E)
private theorem sat_2309 (E : Nat → Bool) : (valuation E).satisfies [.neg 2576, .pos 9] := by
  change (g2577 E = true) → (¬ (g10 E = true)) → False
  exact pattern_2 (g9 E) (g10 E)
private theorem sat_2310 (E : Nat → Bool) : (valuation E).satisfies [.neg 9, .neg 8, .pos 2576] := by
  change (g10 E = true) → (g9 E = true) → (¬ (g2577 E = true)) → False
  exact pattern_15 (g9 E) (g10 E)
private theorem sat_2311 (E : Nat → Bool) : (valuation E).satisfies [.neg 2577, .pos 8] := by
  change (g2578 E = true) → (¬ (g9 E = true)) → False
  exact pattern_1 (g9 E) (g14 E)
private theorem sat_2312 (E : Nat → Bool) : (valuation E).satisfies [.neg 2577, .pos 13] := by
  change (g2578 E = true) → (¬ (g14 E = true)) → False
  exact pattern_2 (g9 E) (g14 E)
private theorem sat_2313 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 8, .pos 2577] := by
  change (g14 E = true) → (g9 E = true) → (¬ (g2578 E = true)) → False
  exact pattern_15 (g9 E) (g14 E)
private theorem sat_2314 (E : Nat → Bool) : (valuation E).satisfies [.neg 2578, .pos 9] := by
  change (g2579 E = true) → (¬ (g10 E = true)) → False
  exact pattern_1 (g10 E) (g14 E)
private theorem sat_2315 (E : Nat → Bool) : (valuation E).satisfies [.neg 2578, .pos 13] := by
  change (g2579 E = true) → (¬ (g14 E = true)) → False
  exact pattern_2 (g10 E) (g14 E)
private theorem sat_2316 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 9, .pos 2578] := by
  change (g14 E = true) → (g10 E = true) → (¬ (g2579 E = true)) → False
  exact pattern_15 (g10 E) (g14 E)
private theorem sat_2317 (E : Nat → Bool) : (valuation E).satisfies [.neg 2579, .neg 2578] := by
  change (g2580 E = true) → (g2579 E = true) → False
  exact pattern_18 (g2577 E) (g2578 E) (g2579 E)
private theorem sat_2318 (E : Nat → Bool) : (valuation E).satisfies [.neg 2579, .neg 2577] := by
  change (g2580 E = true) → (g2578 E = true) → False
  exact pattern_19 (g2577 E) (g2578 E) (g2579 E)
private theorem sat_2319 (E : Nat → Bool) : (valuation E).satisfies [.neg 2579, .neg 2576] := by
  change (g2580 E = true) → (g2577 E = true) → False
  exact pattern_20 (g2577 E) (g2578 E) (g2579 E)
private theorem sat_2320 (E : Nat → Bool) : (valuation E).satisfies [.pos 2576, .pos 2577, .pos 2578, .pos 2579] := by
  change (¬ (g2577 E = true)) → (¬ (g2578 E = true)) → (¬ (g2579 E = true)) → (¬ (g2580 E = true)) → False
  exact pattern_21 (g2577 E) (g2578 E) (g2579 E)
private theorem sat_2321 (E : Nat → Bool) : (valuation E).satisfies [.neg 2580, .neg 25] := by
  change (g2581 E = true) → (g26 E = true) → False
  exact pattern_18 (g16 E) (g20 E) (g26 E)
private theorem sat_2322 (E : Nat → Bool) : (valuation E).satisfies [.neg 2580, .neg 19] := by
  change (g2581 E = true) → (g20 E = true) → False
  exact pattern_19 (g16 E) (g20 E) (g26 E)
private theorem sat_2323 (E : Nat → Bool) : (valuation E).satisfies [.neg 2580, .neg 15] := by
  change (g2581 E = true) → (g16 E = true) → False
  exact pattern_20 (g16 E) (g20 E) (g26 E)
private theorem sat_2324 (E : Nat → Bool) : (valuation E).satisfies [.pos 15, .pos 19, .pos 25, .pos 2580] := by
  change (¬ (g16 E = true)) → (¬ (g20 E = true)) → (¬ (g26 E = true)) → (¬ (g2581 E = true)) → False
  exact pattern_21 (g16 E) (g20 E) (g26 E)
private theorem sat_2325 (E : Nat → Bool) : (valuation E).satisfies [.neg 2581, .neg 27] := by
  change (g2582 E = true) → (g28 E = true) → False
  exact pattern_18 (g17 E) (g21 E) (g28 E)
private theorem sat_2326 (E : Nat → Bool) : (valuation E).satisfies [.neg 2581, .neg 20] := by
  change (g2582 E = true) → (g21 E = true) → False
  exact pattern_19 (g17 E) (g21 E) (g28 E)
private theorem sat_2327 (E : Nat → Bool) : (valuation E).satisfies [.neg 2581, .neg 16] := by
  change (g2582 E = true) → (g17 E = true) → False
  exact pattern_20 (g17 E) (g21 E) (g28 E)
private theorem sat_2328 (E : Nat → Bool) : (valuation E).satisfies [.pos 16, .pos 20, .pos 27, .pos 2581] := by
  change (¬ (g17 E = true)) → (¬ (g21 E = true)) → (¬ (g28 E = true)) → (¬ (g2582 E = true)) → False
  exact pattern_21 (g17 E) (g21 E) (g28 E)
private theorem sat_2329 (E : Nat → Bool) : (valuation E).satisfies [.neg 2582, .neg 28] := by
  change (g2583 E = true) → (g29 E = true) → False
  exact pattern_18 (g18 E) (g22 E) (g29 E)
private theorem sat_2330 (E : Nat → Bool) : (valuation E).satisfies [.neg 2582, .neg 21] := by
  change (g2583 E = true) → (g22 E = true) → False
  exact pattern_19 (g18 E) (g22 E) (g29 E)
private theorem sat_2331 (E : Nat → Bool) : (valuation E).satisfies [.neg 2582, .neg 17] := by
  change (g2583 E = true) → (g18 E = true) → False
  exact pattern_20 (g18 E) (g22 E) (g29 E)
private theorem sat_2332 (E : Nat → Bool) : (valuation E).satisfies [.pos 17, .pos 21, .pos 28, .pos 2582] := by
  change (¬ (g18 E = true)) → (¬ (g22 E = true)) → (¬ (g29 E = true)) → (¬ (g2583 E = true)) → False
  exact pattern_21 (g18 E) (g22 E) (g29 E)
private theorem sat_2334 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .neg 4, .pos 2599] := by
  change (g7 E = true) → (g5 E = true) → (¬ (g2600 E = true)) → False
  exact pattern_15 (g5 E) (g7 E)
private theorem sat_2335 (E : Nat → Bool) : (valuation E).satisfies [.neg 2600, .neg 2599] := by
  change (g2601 E = true) → (g2600 E = true) → False
  exact pattern_18 (g2598 E) (g2599 E) (g2600 E)
private theorem sat_2336 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 10, .pos 2603] := by
  change (g13 E = true) → (g11 E = true) → (¬ (g2604 E = true)) → False
  exact pattern_15 (g11 E) (g13 E)
private theorem sat_2337 (E : Nat → Bool) : (valuation E).satisfies [.neg 2604, .neg 2603] := by
  change (g2605 E = true) → (g2604 E = true) → False
  exact pattern_18 (g2602 E) (g2603 E) (g2604 E)
private theorem sat_2338 (E : Nat → Bool) : (valuation E).satisfies [.neg 21, .neg 19, .pos 2607] := by
  change (g22 E = true) → (g20 E = true) → (¬ (g2608 E = true)) → False
  exact pattern_15 (g20 E) (g22 E)
private theorem sat_2339 (E : Nat → Bool) : (valuation E).satisfies [.neg 2608, .neg 2607] := by
  change (g2609 E = true) → (g2608 E = true) → False
  exact pattern_18 (g2606 E) (g2607 E) (g2608 E)
private theorem sat_2340 (E : Nat → Bool) : (valuation E).satisfies [.neg 2609, .neg 26] := by
  change (g2610 E = true) → (g27 E = true) → False
  exact pattern_18 (g17 E) (g24 E) (g27 E)
private theorem sat_2341 (E : Nat → Bool) : (valuation E).satisfies [.neg 2610, .neg 28] := by
  change (g2611 E = true) → (g29 E = true) → False
  exact pattern_18 (g19 E) (g26 E) (g29 E)
private theorem sat_2343 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .neg 2, .pos 2626] := by
  change (g7 E = true) → (g3 E = true) → (¬ (g2627 E = true)) → False
  exact pattern_15 (g3 E) (g7 E)
private theorem sat_2344 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .neg 5, .pos 2627] := by
  change (g7 E = true) → (g6 E = true) → (¬ (g2628 E = true)) → False
  exact pattern_15 (g6 E) (g7 E)
private theorem sat_2345 (E : Nat → Bool) : (valuation E).satisfies [.neg 2628, .neg 2627] := by
  change (g2629 E = true) → (g2628 E = true) → False
  exact pattern_18 (g2626 E) (g2627 E) (g2628 E)
private theorem sat_2346 (E : Nat → Bool) : (valuation E).satisfies [.neg 2628, .neg 2626] := by
  change (g2629 E = true) → (g2627 E = true) → False
  exact pattern_19 (g2626 E) (g2627 E) (g2628 E)
private theorem sat_2347 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 8, .pos 2630] := by
  change (g13 E = true) → (g9 E = true) → (¬ (g2631 E = true)) → False
  exact pattern_15 (g9 E) (g13 E)
private theorem sat_2348 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 11, .pos 2631] := by
  change (g13 E = true) → (g12 E = true) → (¬ (g2632 E = true)) → False
  exact pattern_15 (g12 E) (g13 E)
private theorem sat_2349 (E : Nat → Bool) : (valuation E).satisfies [.neg 2632, .neg 2631] := by
  change (g2633 E = true) → (g2632 E = true) → False
  exact pattern_18 (g2630 E) (g2631 E) (g2632 E)
private theorem sat_2350 (E : Nat → Bool) : (valuation E).satisfies [.neg 2632, .neg 2630] := by
  change (g2633 E = true) → (g2631 E = true) → False
  exact pattern_19 (g2630 E) (g2631 E) (g2632 E)
private theorem sat_2351 (E : Nat → Bool) : (valuation E).satisfies [.neg 21, .neg 14, .pos 2634] := by
  change (g22 E = true) → (g15 E = true) → (¬ (g2635 E = true)) → False
  exact pattern_15 (g15 E) (g22 E)
private theorem sat_2352 (E : Nat → Bool) : (valuation E).satisfies [.neg 21, .neg 20, .pos 2635] := by
  change (g22 E = true) → (g21 E = true) → (¬ (g2636 E = true)) → False
  exact pattern_15 (g21 E) (g22 E)
private theorem sat_2353 (E : Nat → Bool) : (valuation E).satisfies [.neg 2636, .neg 2635] := by
  change (g2637 E = true) → (g2636 E = true) → False
  exact pattern_18 (g2634 E) (g2635 E) (g2636 E)
private theorem sat_2354 (E : Nat → Bool) : (valuation E).satisfies [.neg 2636, .neg 2634] := by
  change (g2637 E = true) → (g2635 E = true) → False
  exact pattern_19 (g2634 E) (g2635 E) (g2636 E)
private theorem sat_2355 (E : Nat → Bool) : (valuation E).satisfies [.neg 2637, .neg 24] := by
  change (g2638 E = true) → (g25 E = true) → False
  exact pattern_18 (g16 E) (g24 E) (g25 E)
private theorem sat_2356 (E : Nat → Bool) : (valuation E).satisfies [.neg 2637, .neg 15] := by
  change (g2638 E = true) → (g16 E = true) → False
  exact pattern_20 (g16 E) (g24 E) (g25 E)
private theorem sat_2357 (E : Nat → Bool) : (valuation E).satisfies [.neg 2638, .neg 28] := by
  change (g2639 E = true) → (g29 E = true) → False
  exact pattern_18 (g19 E) (g28 E) (g29 E)
private theorem sat_2358 (E : Nat → Bool) : (valuation E).satisfies [.neg 2638, .neg 18] := by
  change (g2639 E = true) → (g19 E = true) → False
  exact pattern_20 (g19 E) (g28 E) (g29 E)
private theorem sat_2360 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 2, .pos 2640] := by
  change (g8 E = true) → (g3 E = true) → (¬ (g2641 E = true)) → False
  exact pattern_15 (g3 E) (g8 E)
private theorem sat_2361 (E : Nat → Bool) : (valuation E).satisfies [.neg 2642, .neg 2640] := by
  change (g2643 E = true) → (g2641 E = true) → False
  exact pattern_19 (g2640 E) (g2641 E) (g2642 E)
private theorem sat_2362 (E : Nat → Bool) : (valuation E).satisfies [.neg 11, .neg 8, .pos 2643] := by
  change (g12 E = true) → (g9 E = true) → (¬ (g2644 E = true)) → False
  exact pattern_15 (g9 E) (g12 E)
private theorem sat_2363 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 11, .pos 2645] := by
  change (g14 E = true) → (g12 E = true) → (¬ (g2646 E = true)) → False
  exact pattern_15 (g12 E) (g14 E)
private theorem sat_2364 (E : Nat → Bool) : (valuation E).satisfies [.neg 2646, .neg 2645] := by
  change (g2647 E = true) → (g2646 E = true) → False
  exact pattern_18 (g2644 E) (g2645 E) (g2646 E)
private theorem sat_2365 (E : Nat → Bool) : (valuation E).satisfies [.neg 2646, .neg 2643] := by
  change (g2647 E = true) → (g2644 E = true) → False
  exact pattern_20 (g2644 E) (g2645 E) (g2646 E)
private theorem sat_2366 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 14, .pos 2648] := by
  change (g23 E = true) → (g15 E = true) → (¬ (g2649 E = true)) → False
  exact pattern_15 (g15 E) (g23 E)
private theorem sat_2367 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 20, .pos 2649] := by
  change (g23 E = true) → (g21 E = true) → (¬ (g2650 E = true)) → False
  exact pattern_15 (g21 E) (g23 E)
private theorem sat_2368 (E : Nat → Bool) : (valuation E).satisfies [.neg 2650, .neg 2649] := by
  change (g2651 E = true) → (g2650 E = true) → False
  exact pattern_18 (g2648 E) (g2649 E) (g2650 E)
private theorem sat_2369 (E : Nat → Bool) : (valuation E).satisfies [.neg 2650, .neg 2648] := by
  change (g2651 E = true) → (g2649 E = true) → False
  exact pattern_19 (g2648 E) (g2649 E) (g2650 E)
private theorem sat_2370 (E : Nat → Bool) : (valuation E).satisfies [.neg 2651, .neg 25] := by
  change (g2652 E = true) → (g26 E = true) → False
  exact pattern_18 (g16 E) (g24 E) (g26 E)
private theorem sat_2371 (E : Nat → Bool) : (valuation E).satisfies [.neg 2651, .neg 15] := by
  change (g2652 E = true) → (g16 E = true) → False
  exact pattern_20 (g16 E) (g24 E) (g26 E)
private theorem sat_2372 (E : Nat → Bool) : (valuation E).satisfies [.neg 2652, .neg 28] := by
  change (g2653 E = true) → (g29 E = true) → False
  exact pattern_18 (g18 E) (g27 E) (g29 E)
private theorem sat_2373 (E : Nat → Bool) : (valuation E).satisfies [.neg 2652, .neg 26] := by
  change (g2653 E = true) → (g27 E = true) → False
  exact pattern_19 (g18 E) (g27 E) (g29 E)
private theorem sat_2375 (E : Nat → Bool) : (valuation E).satisfies [.neg 2653, .pos 2] := by
  change (g2654 E = true) → (¬ (g3 E = true)) → False
  exact pattern_1 (g3 E) (g7 E)
private theorem sat_2376 (E : Nat → Bool) : (valuation E).satisfies [.neg 2653, .pos 6] := by
  change (g2654 E = true) → (¬ (g7 E = true)) → False
  exact pattern_2 (g3 E) (g7 E)
private theorem sat_2377 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .neg 2, .pos 2653] := by
  change (g7 E = true) → (g3 E = true) → (¬ (g2654 E = true)) → False
  exact pattern_15 (g3 E) (g7 E)
private theorem sat_2378 (E : Nat → Bool) : (valuation E).satisfies [.neg 2654, .pos 2] := by
  change (g2655 E = true) → (¬ (g3 E = true)) → False
  exact pattern_1 (g3 E) (g8 E)
private theorem sat_2379 (E : Nat → Bool) : (valuation E).satisfies [.neg 2654, .pos 7] := by
  change (g2655 E = true) → (¬ (g8 E = true)) → False
  exact pattern_2 (g3 E) (g8 E)
private theorem sat_2380 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 2, .pos 2654] := by
  change (g8 E = true) → (g3 E = true) → (¬ (g2655 E = true)) → False
  exact pattern_15 (g3 E) (g8 E)
private theorem sat_2381 (E : Nat → Bool) : (valuation E).satisfies [.neg 2655, .pos 6] := by
  change (g2656 E = true) → (¬ (g7 E = true)) → False
  exact pattern_1 (g7 E) (g8 E)
private theorem sat_2382 (E : Nat → Bool) : (valuation E).satisfies [.neg 2655, .pos 7] := by
  change (g2656 E = true) → (¬ (g8 E = true)) → False
  exact pattern_2 (g7 E) (g8 E)
private theorem sat_2383 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 6, .pos 2655] := by
  change (g8 E = true) → (g7 E = true) → (¬ (g2656 E = true)) → False
  exact pattern_15 (g7 E) (g8 E)
private theorem sat_2384 (E : Nat → Bool) : (valuation E).satisfies [.neg 2656, .neg 2655] := by
  change (g2657 E = true) → (g2656 E = true) → False
  exact pattern_18 (g2654 E) (g2655 E) (g2656 E)
private theorem sat_2385 (E : Nat → Bool) : (valuation E).satisfies [.neg 2656, .neg 2654] := by
  change (g2657 E = true) → (g2655 E = true) → False
  exact pattern_19 (g2654 E) (g2655 E) (g2656 E)
private theorem sat_2386 (E : Nat → Bool) : (valuation E).satisfies [.neg 2656, .neg 2653] := by
  change (g2657 E = true) → (g2654 E = true) → False
  exact pattern_20 (g2654 E) (g2655 E) (g2656 E)
private theorem sat_2387 (E : Nat → Bool) : (valuation E).satisfies [.pos 2653, .pos 2654, .pos 2655, .pos 2656] := by
  change (¬ (g2654 E = true)) → (¬ (g2655 E = true)) → (¬ (g2656 E = true)) → (¬ (g2657 E = true)) → False
  exact pattern_21 (g2654 E) (g2655 E) (g2656 E)
private theorem sat_2388 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 8, .pos 2657] := by
  change (g13 E = true) → (g9 E = true) → (¬ (g2658 E = true)) → False
  exact pattern_15 (g9 E) (g13 E)
private theorem sat_2389 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 8, .pos 2658] := by
  change (g14 E = true) → (g9 E = true) → (¬ (g2659 E = true)) → False
  exact pattern_15 (g9 E) (g14 E)
private theorem sat_2390 (E : Nat → Bool) : (valuation E).satisfies [.neg 2659, .pos 13] := by
  change (g2660 E = true) → (¬ (g14 E = true)) → False
  exact pattern_2 (g13 E) (g14 E)
private theorem sat_2391 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 12, .pos 2659] := by
  change (g14 E = true) → (g13 E = true) → (¬ (g2660 E = true)) → False
  exact pattern_15 (g13 E) (g14 E)
private theorem sat_2392 (E : Nat → Bool) : (valuation E).satisfies [.neg 2660, .neg 2659] := by
  change (g2661 E = true) → (g2660 E = true) → False
  exact pattern_18 (g2658 E) (g2659 E) (g2660 E)
private theorem sat_2393 (E : Nat → Bool) : (valuation E).satisfies [.neg 2660, .neg 2658] := by
  change (g2661 E = true) → (g2659 E = true) → False
  exact pattern_19 (g2658 E) (g2659 E) (g2660 E)
private theorem sat_2394 (E : Nat → Bool) : (valuation E).satisfies [.neg 2660, .neg 2657] := by
  change (g2661 E = true) → (g2658 E = true) → False
  exact pattern_20 (g2658 E) (g2659 E) (g2660 E)
private theorem sat_2395 (E : Nat → Bool) : (valuation E).satisfies [.neg 2661, .pos 21] := by
  change (g2662 E = true) → (¬ (g22 E = true)) → False
  exact pattern_2 (g15 E) (g22 E)
private theorem sat_2396 (E : Nat → Bool) : (valuation E).satisfies [.neg 21, .neg 14, .pos 2661] := by
  change (g22 E = true) → (g15 E = true) → (¬ (g2662 E = true)) → False
  exact pattern_15 (g15 E) (g22 E)
private theorem sat_2397 (E : Nat → Bool) : (valuation E).satisfies [.neg 2662, .pos 22] := by
  change (g2663 E = true) → (¬ (g23 E = true)) → False
  exact pattern_2 (g15 E) (g23 E)
private theorem sat_2398 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 14, .pos 2662] := by
  change (g23 E = true) → (g15 E = true) → (¬ (g2663 E = true)) → False
  exact pattern_15 (g15 E) (g23 E)
private theorem sat_2399 (E : Nat → Bool) : (valuation E).satisfies [.neg 2663, .pos 21] := by
  change (g2664 E = true) → (¬ (g22 E = true)) → False
  exact pattern_1 (g22 E) (g23 E)
private theorem sat_2400 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 21, .pos 2663] := by
  change (g23 E = true) → (g22 E = true) → (¬ (g2664 E = true)) → False
  exact pattern_15 (g22 E) (g23 E)
private theorem sat_2401 (E : Nat → Bool) : (valuation E).satisfies [.neg 2664, .neg 2663] := by
  change (g2665 E = true) → (g2664 E = true) → False
  exact pattern_18 (g2662 E) (g2663 E) (g2664 E)
private theorem sat_2402 (E : Nat → Bool) : (valuation E).satisfies [.neg 2664, .neg 2662] := by
  change (g2665 E = true) → (g2663 E = true) → False
  exact pattern_19 (g2662 E) (g2663 E) (g2664 E)
private theorem sat_2403 (E : Nat → Bool) : (valuation E).satisfies [.neg 2664, .neg 2661] := by
  change (g2665 E = true) → (g2662 E = true) → False
  exact pattern_20 (g2662 E) (g2663 E) (g2664 E)
private theorem sat_2404 (E : Nat → Bool) : (valuation E).satisfies [.pos 2661, .pos 2662, .pos 2663, .pos 2664] := by
  change (¬ (g2662 E = true)) → (¬ (g2663 E = true)) → (¬ (g2664 E = true)) → (¬ (g2665 E = true)) → False
  exact pattern_21 (g2662 E) (g2663 E) (g2664 E)
private theorem sat_2405 (E : Nat → Bool) : (valuation E).satisfies [.neg 2665, .neg 25] := by
  change (g2666 E = true) → (g26 E = true) → False
  exact pattern_18 (g16 E) (g25 E) (g26 E)
private theorem sat_2406 (E : Nat → Bool) : (valuation E).satisfies [.neg 2665, .neg 24] := by
  change (g2666 E = true) → (g25 E = true) → False
  exact pattern_19 (g16 E) (g25 E) (g26 E)
private theorem sat_2407 (E : Nat → Bool) : (valuation E).satisfies [.neg 2665, .neg 15] := by
  change (g2666 E = true) → (g16 E = true) → False
  exact pattern_20 (g16 E) (g25 E) (g26 E)
private theorem sat_2408 (E : Nat → Bool) : (valuation E).satisfies [.neg 2666, .neg 27] := by
  change (g2667 E = true) → (g28 E = true) → False
  exact pattern_18 (g17 E) (g27 E) (g28 E)
private theorem sat_2409 (E : Nat → Bool) : (valuation E).satisfies [.neg 2666, .neg 26] := by
  change (g2667 E = true) → (g27 E = true) → False
  exact pattern_19 (g17 E) (g27 E) (g28 E)
private theorem sat_2410 (E : Nat → Bool) : (valuation E).satisfies [.neg 2666, .neg 16] := by
  change (g2667 E = true) → (g17 E = true) → False
  exact pattern_20 (g17 E) (g27 E) (g28 E)
private theorem sat_2412 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 3, .pos 2696] := by
  change (g8 E = true) → (g4 E = true) → (¬ (g2697 E = true)) → False
  exact pattern_15 (g4 E) (g8 E)
private theorem sat_2413 (E : Nat → Bool) : (valuation E).satisfies [.neg 2698, .neg 2696] := by
  change (g2699 E = true) → (g2697 E = true) → False
  exact pattern_19 (g2696 E) (g2697 E) (g2698 E)
private theorem sat_2414 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 10, .pos 2701] := by
  change (g14 E = true) → (g11 E = true) → (¬ (g2702 E = true)) → False
  exact pattern_15 (g11 E) (g14 E)
private theorem sat_2415 (E : Nat → Bool) : (valuation E).satisfies [.neg 2702, .neg 2701] := by
  change (g2703 E = true) → (g2702 E = true) → False
  exact pattern_18 (g2700 E) (g2701 E) (g2702 E)
private theorem sat_2416 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 15, .pos 2705] := by
  change (g19 E = true) → (g16 E = true) → (¬ (g2706 E = true)) → False
  exact pattern_15 (g16 E) (g19 E)
private theorem sat_2417 (E : Nat → Bool) : (valuation E).satisfies [.neg 2706, .neg 2705] := by
  change (g2707 E = true) → (g2706 E = true) → False
  exact pattern_18 (g2704 E) (g2705 E) (g2706 E)
private theorem sat_2418 (E : Nat → Bool) : (valuation E).satisfies [.neg 2707, .neg 20] := by
  change (g2708 E = true) → (g21 E = true) → False
  exact pattern_20 (g21 E) (g24 E) (g28 E)
private theorem sat_2419 (E : Nat → Bool) : (valuation E).satisfies [.neg 2708, .neg 21] := by
  change (g2709 E = true) → (g22 E = true) → False
  exact pattern_20 (g22 E) (g25 E) (g29 E)
private theorem sat_2421 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .neg 5, .pos 2711] := by
  change (g7 E = true) → (g6 E = true) → (¬ (g2712 E = true)) → False
  exact pattern_15 (g6 E) (g7 E)
private theorem sat_2422 (E : Nat → Bool) : (valuation E).satisfies [.neg 2712, .neg 2711] := by
  change (g2713 E = true) → (g2712 E = true) → False
  exact pattern_18 (g2710 E) (g2711 E) (g2712 E)
private theorem sat_2423 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 9, .pos 2714] := by
  change (g13 E = true) → (g10 E = true) → (¬ (g2715 E = true)) → False
  exact pattern_15 (g10 E) (g13 E)
private theorem sat_2424 (E : Nat → Bool) : (valuation E).satisfies [.neg 2716, .neg 2714] := by
  change (g2717 E = true) → (g2715 E = true) → False
  exact pattern_19 (g2714 E) (g2715 E) (g2716 E)
private theorem sat_2425 (E : Nat → Bool) : (valuation E).satisfies [.neg 17, .neg 16, .pos 2719] := by
  change (g18 E = true) → (g17 E = true) → (¬ (g2720 E = true)) → False
  exact pattern_15 (g17 E) (g18 E)
private theorem sat_2426 (E : Nat → Bool) : (valuation E).satisfies [.neg 2720, .neg 2719] := by
  change (g2721 E = true) → (g2720 E = true) → False
  exact pattern_18 (g2718 E) (g2719 E) (g2720 E)
private theorem sat_2427 (E : Nat → Bool) : (valuation E).satisfies [.neg 2721, .neg 19] := by
  change (g2722 E = true) → (g20 E = true) → False
  exact pattern_20 (g20 E) (g24 E) (g25 E)
private theorem sat_2428 (E : Nat → Bool) : (valuation E).satisfies [.neg 2722, .neg 22] := by
  change (g2723 E = true) → (g23 E = true) → False
  exact pattern_20 (g23 E) (g28 E) (g29 E)
private theorem sat_2430 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 3, .pos 2724] := by
  change (g8 E = true) → (g4 E = true) → (¬ (g2725 E = true)) → False
  exact pattern_15 (g4 E) (g8 E)
private theorem sat_2431 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 5, .pos 2725] := by
  change (g8 E = true) → (g6 E = true) → (¬ (g2726 E = true)) → False
  exact pattern_15 (g6 E) (g8 E)
private theorem sat_2432 (E : Nat → Bool) : (valuation E).satisfies [.neg 2726, .neg 2725] := by
  change (g2727 E = true) → (g2726 E = true) → False
  exact pattern_18 (g2724 E) (g2725 E) (g2726 E)
private theorem sat_2433 (E : Nat → Bool) : (valuation E).satisfies [.neg 2726, .neg 2724] := by
  change (g2727 E = true) → (g2725 E = true) → False
  exact pattern_19 (g2724 E) (g2725 E) (g2726 E)
private theorem sat_2434 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 9, .pos 2728] := by
  change (g14 E = true) → (g10 E = true) → (¬ (g2729 E = true)) → False
  exact pattern_15 (g10 E) (g14 E)
private theorem sat_2435 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 11, .pos 2729] := by
  change (g14 E = true) → (g12 E = true) → (¬ (g2730 E = true)) → False
  exact pattern_15 (g12 E) (g14 E)
private theorem sat_2436 (E : Nat → Bool) : (valuation E).satisfies [.neg 2730, .neg 2729] := by
  change (g2731 E = true) → (g2730 E = true) → False
  exact pattern_18 (g2728 E) (g2729 E) (g2730 E)
private theorem sat_2437 (E : Nat → Bool) : (valuation E).satisfies [.neg 2730, .neg 2728] := by
  change (g2731 E = true) → (g2729 E = true) → False
  exact pattern_19 (g2728 E) (g2729 E) (g2730 E)
private theorem sat_2438 (E : Nat → Bool) : (valuation E).satisfies [.neg 16, .neg 14, .pos 2731] := by
  change (g17 E = true) → (g15 E = true) → (¬ (g2732 E = true)) → False
  exact pattern_15 (g15 E) (g17 E)
private theorem sat_2439 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 14, .pos 2732] := by
  change (g19 E = true) → (g15 E = true) → (¬ (g2733 E = true)) → False
  exact pattern_15 (g15 E) (g19 E)
private theorem sat_2440 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 16, .pos 2733] := by
  change (g19 E = true) → (g17 E = true) → (¬ (g2734 E = true)) → False
  exact pattern_15 (g17 E) (g19 E)
private theorem sat_2441 (E : Nat → Bool) : (valuation E).satisfies [.neg 2734, .neg 2733] := by
  change (g2735 E = true) → (g2734 E = true) → False
  exact pattern_18 (g2732 E) (g2733 E) (g2734 E)
private theorem sat_2442 (E : Nat → Bool) : (valuation E).satisfies [.neg 2734, .neg 2732] := by
  change (g2735 E = true) → (g2733 E = true) → False
  exact pattern_19 (g2732 E) (g2733 E) (g2734 E)
private theorem sat_2443 (E : Nat → Bool) : (valuation E).satisfies [.neg 2734, .neg 2731] := by
  change (g2735 E = true) → (g2732 E = true) → False
  exact pattern_20 (g2732 E) (g2733 E) (g2734 E)
private theorem sat_2444 (E : Nat → Bool) : (valuation E).satisfies [.neg 2735, .neg 19] := by
  change (g2736 E = true) → (g20 E = true) → False
  exact pattern_20 (g20 E) (g24 E) (g26 E)
private theorem sat_2445 (E : Nat → Bool) : (valuation E).satisfies [.neg 2736, .neg 28] := by
  change (g2737 E = true) → (g29 E = true) → False
  exact pattern_18 (g22 E) (g27 E) (g29 E)
private theorem sat_2446 (E : Nat → Bool) : (valuation E).satisfies [.neg 2736, .neg 26] := by
  change (g2737 E = true) → (g27 E = true) → False
  exact pattern_19 (g22 E) (g27 E) (g29 E)
private theorem sat_2447 (E : Nat → Bool) : (valuation E).satisfies [.neg 2736, .neg 21] := by
  change (g2737 E = true) → (g22 E = true) → False
  exact pattern_20 (g22 E) (g27 E) (g29 E)
private theorem sat_2449 (E : Nat → Bool) : (valuation E).satisfies [.neg 2737, .pos 3] := by
  change (g2738 E = true) → (¬ (g4 E = true)) → False
  exact pattern_1 (g4 E) (g7 E)
private theorem sat_2450 (E : Nat → Bool) : (valuation E).satisfies [.neg 2737, .pos 6] := by
  change (g2738 E = true) → (¬ (g7 E = true)) → False
  exact pattern_2 (g4 E) (g7 E)
private theorem sat_2451 (E : Nat → Bool) : (valuation E).satisfies [.neg 2738, .pos 3] := by
  change (g2739 E = true) → (¬ (g4 E = true)) → False
  exact pattern_1 (g4 E) (g8 E)
private theorem sat_2452 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 3, .pos 2738] := by
  change (g8 E = true) → (g4 E = true) → (¬ (g2739 E = true)) → False
  exact pattern_15 (g4 E) (g8 E)
private theorem sat_2453 (E : Nat → Bool) : (valuation E).satisfies [.neg 2739, .pos 6] := by
  change (g2740 E = true) → (¬ (g7 E = true)) → False
  exact pattern_1 (g7 E) (g8 E)
private theorem sat_2454 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 6, .pos 2739] := by
  change (g8 E = true) → (g7 E = true) → (¬ (g2740 E = true)) → False
  exact pattern_15 (g7 E) (g8 E)
private theorem sat_2455 (E : Nat → Bool) : (valuation E).satisfies [.neg 2740, .neg 2739] := by
  change (g2741 E = true) → (g2740 E = true) → False
  exact pattern_18 (g2738 E) (g2739 E) (g2740 E)
private theorem sat_2456 (E : Nat → Bool) : (valuation E).satisfies [.neg 2740, .neg 2738] := by
  change (g2741 E = true) → (g2739 E = true) → False
  exact pattern_19 (g2738 E) (g2739 E) (g2740 E)
private theorem sat_2457 (E : Nat → Bool) : (valuation E).satisfies [.pos 2737, .pos 2738, .pos 2739, .pos 2740] := by
  change (¬ (g2738 E = true)) → (¬ (g2739 E = true)) → (¬ (g2740 E = true)) → (¬ (g2741 E = true)) → False
  exact pattern_21 (g2738 E) (g2739 E) (g2740 E)
private theorem sat_2458 (E : Nat → Bool) : (valuation E).satisfies [.neg 2741, .pos 9] := by
  change (g2742 E = true) → (¬ (g10 E = true)) → False
  exact pattern_1 (g10 E) (g13 E)
private theorem sat_2459 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 9, .pos 2741] := by
  change (g13 E = true) → (g10 E = true) → (¬ (g2742 E = true)) → False
  exact pattern_15 (g10 E) (g13 E)
private theorem sat_2460 (E : Nat → Bool) : (valuation E).satisfies [.neg 2742, .pos 9] := by
  change (g2743 E = true) → (¬ (g10 E = true)) → False
  exact pattern_1 (g10 E) (g14 E)
private theorem sat_2461 (E : Nat → Bool) : (valuation E).satisfies [.neg 2742, .pos 13] := by
  change (g2743 E = true) → (¬ (g14 E = true)) → False
  exact pattern_2 (g10 E) (g14 E)
private theorem sat_2462 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 9, .pos 2742] := by
  change (g14 E = true) → (g10 E = true) → (¬ (g2743 E = true)) → False
  exact pattern_15 (g10 E) (g14 E)
private theorem sat_2463 (E : Nat → Bool) : (valuation E).satisfies [.neg 2743, .pos 13] := by
  change (g2744 E = true) → (¬ (g14 E = true)) → False
  exact pattern_2 (g13 E) (g14 E)
private theorem sat_2464 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 12, .pos 2743] := by
  change (g14 E = true) → (g13 E = true) → (¬ (g2744 E = true)) → False
  exact pattern_15 (g13 E) (g14 E)
private theorem sat_2465 (E : Nat → Bool) : (valuation E).satisfies [.neg 2744, .neg 2743] := by
  change (g2745 E = true) → (g2744 E = true) → False
  exact pattern_18 (g2742 E) (g2743 E) (g2744 E)
private theorem sat_2466 (E : Nat → Bool) : (valuation E).satisfies [.neg 2744, .neg 2742] := by
  change (g2745 E = true) → (g2743 E = true) → False
  exact pattern_19 (g2742 E) (g2743 E) (g2744 E)
private theorem sat_2467 (E : Nat → Bool) : (valuation E).satisfies [.neg 2744, .neg 2741] := by
  change (g2745 E = true) → (g2742 E = true) → False
  exact pattern_20 (g2742 E) (g2743 E) (g2744 E)
private theorem sat_2468 (E : Nat → Bool) : (valuation E).satisfies [.pos 2741, .pos 2742, .pos 2743, .pos 2744] := by
  change (¬ (g2742 E = true)) → (¬ (g2743 E = true)) → (¬ (g2744 E = true)) → (¬ (g2745 E = true)) → False
  exact pattern_21 (g2742 E) (g2743 E) (g2744 E)
private theorem sat_2469 (E : Nat → Bool) : (valuation E).satisfies [.neg 17, .neg 14, .pos 2745] := by
  change (g18 E = true) → (g15 E = true) → (¬ (g2746 E = true)) → False
  exact pattern_15 (g15 E) (g18 E)
private theorem sat_2470 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 14, .pos 2746] := by
  change (g19 E = true) → (g15 E = true) → (¬ (g2747 E = true)) → False
  exact pattern_15 (g15 E) (g19 E)
private theorem sat_2471 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 17, .pos 2747] := by
  change (g19 E = true) → (g18 E = true) → (¬ (g2748 E = true)) → False
  exact pattern_15 (g18 E) (g19 E)
private theorem sat_2472 (E : Nat → Bool) : (valuation E).satisfies [.neg 2748, .neg 2747] := by
  change (g2749 E = true) → (g2748 E = true) → False
  exact pattern_18 (g2746 E) (g2747 E) (g2748 E)
private theorem sat_2473 (E : Nat → Bool) : (valuation E).satisfies [.neg 2748, .neg 2746] := by
  change (g2749 E = true) → (g2747 E = true) → False
  exact pattern_19 (g2746 E) (g2747 E) (g2748 E)
private theorem sat_2474 (E : Nat → Bool) : (valuation E).satisfies [.neg 2748, .neg 2745] := by
  change (g2749 E = true) → (g2746 E = true) → False
  exact pattern_20 (g2746 E) (g2747 E) (g2748 E)
private theorem sat_2475 (E : Nat → Bool) : (valuation E).satisfies [.neg 2749, .neg 25] := by
  change (g2750 E = true) → (g26 E = true) → False
  exact pattern_18 (g20 E) (g25 E) (g26 E)
private theorem sat_2476 (E : Nat → Bool) : (valuation E).satisfies [.neg 2749, .neg 24] := by
  change (g2750 E = true) → (g25 E = true) → False
  exact pattern_19 (g20 E) (g25 E) (g26 E)
private theorem sat_2477 (E : Nat → Bool) : (valuation E).satisfies [.neg 2749, .neg 19] := by
  change (g2750 E = true) → (g20 E = true) → False
  exact pattern_20 (g20 E) (g25 E) (g26 E)
private theorem sat_2478 (E : Nat → Bool) : (valuation E).satisfies [.neg 2750, .neg 27] := by
  change (g2751 E = true) → (g28 E = true) → False
  exact pattern_18 (g21 E) (g27 E) (g28 E)
private theorem sat_2479 (E : Nat → Bool) : (valuation E).satisfies [.neg 2750, .neg 26] := by
  change (g2751 E = true) → (g27 E = true) → False
  exact pattern_19 (g21 E) (g27 E) (g28 E)
private theorem sat_2480 (E : Nat → Bool) : (valuation E).satisfies [.neg 2750, .neg 20] := by
  change (g2751 E = true) → (g21 E = true) → False
  exact pattern_20 (g21 E) (g27 E) (g28 E)
private theorem sat_2482 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 5, .pos 2770] := by
  change (g8 E = true) → (g6 E = true) → (¬ (g2771 E = true)) → False
  exact pattern_15 (g6 E) (g8 E)
private theorem sat_2483 (E : Nat → Bool) : (valuation E).satisfies [.neg 2771, .neg 2770] := by
  change (g2772 E = true) → (g2771 E = true) → False
  exact pattern_18 (g2769 E) (g2770 E) (g2771 E)
private theorem sat_2484 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 10, .pos 2773] := by
  change (g14 E = true) → (g11 E = true) → (¬ (g2774 E = true)) → False
  exact pattern_15 (g11 E) (g14 E)
private theorem sat_2485 (E : Nat → Bool) : (valuation E).satisfies [.neg 2775, .neg 2773] := by
  change (g2776 E = true) → (g2774 E = true) → False
  exact pattern_19 (g2773 E) (g2774 E) (g2775 E)
private theorem sat_2486 (E : Nat → Bool) : (valuation E).satisfies [.neg 16, .neg 15, .pos 2776] := by
  change (g17 E = true) → (g16 E = true) → (¬ (g2777 E = true)) → False
  exact pattern_15 (g16 E) (g17 E)
private theorem sat_2487 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 16, .pos 2778] := by
  change (g19 E = true) → (g17 E = true) → (¬ (g2779 E = true)) → False
  exact pattern_15 (g17 E) (g19 E)
private theorem sat_2488 (E : Nat → Bool) : (valuation E).satisfies [.neg 2779, .neg 2778] := by
  change (g2780 E = true) → (g2779 E = true) → False
  exact pattern_18 (g2777 E) (g2778 E) (g2779 E)
private theorem sat_2489 (E : Nat → Bool) : (valuation E).satisfies [.neg 2779, .neg 2776] := by
  change (g2780 E = true) → (g2777 E = true) → False
  exact pattern_20 (g2777 E) (g2778 E) (g2779 E)
private theorem sat_2490 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 19, .pos 2781] := by
  change (g23 E = true) → (g20 E = true) → (¬ (g2782 E = true)) → False
  exact pattern_15 (g20 E) (g23 E)
private theorem sat_2491 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 20, .pos 2782] := by
  change (g23 E = true) → (g21 E = true) → (¬ (g2783 E = true)) → False
  exact pattern_15 (g21 E) (g23 E)
private theorem sat_2492 (E : Nat → Bool) : (valuation E).satisfies [.neg 2783, .neg 2782] := by
  change (g2784 E = true) → (g2783 E = true) → False
  exact pattern_18 (g2781 E) (g2782 E) (g2783 E)
private theorem sat_2493 (E : Nat → Bool) : (valuation E).satisfies [.neg 2783, .neg 2781] := by
  change (g2784 E = true) → (g2782 E = true) → False
  exact pattern_19 (g2781 E) (g2782 E) (g2783 E)
private theorem sat_2494 (E : Nat → Bool) : (valuation E).satisfies [.neg 2784, .neg 28] := by
  change (g2785 E = true) → (g29 E = true) → False
  exact pattern_18 (g25 E) (g27 E) (g29 E)
private theorem sat_2495 (E : Nat → Bool) : (valuation E).satisfies [.neg 2784, .neg 26] := by
  change (g2785 E = true) → (g27 E = true) → False
  exact pattern_19 (g25 E) (g27 E) (g29 E)
private theorem sat_2496 (E : Nat → Bool) : (valuation E).satisfies [.neg 2784, .neg 24] := by
  change (g2785 E = true) → (g25 E = true) → False
  exact pattern_20 (g25 E) (g27 E) (g29 E)
private theorem sat_2498 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 6, .pos 2787] := by
  change (g8 E = true) → (g7 E = true) → (¬ (g2788 E = true)) → False
  exact pattern_15 (g7 E) (g8 E)
private theorem sat_2499 (E : Nat → Bool) : (valuation E).satisfies [.neg 2788, .neg 2787] := by
  change (g2789 E = true) → (g2788 E = true) → False
  exact pattern_18 (g2786 E) (g2787 E) (g2788 E)
private theorem sat_2500 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 10, .pos 2790] := by
  change (g14 E = true) → (g11 E = true) → (¬ (g2791 E = true)) → False
  exact pattern_15 (g11 E) (g14 E)
private theorem sat_2501 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 12, .pos 2791] := by
  change (g14 E = true) → (g13 E = true) → (¬ (g2792 E = true)) → False
  exact pattern_15 (g13 E) (g14 E)
private theorem sat_2502 (E : Nat → Bool) : (valuation E).satisfies [.neg 2792, .neg 2791] := by
  change (g2793 E = true) → (g2792 E = true) → False
  exact pattern_18 (g2790 E) (g2791 E) (g2792 E)
private theorem sat_2503 (E : Nat → Bool) : (valuation E).satisfies [.neg 2792, .neg 2790] := by
  change (g2793 E = true) → (g2791 E = true) → False
  exact pattern_19 (g2790 E) (g2791 E) (g2792 E)
private theorem sat_2504 (E : Nat → Bool) : (valuation E).satisfies [.neg 17, .neg 15, .pos 2793] := by
  change (g18 E = true) → (g16 E = true) → (¬ (g2794 E = true)) → False
  exact pattern_15 (g16 E) (g18 E)
private theorem sat_2505 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 15, .pos 2794] := by
  change (g19 E = true) → (g16 E = true) → (¬ (g2795 E = true)) → False
  exact pattern_15 (g16 E) (g19 E)
private theorem sat_2506 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 17, .pos 2795] := by
  change (g19 E = true) → (g18 E = true) → (¬ (g2796 E = true)) → False
  exact pattern_15 (g18 E) (g19 E)
private theorem sat_2507 (E : Nat → Bool) : (valuation E).satisfies [.neg 2796, .neg 2795] := by
  change (g2797 E = true) → (g2796 E = true) → False
  exact pattern_18 (g2794 E) (g2795 E) (g2796 E)
private theorem sat_2508 (E : Nat → Bool) : (valuation E).satisfies [.neg 2796, .neg 2794] := by
  change (g2797 E = true) → (g2795 E = true) → False
  exact pattern_19 (g2794 E) (g2795 E) (g2796 E)
private theorem sat_2509 (E : Nat → Bool) : (valuation E).satisfies [.neg 2796, .neg 2793] := by
  change (g2797 E = true) → (g2794 E = true) → False
  exact pattern_20 (g2794 E) (g2795 E) (g2796 E)
private theorem sat_2510 (E : Nat → Bool) : (valuation E).satisfies [.neg 21, .neg 19, .pos 2797] := by
  change (g22 E = true) → (g20 E = true) → (¬ (g2798 E = true)) → False
  exact pattern_15 (g20 E) (g22 E)
private theorem sat_2511 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 19, .pos 2798] := by
  change (g23 E = true) → (g20 E = true) → (¬ (g2799 E = true)) → False
  exact pattern_15 (g20 E) (g23 E)
private theorem sat_2512 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 21, .pos 2799] := by
  change (g23 E = true) → (g22 E = true) → (¬ (g2800 E = true)) → False
  exact pattern_15 (g22 E) (g23 E)
private theorem sat_2513 (E : Nat → Bool) : (valuation E).satisfies [.neg 2800, .neg 2799] := by
  change (g2801 E = true) → (g2800 E = true) → False
  exact pattern_18 (g2798 E) (g2799 E) (g2800 E)
private theorem sat_2514 (E : Nat → Bool) : (valuation E).satisfies [.neg 2800, .neg 2798] := by
  change (g2801 E = true) → (g2799 E = true) → False
  exact pattern_19 (g2798 E) (g2799 E) (g2800 E)
private theorem sat_2515 (E : Nat → Bool) : (valuation E).satisfies [.neg 2800, .neg 2797] := by
  change (g2801 E = true) → (g2798 E = true) → False
  exact pattern_20 (g2798 E) (g2799 E) (g2800 E)
private theorem sat_2516 (E : Nat → Bool) : (valuation E).satisfies [.neg 2801, .neg 27] := by
  change (g2802 E = true) → (g28 E = true) → False
  exact pattern_18 (g24 E) (g27 E) (g28 E)
private theorem sat_2517 (E : Nat → Bool) : (valuation E).satisfies [.neg 2801, .neg 26] := by
  change (g2802 E = true) → (g27 E = true) → False
  exact pattern_19 (g24 E) (g27 E) (g28 E)
private theorem sat_2518 (E : Nat → Bool) : (valuation E).satisfies [.neg 2801, .neg 23] := by
  change (g2802 E = true) → (g24 E = true) → False
  exact pattern_20 (g24 E) (g27 E) (g28 E)
private theorem sat_2520 (E : Nat → Bool) : (valuation E).satisfies [.neg 2802, .pos 6] := by
  change (g2803 E = true) → (¬ (g7 E = true)) → False
  exact pattern_2 (g6 E) (g7 E)
private theorem sat_2521 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .neg 5, .pos 2802] := by
  change (g7 E = true) → (g6 E = true) → (¬ (g2803 E = true)) → False
  exact pattern_15 (g6 E) (g7 E)
private theorem sat_2522 (E : Nat → Bool) : (valuation E).satisfies [.neg 2803, .pos 5] := by
  change (g2804 E = true) → (¬ (g6 E = true)) → False
  exact pattern_1 (g6 E) (g8 E)
private theorem sat_2523 (E : Nat → Bool) : (valuation E).satisfies [.neg 2804, .pos 6] := by
  change (g2805 E = true) → (¬ (g7 E = true)) → False
  exact pattern_1 (g7 E) (g8 E)
private theorem sat_2524 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 6, .pos 2804] := by
  change (g8 E = true) → (g7 E = true) → (¬ (g2805 E = true)) → False
  exact pattern_15 (g7 E) (g8 E)
private theorem sat_2525 (E : Nat → Bool) : (valuation E).satisfies [.neg 2805, .neg 2804] := by
  change (g2806 E = true) → (g2805 E = true) → False
  exact pattern_18 (g2803 E) (g2804 E) (g2805 E)
private theorem sat_2526 (E : Nat → Bool) : (valuation E).satisfies [.neg 2805, .neg 2802] := by
  change (g2806 E = true) → (g2803 E = true) → False
  exact pattern_20 (g2803 E) (g2804 E) (g2805 E)
private theorem sat_2527 (E : Nat → Bool) : (valuation E).satisfies [.pos 2802, .pos 2803, .pos 2804, .pos 2805] := by
  change (¬ (g2803 E = true)) → (¬ (g2804 E = true)) → (¬ (g2805 E = true)) → (¬ (g2806 E = true)) → False
  exact pattern_21 (g2803 E) (g2804 E) (g2805 E)
private theorem sat_2528 (E : Nat → Bool) : (valuation E).satisfies [.neg 2806, .pos 11] := by
  change (g2807 E = true) → (¬ (g12 E = true)) → False
  exact pattern_1 (g12 E) (g13 E)
private theorem sat_2529 (E : Nat → Bool) : (valuation E).satisfies [.neg 2806, .pos 12] := by
  change (g2807 E = true) → (¬ (g13 E = true)) → False
  exact pattern_2 (g12 E) (g13 E)
private theorem sat_2530 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 11, .pos 2806] := by
  change (g13 E = true) → (g12 E = true) → (¬ (g2807 E = true)) → False
  exact pattern_15 (g12 E) (g13 E)
private theorem sat_2531 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 11, .pos 2807] := by
  change (g14 E = true) → (g12 E = true) → (¬ (g2808 E = true)) → False
  exact pattern_15 (g12 E) (g14 E)
private theorem sat_2532 (E : Nat → Bool) : (valuation E).satisfies [.neg 2808, .pos 12] := by
  change (g2809 E = true) → (¬ (g13 E = true)) → False
  exact pattern_1 (g13 E) (g14 E)
private theorem sat_2533 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 12, .pos 2808] := by
  change (g14 E = true) → (g13 E = true) → (¬ (g2809 E = true)) → False
  exact pattern_15 (g13 E) (g14 E)
private theorem sat_2534 (E : Nat → Bool) : (valuation E).satisfies [.neg 2809, .neg 2808] := by
  change (g2810 E = true) → (g2809 E = true) → False
  exact pattern_18 (g2807 E) (g2808 E) (g2809 E)
private theorem sat_2535 (E : Nat → Bool) : (valuation E).satisfies [.neg 2809, .neg 2807] := by
  change (g2810 E = true) → (g2808 E = true) → False
  exact pattern_19 (g2807 E) (g2808 E) (g2809 E)
private theorem sat_2536 (E : Nat → Bool) : (valuation E).satisfies [.neg 2809, .neg 2806] := by
  change (g2810 E = true) → (g2807 E = true) → False
  exact pattern_20 (g2807 E) (g2808 E) (g2809 E)
private theorem sat_2537 (E : Nat → Bool) : (valuation E).satisfies [.neg 2810, .pos 16] := by
  change (g2811 E = true) → (¬ (g17 E = true)) → False
  exact pattern_1 (g17 E) (g18 E)
private theorem sat_2538 (E : Nat → Bool) : (valuation E).satisfies [.neg 17, .neg 16, .pos 2810] := by
  change (g18 E = true) → (g17 E = true) → (¬ (g2811 E = true)) → False
  exact pattern_15 (g17 E) (g18 E)
private theorem sat_2539 (E : Nat → Bool) : (valuation E).satisfies [.neg 2811, .pos 16] := by
  change (g2812 E = true) → (¬ (g17 E = true)) → False
  exact pattern_1 (g17 E) (g19 E)
private theorem sat_2540 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 16, .pos 2811] := by
  change (g19 E = true) → (g17 E = true) → (¬ (g2812 E = true)) → False
  exact pattern_15 (g17 E) (g19 E)
private theorem sat_2541 (E : Nat → Bool) : (valuation E).satisfies [.neg 2812, .pos 17] := by
  change (g2813 E = true) → (¬ (g18 E = true)) → False
  exact pattern_1 (g18 E) (g19 E)
private theorem sat_2542 (E : Nat → Bool) : (valuation E).satisfies [.neg 2812, .pos 18] := by
  change (g2813 E = true) → (¬ (g19 E = true)) → False
  exact pattern_2 (g18 E) (g19 E)
private theorem sat_2543 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 17, .pos 2812] := by
  change (g19 E = true) → (g18 E = true) → (¬ (g2813 E = true)) → False
  exact pattern_15 (g18 E) (g19 E)
private theorem sat_2544 (E : Nat → Bool) : (valuation E).satisfies [.neg 2813, .neg 2812] := by
  change (g2814 E = true) → (g2813 E = true) → False
  exact pattern_18 (g2811 E) (g2812 E) (g2813 E)
private theorem sat_2545 (E : Nat → Bool) : (valuation E).satisfies [.neg 2813, .neg 2811] := by
  change (g2814 E = true) → (g2812 E = true) → False
  exact pattern_19 (g2811 E) (g2812 E) (g2813 E)
private theorem sat_2546 (E : Nat → Bool) : (valuation E).satisfies [.neg 2813, .neg 2810] := by
  change (g2814 E = true) → (g2811 E = true) → False
  exact pattern_20 (g2811 E) (g2812 E) (g2813 E)
private theorem sat_2547 (E : Nat → Bool) : (valuation E).satisfies [.pos 2810, .pos 2811, .pos 2812, .pos 2813] := by
  change (¬ (g2811 E = true)) → (¬ (g2812 E = true)) → (¬ (g2813 E = true)) → (¬ (g2814 E = true)) → False
  exact pattern_21 (g2811 E) (g2812 E) (g2813 E)
private theorem sat_2548 (E : Nat → Bool) : (valuation E).satisfies [.neg 2814, .pos 20] := by
  change (g2815 E = true) → (¬ (g21 E = true)) → False
  exact pattern_1 (g21 E) (g22 E)
private theorem sat_2549 (E : Nat → Bool) : (valuation E).satisfies [.neg 2814, .pos 21] := by
  change (g2815 E = true) → (¬ (g22 E = true)) → False
  exact pattern_2 (g21 E) (g22 E)
private theorem sat_2550 (E : Nat → Bool) : (valuation E).satisfies [.neg 21, .neg 20, .pos 2814] := by
  change (g22 E = true) → (g21 E = true) → (¬ (g2815 E = true)) → False
  exact pattern_15 (g21 E) (g22 E)
private theorem sat_2551 (E : Nat → Bool) : (valuation E).satisfies [.neg 2815, .pos 20] := by
  change (g2816 E = true) → (¬ (g21 E = true)) → False
  exact pattern_1 (g21 E) (g23 E)
private theorem sat_2552 (E : Nat → Bool) : (valuation E).satisfies [.neg 2815, .pos 22] := by
  change (g2816 E = true) → (¬ (g23 E = true)) → False
  exact pattern_2 (g21 E) (g23 E)
private theorem sat_2553 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 20, .pos 2815] := by
  change (g23 E = true) → (g21 E = true) → (¬ (g2816 E = true)) → False
  exact pattern_15 (g21 E) (g23 E)
private theorem sat_2554 (E : Nat → Bool) : (valuation E).satisfies [.neg 2816, .pos 21] := by
  change (g2817 E = true) → (¬ (g22 E = true)) → False
  exact pattern_1 (g22 E) (g23 E)
private theorem sat_2555 (E : Nat → Bool) : (valuation E).satisfies [.neg 2816, .pos 22] := by
  change (g2817 E = true) → (¬ (g23 E = true)) → False
  exact pattern_2 (g22 E) (g23 E)
private theorem sat_2556 (E : Nat → Bool) : (valuation E).satisfies [.neg 22, .neg 21, .pos 2816] := by
  change (g23 E = true) → (g22 E = true) → (¬ (g2817 E = true)) → False
  exact pattern_15 (g22 E) (g23 E)
private theorem sat_2557 (E : Nat → Bool) : (valuation E).satisfies [.neg 2817, .neg 2816] := by
  change (g2818 E = true) → (g2817 E = true) → False
  exact pattern_18 (g2815 E) (g2816 E) (g2817 E)
private theorem sat_2558 (E : Nat → Bool) : (valuation E).satisfies [.neg 2817, .neg 2815] := by
  change (g2818 E = true) → (g2816 E = true) → False
  exact pattern_19 (g2815 E) (g2816 E) (g2817 E)
private theorem sat_2559 (E : Nat → Bool) : (valuation E).satisfies [.neg 2817, .neg 2814] := by
  change (g2818 E = true) → (g2815 E = true) → False
  exact pattern_20 (g2815 E) (g2816 E) (g2817 E)
private theorem sat_2560 (E : Nat → Bool) : (valuation E).satisfies [.pos 2814, .pos 2815, .pos 2816, .pos 2817] := by
  change (¬ (g2815 E = true)) → (¬ (g2816 E = true)) → (¬ (g2817 E = true)) → (¬ (g2818 E = true)) → False
  exact pattern_21 (g2815 E) (g2816 E) (g2817 E)
private theorem sat_2561 (E : Nat → Bool) : (valuation E).satisfies [.neg 2818, .neg 25] := by
  change (g2819 E = true) → (g26 E = true) → False
  exact pattern_18 (g24 E) (g25 E) (g26 E)
private theorem sat_2562 (E : Nat → Bool) : (valuation E).satisfies [.neg 2818, .neg 24] := by
  change (g2819 E = true) → (g25 E = true) → False
  exact pattern_19 (g24 E) (g25 E) (g26 E)
private theorem sat_2563 (E : Nat → Bool) : (valuation E).satisfies [.neg 2818, .neg 23] := by
  change (g2819 E = true) → (g24 E = true) → False
  exact pattern_20 (g24 E) (g25 E) (g26 E)
theorem contradiction_of_semantic_roots (E : Nat → Bool)
    (h_28 : (valuation E).satisfies [.neg 63])
    (h_73 : (valuation E).satisfies [.neg 105])
    (h_104 : (valuation E).satisfies [.neg 147])
    (h_131 : (valuation E).satisfies [.neg 189])
    (h_169 : (valuation E).satisfies [.neg 231])
    (h_201 : (valuation E).satisfies [.neg 273])
    (h_233 : (valuation E).satisfies [.neg 315])
    (h_254 : (valuation E).satisfies [.neg 357])
    (h_1484 : (valuation E).satisfies [.neg 803])
    (h_1485 : (valuation E).satisfies [.neg 1225, .pos 803])
    (h_1486 : (valuation E).satisfies [.neg 1227, .pos 805])
    (h_1487 : (valuation E).satisfies [.neg 1229, .pos 807])
    (h_1488 : (valuation E).satisfies [.neg 1231, .pos 809])
    (h_1489 : (valuation E).satisfies [.neg 1647, .pos 1225])
    (h_1490 : (valuation E).satisfies [.neg 1649, .pos 1227])
    (h_1491 : (valuation E).satisfies [.neg 1651, .pos 1229])
    (h_1492 : (valuation E).satisfies [.neg 1653, .pos 1231])
    (h_1493 : (valuation E).satisfies [.neg 2069, .pos 1647])
    (h_1494 : (valuation E).satisfies [.neg 2071, .pos 1649])
    (h_1495 : (valuation E).satisfies [.neg 2073, .pos 1651])
    (h_1496 : (valuation E).satisfies [.neg 2075, .pos 1653])
    (h_1505 : (valuation E).satisfies [.pos 2106])
    (h_1515 : (valuation E).satisfies [.pos 2112])
    (h_1525 : (valuation E).satisfies [.pos 2118])
    (h_1553 : (valuation E).satisfies [.pos 2122, .pos 2123, .pos 2124, .pos 2125, .pos 2126])
    (h_1575 : (valuation E).satisfies [.pos 2130, .pos 2131, .pos 2132, .pos 2133, .pos 2134])
    (h_1600 : (valuation E).satisfies [.pos 2138, .pos 2142, .pos 2143, .pos 2144, .pos 2145])
    (h_1620 : (valuation E).satisfies [.pos 2149, .pos 2153, .pos 2154, .pos 2155, .pos 2156])
    (h_1636 : (valuation E).satisfies [.pos 2160, .pos 2164, .pos 2165, .pos 2166, .pos 2167])
    (h_1661 : (valuation E).satisfies [.pos 2171, .pos 2175, .pos 2176, .pos 2177, .pos 2178])
    (h_1685 : (valuation E).satisfies [.pos 2182, .pos 2183, .pos 2184, .pos 2185, .pos 2186])
    (h_1704 : (valuation E).satisfies [.pos 2190, .pos 2194, .pos 2195, .pos 2196, .pos 2197])
    (h_1722 : (valuation E).satisfies [.pos 2201, .pos 2205, .pos 2206, .pos 2207, .pos 2208])
    (h_1739 : (valuation E).satisfies [.pos 2212, .pos 2216, .pos 2217, .pos 2218, .pos 2219])
    (h_1757 : (valuation E).satisfies [.pos 2223, .pos 2227, .pos 2228, .pos 2229, .pos 2230])
    (h_1775 : (valuation E).satisfies [.pos 2234, .pos 2238, .pos 2239, .pos 2240, .pos 2241])
    (h_1797 : (valuation E).satisfies [.pos 2245, .pos 2249, .pos 2250, .pos 2251, .pos 2252])
    (h_1820 : (valuation E).satisfies [.pos 2256, .pos 2260, .pos 2261, .pos 2262, .pos 2263])
    (h_1851 : (valuation E).satisfies [.pos 2267, .pos 2271, .pos 2272, .pos 2273, .pos 2274])
    (h_1872 : (valuation E).satisfies [.pos 2278, .pos 2282, .pos 2286, .pos 2287, .pos 2288])
    (h_1885 : (valuation E).satisfies [.pos 2292, .pos 2296, .pos 2300, .pos 2301, .pos 2302])
    (h_1901 : (valuation E).satisfies [.pos 2306, .pos 2310, .pos 2314, .pos 2315, .pos 2316])
    (h_1912 : (valuation E).satisfies [.pos 2320, .pos 2324, .pos 2328, .pos 2329, .pos 2330])
    (h_1932 : (valuation E).satisfies [.pos 2334, .pos 2338, .pos 2342, .pos 2343, .pos 2344])
    (h_1958 : (valuation E).satisfies [.pos 2348, .pos 2352, .pos 2356, .pos 2357, .pos 2358])
    (h_1985 : (valuation E).satisfies [.pos 2362, .pos 2363, .pos 2364, .pos 2365, .pos 2366])
    (h_1998 : (valuation E).satisfies [.pos 2370, .pos 2374, .pos 2375, .pos 2376, .pos 2377])
    (h_2020 : (valuation E).satisfies [.pos 2381, .pos 2385, .pos 2386, .pos 2387, .pos 2388])
    (h_2050 : (valuation E).satisfies [.pos 2392, .pos 2396, .pos 2397, .pos 2398, .pos 2399])
    (h_2080 : (valuation E).satisfies [.pos 2403, .pos 2407, .pos 2408, .pos 2409, .pos 2410])
    (h_2090 : (valuation E).satisfies [.pos 2414, .pos 2418, .pos 2419, .pos 2420, .pos 2421])
    (h_2108 : (valuation E).satisfies [.pos 2425, .pos 2429, .pos 2430, .pos 2431, .pos 2432])
    (h_2134 : (valuation E).satisfies [.pos 2436, .pos 2440, .pos 2441, .pos 2442, .pos 2443])
    (h_2155 : (valuation E).satisfies [.pos 2447, .pos 2451, .pos 2452, .pos 2453, .pos 2454])
    (h_2164 : (valuation E).satisfies [.pos 2458, .pos 2462, .pos 2466, .pos 2467, .pos 2468])
    (h_2175 : (valuation E).satisfies [.pos 2472, .pos 2476, .pos 2480, .pos 2481, .pos 2482])
    (h_2187 : (valuation E).satisfies [.pos 2486, .pos 2490, .pos 2494, .pos 2495, .pos 2496])
    (h_2204 : (valuation E).satisfies [.pos 2500, .pos 2504, .pos 2508, .pos 2509, .pos 2510])
    (h_2226 : (valuation E).satisfies [.pos 2514, .pos 2518, .pos 2522, .pos 2523, .pos 2524])
    (h_2243 : (valuation E).satisfies [.pos 2528, .pos 2532, .pos 2536, .pos 2537, .pos 2538])
    (h_2251 : (valuation E).satisfies [.pos 2542, .pos 2546, .pos 2547, .pos 2548, .pos 2549])
    (h_2268 : (valuation E).satisfies [.pos 2553, .pos 2557, .pos 2558, .pos 2559, .pos 2560])
    (h_2297 : (valuation E).satisfies [.pos 2564, .pos 2568, .pos 2569, .pos 2570, .pos 2571])
    (h_2333 : (valuation E).satisfies [.pos 2575, .pos 2579, .pos 2580, .pos 2581, .pos 2582])
    (h_2342 : (valuation E).satisfies [.pos 2600, .pos 2604, .pos 2608, .pos 2609, .pos 2610])
    (h_2359 : (valuation E).satisfies [.pos 2628, .pos 2632, .pos 2636, .pos 2637, .pos 2638])
    (h_2374 : (valuation E).satisfies [.pos 2642, .pos 2646, .pos 2650, .pos 2651, .pos 2652])
    (h_2411 : (valuation E).satisfies [.pos 2656, .pos 2660, .pos 2664, .pos 2665, .pos 2666])
    (h_2420 : (valuation E).satisfies [.pos 2698, .pos 2702, .pos 2706, .pos 2707, .pos 2708])
    (h_2429 : (valuation E).satisfies [.pos 2712, .pos 2716, .pos 2720, .pos 2721, .pos 2722])
    (h_2448 : (valuation E).satisfies [.pos 2726, .pos 2730, .pos 2734, .pos 2735, .pos 2736])
    (h_2481 : (valuation E).satisfies [.pos 2740, .pos 2744, .pos 2748, .pos 2749, .pos 2750])
    (h_2497 : (valuation E).satisfies [.pos 2771, .pos 2775, .pos 2779, .pos 2783, .pos 2784])
    (h_2519 : (valuation E).satisfies [.pos 2788, .pos 2792, .pos 2796, .pos 2800, .pos 2801])
    (h_2564 : (valuation E).satisfies [.pos 2805, .pos 2809, .pos 2813, .pos 2817, .pos 2818])
    : False := by
  exact pendant_four_rup (valuation E) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_0 E)) (fmla_one _ _ (sat_1 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_3 E)) (fmla_one _ _ (sat_4 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_5 E)) (fmla_one _ _ (sat_6 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_7 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_8 E)) (fmla_one _ _ (sat_9 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_10 E)) (fmla_one _ _ (sat_11 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_12 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_13 E)) (fmla_one _ _ (sat_14 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_15 E)) (fmla_one _ _ (sat_16 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_17 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_18 E)) (fmla_one _ _ (sat_19 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_20 E)) (fmla_one _ _ (sat_21 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_22 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_23 E)) (fmla_one _ _ (sat_24 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_25 E)) (fmla_one _ _ (sat_26 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_27 E)) (fmla_and _ _ _ (fmla_one _ _ h_28) (fmla_one _ _ (sat_29 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_30 E)) (fmla_one _ _ (sat_31 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_32 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_33 E)) (fmla_one _ _ (sat_34 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_35 E)) (fmla_one _ _ (sat_36 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_37 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_38 E)) (fmla_one _ _ (sat_39 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_40 E)) (fmla_one _ _ (sat_41 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_42 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_43 E)) (fmla_one _ _ (sat_44 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_45 E)) (fmla_one _ _ (sat_46 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_47 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_48 E)) (fmla_one _ _ (sat_49 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_50 E)) (fmla_one _ _ (sat_51 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_52 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_53 E)) (fmla_one _ _ (sat_54 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_55 E)) (fmla_one _ _ (sat_56 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_57 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_58 E)) (fmla_one _ _ (sat_59 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_60 E)) (fmla_one _ _ (sat_61 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_62 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_63 E)) (fmla_one _ _ (sat_64 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_65 E)) (fmla_one _ _ (sat_66 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_67 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_68 E)) (fmla_one _ _ (sat_69 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_70 E)) (fmla_one _ _ (sat_71 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_72 E)) (fmla_and _ _ _ (fmla_one _ _ h_73) (fmla_one _ _ (sat_74 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_75 E)) (fmla_one _ _ (sat_76 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_77 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_78 E)) (fmla_one _ _ (sat_79 E))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_80 E)) (fmla_one _ _ (sat_81 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_82 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_83 E)) (fmla_one _ _ (sat_84 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_85 E)) (fmla_one _ _ (sat_86 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_87 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_88 E)) (fmla_one _ _ (sat_89 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_90 E)) (fmla_one _ _ (sat_91 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_92 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_93 E)) (fmla_one _ _ (sat_94 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_95 E)) (fmla_one _ _ (sat_96 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_97 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_98 E)) (fmla_one _ _ (sat_99 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_100 E)) (fmla_one _ _ (sat_101 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_102 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_103 E)) (fmla_one _ _ h_104)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_105 E)) (fmla_one _ _ (sat_106 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_107 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_108 E)) (fmla_one _ _ (sat_109 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_110 E)) (fmla_one _ _ (sat_111 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_112 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_113 E)) (fmla_one _ _ (sat_114 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_115 E)) (fmla_one _ _ (sat_116 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_117 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_118 E)) (fmla_one _ _ (sat_119 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_120 E)) (fmla_one _ _ (sat_121 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_122 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_123 E)) (fmla_one _ _ (sat_124 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_125 E)) (fmla_one _ _ (sat_126 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_127 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_128 E)) (fmla_one _ _ (sat_129 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_130 E)) (fmla_one _ _ h_131)) (fmla_and _ _ _ (fmla_one _ _ (sat_132 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_133 E)) (fmla_one _ _ (sat_134 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_135 E)) (fmla_one _ _ (sat_136 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_137 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_138 E)) (fmla_one _ _ (sat_139 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_140 E)) (fmla_one _ _ (sat_141 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_142 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_143 E)) (fmla_one _ _ (sat_144 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_145 E)) (fmla_one _ _ (sat_146 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_147 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_148 E)) (fmla_one _ _ (sat_149 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_150 E)) (fmla_one _ _ (sat_151 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_152 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_153 E)) (fmla_one _ _ (sat_154 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_155 E)) (fmla_one _ _ (sat_156 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_157 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_158 E)) (fmla_one _ _ (sat_159 E)))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_160 E)) (fmla_one _ _ (sat_161 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_162 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_163 E)) (fmla_one _ _ (sat_164 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_165 E)) (fmla_one _ _ (sat_166 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_167 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_168 E)) (fmla_one _ _ h_169))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_170 E)) (fmla_one _ _ (sat_171 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_172 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_173 E)) (fmla_one _ _ (sat_174 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_175 E)) (fmla_one _ _ (sat_176 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_177 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_178 E)) (fmla_one _ _ (sat_179 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_180 E)) (fmla_one _ _ (sat_181 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_182 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_183 E)) (fmla_one _ _ (sat_184 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_185 E)) (fmla_one _ _ (sat_186 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_187 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_188 E)) (fmla_one _ _ (sat_189 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_190 E)) (fmla_one _ _ (sat_191 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_192 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_193 E)) (fmla_one _ _ (sat_194 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_195 E)) (fmla_one _ _ (sat_196 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_197 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_198 E)) (fmla_one _ _ (sat_199 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_200 E)) (fmla_one _ _ h_201)) (fmla_and _ _ _ (fmla_one _ _ (sat_202 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_203 E)) (fmla_one _ _ (sat_204 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_205 E)) (fmla_one _ _ (sat_206 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_207 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_208 E)) (fmla_one _ _ (sat_209 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_210 E)) (fmla_one _ _ (sat_211 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_212 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_213 E)) (fmla_one _ _ (sat_214 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_215 E)) (fmla_one _ _ (sat_216 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_217 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_218 E)) (fmla_one _ _ (sat_219 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_220 E)) (fmla_one _ _ (sat_221 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_222 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_223 E)) (fmla_one _ _ (sat_224 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_225 E)) (fmla_one _ _ (sat_226 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_227 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_228 E)) (fmla_one _ _ (sat_229 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_230 E)) (fmla_one _ _ (sat_231 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_232 E)) (fmla_and _ _ _ (fmla_one _ _ h_233) (fmla_one _ _ (sat_234 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_235 E)) (fmla_one _ _ (sat_236 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_237 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_238 E)) (fmla_one _ _ (sat_239 E))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_240 E)) (fmla_one _ _ (sat_241 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_242 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_243 E)) (fmla_one _ _ (sat_244 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_245 E)) (fmla_one _ _ (sat_246 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_247 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_248 E)) (fmla_one _ _ (sat_249 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_250 E)) (fmla_one _ _ (sat_251 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_252 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_253 E)) (fmla_one _ _ h_254)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_255 E)) (fmla_one _ _ (sat_256 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_257 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_258 E)) (fmla_one _ _ (sat_259 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_260 E)) (fmla_one _ _ (sat_261 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_262 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_263 E)) (fmla_one _ _ (sat_264 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_265 E)) (fmla_one _ _ (sat_266 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_267 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_268 E)) (fmla_one _ _ (sat_269 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_270 E)) (fmla_one _ _ (sat_271 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_272 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_273 E)) (fmla_one _ _ (sat_274 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_275 E)) (fmla_one _ _ (sat_276 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_277 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_278 E)) (fmla_one _ _ (sat_279 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_280 E)) (fmla_one _ _ (sat_281 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_282 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_283 E)) (fmla_one _ _ (sat_284 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_285 E)) (fmla_one _ _ (sat_286 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_287 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_288 E)) (fmla_one _ _ (sat_289 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_290 E)) (fmla_one _ _ (sat_291 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_292 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_293 E)) (fmla_one _ _ (sat_294 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_295 E)) (fmla_one _ _ (sat_296 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_297 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_298 E)) (fmla_one _ _ (sat_299 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_300 E)) (fmla_one _ _ (sat_301 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_302 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_303 E)) (fmla_one _ _ (sat_304 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_305 E)) (fmla_one _ _ (sat_306 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_307 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_308 E)) (fmla_one _ _ (sat_309 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_310 E)) (fmla_one _ _ (sat_311 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_312 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_313 E)) (fmla_one _ _ (sat_314 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_315 E)) (fmla_one _ _ (sat_316 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_317 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_318 E)) (fmla_one _ _ (sat_319 E))))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_320 E)) (fmla_one _ _ (sat_321 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_322 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_323 E)) (fmla_one _ _ (sat_324 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_325 E)) (fmla_one _ _ (sat_326 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_327 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_328 E)) (fmla_one _ _ (sat_329 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_330 E)) (fmla_one _ _ (sat_331 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_332 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_333 E)) (fmla_one _ _ (sat_334 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_335 E)) (fmla_one _ _ (sat_336 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_337 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_338 E)) (fmla_one _ _ (sat_339 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_340 E)) (fmla_one _ _ (sat_341 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_342 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_343 E)) (fmla_one _ _ (sat_344 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_345 E)) (fmla_one _ _ (sat_346 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_347 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_348 E)) (fmla_one _ _ (sat_349 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_350 E)) (fmla_one _ _ (sat_351 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_352 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_353 E)) (fmla_one _ _ (sat_354 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_355 E)) (fmla_one _ _ (sat_356 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_357 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_358 E)) (fmla_one _ _ (sat_359 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_360 E)) (fmla_one _ _ (sat_361 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_362 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_363 E)) (fmla_one _ _ (sat_364 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_365 E)) (fmla_one _ _ (sat_366 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_367 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_368 E)) (fmla_one _ _ (sat_369 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_370 E)) (fmla_one _ _ (sat_371 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_372 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_373 E)) (fmla_one _ _ (sat_374 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_375 E)) (fmla_one _ _ (sat_376 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_377 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_378 E)) (fmla_one _ _ (sat_379 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_380 E)) (fmla_one _ _ (sat_381 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_382 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_383 E)) (fmla_one _ _ (sat_384 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_385 E)) (fmla_one _ _ (sat_386 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_387 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_388 E)) (fmla_one _ _ (sat_389 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_390 E)) (fmla_one _ _ (sat_391 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_392 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_393 E)) (fmla_one _ _ (sat_394 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_395 E)) (fmla_one _ _ (sat_396 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_397 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_398 E)) (fmla_one _ _ (sat_399 E))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_400 E)) (fmla_one _ _ (sat_401 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_402 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_403 E)) (fmla_one _ _ (sat_404 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_405 E)) (fmla_one _ _ (sat_406 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_407 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_408 E)) (fmla_one _ _ (sat_409 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_410 E)) (fmla_one _ _ (sat_411 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_412 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_413 E)) (fmla_one _ _ (sat_414 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_415 E)) (fmla_one _ _ (sat_416 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_417 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_418 E)) (fmla_one _ _ (sat_419 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_420 E)) (fmla_one _ _ (sat_421 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_422 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_423 E)) (fmla_one _ _ (sat_424 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_425 E)) (fmla_one _ _ (sat_426 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_427 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_428 E)) (fmla_one _ _ (sat_429 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_430 E)) (fmla_one _ _ (sat_431 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_432 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_433 E)) (fmla_one _ _ (sat_434 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_435 E)) (fmla_one _ _ (sat_436 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_437 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_438 E)) (fmla_one _ _ (sat_439 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_440 E)) (fmla_one _ _ (sat_441 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_442 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_443 E)) (fmla_one _ _ (sat_444 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_445 E)) (fmla_one _ _ (sat_446 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_447 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_448 E)) (fmla_one _ _ (sat_449 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_450 E)) (fmla_one _ _ (sat_451 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_452 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_453 E)) (fmla_one _ _ (sat_454 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_455 E)) (fmla_one _ _ (sat_456 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_457 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_458 E)) (fmla_one _ _ (sat_459 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_460 E)) (fmla_one _ _ (sat_461 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_462 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_463 E)) (fmla_one _ _ (sat_464 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_465 E)) (fmla_one _ _ (sat_466 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_467 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_468 E)) (fmla_one _ _ (sat_469 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_470 E)) (fmla_one _ _ (sat_471 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_472 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_473 E)) (fmla_one _ _ (sat_474 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_475 E)) (fmla_one _ _ (sat_476 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_477 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_478 E)) (fmla_one _ _ (sat_479 E)))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_480 E)) (fmla_one _ _ (sat_481 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_482 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_483 E)) (fmla_one _ _ (sat_484 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_485 E)) (fmla_one _ _ (sat_486 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_487 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_488 E)) (fmla_one _ _ (sat_489 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_490 E)) (fmla_one _ _ (sat_491 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_492 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_493 E)) (fmla_one _ _ (sat_494 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_495 E)) (fmla_one _ _ (sat_496 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_497 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_498 E)) (fmla_one _ _ (sat_499 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_500 E)) (fmla_one _ _ (sat_501 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_502 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_503 E)) (fmla_one _ _ (sat_504 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_505 E)) (fmla_one _ _ (sat_506 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_507 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_508 E)) (fmla_one _ _ (sat_509 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_510 E)) (fmla_one _ _ (sat_511 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_512 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_513 E)) (fmla_one _ _ (sat_514 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_515 E)) (fmla_one _ _ (sat_516 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_517 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_518 E)) (fmla_one _ _ (sat_519 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_520 E)) (fmla_one _ _ (sat_521 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_522 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_523 E)) (fmla_one _ _ (sat_524 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_525 E)) (fmla_one _ _ (sat_526 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_527 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_528 E)) (fmla_one _ _ (sat_529 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_530 E)) (fmla_one _ _ (sat_531 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_532 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_533 E)) (fmla_one _ _ (sat_534 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_535 E)) (fmla_one _ _ (sat_536 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_537 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_538 E)) (fmla_one _ _ (sat_539 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_540 E)) (fmla_one _ _ (sat_541 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_542 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_543 E)) (fmla_one _ _ (sat_544 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_545 E)) (fmla_one _ _ (sat_546 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_547 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_548 E)) (fmla_one _ _ (sat_549 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_550 E)) (fmla_one _ _ (sat_551 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_552 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_553 E)) (fmla_one _ _ (sat_554 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_555 E)) (fmla_one _ _ (sat_556 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_557 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_558 E)) (fmla_one _ _ (sat_559 E))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_560 E)) (fmla_one _ _ (sat_561 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_562 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_563 E)) (fmla_one _ _ (sat_564 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_565 E)) (fmla_one _ _ (sat_566 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_567 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_568 E)) (fmla_one _ _ (sat_569 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_570 E)) (fmla_one _ _ (sat_571 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_572 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_573 E)) (fmla_one _ _ (sat_574 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_575 E)) (fmla_one _ _ (sat_576 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_577 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_578 E)) (fmla_one _ _ (sat_579 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_580 E)) (fmla_one _ _ (sat_581 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_582 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_583 E)) (fmla_one _ _ (sat_584 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_585 E)) (fmla_one _ _ (sat_586 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_587 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_588 E)) (fmla_one _ _ (sat_589 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_590 E)) (fmla_one _ _ (sat_591 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_592 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_593 E)) (fmla_one _ _ (sat_594 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_595 E)) (fmla_one _ _ (sat_596 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_597 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_598 E)) (fmla_one _ _ (sat_599 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_600 E)) (fmla_one _ _ (sat_601 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_602 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_603 E)) (fmla_one _ _ (sat_604 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_605 E)) (fmla_one _ _ (sat_606 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_607 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_608 E)) (fmla_one _ _ (sat_609 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_610 E)) (fmla_one _ _ (sat_611 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_612 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_613 E)) (fmla_one _ _ (sat_614 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_615 E)) (fmla_one _ _ (sat_616 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_617 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_618 E)) (fmla_one _ _ (sat_619 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_620 E)) (fmla_one _ _ (sat_621 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_622 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_623 E)) (fmla_one _ _ (sat_624 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_625 E)) (fmla_one _ _ (sat_626 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_627 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_628 E)) (fmla_one _ _ (sat_629 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_630 E)) (fmla_one _ _ (sat_631 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_632 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_633 E)) (fmla_one _ _ (sat_634 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_635 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_636 E)) (fmla_one _ _ (sat_637 E)))) (fmla_and _ _ _ (fmla_one _ _ (sat_638 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_639 E)) (fmla_one _ _ (sat_640 E)))))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_641 E)) (fmla_one _ _ (sat_642 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_643 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_644 E)) (fmla_one _ _ (sat_645 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_646 E)) (fmla_one _ _ (sat_647 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_648 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_649 E)) (fmla_one _ _ (sat_650 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_651 E)) (fmla_one _ _ (sat_652 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_653 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_654 E)) (fmla_one _ _ (sat_655 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_656 E)) (fmla_one _ _ (sat_657 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_658 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_659 E)) (fmla_one _ _ (sat_660 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_661 E)) (fmla_one _ _ (sat_662 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_663 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_664 E)) (fmla_one _ _ (sat_665 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_666 E)) (fmla_one _ _ (sat_667 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_668 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_669 E)) (fmla_one _ _ (sat_670 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_671 E)) (fmla_one _ _ (sat_672 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_673 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_674 E)) (fmla_one _ _ (sat_675 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_676 E)) (fmla_one _ _ (sat_677 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_678 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_679 E)) (fmla_one _ _ (sat_680 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_681 E)) (fmla_one _ _ (sat_682 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_683 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_684 E)) (fmla_one _ _ (sat_685 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_686 E)) (fmla_one _ _ (sat_687 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_688 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_689 E)) (fmla_one _ _ (sat_690 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_691 E)) (fmla_one _ _ (sat_692 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_693 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_694 E)) (fmla_one _ _ (sat_695 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_696 E)) (fmla_one _ _ (sat_697 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_698 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_699 E)) (fmla_one _ _ (sat_700 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_701 E)) (fmla_one _ _ (sat_702 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_703 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_704 E)) (fmla_one _ _ (sat_705 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_706 E)) (fmla_one _ _ (sat_707 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_708 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_709 E)) (fmla_one _ _ (sat_710 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_711 E)) (fmla_one _ _ (sat_712 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_713 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_714 E)) (fmla_one _ _ (sat_715 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_716 E)) (fmla_one _ _ (sat_717 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_718 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_719 E)) (fmla_one _ _ (sat_720 E))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_721 E)) (fmla_one _ _ (sat_722 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_723 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_724 E)) (fmla_one _ _ (sat_725 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_726 E)) (fmla_one _ _ (sat_727 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_728 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_729 E)) (fmla_one _ _ (sat_730 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_731 E)) (fmla_one _ _ (sat_732 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_733 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_734 E)) (fmla_one _ _ (sat_735 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_736 E)) (fmla_one _ _ (sat_737 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_738 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_739 E)) (fmla_one _ _ (sat_740 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_741 E)) (fmla_one _ _ (sat_742 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_743 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_744 E)) (fmla_one _ _ (sat_745 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_746 E)) (fmla_one _ _ (sat_747 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_748 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_749 E)) (fmla_one _ _ (sat_750 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_751 E)) (fmla_one _ _ (sat_752 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_753 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_754 E)) (fmla_one _ _ (sat_755 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_756 E)) (fmla_one _ _ (sat_757 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_758 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_759 E)) (fmla_one _ _ (sat_760 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_761 E)) (fmla_one _ _ (sat_762 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_763 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_764 E)) (fmla_one _ _ (sat_765 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_766 E)) (fmla_one _ _ (sat_767 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_768 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_769 E)) (fmla_one _ _ (sat_770 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_771 E)) (fmla_one _ _ (sat_772 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_773 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_774 E)) (fmla_one _ _ (sat_775 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_776 E)) (fmla_one _ _ (sat_777 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_778 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_779 E)) (fmla_one _ _ (sat_780 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_781 E)) (fmla_one _ _ (sat_782 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_783 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_784 E)) (fmla_one _ _ (sat_785 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_786 E)) (fmla_one _ _ (sat_787 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_788 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_789 E)) (fmla_one _ _ (sat_790 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_791 E)) (fmla_one _ _ (sat_792 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_793 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_794 E)) (fmla_one _ _ (sat_795 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_796 E)) (fmla_one _ _ (sat_797 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_798 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_799 E)) (fmla_one _ _ (sat_800 E)))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_801 E)) (fmla_one _ _ (sat_802 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_803 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_804 E)) (fmla_one _ _ (sat_805 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_806 E)) (fmla_one _ _ (sat_807 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_808 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_809 E)) (fmla_one _ _ (sat_810 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_811 E)) (fmla_one _ _ (sat_812 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_813 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_814 E)) (fmla_one _ _ (sat_815 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_816 E)) (fmla_one _ _ (sat_817 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_818 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_819 E)) (fmla_one _ _ (sat_820 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_821 E)) (fmla_one _ _ (sat_822 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_823 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_824 E)) (fmla_one _ _ (sat_825 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_826 E)) (fmla_one _ _ (sat_827 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_828 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_829 E)) (fmla_one _ _ (sat_830 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_831 E)) (fmla_one _ _ (sat_832 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_833 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_834 E)) (fmla_one _ _ (sat_835 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_836 E)) (fmla_one _ _ (sat_837 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_838 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_839 E)) (fmla_one _ _ (sat_840 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_841 E)) (fmla_one _ _ (sat_842 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_843 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_844 E)) (fmla_one _ _ (sat_845 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_846 E)) (fmla_one _ _ (sat_847 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_848 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_849 E)) (fmla_one _ _ (sat_850 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_851 E)) (fmla_one _ _ (sat_852 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_853 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_854 E)) (fmla_one _ _ (sat_855 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_856 E)) (fmla_one _ _ (sat_857 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_858 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_859 E)) (fmla_one _ _ (sat_860 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_861 E)) (fmla_one _ _ (sat_862 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_863 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_864 E)) (fmla_one _ _ (sat_865 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_866 E)) (fmla_one _ _ (sat_867 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_868 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_869 E)) (fmla_one _ _ (sat_870 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_871 E)) (fmla_one _ _ (sat_872 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_873 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_874 E)) (fmla_one _ _ (sat_875 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_876 E)) (fmla_one _ _ (sat_877 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_878 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_879 E)) (fmla_one _ _ (sat_880 E))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_881 E)) (fmla_one _ _ (sat_882 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_883 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_884 E)) (fmla_one _ _ (sat_885 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_886 E)) (fmla_one _ _ (sat_887 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_888 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_889 E)) (fmla_one _ _ (sat_890 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_891 E)) (fmla_one _ _ (sat_892 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_893 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_894 E)) (fmla_one _ _ (sat_895 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_896 E)) (fmla_one _ _ (sat_897 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_898 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_899 E)) (fmla_one _ _ (sat_900 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_901 E)) (fmla_one _ _ (sat_902 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_903 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_904 E)) (fmla_one _ _ (sat_905 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_906 E)) (fmla_one _ _ (sat_907 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_908 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_909 E)) (fmla_one _ _ (sat_910 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_911 E)) (fmla_one _ _ (sat_912 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_913 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_914 E)) (fmla_one _ _ (sat_915 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_916 E)) (fmla_one _ _ (sat_917 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_918 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_919 E)) (fmla_one _ _ (sat_920 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_921 E)) (fmla_one _ _ (sat_922 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_923 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_924 E)) (fmla_one _ _ (sat_925 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_926 E)) (fmla_one _ _ (sat_927 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_928 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_929 E)) (fmla_one _ _ (sat_930 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_931 E)) (fmla_one _ _ (sat_932 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_933 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_934 E)) (fmla_one _ _ (sat_935 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_936 E)) (fmla_one _ _ (sat_937 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_938 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_939 E)) (fmla_one _ _ (sat_940 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_941 E)) (fmla_one _ _ (sat_942 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_943 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_944 E)) (fmla_one _ _ (sat_945 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_946 E)) (fmla_one _ _ (sat_947 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_948 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_949 E)) (fmla_one _ _ (sat_950 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_951 E)) (fmla_one _ _ (sat_952 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_953 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_954 E)) (fmla_one _ _ (sat_955 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_956 E)) (fmla_one _ _ (sat_957 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_958 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_959 E)) (fmla_one _ _ (sat_960 E))))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_961 E)) (fmla_one _ _ (sat_962 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_963 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_964 E)) (fmla_one _ _ (sat_965 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_966 E)) (fmla_one _ _ (sat_967 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_968 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_969 E)) (fmla_one _ _ (sat_970 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_971 E)) (fmla_one _ _ (sat_972 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_973 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_974 E)) (fmla_one _ _ (sat_975 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_976 E)) (fmla_one _ _ (sat_977 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_978 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_979 E)) (fmla_one _ _ (sat_980 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_981 E)) (fmla_one _ _ (sat_982 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_983 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_984 E)) (fmla_one _ _ (sat_985 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_986 E)) (fmla_one _ _ (sat_987 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_988 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_989 E)) (fmla_one _ _ (sat_990 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_991 E)) (fmla_one _ _ (sat_992 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_993 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_994 E)) (fmla_one _ _ (sat_995 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_996 E)) (fmla_one _ _ (sat_997 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_998 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_999 E)) (fmla_one _ _ (sat_1000 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1001 E)) (fmla_one _ _ (sat_1002 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1003 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1004 E)) (fmla_one _ _ (sat_1005 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1006 E)) (fmla_one _ _ (sat_1007 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1008 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1009 E)) (fmla_one _ _ (sat_1010 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1011 E)) (fmla_one _ _ (sat_1012 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1013 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1014 E)) (fmla_one _ _ (sat_1015 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1016 E)) (fmla_one _ _ (sat_1017 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1018 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1019 E)) (fmla_one _ _ (sat_1020 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1021 E)) (fmla_one _ _ (sat_1022 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1023 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1024 E)) (fmla_one _ _ (sat_1025 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1026 E)) (fmla_one _ _ (sat_1027 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1028 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1029 E)) (fmla_one _ _ (sat_1030 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1031 E)) (fmla_one _ _ (sat_1032 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1033 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1034 E)) (fmla_one _ _ (sat_1035 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1036 E)) (fmla_one _ _ (sat_1037 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1038 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1039 E)) (fmla_one _ _ (sat_1040 E))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1041 E)) (fmla_one _ _ (sat_1042 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1043 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1044 E)) (fmla_one _ _ (sat_1045 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1046 E)) (fmla_one _ _ (sat_1047 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1048 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1049 E)) (fmla_one _ _ (sat_1050 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1051 E)) (fmla_one _ _ (sat_1052 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1053 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1054 E)) (fmla_one _ _ (sat_1055 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1056 E)) (fmla_one _ _ (sat_1057 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1058 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1059 E)) (fmla_one _ _ (sat_1060 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1061 E)) (fmla_one _ _ (sat_1062 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1063 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1064 E)) (fmla_one _ _ (sat_1065 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1066 E)) (fmla_one _ _ (sat_1067 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1068 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1069 E)) (fmla_one _ _ (sat_1070 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1071 E)) (fmla_one _ _ (sat_1072 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1073 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1074 E)) (fmla_one _ _ (sat_1075 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1076 E)) (fmla_one _ _ (sat_1077 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1078 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1079 E)) (fmla_one _ _ (sat_1080 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1081 E)) (fmla_one _ _ (sat_1082 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1083 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1084 E)) (fmla_one _ _ (sat_1085 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1086 E)) (fmla_one _ _ (sat_1087 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1088 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1089 E)) (fmla_one _ _ (sat_1090 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1091 E)) (fmla_one _ _ (sat_1092 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1093 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1094 E)) (fmla_one _ _ (sat_1095 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1096 E)) (fmla_one _ _ (sat_1097 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1098 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1099 E)) (fmla_one _ _ (sat_1100 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1101 E)) (fmla_one _ _ (sat_1102 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1103 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1104 E)) (fmla_one _ _ (sat_1105 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1106 E)) (fmla_one _ _ (sat_1107 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1108 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1109 E)) (fmla_one _ _ (sat_1110 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1111 E)) (fmla_one _ _ (sat_1112 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1113 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1114 E)) (fmla_one _ _ (sat_1115 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1116 E)) (fmla_one _ _ (sat_1117 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1118 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1119 E)) (fmla_one _ _ (sat_1120 E)))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1121 E)) (fmla_one _ _ (sat_1122 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1123 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1124 E)) (fmla_one _ _ (sat_1125 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1126 E)) (fmla_one _ _ (sat_1127 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1128 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1129 E)) (fmla_one _ _ (sat_1130 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1131 E)) (fmla_one _ _ (sat_1132 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1133 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1134 E)) (fmla_one _ _ (sat_1135 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1136 E)) (fmla_one _ _ (sat_1137 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1138 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1139 E)) (fmla_one _ _ (sat_1140 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1141 E)) (fmla_one _ _ (sat_1142 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1143 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1144 E)) (fmla_one _ _ (sat_1145 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1146 E)) (fmla_one _ _ (sat_1147 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1148 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1149 E)) (fmla_one _ _ (sat_1150 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1151 E)) (fmla_one _ _ (sat_1152 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1153 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1154 E)) (fmla_one _ _ (sat_1155 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1156 E)) (fmla_one _ _ (sat_1157 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1158 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1159 E)) (fmla_one _ _ (sat_1160 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1161 E)) (fmla_one _ _ (sat_1162 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1163 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1164 E)) (fmla_one _ _ (sat_1165 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1166 E)) (fmla_one _ _ (sat_1167 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1168 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1169 E)) (fmla_one _ _ (sat_1170 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1171 E)) (fmla_one _ _ (sat_1172 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1173 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1174 E)) (fmla_one _ _ (sat_1175 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1176 E)) (fmla_one _ _ (sat_1177 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1178 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1179 E)) (fmla_one _ _ (sat_1180 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1181 E)) (fmla_one _ _ (sat_1182 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1183 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1184 E)) (fmla_one _ _ (sat_1185 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1186 E)) (fmla_one _ _ (sat_1187 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1188 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1189 E)) (fmla_one _ _ (sat_1190 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1191 E)) (fmla_one _ _ (sat_1192 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1193 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1194 E)) (fmla_one _ _ (sat_1195 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1196 E)) (fmla_one _ _ (sat_1197 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1198 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1199 E)) (fmla_one _ _ (sat_1200 E))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1201 E)) (fmla_one _ _ (sat_1202 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1203 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1204 E)) (fmla_one _ _ (sat_1205 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1206 E)) (fmla_one _ _ (sat_1207 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1208 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1209 E)) (fmla_one _ _ (sat_1210 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1211 E)) (fmla_one _ _ (sat_1212 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1213 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1214 E)) (fmla_one _ _ (sat_1215 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1216 E)) (fmla_one _ _ (sat_1217 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1218 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1219 E)) (fmla_one _ _ (sat_1220 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1221 E)) (fmla_one _ _ (sat_1222 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1223 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1224 E)) (fmla_one _ _ (sat_1225 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1226 E)) (fmla_one _ _ (sat_1227 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1228 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1229 E)) (fmla_one _ _ (sat_1230 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1231 E)) (fmla_one _ _ (sat_1232 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1233 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1234 E)) (fmla_one _ _ (sat_1235 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1236 E)) (fmla_one _ _ (sat_1237 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1238 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1239 E)) (fmla_one _ _ (sat_1240 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1241 E)) (fmla_one _ _ (sat_1242 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1243 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1244 E)) (fmla_one _ _ (sat_1245 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1246 E)) (fmla_one _ _ (sat_1247 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1248 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1249 E)) (fmla_one _ _ (sat_1250 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1251 E)) (fmla_one _ _ (sat_1252 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1253 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1254 E)) (fmla_one _ _ (sat_1255 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1256 E)) (fmla_one _ _ (sat_1257 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1258 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1259 E)) (fmla_one _ _ (sat_1260 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1261 E)) (fmla_one _ _ (sat_1262 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1263 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1264 E)) (fmla_one _ _ (sat_1265 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1266 E)) (fmla_one _ _ (sat_1267 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1268 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1269 E)) (fmla_one _ _ (sat_1270 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1271 E)) (fmla_one _ _ (sat_1272 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1273 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1274 E)) (fmla_one _ _ (sat_1275 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1276 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1277 E)) (fmla_one _ _ (sat_1278 E)))) (fmla_and _ _ _ (fmla_one _ _ (sat_1279 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1280 E)) (fmla_one _ _ (sat_1281 E))))))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1282 E)) (fmla_one _ _ (sat_1283 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1284 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1285 E)) (fmla_one _ _ (sat_1286 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1287 E)) (fmla_one _ _ (sat_1288 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1289 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1290 E)) (fmla_one _ _ (sat_1291 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1292 E)) (fmla_one _ _ (sat_1293 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1294 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1295 E)) (fmla_one _ _ (sat_1296 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1297 E)) (fmla_one _ _ (sat_1298 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1299 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1300 E)) (fmla_one _ _ (sat_1301 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1302 E)) (fmla_one _ _ (sat_1303 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1304 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1305 E)) (fmla_one _ _ (sat_1306 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1307 E)) (fmla_one _ _ (sat_1308 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1309 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1310 E)) (fmla_one _ _ (sat_1311 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1312 E)) (fmla_one _ _ (sat_1313 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1314 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1315 E)) (fmla_one _ _ (sat_1316 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1317 E)) (fmla_one _ _ (sat_1318 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1319 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1320 E)) (fmla_one _ _ (sat_1321 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1322 E)) (fmla_one _ _ (sat_1323 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1324 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1325 E)) (fmla_one _ _ (sat_1326 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1327 E)) (fmla_one _ _ (sat_1328 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1329 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1330 E)) (fmla_one _ _ (sat_1331 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1332 E)) (fmla_one _ _ (sat_1333 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1334 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1335 E)) (fmla_one _ _ (sat_1336 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1337 E)) (fmla_one _ _ (sat_1338 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1339 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1340 E)) (fmla_one _ _ (sat_1341 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1342 E)) (fmla_one _ _ (sat_1343 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1344 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1345 E)) (fmla_one _ _ (sat_1346 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1347 E)) (fmla_one _ _ (sat_1348 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1349 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1350 E)) (fmla_one _ _ (sat_1351 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1352 E)) (fmla_one _ _ (sat_1353 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1354 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1355 E)) (fmla_one _ _ (sat_1356 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1357 E)) (fmla_one _ _ (sat_1358 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1359 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1360 E)) (fmla_one _ _ (sat_1361 E))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1362 E)) (fmla_one _ _ (sat_1363 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1364 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1365 E)) (fmla_one _ _ (sat_1366 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1367 E)) (fmla_one _ _ (sat_1368 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1369 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1370 E)) (fmla_one _ _ (sat_1371 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1372 E)) (fmla_one _ _ (sat_1373 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1374 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1375 E)) (fmla_one _ _ (sat_1376 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1377 E)) (fmla_one _ _ (sat_1378 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1379 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1380 E)) (fmla_one _ _ (sat_1381 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1382 E)) (fmla_one _ _ (sat_1383 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1384 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1385 E)) (fmla_one _ _ (sat_1386 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1387 E)) (fmla_one _ _ (sat_1388 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1389 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1390 E)) (fmla_one _ _ (sat_1391 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1392 E)) (fmla_one _ _ (sat_1393 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1394 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1395 E)) (fmla_one _ _ (sat_1396 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1397 E)) (fmla_one _ _ (sat_1398 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1399 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1400 E)) (fmla_one _ _ (sat_1401 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1402 E)) (fmla_one _ _ (sat_1403 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1404 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1405 E)) (fmla_one _ _ (sat_1406 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1407 E)) (fmla_one _ _ (sat_1408 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1409 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1410 E)) (fmla_one _ _ (sat_1411 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1412 E)) (fmla_one _ _ (sat_1413 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1414 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1415 E)) (fmla_one _ _ (sat_1416 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1417 E)) (fmla_one _ _ (sat_1418 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1419 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1420 E)) (fmla_one _ _ (sat_1421 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1422 E)) (fmla_one _ _ (sat_1423 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1424 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1425 E)) (fmla_one _ _ (sat_1426 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1427 E)) (fmla_one _ _ (sat_1428 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1429 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1430 E)) (fmla_one _ _ (sat_1431 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1432 E)) (fmla_one _ _ (sat_1433 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1434 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1435 E)) (fmla_one _ _ (sat_1436 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1437 E)) (fmla_one _ _ (sat_1438 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1439 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1440 E)) (fmla_one _ _ (sat_1441 E)))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1442 E)) (fmla_one _ _ (sat_1443 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1444 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1445 E)) (fmla_one _ _ (sat_1446 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1447 E)) (fmla_one _ _ (sat_1448 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1449 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1450 E)) (fmla_one _ _ (sat_1451 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1452 E)) (fmla_one _ _ (sat_1453 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1454 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1455 E)) (fmla_one _ _ (sat_1456 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1457 E)) (fmla_one _ _ (sat_1458 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1459 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1460 E)) (fmla_one _ _ (sat_1461 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1462 E)) (fmla_one _ _ (sat_1463 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1464 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1465 E)) (fmla_one _ _ (sat_1466 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1467 E)) (fmla_one _ _ (sat_1468 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1469 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1470 E)) (fmla_one _ _ (sat_1471 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1472 E)) (fmla_one _ _ (sat_1473 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1474 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1475 E)) (fmla_one _ _ (sat_1476 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1477 E)) (fmla_one _ _ (sat_1478 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1479 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1480 E)) (fmla_one _ _ (sat_1481 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1482 E)) (fmla_one _ _ (sat_1483 E))) (fmla_and _ _ _ (fmla_one _ _ h_1484) (fmla_and _ _ _ (fmla_one _ _ h_1485) (fmla_one _ _ h_1486)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ h_1487) (fmla_one _ _ h_1488)) (fmla_and _ _ _ (fmla_one _ _ h_1489) (fmla_and _ _ _ (fmla_one _ _ h_1490) (fmla_one _ _ h_1491))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ h_1492) (fmla_one _ _ h_1493)) (fmla_and _ _ _ (fmla_one _ _ h_1494) (fmla_and _ _ _ (fmla_one _ _ h_1495) (fmla_one _ _ h_1496)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1497 E)) (fmla_one _ _ (sat_1498 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1499 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1500 E)) (fmla_one _ _ (sat_1501 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1502 E)) (fmla_one _ _ (sat_1503 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1504 E)) (fmla_and _ _ _ (fmla_one _ _ h_1505) (fmla_one _ _ (sat_1506 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1507 E)) (fmla_one _ _ (sat_1508 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1509 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1510 E)) (fmla_one _ _ (sat_1511 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1512 E)) (fmla_one _ _ (sat_1513 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1514 E)) (fmla_and _ _ _ (fmla_one _ _ h_1515) (fmla_one _ _ (sat_1516 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1517 E)) (fmla_one _ _ (sat_1518 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1519 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1520 E)) (fmla_one _ _ (sat_1521 E))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1522 E)) (fmla_one _ _ (sat_1523 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1524 E)) (fmla_and _ _ _ (fmla_one _ _ h_1525) (fmla_one _ _ (sat_1526 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1527 E)) (fmla_one _ _ (sat_1528 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1529 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1530 E)) (fmla_one _ _ (sat_1531 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1532 E)) (fmla_one _ _ (sat_1533 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1534 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1535 E)) (fmla_one _ _ (sat_1536 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1537 E)) (fmla_one _ _ (sat_1538 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1539 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1540 E)) (fmla_one _ _ (sat_1541 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1542 E)) (fmla_one _ _ (sat_1543 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1544 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1545 E)) (fmla_one _ _ (sat_1546 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1547 E)) (fmla_one _ _ (sat_1548 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1549 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1550 E)) (fmla_one _ _ (sat_1551 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1552 E)) (fmla_one _ _ h_1553)) (fmla_and _ _ _ (fmla_one _ _ (sat_1554 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1555 E)) (fmla_one _ _ (sat_1556 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1557 E)) (fmla_one _ _ (sat_1558 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1559 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1560 E)) (fmla_one _ _ (sat_1561 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1562 E)) (fmla_one _ _ (sat_1563 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1564 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1565 E)) (fmla_one _ _ (sat_1566 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1567 E)) (fmla_one _ _ (sat_1568 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1569 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1570 E)) (fmla_one _ _ (sat_1571 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1572 E)) (fmla_one _ _ (sat_1573 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1574 E)) (fmla_and _ _ _ (fmla_one _ _ h_1575) (fmla_one _ _ (sat_1576 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1577 E)) (fmla_one _ _ (sat_1578 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1579 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1580 E)) (fmla_one _ _ (sat_1581 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1582 E)) (fmla_one _ _ (sat_1583 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1584 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1585 E)) (fmla_one _ _ (sat_1586 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1587 E)) (fmla_one _ _ (sat_1588 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1589 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1590 E)) (fmla_one _ _ (sat_1591 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1592 E)) (fmla_one _ _ (sat_1593 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1594 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1595 E)) (fmla_one _ _ (sat_1596 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1597 E)) (fmla_one _ _ (sat_1598 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1599 E)) (fmla_and _ _ _ (fmla_one _ _ h_1600) (fmla_one _ _ (sat_1601 E))))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1602 E)) (fmla_one _ _ (sat_1603 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1604 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1605 E)) (fmla_one _ _ (sat_1606 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1607 E)) (fmla_one _ _ (sat_1608 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1609 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1610 E)) (fmla_one _ _ (sat_1611 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1612 E)) (fmla_one _ _ (sat_1613 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1614 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1615 E)) (fmla_one _ _ (sat_1616 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1617 E)) (fmla_one _ _ (sat_1618 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1619 E)) (fmla_and _ _ _ (fmla_one _ _ h_1620) (fmla_one _ _ (sat_1621 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1622 E)) (fmla_one _ _ (sat_1623 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1624 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1625 E)) (fmla_one _ _ (sat_1626 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1627 E)) (fmla_one _ _ (sat_1628 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1629 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1630 E)) (fmla_one _ _ (sat_1631 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1632 E)) (fmla_one _ _ (sat_1633 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1634 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1635 E)) (fmla_one _ _ h_1636)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1637 E)) (fmla_one _ _ (sat_1638 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1639 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1640 E)) (fmla_one _ _ (sat_1641 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1642 E)) (fmla_one _ _ (sat_1643 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1644 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1645 E)) (fmla_one _ _ (sat_1646 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1647 E)) (fmla_one _ _ (sat_1648 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1649 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1650 E)) (fmla_one _ _ (sat_1651 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1652 E)) (fmla_one _ _ (sat_1653 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1654 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1655 E)) (fmla_one _ _ (sat_1656 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1657 E)) (fmla_one _ _ (sat_1658 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1659 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1660 E)) (fmla_one _ _ h_1661)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1662 E)) (fmla_one _ _ (sat_1663 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1664 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1665 E)) (fmla_one _ _ (sat_1666 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1667 E)) (fmla_one _ _ (sat_1668 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1669 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1670 E)) (fmla_one _ _ (sat_1671 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1672 E)) (fmla_one _ _ (sat_1673 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1674 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1675 E)) (fmla_one _ _ (sat_1676 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1677 E)) (fmla_one _ _ (sat_1678 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1679 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1680 E)) (fmla_one _ _ (sat_1681 E))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1682 E)) (fmla_one _ _ (sat_1683 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1684 E)) (fmla_and _ _ _ (fmla_one _ _ h_1685) (fmla_one _ _ (sat_1686 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1687 E)) (fmla_one _ _ (sat_1688 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1689 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1690 E)) (fmla_one _ _ (sat_1691 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1692 E)) (fmla_one _ _ (sat_1693 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1694 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1695 E)) (fmla_one _ _ (sat_1696 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1697 E)) (fmla_one _ _ (sat_1698 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1699 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1700 E)) (fmla_one _ _ (sat_1701 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1702 E)) (fmla_one _ _ (sat_1703 E))) (fmla_and _ _ _ (fmla_one _ _ h_1704) (fmla_and _ _ _ (fmla_one _ _ (sat_1705 E)) (fmla_one _ _ (sat_1706 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1707 E)) (fmla_one _ _ (sat_1708 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1709 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1710 E)) (fmla_one _ _ (sat_1711 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1712 E)) (fmla_one _ _ (sat_1713 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1714 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1715 E)) (fmla_one _ _ (sat_1716 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1717 E)) (fmla_one _ _ (sat_1718 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1719 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1720 E)) (fmla_one _ _ (sat_1721 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ h_1722) (fmla_one _ _ (sat_1723 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1724 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1725 E)) (fmla_one _ _ (sat_1726 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1727 E)) (fmla_one _ _ (sat_1728 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1729 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1730 E)) (fmla_one _ _ (sat_1731 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1732 E)) (fmla_one _ _ (sat_1733 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1734 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1735 E)) (fmla_one _ _ (sat_1736 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1737 E)) (fmla_one _ _ (sat_1738 E))) (fmla_and _ _ _ (fmla_one _ _ h_1739) (fmla_and _ _ _ (fmla_one _ _ (sat_1740 E)) (fmla_one _ _ (sat_1741 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1742 E)) (fmla_one _ _ (sat_1743 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1744 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1745 E)) (fmla_one _ _ (sat_1746 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1747 E)) (fmla_one _ _ (sat_1748 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1749 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1750 E)) (fmla_one _ _ (sat_1751 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1752 E)) (fmla_one _ _ (sat_1753 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1754 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1755 E)) (fmla_one _ _ (sat_1756 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ h_1757) (fmla_one _ _ (sat_1758 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1759 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1760 E)) (fmla_one _ _ (sat_1761 E)))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1762 E)) (fmla_one _ _ (sat_1763 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1764 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1765 E)) (fmla_one _ _ (sat_1766 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1767 E)) (fmla_one _ _ (sat_1768 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1769 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1770 E)) (fmla_one _ _ (sat_1771 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1772 E)) (fmla_one _ _ (sat_1773 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1774 E)) (fmla_and _ _ _ (fmla_one _ _ h_1775) (fmla_one _ _ (sat_1776 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1777 E)) (fmla_one _ _ (sat_1778 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1779 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1780 E)) (fmla_one _ _ (sat_1781 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1782 E)) (fmla_one _ _ (sat_1783 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1784 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1785 E)) (fmla_one _ _ (sat_1786 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1787 E)) (fmla_one _ _ (sat_1788 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1789 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1790 E)) (fmla_one _ _ (sat_1791 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1792 E)) (fmla_one _ _ (sat_1793 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1794 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1795 E)) (fmla_one _ _ (sat_1796 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ h_1797) (fmla_one _ _ (sat_1798 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1799 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1800 E)) (fmla_one _ _ (sat_1801 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1802 E)) (fmla_one _ _ (sat_1803 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1804 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1805 E)) (fmla_one _ _ (sat_1806 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1807 E)) (fmla_one _ _ (sat_1808 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1809 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1810 E)) (fmla_one _ _ (sat_1811 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1812 E)) (fmla_one _ _ (sat_1813 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1814 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1815 E)) (fmla_one _ _ (sat_1816 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1817 E)) (fmla_one _ _ (sat_1818 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1819 E)) (fmla_and _ _ _ (fmla_one _ _ h_1820) (fmla_one _ _ (sat_1821 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1822 E)) (fmla_one _ _ (sat_1823 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1824 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1825 E)) (fmla_one _ _ (sat_1826 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1827 E)) (fmla_one _ _ (sat_1828 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1829 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1830 E)) (fmla_one _ _ (sat_1831 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1832 E)) (fmla_one _ _ (sat_1833 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1834 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1835 E)) (fmla_one _ _ (sat_1836 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1837 E)) (fmla_one _ _ (sat_1838 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1839 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1840 E)) (fmla_one _ _ (sat_1841 E))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1842 E)) (fmla_one _ _ (sat_1843 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1844 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1845 E)) (fmla_one _ _ (sat_1846 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1847 E)) (fmla_one _ _ (sat_1848 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1849 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1850 E)) (fmla_one _ _ h_1851))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1852 E)) (fmla_one _ _ (sat_1853 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1854 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1855 E)) (fmla_one _ _ (sat_1856 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1857 E)) (fmla_one _ _ (sat_1858 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1859 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1860 E)) (fmla_one _ _ (sat_1861 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1862 E)) (fmla_one _ _ (sat_1863 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1864 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1865 E)) (fmla_one _ _ (sat_1866 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1867 E)) (fmla_one _ _ (sat_1868 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1869 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1870 E)) (fmla_one _ _ (sat_1871 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ h_1872) (fmla_one _ _ (sat_1873 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1874 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1875 E)) (fmla_one _ _ (sat_1876 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1877 E)) (fmla_one _ _ (sat_1878 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1879 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1880 E)) (fmla_one _ _ (sat_1881 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1882 E)) (fmla_one _ _ (sat_1883 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1884 E)) (fmla_and _ _ _ (fmla_one _ _ h_1885) (fmla_one _ _ (sat_1886 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1887 E)) (fmla_one _ _ (sat_1888 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1889 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1890 E)) (fmla_one _ _ (sat_1891 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1892 E)) (fmla_one _ _ (sat_1893 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1894 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1895 E)) (fmla_one _ _ (sat_1896 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1897 E)) (fmla_one _ _ (sat_1898 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1899 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1900 E)) (fmla_one _ _ h_1901)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1902 E)) (fmla_one _ _ (sat_1903 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1904 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1905 E)) (fmla_one _ _ (sat_1906 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1907 E)) (fmla_one _ _ (sat_1908 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1909 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1910 E)) (fmla_one _ _ (sat_1911 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ h_1912) (fmla_one _ _ (sat_1913 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1914 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1915 E)) (fmla_one _ _ (sat_1916 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1917 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1918 E)) (fmla_one _ _ (sat_1919 E)))) (fmla_and _ _ _ (fmla_one _ _ (sat_1920 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1921 E)) (fmla_one _ _ (sat_1922 E)))))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1923 E)) (fmla_one _ _ (sat_1924 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1925 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1926 E)) (fmla_one _ _ (sat_1927 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1928 E)) (fmla_one _ _ (sat_1929 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1930 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1931 E)) (fmla_one _ _ h_1932))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1933 E)) (fmla_one _ _ (sat_1934 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1935 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1936 E)) (fmla_one _ _ (sat_1937 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1938 E)) (fmla_one _ _ (sat_1939 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1940 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1941 E)) (fmla_one _ _ (sat_1942 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1943 E)) (fmla_one _ _ (sat_1944 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1945 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1946 E)) (fmla_one _ _ (sat_1947 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1948 E)) (fmla_one _ _ (sat_1949 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1950 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1951 E)) (fmla_one _ _ (sat_1952 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1953 E)) (fmla_one _ _ (sat_1954 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1955 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1956 E)) (fmla_one _ _ (sat_1957 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ h_1958) (fmla_one _ _ (sat_1959 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1960 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1961 E)) (fmla_one _ _ (sat_1962 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1963 E)) (fmla_one _ _ (sat_1964 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1965 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1966 E)) (fmla_one _ _ (sat_1967 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1968 E)) (fmla_one _ _ (sat_1969 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1970 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1971 E)) (fmla_one _ _ (sat_1972 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1973 E)) (fmla_one _ _ (sat_1974 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1975 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1976 E)) (fmla_one _ _ (sat_1977 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1978 E)) (fmla_one _ _ (sat_1979 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1980 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1981 E)) (fmla_one _ _ (sat_1982 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1983 E)) (fmla_one _ _ (sat_1984 E))) (fmla_and _ _ _ (fmla_one _ _ h_1985) (fmla_and _ _ _ (fmla_one _ _ (sat_1986 E)) (fmla_one _ _ (sat_1987 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1988 E)) (fmla_one _ _ (sat_1989 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1990 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1991 E)) (fmla_one _ _ (sat_1992 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1993 E)) (fmla_one _ _ (sat_1994 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1995 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1996 E)) (fmla_one _ _ (sat_1997 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ h_1998) (fmla_one _ _ (sat_1999 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2000 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2001 E)) (fmla_one _ _ (sat_2002 E))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2003 E)) (fmla_one _ _ (sat_2004 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2005 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2006 E)) (fmla_one _ _ (sat_2007 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2008 E)) (fmla_one _ _ (sat_2009 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2010 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2011 E)) (fmla_one _ _ (sat_2012 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2013 E)) (fmla_one _ _ (sat_2014 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2015 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2016 E)) (fmla_one _ _ (sat_2017 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2018 E)) (fmla_one _ _ (sat_2019 E))) (fmla_and _ _ _ (fmla_one _ _ h_2020) (fmla_and _ _ _ (fmla_one _ _ (sat_2021 E)) (fmla_one _ _ (sat_2022 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2023 E)) (fmla_one _ _ (sat_2024 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2025 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2026 E)) (fmla_one _ _ (sat_2027 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2028 E)) (fmla_one _ _ (sat_2029 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2030 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2031 E)) (fmla_one _ _ (sat_2032 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2033 E)) (fmla_one _ _ (sat_2034 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2035 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2036 E)) (fmla_one _ _ (sat_2037 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2038 E)) (fmla_one _ _ (sat_2039 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2040 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2041 E)) (fmla_one _ _ (sat_2042 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2043 E)) (fmla_one _ _ (sat_2044 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2045 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2046 E)) (fmla_one _ _ (sat_2047 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2048 E)) (fmla_one _ _ (sat_2049 E))) (fmla_and _ _ _ (fmla_one _ _ h_2050) (fmla_and _ _ _ (fmla_one _ _ (sat_2051 E)) (fmla_one _ _ (sat_2052 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2053 E)) (fmla_one _ _ (sat_2054 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2055 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2056 E)) (fmla_one _ _ (sat_2057 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2058 E)) (fmla_one _ _ (sat_2059 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2060 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2061 E)) (fmla_one _ _ (sat_2062 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2063 E)) (fmla_one _ _ (sat_2064 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2065 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2066 E)) (fmla_one _ _ (sat_2067 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2068 E)) (fmla_one _ _ (sat_2069 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2070 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2071 E)) (fmla_one _ _ (sat_2072 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2073 E)) (fmla_one _ _ (sat_2074 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2075 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2076 E)) (fmla_one _ _ (sat_2077 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2078 E)) (fmla_one _ _ (sat_2079 E))) (fmla_and _ _ _ (fmla_one _ _ h_2080) (fmla_and _ _ _ (fmla_one _ _ (sat_2081 E)) (fmla_one _ _ (sat_2082 E)))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2083 E)) (fmla_one _ _ (sat_2084 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2085 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2086 E)) (fmla_one _ _ (sat_2087 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2088 E)) (fmla_one _ _ (sat_2089 E))) (fmla_and _ _ _ (fmla_one _ _ h_2090) (fmla_and _ _ _ (fmla_one _ _ (sat_2091 E)) (fmla_one _ _ (sat_2092 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2093 E)) (fmla_one _ _ (sat_2094 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2095 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2096 E)) (fmla_one _ _ (sat_2097 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2098 E)) (fmla_one _ _ (sat_2099 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2100 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2101 E)) (fmla_one _ _ (sat_2102 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2103 E)) (fmla_one _ _ (sat_2104 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2105 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2106 E)) (fmla_one _ _ (sat_2107 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ h_2108) (fmla_one _ _ (sat_2109 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2110 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2111 E)) (fmla_one _ _ (sat_2112 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2113 E)) (fmla_one _ _ (sat_2114 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2115 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2116 E)) (fmla_one _ _ (sat_2117 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2118 E)) (fmla_one _ _ (sat_2119 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2120 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2121 E)) (fmla_one _ _ (sat_2122 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2123 E)) (fmla_one _ _ (sat_2124 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2125 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2126 E)) (fmla_one _ _ (sat_2127 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2128 E)) (fmla_one _ _ (sat_2129 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2130 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2131 E)) (fmla_one _ _ (sat_2132 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2133 E)) (fmla_one _ _ h_2134)) (fmla_and _ _ _ (fmla_one _ _ (sat_2135 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2136 E)) (fmla_one _ _ (sat_2137 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2138 E)) (fmla_one _ _ (sat_2139 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2140 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2141 E)) (fmla_one _ _ (sat_2142 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2143 E)) (fmla_one _ _ (sat_2144 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2145 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2146 E)) (fmla_one _ _ (sat_2147 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2148 E)) (fmla_one _ _ (sat_2149 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2150 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2151 E)) (fmla_one _ _ (sat_2152 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2153 E)) (fmla_one _ _ (sat_2154 E))) (fmla_and _ _ _ (fmla_one _ _ h_2155) (fmla_and _ _ _ (fmla_one _ _ (sat_2156 E)) (fmla_one _ _ (sat_2157 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2158 E)) (fmla_one _ _ (sat_2159 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2160 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2161 E)) (fmla_one _ _ (sat_2162 E))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2163 E)) (fmla_one _ _ h_2164)) (fmla_and _ _ _ (fmla_one _ _ (sat_2165 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2166 E)) (fmla_one _ _ (sat_2167 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2168 E)) (fmla_one _ _ (sat_2169 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2170 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2171 E)) (fmla_one _ _ (sat_2172 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2173 E)) (fmla_one _ _ (sat_2174 E))) (fmla_and _ _ _ (fmla_one _ _ h_2175) (fmla_and _ _ _ (fmla_one _ _ (sat_2176 E)) (fmla_one _ _ (sat_2177 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2178 E)) (fmla_one _ _ (sat_2179 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2180 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2181 E)) (fmla_one _ _ (sat_2182 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2183 E)) (fmla_one _ _ (sat_2184 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2185 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2186 E)) (fmla_one _ _ h_2187)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2188 E)) (fmla_one _ _ (sat_2189 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2190 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2191 E)) (fmla_one _ _ (sat_2192 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2193 E)) (fmla_one _ _ (sat_2194 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2195 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2196 E)) (fmla_one _ _ (sat_2197 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2198 E)) (fmla_one _ _ (sat_2199 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2200 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2201 E)) (fmla_one _ _ (sat_2202 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2203 E)) (fmla_one _ _ h_2204)) (fmla_and _ _ _ (fmla_one _ _ (sat_2205 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2206 E)) (fmla_one _ _ (sat_2207 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2208 E)) (fmla_one _ _ (sat_2209 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2210 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2211 E)) (fmla_one _ _ (sat_2212 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2213 E)) (fmla_one _ _ (sat_2214 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2215 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2216 E)) (fmla_one _ _ (sat_2217 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2218 E)) (fmla_one _ _ (sat_2219 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2220 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2221 E)) (fmla_one _ _ (sat_2222 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2223 E)) (fmla_one _ _ (sat_2224 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2225 E)) (fmla_and _ _ _ (fmla_one _ _ h_2226) (fmla_one _ _ (sat_2227 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2228 E)) (fmla_one _ _ (sat_2229 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2230 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2231 E)) (fmla_one _ _ (sat_2232 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2233 E)) (fmla_one _ _ (sat_2234 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2235 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2236 E)) (fmla_one _ _ (sat_2237 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2238 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2239 E)) (fmla_one _ _ (sat_2240 E)))) (fmla_and _ _ _ (fmla_one _ _ (sat_2241 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2242 E)) (fmla_one _ _ h_2243)))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2244 E)) (fmla_one _ _ (sat_2245 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2246 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2247 E)) (fmla_one _ _ (sat_2248 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2249 E)) (fmla_one _ _ (sat_2250 E))) (fmla_and _ _ _ (fmla_one _ _ h_2251) (fmla_and _ _ _ (fmla_one _ _ (sat_2252 E)) (fmla_one _ _ (sat_2253 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2254 E)) (fmla_one _ _ (sat_2255 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2256 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2257 E)) (fmla_one _ _ (sat_2258 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2259 E)) (fmla_one _ _ (sat_2260 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2261 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2262 E)) (fmla_one _ _ (sat_2263 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2264 E)) (fmla_one _ _ (sat_2265 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2266 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2267 E)) (fmla_one _ _ h_2268)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2269 E)) (fmla_one _ _ (sat_2270 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2271 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2272 E)) (fmla_one _ _ (sat_2273 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2274 E)) (fmla_one _ _ (sat_2275 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2276 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2277 E)) (fmla_one _ _ (sat_2278 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2279 E)) (fmla_one _ _ (sat_2280 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2281 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2282 E)) (fmla_one _ _ (sat_2283 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2284 E)) (fmla_one _ _ (sat_2285 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2286 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2287 E)) (fmla_one _ _ (sat_2288 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2289 E)) (fmla_one _ _ (sat_2290 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2291 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2292 E)) (fmla_one _ _ (sat_2293 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2294 E)) (fmla_one _ _ (sat_2295 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2296 E)) (fmla_and _ _ _ (fmla_one _ _ h_2297) (fmla_one _ _ (sat_2298 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2299 E)) (fmla_one _ _ (sat_2300 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2301 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2302 E)) (fmla_one _ _ (sat_2303 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2304 E)) (fmla_one _ _ (sat_2305 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2306 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2307 E)) (fmla_one _ _ (sat_2308 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2309 E)) (fmla_one _ _ (sat_2310 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2311 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2312 E)) (fmla_one _ _ (sat_2313 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2314 E)) (fmla_one _ _ (sat_2315 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2316 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2317 E)) (fmla_one _ _ (sat_2318 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2319 E)) (fmla_one _ _ (sat_2320 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2321 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2322 E)) (fmla_one _ _ (sat_2323 E))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2324 E)) (fmla_one _ _ (sat_2325 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2326 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2327 E)) (fmla_one _ _ (sat_2328 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2329 E)) (fmla_one _ _ (sat_2330 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2331 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2332 E)) (fmla_one _ _ h_2333))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2334 E)) (fmla_one _ _ (sat_2335 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2336 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2337 E)) (fmla_one _ _ (sat_2338 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2339 E)) (fmla_one _ _ (sat_2340 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2341 E)) (fmla_and _ _ _ (fmla_one _ _ h_2342) (fmla_one _ _ (sat_2343 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2344 E)) (fmla_one _ _ (sat_2345 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2346 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2347 E)) (fmla_one _ _ (sat_2348 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2349 E)) (fmla_one _ _ (sat_2350 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2351 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2352 E)) (fmla_one _ _ (sat_2353 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2354 E)) (fmla_one _ _ (sat_2355 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2356 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2357 E)) (fmla_one _ _ (sat_2358 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ h_2359) (fmla_one _ _ (sat_2360 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2361 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2362 E)) (fmla_one _ _ (sat_2363 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2364 E)) (fmla_one _ _ (sat_2365 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2366 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2367 E)) (fmla_one _ _ (sat_2368 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2369 E)) (fmla_one _ _ (sat_2370 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2371 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2372 E)) (fmla_one _ _ (sat_2373 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ h_2374) (fmla_one _ _ (sat_2375 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2376 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2377 E)) (fmla_one _ _ (sat_2378 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2379 E)) (fmla_one _ _ (sat_2380 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2381 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2382 E)) (fmla_one _ _ (sat_2383 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2384 E)) (fmla_one _ _ (sat_2385 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2386 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2387 E)) (fmla_one _ _ (sat_2388 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2389 E)) (fmla_one _ _ (sat_2390 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2391 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2392 E)) (fmla_one _ _ (sat_2393 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2394 E)) (fmla_one _ _ (sat_2395 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2396 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2397 E)) (fmla_one _ _ (sat_2398 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2399 E)) (fmla_one _ _ (sat_2400 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2401 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2402 E)) (fmla_one _ _ (sat_2403 E)))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2404 E)) (fmla_one _ _ (sat_2405 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2406 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2407 E)) (fmla_one _ _ (sat_2408 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2409 E)) (fmla_one _ _ (sat_2410 E))) (fmla_and _ _ _ (fmla_one _ _ h_2411) (fmla_and _ _ _ (fmla_one _ _ (sat_2412 E)) (fmla_one _ _ (sat_2413 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2414 E)) (fmla_one _ _ (sat_2415 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2416 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2417 E)) (fmla_one _ _ (sat_2418 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2419 E)) (fmla_one _ _ h_2420)) (fmla_and _ _ _ (fmla_one _ _ (sat_2421 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2422 E)) (fmla_one _ _ (sat_2423 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2424 E)) (fmla_one _ _ (sat_2425 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2426 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2427 E)) (fmla_one _ _ (sat_2428 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ h_2429) (fmla_one _ _ (sat_2430 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2431 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2432 E)) (fmla_one _ _ (sat_2433 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2434 E)) (fmla_one _ _ (sat_2435 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2436 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2437 E)) (fmla_one _ _ (sat_2438 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2439 E)) (fmla_one _ _ (sat_2440 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2441 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2442 E)) (fmla_one _ _ (sat_2443 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2444 E)) (fmla_one _ _ (sat_2445 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2446 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2447 E)) (fmla_one _ _ h_2448)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2449 E)) (fmla_one _ _ (sat_2450 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2451 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2452 E)) (fmla_one _ _ (sat_2453 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2454 E)) (fmla_one _ _ (sat_2455 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2456 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2457 E)) (fmla_one _ _ (sat_2458 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2459 E)) (fmla_one _ _ (sat_2460 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2461 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2462 E)) (fmla_one _ _ (sat_2463 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2464 E)) (fmla_one _ _ (sat_2465 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2466 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2467 E)) (fmla_one _ _ (sat_2468 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2469 E)) (fmla_one _ _ (sat_2470 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2471 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2472 E)) (fmla_one _ _ (sat_2473 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2474 E)) (fmla_one _ _ (sat_2475 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2476 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2477 E)) (fmla_one _ _ (sat_2478 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2479 E)) (fmla_one _ _ (sat_2480 E))) (fmla_and _ _ _ (fmla_one _ _ h_2481) (fmla_and _ _ _ (fmla_one _ _ (sat_2482 E)) (fmla_one _ _ (sat_2483 E))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2484 E)) (fmla_one _ _ (sat_2485 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2486 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2487 E)) (fmla_one _ _ (sat_2488 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2489 E)) (fmla_one _ _ (sat_2490 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2491 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2492 E)) (fmla_one _ _ (sat_2493 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2494 E)) (fmla_one _ _ (sat_2495 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2496 E)) (fmla_and _ _ _ (fmla_one _ _ h_2497) (fmla_one _ _ (sat_2498 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2499 E)) (fmla_one _ _ (sat_2500 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2501 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2502 E)) (fmla_one _ _ (sat_2503 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2504 E)) (fmla_one _ _ (sat_2505 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2506 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2507 E)) (fmla_one _ _ (sat_2508 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2509 E)) (fmla_one _ _ (sat_2510 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2511 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2512 E)) (fmla_one _ _ (sat_2513 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2514 E)) (fmla_one _ _ (sat_2515 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2516 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2517 E)) (fmla_one _ _ (sat_2518 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ h_2519) (fmla_one _ _ (sat_2520 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2521 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2522 E)) (fmla_one _ _ (sat_2523 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2524 E)) (fmla_one _ _ (sat_2525 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2526 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2527 E)) (fmla_one _ _ (sat_2528 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2529 E)) (fmla_one _ _ (sat_2530 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2531 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2532 E)) (fmla_one _ _ (sat_2533 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2534 E)) (fmla_one _ _ (sat_2535 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2536 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2537 E)) (fmla_one _ _ (sat_2538 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2539 E)) (fmla_one _ _ (sat_2540 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2541 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2542 E)) (fmla_one _ _ (sat_2543 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2544 E)) (fmla_one _ _ (sat_2545 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2546 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2547 E)) (fmla_one _ _ (sat_2548 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2549 E)) (fmla_one _ _ (sat_2550 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2551 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2552 E)) (fmla_one _ _ (sat_2553 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2554 E)) (fmla_one _ _ (sat_2555 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2556 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2557 E)) (fmla_one _ _ (sat_2558 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_2559 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2560 E)) (fmla_one _ _ (sat_2561 E)))) (fmla_and _ _ _ (fmla_one _ _ (sat_2562 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_2563 E)) (fmla_one _ _ h_2564)))))))))))))
#print axioms contradiction_of_semantic_roots
end Graffiti384b.DiversityEleven.PendantCircuit.K4
