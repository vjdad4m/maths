import DiversityElevenFourTagResidual384b
import DiversityElevenExactFourSelector384b
import DiversityElevenExactFiveSelector384b
import DiversityElevenExactSixSelector384b

namespace Graffiti384b.DiversityEleven
open Finset SimpleGraph

private theorem four_checked : EightSelectorAt 4 := by
  intro H dec Z d c m s
  letI := dec
  exact exact_four_selector H Z c d m s

private theorem five_checked : EightSelectorAt 5 := by
  intro H dec Z d c m s
  letI := dec
  exact exact_five_selector H Z c d m s

private theorem six_checked : EightSelectorAt 6 := by
  intro H dec Z d c m s
  letI := dec
  exact exact_six_selector H Z c d m s

variable {V : Type*} [Fintype V] [DecidableEq V]
  (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Closes all remaining dense pendant boards, with no finite
certificate hypothesis. -/
theorem exact_pendant_four_to_six_tags (sup : Supported G) (t : (types G).card=11)
    (nine : (high G).card=9) {e f a : V} (ah : a∈high G)
    (low : nonleaves G \ high G={e,f})
    (en : G.neighborFinset e={f,a}) (fn : G.neighborFinset f={e,a})
    (scores : Set.InjOn (trianglesAt G) (high G : Set V))
    (mins : ∀ v∈high G, 2≤trianglesAt G v)
    (dense : ∀ v∈(high G).erase a, 3≤nbr G v ((high G).erase a))
    (zmin : 4≤(((high G).erase a).filter (fun v => ¬G.Adj v a)).card)
    (zmax : (((high G).erase a).filter (fun v => ¬G.Adj v a)).card≤6) :
    gamma G≤bound G := by
  let z := (((high G).erase a).filter (fun v => ¬G.Adj v a)).card
  have he : z=4 ∨ z=5 ∨ z=6 := by
    change 4≤z at zmin
    change z≤6 at zmax
    omega
  rcases he with hf|hf|hf
  · exact exact_pendant_selector_at G four_checked sup t nine ah low en fn scores mins dense hf
  · exact exact_pendant_selector_at G five_checked sup t nine ah low en fn scores mins dense hf
  · exact exact_pendant_selector_at G six_checked sup t nine ah low en fn scores mins dense hf

/-- At diversity eleven, any possible failure is now concentrated on
a supported ten-nonisolated graph with exactly nine highs, with every
triangle count preserved. The pendant branch is gone. -/
theorem residual_eleven_exactly_ten (t : (types G).card=11) (bad : bound G<gamma G) :
    ∃ (J : SimpleGraph V) (dec : DecidableRel J.Adj),
      letI := dec
      J ≤ G ∧ Supported J ∧ (∀ v,trianglesAt J v=trianglesAt G v) ∧
        types J=types G ∧ bound J<gamma J ∧ (high J).card=9 ∧
        (nonleaves J).card=10 := by
  obtain ⟨J,dec,sub,sup,sc,tp,jbad,nine,rest⟩ := residual_eleven_ten_or_four_to_six_tags G t bad
  letI := dec
  have tj : (types J).card=11 := by rwa [tp]
  refine ⟨J,dec,sub,sup,sc,tp,jbad,nine,?_⟩
  rcases rest with q|⟨q,e,f,a,_,ah,low,en,fn,dense,zmin,zmax,_⟩
  · exact q
  rcases split_profile J sup tj jbad with ⟨qq,_⟩|⟨_,scores,mins,_⟩
  · omega
  · exact False.elim ((not_le_of_gt jbad)
      (exact_pendant_four_to_six_tags J sup tj nine ah low en fn scores mins dense zmin zmax))

#print axioms exact_pendant_four_to_six_tags
#print axioms residual_eleven_exactly_ten
end Graffiti384b.DiversityEleven
