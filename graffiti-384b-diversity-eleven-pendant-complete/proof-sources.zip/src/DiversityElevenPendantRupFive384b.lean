import DiversityElevenModularRup384b

namespace Graffiti384b.DiversityEleven
set_option maxRecDepth 32768
set_option maxHeartbeats 100000000

modular_rup pendant_five_rup
  (include_str "../q11-study/dp5_slice.cnf")
  (include_str "../q11-study/dp5_slice.lrat")

#print axioms pendant_five_rup
end Graffiti384b.DiversityEleven
