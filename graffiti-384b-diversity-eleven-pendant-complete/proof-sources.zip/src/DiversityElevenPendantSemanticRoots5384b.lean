import DiversityElevenPendantThresholds5384b
import DiversityElevenPendantWireClauses5384b
import Mathlib.Data.Finset.Card
import Mathlib.Tactic.FinCases
namespace Graffiti384b.DiversityEleven.PendantCircuit.K5
open Sat Finset
set_option maxRecDepth 32768
set_option maxHeartbeats 15000000
def edgeNumber (i j : Fin 8) : Nat :=
  let a := min i.val j.val
  let b := max i.val j.val
  2 + (a*(15-a))/2 + (b-a-1)
def edge (E : Nat→Bool) (i j : Fin 8) : Bool := if i=j then false else E (edgeNumber i j)
def portRank (E : Nat→Bool) (i : Fin 8) : Nat :=
  (if edge E 1 i then 1 else 0)+(if edge E 0 i then 2 else 0)
private theorem negWire (b : Bool) : ((!b)=true) ↔ ¬b=true := by cases b <;> decide
def HasTriple (E : Nat→Bool) : Prop :=
  ∃ a b c : Fin 8, a<b ∧ b<c ∧ ∀ v : Fin 8, v≠a → v≠b → v≠c →
    (if v.val < 5 then 2 else 1)≤countTrue [edge E v a,edge E v b,edge E v c]
private theorem root_32 (E : Nat→Bool) (h : 3≤degree0_count E) : (valuation E).satisfies [.neg 63] := by
  change ((g64 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree0_threshold7_2 E).mpr h) hn
private theorem root_74 (E : Nat→Bool) (h : 3≤degree1_count E) : (valuation E).satisfies [.neg 105] := by
  change ((g106 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree1_threshold7_2 E).mpr h) hn
private theorem root_106 (E : Nat→Bool) (h : 3≤degree2_count E) : (valuation E).satisfies [.neg 147] := by
  change ((g148 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree2_threshold7_2 E).mpr h) hn
private theorem root_138 (E : Nat→Bool) (h : 3≤degree3_count E) : (valuation E).satisfies [.neg 189] := by
  change ((g190 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree3_threshold7_2 E).mpr h) hn
private theorem root_151 (E : Nat→Bool) (h : 3≤degree4_count E) : (valuation E).satisfies [.neg 231] := by
  change ((g232 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree4_threshold7_2 E).mpr h) hn
private theorem root_184 (E : Nat→Bool) (h : 3≤degree5_count E) : (valuation E).satisfies [.neg 273] := by
  change ((g274 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree5_threshold7_2 E).mpr h) hn
private theorem root_217 (E : Nat→Bool) (h : 3≤degree6_count E) : (valuation E).satisfies [.neg 315] := by
  change ((g316 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree6_threshold7_2 E).mpr h) hn
private theorem root_247 (E : Nat→Bool) (h : 3≤degree7_count E) : (valuation E).satisfies [.neg 357] := by
  change ((g358 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree7_threshold7_2 E).mpr h) hn
private theorem root_2506 (E : Nat→Bool) (h : 2≤score0_count E) : (valuation E).satisfies [.neg 803] := by
  change ((g804 E)=true) → False
  intro hn
  exact (negWire _).mp ((score0_threshold21_1 E).mpr h) hn
private theorem root_2507 (E : Nat→Bool) (h : 2≤score1_count E) : (valuation E).satisfies [.neg 1223] := by
  change ((g1224 E)=true) → False
  intro hn
  exact (negWire _).mp ((score1_threshold21_1 E).mpr h) hn
private theorem root_2508 (E : Nat→Bool) (h : 2≤score2_count E) : (valuation E).satisfies [.neg 1643] := by
  change ((g1644 E)=true) → False
  intro hn
  exact (negWire _).mp ((score2_threshold21_1 E).mpr h) hn
private theorem root_2509 (E : Nat→Bool) (h : score0_count E<score1_count E) : (valuation E).satisfies [.neg 1225, .pos 803] := by
  change ((g1226 E)=true) → (¬ ((g804 E)=true)) → False
  intro fail old
  have oldScore := (score0_threshold21_1 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 1 h oldScore
  exact (negWire _).mp ((score1_threshold21_2 E).mpr newScore) fail
private theorem root_2510 (E : Nat→Bool) (h : score0_count E<score1_count E) : (valuation E).satisfies [.neg 1227, .pos 805] := by
  change ((g1228 E)=true) → (¬ ((g806 E)=true)) → False
  intro fail old
  have oldScore := (score0_threshold21_2 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 2 h oldScore
  exact (negWire _).mp ((score1_threshold21_3 E).mpr newScore) fail
private theorem root_2511 (E : Nat→Bool) (h : score0_count E<score1_count E) : (valuation E).satisfies [.neg 1229, .pos 807] := by
  change ((g1230 E)=true) → (¬ ((g808 E)=true)) → False
  intro fail old
  have oldScore := (score0_threshold21_3 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 3 h oldScore
  exact (negWire _).mp ((score1_threshold21_4 E).mpr newScore) fail
private theorem root_2512 (E : Nat→Bool) (h : score0_count E<score1_count E) : (valuation E).satisfies [.neg 1231, .pos 809] := by
  change ((g1232 E)=true) → (¬ ((g810 E)=true)) → False
  intro fail old
  have oldScore := (score0_threshold21_4 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 4 h oldScore
  exact (negWire _).mp ((score1_threshold21_5 E).mpr newScore) fail
private theorem root_2513 (E : Nat→Bool) (h : score1_count E<score2_count E) : (valuation E).satisfies [.neg 1645, .pos 1223] := by
  change ((g1646 E)=true) → (¬ ((g1224 E)=true)) → False
  intro fail old
  have oldScore := (score1_threshold21_1 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 1 h oldScore
  exact (negWire _).mp ((score2_threshold21_2 E).mpr newScore) fail
private theorem root_2514 (E : Nat→Bool) (h : score1_count E<score2_count E) : (valuation E).satisfies [.neg 1647, .pos 1225] := by
  change ((g1648 E)=true) → (¬ ((g1226 E)=true)) → False
  intro fail old
  have oldScore := (score1_threshold21_2 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 2 h oldScore
  exact (negWire _).mp ((score2_threshold21_3 E).mpr newScore) fail
private theorem root_2515 (E : Nat→Bool) (h : score1_count E<score2_count E) : (valuation E).satisfies [.neg 1649, .pos 1227] := by
  change ((g1650 E)=true) → (¬ ((g1228 E)=true)) → False
  intro fail old
  have oldScore := (score1_threshold21_3 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 3 h oldScore
  exact (negWire _).mp ((score2_threshold21_4 E).mpr newScore) fail
private theorem root_2516 (E : Nat→Bool) (h : score1_count E<score2_count E) : (valuation E).satisfies [.neg 1651, .pos 1229] := by
  change ((g1652 E)=true) → (¬ ((g1230 E)=true)) → False
  intro fail old
  have oldScore := (score1_threshold21_4 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 4 h oldScore
  exact (negWire _).mp ((score2_threshold21_5 E).mpr newScore) fail
private theorem root_2517 (E : Nat→Bool) (h : score1_count E<score2_count E) : (valuation E).satisfies [.neg 1653, .pos 1231] := by
  change ((g1654 E)=true) → (¬ ((g1232 E)=true)) → False
  intro fail old
  have oldScore := (score1_threshold21_5 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 5 h oldScore
  exact (negWire _).mp ((score2_threshold21_6 E).mpr newScore) fail
private theorem root_2518 (E : Nat→Bool) (h : score2_count E<score3_count E) : (valuation E).satisfies [.neg 2065, .pos 1643] := by
  change ((g2066 E)=true) → (¬ ((g1644 E)=true)) → False
  intro fail old
  have oldScore := (score2_threshold21_1 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 1 h oldScore
  exact (negWire _).mp ((score3_threshold21_2 E).mpr newScore) fail
private theorem root_2519 (E : Nat→Bool) (h : score2_count E<score3_count E) : (valuation E).satisfies [.neg 2067, .pos 1645] := by
  change ((g2068 E)=true) → (¬ ((g1646 E)=true)) → False
  intro fail old
  have oldScore := (score2_threshold21_2 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 2 h oldScore
  exact (negWire _).mp ((score3_threshold21_3 E).mpr newScore) fail
private theorem root_2520 (E : Nat→Bool) (h : score2_count E<score3_count E) : (valuation E).satisfies [.neg 2069, .pos 1647] := by
  change ((g2070 E)=true) → (¬ ((g1648 E)=true)) → False
  intro fail old
  have oldScore := (score2_threshold21_3 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 3 h oldScore
  exact (negWire _).mp ((score3_threshold21_4 E).mpr newScore) fail
private theorem root_2521 (E : Nat→Bool) (h : score2_count E<score3_count E) : (valuation E).satisfies [.neg 2071, .pos 1649] := by
  change ((g2072 E)=true) → (¬ ((g1650 E)=true)) → False
  intro fail old
  have oldScore := (score2_threshold21_4 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 4 h oldScore
  exact (negWire _).mp ((score3_threshold21_5 E).mpr newScore) fail
private theorem root_2522 (E : Nat→Bool) (h : score2_count E<score3_count E) : (valuation E).satisfies [.neg 2073, .pos 1651] := by
  change ((g2074 E)=true) → (¬ ((g1652 E)=true)) → False
  intro fail old
  have oldScore := (score2_threshold21_5 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 5 h oldScore
  exact (negWire _).mp ((score3_threshold21_6 E).mpr newScore) fail
private theorem root_2523 (E : Nat→Bool) (h : score2_count E<score3_count E) : (valuation E).satisfies [.neg 2075, .pos 1653] := by
  change ((g2076 E)=true) → (¬ ((g1654 E)=true)) → False
  intro fail old
  have oldScore := (score2_threshold21_6 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 6 h oldScore
  exact (negWire _).mp ((score3_threshold21_7 E).mpr newScore) fail
private theorem root_2524 (E : Nat→Bool) (h : score3_count E<score4_count E) : (valuation E).satisfies [.neg 2489, .pos 2067] := by
  change ((g2490 E)=true) → (¬ ((g2068 E)=true)) → False
  intro fail old
  have oldScore := (score3_threshold21_3 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 3 h oldScore
  exact (negWire _).mp ((score4_threshold21_4 E).mpr newScore) fail
private theorem root_2525 (E : Nat→Bool) (h : score3_count E<score4_count E) : (valuation E).satisfies [.neg 2491, .pos 2069] := by
  change ((g2492 E)=true) → (¬ ((g2070 E)=true)) → False
  intro fail old
  have oldScore := (score3_threshold21_4 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 4 h oldScore
  exact (negWire _).mp ((score4_threshold21_5 E).mpr newScore) fail
private theorem root_2526 (E : Nat→Bool) (h : score3_count E<score4_count E) : (valuation E).satisfies [.neg 2493, .pos 2071] := by
  change ((g2494 E)=true) → (¬ ((g2072 E)=true)) → False
  intro fail old
  have oldScore := (score3_threshold21_5 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 5 h oldScore
  exact (negWire _).mp ((score4_threshold21_6 E).mpr newScore) fail
private theorem root_2527 (E : Nat→Bool) (h : score3_count E<score4_count E) : (valuation E).satisfies [.neg 2495, .pos 2073] := by
  change ((g2496 E)=true) → (¬ ((g2074 E)=true)) → False
  intro fail old
  have oldScore := (score3_threshold21_6 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 6 h oldScore
  exact (negWire _).mp ((score4_threshold21_7 E).mpr newScore) fail
private theorem root_2528 (E : Nat→Bool) (h : score3_count E<score4_count E) : (valuation E).satisfies [.neg 2497, .pos 2075] := by
  change ((g2498 E)=true) → (¬ ((g2076 E)=true)) → False
  intro fail old
  have oldScore := (score3_threshold21_7 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 7 h oldScore
  exact (negWire _).mp ((score4_threshold21_8 E).mpr newScore) fail
private theorem root_2529 (E : Nat→Bool) (h : score3_count E<score4_count E) : (valuation E).satisfies [.neg 2499, .pos 2077] := by
  change ((g2500 E)=true) → (¬ ((g2078 E)=true)) → False
  intro fail old
  have oldScore := (score3_threshold21_8 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 8 h oldScore
  exact (negWire _).mp ((score4_threshold21_9 E).mpr newScore) fail
private theorem root_2540 (E : Nat→Bool) (h : portRank E 5≤portRank E 6) : (valuation E).satisfies [.pos 2526] := by
  change (¬ ((g2527 E)=true)) → False
  intro contrary
  change (if (g12 E) then 1 else 0) + (if (g6 E) then 2 else 0) ≤ (if (g13 E) then 1 else 0) + (if (g7 E) then 2 else 0) at h
  cases q12 : g12 E <;> cases q6 : g6 E <;> cases q13 : g13 E <;> cases q7 : g7 E <;> simp [g2522,g2523,g2524,g2525,g2526,g2527,q12,q6,q13,q7] at h contrary
private theorem root_2550 (E : Nat→Bool) (h : portRank E 6≤portRank E 7) : (valuation E).satisfies [.pos 2532] := by
  change (¬ ((g2533 E)=true)) → False
  intro contrary
  change (if (g13 E) then 1 else 0) + (if (g7 E) then 2 else 0) ≤ (if (g14 E) then 1 else 0) + (if (g8 E) then 2 else 0) at h
  cases q13 : g13 E <;> cases q7 : g7 E <;> cases q14 : g14 E <;> cases q8 : g8 E <;> simp [g2528,g2529,g2530,g2531,g2532,g2533,q13,q7,q14,q8] at h contrary
private theorem root_2576 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2536, .pos 2540, .pos 2541, .pos 2542, .pos 2543] := by
  change (¬ ((g2537 E)=true)) → (¬ ((g2541 E)=true)) → (¬ ((g2542 E)=true)) → (¬ ((g2543 E)=true)) → (¬ ((g2544 E)=true)) → False
  intro c3 c4 c5 c6 c7
  apply h
  refine ⟨0,1,2,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 2≤countTrue [edge E 3 0, edge E 3 1, edge E 3 2]
    apply (mask_ge_two (edge E 3 0) (edge E 3 1) (edge E 3 2)).mp
    change (((g4 E) && (g10 E)) || ((g4 E) && (g15 E)) || ((g10 E) && (g15 E)))=true
    simpa [g2534, g2535, g2536, g2537, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 0, edge E 4 1, edge E 4 2]
    apply (mask_ge_two (edge E 4 0) (edge E 4 1) (edge E 4 2)).mp
    change (((g5 E) && (g11 E)) || ((g5 E) && (g16 E)) || ((g11 E) && (g16 E)))=true
    simpa [g2538, g2539, g2540, g2541, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 1, edge E 5 2]
    apply (mask_ge_one (edge E 5 0) (edge E 5 1) (edge E 5 2)).mp
    change ((g6 E) || (g12 E) || (g17 E))=true
    simpa [g2542, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 1, edge E 6 2]
    apply (mask_ge_one (edge E 6 0) (edge E 6 1) (edge E 6 2)).mp
    change ((g7 E) || (g13 E) || (g18 E))=true
    simpa [g2543, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 1, edge E 7 2]
    apply (mask_ge_one (edge E 7 0) (edge E 7 1) (edge E 7 2)).mp
    change ((g8 E) || (g14 E) || (g19 E))=true
    simpa [g2544, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2599 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2547, .pos 2551, .pos 2552, .pos 2553, .pos 2554] := by
  change (¬ ((g2548 E)=true)) → (¬ ((g2552 E)=true)) → (¬ ((g2553 E)=true)) → (¬ ((g2554 E)=true)) → (¬ ((g2555 E)=true)) → False
  intro c2 c4 c5 c6 c7
  apply h
  refine ⟨0,1,3,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 2 0, edge E 2 1, edge E 2 3]
    apply (mask_ge_two (edge E 2 0) (edge E 2 1) (edge E 2 3)).mp
    change (((g3 E) && (g9 E)) || ((g3 E) && (g15 E)) || ((g9 E) && (g15 E)))=true
    simpa [g2545, g2546, g2547, g2548, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vc rfl).elim
  · change 2≤countTrue [edge E 4 0, edge E 4 1, edge E 4 3]
    apply (mask_ge_two (edge E 4 0) (edge E 4 1) (edge E 4 3)).mp
    change (((g5 E) && (g11 E)) || ((g5 E) && (g20 E)) || ((g11 E) && (g20 E)))=true
    simpa [g2549, g2550, g2551, g2552, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 1, edge E 5 3]
    apply (mask_ge_one (edge E 5 0) (edge E 5 1) (edge E 5 3)).mp
    change ((g6 E) || (g12 E) || (g21 E))=true
    simpa [g2553, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 1, edge E 6 3]
    apply (mask_ge_one (edge E 6 0) (edge E 6 1) (edge E 6 3)).mp
    change ((g7 E) || (g13 E) || (g22 E))=true
    simpa [g2554, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 1, edge E 7 3]
    apply (mask_ge_one (edge E 7 0) (edge E 7 1) (edge E 7 3)).mp
    change ((g8 E) || (g14 E) || (g23 E))=true
    simpa [g2555, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2631 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2558, .pos 2562, .pos 2563, .pos 2564, .pos 2565] := by
  change (¬ ((g2559 E)=true)) → (¬ ((g2563 E)=true)) → (¬ ((g2564 E)=true)) → (¬ ((g2565 E)=true)) → (¬ ((g2566 E)=true)) → False
  intro c2 c3 c5 c6 c7
  apply h
  refine ⟨0,1,4,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 2 0, edge E 2 1, edge E 2 4]
    apply (mask_ge_two (edge E 2 0) (edge E 2 1) (edge E 2 4)).mp
    change (((g3 E) && (g9 E)) || ((g3 E) && (g16 E)) || ((g9 E) && (g16 E)))=true
    simpa [g2556, g2557, g2558, g2559, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 1, edge E 3 4]
    apply (mask_ge_two (edge E 3 0) (edge E 3 1) (edge E 3 4)).mp
    change (((g4 E) && (g10 E)) || ((g4 E) && (g20 E)) || ((g10 E) && (g20 E)))=true
    simpa [g2560, g2561, g2562, g2563, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 5 0, edge E 5 1, edge E 5 4]
    apply (mask_ge_one (edge E 5 0) (edge E 5 1) (edge E 5 4)).mp
    change ((g6 E) || (g12 E) || (g24 E))=true
    simpa [g2564, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 1, edge E 6 4]
    apply (mask_ge_one (edge E 6 0) (edge E 6 1) (edge E 6 4)).mp
    change ((g7 E) || (g13 E) || (g25 E))=true
    simpa [g2565, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 1, edge E 7 4]
    apply (mask_ge_one (edge E 7 0) (edge E 7 1) (edge E 7 4)).mp
    change ((g8 E) || (g14 E) || (g26 E))=true
    simpa [g2566, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2652 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2569, .pos 2573, .pos 2577, .pos 2578, .pos 2579] := by
  change (¬ ((g2570 E)=true)) → (¬ ((g2574 E)=true)) → (¬ ((g2578 E)=true)) → (¬ ((g2579 E)=true)) → (¬ ((g2580 E)=true)) → False
  intro c2 c3 c4 c6 c7
  apply h
  refine ⟨0,1,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 2 0, edge E 2 1, edge E 2 5]
    apply (mask_ge_two (edge E 2 0) (edge E 2 1) (edge E 2 5)).mp
    change (((g3 E) && (g9 E)) || ((g3 E) && (g17 E)) || ((g9 E) && (g17 E)))=true
    simpa [g2567, g2568, g2569, g2570, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 1, edge E 3 5]
    apply (mask_ge_two (edge E 3 0) (edge E 3 1) (edge E 3 5)).mp
    change (((g4 E) && (g10 E)) || ((g4 E) && (g21 E)) || ((g10 E) && (g21 E)))=true
    simpa [g2571, g2572, g2573, g2574, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 0, edge E 4 1, edge E 4 5]
    apply (mask_ge_two (edge E 4 0) (edge E 4 1) (edge E 4 5)).mp
    change (((g5 E) && (g11 E)) || ((g5 E) && (g24 E)) || ((g11 E) && (g24 E)))=true
    simpa [g2575, g2576, g2577, g2578, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 0, edge E 6 1, edge E 6 5]
    apply (mask_ge_one (edge E 6 0) (edge E 6 1) (edge E 6 5)).mp
    change ((g7 E) || (g13 E) || (g27 E))=true
    simpa [g2579, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 1, edge E 7 5]
    apply (mask_ge_one (edge E 7 0) (edge E 7 1) (edge E 7 5)).mp
    change ((g8 E) || (g14 E) || (g28 E))=true
    simpa [g2580, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2667 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2583, .pos 2587, .pos 2591, .pos 2592, .pos 2593] := by
  change (¬ ((g2584 E)=true)) → (¬ ((g2588 E)=true)) → (¬ ((g2592 E)=true)) → (¬ ((g2593 E)=true)) → (¬ ((g2594 E)=true)) → False
  intro c2 c3 c4 c5 c7
  apply h
  refine ⟨0,1,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 2 0, edge E 2 1, edge E 2 6]
    apply (mask_ge_two (edge E 2 0) (edge E 2 1) (edge E 2 6)).mp
    change (((g3 E) && (g9 E)) || ((g3 E) && (g18 E)) || ((g9 E) && (g18 E)))=true
    simpa [g2581, g2582, g2583, g2584, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 1, edge E 3 6]
    apply (mask_ge_two (edge E 3 0) (edge E 3 1) (edge E 3 6)).mp
    change (((g4 E) && (g10 E)) || ((g4 E) && (g22 E)) || ((g10 E) && (g22 E)))=true
    simpa [g2585, g2586, g2587, g2588, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 0, edge E 4 1, edge E 4 6]
    apply (mask_ge_two (edge E 4 0) (edge E 4 1) (edge E 4 6)).mp
    change (((g5 E) && (g11 E)) || ((g5 E) && (g25 E)) || ((g11 E) && (g25 E)))=true
    simpa [g2589, g2590, g2591, g2592, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 1, edge E 5 6]
    apply (mask_ge_one (edge E 5 0) (edge E 5 1) (edge E 5 6)).mp
    change ((g6 E) || (g12 E) || (g27 E))=true
    simpa [g2593, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 0, edge E 7 1, edge E 7 6]
    apply (mask_ge_one (edge E 7 0) (edge E 7 1) (edge E 7 6)).mp
    change ((g8 E) || (g14 E) || (g29 E))=true
    simpa [g2594, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2689 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2597, .pos 2601, .pos 2605, .pos 2606, .pos 2607] := by
  change (¬ ((g2598 E)=true)) → (¬ ((g2602 E)=true)) → (¬ ((g2606 E)=true)) → (¬ ((g2607 E)=true)) → (¬ ((g2608 E)=true)) → False
  intro c2 c3 c4 c5 c6
  apply h
  refine ⟨0,1,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 2 0, edge E 2 1, edge E 2 7]
    apply (mask_ge_two (edge E 2 0) (edge E 2 1) (edge E 2 7)).mp
    change (((g3 E) && (g9 E)) || ((g3 E) && (g19 E)) || ((g9 E) && (g19 E)))=true
    simpa [g2595, g2596, g2597, g2598, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 1, edge E 3 7]
    apply (mask_ge_two (edge E 3 0) (edge E 3 1) (edge E 3 7)).mp
    change (((g4 E) && (g10 E)) || ((g4 E) && (g23 E)) || ((g10 E) && (g23 E)))=true
    simpa [g2599, g2600, g2601, g2602, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 0, edge E 4 1, edge E 4 7]
    apply (mask_ge_two (edge E 4 0) (edge E 4 1) (edge E 4 7)).mp
    change (((g5 E) && (g11 E)) || ((g5 E) && (g26 E)) || ((g11 E) && (g26 E)))=true
    simpa [g2603, g2604, g2605, g2606, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 1, edge E 5 7]
    apply (mask_ge_one (edge E 5 0) (edge E 5 1) (edge E 5 7)).mp
    change ((g6 E) || (g12 E) || (g28 E))=true
    simpa [g2607, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 1, edge E 6 7]
    apply (mask_ge_one (edge E 6 0) (edge E 6 1) (edge E 6 7)).mp
    change ((g7 E) || (g13 E) || (g29 E))=true
    simpa [g2608, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_2721 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2611, .pos 2615, .pos 2616, .pos 2617, .pos 2618] := by
  change (¬ ((g2612 E)=true)) → (¬ ((g2616 E)=true)) → (¬ ((g2617 E)=true)) → (¬ ((g2618 E)=true)) → (¬ ((g2619 E)=true)) → False
  intro c1 c4 c5 c6 c7
  apply h
  refine ⟨0,2,3,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 2, edge E 1 3]
    apply (mask_ge_two (edge E 1 0) (edge E 1 2) (edge E 1 3)).mp
    change (((g2 E) && (g9 E)) || ((g2 E) && (g10 E)) || ((g9 E) && (g10 E)))=true
    simpa [g2609, g2610, g2611, g2612, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 2≤countTrue [edge E 4 0, edge E 4 2, edge E 4 3]
    apply (mask_ge_two (edge E 4 0) (edge E 4 2) (edge E 4 3)).mp
    change (((g5 E) && (g16 E)) || ((g5 E) && (g20 E)) || ((g16 E) && (g20 E)))=true
    simpa [g2613, g2614, g2615, g2616, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 2, edge E 5 3]
    apply (mask_ge_one (edge E 5 0) (edge E 5 2) (edge E 5 3)).mp
    change ((g6 E) || (g17 E) || (g21 E))=true
    simpa [g2617, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 2, edge E 6 3]
    apply (mask_ge_one (edge E 6 0) (edge E 6 2) (edge E 6 3)).mp
    change ((g7 E) || (g18 E) || (g22 E))=true
    simpa [g2618, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 2, edge E 7 3]
    apply (mask_ge_one (edge E 7 0) (edge E 7 2) (edge E 7 3)).mp
    change ((g8 E) || (g19 E) || (g23 E))=true
    simpa [g2619, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2746 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2622, .pos 2626, .pos 2627, .pos 2628, .pos 2629] := by
  change (¬ ((g2623 E)=true)) → (¬ ((g2627 E)=true)) → (¬ ((g2628 E)=true)) → (¬ ((g2629 E)=true)) → (¬ ((g2630 E)=true)) → False
  intro c1 c3 c5 c6 c7
  apply h
  refine ⟨0,2,4,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 2, edge E 1 4]
    apply (mask_ge_two (edge E 1 0) (edge E 1 2) (edge E 1 4)).mp
    change (((g2 E) && (g9 E)) || ((g2 E) && (g11 E)) || ((g9 E) && (g11 E)))=true
    simpa [g2620, g2621, g2622, g2623, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 3 0, edge E 3 2, edge E 3 4]
    apply (mask_ge_two (edge E 3 0) (edge E 3 2) (edge E 3 4)).mp
    change (((g4 E) && (g15 E)) || ((g4 E) && (g20 E)) || ((g15 E) && (g20 E)))=true
    simpa [g2624, g2625, g2626, g2627, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 5 0, edge E 5 2, edge E 5 4]
    apply (mask_ge_one (edge E 5 0) (edge E 5 2) (edge E 5 4)).mp
    change ((g6 E) || (g17 E) || (g24 E))=true
    simpa [g2628, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 2, edge E 6 4]
    apply (mask_ge_one (edge E 6 0) (edge E 6 2) (edge E 6 4)).mp
    change ((g7 E) || (g18 E) || (g25 E))=true
    simpa [g2629, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 2, edge E 7 4]
    apply (mask_ge_one (edge E 7 0) (edge E 7 2) (edge E 7 4)).mp
    change ((g8 E) || (g19 E) || (g26 E))=true
    simpa [g2630, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2764 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2633, .pos 2637, .pos 2641, .pos 2642, .pos 2643] := by
  change (¬ ((g2634 E)=true)) → (¬ ((g2638 E)=true)) → (¬ ((g2642 E)=true)) → (¬ ((g2643 E)=true)) → (¬ ((g2644 E)=true)) → False
  intro c1 c3 c4 c6 c7
  apply h
  refine ⟨0,2,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 2, edge E 1 5]
    apply (mask_ge_two (edge E 1 0) (edge E 1 2) (edge E 1 5)).mp
    change (((g2 E) && (g9 E)) || ((g2 E) && (g12 E)) || ((g9 E) && (g12 E)))=true
    simpa [g2631, g2632, g2633, g2634, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 3 0, edge E 3 2, edge E 3 5]
    apply (mask_ge_two (edge E 3 0) (edge E 3 2) (edge E 3 5)).mp
    change (((g4 E) && (g15 E)) || ((g4 E) && (g21 E)) || ((g15 E) && (g21 E)))=true
    simpa [g2635, g2636, g2637, g2638, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 0, edge E 4 2, edge E 4 5]
    apply (mask_ge_two (edge E 4 0) (edge E 4 2) (edge E 4 5)).mp
    change (((g5 E) && (g16 E)) || ((g5 E) && (g24 E)) || ((g16 E) && (g24 E)))=true
    simpa [g2639, g2640, g2641, g2642, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 0, edge E 6 2, edge E 6 5]
    apply (mask_ge_one (edge E 6 0) (edge E 6 2) (edge E 6 5)).mp
    change ((g7 E) || (g18 E) || (g27 E))=true
    simpa [g2643, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 2, edge E 7 5]
    apply (mask_ge_one (edge E 7 0) (edge E 7 2) (edge E 7 5)).mp
    change ((g8 E) || (g19 E) || (g28 E))=true
    simpa [g2644, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2788 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2647, .pos 2651, .pos 2655, .pos 2656, .pos 2657] := by
  change (¬ ((g2648 E)=true)) → (¬ ((g2652 E)=true)) → (¬ ((g2656 E)=true)) → (¬ ((g2657 E)=true)) → (¬ ((g2658 E)=true)) → False
  intro c1 c3 c4 c5 c7
  apply h
  refine ⟨0,2,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 2, edge E 1 6]
    apply (mask_ge_two (edge E 1 0) (edge E 1 2) (edge E 1 6)).mp
    change (((g2 E) && (g9 E)) || ((g2 E) && (g13 E)) || ((g9 E) && (g13 E)))=true
    simpa [g2645, g2646, g2647, g2648, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 3 0, edge E 3 2, edge E 3 6]
    apply (mask_ge_two (edge E 3 0) (edge E 3 2) (edge E 3 6)).mp
    change (((g4 E) && (g15 E)) || ((g4 E) && (g22 E)) || ((g15 E) && (g22 E)))=true
    simpa [g2649, g2650, g2651, g2652, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 0, edge E 4 2, edge E 4 6]
    apply (mask_ge_two (edge E 4 0) (edge E 4 2) (edge E 4 6)).mp
    change (((g5 E) && (g16 E)) || ((g5 E) && (g25 E)) || ((g16 E) && (g25 E)))=true
    simpa [g2653, g2654, g2655, g2656, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 2, edge E 5 6]
    apply (mask_ge_one (edge E 5 0) (edge E 5 2) (edge E 5 6)).mp
    change ((g6 E) || (g17 E) || (g27 E))=true
    simpa [g2657, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 0, edge E 7 2, edge E 7 6]
    apply (mask_ge_one (edge E 7 0) (edge E 7 2) (edge E 7 6)).mp
    change ((g8 E) || (g19 E) || (g29 E))=true
    simpa [g2658, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2817 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2661, .pos 2665, .pos 2669, .pos 2670, .pos 2671] := by
  change (¬ ((g2662 E)=true)) → (¬ ((g2666 E)=true)) → (¬ ((g2670 E)=true)) → (¬ ((g2671 E)=true)) → (¬ ((g2672 E)=true)) → False
  intro c1 c3 c4 c5 c6
  apply h
  refine ⟨0,2,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 2, edge E 1 7]
    apply (mask_ge_two (edge E 1 0) (edge E 1 2) (edge E 1 7)).mp
    change (((g2 E) && (g9 E)) || ((g2 E) && (g14 E)) || ((g9 E) && (g14 E)))=true
    simpa [g2659, g2660, g2661, g2662, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 3 0, edge E 3 2, edge E 3 7]
    apply (mask_ge_two (edge E 3 0) (edge E 3 2) (edge E 3 7)).mp
    change (((g4 E) && (g15 E)) || ((g4 E) && (g23 E)) || ((g15 E) && (g23 E)))=true
    simpa [g2663, g2664, g2665, g2666, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 0, edge E 4 2, edge E 4 7]
    apply (mask_ge_two (edge E 4 0) (edge E 4 2) (edge E 4 7)).mp
    change (((g5 E) && (g16 E)) || ((g5 E) && (g26 E)) || ((g16 E) && (g26 E)))=true
    simpa [g2667, g2668, g2669, g2670, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 2, edge E 5 7]
    apply (mask_ge_one (edge E 5 0) (edge E 5 2) (edge E 5 7)).mp
    change ((g6 E) || (g17 E) || (g28 E))=true
    simpa [g2671, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 2, edge E 6 7]
    apply (mask_ge_one (edge E 6 0) (edge E 6 2) (edge E 6 7)).mp
    change ((g7 E) || (g18 E) || (g29 E))=true
    simpa [g2672, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_2841 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2675, .pos 2679, .pos 2680, .pos 2681, .pos 2682] := by
  change (¬ ((g2676 E)=true)) → (¬ ((g2680 E)=true)) → (¬ ((g2681 E)=true)) → (¬ ((g2682 E)=true)) → (¬ ((g2683 E)=true)) → False
  intro c1 c2 c5 c6 c7
  apply h
  refine ⟨0,3,4,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 3, edge E 1 4]
    apply (mask_ge_two (edge E 1 0) (edge E 1 3) (edge E 1 4)).mp
    change (((g2 E) && (g10 E)) || ((g2 E) && (g11 E)) || ((g10 E) && (g11 E)))=true
    simpa [g2673, g2674, g2675, g2676, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 3, edge E 2 4]
    apply (mask_ge_two (edge E 2 0) (edge E 2 3) (edge E 2 4)).mp
    change (((g3 E) && (g15 E)) || ((g3 E) && (g16 E)) || ((g15 E) && (g16 E)))=true
    simpa [g2677, g2678, g2679, g2680, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 5 0, edge E 5 3, edge E 5 4]
    apply (mask_ge_one (edge E 5 0) (edge E 5 3) (edge E 5 4)).mp
    change ((g6 E) || (g21 E) || (g24 E))=true
    simpa [g2681, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 3, edge E 6 4]
    apply (mask_ge_one (edge E 6 0) (edge E 6 3) (edge E 6 4)).mp
    change ((g7 E) || (g22 E) || (g25 E))=true
    simpa [g2682, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 3, edge E 7 4]
    apply (mask_ge_one (edge E 7 0) (edge E 7 3) (edge E 7 4)).mp
    change ((g8 E) || (g23 E) || (g26 E))=true
    simpa [g2683, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2865 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2686, .pos 2690, .pos 2694, .pos 2695, .pos 2696] := by
  change (¬ ((g2687 E)=true)) → (¬ ((g2691 E)=true)) → (¬ ((g2695 E)=true)) → (¬ ((g2696 E)=true)) → (¬ ((g2697 E)=true)) → False
  intro c1 c2 c4 c6 c7
  apply h
  refine ⟨0,3,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 3, edge E 1 5]
    apply (mask_ge_two (edge E 1 0) (edge E 1 3) (edge E 1 5)).mp
    change (((g2 E) && (g10 E)) || ((g2 E) && (g12 E)) || ((g10 E) && (g12 E)))=true
    simpa [g2684, g2685, g2686, g2687, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 3, edge E 2 5]
    apply (mask_ge_two (edge E 2 0) (edge E 2 3) (edge E 2 5)).mp
    change (((g3 E) && (g15 E)) || ((g3 E) && (g17 E)) || ((g15 E) && (g17 E)))=true
    simpa [g2688, g2689, g2690, g2691, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 4 0, edge E 4 3, edge E 4 5]
    apply (mask_ge_two (edge E 4 0) (edge E 4 3) (edge E 4 5)).mp
    change (((g5 E) && (g20 E)) || ((g5 E) && (g24 E)) || ((g20 E) && (g24 E)))=true
    simpa [g2692, g2693, g2694, g2695, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 0, edge E 6 3, edge E 6 5]
    apply (mask_ge_one (edge E 6 0) (edge E 6 3) (edge E 6 5)).mp
    change ((g7 E) || (g22 E) || (g27 E))=true
    simpa [g2696, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 3, edge E 7 5]
    apply (mask_ge_one (edge E 7 0) (edge E 7 3) (edge E 7 5)).mp
    change ((g8 E) || (g23 E) || (g28 E))=true
    simpa [g2697, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2875 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2700, .pos 2704, .pos 2708, .pos 2709, .pos 2710] := by
  change (¬ ((g2701 E)=true)) → (¬ ((g2705 E)=true)) → (¬ ((g2709 E)=true)) → (¬ ((g2710 E)=true)) → (¬ ((g2711 E)=true)) → False
  intro c1 c2 c4 c5 c7
  apply h
  refine ⟨0,3,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 3, edge E 1 6]
    apply (mask_ge_two (edge E 1 0) (edge E 1 3) (edge E 1 6)).mp
    change (((g2 E) && (g10 E)) || ((g2 E) && (g13 E)) || ((g10 E) && (g13 E)))=true
    simpa [g2698, g2699, g2700, g2701, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 3, edge E 2 6]
    apply (mask_ge_two (edge E 2 0) (edge E 2 3) (edge E 2 6)).mp
    change (((g3 E) && (g15 E)) || ((g3 E) && (g18 E)) || ((g15 E) && (g18 E)))=true
    simpa [g2702, g2703, g2704, g2705, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 4 0, edge E 4 3, edge E 4 6]
    apply (mask_ge_two (edge E 4 0) (edge E 4 3) (edge E 4 6)).mp
    change (((g5 E) && (g20 E)) || ((g5 E) && (g25 E)) || ((g20 E) && (g25 E)))=true
    simpa [g2706, g2707, g2708, g2709, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 3, edge E 5 6]
    apply (mask_ge_one (edge E 5 0) (edge E 5 3) (edge E 5 6)).mp
    change ((g6 E) || (g21 E) || (g27 E))=true
    simpa [g2710, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 0, edge E 7 3, edge E 7 6]
    apply (mask_ge_one (edge E 7 0) (edge E 7 3) (edge E 7 6)).mp
    change ((g8 E) || (g23 E) || (g29 E))=true
    simpa [g2711, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2895 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2714, .pos 2718, .pos 2722, .pos 2723, .pos 2724] := by
  change (¬ ((g2715 E)=true)) → (¬ ((g2719 E)=true)) → (¬ ((g2723 E)=true)) → (¬ ((g2724 E)=true)) → (¬ ((g2725 E)=true)) → False
  intro c1 c2 c4 c5 c6
  apply h
  refine ⟨0,3,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 3, edge E 1 7]
    apply (mask_ge_two (edge E 1 0) (edge E 1 3) (edge E 1 7)).mp
    change (((g2 E) && (g10 E)) || ((g2 E) && (g14 E)) || ((g10 E) && (g14 E)))=true
    simpa [g2712, g2713, g2714, g2715, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 3, edge E 2 7]
    apply (mask_ge_two (edge E 2 0) (edge E 2 3) (edge E 2 7)).mp
    change (((g3 E) && (g15 E)) || ((g3 E) && (g19 E)) || ((g15 E) && (g19 E)))=true
    simpa [g2716, g2717, g2718, g2719, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 4 0, edge E 4 3, edge E 4 7]
    apply (mask_ge_two (edge E 4 0) (edge E 4 3) (edge E 4 7)).mp
    change (((g5 E) && (g20 E)) || ((g5 E) && (g26 E)) || ((g20 E) && (g26 E)))=true
    simpa [g2720, g2721, g2722, g2723, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 3, edge E 5 7]
    apply (mask_ge_one (edge E 5 0) (edge E 5 3) (edge E 5 7)).mp
    change ((g6 E) || (g21 E) || (g28 E))=true
    simpa [g2724, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 3, edge E 6 7]
    apply (mask_ge_one (edge E 6 0) (edge E 6 3) (edge E 6 7)).mp
    change ((g7 E) || (g22 E) || (g29 E))=true
    simpa [g2725, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_2916 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2728, .pos 2732, .pos 2736, .pos 2737, .pos 2738] := by
  change (¬ ((g2729 E)=true)) → (¬ ((g2733 E)=true)) → (¬ ((g2737 E)=true)) → (¬ ((g2738 E)=true)) → (¬ ((g2739 E)=true)) → False
  intro c1 c2 c3 c6 c7
  apply h
  refine ⟨0,4,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 4, edge E 1 5]
    apply (mask_ge_two (edge E 1 0) (edge E 1 4) (edge E 1 5)).mp
    change (((g2 E) && (g11 E)) || ((g2 E) && (g12 E)) || ((g11 E) && (g12 E)))=true
    simpa [g2726, g2727, g2728, g2729, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 4, edge E 2 5]
    apply (mask_ge_two (edge E 2 0) (edge E 2 4) (edge E 2 5)).mp
    change (((g3 E) && (g16 E)) || ((g3 E) && (g17 E)) || ((g16 E) && (g17 E)))=true
    simpa [g2730, g2731, g2732, g2733, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 4, edge E 3 5]
    apply (mask_ge_two (edge E 3 0) (edge E 3 4) (edge E 3 5)).mp
    change (((g4 E) && (g20 E)) || ((g4 E) && (g21 E)) || ((g20 E) && (g21 E)))=true
    simpa [g2734, g2735, g2736, g2737, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 0, edge E 6 4, edge E 6 5]
    apply (mask_ge_one (edge E 6 0) (edge E 6 4) (edge E 6 5)).mp
    change ((g7 E) || (g25 E) || (g27 E))=true
    simpa [g2738, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 4, edge E 7 5]
    apply (mask_ge_one (edge E 7 0) (edge E 7 4) (edge E 7 5)).mp
    change ((g8 E) || (g26 E) || (g28 E))=true
    simpa [g2739, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2949 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2742, .pos 2746, .pos 2750, .pos 2751, .pos 2752] := by
  change (¬ ((g2743 E)=true)) → (¬ ((g2747 E)=true)) → (¬ ((g2751 E)=true)) → (¬ ((g2752 E)=true)) → (¬ ((g2753 E)=true)) → False
  intro c1 c2 c3 c5 c7
  apply h
  refine ⟨0,4,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 4, edge E 1 6]
    apply (mask_ge_two (edge E 1 0) (edge E 1 4) (edge E 1 6)).mp
    change (((g2 E) && (g11 E)) || ((g2 E) && (g13 E)) || ((g11 E) && (g13 E)))=true
    simpa [g2740, g2741, g2742, g2743, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 4, edge E 2 6]
    apply (mask_ge_two (edge E 2 0) (edge E 2 4) (edge E 2 6)).mp
    change (((g3 E) && (g16 E)) || ((g3 E) && (g18 E)) || ((g16 E) && (g18 E)))=true
    simpa [g2744, g2745, g2746, g2747, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 4, edge E 3 6]
    apply (mask_ge_two (edge E 3 0) (edge E 3 4) (edge E 3 6)).mp
    change (((g4 E) && (g20 E)) || ((g4 E) && (g22 E)) || ((g20 E) && (g22 E)))=true
    simpa [g2748, g2749, g2750, g2751, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 5 0, edge E 5 4, edge E 5 6]
    apply (mask_ge_one (edge E 5 0) (edge E 5 4) (edge E 5 6)).mp
    change ((g6 E) || (g24 E) || (g27 E))=true
    simpa [g2752, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 0, edge E 7 4, edge E 7 6]
    apply (mask_ge_one (edge E 7 0) (edge E 7 4) (edge E 7 6)).mp
    change ((g8 E) || (g26 E) || (g29 E))=true
    simpa [g2753, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_2978 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2756, .pos 2760, .pos 2764, .pos 2765, .pos 2766] := by
  change (¬ ((g2757 E)=true)) → (¬ ((g2761 E)=true)) → (¬ ((g2765 E)=true)) → (¬ ((g2766 E)=true)) → (¬ ((g2767 E)=true)) → False
  intro c1 c2 c3 c5 c6
  apply h
  refine ⟨0,4,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 4, edge E 1 7]
    apply (mask_ge_two (edge E 1 0) (edge E 1 4) (edge E 1 7)).mp
    change (((g2 E) && (g11 E)) || ((g2 E) && (g14 E)) || ((g11 E) && (g14 E)))=true
    simpa [g2754, g2755, g2756, g2757, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 4, edge E 2 7]
    apply (mask_ge_two (edge E 2 0) (edge E 2 4) (edge E 2 7)).mp
    change (((g3 E) && (g16 E)) || ((g3 E) && (g19 E)) || ((g16 E) && (g19 E)))=true
    simpa [g2758, g2759, g2760, g2761, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 4, edge E 3 7]
    apply (mask_ge_two (edge E 3 0) (edge E 3 4) (edge E 3 7)).mp
    change (((g4 E) && (g20 E)) || ((g4 E) && (g23 E)) || ((g20 E) && (g23 E)))=true
    simpa [g2762, g2763, g2764, g2765, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 5 0, edge E 5 4, edge E 5 7]
    apply (mask_ge_one (edge E 5 0) (edge E 5 4) (edge E 5 7)).mp
    change ((g6 E) || (g24 E) || (g28 E))=true
    simpa [g2766, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 4, edge E 6 7]
    apply (mask_ge_one (edge E 6 0) (edge E 6 4) (edge E 6 7)).mp
    change ((g7 E) || (g25 E) || (g29 E))=true
    simpa [g2767, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_2988 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2770, .pos 2774, .pos 2778, .pos 2782, .pos 2783] := by
  change (¬ ((g2771 E)=true)) → (¬ ((g2775 E)=true)) → (¬ ((g2779 E)=true)) → (¬ ((g2783 E)=true)) → (¬ ((g2784 E)=true)) → False
  intro c1 c2 c3 c4 c7
  apply h
  refine ⟨0,5,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 5, edge E 1 6]
    apply (mask_ge_two (edge E 1 0) (edge E 1 5) (edge E 1 6)).mp
    change (((g2 E) && (g12 E)) || ((g2 E) && (g13 E)) || ((g12 E) && (g13 E)))=true
    simpa [g2768, g2769, g2770, g2771, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 5, edge E 2 6]
    apply (mask_ge_two (edge E 2 0) (edge E 2 5) (edge E 2 6)).mp
    change (((g3 E) && (g17 E)) || ((g3 E) && (g18 E)) || ((g17 E) && (g18 E)))=true
    simpa [g2772, g2773, g2774, g2775, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 5, edge E 3 6]
    apply (mask_ge_two (edge E 3 0) (edge E 3 5) (edge E 3 6)).mp
    change (((g4 E) && (g21 E)) || ((g4 E) && (g22 E)) || ((g21 E) && (g22 E)))=true
    simpa [g2776, g2777, g2778, g2779, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 0, edge E 4 5, edge E 4 6]
    apply (mask_ge_two (edge E 4 0) (edge E 4 5) (edge E 4 6)).mp
    change (((g5 E) && (g24 E)) || ((g5 E) && (g25 E)) || ((g24 E) && (g25 E)))=true
    simpa [g2780, g2781, g2782, g2783, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 0, edge E 7 5, edge E 7 6]
    apply (mask_ge_one (edge E 7 0) (edge E 7 5) (edge E 7 6)).mp
    change ((g8 E) || (g28 E) || (g29 E))=true
    simpa [g2784, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3011 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2787, .pos 2791, .pos 2795, .pos 2799, .pos 2800] := by
  change (¬ ((g2788 E)=true)) → (¬ ((g2792 E)=true)) → (¬ ((g2796 E)=true)) → (¬ ((g2800 E)=true)) → (¬ ((g2801 E)=true)) → False
  intro c1 c2 c3 c4 c6
  apply h
  refine ⟨0,5,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 5, edge E 1 7]
    apply (mask_ge_two (edge E 1 0) (edge E 1 5) (edge E 1 7)).mp
    change (((g2 E) && (g12 E)) || ((g2 E) && (g14 E)) || ((g12 E) && (g14 E)))=true
    simpa [g2785, g2786, g2787, g2788, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 5, edge E 2 7]
    apply (mask_ge_two (edge E 2 0) (edge E 2 5) (edge E 2 7)).mp
    change (((g3 E) && (g17 E)) || ((g3 E) && (g19 E)) || ((g17 E) && (g19 E)))=true
    simpa [g2789, g2790, g2791, g2792, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 5, edge E 3 7]
    apply (mask_ge_two (edge E 3 0) (edge E 3 5) (edge E 3 7)).mp
    change (((g4 E) && (g21 E)) || ((g4 E) && (g23 E)) || ((g21 E) && (g23 E)))=true
    simpa [g2793, g2794, g2795, g2796, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 0, edge E 4 5, edge E 4 7]
    apply (mask_ge_two (edge E 4 0) (edge E 4 5) (edge E 4 7)).mp
    change (((g5 E) && (g24 E)) || ((g5 E) && (g26 E)) || ((g24 E) && (g26 E)))=true
    simpa [g2797, g2798, g2799, g2800, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 6 0, edge E 6 5, edge E 6 7]
    apply (mask_ge_one (edge E 6 0) (edge E 6 5) (edge E 6 7)).mp
    change ((g7 E) || (g27 E) || (g29 E))=true
    simpa [g2801, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_3027 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2804, .pos 2808, .pos 2812, .pos 2816, .pos 2817] := by
  change (¬ ((g2805 E)=true)) → (¬ ((g2809 E)=true)) → (¬ ((g2813 E)=true)) → (¬ ((g2817 E)=true)) → (¬ ((g2818 E)=true)) → False
  intro c1 c2 c3 c4 c5
  apply h
  refine ⟨0,6,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 6, edge E 1 7]
    apply (mask_ge_two (edge E 1 0) (edge E 1 6) (edge E 1 7)).mp
    change (((g2 E) && (g13 E)) || ((g2 E) && (g14 E)) || ((g13 E) && (g14 E)))=true
    simpa [g2802, g2803, g2804, g2805, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 6, edge E 2 7]
    apply (mask_ge_two (edge E 2 0) (edge E 2 6) (edge E 2 7)).mp
    change (((g3 E) && (g18 E)) || ((g3 E) && (g19 E)) || ((g18 E) && (g19 E)))=true
    simpa [g2806, g2807, g2808, g2809, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 6, edge E 3 7]
    apply (mask_ge_two (edge E 3 0) (edge E 3 6) (edge E 3 7)).mp
    change (((g4 E) && (g22 E)) || ((g4 E) && (g23 E)) || ((g22 E) && (g23 E)))=true
    simpa [g2810, g2811, g2812, g2813, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 0, edge E 4 6, edge E 4 7]
    apply (mask_ge_two (edge E 4 0) (edge E 4 6) (edge E 4 7)).mp
    change (((g5 E) && (g25 E)) || ((g5 E) && (g26 E)) || ((g25 E) && (g26 E)))=true
    simpa [g2814, g2815, g2816, g2817, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 6, edge E 5 7]
    apply (mask_ge_one (edge E 5 0) (edge E 5 6) (edge E 5 7)).mp
    change ((g6 E) || (g27 E) || (g28 E))=true
    simpa [g2818, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
private theorem root_3060 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2821, .pos 2825, .pos 2826, .pos 2827, .pos 2828] := by
  change (¬ ((g2822 E)=true)) → (¬ ((g2826 E)=true)) → (¬ ((g2827 E)=true)) → (¬ ((g2828 E)=true)) → (¬ ((g2829 E)=true)) → False
  intro c0 c4 c5 c6 c7
  apply h
  refine ⟨1,2,3,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 2, edge E 0 3]
    apply (mask_ge_two (edge E 0 1) (edge E 0 2) (edge E 0 3)).mp
    change (((g2 E) && (g3 E)) || ((g2 E) && (g4 E)) || ((g3 E) && (g4 E)))=true
    simpa [g2819, g2820, g2821, g2822, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 2≤countTrue [edge E 4 1, edge E 4 2, edge E 4 3]
    apply (mask_ge_two (edge E 4 1) (edge E 4 2) (edge E 4 3)).mp
    change (((g11 E) && (g16 E)) || ((g11 E) && (g20 E)) || ((g16 E) && (g20 E)))=true
    simpa [g2823, g2824, g2825, g2826, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 1, edge E 5 2, edge E 5 3]
    apply (mask_ge_one (edge E 5 1) (edge E 5 2) (edge E 5 3)).mp
    change ((g12 E) || (g17 E) || (g21 E))=true
    simpa [g2827, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 1, edge E 6 2, edge E 6 3]
    apply (mask_ge_one (edge E 6 1) (edge E 6 2) (edge E 6 3)).mp
    change ((g13 E) || (g18 E) || (g22 E))=true
    simpa [g2828, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 1, edge E 7 2, edge E 7 3]
    apply (mask_ge_one (edge E 7 1) (edge E 7 2) (edge E 7 3)).mp
    change ((g14 E) || (g19 E) || (g23 E))=true
    simpa [g2829, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3090 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2832, .pos 2836, .pos 2837, .pos 2838, .pos 2839] := by
  change (¬ ((g2833 E)=true)) → (¬ ((g2837 E)=true)) → (¬ ((g2838 E)=true)) → (¬ ((g2839 E)=true)) → (¬ ((g2840 E)=true)) → False
  intro c0 c3 c5 c6 c7
  apply h
  refine ⟨1,2,4,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 2, edge E 0 4]
    apply (mask_ge_two (edge E 0 1) (edge E 0 2) (edge E 0 4)).mp
    change (((g2 E) && (g3 E)) || ((g2 E) && (g5 E)) || ((g3 E) && (g5 E)))=true
    simpa [g2830, g2831, g2832, g2833, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 3 1, edge E 3 2, edge E 3 4]
    apply (mask_ge_two (edge E 3 1) (edge E 3 2) (edge E 3 4)).mp
    change (((g10 E) && (g15 E)) || ((g10 E) && (g20 E)) || ((g15 E) && (g20 E)))=true
    simpa [g2834, g2835, g2836, g2837, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 5 1, edge E 5 2, edge E 5 4]
    apply (mask_ge_one (edge E 5 1) (edge E 5 2) (edge E 5 4)).mp
    change ((g12 E) || (g17 E) || (g24 E))=true
    simpa [g2838, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 1, edge E 6 2, edge E 6 4]
    apply (mask_ge_one (edge E 6 1) (edge E 6 2) (edge E 6 4)).mp
    change ((g13 E) || (g18 E) || (g25 E))=true
    simpa [g2839, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 1, edge E 7 2, edge E 7 4]
    apply (mask_ge_one (edge E 7 1) (edge E 7 2) (edge E 7 4)).mp
    change ((g14 E) || (g19 E) || (g26 E))=true
    simpa [g2840, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3106 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2843, .pos 2847, .pos 2851, .pos 2852, .pos 2853] := by
  change (¬ ((g2844 E)=true)) → (¬ ((g2848 E)=true)) → (¬ ((g2852 E)=true)) → (¬ ((g2853 E)=true)) → (¬ ((g2854 E)=true)) → False
  intro c0 c3 c4 c6 c7
  apply h
  refine ⟨1,2,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 2, edge E 0 5]
    apply (mask_ge_two (edge E 0 1) (edge E 0 2) (edge E 0 5)).mp
    change (((g2 E) && (g3 E)) || ((g2 E) && (g6 E)) || ((g3 E) && (g6 E)))=true
    simpa [g2841, g2842, g2843, g2844, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 3 1, edge E 3 2, edge E 3 5]
    apply (mask_ge_two (edge E 3 1) (edge E 3 2) (edge E 3 5)).mp
    change (((g10 E) && (g15 E)) || ((g10 E) && (g21 E)) || ((g15 E) && (g21 E)))=true
    simpa [g2845, g2846, g2847, g2848, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 1, edge E 4 2, edge E 4 5]
    apply (mask_ge_two (edge E 4 1) (edge E 4 2) (edge E 4 5)).mp
    change (((g11 E) && (g16 E)) || ((g11 E) && (g24 E)) || ((g16 E) && (g24 E)))=true
    simpa [g2849, g2850, g2851, g2852, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 1, edge E 6 2, edge E 6 5]
    apply (mask_ge_one (edge E 6 1) (edge E 6 2) (edge E 6 5)).mp
    change ((g13 E) || (g18 E) || (g27 E))=true
    simpa [g2853, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 1, edge E 7 2, edge E 7 5]
    apply (mask_ge_one (edge E 7 1) (edge E 7 2) (edge E 7 5)).mp
    change ((g14 E) || (g19 E) || (g28 E))=true
    simpa [g2854, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3127 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2857, .pos 2861, .pos 2865, .pos 2866, .pos 2867] := by
  change (¬ ((g2858 E)=true)) → (¬ ((g2862 E)=true)) → (¬ ((g2866 E)=true)) → (¬ ((g2867 E)=true)) → (¬ ((g2868 E)=true)) → False
  intro c0 c3 c4 c5 c7
  apply h
  refine ⟨1,2,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 2, edge E 0 6]
    apply (mask_ge_two (edge E 0 1) (edge E 0 2) (edge E 0 6)).mp
    change (((g2 E) && (g3 E)) || ((g2 E) && (g7 E)) || ((g3 E) && (g7 E)))=true
    simpa [g2855, g2856, g2857, g2858, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 3 1, edge E 3 2, edge E 3 6]
    apply (mask_ge_two (edge E 3 1) (edge E 3 2) (edge E 3 6)).mp
    change (((g10 E) && (g15 E)) || ((g10 E) && (g22 E)) || ((g15 E) && (g22 E)))=true
    simpa [g2859, g2860, g2861, g2862, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 1, edge E 4 2, edge E 4 6]
    apply (mask_ge_two (edge E 4 1) (edge E 4 2) (edge E 4 6)).mp
    change (((g11 E) && (g16 E)) || ((g11 E) && (g25 E)) || ((g16 E) && (g25 E)))=true
    simpa [g2863, g2864, g2865, g2866, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 1, edge E 5 2, edge E 5 6]
    apply (mask_ge_one (edge E 5 1) (edge E 5 2) (edge E 5 6)).mp
    change ((g12 E) || (g17 E) || (g27 E))=true
    simpa [g2867, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 1, edge E 7 2, edge E 7 6]
    apply (mask_ge_one (edge E 7 1) (edge E 7 2) (edge E 7 6)).mp
    change ((g14 E) || (g19 E) || (g29 E))=true
    simpa [g2868, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3157 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2871, .pos 2875, .pos 2879, .pos 2880, .pos 2881] := by
  change (¬ ((g2872 E)=true)) → (¬ ((g2876 E)=true)) → (¬ ((g2880 E)=true)) → (¬ ((g2881 E)=true)) → (¬ ((g2882 E)=true)) → False
  intro c0 c3 c4 c5 c6
  apply h
  refine ⟨1,2,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 2, edge E 0 7]
    apply (mask_ge_two (edge E 0 1) (edge E 0 2) (edge E 0 7)).mp
    change (((g2 E) && (g3 E)) || ((g2 E) && (g8 E)) || ((g3 E) && (g8 E)))=true
    simpa [g2869, g2870, g2871, g2872, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 3 1, edge E 3 2, edge E 3 7]
    apply (mask_ge_two (edge E 3 1) (edge E 3 2) (edge E 3 7)).mp
    change (((g10 E) && (g15 E)) || ((g10 E) && (g23 E)) || ((g15 E) && (g23 E)))=true
    simpa [g2873, g2874, g2875, g2876, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 1, edge E 4 2, edge E 4 7]
    apply (mask_ge_two (edge E 4 1) (edge E 4 2) (edge E 4 7)).mp
    change (((g11 E) && (g16 E)) || ((g11 E) && (g26 E)) || ((g16 E) && (g26 E)))=true
    simpa [g2877, g2878, g2879, g2880, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 1, edge E 5 2, edge E 5 7]
    apply (mask_ge_one (edge E 5 1) (edge E 5 2) (edge E 5 7)).mp
    change ((g12 E) || (g17 E) || (g28 E))=true
    simpa [g2881, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 1, edge E 6 2, edge E 6 7]
    apply (mask_ge_one (edge E 6 1) (edge E 6 2) (edge E 6 7)).mp
    change ((g13 E) || (g18 E) || (g29 E))=true
    simpa [g2882, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_3187 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2885, .pos 2889, .pos 2890, .pos 2891, .pos 2892] := by
  change (¬ ((g2886 E)=true)) → (¬ ((g2890 E)=true)) → (¬ ((g2891 E)=true)) → (¬ ((g2892 E)=true)) → (¬ ((g2893 E)=true)) → False
  intro c0 c2 c5 c6 c7
  apply h
  refine ⟨1,3,4,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 3, edge E 0 4]
    apply (mask_ge_two (edge E 0 1) (edge E 0 3) (edge E 0 4)).mp
    change (((g2 E) && (g4 E)) || ((g2 E) && (g5 E)) || ((g4 E) && (g5 E)))=true
    simpa [g2883, g2884, g2885, g2886, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 3, edge E 2 4]
    apply (mask_ge_two (edge E 2 1) (edge E 2 3) (edge E 2 4)).mp
    change (((g9 E) && (g15 E)) || ((g9 E) && (g16 E)) || ((g15 E) && (g16 E)))=true
    simpa [g2887, g2888, g2889, g2890, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 5 1, edge E 5 3, edge E 5 4]
    apply (mask_ge_one (edge E 5 1) (edge E 5 3) (edge E 5 4)).mp
    change ((g12 E) || (g21 E) || (g24 E))=true
    simpa [g2891, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 1, edge E 6 3, edge E 6 4]
    apply (mask_ge_one (edge E 6 1) (edge E 6 3) (edge E 6 4)).mp
    change ((g13 E) || (g22 E) || (g25 E))=true
    simpa [g2892, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 1, edge E 7 3, edge E 7 4]
    apply (mask_ge_one (edge E 7 1) (edge E 7 3) (edge E 7 4)).mp
    change ((g14 E) || (g23 E) || (g26 E))=true
    simpa [g2893, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3202 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2896, .pos 2900, .pos 2904, .pos 2905, .pos 2906] := by
  change (¬ ((g2897 E)=true)) → (¬ ((g2901 E)=true)) → (¬ ((g2905 E)=true)) → (¬ ((g2906 E)=true)) → (¬ ((g2907 E)=true)) → False
  intro c0 c2 c4 c6 c7
  apply h
  refine ⟨1,3,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 3, edge E 0 5]
    apply (mask_ge_two (edge E 0 1) (edge E 0 3) (edge E 0 5)).mp
    change (((g2 E) && (g4 E)) || ((g2 E) && (g6 E)) || ((g4 E) && (g6 E)))=true
    simpa [g2894, g2895, g2896, g2897, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 3, edge E 2 5]
    apply (mask_ge_two (edge E 2 1) (edge E 2 3) (edge E 2 5)).mp
    change (((g9 E) && (g15 E)) || ((g9 E) && (g17 E)) || ((g15 E) && (g17 E)))=true
    simpa [g2898, g2899, g2900, g2901, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 4 1, edge E 4 3, edge E 4 5]
    apply (mask_ge_two (edge E 4 1) (edge E 4 3) (edge E 4 5)).mp
    change (((g11 E) && (g20 E)) || ((g11 E) && (g24 E)) || ((g20 E) && (g24 E)))=true
    simpa [g2902, g2903, g2904, g2905, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 1, edge E 6 3, edge E 6 5]
    apply (mask_ge_one (edge E 6 1) (edge E 6 3) (edge E 6 5)).mp
    change ((g13 E) || (g22 E) || (g27 E))=true
    simpa [g2906, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 1, edge E 7 3, edge E 7 5]
    apply (mask_ge_one (edge E 7 1) (edge E 7 3) (edge E 7 5)).mp
    change ((g14 E) || (g23 E) || (g28 E))=true
    simpa [g2907, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3221 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2910, .pos 2914, .pos 2918, .pos 2919, .pos 2920] := by
  change (¬ ((g2911 E)=true)) → (¬ ((g2915 E)=true)) → (¬ ((g2919 E)=true)) → (¬ ((g2920 E)=true)) → (¬ ((g2921 E)=true)) → False
  intro c0 c2 c4 c5 c7
  apply h
  refine ⟨1,3,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 3, edge E 0 6]
    apply (mask_ge_two (edge E 0 1) (edge E 0 3) (edge E 0 6)).mp
    change (((g2 E) && (g4 E)) || ((g2 E) && (g7 E)) || ((g4 E) && (g7 E)))=true
    simpa [g2908, g2909, g2910, g2911, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 3, edge E 2 6]
    apply (mask_ge_two (edge E 2 1) (edge E 2 3) (edge E 2 6)).mp
    change (((g9 E) && (g15 E)) || ((g9 E) && (g18 E)) || ((g15 E) && (g18 E)))=true
    simpa [g2912, g2913, g2914, g2915, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 4 1, edge E 4 3, edge E 4 6]
    apply (mask_ge_two (edge E 4 1) (edge E 4 3) (edge E 4 6)).mp
    change (((g11 E) && (g20 E)) || ((g11 E) && (g25 E)) || ((g20 E) && (g25 E)))=true
    simpa [g2916, g2917, g2918, g2919, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 1, edge E 5 3, edge E 5 6]
    apply (mask_ge_one (edge E 5 1) (edge E 5 3) (edge E 5 6)).mp
    change ((g12 E) || (g21 E) || (g27 E))=true
    simpa [g2920, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 1, edge E 7 3, edge E 7 6]
    apply (mask_ge_one (edge E 7 1) (edge E 7 3) (edge E 7 6)).mp
    change ((g14 E) || (g23 E) || (g29 E))=true
    simpa [g2921, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3248 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2924, .pos 2928, .pos 2932, .pos 2933, .pos 2934] := by
  change (¬ ((g2925 E)=true)) → (¬ ((g2929 E)=true)) → (¬ ((g2933 E)=true)) → (¬ ((g2934 E)=true)) → (¬ ((g2935 E)=true)) → False
  intro c0 c2 c4 c5 c6
  apply h
  refine ⟨1,3,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 3, edge E 0 7]
    apply (mask_ge_two (edge E 0 1) (edge E 0 3) (edge E 0 7)).mp
    change (((g2 E) && (g4 E)) || ((g2 E) && (g8 E)) || ((g4 E) && (g8 E)))=true
    simpa [g2922, g2923, g2924, g2925, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 3, edge E 2 7]
    apply (mask_ge_two (edge E 2 1) (edge E 2 3) (edge E 2 7)).mp
    change (((g9 E) && (g15 E)) || ((g9 E) && (g19 E)) || ((g15 E) && (g19 E)))=true
    simpa [g2926, g2927, g2928, g2929, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 4 1, edge E 4 3, edge E 4 7]
    apply (mask_ge_two (edge E 4 1) (edge E 4 3) (edge E 4 7)).mp
    change (((g11 E) && (g20 E)) || ((g11 E) && (g26 E)) || ((g20 E) && (g26 E)))=true
    simpa [g2930, g2931, g2932, g2933, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 1, edge E 5 3, edge E 5 7]
    apply (mask_ge_one (edge E 5 1) (edge E 5 3) (edge E 5 7)).mp
    change ((g12 E) || (g21 E) || (g28 E))=true
    simpa [g2934, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 1, edge E 6 3, edge E 6 7]
    apply (mask_ge_one (edge E 6 1) (edge E 6 3) (edge E 6 7)).mp
    change ((g13 E) || (g22 E) || (g29 E))=true
    simpa [g2935, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_3266 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2938, .pos 2942, .pos 2946, .pos 2947, .pos 2948] := by
  change (¬ ((g2939 E)=true)) → (¬ ((g2943 E)=true)) → (¬ ((g2947 E)=true)) → (¬ ((g2948 E)=true)) → (¬ ((g2949 E)=true)) → False
  intro c0 c2 c3 c6 c7
  apply h
  refine ⟨1,4,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 4, edge E 0 5]
    apply (mask_ge_two (edge E 0 1) (edge E 0 4) (edge E 0 5)).mp
    change (((g2 E) && (g5 E)) || ((g2 E) && (g6 E)) || ((g5 E) && (g6 E)))=true
    simpa [g2936, g2937, g2938, g2939, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 4, edge E 2 5]
    apply (mask_ge_two (edge E 2 1) (edge E 2 4) (edge E 2 5)).mp
    change (((g9 E) && (g16 E)) || ((g9 E) && (g17 E)) || ((g16 E) && (g17 E)))=true
    simpa [g2940, g2941, g2942, g2943, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 1, edge E 3 4, edge E 3 5]
    apply (mask_ge_two (edge E 3 1) (edge E 3 4) (edge E 3 5)).mp
    change (((g10 E) && (g20 E)) || ((g10 E) && (g21 E)) || ((g20 E) && (g21 E)))=true
    simpa [g2944, g2945, g2946, g2947, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 1, edge E 6 4, edge E 6 5]
    apply (mask_ge_one (edge E 6 1) (edge E 6 4) (edge E 6 5)).mp
    change ((g13 E) || (g25 E) || (g27 E))=true
    simpa [g2948, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 1, edge E 7 4, edge E 7 5]
    apply (mask_ge_one (edge E 7 1) (edge E 7 4) (edge E 7 5)).mp
    change ((g14 E) || (g26 E) || (g28 E))=true
    simpa [g2949, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3291 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2952, .pos 2956, .pos 2960, .pos 2961, .pos 2962] := by
  change (¬ ((g2953 E)=true)) → (¬ ((g2957 E)=true)) → (¬ ((g2961 E)=true)) → (¬ ((g2962 E)=true)) → (¬ ((g2963 E)=true)) → False
  intro c0 c2 c3 c5 c7
  apply h
  refine ⟨1,4,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 4, edge E 0 6]
    apply (mask_ge_two (edge E 0 1) (edge E 0 4) (edge E 0 6)).mp
    change (((g2 E) && (g5 E)) || ((g2 E) && (g7 E)) || ((g5 E) && (g7 E)))=true
    simpa [g2950, g2951, g2952, g2953, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 4, edge E 2 6]
    apply (mask_ge_two (edge E 2 1) (edge E 2 4) (edge E 2 6)).mp
    change (((g9 E) && (g16 E)) || ((g9 E) && (g18 E)) || ((g16 E) && (g18 E)))=true
    simpa [g2954, g2955, g2956, g2957, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 1, edge E 3 4, edge E 3 6]
    apply (mask_ge_two (edge E 3 1) (edge E 3 4) (edge E 3 6)).mp
    change (((g10 E) && (g20 E)) || ((g10 E) && (g22 E)) || ((g20 E) && (g22 E)))=true
    simpa [g2958, g2959, g2960, g2961, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 5 1, edge E 5 4, edge E 5 6]
    apply (mask_ge_one (edge E 5 1) (edge E 5 4) (edge E 5 6)).mp
    change ((g12 E) || (g24 E) || (g27 E))=true
    simpa [g2962, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 1, edge E 7 4, edge E 7 6]
    apply (mask_ge_one (edge E 7 1) (edge E 7 4) (edge E 7 6)).mp
    change ((g14 E) || (g26 E) || (g29 E))=true
    simpa [g2963, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3318 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2966, .pos 2970, .pos 2974, .pos 2975, .pos 2976] := by
  change (¬ ((g2967 E)=true)) → (¬ ((g2971 E)=true)) → (¬ ((g2975 E)=true)) → (¬ ((g2976 E)=true)) → (¬ ((g2977 E)=true)) → False
  intro c0 c2 c3 c5 c6
  apply h
  refine ⟨1,4,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 4, edge E 0 7]
    apply (mask_ge_two (edge E 0 1) (edge E 0 4) (edge E 0 7)).mp
    change (((g2 E) && (g5 E)) || ((g2 E) && (g8 E)) || ((g5 E) && (g8 E)))=true
    simpa [g2964, g2965, g2966, g2967, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 4, edge E 2 7]
    apply (mask_ge_two (edge E 2 1) (edge E 2 4) (edge E 2 7)).mp
    change (((g9 E) && (g16 E)) || ((g9 E) && (g19 E)) || ((g16 E) && (g19 E)))=true
    simpa [g2968, g2969, g2970, g2971, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 1, edge E 3 4, edge E 3 7]
    apply (mask_ge_two (edge E 3 1) (edge E 3 4) (edge E 3 7)).mp
    change (((g10 E) && (g20 E)) || ((g10 E) && (g23 E)) || ((g20 E) && (g23 E)))=true
    simpa [g2972, g2973, g2974, g2975, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 5 1, edge E 5 4, edge E 5 7]
    apply (mask_ge_one (edge E 5 1) (edge E 5 4) (edge E 5 7)).mp
    change ((g12 E) || (g24 E) || (g28 E))=true
    simpa [g2976, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 1, edge E 6 4, edge E 6 7]
    apply (mask_ge_one (edge E 6 1) (edge E 6 4) (edge E 6 7)).mp
    change ((g13 E) || (g25 E) || (g29 E))=true
    simpa [g2977, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_3328 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2980, .pos 2984, .pos 2988, .pos 2992, .pos 2993] := by
  change (¬ ((g2981 E)=true)) → (¬ ((g2985 E)=true)) → (¬ ((g2989 E)=true)) → (¬ ((g2993 E)=true)) → (¬ ((g2994 E)=true)) → False
  intro c0 c2 c3 c4 c7
  apply h
  refine ⟨1,5,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 5, edge E 0 6]
    apply (mask_ge_two (edge E 0 1) (edge E 0 5) (edge E 0 6)).mp
    change (((g2 E) && (g6 E)) || ((g2 E) && (g7 E)) || ((g6 E) && (g7 E)))=true
    simpa [g2978, g2979, g2980, g2981, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 5, edge E 2 6]
    apply (mask_ge_two (edge E 2 1) (edge E 2 5) (edge E 2 6)).mp
    change (((g9 E) && (g17 E)) || ((g9 E) && (g18 E)) || ((g17 E) && (g18 E)))=true
    simpa [g2982, g2983, g2984, g2985, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 1, edge E 3 5, edge E 3 6]
    apply (mask_ge_two (edge E 3 1) (edge E 3 5) (edge E 3 6)).mp
    change (((g10 E) && (g21 E)) || ((g10 E) && (g22 E)) || ((g21 E) && (g22 E)))=true
    simpa [g2986, g2987, g2988, g2989, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 1, edge E 4 5, edge E 4 6]
    apply (mask_ge_two (edge E 4 1) (edge E 4 5) (edge E 4 6)).mp
    change (((g11 E) && (g24 E)) || ((g11 E) && (g25 E)) || ((g24 E) && (g25 E)))=true
    simpa [g2990, g2991, g2992, g2993, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 1, edge E 7 5, edge E 7 6]
    apply (mask_ge_one (edge E 7 1) (edge E 7 5) (edge E 7 6)).mp
    change ((g14 E) || (g28 E) || (g29 E))=true
    simpa [g2994, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3365 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3014, .pos 3018, .pos 3022, .pos 3026, .pos 3027] := by
  change (¬ ((g3015 E)=true)) → (¬ ((g3019 E)=true)) → (¬ ((g3023 E)=true)) → (¬ ((g3027 E)=true)) → (¬ ((g3028 E)=true)) → False
  intro c0 c2 c3 c4 c5
  apply h
  refine ⟨1,6,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 6, edge E 0 7]
    apply (mask_ge_two (edge E 0 1) (edge E 0 6) (edge E 0 7)).mp
    change (((g2 E) && (g7 E)) || ((g2 E) && (g8 E)) || ((g7 E) && (g8 E)))=true
    simpa [g3012, g3013, g3014, g3015, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 6, edge E 2 7]
    apply (mask_ge_two (edge E 2 1) (edge E 2 6) (edge E 2 7)).mp
    change (((g9 E) && (g18 E)) || ((g9 E) && (g19 E)) || ((g18 E) && (g19 E)))=true
    simpa [g3016, g3017, g3018, g3019, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 1, edge E 3 6, edge E 3 7]
    apply (mask_ge_two (edge E 3 1) (edge E 3 6) (edge E 3 7)).mp
    change (((g10 E) && (g22 E)) || ((g10 E) && (g23 E)) || ((g22 E) && (g23 E)))=true
    simpa [g3020, g3021, g3022, g3023, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 1, edge E 4 6, edge E 4 7]
    apply (mask_ge_two (edge E 4 1) (edge E 4 6) (edge E 4 7)).mp
    change (((g11 E) && (g25 E)) || ((g11 E) && (g26 E)) || ((g25 E) && (g26 E)))=true
    simpa [g3024, g3025, g3026, g3027, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 1, edge E 5 6, edge E 5 7]
    apply (mask_ge_one (edge E 5 1) (edge E 5 6) (edge E 5 7)).mp
    change ((g12 E) || (g27 E) || (g28 E))=true
    simpa [g3028, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
private theorem root_3402 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3031, .pos 3035, .pos 3036, .pos 3037, .pos 3038] := by
  change (¬ ((g3032 E)=true)) → (¬ ((g3036 E)=true)) → (¬ ((g3037 E)=true)) → (¬ ((g3038 E)=true)) → (¬ ((g3039 E)=true)) → False
  intro c0 c1 c5 c6 c7
  apply h
  refine ⟨2,3,4,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 3, edge E 0 4]
    apply (mask_ge_two (edge E 0 2) (edge E 0 3) (edge E 0 4)).mp
    change (((g3 E) && (g4 E)) || ((g3 E) && (g5 E)) || ((g4 E) && (g5 E)))=true
    simpa [g3029, g3030, g3031, g3032, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 3, edge E 1 4]
    apply (mask_ge_two (edge E 1 2) (edge E 1 3) (edge E 1 4)).mp
    change (((g9 E) && (g10 E)) || ((g9 E) && (g11 E)) || ((g10 E) && (g11 E)))=true
    simpa [g3033, g3034, g3035, g3036, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 5 2, edge E 5 3, edge E 5 4]
    apply (mask_ge_one (edge E 5 2) (edge E 5 3) (edge E 5 4)).mp
    change ((g17 E) || (g21 E) || (g24 E))=true
    simpa [g3037, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 2, edge E 6 3, edge E 6 4]
    apply (mask_ge_one (edge E 6 2) (edge E 6 3) (edge E 6 4)).mp
    change ((g18 E) || (g22 E) || (g25 E))=true
    simpa [g3038, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 2, edge E 7 3, edge E 7 4]
    apply (mask_ge_one (edge E 7 2) (edge E 7 3) (edge E 7 4)).mp
    change ((g19 E) || (g23 E) || (g26 E))=true
    simpa [g3039, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3411 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3042, .pos 3046, .pos 3050, .pos 3051, .pos 3052] := by
  change (¬ ((g3043 E)=true)) → (¬ ((g3047 E)=true)) → (¬ ((g3051 E)=true)) → (¬ ((g3052 E)=true)) → (¬ ((g3053 E)=true)) → False
  intro c0 c1 c4 c6 c7
  apply h
  refine ⟨2,3,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 3, edge E 0 5]
    apply (mask_ge_two (edge E 0 2) (edge E 0 3) (edge E 0 5)).mp
    change (((g3 E) && (g4 E)) || ((g3 E) && (g6 E)) || ((g4 E) && (g6 E)))=true
    simpa [g3040, g3041, g3042, g3043, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 3, edge E 1 5]
    apply (mask_ge_two (edge E 1 2) (edge E 1 3) (edge E 1 5)).mp
    change (((g9 E) && (g10 E)) || ((g9 E) && (g12 E)) || ((g10 E) && (g12 E)))=true
    simpa [g3044, g3045, g3046, g3047, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 4 2, edge E 4 3, edge E 4 5]
    apply (mask_ge_two (edge E 4 2) (edge E 4 3) (edge E 4 5)).mp
    change (((g16 E) && (g20 E)) || ((g16 E) && (g24 E)) || ((g20 E) && (g24 E)))=true
    simpa [g3048, g3049, g3050, g3051, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 2, edge E 6 3, edge E 6 5]
    apply (mask_ge_one (edge E 6 2) (edge E 6 3) (edge E 6 5)).mp
    change ((g18 E) || (g22 E) || (g27 E))=true
    simpa [g3052, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 2, edge E 7 3, edge E 7 5]
    apply (mask_ge_one (edge E 7 2) (edge E 7 3) (edge E 7 5)).mp
    change ((g19 E) || (g23 E) || (g28 E))=true
    simpa [g3053, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3437 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3056, .pos 3060, .pos 3064, .pos 3065, .pos 3066] := by
  change (¬ ((g3057 E)=true)) → (¬ ((g3061 E)=true)) → (¬ ((g3065 E)=true)) → (¬ ((g3066 E)=true)) → (¬ ((g3067 E)=true)) → False
  intro c0 c1 c4 c5 c7
  apply h
  refine ⟨2,3,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 3, edge E 0 6]
    apply (mask_ge_two (edge E 0 2) (edge E 0 3) (edge E 0 6)).mp
    change (((g3 E) && (g4 E)) || ((g3 E) && (g7 E)) || ((g4 E) && (g7 E)))=true
    simpa [g3054, g3055, g3056, g3057, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 3, edge E 1 6]
    apply (mask_ge_two (edge E 1 2) (edge E 1 3) (edge E 1 6)).mp
    change (((g9 E) && (g10 E)) || ((g9 E) && (g13 E)) || ((g10 E) && (g13 E)))=true
    simpa [g3058, g3059, g3060, g3061, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 4 2, edge E 4 3, edge E 4 6]
    apply (mask_ge_two (edge E 4 2) (edge E 4 3) (edge E 4 6)).mp
    change (((g16 E) && (g20 E)) || ((g16 E) && (g25 E)) || ((g20 E) && (g25 E)))=true
    simpa [g3062, g3063, g3064, g3065, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 2, edge E 5 3, edge E 5 6]
    apply (mask_ge_one (edge E 5 2) (edge E 5 3) (edge E 5 6)).mp
    change ((g17 E) || (g21 E) || (g27 E))=true
    simpa [g3066, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 2, edge E 7 3, edge E 7 6]
    apply (mask_ge_one (edge E 7 2) (edge E 7 3) (edge E 7 6)).mp
    change ((g19 E) || (g23 E) || (g29 E))=true
    simpa [g3067, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3469 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3070, .pos 3074, .pos 3078, .pos 3079, .pos 3080] := by
  change (¬ ((g3071 E)=true)) → (¬ ((g3075 E)=true)) → (¬ ((g3079 E)=true)) → (¬ ((g3080 E)=true)) → (¬ ((g3081 E)=true)) → False
  intro c0 c1 c4 c5 c6
  apply h
  refine ⟨2,3,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 3, edge E 0 7]
    apply (mask_ge_two (edge E 0 2) (edge E 0 3) (edge E 0 7)).mp
    change (((g3 E) && (g4 E)) || ((g3 E) && (g8 E)) || ((g4 E) && (g8 E)))=true
    simpa [g3068, g3069, g3070, g3071, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 3, edge E 1 7]
    apply (mask_ge_two (edge E 1 2) (edge E 1 3) (edge E 1 7)).mp
    change (((g9 E) && (g10 E)) || ((g9 E) && (g14 E)) || ((g10 E) && (g14 E)))=true
    simpa [g3072, g3073, g3074, g3075, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 4 2, edge E 4 3, edge E 4 7]
    apply (mask_ge_two (edge E 4 2) (edge E 4 3) (edge E 4 7)).mp
    change (((g16 E) && (g20 E)) || ((g16 E) && (g26 E)) || ((g20 E) && (g26 E)))=true
    simpa [g3076, g3077, g3078, g3079, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 2, edge E 5 3, edge E 5 7]
    apply (mask_ge_one (edge E 5 2) (edge E 5 3) (edge E 5 7)).mp
    change ((g17 E) || (g21 E) || (g28 E))=true
    simpa [g3080, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 2, edge E 6 3, edge E 6 7]
    apply (mask_ge_one (edge E 6 2) (edge E 6 3) (edge E 6 7)).mp
    change ((g18 E) || (g22 E) || (g29 E))=true
    simpa [g3081, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_3495 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3098, .pos 3102, .pos 3106, .pos 3107, .pos 3108] := by
  change (¬ ((g3099 E)=true)) → (¬ ((g3103 E)=true)) → (¬ ((g3107 E)=true)) → (¬ ((g3108 E)=true)) → (¬ ((g3109 E)=true)) → False
  intro c0 c1 c3 c5 c7
  apply h
  refine ⟨2,4,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 4, edge E 0 6]
    apply (mask_ge_two (edge E 0 2) (edge E 0 4) (edge E 0 6)).mp
    change (((g3 E) && (g5 E)) || ((g3 E) && (g7 E)) || ((g5 E) && (g7 E)))=true
    simpa [g3096, g3097, g3098, g3099, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 4, edge E 1 6]
    apply (mask_ge_two (edge E 1 2) (edge E 1 4) (edge E 1 6)).mp
    change (((g9 E) && (g11 E)) || ((g9 E) && (g13 E)) || ((g11 E) && (g13 E)))=true
    simpa [g3100, g3101, g3102, g3103, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 3 2, edge E 3 4, edge E 3 6]
    apply (mask_ge_two (edge E 3 2) (edge E 3 4) (edge E 3 6)).mp
    change (((g15 E) && (g20 E)) || ((g15 E) && (g22 E)) || ((g20 E) && (g22 E)))=true
    simpa [g3104, g3105, g3106, g3107, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 5 2, edge E 5 4, edge E 5 6]
    apply (mask_ge_one (edge E 5 2) (edge E 5 4) (edge E 5 6)).mp
    change ((g17 E) || (g24 E) || (g27 E))=true
    simpa [g3108, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 2, edge E 7 4, edge E 7 6]
    apply (mask_ge_one (edge E 7 2) (edge E 7 4) (edge E 7 6)).mp
    change ((g19 E) || (g26 E) || (g29 E))=true
    simpa [g3109, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3526 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3112, .pos 3116, .pos 3120, .pos 3121, .pos 3122] := by
  change (¬ ((g3113 E)=true)) → (¬ ((g3117 E)=true)) → (¬ ((g3121 E)=true)) → (¬ ((g3122 E)=true)) → (¬ ((g3123 E)=true)) → False
  intro c0 c1 c3 c5 c6
  apply h
  refine ⟨2,4,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 4, edge E 0 7]
    apply (mask_ge_two (edge E 0 2) (edge E 0 4) (edge E 0 7)).mp
    change (((g3 E) && (g5 E)) || ((g3 E) && (g8 E)) || ((g5 E) && (g8 E)))=true
    simpa [g3110, g3111, g3112, g3113, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 4, edge E 1 7]
    apply (mask_ge_two (edge E 1 2) (edge E 1 4) (edge E 1 7)).mp
    change (((g9 E) && (g11 E)) || ((g9 E) && (g14 E)) || ((g11 E) && (g14 E)))=true
    simpa [g3114, g3115, g3116, g3117, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 3 2, edge E 3 4, edge E 3 7]
    apply (mask_ge_two (edge E 3 2) (edge E 3 4) (edge E 3 7)).mp
    change (((g15 E) && (g20 E)) || ((g15 E) && (g23 E)) || ((g20 E) && (g23 E)))=true
    simpa [g3118, g3119, g3120, g3121, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 5 2, edge E 5 4, edge E 5 7]
    apply (mask_ge_one (edge E 5 2) (edge E 5 4) (edge E 5 7)).mp
    change ((g17 E) || (g24 E) || (g28 E))=true
    simpa [g3122, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 2, edge E 6 4, edge E 6 7]
    apply (mask_ge_one (edge E 6 2) (edge E 6 4) (edge E 6 7)).mp
    change ((g18 E) || (g25 E) || (g29 E))=true
    simpa [g3123, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_3540 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3126, .pos 3130, .pos 3134, .pos 3138, .pos 3139] := by
  change (¬ ((g3127 E)=true)) → (¬ ((g3131 E)=true)) → (¬ ((g3135 E)=true)) → (¬ ((g3139 E)=true)) → (¬ ((g3140 E)=true)) → False
  intro c0 c1 c3 c4 c7
  apply h
  refine ⟨2,5,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 5, edge E 0 6]
    apply (mask_ge_two (edge E 0 2) (edge E 0 5) (edge E 0 6)).mp
    change (((g3 E) && (g6 E)) || ((g3 E) && (g7 E)) || ((g6 E) && (g7 E)))=true
    simpa [g3124, g3125, g3126, g3127, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 5, edge E 1 6]
    apply (mask_ge_two (edge E 1 2) (edge E 1 5) (edge E 1 6)).mp
    change (((g9 E) && (g12 E)) || ((g9 E) && (g13 E)) || ((g12 E) && (g13 E)))=true
    simpa [g3128, g3129, g3130, g3131, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 3 2, edge E 3 5, edge E 3 6]
    apply (mask_ge_two (edge E 3 2) (edge E 3 5) (edge E 3 6)).mp
    change (((g15 E) && (g21 E)) || ((g15 E) && (g22 E)) || ((g21 E) && (g22 E)))=true
    simpa [g3132, g3133, g3134, g3135, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 2, edge E 4 5, edge E 4 6]
    apply (mask_ge_two (edge E 4 2) (edge E 4 5) (edge E 4 6)).mp
    change (((g16 E) && (g24 E)) || ((g16 E) && (g25 E)) || ((g24 E) && (g25 E)))=true
    simpa [g3136, g3137, g3138, g3139, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 2, edge E 7 5, edge E 7 6]
    apply (mask_ge_one (edge E 7 2) (edge E 7 5) (edge E 7 6)).mp
    change ((g19 E) || (g28 E) || (g29 E))=true
    simpa [g3140, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3572 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3160, .pos 3164, .pos 3168, .pos 3172, .pos 3173] := by
  change (¬ ((g3161 E)=true)) → (¬ ((g3165 E)=true)) → (¬ ((g3169 E)=true)) → (¬ ((g3173 E)=true)) → (¬ ((g3174 E)=true)) → False
  intro c0 c1 c3 c4 c5
  apply h
  refine ⟨2,6,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 6, edge E 0 7]
    apply (mask_ge_two (edge E 0 2) (edge E 0 6) (edge E 0 7)).mp
    change (((g3 E) && (g7 E)) || ((g3 E) && (g8 E)) || ((g7 E) && (g8 E)))=true
    simpa [g3158, g3159, g3160, g3161, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 6, edge E 1 7]
    apply (mask_ge_two (edge E 1 2) (edge E 1 6) (edge E 1 7)).mp
    change (((g9 E) && (g13 E)) || ((g9 E) && (g14 E)) || ((g13 E) && (g14 E)))=true
    simpa [g3162, g3163, g3164, g3165, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 3 2, edge E 3 6, edge E 3 7]
    apply (mask_ge_two (edge E 3 2) (edge E 3 6) (edge E 3 7)).mp
    change (((g15 E) && (g22 E)) || ((g15 E) && (g23 E)) || ((g22 E) && (g23 E)))=true
    simpa [g3166, g3167, g3168, g3169, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 2, edge E 4 6, edge E 4 7]
    apply (mask_ge_two (edge E 4 2) (edge E 4 6) (edge E 4 7)).mp
    change (((g16 E) && (g25 E)) || ((g16 E) && (g26 E)) || ((g25 E) && (g26 E)))=true
    simpa [g3170, g3171, g3172, g3173, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 2, edge E 5 6, edge E 5 7]
    apply (mask_ge_one (edge E 5 2) (edge E 5 6) (edge E 5 7)).mp
    change ((g17 E) || (g27 E) || (g28 E))=true
    simpa [g3174, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
private theorem root_3583 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3177, .pos 3181, .pos 3185, .pos 3186, .pos 3187] := by
  change (¬ ((g3178 E)=true)) → (¬ ((g3182 E)=true)) → (¬ ((g3186 E)=true)) → (¬ ((g3187 E)=true)) → (¬ ((g3188 E)=true)) → False
  intro c0 c1 c2 c6 c7
  apply h
  refine ⟨3,4,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 3, edge E 0 4, edge E 0 5]
    apply (mask_ge_two (edge E 0 3) (edge E 0 4) (edge E 0 5)).mp
    change (((g4 E) && (g5 E)) || ((g4 E) && (g6 E)) || ((g5 E) && (g6 E)))=true
    simpa [g3175, g3176, g3177, g3178, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 3, edge E 1 4, edge E 1 5]
    apply (mask_ge_two (edge E 1 3) (edge E 1 4) (edge E 1 5)).mp
    change (((g10 E) && (g11 E)) || ((g10 E) && (g12 E)) || ((g11 E) && (g12 E)))=true
    simpa [g3179, g3180, g3181, g3182, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 3, edge E 2 4, edge E 2 5]
    apply (mask_ge_two (edge E 2 3) (edge E 2 4) (edge E 2 5)).mp
    change (((g15 E) && (g16 E)) || ((g15 E) && (g17 E)) || ((g16 E) && (g17 E)))=true
    simpa [g3183, g3184, g3185, g3186, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 3, edge E 6 4, edge E 6 5]
    apply (mask_ge_one (edge E 6 3) (edge E 6 4) (edge E 6 5)).mp
    change ((g22 E) || (g25 E) || (g27 E))=true
    simpa [g3187, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 3, edge E 7 4, edge E 7 5]
    apply (mask_ge_one (edge E 7 3) (edge E 7 4) (edge E 7 5)).mp
    change ((g23 E) || (g26 E) || (g28 E))=true
    simpa [g3188, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3608 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3191, .pos 3195, .pos 3199, .pos 3200, .pos 3201] := by
  change (¬ ((g3192 E)=true)) → (¬ ((g3196 E)=true)) → (¬ ((g3200 E)=true)) → (¬ ((g3201 E)=true)) → (¬ ((g3202 E)=true)) → False
  intro c0 c1 c2 c5 c7
  apply h
  refine ⟨3,4,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 3, edge E 0 4, edge E 0 6]
    apply (mask_ge_two (edge E 0 3) (edge E 0 4) (edge E 0 6)).mp
    change (((g4 E) && (g5 E)) || ((g4 E) && (g7 E)) || ((g5 E) && (g7 E)))=true
    simpa [g3189, g3190, g3191, g3192, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 3, edge E 1 4, edge E 1 6]
    apply (mask_ge_two (edge E 1 3) (edge E 1 4) (edge E 1 6)).mp
    change (((g10 E) && (g11 E)) || ((g10 E) && (g13 E)) || ((g11 E) && (g13 E)))=true
    simpa [g3193, g3194, g3195, g3196, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 3, edge E 2 4, edge E 2 6]
    apply (mask_ge_two (edge E 2 3) (edge E 2 4) (edge E 2 6)).mp
    change (((g15 E) && (g16 E)) || ((g15 E) && (g18 E)) || ((g16 E) && (g18 E)))=true
    simpa [g3197, g3198, g3199, g3200, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 5 3, edge E 5 4, edge E 5 6]
    apply (mask_ge_one (edge E 5 3) (edge E 5 4) (edge E 5 6)).mp
    change ((g21 E) || (g24 E) || (g27 E))=true
    simpa [g3201, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 3, edge E 7 4, edge E 7 6]
    apply (mask_ge_one (edge E 7 3) (edge E 7 4) (edge E 7 6)).mp
    change ((g23 E) || (g26 E) || (g29 E))=true
    simpa [g3202, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3634 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3205, .pos 3209, .pos 3213, .pos 3214, .pos 3215] := by
  change (¬ ((g3206 E)=true)) → (¬ ((g3210 E)=true)) → (¬ ((g3214 E)=true)) → (¬ ((g3215 E)=true)) → (¬ ((g3216 E)=true)) → False
  intro c0 c1 c2 c5 c6
  apply h
  refine ⟨3,4,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 3, edge E 0 4, edge E 0 7]
    apply (mask_ge_two (edge E 0 3) (edge E 0 4) (edge E 0 7)).mp
    change (((g4 E) && (g5 E)) || ((g4 E) && (g8 E)) || ((g5 E) && (g8 E)))=true
    simpa [g3203, g3204, g3205, g3206, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 3, edge E 1 4, edge E 1 7]
    apply (mask_ge_two (edge E 1 3) (edge E 1 4) (edge E 1 7)).mp
    change (((g10 E) && (g11 E)) || ((g10 E) && (g14 E)) || ((g11 E) && (g14 E)))=true
    simpa [g3207, g3208, g3209, g3210, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 3, edge E 2 4, edge E 2 7]
    apply (mask_ge_two (edge E 2 3) (edge E 2 4) (edge E 2 7)).mp
    change (((g15 E) && (g16 E)) || ((g15 E) && (g19 E)) || ((g16 E) && (g19 E)))=true
    simpa [g3211, g3212, g3213, g3214, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 5 3, edge E 5 4, edge E 5 7]
    apply (mask_ge_one (edge E 5 3) (edge E 5 4) (edge E 5 7)).mp
    change ((g21 E) || (g24 E) || (g28 E))=true
    simpa [g3215, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 3, edge E 6 4, edge E 6 7]
    apply (mask_ge_one (edge E 6 3) (edge E 6 4) (edge E 6 7)).mp
    change ((g22 E) || (g25 E) || (g29 E))=true
    simpa [g3216, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_3649 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3219, .pos 3223, .pos 3227, .pos 3231, .pos 3232] := by
  change (¬ ((g3220 E)=true)) → (¬ ((g3224 E)=true)) → (¬ ((g3228 E)=true)) → (¬ ((g3232 E)=true)) → (¬ ((g3233 E)=true)) → False
  intro c0 c1 c2 c4 c7
  apply h
  refine ⟨3,5,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 3, edge E 0 5, edge E 0 6]
    apply (mask_ge_two (edge E 0 3) (edge E 0 5) (edge E 0 6)).mp
    change (((g4 E) && (g6 E)) || ((g4 E) && (g7 E)) || ((g6 E) && (g7 E)))=true
    simpa [g3217, g3218, g3219, g3220, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 3, edge E 1 5, edge E 1 6]
    apply (mask_ge_two (edge E 1 3) (edge E 1 5) (edge E 1 6)).mp
    change (((g10 E) && (g12 E)) || ((g10 E) && (g13 E)) || ((g12 E) && (g13 E)))=true
    simpa [g3221, g3222, g3223, g3224, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 3, edge E 2 5, edge E 2 6]
    apply (mask_ge_two (edge E 2 3) (edge E 2 5) (edge E 2 6)).mp
    change (((g15 E) && (g17 E)) || ((g15 E) && (g18 E)) || ((g17 E) && (g18 E)))=true
    simpa [g3225, g3226, g3227, g3228, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 4 3, edge E 4 5, edge E 4 6]
    apply (mask_ge_two (edge E 4 3) (edge E 4 5) (edge E 4 6)).mp
    change (((g20 E) && (g24 E)) || ((g20 E) && (g25 E)) || ((g24 E) && (g25 E)))=true
    simpa [g3229, g3230, g3231, g3232, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 3, edge E 7 5, edge E 7 6]
    apply (mask_ge_one (edge E 7 3) (edge E 7 5) (edge E 7 6)).mp
    change ((g23 E) || (g28 E) || (g29 E))=true
    simpa [g3233, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3668 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3236, .pos 3240, .pos 3244, .pos 3248, .pos 3249] := by
  change (¬ ((g3237 E)=true)) → (¬ ((g3241 E)=true)) → (¬ ((g3245 E)=true)) → (¬ ((g3249 E)=true)) → (¬ ((g3250 E)=true)) → False
  intro c0 c1 c2 c4 c6
  apply h
  refine ⟨3,5,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 3, edge E 0 5, edge E 0 7]
    apply (mask_ge_two (edge E 0 3) (edge E 0 5) (edge E 0 7)).mp
    change (((g4 E) && (g6 E)) || ((g4 E) && (g8 E)) || ((g6 E) && (g8 E)))=true
    simpa [g3234, g3235, g3236, g3237, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 3, edge E 1 5, edge E 1 7]
    apply (mask_ge_two (edge E 1 3) (edge E 1 5) (edge E 1 7)).mp
    change (((g10 E) && (g12 E)) || ((g10 E) && (g14 E)) || ((g12 E) && (g14 E)))=true
    simpa [g3238, g3239, g3240, g3241, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 3, edge E 2 5, edge E 2 7]
    apply (mask_ge_two (edge E 2 3) (edge E 2 5) (edge E 2 7)).mp
    change (((g15 E) && (g17 E)) || ((g15 E) && (g19 E)) || ((g17 E) && (g19 E)))=true
    simpa [g3242, g3243, g3244, g3245, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 4 3, edge E 4 5, edge E 4 7]
    apply (mask_ge_two (edge E 4 3) (edge E 4 5) (edge E 4 7)).mp
    change (((g20 E) && (g24 E)) || ((g20 E) && (g26 E)) || ((g24 E) && (g26 E)))=true
    simpa [g3246, g3247, g3248, g3249, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 6 3, edge E 6 5, edge E 6 7]
    apply (mask_ge_one (edge E 6 3) (edge E 6 5) (edge E 6 7)).mp
    change ((g22 E) || (g27 E) || (g29 E))=true
    simpa [g3250, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_3688 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3253, .pos 3257, .pos 3261, .pos 3265, .pos 3266] := by
  change (¬ ((g3254 E)=true)) → (¬ ((g3258 E)=true)) → (¬ ((g3262 E)=true)) → (¬ ((g3266 E)=true)) → (¬ ((g3267 E)=true)) → False
  intro c0 c1 c2 c4 c5
  apply h
  refine ⟨3,6,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 3, edge E 0 6, edge E 0 7]
    apply (mask_ge_two (edge E 0 3) (edge E 0 6) (edge E 0 7)).mp
    change (((g4 E) && (g7 E)) || ((g4 E) && (g8 E)) || ((g7 E) && (g8 E)))=true
    simpa [g3251, g3252, g3253, g3254, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 3, edge E 1 6, edge E 1 7]
    apply (mask_ge_two (edge E 1 3) (edge E 1 6) (edge E 1 7)).mp
    change (((g10 E) && (g13 E)) || ((g10 E) && (g14 E)) || ((g13 E) && (g14 E)))=true
    simpa [g3255, g3256, g3257, g3258, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 3, edge E 2 6, edge E 2 7]
    apply (mask_ge_two (edge E 2 3) (edge E 2 6) (edge E 2 7)).mp
    change (((g15 E) && (g18 E)) || ((g15 E) && (g19 E)) || ((g18 E) && (g19 E)))=true
    simpa [g3259, g3260, g3261, g3262, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 4 3, edge E 4 6, edge E 4 7]
    apply (mask_ge_two (edge E 4 3) (edge E 4 6) (edge E 4 7)).mp
    change (((g20 E) && (g25 E)) || ((g20 E) && (g26 E)) || ((g25 E) && (g26 E)))=true
    simpa [g3263, g3264, g3265, g3266, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 3, edge E 5 6, edge E 5 7]
    apply (mask_ge_one (edge E 5 3) (edge E 5 6) (edge E 5 7)).mp
    change ((g21 E) || (g27 E) || (g28 E))=true
    simpa [g3267, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
private theorem root_3698 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3270, .pos 3274, .pos 3278, .pos 3282, .pos 3283] := by
  change (¬ ((g3271 E)=true)) → (¬ ((g3275 E)=true)) → (¬ ((g3279 E)=true)) → (¬ ((g3283 E)=true)) → (¬ ((g3284 E)=true)) → False
  intro c0 c1 c2 c3 c7
  apply h
  refine ⟨4,5,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 4, edge E 0 5, edge E 0 6]
    apply (mask_ge_two (edge E 0 4) (edge E 0 5) (edge E 0 6)).mp
    change (((g5 E) && (g6 E)) || ((g5 E) && (g7 E)) || ((g6 E) && (g7 E)))=true
    simpa [g3268, g3269, g3270, g3271, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 4, edge E 1 5, edge E 1 6]
    apply (mask_ge_two (edge E 1 4) (edge E 1 5) (edge E 1 6)).mp
    change (((g11 E) && (g12 E)) || ((g11 E) && (g13 E)) || ((g12 E) && (g13 E)))=true
    simpa [g3272, g3273, g3274, g3275, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 4, edge E 2 5, edge E 2 6]
    apply (mask_ge_two (edge E 2 4) (edge E 2 5) (edge E 2 6)).mp
    change (((g16 E) && (g17 E)) || ((g16 E) && (g18 E)) || ((g17 E) && (g18 E)))=true
    simpa [g3276, g3277, g3278, g3279, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 4, edge E 3 5, edge E 3 6]
    apply (mask_ge_two (edge E 3 4) (edge E 3 5) (edge E 3 6)).mp
    change (((g20 E) && (g21 E)) || ((g20 E) && (g22 E)) || ((g21 E) && (g22 E)))=true
    simpa [g3280, g3281, g3282, g3283, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 4, edge E 7 5, edge E 7 6]
    apply (mask_ge_one (edge E 7 4) (edge E 7 5) (edge E 7 6)).mp
    change ((g26 E) || (g28 E) || (g29 E))=true
    simpa [g3284, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3733 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3287, .pos 3291, .pos 3295, .pos 3299, .pos 3300] := by
  change (¬ ((g3288 E)=true)) → (¬ ((g3292 E)=true)) → (¬ ((g3296 E)=true)) → (¬ ((g3300 E)=true)) → (¬ ((g3301 E)=true)) → False
  intro c0 c1 c2 c3 c6
  apply h
  refine ⟨4,5,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 4, edge E 0 5, edge E 0 7]
    apply (mask_ge_two (edge E 0 4) (edge E 0 5) (edge E 0 7)).mp
    change (((g5 E) && (g6 E)) || ((g5 E) && (g8 E)) || ((g6 E) && (g8 E)))=true
    simpa [g3285, g3286, g3287, g3288, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 4, edge E 1 5, edge E 1 7]
    apply (mask_ge_two (edge E 1 4) (edge E 1 5) (edge E 1 7)).mp
    change (((g11 E) && (g12 E)) || ((g11 E) && (g14 E)) || ((g12 E) && (g14 E)))=true
    simpa [g3289, g3290, g3291, g3292, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 4, edge E 2 5, edge E 2 7]
    apply (mask_ge_two (edge E 2 4) (edge E 2 5) (edge E 2 7)).mp
    change (((g16 E) && (g17 E)) || ((g16 E) && (g19 E)) || ((g17 E) && (g19 E)))=true
    simpa [g3293, g3294, g3295, g3296, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 4, edge E 3 5, edge E 3 7]
    apply (mask_ge_two (edge E 3 4) (edge E 3 5) (edge E 3 7)).mp
    change (((g20 E) && (g21 E)) || ((g20 E) && (g23 E)) || ((g21 E) && (g23 E)))=true
    simpa [g3297, g3298, g3299, g3300, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 6 4, edge E 6 5, edge E 6 7]
    apply (mask_ge_one (edge E 6 4) (edge E 6 5) (edge E 6 7)).mp
    change ((g25 E) || (g27 E) || (g29 E))=true
    simpa [g3301, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_3780 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3304, .pos 3308, .pos 3312, .pos 3316, .pos 3317] := by
  change (¬ ((g3305 E)=true)) → (¬ ((g3309 E)=true)) → (¬ ((g3313 E)=true)) → (¬ ((g3317 E)=true)) → (¬ ((g3318 E)=true)) → False
  intro c0 c1 c2 c3 c5
  apply h
  refine ⟨4,6,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 4, edge E 0 6, edge E 0 7]
    apply (mask_ge_two (edge E 0 4) (edge E 0 6) (edge E 0 7)).mp
    change (((g5 E) && (g7 E)) || ((g5 E) && (g8 E)) || ((g7 E) && (g8 E)))=true
    simpa [g3302, g3303, g3304, g3305, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 4, edge E 1 6, edge E 1 7]
    apply (mask_ge_two (edge E 1 4) (edge E 1 6) (edge E 1 7)).mp
    change (((g11 E) && (g13 E)) || ((g11 E) && (g14 E)) || ((g13 E) && (g14 E)))=true
    simpa [g3306, g3307, g3308, g3309, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 4, edge E 2 6, edge E 2 7]
    apply (mask_ge_two (edge E 2 4) (edge E 2 6) (edge E 2 7)).mp
    change (((g16 E) && (g18 E)) || ((g16 E) && (g19 E)) || ((g18 E) && (g19 E)))=true
    simpa [g3310, g3311, g3312, g3313, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 4, edge E 3 6, edge E 3 7]
    apply (mask_ge_two (edge E 3 4) (edge E 3 6) (edge E 3 7)).mp
    change (((g20 E) && (g22 E)) || ((g20 E) && (g23 E)) || ((g22 E) && (g23 E)))=true
    simpa [g3314, g3315, g3316, g3317, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (va rfl).elim
  · change 1≤countTrue [edge E 5 4, edge E 5 6, edge E 5 7]
    apply (mask_ge_one (edge E 5 4) (edge E 5 6) (edge E 5 7)).mp
    change ((g24 E) || (g27 E) || (g28 E))=true
    simpa [g3318, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
private theorem root_3836 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3321, .pos 3325, .pos 3329, .pos 3333, .pos 3337] := by
  change (¬ ((g3322 E)=true)) → (¬ ((g3326 E)=true)) → (¬ ((g3330 E)=true)) → (¬ ((g3334 E)=true)) → (¬ ((g3338 E)=true)) → False
  intro c0 c1 c2 c3 c4
  apply h
  refine ⟨5,6,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 5, edge E 0 6, edge E 0 7]
    apply (mask_ge_two (edge E 0 5) (edge E 0 6) (edge E 0 7)).mp
    change (((g6 E) && (g7 E)) || ((g6 E) && (g8 E)) || ((g7 E) && (g8 E)))=true
    simpa [g3319, g3320, g3321, g3322, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 5, edge E 1 6, edge E 1 7]
    apply (mask_ge_two (edge E 1 5) (edge E 1 6) (edge E 1 7)).mp
    change (((g12 E) && (g13 E)) || ((g12 E) && (g14 E)) || ((g13 E) && (g14 E)))=true
    simpa [g3323, g3324, g3325, g3326, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 5, edge E 2 6, edge E 2 7]
    apply (mask_ge_two (edge E 2 5) (edge E 2 6) (edge E 2 7)).mp
    change (((g17 E) && (g18 E)) || ((g17 E) && (g19 E)) || ((g18 E) && (g19 E)))=true
    simpa [g3327, g3328, g3329, g3330, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 5, edge E 3 6, edge E 3 7]
    apply (mask_ge_two (edge E 3 5) (edge E 3 6) (edge E 3 7)).mp
    change (((g21 E) && (g22 E)) || ((g21 E) && (g23 E)) || ((g22 E) && (g23 E)))=true
    simpa [g3331, g3332, g3333, g3334, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 5, edge E 4 6, edge E 4 7]
    apply (mask_ge_two (edge E 4 5) (edge E 4 6) (edge E 4 7)).mp
    change (((g24 E) && (g25 E)) || ((g24 E) && (g26 E)) || ((g25 E) && (g26 E)))=true
    simpa [g3335, g3336, g3337, g3338, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · exact (vc rfl).elim
theorem have_triple_of_exact_counts (E : Nat→Bool)
    (d0 : 3≤degree0_count E)
    (d1 : 3≤degree1_count E)
    (d2 : 3≤degree2_count E)
    (d3 : 3≤degree3_count E)
    (d4 : 3≤degree4_count E)
    (d5 : 3≤degree5_count E)
    (d6 : 3≤degree6_count E)
    (d7 : 3≤degree7_count E)
    (s0 : 2≤score0_count E)
    (s1 : 2≤score1_count E)
    (s2 : 2≤score2_count E)
    (o01 : score0_count E<score1_count E)
    (o12 : score1_count E<score2_count E)
    (o23 : score2_count E<score3_count E)
    (o34 : score3_count E<score4_count E)
    (p56 : portRank E 5≤portRank E 6)
    (p67 : portRank E 6≤portRank E 7)
    : HasTriple E := by
  by_contra n
  apply contradiction_of_semantic_roots E
  · exact root_32 E d0
  · exact root_74 E d1
  · exact root_106 E d2
  · exact root_138 E d3
  · exact root_151 E d4
  · exact root_184 E d5
  · exact root_217 E d6
  · exact root_247 E d7
  · exact root_2506 E s0
  · exact root_2507 E s1
  · exact root_2508 E s2
  · exact root_2509 E o01
  · exact root_2510 E o01
  · exact root_2511 E o01
  · exact root_2512 E o01
  · exact root_2513 E o12
  · exact root_2514 E o12
  · exact root_2515 E o12
  · exact root_2516 E o12
  · exact root_2517 E o12
  · exact root_2518 E o23
  · exact root_2519 E o23
  · exact root_2520 E o23
  · exact root_2521 E o23
  · exact root_2522 E o23
  · exact root_2523 E o23
  · exact root_2524 E o34
  · exact root_2525 E o34
  · exact root_2526 E o34
  · exact root_2527 E o34
  · exact root_2528 E o34
  · exact root_2529 E o34
  · exact root_2540 E p56
  · exact root_2550 E p67
  · exact root_2576 E n
  · exact root_2599 E n
  · exact root_2631 E n
  · exact root_2652 E n
  · exact root_2667 E n
  · exact root_2689 E n
  · exact root_2721 E n
  · exact root_2746 E n
  · exact root_2764 E n
  · exact root_2788 E n
  · exact root_2817 E n
  · exact root_2841 E n
  · exact root_2865 E n
  · exact root_2875 E n
  · exact root_2895 E n
  · exact root_2916 E n
  · exact root_2949 E n
  · exact root_2978 E n
  · exact root_2988 E n
  · exact root_3011 E n
  · exact root_3027 E n
  · exact root_3060 E n
  · exact root_3090 E n
  · exact root_3106 E n
  · exact root_3127 E n
  · exact root_3157 E n
  · exact root_3187 E n
  · exact root_3202 E n
  · exact root_3221 E n
  · exact root_3248 E n
  · exact root_3266 E n
  · exact root_3291 E n
  · exact root_3318 E n
  · exact root_3328 E n
  · exact root_3365 E n
  · exact root_3402 E n
  · exact root_3411 E n
  · exact root_3437 E n
  · exact root_3469 E n
  · exact root_3495 E n
  · exact root_3526 E n
  · exact root_3540 E n
  · exact root_3572 E n
  · exact root_3583 E n
  · exact root_3608 E n
  · exact root_3634 E n
  · exact root_3649 E n
  · exact root_3668 E n
  · exact root_3688 E n
  · exact root_3698 E n
  · exact root_3733 E n
  · exact root_3780 E n
  · exact root_3836 E n
#print axioms have_triple_of_exact_counts
end Graffiti384b.DiversityEleven.PendantCircuit.K5
