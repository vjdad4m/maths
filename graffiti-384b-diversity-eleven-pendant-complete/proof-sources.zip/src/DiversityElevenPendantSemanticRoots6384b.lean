import DiversityElevenPendantThresholds6384b
import DiversityElevenPendantWireClauses6384b
import Mathlib.Data.Finset.Card
import Mathlib.Tactic.FinCases
namespace Graffiti384b.DiversityEleven.PendantCircuit.K6
open Sat Finset
set_option maxRecDepth 32768
set_option maxHeartbeats 15000000
def edgeNumber (i j : Fin 8) : Nat :=
  let a := min i.val j.val
  let b := max i.val j.val
  2 + (a*(15-a))/2 + (b-a-1)
def edge (E : Nat→Bool) (i j : Fin 8) : Bool := if i=j then false else E (edgeNumber i j)
def portRank (E : Nat→Bool) (i : Fin 8) : Nat :=
  (if edge E 1 i then 1 else 0)+(if edge E 0 i then 2 else 0)
private theorem negWire (b : Bool) : ((!b)=true) ↔ ¬b=true := by cases b <;> decide
def HasTriple (E : Nat→Bool) : Prop :=
  ∃ a b c : Fin 8, a<b ∧ b<c ∧ ∀ v : Fin 8, v≠a → v≠b → v≠c →
    (if v.val < 6 then 2 else 1)≤countTrue [edge E v a,edge E v b,edge E v c]
private theorem root_34 (E : Nat→Bool) (h : 3≤degree0_count E) : (valuation E).satisfies [.neg 63] := by
  change ((g64 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree0_threshold7_2 E).mpr h) hn
private theorem root_65 (E : Nat→Bool) (h : 3≤degree1_count E) : (valuation E).satisfies [.neg 105] := by
  change ((g106 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree1_threshold7_2 E).mpr h) hn
private theorem root_96 (E : Nat→Bool) (h : 3≤degree2_count E) : (valuation E).satisfies [.neg 147] := by
  change ((g148 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree2_threshold7_2 E).mpr h) hn
private theorem root_117 (E : Nat→Bool) (h : 3≤degree3_count E) : (valuation E).satisfies [.neg 189] := by
  change ((g190 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree3_threshold7_2 E).mpr h) hn
private theorem root_140 (E : Nat→Bool) (h : 3≤degree4_count E) : (valuation E).satisfies [.neg 231] := by
  change ((g232 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree4_threshold7_2 E).mpr h) hn
private theorem root_181 (E : Nat→Bool) (h : 3≤degree6_count E) : (valuation E).satisfies [.neg 315] := by
  change ((g316 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree6_threshold7_2 E).mpr h) hn
private theorem root_217 (E : Nat→Bool) (h : 3≤degree7_count E) : (valuation E).satisfies [.neg 357] := by
  change ((g358 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree7_threshold7_2 E).mpr h) hn
private theorem root_3178 (E : Nat→Bool) (h : 2≤score0_count E) : (valuation E).satisfies [.neg 803] := by
  change ((g804 E)=true) → False
  intro hn
  exact (negWire _).mp ((score0_threshold21_1 E).mpr h) hn
private theorem root_3179 (E : Nat→Bool) (h : 2≤score1_count E) : (valuation E).satisfies [.neg 1223] := by
  change ((g1224 E)=true) → False
  intro hn
  exact (negWire _).mp ((score1_threshold21_1 E).mpr h) hn
private theorem root_3180 (E : Nat→Bool) (h : score0_count E<score1_count E) : (valuation E).satisfies [.neg 1225, .pos 803] := by
  change ((g1226 E)=true) → (¬ ((g804 E)=true)) → False
  intro fail old
  have oldScore := (score0_threshold21_1 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 1 h oldScore
  exact (negWire _).mp ((score1_threshold21_2 E).mpr newScore) fail
private theorem root_3181 (E : Nat→Bool) (h : score0_count E<score1_count E) : (valuation E).satisfies [.neg 1227, .pos 805] := by
  change ((g1228 E)=true) → (¬ ((g806 E)=true)) → False
  intro fail old
  have oldScore := (score0_threshold21_2 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 2 h oldScore
  exact (negWire _).mp ((score1_threshold21_3 E).mpr newScore) fail
private theorem root_3182 (E : Nat→Bool) (h : score0_count E<score1_count E) : (valuation E).satisfies [.neg 1229, .pos 807] := by
  change ((g1230 E)=true) → (¬ ((g808 E)=true)) → False
  intro fail old
  have oldScore := (score0_threshold21_3 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 3 h oldScore
  exact (negWire _).mp ((score1_threshold21_4 E).mpr newScore) fail
private theorem root_3183 (E : Nat→Bool) (h : score0_count E<score1_count E) : (valuation E).satisfies [.neg 1231, .pos 809] := by
  change ((g1232 E)=true) → (¬ ((g810 E)=true)) → False
  intro fail old
  have oldScore := (score0_threshold21_4 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 4 h oldScore
  exact (negWire _).mp ((score1_threshold21_5 E).mpr newScore) fail
private theorem root_3184 (E : Nat→Bool) (h : score0_count E<score1_count E) : (valuation E).satisfies [.neg 1233, .pos 811] := by
  change ((g1234 E)=true) → (¬ ((g812 E)=true)) → False
  intro fail old
  have oldScore := (score0_threshold21_5 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 5 h oldScore
  exact (negWire _).mp ((score1_threshold21_6 E).mpr newScore) fail
private theorem root_3185 (E : Nat→Bool) (h : score0_count E<score1_count E) : (valuation E).satisfies [.neg 1235, .pos 813] := by
  change ((g1236 E)=true) → (¬ ((g814 E)=true)) → False
  intro fail old
  have oldScore := (score0_threshold21_6 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 6 h oldScore
  exact (negWire _).mp ((score1_threshold21_7 E).mpr newScore) fail
private theorem root_3186 (E : Nat→Bool) (h : score1_count E<score2_count E) : (valuation E).satisfies [.neg 1645, .pos 1223] := by
  change ((g1646 E)=true) → (¬ ((g1224 E)=true)) → False
  intro fail old
  have oldScore := (score1_threshold21_1 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 1 h oldScore
  exact (negWire _).mp ((score2_threshold21_2 E).mpr newScore) fail
private theorem root_3187 (E : Nat→Bool) (h : score1_count E<score2_count E) : (valuation E).satisfies [.neg 1647, .pos 1225] := by
  change ((g1648 E)=true) → (¬ ((g1226 E)=true)) → False
  intro fail old
  have oldScore := (score1_threshold21_2 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 2 h oldScore
  exact (negWire _).mp ((score2_threshold21_3 E).mpr newScore) fail
private theorem root_3188 (E : Nat→Bool) (h : score1_count E<score2_count E) : (valuation E).satisfies [.neg 1649, .pos 1227] := by
  change ((g1650 E)=true) → (¬ ((g1228 E)=true)) → False
  intro fail old
  have oldScore := (score1_threshold21_3 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 3 h oldScore
  exact (negWire _).mp ((score2_threshold21_4 E).mpr newScore) fail
private theorem root_3189 (E : Nat→Bool) (h : score1_count E<score2_count E) : (valuation E).satisfies [.neg 1651, .pos 1229] := by
  change ((g1652 E)=true) → (¬ ((g1230 E)=true)) → False
  intro fail old
  have oldScore := (score1_threshold21_4 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 4 h oldScore
  exact (negWire _).mp ((score2_threshold21_5 E).mpr newScore) fail
private theorem root_3190 (E : Nat→Bool) (h : score1_count E<score2_count E) : (valuation E).satisfies [.neg 1653, .pos 1231] := by
  change ((g1654 E)=true) → (¬ ((g1232 E)=true)) → False
  intro fail old
  have oldScore := (score1_threshold21_5 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 5 h oldScore
  exact (negWire _).mp ((score2_threshold21_6 E).mpr newScore) fail
private theorem root_3191 (E : Nat→Bool) (h : score1_count E<score2_count E) : (valuation E).satisfies [.neg 1655, .pos 1233] := by
  change ((g1656 E)=true) → (¬ ((g1234 E)=true)) → False
  intro fail old
  have oldScore := (score1_threshold21_6 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 6 h oldScore
  exact (negWire _).mp ((score2_threshold21_7 E).mpr newScore) fail
private theorem root_3192 (E : Nat→Bool) (h : score1_count E<score2_count E) : (valuation E).satisfies [.neg 1657, .pos 1235] := by
  change ((g1658 E)=true) → (¬ ((g1236 E)=true)) → False
  intro fail old
  have oldScore := (score1_threshold21_7 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 7 h oldScore
  exact (negWire _).mp ((score2_threshold21_8 E).mpr newScore) fail
private theorem root_3193 (E : Nat→Bool) (h : score2_count E<score3_count E) : (valuation E).satisfies [.neg 2067, .pos 1645] := by
  change ((g2068 E)=true) → (¬ ((g1646 E)=true)) → False
  intro fail old
  have oldScore := (score2_threshold21_2 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 2 h oldScore
  exact (negWire _).mp ((score3_threshold21_3 E).mpr newScore) fail
private theorem root_3194 (E : Nat→Bool) (h : score2_count E<score3_count E) : (valuation E).satisfies [.neg 2069, .pos 1647] := by
  change ((g2070 E)=true) → (¬ ((g1648 E)=true)) → False
  intro fail old
  have oldScore := (score2_threshold21_3 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 3 h oldScore
  exact (negWire _).mp ((score3_threshold21_4 E).mpr newScore) fail
private theorem root_3195 (E : Nat→Bool) (h : score2_count E<score3_count E) : (valuation E).satisfies [.neg 2071, .pos 1649] := by
  change ((g2072 E)=true) → (¬ ((g1650 E)=true)) → False
  intro fail old
  have oldScore := (score2_threshold21_4 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 4 h oldScore
  exact (negWire _).mp ((score3_threshold21_5 E).mpr newScore) fail
private theorem root_3196 (E : Nat→Bool) (h : score2_count E<score3_count E) : (valuation E).satisfies [.neg 2073, .pos 1651] := by
  change ((g2074 E)=true) → (¬ ((g1652 E)=true)) → False
  intro fail old
  have oldScore := (score2_threshold21_5 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 5 h oldScore
  exact (negWire _).mp ((score3_threshold21_6 E).mpr newScore) fail
private theorem root_3197 (E : Nat→Bool) (h : score2_count E<score3_count E) : (valuation E).satisfies [.neg 2075, .pos 1653] := by
  change ((g2076 E)=true) → (¬ ((g1654 E)=true)) → False
  intro fail old
  have oldScore := (score2_threshold21_6 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 6 h oldScore
  exact (negWire _).mp ((score3_threshold21_7 E).mpr newScore) fail
private theorem root_3198 (E : Nat→Bool) (h : score2_count E<score3_count E) : (valuation E).satisfies [.neg 2077, .pos 1655] := by
  change ((g2078 E)=true) → (¬ ((g1656 E)=true)) → False
  intro fail old
  have oldScore := (score2_threshold21_7 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 7 h oldScore
  exact (negWire _).mp ((score3_threshold21_8 E).mpr newScore) fail
private theorem root_3199 (E : Nat→Bool) (h : score2_count E<score3_count E) : (valuation E).satisfies [.neg 2079, .pos 1657] := by
  change ((g2080 E)=true) → (¬ ((g1658 E)=true)) → False
  intro fail old
  have oldScore := (score2_threshold21_8 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 8 h oldScore
  exact (negWire _).mp ((score3_threshold21_9 E).mpr newScore) fail
private theorem root_3200 (E : Nat→Bool) (h : score3_count E<score4_count E) : (valuation E).satisfies [.neg 2489, .pos 2067] := by
  change ((g2490 E)=true) → (¬ ((g2068 E)=true)) → False
  intro fail old
  have oldScore := (score3_threshold21_3 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 3 h oldScore
  exact (negWire _).mp ((score4_threshold21_4 E).mpr newScore) fail
private theorem root_3201 (E : Nat→Bool) (h : score3_count E<score4_count E) : (valuation E).satisfies [.neg 2491, .pos 2069] := by
  change ((g2492 E)=true) → (¬ ((g2070 E)=true)) → False
  intro fail old
  have oldScore := (score3_threshold21_4 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 4 h oldScore
  exact (negWire _).mp ((score4_threshold21_5 E).mpr newScore) fail
private theorem root_3202 (E : Nat→Bool) (h : score3_count E<score4_count E) : (valuation E).satisfies [.neg 2493, .pos 2071] := by
  change ((g2494 E)=true) → (¬ ((g2072 E)=true)) → False
  intro fail old
  have oldScore := (score3_threshold21_5 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 5 h oldScore
  exact (negWire _).mp ((score4_threshold21_6 E).mpr newScore) fail
private theorem root_3203 (E : Nat→Bool) (h : score3_count E<score4_count E) : (valuation E).satisfies [.neg 2495, .pos 2073] := by
  change ((g2496 E)=true) → (¬ ((g2074 E)=true)) → False
  intro fail old
  have oldScore := (score3_threshold21_6 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 6 h oldScore
  exact (negWire _).mp ((score4_threshold21_7 E).mpr newScore) fail
private theorem root_3204 (E : Nat→Bool) (h : score3_count E<score4_count E) : (valuation E).satisfies [.neg 2497, .pos 2075] := by
  change ((g2498 E)=true) → (¬ ((g2076 E)=true)) → False
  intro fail old
  have oldScore := (score3_threshold21_7 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 7 h oldScore
  exact (negWire _).mp ((score4_threshold21_8 E).mpr newScore) fail
private theorem root_3205 (E : Nat→Bool) (h : score3_count E<score4_count E) : (valuation E).satisfies [.neg 2499, .pos 2077] := by
  change ((g2500 E)=true) → (¬ ((g2078 E)=true)) → False
  intro fail old
  have oldScore := (score3_threshold21_8 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 8 h oldScore
  exact (negWire _).mp ((score4_threshold21_9 E).mpr newScore) fail
private theorem root_3206 (E : Nat→Bool) (h : score3_count E<score4_count E) : (valuation E).satisfies [.neg 2501, .pos 2079] := by
  change ((g2502 E)=true) → (¬ ((g2080 E)=true)) → False
  intro fail old
  have oldScore := (score3_threshold21_9 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 9 h oldScore
  exact (negWire _).mp ((score4_threshold21_10 E).mpr newScore) fail
private theorem root_3207 (E : Nat→Bool) (h : score4_count E<score5_count E) : (valuation E).satisfies [.neg 2911, .pos 2489] := by
  change ((g2912 E)=true) → (¬ ((g2490 E)=true)) → False
  intro fail old
  have oldScore := (score4_threshold21_4 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 4 h oldScore
  exact (negWire _).mp ((score5_threshold21_5 E).mpr newScore) fail
private theorem root_3208 (E : Nat→Bool) (h : score4_count E<score5_count E) : (valuation E).satisfies [.neg 2913, .pos 2491] := by
  change ((g2914 E)=true) → (¬ ((g2492 E)=true)) → False
  intro fail old
  have oldScore := (score4_threshold21_5 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 5 h oldScore
  exact (negWire _).mp ((score5_threshold21_6 E).mpr newScore) fail
private theorem root_3209 (E : Nat→Bool) (h : score4_count E<score5_count E) : (valuation E).satisfies [.neg 2915, .pos 2493] := by
  change ((g2916 E)=true) → (¬ ((g2494 E)=true)) → False
  intro fail old
  have oldScore := (score4_threshold21_6 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 6 h oldScore
  exact (negWire _).mp ((score5_threshold21_7 E).mpr newScore) fail
private theorem root_3210 (E : Nat→Bool) (h : score4_count E<score5_count E) : (valuation E).satisfies [.neg 2917, .pos 2495] := by
  change ((g2918 E)=true) → (¬ ((g2496 E)=true)) → False
  intro fail old
  have oldScore := (score4_threshold21_7 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 7 h oldScore
  exact (negWire _).mp ((score5_threshold21_8 E).mpr newScore) fail
private theorem root_3211 (E : Nat→Bool) (h : score4_count E<score5_count E) : (valuation E).satisfies [.neg 2919, .pos 2497] := by
  change ((g2920 E)=true) → (¬ ((g2498 E)=true)) → False
  intro fail old
  have oldScore := (score4_threshold21_8 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 8 h oldScore
  exact (negWire _).mp ((score5_threshold21_9 E).mpr newScore) fail
private theorem root_3212 (E : Nat→Bool) (h : score4_count E<score5_count E) : (valuation E).satisfies [.neg 2921, .pos 2499] := by
  change ((g2922 E)=true) → (¬ ((g2500 E)=true)) → False
  intro fail old
  have oldScore := (score4_threshold21_9 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 9 h oldScore
  exact (negWire _).mp ((score5_threshold21_10 E).mpr newScore) fail
private theorem root_3213 (E : Nat→Bool) (h : score4_count E<score5_count E) : (valuation E).satisfies [.neg 2923, .pos 2501] := by
  change ((g2924 E)=true) → (¬ ((g2502 E)=true)) → False
  intro fail old
  have oldScore := (score4_threshold21_10 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 10 h oldScore
  exact (negWire _).mp ((score5_threshold21_11 E).mpr newScore) fail
private theorem root_3223 (E : Nat→Bool) (h : portRank E 6≤portRank E 7) : (valuation E).satisfies [.pos 2946] := by
  change (¬ ((g2947 E)=true)) → False
  intro contrary
  change (if (g13 E) then 1 else 0) + (if (g7 E) then 2 else 0) ≤ (if (g14 E) then 1 else 0) + (if (g8 E) then 2 else 0) at h
  cases q13 : g13 E <;> cases q7 : g7 E <;> cases q14 : g14 E <;> cases q8 : g8 E <;> simp [g2942,g2943,g2944,g2945,g2946,g2947,q13,q7,q14,q8] at h contrary
private theorem root_3260 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2950, .pos 2954, .pos 2958, .pos 2959, .pos 2960] := by
  change (¬ ((g2951 E)=true)) → (¬ ((g2955 E)=true)) → (¬ ((g2959 E)=true)) → (¬ ((g2960 E)=true)) → (¬ ((g2961 E)=true)) → False
  intro c3 c4 c5 c6 c7
  apply h
  refine ⟨0,1,2,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 2≤countTrue [edge E 3 0, edge E 3 1, edge E 3 2]
    apply (mask_ge_two (edge E 3 0) (edge E 3 1) (edge E 3 2)).mp
    change (((g4 E) && (g10 E)) || ((g4 E) && (g15 E)) || ((g10 E) && (g15 E)))=true
    simpa [g2948, g2949, g2950, g2951, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 0, edge E 4 1, edge E 4 2]
    apply (mask_ge_two (edge E 4 0) (edge E 4 1) (edge E 4 2)).mp
    change (((g5 E) && (g11 E)) || ((g5 E) && (g16 E)) || ((g11 E) && (g16 E)))=true
    simpa [g2952, g2953, g2954, g2955, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 2≤countTrue [edge E 5 0, edge E 5 1, edge E 5 2]
    apply (mask_ge_two (edge E 5 0) (edge E 5 1) (edge E 5 2)).mp
    change (((g6 E) && (g12 E)) || ((g6 E) && (g17 E)) || ((g12 E) && (g17 E)))=true
    simpa [g2956, g2957, g2958, g2959, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 1, edge E 6 2]
    apply (mask_ge_one (edge E 6 0) (edge E 6 1) (edge E 6 2)).mp
    change ((g7 E) || (g13 E) || (g18 E))=true
    simpa [g2960, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 1, edge E 7 2]
    apply (mask_ge_one (edge E 7 0) (edge E 7 1) (edge E 7 2)).mp
    change ((g8 E) || (g14 E) || (g19 E))=true
    simpa [g2961, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3290 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2964, .pos 2968, .pos 2972, .pos 2973, .pos 2974] := by
  change (¬ ((g2965 E)=true)) → (¬ ((g2969 E)=true)) → (¬ ((g2973 E)=true)) → (¬ ((g2974 E)=true)) → (¬ ((g2975 E)=true)) → False
  intro c2 c4 c5 c6 c7
  apply h
  refine ⟨0,1,3,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 2 0, edge E 2 1, edge E 2 3]
    apply (mask_ge_two (edge E 2 0) (edge E 2 1) (edge E 2 3)).mp
    change (((g3 E) && (g9 E)) || ((g3 E) && (g15 E)) || ((g9 E) && (g15 E)))=true
    simpa [g2962, g2963, g2964, g2965, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vc rfl).elim
  · change 2≤countTrue [edge E 4 0, edge E 4 1, edge E 4 3]
    apply (mask_ge_two (edge E 4 0) (edge E 4 1) (edge E 4 3)).mp
    change (((g5 E) && (g11 E)) || ((g5 E) && (g20 E)) || ((g11 E) && (g20 E)))=true
    simpa [g2966, g2967, g2968, g2969, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 2≤countTrue [edge E 5 0, edge E 5 1, edge E 5 3]
    apply (mask_ge_two (edge E 5 0) (edge E 5 1) (edge E 5 3)).mp
    change (((g6 E) && (g12 E)) || ((g6 E) && (g21 E)) || ((g12 E) && (g21 E)))=true
    simpa [g2970, g2971, g2972, g2973, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 1, edge E 6 3]
    apply (mask_ge_one (edge E 6 0) (edge E 6 1) (edge E 6 3)).mp
    change ((g7 E) || (g13 E) || (g22 E))=true
    simpa [g2974, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 1, edge E 7 3]
    apply (mask_ge_one (edge E 7 0) (edge E 7 1) (edge E 7 3)).mp
    change ((g8 E) || (g14 E) || (g23 E))=true
    simpa [g2975, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3318 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2978, .pos 2982, .pos 2986, .pos 2987, .pos 2988] := by
  change (¬ ((g2979 E)=true)) → (¬ ((g2983 E)=true)) → (¬ ((g2987 E)=true)) → (¬ ((g2988 E)=true)) → (¬ ((g2989 E)=true)) → False
  intro c2 c3 c5 c6 c7
  apply h
  refine ⟨0,1,4,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 2 0, edge E 2 1, edge E 2 4]
    apply (mask_ge_two (edge E 2 0) (edge E 2 1) (edge E 2 4)).mp
    change (((g3 E) && (g9 E)) || ((g3 E) && (g16 E)) || ((g9 E) && (g16 E)))=true
    simpa [g2976, g2977, g2978, g2979, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 1, edge E 3 4]
    apply (mask_ge_two (edge E 3 0) (edge E 3 1) (edge E 3 4)).mp
    change (((g4 E) && (g10 E)) || ((g4 E) && (g20 E)) || ((g10 E) && (g20 E)))=true
    simpa [g2980, g2981, g2982, g2983, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vc rfl).elim
  · change 2≤countTrue [edge E 5 0, edge E 5 1, edge E 5 4]
    apply (mask_ge_two (edge E 5 0) (edge E 5 1) (edge E 5 4)).mp
    change (((g6 E) && (g12 E)) || ((g6 E) && (g24 E)) || ((g12 E) && (g24 E)))=true
    simpa [g2984, g2985, g2986, g2987, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 1, edge E 6 4]
    apply (mask_ge_one (edge E 6 0) (edge E 6 1) (edge E 6 4)).mp
    change ((g7 E) || (g13 E) || (g25 E))=true
    simpa [g2988, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 1, edge E 7 4]
    apply (mask_ge_one (edge E 7 0) (edge E 7 1) (edge E 7 4)).mp
    change ((g8 E) || (g14 E) || (g26 E))=true
    simpa [g2989, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3359 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2992, .pos 2996, .pos 3000, .pos 3001, .pos 3002] := by
  change (¬ ((g2993 E)=true)) → (¬ ((g2997 E)=true)) → (¬ ((g3001 E)=true)) → (¬ ((g3002 E)=true)) → (¬ ((g3003 E)=true)) → False
  intro c2 c3 c4 c6 c7
  apply h
  refine ⟨0,1,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 2 0, edge E 2 1, edge E 2 5]
    apply (mask_ge_two (edge E 2 0) (edge E 2 1) (edge E 2 5)).mp
    change (((g3 E) && (g9 E)) || ((g3 E) && (g17 E)) || ((g9 E) && (g17 E)))=true
    simpa [g2990, g2991, g2992, g2993, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 1, edge E 3 5]
    apply (mask_ge_two (edge E 3 0) (edge E 3 1) (edge E 3 5)).mp
    change (((g4 E) && (g10 E)) || ((g4 E) && (g21 E)) || ((g10 E) && (g21 E)))=true
    simpa [g2994, g2995, g2996, g2997, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 0, edge E 4 1, edge E 4 5]
    apply (mask_ge_two (edge E 4 0) (edge E 4 1) (edge E 4 5)).mp
    change (((g5 E) && (g11 E)) || ((g5 E) && (g24 E)) || ((g11 E) && (g24 E)))=true
    simpa [g2998, g2999, g3000, g3001, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 0, edge E 6 1, edge E 6 5]
    apply (mask_ge_one (edge E 6 0) (edge E 6 1) (edge E 6 5)).mp
    change ((g7 E) || (g13 E) || (g27 E))=true
    simpa [g3002, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 1, edge E 7 5]
    apply (mask_ge_one (edge E 7 0) (edge E 7 1) (edge E 7 5)).mp
    change ((g8 E) || (g14 E) || (g28 E))=true
    simpa [g3003, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3379 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3006, .pos 3010, .pos 3014, .pos 3018, .pos 3019] := by
  change (¬ ((g3007 E)=true)) → (¬ ((g3011 E)=true)) → (¬ ((g3015 E)=true)) → (¬ ((g3019 E)=true)) → (¬ ((g3020 E)=true)) → False
  intro c2 c3 c4 c5 c7
  apply h
  refine ⟨0,1,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 2 0, edge E 2 1, edge E 2 6]
    apply (mask_ge_two (edge E 2 0) (edge E 2 1) (edge E 2 6)).mp
    change (((g3 E) && (g9 E)) || ((g3 E) && (g18 E)) || ((g9 E) && (g18 E)))=true
    simpa [g3004, g3005, g3006, g3007, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 1, edge E 3 6]
    apply (mask_ge_two (edge E 3 0) (edge E 3 1) (edge E 3 6)).mp
    change (((g4 E) && (g10 E)) || ((g4 E) && (g22 E)) || ((g10 E) && (g22 E)))=true
    simpa [g3008, g3009, g3010, g3011, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 0, edge E 4 1, edge E 4 6]
    apply (mask_ge_two (edge E 4 0) (edge E 4 1) (edge E 4 6)).mp
    change (((g5 E) && (g11 E)) || ((g5 E) && (g25 E)) || ((g11 E) && (g25 E)))=true
    simpa [g3012, g3013, g3014, g3015, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 2≤countTrue [edge E 5 0, edge E 5 1, edge E 5 6]
    apply (mask_ge_two (edge E 5 0) (edge E 5 1) (edge E 5 6)).mp
    change (((g6 E) && (g12 E)) || ((g6 E) && (g27 E)) || ((g12 E) && (g27 E)))=true
    simpa [g3016, g3017, g3018, g3019, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 0, edge E 7 1, edge E 7 6]
    apply (mask_ge_one (edge E 7 0) (edge E 7 1) (edge E 7 6)).mp
    change ((g8 E) || (g14 E) || (g29 E))=true
    simpa [g3020, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3398 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3023, .pos 3027, .pos 3031, .pos 3035, .pos 3036] := by
  change (¬ ((g3024 E)=true)) → (¬ ((g3028 E)=true)) → (¬ ((g3032 E)=true)) → (¬ ((g3036 E)=true)) → (¬ ((g3037 E)=true)) → False
  intro c2 c3 c4 c5 c6
  apply h
  refine ⟨0,1,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 2 0, edge E 2 1, edge E 2 7]
    apply (mask_ge_two (edge E 2 0) (edge E 2 1) (edge E 2 7)).mp
    change (((g3 E) && (g9 E)) || ((g3 E) && (g19 E)) || ((g9 E) && (g19 E)))=true
    simpa [g3021, g3022, g3023, g3024, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 1, edge E 3 7]
    apply (mask_ge_two (edge E 3 0) (edge E 3 1) (edge E 3 7)).mp
    change (((g4 E) && (g10 E)) || ((g4 E) && (g23 E)) || ((g10 E) && (g23 E)))=true
    simpa [g3025, g3026, g3027, g3028, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 0, edge E 4 1, edge E 4 7]
    apply (mask_ge_two (edge E 4 0) (edge E 4 1) (edge E 4 7)).mp
    change (((g5 E) && (g11 E)) || ((g5 E) && (g26 E)) || ((g11 E) && (g26 E)))=true
    simpa [g3029, g3030, g3031, g3032, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 2≤countTrue [edge E 5 0, edge E 5 1, edge E 5 7]
    apply (mask_ge_two (edge E 5 0) (edge E 5 1) (edge E 5 7)).mp
    change (((g6 E) && (g12 E)) || ((g6 E) && (g28 E)) || ((g12 E) && (g28 E)))=true
    simpa [g3033, g3034, g3035, g3036, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 1, edge E 6 7]
    apply (mask_ge_one (edge E 6 0) (edge E 6 1) (edge E 6 7)).mp
    change ((g7 E) || (g13 E) || (g29 E))=true
    simpa [g3037, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_3431 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3040, .pos 3044, .pos 3048, .pos 3049, .pos 3050] := by
  change (¬ ((g3041 E)=true)) → (¬ ((g3045 E)=true)) → (¬ ((g3049 E)=true)) → (¬ ((g3050 E)=true)) → (¬ ((g3051 E)=true)) → False
  intro c1 c4 c5 c6 c7
  apply h
  refine ⟨0,2,3,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 2, edge E 1 3]
    apply (mask_ge_two (edge E 1 0) (edge E 1 2) (edge E 1 3)).mp
    change (((g2 E) && (g9 E)) || ((g2 E) && (g10 E)) || ((g9 E) && (g10 E)))=true
    simpa [g3038, g3039, g3040, g3041, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 2≤countTrue [edge E 4 0, edge E 4 2, edge E 4 3]
    apply (mask_ge_two (edge E 4 0) (edge E 4 2) (edge E 4 3)).mp
    change (((g5 E) && (g16 E)) || ((g5 E) && (g20 E)) || ((g16 E) && (g20 E)))=true
    simpa [g3042, g3043, g3044, g3045, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 2≤countTrue [edge E 5 0, edge E 5 2, edge E 5 3]
    apply (mask_ge_two (edge E 5 0) (edge E 5 2) (edge E 5 3)).mp
    change (((g6 E) && (g17 E)) || ((g6 E) && (g21 E)) || ((g17 E) && (g21 E)))=true
    simpa [g3046, g3047, g3048, g3049, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 2, edge E 6 3]
    apply (mask_ge_one (edge E 6 0) (edge E 6 2) (edge E 6 3)).mp
    change ((g7 E) || (g18 E) || (g22 E))=true
    simpa [g3050, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 2, edge E 7 3]
    apply (mask_ge_one (edge E 7 0) (edge E 7 2) (edge E 7 3)).mp
    change ((g8 E) || (g19 E) || (g23 E))=true
    simpa [g3051, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3467 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3054, .pos 3058, .pos 3062, .pos 3063, .pos 3064] := by
  change (¬ ((g3055 E)=true)) → (¬ ((g3059 E)=true)) → (¬ ((g3063 E)=true)) → (¬ ((g3064 E)=true)) → (¬ ((g3065 E)=true)) → False
  intro c1 c3 c5 c6 c7
  apply h
  refine ⟨0,2,4,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 2, edge E 1 4]
    apply (mask_ge_two (edge E 1 0) (edge E 1 2) (edge E 1 4)).mp
    change (((g2 E) && (g9 E)) || ((g2 E) && (g11 E)) || ((g9 E) && (g11 E)))=true
    simpa [g3052, g3053, g3054, g3055, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 3 0, edge E 3 2, edge E 3 4]
    apply (mask_ge_two (edge E 3 0) (edge E 3 2) (edge E 3 4)).mp
    change (((g4 E) && (g15 E)) || ((g4 E) && (g20 E)) || ((g15 E) && (g20 E)))=true
    simpa [g3056, g3057, g3058, g3059, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vc rfl).elim
  · change 2≤countTrue [edge E 5 0, edge E 5 2, edge E 5 4]
    apply (mask_ge_two (edge E 5 0) (edge E 5 2) (edge E 5 4)).mp
    change (((g6 E) && (g17 E)) || ((g6 E) && (g24 E)) || ((g17 E) && (g24 E)))=true
    simpa [g3060, g3061, g3062, g3063, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 2, edge E 6 4]
    apply (mask_ge_one (edge E 6 0) (edge E 6 2) (edge E 6 4)).mp
    change ((g7 E) || (g18 E) || (g25 E))=true
    simpa [g3064, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 2, edge E 7 4]
    apply (mask_ge_one (edge E 7 0) (edge E 7 2) (edge E 7 4)).mp
    change ((g8 E) || (g19 E) || (g26 E))=true
    simpa [g3065, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3497 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3068, .pos 3072, .pos 3076, .pos 3077, .pos 3078] := by
  change (¬ ((g3069 E)=true)) → (¬ ((g3073 E)=true)) → (¬ ((g3077 E)=true)) → (¬ ((g3078 E)=true)) → (¬ ((g3079 E)=true)) → False
  intro c1 c3 c4 c6 c7
  apply h
  refine ⟨0,2,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 2, edge E 1 5]
    apply (mask_ge_two (edge E 1 0) (edge E 1 2) (edge E 1 5)).mp
    change (((g2 E) && (g9 E)) || ((g2 E) && (g12 E)) || ((g9 E) && (g12 E)))=true
    simpa [g3066, g3067, g3068, g3069, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 3 0, edge E 3 2, edge E 3 5]
    apply (mask_ge_two (edge E 3 0) (edge E 3 2) (edge E 3 5)).mp
    change (((g4 E) && (g15 E)) || ((g4 E) && (g21 E)) || ((g15 E) && (g21 E)))=true
    simpa [g3070, g3071, g3072, g3073, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 0, edge E 4 2, edge E 4 5]
    apply (mask_ge_two (edge E 4 0) (edge E 4 2) (edge E 4 5)).mp
    change (((g5 E) && (g16 E)) || ((g5 E) && (g24 E)) || ((g16 E) && (g24 E)))=true
    simpa [g3074, g3075, g3076, g3077, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 0, edge E 6 2, edge E 6 5]
    apply (mask_ge_one (edge E 6 0) (edge E 6 2) (edge E 6 5)).mp
    change ((g7 E) || (g18 E) || (g27 E))=true
    simpa [g3078, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 2, edge E 7 5]
    apply (mask_ge_one (edge E 7 0) (edge E 7 2) (edge E 7 5)).mp
    change ((g8 E) || (g19 E) || (g28 E))=true
    simpa [g3079, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3523 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3082, .pos 3086, .pos 3090, .pos 3094, .pos 3095] := by
  change (¬ ((g3083 E)=true)) → (¬ ((g3087 E)=true)) → (¬ ((g3091 E)=true)) → (¬ ((g3095 E)=true)) → (¬ ((g3096 E)=true)) → False
  intro c1 c3 c4 c5 c7
  apply h
  refine ⟨0,2,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 2, edge E 1 6]
    apply (mask_ge_two (edge E 1 0) (edge E 1 2) (edge E 1 6)).mp
    change (((g2 E) && (g9 E)) || ((g2 E) && (g13 E)) || ((g9 E) && (g13 E)))=true
    simpa [g3080, g3081, g3082, g3083, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 3 0, edge E 3 2, edge E 3 6]
    apply (mask_ge_two (edge E 3 0) (edge E 3 2) (edge E 3 6)).mp
    change (((g4 E) && (g15 E)) || ((g4 E) && (g22 E)) || ((g15 E) && (g22 E)))=true
    simpa [g3084, g3085, g3086, g3087, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 0, edge E 4 2, edge E 4 6]
    apply (mask_ge_two (edge E 4 0) (edge E 4 2) (edge E 4 6)).mp
    change (((g5 E) && (g16 E)) || ((g5 E) && (g25 E)) || ((g16 E) && (g25 E)))=true
    simpa [g3088, g3089, g3090, g3091, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 2≤countTrue [edge E 5 0, edge E 5 2, edge E 5 6]
    apply (mask_ge_two (edge E 5 0) (edge E 5 2) (edge E 5 6)).mp
    change (((g6 E) && (g17 E)) || ((g6 E) && (g27 E)) || ((g17 E) && (g27 E)))=true
    simpa [g3092, g3093, g3094, g3095, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 0, edge E 7 2, edge E 7 6]
    apply (mask_ge_one (edge E 7 0) (edge E 7 2) (edge E 7 6)).mp
    change ((g8 E) || (g19 E) || (g29 E))=true
    simpa [g3096, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3563 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3099, .pos 3103, .pos 3107, .pos 3111, .pos 3112] := by
  change (¬ ((g3100 E)=true)) → (¬ ((g3104 E)=true)) → (¬ ((g3108 E)=true)) → (¬ ((g3112 E)=true)) → (¬ ((g3113 E)=true)) → False
  intro c1 c3 c4 c5 c6
  apply h
  refine ⟨0,2,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 2, edge E 1 7]
    apply (mask_ge_two (edge E 1 0) (edge E 1 2) (edge E 1 7)).mp
    change (((g2 E) && (g9 E)) || ((g2 E) && (g14 E)) || ((g9 E) && (g14 E)))=true
    simpa [g3097, g3098, g3099, g3100, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 3 0, edge E 3 2, edge E 3 7]
    apply (mask_ge_two (edge E 3 0) (edge E 3 2) (edge E 3 7)).mp
    change (((g4 E) && (g15 E)) || ((g4 E) && (g23 E)) || ((g15 E) && (g23 E)))=true
    simpa [g3101, g3102, g3103, g3104, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 0, edge E 4 2, edge E 4 7]
    apply (mask_ge_two (edge E 4 0) (edge E 4 2) (edge E 4 7)).mp
    change (((g5 E) && (g16 E)) || ((g5 E) && (g26 E)) || ((g16 E) && (g26 E)))=true
    simpa [g3105, g3106, g3107, g3108, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 2≤countTrue [edge E 5 0, edge E 5 2, edge E 5 7]
    apply (mask_ge_two (edge E 5 0) (edge E 5 2) (edge E 5 7)).mp
    change (((g6 E) && (g17 E)) || ((g6 E) && (g28 E)) || ((g17 E) && (g28 E)))=true
    simpa [g3109, g3110, g3111, g3112, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 2, edge E 6 7]
    apply (mask_ge_one (edge E 6 0) (edge E 6 2) (edge E 6 7)).mp
    change ((g7 E) || (g18 E) || (g29 E))=true
    simpa [g3113, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_3591 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3116, .pos 3120, .pos 3124, .pos 3125, .pos 3126] := by
  change (¬ ((g3117 E)=true)) → (¬ ((g3121 E)=true)) → (¬ ((g3125 E)=true)) → (¬ ((g3126 E)=true)) → (¬ ((g3127 E)=true)) → False
  intro c1 c2 c5 c6 c7
  apply h
  refine ⟨0,3,4,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 3, edge E 1 4]
    apply (mask_ge_two (edge E 1 0) (edge E 1 3) (edge E 1 4)).mp
    change (((g2 E) && (g10 E)) || ((g2 E) && (g11 E)) || ((g10 E) && (g11 E)))=true
    simpa [g3114, g3115, g3116, g3117, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 3, edge E 2 4]
    apply (mask_ge_two (edge E 2 0) (edge E 2 3) (edge E 2 4)).mp
    change (((g3 E) && (g15 E)) || ((g3 E) && (g16 E)) || ((g15 E) && (g16 E)))=true
    simpa [g3118, g3119, g3120, g3121, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 2≤countTrue [edge E 5 0, edge E 5 3, edge E 5 4]
    apply (mask_ge_two (edge E 5 0) (edge E 5 3) (edge E 5 4)).mp
    change (((g6 E) && (g21 E)) || ((g6 E) && (g24 E)) || ((g21 E) && (g24 E)))=true
    simpa [g3122, g3123, g3124, g3125, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 3, edge E 6 4]
    apply (mask_ge_one (edge E 6 0) (edge E 6 3) (edge E 6 4)).mp
    change ((g7 E) || (g22 E) || (g25 E))=true
    simpa [g3126, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 3, edge E 7 4]
    apply (mask_ge_one (edge E 7 0) (edge E 7 3) (edge E 7 4)).mp
    change ((g8 E) || (g23 E) || (g26 E))=true
    simpa [g3127, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3623 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3130, .pos 3134, .pos 3138, .pos 3139, .pos 3140] := by
  change (¬ ((g3131 E)=true)) → (¬ ((g3135 E)=true)) → (¬ ((g3139 E)=true)) → (¬ ((g3140 E)=true)) → (¬ ((g3141 E)=true)) → False
  intro c1 c2 c4 c6 c7
  apply h
  refine ⟨0,3,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 3, edge E 1 5]
    apply (mask_ge_two (edge E 1 0) (edge E 1 3) (edge E 1 5)).mp
    change (((g2 E) && (g10 E)) || ((g2 E) && (g12 E)) || ((g10 E) && (g12 E)))=true
    simpa [g3128, g3129, g3130, g3131, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 3, edge E 2 5]
    apply (mask_ge_two (edge E 2 0) (edge E 2 3) (edge E 2 5)).mp
    change (((g3 E) && (g15 E)) || ((g3 E) && (g17 E)) || ((g15 E) && (g17 E)))=true
    simpa [g3132, g3133, g3134, g3135, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 4 0, edge E 4 3, edge E 4 5]
    apply (mask_ge_two (edge E 4 0) (edge E 4 3) (edge E 4 5)).mp
    change (((g5 E) && (g20 E)) || ((g5 E) && (g24 E)) || ((g20 E) && (g24 E)))=true
    simpa [g3136, g3137, g3138, g3139, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 0, edge E 6 3, edge E 6 5]
    apply (mask_ge_one (edge E 6 0) (edge E 6 3) (edge E 6 5)).mp
    change ((g7 E) || (g22 E) || (g27 E))=true
    simpa [g3140, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 3, edge E 7 5]
    apply (mask_ge_one (edge E 7 0) (edge E 7 3) (edge E 7 5)).mp
    change ((g8 E) || (g23 E) || (g28 E))=true
    simpa [g3141, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3651 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3144, .pos 3148, .pos 3152, .pos 3156, .pos 3157] := by
  change (¬ ((g3145 E)=true)) → (¬ ((g3149 E)=true)) → (¬ ((g3153 E)=true)) → (¬ ((g3157 E)=true)) → (¬ ((g3158 E)=true)) → False
  intro c1 c2 c4 c5 c7
  apply h
  refine ⟨0,3,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 3, edge E 1 6]
    apply (mask_ge_two (edge E 1 0) (edge E 1 3) (edge E 1 6)).mp
    change (((g2 E) && (g10 E)) || ((g2 E) && (g13 E)) || ((g10 E) && (g13 E)))=true
    simpa [g3142, g3143, g3144, g3145, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 3, edge E 2 6]
    apply (mask_ge_two (edge E 2 0) (edge E 2 3) (edge E 2 6)).mp
    change (((g3 E) && (g15 E)) || ((g3 E) && (g18 E)) || ((g15 E) && (g18 E)))=true
    simpa [g3146, g3147, g3148, g3149, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 4 0, edge E 4 3, edge E 4 6]
    apply (mask_ge_two (edge E 4 0) (edge E 4 3) (edge E 4 6)).mp
    change (((g5 E) && (g20 E)) || ((g5 E) && (g25 E)) || ((g20 E) && (g25 E)))=true
    simpa [g3150, g3151, g3152, g3153, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 2≤countTrue [edge E 5 0, edge E 5 3, edge E 5 6]
    apply (mask_ge_two (edge E 5 0) (edge E 5 3) (edge E 5 6)).mp
    change (((g6 E) && (g21 E)) || ((g6 E) && (g27 E)) || ((g21 E) && (g27 E)))=true
    simpa [g3154, g3155, g3156, g3157, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 0, edge E 7 3, edge E 7 6]
    apply (mask_ge_one (edge E 7 0) (edge E 7 3) (edge E 7 6)).mp
    change ((g8 E) || (g23 E) || (g29 E))=true
    simpa [g3158, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3679 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3161, .pos 3165, .pos 3169, .pos 3173, .pos 3174] := by
  change (¬ ((g3162 E)=true)) → (¬ ((g3166 E)=true)) → (¬ ((g3170 E)=true)) → (¬ ((g3174 E)=true)) → (¬ ((g3175 E)=true)) → False
  intro c1 c2 c4 c5 c6
  apply h
  refine ⟨0,3,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 3, edge E 1 7]
    apply (mask_ge_two (edge E 1 0) (edge E 1 3) (edge E 1 7)).mp
    change (((g2 E) && (g10 E)) || ((g2 E) && (g14 E)) || ((g10 E) && (g14 E)))=true
    simpa [g3159, g3160, g3161, g3162, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 3, edge E 2 7]
    apply (mask_ge_two (edge E 2 0) (edge E 2 3) (edge E 2 7)).mp
    change (((g3 E) && (g15 E)) || ((g3 E) && (g19 E)) || ((g15 E) && (g19 E)))=true
    simpa [g3163, g3164, g3165, g3166, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 4 0, edge E 4 3, edge E 4 7]
    apply (mask_ge_two (edge E 4 0) (edge E 4 3) (edge E 4 7)).mp
    change (((g5 E) && (g20 E)) || ((g5 E) && (g26 E)) || ((g20 E) && (g26 E)))=true
    simpa [g3167, g3168, g3169, g3170, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 2≤countTrue [edge E 5 0, edge E 5 3, edge E 5 7]
    apply (mask_ge_two (edge E 5 0) (edge E 5 3) (edge E 5 7)).mp
    change (((g6 E) && (g21 E)) || ((g6 E) && (g28 E)) || ((g21 E) && (g28 E)))=true
    simpa [g3171, g3172, g3173, g3174, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 3, edge E 6 7]
    apply (mask_ge_one (edge E 6 0) (edge E 6 3) (edge E 6 7)).mp
    change ((g7 E) || (g22 E) || (g29 E))=true
    simpa [g3175, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_3716 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3178, .pos 3182, .pos 3186, .pos 3187, .pos 3188] := by
  change (¬ ((g3179 E)=true)) → (¬ ((g3183 E)=true)) → (¬ ((g3187 E)=true)) → (¬ ((g3188 E)=true)) → (¬ ((g3189 E)=true)) → False
  intro c1 c2 c3 c6 c7
  apply h
  refine ⟨0,4,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 4, edge E 1 5]
    apply (mask_ge_two (edge E 1 0) (edge E 1 4) (edge E 1 5)).mp
    change (((g2 E) && (g11 E)) || ((g2 E) && (g12 E)) || ((g11 E) && (g12 E)))=true
    simpa [g3176, g3177, g3178, g3179, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 4, edge E 2 5]
    apply (mask_ge_two (edge E 2 0) (edge E 2 4) (edge E 2 5)).mp
    change (((g3 E) && (g16 E)) || ((g3 E) && (g17 E)) || ((g16 E) && (g17 E)))=true
    simpa [g3180, g3181, g3182, g3183, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 4, edge E 3 5]
    apply (mask_ge_two (edge E 3 0) (edge E 3 4) (edge E 3 5)).mp
    change (((g4 E) && (g20 E)) || ((g4 E) && (g21 E)) || ((g20 E) && (g21 E)))=true
    simpa [g3184, g3185, g3186, g3187, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 0, edge E 6 4, edge E 6 5]
    apply (mask_ge_one (edge E 6 0) (edge E 6 4) (edge E 6 5)).mp
    change ((g7 E) || (g25 E) || (g27 E))=true
    simpa [g3188, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 4, edge E 7 5]
    apply (mask_ge_one (edge E 7 0) (edge E 7 4) (edge E 7 5)).mp
    change ((g8 E) || (g26 E) || (g28 E))=true
    simpa [g3189, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3743 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3192, .pos 3196, .pos 3200, .pos 3204, .pos 3205] := by
  change (¬ ((g3193 E)=true)) → (¬ ((g3197 E)=true)) → (¬ ((g3201 E)=true)) → (¬ ((g3205 E)=true)) → (¬ ((g3206 E)=true)) → False
  intro c1 c2 c3 c5 c7
  apply h
  refine ⟨0,4,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 4, edge E 1 6]
    apply (mask_ge_two (edge E 1 0) (edge E 1 4) (edge E 1 6)).mp
    change (((g2 E) && (g11 E)) || ((g2 E) && (g13 E)) || ((g11 E) && (g13 E)))=true
    simpa [g3190, g3191, g3192, g3193, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 4, edge E 2 6]
    apply (mask_ge_two (edge E 2 0) (edge E 2 4) (edge E 2 6)).mp
    change (((g3 E) && (g16 E)) || ((g3 E) && (g18 E)) || ((g16 E) && (g18 E)))=true
    simpa [g3194, g3195, g3196, g3197, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 4, edge E 3 6]
    apply (mask_ge_two (edge E 3 0) (edge E 3 4) (edge E 3 6)).mp
    change (((g4 E) && (g20 E)) || ((g4 E) && (g22 E)) || ((g20 E) && (g22 E)))=true
    simpa [g3198, g3199, g3200, g3201, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 5 0, edge E 5 4, edge E 5 6]
    apply (mask_ge_two (edge E 5 0) (edge E 5 4) (edge E 5 6)).mp
    change (((g6 E) && (g24 E)) || ((g6 E) && (g27 E)) || ((g24 E) && (g27 E)))=true
    simpa [g3202, g3203, g3204, g3205, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 0, edge E 7 4, edge E 7 6]
    apply (mask_ge_one (edge E 7 0) (edge E 7 4) (edge E 7 6)).mp
    change ((g8 E) || (g26 E) || (g29 E))=true
    simpa [g3206, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3769 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3209, .pos 3213, .pos 3217, .pos 3221, .pos 3222] := by
  change (¬ ((g3210 E)=true)) → (¬ ((g3214 E)=true)) → (¬ ((g3218 E)=true)) → (¬ ((g3222 E)=true)) → (¬ ((g3223 E)=true)) → False
  intro c1 c2 c3 c5 c6
  apply h
  refine ⟨0,4,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 4, edge E 1 7]
    apply (mask_ge_two (edge E 1 0) (edge E 1 4) (edge E 1 7)).mp
    change (((g2 E) && (g11 E)) || ((g2 E) && (g14 E)) || ((g11 E) && (g14 E)))=true
    simpa [g3207, g3208, g3209, g3210, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 4, edge E 2 7]
    apply (mask_ge_two (edge E 2 0) (edge E 2 4) (edge E 2 7)).mp
    change (((g3 E) && (g16 E)) || ((g3 E) && (g19 E)) || ((g16 E) && (g19 E)))=true
    simpa [g3211, g3212, g3213, g3214, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 4, edge E 3 7]
    apply (mask_ge_two (edge E 3 0) (edge E 3 4) (edge E 3 7)).mp
    change (((g4 E) && (g20 E)) || ((g4 E) && (g23 E)) || ((g20 E) && (g23 E)))=true
    simpa [g3215, g3216, g3217, g3218, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 5 0, edge E 5 4, edge E 5 7]
    apply (mask_ge_two (edge E 5 0) (edge E 5 4) (edge E 5 7)).mp
    change (((g6 E) && (g24 E)) || ((g6 E) && (g28 E)) || ((g24 E) && (g28 E)))=true
    simpa [g3219, g3220, g3221, g3222, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 4, edge E 6 7]
    apply (mask_ge_one (edge E 6 0) (edge E 6 4) (edge E 6 7)).mp
    change ((g7 E) || (g25 E) || (g29 E))=true
    simpa [g3223, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_3797 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3226, .pos 3230, .pos 3234, .pos 3238, .pos 3239] := by
  change (¬ ((g3227 E)=true)) → (¬ ((g3231 E)=true)) → (¬ ((g3235 E)=true)) → (¬ ((g3239 E)=true)) → (¬ ((g3240 E)=true)) → False
  intro c1 c2 c3 c4 c7
  apply h
  refine ⟨0,5,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 5, edge E 1 6]
    apply (mask_ge_two (edge E 1 0) (edge E 1 5) (edge E 1 6)).mp
    change (((g2 E) && (g12 E)) || ((g2 E) && (g13 E)) || ((g12 E) && (g13 E)))=true
    simpa [g3224, g3225, g3226, g3227, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 5, edge E 2 6]
    apply (mask_ge_two (edge E 2 0) (edge E 2 5) (edge E 2 6)).mp
    change (((g3 E) && (g17 E)) || ((g3 E) && (g18 E)) || ((g17 E) && (g18 E)))=true
    simpa [g3228, g3229, g3230, g3231, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 5, edge E 3 6]
    apply (mask_ge_two (edge E 3 0) (edge E 3 5) (edge E 3 6)).mp
    change (((g4 E) && (g21 E)) || ((g4 E) && (g22 E)) || ((g21 E) && (g22 E)))=true
    simpa [g3232, g3233, g3234, g3235, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 0, edge E 4 5, edge E 4 6]
    apply (mask_ge_two (edge E 4 0) (edge E 4 5) (edge E 4 6)).mp
    change (((g5 E) && (g24 E)) || ((g5 E) && (g25 E)) || ((g24 E) && (g25 E)))=true
    simpa [g3236, g3237, g3238, g3239, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 0, edge E 7 5, edge E 7 6]
    apply (mask_ge_one (edge E 7 0) (edge E 7 5) (edge E 7 6)).mp
    change ((g8 E) || (g28 E) || (g29 E))=true
    simpa [g3240, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3835 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3243, .pos 3247, .pos 3251, .pos 3255, .pos 3256] := by
  change (¬ ((g3244 E)=true)) → (¬ ((g3248 E)=true)) → (¬ ((g3252 E)=true)) → (¬ ((g3256 E)=true)) → (¬ ((g3257 E)=true)) → False
  intro c1 c2 c3 c4 c6
  apply h
  refine ⟨0,5,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 5, edge E 1 7]
    apply (mask_ge_two (edge E 1 0) (edge E 1 5) (edge E 1 7)).mp
    change (((g2 E) && (g12 E)) || ((g2 E) && (g14 E)) || ((g12 E) && (g14 E)))=true
    simpa [g3241, g3242, g3243, g3244, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 5, edge E 2 7]
    apply (mask_ge_two (edge E 2 0) (edge E 2 5) (edge E 2 7)).mp
    change (((g3 E) && (g17 E)) || ((g3 E) && (g19 E)) || ((g17 E) && (g19 E)))=true
    simpa [g3245, g3246, g3247, g3248, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 0, edge E 3 5, edge E 3 7]
    apply (mask_ge_two (edge E 3 0) (edge E 3 5) (edge E 3 7)).mp
    change (((g4 E) && (g21 E)) || ((g4 E) && (g23 E)) || ((g21 E) && (g23 E)))=true
    simpa [g3249, g3250, g3251, g3252, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 0, edge E 4 5, edge E 4 7]
    apply (mask_ge_two (edge E 4 0) (edge E 4 5) (edge E 4 7)).mp
    change (((g5 E) && (g24 E)) || ((g5 E) && (g26 E)) || ((g24 E) && (g26 E)))=true
    simpa [g3253, g3254, g3255, g3256, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 6 0, edge E 6 5, edge E 6 7]
    apply (mask_ge_one (edge E 6 0) (edge E 6 5) (edge E 6 7)).mp
    change ((g7 E) || (g27 E) || (g29 E))=true
    simpa [g3257, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_3860 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3280, .pos 3284, .pos 3288, .pos 3289, .pos 3290] := by
  change (¬ ((g3281 E)=true)) → (¬ ((g3285 E)=true)) → (¬ ((g3289 E)=true)) → (¬ ((g3290 E)=true)) → (¬ ((g3291 E)=true)) → False
  intro c0 c4 c5 c6 c7
  apply h
  refine ⟨1,2,3,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 2, edge E 0 3]
    apply (mask_ge_two (edge E 0 1) (edge E 0 2) (edge E 0 3)).mp
    change (((g2 E) && (g3 E)) || ((g2 E) && (g4 E)) || ((g3 E) && (g4 E)))=true
    simpa [g3278, g3279, g3280, g3281, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 2≤countTrue [edge E 4 1, edge E 4 2, edge E 4 3]
    apply (mask_ge_two (edge E 4 1) (edge E 4 2) (edge E 4 3)).mp
    change (((g11 E) && (g16 E)) || ((g11 E) && (g20 E)) || ((g16 E) && (g20 E)))=true
    simpa [g3282, g3283, g3284, g3285, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 2≤countTrue [edge E 5 1, edge E 5 2, edge E 5 3]
    apply (mask_ge_two (edge E 5 1) (edge E 5 2) (edge E 5 3)).mp
    change (((g12 E) && (g17 E)) || ((g12 E) && (g21 E)) || ((g17 E) && (g21 E)))=true
    simpa [g3286, g3287, g3288, g3289, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 1, edge E 6 2, edge E 6 3]
    apply (mask_ge_one (edge E 6 1) (edge E 6 2) (edge E 6 3)).mp
    change ((g13 E) || (g18 E) || (g22 E))=true
    simpa [g3290, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 1, edge E 7 2, edge E 7 3]
    apply (mask_ge_one (edge E 7 1) (edge E 7 2) (edge E 7 3)).mp
    change ((g14 E) || (g19 E) || (g23 E))=true
    simpa [g3291, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3887 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3294, .pos 3298, .pos 3302, .pos 3303, .pos 3304] := by
  change (¬ ((g3295 E)=true)) → (¬ ((g3299 E)=true)) → (¬ ((g3303 E)=true)) → (¬ ((g3304 E)=true)) → (¬ ((g3305 E)=true)) → False
  intro c0 c3 c5 c6 c7
  apply h
  refine ⟨1,2,4,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 2, edge E 0 4]
    apply (mask_ge_two (edge E 0 1) (edge E 0 2) (edge E 0 4)).mp
    change (((g2 E) && (g3 E)) || ((g2 E) && (g5 E)) || ((g3 E) && (g5 E)))=true
    simpa [g3292, g3293, g3294, g3295, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 3 1, edge E 3 2, edge E 3 4]
    apply (mask_ge_two (edge E 3 1) (edge E 3 2) (edge E 3 4)).mp
    change (((g10 E) && (g15 E)) || ((g10 E) && (g20 E)) || ((g15 E) && (g20 E)))=true
    simpa [g3296, g3297, g3298, g3299, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vc rfl).elim
  · change 2≤countTrue [edge E 5 1, edge E 5 2, edge E 5 4]
    apply (mask_ge_two (edge E 5 1) (edge E 5 2) (edge E 5 4)).mp
    change (((g12 E) && (g17 E)) || ((g12 E) && (g24 E)) || ((g17 E) && (g24 E)))=true
    simpa [g3300, g3301, g3302, g3303, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 1, edge E 6 2, edge E 6 4]
    apply (mask_ge_one (edge E 6 1) (edge E 6 2) (edge E 6 4)).mp
    change ((g13 E) || (g18 E) || (g25 E))=true
    simpa [g3304, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 1, edge E 7 2, edge E 7 4]
    apply (mask_ge_one (edge E 7 1) (edge E 7 2) (edge E 7 4)).mp
    change ((g14 E) || (g19 E) || (g26 E))=true
    simpa [g3305, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3920 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3308, .pos 3312, .pos 3316, .pos 3317, .pos 3318] := by
  change (¬ ((g3309 E)=true)) → (¬ ((g3313 E)=true)) → (¬ ((g3317 E)=true)) → (¬ ((g3318 E)=true)) → (¬ ((g3319 E)=true)) → False
  intro c0 c3 c4 c6 c7
  apply h
  refine ⟨1,2,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 2, edge E 0 5]
    apply (mask_ge_two (edge E 0 1) (edge E 0 2) (edge E 0 5)).mp
    change (((g2 E) && (g3 E)) || ((g2 E) && (g6 E)) || ((g3 E) && (g6 E)))=true
    simpa [g3306, g3307, g3308, g3309, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 3 1, edge E 3 2, edge E 3 5]
    apply (mask_ge_two (edge E 3 1) (edge E 3 2) (edge E 3 5)).mp
    change (((g10 E) && (g15 E)) || ((g10 E) && (g21 E)) || ((g15 E) && (g21 E)))=true
    simpa [g3310, g3311, g3312, g3313, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 1, edge E 4 2, edge E 4 5]
    apply (mask_ge_two (edge E 4 1) (edge E 4 2) (edge E 4 5)).mp
    change (((g11 E) && (g16 E)) || ((g11 E) && (g24 E)) || ((g16 E) && (g24 E)))=true
    simpa [g3314, g3315, g3316, g3317, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 1, edge E 6 2, edge E 6 5]
    apply (mask_ge_one (edge E 6 1) (edge E 6 2) (edge E 6 5)).mp
    change ((g13 E) || (g18 E) || (g27 E))=true
    simpa [g3318, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 1, edge E 7 2, edge E 7 5]
    apply (mask_ge_one (edge E 7 1) (edge E 7 2) (edge E 7 5)).mp
    change ((g14 E) || (g19 E) || (g28 E))=true
    simpa [g3319, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3948 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3322, .pos 3326, .pos 3330, .pos 3334, .pos 3335] := by
  change (¬ ((g3323 E)=true)) → (¬ ((g3327 E)=true)) → (¬ ((g3331 E)=true)) → (¬ ((g3335 E)=true)) → (¬ ((g3336 E)=true)) → False
  intro c0 c3 c4 c5 c7
  apply h
  refine ⟨1,2,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 2, edge E 0 6]
    apply (mask_ge_two (edge E 0 1) (edge E 0 2) (edge E 0 6)).mp
    change (((g2 E) && (g3 E)) || ((g2 E) && (g7 E)) || ((g3 E) && (g7 E)))=true
    simpa [g3320, g3321, g3322, g3323, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 3 1, edge E 3 2, edge E 3 6]
    apply (mask_ge_two (edge E 3 1) (edge E 3 2) (edge E 3 6)).mp
    change (((g10 E) && (g15 E)) || ((g10 E) && (g22 E)) || ((g15 E) && (g22 E)))=true
    simpa [g3324, g3325, g3326, g3327, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 1, edge E 4 2, edge E 4 6]
    apply (mask_ge_two (edge E 4 1) (edge E 4 2) (edge E 4 6)).mp
    change (((g11 E) && (g16 E)) || ((g11 E) && (g25 E)) || ((g16 E) && (g25 E)))=true
    simpa [g3328, g3329, g3330, g3331, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 2≤countTrue [edge E 5 1, edge E 5 2, edge E 5 6]
    apply (mask_ge_two (edge E 5 1) (edge E 5 2) (edge E 5 6)).mp
    change (((g12 E) && (g17 E)) || ((g12 E) && (g27 E)) || ((g17 E) && (g27 E)))=true
    simpa [g3332, g3333, g3334, g3335, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 1, edge E 7 2, edge E 7 6]
    apply (mask_ge_one (edge E 7 1) (edge E 7 2) (edge E 7 6)).mp
    change ((g14 E) || (g19 E) || (g29 E))=true
    simpa [g3336, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_3976 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3339, .pos 3343, .pos 3347, .pos 3351, .pos 3352] := by
  change (¬ ((g3340 E)=true)) → (¬ ((g3344 E)=true)) → (¬ ((g3348 E)=true)) → (¬ ((g3352 E)=true)) → (¬ ((g3353 E)=true)) → False
  intro c0 c3 c4 c5 c6
  apply h
  refine ⟨1,2,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 2, edge E 0 7]
    apply (mask_ge_two (edge E 0 1) (edge E 0 2) (edge E 0 7)).mp
    change (((g2 E) && (g3 E)) || ((g2 E) && (g8 E)) || ((g3 E) && (g8 E)))=true
    simpa [g3337, g3338, g3339, g3340, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 3 1, edge E 3 2, edge E 3 7]
    apply (mask_ge_two (edge E 3 1) (edge E 3 2) (edge E 3 7)).mp
    change (((g10 E) && (g15 E)) || ((g10 E) && (g23 E)) || ((g15 E) && (g23 E)))=true
    simpa [g3341, g3342, g3343, g3344, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 1, edge E 4 2, edge E 4 7]
    apply (mask_ge_two (edge E 4 1) (edge E 4 2) (edge E 4 7)).mp
    change (((g11 E) && (g16 E)) || ((g11 E) && (g26 E)) || ((g16 E) && (g26 E)))=true
    simpa [g3345, g3346, g3347, g3348, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 2≤countTrue [edge E 5 1, edge E 5 2, edge E 5 7]
    apply (mask_ge_two (edge E 5 1) (edge E 5 2) (edge E 5 7)).mp
    change (((g12 E) && (g17 E)) || ((g12 E) && (g28 E)) || ((g17 E) && (g28 E)))=true
    simpa [g3349, g3350, g3351, g3352, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 1, edge E 6 2, edge E 6 7]
    apply (mask_ge_one (edge E 6 1) (edge E 6 2) (edge E 6 7)).mp
    change ((g13 E) || (g18 E) || (g29 E))=true
    simpa [g3353, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_4007 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3356, .pos 3360, .pos 3364, .pos 3365, .pos 3366] := by
  change (¬ ((g3357 E)=true)) → (¬ ((g3361 E)=true)) → (¬ ((g3365 E)=true)) → (¬ ((g3366 E)=true)) → (¬ ((g3367 E)=true)) → False
  intro c0 c2 c5 c6 c7
  apply h
  refine ⟨1,3,4,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 3, edge E 0 4]
    apply (mask_ge_two (edge E 0 1) (edge E 0 3) (edge E 0 4)).mp
    change (((g2 E) && (g4 E)) || ((g2 E) && (g5 E)) || ((g4 E) && (g5 E)))=true
    simpa [g3354, g3355, g3356, g3357, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 3, edge E 2 4]
    apply (mask_ge_two (edge E 2 1) (edge E 2 3) (edge E 2 4)).mp
    change (((g9 E) && (g15 E)) || ((g9 E) && (g16 E)) || ((g15 E) && (g16 E)))=true
    simpa [g3358, g3359, g3360, g3361, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 2≤countTrue [edge E 5 1, edge E 5 3, edge E 5 4]
    apply (mask_ge_two (edge E 5 1) (edge E 5 3) (edge E 5 4)).mp
    change (((g12 E) && (g21 E)) || ((g12 E) && (g24 E)) || ((g21 E) && (g24 E)))=true
    simpa [g3362, g3363, g3364, g3365, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 1, edge E 6 3, edge E 6 4]
    apply (mask_ge_one (edge E 6 1) (edge E 6 3) (edge E 6 4)).mp
    change ((g13 E) || (g22 E) || (g25 E))=true
    simpa [g3366, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 1, edge E 7 3, edge E 7 4]
    apply (mask_ge_one (edge E 7 1) (edge E 7 3) (edge E 7 4)).mp
    change ((g14 E) || (g23 E) || (g26 E))=true
    simpa [g3367, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_4038 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3370, .pos 3374, .pos 3378, .pos 3379, .pos 3380] := by
  change (¬ ((g3371 E)=true)) → (¬ ((g3375 E)=true)) → (¬ ((g3379 E)=true)) → (¬ ((g3380 E)=true)) → (¬ ((g3381 E)=true)) → False
  intro c0 c2 c4 c6 c7
  apply h
  refine ⟨1,3,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 3, edge E 0 5]
    apply (mask_ge_two (edge E 0 1) (edge E 0 3) (edge E 0 5)).mp
    change (((g2 E) && (g4 E)) || ((g2 E) && (g6 E)) || ((g4 E) && (g6 E)))=true
    simpa [g3368, g3369, g3370, g3371, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 3, edge E 2 5]
    apply (mask_ge_two (edge E 2 1) (edge E 2 3) (edge E 2 5)).mp
    change (((g9 E) && (g15 E)) || ((g9 E) && (g17 E)) || ((g15 E) && (g17 E)))=true
    simpa [g3372, g3373, g3374, g3375, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 4 1, edge E 4 3, edge E 4 5]
    apply (mask_ge_two (edge E 4 1) (edge E 4 3) (edge E 4 5)).mp
    change (((g11 E) && (g20 E)) || ((g11 E) && (g24 E)) || ((g20 E) && (g24 E)))=true
    simpa [g3376, g3377, g3378, g3379, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 1, edge E 6 3, edge E 6 5]
    apply (mask_ge_one (edge E 6 1) (edge E 6 3) (edge E 6 5)).mp
    change ((g13 E) || (g22 E) || (g27 E))=true
    simpa [g3380, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 1, edge E 7 3, edge E 7 5]
    apply (mask_ge_one (edge E 7 1) (edge E 7 3) (edge E 7 5)).mp
    change ((g14 E) || (g23 E) || (g28 E))=true
    simpa [g3381, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_4066 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3384, .pos 3388, .pos 3392, .pos 3396, .pos 3397] := by
  change (¬ ((g3385 E)=true)) → (¬ ((g3389 E)=true)) → (¬ ((g3393 E)=true)) → (¬ ((g3397 E)=true)) → (¬ ((g3398 E)=true)) → False
  intro c0 c2 c4 c5 c7
  apply h
  refine ⟨1,3,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 3, edge E 0 6]
    apply (mask_ge_two (edge E 0 1) (edge E 0 3) (edge E 0 6)).mp
    change (((g2 E) && (g4 E)) || ((g2 E) && (g7 E)) || ((g4 E) && (g7 E)))=true
    simpa [g3382, g3383, g3384, g3385, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 3, edge E 2 6]
    apply (mask_ge_two (edge E 2 1) (edge E 2 3) (edge E 2 6)).mp
    change (((g9 E) && (g15 E)) || ((g9 E) && (g18 E)) || ((g15 E) && (g18 E)))=true
    simpa [g3386, g3387, g3388, g3389, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 4 1, edge E 4 3, edge E 4 6]
    apply (mask_ge_two (edge E 4 1) (edge E 4 3) (edge E 4 6)).mp
    change (((g11 E) && (g20 E)) || ((g11 E) && (g25 E)) || ((g20 E) && (g25 E)))=true
    simpa [g3390, g3391, g3392, g3393, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 2≤countTrue [edge E 5 1, edge E 5 3, edge E 5 6]
    apply (mask_ge_two (edge E 5 1) (edge E 5 3) (edge E 5 6)).mp
    change (((g12 E) && (g21 E)) || ((g12 E) && (g27 E)) || ((g21 E) && (g27 E)))=true
    simpa [g3394, g3395, g3396, g3397, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 1, edge E 7 3, edge E 7 6]
    apply (mask_ge_one (edge E 7 1) (edge E 7 3) (edge E 7 6)).mp
    change ((g14 E) || (g23 E) || (g29 E))=true
    simpa [g3398, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_4104 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3401, .pos 3405, .pos 3409, .pos 3413, .pos 3414] := by
  change (¬ ((g3402 E)=true)) → (¬ ((g3406 E)=true)) → (¬ ((g3410 E)=true)) → (¬ ((g3414 E)=true)) → (¬ ((g3415 E)=true)) → False
  intro c0 c2 c4 c5 c6
  apply h
  refine ⟨1,3,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 3, edge E 0 7]
    apply (mask_ge_two (edge E 0 1) (edge E 0 3) (edge E 0 7)).mp
    change (((g2 E) && (g4 E)) || ((g2 E) && (g8 E)) || ((g4 E) && (g8 E)))=true
    simpa [g3399, g3400, g3401, g3402, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 3, edge E 2 7]
    apply (mask_ge_two (edge E 2 1) (edge E 2 3) (edge E 2 7)).mp
    change (((g9 E) && (g15 E)) || ((g9 E) && (g19 E)) || ((g15 E) && (g19 E)))=true
    simpa [g3403, g3404, g3405, g3406, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 4 1, edge E 4 3, edge E 4 7]
    apply (mask_ge_two (edge E 4 1) (edge E 4 3) (edge E 4 7)).mp
    change (((g11 E) && (g20 E)) || ((g11 E) && (g26 E)) || ((g20 E) && (g26 E)))=true
    simpa [g3407, g3408, g3409, g3410, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 2≤countTrue [edge E 5 1, edge E 5 3, edge E 5 7]
    apply (mask_ge_two (edge E 5 1) (edge E 5 3) (edge E 5 7)).mp
    change (((g12 E) && (g21 E)) || ((g12 E) && (g28 E)) || ((g21 E) && (g28 E)))=true
    simpa [g3411, g3412, g3413, g3414, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 1, edge E 6 3, edge E 6 7]
    apply (mask_ge_one (edge E 6 1) (edge E 6 3) (edge E 6 7)).mp
    change ((g13 E) || (g22 E) || (g29 E))=true
    simpa [g3415, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_4140 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3418, .pos 3422, .pos 3426, .pos 3427, .pos 3428] := by
  change (¬ ((g3419 E)=true)) → (¬ ((g3423 E)=true)) → (¬ ((g3427 E)=true)) → (¬ ((g3428 E)=true)) → (¬ ((g3429 E)=true)) → False
  intro c0 c2 c3 c6 c7
  apply h
  refine ⟨1,4,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 4, edge E 0 5]
    apply (mask_ge_two (edge E 0 1) (edge E 0 4) (edge E 0 5)).mp
    change (((g2 E) && (g5 E)) || ((g2 E) && (g6 E)) || ((g5 E) && (g6 E)))=true
    simpa [g3416, g3417, g3418, g3419, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 4, edge E 2 5]
    apply (mask_ge_two (edge E 2 1) (edge E 2 4) (edge E 2 5)).mp
    change (((g9 E) && (g16 E)) || ((g9 E) && (g17 E)) || ((g16 E) && (g17 E)))=true
    simpa [g3420, g3421, g3422, g3423, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 1, edge E 3 4, edge E 3 5]
    apply (mask_ge_two (edge E 3 1) (edge E 3 4) (edge E 3 5)).mp
    change (((g10 E) && (g20 E)) || ((g10 E) && (g21 E)) || ((g20 E) && (g21 E)))=true
    simpa [g3424, g3425, g3426, g3427, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 1, edge E 6 4, edge E 6 5]
    apply (mask_ge_one (edge E 6 1) (edge E 6 4) (edge E 6 5)).mp
    change ((g13 E) || (g25 E) || (g27 E))=true
    simpa [g3428, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 1, edge E 7 4, edge E 7 5]
    apply (mask_ge_one (edge E 7 1) (edge E 7 4) (edge E 7 5)).mp
    change ((g14 E) || (g26 E) || (g28 E))=true
    simpa [g3429, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_4171 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3432, .pos 3436, .pos 3440, .pos 3444, .pos 3445] := by
  change (¬ ((g3433 E)=true)) → (¬ ((g3437 E)=true)) → (¬ ((g3441 E)=true)) → (¬ ((g3445 E)=true)) → (¬ ((g3446 E)=true)) → False
  intro c0 c2 c3 c5 c7
  apply h
  refine ⟨1,4,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 4, edge E 0 6]
    apply (mask_ge_two (edge E 0 1) (edge E 0 4) (edge E 0 6)).mp
    change (((g2 E) && (g5 E)) || ((g2 E) && (g7 E)) || ((g5 E) && (g7 E)))=true
    simpa [g3430, g3431, g3432, g3433, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 4, edge E 2 6]
    apply (mask_ge_two (edge E 2 1) (edge E 2 4) (edge E 2 6)).mp
    change (((g9 E) && (g16 E)) || ((g9 E) && (g18 E)) || ((g16 E) && (g18 E)))=true
    simpa [g3434, g3435, g3436, g3437, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 1, edge E 3 4, edge E 3 6]
    apply (mask_ge_two (edge E 3 1) (edge E 3 4) (edge E 3 6)).mp
    change (((g10 E) && (g20 E)) || ((g10 E) && (g22 E)) || ((g20 E) && (g22 E)))=true
    simpa [g3438, g3439, g3440, g3441, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 5 1, edge E 5 4, edge E 5 6]
    apply (mask_ge_two (edge E 5 1) (edge E 5 4) (edge E 5 6)).mp
    change (((g12 E) && (g24 E)) || ((g12 E) && (g27 E)) || ((g24 E) && (g27 E)))=true
    simpa [g3442, g3443, g3444, g3445, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 1, edge E 7 4, edge E 7 6]
    apply (mask_ge_one (edge E 7 1) (edge E 7 4) (edge E 7 6)).mp
    change ((g14 E) || (g26 E) || (g29 E))=true
    simpa [g3446, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_4205 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3449, .pos 3453, .pos 3457, .pos 3461, .pos 3462] := by
  change (¬ ((g3450 E)=true)) → (¬ ((g3454 E)=true)) → (¬ ((g3458 E)=true)) → (¬ ((g3462 E)=true)) → (¬ ((g3463 E)=true)) → False
  intro c0 c2 c3 c5 c6
  apply h
  refine ⟨1,4,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 4, edge E 0 7]
    apply (mask_ge_two (edge E 0 1) (edge E 0 4) (edge E 0 7)).mp
    change (((g2 E) && (g5 E)) || ((g2 E) && (g8 E)) || ((g5 E) && (g8 E)))=true
    simpa [g3447, g3448, g3449, g3450, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 4, edge E 2 7]
    apply (mask_ge_two (edge E 2 1) (edge E 2 4) (edge E 2 7)).mp
    change (((g9 E) && (g16 E)) || ((g9 E) && (g19 E)) || ((g16 E) && (g19 E)))=true
    simpa [g3451, g3452, g3453, g3454, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 1, edge E 3 4, edge E 3 7]
    apply (mask_ge_two (edge E 3 1) (edge E 3 4) (edge E 3 7)).mp
    change (((g10 E) && (g20 E)) || ((g10 E) && (g23 E)) || ((g20 E) && (g23 E)))=true
    simpa [g3455, g3456, g3457, g3458, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 5 1, edge E 5 4, edge E 5 7]
    apply (mask_ge_two (edge E 5 1) (edge E 5 4) (edge E 5 7)).mp
    change (((g12 E) && (g24 E)) || ((g12 E) && (g28 E)) || ((g24 E) && (g28 E)))=true
    simpa [g3459, g3460, g3461, g3462, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 1, edge E 6 4, edge E 6 7]
    apply (mask_ge_one (edge E 6 1) (edge E 6 4) (edge E 6 7)).mp
    change ((g13 E) || (g25 E) || (g29 E))=true
    simpa [g3463, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_4231 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3466, .pos 3470, .pos 3474, .pos 3478, .pos 3479] := by
  change (¬ ((g3467 E)=true)) → (¬ ((g3471 E)=true)) → (¬ ((g3475 E)=true)) → (¬ ((g3479 E)=true)) → (¬ ((g3480 E)=true)) → False
  intro c0 c2 c3 c4 c7
  apply h
  refine ⟨1,5,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 5, edge E 0 6]
    apply (mask_ge_two (edge E 0 1) (edge E 0 5) (edge E 0 6)).mp
    change (((g2 E) && (g6 E)) || ((g2 E) && (g7 E)) || ((g6 E) && (g7 E)))=true
    simpa [g3464, g3465, g3466, g3467, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 5, edge E 2 6]
    apply (mask_ge_two (edge E 2 1) (edge E 2 5) (edge E 2 6)).mp
    change (((g9 E) && (g17 E)) || ((g9 E) && (g18 E)) || ((g17 E) && (g18 E)))=true
    simpa [g3468, g3469, g3470, g3471, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 1, edge E 3 5, edge E 3 6]
    apply (mask_ge_two (edge E 3 1) (edge E 3 5) (edge E 3 6)).mp
    change (((g10 E) && (g21 E)) || ((g10 E) && (g22 E)) || ((g21 E) && (g22 E)))=true
    simpa [g3472, g3473, g3474, g3475, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 1, edge E 4 5, edge E 4 6]
    apply (mask_ge_two (edge E 4 1) (edge E 4 5) (edge E 4 6)).mp
    change (((g11 E) && (g24 E)) || ((g11 E) && (g25 E)) || ((g24 E) && (g25 E)))=true
    simpa [g3476, g3477, g3478, g3479, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 1, edge E 7 5, edge E 7 6]
    apply (mask_ge_one (edge E 7 1) (edge E 7 5) (edge E 7 6)).mp
    change ((g14 E) || (g28 E) || (g29 E))=true
    simpa [g3480, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_4263 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3483, .pos 3487, .pos 3491, .pos 3495, .pos 3496] := by
  change (¬ ((g3484 E)=true)) → (¬ ((g3488 E)=true)) → (¬ ((g3492 E)=true)) → (¬ ((g3496 E)=true)) → (¬ ((g3497 E)=true)) → False
  intro c0 c2 c3 c4 c6
  apply h
  refine ⟨1,5,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 5, edge E 0 7]
    apply (mask_ge_two (edge E 0 1) (edge E 0 5) (edge E 0 7)).mp
    change (((g2 E) && (g6 E)) || ((g2 E) && (g8 E)) || ((g6 E) && (g8 E)))=true
    simpa [g3481, g3482, g3483, g3484, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 5, edge E 2 7]
    apply (mask_ge_two (edge E 2 1) (edge E 2 5) (edge E 2 7)).mp
    change (((g9 E) && (g17 E)) || ((g9 E) && (g19 E)) || ((g17 E) && (g19 E)))=true
    simpa [g3485, g3486, g3487, g3488, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 1, edge E 3 5, edge E 3 7]
    apply (mask_ge_two (edge E 3 1) (edge E 3 5) (edge E 3 7)).mp
    change (((g10 E) && (g21 E)) || ((g10 E) && (g23 E)) || ((g21 E) && (g23 E)))=true
    simpa [g3489, g3490, g3491, g3492, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 1, edge E 4 5, edge E 4 7]
    apply (mask_ge_two (edge E 4 1) (edge E 4 5) (edge E 4 7)).mp
    change (((g11 E) && (g24 E)) || ((g11 E) && (g26 E)) || ((g24 E) && (g26 E)))=true
    simpa [g3493, g3494, g3495, g3496, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 6 1, edge E 6 5, edge E 6 7]
    apply (mask_ge_one (edge E 6 1) (edge E 6 5) (edge E 6 7)).mp
    change ((g13 E) || (g27 E) || (g29 E))=true
    simpa [g3497, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_4286 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3500, .pos 3504, .pos 3508, .pos 3512, .pos 3516] := by
  change (¬ ((g3501 E)=true)) → (¬ ((g3505 E)=true)) → (¬ ((g3509 E)=true)) → (¬ ((g3513 E)=true)) → (¬ ((g3517 E)=true)) → False
  intro c0 c2 c3 c4 c5
  apply h
  refine ⟨1,6,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 6, edge E 0 7]
    apply (mask_ge_two (edge E 0 1) (edge E 0 6) (edge E 0 7)).mp
    change (((g2 E) && (g7 E)) || ((g2 E) && (g8 E)) || ((g7 E) && (g8 E)))=true
    simpa [g3498, g3499, g3500, g3501, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 6, edge E 2 7]
    apply (mask_ge_two (edge E 2 1) (edge E 2 6) (edge E 2 7)).mp
    change (((g9 E) && (g18 E)) || ((g9 E) && (g19 E)) || ((g18 E) && (g19 E)))=true
    simpa [g3502, g3503, g3504, g3505, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 1, edge E 3 6, edge E 3 7]
    apply (mask_ge_two (edge E 3 1) (edge E 3 6) (edge E 3 7)).mp
    change (((g10 E) && (g22 E)) || ((g10 E) && (g23 E)) || ((g22 E) && (g23 E)))=true
    simpa [g3506, g3507, g3508, g3509, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 1, edge E 4 6, edge E 4 7]
    apply (mask_ge_two (edge E 4 1) (edge E 4 6) (edge E 4 7)).mp
    change (((g11 E) && (g25 E)) || ((g11 E) && (g26 E)) || ((g25 E) && (g26 E)))=true
    simpa [g3510, g3511, g3512, g3513, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 2≤countTrue [edge E 5 1, edge E 5 6, edge E 5 7]
    apply (mask_ge_two (edge E 5 1) (edge E 5 6) (edge E 5 7)).mp
    change (((g12 E) && (g27 E)) || ((g12 E) && (g28 E)) || ((g27 E) && (g28 E)))=true
    simpa [g3514, g3515, g3516, g3517, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
private theorem root_4311 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3520, .pos 3524, .pos 3528, .pos 3529, .pos 3530] := by
  change (¬ ((g3521 E)=true)) → (¬ ((g3525 E)=true)) → (¬ ((g3529 E)=true)) → (¬ ((g3530 E)=true)) → (¬ ((g3531 E)=true)) → False
  intro c0 c1 c5 c6 c7
  apply h
  refine ⟨2,3,4,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 3, edge E 0 4]
    apply (mask_ge_two (edge E 0 2) (edge E 0 3) (edge E 0 4)).mp
    change (((g3 E) && (g4 E)) || ((g3 E) && (g5 E)) || ((g4 E) && (g5 E)))=true
    simpa [g3518, g3519, g3520, g3521, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 3, edge E 1 4]
    apply (mask_ge_two (edge E 1 2) (edge E 1 3) (edge E 1 4)).mp
    change (((g9 E) && (g10 E)) || ((g9 E) && (g11 E)) || ((g10 E) && (g11 E)))=true
    simpa [g3522, g3523, g3524, g3525, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 2≤countTrue [edge E 5 2, edge E 5 3, edge E 5 4]
    apply (mask_ge_two (edge E 5 2) (edge E 5 3) (edge E 5 4)).mp
    change (((g17 E) && (g21 E)) || ((g17 E) && (g24 E)) || ((g21 E) && (g24 E)))=true
    simpa [g3526, g3527, g3528, g3529, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 2, edge E 6 3, edge E 6 4]
    apply (mask_ge_one (edge E 6 2) (edge E 6 3) (edge E 6 4)).mp
    change ((g18 E) || (g22 E) || (g25 E))=true
    simpa [g3530, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 2, edge E 7 3, edge E 7 4]
    apply (mask_ge_one (edge E 7 2) (edge E 7 3) (edge E 7 4)).mp
    change ((g19 E) || (g23 E) || (g26 E))=true
    simpa [g3531, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_4340 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3534, .pos 3538, .pos 3542, .pos 3543, .pos 3544] := by
  change (¬ ((g3535 E)=true)) → (¬ ((g3539 E)=true)) → (¬ ((g3543 E)=true)) → (¬ ((g3544 E)=true)) → (¬ ((g3545 E)=true)) → False
  intro c0 c1 c4 c6 c7
  apply h
  refine ⟨2,3,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 3, edge E 0 5]
    apply (mask_ge_two (edge E 0 2) (edge E 0 3) (edge E 0 5)).mp
    change (((g3 E) && (g4 E)) || ((g3 E) && (g6 E)) || ((g4 E) && (g6 E)))=true
    simpa [g3532, g3533, g3534, g3535, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 3, edge E 1 5]
    apply (mask_ge_two (edge E 1 2) (edge E 1 3) (edge E 1 5)).mp
    change (((g9 E) && (g10 E)) || ((g9 E) && (g12 E)) || ((g10 E) && (g12 E)))=true
    simpa [g3536, g3537, g3538, g3539, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 4 2, edge E 4 3, edge E 4 5]
    apply (mask_ge_two (edge E 4 2) (edge E 4 3) (edge E 4 5)).mp
    change (((g16 E) && (g20 E)) || ((g16 E) && (g24 E)) || ((g20 E) && (g24 E)))=true
    simpa [g3540, g3541, g3542, g3543, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 2, edge E 6 3, edge E 6 5]
    apply (mask_ge_one (edge E 6 2) (edge E 6 3) (edge E 6 5)).mp
    change ((g18 E) || (g22 E) || (g27 E))=true
    simpa [g3544, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 2, edge E 7 3, edge E 7 5]
    apply (mask_ge_one (edge E 7 2) (edge E 7 3) (edge E 7 5)).mp
    change ((g19 E) || (g23 E) || (g28 E))=true
    simpa [g3545, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_4357 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3548, .pos 3552, .pos 3556, .pos 3560, .pos 3561] := by
  change (¬ ((g3549 E)=true)) → (¬ ((g3553 E)=true)) → (¬ ((g3557 E)=true)) → (¬ ((g3561 E)=true)) → (¬ ((g3562 E)=true)) → False
  intro c0 c1 c4 c5 c7
  apply h
  refine ⟨2,3,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 3, edge E 0 6]
    apply (mask_ge_two (edge E 0 2) (edge E 0 3) (edge E 0 6)).mp
    change (((g3 E) && (g4 E)) || ((g3 E) && (g7 E)) || ((g4 E) && (g7 E)))=true
    simpa [g3546, g3547, g3548, g3549, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 3, edge E 1 6]
    apply (mask_ge_two (edge E 1 2) (edge E 1 3) (edge E 1 6)).mp
    change (((g9 E) && (g10 E)) || ((g9 E) && (g13 E)) || ((g10 E) && (g13 E)))=true
    simpa [g3550, g3551, g3552, g3553, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 4 2, edge E 4 3, edge E 4 6]
    apply (mask_ge_two (edge E 4 2) (edge E 4 3) (edge E 4 6)).mp
    change (((g16 E) && (g20 E)) || ((g16 E) && (g25 E)) || ((g20 E) && (g25 E)))=true
    simpa [g3554, g3555, g3556, g3557, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 2≤countTrue [edge E 5 2, edge E 5 3, edge E 5 6]
    apply (mask_ge_two (edge E 5 2) (edge E 5 3) (edge E 5 6)).mp
    change (((g17 E) && (g21 E)) || ((g17 E) && (g27 E)) || ((g21 E) && (g27 E)))=true
    simpa [g3558, g3559, g3560, g3561, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 2, edge E 7 3, edge E 7 6]
    apply (mask_ge_one (edge E 7 2) (edge E 7 3) (edge E 7 6)).mp
    change ((g19 E) || (g23 E) || (g29 E))=true
    simpa [g3562, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_4385 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3565, .pos 3569, .pos 3573, .pos 3577, .pos 3578] := by
  change (¬ ((g3566 E)=true)) → (¬ ((g3570 E)=true)) → (¬ ((g3574 E)=true)) → (¬ ((g3578 E)=true)) → (¬ ((g3579 E)=true)) → False
  intro c0 c1 c4 c5 c6
  apply h
  refine ⟨2,3,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 3, edge E 0 7]
    apply (mask_ge_two (edge E 0 2) (edge E 0 3) (edge E 0 7)).mp
    change (((g3 E) && (g4 E)) || ((g3 E) && (g8 E)) || ((g4 E) && (g8 E)))=true
    simpa [g3563, g3564, g3565, g3566, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 3, edge E 1 7]
    apply (mask_ge_two (edge E 1 2) (edge E 1 3) (edge E 1 7)).mp
    change (((g9 E) && (g10 E)) || ((g9 E) && (g14 E)) || ((g10 E) && (g14 E)))=true
    simpa [g3567, g3568, g3569, g3570, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 4 2, edge E 4 3, edge E 4 7]
    apply (mask_ge_two (edge E 4 2) (edge E 4 3) (edge E 4 7)).mp
    change (((g16 E) && (g20 E)) || ((g16 E) && (g26 E)) || ((g20 E) && (g26 E)))=true
    simpa [g3571, g3572, g3573, g3574, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 2≤countTrue [edge E 5 2, edge E 5 3, edge E 5 7]
    apply (mask_ge_two (edge E 5 2) (edge E 5 3) (edge E 5 7)).mp
    change (((g17 E) && (g21 E)) || ((g17 E) && (g28 E)) || ((g21 E) && (g28 E)))=true
    simpa [g3575, g3576, g3577, g3578, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 2, edge E 6 3, edge E 6 7]
    apply (mask_ge_one (edge E 6 2) (edge E 6 3) (edge E 6 7)).mp
    change ((g18 E) || (g22 E) || (g29 E))=true
    simpa [g3579, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_4411 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3582, .pos 3586, .pos 3590, .pos 3591, .pos 3592] := by
  change (¬ ((g3583 E)=true)) → (¬ ((g3587 E)=true)) → (¬ ((g3591 E)=true)) → (¬ ((g3592 E)=true)) → (¬ ((g3593 E)=true)) → False
  intro c0 c1 c3 c6 c7
  apply h
  refine ⟨2,4,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 4, edge E 0 5]
    apply (mask_ge_two (edge E 0 2) (edge E 0 4) (edge E 0 5)).mp
    change (((g3 E) && (g5 E)) || ((g3 E) && (g6 E)) || ((g5 E) && (g6 E)))=true
    simpa [g3580, g3581, g3582, g3583, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 4, edge E 1 5]
    apply (mask_ge_two (edge E 1 2) (edge E 1 4) (edge E 1 5)).mp
    change (((g9 E) && (g11 E)) || ((g9 E) && (g12 E)) || ((g11 E) && (g12 E)))=true
    simpa [g3584, g3585, g3586, g3587, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 3 2, edge E 3 4, edge E 3 5]
    apply (mask_ge_two (edge E 3 2) (edge E 3 4) (edge E 3 5)).mp
    change (((g15 E) && (g20 E)) || ((g15 E) && (g21 E)) || ((g20 E) && (g21 E)))=true
    simpa [g3588, g3589, g3590, g3591, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 2, edge E 6 4, edge E 6 5]
    apply (mask_ge_one (edge E 6 2) (edge E 6 4) (edge E 6 5)).mp
    change ((g18 E) || (g25 E) || (g27 E))=true
    simpa [g3592, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 2, edge E 7 4, edge E 7 5]
    apply (mask_ge_one (edge E 7 2) (edge E 7 4) (edge E 7 5)).mp
    change ((g19 E) || (g26 E) || (g28 E))=true
    simpa [g3593, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_4436 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3596, .pos 3600, .pos 3604, .pos 3608, .pos 3609] := by
  change (¬ ((g3597 E)=true)) → (¬ ((g3601 E)=true)) → (¬ ((g3605 E)=true)) → (¬ ((g3609 E)=true)) → (¬ ((g3610 E)=true)) → False
  intro c0 c1 c3 c5 c7
  apply h
  refine ⟨2,4,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 4, edge E 0 6]
    apply (mask_ge_two (edge E 0 2) (edge E 0 4) (edge E 0 6)).mp
    change (((g3 E) && (g5 E)) || ((g3 E) && (g7 E)) || ((g5 E) && (g7 E)))=true
    simpa [g3594, g3595, g3596, g3597, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 4, edge E 1 6]
    apply (mask_ge_two (edge E 1 2) (edge E 1 4) (edge E 1 6)).mp
    change (((g9 E) && (g11 E)) || ((g9 E) && (g13 E)) || ((g11 E) && (g13 E)))=true
    simpa [g3598, g3599, g3600, g3601, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 3 2, edge E 3 4, edge E 3 6]
    apply (mask_ge_two (edge E 3 2) (edge E 3 4) (edge E 3 6)).mp
    change (((g15 E) && (g20 E)) || ((g15 E) && (g22 E)) || ((g20 E) && (g22 E)))=true
    simpa [g3602, g3603, g3604, g3605, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 5 2, edge E 5 4, edge E 5 6]
    apply (mask_ge_two (edge E 5 2) (edge E 5 4) (edge E 5 6)).mp
    change (((g17 E) && (g24 E)) || ((g17 E) && (g27 E)) || ((g24 E) && (g27 E)))=true
    simpa [g3606, g3607, g3608, g3609, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 2, edge E 7 4, edge E 7 6]
    apply (mask_ge_one (edge E 7 2) (edge E 7 4) (edge E 7 6)).mp
    change ((g19 E) || (g26 E) || (g29 E))=true
    simpa [g3610, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_4471 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3613, .pos 3617, .pos 3621, .pos 3625, .pos 3626] := by
  change (¬ ((g3614 E)=true)) → (¬ ((g3618 E)=true)) → (¬ ((g3622 E)=true)) → (¬ ((g3626 E)=true)) → (¬ ((g3627 E)=true)) → False
  intro c0 c1 c3 c5 c6
  apply h
  refine ⟨2,4,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 4, edge E 0 7]
    apply (mask_ge_two (edge E 0 2) (edge E 0 4) (edge E 0 7)).mp
    change (((g3 E) && (g5 E)) || ((g3 E) && (g8 E)) || ((g5 E) && (g8 E)))=true
    simpa [g3611, g3612, g3613, g3614, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 4, edge E 1 7]
    apply (mask_ge_two (edge E 1 2) (edge E 1 4) (edge E 1 7)).mp
    change (((g9 E) && (g11 E)) || ((g9 E) && (g14 E)) || ((g11 E) && (g14 E)))=true
    simpa [g3615, g3616, g3617, g3618, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 3 2, edge E 3 4, edge E 3 7]
    apply (mask_ge_two (edge E 3 2) (edge E 3 4) (edge E 3 7)).mp
    change (((g15 E) && (g20 E)) || ((g15 E) && (g23 E)) || ((g20 E) && (g23 E)))=true
    simpa [g3619, g3620, g3621, g3622, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 5 2, edge E 5 4, edge E 5 7]
    apply (mask_ge_two (edge E 5 2) (edge E 5 4) (edge E 5 7)).mp
    change (((g17 E) && (g24 E)) || ((g17 E) && (g28 E)) || ((g24 E) && (g28 E)))=true
    simpa [g3623, g3624, g3625, g3626, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 2, edge E 6 4, edge E 6 7]
    apply (mask_ge_one (edge E 6 2) (edge E 6 4) (edge E 6 7)).mp
    change ((g18 E) || (g25 E) || (g29 E))=true
    simpa [g3627, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_4497 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3630, .pos 3634, .pos 3638, .pos 3642, .pos 3643] := by
  change (¬ ((g3631 E)=true)) → (¬ ((g3635 E)=true)) → (¬ ((g3639 E)=true)) → (¬ ((g3643 E)=true)) → (¬ ((g3644 E)=true)) → False
  intro c0 c1 c3 c4 c7
  apply h
  refine ⟨2,5,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 5, edge E 0 6]
    apply (mask_ge_two (edge E 0 2) (edge E 0 5) (edge E 0 6)).mp
    change (((g3 E) && (g6 E)) || ((g3 E) && (g7 E)) || ((g6 E) && (g7 E)))=true
    simpa [g3628, g3629, g3630, g3631, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 5, edge E 1 6]
    apply (mask_ge_two (edge E 1 2) (edge E 1 5) (edge E 1 6)).mp
    change (((g9 E) && (g12 E)) || ((g9 E) && (g13 E)) || ((g12 E) && (g13 E)))=true
    simpa [g3632, g3633, g3634, g3635, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 3 2, edge E 3 5, edge E 3 6]
    apply (mask_ge_two (edge E 3 2) (edge E 3 5) (edge E 3 6)).mp
    change (((g15 E) && (g21 E)) || ((g15 E) && (g22 E)) || ((g21 E) && (g22 E)))=true
    simpa [g3636, g3637, g3638, g3639, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 2, edge E 4 5, edge E 4 6]
    apply (mask_ge_two (edge E 4 2) (edge E 4 5) (edge E 4 6)).mp
    change (((g16 E) && (g24 E)) || ((g16 E) && (g25 E)) || ((g24 E) && (g25 E)))=true
    simpa [g3640, g3641, g3642, g3643, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 2, edge E 7 5, edge E 7 6]
    apply (mask_ge_one (edge E 7 2) (edge E 7 5) (edge E 7 6)).mp
    change ((g19 E) || (g28 E) || (g29 E))=true
    simpa [g3644, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_4533 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3647, .pos 3651, .pos 3655, .pos 3659, .pos 3660] := by
  change (¬ ((g3648 E)=true)) → (¬ ((g3652 E)=true)) → (¬ ((g3656 E)=true)) → (¬ ((g3660 E)=true)) → (¬ ((g3661 E)=true)) → False
  intro c0 c1 c3 c4 c6
  apply h
  refine ⟨2,5,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 5, edge E 0 7]
    apply (mask_ge_two (edge E 0 2) (edge E 0 5) (edge E 0 7)).mp
    change (((g3 E) && (g6 E)) || ((g3 E) && (g8 E)) || ((g6 E) && (g8 E)))=true
    simpa [g3645, g3646, g3647, g3648, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 5, edge E 1 7]
    apply (mask_ge_two (edge E 1 2) (edge E 1 5) (edge E 1 7)).mp
    change (((g9 E) && (g12 E)) || ((g9 E) && (g14 E)) || ((g12 E) && (g14 E)))=true
    simpa [g3649, g3650, g3651, g3652, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 3 2, edge E 3 5, edge E 3 7]
    apply (mask_ge_two (edge E 3 2) (edge E 3 5) (edge E 3 7)).mp
    change (((g15 E) && (g21 E)) || ((g15 E) && (g23 E)) || ((g21 E) && (g23 E)))=true
    simpa [g3653, g3654, g3655, g3656, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 2, edge E 4 5, edge E 4 7]
    apply (mask_ge_two (edge E 4 2) (edge E 4 5) (edge E 4 7)).mp
    change (((g16 E) && (g24 E)) || ((g16 E) && (g26 E)) || ((g24 E) && (g26 E)))=true
    simpa [g3657, g3658, g3659, g3660, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 6 2, edge E 6 5, edge E 6 7]
    apply (mask_ge_one (edge E 6 2) (edge E 6 5) (edge E 6 7)).mp
    change ((g18 E) || (g27 E) || (g29 E))=true
    simpa [g3661, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_4572 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3664, .pos 3668, .pos 3672, .pos 3676, .pos 3680] := by
  change (¬ ((g3665 E)=true)) → (¬ ((g3669 E)=true)) → (¬ ((g3673 E)=true)) → (¬ ((g3677 E)=true)) → (¬ ((g3681 E)=true)) → False
  intro c0 c1 c3 c4 c5
  apply h
  refine ⟨2,6,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 6, edge E 0 7]
    apply (mask_ge_two (edge E 0 2) (edge E 0 6) (edge E 0 7)).mp
    change (((g3 E) && (g7 E)) || ((g3 E) && (g8 E)) || ((g7 E) && (g8 E)))=true
    simpa [g3662, g3663, g3664, g3665, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 6, edge E 1 7]
    apply (mask_ge_two (edge E 1 2) (edge E 1 6) (edge E 1 7)).mp
    change (((g9 E) && (g13 E)) || ((g9 E) && (g14 E)) || ((g13 E) && (g14 E)))=true
    simpa [g3666, g3667, g3668, g3669, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 3 2, edge E 3 6, edge E 3 7]
    apply (mask_ge_two (edge E 3 2) (edge E 3 6) (edge E 3 7)).mp
    change (((g15 E) && (g22 E)) || ((g15 E) && (g23 E)) || ((g22 E) && (g23 E)))=true
    simpa [g3670, g3671, g3672, g3673, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 2, edge E 4 6, edge E 4 7]
    apply (mask_ge_two (edge E 4 2) (edge E 4 6) (edge E 4 7)).mp
    change (((g16 E) && (g25 E)) || ((g16 E) && (g26 E)) || ((g25 E) && (g26 E)))=true
    simpa [g3674, g3675, g3676, g3677, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 2≤countTrue [edge E 5 2, edge E 5 6, edge E 5 7]
    apply (mask_ge_two (edge E 5 2) (edge E 5 6) (edge E 5 7)).mp
    change (((g17 E) && (g27 E)) || ((g17 E) && (g28 E)) || ((g27 E) && (g28 E)))=true
    simpa [g3678, g3679, g3680, g3681, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
private theorem root_4603 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3684, .pos 3688, .pos 3692, .pos 3693, .pos 3694] := by
  change (¬ ((g3685 E)=true)) → (¬ ((g3689 E)=true)) → (¬ ((g3693 E)=true)) → (¬ ((g3694 E)=true)) → (¬ ((g3695 E)=true)) → False
  intro c0 c1 c2 c6 c7
  apply h
  refine ⟨3,4,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 3, edge E 0 4, edge E 0 5]
    apply (mask_ge_two (edge E 0 3) (edge E 0 4) (edge E 0 5)).mp
    change (((g4 E) && (g5 E)) || ((g4 E) && (g6 E)) || ((g5 E) && (g6 E)))=true
    simpa [g3682, g3683, g3684, g3685, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 3, edge E 1 4, edge E 1 5]
    apply (mask_ge_two (edge E 1 3) (edge E 1 4) (edge E 1 5)).mp
    change (((g10 E) && (g11 E)) || ((g10 E) && (g12 E)) || ((g11 E) && (g12 E)))=true
    simpa [g3686, g3687, g3688, g3689, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 3, edge E 2 4, edge E 2 5]
    apply (mask_ge_two (edge E 2 3) (edge E 2 4) (edge E 2 5)).mp
    change (((g15 E) && (g16 E)) || ((g15 E) && (g17 E)) || ((g16 E) && (g17 E)))=true
    simpa [g3690, g3691, g3692, g3693, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 3, edge E 6 4, edge E 6 5]
    apply (mask_ge_one (edge E 6 3) (edge E 6 4) (edge E 6 5)).mp
    change ((g22 E) || (g25 E) || (g27 E))=true
    simpa [g3694, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 3, edge E 7 4, edge E 7 5]
    apply (mask_ge_one (edge E 7 3) (edge E 7 4) (edge E 7 5)).mp
    change ((g23 E) || (g26 E) || (g28 E))=true
    simpa [g3695, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_4627 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3698, .pos 3702, .pos 3706, .pos 3710, .pos 3711] := by
  change (¬ ((g3699 E)=true)) → (¬ ((g3703 E)=true)) → (¬ ((g3707 E)=true)) → (¬ ((g3711 E)=true)) → (¬ ((g3712 E)=true)) → False
  intro c0 c1 c2 c5 c7
  apply h
  refine ⟨3,4,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 3, edge E 0 4, edge E 0 6]
    apply (mask_ge_two (edge E 0 3) (edge E 0 4) (edge E 0 6)).mp
    change (((g4 E) && (g5 E)) || ((g4 E) && (g7 E)) || ((g5 E) && (g7 E)))=true
    simpa [g3696, g3697, g3698, g3699, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 3, edge E 1 4, edge E 1 6]
    apply (mask_ge_two (edge E 1 3) (edge E 1 4) (edge E 1 6)).mp
    change (((g10 E) && (g11 E)) || ((g10 E) && (g13 E)) || ((g11 E) && (g13 E)))=true
    simpa [g3700, g3701, g3702, g3703, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 3, edge E 2 4, edge E 2 6]
    apply (mask_ge_two (edge E 2 3) (edge E 2 4) (edge E 2 6)).mp
    change (((g15 E) && (g16 E)) || ((g15 E) && (g18 E)) || ((g16 E) && (g18 E)))=true
    simpa [g3704, g3705, g3706, g3707, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 5 3, edge E 5 4, edge E 5 6]
    apply (mask_ge_two (edge E 5 3) (edge E 5 4) (edge E 5 6)).mp
    change (((g21 E) && (g24 E)) || ((g21 E) && (g27 E)) || ((g24 E) && (g27 E)))=true
    simpa [g3708, g3709, g3710, g3711, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 3, edge E 7 4, edge E 7 6]
    apply (mask_ge_one (edge E 7 3) (edge E 7 4) (edge E 7 6)).mp
    change ((g23 E) || (g26 E) || (g29 E))=true
    simpa [g3712, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_4655 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3715, .pos 3719, .pos 3723, .pos 3727, .pos 3728] := by
  change (¬ ((g3716 E)=true)) → (¬ ((g3720 E)=true)) → (¬ ((g3724 E)=true)) → (¬ ((g3728 E)=true)) → (¬ ((g3729 E)=true)) → False
  intro c0 c1 c2 c5 c6
  apply h
  refine ⟨3,4,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 3, edge E 0 4, edge E 0 7]
    apply (mask_ge_two (edge E 0 3) (edge E 0 4) (edge E 0 7)).mp
    change (((g4 E) && (g5 E)) || ((g4 E) && (g8 E)) || ((g5 E) && (g8 E)))=true
    simpa [g3713, g3714, g3715, g3716, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 3, edge E 1 4, edge E 1 7]
    apply (mask_ge_two (edge E 1 3) (edge E 1 4) (edge E 1 7)).mp
    change (((g10 E) && (g11 E)) || ((g10 E) && (g14 E)) || ((g11 E) && (g14 E)))=true
    simpa [g3717, g3718, g3719, g3720, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 3, edge E 2 4, edge E 2 7]
    apply (mask_ge_two (edge E 2 3) (edge E 2 4) (edge E 2 7)).mp
    change (((g15 E) && (g16 E)) || ((g15 E) && (g19 E)) || ((g16 E) && (g19 E)))=true
    simpa [g3721, g3722, g3723, g3724, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 5 3, edge E 5 4, edge E 5 7]
    apply (mask_ge_two (edge E 5 3) (edge E 5 4) (edge E 5 7)).mp
    change (((g21 E) && (g24 E)) || ((g21 E) && (g28 E)) || ((g24 E) && (g28 E)))=true
    simpa [g3725, g3726, g3727, g3728, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 3, edge E 6 4, edge E 6 7]
    apply (mask_ge_one (edge E 6 3) (edge E 6 4) (edge E 6 7)).mp
    change ((g22 E) || (g25 E) || (g29 E))=true
    simpa [g3729, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_4687 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3732, .pos 3736, .pos 3740, .pos 3744, .pos 3745] := by
  change (¬ ((g3733 E)=true)) → (¬ ((g3737 E)=true)) → (¬ ((g3741 E)=true)) → (¬ ((g3745 E)=true)) → (¬ ((g3746 E)=true)) → False
  intro c0 c1 c2 c4 c7
  apply h
  refine ⟨3,5,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 3, edge E 0 5, edge E 0 6]
    apply (mask_ge_two (edge E 0 3) (edge E 0 5) (edge E 0 6)).mp
    change (((g4 E) && (g6 E)) || ((g4 E) && (g7 E)) || ((g6 E) && (g7 E)))=true
    simpa [g3730, g3731, g3732, g3733, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 3, edge E 1 5, edge E 1 6]
    apply (mask_ge_two (edge E 1 3) (edge E 1 5) (edge E 1 6)).mp
    change (((g10 E) && (g12 E)) || ((g10 E) && (g13 E)) || ((g12 E) && (g13 E)))=true
    simpa [g3734, g3735, g3736, g3737, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 3, edge E 2 5, edge E 2 6]
    apply (mask_ge_two (edge E 2 3) (edge E 2 5) (edge E 2 6)).mp
    change (((g15 E) && (g17 E)) || ((g15 E) && (g18 E)) || ((g17 E) && (g18 E)))=true
    simpa [g3738, g3739, g3740, g3741, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 4 3, edge E 4 5, edge E 4 6]
    apply (mask_ge_two (edge E 4 3) (edge E 4 5) (edge E 4 6)).mp
    change (((g20 E) && (g24 E)) || ((g20 E) && (g25 E)) || ((g24 E) && (g25 E)))=true
    simpa [g3742, g3743, g3744, g3745, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 3, edge E 7 5, edge E 7 6]
    apply (mask_ge_one (edge E 7 3) (edge E 7 5) (edge E 7 6)).mp
    change ((g23 E) || (g28 E) || (g29 E))=true
    simpa [g3746, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_4714 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3749, .pos 3753, .pos 3757, .pos 3761, .pos 3762] := by
  change (¬ ((g3750 E)=true)) → (¬ ((g3754 E)=true)) → (¬ ((g3758 E)=true)) → (¬ ((g3762 E)=true)) → (¬ ((g3763 E)=true)) → False
  intro c0 c1 c2 c4 c6
  apply h
  refine ⟨3,5,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 3, edge E 0 5, edge E 0 7]
    apply (mask_ge_two (edge E 0 3) (edge E 0 5) (edge E 0 7)).mp
    change (((g4 E) && (g6 E)) || ((g4 E) && (g8 E)) || ((g6 E) && (g8 E)))=true
    simpa [g3747, g3748, g3749, g3750, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 3, edge E 1 5, edge E 1 7]
    apply (mask_ge_two (edge E 1 3) (edge E 1 5) (edge E 1 7)).mp
    change (((g10 E) && (g12 E)) || ((g10 E) && (g14 E)) || ((g12 E) && (g14 E)))=true
    simpa [g3751, g3752, g3753, g3754, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 3, edge E 2 5, edge E 2 7]
    apply (mask_ge_two (edge E 2 3) (edge E 2 5) (edge E 2 7)).mp
    change (((g15 E) && (g17 E)) || ((g15 E) && (g19 E)) || ((g17 E) && (g19 E)))=true
    simpa [g3755, g3756, g3757, g3758, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 4 3, edge E 4 5, edge E 4 7]
    apply (mask_ge_two (edge E 4 3) (edge E 4 5) (edge E 4 7)).mp
    change (((g20 E) && (g24 E)) || ((g20 E) && (g26 E)) || ((g24 E) && (g26 E)))=true
    simpa [g3759, g3760, g3761, g3762, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 6 3, edge E 6 5, edge E 6 7]
    apply (mask_ge_one (edge E 6 3) (edge E 6 5) (edge E 6 7)).mp
    change ((g22 E) || (g27 E) || (g29 E))=true
    simpa [g3763, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_4749 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3766, .pos 3770, .pos 3774, .pos 3778, .pos 3782] := by
  change (¬ ((g3767 E)=true)) → (¬ ((g3771 E)=true)) → (¬ ((g3775 E)=true)) → (¬ ((g3779 E)=true)) → (¬ ((g3783 E)=true)) → False
  intro c0 c1 c2 c4 c5
  apply h
  refine ⟨3,6,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 3, edge E 0 6, edge E 0 7]
    apply (mask_ge_two (edge E 0 3) (edge E 0 6) (edge E 0 7)).mp
    change (((g4 E) && (g7 E)) || ((g4 E) && (g8 E)) || ((g7 E) && (g8 E)))=true
    simpa [g3764, g3765, g3766, g3767, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 3, edge E 1 6, edge E 1 7]
    apply (mask_ge_two (edge E 1 3) (edge E 1 6) (edge E 1 7)).mp
    change (((g10 E) && (g13 E)) || ((g10 E) && (g14 E)) || ((g13 E) && (g14 E)))=true
    simpa [g3768, g3769, g3770, g3771, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 3, edge E 2 6, edge E 2 7]
    apply (mask_ge_two (edge E 2 3) (edge E 2 6) (edge E 2 7)).mp
    change (((g15 E) && (g18 E)) || ((g15 E) && (g19 E)) || ((g18 E) && (g19 E)))=true
    simpa [g3772, g3773, g3774, g3775, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 4 3, edge E 4 6, edge E 4 7]
    apply (mask_ge_two (edge E 4 3) (edge E 4 6) (edge E 4 7)).mp
    change (((g20 E) && (g25 E)) || ((g20 E) && (g26 E)) || ((g25 E) && (g26 E)))=true
    simpa [g3776, g3777, g3778, g3779, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 2≤countTrue [edge E 5 3, edge E 5 6, edge E 5 7]
    apply (mask_ge_two (edge E 5 3) (edge E 5 6) (edge E 5 7)).mp
    change (((g21 E) && (g27 E)) || ((g21 E) && (g28 E)) || ((g27 E) && (g28 E)))=true
    simpa [g3780, g3781, g3782, g3783, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
private theorem root_4783 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3786, .pos 3790, .pos 3794, .pos 3798, .pos 3799] := by
  change (¬ ((g3787 E)=true)) → (¬ ((g3791 E)=true)) → (¬ ((g3795 E)=true)) → (¬ ((g3799 E)=true)) → (¬ ((g3800 E)=true)) → False
  intro c0 c1 c2 c3 c7
  apply h
  refine ⟨4,5,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 4, edge E 0 5, edge E 0 6]
    apply (mask_ge_two (edge E 0 4) (edge E 0 5) (edge E 0 6)).mp
    change (((g5 E) && (g6 E)) || ((g5 E) && (g7 E)) || ((g6 E) && (g7 E)))=true
    simpa [g3784, g3785, g3786, g3787, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 4, edge E 1 5, edge E 1 6]
    apply (mask_ge_two (edge E 1 4) (edge E 1 5) (edge E 1 6)).mp
    change (((g11 E) && (g12 E)) || ((g11 E) && (g13 E)) || ((g12 E) && (g13 E)))=true
    simpa [g3788, g3789, g3790, g3791, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 4, edge E 2 5, edge E 2 6]
    apply (mask_ge_two (edge E 2 4) (edge E 2 5) (edge E 2 6)).mp
    change (((g16 E) && (g17 E)) || ((g16 E) && (g18 E)) || ((g17 E) && (g18 E)))=true
    simpa [g3792, g3793, g3794, g3795, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 4, edge E 3 5, edge E 3 6]
    apply (mask_ge_two (edge E 3 4) (edge E 3 5) (edge E 3 6)).mp
    change (((g20 E) && (g21 E)) || ((g20 E) && (g22 E)) || ((g21 E) && (g22 E)))=true
    simpa [g3796, g3797, g3798, g3799, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 4, edge E 7 5, edge E 7 6]
    apply (mask_ge_one (edge E 7 4) (edge E 7 5) (edge E 7 6)).mp
    change ((g26 E) || (g28 E) || (g29 E))=true
    simpa [g3800, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_4820 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3803, .pos 3807, .pos 3811, .pos 3815, .pos 3816] := by
  change (¬ ((g3804 E)=true)) → (¬ ((g3808 E)=true)) → (¬ ((g3812 E)=true)) → (¬ ((g3816 E)=true)) → (¬ ((g3817 E)=true)) → False
  intro c0 c1 c2 c3 c6
  apply h
  refine ⟨4,5,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 4, edge E 0 5, edge E 0 7]
    apply (mask_ge_two (edge E 0 4) (edge E 0 5) (edge E 0 7)).mp
    change (((g5 E) && (g6 E)) || ((g5 E) && (g8 E)) || ((g6 E) && (g8 E)))=true
    simpa [g3801, g3802, g3803, g3804, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 4, edge E 1 5, edge E 1 7]
    apply (mask_ge_two (edge E 1 4) (edge E 1 5) (edge E 1 7)).mp
    change (((g11 E) && (g12 E)) || ((g11 E) && (g14 E)) || ((g12 E) && (g14 E)))=true
    simpa [g3805, g3806, g3807, g3808, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 4, edge E 2 5, edge E 2 7]
    apply (mask_ge_two (edge E 2 4) (edge E 2 5) (edge E 2 7)).mp
    change (((g16 E) && (g17 E)) || ((g16 E) && (g19 E)) || ((g17 E) && (g19 E)))=true
    simpa [g3809, g3810, g3811, g3812, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 4, edge E 3 5, edge E 3 7]
    apply (mask_ge_two (edge E 3 4) (edge E 3 5) (edge E 3 7)).mp
    change (((g20 E) && (g21 E)) || ((g20 E) && (g23 E)) || ((g21 E) && (g23 E)))=true
    simpa [g3813, g3814, g3815, g3816, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 6 4, edge E 6 5, edge E 6 7]
    apply (mask_ge_one (edge E 6 4) (edge E 6 5) (edge E 6 7)).mp
    change ((g25 E) || (g27 E) || (g29 E))=true
    simpa [g3817, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_4876 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 3840, .pos 3844, .pos 3848, .pos 3852, .pos 3856] := by
  change (¬ ((g3841 E)=true)) → (¬ ((g3845 E)=true)) → (¬ ((g3849 E)=true)) → (¬ ((g3853 E)=true)) → (¬ ((g3857 E)=true)) → False
  intro c0 c1 c2 c3 c4
  apply h
  refine ⟨5,6,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 5, edge E 0 6, edge E 0 7]
    apply (mask_ge_two (edge E 0 5) (edge E 0 6) (edge E 0 7)).mp
    change (((g6 E) && (g7 E)) || ((g6 E) && (g8 E)) || ((g7 E) && (g8 E)))=true
    simpa [g3838, g3839, g3840, g3841, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 5, edge E 1 6, edge E 1 7]
    apply (mask_ge_two (edge E 1 5) (edge E 1 6) (edge E 1 7)).mp
    change (((g12 E) && (g13 E)) || ((g12 E) && (g14 E)) || ((g13 E) && (g14 E)))=true
    simpa [g3842, g3843, g3844, g3845, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 5, edge E 2 6, edge E 2 7]
    apply (mask_ge_two (edge E 2 5) (edge E 2 6) (edge E 2 7)).mp
    change (((g17 E) && (g18 E)) || ((g17 E) && (g19 E)) || ((g18 E) && (g19 E)))=true
    simpa [g3846, g3847, g3848, g3849, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 2≤countTrue [edge E 3 5, edge E 3 6, edge E 3 7]
    apply (mask_ge_two (edge E 3 5) (edge E 3 6) (edge E 3 7)).mp
    change (((g21 E) && (g22 E)) || ((g21 E) && (g23 E)) || ((g22 E) && (g23 E)))=true
    simpa [g3850, g3851, g3852, g3853, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 2≤countTrue [edge E 4 5, edge E 4 6, edge E 4 7]
    apply (mask_ge_two (edge E 4 5) (edge E 4 6) (edge E 4 7)).mp
    change (((g24 E) && (g25 E)) || ((g24 E) && (g26 E)) || ((g25 E) && (g26 E)))=true
    simpa [g3854, g3855, g3856, g3857, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · exact (vc rfl).elim
theorem have_triple_of_exact_counts (E : Nat→Bool)
    (d0 : 3≤degree0_count E)
    (d1 : 3≤degree1_count E)
    (d2 : 3≤degree2_count E)
    (d3 : 3≤degree3_count E)
    (d4 : 3≤degree4_count E)
    (d6 : 3≤degree6_count E)
    (d7 : 3≤degree7_count E)
    (s0 : 2≤score0_count E)
    (s1 : 2≤score1_count E)
    (o01 : score0_count E<score1_count E)
    (o12 : score1_count E<score2_count E)
    (o23 : score2_count E<score3_count E)
    (o34 : score3_count E<score4_count E)
    (o45 : score4_count E<score5_count E)
    (p67 : portRank E 6≤portRank E 7)
    : HasTriple E := by
  by_contra n
  apply contradiction_of_semantic_roots E
  · exact root_34 E d0
  · exact root_65 E d1
  · exact root_96 E d2
  · exact root_117 E d3
  · exact root_140 E d4
  · exact root_181 E d6
  · exact root_217 E d7
  · exact root_3178 E s0
  · exact root_3179 E s1
  · exact root_3180 E o01
  · exact root_3181 E o01
  · exact root_3182 E o01
  · exact root_3183 E o01
  · exact root_3184 E o01
  · exact root_3185 E o01
  · exact root_3186 E o12
  · exact root_3187 E o12
  · exact root_3188 E o12
  · exact root_3189 E o12
  · exact root_3190 E o12
  · exact root_3191 E o12
  · exact root_3192 E o12
  · exact root_3193 E o23
  · exact root_3194 E o23
  · exact root_3195 E o23
  · exact root_3196 E o23
  · exact root_3197 E o23
  · exact root_3198 E o23
  · exact root_3199 E o23
  · exact root_3200 E o34
  · exact root_3201 E o34
  · exact root_3202 E o34
  · exact root_3203 E o34
  · exact root_3204 E o34
  · exact root_3205 E o34
  · exact root_3206 E o34
  · exact root_3207 E o45
  · exact root_3208 E o45
  · exact root_3209 E o45
  · exact root_3210 E o45
  · exact root_3211 E o45
  · exact root_3212 E o45
  · exact root_3213 E o45
  · exact root_3223 E p67
  · exact root_3260 E n
  · exact root_3290 E n
  · exact root_3318 E n
  · exact root_3359 E n
  · exact root_3379 E n
  · exact root_3398 E n
  · exact root_3431 E n
  · exact root_3467 E n
  · exact root_3497 E n
  · exact root_3523 E n
  · exact root_3563 E n
  · exact root_3591 E n
  · exact root_3623 E n
  · exact root_3651 E n
  · exact root_3679 E n
  · exact root_3716 E n
  · exact root_3743 E n
  · exact root_3769 E n
  · exact root_3797 E n
  · exact root_3835 E n
  · exact root_3860 E n
  · exact root_3887 E n
  · exact root_3920 E n
  · exact root_3948 E n
  · exact root_3976 E n
  · exact root_4007 E n
  · exact root_4038 E n
  · exact root_4066 E n
  · exact root_4104 E n
  · exact root_4140 E n
  · exact root_4171 E n
  · exact root_4205 E n
  · exact root_4231 E n
  · exact root_4263 E n
  · exact root_4286 E n
  · exact root_4311 E n
  · exact root_4340 E n
  · exact root_4357 E n
  · exact root_4385 E n
  · exact root_4411 E n
  · exact root_4436 E n
  · exact root_4471 E n
  · exact root_4497 E n
  · exact root_4533 E n
  · exact root_4572 E n
  · exact root_4603 E n
  · exact root_4627 E n
  · exact root_4655 E n
  · exact root_4687 E n
  · exact root_4714 E n
  · exact root_4749 E n
  · exact root_4783 E n
  · exact root_4820 E n
  · exact root_4876 E n
#print axioms have_triple_of_exact_counts
end Graffiti384b.DiversityEleven.PendantCircuit.K6
