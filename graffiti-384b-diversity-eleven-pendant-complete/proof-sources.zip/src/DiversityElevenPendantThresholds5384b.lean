import DiversityElevenPendantWires5384b
namespace Graffiti384b.DiversityEleven.PendantCircuit.K5
set_option maxHeartbeats 3000000
def degree0_vals1 (E : Nat→Bool) : List Bool := (g2 E) :: ([])
def degree0_vals2 (E : Nat→Bool) : List Bool := (g3 E) :: (degree0_vals1 E)
def degree0_vals3 (E : Nat→Bool) : List Bool := (g4 E) :: (degree0_vals2 E)
def degree0_vals4 (E : Nat→Bool) : List Bool := (g5 E) :: (degree0_vals3 E)
def degree0_vals5 (E : Nat→Bool) : List Bool := (g6 E) :: (degree0_vals4 E)
def degree0_vals6 (E : Nat→Bool) : List Bool := (g7 E) :: (degree0_vals5 E)
def degree0_vals7 (E : Nat→Bool) : List Bool := (g8 E) :: (degree0_vals6 E)
theorem degree0_threshold1_0 (E : Nat→Bool) : ((g2 E)=true) ↔ 1≤countTrue (degree0_vals1 E) := by
  have rew : (g2 E) = ((!g1 E) || ((g2 E) && (g1 E))) := by simp [g1,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 1≤countTrue ([] : List Bool) := by
    have hh := count_true_bound ([] : List Bool)
    change countTrue ([] : List Bool)≤0 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬1≤countTrue ([] : List Bool)
    omega
  have T0 : (g1 E)=true ↔ 0≤countTrue ([] : List Bool) := by simp [g1]
  exact threshold_step (g2 E) (!g1 E) (g1 E) 0 (countTrue ([] : List Bool)) T1 T0
theorem degree0_threshold2_1 (E : Nat→Bool) : ((g31 E)=true) ↔ 2≤countTrue (degree0_vals2 E) := by
  have rew : (g31 E) = ((!g1 E) || ((g3 E) && (g2 E))) := by simp [g1,g31,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 2≤countTrue (degree0_vals1 E) := by
    have hh := count_true_bound (degree0_vals1 E)
    change countTrue (degree0_vals1 E)≤1 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬2≤countTrue (degree0_vals1 E)
    omega
  have T0 := degree0_threshold1_0 E
  exact threshold_step (g3 E) (!g1 E) (g2 E) 1 (countTrue (degree0_vals1 E)) T1 T0
theorem degree0_threshold3_2 (E : Nat→Bool) : ((g35 E)=true) ↔ 3≤countTrue (degree0_vals3 E) := by
  have rew : (g35 E) = ((!g1 E) || ((g4 E) && (g31 E))) := by simp [g1,g35,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 3≤countTrue (degree0_vals2 E) := by
    have hh := count_true_bound (degree0_vals2 E)
    change countTrue (degree0_vals2 E)≤2 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬3≤countTrue (degree0_vals2 E)
    omega
  have T0 := degree0_threshold2_1 E
  exact threshold_step (g4 E) (!g1 E) (g31 E) 2 (countTrue (degree0_vals2 E)) T1 T0
theorem degree0_threshold2_0 (E : Nat→Bool) : ((!g30 E)=true) ↔ 1≤countTrue (degree0_vals2 E) := by
  have rew : (!g30 E) = ((g2 E) || ((g3 E) && (g1 E))) := by simp [g1,g30,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree0_threshold1_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree0_vals1 E) := by simp [g1]
  exact threshold_step (g3 E) (g2 E) (g1 E) 0 (countTrue (degree0_vals1 E)) T1 T0
theorem degree0_threshold3_1 (E : Nat→Bool) : ((!g34 E)=true) ↔ 2≤countTrue (degree0_vals3 E) := by
  have rew : (!g34 E) = ((g31 E) || ((g4 E) && (!g30 E))) := by simp [g1,g33,g34,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree0_threshold2_1 E
  have T0 := degree0_threshold2_0 E
  exact threshold_step (g4 E) (g31 E) (!g30 E) 1 (countTrue (degree0_vals2 E)) T1 T0
theorem degree0_threshold4_2 (E : Nat→Bool) : ((!g40 E)=true) ↔ 3≤countTrue (degree0_vals4 E) := by
  have rew : (!g40 E) = ((g35 E) || ((g5 E) && (!g34 E))) := by simp [g1,g39,g40,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree0_threshold3_2 E
  have T0 := degree0_threshold3_1 E
  exact threshold_step (g5 E) (g35 E) (!g34 E) 2 (countTrue (degree0_vals3 E)) T1 T0
theorem degree0_threshold3_0 (E : Nat→Bool) : ((!g32 E)=true) ↔ 1≤countTrue (degree0_vals3 E) := by
  have rew : (!g32 E) = ((!g30 E) || ((g4 E) && (g1 E))) := by simp [g1,g32,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree0_threshold2_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree0_vals2 E) := by simp [g1]
  exact threshold_step (g4 E) (!g30 E) (g1 E) 0 (countTrue (degree0_vals2 E)) T1 T0
theorem degree0_threshold4_1 (E : Nat→Bool) : ((!g38 E)=true) ↔ 2≤countTrue (degree0_vals4 E) := by
  have rew : (!g38 E) = ((!g34 E) || ((g5 E) && (!g32 E))) := by simp [g1,g37,g38,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree0_threshold3_1 E
  have T0 := degree0_threshold3_0 E
  exact threshold_step (g5 E) (!g34 E) (!g32 E) 1 (countTrue (degree0_vals3 E)) T1 T0
theorem degree0_threshold5_2 (E : Nat→Bool) : ((!g46 E)=true) ↔ 3≤countTrue (degree0_vals5 E) := by
  have rew : (!g46 E) = ((!g40 E) || ((g6 E) && (!g38 E))) := by simp [g1,g45,g46,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree0_threshold4_2 E
  have T0 := degree0_threshold4_1 E
  exact threshold_step (g6 E) (!g40 E) (!g38 E) 2 (countTrue (degree0_vals4 E)) T1 T0
theorem degree0_threshold4_0 (E : Nat→Bool) : ((!g36 E)=true) ↔ 1≤countTrue (degree0_vals4 E) := by
  have rew : (!g36 E) = ((!g32 E) || ((g5 E) && (g1 E))) := by simp [g1,g36,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree0_threshold3_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree0_vals3 E) := by simp [g1]
  exact threshold_step (g5 E) (!g32 E) (g1 E) 0 (countTrue (degree0_vals3 E)) T1 T0
theorem degree0_threshold5_1 (E : Nat→Bool) : ((!g44 E)=true) ↔ 2≤countTrue (degree0_vals5 E) := by
  have rew : (!g44 E) = ((!g38 E) || ((g6 E) && (!g36 E))) := by simp [g1,g43,g44,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree0_threshold4_1 E
  have T0 := degree0_threshold4_0 E
  exact threshold_step (g6 E) (!g38 E) (!g36 E) 1 (countTrue (degree0_vals4 E)) T1 T0
theorem degree0_threshold6_2 (E : Nat→Bool) : ((!g54 E)=true) ↔ 3≤countTrue (degree0_vals6 E) := by
  have rew : (!g54 E) = ((!g46 E) || ((g7 E) && (!g44 E))) := by simp [g1,g53,g54,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree0_threshold5_2 E
  have T0 := degree0_threshold5_1 E
  exact threshold_step (g7 E) (!g46 E) (!g44 E) 2 (countTrue (degree0_vals5 E)) T1 T0
theorem degree0_threshold5_0 (E : Nat→Bool) : ((!g42 E)=true) ↔ 1≤countTrue (degree0_vals5 E) := by
  have rew : (!g42 E) = ((!g36 E) || ((g6 E) && (g1 E))) := by simp [g1,g42,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree0_threshold4_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree0_vals4 E) := by simp [g1]
  exact threshold_step (g6 E) (!g36 E) (g1 E) 0 (countTrue (degree0_vals4 E)) T1 T0
theorem degree0_threshold6_1 (E : Nat→Bool) : ((!g52 E)=true) ↔ 2≤countTrue (degree0_vals6 E) := by
  have rew : (!g52 E) = ((!g44 E) || ((g7 E) && (!g42 E))) := by simp [g1,g51,g52,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree0_threshold5_1 E
  have T0 := degree0_threshold5_0 E
  exact threshold_step (g7 E) (!g44 E) (!g42 E) 1 (countTrue (degree0_vals5 E)) T1 T0
theorem degree0_threshold7_2 (E : Nat→Bool) : ((!g64 E)=true) ↔ 3≤countTrue (degree0_vals7 E) := by
  have rew : (!g64 E) = ((!g54 E) || ((g8 E) && (!g52 E))) := by simp [g1,g63,g64,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree0_threshold6_2 E
  have T0 := degree0_threshold6_1 E
  exact threshold_step (g8 E) (!g54 E) (!g52 E) 2 (countTrue (degree0_vals6 E)) T1 T0
def degree0_count (E : Nat→Bool) : Nat := countTrue (degree0_vals7 E)
def degree1_vals1 (E : Nat→Bool) : List Bool := (g2 E) :: ([])
def degree1_vals2 (E : Nat→Bool) : List Bool := (g9 E) :: (degree1_vals1 E)
def degree1_vals3 (E : Nat→Bool) : List Bool := (g10 E) :: (degree1_vals2 E)
def degree1_vals4 (E : Nat→Bool) : List Bool := (g11 E) :: (degree1_vals3 E)
def degree1_vals5 (E : Nat→Bool) : List Bool := (g12 E) :: (degree1_vals4 E)
def degree1_vals6 (E : Nat→Bool) : List Bool := (g13 E) :: (degree1_vals5 E)
def degree1_vals7 (E : Nat→Bool) : List Bool := (g14 E) :: (degree1_vals6 E)
theorem degree1_threshold1_0 (E : Nat→Bool) : ((g2 E)=true) ↔ 1≤countTrue (degree1_vals1 E) := by
  have rew : (g2 E) = ((!g1 E) || ((g2 E) && (g1 E))) := by simp [g1,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 1≤countTrue ([] : List Bool) := by
    have hh := count_true_bound ([] : List Bool)
    change countTrue ([] : List Bool)≤0 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬1≤countTrue ([] : List Bool)
    omega
  have T0 : (g1 E)=true ↔ 0≤countTrue ([] : List Bool) := by simp [g1]
  exact threshold_step (g2 E) (!g1 E) (g1 E) 0 (countTrue ([] : List Bool)) T1 T0
theorem degree1_threshold2_1 (E : Nat→Bool) : ((g73 E)=true) ↔ 2≤countTrue (degree1_vals2 E) := by
  have rew : (g73 E) = ((!g1 E) || ((g9 E) && (g2 E))) := by simp [g1,g73,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 2≤countTrue (degree1_vals1 E) := by
    have hh := count_true_bound (degree1_vals1 E)
    change countTrue (degree1_vals1 E)≤1 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬2≤countTrue (degree1_vals1 E)
    omega
  have T0 := degree1_threshold1_0 E
  exact threshold_step (g9 E) (!g1 E) (g2 E) 1 (countTrue (degree1_vals1 E)) T1 T0
theorem degree1_threshold3_2 (E : Nat→Bool) : ((g77 E)=true) ↔ 3≤countTrue (degree1_vals3 E) := by
  have rew : (g77 E) = ((!g1 E) || ((g10 E) && (g73 E))) := by simp [g1,g77,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 3≤countTrue (degree1_vals2 E) := by
    have hh := count_true_bound (degree1_vals2 E)
    change countTrue (degree1_vals2 E)≤2 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬3≤countTrue (degree1_vals2 E)
    omega
  have T0 := degree1_threshold2_1 E
  exact threshold_step (g10 E) (!g1 E) (g73 E) 2 (countTrue (degree1_vals2 E)) T1 T0
theorem degree1_threshold2_0 (E : Nat→Bool) : ((!g72 E)=true) ↔ 1≤countTrue (degree1_vals2 E) := by
  have rew : (!g72 E) = ((g2 E) || ((g9 E) && (g1 E))) := by simp [g1,g72,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree1_threshold1_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree1_vals1 E) := by simp [g1]
  exact threshold_step (g9 E) (g2 E) (g1 E) 0 (countTrue (degree1_vals1 E)) T1 T0
theorem degree1_threshold3_1 (E : Nat→Bool) : ((!g76 E)=true) ↔ 2≤countTrue (degree1_vals3 E) := by
  have rew : (!g76 E) = ((g73 E) || ((g10 E) && (!g72 E))) := by simp [g1,g75,g76,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree1_threshold2_1 E
  have T0 := degree1_threshold2_0 E
  exact threshold_step (g10 E) (g73 E) (!g72 E) 1 (countTrue (degree1_vals2 E)) T1 T0
theorem degree1_threshold4_2 (E : Nat→Bool) : ((!g82 E)=true) ↔ 3≤countTrue (degree1_vals4 E) := by
  have rew : (!g82 E) = ((g77 E) || ((g11 E) && (!g76 E))) := by simp [g1,g81,g82,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree1_threshold3_2 E
  have T0 := degree1_threshold3_1 E
  exact threshold_step (g11 E) (g77 E) (!g76 E) 2 (countTrue (degree1_vals3 E)) T1 T0
theorem degree1_threshold3_0 (E : Nat→Bool) : ((!g74 E)=true) ↔ 1≤countTrue (degree1_vals3 E) := by
  have rew : (!g74 E) = ((!g72 E) || ((g10 E) && (g1 E))) := by simp [g1,g74,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree1_threshold2_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree1_vals2 E) := by simp [g1]
  exact threshold_step (g10 E) (!g72 E) (g1 E) 0 (countTrue (degree1_vals2 E)) T1 T0
theorem degree1_threshold4_1 (E : Nat→Bool) : ((!g80 E)=true) ↔ 2≤countTrue (degree1_vals4 E) := by
  have rew : (!g80 E) = ((!g76 E) || ((g11 E) && (!g74 E))) := by simp [g1,g79,g80,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree1_threshold3_1 E
  have T0 := degree1_threshold3_0 E
  exact threshold_step (g11 E) (!g76 E) (!g74 E) 1 (countTrue (degree1_vals3 E)) T1 T0
theorem degree1_threshold5_2 (E : Nat→Bool) : ((!g88 E)=true) ↔ 3≤countTrue (degree1_vals5 E) := by
  have rew : (!g88 E) = ((!g82 E) || ((g12 E) && (!g80 E))) := by simp [g1,g87,g88,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree1_threshold4_2 E
  have T0 := degree1_threshold4_1 E
  exact threshold_step (g12 E) (!g82 E) (!g80 E) 2 (countTrue (degree1_vals4 E)) T1 T0
theorem degree1_threshold4_0 (E : Nat→Bool) : ((!g78 E)=true) ↔ 1≤countTrue (degree1_vals4 E) := by
  have rew : (!g78 E) = ((!g74 E) || ((g11 E) && (g1 E))) := by simp [g1,g78,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree1_threshold3_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree1_vals3 E) := by simp [g1]
  exact threshold_step (g11 E) (!g74 E) (g1 E) 0 (countTrue (degree1_vals3 E)) T1 T0
theorem degree1_threshold5_1 (E : Nat→Bool) : ((!g86 E)=true) ↔ 2≤countTrue (degree1_vals5 E) := by
  have rew : (!g86 E) = ((!g80 E) || ((g12 E) && (!g78 E))) := by simp [g1,g85,g86,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree1_threshold4_1 E
  have T0 := degree1_threshold4_0 E
  exact threshold_step (g12 E) (!g80 E) (!g78 E) 1 (countTrue (degree1_vals4 E)) T1 T0
theorem degree1_threshold6_2 (E : Nat→Bool) : ((!g96 E)=true) ↔ 3≤countTrue (degree1_vals6 E) := by
  have rew : (!g96 E) = ((!g88 E) || ((g13 E) && (!g86 E))) := by simp [g1,g95,g96,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree1_threshold5_2 E
  have T0 := degree1_threshold5_1 E
  exact threshold_step (g13 E) (!g88 E) (!g86 E) 2 (countTrue (degree1_vals5 E)) T1 T0
theorem degree1_threshold5_0 (E : Nat→Bool) : ((!g84 E)=true) ↔ 1≤countTrue (degree1_vals5 E) := by
  have rew : (!g84 E) = ((!g78 E) || ((g12 E) && (g1 E))) := by simp [g1,g84,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree1_threshold4_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree1_vals4 E) := by simp [g1]
  exact threshold_step (g12 E) (!g78 E) (g1 E) 0 (countTrue (degree1_vals4 E)) T1 T0
theorem degree1_threshold6_1 (E : Nat→Bool) : ((!g94 E)=true) ↔ 2≤countTrue (degree1_vals6 E) := by
  have rew : (!g94 E) = ((!g86 E) || ((g13 E) && (!g84 E))) := by simp [g1,g93,g94,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree1_threshold5_1 E
  have T0 := degree1_threshold5_0 E
  exact threshold_step (g13 E) (!g86 E) (!g84 E) 1 (countTrue (degree1_vals5 E)) T1 T0
theorem degree1_threshold7_2 (E : Nat→Bool) : ((!g106 E)=true) ↔ 3≤countTrue (degree1_vals7 E) := by
  have rew : (!g106 E) = ((!g96 E) || ((g14 E) && (!g94 E))) := by simp [g1,g105,g106,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree1_threshold6_2 E
  have T0 := degree1_threshold6_1 E
  exact threshold_step (g14 E) (!g96 E) (!g94 E) 2 (countTrue (degree1_vals6 E)) T1 T0
def degree1_count (E : Nat→Bool) : Nat := countTrue (degree1_vals7 E)
def degree2_vals1 (E : Nat→Bool) : List Bool := (g3 E) :: ([])
def degree2_vals2 (E : Nat→Bool) : List Bool := (g9 E) :: (degree2_vals1 E)
def degree2_vals3 (E : Nat→Bool) : List Bool := (g15 E) :: (degree2_vals2 E)
def degree2_vals4 (E : Nat→Bool) : List Bool := (g16 E) :: (degree2_vals3 E)
def degree2_vals5 (E : Nat→Bool) : List Bool := (g17 E) :: (degree2_vals4 E)
def degree2_vals6 (E : Nat→Bool) : List Bool := (g18 E) :: (degree2_vals5 E)
def degree2_vals7 (E : Nat→Bool) : List Bool := (g19 E) :: (degree2_vals6 E)
theorem degree2_threshold1_0 (E : Nat→Bool) : ((g3 E)=true) ↔ 1≤countTrue (degree2_vals1 E) := by
  have rew : (g3 E) = ((!g1 E) || ((g3 E) && (g1 E))) := by simp [g1,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 1≤countTrue ([] : List Bool) := by
    have hh := count_true_bound ([] : List Bool)
    change countTrue ([] : List Bool)≤0 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬1≤countTrue ([] : List Bool)
    omega
  have T0 : (g1 E)=true ↔ 0≤countTrue ([] : List Bool) := by simp [g1]
  exact threshold_step (g3 E) (!g1 E) (g1 E) 0 (countTrue ([] : List Bool)) T1 T0
theorem degree2_threshold2_1 (E : Nat→Bool) : ((g115 E)=true) ↔ 2≤countTrue (degree2_vals2 E) := by
  have rew : (g115 E) = ((!g1 E) || ((g9 E) && (g3 E))) := by simp [g1,g115,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 2≤countTrue (degree2_vals1 E) := by
    have hh := count_true_bound (degree2_vals1 E)
    change countTrue (degree2_vals1 E)≤1 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬2≤countTrue (degree2_vals1 E)
    omega
  have T0 := degree2_threshold1_0 E
  exact threshold_step (g9 E) (!g1 E) (g3 E) 1 (countTrue (degree2_vals1 E)) T1 T0
theorem degree2_threshold3_2 (E : Nat→Bool) : ((g119 E)=true) ↔ 3≤countTrue (degree2_vals3 E) := by
  have rew : (g119 E) = ((!g1 E) || ((g15 E) && (g115 E))) := by simp [g1,g119,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 3≤countTrue (degree2_vals2 E) := by
    have hh := count_true_bound (degree2_vals2 E)
    change countTrue (degree2_vals2 E)≤2 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬3≤countTrue (degree2_vals2 E)
    omega
  have T0 := degree2_threshold2_1 E
  exact threshold_step (g15 E) (!g1 E) (g115 E) 2 (countTrue (degree2_vals2 E)) T1 T0
theorem degree2_threshold2_0 (E : Nat→Bool) : ((!g114 E)=true) ↔ 1≤countTrue (degree2_vals2 E) := by
  have rew : (!g114 E) = ((g3 E) || ((g9 E) && (g1 E))) := by simp [g1,g114,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree2_threshold1_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree2_vals1 E) := by simp [g1]
  exact threshold_step (g9 E) (g3 E) (g1 E) 0 (countTrue (degree2_vals1 E)) T1 T0
theorem degree2_threshold3_1 (E : Nat→Bool) : ((!g118 E)=true) ↔ 2≤countTrue (degree2_vals3 E) := by
  have rew : (!g118 E) = ((g115 E) || ((g15 E) && (!g114 E))) := by simp [g1,g117,g118,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree2_threshold2_1 E
  have T0 := degree2_threshold2_0 E
  exact threshold_step (g15 E) (g115 E) (!g114 E) 1 (countTrue (degree2_vals2 E)) T1 T0
theorem degree2_threshold4_2 (E : Nat→Bool) : ((!g124 E)=true) ↔ 3≤countTrue (degree2_vals4 E) := by
  have rew : (!g124 E) = ((g119 E) || ((g16 E) && (!g118 E))) := by simp [g1,g123,g124,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree2_threshold3_2 E
  have T0 := degree2_threshold3_1 E
  exact threshold_step (g16 E) (g119 E) (!g118 E) 2 (countTrue (degree2_vals3 E)) T1 T0
theorem degree2_threshold3_0 (E : Nat→Bool) : ((!g116 E)=true) ↔ 1≤countTrue (degree2_vals3 E) := by
  have rew : (!g116 E) = ((!g114 E) || ((g15 E) && (g1 E))) := by simp [g1,g116,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree2_threshold2_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree2_vals2 E) := by simp [g1]
  exact threshold_step (g15 E) (!g114 E) (g1 E) 0 (countTrue (degree2_vals2 E)) T1 T0
theorem degree2_threshold4_1 (E : Nat→Bool) : ((!g122 E)=true) ↔ 2≤countTrue (degree2_vals4 E) := by
  have rew : (!g122 E) = ((!g118 E) || ((g16 E) && (!g116 E))) := by simp [g1,g121,g122,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree2_threshold3_1 E
  have T0 := degree2_threshold3_0 E
  exact threshold_step (g16 E) (!g118 E) (!g116 E) 1 (countTrue (degree2_vals3 E)) T1 T0
theorem degree2_threshold5_2 (E : Nat→Bool) : ((!g130 E)=true) ↔ 3≤countTrue (degree2_vals5 E) := by
  have rew : (!g130 E) = ((!g124 E) || ((g17 E) && (!g122 E))) := by simp [g1,g129,g130,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree2_threshold4_2 E
  have T0 := degree2_threshold4_1 E
  exact threshold_step (g17 E) (!g124 E) (!g122 E) 2 (countTrue (degree2_vals4 E)) T1 T0
theorem degree2_threshold4_0 (E : Nat→Bool) : ((!g120 E)=true) ↔ 1≤countTrue (degree2_vals4 E) := by
  have rew : (!g120 E) = ((!g116 E) || ((g16 E) && (g1 E))) := by simp [g1,g120,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree2_threshold3_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree2_vals3 E) := by simp [g1]
  exact threshold_step (g16 E) (!g116 E) (g1 E) 0 (countTrue (degree2_vals3 E)) T1 T0
theorem degree2_threshold5_1 (E : Nat→Bool) : ((!g128 E)=true) ↔ 2≤countTrue (degree2_vals5 E) := by
  have rew : (!g128 E) = ((!g122 E) || ((g17 E) && (!g120 E))) := by simp [g1,g127,g128,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree2_threshold4_1 E
  have T0 := degree2_threshold4_0 E
  exact threshold_step (g17 E) (!g122 E) (!g120 E) 1 (countTrue (degree2_vals4 E)) T1 T0
theorem degree2_threshold6_2 (E : Nat→Bool) : ((!g138 E)=true) ↔ 3≤countTrue (degree2_vals6 E) := by
  have rew : (!g138 E) = ((!g130 E) || ((g18 E) && (!g128 E))) := by simp [g1,g137,g138,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree2_threshold5_2 E
  have T0 := degree2_threshold5_1 E
  exact threshold_step (g18 E) (!g130 E) (!g128 E) 2 (countTrue (degree2_vals5 E)) T1 T0
theorem degree2_threshold5_0 (E : Nat→Bool) : ((!g126 E)=true) ↔ 1≤countTrue (degree2_vals5 E) := by
  have rew : (!g126 E) = ((!g120 E) || ((g17 E) && (g1 E))) := by simp [g1,g126,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree2_threshold4_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree2_vals4 E) := by simp [g1]
  exact threshold_step (g17 E) (!g120 E) (g1 E) 0 (countTrue (degree2_vals4 E)) T1 T0
theorem degree2_threshold6_1 (E : Nat→Bool) : ((!g136 E)=true) ↔ 2≤countTrue (degree2_vals6 E) := by
  have rew : (!g136 E) = ((!g128 E) || ((g18 E) && (!g126 E))) := by simp [g1,g135,g136,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree2_threshold5_1 E
  have T0 := degree2_threshold5_0 E
  exact threshold_step (g18 E) (!g128 E) (!g126 E) 1 (countTrue (degree2_vals5 E)) T1 T0
theorem degree2_threshold7_2 (E : Nat→Bool) : ((!g148 E)=true) ↔ 3≤countTrue (degree2_vals7 E) := by
  have rew : (!g148 E) = ((!g138 E) || ((g19 E) && (!g136 E))) := by simp [g1,g147,g148,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree2_threshold6_2 E
  have T0 := degree2_threshold6_1 E
  exact threshold_step (g19 E) (!g138 E) (!g136 E) 2 (countTrue (degree2_vals6 E)) T1 T0
def degree2_count (E : Nat→Bool) : Nat := countTrue (degree2_vals7 E)
def degree3_vals1 (E : Nat→Bool) : List Bool := (g4 E) :: ([])
def degree3_vals2 (E : Nat→Bool) : List Bool := (g10 E) :: (degree3_vals1 E)
def degree3_vals3 (E : Nat→Bool) : List Bool := (g15 E) :: (degree3_vals2 E)
def degree3_vals4 (E : Nat→Bool) : List Bool := (g20 E) :: (degree3_vals3 E)
def degree3_vals5 (E : Nat→Bool) : List Bool := (g21 E) :: (degree3_vals4 E)
def degree3_vals6 (E : Nat→Bool) : List Bool := (g22 E) :: (degree3_vals5 E)
def degree3_vals7 (E : Nat→Bool) : List Bool := (g23 E) :: (degree3_vals6 E)
theorem degree3_threshold1_0 (E : Nat→Bool) : ((g4 E)=true) ↔ 1≤countTrue (degree3_vals1 E) := by
  have rew : (g4 E) = ((!g1 E) || ((g4 E) && (g1 E))) := by simp [g1,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 1≤countTrue ([] : List Bool) := by
    have hh := count_true_bound ([] : List Bool)
    change countTrue ([] : List Bool)≤0 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬1≤countTrue ([] : List Bool)
    omega
  have T0 : (g1 E)=true ↔ 0≤countTrue ([] : List Bool) := by simp [g1]
  exact threshold_step (g4 E) (!g1 E) (g1 E) 0 (countTrue ([] : List Bool)) T1 T0
theorem degree3_threshold2_1 (E : Nat→Bool) : ((g157 E)=true) ↔ 2≤countTrue (degree3_vals2 E) := by
  have rew : (g157 E) = ((!g1 E) || ((g10 E) && (g4 E))) := by simp [g1,g157,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 2≤countTrue (degree3_vals1 E) := by
    have hh := count_true_bound (degree3_vals1 E)
    change countTrue (degree3_vals1 E)≤1 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬2≤countTrue (degree3_vals1 E)
    omega
  have T0 := degree3_threshold1_0 E
  exact threshold_step (g10 E) (!g1 E) (g4 E) 1 (countTrue (degree3_vals1 E)) T1 T0
theorem degree3_threshold3_2 (E : Nat→Bool) : ((g161 E)=true) ↔ 3≤countTrue (degree3_vals3 E) := by
  have rew : (g161 E) = ((!g1 E) || ((g15 E) && (g157 E))) := by simp [g1,g161,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 3≤countTrue (degree3_vals2 E) := by
    have hh := count_true_bound (degree3_vals2 E)
    change countTrue (degree3_vals2 E)≤2 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬3≤countTrue (degree3_vals2 E)
    omega
  have T0 := degree3_threshold2_1 E
  exact threshold_step (g15 E) (!g1 E) (g157 E) 2 (countTrue (degree3_vals2 E)) T1 T0
theorem degree3_threshold2_0 (E : Nat→Bool) : ((!g156 E)=true) ↔ 1≤countTrue (degree3_vals2 E) := by
  have rew : (!g156 E) = ((g4 E) || ((g10 E) && (g1 E))) := by simp [g1,g156,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree3_threshold1_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree3_vals1 E) := by simp [g1]
  exact threshold_step (g10 E) (g4 E) (g1 E) 0 (countTrue (degree3_vals1 E)) T1 T0
theorem degree3_threshold3_1 (E : Nat→Bool) : ((!g160 E)=true) ↔ 2≤countTrue (degree3_vals3 E) := by
  have rew : (!g160 E) = ((g157 E) || ((g15 E) && (!g156 E))) := by simp [g1,g159,g160,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree3_threshold2_1 E
  have T0 := degree3_threshold2_0 E
  exact threshold_step (g15 E) (g157 E) (!g156 E) 1 (countTrue (degree3_vals2 E)) T1 T0
theorem degree3_threshold4_2 (E : Nat→Bool) : ((!g166 E)=true) ↔ 3≤countTrue (degree3_vals4 E) := by
  have rew : (!g166 E) = ((g161 E) || ((g20 E) && (!g160 E))) := by simp [g1,g165,g166,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree3_threshold3_2 E
  have T0 := degree3_threshold3_1 E
  exact threshold_step (g20 E) (g161 E) (!g160 E) 2 (countTrue (degree3_vals3 E)) T1 T0
theorem degree3_threshold3_0 (E : Nat→Bool) : ((!g158 E)=true) ↔ 1≤countTrue (degree3_vals3 E) := by
  have rew : (!g158 E) = ((!g156 E) || ((g15 E) && (g1 E))) := by simp [g1,g158,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree3_threshold2_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree3_vals2 E) := by simp [g1]
  exact threshold_step (g15 E) (!g156 E) (g1 E) 0 (countTrue (degree3_vals2 E)) T1 T0
theorem degree3_threshold4_1 (E : Nat→Bool) : ((!g164 E)=true) ↔ 2≤countTrue (degree3_vals4 E) := by
  have rew : (!g164 E) = ((!g160 E) || ((g20 E) && (!g158 E))) := by simp [g1,g163,g164,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree3_threshold3_1 E
  have T0 := degree3_threshold3_0 E
  exact threshold_step (g20 E) (!g160 E) (!g158 E) 1 (countTrue (degree3_vals3 E)) T1 T0
theorem degree3_threshold5_2 (E : Nat→Bool) : ((!g172 E)=true) ↔ 3≤countTrue (degree3_vals5 E) := by
  have rew : (!g172 E) = ((!g166 E) || ((g21 E) && (!g164 E))) := by simp [g1,g171,g172,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree3_threshold4_2 E
  have T0 := degree3_threshold4_1 E
  exact threshold_step (g21 E) (!g166 E) (!g164 E) 2 (countTrue (degree3_vals4 E)) T1 T0
theorem degree3_threshold4_0 (E : Nat→Bool) : ((!g162 E)=true) ↔ 1≤countTrue (degree3_vals4 E) := by
  have rew : (!g162 E) = ((!g158 E) || ((g20 E) && (g1 E))) := by simp [g1,g162,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree3_threshold3_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree3_vals3 E) := by simp [g1]
  exact threshold_step (g20 E) (!g158 E) (g1 E) 0 (countTrue (degree3_vals3 E)) T1 T0
theorem degree3_threshold5_1 (E : Nat→Bool) : ((!g170 E)=true) ↔ 2≤countTrue (degree3_vals5 E) := by
  have rew : (!g170 E) = ((!g164 E) || ((g21 E) && (!g162 E))) := by simp [g1,g169,g170,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree3_threshold4_1 E
  have T0 := degree3_threshold4_0 E
  exact threshold_step (g21 E) (!g164 E) (!g162 E) 1 (countTrue (degree3_vals4 E)) T1 T0
theorem degree3_threshold6_2 (E : Nat→Bool) : ((!g180 E)=true) ↔ 3≤countTrue (degree3_vals6 E) := by
  have rew : (!g180 E) = ((!g172 E) || ((g22 E) && (!g170 E))) := by simp [g1,g179,g180,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree3_threshold5_2 E
  have T0 := degree3_threshold5_1 E
  exact threshold_step (g22 E) (!g172 E) (!g170 E) 2 (countTrue (degree3_vals5 E)) T1 T0
theorem degree3_threshold5_0 (E : Nat→Bool) : ((!g168 E)=true) ↔ 1≤countTrue (degree3_vals5 E) := by
  have rew : (!g168 E) = ((!g162 E) || ((g21 E) && (g1 E))) := by simp [g1,g168,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree3_threshold4_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree3_vals4 E) := by simp [g1]
  exact threshold_step (g21 E) (!g162 E) (g1 E) 0 (countTrue (degree3_vals4 E)) T1 T0
theorem degree3_threshold6_1 (E : Nat→Bool) : ((!g178 E)=true) ↔ 2≤countTrue (degree3_vals6 E) := by
  have rew : (!g178 E) = ((!g170 E) || ((g22 E) && (!g168 E))) := by simp [g1,g177,g178,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree3_threshold5_1 E
  have T0 := degree3_threshold5_0 E
  exact threshold_step (g22 E) (!g170 E) (!g168 E) 1 (countTrue (degree3_vals5 E)) T1 T0
theorem degree3_threshold7_2 (E : Nat→Bool) : ((!g190 E)=true) ↔ 3≤countTrue (degree3_vals7 E) := by
  have rew : (!g190 E) = ((!g180 E) || ((g23 E) && (!g178 E))) := by simp [g1,g189,g190,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree3_threshold6_2 E
  have T0 := degree3_threshold6_1 E
  exact threshold_step (g23 E) (!g180 E) (!g178 E) 2 (countTrue (degree3_vals6 E)) T1 T0
def degree3_count (E : Nat→Bool) : Nat := countTrue (degree3_vals7 E)
def degree4_vals1 (E : Nat→Bool) : List Bool := (g5 E) :: ([])
def degree4_vals2 (E : Nat→Bool) : List Bool := (g11 E) :: (degree4_vals1 E)
def degree4_vals3 (E : Nat→Bool) : List Bool := (g16 E) :: (degree4_vals2 E)
def degree4_vals4 (E : Nat→Bool) : List Bool := (g20 E) :: (degree4_vals3 E)
def degree4_vals5 (E : Nat→Bool) : List Bool := (g24 E) :: (degree4_vals4 E)
def degree4_vals6 (E : Nat→Bool) : List Bool := (g25 E) :: (degree4_vals5 E)
def degree4_vals7 (E : Nat→Bool) : List Bool := (g26 E) :: (degree4_vals6 E)
theorem degree4_threshold1_0 (E : Nat→Bool) : ((g5 E)=true) ↔ 1≤countTrue (degree4_vals1 E) := by
  have rew : (g5 E) = ((!g1 E) || ((g5 E) && (g1 E))) := by simp [g1,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 1≤countTrue ([] : List Bool) := by
    have hh := count_true_bound ([] : List Bool)
    change countTrue ([] : List Bool)≤0 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬1≤countTrue ([] : List Bool)
    omega
  have T0 : (g1 E)=true ↔ 0≤countTrue ([] : List Bool) := by simp [g1]
  exact threshold_step (g5 E) (!g1 E) (g1 E) 0 (countTrue ([] : List Bool)) T1 T0
theorem degree4_threshold2_1 (E : Nat→Bool) : ((g199 E)=true) ↔ 2≤countTrue (degree4_vals2 E) := by
  have rew : (g199 E) = ((!g1 E) || ((g11 E) && (g5 E))) := by simp [g1,g199,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 2≤countTrue (degree4_vals1 E) := by
    have hh := count_true_bound (degree4_vals1 E)
    change countTrue (degree4_vals1 E)≤1 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬2≤countTrue (degree4_vals1 E)
    omega
  have T0 := degree4_threshold1_0 E
  exact threshold_step (g11 E) (!g1 E) (g5 E) 1 (countTrue (degree4_vals1 E)) T1 T0
theorem degree4_threshold3_2 (E : Nat→Bool) : ((g203 E)=true) ↔ 3≤countTrue (degree4_vals3 E) := by
  have rew : (g203 E) = ((!g1 E) || ((g16 E) && (g199 E))) := by simp [g1,g203,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 3≤countTrue (degree4_vals2 E) := by
    have hh := count_true_bound (degree4_vals2 E)
    change countTrue (degree4_vals2 E)≤2 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬3≤countTrue (degree4_vals2 E)
    omega
  have T0 := degree4_threshold2_1 E
  exact threshold_step (g16 E) (!g1 E) (g199 E) 2 (countTrue (degree4_vals2 E)) T1 T0
theorem degree4_threshold2_0 (E : Nat→Bool) : ((!g198 E)=true) ↔ 1≤countTrue (degree4_vals2 E) := by
  have rew : (!g198 E) = ((g5 E) || ((g11 E) && (g1 E))) := by simp [g1,g198,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree4_threshold1_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree4_vals1 E) := by simp [g1]
  exact threshold_step (g11 E) (g5 E) (g1 E) 0 (countTrue (degree4_vals1 E)) T1 T0
theorem degree4_threshold3_1 (E : Nat→Bool) : ((!g202 E)=true) ↔ 2≤countTrue (degree4_vals3 E) := by
  have rew : (!g202 E) = ((g199 E) || ((g16 E) && (!g198 E))) := by simp [g1,g201,g202,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree4_threshold2_1 E
  have T0 := degree4_threshold2_0 E
  exact threshold_step (g16 E) (g199 E) (!g198 E) 1 (countTrue (degree4_vals2 E)) T1 T0
theorem degree4_threshold4_2 (E : Nat→Bool) : ((!g208 E)=true) ↔ 3≤countTrue (degree4_vals4 E) := by
  have rew : (!g208 E) = ((g203 E) || ((g20 E) && (!g202 E))) := by simp [g1,g207,g208,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree4_threshold3_2 E
  have T0 := degree4_threshold3_1 E
  exact threshold_step (g20 E) (g203 E) (!g202 E) 2 (countTrue (degree4_vals3 E)) T1 T0
theorem degree4_threshold3_0 (E : Nat→Bool) : ((!g200 E)=true) ↔ 1≤countTrue (degree4_vals3 E) := by
  have rew : (!g200 E) = ((!g198 E) || ((g16 E) && (g1 E))) := by simp [g1,g200,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree4_threshold2_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree4_vals2 E) := by simp [g1]
  exact threshold_step (g16 E) (!g198 E) (g1 E) 0 (countTrue (degree4_vals2 E)) T1 T0
theorem degree4_threshold4_1 (E : Nat→Bool) : ((!g206 E)=true) ↔ 2≤countTrue (degree4_vals4 E) := by
  have rew : (!g206 E) = ((!g202 E) || ((g20 E) && (!g200 E))) := by simp [g1,g205,g206,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree4_threshold3_1 E
  have T0 := degree4_threshold3_0 E
  exact threshold_step (g20 E) (!g202 E) (!g200 E) 1 (countTrue (degree4_vals3 E)) T1 T0
theorem degree4_threshold5_2 (E : Nat→Bool) : ((!g214 E)=true) ↔ 3≤countTrue (degree4_vals5 E) := by
  have rew : (!g214 E) = ((!g208 E) || ((g24 E) && (!g206 E))) := by simp [g1,g213,g214,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree4_threshold4_2 E
  have T0 := degree4_threshold4_1 E
  exact threshold_step (g24 E) (!g208 E) (!g206 E) 2 (countTrue (degree4_vals4 E)) T1 T0
theorem degree4_threshold4_0 (E : Nat→Bool) : ((!g204 E)=true) ↔ 1≤countTrue (degree4_vals4 E) := by
  have rew : (!g204 E) = ((!g200 E) || ((g20 E) && (g1 E))) := by simp [g1,g204,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree4_threshold3_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree4_vals3 E) := by simp [g1]
  exact threshold_step (g20 E) (!g200 E) (g1 E) 0 (countTrue (degree4_vals3 E)) T1 T0
theorem degree4_threshold5_1 (E : Nat→Bool) : ((!g212 E)=true) ↔ 2≤countTrue (degree4_vals5 E) := by
  have rew : (!g212 E) = ((!g206 E) || ((g24 E) && (!g204 E))) := by simp [g1,g211,g212,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree4_threshold4_1 E
  have T0 := degree4_threshold4_0 E
  exact threshold_step (g24 E) (!g206 E) (!g204 E) 1 (countTrue (degree4_vals4 E)) T1 T0
theorem degree4_threshold6_2 (E : Nat→Bool) : ((!g222 E)=true) ↔ 3≤countTrue (degree4_vals6 E) := by
  have rew : (!g222 E) = ((!g214 E) || ((g25 E) && (!g212 E))) := by simp [g1,g221,g222,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree4_threshold5_2 E
  have T0 := degree4_threshold5_1 E
  exact threshold_step (g25 E) (!g214 E) (!g212 E) 2 (countTrue (degree4_vals5 E)) T1 T0
theorem degree4_threshold5_0 (E : Nat→Bool) : ((!g210 E)=true) ↔ 1≤countTrue (degree4_vals5 E) := by
  have rew : (!g210 E) = ((!g204 E) || ((g24 E) && (g1 E))) := by simp [g1,g210,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree4_threshold4_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree4_vals4 E) := by simp [g1]
  exact threshold_step (g24 E) (!g204 E) (g1 E) 0 (countTrue (degree4_vals4 E)) T1 T0
theorem degree4_threshold6_1 (E : Nat→Bool) : ((!g220 E)=true) ↔ 2≤countTrue (degree4_vals6 E) := by
  have rew : (!g220 E) = ((!g212 E) || ((g25 E) && (!g210 E))) := by simp [g1,g219,g220,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree4_threshold5_1 E
  have T0 := degree4_threshold5_0 E
  exact threshold_step (g25 E) (!g212 E) (!g210 E) 1 (countTrue (degree4_vals5 E)) T1 T0
theorem degree4_threshold7_2 (E : Nat→Bool) : ((!g232 E)=true) ↔ 3≤countTrue (degree4_vals7 E) := by
  have rew : (!g232 E) = ((!g222 E) || ((g26 E) && (!g220 E))) := by simp [g1,g231,g232,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree4_threshold6_2 E
  have T0 := degree4_threshold6_1 E
  exact threshold_step (g26 E) (!g222 E) (!g220 E) 2 (countTrue (degree4_vals6 E)) T1 T0
def degree4_count (E : Nat→Bool) : Nat := countTrue (degree4_vals7 E)
def degree5_vals1 (E : Nat→Bool) : List Bool := (g6 E) :: ([])
def degree5_vals2 (E : Nat→Bool) : List Bool := (g12 E) :: (degree5_vals1 E)
def degree5_vals3 (E : Nat→Bool) : List Bool := (g17 E) :: (degree5_vals2 E)
def degree5_vals4 (E : Nat→Bool) : List Bool := (g21 E) :: (degree5_vals3 E)
def degree5_vals5 (E : Nat→Bool) : List Bool := (g24 E) :: (degree5_vals4 E)
def degree5_vals6 (E : Nat→Bool) : List Bool := (g27 E) :: (degree5_vals5 E)
def degree5_vals7 (E : Nat→Bool) : List Bool := (g28 E) :: (degree5_vals6 E)
theorem degree5_threshold1_0 (E : Nat→Bool) : ((g6 E)=true) ↔ 1≤countTrue (degree5_vals1 E) := by
  have rew : (g6 E) = ((!g1 E) || ((g6 E) && (g1 E))) := by simp [g1,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 1≤countTrue ([] : List Bool) := by
    have hh := count_true_bound ([] : List Bool)
    change countTrue ([] : List Bool)≤0 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬1≤countTrue ([] : List Bool)
    omega
  have T0 : (g1 E)=true ↔ 0≤countTrue ([] : List Bool) := by simp [g1]
  exact threshold_step (g6 E) (!g1 E) (g1 E) 0 (countTrue ([] : List Bool)) T1 T0
theorem degree5_threshold2_1 (E : Nat→Bool) : ((g241 E)=true) ↔ 2≤countTrue (degree5_vals2 E) := by
  have rew : (g241 E) = ((!g1 E) || ((g12 E) && (g6 E))) := by simp [g1,g241,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 2≤countTrue (degree5_vals1 E) := by
    have hh := count_true_bound (degree5_vals1 E)
    change countTrue (degree5_vals1 E)≤1 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬2≤countTrue (degree5_vals1 E)
    omega
  have T0 := degree5_threshold1_0 E
  exact threshold_step (g12 E) (!g1 E) (g6 E) 1 (countTrue (degree5_vals1 E)) T1 T0
theorem degree5_threshold3_2 (E : Nat→Bool) : ((g245 E)=true) ↔ 3≤countTrue (degree5_vals3 E) := by
  have rew : (g245 E) = ((!g1 E) || ((g17 E) && (g241 E))) := by simp [g1,g245,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 3≤countTrue (degree5_vals2 E) := by
    have hh := count_true_bound (degree5_vals2 E)
    change countTrue (degree5_vals2 E)≤2 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬3≤countTrue (degree5_vals2 E)
    omega
  have T0 := degree5_threshold2_1 E
  exact threshold_step (g17 E) (!g1 E) (g241 E) 2 (countTrue (degree5_vals2 E)) T1 T0
theorem degree5_threshold2_0 (E : Nat→Bool) : ((!g240 E)=true) ↔ 1≤countTrue (degree5_vals2 E) := by
  have rew : (!g240 E) = ((g6 E) || ((g12 E) && (g1 E))) := by simp [g1,g240,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree5_threshold1_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree5_vals1 E) := by simp [g1]
  exact threshold_step (g12 E) (g6 E) (g1 E) 0 (countTrue (degree5_vals1 E)) T1 T0
theorem degree5_threshold3_1 (E : Nat→Bool) : ((!g244 E)=true) ↔ 2≤countTrue (degree5_vals3 E) := by
  have rew : (!g244 E) = ((g241 E) || ((g17 E) && (!g240 E))) := by simp [g1,g243,g244,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree5_threshold2_1 E
  have T0 := degree5_threshold2_0 E
  exact threshold_step (g17 E) (g241 E) (!g240 E) 1 (countTrue (degree5_vals2 E)) T1 T0
theorem degree5_threshold4_2 (E : Nat→Bool) : ((!g250 E)=true) ↔ 3≤countTrue (degree5_vals4 E) := by
  have rew : (!g250 E) = ((g245 E) || ((g21 E) && (!g244 E))) := by simp [g1,g249,g250,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree5_threshold3_2 E
  have T0 := degree5_threshold3_1 E
  exact threshold_step (g21 E) (g245 E) (!g244 E) 2 (countTrue (degree5_vals3 E)) T1 T0
theorem degree5_threshold3_0 (E : Nat→Bool) : ((!g242 E)=true) ↔ 1≤countTrue (degree5_vals3 E) := by
  have rew : (!g242 E) = ((!g240 E) || ((g17 E) && (g1 E))) := by simp [g1,g242,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree5_threshold2_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree5_vals2 E) := by simp [g1]
  exact threshold_step (g17 E) (!g240 E) (g1 E) 0 (countTrue (degree5_vals2 E)) T1 T0
theorem degree5_threshold4_1 (E : Nat→Bool) : ((!g248 E)=true) ↔ 2≤countTrue (degree5_vals4 E) := by
  have rew : (!g248 E) = ((!g244 E) || ((g21 E) && (!g242 E))) := by simp [g1,g247,g248,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree5_threshold3_1 E
  have T0 := degree5_threshold3_0 E
  exact threshold_step (g21 E) (!g244 E) (!g242 E) 1 (countTrue (degree5_vals3 E)) T1 T0
theorem degree5_threshold5_2 (E : Nat→Bool) : ((!g256 E)=true) ↔ 3≤countTrue (degree5_vals5 E) := by
  have rew : (!g256 E) = ((!g250 E) || ((g24 E) && (!g248 E))) := by simp [g1,g255,g256,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree5_threshold4_2 E
  have T0 := degree5_threshold4_1 E
  exact threshold_step (g24 E) (!g250 E) (!g248 E) 2 (countTrue (degree5_vals4 E)) T1 T0
theorem degree5_threshold4_0 (E : Nat→Bool) : ((!g246 E)=true) ↔ 1≤countTrue (degree5_vals4 E) := by
  have rew : (!g246 E) = ((!g242 E) || ((g21 E) && (g1 E))) := by simp [g1,g246,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree5_threshold3_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree5_vals3 E) := by simp [g1]
  exact threshold_step (g21 E) (!g242 E) (g1 E) 0 (countTrue (degree5_vals3 E)) T1 T0
theorem degree5_threshold5_1 (E : Nat→Bool) : ((!g254 E)=true) ↔ 2≤countTrue (degree5_vals5 E) := by
  have rew : (!g254 E) = ((!g248 E) || ((g24 E) && (!g246 E))) := by simp [g1,g253,g254,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree5_threshold4_1 E
  have T0 := degree5_threshold4_0 E
  exact threshold_step (g24 E) (!g248 E) (!g246 E) 1 (countTrue (degree5_vals4 E)) T1 T0
theorem degree5_threshold6_2 (E : Nat→Bool) : ((!g264 E)=true) ↔ 3≤countTrue (degree5_vals6 E) := by
  have rew : (!g264 E) = ((!g256 E) || ((g27 E) && (!g254 E))) := by simp [g1,g263,g264,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree5_threshold5_2 E
  have T0 := degree5_threshold5_1 E
  exact threshold_step (g27 E) (!g256 E) (!g254 E) 2 (countTrue (degree5_vals5 E)) T1 T0
theorem degree5_threshold5_0 (E : Nat→Bool) : ((!g252 E)=true) ↔ 1≤countTrue (degree5_vals5 E) := by
  have rew : (!g252 E) = ((!g246 E) || ((g24 E) && (g1 E))) := by simp [g1,g252,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree5_threshold4_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree5_vals4 E) := by simp [g1]
  exact threshold_step (g24 E) (!g246 E) (g1 E) 0 (countTrue (degree5_vals4 E)) T1 T0
theorem degree5_threshold6_1 (E : Nat→Bool) : ((!g262 E)=true) ↔ 2≤countTrue (degree5_vals6 E) := by
  have rew : (!g262 E) = ((!g254 E) || ((g27 E) && (!g252 E))) := by simp [g1,g261,g262,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree5_threshold5_1 E
  have T0 := degree5_threshold5_0 E
  exact threshold_step (g27 E) (!g254 E) (!g252 E) 1 (countTrue (degree5_vals5 E)) T1 T0
theorem degree5_threshold7_2 (E : Nat→Bool) : ((!g274 E)=true) ↔ 3≤countTrue (degree5_vals7 E) := by
  have rew : (!g274 E) = ((!g264 E) || ((g28 E) && (!g262 E))) := by simp [g1,g273,g274,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree5_threshold6_2 E
  have T0 := degree5_threshold6_1 E
  exact threshold_step (g28 E) (!g264 E) (!g262 E) 2 (countTrue (degree5_vals6 E)) T1 T0
def degree5_count (E : Nat→Bool) : Nat := countTrue (degree5_vals7 E)
def degree6_vals1 (E : Nat→Bool) : List Bool := (g7 E) :: ([])
def degree6_vals2 (E : Nat→Bool) : List Bool := (g13 E) :: (degree6_vals1 E)
def degree6_vals3 (E : Nat→Bool) : List Bool := (g18 E) :: (degree6_vals2 E)
def degree6_vals4 (E : Nat→Bool) : List Bool := (g22 E) :: (degree6_vals3 E)
def degree6_vals5 (E : Nat→Bool) : List Bool := (g25 E) :: (degree6_vals4 E)
def degree6_vals6 (E : Nat→Bool) : List Bool := (g27 E) :: (degree6_vals5 E)
def degree6_vals7 (E : Nat→Bool) : List Bool := (g29 E) :: (degree6_vals6 E)
theorem degree6_threshold1_0 (E : Nat→Bool) : ((g7 E)=true) ↔ 1≤countTrue (degree6_vals1 E) := by
  have rew : (g7 E) = ((!g1 E) || ((g7 E) && (g1 E))) := by simp [g1,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 1≤countTrue ([] : List Bool) := by
    have hh := count_true_bound ([] : List Bool)
    change countTrue ([] : List Bool)≤0 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬1≤countTrue ([] : List Bool)
    omega
  have T0 : (g1 E)=true ↔ 0≤countTrue ([] : List Bool) := by simp [g1]
  exact threshold_step (g7 E) (!g1 E) (g1 E) 0 (countTrue ([] : List Bool)) T1 T0
theorem degree6_threshold2_1 (E : Nat→Bool) : ((g283 E)=true) ↔ 2≤countTrue (degree6_vals2 E) := by
  have rew : (g283 E) = ((!g1 E) || ((g13 E) && (g7 E))) := by simp [g1,g283,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 2≤countTrue (degree6_vals1 E) := by
    have hh := count_true_bound (degree6_vals1 E)
    change countTrue (degree6_vals1 E)≤1 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬2≤countTrue (degree6_vals1 E)
    omega
  have T0 := degree6_threshold1_0 E
  exact threshold_step (g13 E) (!g1 E) (g7 E) 1 (countTrue (degree6_vals1 E)) T1 T0
theorem degree6_threshold3_2 (E : Nat→Bool) : ((g287 E)=true) ↔ 3≤countTrue (degree6_vals3 E) := by
  have rew : (g287 E) = ((!g1 E) || ((g18 E) && (g283 E))) := by simp [g1,g287,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 3≤countTrue (degree6_vals2 E) := by
    have hh := count_true_bound (degree6_vals2 E)
    change countTrue (degree6_vals2 E)≤2 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬3≤countTrue (degree6_vals2 E)
    omega
  have T0 := degree6_threshold2_1 E
  exact threshold_step (g18 E) (!g1 E) (g283 E) 2 (countTrue (degree6_vals2 E)) T1 T0
theorem degree6_threshold2_0 (E : Nat→Bool) : ((!g282 E)=true) ↔ 1≤countTrue (degree6_vals2 E) := by
  have rew : (!g282 E) = ((g7 E) || ((g13 E) && (g1 E))) := by simp [g1,g282,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree6_threshold1_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree6_vals1 E) := by simp [g1]
  exact threshold_step (g13 E) (g7 E) (g1 E) 0 (countTrue (degree6_vals1 E)) T1 T0
theorem degree6_threshold3_1 (E : Nat→Bool) : ((!g286 E)=true) ↔ 2≤countTrue (degree6_vals3 E) := by
  have rew : (!g286 E) = ((g283 E) || ((g18 E) && (!g282 E))) := by simp [g1,g285,g286,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree6_threshold2_1 E
  have T0 := degree6_threshold2_0 E
  exact threshold_step (g18 E) (g283 E) (!g282 E) 1 (countTrue (degree6_vals2 E)) T1 T0
theorem degree6_threshold4_2 (E : Nat→Bool) : ((!g292 E)=true) ↔ 3≤countTrue (degree6_vals4 E) := by
  have rew : (!g292 E) = ((g287 E) || ((g22 E) && (!g286 E))) := by simp [g1,g291,g292,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree6_threshold3_2 E
  have T0 := degree6_threshold3_1 E
  exact threshold_step (g22 E) (g287 E) (!g286 E) 2 (countTrue (degree6_vals3 E)) T1 T0
theorem degree6_threshold3_0 (E : Nat→Bool) : ((!g284 E)=true) ↔ 1≤countTrue (degree6_vals3 E) := by
  have rew : (!g284 E) = ((!g282 E) || ((g18 E) && (g1 E))) := by simp [g1,g284,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree6_threshold2_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree6_vals2 E) := by simp [g1]
  exact threshold_step (g18 E) (!g282 E) (g1 E) 0 (countTrue (degree6_vals2 E)) T1 T0
theorem degree6_threshold4_1 (E : Nat→Bool) : ((!g290 E)=true) ↔ 2≤countTrue (degree6_vals4 E) := by
  have rew : (!g290 E) = ((!g286 E) || ((g22 E) && (!g284 E))) := by simp [g1,g289,g290,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree6_threshold3_1 E
  have T0 := degree6_threshold3_0 E
  exact threshold_step (g22 E) (!g286 E) (!g284 E) 1 (countTrue (degree6_vals3 E)) T1 T0
theorem degree6_threshold5_2 (E : Nat→Bool) : ((!g298 E)=true) ↔ 3≤countTrue (degree6_vals5 E) := by
  have rew : (!g298 E) = ((!g292 E) || ((g25 E) && (!g290 E))) := by simp [g1,g297,g298,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree6_threshold4_2 E
  have T0 := degree6_threshold4_1 E
  exact threshold_step (g25 E) (!g292 E) (!g290 E) 2 (countTrue (degree6_vals4 E)) T1 T0
theorem degree6_threshold4_0 (E : Nat→Bool) : ((!g288 E)=true) ↔ 1≤countTrue (degree6_vals4 E) := by
  have rew : (!g288 E) = ((!g284 E) || ((g22 E) && (g1 E))) := by simp [g1,g288,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree6_threshold3_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree6_vals3 E) := by simp [g1]
  exact threshold_step (g22 E) (!g284 E) (g1 E) 0 (countTrue (degree6_vals3 E)) T1 T0
theorem degree6_threshold5_1 (E : Nat→Bool) : ((!g296 E)=true) ↔ 2≤countTrue (degree6_vals5 E) := by
  have rew : (!g296 E) = ((!g290 E) || ((g25 E) && (!g288 E))) := by simp [g1,g295,g296,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree6_threshold4_1 E
  have T0 := degree6_threshold4_0 E
  exact threshold_step (g25 E) (!g290 E) (!g288 E) 1 (countTrue (degree6_vals4 E)) T1 T0
theorem degree6_threshold6_2 (E : Nat→Bool) : ((!g306 E)=true) ↔ 3≤countTrue (degree6_vals6 E) := by
  have rew : (!g306 E) = ((!g298 E) || ((g27 E) && (!g296 E))) := by simp [g1,g305,g306,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree6_threshold5_2 E
  have T0 := degree6_threshold5_1 E
  exact threshold_step (g27 E) (!g298 E) (!g296 E) 2 (countTrue (degree6_vals5 E)) T1 T0
theorem degree6_threshold5_0 (E : Nat→Bool) : ((!g294 E)=true) ↔ 1≤countTrue (degree6_vals5 E) := by
  have rew : (!g294 E) = ((!g288 E) || ((g25 E) && (g1 E))) := by simp [g1,g294,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree6_threshold4_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree6_vals4 E) := by simp [g1]
  exact threshold_step (g25 E) (!g288 E) (g1 E) 0 (countTrue (degree6_vals4 E)) T1 T0
theorem degree6_threshold6_1 (E : Nat→Bool) : ((!g304 E)=true) ↔ 2≤countTrue (degree6_vals6 E) := by
  have rew : (!g304 E) = ((!g296 E) || ((g27 E) && (!g294 E))) := by simp [g1,g303,g304,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree6_threshold5_1 E
  have T0 := degree6_threshold5_0 E
  exact threshold_step (g27 E) (!g296 E) (!g294 E) 1 (countTrue (degree6_vals5 E)) T1 T0
theorem degree6_threshold7_2 (E : Nat→Bool) : ((!g316 E)=true) ↔ 3≤countTrue (degree6_vals7 E) := by
  have rew : (!g316 E) = ((!g306 E) || ((g29 E) && (!g304 E))) := by simp [g1,g315,g316,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree6_threshold6_2 E
  have T0 := degree6_threshold6_1 E
  exact threshold_step (g29 E) (!g306 E) (!g304 E) 2 (countTrue (degree6_vals6 E)) T1 T0
def degree6_count (E : Nat→Bool) : Nat := countTrue (degree6_vals7 E)
def degree7_vals1 (E : Nat→Bool) : List Bool := (g8 E) :: ([])
def degree7_vals2 (E : Nat→Bool) : List Bool := (g14 E) :: (degree7_vals1 E)
def degree7_vals3 (E : Nat→Bool) : List Bool := (g19 E) :: (degree7_vals2 E)
def degree7_vals4 (E : Nat→Bool) : List Bool := (g23 E) :: (degree7_vals3 E)
def degree7_vals5 (E : Nat→Bool) : List Bool := (g26 E) :: (degree7_vals4 E)
def degree7_vals6 (E : Nat→Bool) : List Bool := (g28 E) :: (degree7_vals5 E)
def degree7_vals7 (E : Nat→Bool) : List Bool := (g29 E) :: (degree7_vals6 E)
theorem degree7_threshold1_0 (E : Nat→Bool) : ((g8 E)=true) ↔ 1≤countTrue (degree7_vals1 E) := by
  have rew : (g8 E) = ((!g1 E) || ((g8 E) && (g1 E))) := by simp [g1,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 1≤countTrue ([] : List Bool) := by
    have hh := count_true_bound ([] : List Bool)
    change countTrue ([] : List Bool)≤0 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬1≤countTrue ([] : List Bool)
    omega
  have T0 : (g1 E)=true ↔ 0≤countTrue ([] : List Bool) := by simp [g1]
  exact threshold_step (g8 E) (!g1 E) (g1 E) 0 (countTrue ([] : List Bool)) T1 T0
theorem degree7_threshold2_1 (E : Nat→Bool) : ((g325 E)=true) ↔ 2≤countTrue (degree7_vals2 E) := by
  have rew : (g325 E) = ((!g1 E) || ((g14 E) && (g8 E))) := by simp [g1,g325,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 2≤countTrue (degree7_vals1 E) := by
    have hh := count_true_bound (degree7_vals1 E)
    change countTrue (degree7_vals1 E)≤1 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬2≤countTrue (degree7_vals1 E)
    omega
  have T0 := degree7_threshold1_0 E
  exact threshold_step (g14 E) (!g1 E) (g8 E) 1 (countTrue (degree7_vals1 E)) T1 T0
theorem degree7_threshold3_2 (E : Nat→Bool) : ((g329 E)=true) ↔ 3≤countTrue (degree7_vals3 E) := by
  have rew : (g329 E) = ((!g1 E) || ((g19 E) && (g325 E))) := by simp [g1,g329,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 3≤countTrue (degree7_vals2 E) := by
    have hh := count_true_bound (degree7_vals2 E)
    change countTrue (degree7_vals2 E)≤2 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬3≤countTrue (degree7_vals2 E)
    omega
  have T0 := degree7_threshold2_1 E
  exact threshold_step (g19 E) (!g1 E) (g325 E) 2 (countTrue (degree7_vals2 E)) T1 T0
theorem degree7_threshold2_0 (E : Nat→Bool) : ((!g324 E)=true) ↔ 1≤countTrue (degree7_vals2 E) := by
  have rew : (!g324 E) = ((g8 E) || ((g14 E) && (g1 E))) := by simp [g1,g324,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree7_threshold1_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree7_vals1 E) := by simp [g1]
  exact threshold_step (g14 E) (g8 E) (g1 E) 0 (countTrue (degree7_vals1 E)) T1 T0
theorem degree7_threshold3_1 (E : Nat→Bool) : ((!g328 E)=true) ↔ 2≤countTrue (degree7_vals3 E) := by
  have rew : (!g328 E) = ((g325 E) || ((g19 E) && (!g324 E))) := by simp [g1,g327,g328,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree7_threshold2_1 E
  have T0 := degree7_threshold2_0 E
  exact threshold_step (g19 E) (g325 E) (!g324 E) 1 (countTrue (degree7_vals2 E)) T1 T0
theorem degree7_threshold4_2 (E : Nat→Bool) : ((!g334 E)=true) ↔ 3≤countTrue (degree7_vals4 E) := by
  have rew : (!g334 E) = ((g329 E) || ((g23 E) && (!g328 E))) := by simp [g1,g333,g334,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree7_threshold3_2 E
  have T0 := degree7_threshold3_1 E
  exact threshold_step (g23 E) (g329 E) (!g328 E) 2 (countTrue (degree7_vals3 E)) T1 T0
theorem degree7_threshold3_0 (E : Nat→Bool) : ((!g326 E)=true) ↔ 1≤countTrue (degree7_vals3 E) := by
  have rew : (!g326 E) = ((!g324 E) || ((g19 E) && (g1 E))) := by simp [g1,g326,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree7_threshold2_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree7_vals2 E) := by simp [g1]
  exact threshold_step (g19 E) (!g324 E) (g1 E) 0 (countTrue (degree7_vals2 E)) T1 T0
theorem degree7_threshold4_1 (E : Nat→Bool) : ((!g332 E)=true) ↔ 2≤countTrue (degree7_vals4 E) := by
  have rew : (!g332 E) = ((!g328 E) || ((g23 E) && (!g326 E))) := by simp [g1,g331,g332,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree7_threshold3_1 E
  have T0 := degree7_threshold3_0 E
  exact threshold_step (g23 E) (!g328 E) (!g326 E) 1 (countTrue (degree7_vals3 E)) T1 T0
theorem degree7_threshold5_2 (E : Nat→Bool) : ((!g340 E)=true) ↔ 3≤countTrue (degree7_vals5 E) := by
  have rew : (!g340 E) = ((!g334 E) || ((g26 E) && (!g332 E))) := by simp [g1,g339,g340,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree7_threshold4_2 E
  have T0 := degree7_threshold4_1 E
  exact threshold_step (g26 E) (!g334 E) (!g332 E) 2 (countTrue (degree7_vals4 E)) T1 T0
theorem degree7_threshold4_0 (E : Nat→Bool) : ((!g330 E)=true) ↔ 1≤countTrue (degree7_vals4 E) := by
  have rew : (!g330 E) = ((!g326 E) || ((g23 E) && (g1 E))) := by simp [g1,g330,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree7_threshold3_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree7_vals3 E) := by simp [g1]
  exact threshold_step (g23 E) (!g326 E) (g1 E) 0 (countTrue (degree7_vals3 E)) T1 T0
theorem degree7_threshold5_1 (E : Nat→Bool) : ((!g338 E)=true) ↔ 2≤countTrue (degree7_vals5 E) := by
  have rew : (!g338 E) = ((!g332 E) || ((g26 E) && (!g330 E))) := by simp [g1,g337,g338,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree7_threshold4_1 E
  have T0 := degree7_threshold4_0 E
  exact threshold_step (g26 E) (!g332 E) (!g330 E) 1 (countTrue (degree7_vals4 E)) T1 T0
theorem degree7_threshold6_2 (E : Nat→Bool) : ((!g348 E)=true) ↔ 3≤countTrue (degree7_vals6 E) := by
  have rew : (!g348 E) = ((!g340 E) || ((g28 E) && (!g338 E))) := by simp [g1,g347,g348,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree7_threshold5_2 E
  have T0 := degree7_threshold5_1 E
  exact threshold_step (g28 E) (!g340 E) (!g338 E) 2 (countTrue (degree7_vals5 E)) T1 T0
theorem degree7_threshold5_0 (E : Nat→Bool) : ((!g336 E)=true) ↔ 1≤countTrue (degree7_vals5 E) := by
  have rew : (!g336 E) = ((!g330 E) || ((g26 E) && (g1 E))) := by simp [g1,g336,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree7_threshold4_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree7_vals4 E) := by simp [g1]
  exact threshold_step (g26 E) (!g330 E) (g1 E) 0 (countTrue (degree7_vals4 E)) T1 T0
theorem degree7_threshold6_1 (E : Nat→Bool) : ((!g346 E)=true) ↔ 2≤countTrue (degree7_vals6 E) := by
  have rew : (!g346 E) = ((!g338 E) || ((g28 E) && (!g336 E))) := by simp [g1,g345,g346,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree7_threshold5_1 E
  have T0 := degree7_threshold5_0 E
  exact threshold_step (g28 E) (!g338 E) (!g336 E) 1 (countTrue (degree7_vals5 E)) T1 T0
theorem degree7_threshold7_2 (E : Nat→Bool) : ((!g358 E)=true) ↔ 3≤countTrue (degree7_vals7 E) := by
  have rew : (!g358 E) = ((!g348 E) || ((g29 E) && (!g346 E))) := by simp [g1,g357,g358,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree7_threshold6_2 E
  have T0 := degree7_threshold6_1 E
  exact threshold_step (g29 E) (!g348 E) (!g346 E) 2 (countTrue (degree7_vals6 E)) T1 T0
def degree7_count (E : Nat→Bool) : Nat := countTrue (degree7_vals7 E)
def score0_vals1 (E : Nat→Bool) : List Bool := (g366 E) :: ([])
def score0_vals2 (E : Nat→Bool) : List Bool := (g367 E) :: (score0_vals1 E)
def score0_vals3 (E : Nat→Bool) : List Bool := (g368 E) :: (score0_vals2 E)
def score0_vals4 (E : Nat→Bool) : List Bool := (g369 E) :: (score0_vals3 E)
def score0_vals5 (E : Nat→Bool) : List Bool := (g370 E) :: (score0_vals4 E)
def score0_vals6 (E : Nat→Bool) : List Bool := (g371 E) :: (score0_vals5 E)
def score0_vals7 (E : Nat→Bool) : List Bool := (g372 E) :: (score0_vals6 E)
def score0_vals8 (E : Nat→Bool) : List Bool := (g373 E) :: (score0_vals7 E)
def score0_vals9 (E : Nat→Bool) : List Bool := (g374 E) :: (score0_vals8 E)
def score0_vals10 (E : Nat→Bool) : List Bool := (g375 E) :: (score0_vals9 E)
def score0_vals11 (E : Nat→Bool) : List Bool := (g376 E) :: (score0_vals10 E)
def score0_vals12 (E : Nat→Bool) : List Bool := (g377 E) :: (score0_vals11 E)
def score0_vals13 (E : Nat→Bool) : List Bool := (g378 E) :: (score0_vals12 E)
def score0_vals14 (E : Nat→Bool) : List Bool := (g379 E) :: (score0_vals13 E)
def score0_vals15 (E : Nat→Bool) : List Bool := (g380 E) :: (score0_vals14 E)
def score0_vals16 (E : Nat→Bool) : List Bool := (g381 E) :: (score0_vals15 E)
def score0_vals17 (E : Nat→Bool) : List Bool := (g382 E) :: (score0_vals16 E)
def score0_vals18 (E : Nat→Bool) : List Bool := (g383 E) :: (score0_vals17 E)
def score0_vals19 (E : Nat→Bool) : List Bool := (g384 E) :: (score0_vals18 E)
def score0_vals20 (E : Nat→Bool) : List Bool := (g385 E) :: (score0_vals19 E)
def score0_vals21 (E : Nat→Bool) : List Bool := (g386 E) :: (score0_vals20 E)
theorem score0_threshold1_0 (E : Nat→Bool) : ((g366 E)=true) ↔ 1≤countTrue (score0_vals1 E) := by
  have rew : (g366 E) = ((!g1 E) || ((g366 E) && (g1 E))) := by simp [g1,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 1≤countTrue ([] : List Bool) := by
    have hh := count_true_bound ([] : List Bool)
    change countTrue ([] : List Bool)≤0 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬1≤countTrue ([] : List Bool)
    omega
  have T0 : (g1 E)=true ↔ 0≤countTrue ([] : List Bool) := by simp [g1]
  exact threshold_step (g366 E) (!g1 E) (g1 E) 0 (countTrue ([] : List Bool)) T1 T0
theorem score0_threshold2_1 (E : Nat→Bool) : ((g423 E)=true) ↔ 2≤countTrue (score0_vals2 E) := by
  have rew : (g423 E) = ((!g1 E) || ((g367 E) && (g366 E))) := by simp [g1,g423,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 2≤countTrue (score0_vals1 E) := by
    have hh := count_true_bound (score0_vals1 E)
    change countTrue (score0_vals1 E)≤1 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬2≤countTrue (score0_vals1 E)
    omega
  have T0 := score0_threshold1_0 E
  exact threshold_step (g367 E) (!g1 E) (g366 E) 1 (countTrue (score0_vals1 E)) T1 T0
theorem score0_threshold2_0 (E : Nat→Bool) : ((!g422 E)=true) ↔ 1≤countTrue (score0_vals2 E) := by
  have rew : (!g422 E) = ((g366 E) || ((g367 E) && (g1 E))) := by simp [g1,g422,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold1_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals1 E) := by simp [g1]
  exact threshold_step (g367 E) (g366 E) (g1 E) 0 (countTrue (score0_vals1 E)) T1 T0
theorem score0_threshold3_1 (E : Nat→Bool) : ((!g426 E)=true) ↔ 2≤countTrue (score0_vals3 E) := by
  have rew : (!g426 E) = ((g423 E) || ((g368 E) && (!g422 E))) := by simp [g1,g425,g426,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold2_1 E
  have T0 := score0_threshold2_0 E
  exact threshold_step (g368 E) (g423 E) (!g422 E) 1 (countTrue (score0_vals2 E)) T1 T0
theorem score0_threshold3_0 (E : Nat→Bool) : ((!g424 E)=true) ↔ 1≤countTrue (score0_vals3 E) := by
  have rew : (!g424 E) = ((!g422 E) || ((g368 E) && (g1 E))) := by simp [g1,g424,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold2_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals2 E) := by simp [g1]
  exact threshold_step (g368 E) (!g422 E) (g1 E) 0 (countTrue (score0_vals2 E)) T1 T0
theorem score0_threshold4_1 (E : Nat→Bool) : ((!g430 E)=true) ↔ 2≤countTrue (score0_vals4 E) := by
  have rew : (!g430 E) = ((!g426 E) || ((g369 E) && (!g424 E))) := by simp [g1,g429,g430,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold3_1 E
  have T0 := score0_threshold3_0 E
  exact threshold_step (g369 E) (!g426 E) (!g424 E) 1 (countTrue (score0_vals3 E)) T1 T0
theorem score0_threshold4_0 (E : Nat→Bool) : ((!g428 E)=true) ↔ 1≤countTrue (score0_vals4 E) := by
  have rew : (!g428 E) = ((!g424 E) || ((g369 E) && (g1 E))) := by simp [g1,g428,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold3_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals3 E) := by simp [g1]
  exact threshold_step (g369 E) (!g424 E) (g1 E) 0 (countTrue (score0_vals3 E)) T1 T0
theorem score0_threshold5_1 (E : Nat→Bool) : ((!g436 E)=true) ↔ 2≤countTrue (score0_vals5 E) := by
  have rew : (!g436 E) = ((!g430 E) || ((g370 E) && (!g428 E))) := by simp [g1,g435,g436,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold4_1 E
  have T0 := score0_threshold4_0 E
  exact threshold_step (g370 E) (!g430 E) (!g428 E) 1 (countTrue (score0_vals4 E)) T1 T0
theorem score0_threshold5_0 (E : Nat→Bool) : ((!g434 E)=true) ↔ 1≤countTrue (score0_vals5 E) := by
  have rew : (!g434 E) = ((!g428 E) || ((g370 E) && (g1 E))) := by simp [g1,g434,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold4_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals4 E) := by simp [g1]
  exact threshold_step (g370 E) (!g428 E) (g1 E) 0 (countTrue (score0_vals4 E)) T1 T0
theorem score0_threshold6_1 (E : Nat→Bool) : ((!g444 E)=true) ↔ 2≤countTrue (score0_vals6 E) := by
  have rew : (!g444 E) = ((!g436 E) || ((g371 E) && (!g434 E))) := by simp [g1,g443,g444,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold5_1 E
  have T0 := score0_threshold5_0 E
  exact threshold_step (g371 E) (!g436 E) (!g434 E) 1 (countTrue (score0_vals5 E)) T1 T0
theorem score0_threshold6_0 (E : Nat→Bool) : ((!g442 E)=true) ↔ 1≤countTrue (score0_vals6 E) := by
  have rew : (!g442 E) = ((!g434 E) || ((g371 E) && (g1 E))) := by simp [g1,g442,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold5_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals5 E) := by simp [g1]
  exact threshold_step (g371 E) (!g434 E) (g1 E) 0 (countTrue (score0_vals5 E)) T1 T0
theorem score0_threshold7_1 (E : Nat→Bool) : ((!g454 E)=true) ↔ 2≤countTrue (score0_vals7 E) := by
  have rew : (!g454 E) = ((!g444 E) || ((g372 E) && (!g442 E))) := by simp [g1,g453,g454,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold6_1 E
  have T0 := score0_threshold6_0 E
  exact threshold_step (g372 E) (!g444 E) (!g442 E) 1 (countTrue (score0_vals6 E)) T1 T0
theorem score0_threshold7_0 (E : Nat→Bool) : ((!g452 E)=true) ↔ 1≤countTrue (score0_vals7 E) := by
  have rew : (!g452 E) = ((!g442 E) || ((g372 E) && (g1 E))) := by simp [g1,g452,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold6_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals6 E) := by simp [g1]
  exact threshold_step (g372 E) (!g442 E) (g1 E) 0 (countTrue (score0_vals6 E)) T1 T0
theorem score0_threshold8_1 (E : Nat→Bool) : ((!g466 E)=true) ↔ 2≤countTrue (score0_vals8 E) := by
  have rew : (!g466 E) = ((!g454 E) || ((g373 E) && (!g452 E))) := by simp [g1,g465,g466,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold7_1 E
  have T0 := score0_threshold7_0 E
  exact threshold_step (g373 E) (!g454 E) (!g452 E) 1 (countTrue (score0_vals7 E)) T1 T0
theorem score0_threshold8_0 (E : Nat→Bool) : ((!g464 E)=true) ↔ 1≤countTrue (score0_vals8 E) := by
  have rew : (!g464 E) = ((!g452 E) || ((g373 E) && (g1 E))) := by simp [g1,g464,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold7_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals7 E) := by simp [g1]
  exact threshold_step (g373 E) (!g452 E) (g1 E) 0 (countTrue (score0_vals7 E)) T1 T0
theorem score0_threshold9_1 (E : Nat→Bool) : ((!g480 E)=true) ↔ 2≤countTrue (score0_vals9 E) := by
  have rew : (!g480 E) = ((!g466 E) || ((g374 E) && (!g464 E))) := by simp [g1,g479,g480,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold8_1 E
  have T0 := score0_threshold8_0 E
  exact threshold_step (g374 E) (!g466 E) (!g464 E) 1 (countTrue (score0_vals8 E)) T1 T0
theorem score0_threshold9_0 (E : Nat→Bool) : ((!g478 E)=true) ↔ 1≤countTrue (score0_vals9 E) := by
  have rew : (!g478 E) = ((!g464 E) || ((g374 E) && (g1 E))) := by simp [g1,g478,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold8_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals8 E) := by simp [g1]
  exact threshold_step (g374 E) (!g464 E) (g1 E) 0 (countTrue (score0_vals8 E)) T1 T0
theorem score0_threshold10_1 (E : Nat→Bool) : ((!g496 E)=true) ↔ 2≤countTrue (score0_vals10 E) := by
  have rew : (!g496 E) = ((!g480 E) || ((g375 E) && (!g478 E))) := by simp [g1,g495,g496,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold9_1 E
  have T0 := score0_threshold9_0 E
  exact threshold_step (g375 E) (!g480 E) (!g478 E) 1 (countTrue (score0_vals9 E)) T1 T0
theorem score0_threshold10_0 (E : Nat→Bool) : ((!g494 E)=true) ↔ 1≤countTrue (score0_vals10 E) := by
  have rew : (!g494 E) = ((!g478 E) || ((g375 E) && (g1 E))) := by simp [g1,g494,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold9_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals9 E) := by simp [g1]
  exact threshold_step (g375 E) (!g478 E) (g1 E) 0 (countTrue (score0_vals9 E)) T1 T0
theorem score0_threshold11_1 (E : Nat→Bool) : ((!g514 E)=true) ↔ 2≤countTrue (score0_vals11 E) := by
  have rew : (!g514 E) = ((!g496 E) || ((g376 E) && (!g494 E))) := by simp [g1,g513,g514,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold10_1 E
  have T0 := score0_threshold10_0 E
  exact threshold_step (g376 E) (!g496 E) (!g494 E) 1 (countTrue (score0_vals10 E)) T1 T0
theorem score0_threshold11_0 (E : Nat→Bool) : ((!g512 E)=true) ↔ 1≤countTrue (score0_vals11 E) := by
  have rew : (!g512 E) = ((!g494 E) || ((g376 E) && (g1 E))) := by simp [g1,g512,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold10_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals10 E) := by simp [g1]
  exact threshold_step (g376 E) (!g494 E) (g1 E) 0 (countTrue (score0_vals10 E)) T1 T0
theorem score0_threshold12_1 (E : Nat→Bool) : ((!g534 E)=true) ↔ 2≤countTrue (score0_vals12 E) := by
  have rew : (!g534 E) = ((!g514 E) || ((g377 E) && (!g512 E))) := by simp [g1,g533,g534,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold11_1 E
  have T0 := score0_threshold11_0 E
  exact threshold_step (g377 E) (!g514 E) (!g512 E) 1 (countTrue (score0_vals11 E)) T1 T0
theorem score0_threshold12_0 (E : Nat→Bool) : ((!g532 E)=true) ↔ 1≤countTrue (score0_vals12 E) := by
  have rew : (!g532 E) = ((!g512 E) || ((g377 E) && (g1 E))) := by simp [g1,g532,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold11_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals11 E) := by simp [g1]
  exact threshold_step (g377 E) (!g512 E) (g1 E) 0 (countTrue (score0_vals11 E)) T1 T0
theorem score0_threshold13_1 (E : Nat→Bool) : ((!g556 E)=true) ↔ 2≤countTrue (score0_vals13 E) := by
  have rew : (!g556 E) = ((!g534 E) || ((g378 E) && (!g532 E))) := by simp [g1,g555,g556,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold12_1 E
  have T0 := score0_threshold12_0 E
  exact threshold_step (g378 E) (!g534 E) (!g532 E) 1 (countTrue (score0_vals12 E)) T1 T0
theorem score0_threshold13_0 (E : Nat→Bool) : ((!g554 E)=true) ↔ 1≤countTrue (score0_vals13 E) := by
  have rew : (!g554 E) = ((!g532 E) || ((g378 E) && (g1 E))) := by simp [g1,g554,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold12_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals12 E) := by simp [g1]
  exact threshold_step (g378 E) (!g532 E) (g1 E) 0 (countTrue (score0_vals12 E)) T1 T0
theorem score0_threshold14_1 (E : Nat→Bool) : ((!g580 E)=true) ↔ 2≤countTrue (score0_vals14 E) := by
  have rew : (!g580 E) = ((!g556 E) || ((g379 E) && (!g554 E))) := by simp [g1,g579,g580,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold13_1 E
  have T0 := score0_threshold13_0 E
  exact threshold_step (g379 E) (!g556 E) (!g554 E) 1 (countTrue (score0_vals13 E)) T1 T0
theorem score0_threshold14_0 (E : Nat→Bool) : ((!g578 E)=true) ↔ 1≤countTrue (score0_vals14 E) := by
  have rew : (!g578 E) = ((!g554 E) || ((g379 E) && (g1 E))) := by simp [g1,g578,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold13_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals13 E) := by simp [g1]
  exact threshold_step (g379 E) (!g554 E) (g1 E) 0 (countTrue (score0_vals13 E)) T1 T0
theorem score0_threshold15_1 (E : Nat→Bool) : ((!g606 E)=true) ↔ 2≤countTrue (score0_vals15 E) := by
  have rew : (!g606 E) = ((!g580 E) || ((g380 E) && (!g578 E))) := by simp [g1,g605,g606,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold14_1 E
  have T0 := score0_threshold14_0 E
  exact threshold_step (g380 E) (!g580 E) (!g578 E) 1 (countTrue (score0_vals14 E)) T1 T0
theorem score0_threshold15_0 (E : Nat→Bool) : ((!g604 E)=true) ↔ 1≤countTrue (score0_vals15 E) := by
  have rew : (!g604 E) = ((!g578 E) || ((g380 E) && (g1 E))) := by simp [g1,g604,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold14_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals14 E) := by simp [g1]
  exact threshold_step (g380 E) (!g578 E) (g1 E) 0 (countTrue (score0_vals14 E)) T1 T0
theorem score0_threshold16_1 (E : Nat→Bool) : ((!g634 E)=true) ↔ 2≤countTrue (score0_vals16 E) := by
  have rew : (!g634 E) = ((!g606 E) || ((g381 E) && (!g604 E))) := by simp [g1,g633,g634,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold15_1 E
  have T0 := score0_threshold15_0 E
  exact threshold_step (g381 E) (!g606 E) (!g604 E) 1 (countTrue (score0_vals15 E)) T1 T0
theorem score0_threshold16_0 (E : Nat→Bool) : ((!g632 E)=true) ↔ 1≤countTrue (score0_vals16 E) := by
  have rew : (!g632 E) = ((!g604 E) || ((g381 E) && (g1 E))) := by simp [g1,g632,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold15_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals15 E) := by simp [g1]
  exact threshold_step (g381 E) (!g604 E) (g1 E) 0 (countTrue (score0_vals15 E)) T1 T0
theorem score0_threshold17_1 (E : Nat→Bool) : ((!g664 E)=true) ↔ 2≤countTrue (score0_vals17 E) := by
  have rew : (!g664 E) = ((!g634 E) || ((g382 E) && (!g632 E))) := by simp [g1,g663,g664,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold16_1 E
  have T0 := score0_threshold16_0 E
  exact threshold_step (g382 E) (!g634 E) (!g632 E) 1 (countTrue (score0_vals16 E)) T1 T0
theorem score0_threshold17_0 (E : Nat→Bool) : ((!g662 E)=true) ↔ 1≤countTrue (score0_vals17 E) := by
  have rew : (!g662 E) = ((!g632 E) || ((g382 E) && (g1 E))) := by simp [g1,g662,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold16_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals16 E) := by simp [g1]
  exact threshold_step (g382 E) (!g632 E) (g1 E) 0 (countTrue (score0_vals16 E)) T1 T0
theorem score0_threshold18_1 (E : Nat→Bool) : ((!g696 E)=true) ↔ 2≤countTrue (score0_vals18 E) := by
  have rew : (!g696 E) = ((!g664 E) || ((g383 E) && (!g662 E))) := by simp [g1,g695,g696,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold17_1 E
  have T0 := score0_threshold17_0 E
  exact threshold_step (g383 E) (!g664 E) (!g662 E) 1 (countTrue (score0_vals17 E)) T1 T0
theorem score0_threshold18_0 (E : Nat→Bool) : ((!g694 E)=true) ↔ 1≤countTrue (score0_vals18 E) := by
  have rew : (!g694 E) = ((!g662 E) || ((g383 E) && (g1 E))) := by simp [g1,g694,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold17_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals17 E) := by simp [g1]
  exact threshold_step (g383 E) (!g662 E) (g1 E) 0 (countTrue (score0_vals17 E)) T1 T0
theorem score0_threshold19_1 (E : Nat→Bool) : ((!g730 E)=true) ↔ 2≤countTrue (score0_vals19 E) := by
  have rew : (!g730 E) = ((!g696 E) || ((g384 E) && (!g694 E))) := by simp [g1,g729,g730,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold18_1 E
  have T0 := score0_threshold18_0 E
  exact threshold_step (g384 E) (!g696 E) (!g694 E) 1 (countTrue (score0_vals18 E)) T1 T0
theorem score0_threshold19_0 (E : Nat→Bool) : ((!g728 E)=true) ↔ 1≤countTrue (score0_vals19 E) := by
  have rew : (!g728 E) = ((!g694 E) || ((g384 E) && (g1 E))) := by simp [g1,g728,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold18_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals18 E) := by simp [g1]
  exact threshold_step (g384 E) (!g694 E) (g1 E) 0 (countTrue (score0_vals18 E)) T1 T0
theorem score0_threshold20_1 (E : Nat→Bool) : ((!g766 E)=true) ↔ 2≤countTrue (score0_vals20 E) := by
  have rew : (!g766 E) = ((!g730 E) || ((g385 E) && (!g728 E))) := by simp [g1,g765,g766,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold19_1 E
  have T0 := score0_threshold19_0 E
  exact threshold_step (g385 E) (!g730 E) (!g728 E) 1 (countTrue (score0_vals19 E)) T1 T0
theorem score0_threshold20_0 (E : Nat→Bool) : ((!g764 E)=true) ↔ 1≤countTrue (score0_vals20 E) := by
  have rew : (!g764 E) = ((!g728 E) || ((g385 E) && (g1 E))) := by simp [g1,g764,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold19_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals19 E) := by simp [g1]
  exact threshold_step (g385 E) (!g728 E) (g1 E) 0 (countTrue (score0_vals19 E)) T1 T0
theorem score0_threshold21_1 (E : Nat→Bool) : ((!g804 E)=true) ↔ 2≤countTrue (score0_vals21 E) := by
  have rew : (!g804 E) = ((!g766 E) || ((g386 E) && (!g764 E))) := by simp [g1,g803,g804,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold20_1 E
  have T0 := score0_threshold20_0 E
  exact threshold_step (g386 E) (!g766 E) (!g764 E) 1 (countTrue (score0_vals20 E)) T1 T0
theorem score0_threshold3_2 (E : Nat→Bool) : ((g427 E)=true) ↔ 3≤countTrue (score0_vals3 E) := by
  have rew : (g427 E) = ((!g1 E) || ((g368 E) && (g423 E))) := by simp [g1,g427,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 3≤countTrue (score0_vals2 E) := by
    have hh := count_true_bound (score0_vals2 E)
    change countTrue (score0_vals2 E)≤2 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬3≤countTrue (score0_vals2 E)
    omega
  have T0 := score0_threshold2_1 E
  exact threshold_step (g368 E) (!g1 E) (g423 E) 2 (countTrue (score0_vals2 E)) T1 T0
theorem score0_threshold4_2 (E : Nat→Bool) : ((!g432 E)=true) ↔ 3≤countTrue (score0_vals4 E) := by
  have rew : (!g432 E) = ((g427 E) || ((g369 E) && (!g426 E))) := by simp [g1,g431,g432,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold3_2 E
  have T0 := score0_threshold3_1 E
  exact threshold_step (g369 E) (g427 E) (!g426 E) 2 (countTrue (score0_vals3 E)) T1 T0
theorem score0_threshold5_2 (E : Nat→Bool) : ((!g438 E)=true) ↔ 3≤countTrue (score0_vals5 E) := by
  have rew : (!g438 E) = ((!g432 E) || ((g370 E) && (!g430 E))) := by simp [g1,g437,g438,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold4_2 E
  have T0 := score0_threshold4_1 E
  exact threshold_step (g370 E) (!g432 E) (!g430 E) 2 (countTrue (score0_vals4 E)) T1 T0
theorem score0_threshold6_2 (E : Nat→Bool) : ((!g446 E)=true) ↔ 3≤countTrue (score0_vals6 E) := by
  have rew : (!g446 E) = ((!g438 E) || ((g371 E) && (!g436 E))) := by simp [g1,g445,g446,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold5_2 E
  have T0 := score0_threshold5_1 E
  exact threshold_step (g371 E) (!g438 E) (!g436 E) 2 (countTrue (score0_vals5 E)) T1 T0
theorem score0_threshold7_2 (E : Nat→Bool) : ((!g456 E)=true) ↔ 3≤countTrue (score0_vals7 E) := by
  have rew : (!g456 E) = ((!g446 E) || ((g372 E) && (!g444 E))) := by simp [g1,g455,g456,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold6_2 E
  have T0 := score0_threshold6_1 E
  exact threshold_step (g372 E) (!g446 E) (!g444 E) 2 (countTrue (score0_vals6 E)) T1 T0
theorem score0_threshold8_2 (E : Nat→Bool) : ((!g468 E)=true) ↔ 3≤countTrue (score0_vals8 E) := by
  have rew : (!g468 E) = ((!g456 E) || ((g373 E) && (!g454 E))) := by simp [g1,g467,g468,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold7_2 E
  have T0 := score0_threshold7_1 E
  exact threshold_step (g373 E) (!g456 E) (!g454 E) 2 (countTrue (score0_vals7 E)) T1 T0
theorem score0_threshold9_2 (E : Nat→Bool) : ((!g482 E)=true) ↔ 3≤countTrue (score0_vals9 E) := by
  have rew : (!g482 E) = ((!g468 E) || ((g374 E) && (!g466 E))) := by simp [g1,g481,g482,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold8_2 E
  have T0 := score0_threshold8_1 E
  exact threshold_step (g374 E) (!g468 E) (!g466 E) 2 (countTrue (score0_vals8 E)) T1 T0
theorem score0_threshold10_2 (E : Nat→Bool) : ((!g498 E)=true) ↔ 3≤countTrue (score0_vals10 E) := by
  have rew : (!g498 E) = ((!g482 E) || ((g375 E) && (!g480 E))) := by simp [g1,g497,g498,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold9_2 E
  have T0 := score0_threshold9_1 E
  exact threshold_step (g375 E) (!g482 E) (!g480 E) 2 (countTrue (score0_vals9 E)) T1 T0
theorem score0_threshold11_2 (E : Nat→Bool) : ((!g516 E)=true) ↔ 3≤countTrue (score0_vals11 E) := by
  have rew : (!g516 E) = ((!g498 E) || ((g376 E) && (!g496 E))) := by simp [g1,g515,g516,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold10_2 E
  have T0 := score0_threshold10_1 E
  exact threshold_step (g376 E) (!g498 E) (!g496 E) 2 (countTrue (score0_vals10 E)) T1 T0
theorem score0_threshold12_2 (E : Nat→Bool) : ((!g536 E)=true) ↔ 3≤countTrue (score0_vals12 E) := by
  have rew : (!g536 E) = ((!g516 E) || ((g377 E) && (!g514 E))) := by simp [g1,g535,g536,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold11_2 E
  have T0 := score0_threshold11_1 E
  exact threshold_step (g377 E) (!g516 E) (!g514 E) 2 (countTrue (score0_vals11 E)) T1 T0
theorem score0_threshold13_2 (E : Nat→Bool) : ((!g558 E)=true) ↔ 3≤countTrue (score0_vals13 E) := by
  have rew : (!g558 E) = ((!g536 E) || ((g378 E) && (!g534 E))) := by simp [g1,g557,g558,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold12_2 E
  have T0 := score0_threshold12_1 E
  exact threshold_step (g378 E) (!g536 E) (!g534 E) 2 (countTrue (score0_vals12 E)) T1 T0
theorem score0_threshold14_2 (E : Nat→Bool) : ((!g582 E)=true) ↔ 3≤countTrue (score0_vals14 E) := by
  have rew : (!g582 E) = ((!g558 E) || ((g379 E) && (!g556 E))) := by simp [g1,g581,g582,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold13_2 E
  have T0 := score0_threshold13_1 E
  exact threshold_step (g379 E) (!g558 E) (!g556 E) 2 (countTrue (score0_vals13 E)) T1 T0
theorem score0_threshold15_2 (E : Nat→Bool) : ((!g608 E)=true) ↔ 3≤countTrue (score0_vals15 E) := by
  have rew : (!g608 E) = ((!g582 E) || ((g380 E) && (!g580 E))) := by simp [g1,g607,g608,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold14_2 E
  have T0 := score0_threshold14_1 E
  exact threshold_step (g380 E) (!g582 E) (!g580 E) 2 (countTrue (score0_vals14 E)) T1 T0
theorem score0_threshold16_2 (E : Nat→Bool) : ((!g636 E)=true) ↔ 3≤countTrue (score0_vals16 E) := by
  have rew : (!g636 E) = ((!g608 E) || ((g381 E) && (!g606 E))) := by simp [g1,g635,g636,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold15_2 E
  have T0 := score0_threshold15_1 E
  exact threshold_step (g381 E) (!g608 E) (!g606 E) 2 (countTrue (score0_vals15 E)) T1 T0
theorem score0_threshold17_2 (E : Nat→Bool) : ((!g666 E)=true) ↔ 3≤countTrue (score0_vals17 E) := by
  have rew : (!g666 E) = ((!g636 E) || ((g382 E) && (!g634 E))) := by simp [g1,g665,g666,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold16_2 E
  have T0 := score0_threshold16_1 E
  exact threshold_step (g382 E) (!g636 E) (!g634 E) 2 (countTrue (score0_vals16 E)) T1 T0
theorem score0_threshold18_2 (E : Nat→Bool) : ((!g698 E)=true) ↔ 3≤countTrue (score0_vals18 E) := by
  have rew : (!g698 E) = ((!g666 E) || ((g383 E) && (!g664 E))) := by simp [g1,g697,g698,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold17_2 E
  have T0 := score0_threshold17_1 E
  exact threshold_step (g383 E) (!g666 E) (!g664 E) 2 (countTrue (score0_vals17 E)) T1 T0
theorem score0_threshold19_2 (E : Nat→Bool) : ((!g732 E)=true) ↔ 3≤countTrue (score0_vals19 E) := by
  have rew : (!g732 E) = ((!g698 E) || ((g384 E) && (!g696 E))) := by simp [g1,g731,g732,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold18_2 E
  have T0 := score0_threshold18_1 E
  exact threshold_step (g384 E) (!g698 E) (!g696 E) 2 (countTrue (score0_vals18 E)) T1 T0
theorem score0_threshold20_2 (E : Nat→Bool) : ((!g768 E)=true) ↔ 3≤countTrue (score0_vals20 E) := by
  have rew : (!g768 E) = ((!g732 E) || ((g385 E) && (!g730 E))) := by simp [g1,g767,g768,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold19_2 E
  have T0 := score0_threshold19_1 E
  exact threshold_step (g385 E) (!g732 E) (!g730 E) 2 (countTrue (score0_vals19 E)) T1 T0
theorem score0_threshold21_2 (E : Nat→Bool) : ((!g806 E)=true) ↔ 3≤countTrue (score0_vals21 E) := by
  have rew : (!g806 E) = ((!g768 E) || ((g386 E) && (!g766 E))) := by simp [g1,g805,g806,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold20_2 E
  have T0 := score0_threshold20_1 E
  exact threshold_step (g386 E) (!g768 E) (!g766 E) 2 (countTrue (score0_vals20 E)) T1 T0
theorem score0_threshold4_3 (E : Nat→Bool) : ((g433 E)=true) ↔ 4≤countTrue (score0_vals4 E) := by
  have rew : (g433 E) = ((!g1 E) || ((g369 E) && (g427 E))) := by simp [g1,g433,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 4≤countTrue (score0_vals3 E) := by
    have hh := count_true_bound (score0_vals3 E)
    change countTrue (score0_vals3 E)≤3 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬4≤countTrue (score0_vals3 E)
    omega
  have T0 := score0_threshold3_2 E
  exact threshold_step (g369 E) (!g1 E) (g427 E) 3 (countTrue (score0_vals3 E)) T1 T0
theorem score0_threshold5_3 (E : Nat→Bool) : ((!g440 E)=true) ↔ 4≤countTrue (score0_vals5 E) := by
  have rew : (!g440 E) = ((g433 E) || ((g370 E) && (!g432 E))) := by simp [g1,g439,g440,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold4_3 E
  have T0 := score0_threshold4_2 E
  exact threshold_step (g370 E) (g433 E) (!g432 E) 3 (countTrue (score0_vals4 E)) T1 T0
theorem score0_threshold6_3 (E : Nat→Bool) : ((!g448 E)=true) ↔ 4≤countTrue (score0_vals6 E) := by
  have rew : (!g448 E) = ((!g440 E) || ((g371 E) && (!g438 E))) := by simp [g1,g447,g448,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold5_3 E
  have T0 := score0_threshold5_2 E
  exact threshold_step (g371 E) (!g440 E) (!g438 E) 3 (countTrue (score0_vals5 E)) T1 T0
theorem score0_threshold7_3 (E : Nat→Bool) : ((!g458 E)=true) ↔ 4≤countTrue (score0_vals7 E) := by
  have rew : (!g458 E) = ((!g448 E) || ((g372 E) && (!g446 E))) := by simp [g1,g457,g458,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold6_3 E
  have T0 := score0_threshold6_2 E
  exact threshold_step (g372 E) (!g448 E) (!g446 E) 3 (countTrue (score0_vals6 E)) T1 T0
theorem score0_threshold8_3 (E : Nat→Bool) : ((!g470 E)=true) ↔ 4≤countTrue (score0_vals8 E) := by
  have rew : (!g470 E) = ((!g458 E) || ((g373 E) && (!g456 E))) := by simp [g1,g469,g470,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold7_3 E
  have T0 := score0_threshold7_2 E
  exact threshold_step (g373 E) (!g458 E) (!g456 E) 3 (countTrue (score0_vals7 E)) T1 T0
theorem score0_threshold9_3 (E : Nat→Bool) : ((!g484 E)=true) ↔ 4≤countTrue (score0_vals9 E) := by
  have rew : (!g484 E) = ((!g470 E) || ((g374 E) && (!g468 E))) := by simp [g1,g483,g484,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold8_3 E
  have T0 := score0_threshold8_2 E
  exact threshold_step (g374 E) (!g470 E) (!g468 E) 3 (countTrue (score0_vals8 E)) T1 T0
theorem score0_threshold10_3 (E : Nat→Bool) : ((!g500 E)=true) ↔ 4≤countTrue (score0_vals10 E) := by
  have rew : (!g500 E) = ((!g484 E) || ((g375 E) && (!g482 E))) := by simp [g1,g499,g500,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold9_3 E
  have T0 := score0_threshold9_2 E
  exact threshold_step (g375 E) (!g484 E) (!g482 E) 3 (countTrue (score0_vals9 E)) T1 T0
theorem score0_threshold11_3 (E : Nat→Bool) : ((!g518 E)=true) ↔ 4≤countTrue (score0_vals11 E) := by
  have rew : (!g518 E) = ((!g500 E) || ((g376 E) && (!g498 E))) := by simp [g1,g517,g518,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold10_3 E
  have T0 := score0_threshold10_2 E
  exact threshold_step (g376 E) (!g500 E) (!g498 E) 3 (countTrue (score0_vals10 E)) T1 T0
theorem score0_threshold12_3 (E : Nat→Bool) : ((!g538 E)=true) ↔ 4≤countTrue (score0_vals12 E) := by
  have rew : (!g538 E) = ((!g518 E) || ((g377 E) && (!g516 E))) := by simp [g1,g537,g538,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold11_3 E
  have T0 := score0_threshold11_2 E
  exact threshold_step (g377 E) (!g518 E) (!g516 E) 3 (countTrue (score0_vals11 E)) T1 T0
theorem score0_threshold13_3 (E : Nat→Bool) : ((!g560 E)=true) ↔ 4≤countTrue (score0_vals13 E) := by
  have rew : (!g560 E) = ((!g538 E) || ((g378 E) && (!g536 E))) := by simp [g1,g559,g560,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold12_3 E
  have T0 := score0_threshold12_2 E
  exact threshold_step (g378 E) (!g538 E) (!g536 E) 3 (countTrue (score0_vals12 E)) T1 T0
theorem score0_threshold14_3 (E : Nat→Bool) : ((!g584 E)=true) ↔ 4≤countTrue (score0_vals14 E) := by
  have rew : (!g584 E) = ((!g560 E) || ((g379 E) && (!g558 E))) := by simp [g1,g583,g584,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold13_3 E
  have T0 := score0_threshold13_2 E
  exact threshold_step (g379 E) (!g560 E) (!g558 E) 3 (countTrue (score0_vals13 E)) T1 T0
theorem score0_threshold15_3 (E : Nat→Bool) : ((!g610 E)=true) ↔ 4≤countTrue (score0_vals15 E) := by
  have rew : (!g610 E) = ((!g584 E) || ((g380 E) && (!g582 E))) := by simp [g1,g609,g610,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold14_3 E
  have T0 := score0_threshold14_2 E
  exact threshold_step (g380 E) (!g584 E) (!g582 E) 3 (countTrue (score0_vals14 E)) T1 T0
theorem score0_threshold16_3 (E : Nat→Bool) : ((!g638 E)=true) ↔ 4≤countTrue (score0_vals16 E) := by
  have rew : (!g638 E) = ((!g610 E) || ((g381 E) && (!g608 E))) := by simp [g1,g637,g638,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold15_3 E
  have T0 := score0_threshold15_2 E
  exact threshold_step (g381 E) (!g610 E) (!g608 E) 3 (countTrue (score0_vals15 E)) T1 T0
theorem score0_threshold17_3 (E : Nat→Bool) : ((!g668 E)=true) ↔ 4≤countTrue (score0_vals17 E) := by
  have rew : (!g668 E) = ((!g638 E) || ((g382 E) && (!g636 E))) := by simp [g1,g667,g668,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold16_3 E
  have T0 := score0_threshold16_2 E
  exact threshold_step (g382 E) (!g638 E) (!g636 E) 3 (countTrue (score0_vals16 E)) T1 T0
theorem score0_threshold18_3 (E : Nat→Bool) : ((!g700 E)=true) ↔ 4≤countTrue (score0_vals18 E) := by
  have rew : (!g700 E) = ((!g668 E) || ((g383 E) && (!g666 E))) := by simp [g1,g699,g700,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold17_3 E
  have T0 := score0_threshold17_2 E
  exact threshold_step (g383 E) (!g668 E) (!g666 E) 3 (countTrue (score0_vals17 E)) T1 T0
theorem score0_threshold19_3 (E : Nat→Bool) : ((!g734 E)=true) ↔ 4≤countTrue (score0_vals19 E) := by
  have rew : (!g734 E) = ((!g700 E) || ((g384 E) && (!g698 E))) := by simp [g1,g733,g734,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold18_3 E
  have T0 := score0_threshold18_2 E
  exact threshold_step (g384 E) (!g700 E) (!g698 E) 3 (countTrue (score0_vals18 E)) T1 T0
theorem score0_threshold20_3 (E : Nat→Bool) : ((!g770 E)=true) ↔ 4≤countTrue (score0_vals20 E) := by
  have rew : (!g770 E) = ((!g734 E) || ((g385 E) && (!g732 E))) := by simp [g1,g769,g770,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold19_3 E
  have T0 := score0_threshold19_2 E
  exact threshold_step (g385 E) (!g734 E) (!g732 E) 3 (countTrue (score0_vals19 E)) T1 T0
theorem score0_threshold21_3 (E : Nat→Bool) : ((!g808 E)=true) ↔ 4≤countTrue (score0_vals21 E) := by
  have rew : (!g808 E) = ((!g770 E) || ((g386 E) && (!g768 E))) := by simp [g1,g807,g808,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold20_3 E
  have T0 := score0_threshold20_2 E
  exact threshold_step (g386 E) (!g770 E) (!g768 E) 3 (countTrue (score0_vals20 E)) T1 T0
theorem score0_threshold5_4 (E : Nat→Bool) : ((g441 E)=true) ↔ 5≤countTrue (score0_vals5 E) := by
  have rew : (g441 E) = ((!g1 E) || ((g370 E) && (g433 E))) := by simp [g1,g441,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 5≤countTrue (score0_vals4 E) := by
    have hh := count_true_bound (score0_vals4 E)
    change countTrue (score0_vals4 E)≤4 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬5≤countTrue (score0_vals4 E)
    omega
  have T0 := score0_threshold4_3 E
  exact threshold_step (g370 E) (!g1 E) (g433 E) 4 (countTrue (score0_vals4 E)) T1 T0
theorem score0_threshold6_4 (E : Nat→Bool) : ((!g450 E)=true) ↔ 5≤countTrue (score0_vals6 E) := by
  have rew : (!g450 E) = ((g441 E) || ((g371 E) && (!g440 E))) := by simp [g1,g449,g450,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold5_4 E
  have T0 := score0_threshold5_3 E
  exact threshold_step (g371 E) (g441 E) (!g440 E) 4 (countTrue (score0_vals5 E)) T1 T0
theorem score0_threshold7_4 (E : Nat→Bool) : ((!g460 E)=true) ↔ 5≤countTrue (score0_vals7 E) := by
  have rew : (!g460 E) = ((!g450 E) || ((g372 E) && (!g448 E))) := by simp [g1,g459,g460,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold6_4 E
  have T0 := score0_threshold6_3 E
  exact threshold_step (g372 E) (!g450 E) (!g448 E) 4 (countTrue (score0_vals6 E)) T1 T0
theorem score0_threshold8_4 (E : Nat→Bool) : ((!g472 E)=true) ↔ 5≤countTrue (score0_vals8 E) := by
  have rew : (!g472 E) = ((!g460 E) || ((g373 E) && (!g458 E))) := by simp [g1,g471,g472,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold7_4 E
  have T0 := score0_threshold7_3 E
  exact threshold_step (g373 E) (!g460 E) (!g458 E) 4 (countTrue (score0_vals7 E)) T1 T0
theorem score0_threshold9_4 (E : Nat→Bool) : ((!g486 E)=true) ↔ 5≤countTrue (score0_vals9 E) := by
  have rew : (!g486 E) = ((!g472 E) || ((g374 E) && (!g470 E))) := by simp [g1,g485,g486,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold8_4 E
  have T0 := score0_threshold8_3 E
  exact threshold_step (g374 E) (!g472 E) (!g470 E) 4 (countTrue (score0_vals8 E)) T1 T0
theorem score0_threshold10_4 (E : Nat→Bool) : ((!g502 E)=true) ↔ 5≤countTrue (score0_vals10 E) := by
  have rew : (!g502 E) = ((!g486 E) || ((g375 E) && (!g484 E))) := by simp [g1,g501,g502,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold9_4 E
  have T0 := score0_threshold9_3 E
  exact threshold_step (g375 E) (!g486 E) (!g484 E) 4 (countTrue (score0_vals9 E)) T1 T0
theorem score0_threshold11_4 (E : Nat→Bool) : ((!g520 E)=true) ↔ 5≤countTrue (score0_vals11 E) := by
  have rew : (!g520 E) = ((!g502 E) || ((g376 E) && (!g500 E))) := by simp [g1,g519,g520,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold10_4 E
  have T0 := score0_threshold10_3 E
  exact threshold_step (g376 E) (!g502 E) (!g500 E) 4 (countTrue (score0_vals10 E)) T1 T0
theorem score0_threshold12_4 (E : Nat→Bool) : ((!g540 E)=true) ↔ 5≤countTrue (score0_vals12 E) := by
  have rew : (!g540 E) = ((!g520 E) || ((g377 E) && (!g518 E))) := by simp [g1,g539,g540,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold11_4 E
  have T0 := score0_threshold11_3 E
  exact threshold_step (g377 E) (!g520 E) (!g518 E) 4 (countTrue (score0_vals11 E)) T1 T0
theorem score0_threshold13_4 (E : Nat→Bool) : ((!g562 E)=true) ↔ 5≤countTrue (score0_vals13 E) := by
  have rew : (!g562 E) = ((!g540 E) || ((g378 E) && (!g538 E))) := by simp [g1,g561,g562,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold12_4 E
  have T0 := score0_threshold12_3 E
  exact threshold_step (g378 E) (!g540 E) (!g538 E) 4 (countTrue (score0_vals12 E)) T1 T0
theorem score0_threshold14_4 (E : Nat→Bool) : ((!g586 E)=true) ↔ 5≤countTrue (score0_vals14 E) := by
  have rew : (!g586 E) = ((!g562 E) || ((g379 E) && (!g560 E))) := by simp [g1,g585,g586,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold13_4 E
  have T0 := score0_threshold13_3 E
  exact threshold_step (g379 E) (!g562 E) (!g560 E) 4 (countTrue (score0_vals13 E)) T1 T0
theorem score0_threshold15_4 (E : Nat→Bool) : ((!g612 E)=true) ↔ 5≤countTrue (score0_vals15 E) := by
  have rew : (!g612 E) = ((!g586 E) || ((g380 E) && (!g584 E))) := by simp [g1,g611,g612,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold14_4 E
  have T0 := score0_threshold14_3 E
  exact threshold_step (g380 E) (!g586 E) (!g584 E) 4 (countTrue (score0_vals14 E)) T1 T0
theorem score0_threshold16_4 (E : Nat→Bool) : ((!g640 E)=true) ↔ 5≤countTrue (score0_vals16 E) := by
  have rew : (!g640 E) = ((!g612 E) || ((g381 E) && (!g610 E))) := by simp [g1,g639,g640,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold15_4 E
  have T0 := score0_threshold15_3 E
  exact threshold_step (g381 E) (!g612 E) (!g610 E) 4 (countTrue (score0_vals15 E)) T1 T0
theorem score0_threshold17_4 (E : Nat→Bool) : ((!g670 E)=true) ↔ 5≤countTrue (score0_vals17 E) := by
  have rew : (!g670 E) = ((!g640 E) || ((g382 E) && (!g638 E))) := by simp [g1,g669,g670,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold16_4 E
  have T0 := score0_threshold16_3 E
  exact threshold_step (g382 E) (!g640 E) (!g638 E) 4 (countTrue (score0_vals16 E)) T1 T0
theorem score0_threshold18_4 (E : Nat→Bool) : ((!g702 E)=true) ↔ 5≤countTrue (score0_vals18 E) := by
  have rew : (!g702 E) = ((!g670 E) || ((g383 E) && (!g668 E))) := by simp [g1,g701,g702,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold17_4 E
  have T0 := score0_threshold17_3 E
  exact threshold_step (g383 E) (!g670 E) (!g668 E) 4 (countTrue (score0_vals17 E)) T1 T0
theorem score0_threshold19_4 (E : Nat→Bool) : ((!g736 E)=true) ↔ 5≤countTrue (score0_vals19 E) := by
  have rew : (!g736 E) = ((!g702 E) || ((g384 E) && (!g700 E))) := by simp [g1,g735,g736,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold18_4 E
  have T0 := score0_threshold18_3 E
  exact threshold_step (g384 E) (!g702 E) (!g700 E) 4 (countTrue (score0_vals18 E)) T1 T0
theorem score0_threshold20_4 (E : Nat→Bool) : ((!g772 E)=true) ↔ 5≤countTrue (score0_vals20 E) := by
  have rew : (!g772 E) = ((!g736 E) || ((g385 E) && (!g734 E))) := by simp [g1,g771,g772,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold19_4 E
  have T0 := score0_threshold19_3 E
  exact threshold_step (g385 E) (!g736 E) (!g734 E) 4 (countTrue (score0_vals19 E)) T1 T0
theorem score0_threshold21_4 (E : Nat→Bool) : ((!g810 E)=true) ↔ 5≤countTrue (score0_vals21 E) := by
  have rew : (!g810 E) = ((!g772 E) || ((g386 E) && (!g770 E))) := by simp [g1,g809,g810,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold20_4 E
  have T0 := score0_threshold20_3 E
  exact threshold_step (g386 E) (!g772 E) (!g770 E) 4 (countTrue (score0_vals20 E)) T1 T0
def score0_count (E : Nat→Bool) : Nat := countTrue (score0_vals21 E)
def score1_vals1 (E : Nat→Bool) : List Bool := (g366 E) :: ([])
def score1_vals2 (E : Nat→Bool) : List Bool := (g367 E) :: (score1_vals1 E)
def score1_vals3 (E : Nat→Bool) : List Bool := (g368 E) :: (score1_vals2 E)
def score1_vals4 (E : Nat→Bool) : List Bool := (g369 E) :: (score1_vals3 E)
def score1_vals5 (E : Nat→Bool) : List Bool := (g370 E) :: (score1_vals4 E)
def score1_vals6 (E : Nat→Bool) : List Bool := (g371 E) :: (score1_vals5 E)
def score1_vals7 (E : Nat→Bool) : List Bool := (g387 E) :: (score1_vals6 E)
def score1_vals8 (E : Nat→Bool) : List Bool := (g388 E) :: (score1_vals7 E)
def score1_vals9 (E : Nat→Bool) : List Bool := (g389 E) :: (score1_vals8 E)
def score1_vals10 (E : Nat→Bool) : List Bool := (g390 E) :: (score1_vals9 E)
def score1_vals11 (E : Nat→Bool) : List Bool := (g391 E) :: (score1_vals10 E)
def score1_vals12 (E : Nat→Bool) : List Bool := (g392 E) :: (score1_vals11 E)
def score1_vals13 (E : Nat→Bool) : List Bool := (g393 E) :: (score1_vals12 E)
def score1_vals14 (E : Nat→Bool) : List Bool := (g394 E) :: (score1_vals13 E)
def score1_vals15 (E : Nat→Bool) : List Bool := (g395 E) :: (score1_vals14 E)
def score1_vals16 (E : Nat→Bool) : List Bool := (g396 E) :: (score1_vals15 E)
def score1_vals17 (E : Nat→Bool) : List Bool := (g397 E) :: (score1_vals16 E)
def score1_vals18 (E : Nat→Bool) : List Bool := (g398 E) :: (score1_vals17 E)
def score1_vals19 (E : Nat→Bool) : List Bool := (g399 E) :: (score1_vals18 E)
def score1_vals20 (E : Nat→Bool) : List Bool := (g400 E) :: (score1_vals19 E)
def score1_vals21 (E : Nat→Bool) : List Bool := (g401 E) :: (score1_vals20 E)
theorem score1_threshold1_0 (E : Nat→Bool) : ((g366 E)=true) ↔ 1≤countTrue (score1_vals1 E) := by
  have rew : (g366 E) = ((!g1 E) || ((g366 E) && (g1 E))) := by simp [g1,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 1≤countTrue ([] : List Bool) := by
    have hh := count_true_bound ([] : List Bool)
    change countTrue ([] : List Bool)≤0 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬1≤countTrue ([] : List Bool)
    omega
  have T0 : (g1 E)=true ↔ 0≤countTrue ([] : List Bool) := by simp [g1]
  exact threshold_step (g366 E) (!g1 E) (g1 E) 0 (countTrue ([] : List Bool)) T1 T0
theorem score1_threshold2_1 (E : Nat→Bool) : ((g843 E)=true) ↔ 2≤countTrue (score1_vals2 E) := by
  have rew : (g843 E) = ((!g1 E) || ((g367 E) && (g366 E))) := by simp [g1,g843,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 2≤countTrue (score1_vals1 E) := by
    have hh := count_true_bound (score1_vals1 E)
    change countTrue (score1_vals1 E)≤1 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬2≤countTrue (score1_vals1 E)
    omega
  have T0 := score1_threshold1_0 E
  exact threshold_step (g367 E) (!g1 E) (g366 E) 1 (countTrue (score1_vals1 E)) T1 T0
theorem score1_threshold2_0 (E : Nat→Bool) : ((!g842 E)=true) ↔ 1≤countTrue (score1_vals2 E) := by
  have rew : (!g842 E) = ((g366 E) || ((g367 E) && (g1 E))) := by simp [g1,g842,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold1_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals1 E) := by simp [g1]
  exact threshold_step (g367 E) (g366 E) (g1 E) 0 (countTrue (score1_vals1 E)) T1 T0
theorem score1_threshold3_1 (E : Nat→Bool) : ((!g846 E)=true) ↔ 2≤countTrue (score1_vals3 E) := by
  have rew : (!g846 E) = ((g843 E) || ((g368 E) && (!g842 E))) := by simp [g1,g845,g846,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold2_1 E
  have T0 := score1_threshold2_0 E
  exact threshold_step (g368 E) (g843 E) (!g842 E) 1 (countTrue (score1_vals2 E)) T1 T0
theorem score1_threshold3_0 (E : Nat→Bool) : ((!g844 E)=true) ↔ 1≤countTrue (score1_vals3 E) := by
  have rew : (!g844 E) = ((!g842 E) || ((g368 E) && (g1 E))) := by simp [g1,g844,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold2_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals2 E) := by simp [g1]
  exact threshold_step (g368 E) (!g842 E) (g1 E) 0 (countTrue (score1_vals2 E)) T1 T0
theorem score1_threshold4_1 (E : Nat→Bool) : ((!g850 E)=true) ↔ 2≤countTrue (score1_vals4 E) := by
  have rew : (!g850 E) = ((!g846 E) || ((g369 E) && (!g844 E))) := by simp [g1,g849,g850,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold3_1 E
  have T0 := score1_threshold3_0 E
  exact threshold_step (g369 E) (!g846 E) (!g844 E) 1 (countTrue (score1_vals3 E)) T1 T0
theorem score1_threshold4_0 (E : Nat→Bool) : ((!g848 E)=true) ↔ 1≤countTrue (score1_vals4 E) := by
  have rew : (!g848 E) = ((!g844 E) || ((g369 E) && (g1 E))) := by simp [g1,g848,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold3_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals3 E) := by simp [g1]
  exact threshold_step (g369 E) (!g844 E) (g1 E) 0 (countTrue (score1_vals3 E)) T1 T0
theorem score1_threshold5_1 (E : Nat→Bool) : ((!g856 E)=true) ↔ 2≤countTrue (score1_vals5 E) := by
  have rew : (!g856 E) = ((!g850 E) || ((g370 E) && (!g848 E))) := by simp [g1,g855,g856,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold4_1 E
  have T0 := score1_threshold4_0 E
  exact threshold_step (g370 E) (!g850 E) (!g848 E) 1 (countTrue (score1_vals4 E)) T1 T0
theorem score1_threshold5_0 (E : Nat→Bool) : ((!g854 E)=true) ↔ 1≤countTrue (score1_vals5 E) := by
  have rew : (!g854 E) = ((!g848 E) || ((g370 E) && (g1 E))) := by simp [g1,g854,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold4_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals4 E) := by simp [g1]
  exact threshold_step (g370 E) (!g848 E) (g1 E) 0 (countTrue (score1_vals4 E)) T1 T0
theorem score1_threshold6_1 (E : Nat→Bool) : ((!g864 E)=true) ↔ 2≤countTrue (score1_vals6 E) := by
  have rew : (!g864 E) = ((!g856 E) || ((g371 E) && (!g854 E))) := by simp [g1,g863,g864,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold5_1 E
  have T0 := score1_threshold5_0 E
  exact threshold_step (g371 E) (!g856 E) (!g854 E) 1 (countTrue (score1_vals5 E)) T1 T0
theorem score1_threshold6_0 (E : Nat→Bool) : ((!g862 E)=true) ↔ 1≤countTrue (score1_vals6 E) := by
  have rew : (!g862 E) = ((!g854 E) || ((g371 E) && (g1 E))) := by simp [g1,g862,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold5_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals5 E) := by simp [g1]
  exact threshold_step (g371 E) (!g854 E) (g1 E) 0 (countTrue (score1_vals5 E)) T1 T0
theorem score1_threshold7_1 (E : Nat→Bool) : ((!g874 E)=true) ↔ 2≤countTrue (score1_vals7 E) := by
  have rew : (!g874 E) = ((!g864 E) || ((g387 E) && (!g862 E))) := by simp [g1,g873,g874,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold6_1 E
  have T0 := score1_threshold6_0 E
  exact threshold_step (g387 E) (!g864 E) (!g862 E) 1 (countTrue (score1_vals6 E)) T1 T0
theorem score1_threshold7_0 (E : Nat→Bool) : ((!g872 E)=true) ↔ 1≤countTrue (score1_vals7 E) := by
  have rew : (!g872 E) = ((!g862 E) || ((g387 E) && (g1 E))) := by simp [g1,g872,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold6_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals6 E) := by simp [g1]
  exact threshold_step (g387 E) (!g862 E) (g1 E) 0 (countTrue (score1_vals6 E)) T1 T0
theorem score1_threshold8_1 (E : Nat→Bool) : ((!g886 E)=true) ↔ 2≤countTrue (score1_vals8 E) := by
  have rew : (!g886 E) = ((!g874 E) || ((g388 E) && (!g872 E))) := by simp [g1,g885,g886,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold7_1 E
  have T0 := score1_threshold7_0 E
  exact threshold_step (g388 E) (!g874 E) (!g872 E) 1 (countTrue (score1_vals7 E)) T1 T0
theorem score1_threshold8_0 (E : Nat→Bool) : ((!g884 E)=true) ↔ 1≤countTrue (score1_vals8 E) := by
  have rew : (!g884 E) = ((!g872 E) || ((g388 E) && (g1 E))) := by simp [g1,g884,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold7_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals7 E) := by simp [g1]
  exact threshold_step (g388 E) (!g872 E) (g1 E) 0 (countTrue (score1_vals7 E)) T1 T0
theorem score1_threshold9_1 (E : Nat→Bool) : ((!g900 E)=true) ↔ 2≤countTrue (score1_vals9 E) := by
  have rew : (!g900 E) = ((!g886 E) || ((g389 E) && (!g884 E))) := by simp [g1,g899,g900,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold8_1 E
  have T0 := score1_threshold8_0 E
  exact threshold_step (g389 E) (!g886 E) (!g884 E) 1 (countTrue (score1_vals8 E)) T1 T0
theorem score1_threshold9_0 (E : Nat→Bool) : ((!g898 E)=true) ↔ 1≤countTrue (score1_vals9 E) := by
  have rew : (!g898 E) = ((!g884 E) || ((g389 E) && (g1 E))) := by simp [g1,g898,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold8_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals8 E) := by simp [g1]
  exact threshold_step (g389 E) (!g884 E) (g1 E) 0 (countTrue (score1_vals8 E)) T1 T0
theorem score1_threshold10_1 (E : Nat→Bool) : ((!g916 E)=true) ↔ 2≤countTrue (score1_vals10 E) := by
  have rew : (!g916 E) = ((!g900 E) || ((g390 E) && (!g898 E))) := by simp [g1,g915,g916,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold9_1 E
  have T0 := score1_threshold9_0 E
  exact threshold_step (g390 E) (!g900 E) (!g898 E) 1 (countTrue (score1_vals9 E)) T1 T0
theorem score1_threshold10_0 (E : Nat→Bool) : ((!g914 E)=true) ↔ 1≤countTrue (score1_vals10 E) := by
  have rew : (!g914 E) = ((!g898 E) || ((g390 E) && (g1 E))) := by simp [g1,g914,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold9_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals9 E) := by simp [g1]
  exact threshold_step (g390 E) (!g898 E) (g1 E) 0 (countTrue (score1_vals9 E)) T1 T0
theorem score1_threshold11_1 (E : Nat→Bool) : ((!g934 E)=true) ↔ 2≤countTrue (score1_vals11 E) := by
  have rew : (!g934 E) = ((!g916 E) || ((g391 E) && (!g914 E))) := by simp [g1,g933,g934,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold10_1 E
  have T0 := score1_threshold10_0 E
  exact threshold_step (g391 E) (!g916 E) (!g914 E) 1 (countTrue (score1_vals10 E)) T1 T0
theorem score1_threshold11_0 (E : Nat→Bool) : ((!g932 E)=true) ↔ 1≤countTrue (score1_vals11 E) := by
  have rew : (!g932 E) = ((!g914 E) || ((g391 E) && (g1 E))) := by simp [g1,g932,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold10_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals10 E) := by simp [g1]
  exact threshold_step (g391 E) (!g914 E) (g1 E) 0 (countTrue (score1_vals10 E)) T1 T0
theorem score1_threshold12_1 (E : Nat→Bool) : ((!g954 E)=true) ↔ 2≤countTrue (score1_vals12 E) := by
  have rew : (!g954 E) = ((!g934 E) || ((g392 E) && (!g932 E))) := by simp [g1,g953,g954,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold11_1 E
  have T0 := score1_threshold11_0 E
  exact threshold_step (g392 E) (!g934 E) (!g932 E) 1 (countTrue (score1_vals11 E)) T1 T0
theorem score1_threshold12_0 (E : Nat→Bool) : ((!g952 E)=true) ↔ 1≤countTrue (score1_vals12 E) := by
  have rew : (!g952 E) = ((!g932 E) || ((g392 E) && (g1 E))) := by simp [g1,g952,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold11_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals11 E) := by simp [g1]
  exact threshold_step (g392 E) (!g932 E) (g1 E) 0 (countTrue (score1_vals11 E)) T1 T0
theorem score1_threshold13_1 (E : Nat→Bool) : ((!g976 E)=true) ↔ 2≤countTrue (score1_vals13 E) := by
  have rew : (!g976 E) = ((!g954 E) || ((g393 E) && (!g952 E))) := by simp [g1,g975,g976,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold12_1 E
  have T0 := score1_threshold12_0 E
  exact threshold_step (g393 E) (!g954 E) (!g952 E) 1 (countTrue (score1_vals12 E)) T1 T0
theorem score1_threshold13_0 (E : Nat→Bool) : ((!g974 E)=true) ↔ 1≤countTrue (score1_vals13 E) := by
  have rew : (!g974 E) = ((!g952 E) || ((g393 E) && (g1 E))) := by simp [g1,g974,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold12_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals12 E) := by simp [g1]
  exact threshold_step (g393 E) (!g952 E) (g1 E) 0 (countTrue (score1_vals12 E)) T1 T0
theorem score1_threshold14_1 (E : Nat→Bool) : ((!g1000 E)=true) ↔ 2≤countTrue (score1_vals14 E) := by
  have rew : (!g1000 E) = ((!g976 E) || ((g394 E) && (!g974 E))) := by simp [g1,g999,g1000,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold13_1 E
  have T0 := score1_threshold13_0 E
  exact threshold_step (g394 E) (!g976 E) (!g974 E) 1 (countTrue (score1_vals13 E)) T1 T0
theorem score1_threshold14_0 (E : Nat→Bool) : ((!g998 E)=true) ↔ 1≤countTrue (score1_vals14 E) := by
  have rew : (!g998 E) = ((!g974 E) || ((g394 E) && (g1 E))) := by simp [g1,g998,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold13_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals13 E) := by simp [g1]
  exact threshold_step (g394 E) (!g974 E) (g1 E) 0 (countTrue (score1_vals13 E)) T1 T0
theorem score1_threshold15_1 (E : Nat→Bool) : ((!g1026 E)=true) ↔ 2≤countTrue (score1_vals15 E) := by
  have rew : (!g1026 E) = ((!g1000 E) || ((g395 E) && (!g998 E))) := by simp [g1,g1025,g1026,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold14_1 E
  have T0 := score1_threshold14_0 E
  exact threshold_step (g395 E) (!g1000 E) (!g998 E) 1 (countTrue (score1_vals14 E)) T1 T0
theorem score1_threshold15_0 (E : Nat→Bool) : ((!g1024 E)=true) ↔ 1≤countTrue (score1_vals15 E) := by
  have rew : (!g1024 E) = ((!g998 E) || ((g395 E) && (g1 E))) := by simp [g1,g1024,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold14_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals14 E) := by simp [g1]
  exact threshold_step (g395 E) (!g998 E) (g1 E) 0 (countTrue (score1_vals14 E)) T1 T0
theorem score1_threshold16_1 (E : Nat→Bool) : ((!g1054 E)=true) ↔ 2≤countTrue (score1_vals16 E) := by
  have rew : (!g1054 E) = ((!g1026 E) || ((g396 E) && (!g1024 E))) := by simp [g1,g1053,g1054,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold15_1 E
  have T0 := score1_threshold15_0 E
  exact threshold_step (g396 E) (!g1026 E) (!g1024 E) 1 (countTrue (score1_vals15 E)) T1 T0
theorem score1_threshold16_0 (E : Nat→Bool) : ((!g1052 E)=true) ↔ 1≤countTrue (score1_vals16 E) := by
  have rew : (!g1052 E) = ((!g1024 E) || ((g396 E) && (g1 E))) := by simp [g1,g1052,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold15_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals15 E) := by simp [g1]
  exact threshold_step (g396 E) (!g1024 E) (g1 E) 0 (countTrue (score1_vals15 E)) T1 T0
theorem score1_threshold17_1 (E : Nat→Bool) : ((!g1084 E)=true) ↔ 2≤countTrue (score1_vals17 E) := by
  have rew : (!g1084 E) = ((!g1054 E) || ((g397 E) && (!g1052 E))) := by simp [g1,g1083,g1084,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold16_1 E
  have T0 := score1_threshold16_0 E
  exact threshold_step (g397 E) (!g1054 E) (!g1052 E) 1 (countTrue (score1_vals16 E)) T1 T0
theorem score1_threshold17_0 (E : Nat→Bool) : ((!g1082 E)=true) ↔ 1≤countTrue (score1_vals17 E) := by
  have rew : (!g1082 E) = ((!g1052 E) || ((g397 E) && (g1 E))) := by simp [g1,g1082,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold16_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals16 E) := by simp [g1]
  exact threshold_step (g397 E) (!g1052 E) (g1 E) 0 (countTrue (score1_vals16 E)) T1 T0
theorem score1_threshold18_1 (E : Nat→Bool) : ((!g1116 E)=true) ↔ 2≤countTrue (score1_vals18 E) := by
  have rew : (!g1116 E) = ((!g1084 E) || ((g398 E) && (!g1082 E))) := by simp [g1,g1115,g1116,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold17_1 E
  have T0 := score1_threshold17_0 E
  exact threshold_step (g398 E) (!g1084 E) (!g1082 E) 1 (countTrue (score1_vals17 E)) T1 T0
theorem score1_threshold18_0 (E : Nat→Bool) : ((!g1114 E)=true) ↔ 1≤countTrue (score1_vals18 E) := by
  have rew : (!g1114 E) = ((!g1082 E) || ((g398 E) && (g1 E))) := by simp [g1,g1114,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold17_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals17 E) := by simp [g1]
  exact threshold_step (g398 E) (!g1082 E) (g1 E) 0 (countTrue (score1_vals17 E)) T1 T0
theorem score1_threshold19_1 (E : Nat→Bool) : ((!g1150 E)=true) ↔ 2≤countTrue (score1_vals19 E) := by
  have rew : (!g1150 E) = ((!g1116 E) || ((g399 E) && (!g1114 E))) := by simp [g1,g1149,g1150,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold18_1 E
  have T0 := score1_threshold18_0 E
  exact threshold_step (g399 E) (!g1116 E) (!g1114 E) 1 (countTrue (score1_vals18 E)) T1 T0
theorem score1_threshold19_0 (E : Nat→Bool) : ((!g1148 E)=true) ↔ 1≤countTrue (score1_vals19 E) := by
  have rew : (!g1148 E) = ((!g1114 E) || ((g399 E) && (g1 E))) := by simp [g1,g1148,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold18_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals18 E) := by simp [g1]
  exact threshold_step (g399 E) (!g1114 E) (g1 E) 0 (countTrue (score1_vals18 E)) T1 T0
theorem score1_threshold20_1 (E : Nat→Bool) : ((!g1186 E)=true) ↔ 2≤countTrue (score1_vals20 E) := by
  have rew : (!g1186 E) = ((!g1150 E) || ((g400 E) && (!g1148 E))) := by simp [g1,g1185,g1186,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold19_1 E
  have T0 := score1_threshold19_0 E
  exact threshold_step (g400 E) (!g1150 E) (!g1148 E) 1 (countTrue (score1_vals19 E)) T1 T0
theorem score1_threshold20_0 (E : Nat→Bool) : ((!g1184 E)=true) ↔ 1≤countTrue (score1_vals20 E) := by
  have rew : (!g1184 E) = ((!g1148 E) || ((g400 E) && (g1 E))) := by simp [g1,g1184,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold19_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals19 E) := by simp [g1]
  exact threshold_step (g400 E) (!g1148 E) (g1 E) 0 (countTrue (score1_vals19 E)) T1 T0
theorem score1_threshold21_1 (E : Nat→Bool) : ((!g1224 E)=true) ↔ 2≤countTrue (score1_vals21 E) := by
  have rew : (!g1224 E) = ((!g1186 E) || ((g401 E) && (!g1184 E))) := by simp [g1,g1223,g1224,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold20_1 E
  have T0 := score1_threshold20_0 E
  exact threshold_step (g401 E) (!g1186 E) (!g1184 E) 1 (countTrue (score1_vals20 E)) T1 T0
theorem score1_threshold3_2 (E : Nat→Bool) : ((g847 E)=true) ↔ 3≤countTrue (score1_vals3 E) := by
  have rew : (g847 E) = ((!g1 E) || ((g368 E) && (g843 E))) := by simp [g1,g847,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 3≤countTrue (score1_vals2 E) := by
    have hh := count_true_bound (score1_vals2 E)
    change countTrue (score1_vals2 E)≤2 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬3≤countTrue (score1_vals2 E)
    omega
  have T0 := score1_threshold2_1 E
  exact threshold_step (g368 E) (!g1 E) (g843 E) 2 (countTrue (score1_vals2 E)) T1 T0
theorem score1_threshold4_2 (E : Nat→Bool) : ((!g852 E)=true) ↔ 3≤countTrue (score1_vals4 E) := by
  have rew : (!g852 E) = ((g847 E) || ((g369 E) && (!g846 E))) := by simp [g1,g851,g852,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold3_2 E
  have T0 := score1_threshold3_1 E
  exact threshold_step (g369 E) (g847 E) (!g846 E) 2 (countTrue (score1_vals3 E)) T1 T0
theorem score1_threshold5_2 (E : Nat→Bool) : ((!g858 E)=true) ↔ 3≤countTrue (score1_vals5 E) := by
  have rew : (!g858 E) = ((!g852 E) || ((g370 E) && (!g850 E))) := by simp [g1,g857,g858,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold4_2 E
  have T0 := score1_threshold4_1 E
  exact threshold_step (g370 E) (!g852 E) (!g850 E) 2 (countTrue (score1_vals4 E)) T1 T0
theorem score1_threshold6_2 (E : Nat→Bool) : ((!g866 E)=true) ↔ 3≤countTrue (score1_vals6 E) := by
  have rew : (!g866 E) = ((!g858 E) || ((g371 E) && (!g856 E))) := by simp [g1,g865,g866,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold5_2 E
  have T0 := score1_threshold5_1 E
  exact threshold_step (g371 E) (!g858 E) (!g856 E) 2 (countTrue (score1_vals5 E)) T1 T0
theorem score1_threshold7_2 (E : Nat→Bool) : ((!g876 E)=true) ↔ 3≤countTrue (score1_vals7 E) := by
  have rew : (!g876 E) = ((!g866 E) || ((g387 E) && (!g864 E))) := by simp [g1,g875,g876,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold6_2 E
  have T0 := score1_threshold6_1 E
  exact threshold_step (g387 E) (!g866 E) (!g864 E) 2 (countTrue (score1_vals6 E)) T1 T0
theorem score1_threshold8_2 (E : Nat→Bool) : ((!g888 E)=true) ↔ 3≤countTrue (score1_vals8 E) := by
  have rew : (!g888 E) = ((!g876 E) || ((g388 E) && (!g874 E))) := by simp [g1,g887,g888,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold7_2 E
  have T0 := score1_threshold7_1 E
  exact threshold_step (g388 E) (!g876 E) (!g874 E) 2 (countTrue (score1_vals7 E)) T1 T0
theorem score1_threshold9_2 (E : Nat→Bool) : ((!g902 E)=true) ↔ 3≤countTrue (score1_vals9 E) := by
  have rew : (!g902 E) = ((!g888 E) || ((g389 E) && (!g886 E))) := by simp [g1,g901,g902,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold8_2 E
  have T0 := score1_threshold8_1 E
  exact threshold_step (g389 E) (!g888 E) (!g886 E) 2 (countTrue (score1_vals8 E)) T1 T0
theorem score1_threshold10_2 (E : Nat→Bool) : ((!g918 E)=true) ↔ 3≤countTrue (score1_vals10 E) := by
  have rew : (!g918 E) = ((!g902 E) || ((g390 E) && (!g900 E))) := by simp [g1,g917,g918,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold9_2 E
  have T0 := score1_threshold9_1 E
  exact threshold_step (g390 E) (!g902 E) (!g900 E) 2 (countTrue (score1_vals9 E)) T1 T0
theorem score1_threshold11_2 (E : Nat→Bool) : ((!g936 E)=true) ↔ 3≤countTrue (score1_vals11 E) := by
  have rew : (!g936 E) = ((!g918 E) || ((g391 E) && (!g916 E))) := by simp [g1,g935,g936,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold10_2 E
  have T0 := score1_threshold10_1 E
  exact threshold_step (g391 E) (!g918 E) (!g916 E) 2 (countTrue (score1_vals10 E)) T1 T0
theorem score1_threshold12_2 (E : Nat→Bool) : ((!g956 E)=true) ↔ 3≤countTrue (score1_vals12 E) := by
  have rew : (!g956 E) = ((!g936 E) || ((g392 E) && (!g934 E))) := by simp [g1,g955,g956,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold11_2 E
  have T0 := score1_threshold11_1 E
  exact threshold_step (g392 E) (!g936 E) (!g934 E) 2 (countTrue (score1_vals11 E)) T1 T0
theorem score1_threshold13_2 (E : Nat→Bool) : ((!g978 E)=true) ↔ 3≤countTrue (score1_vals13 E) := by
  have rew : (!g978 E) = ((!g956 E) || ((g393 E) && (!g954 E))) := by simp [g1,g977,g978,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold12_2 E
  have T0 := score1_threshold12_1 E
  exact threshold_step (g393 E) (!g956 E) (!g954 E) 2 (countTrue (score1_vals12 E)) T1 T0
theorem score1_threshold14_2 (E : Nat→Bool) : ((!g1002 E)=true) ↔ 3≤countTrue (score1_vals14 E) := by
  have rew : (!g1002 E) = ((!g978 E) || ((g394 E) && (!g976 E))) := by simp [g1,g1001,g1002,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold13_2 E
  have T0 := score1_threshold13_1 E
  exact threshold_step (g394 E) (!g978 E) (!g976 E) 2 (countTrue (score1_vals13 E)) T1 T0
theorem score1_threshold15_2 (E : Nat→Bool) : ((!g1028 E)=true) ↔ 3≤countTrue (score1_vals15 E) := by
  have rew : (!g1028 E) = ((!g1002 E) || ((g395 E) && (!g1000 E))) := by simp [g1,g1027,g1028,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold14_2 E
  have T0 := score1_threshold14_1 E
  exact threshold_step (g395 E) (!g1002 E) (!g1000 E) 2 (countTrue (score1_vals14 E)) T1 T0
theorem score1_threshold16_2 (E : Nat→Bool) : ((!g1056 E)=true) ↔ 3≤countTrue (score1_vals16 E) := by
  have rew : (!g1056 E) = ((!g1028 E) || ((g396 E) && (!g1026 E))) := by simp [g1,g1055,g1056,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold15_2 E
  have T0 := score1_threshold15_1 E
  exact threshold_step (g396 E) (!g1028 E) (!g1026 E) 2 (countTrue (score1_vals15 E)) T1 T0
theorem score1_threshold17_2 (E : Nat→Bool) : ((!g1086 E)=true) ↔ 3≤countTrue (score1_vals17 E) := by
  have rew : (!g1086 E) = ((!g1056 E) || ((g397 E) && (!g1054 E))) := by simp [g1,g1085,g1086,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold16_2 E
  have T0 := score1_threshold16_1 E
  exact threshold_step (g397 E) (!g1056 E) (!g1054 E) 2 (countTrue (score1_vals16 E)) T1 T0
theorem score1_threshold18_2 (E : Nat→Bool) : ((!g1118 E)=true) ↔ 3≤countTrue (score1_vals18 E) := by
  have rew : (!g1118 E) = ((!g1086 E) || ((g398 E) && (!g1084 E))) := by simp [g1,g1117,g1118,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold17_2 E
  have T0 := score1_threshold17_1 E
  exact threshold_step (g398 E) (!g1086 E) (!g1084 E) 2 (countTrue (score1_vals17 E)) T1 T0
theorem score1_threshold19_2 (E : Nat→Bool) : ((!g1152 E)=true) ↔ 3≤countTrue (score1_vals19 E) := by
  have rew : (!g1152 E) = ((!g1118 E) || ((g399 E) && (!g1116 E))) := by simp [g1,g1151,g1152,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold18_2 E
  have T0 := score1_threshold18_1 E
  exact threshold_step (g399 E) (!g1118 E) (!g1116 E) 2 (countTrue (score1_vals18 E)) T1 T0
theorem score1_threshold20_2 (E : Nat→Bool) : ((!g1188 E)=true) ↔ 3≤countTrue (score1_vals20 E) := by
  have rew : (!g1188 E) = ((!g1152 E) || ((g400 E) && (!g1150 E))) := by simp [g1,g1187,g1188,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold19_2 E
  have T0 := score1_threshold19_1 E
  exact threshold_step (g400 E) (!g1152 E) (!g1150 E) 2 (countTrue (score1_vals19 E)) T1 T0
theorem score1_threshold21_2 (E : Nat→Bool) : ((!g1226 E)=true) ↔ 3≤countTrue (score1_vals21 E) := by
  have rew : (!g1226 E) = ((!g1188 E) || ((g401 E) && (!g1186 E))) := by simp [g1,g1225,g1226,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold20_2 E
  have T0 := score1_threshold20_1 E
  exact threshold_step (g401 E) (!g1188 E) (!g1186 E) 2 (countTrue (score1_vals20 E)) T1 T0
theorem score1_threshold4_3 (E : Nat→Bool) : ((g853 E)=true) ↔ 4≤countTrue (score1_vals4 E) := by
  have rew : (g853 E) = ((!g1 E) || ((g369 E) && (g847 E))) := by simp [g1,g853,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 4≤countTrue (score1_vals3 E) := by
    have hh := count_true_bound (score1_vals3 E)
    change countTrue (score1_vals3 E)≤3 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬4≤countTrue (score1_vals3 E)
    omega
  have T0 := score1_threshold3_2 E
  exact threshold_step (g369 E) (!g1 E) (g847 E) 3 (countTrue (score1_vals3 E)) T1 T0
theorem score1_threshold5_3 (E : Nat→Bool) : ((!g860 E)=true) ↔ 4≤countTrue (score1_vals5 E) := by
  have rew : (!g860 E) = ((g853 E) || ((g370 E) && (!g852 E))) := by simp [g1,g859,g860,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold4_3 E
  have T0 := score1_threshold4_2 E
  exact threshold_step (g370 E) (g853 E) (!g852 E) 3 (countTrue (score1_vals4 E)) T1 T0
theorem score1_threshold6_3 (E : Nat→Bool) : ((!g868 E)=true) ↔ 4≤countTrue (score1_vals6 E) := by
  have rew : (!g868 E) = ((!g860 E) || ((g371 E) && (!g858 E))) := by simp [g1,g867,g868,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold5_3 E
  have T0 := score1_threshold5_2 E
  exact threshold_step (g371 E) (!g860 E) (!g858 E) 3 (countTrue (score1_vals5 E)) T1 T0
theorem score1_threshold7_3 (E : Nat→Bool) : ((!g878 E)=true) ↔ 4≤countTrue (score1_vals7 E) := by
  have rew : (!g878 E) = ((!g868 E) || ((g387 E) && (!g866 E))) := by simp [g1,g877,g878,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold6_3 E
  have T0 := score1_threshold6_2 E
  exact threshold_step (g387 E) (!g868 E) (!g866 E) 3 (countTrue (score1_vals6 E)) T1 T0
theorem score1_threshold8_3 (E : Nat→Bool) : ((!g890 E)=true) ↔ 4≤countTrue (score1_vals8 E) := by
  have rew : (!g890 E) = ((!g878 E) || ((g388 E) && (!g876 E))) := by simp [g1,g889,g890,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold7_3 E
  have T0 := score1_threshold7_2 E
  exact threshold_step (g388 E) (!g878 E) (!g876 E) 3 (countTrue (score1_vals7 E)) T1 T0
theorem score1_threshold9_3 (E : Nat→Bool) : ((!g904 E)=true) ↔ 4≤countTrue (score1_vals9 E) := by
  have rew : (!g904 E) = ((!g890 E) || ((g389 E) && (!g888 E))) := by simp [g1,g903,g904,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold8_3 E
  have T0 := score1_threshold8_2 E
  exact threshold_step (g389 E) (!g890 E) (!g888 E) 3 (countTrue (score1_vals8 E)) T1 T0
theorem score1_threshold10_3 (E : Nat→Bool) : ((!g920 E)=true) ↔ 4≤countTrue (score1_vals10 E) := by
  have rew : (!g920 E) = ((!g904 E) || ((g390 E) && (!g902 E))) := by simp [g1,g919,g920,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold9_3 E
  have T0 := score1_threshold9_2 E
  exact threshold_step (g390 E) (!g904 E) (!g902 E) 3 (countTrue (score1_vals9 E)) T1 T0
theorem score1_threshold11_3 (E : Nat→Bool) : ((!g938 E)=true) ↔ 4≤countTrue (score1_vals11 E) := by
  have rew : (!g938 E) = ((!g920 E) || ((g391 E) && (!g918 E))) := by simp [g1,g937,g938,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold10_3 E
  have T0 := score1_threshold10_2 E
  exact threshold_step (g391 E) (!g920 E) (!g918 E) 3 (countTrue (score1_vals10 E)) T1 T0
theorem score1_threshold12_3 (E : Nat→Bool) : ((!g958 E)=true) ↔ 4≤countTrue (score1_vals12 E) := by
  have rew : (!g958 E) = ((!g938 E) || ((g392 E) && (!g936 E))) := by simp [g1,g957,g958,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold11_3 E
  have T0 := score1_threshold11_2 E
  exact threshold_step (g392 E) (!g938 E) (!g936 E) 3 (countTrue (score1_vals11 E)) T1 T0
theorem score1_threshold13_3 (E : Nat→Bool) : ((!g980 E)=true) ↔ 4≤countTrue (score1_vals13 E) := by
  have rew : (!g980 E) = ((!g958 E) || ((g393 E) && (!g956 E))) := by simp [g1,g979,g980,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold12_3 E
  have T0 := score1_threshold12_2 E
  exact threshold_step (g393 E) (!g958 E) (!g956 E) 3 (countTrue (score1_vals12 E)) T1 T0
theorem score1_threshold14_3 (E : Nat→Bool) : ((!g1004 E)=true) ↔ 4≤countTrue (score1_vals14 E) := by
  have rew : (!g1004 E) = ((!g980 E) || ((g394 E) && (!g978 E))) := by simp [g1,g1003,g1004,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold13_3 E
  have T0 := score1_threshold13_2 E
  exact threshold_step (g394 E) (!g980 E) (!g978 E) 3 (countTrue (score1_vals13 E)) T1 T0
theorem score1_threshold15_3 (E : Nat→Bool) : ((!g1030 E)=true) ↔ 4≤countTrue (score1_vals15 E) := by
  have rew : (!g1030 E) = ((!g1004 E) || ((g395 E) && (!g1002 E))) := by simp [g1,g1029,g1030,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold14_3 E
  have T0 := score1_threshold14_2 E
  exact threshold_step (g395 E) (!g1004 E) (!g1002 E) 3 (countTrue (score1_vals14 E)) T1 T0
theorem score1_threshold16_3 (E : Nat→Bool) : ((!g1058 E)=true) ↔ 4≤countTrue (score1_vals16 E) := by
  have rew : (!g1058 E) = ((!g1030 E) || ((g396 E) && (!g1028 E))) := by simp [g1,g1057,g1058,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold15_3 E
  have T0 := score1_threshold15_2 E
  exact threshold_step (g396 E) (!g1030 E) (!g1028 E) 3 (countTrue (score1_vals15 E)) T1 T0
theorem score1_threshold17_3 (E : Nat→Bool) : ((!g1088 E)=true) ↔ 4≤countTrue (score1_vals17 E) := by
  have rew : (!g1088 E) = ((!g1058 E) || ((g397 E) && (!g1056 E))) := by simp [g1,g1087,g1088,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold16_3 E
  have T0 := score1_threshold16_2 E
  exact threshold_step (g397 E) (!g1058 E) (!g1056 E) 3 (countTrue (score1_vals16 E)) T1 T0
theorem score1_threshold18_3 (E : Nat→Bool) : ((!g1120 E)=true) ↔ 4≤countTrue (score1_vals18 E) := by
  have rew : (!g1120 E) = ((!g1088 E) || ((g398 E) && (!g1086 E))) := by simp [g1,g1119,g1120,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold17_3 E
  have T0 := score1_threshold17_2 E
  exact threshold_step (g398 E) (!g1088 E) (!g1086 E) 3 (countTrue (score1_vals17 E)) T1 T0
theorem score1_threshold19_3 (E : Nat→Bool) : ((!g1154 E)=true) ↔ 4≤countTrue (score1_vals19 E) := by
  have rew : (!g1154 E) = ((!g1120 E) || ((g399 E) && (!g1118 E))) := by simp [g1,g1153,g1154,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold18_3 E
  have T0 := score1_threshold18_2 E
  exact threshold_step (g399 E) (!g1120 E) (!g1118 E) 3 (countTrue (score1_vals18 E)) T1 T0
theorem score1_threshold20_3 (E : Nat→Bool) : ((!g1190 E)=true) ↔ 4≤countTrue (score1_vals20 E) := by
  have rew : (!g1190 E) = ((!g1154 E) || ((g400 E) && (!g1152 E))) := by simp [g1,g1189,g1190,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold19_3 E
  have T0 := score1_threshold19_2 E
  exact threshold_step (g400 E) (!g1154 E) (!g1152 E) 3 (countTrue (score1_vals19 E)) T1 T0
theorem score1_threshold21_3 (E : Nat→Bool) : ((!g1228 E)=true) ↔ 4≤countTrue (score1_vals21 E) := by
  have rew : (!g1228 E) = ((!g1190 E) || ((g401 E) && (!g1188 E))) := by simp [g1,g1227,g1228,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold20_3 E
  have T0 := score1_threshold20_2 E
  exact threshold_step (g401 E) (!g1190 E) (!g1188 E) 3 (countTrue (score1_vals20 E)) T1 T0
theorem score1_threshold5_4 (E : Nat→Bool) : ((g861 E)=true) ↔ 5≤countTrue (score1_vals5 E) := by
  have rew : (g861 E) = ((!g1 E) || ((g370 E) && (g853 E))) := by simp [g1,g861,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 5≤countTrue (score1_vals4 E) := by
    have hh := count_true_bound (score1_vals4 E)
    change countTrue (score1_vals4 E)≤4 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬5≤countTrue (score1_vals4 E)
    omega
  have T0 := score1_threshold4_3 E
  exact threshold_step (g370 E) (!g1 E) (g853 E) 4 (countTrue (score1_vals4 E)) T1 T0
theorem score1_threshold6_4 (E : Nat→Bool) : ((!g870 E)=true) ↔ 5≤countTrue (score1_vals6 E) := by
  have rew : (!g870 E) = ((g861 E) || ((g371 E) && (!g860 E))) := by simp [g1,g869,g870,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold5_4 E
  have T0 := score1_threshold5_3 E
  exact threshold_step (g371 E) (g861 E) (!g860 E) 4 (countTrue (score1_vals5 E)) T1 T0
theorem score1_threshold7_4 (E : Nat→Bool) : ((!g880 E)=true) ↔ 5≤countTrue (score1_vals7 E) := by
  have rew : (!g880 E) = ((!g870 E) || ((g387 E) && (!g868 E))) := by simp [g1,g879,g880,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold6_4 E
  have T0 := score1_threshold6_3 E
  exact threshold_step (g387 E) (!g870 E) (!g868 E) 4 (countTrue (score1_vals6 E)) T1 T0
theorem score1_threshold8_4 (E : Nat→Bool) : ((!g892 E)=true) ↔ 5≤countTrue (score1_vals8 E) := by
  have rew : (!g892 E) = ((!g880 E) || ((g388 E) && (!g878 E))) := by simp [g1,g891,g892,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold7_4 E
  have T0 := score1_threshold7_3 E
  exact threshold_step (g388 E) (!g880 E) (!g878 E) 4 (countTrue (score1_vals7 E)) T1 T0
theorem score1_threshold9_4 (E : Nat→Bool) : ((!g906 E)=true) ↔ 5≤countTrue (score1_vals9 E) := by
  have rew : (!g906 E) = ((!g892 E) || ((g389 E) && (!g890 E))) := by simp [g1,g905,g906,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold8_4 E
  have T0 := score1_threshold8_3 E
  exact threshold_step (g389 E) (!g892 E) (!g890 E) 4 (countTrue (score1_vals8 E)) T1 T0
theorem score1_threshold10_4 (E : Nat→Bool) : ((!g922 E)=true) ↔ 5≤countTrue (score1_vals10 E) := by
  have rew : (!g922 E) = ((!g906 E) || ((g390 E) && (!g904 E))) := by simp [g1,g921,g922,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold9_4 E
  have T0 := score1_threshold9_3 E
  exact threshold_step (g390 E) (!g906 E) (!g904 E) 4 (countTrue (score1_vals9 E)) T1 T0
theorem score1_threshold11_4 (E : Nat→Bool) : ((!g940 E)=true) ↔ 5≤countTrue (score1_vals11 E) := by
  have rew : (!g940 E) = ((!g922 E) || ((g391 E) && (!g920 E))) := by simp [g1,g939,g940,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold10_4 E
  have T0 := score1_threshold10_3 E
  exact threshold_step (g391 E) (!g922 E) (!g920 E) 4 (countTrue (score1_vals10 E)) T1 T0
theorem score1_threshold12_4 (E : Nat→Bool) : ((!g960 E)=true) ↔ 5≤countTrue (score1_vals12 E) := by
  have rew : (!g960 E) = ((!g940 E) || ((g392 E) && (!g938 E))) := by simp [g1,g959,g960,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold11_4 E
  have T0 := score1_threshold11_3 E
  exact threshold_step (g392 E) (!g940 E) (!g938 E) 4 (countTrue (score1_vals11 E)) T1 T0
theorem score1_threshold13_4 (E : Nat→Bool) : ((!g982 E)=true) ↔ 5≤countTrue (score1_vals13 E) := by
  have rew : (!g982 E) = ((!g960 E) || ((g393 E) && (!g958 E))) := by simp [g1,g981,g982,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold12_4 E
  have T0 := score1_threshold12_3 E
  exact threshold_step (g393 E) (!g960 E) (!g958 E) 4 (countTrue (score1_vals12 E)) T1 T0
theorem score1_threshold14_4 (E : Nat→Bool) : ((!g1006 E)=true) ↔ 5≤countTrue (score1_vals14 E) := by
  have rew : (!g1006 E) = ((!g982 E) || ((g394 E) && (!g980 E))) := by simp [g1,g1005,g1006,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold13_4 E
  have T0 := score1_threshold13_3 E
  exact threshold_step (g394 E) (!g982 E) (!g980 E) 4 (countTrue (score1_vals13 E)) T1 T0
theorem score1_threshold15_4 (E : Nat→Bool) : ((!g1032 E)=true) ↔ 5≤countTrue (score1_vals15 E) := by
  have rew : (!g1032 E) = ((!g1006 E) || ((g395 E) && (!g1004 E))) := by simp [g1,g1031,g1032,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold14_4 E
  have T0 := score1_threshold14_3 E
  exact threshold_step (g395 E) (!g1006 E) (!g1004 E) 4 (countTrue (score1_vals14 E)) T1 T0
theorem score1_threshold16_4 (E : Nat→Bool) : ((!g1060 E)=true) ↔ 5≤countTrue (score1_vals16 E) := by
  have rew : (!g1060 E) = ((!g1032 E) || ((g396 E) && (!g1030 E))) := by simp [g1,g1059,g1060,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold15_4 E
  have T0 := score1_threshold15_3 E
  exact threshold_step (g396 E) (!g1032 E) (!g1030 E) 4 (countTrue (score1_vals15 E)) T1 T0
theorem score1_threshold17_4 (E : Nat→Bool) : ((!g1090 E)=true) ↔ 5≤countTrue (score1_vals17 E) := by
  have rew : (!g1090 E) = ((!g1060 E) || ((g397 E) && (!g1058 E))) := by simp [g1,g1089,g1090,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold16_4 E
  have T0 := score1_threshold16_3 E
  exact threshold_step (g397 E) (!g1060 E) (!g1058 E) 4 (countTrue (score1_vals16 E)) T1 T0
theorem score1_threshold18_4 (E : Nat→Bool) : ((!g1122 E)=true) ↔ 5≤countTrue (score1_vals18 E) := by
  have rew : (!g1122 E) = ((!g1090 E) || ((g398 E) && (!g1088 E))) := by simp [g1,g1121,g1122,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold17_4 E
  have T0 := score1_threshold17_3 E
  exact threshold_step (g398 E) (!g1090 E) (!g1088 E) 4 (countTrue (score1_vals17 E)) T1 T0
theorem score1_threshold19_4 (E : Nat→Bool) : ((!g1156 E)=true) ↔ 5≤countTrue (score1_vals19 E) := by
  have rew : (!g1156 E) = ((!g1122 E) || ((g399 E) && (!g1120 E))) := by simp [g1,g1155,g1156,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold18_4 E
  have T0 := score1_threshold18_3 E
  exact threshold_step (g399 E) (!g1122 E) (!g1120 E) 4 (countTrue (score1_vals18 E)) T1 T0
theorem score1_threshold20_4 (E : Nat→Bool) : ((!g1192 E)=true) ↔ 5≤countTrue (score1_vals20 E) := by
  have rew : (!g1192 E) = ((!g1156 E) || ((g400 E) && (!g1154 E))) := by simp [g1,g1191,g1192,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold19_4 E
  have T0 := score1_threshold19_3 E
  exact threshold_step (g400 E) (!g1156 E) (!g1154 E) 4 (countTrue (score1_vals19 E)) T1 T0
theorem score1_threshold21_4 (E : Nat→Bool) : ((!g1230 E)=true) ↔ 5≤countTrue (score1_vals21 E) := by
  have rew : (!g1230 E) = ((!g1192 E) || ((g401 E) && (!g1190 E))) := by simp [g1,g1229,g1230,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold20_4 E
  have T0 := score1_threshold20_3 E
  exact threshold_step (g401 E) (!g1192 E) (!g1190 E) 4 (countTrue (score1_vals20 E)) T1 T0
theorem score1_threshold6_5 (E : Nat→Bool) : ((g871 E)=true) ↔ 6≤countTrue (score1_vals6 E) := by
  have rew : (g871 E) = ((!g1 E) || ((g371 E) && (g861 E))) := by simp [g1,g871,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 6≤countTrue (score1_vals5 E) := by
    have hh := count_true_bound (score1_vals5 E)
    change countTrue (score1_vals5 E)≤5 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬6≤countTrue (score1_vals5 E)
    omega
  have T0 := score1_threshold5_4 E
  exact threshold_step (g371 E) (!g1 E) (g861 E) 5 (countTrue (score1_vals5 E)) T1 T0
theorem score1_threshold7_5 (E : Nat→Bool) : ((!g882 E)=true) ↔ 6≤countTrue (score1_vals7 E) := by
  have rew : (!g882 E) = ((g871 E) || ((g387 E) && (!g870 E))) := by simp [g1,g881,g882,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold6_5 E
  have T0 := score1_threshold6_4 E
  exact threshold_step (g387 E) (g871 E) (!g870 E) 5 (countTrue (score1_vals6 E)) T1 T0
theorem score1_threshold8_5 (E : Nat→Bool) : ((!g894 E)=true) ↔ 6≤countTrue (score1_vals8 E) := by
  have rew : (!g894 E) = ((!g882 E) || ((g388 E) && (!g880 E))) := by simp [g1,g893,g894,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold7_5 E
  have T0 := score1_threshold7_4 E
  exact threshold_step (g388 E) (!g882 E) (!g880 E) 5 (countTrue (score1_vals7 E)) T1 T0
theorem score1_threshold9_5 (E : Nat→Bool) : ((!g908 E)=true) ↔ 6≤countTrue (score1_vals9 E) := by
  have rew : (!g908 E) = ((!g894 E) || ((g389 E) && (!g892 E))) := by simp [g1,g907,g908,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold8_5 E
  have T0 := score1_threshold8_4 E
  exact threshold_step (g389 E) (!g894 E) (!g892 E) 5 (countTrue (score1_vals8 E)) T1 T0
theorem score1_threshold10_5 (E : Nat→Bool) : ((!g924 E)=true) ↔ 6≤countTrue (score1_vals10 E) := by
  have rew : (!g924 E) = ((!g908 E) || ((g390 E) && (!g906 E))) := by simp [g1,g923,g924,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold9_5 E
  have T0 := score1_threshold9_4 E
  exact threshold_step (g390 E) (!g908 E) (!g906 E) 5 (countTrue (score1_vals9 E)) T1 T0
theorem score1_threshold11_5 (E : Nat→Bool) : ((!g942 E)=true) ↔ 6≤countTrue (score1_vals11 E) := by
  have rew : (!g942 E) = ((!g924 E) || ((g391 E) && (!g922 E))) := by simp [g1,g941,g942,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold10_5 E
  have T0 := score1_threshold10_4 E
  exact threshold_step (g391 E) (!g924 E) (!g922 E) 5 (countTrue (score1_vals10 E)) T1 T0
theorem score1_threshold12_5 (E : Nat→Bool) : ((!g962 E)=true) ↔ 6≤countTrue (score1_vals12 E) := by
  have rew : (!g962 E) = ((!g942 E) || ((g392 E) && (!g940 E))) := by simp [g1,g961,g962,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold11_5 E
  have T0 := score1_threshold11_4 E
  exact threshold_step (g392 E) (!g942 E) (!g940 E) 5 (countTrue (score1_vals11 E)) T1 T0
theorem score1_threshold13_5 (E : Nat→Bool) : ((!g984 E)=true) ↔ 6≤countTrue (score1_vals13 E) := by
  have rew : (!g984 E) = ((!g962 E) || ((g393 E) && (!g960 E))) := by simp [g1,g983,g984,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold12_5 E
  have T0 := score1_threshold12_4 E
  exact threshold_step (g393 E) (!g962 E) (!g960 E) 5 (countTrue (score1_vals12 E)) T1 T0
theorem score1_threshold14_5 (E : Nat→Bool) : ((!g1008 E)=true) ↔ 6≤countTrue (score1_vals14 E) := by
  have rew : (!g1008 E) = ((!g984 E) || ((g394 E) && (!g982 E))) := by simp [g1,g1007,g1008,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold13_5 E
  have T0 := score1_threshold13_4 E
  exact threshold_step (g394 E) (!g984 E) (!g982 E) 5 (countTrue (score1_vals13 E)) T1 T0
theorem score1_threshold15_5 (E : Nat→Bool) : ((!g1034 E)=true) ↔ 6≤countTrue (score1_vals15 E) := by
  have rew : (!g1034 E) = ((!g1008 E) || ((g395 E) && (!g1006 E))) := by simp [g1,g1033,g1034,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold14_5 E
  have T0 := score1_threshold14_4 E
  exact threshold_step (g395 E) (!g1008 E) (!g1006 E) 5 (countTrue (score1_vals14 E)) T1 T0
theorem score1_threshold16_5 (E : Nat→Bool) : ((!g1062 E)=true) ↔ 6≤countTrue (score1_vals16 E) := by
  have rew : (!g1062 E) = ((!g1034 E) || ((g396 E) && (!g1032 E))) := by simp [g1,g1061,g1062,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold15_5 E
  have T0 := score1_threshold15_4 E
  exact threshold_step (g396 E) (!g1034 E) (!g1032 E) 5 (countTrue (score1_vals15 E)) T1 T0
theorem score1_threshold17_5 (E : Nat→Bool) : ((!g1092 E)=true) ↔ 6≤countTrue (score1_vals17 E) := by
  have rew : (!g1092 E) = ((!g1062 E) || ((g397 E) && (!g1060 E))) := by simp [g1,g1091,g1092,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold16_5 E
  have T0 := score1_threshold16_4 E
  exact threshold_step (g397 E) (!g1062 E) (!g1060 E) 5 (countTrue (score1_vals16 E)) T1 T0
theorem score1_threshold18_5 (E : Nat→Bool) : ((!g1124 E)=true) ↔ 6≤countTrue (score1_vals18 E) := by
  have rew : (!g1124 E) = ((!g1092 E) || ((g398 E) && (!g1090 E))) := by simp [g1,g1123,g1124,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold17_5 E
  have T0 := score1_threshold17_4 E
  exact threshold_step (g398 E) (!g1092 E) (!g1090 E) 5 (countTrue (score1_vals17 E)) T1 T0
theorem score1_threshold19_5 (E : Nat→Bool) : ((!g1158 E)=true) ↔ 6≤countTrue (score1_vals19 E) := by
  have rew : (!g1158 E) = ((!g1124 E) || ((g399 E) && (!g1122 E))) := by simp [g1,g1157,g1158,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold18_5 E
  have T0 := score1_threshold18_4 E
  exact threshold_step (g399 E) (!g1124 E) (!g1122 E) 5 (countTrue (score1_vals18 E)) T1 T0
theorem score1_threshold20_5 (E : Nat→Bool) : ((!g1194 E)=true) ↔ 6≤countTrue (score1_vals20 E) := by
  have rew : (!g1194 E) = ((!g1158 E) || ((g400 E) && (!g1156 E))) := by simp [g1,g1193,g1194,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold19_5 E
  have T0 := score1_threshold19_4 E
  exact threshold_step (g400 E) (!g1158 E) (!g1156 E) 5 (countTrue (score1_vals19 E)) T1 T0
theorem score1_threshold21_5 (E : Nat→Bool) : ((!g1232 E)=true) ↔ 6≤countTrue (score1_vals21 E) := by
  have rew : (!g1232 E) = ((!g1194 E) || ((g401 E) && (!g1192 E))) := by simp [g1,g1231,g1232,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold20_5 E
  have T0 := score1_threshold20_4 E
  exact threshold_step (g401 E) (!g1194 E) (!g1192 E) 5 (countTrue (score1_vals20 E)) T1 T0
def score1_count (E : Nat→Bool) : Nat := countTrue (score1_vals21 E)
def score2_vals1 (E : Nat→Bool) : List Bool := (g366 E) :: ([])
def score2_vals2 (E : Nat→Bool) : List Bool := (g372 E) :: (score2_vals1 E)
def score2_vals3 (E : Nat→Bool) : List Bool := (g373 E) :: (score2_vals2 E)
def score2_vals4 (E : Nat→Bool) : List Bool := (g374 E) :: (score2_vals3 E)
def score2_vals5 (E : Nat→Bool) : List Bool := (g375 E) :: (score2_vals4 E)
def score2_vals6 (E : Nat→Bool) : List Bool := (g376 E) :: (score2_vals5 E)
def score2_vals7 (E : Nat→Bool) : List Bool := (g387 E) :: (score2_vals6 E)
def score2_vals8 (E : Nat→Bool) : List Bool := (g388 E) :: (score2_vals7 E)
def score2_vals9 (E : Nat→Bool) : List Bool := (g389 E) :: (score2_vals8 E)
def score2_vals10 (E : Nat→Bool) : List Bool := (g390 E) :: (score2_vals9 E)
def score2_vals11 (E : Nat→Bool) : List Bool := (g391 E) :: (score2_vals10 E)
def score2_vals12 (E : Nat→Bool) : List Bool := (g402 E) :: (score2_vals11 E)
def score2_vals13 (E : Nat→Bool) : List Bool := (g403 E) :: (score2_vals12 E)
def score2_vals14 (E : Nat→Bool) : List Bool := (g404 E) :: (score2_vals13 E)
def score2_vals15 (E : Nat→Bool) : List Bool := (g405 E) :: (score2_vals14 E)
def score2_vals16 (E : Nat→Bool) : List Bool := (g406 E) :: (score2_vals15 E)
def score2_vals17 (E : Nat→Bool) : List Bool := (g407 E) :: (score2_vals16 E)
def score2_vals18 (E : Nat→Bool) : List Bool := (g408 E) :: (score2_vals17 E)
def score2_vals19 (E : Nat→Bool) : List Bool := (g409 E) :: (score2_vals18 E)
def score2_vals20 (E : Nat→Bool) : List Bool := (g410 E) :: (score2_vals19 E)
def score2_vals21 (E : Nat→Bool) : List Bool := (g411 E) :: (score2_vals20 E)
theorem score2_threshold1_0 (E : Nat→Bool) : ((g366 E)=true) ↔ 1≤countTrue (score2_vals1 E) := by
  have rew : (g366 E) = ((!g1 E) || ((g366 E) && (g1 E))) := by simp [g1,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 1≤countTrue ([] : List Bool) := by
    have hh := count_true_bound ([] : List Bool)
    change countTrue ([] : List Bool)≤0 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬1≤countTrue ([] : List Bool)
    omega
  have T0 : (g1 E)=true ↔ 0≤countTrue ([] : List Bool) := by simp [g1]
  exact threshold_step (g366 E) (!g1 E) (g1 E) 0 (countTrue ([] : List Bool)) T1 T0
theorem score2_threshold2_1 (E : Nat→Bool) : ((g1263 E)=true) ↔ 2≤countTrue (score2_vals2 E) := by
  have rew : (g1263 E) = ((!g1 E) || ((g372 E) && (g366 E))) := by simp [g1,g1263,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 2≤countTrue (score2_vals1 E) := by
    have hh := count_true_bound (score2_vals1 E)
    change countTrue (score2_vals1 E)≤1 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬2≤countTrue (score2_vals1 E)
    omega
  have T0 := score2_threshold1_0 E
  exact threshold_step (g372 E) (!g1 E) (g366 E) 1 (countTrue (score2_vals1 E)) T1 T0
theorem score2_threshold2_0 (E : Nat→Bool) : ((!g1262 E)=true) ↔ 1≤countTrue (score2_vals2 E) := by
  have rew : (!g1262 E) = ((g366 E) || ((g372 E) && (g1 E))) := by simp [g1,g1262,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold1_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals1 E) := by simp [g1]
  exact threshold_step (g372 E) (g366 E) (g1 E) 0 (countTrue (score2_vals1 E)) T1 T0
theorem score2_threshold3_1 (E : Nat→Bool) : ((!g1266 E)=true) ↔ 2≤countTrue (score2_vals3 E) := by
  have rew : (!g1266 E) = ((g1263 E) || ((g373 E) && (!g1262 E))) := by simp [g1,g1265,g1266,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold2_1 E
  have T0 := score2_threshold2_0 E
  exact threshold_step (g373 E) (g1263 E) (!g1262 E) 1 (countTrue (score2_vals2 E)) T1 T0
theorem score2_threshold3_0 (E : Nat→Bool) : ((!g1264 E)=true) ↔ 1≤countTrue (score2_vals3 E) := by
  have rew : (!g1264 E) = ((!g1262 E) || ((g373 E) && (g1 E))) := by simp [g1,g1264,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold2_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals2 E) := by simp [g1]
  exact threshold_step (g373 E) (!g1262 E) (g1 E) 0 (countTrue (score2_vals2 E)) T1 T0
theorem score2_threshold4_1 (E : Nat→Bool) : ((!g1270 E)=true) ↔ 2≤countTrue (score2_vals4 E) := by
  have rew : (!g1270 E) = ((!g1266 E) || ((g374 E) && (!g1264 E))) := by simp [g1,g1269,g1270,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold3_1 E
  have T0 := score2_threshold3_0 E
  exact threshold_step (g374 E) (!g1266 E) (!g1264 E) 1 (countTrue (score2_vals3 E)) T1 T0
theorem score2_threshold4_0 (E : Nat→Bool) : ((!g1268 E)=true) ↔ 1≤countTrue (score2_vals4 E) := by
  have rew : (!g1268 E) = ((!g1264 E) || ((g374 E) && (g1 E))) := by simp [g1,g1268,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold3_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals3 E) := by simp [g1]
  exact threshold_step (g374 E) (!g1264 E) (g1 E) 0 (countTrue (score2_vals3 E)) T1 T0
theorem score2_threshold5_1 (E : Nat→Bool) : ((!g1276 E)=true) ↔ 2≤countTrue (score2_vals5 E) := by
  have rew : (!g1276 E) = ((!g1270 E) || ((g375 E) && (!g1268 E))) := by simp [g1,g1275,g1276,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold4_1 E
  have T0 := score2_threshold4_0 E
  exact threshold_step (g375 E) (!g1270 E) (!g1268 E) 1 (countTrue (score2_vals4 E)) T1 T0
theorem score2_threshold5_0 (E : Nat→Bool) : ((!g1274 E)=true) ↔ 1≤countTrue (score2_vals5 E) := by
  have rew : (!g1274 E) = ((!g1268 E) || ((g375 E) && (g1 E))) := by simp [g1,g1274,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold4_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals4 E) := by simp [g1]
  exact threshold_step (g375 E) (!g1268 E) (g1 E) 0 (countTrue (score2_vals4 E)) T1 T0
theorem score2_threshold6_1 (E : Nat→Bool) : ((!g1284 E)=true) ↔ 2≤countTrue (score2_vals6 E) := by
  have rew : (!g1284 E) = ((!g1276 E) || ((g376 E) && (!g1274 E))) := by simp [g1,g1283,g1284,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold5_1 E
  have T0 := score2_threshold5_0 E
  exact threshold_step (g376 E) (!g1276 E) (!g1274 E) 1 (countTrue (score2_vals5 E)) T1 T0
theorem score2_threshold6_0 (E : Nat→Bool) : ((!g1282 E)=true) ↔ 1≤countTrue (score2_vals6 E) := by
  have rew : (!g1282 E) = ((!g1274 E) || ((g376 E) && (g1 E))) := by simp [g1,g1282,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold5_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals5 E) := by simp [g1]
  exact threshold_step (g376 E) (!g1274 E) (g1 E) 0 (countTrue (score2_vals5 E)) T1 T0
theorem score2_threshold7_1 (E : Nat→Bool) : ((!g1294 E)=true) ↔ 2≤countTrue (score2_vals7 E) := by
  have rew : (!g1294 E) = ((!g1284 E) || ((g387 E) && (!g1282 E))) := by simp [g1,g1293,g1294,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold6_1 E
  have T0 := score2_threshold6_0 E
  exact threshold_step (g387 E) (!g1284 E) (!g1282 E) 1 (countTrue (score2_vals6 E)) T1 T0
theorem score2_threshold7_0 (E : Nat→Bool) : ((!g1292 E)=true) ↔ 1≤countTrue (score2_vals7 E) := by
  have rew : (!g1292 E) = ((!g1282 E) || ((g387 E) && (g1 E))) := by simp [g1,g1292,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold6_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals6 E) := by simp [g1]
  exact threshold_step (g387 E) (!g1282 E) (g1 E) 0 (countTrue (score2_vals6 E)) T1 T0
theorem score2_threshold8_1 (E : Nat→Bool) : ((!g1306 E)=true) ↔ 2≤countTrue (score2_vals8 E) := by
  have rew : (!g1306 E) = ((!g1294 E) || ((g388 E) && (!g1292 E))) := by simp [g1,g1305,g1306,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold7_1 E
  have T0 := score2_threshold7_0 E
  exact threshold_step (g388 E) (!g1294 E) (!g1292 E) 1 (countTrue (score2_vals7 E)) T1 T0
theorem score2_threshold8_0 (E : Nat→Bool) : ((!g1304 E)=true) ↔ 1≤countTrue (score2_vals8 E) := by
  have rew : (!g1304 E) = ((!g1292 E) || ((g388 E) && (g1 E))) := by simp [g1,g1304,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold7_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals7 E) := by simp [g1]
  exact threshold_step (g388 E) (!g1292 E) (g1 E) 0 (countTrue (score2_vals7 E)) T1 T0
theorem score2_threshold9_1 (E : Nat→Bool) : ((!g1320 E)=true) ↔ 2≤countTrue (score2_vals9 E) := by
  have rew : (!g1320 E) = ((!g1306 E) || ((g389 E) && (!g1304 E))) := by simp [g1,g1319,g1320,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold8_1 E
  have T0 := score2_threshold8_0 E
  exact threshold_step (g389 E) (!g1306 E) (!g1304 E) 1 (countTrue (score2_vals8 E)) T1 T0
theorem score2_threshold9_0 (E : Nat→Bool) : ((!g1318 E)=true) ↔ 1≤countTrue (score2_vals9 E) := by
  have rew : (!g1318 E) = ((!g1304 E) || ((g389 E) && (g1 E))) := by simp [g1,g1318,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold8_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals8 E) := by simp [g1]
  exact threshold_step (g389 E) (!g1304 E) (g1 E) 0 (countTrue (score2_vals8 E)) T1 T0
theorem score2_threshold10_1 (E : Nat→Bool) : ((!g1336 E)=true) ↔ 2≤countTrue (score2_vals10 E) := by
  have rew : (!g1336 E) = ((!g1320 E) || ((g390 E) && (!g1318 E))) := by simp [g1,g1335,g1336,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold9_1 E
  have T0 := score2_threshold9_0 E
  exact threshold_step (g390 E) (!g1320 E) (!g1318 E) 1 (countTrue (score2_vals9 E)) T1 T0
theorem score2_threshold10_0 (E : Nat→Bool) : ((!g1334 E)=true) ↔ 1≤countTrue (score2_vals10 E) := by
  have rew : (!g1334 E) = ((!g1318 E) || ((g390 E) && (g1 E))) := by simp [g1,g1334,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold9_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals9 E) := by simp [g1]
  exact threshold_step (g390 E) (!g1318 E) (g1 E) 0 (countTrue (score2_vals9 E)) T1 T0
theorem score2_threshold11_1 (E : Nat→Bool) : ((!g1354 E)=true) ↔ 2≤countTrue (score2_vals11 E) := by
  have rew : (!g1354 E) = ((!g1336 E) || ((g391 E) && (!g1334 E))) := by simp [g1,g1353,g1354,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold10_1 E
  have T0 := score2_threshold10_0 E
  exact threshold_step (g391 E) (!g1336 E) (!g1334 E) 1 (countTrue (score2_vals10 E)) T1 T0
theorem score2_threshold11_0 (E : Nat→Bool) : ((!g1352 E)=true) ↔ 1≤countTrue (score2_vals11 E) := by
  have rew : (!g1352 E) = ((!g1334 E) || ((g391 E) && (g1 E))) := by simp [g1,g1352,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold10_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals10 E) := by simp [g1]
  exact threshold_step (g391 E) (!g1334 E) (g1 E) 0 (countTrue (score2_vals10 E)) T1 T0
theorem score2_threshold12_1 (E : Nat→Bool) : ((!g1374 E)=true) ↔ 2≤countTrue (score2_vals12 E) := by
  have rew : (!g1374 E) = ((!g1354 E) || ((g402 E) && (!g1352 E))) := by simp [g1,g1373,g1374,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold11_1 E
  have T0 := score2_threshold11_0 E
  exact threshold_step (g402 E) (!g1354 E) (!g1352 E) 1 (countTrue (score2_vals11 E)) T1 T0
theorem score2_threshold12_0 (E : Nat→Bool) : ((!g1372 E)=true) ↔ 1≤countTrue (score2_vals12 E) := by
  have rew : (!g1372 E) = ((!g1352 E) || ((g402 E) && (g1 E))) := by simp [g1,g1372,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold11_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals11 E) := by simp [g1]
  exact threshold_step (g402 E) (!g1352 E) (g1 E) 0 (countTrue (score2_vals11 E)) T1 T0
theorem score2_threshold13_1 (E : Nat→Bool) : ((!g1396 E)=true) ↔ 2≤countTrue (score2_vals13 E) := by
  have rew : (!g1396 E) = ((!g1374 E) || ((g403 E) && (!g1372 E))) := by simp [g1,g1395,g1396,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold12_1 E
  have T0 := score2_threshold12_0 E
  exact threshold_step (g403 E) (!g1374 E) (!g1372 E) 1 (countTrue (score2_vals12 E)) T1 T0
theorem score2_threshold13_0 (E : Nat→Bool) : ((!g1394 E)=true) ↔ 1≤countTrue (score2_vals13 E) := by
  have rew : (!g1394 E) = ((!g1372 E) || ((g403 E) && (g1 E))) := by simp [g1,g1394,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold12_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals12 E) := by simp [g1]
  exact threshold_step (g403 E) (!g1372 E) (g1 E) 0 (countTrue (score2_vals12 E)) T1 T0
theorem score2_threshold14_1 (E : Nat→Bool) : ((!g1420 E)=true) ↔ 2≤countTrue (score2_vals14 E) := by
  have rew : (!g1420 E) = ((!g1396 E) || ((g404 E) && (!g1394 E))) := by simp [g1,g1419,g1420,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold13_1 E
  have T0 := score2_threshold13_0 E
  exact threshold_step (g404 E) (!g1396 E) (!g1394 E) 1 (countTrue (score2_vals13 E)) T1 T0
theorem score2_threshold14_0 (E : Nat→Bool) : ((!g1418 E)=true) ↔ 1≤countTrue (score2_vals14 E) := by
  have rew : (!g1418 E) = ((!g1394 E) || ((g404 E) && (g1 E))) := by simp [g1,g1418,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold13_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals13 E) := by simp [g1]
  exact threshold_step (g404 E) (!g1394 E) (g1 E) 0 (countTrue (score2_vals13 E)) T1 T0
theorem score2_threshold15_1 (E : Nat→Bool) : ((!g1446 E)=true) ↔ 2≤countTrue (score2_vals15 E) := by
  have rew : (!g1446 E) = ((!g1420 E) || ((g405 E) && (!g1418 E))) := by simp [g1,g1445,g1446,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold14_1 E
  have T0 := score2_threshold14_0 E
  exact threshold_step (g405 E) (!g1420 E) (!g1418 E) 1 (countTrue (score2_vals14 E)) T1 T0
theorem score2_threshold15_0 (E : Nat→Bool) : ((!g1444 E)=true) ↔ 1≤countTrue (score2_vals15 E) := by
  have rew : (!g1444 E) = ((!g1418 E) || ((g405 E) && (g1 E))) := by simp [g1,g1444,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold14_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals14 E) := by simp [g1]
  exact threshold_step (g405 E) (!g1418 E) (g1 E) 0 (countTrue (score2_vals14 E)) T1 T0
theorem score2_threshold16_1 (E : Nat→Bool) : ((!g1474 E)=true) ↔ 2≤countTrue (score2_vals16 E) := by
  have rew : (!g1474 E) = ((!g1446 E) || ((g406 E) && (!g1444 E))) := by simp [g1,g1473,g1474,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold15_1 E
  have T0 := score2_threshold15_0 E
  exact threshold_step (g406 E) (!g1446 E) (!g1444 E) 1 (countTrue (score2_vals15 E)) T1 T0
theorem score2_threshold16_0 (E : Nat→Bool) : ((!g1472 E)=true) ↔ 1≤countTrue (score2_vals16 E) := by
  have rew : (!g1472 E) = ((!g1444 E) || ((g406 E) && (g1 E))) := by simp [g1,g1472,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold15_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals15 E) := by simp [g1]
  exact threshold_step (g406 E) (!g1444 E) (g1 E) 0 (countTrue (score2_vals15 E)) T1 T0
theorem score2_threshold17_1 (E : Nat→Bool) : ((!g1504 E)=true) ↔ 2≤countTrue (score2_vals17 E) := by
  have rew : (!g1504 E) = ((!g1474 E) || ((g407 E) && (!g1472 E))) := by simp [g1,g1503,g1504,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold16_1 E
  have T0 := score2_threshold16_0 E
  exact threshold_step (g407 E) (!g1474 E) (!g1472 E) 1 (countTrue (score2_vals16 E)) T1 T0
theorem score2_threshold17_0 (E : Nat→Bool) : ((!g1502 E)=true) ↔ 1≤countTrue (score2_vals17 E) := by
  have rew : (!g1502 E) = ((!g1472 E) || ((g407 E) && (g1 E))) := by simp [g1,g1502,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold16_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals16 E) := by simp [g1]
  exact threshold_step (g407 E) (!g1472 E) (g1 E) 0 (countTrue (score2_vals16 E)) T1 T0
theorem score2_threshold18_1 (E : Nat→Bool) : ((!g1536 E)=true) ↔ 2≤countTrue (score2_vals18 E) := by
  have rew : (!g1536 E) = ((!g1504 E) || ((g408 E) && (!g1502 E))) := by simp [g1,g1535,g1536,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold17_1 E
  have T0 := score2_threshold17_0 E
  exact threshold_step (g408 E) (!g1504 E) (!g1502 E) 1 (countTrue (score2_vals17 E)) T1 T0
theorem score2_threshold18_0 (E : Nat→Bool) : ((!g1534 E)=true) ↔ 1≤countTrue (score2_vals18 E) := by
  have rew : (!g1534 E) = ((!g1502 E) || ((g408 E) && (g1 E))) := by simp [g1,g1534,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold17_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals17 E) := by simp [g1]
  exact threshold_step (g408 E) (!g1502 E) (g1 E) 0 (countTrue (score2_vals17 E)) T1 T0
theorem score2_threshold19_1 (E : Nat→Bool) : ((!g1570 E)=true) ↔ 2≤countTrue (score2_vals19 E) := by
  have rew : (!g1570 E) = ((!g1536 E) || ((g409 E) && (!g1534 E))) := by simp [g1,g1569,g1570,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold18_1 E
  have T0 := score2_threshold18_0 E
  exact threshold_step (g409 E) (!g1536 E) (!g1534 E) 1 (countTrue (score2_vals18 E)) T1 T0
theorem score2_threshold19_0 (E : Nat→Bool) : ((!g1568 E)=true) ↔ 1≤countTrue (score2_vals19 E) := by
  have rew : (!g1568 E) = ((!g1534 E) || ((g409 E) && (g1 E))) := by simp [g1,g1568,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold18_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals18 E) := by simp [g1]
  exact threshold_step (g409 E) (!g1534 E) (g1 E) 0 (countTrue (score2_vals18 E)) T1 T0
theorem score2_threshold20_1 (E : Nat→Bool) : ((!g1606 E)=true) ↔ 2≤countTrue (score2_vals20 E) := by
  have rew : (!g1606 E) = ((!g1570 E) || ((g410 E) && (!g1568 E))) := by simp [g1,g1605,g1606,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold19_1 E
  have T0 := score2_threshold19_0 E
  exact threshold_step (g410 E) (!g1570 E) (!g1568 E) 1 (countTrue (score2_vals19 E)) T1 T0
theorem score2_threshold20_0 (E : Nat→Bool) : ((!g1604 E)=true) ↔ 1≤countTrue (score2_vals20 E) := by
  have rew : (!g1604 E) = ((!g1568 E) || ((g410 E) && (g1 E))) := by simp [g1,g1604,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold19_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals19 E) := by simp [g1]
  exact threshold_step (g410 E) (!g1568 E) (g1 E) 0 (countTrue (score2_vals19 E)) T1 T0
theorem score2_threshold21_1 (E : Nat→Bool) : ((!g1644 E)=true) ↔ 2≤countTrue (score2_vals21 E) := by
  have rew : (!g1644 E) = ((!g1606 E) || ((g411 E) && (!g1604 E))) := by simp [g1,g1643,g1644,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold20_1 E
  have T0 := score2_threshold20_0 E
  exact threshold_step (g411 E) (!g1606 E) (!g1604 E) 1 (countTrue (score2_vals20 E)) T1 T0
theorem score2_threshold3_2 (E : Nat→Bool) : ((g1267 E)=true) ↔ 3≤countTrue (score2_vals3 E) := by
  have rew : (g1267 E) = ((!g1 E) || ((g373 E) && (g1263 E))) := by simp [g1,g1267,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 3≤countTrue (score2_vals2 E) := by
    have hh := count_true_bound (score2_vals2 E)
    change countTrue (score2_vals2 E)≤2 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬3≤countTrue (score2_vals2 E)
    omega
  have T0 := score2_threshold2_1 E
  exact threshold_step (g373 E) (!g1 E) (g1263 E) 2 (countTrue (score2_vals2 E)) T1 T0
theorem score2_threshold4_2 (E : Nat→Bool) : ((!g1272 E)=true) ↔ 3≤countTrue (score2_vals4 E) := by
  have rew : (!g1272 E) = ((g1267 E) || ((g374 E) && (!g1266 E))) := by simp [g1,g1271,g1272,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold3_2 E
  have T0 := score2_threshold3_1 E
  exact threshold_step (g374 E) (g1267 E) (!g1266 E) 2 (countTrue (score2_vals3 E)) T1 T0
theorem score2_threshold5_2 (E : Nat→Bool) : ((!g1278 E)=true) ↔ 3≤countTrue (score2_vals5 E) := by
  have rew : (!g1278 E) = ((!g1272 E) || ((g375 E) && (!g1270 E))) := by simp [g1,g1277,g1278,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold4_2 E
  have T0 := score2_threshold4_1 E
  exact threshold_step (g375 E) (!g1272 E) (!g1270 E) 2 (countTrue (score2_vals4 E)) T1 T0
theorem score2_threshold6_2 (E : Nat→Bool) : ((!g1286 E)=true) ↔ 3≤countTrue (score2_vals6 E) := by
  have rew : (!g1286 E) = ((!g1278 E) || ((g376 E) && (!g1276 E))) := by simp [g1,g1285,g1286,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold5_2 E
  have T0 := score2_threshold5_1 E
  exact threshold_step (g376 E) (!g1278 E) (!g1276 E) 2 (countTrue (score2_vals5 E)) T1 T0
theorem score2_threshold7_2 (E : Nat→Bool) : ((!g1296 E)=true) ↔ 3≤countTrue (score2_vals7 E) := by
  have rew : (!g1296 E) = ((!g1286 E) || ((g387 E) && (!g1284 E))) := by simp [g1,g1295,g1296,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold6_2 E
  have T0 := score2_threshold6_1 E
  exact threshold_step (g387 E) (!g1286 E) (!g1284 E) 2 (countTrue (score2_vals6 E)) T1 T0
theorem score2_threshold8_2 (E : Nat→Bool) : ((!g1308 E)=true) ↔ 3≤countTrue (score2_vals8 E) := by
  have rew : (!g1308 E) = ((!g1296 E) || ((g388 E) && (!g1294 E))) := by simp [g1,g1307,g1308,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold7_2 E
  have T0 := score2_threshold7_1 E
  exact threshold_step (g388 E) (!g1296 E) (!g1294 E) 2 (countTrue (score2_vals7 E)) T1 T0
theorem score2_threshold9_2 (E : Nat→Bool) : ((!g1322 E)=true) ↔ 3≤countTrue (score2_vals9 E) := by
  have rew : (!g1322 E) = ((!g1308 E) || ((g389 E) && (!g1306 E))) := by simp [g1,g1321,g1322,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold8_2 E
  have T0 := score2_threshold8_1 E
  exact threshold_step (g389 E) (!g1308 E) (!g1306 E) 2 (countTrue (score2_vals8 E)) T1 T0
theorem score2_threshold10_2 (E : Nat→Bool) : ((!g1338 E)=true) ↔ 3≤countTrue (score2_vals10 E) := by
  have rew : (!g1338 E) = ((!g1322 E) || ((g390 E) && (!g1320 E))) := by simp [g1,g1337,g1338,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold9_2 E
  have T0 := score2_threshold9_1 E
  exact threshold_step (g390 E) (!g1322 E) (!g1320 E) 2 (countTrue (score2_vals9 E)) T1 T0
theorem score2_threshold11_2 (E : Nat→Bool) : ((!g1356 E)=true) ↔ 3≤countTrue (score2_vals11 E) := by
  have rew : (!g1356 E) = ((!g1338 E) || ((g391 E) && (!g1336 E))) := by simp [g1,g1355,g1356,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold10_2 E
  have T0 := score2_threshold10_1 E
  exact threshold_step (g391 E) (!g1338 E) (!g1336 E) 2 (countTrue (score2_vals10 E)) T1 T0
theorem score2_threshold12_2 (E : Nat→Bool) : ((!g1376 E)=true) ↔ 3≤countTrue (score2_vals12 E) := by
  have rew : (!g1376 E) = ((!g1356 E) || ((g402 E) && (!g1354 E))) := by simp [g1,g1375,g1376,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold11_2 E
  have T0 := score2_threshold11_1 E
  exact threshold_step (g402 E) (!g1356 E) (!g1354 E) 2 (countTrue (score2_vals11 E)) T1 T0
theorem score2_threshold13_2 (E : Nat→Bool) : ((!g1398 E)=true) ↔ 3≤countTrue (score2_vals13 E) := by
  have rew : (!g1398 E) = ((!g1376 E) || ((g403 E) && (!g1374 E))) := by simp [g1,g1397,g1398,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold12_2 E
  have T0 := score2_threshold12_1 E
  exact threshold_step (g403 E) (!g1376 E) (!g1374 E) 2 (countTrue (score2_vals12 E)) T1 T0
theorem score2_threshold14_2 (E : Nat→Bool) : ((!g1422 E)=true) ↔ 3≤countTrue (score2_vals14 E) := by
  have rew : (!g1422 E) = ((!g1398 E) || ((g404 E) && (!g1396 E))) := by simp [g1,g1421,g1422,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold13_2 E
  have T0 := score2_threshold13_1 E
  exact threshold_step (g404 E) (!g1398 E) (!g1396 E) 2 (countTrue (score2_vals13 E)) T1 T0
theorem score2_threshold15_2 (E : Nat→Bool) : ((!g1448 E)=true) ↔ 3≤countTrue (score2_vals15 E) := by
  have rew : (!g1448 E) = ((!g1422 E) || ((g405 E) && (!g1420 E))) := by simp [g1,g1447,g1448,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold14_2 E
  have T0 := score2_threshold14_1 E
  exact threshold_step (g405 E) (!g1422 E) (!g1420 E) 2 (countTrue (score2_vals14 E)) T1 T0
theorem score2_threshold16_2 (E : Nat→Bool) : ((!g1476 E)=true) ↔ 3≤countTrue (score2_vals16 E) := by
  have rew : (!g1476 E) = ((!g1448 E) || ((g406 E) && (!g1446 E))) := by simp [g1,g1475,g1476,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold15_2 E
  have T0 := score2_threshold15_1 E
  exact threshold_step (g406 E) (!g1448 E) (!g1446 E) 2 (countTrue (score2_vals15 E)) T1 T0
theorem score2_threshold17_2 (E : Nat→Bool) : ((!g1506 E)=true) ↔ 3≤countTrue (score2_vals17 E) := by
  have rew : (!g1506 E) = ((!g1476 E) || ((g407 E) && (!g1474 E))) := by simp [g1,g1505,g1506,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold16_2 E
  have T0 := score2_threshold16_1 E
  exact threshold_step (g407 E) (!g1476 E) (!g1474 E) 2 (countTrue (score2_vals16 E)) T1 T0
theorem score2_threshold18_2 (E : Nat→Bool) : ((!g1538 E)=true) ↔ 3≤countTrue (score2_vals18 E) := by
  have rew : (!g1538 E) = ((!g1506 E) || ((g408 E) && (!g1504 E))) := by simp [g1,g1537,g1538,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold17_2 E
  have T0 := score2_threshold17_1 E
  exact threshold_step (g408 E) (!g1506 E) (!g1504 E) 2 (countTrue (score2_vals17 E)) T1 T0
theorem score2_threshold19_2 (E : Nat→Bool) : ((!g1572 E)=true) ↔ 3≤countTrue (score2_vals19 E) := by
  have rew : (!g1572 E) = ((!g1538 E) || ((g409 E) && (!g1536 E))) := by simp [g1,g1571,g1572,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold18_2 E
  have T0 := score2_threshold18_1 E
  exact threshold_step (g409 E) (!g1538 E) (!g1536 E) 2 (countTrue (score2_vals18 E)) T1 T0
theorem score2_threshold20_2 (E : Nat→Bool) : ((!g1608 E)=true) ↔ 3≤countTrue (score2_vals20 E) := by
  have rew : (!g1608 E) = ((!g1572 E) || ((g410 E) && (!g1570 E))) := by simp [g1,g1607,g1608,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold19_2 E
  have T0 := score2_threshold19_1 E
  exact threshold_step (g410 E) (!g1572 E) (!g1570 E) 2 (countTrue (score2_vals19 E)) T1 T0
theorem score2_threshold21_2 (E : Nat→Bool) : ((!g1646 E)=true) ↔ 3≤countTrue (score2_vals21 E) := by
  have rew : (!g1646 E) = ((!g1608 E) || ((g411 E) && (!g1606 E))) := by simp [g1,g1645,g1646,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold20_2 E
  have T0 := score2_threshold20_1 E
  exact threshold_step (g411 E) (!g1608 E) (!g1606 E) 2 (countTrue (score2_vals20 E)) T1 T0
theorem score2_threshold4_3 (E : Nat→Bool) : ((g1273 E)=true) ↔ 4≤countTrue (score2_vals4 E) := by
  have rew : (g1273 E) = ((!g1 E) || ((g374 E) && (g1267 E))) := by simp [g1,g1273,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 4≤countTrue (score2_vals3 E) := by
    have hh := count_true_bound (score2_vals3 E)
    change countTrue (score2_vals3 E)≤3 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬4≤countTrue (score2_vals3 E)
    omega
  have T0 := score2_threshold3_2 E
  exact threshold_step (g374 E) (!g1 E) (g1267 E) 3 (countTrue (score2_vals3 E)) T1 T0
theorem score2_threshold5_3 (E : Nat→Bool) : ((!g1280 E)=true) ↔ 4≤countTrue (score2_vals5 E) := by
  have rew : (!g1280 E) = ((g1273 E) || ((g375 E) && (!g1272 E))) := by simp [g1,g1279,g1280,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold4_3 E
  have T0 := score2_threshold4_2 E
  exact threshold_step (g375 E) (g1273 E) (!g1272 E) 3 (countTrue (score2_vals4 E)) T1 T0
theorem score2_threshold6_3 (E : Nat→Bool) : ((!g1288 E)=true) ↔ 4≤countTrue (score2_vals6 E) := by
  have rew : (!g1288 E) = ((!g1280 E) || ((g376 E) && (!g1278 E))) := by simp [g1,g1287,g1288,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold5_3 E
  have T0 := score2_threshold5_2 E
  exact threshold_step (g376 E) (!g1280 E) (!g1278 E) 3 (countTrue (score2_vals5 E)) T1 T0
theorem score2_threshold7_3 (E : Nat→Bool) : ((!g1298 E)=true) ↔ 4≤countTrue (score2_vals7 E) := by
  have rew : (!g1298 E) = ((!g1288 E) || ((g387 E) && (!g1286 E))) := by simp [g1,g1297,g1298,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold6_3 E
  have T0 := score2_threshold6_2 E
  exact threshold_step (g387 E) (!g1288 E) (!g1286 E) 3 (countTrue (score2_vals6 E)) T1 T0
theorem score2_threshold8_3 (E : Nat→Bool) : ((!g1310 E)=true) ↔ 4≤countTrue (score2_vals8 E) := by
  have rew : (!g1310 E) = ((!g1298 E) || ((g388 E) && (!g1296 E))) := by simp [g1,g1309,g1310,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold7_3 E
  have T0 := score2_threshold7_2 E
  exact threshold_step (g388 E) (!g1298 E) (!g1296 E) 3 (countTrue (score2_vals7 E)) T1 T0
theorem score2_threshold9_3 (E : Nat→Bool) : ((!g1324 E)=true) ↔ 4≤countTrue (score2_vals9 E) := by
  have rew : (!g1324 E) = ((!g1310 E) || ((g389 E) && (!g1308 E))) := by simp [g1,g1323,g1324,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold8_3 E
  have T0 := score2_threshold8_2 E
  exact threshold_step (g389 E) (!g1310 E) (!g1308 E) 3 (countTrue (score2_vals8 E)) T1 T0
theorem score2_threshold10_3 (E : Nat→Bool) : ((!g1340 E)=true) ↔ 4≤countTrue (score2_vals10 E) := by
  have rew : (!g1340 E) = ((!g1324 E) || ((g390 E) && (!g1322 E))) := by simp [g1,g1339,g1340,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold9_3 E
  have T0 := score2_threshold9_2 E
  exact threshold_step (g390 E) (!g1324 E) (!g1322 E) 3 (countTrue (score2_vals9 E)) T1 T0
theorem score2_threshold11_3 (E : Nat→Bool) : ((!g1358 E)=true) ↔ 4≤countTrue (score2_vals11 E) := by
  have rew : (!g1358 E) = ((!g1340 E) || ((g391 E) && (!g1338 E))) := by simp [g1,g1357,g1358,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold10_3 E
  have T0 := score2_threshold10_2 E
  exact threshold_step (g391 E) (!g1340 E) (!g1338 E) 3 (countTrue (score2_vals10 E)) T1 T0
theorem score2_threshold12_3 (E : Nat→Bool) : ((!g1378 E)=true) ↔ 4≤countTrue (score2_vals12 E) := by
  have rew : (!g1378 E) = ((!g1358 E) || ((g402 E) && (!g1356 E))) := by simp [g1,g1377,g1378,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold11_3 E
  have T0 := score2_threshold11_2 E
  exact threshold_step (g402 E) (!g1358 E) (!g1356 E) 3 (countTrue (score2_vals11 E)) T1 T0
theorem score2_threshold13_3 (E : Nat→Bool) : ((!g1400 E)=true) ↔ 4≤countTrue (score2_vals13 E) := by
  have rew : (!g1400 E) = ((!g1378 E) || ((g403 E) && (!g1376 E))) := by simp [g1,g1399,g1400,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold12_3 E
  have T0 := score2_threshold12_2 E
  exact threshold_step (g403 E) (!g1378 E) (!g1376 E) 3 (countTrue (score2_vals12 E)) T1 T0
theorem score2_threshold14_3 (E : Nat→Bool) : ((!g1424 E)=true) ↔ 4≤countTrue (score2_vals14 E) := by
  have rew : (!g1424 E) = ((!g1400 E) || ((g404 E) && (!g1398 E))) := by simp [g1,g1423,g1424,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold13_3 E
  have T0 := score2_threshold13_2 E
  exact threshold_step (g404 E) (!g1400 E) (!g1398 E) 3 (countTrue (score2_vals13 E)) T1 T0
theorem score2_threshold15_3 (E : Nat→Bool) : ((!g1450 E)=true) ↔ 4≤countTrue (score2_vals15 E) := by
  have rew : (!g1450 E) = ((!g1424 E) || ((g405 E) && (!g1422 E))) := by simp [g1,g1449,g1450,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold14_3 E
  have T0 := score2_threshold14_2 E
  exact threshold_step (g405 E) (!g1424 E) (!g1422 E) 3 (countTrue (score2_vals14 E)) T1 T0
theorem score2_threshold16_3 (E : Nat→Bool) : ((!g1478 E)=true) ↔ 4≤countTrue (score2_vals16 E) := by
  have rew : (!g1478 E) = ((!g1450 E) || ((g406 E) && (!g1448 E))) := by simp [g1,g1477,g1478,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold15_3 E
  have T0 := score2_threshold15_2 E
  exact threshold_step (g406 E) (!g1450 E) (!g1448 E) 3 (countTrue (score2_vals15 E)) T1 T0
theorem score2_threshold17_3 (E : Nat→Bool) : ((!g1508 E)=true) ↔ 4≤countTrue (score2_vals17 E) := by
  have rew : (!g1508 E) = ((!g1478 E) || ((g407 E) && (!g1476 E))) := by simp [g1,g1507,g1508,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold16_3 E
  have T0 := score2_threshold16_2 E
  exact threshold_step (g407 E) (!g1478 E) (!g1476 E) 3 (countTrue (score2_vals16 E)) T1 T0
theorem score2_threshold18_3 (E : Nat→Bool) : ((!g1540 E)=true) ↔ 4≤countTrue (score2_vals18 E) := by
  have rew : (!g1540 E) = ((!g1508 E) || ((g408 E) && (!g1506 E))) := by simp [g1,g1539,g1540,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold17_3 E
  have T0 := score2_threshold17_2 E
  exact threshold_step (g408 E) (!g1508 E) (!g1506 E) 3 (countTrue (score2_vals17 E)) T1 T0
theorem score2_threshold19_3 (E : Nat→Bool) : ((!g1574 E)=true) ↔ 4≤countTrue (score2_vals19 E) := by
  have rew : (!g1574 E) = ((!g1540 E) || ((g409 E) && (!g1538 E))) := by simp [g1,g1573,g1574,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold18_3 E
  have T0 := score2_threshold18_2 E
  exact threshold_step (g409 E) (!g1540 E) (!g1538 E) 3 (countTrue (score2_vals18 E)) T1 T0
theorem score2_threshold20_3 (E : Nat→Bool) : ((!g1610 E)=true) ↔ 4≤countTrue (score2_vals20 E) := by
  have rew : (!g1610 E) = ((!g1574 E) || ((g410 E) && (!g1572 E))) := by simp [g1,g1609,g1610,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold19_3 E
  have T0 := score2_threshold19_2 E
  exact threshold_step (g410 E) (!g1574 E) (!g1572 E) 3 (countTrue (score2_vals19 E)) T1 T0
theorem score2_threshold21_3 (E : Nat→Bool) : ((!g1648 E)=true) ↔ 4≤countTrue (score2_vals21 E) := by
  have rew : (!g1648 E) = ((!g1610 E) || ((g411 E) && (!g1608 E))) := by simp [g1,g1647,g1648,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold20_3 E
  have T0 := score2_threshold20_2 E
  exact threshold_step (g411 E) (!g1610 E) (!g1608 E) 3 (countTrue (score2_vals20 E)) T1 T0
theorem score2_threshold5_4 (E : Nat→Bool) : ((g1281 E)=true) ↔ 5≤countTrue (score2_vals5 E) := by
  have rew : (g1281 E) = ((!g1 E) || ((g375 E) && (g1273 E))) := by simp [g1,g1281,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 5≤countTrue (score2_vals4 E) := by
    have hh := count_true_bound (score2_vals4 E)
    change countTrue (score2_vals4 E)≤4 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬5≤countTrue (score2_vals4 E)
    omega
  have T0 := score2_threshold4_3 E
  exact threshold_step (g375 E) (!g1 E) (g1273 E) 4 (countTrue (score2_vals4 E)) T1 T0
theorem score2_threshold6_4 (E : Nat→Bool) : ((!g1290 E)=true) ↔ 5≤countTrue (score2_vals6 E) := by
  have rew : (!g1290 E) = ((g1281 E) || ((g376 E) && (!g1280 E))) := by simp [g1,g1289,g1290,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold5_4 E
  have T0 := score2_threshold5_3 E
  exact threshold_step (g376 E) (g1281 E) (!g1280 E) 4 (countTrue (score2_vals5 E)) T1 T0
theorem score2_threshold7_4 (E : Nat→Bool) : ((!g1300 E)=true) ↔ 5≤countTrue (score2_vals7 E) := by
  have rew : (!g1300 E) = ((!g1290 E) || ((g387 E) && (!g1288 E))) := by simp [g1,g1299,g1300,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold6_4 E
  have T0 := score2_threshold6_3 E
  exact threshold_step (g387 E) (!g1290 E) (!g1288 E) 4 (countTrue (score2_vals6 E)) T1 T0
theorem score2_threshold8_4 (E : Nat→Bool) : ((!g1312 E)=true) ↔ 5≤countTrue (score2_vals8 E) := by
  have rew : (!g1312 E) = ((!g1300 E) || ((g388 E) && (!g1298 E))) := by simp [g1,g1311,g1312,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold7_4 E
  have T0 := score2_threshold7_3 E
  exact threshold_step (g388 E) (!g1300 E) (!g1298 E) 4 (countTrue (score2_vals7 E)) T1 T0
theorem score2_threshold9_4 (E : Nat→Bool) : ((!g1326 E)=true) ↔ 5≤countTrue (score2_vals9 E) := by
  have rew : (!g1326 E) = ((!g1312 E) || ((g389 E) && (!g1310 E))) := by simp [g1,g1325,g1326,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold8_4 E
  have T0 := score2_threshold8_3 E
  exact threshold_step (g389 E) (!g1312 E) (!g1310 E) 4 (countTrue (score2_vals8 E)) T1 T0
theorem score2_threshold10_4 (E : Nat→Bool) : ((!g1342 E)=true) ↔ 5≤countTrue (score2_vals10 E) := by
  have rew : (!g1342 E) = ((!g1326 E) || ((g390 E) && (!g1324 E))) := by simp [g1,g1341,g1342,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold9_4 E
  have T0 := score2_threshold9_3 E
  exact threshold_step (g390 E) (!g1326 E) (!g1324 E) 4 (countTrue (score2_vals9 E)) T1 T0
theorem score2_threshold11_4 (E : Nat→Bool) : ((!g1360 E)=true) ↔ 5≤countTrue (score2_vals11 E) := by
  have rew : (!g1360 E) = ((!g1342 E) || ((g391 E) && (!g1340 E))) := by simp [g1,g1359,g1360,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold10_4 E
  have T0 := score2_threshold10_3 E
  exact threshold_step (g391 E) (!g1342 E) (!g1340 E) 4 (countTrue (score2_vals10 E)) T1 T0
theorem score2_threshold12_4 (E : Nat→Bool) : ((!g1380 E)=true) ↔ 5≤countTrue (score2_vals12 E) := by
  have rew : (!g1380 E) = ((!g1360 E) || ((g402 E) && (!g1358 E))) := by simp [g1,g1379,g1380,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold11_4 E
  have T0 := score2_threshold11_3 E
  exact threshold_step (g402 E) (!g1360 E) (!g1358 E) 4 (countTrue (score2_vals11 E)) T1 T0
theorem score2_threshold13_4 (E : Nat→Bool) : ((!g1402 E)=true) ↔ 5≤countTrue (score2_vals13 E) := by
  have rew : (!g1402 E) = ((!g1380 E) || ((g403 E) && (!g1378 E))) := by simp [g1,g1401,g1402,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold12_4 E
  have T0 := score2_threshold12_3 E
  exact threshold_step (g403 E) (!g1380 E) (!g1378 E) 4 (countTrue (score2_vals12 E)) T1 T0
theorem score2_threshold14_4 (E : Nat→Bool) : ((!g1426 E)=true) ↔ 5≤countTrue (score2_vals14 E) := by
  have rew : (!g1426 E) = ((!g1402 E) || ((g404 E) && (!g1400 E))) := by simp [g1,g1425,g1426,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold13_4 E
  have T0 := score2_threshold13_3 E
  exact threshold_step (g404 E) (!g1402 E) (!g1400 E) 4 (countTrue (score2_vals13 E)) T1 T0
theorem score2_threshold15_4 (E : Nat→Bool) : ((!g1452 E)=true) ↔ 5≤countTrue (score2_vals15 E) := by
  have rew : (!g1452 E) = ((!g1426 E) || ((g405 E) && (!g1424 E))) := by simp [g1,g1451,g1452,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold14_4 E
  have T0 := score2_threshold14_3 E
  exact threshold_step (g405 E) (!g1426 E) (!g1424 E) 4 (countTrue (score2_vals14 E)) T1 T0
theorem score2_threshold16_4 (E : Nat→Bool) : ((!g1480 E)=true) ↔ 5≤countTrue (score2_vals16 E) := by
  have rew : (!g1480 E) = ((!g1452 E) || ((g406 E) && (!g1450 E))) := by simp [g1,g1479,g1480,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold15_4 E
  have T0 := score2_threshold15_3 E
  exact threshold_step (g406 E) (!g1452 E) (!g1450 E) 4 (countTrue (score2_vals15 E)) T1 T0
theorem score2_threshold17_4 (E : Nat→Bool) : ((!g1510 E)=true) ↔ 5≤countTrue (score2_vals17 E) := by
  have rew : (!g1510 E) = ((!g1480 E) || ((g407 E) && (!g1478 E))) := by simp [g1,g1509,g1510,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold16_4 E
  have T0 := score2_threshold16_3 E
  exact threshold_step (g407 E) (!g1480 E) (!g1478 E) 4 (countTrue (score2_vals16 E)) T1 T0
theorem score2_threshold18_4 (E : Nat→Bool) : ((!g1542 E)=true) ↔ 5≤countTrue (score2_vals18 E) := by
  have rew : (!g1542 E) = ((!g1510 E) || ((g408 E) && (!g1508 E))) := by simp [g1,g1541,g1542,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold17_4 E
  have T0 := score2_threshold17_3 E
  exact threshold_step (g408 E) (!g1510 E) (!g1508 E) 4 (countTrue (score2_vals17 E)) T1 T0
theorem score2_threshold19_4 (E : Nat→Bool) : ((!g1576 E)=true) ↔ 5≤countTrue (score2_vals19 E) := by
  have rew : (!g1576 E) = ((!g1542 E) || ((g409 E) && (!g1540 E))) := by simp [g1,g1575,g1576,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold18_4 E
  have T0 := score2_threshold18_3 E
  exact threshold_step (g409 E) (!g1542 E) (!g1540 E) 4 (countTrue (score2_vals18 E)) T1 T0
theorem score2_threshold20_4 (E : Nat→Bool) : ((!g1612 E)=true) ↔ 5≤countTrue (score2_vals20 E) := by
  have rew : (!g1612 E) = ((!g1576 E) || ((g410 E) && (!g1574 E))) := by simp [g1,g1611,g1612,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold19_4 E
  have T0 := score2_threshold19_3 E
  exact threshold_step (g410 E) (!g1576 E) (!g1574 E) 4 (countTrue (score2_vals19 E)) T1 T0
theorem score2_threshold21_4 (E : Nat→Bool) : ((!g1650 E)=true) ↔ 5≤countTrue (score2_vals21 E) := by
  have rew : (!g1650 E) = ((!g1612 E) || ((g411 E) && (!g1610 E))) := by simp [g1,g1649,g1650,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold20_4 E
  have T0 := score2_threshold20_3 E
  exact threshold_step (g411 E) (!g1612 E) (!g1610 E) 4 (countTrue (score2_vals20 E)) T1 T0
theorem score2_threshold6_5 (E : Nat→Bool) : ((g1291 E)=true) ↔ 6≤countTrue (score2_vals6 E) := by
  have rew : (g1291 E) = ((!g1 E) || ((g376 E) && (g1281 E))) := by simp [g1,g1291,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 6≤countTrue (score2_vals5 E) := by
    have hh := count_true_bound (score2_vals5 E)
    change countTrue (score2_vals5 E)≤5 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬6≤countTrue (score2_vals5 E)
    omega
  have T0 := score2_threshold5_4 E
  exact threshold_step (g376 E) (!g1 E) (g1281 E) 5 (countTrue (score2_vals5 E)) T1 T0
theorem score2_threshold7_5 (E : Nat→Bool) : ((!g1302 E)=true) ↔ 6≤countTrue (score2_vals7 E) := by
  have rew : (!g1302 E) = ((g1291 E) || ((g387 E) && (!g1290 E))) := by simp [g1,g1301,g1302,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold6_5 E
  have T0 := score2_threshold6_4 E
  exact threshold_step (g387 E) (g1291 E) (!g1290 E) 5 (countTrue (score2_vals6 E)) T1 T0
theorem score2_threshold8_5 (E : Nat→Bool) : ((!g1314 E)=true) ↔ 6≤countTrue (score2_vals8 E) := by
  have rew : (!g1314 E) = ((!g1302 E) || ((g388 E) && (!g1300 E))) := by simp [g1,g1313,g1314,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold7_5 E
  have T0 := score2_threshold7_4 E
  exact threshold_step (g388 E) (!g1302 E) (!g1300 E) 5 (countTrue (score2_vals7 E)) T1 T0
theorem score2_threshold9_5 (E : Nat→Bool) : ((!g1328 E)=true) ↔ 6≤countTrue (score2_vals9 E) := by
  have rew : (!g1328 E) = ((!g1314 E) || ((g389 E) && (!g1312 E))) := by simp [g1,g1327,g1328,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold8_5 E
  have T0 := score2_threshold8_4 E
  exact threshold_step (g389 E) (!g1314 E) (!g1312 E) 5 (countTrue (score2_vals8 E)) T1 T0
theorem score2_threshold10_5 (E : Nat→Bool) : ((!g1344 E)=true) ↔ 6≤countTrue (score2_vals10 E) := by
  have rew : (!g1344 E) = ((!g1328 E) || ((g390 E) && (!g1326 E))) := by simp [g1,g1343,g1344,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold9_5 E
  have T0 := score2_threshold9_4 E
  exact threshold_step (g390 E) (!g1328 E) (!g1326 E) 5 (countTrue (score2_vals9 E)) T1 T0
theorem score2_threshold11_5 (E : Nat→Bool) : ((!g1362 E)=true) ↔ 6≤countTrue (score2_vals11 E) := by
  have rew : (!g1362 E) = ((!g1344 E) || ((g391 E) && (!g1342 E))) := by simp [g1,g1361,g1362,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold10_5 E
  have T0 := score2_threshold10_4 E
  exact threshold_step (g391 E) (!g1344 E) (!g1342 E) 5 (countTrue (score2_vals10 E)) T1 T0
theorem score2_threshold12_5 (E : Nat→Bool) : ((!g1382 E)=true) ↔ 6≤countTrue (score2_vals12 E) := by
  have rew : (!g1382 E) = ((!g1362 E) || ((g402 E) && (!g1360 E))) := by simp [g1,g1381,g1382,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold11_5 E
  have T0 := score2_threshold11_4 E
  exact threshold_step (g402 E) (!g1362 E) (!g1360 E) 5 (countTrue (score2_vals11 E)) T1 T0
theorem score2_threshold13_5 (E : Nat→Bool) : ((!g1404 E)=true) ↔ 6≤countTrue (score2_vals13 E) := by
  have rew : (!g1404 E) = ((!g1382 E) || ((g403 E) && (!g1380 E))) := by simp [g1,g1403,g1404,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold12_5 E
  have T0 := score2_threshold12_4 E
  exact threshold_step (g403 E) (!g1382 E) (!g1380 E) 5 (countTrue (score2_vals12 E)) T1 T0
theorem score2_threshold14_5 (E : Nat→Bool) : ((!g1428 E)=true) ↔ 6≤countTrue (score2_vals14 E) := by
  have rew : (!g1428 E) = ((!g1404 E) || ((g404 E) && (!g1402 E))) := by simp [g1,g1427,g1428,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold13_5 E
  have T0 := score2_threshold13_4 E
  exact threshold_step (g404 E) (!g1404 E) (!g1402 E) 5 (countTrue (score2_vals13 E)) T1 T0
theorem score2_threshold15_5 (E : Nat→Bool) : ((!g1454 E)=true) ↔ 6≤countTrue (score2_vals15 E) := by
  have rew : (!g1454 E) = ((!g1428 E) || ((g405 E) && (!g1426 E))) := by simp [g1,g1453,g1454,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold14_5 E
  have T0 := score2_threshold14_4 E
  exact threshold_step (g405 E) (!g1428 E) (!g1426 E) 5 (countTrue (score2_vals14 E)) T1 T0
theorem score2_threshold16_5 (E : Nat→Bool) : ((!g1482 E)=true) ↔ 6≤countTrue (score2_vals16 E) := by
  have rew : (!g1482 E) = ((!g1454 E) || ((g406 E) && (!g1452 E))) := by simp [g1,g1481,g1482,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold15_5 E
  have T0 := score2_threshold15_4 E
  exact threshold_step (g406 E) (!g1454 E) (!g1452 E) 5 (countTrue (score2_vals15 E)) T1 T0
theorem score2_threshold17_5 (E : Nat→Bool) : ((!g1512 E)=true) ↔ 6≤countTrue (score2_vals17 E) := by
  have rew : (!g1512 E) = ((!g1482 E) || ((g407 E) && (!g1480 E))) := by simp [g1,g1511,g1512,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold16_5 E
  have T0 := score2_threshold16_4 E
  exact threshold_step (g407 E) (!g1482 E) (!g1480 E) 5 (countTrue (score2_vals16 E)) T1 T0
theorem score2_threshold18_5 (E : Nat→Bool) : ((!g1544 E)=true) ↔ 6≤countTrue (score2_vals18 E) := by
  have rew : (!g1544 E) = ((!g1512 E) || ((g408 E) && (!g1510 E))) := by simp [g1,g1543,g1544,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold17_5 E
  have T0 := score2_threshold17_4 E
  exact threshold_step (g408 E) (!g1512 E) (!g1510 E) 5 (countTrue (score2_vals17 E)) T1 T0
theorem score2_threshold19_5 (E : Nat→Bool) : ((!g1578 E)=true) ↔ 6≤countTrue (score2_vals19 E) := by
  have rew : (!g1578 E) = ((!g1544 E) || ((g409 E) && (!g1542 E))) := by simp [g1,g1577,g1578,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold18_5 E
  have T0 := score2_threshold18_4 E
  exact threshold_step (g409 E) (!g1544 E) (!g1542 E) 5 (countTrue (score2_vals18 E)) T1 T0
theorem score2_threshold20_5 (E : Nat→Bool) : ((!g1614 E)=true) ↔ 6≤countTrue (score2_vals20 E) := by
  have rew : (!g1614 E) = ((!g1578 E) || ((g410 E) && (!g1576 E))) := by simp [g1,g1613,g1614,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold19_5 E
  have T0 := score2_threshold19_4 E
  exact threshold_step (g410 E) (!g1578 E) (!g1576 E) 5 (countTrue (score2_vals19 E)) T1 T0
theorem score2_threshold21_5 (E : Nat→Bool) : ((!g1652 E)=true) ↔ 6≤countTrue (score2_vals21 E) := by
  have rew : (!g1652 E) = ((!g1614 E) || ((g411 E) && (!g1612 E))) := by simp [g1,g1651,g1652,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold20_5 E
  have T0 := score2_threshold20_4 E
  exact threshold_step (g411 E) (!g1614 E) (!g1612 E) 5 (countTrue (score2_vals20 E)) T1 T0
theorem score2_threshold7_6 (E : Nat→Bool) : ((g1303 E)=true) ↔ 7≤countTrue (score2_vals7 E) := by
  have rew : (g1303 E) = ((!g1 E) || ((g387 E) && (g1291 E))) := by simp [g1,g1303,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 7≤countTrue (score2_vals6 E) := by
    have hh := count_true_bound (score2_vals6 E)
    change countTrue (score2_vals6 E)≤6 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬7≤countTrue (score2_vals6 E)
    omega
  have T0 := score2_threshold6_5 E
  exact threshold_step (g387 E) (!g1 E) (g1291 E) 6 (countTrue (score2_vals6 E)) T1 T0
theorem score2_threshold8_6 (E : Nat→Bool) : ((!g1316 E)=true) ↔ 7≤countTrue (score2_vals8 E) := by
  have rew : (!g1316 E) = ((g1303 E) || ((g388 E) && (!g1302 E))) := by simp [g1,g1315,g1316,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold7_6 E
  have T0 := score2_threshold7_5 E
  exact threshold_step (g388 E) (g1303 E) (!g1302 E) 6 (countTrue (score2_vals7 E)) T1 T0
theorem score2_threshold9_6 (E : Nat→Bool) : ((!g1330 E)=true) ↔ 7≤countTrue (score2_vals9 E) := by
  have rew : (!g1330 E) = ((!g1316 E) || ((g389 E) && (!g1314 E))) := by simp [g1,g1329,g1330,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold8_6 E
  have T0 := score2_threshold8_5 E
  exact threshold_step (g389 E) (!g1316 E) (!g1314 E) 6 (countTrue (score2_vals8 E)) T1 T0
theorem score2_threshold10_6 (E : Nat→Bool) : ((!g1346 E)=true) ↔ 7≤countTrue (score2_vals10 E) := by
  have rew : (!g1346 E) = ((!g1330 E) || ((g390 E) && (!g1328 E))) := by simp [g1,g1345,g1346,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold9_6 E
  have T0 := score2_threshold9_5 E
  exact threshold_step (g390 E) (!g1330 E) (!g1328 E) 6 (countTrue (score2_vals9 E)) T1 T0
theorem score2_threshold11_6 (E : Nat→Bool) : ((!g1364 E)=true) ↔ 7≤countTrue (score2_vals11 E) := by
  have rew : (!g1364 E) = ((!g1346 E) || ((g391 E) && (!g1344 E))) := by simp [g1,g1363,g1364,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold10_6 E
  have T0 := score2_threshold10_5 E
  exact threshold_step (g391 E) (!g1346 E) (!g1344 E) 6 (countTrue (score2_vals10 E)) T1 T0
theorem score2_threshold12_6 (E : Nat→Bool) : ((!g1384 E)=true) ↔ 7≤countTrue (score2_vals12 E) := by
  have rew : (!g1384 E) = ((!g1364 E) || ((g402 E) && (!g1362 E))) := by simp [g1,g1383,g1384,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold11_6 E
  have T0 := score2_threshold11_5 E
  exact threshold_step (g402 E) (!g1364 E) (!g1362 E) 6 (countTrue (score2_vals11 E)) T1 T0
theorem score2_threshold13_6 (E : Nat→Bool) : ((!g1406 E)=true) ↔ 7≤countTrue (score2_vals13 E) := by
  have rew : (!g1406 E) = ((!g1384 E) || ((g403 E) && (!g1382 E))) := by simp [g1,g1405,g1406,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold12_6 E
  have T0 := score2_threshold12_5 E
  exact threshold_step (g403 E) (!g1384 E) (!g1382 E) 6 (countTrue (score2_vals12 E)) T1 T0
theorem score2_threshold14_6 (E : Nat→Bool) : ((!g1430 E)=true) ↔ 7≤countTrue (score2_vals14 E) := by
  have rew : (!g1430 E) = ((!g1406 E) || ((g404 E) && (!g1404 E))) := by simp [g1,g1429,g1430,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold13_6 E
  have T0 := score2_threshold13_5 E
  exact threshold_step (g404 E) (!g1406 E) (!g1404 E) 6 (countTrue (score2_vals13 E)) T1 T0
theorem score2_threshold15_6 (E : Nat→Bool) : ((!g1456 E)=true) ↔ 7≤countTrue (score2_vals15 E) := by
  have rew : (!g1456 E) = ((!g1430 E) || ((g405 E) && (!g1428 E))) := by simp [g1,g1455,g1456,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold14_6 E
  have T0 := score2_threshold14_5 E
  exact threshold_step (g405 E) (!g1430 E) (!g1428 E) 6 (countTrue (score2_vals14 E)) T1 T0
theorem score2_threshold16_6 (E : Nat→Bool) : ((!g1484 E)=true) ↔ 7≤countTrue (score2_vals16 E) := by
  have rew : (!g1484 E) = ((!g1456 E) || ((g406 E) && (!g1454 E))) := by simp [g1,g1483,g1484,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold15_6 E
  have T0 := score2_threshold15_5 E
  exact threshold_step (g406 E) (!g1456 E) (!g1454 E) 6 (countTrue (score2_vals15 E)) T1 T0
theorem score2_threshold17_6 (E : Nat→Bool) : ((!g1514 E)=true) ↔ 7≤countTrue (score2_vals17 E) := by
  have rew : (!g1514 E) = ((!g1484 E) || ((g407 E) && (!g1482 E))) := by simp [g1,g1513,g1514,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold16_6 E
  have T0 := score2_threshold16_5 E
  exact threshold_step (g407 E) (!g1484 E) (!g1482 E) 6 (countTrue (score2_vals16 E)) T1 T0
theorem score2_threshold18_6 (E : Nat→Bool) : ((!g1546 E)=true) ↔ 7≤countTrue (score2_vals18 E) := by
  have rew : (!g1546 E) = ((!g1514 E) || ((g408 E) && (!g1512 E))) := by simp [g1,g1545,g1546,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold17_6 E
  have T0 := score2_threshold17_5 E
  exact threshold_step (g408 E) (!g1514 E) (!g1512 E) 6 (countTrue (score2_vals17 E)) T1 T0
theorem score2_threshold19_6 (E : Nat→Bool) : ((!g1580 E)=true) ↔ 7≤countTrue (score2_vals19 E) := by
  have rew : (!g1580 E) = ((!g1546 E) || ((g409 E) && (!g1544 E))) := by simp [g1,g1579,g1580,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold18_6 E
  have T0 := score2_threshold18_5 E
  exact threshold_step (g409 E) (!g1546 E) (!g1544 E) 6 (countTrue (score2_vals18 E)) T1 T0
theorem score2_threshold20_6 (E : Nat→Bool) : ((!g1616 E)=true) ↔ 7≤countTrue (score2_vals20 E) := by
  have rew : (!g1616 E) = ((!g1580 E) || ((g410 E) && (!g1578 E))) := by simp [g1,g1615,g1616,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold19_6 E
  have T0 := score2_threshold19_5 E
  exact threshold_step (g410 E) (!g1580 E) (!g1578 E) 6 (countTrue (score2_vals19 E)) T1 T0
theorem score2_threshold21_6 (E : Nat→Bool) : ((!g1654 E)=true) ↔ 7≤countTrue (score2_vals21 E) := by
  have rew : (!g1654 E) = ((!g1616 E) || ((g411 E) && (!g1614 E))) := by simp [g1,g1653,g1654,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold20_6 E
  have T0 := score2_threshold20_5 E
  exact threshold_step (g411 E) (!g1616 E) (!g1614 E) 6 (countTrue (score2_vals20 E)) T1 T0
def score2_count (E : Nat→Bool) : Nat := countTrue (score2_vals21 E)
def score3_vals1 (E : Nat→Bool) : List Bool := (g367 E) :: ([])
def score3_vals2 (E : Nat→Bool) : List Bool := (g372 E) :: (score3_vals1 E)
def score3_vals3 (E : Nat→Bool) : List Bool := (g377 E) :: (score3_vals2 E)
def score3_vals4 (E : Nat→Bool) : List Bool := (g378 E) :: (score3_vals3 E)
def score3_vals5 (E : Nat→Bool) : List Bool := (g379 E) :: (score3_vals4 E)
def score3_vals6 (E : Nat→Bool) : List Bool := (g380 E) :: (score3_vals5 E)
def score3_vals7 (E : Nat→Bool) : List Bool := (g387 E) :: (score3_vals6 E)
def score3_vals8 (E : Nat→Bool) : List Bool := (g392 E) :: (score3_vals7 E)
def score3_vals9 (E : Nat→Bool) : List Bool := (g393 E) :: (score3_vals8 E)
def score3_vals10 (E : Nat→Bool) : List Bool := (g394 E) :: (score3_vals9 E)
def score3_vals11 (E : Nat→Bool) : List Bool := (g395 E) :: (score3_vals10 E)
def score3_vals12 (E : Nat→Bool) : List Bool := (g402 E) :: (score3_vals11 E)
def score3_vals13 (E : Nat→Bool) : List Bool := (g403 E) :: (score3_vals12 E)
def score3_vals14 (E : Nat→Bool) : List Bool := (g404 E) :: (score3_vals13 E)
def score3_vals15 (E : Nat→Bool) : List Bool := (g405 E) :: (score3_vals14 E)
def score3_vals16 (E : Nat→Bool) : List Bool := (g412 E) :: (score3_vals15 E)
def score3_vals17 (E : Nat→Bool) : List Bool := (g413 E) :: (score3_vals16 E)
def score3_vals18 (E : Nat→Bool) : List Bool := (g414 E) :: (score3_vals17 E)
def score3_vals19 (E : Nat→Bool) : List Bool := (g415 E) :: (score3_vals18 E)
def score3_vals20 (E : Nat→Bool) : List Bool := (g416 E) :: (score3_vals19 E)
def score3_vals21 (E : Nat→Bool) : List Bool := (g417 E) :: (score3_vals20 E)
theorem score3_threshold1_0 (E : Nat→Bool) : ((g367 E)=true) ↔ 1≤countTrue (score3_vals1 E) := by
  have rew : (g367 E) = ((!g1 E) || ((g367 E) && (g1 E))) := by simp [g1,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 1≤countTrue ([] : List Bool) := by
    have hh := count_true_bound ([] : List Bool)
    change countTrue ([] : List Bool)≤0 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬1≤countTrue ([] : List Bool)
    omega
  have T0 : (g1 E)=true ↔ 0≤countTrue ([] : List Bool) := by simp [g1]
  exact threshold_step (g367 E) (!g1 E) (g1 E) 0 (countTrue ([] : List Bool)) T1 T0
theorem score3_threshold2_1 (E : Nat→Bool) : ((g1683 E)=true) ↔ 2≤countTrue (score3_vals2 E) := by
  have rew : (g1683 E) = ((!g1 E) || ((g372 E) && (g367 E))) := by simp [g1,g1683,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 2≤countTrue (score3_vals1 E) := by
    have hh := count_true_bound (score3_vals1 E)
    change countTrue (score3_vals1 E)≤1 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬2≤countTrue (score3_vals1 E)
    omega
  have T0 := score3_threshold1_0 E
  exact threshold_step (g372 E) (!g1 E) (g367 E) 1 (countTrue (score3_vals1 E)) T1 T0
theorem score3_threshold3_2 (E : Nat→Bool) : ((g1687 E)=true) ↔ 3≤countTrue (score3_vals3 E) := by
  have rew : (g1687 E) = ((!g1 E) || ((g377 E) && (g1683 E))) := by simp [g1,g1687,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 3≤countTrue (score3_vals2 E) := by
    have hh := count_true_bound (score3_vals2 E)
    change countTrue (score3_vals2 E)≤2 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬3≤countTrue (score3_vals2 E)
    omega
  have T0 := score3_threshold2_1 E
  exact threshold_step (g377 E) (!g1 E) (g1683 E) 2 (countTrue (score3_vals2 E)) T1 T0
theorem score3_threshold2_0 (E : Nat→Bool) : ((!g1682 E)=true) ↔ 1≤countTrue (score3_vals2 E) := by
  have rew : (!g1682 E) = ((g367 E) || ((g372 E) && (g1 E))) := by simp [g1,g1682,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold1_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score3_vals1 E) := by simp [g1]
  exact threshold_step (g372 E) (g367 E) (g1 E) 0 (countTrue (score3_vals1 E)) T1 T0
theorem score3_threshold3_1 (E : Nat→Bool) : ((!g1686 E)=true) ↔ 2≤countTrue (score3_vals3 E) := by
  have rew : (!g1686 E) = ((g1683 E) || ((g377 E) && (!g1682 E))) := by simp [g1,g1685,g1686,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold2_1 E
  have T0 := score3_threshold2_0 E
  exact threshold_step (g377 E) (g1683 E) (!g1682 E) 1 (countTrue (score3_vals2 E)) T1 T0
theorem score3_threshold4_2 (E : Nat→Bool) : ((!g1692 E)=true) ↔ 3≤countTrue (score3_vals4 E) := by
  have rew : (!g1692 E) = ((g1687 E) || ((g378 E) && (!g1686 E))) := by simp [g1,g1691,g1692,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold3_2 E
  have T0 := score3_threshold3_1 E
  exact threshold_step (g378 E) (g1687 E) (!g1686 E) 2 (countTrue (score3_vals3 E)) T1 T0
theorem score3_threshold3_0 (E : Nat→Bool) : ((!g1684 E)=true) ↔ 1≤countTrue (score3_vals3 E) := by
  have rew : (!g1684 E) = ((!g1682 E) || ((g377 E) && (g1 E))) := by simp [g1,g1684,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold2_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score3_vals2 E) := by simp [g1]
  exact threshold_step (g377 E) (!g1682 E) (g1 E) 0 (countTrue (score3_vals2 E)) T1 T0
theorem score3_threshold4_1 (E : Nat→Bool) : ((!g1690 E)=true) ↔ 2≤countTrue (score3_vals4 E) := by
  have rew : (!g1690 E) = ((!g1686 E) || ((g378 E) && (!g1684 E))) := by simp [g1,g1689,g1690,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold3_1 E
  have T0 := score3_threshold3_0 E
  exact threshold_step (g378 E) (!g1686 E) (!g1684 E) 1 (countTrue (score3_vals3 E)) T1 T0
theorem score3_threshold5_2 (E : Nat→Bool) : ((!g1698 E)=true) ↔ 3≤countTrue (score3_vals5 E) := by
  have rew : (!g1698 E) = ((!g1692 E) || ((g379 E) && (!g1690 E))) := by simp [g1,g1697,g1698,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold4_2 E
  have T0 := score3_threshold4_1 E
  exact threshold_step (g379 E) (!g1692 E) (!g1690 E) 2 (countTrue (score3_vals4 E)) T1 T0
theorem score3_threshold4_0 (E : Nat→Bool) : ((!g1688 E)=true) ↔ 1≤countTrue (score3_vals4 E) := by
  have rew : (!g1688 E) = ((!g1684 E) || ((g378 E) && (g1 E))) := by simp [g1,g1688,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold3_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score3_vals3 E) := by simp [g1]
  exact threshold_step (g378 E) (!g1684 E) (g1 E) 0 (countTrue (score3_vals3 E)) T1 T0
theorem score3_threshold5_1 (E : Nat→Bool) : ((!g1696 E)=true) ↔ 2≤countTrue (score3_vals5 E) := by
  have rew : (!g1696 E) = ((!g1690 E) || ((g379 E) && (!g1688 E))) := by simp [g1,g1695,g1696,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold4_1 E
  have T0 := score3_threshold4_0 E
  exact threshold_step (g379 E) (!g1690 E) (!g1688 E) 1 (countTrue (score3_vals4 E)) T1 T0
theorem score3_threshold6_2 (E : Nat→Bool) : ((!g1706 E)=true) ↔ 3≤countTrue (score3_vals6 E) := by
  have rew : (!g1706 E) = ((!g1698 E) || ((g380 E) && (!g1696 E))) := by simp [g1,g1705,g1706,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold5_2 E
  have T0 := score3_threshold5_1 E
  exact threshold_step (g380 E) (!g1698 E) (!g1696 E) 2 (countTrue (score3_vals5 E)) T1 T0
theorem score3_threshold5_0 (E : Nat→Bool) : ((!g1694 E)=true) ↔ 1≤countTrue (score3_vals5 E) := by
  have rew : (!g1694 E) = ((!g1688 E) || ((g379 E) && (g1 E))) := by simp [g1,g1694,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold4_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score3_vals4 E) := by simp [g1]
  exact threshold_step (g379 E) (!g1688 E) (g1 E) 0 (countTrue (score3_vals4 E)) T1 T0
theorem score3_threshold6_1 (E : Nat→Bool) : ((!g1704 E)=true) ↔ 2≤countTrue (score3_vals6 E) := by
  have rew : (!g1704 E) = ((!g1696 E) || ((g380 E) && (!g1694 E))) := by simp [g1,g1703,g1704,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold5_1 E
  have T0 := score3_threshold5_0 E
  exact threshold_step (g380 E) (!g1696 E) (!g1694 E) 1 (countTrue (score3_vals5 E)) T1 T0
theorem score3_threshold7_2 (E : Nat→Bool) : ((!g1716 E)=true) ↔ 3≤countTrue (score3_vals7 E) := by
  have rew : (!g1716 E) = ((!g1706 E) || ((g387 E) && (!g1704 E))) := by simp [g1,g1715,g1716,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold6_2 E
  have T0 := score3_threshold6_1 E
  exact threshold_step (g387 E) (!g1706 E) (!g1704 E) 2 (countTrue (score3_vals6 E)) T1 T0
theorem score3_threshold6_0 (E : Nat→Bool) : ((!g1702 E)=true) ↔ 1≤countTrue (score3_vals6 E) := by
  have rew : (!g1702 E) = ((!g1694 E) || ((g380 E) && (g1 E))) := by simp [g1,g1702,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold5_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score3_vals5 E) := by simp [g1]
  exact threshold_step (g380 E) (!g1694 E) (g1 E) 0 (countTrue (score3_vals5 E)) T1 T0
theorem score3_threshold7_1 (E : Nat→Bool) : ((!g1714 E)=true) ↔ 2≤countTrue (score3_vals7 E) := by
  have rew : (!g1714 E) = ((!g1704 E) || ((g387 E) && (!g1702 E))) := by simp [g1,g1713,g1714,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold6_1 E
  have T0 := score3_threshold6_0 E
  exact threshold_step (g387 E) (!g1704 E) (!g1702 E) 1 (countTrue (score3_vals6 E)) T1 T0
theorem score3_threshold8_2 (E : Nat→Bool) : ((!g1728 E)=true) ↔ 3≤countTrue (score3_vals8 E) := by
  have rew : (!g1728 E) = ((!g1716 E) || ((g392 E) && (!g1714 E))) := by simp [g1,g1727,g1728,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold7_2 E
  have T0 := score3_threshold7_1 E
  exact threshold_step (g392 E) (!g1716 E) (!g1714 E) 2 (countTrue (score3_vals7 E)) T1 T0
theorem score3_threshold7_0 (E : Nat→Bool) : ((!g1712 E)=true) ↔ 1≤countTrue (score3_vals7 E) := by
  have rew : (!g1712 E) = ((!g1702 E) || ((g387 E) && (g1 E))) := by simp [g1,g1712,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold6_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score3_vals6 E) := by simp [g1]
  exact threshold_step (g387 E) (!g1702 E) (g1 E) 0 (countTrue (score3_vals6 E)) T1 T0
theorem score3_threshold8_1 (E : Nat→Bool) : ((!g1726 E)=true) ↔ 2≤countTrue (score3_vals8 E) := by
  have rew : (!g1726 E) = ((!g1714 E) || ((g392 E) && (!g1712 E))) := by simp [g1,g1725,g1726,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold7_1 E
  have T0 := score3_threshold7_0 E
  exact threshold_step (g392 E) (!g1714 E) (!g1712 E) 1 (countTrue (score3_vals7 E)) T1 T0
theorem score3_threshold9_2 (E : Nat→Bool) : ((!g1742 E)=true) ↔ 3≤countTrue (score3_vals9 E) := by
  have rew : (!g1742 E) = ((!g1728 E) || ((g393 E) && (!g1726 E))) := by simp [g1,g1741,g1742,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold8_2 E
  have T0 := score3_threshold8_1 E
  exact threshold_step (g393 E) (!g1728 E) (!g1726 E) 2 (countTrue (score3_vals8 E)) T1 T0
theorem score3_threshold8_0 (E : Nat→Bool) : ((!g1724 E)=true) ↔ 1≤countTrue (score3_vals8 E) := by
  have rew : (!g1724 E) = ((!g1712 E) || ((g392 E) && (g1 E))) := by simp [g1,g1724,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold7_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score3_vals7 E) := by simp [g1]
  exact threshold_step (g392 E) (!g1712 E) (g1 E) 0 (countTrue (score3_vals7 E)) T1 T0
theorem score3_threshold9_1 (E : Nat→Bool) : ((!g1740 E)=true) ↔ 2≤countTrue (score3_vals9 E) := by
  have rew : (!g1740 E) = ((!g1726 E) || ((g393 E) && (!g1724 E))) := by simp [g1,g1739,g1740,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold8_1 E
  have T0 := score3_threshold8_0 E
  exact threshold_step (g393 E) (!g1726 E) (!g1724 E) 1 (countTrue (score3_vals8 E)) T1 T0
theorem score3_threshold10_2 (E : Nat→Bool) : ((!g1758 E)=true) ↔ 3≤countTrue (score3_vals10 E) := by
  have rew : (!g1758 E) = ((!g1742 E) || ((g394 E) && (!g1740 E))) := by simp [g1,g1757,g1758,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold9_2 E
  have T0 := score3_threshold9_1 E
  exact threshold_step (g394 E) (!g1742 E) (!g1740 E) 2 (countTrue (score3_vals9 E)) T1 T0
theorem score3_threshold9_0 (E : Nat→Bool) : ((!g1738 E)=true) ↔ 1≤countTrue (score3_vals9 E) := by
  have rew : (!g1738 E) = ((!g1724 E) || ((g393 E) && (g1 E))) := by simp [g1,g1738,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold8_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score3_vals8 E) := by simp [g1]
  exact threshold_step (g393 E) (!g1724 E) (g1 E) 0 (countTrue (score3_vals8 E)) T1 T0
theorem score3_threshold10_1 (E : Nat→Bool) : ((!g1756 E)=true) ↔ 2≤countTrue (score3_vals10 E) := by
  have rew : (!g1756 E) = ((!g1740 E) || ((g394 E) && (!g1738 E))) := by simp [g1,g1755,g1756,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold9_1 E
  have T0 := score3_threshold9_0 E
  exact threshold_step (g394 E) (!g1740 E) (!g1738 E) 1 (countTrue (score3_vals9 E)) T1 T0
theorem score3_threshold11_2 (E : Nat→Bool) : ((!g1776 E)=true) ↔ 3≤countTrue (score3_vals11 E) := by
  have rew : (!g1776 E) = ((!g1758 E) || ((g395 E) && (!g1756 E))) := by simp [g1,g1775,g1776,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold10_2 E
  have T0 := score3_threshold10_1 E
  exact threshold_step (g395 E) (!g1758 E) (!g1756 E) 2 (countTrue (score3_vals10 E)) T1 T0
theorem score3_threshold10_0 (E : Nat→Bool) : ((!g1754 E)=true) ↔ 1≤countTrue (score3_vals10 E) := by
  have rew : (!g1754 E) = ((!g1738 E) || ((g394 E) && (g1 E))) := by simp [g1,g1754,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold9_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score3_vals9 E) := by simp [g1]
  exact threshold_step (g394 E) (!g1738 E) (g1 E) 0 (countTrue (score3_vals9 E)) T1 T0
theorem score3_threshold11_1 (E : Nat→Bool) : ((!g1774 E)=true) ↔ 2≤countTrue (score3_vals11 E) := by
  have rew : (!g1774 E) = ((!g1756 E) || ((g395 E) && (!g1754 E))) := by simp [g1,g1773,g1774,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold10_1 E
  have T0 := score3_threshold10_0 E
  exact threshold_step (g395 E) (!g1756 E) (!g1754 E) 1 (countTrue (score3_vals10 E)) T1 T0
theorem score3_threshold12_2 (E : Nat→Bool) : ((!g1796 E)=true) ↔ 3≤countTrue (score3_vals12 E) := by
  have rew : (!g1796 E) = ((!g1776 E) || ((g402 E) && (!g1774 E))) := by simp [g1,g1795,g1796,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold11_2 E
  have T0 := score3_threshold11_1 E
  exact threshold_step (g402 E) (!g1776 E) (!g1774 E) 2 (countTrue (score3_vals11 E)) T1 T0
theorem score3_threshold11_0 (E : Nat→Bool) : ((!g1772 E)=true) ↔ 1≤countTrue (score3_vals11 E) := by
  have rew : (!g1772 E) = ((!g1754 E) || ((g395 E) && (g1 E))) := by simp [g1,g1772,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold10_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score3_vals10 E) := by simp [g1]
  exact threshold_step (g395 E) (!g1754 E) (g1 E) 0 (countTrue (score3_vals10 E)) T1 T0
theorem score3_threshold12_1 (E : Nat→Bool) : ((!g1794 E)=true) ↔ 2≤countTrue (score3_vals12 E) := by
  have rew : (!g1794 E) = ((!g1774 E) || ((g402 E) && (!g1772 E))) := by simp [g1,g1793,g1794,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold11_1 E
  have T0 := score3_threshold11_0 E
  exact threshold_step (g402 E) (!g1774 E) (!g1772 E) 1 (countTrue (score3_vals11 E)) T1 T0
theorem score3_threshold13_2 (E : Nat→Bool) : ((!g1818 E)=true) ↔ 3≤countTrue (score3_vals13 E) := by
  have rew : (!g1818 E) = ((!g1796 E) || ((g403 E) && (!g1794 E))) := by simp [g1,g1817,g1818,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold12_2 E
  have T0 := score3_threshold12_1 E
  exact threshold_step (g403 E) (!g1796 E) (!g1794 E) 2 (countTrue (score3_vals12 E)) T1 T0
theorem score3_threshold12_0 (E : Nat→Bool) : ((!g1792 E)=true) ↔ 1≤countTrue (score3_vals12 E) := by
  have rew : (!g1792 E) = ((!g1772 E) || ((g402 E) && (g1 E))) := by simp [g1,g1792,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold11_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score3_vals11 E) := by simp [g1]
  exact threshold_step (g402 E) (!g1772 E) (g1 E) 0 (countTrue (score3_vals11 E)) T1 T0
theorem score3_threshold13_1 (E : Nat→Bool) : ((!g1816 E)=true) ↔ 2≤countTrue (score3_vals13 E) := by
  have rew : (!g1816 E) = ((!g1794 E) || ((g403 E) && (!g1792 E))) := by simp [g1,g1815,g1816,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold12_1 E
  have T0 := score3_threshold12_0 E
  exact threshold_step (g403 E) (!g1794 E) (!g1792 E) 1 (countTrue (score3_vals12 E)) T1 T0
theorem score3_threshold14_2 (E : Nat→Bool) : ((!g1842 E)=true) ↔ 3≤countTrue (score3_vals14 E) := by
  have rew : (!g1842 E) = ((!g1818 E) || ((g404 E) && (!g1816 E))) := by simp [g1,g1841,g1842,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold13_2 E
  have T0 := score3_threshold13_1 E
  exact threshold_step (g404 E) (!g1818 E) (!g1816 E) 2 (countTrue (score3_vals13 E)) T1 T0
theorem score3_threshold13_0 (E : Nat→Bool) : ((!g1814 E)=true) ↔ 1≤countTrue (score3_vals13 E) := by
  have rew : (!g1814 E) = ((!g1792 E) || ((g403 E) && (g1 E))) := by simp [g1,g1814,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold12_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score3_vals12 E) := by simp [g1]
  exact threshold_step (g403 E) (!g1792 E) (g1 E) 0 (countTrue (score3_vals12 E)) T1 T0
theorem score3_threshold14_1 (E : Nat→Bool) : ((!g1840 E)=true) ↔ 2≤countTrue (score3_vals14 E) := by
  have rew : (!g1840 E) = ((!g1816 E) || ((g404 E) && (!g1814 E))) := by simp [g1,g1839,g1840,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold13_1 E
  have T0 := score3_threshold13_0 E
  exact threshold_step (g404 E) (!g1816 E) (!g1814 E) 1 (countTrue (score3_vals13 E)) T1 T0
theorem score3_threshold15_2 (E : Nat→Bool) : ((!g1868 E)=true) ↔ 3≤countTrue (score3_vals15 E) := by
  have rew : (!g1868 E) = ((!g1842 E) || ((g405 E) && (!g1840 E))) := by simp [g1,g1867,g1868,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold14_2 E
  have T0 := score3_threshold14_1 E
  exact threshold_step (g405 E) (!g1842 E) (!g1840 E) 2 (countTrue (score3_vals14 E)) T1 T0
theorem score3_threshold14_0 (E : Nat→Bool) : ((!g1838 E)=true) ↔ 1≤countTrue (score3_vals14 E) := by
  have rew : (!g1838 E) = ((!g1814 E) || ((g404 E) && (g1 E))) := by simp [g1,g1838,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold13_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score3_vals13 E) := by simp [g1]
  exact threshold_step (g404 E) (!g1814 E) (g1 E) 0 (countTrue (score3_vals13 E)) T1 T0
theorem score3_threshold15_1 (E : Nat→Bool) : ((!g1866 E)=true) ↔ 2≤countTrue (score3_vals15 E) := by
  have rew : (!g1866 E) = ((!g1840 E) || ((g405 E) && (!g1838 E))) := by simp [g1,g1865,g1866,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold14_1 E
  have T0 := score3_threshold14_0 E
  exact threshold_step (g405 E) (!g1840 E) (!g1838 E) 1 (countTrue (score3_vals14 E)) T1 T0
theorem score3_threshold16_2 (E : Nat→Bool) : ((!g1896 E)=true) ↔ 3≤countTrue (score3_vals16 E) := by
  have rew : (!g1896 E) = ((!g1868 E) || ((g412 E) && (!g1866 E))) := by simp [g1,g1895,g1896,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold15_2 E
  have T0 := score3_threshold15_1 E
  exact threshold_step (g412 E) (!g1868 E) (!g1866 E) 2 (countTrue (score3_vals15 E)) T1 T0
theorem score3_threshold15_0 (E : Nat→Bool) : ((!g1864 E)=true) ↔ 1≤countTrue (score3_vals15 E) := by
  have rew : (!g1864 E) = ((!g1838 E) || ((g405 E) && (g1 E))) := by simp [g1,g1864,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold14_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score3_vals14 E) := by simp [g1]
  exact threshold_step (g405 E) (!g1838 E) (g1 E) 0 (countTrue (score3_vals14 E)) T1 T0
theorem score3_threshold16_1 (E : Nat→Bool) : ((!g1894 E)=true) ↔ 2≤countTrue (score3_vals16 E) := by
  have rew : (!g1894 E) = ((!g1866 E) || ((g412 E) && (!g1864 E))) := by simp [g1,g1893,g1894,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold15_1 E
  have T0 := score3_threshold15_0 E
  exact threshold_step (g412 E) (!g1866 E) (!g1864 E) 1 (countTrue (score3_vals15 E)) T1 T0
theorem score3_threshold17_2 (E : Nat→Bool) : ((!g1926 E)=true) ↔ 3≤countTrue (score3_vals17 E) := by
  have rew : (!g1926 E) = ((!g1896 E) || ((g413 E) && (!g1894 E))) := by simp [g1,g1925,g1926,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold16_2 E
  have T0 := score3_threshold16_1 E
  exact threshold_step (g413 E) (!g1896 E) (!g1894 E) 2 (countTrue (score3_vals16 E)) T1 T0
theorem score3_threshold16_0 (E : Nat→Bool) : ((!g1892 E)=true) ↔ 1≤countTrue (score3_vals16 E) := by
  have rew : (!g1892 E) = ((!g1864 E) || ((g412 E) && (g1 E))) := by simp [g1,g1892,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold15_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score3_vals15 E) := by simp [g1]
  exact threshold_step (g412 E) (!g1864 E) (g1 E) 0 (countTrue (score3_vals15 E)) T1 T0
theorem score3_threshold17_1 (E : Nat→Bool) : ((!g1924 E)=true) ↔ 2≤countTrue (score3_vals17 E) := by
  have rew : (!g1924 E) = ((!g1894 E) || ((g413 E) && (!g1892 E))) := by simp [g1,g1923,g1924,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold16_1 E
  have T0 := score3_threshold16_0 E
  exact threshold_step (g413 E) (!g1894 E) (!g1892 E) 1 (countTrue (score3_vals16 E)) T1 T0
theorem score3_threshold18_2 (E : Nat→Bool) : ((!g1958 E)=true) ↔ 3≤countTrue (score3_vals18 E) := by
  have rew : (!g1958 E) = ((!g1926 E) || ((g414 E) && (!g1924 E))) := by simp [g1,g1957,g1958,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold17_2 E
  have T0 := score3_threshold17_1 E
  exact threshold_step (g414 E) (!g1926 E) (!g1924 E) 2 (countTrue (score3_vals17 E)) T1 T0
theorem score3_threshold17_0 (E : Nat→Bool) : ((!g1922 E)=true) ↔ 1≤countTrue (score3_vals17 E) := by
  have rew : (!g1922 E) = ((!g1892 E) || ((g413 E) && (g1 E))) := by simp [g1,g1922,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold16_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score3_vals16 E) := by simp [g1]
  exact threshold_step (g413 E) (!g1892 E) (g1 E) 0 (countTrue (score3_vals16 E)) T1 T0
theorem score3_threshold18_1 (E : Nat→Bool) : ((!g1956 E)=true) ↔ 2≤countTrue (score3_vals18 E) := by
  have rew : (!g1956 E) = ((!g1924 E) || ((g414 E) && (!g1922 E))) := by simp [g1,g1955,g1956,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold17_1 E
  have T0 := score3_threshold17_0 E
  exact threshold_step (g414 E) (!g1924 E) (!g1922 E) 1 (countTrue (score3_vals17 E)) T1 T0
theorem score3_threshold19_2 (E : Nat→Bool) : ((!g1992 E)=true) ↔ 3≤countTrue (score3_vals19 E) := by
  have rew : (!g1992 E) = ((!g1958 E) || ((g415 E) && (!g1956 E))) := by simp [g1,g1991,g1992,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold18_2 E
  have T0 := score3_threshold18_1 E
  exact threshold_step (g415 E) (!g1958 E) (!g1956 E) 2 (countTrue (score3_vals18 E)) T1 T0
theorem score3_threshold18_0 (E : Nat→Bool) : ((!g1954 E)=true) ↔ 1≤countTrue (score3_vals18 E) := by
  have rew : (!g1954 E) = ((!g1922 E) || ((g414 E) && (g1 E))) := by simp [g1,g1954,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold17_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score3_vals17 E) := by simp [g1]
  exact threshold_step (g414 E) (!g1922 E) (g1 E) 0 (countTrue (score3_vals17 E)) T1 T0
theorem score3_threshold19_1 (E : Nat→Bool) : ((!g1990 E)=true) ↔ 2≤countTrue (score3_vals19 E) := by
  have rew : (!g1990 E) = ((!g1956 E) || ((g415 E) && (!g1954 E))) := by simp [g1,g1989,g1990,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold18_1 E
  have T0 := score3_threshold18_0 E
  exact threshold_step (g415 E) (!g1956 E) (!g1954 E) 1 (countTrue (score3_vals18 E)) T1 T0
theorem score3_threshold20_2 (E : Nat→Bool) : ((!g2028 E)=true) ↔ 3≤countTrue (score3_vals20 E) := by
  have rew : (!g2028 E) = ((!g1992 E) || ((g416 E) && (!g1990 E))) := by simp [g1,g2027,g2028,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold19_2 E
  have T0 := score3_threshold19_1 E
  exact threshold_step (g416 E) (!g1992 E) (!g1990 E) 2 (countTrue (score3_vals19 E)) T1 T0
theorem score3_threshold19_0 (E : Nat→Bool) : ((!g1988 E)=true) ↔ 1≤countTrue (score3_vals19 E) := by
  have rew : (!g1988 E) = ((!g1954 E) || ((g415 E) && (g1 E))) := by simp [g1,g1988,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold18_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score3_vals18 E) := by simp [g1]
  exact threshold_step (g415 E) (!g1954 E) (g1 E) 0 (countTrue (score3_vals18 E)) T1 T0
theorem score3_threshold20_1 (E : Nat→Bool) : ((!g2026 E)=true) ↔ 2≤countTrue (score3_vals20 E) := by
  have rew : (!g2026 E) = ((!g1990 E) || ((g416 E) && (!g1988 E))) := by simp [g1,g2025,g2026,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold19_1 E
  have T0 := score3_threshold19_0 E
  exact threshold_step (g416 E) (!g1990 E) (!g1988 E) 1 (countTrue (score3_vals19 E)) T1 T0
theorem score3_threshold21_2 (E : Nat→Bool) : ((!g2066 E)=true) ↔ 3≤countTrue (score3_vals21 E) := by
  have rew : (!g2066 E) = ((!g2028 E) || ((g417 E) && (!g2026 E))) := by simp [g1,g2065,g2066,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold20_2 E
  have T0 := score3_threshold20_1 E
  exact threshold_step (g417 E) (!g2028 E) (!g2026 E) 2 (countTrue (score3_vals20 E)) T1 T0
theorem score3_threshold4_3 (E : Nat→Bool) : ((g1693 E)=true) ↔ 4≤countTrue (score3_vals4 E) := by
  have rew : (g1693 E) = ((!g1 E) || ((g378 E) && (g1687 E))) := by simp [g1,g1693,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 4≤countTrue (score3_vals3 E) := by
    have hh := count_true_bound (score3_vals3 E)
    change countTrue (score3_vals3 E)≤3 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬4≤countTrue (score3_vals3 E)
    omega
  have T0 := score3_threshold3_2 E
  exact threshold_step (g378 E) (!g1 E) (g1687 E) 3 (countTrue (score3_vals3 E)) T1 T0
theorem score3_threshold5_3 (E : Nat→Bool) : ((!g1700 E)=true) ↔ 4≤countTrue (score3_vals5 E) := by
  have rew : (!g1700 E) = ((g1693 E) || ((g379 E) && (!g1692 E))) := by simp [g1,g1699,g1700,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold4_3 E
  have T0 := score3_threshold4_2 E
  exact threshold_step (g379 E) (g1693 E) (!g1692 E) 3 (countTrue (score3_vals4 E)) T1 T0
theorem score3_threshold6_3 (E : Nat→Bool) : ((!g1708 E)=true) ↔ 4≤countTrue (score3_vals6 E) := by
  have rew : (!g1708 E) = ((!g1700 E) || ((g380 E) && (!g1698 E))) := by simp [g1,g1707,g1708,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold5_3 E
  have T0 := score3_threshold5_2 E
  exact threshold_step (g380 E) (!g1700 E) (!g1698 E) 3 (countTrue (score3_vals5 E)) T1 T0
theorem score3_threshold7_3 (E : Nat→Bool) : ((!g1718 E)=true) ↔ 4≤countTrue (score3_vals7 E) := by
  have rew : (!g1718 E) = ((!g1708 E) || ((g387 E) && (!g1706 E))) := by simp [g1,g1717,g1718,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold6_3 E
  have T0 := score3_threshold6_2 E
  exact threshold_step (g387 E) (!g1708 E) (!g1706 E) 3 (countTrue (score3_vals6 E)) T1 T0
theorem score3_threshold8_3 (E : Nat→Bool) : ((!g1730 E)=true) ↔ 4≤countTrue (score3_vals8 E) := by
  have rew : (!g1730 E) = ((!g1718 E) || ((g392 E) && (!g1716 E))) := by simp [g1,g1729,g1730,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold7_3 E
  have T0 := score3_threshold7_2 E
  exact threshold_step (g392 E) (!g1718 E) (!g1716 E) 3 (countTrue (score3_vals7 E)) T1 T0
theorem score3_threshold9_3 (E : Nat→Bool) : ((!g1744 E)=true) ↔ 4≤countTrue (score3_vals9 E) := by
  have rew : (!g1744 E) = ((!g1730 E) || ((g393 E) && (!g1728 E))) := by simp [g1,g1743,g1744,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold8_3 E
  have T0 := score3_threshold8_2 E
  exact threshold_step (g393 E) (!g1730 E) (!g1728 E) 3 (countTrue (score3_vals8 E)) T1 T0
theorem score3_threshold10_3 (E : Nat→Bool) : ((!g1760 E)=true) ↔ 4≤countTrue (score3_vals10 E) := by
  have rew : (!g1760 E) = ((!g1744 E) || ((g394 E) && (!g1742 E))) := by simp [g1,g1759,g1760,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold9_3 E
  have T0 := score3_threshold9_2 E
  exact threshold_step (g394 E) (!g1744 E) (!g1742 E) 3 (countTrue (score3_vals9 E)) T1 T0
theorem score3_threshold11_3 (E : Nat→Bool) : ((!g1778 E)=true) ↔ 4≤countTrue (score3_vals11 E) := by
  have rew : (!g1778 E) = ((!g1760 E) || ((g395 E) && (!g1758 E))) := by simp [g1,g1777,g1778,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold10_3 E
  have T0 := score3_threshold10_2 E
  exact threshold_step (g395 E) (!g1760 E) (!g1758 E) 3 (countTrue (score3_vals10 E)) T1 T0
theorem score3_threshold12_3 (E : Nat→Bool) : ((!g1798 E)=true) ↔ 4≤countTrue (score3_vals12 E) := by
  have rew : (!g1798 E) = ((!g1778 E) || ((g402 E) && (!g1776 E))) := by simp [g1,g1797,g1798,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold11_3 E
  have T0 := score3_threshold11_2 E
  exact threshold_step (g402 E) (!g1778 E) (!g1776 E) 3 (countTrue (score3_vals11 E)) T1 T0
theorem score3_threshold13_3 (E : Nat→Bool) : ((!g1820 E)=true) ↔ 4≤countTrue (score3_vals13 E) := by
  have rew : (!g1820 E) = ((!g1798 E) || ((g403 E) && (!g1796 E))) := by simp [g1,g1819,g1820,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold12_3 E
  have T0 := score3_threshold12_2 E
  exact threshold_step (g403 E) (!g1798 E) (!g1796 E) 3 (countTrue (score3_vals12 E)) T1 T0
theorem score3_threshold14_3 (E : Nat→Bool) : ((!g1844 E)=true) ↔ 4≤countTrue (score3_vals14 E) := by
  have rew : (!g1844 E) = ((!g1820 E) || ((g404 E) && (!g1818 E))) := by simp [g1,g1843,g1844,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold13_3 E
  have T0 := score3_threshold13_2 E
  exact threshold_step (g404 E) (!g1820 E) (!g1818 E) 3 (countTrue (score3_vals13 E)) T1 T0
theorem score3_threshold15_3 (E : Nat→Bool) : ((!g1870 E)=true) ↔ 4≤countTrue (score3_vals15 E) := by
  have rew : (!g1870 E) = ((!g1844 E) || ((g405 E) && (!g1842 E))) := by simp [g1,g1869,g1870,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold14_3 E
  have T0 := score3_threshold14_2 E
  exact threshold_step (g405 E) (!g1844 E) (!g1842 E) 3 (countTrue (score3_vals14 E)) T1 T0
theorem score3_threshold16_3 (E : Nat→Bool) : ((!g1898 E)=true) ↔ 4≤countTrue (score3_vals16 E) := by
  have rew : (!g1898 E) = ((!g1870 E) || ((g412 E) && (!g1868 E))) := by simp [g1,g1897,g1898,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold15_3 E
  have T0 := score3_threshold15_2 E
  exact threshold_step (g412 E) (!g1870 E) (!g1868 E) 3 (countTrue (score3_vals15 E)) T1 T0
theorem score3_threshold17_3 (E : Nat→Bool) : ((!g1928 E)=true) ↔ 4≤countTrue (score3_vals17 E) := by
  have rew : (!g1928 E) = ((!g1898 E) || ((g413 E) && (!g1896 E))) := by simp [g1,g1927,g1928,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold16_3 E
  have T0 := score3_threshold16_2 E
  exact threshold_step (g413 E) (!g1898 E) (!g1896 E) 3 (countTrue (score3_vals16 E)) T1 T0
theorem score3_threshold18_3 (E : Nat→Bool) : ((!g1960 E)=true) ↔ 4≤countTrue (score3_vals18 E) := by
  have rew : (!g1960 E) = ((!g1928 E) || ((g414 E) && (!g1926 E))) := by simp [g1,g1959,g1960,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold17_3 E
  have T0 := score3_threshold17_2 E
  exact threshold_step (g414 E) (!g1928 E) (!g1926 E) 3 (countTrue (score3_vals17 E)) T1 T0
theorem score3_threshold19_3 (E : Nat→Bool) : ((!g1994 E)=true) ↔ 4≤countTrue (score3_vals19 E) := by
  have rew : (!g1994 E) = ((!g1960 E) || ((g415 E) && (!g1958 E))) := by simp [g1,g1993,g1994,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold18_3 E
  have T0 := score3_threshold18_2 E
  exact threshold_step (g415 E) (!g1960 E) (!g1958 E) 3 (countTrue (score3_vals18 E)) T1 T0
theorem score3_threshold20_3 (E : Nat→Bool) : ((!g2030 E)=true) ↔ 4≤countTrue (score3_vals20 E) := by
  have rew : (!g2030 E) = ((!g1994 E) || ((g416 E) && (!g1992 E))) := by simp [g1,g2029,g2030,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold19_3 E
  have T0 := score3_threshold19_2 E
  exact threshold_step (g416 E) (!g1994 E) (!g1992 E) 3 (countTrue (score3_vals19 E)) T1 T0
theorem score3_threshold21_3 (E : Nat→Bool) : ((!g2068 E)=true) ↔ 4≤countTrue (score3_vals21 E) := by
  have rew : (!g2068 E) = ((!g2030 E) || ((g417 E) && (!g2028 E))) := by simp [g1,g2067,g2068,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold20_3 E
  have T0 := score3_threshold20_2 E
  exact threshold_step (g417 E) (!g2030 E) (!g2028 E) 3 (countTrue (score3_vals20 E)) T1 T0
theorem score3_threshold5_4 (E : Nat→Bool) : ((g1701 E)=true) ↔ 5≤countTrue (score3_vals5 E) := by
  have rew : (g1701 E) = ((!g1 E) || ((g379 E) && (g1693 E))) := by simp [g1,g1701,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 5≤countTrue (score3_vals4 E) := by
    have hh := count_true_bound (score3_vals4 E)
    change countTrue (score3_vals4 E)≤4 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬5≤countTrue (score3_vals4 E)
    omega
  have T0 := score3_threshold4_3 E
  exact threshold_step (g379 E) (!g1 E) (g1693 E) 4 (countTrue (score3_vals4 E)) T1 T0
theorem score3_threshold6_4 (E : Nat→Bool) : ((!g1710 E)=true) ↔ 5≤countTrue (score3_vals6 E) := by
  have rew : (!g1710 E) = ((g1701 E) || ((g380 E) && (!g1700 E))) := by simp [g1,g1709,g1710,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold5_4 E
  have T0 := score3_threshold5_3 E
  exact threshold_step (g380 E) (g1701 E) (!g1700 E) 4 (countTrue (score3_vals5 E)) T1 T0
theorem score3_threshold7_4 (E : Nat→Bool) : ((!g1720 E)=true) ↔ 5≤countTrue (score3_vals7 E) := by
  have rew : (!g1720 E) = ((!g1710 E) || ((g387 E) && (!g1708 E))) := by simp [g1,g1719,g1720,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold6_4 E
  have T0 := score3_threshold6_3 E
  exact threshold_step (g387 E) (!g1710 E) (!g1708 E) 4 (countTrue (score3_vals6 E)) T1 T0
theorem score3_threshold8_4 (E : Nat→Bool) : ((!g1732 E)=true) ↔ 5≤countTrue (score3_vals8 E) := by
  have rew : (!g1732 E) = ((!g1720 E) || ((g392 E) && (!g1718 E))) := by simp [g1,g1731,g1732,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold7_4 E
  have T0 := score3_threshold7_3 E
  exact threshold_step (g392 E) (!g1720 E) (!g1718 E) 4 (countTrue (score3_vals7 E)) T1 T0
theorem score3_threshold9_4 (E : Nat→Bool) : ((!g1746 E)=true) ↔ 5≤countTrue (score3_vals9 E) := by
  have rew : (!g1746 E) = ((!g1732 E) || ((g393 E) && (!g1730 E))) := by simp [g1,g1745,g1746,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold8_4 E
  have T0 := score3_threshold8_3 E
  exact threshold_step (g393 E) (!g1732 E) (!g1730 E) 4 (countTrue (score3_vals8 E)) T1 T0
theorem score3_threshold10_4 (E : Nat→Bool) : ((!g1762 E)=true) ↔ 5≤countTrue (score3_vals10 E) := by
  have rew : (!g1762 E) = ((!g1746 E) || ((g394 E) && (!g1744 E))) := by simp [g1,g1761,g1762,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold9_4 E
  have T0 := score3_threshold9_3 E
  exact threshold_step (g394 E) (!g1746 E) (!g1744 E) 4 (countTrue (score3_vals9 E)) T1 T0
theorem score3_threshold11_4 (E : Nat→Bool) : ((!g1780 E)=true) ↔ 5≤countTrue (score3_vals11 E) := by
  have rew : (!g1780 E) = ((!g1762 E) || ((g395 E) && (!g1760 E))) := by simp [g1,g1779,g1780,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold10_4 E
  have T0 := score3_threshold10_3 E
  exact threshold_step (g395 E) (!g1762 E) (!g1760 E) 4 (countTrue (score3_vals10 E)) T1 T0
theorem score3_threshold12_4 (E : Nat→Bool) : ((!g1800 E)=true) ↔ 5≤countTrue (score3_vals12 E) := by
  have rew : (!g1800 E) = ((!g1780 E) || ((g402 E) && (!g1778 E))) := by simp [g1,g1799,g1800,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold11_4 E
  have T0 := score3_threshold11_3 E
  exact threshold_step (g402 E) (!g1780 E) (!g1778 E) 4 (countTrue (score3_vals11 E)) T1 T0
theorem score3_threshold13_4 (E : Nat→Bool) : ((!g1822 E)=true) ↔ 5≤countTrue (score3_vals13 E) := by
  have rew : (!g1822 E) = ((!g1800 E) || ((g403 E) && (!g1798 E))) := by simp [g1,g1821,g1822,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold12_4 E
  have T0 := score3_threshold12_3 E
  exact threshold_step (g403 E) (!g1800 E) (!g1798 E) 4 (countTrue (score3_vals12 E)) T1 T0
theorem score3_threshold14_4 (E : Nat→Bool) : ((!g1846 E)=true) ↔ 5≤countTrue (score3_vals14 E) := by
  have rew : (!g1846 E) = ((!g1822 E) || ((g404 E) && (!g1820 E))) := by simp [g1,g1845,g1846,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold13_4 E
  have T0 := score3_threshold13_3 E
  exact threshold_step (g404 E) (!g1822 E) (!g1820 E) 4 (countTrue (score3_vals13 E)) T1 T0
theorem score3_threshold15_4 (E : Nat→Bool) : ((!g1872 E)=true) ↔ 5≤countTrue (score3_vals15 E) := by
  have rew : (!g1872 E) = ((!g1846 E) || ((g405 E) && (!g1844 E))) := by simp [g1,g1871,g1872,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold14_4 E
  have T0 := score3_threshold14_3 E
  exact threshold_step (g405 E) (!g1846 E) (!g1844 E) 4 (countTrue (score3_vals14 E)) T1 T0
theorem score3_threshold16_4 (E : Nat→Bool) : ((!g1900 E)=true) ↔ 5≤countTrue (score3_vals16 E) := by
  have rew : (!g1900 E) = ((!g1872 E) || ((g412 E) && (!g1870 E))) := by simp [g1,g1899,g1900,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold15_4 E
  have T0 := score3_threshold15_3 E
  exact threshold_step (g412 E) (!g1872 E) (!g1870 E) 4 (countTrue (score3_vals15 E)) T1 T0
theorem score3_threshold17_4 (E : Nat→Bool) : ((!g1930 E)=true) ↔ 5≤countTrue (score3_vals17 E) := by
  have rew : (!g1930 E) = ((!g1900 E) || ((g413 E) && (!g1898 E))) := by simp [g1,g1929,g1930,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold16_4 E
  have T0 := score3_threshold16_3 E
  exact threshold_step (g413 E) (!g1900 E) (!g1898 E) 4 (countTrue (score3_vals16 E)) T1 T0
theorem score3_threshold18_4 (E : Nat→Bool) : ((!g1962 E)=true) ↔ 5≤countTrue (score3_vals18 E) := by
  have rew : (!g1962 E) = ((!g1930 E) || ((g414 E) && (!g1928 E))) := by simp [g1,g1961,g1962,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold17_4 E
  have T0 := score3_threshold17_3 E
  exact threshold_step (g414 E) (!g1930 E) (!g1928 E) 4 (countTrue (score3_vals17 E)) T1 T0
theorem score3_threshold19_4 (E : Nat→Bool) : ((!g1996 E)=true) ↔ 5≤countTrue (score3_vals19 E) := by
  have rew : (!g1996 E) = ((!g1962 E) || ((g415 E) && (!g1960 E))) := by simp [g1,g1995,g1996,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold18_4 E
  have T0 := score3_threshold18_3 E
  exact threshold_step (g415 E) (!g1962 E) (!g1960 E) 4 (countTrue (score3_vals18 E)) T1 T0
theorem score3_threshold20_4 (E : Nat→Bool) : ((!g2032 E)=true) ↔ 5≤countTrue (score3_vals20 E) := by
  have rew : (!g2032 E) = ((!g1996 E) || ((g416 E) && (!g1994 E))) := by simp [g1,g2031,g2032,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold19_4 E
  have T0 := score3_threshold19_3 E
  exact threshold_step (g416 E) (!g1996 E) (!g1994 E) 4 (countTrue (score3_vals19 E)) T1 T0
theorem score3_threshold21_4 (E : Nat→Bool) : ((!g2070 E)=true) ↔ 5≤countTrue (score3_vals21 E) := by
  have rew : (!g2070 E) = ((!g2032 E) || ((g417 E) && (!g2030 E))) := by simp [g1,g2069,g2070,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold20_4 E
  have T0 := score3_threshold20_3 E
  exact threshold_step (g417 E) (!g2032 E) (!g2030 E) 4 (countTrue (score3_vals20 E)) T1 T0
theorem score3_threshold6_5 (E : Nat→Bool) : ((g1711 E)=true) ↔ 6≤countTrue (score3_vals6 E) := by
  have rew : (g1711 E) = ((!g1 E) || ((g380 E) && (g1701 E))) := by simp [g1,g1711,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 6≤countTrue (score3_vals5 E) := by
    have hh := count_true_bound (score3_vals5 E)
    change countTrue (score3_vals5 E)≤5 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬6≤countTrue (score3_vals5 E)
    omega
  have T0 := score3_threshold5_4 E
  exact threshold_step (g380 E) (!g1 E) (g1701 E) 5 (countTrue (score3_vals5 E)) T1 T0
theorem score3_threshold7_5 (E : Nat→Bool) : ((!g1722 E)=true) ↔ 6≤countTrue (score3_vals7 E) := by
  have rew : (!g1722 E) = ((g1711 E) || ((g387 E) && (!g1710 E))) := by simp [g1,g1721,g1722,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold6_5 E
  have T0 := score3_threshold6_4 E
  exact threshold_step (g387 E) (g1711 E) (!g1710 E) 5 (countTrue (score3_vals6 E)) T1 T0
theorem score3_threshold8_5 (E : Nat→Bool) : ((!g1734 E)=true) ↔ 6≤countTrue (score3_vals8 E) := by
  have rew : (!g1734 E) = ((!g1722 E) || ((g392 E) && (!g1720 E))) := by simp [g1,g1733,g1734,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold7_5 E
  have T0 := score3_threshold7_4 E
  exact threshold_step (g392 E) (!g1722 E) (!g1720 E) 5 (countTrue (score3_vals7 E)) T1 T0
theorem score3_threshold9_5 (E : Nat→Bool) : ((!g1748 E)=true) ↔ 6≤countTrue (score3_vals9 E) := by
  have rew : (!g1748 E) = ((!g1734 E) || ((g393 E) && (!g1732 E))) := by simp [g1,g1747,g1748,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold8_5 E
  have T0 := score3_threshold8_4 E
  exact threshold_step (g393 E) (!g1734 E) (!g1732 E) 5 (countTrue (score3_vals8 E)) T1 T0
theorem score3_threshold10_5 (E : Nat→Bool) : ((!g1764 E)=true) ↔ 6≤countTrue (score3_vals10 E) := by
  have rew : (!g1764 E) = ((!g1748 E) || ((g394 E) && (!g1746 E))) := by simp [g1,g1763,g1764,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold9_5 E
  have T0 := score3_threshold9_4 E
  exact threshold_step (g394 E) (!g1748 E) (!g1746 E) 5 (countTrue (score3_vals9 E)) T1 T0
theorem score3_threshold11_5 (E : Nat→Bool) : ((!g1782 E)=true) ↔ 6≤countTrue (score3_vals11 E) := by
  have rew : (!g1782 E) = ((!g1764 E) || ((g395 E) && (!g1762 E))) := by simp [g1,g1781,g1782,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold10_5 E
  have T0 := score3_threshold10_4 E
  exact threshold_step (g395 E) (!g1764 E) (!g1762 E) 5 (countTrue (score3_vals10 E)) T1 T0
theorem score3_threshold12_5 (E : Nat→Bool) : ((!g1802 E)=true) ↔ 6≤countTrue (score3_vals12 E) := by
  have rew : (!g1802 E) = ((!g1782 E) || ((g402 E) && (!g1780 E))) := by simp [g1,g1801,g1802,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold11_5 E
  have T0 := score3_threshold11_4 E
  exact threshold_step (g402 E) (!g1782 E) (!g1780 E) 5 (countTrue (score3_vals11 E)) T1 T0
theorem score3_threshold13_5 (E : Nat→Bool) : ((!g1824 E)=true) ↔ 6≤countTrue (score3_vals13 E) := by
  have rew : (!g1824 E) = ((!g1802 E) || ((g403 E) && (!g1800 E))) := by simp [g1,g1823,g1824,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold12_5 E
  have T0 := score3_threshold12_4 E
  exact threshold_step (g403 E) (!g1802 E) (!g1800 E) 5 (countTrue (score3_vals12 E)) T1 T0
theorem score3_threshold14_5 (E : Nat→Bool) : ((!g1848 E)=true) ↔ 6≤countTrue (score3_vals14 E) := by
  have rew : (!g1848 E) = ((!g1824 E) || ((g404 E) && (!g1822 E))) := by simp [g1,g1847,g1848,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold13_5 E
  have T0 := score3_threshold13_4 E
  exact threshold_step (g404 E) (!g1824 E) (!g1822 E) 5 (countTrue (score3_vals13 E)) T1 T0
theorem score3_threshold15_5 (E : Nat→Bool) : ((!g1874 E)=true) ↔ 6≤countTrue (score3_vals15 E) := by
  have rew : (!g1874 E) = ((!g1848 E) || ((g405 E) && (!g1846 E))) := by simp [g1,g1873,g1874,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold14_5 E
  have T0 := score3_threshold14_4 E
  exact threshold_step (g405 E) (!g1848 E) (!g1846 E) 5 (countTrue (score3_vals14 E)) T1 T0
theorem score3_threshold16_5 (E : Nat→Bool) : ((!g1902 E)=true) ↔ 6≤countTrue (score3_vals16 E) := by
  have rew : (!g1902 E) = ((!g1874 E) || ((g412 E) && (!g1872 E))) := by simp [g1,g1901,g1902,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold15_5 E
  have T0 := score3_threshold15_4 E
  exact threshold_step (g412 E) (!g1874 E) (!g1872 E) 5 (countTrue (score3_vals15 E)) T1 T0
theorem score3_threshold17_5 (E : Nat→Bool) : ((!g1932 E)=true) ↔ 6≤countTrue (score3_vals17 E) := by
  have rew : (!g1932 E) = ((!g1902 E) || ((g413 E) && (!g1900 E))) := by simp [g1,g1931,g1932,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold16_5 E
  have T0 := score3_threshold16_4 E
  exact threshold_step (g413 E) (!g1902 E) (!g1900 E) 5 (countTrue (score3_vals16 E)) T1 T0
theorem score3_threshold18_5 (E : Nat→Bool) : ((!g1964 E)=true) ↔ 6≤countTrue (score3_vals18 E) := by
  have rew : (!g1964 E) = ((!g1932 E) || ((g414 E) && (!g1930 E))) := by simp [g1,g1963,g1964,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold17_5 E
  have T0 := score3_threshold17_4 E
  exact threshold_step (g414 E) (!g1932 E) (!g1930 E) 5 (countTrue (score3_vals17 E)) T1 T0
theorem score3_threshold19_5 (E : Nat→Bool) : ((!g1998 E)=true) ↔ 6≤countTrue (score3_vals19 E) := by
  have rew : (!g1998 E) = ((!g1964 E) || ((g415 E) && (!g1962 E))) := by simp [g1,g1997,g1998,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold18_5 E
  have T0 := score3_threshold18_4 E
  exact threshold_step (g415 E) (!g1964 E) (!g1962 E) 5 (countTrue (score3_vals18 E)) T1 T0
theorem score3_threshold20_5 (E : Nat→Bool) : ((!g2034 E)=true) ↔ 6≤countTrue (score3_vals20 E) := by
  have rew : (!g2034 E) = ((!g1998 E) || ((g416 E) && (!g1996 E))) := by simp [g1,g2033,g2034,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold19_5 E
  have T0 := score3_threshold19_4 E
  exact threshold_step (g416 E) (!g1998 E) (!g1996 E) 5 (countTrue (score3_vals19 E)) T1 T0
theorem score3_threshold21_5 (E : Nat→Bool) : ((!g2072 E)=true) ↔ 6≤countTrue (score3_vals21 E) := by
  have rew : (!g2072 E) = ((!g2034 E) || ((g417 E) && (!g2032 E))) := by simp [g1,g2071,g2072,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold20_5 E
  have T0 := score3_threshold20_4 E
  exact threshold_step (g417 E) (!g2034 E) (!g2032 E) 5 (countTrue (score3_vals20 E)) T1 T0
theorem score3_threshold7_6 (E : Nat→Bool) : ((g1723 E)=true) ↔ 7≤countTrue (score3_vals7 E) := by
  have rew : (g1723 E) = ((!g1 E) || ((g387 E) && (g1711 E))) := by simp [g1,g1723,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 7≤countTrue (score3_vals6 E) := by
    have hh := count_true_bound (score3_vals6 E)
    change countTrue (score3_vals6 E)≤6 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬7≤countTrue (score3_vals6 E)
    omega
  have T0 := score3_threshold6_5 E
  exact threshold_step (g387 E) (!g1 E) (g1711 E) 6 (countTrue (score3_vals6 E)) T1 T0
theorem score3_threshold8_6 (E : Nat→Bool) : ((!g1736 E)=true) ↔ 7≤countTrue (score3_vals8 E) := by
  have rew : (!g1736 E) = ((g1723 E) || ((g392 E) && (!g1722 E))) := by simp [g1,g1735,g1736,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold7_6 E
  have T0 := score3_threshold7_5 E
  exact threshold_step (g392 E) (g1723 E) (!g1722 E) 6 (countTrue (score3_vals7 E)) T1 T0
theorem score3_threshold9_6 (E : Nat→Bool) : ((!g1750 E)=true) ↔ 7≤countTrue (score3_vals9 E) := by
  have rew : (!g1750 E) = ((!g1736 E) || ((g393 E) && (!g1734 E))) := by simp [g1,g1749,g1750,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold8_6 E
  have T0 := score3_threshold8_5 E
  exact threshold_step (g393 E) (!g1736 E) (!g1734 E) 6 (countTrue (score3_vals8 E)) T1 T0
theorem score3_threshold10_6 (E : Nat→Bool) : ((!g1766 E)=true) ↔ 7≤countTrue (score3_vals10 E) := by
  have rew : (!g1766 E) = ((!g1750 E) || ((g394 E) && (!g1748 E))) := by simp [g1,g1765,g1766,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold9_6 E
  have T0 := score3_threshold9_5 E
  exact threshold_step (g394 E) (!g1750 E) (!g1748 E) 6 (countTrue (score3_vals9 E)) T1 T0
theorem score3_threshold11_6 (E : Nat→Bool) : ((!g1784 E)=true) ↔ 7≤countTrue (score3_vals11 E) := by
  have rew : (!g1784 E) = ((!g1766 E) || ((g395 E) && (!g1764 E))) := by simp [g1,g1783,g1784,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold10_6 E
  have T0 := score3_threshold10_5 E
  exact threshold_step (g395 E) (!g1766 E) (!g1764 E) 6 (countTrue (score3_vals10 E)) T1 T0
theorem score3_threshold12_6 (E : Nat→Bool) : ((!g1804 E)=true) ↔ 7≤countTrue (score3_vals12 E) := by
  have rew : (!g1804 E) = ((!g1784 E) || ((g402 E) && (!g1782 E))) := by simp [g1,g1803,g1804,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold11_6 E
  have T0 := score3_threshold11_5 E
  exact threshold_step (g402 E) (!g1784 E) (!g1782 E) 6 (countTrue (score3_vals11 E)) T1 T0
theorem score3_threshold13_6 (E : Nat→Bool) : ((!g1826 E)=true) ↔ 7≤countTrue (score3_vals13 E) := by
  have rew : (!g1826 E) = ((!g1804 E) || ((g403 E) && (!g1802 E))) := by simp [g1,g1825,g1826,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold12_6 E
  have T0 := score3_threshold12_5 E
  exact threshold_step (g403 E) (!g1804 E) (!g1802 E) 6 (countTrue (score3_vals12 E)) T1 T0
theorem score3_threshold14_6 (E : Nat→Bool) : ((!g1850 E)=true) ↔ 7≤countTrue (score3_vals14 E) := by
  have rew : (!g1850 E) = ((!g1826 E) || ((g404 E) && (!g1824 E))) := by simp [g1,g1849,g1850,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold13_6 E
  have T0 := score3_threshold13_5 E
  exact threshold_step (g404 E) (!g1826 E) (!g1824 E) 6 (countTrue (score3_vals13 E)) T1 T0
theorem score3_threshold15_6 (E : Nat→Bool) : ((!g1876 E)=true) ↔ 7≤countTrue (score3_vals15 E) := by
  have rew : (!g1876 E) = ((!g1850 E) || ((g405 E) && (!g1848 E))) := by simp [g1,g1875,g1876,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold14_6 E
  have T0 := score3_threshold14_5 E
  exact threshold_step (g405 E) (!g1850 E) (!g1848 E) 6 (countTrue (score3_vals14 E)) T1 T0
theorem score3_threshold16_6 (E : Nat→Bool) : ((!g1904 E)=true) ↔ 7≤countTrue (score3_vals16 E) := by
  have rew : (!g1904 E) = ((!g1876 E) || ((g412 E) && (!g1874 E))) := by simp [g1,g1903,g1904,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold15_6 E
  have T0 := score3_threshold15_5 E
  exact threshold_step (g412 E) (!g1876 E) (!g1874 E) 6 (countTrue (score3_vals15 E)) T1 T0
theorem score3_threshold17_6 (E : Nat→Bool) : ((!g1934 E)=true) ↔ 7≤countTrue (score3_vals17 E) := by
  have rew : (!g1934 E) = ((!g1904 E) || ((g413 E) && (!g1902 E))) := by simp [g1,g1933,g1934,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold16_6 E
  have T0 := score3_threshold16_5 E
  exact threshold_step (g413 E) (!g1904 E) (!g1902 E) 6 (countTrue (score3_vals16 E)) T1 T0
theorem score3_threshold18_6 (E : Nat→Bool) : ((!g1966 E)=true) ↔ 7≤countTrue (score3_vals18 E) := by
  have rew : (!g1966 E) = ((!g1934 E) || ((g414 E) && (!g1932 E))) := by simp [g1,g1965,g1966,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold17_6 E
  have T0 := score3_threshold17_5 E
  exact threshold_step (g414 E) (!g1934 E) (!g1932 E) 6 (countTrue (score3_vals17 E)) T1 T0
theorem score3_threshold19_6 (E : Nat→Bool) : ((!g2000 E)=true) ↔ 7≤countTrue (score3_vals19 E) := by
  have rew : (!g2000 E) = ((!g1966 E) || ((g415 E) && (!g1964 E))) := by simp [g1,g1999,g2000,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold18_6 E
  have T0 := score3_threshold18_5 E
  exact threshold_step (g415 E) (!g1966 E) (!g1964 E) 6 (countTrue (score3_vals18 E)) T1 T0
theorem score3_threshold20_6 (E : Nat→Bool) : ((!g2036 E)=true) ↔ 7≤countTrue (score3_vals20 E) := by
  have rew : (!g2036 E) = ((!g2000 E) || ((g416 E) && (!g1998 E))) := by simp [g1,g2035,g2036,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold19_6 E
  have T0 := score3_threshold19_5 E
  exact threshold_step (g416 E) (!g2000 E) (!g1998 E) 6 (countTrue (score3_vals19 E)) T1 T0
theorem score3_threshold21_6 (E : Nat→Bool) : ((!g2074 E)=true) ↔ 7≤countTrue (score3_vals21 E) := by
  have rew : (!g2074 E) = ((!g2036 E) || ((g417 E) && (!g2034 E))) := by simp [g1,g2073,g2074,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold20_6 E
  have T0 := score3_threshold20_5 E
  exact threshold_step (g417 E) (!g2036 E) (!g2034 E) 6 (countTrue (score3_vals20 E)) T1 T0
theorem score3_threshold8_7 (E : Nat→Bool) : ((g1737 E)=true) ↔ 8≤countTrue (score3_vals8 E) := by
  have rew : (g1737 E) = ((!g1 E) || ((g392 E) && (g1723 E))) := by simp [g1,g1737,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 8≤countTrue (score3_vals7 E) := by
    have hh := count_true_bound (score3_vals7 E)
    change countTrue (score3_vals7 E)≤7 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬8≤countTrue (score3_vals7 E)
    omega
  have T0 := score3_threshold7_6 E
  exact threshold_step (g392 E) (!g1 E) (g1723 E) 7 (countTrue (score3_vals7 E)) T1 T0
theorem score3_threshold9_7 (E : Nat→Bool) : ((!g1752 E)=true) ↔ 8≤countTrue (score3_vals9 E) := by
  have rew : (!g1752 E) = ((g1737 E) || ((g393 E) && (!g1736 E))) := by simp [g1,g1751,g1752,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold8_7 E
  have T0 := score3_threshold8_6 E
  exact threshold_step (g393 E) (g1737 E) (!g1736 E) 7 (countTrue (score3_vals8 E)) T1 T0
theorem score3_threshold10_7 (E : Nat→Bool) : ((!g1768 E)=true) ↔ 8≤countTrue (score3_vals10 E) := by
  have rew : (!g1768 E) = ((!g1752 E) || ((g394 E) && (!g1750 E))) := by simp [g1,g1767,g1768,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold9_7 E
  have T0 := score3_threshold9_6 E
  exact threshold_step (g394 E) (!g1752 E) (!g1750 E) 7 (countTrue (score3_vals9 E)) T1 T0
theorem score3_threshold11_7 (E : Nat→Bool) : ((!g1786 E)=true) ↔ 8≤countTrue (score3_vals11 E) := by
  have rew : (!g1786 E) = ((!g1768 E) || ((g395 E) && (!g1766 E))) := by simp [g1,g1785,g1786,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold10_7 E
  have T0 := score3_threshold10_6 E
  exact threshold_step (g395 E) (!g1768 E) (!g1766 E) 7 (countTrue (score3_vals10 E)) T1 T0
theorem score3_threshold12_7 (E : Nat→Bool) : ((!g1806 E)=true) ↔ 8≤countTrue (score3_vals12 E) := by
  have rew : (!g1806 E) = ((!g1786 E) || ((g402 E) && (!g1784 E))) := by simp [g1,g1805,g1806,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold11_7 E
  have T0 := score3_threshold11_6 E
  exact threshold_step (g402 E) (!g1786 E) (!g1784 E) 7 (countTrue (score3_vals11 E)) T1 T0
theorem score3_threshold13_7 (E : Nat→Bool) : ((!g1828 E)=true) ↔ 8≤countTrue (score3_vals13 E) := by
  have rew : (!g1828 E) = ((!g1806 E) || ((g403 E) && (!g1804 E))) := by simp [g1,g1827,g1828,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold12_7 E
  have T0 := score3_threshold12_6 E
  exact threshold_step (g403 E) (!g1806 E) (!g1804 E) 7 (countTrue (score3_vals12 E)) T1 T0
theorem score3_threshold14_7 (E : Nat→Bool) : ((!g1852 E)=true) ↔ 8≤countTrue (score3_vals14 E) := by
  have rew : (!g1852 E) = ((!g1828 E) || ((g404 E) && (!g1826 E))) := by simp [g1,g1851,g1852,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold13_7 E
  have T0 := score3_threshold13_6 E
  exact threshold_step (g404 E) (!g1828 E) (!g1826 E) 7 (countTrue (score3_vals13 E)) T1 T0
theorem score3_threshold15_7 (E : Nat→Bool) : ((!g1878 E)=true) ↔ 8≤countTrue (score3_vals15 E) := by
  have rew : (!g1878 E) = ((!g1852 E) || ((g405 E) && (!g1850 E))) := by simp [g1,g1877,g1878,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold14_7 E
  have T0 := score3_threshold14_6 E
  exact threshold_step (g405 E) (!g1852 E) (!g1850 E) 7 (countTrue (score3_vals14 E)) T1 T0
theorem score3_threshold16_7 (E : Nat→Bool) : ((!g1906 E)=true) ↔ 8≤countTrue (score3_vals16 E) := by
  have rew : (!g1906 E) = ((!g1878 E) || ((g412 E) && (!g1876 E))) := by simp [g1,g1905,g1906,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold15_7 E
  have T0 := score3_threshold15_6 E
  exact threshold_step (g412 E) (!g1878 E) (!g1876 E) 7 (countTrue (score3_vals15 E)) T1 T0
theorem score3_threshold17_7 (E : Nat→Bool) : ((!g1936 E)=true) ↔ 8≤countTrue (score3_vals17 E) := by
  have rew : (!g1936 E) = ((!g1906 E) || ((g413 E) && (!g1904 E))) := by simp [g1,g1935,g1936,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold16_7 E
  have T0 := score3_threshold16_6 E
  exact threshold_step (g413 E) (!g1906 E) (!g1904 E) 7 (countTrue (score3_vals16 E)) T1 T0
theorem score3_threshold18_7 (E : Nat→Bool) : ((!g1968 E)=true) ↔ 8≤countTrue (score3_vals18 E) := by
  have rew : (!g1968 E) = ((!g1936 E) || ((g414 E) && (!g1934 E))) := by simp [g1,g1967,g1968,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold17_7 E
  have T0 := score3_threshold17_6 E
  exact threshold_step (g414 E) (!g1936 E) (!g1934 E) 7 (countTrue (score3_vals17 E)) T1 T0
theorem score3_threshold19_7 (E : Nat→Bool) : ((!g2002 E)=true) ↔ 8≤countTrue (score3_vals19 E) := by
  have rew : (!g2002 E) = ((!g1968 E) || ((g415 E) && (!g1966 E))) := by simp [g1,g2001,g2002,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold18_7 E
  have T0 := score3_threshold18_6 E
  exact threshold_step (g415 E) (!g1968 E) (!g1966 E) 7 (countTrue (score3_vals18 E)) T1 T0
theorem score3_threshold20_7 (E : Nat→Bool) : ((!g2038 E)=true) ↔ 8≤countTrue (score3_vals20 E) := by
  have rew : (!g2038 E) = ((!g2002 E) || ((g416 E) && (!g2000 E))) := by simp [g1,g2037,g2038,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold19_7 E
  have T0 := score3_threshold19_6 E
  exact threshold_step (g416 E) (!g2002 E) (!g2000 E) 7 (countTrue (score3_vals19 E)) T1 T0
theorem score3_threshold21_7 (E : Nat→Bool) : ((!g2076 E)=true) ↔ 8≤countTrue (score3_vals21 E) := by
  have rew : (!g2076 E) = ((!g2038 E) || ((g417 E) && (!g2036 E))) := by simp [g1,g2075,g2076,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold20_7 E
  have T0 := score3_threshold20_6 E
  exact threshold_step (g417 E) (!g2038 E) (!g2036 E) 7 (countTrue (score3_vals20 E)) T1 T0
theorem score3_threshold9_8 (E : Nat→Bool) : ((g1753 E)=true) ↔ 9≤countTrue (score3_vals9 E) := by
  have rew : (g1753 E) = ((!g1 E) || ((g393 E) && (g1737 E))) := by simp [g1,g1753,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 9≤countTrue (score3_vals8 E) := by
    have hh := count_true_bound (score3_vals8 E)
    change countTrue (score3_vals8 E)≤8 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬9≤countTrue (score3_vals8 E)
    omega
  have T0 := score3_threshold8_7 E
  exact threshold_step (g393 E) (!g1 E) (g1737 E) 8 (countTrue (score3_vals8 E)) T1 T0
theorem score3_threshold10_8 (E : Nat→Bool) : ((!g1770 E)=true) ↔ 9≤countTrue (score3_vals10 E) := by
  have rew : (!g1770 E) = ((g1753 E) || ((g394 E) && (!g1752 E))) := by simp [g1,g1769,g1770,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold9_8 E
  have T0 := score3_threshold9_7 E
  exact threshold_step (g394 E) (g1753 E) (!g1752 E) 8 (countTrue (score3_vals9 E)) T1 T0
theorem score3_threshold11_8 (E : Nat→Bool) : ((!g1788 E)=true) ↔ 9≤countTrue (score3_vals11 E) := by
  have rew : (!g1788 E) = ((!g1770 E) || ((g395 E) && (!g1768 E))) := by simp [g1,g1787,g1788,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold10_8 E
  have T0 := score3_threshold10_7 E
  exact threshold_step (g395 E) (!g1770 E) (!g1768 E) 8 (countTrue (score3_vals10 E)) T1 T0
theorem score3_threshold12_8 (E : Nat→Bool) : ((!g1808 E)=true) ↔ 9≤countTrue (score3_vals12 E) := by
  have rew : (!g1808 E) = ((!g1788 E) || ((g402 E) && (!g1786 E))) := by simp [g1,g1807,g1808,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold11_8 E
  have T0 := score3_threshold11_7 E
  exact threshold_step (g402 E) (!g1788 E) (!g1786 E) 8 (countTrue (score3_vals11 E)) T1 T0
theorem score3_threshold13_8 (E : Nat→Bool) : ((!g1830 E)=true) ↔ 9≤countTrue (score3_vals13 E) := by
  have rew : (!g1830 E) = ((!g1808 E) || ((g403 E) && (!g1806 E))) := by simp [g1,g1829,g1830,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold12_8 E
  have T0 := score3_threshold12_7 E
  exact threshold_step (g403 E) (!g1808 E) (!g1806 E) 8 (countTrue (score3_vals12 E)) T1 T0
theorem score3_threshold14_8 (E : Nat→Bool) : ((!g1854 E)=true) ↔ 9≤countTrue (score3_vals14 E) := by
  have rew : (!g1854 E) = ((!g1830 E) || ((g404 E) && (!g1828 E))) := by simp [g1,g1853,g1854,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold13_8 E
  have T0 := score3_threshold13_7 E
  exact threshold_step (g404 E) (!g1830 E) (!g1828 E) 8 (countTrue (score3_vals13 E)) T1 T0
theorem score3_threshold15_8 (E : Nat→Bool) : ((!g1880 E)=true) ↔ 9≤countTrue (score3_vals15 E) := by
  have rew : (!g1880 E) = ((!g1854 E) || ((g405 E) && (!g1852 E))) := by simp [g1,g1879,g1880,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold14_8 E
  have T0 := score3_threshold14_7 E
  exact threshold_step (g405 E) (!g1854 E) (!g1852 E) 8 (countTrue (score3_vals14 E)) T1 T0
theorem score3_threshold16_8 (E : Nat→Bool) : ((!g1908 E)=true) ↔ 9≤countTrue (score3_vals16 E) := by
  have rew : (!g1908 E) = ((!g1880 E) || ((g412 E) && (!g1878 E))) := by simp [g1,g1907,g1908,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold15_8 E
  have T0 := score3_threshold15_7 E
  exact threshold_step (g412 E) (!g1880 E) (!g1878 E) 8 (countTrue (score3_vals15 E)) T1 T0
theorem score3_threshold17_8 (E : Nat→Bool) : ((!g1938 E)=true) ↔ 9≤countTrue (score3_vals17 E) := by
  have rew : (!g1938 E) = ((!g1908 E) || ((g413 E) && (!g1906 E))) := by simp [g1,g1937,g1938,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold16_8 E
  have T0 := score3_threshold16_7 E
  exact threshold_step (g413 E) (!g1908 E) (!g1906 E) 8 (countTrue (score3_vals16 E)) T1 T0
theorem score3_threshold18_8 (E : Nat→Bool) : ((!g1970 E)=true) ↔ 9≤countTrue (score3_vals18 E) := by
  have rew : (!g1970 E) = ((!g1938 E) || ((g414 E) && (!g1936 E))) := by simp [g1,g1969,g1970,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold17_8 E
  have T0 := score3_threshold17_7 E
  exact threshold_step (g414 E) (!g1938 E) (!g1936 E) 8 (countTrue (score3_vals17 E)) T1 T0
theorem score3_threshold19_8 (E : Nat→Bool) : ((!g2004 E)=true) ↔ 9≤countTrue (score3_vals19 E) := by
  have rew : (!g2004 E) = ((!g1970 E) || ((g415 E) && (!g1968 E))) := by simp [g1,g2003,g2004,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold18_8 E
  have T0 := score3_threshold18_7 E
  exact threshold_step (g415 E) (!g1970 E) (!g1968 E) 8 (countTrue (score3_vals18 E)) T1 T0
theorem score3_threshold20_8 (E : Nat→Bool) : ((!g2040 E)=true) ↔ 9≤countTrue (score3_vals20 E) := by
  have rew : (!g2040 E) = ((!g2004 E) || ((g416 E) && (!g2002 E))) := by simp [g1,g2039,g2040,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold19_8 E
  have T0 := score3_threshold19_7 E
  exact threshold_step (g416 E) (!g2004 E) (!g2002 E) 8 (countTrue (score3_vals19 E)) T1 T0
theorem score3_threshold21_8 (E : Nat→Bool) : ((!g2078 E)=true) ↔ 9≤countTrue (score3_vals21 E) := by
  have rew : (!g2078 E) = ((!g2040 E) || ((g417 E) && (!g2038 E))) := by simp [g1,g2077,g2078,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score3_threshold20_8 E
  have T0 := score3_threshold20_7 E
  exact threshold_step (g417 E) (!g2040 E) (!g2038 E) 8 (countTrue (score3_vals20 E)) T1 T0
def score3_count (E : Nat→Bool) : Nat := countTrue (score3_vals21 E)
def score4_vals1 (E : Nat→Bool) : List Bool := (g368 E) :: ([])
def score4_vals2 (E : Nat→Bool) : List Bool := (g373 E) :: (score4_vals1 E)
def score4_vals3 (E : Nat→Bool) : List Bool := (g377 E) :: (score4_vals2 E)
def score4_vals4 (E : Nat→Bool) : List Bool := (g381 E) :: (score4_vals3 E)
def score4_vals5 (E : Nat→Bool) : List Bool := (g382 E) :: (score4_vals4 E)
def score4_vals6 (E : Nat→Bool) : List Bool := (g383 E) :: (score4_vals5 E)
def score4_vals7 (E : Nat→Bool) : List Bool := (g388 E) :: (score4_vals6 E)
def score4_vals8 (E : Nat→Bool) : List Bool := (g392 E) :: (score4_vals7 E)
def score4_vals9 (E : Nat→Bool) : List Bool := (g396 E) :: (score4_vals8 E)
def score4_vals10 (E : Nat→Bool) : List Bool := (g397 E) :: (score4_vals9 E)
def score4_vals11 (E : Nat→Bool) : List Bool := (g398 E) :: (score4_vals10 E)
def score4_vals12 (E : Nat→Bool) : List Bool := (g402 E) :: (score4_vals11 E)
def score4_vals13 (E : Nat→Bool) : List Bool := (g406 E) :: (score4_vals12 E)
def score4_vals14 (E : Nat→Bool) : List Bool := (g407 E) :: (score4_vals13 E)
def score4_vals15 (E : Nat→Bool) : List Bool := (g408 E) :: (score4_vals14 E)
def score4_vals16 (E : Nat→Bool) : List Bool := (g412 E) :: (score4_vals15 E)
def score4_vals17 (E : Nat→Bool) : List Bool := (g413 E) :: (score4_vals16 E)
def score4_vals18 (E : Nat→Bool) : List Bool := (g414 E) :: (score4_vals17 E)
def score4_vals19 (E : Nat→Bool) : List Bool := (g418 E) :: (score4_vals18 E)
def score4_vals20 (E : Nat→Bool) : List Bool := (g419 E) :: (score4_vals19 E)
def score4_vals21 (E : Nat→Bool) : List Bool := (g420 E) :: (score4_vals20 E)
theorem score4_threshold1_0 (E : Nat→Bool) : ((g368 E)=true) ↔ 1≤countTrue (score4_vals1 E) := by
  have rew : (g368 E) = ((!g1 E) || ((g368 E) && (g1 E))) := by simp [g1,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 1≤countTrue ([] : List Bool) := by
    have hh := count_true_bound ([] : List Bool)
    change countTrue ([] : List Bool)≤0 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬1≤countTrue ([] : List Bool)
    omega
  have T0 : (g1 E)=true ↔ 0≤countTrue ([] : List Bool) := by simp [g1]
  exact threshold_step (g368 E) (!g1 E) (g1 E) 0 (countTrue ([] : List Bool)) T1 T0
theorem score4_threshold2_1 (E : Nat→Bool) : ((g2103 E)=true) ↔ 2≤countTrue (score4_vals2 E) := by
  have rew : (g2103 E) = ((!g1 E) || ((g373 E) && (g368 E))) := by simp [g1,g2103,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 2≤countTrue (score4_vals1 E) := by
    have hh := count_true_bound (score4_vals1 E)
    change countTrue (score4_vals1 E)≤1 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬2≤countTrue (score4_vals1 E)
    omega
  have T0 := score4_threshold1_0 E
  exact threshold_step (g373 E) (!g1 E) (g368 E) 1 (countTrue (score4_vals1 E)) T1 T0
theorem score4_threshold3_2 (E : Nat→Bool) : ((g2107 E)=true) ↔ 3≤countTrue (score4_vals3 E) := by
  have rew : (g2107 E) = ((!g1 E) || ((g377 E) && (g2103 E))) := by simp [g1,g2107,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 3≤countTrue (score4_vals2 E) := by
    have hh := count_true_bound (score4_vals2 E)
    change countTrue (score4_vals2 E)≤2 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬3≤countTrue (score4_vals2 E)
    omega
  have T0 := score4_threshold2_1 E
  exact threshold_step (g377 E) (!g1 E) (g2103 E) 2 (countTrue (score4_vals2 E)) T1 T0
theorem score4_threshold4_3 (E : Nat→Bool) : ((g2113 E)=true) ↔ 4≤countTrue (score4_vals4 E) := by
  have rew : (g2113 E) = ((!g1 E) || ((g381 E) && (g2107 E))) := by simp [g1,g2113,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 4≤countTrue (score4_vals3 E) := by
    have hh := count_true_bound (score4_vals3 E)
    change countTrue (score4_vals3 E)≤3 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬4≤countTrue (score4_vals3 E)
    omega
  have T0 := score4_threshold3_2 E
  exact threshold_step (g381 E) (!g1 E) (g2107 E) 3 (countTrue (score4_vals3 E)) T1 T0
theorem score4_threshold5_4 (E : Nat→Bool) : ((g2121 E)=true) ↔ 5≤countTrue (score4_vals5 E) := by
  have rew : (g2121 E) = ((!g1 E) || ((g382 E) && (g2113 E))) := by simp [g1,g2121,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 5≤countTrue (score4_vals4 E) := by
    have hh := count_true_bound (score4_vals4 E)
    change countTrue (score4_vals4 E)≤4 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬5≤countTrue (score4_vals4 E)
    omega
  have T0 := score4_threshold4_3 E
  exact threshold_step (g382 E) (!g1 E) (g2113 E) 4 (countTrue (score4_vals4 E)) T1 T0
theorem score4_threshold2_0 (E : Nat→Bool) : ((!g2102 E)=true) ↔ 1≤countTrue (score4_vals2 E) := by
  have rew : (!g2102 E) = ((g368 E) || ((g373 E) && (g1 E))) := by simp [g1,g2102,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold1_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score4_vals1 E) := by simp [g1]
  exact threshold_step (g373 E) (g368 E) (g1 E) 0 (countTrue (score4_vals1 E)) T1 T0
theorem score4_threshold3_1 (E : Nat→Bool) : ((!g2106 E)=true) ↔ 2≤countTrue (score4_vals3 E) := by
  have rew : (!g2106 E) = ((g2103 E) || ((g377 E) && (!g2102 E))) := by simp [g1,g2105,g2106,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold2_1 E
  have T0 := score4_threshold2_0 E
  exact threshold_step (g377 E) (g2103 E) (!g2102 E) 1 (countTrue (score4_vals2 E)) T1 T0
theorem score4_threshold4_2 (E : Nat→Bool) : ((!g2112 E)=true) ↔ 3≤countTrue (score4_vals4 E) := by
  have rew : (!g2112 E) = ((g2107 E) || ((g381 E) && (!g2106 E))) := by simp [g1,g2111,g2112,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold3_2 E
  have T0 := score4_threshold3_1 E
  exact threshold_step (g381 E) (g2107 E) (!g2106 E) 2 (countTrue (score4_vals3 E)) T1 T0
theorem score4_threshold5_3 (E : Nat→Bool) : ((!g2120 E)=true) ↔ 4≤countTrue (score4_vals5 E) := by
  have rew : (!g2120 E) = ((g2113 E) || ((g382 E) && (!g2112 E))) := by simp [g1,g2119,g2120,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold4_3 E
  have T0 := score4_threshold4_2 E
  exact threshold_step (g382 E) (g2113 E) (!g2112 E) 3 (countTrue (score4_vals4 E)) T1 T0
theorem score4_threshold6_4 (E : Nat→Bool) : ((!g2130 E)=true) ↔ 5≤countTrue (score4_vals6 E) := by
  have rew : (!g2130 E) = ((g2121 E) || ((g383 E) && (!g2120 E))) := by simp [g1,g2129,g2130,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold5_4 E
  have T0 := score4_threshold5_3 E
  exact threshold_step (g383 E) (g2121 E) (!g2120 E) 4 (countTrue (score4_vals5 E)) T1 T0
theorem score4_threshold3_0 (E : Nat→Bool) : ((!g2104 E)=true) ↔ 1≤countTrue (score4_vals3 E) := by
  have rew : (!g2104 E) = ((!g2102 E) || ((g377 E) && (g1 E))) := by simp [g1,g2104,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold2_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score4_vals2 E) := by simp [g1]
  exact threshold_step (g377 E) (!g2102 E) (g1 E) 0 (countTrue (score4_vals2 E)) T1 T0
theorem score4_threshold4_1 (E : Nat→Bool) : ((!g2110 E)=true) ↔ 2≤countTrue (score4_vals4 E) := by
  have rew : (!g2110 E) = ((!g2106 E) || ((g381 E) && (!g2104 E))) := by simp [g1,g2109,g2110,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold3_1 E
  have T0 := score4_threshold3_0 E
  exact threshold_step (g381 E) (!g2106 E) (!g2104 E) 1 (countTrue (score4_vals3 E)) T1 T0
theorem score4_threshold5_2 (E : Nat→Bool) : ((!g2118 E)=true) ↔ 3≤countTrue (score4_vals5 E) := by
  have rew : (!g2118 E) = ((!g2112 E) || ((g382 E) && (!g2110 E))) := by simp [g1,g2117,g2118,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold4_2 E
  have T0 := score4_threshold4_1 E
  exact threshold_step (g382 E) (!g2112 E) (!g2110 E) 2 (countTrue (score4_vals4 E)) T1 T0
theorem score4_threshold6_3 (E : Nat→Bool) : ((!g2128 E)=true) ↔ 4≤countTrue (score4_vals6 E) := by
  have rew : (!g2128 E) = ((!g2120 E) || ((g383 E) && (!g2118 E))) := by simp [g1,g2127,g2128,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold5_3 E
  have T0 := score4_threshold5_2 E
  exact threshold_step (g383 E) (!g2120 E) (!g2118 E) 3 (countTrue (score4_vals5 E)) T1 T0
theorem score4_threshold7_4 (E : Nat→Bool) : ((!g2140 E)=true) ↔ 5≤countTrue (score4_vals7 E) := by
  have rew : (!g2140 E) = ((!g2130 E) || ((g388 E) && (!g2128 E))) := by simp [g1,g2139,g2140,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold6_4 E
  have T0 := score4_threshold6_3 E
  exact threshold_step (g388 E) (!g2130 E) (!g2128 E) 4 (countTrue (score4_vals6 E)) T1 T0
theorem score4_threshold4_0 (E : Nat→Bool) : ((!g2108 E)=true) ↔ 1≤countTrue (score4_vals4 E) := by
  have rew : (!g2108 E) = ((!g2104 E) || ((g381 E) && (g1 E))) := by simp [g1,g2108,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold3_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score4_vals3 E) := by simp [g1]
  exact threshold_step (g381 E) (!g2104 E) (g1 E) 0 (countTrue (score4_vals3 E)) T1 T0
theorem score4_threshold5_1 (E : Nat→Bool) : ((!g2116 E)=true) ↔ 2≤countTrue (score4_vals5 E) := by
  have rew : (!g2116 E) = ((!g2110 E) || ((g382 E) && (!g2108 E))) := by simp [g1,g2115,g2116,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold4_1 E
  have T0 := score4_threshold4_0 E
  exact threshold_step (g382 E) (!g2110 E) (!g2108 E) 1 (countTrue (score4_vals4 E)) T1 T0
theorem score4_threshold6_2 (E : Nat→Bool) : ((!g2126 E)=true) ↔ 3≤countTrue (score4_vals6 E) := by
  have rew : (!g2126 E) = ((!g2118 E) || ((g383 E) && (!g2116 E))) := by simp [g1,g2125,g2126,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold5_2 E
  have T0 := score4_threshold5_1 E
  exact threshold_step (g383 E) (!g2118 E) (!g2116 E) 2 (countTrue (score4_vals5 E)) T1 T0
theorem score4_threshold7_3 (E : Nat→Bool) : ((!g2138 E)=true) ↔ 4≤countTrue (score4_vals7 E) := by
  have rew : (!g2138 E) = ((!g2128 E) || ((g388 E) && (!g2126 E))) := by simp [g1,g2137,g2138,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold6_3 E
  have T0 := score4_threshold6_2 E
  exact threshold_step (g388 E) (!g2128 E) (!g2126 E) 3 (countTrue (score4_vals6 E)) T1 T0
theorem score4_threshold8_4 (E : Nat→Bool) : ((!g2152 E)=true) ↔ 5≤countTrue (score4_vals8 E) := by
  have rew : (!g2152 E) = ((!g2140 E) || ((g392 E) && (!g2138 E))) := by simp [g1,g2151,g2152,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold7_4 E
  have T0 := score4_threshold7_3 E
  exact threshold_step (g392 E) (!g2140 E) (!g2138 E) 4 (countTrue (score4_vals7 E)) T1 T0
theorem score4_threshold5_0 (E : Nat→Bool) : ((!g2114 E)=true) ↔ 1≤countTrue (score4_vals5 E) := by
  have rew : (!g2114 E) = ((!g2108 E) || ((g382 E) && (g1 E))) := by simp [g1,g2114,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold4_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score4_vals4 E) := by simp [g1]
  exact threshold_step (g382 E) (!g2108 E) (g1 E) 0 (countTrue (score4_vals4 E)) T1 T0
theorem score4_threshold6_1 (E : Nat→Bool) : ((!g2124 E)=true) ↔ 2≤countTrue (score4_vals6 E) := by
  have rew : (!g2124 E) = ((!g2116 E) || ((g383 E) && (!g2114 E))) := by simp [g1,g2123,g2124,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold5_1 E
  have T0 := score4_threshold5_0 E
  exact threshold_step (g383 E) (!g2116 E) (!g2114 E) 1 (countTrue (score4_vals5 E)) T1 T0
theorem score4_threshold7_2 (E : Nat→Bool) : ((!g2136 E)=true) ↔ 3≤countTrue (score4_vals7 E) := by
  have rew : (!g2136 E) = ((!g2126 E) || ((g388 E) && (!g2124 E))) := by simp [g1,g2135,g2136,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold6_2 E
  have T0 := score4_threshold6_1 E
  exact threshold_step (g388 E) (!g2126 E) (!g2124 E) 2 (countTrue (score4_vals6 E)) T1 T0
theorem score4_threshold8_3 (E : Nat→Bool) : ((!g2150 E)=true) ↔ 4≤countTrue (score4_vals8 E) := by
  have rew : (!g2150 E) = ((!g2138 E) || ((g392 E) && (!g2136 E))) := by simp [g1,g2149,g2150,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold7_3 E
  have T0 := score4_threshold7_2 E
  exact threshold_step (g392 E) (!g2138 E) (!g2136 E) 3 (countTrue (score4_vals7 E)) T1 T0
theorem score4_threshold9_4 (E : Nat→Bool) : ((!g2166 E)=true) ↔ 5≤countTrue (score4_vals9 E) := by
  have rew : (!g2166 E) = ((!g2152 E) || ((g396 E) && (!g2150 E))) := by simp [g1,g2165,g2166,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold8_4 E
  have T0 := score4_threshold8_3 E
  exact threshold_step (g396 E) (!g2152 E) (!g2150 E) 4 (countTrue (score4_vals8 E)) T1 T0
theorem score4_threshold6_0 (E : Nat→Bool) : ((!g2122 E)=true) ↔ 1≤countTrue (score4_vals6 E) := by
  have rew : (!g2122 E) = ((!g2114 E) || ((g383 E) && (g1 E))) := by simp [g1,g2122,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold5_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score4_vals5 E) := by simp [g1]
  exact threshold_step (g383 E) (!g2114 E) (g1 E) 0 (countTrue (score4_vals5 E)) T1 T0
theorem score4_threshold7_1 (E : Nat→Bool) : ((!g2134 E)=true) ↔ 2≤countTrue (score4_vals7 E) := by
  have rew : (!g2134 E) = ((!g2124 E) || ((g388 E) && (!g2122 E))) := by simp [g1,g2133,g2134,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold6_1 E
  have T0 := score4_threshold6_0 E
  exact threshold_step (g388 E) (!g2124 E) (!g2122 E) 1 (countTrue (score4_vals6 E)) T1 T0
theorem score4_threshold8_2 (E : Nat→Bool) : ((!g2148 E)=true) ↔ 3≤countTrue (score4_vals8 E) := by
  have rew : (!g2148 E) = ((!g2136 E) || ((g392 E) && (!g2134 E))) := by simp [g1,g2147,g2148,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold7_2 E
  have T0 := score4_threshold7_1 E
  exact threshold_step (g392 E) (!g2136 E) (!g2134 E) 2 (countTrue (score4_vals7 E)) T1 T0
theorem score4_threshold9_3 (E : Nat→Bool) : ((!g2164 E)=true) ↔ 4≤countTrue (score4_vals9 E) := by
  have rew : (!g2164 E) = ((!g2150 E) || ((g396 E) && (!g2148 E))) := by simp [g1,g2163,g2164,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold8_3 E
  have T0 := score4_threshold8_2 E
  exact threshold_step (g396 E) (!g2150 E) (!g2148 E) 3 (countTrue (score4_vals8 E)) T1 T0
theorem score4_threshold10_4 (E : Nat→Bool) : ((!g2182 E)=true) ↔ 5≤countTrue (score4_vals10 E) := by
  have rew : (!g2182 E) = ((!g2166 E) || ((g397 E) && (!g2164 E))) := by simp [g1,g2181,g2182,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold9_4 E
  have T0 := score4_threshold9_3 E
  exact threshold_step (g397 E) (!g2166 E) (!g2164 E) 4 (countTrue (score4_vals9 E)) T1 T0
theorem score4_threshold7_0 (E : Nat→Bool) : ((!g2132 E)=true) ↔ 1≤countTrue (score4_vals7 E) := by
  have rew : (!g2132 E) = ((!g2122 E) || ((g388 E) && (g1 E))) := by simp [g1,g2132,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold6_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score4_vals6 E) := by simp [g1]
  exact threshold_step (g388 E) (!g2122 E) (g1 E) 0 (countTrue (score4_vals6 E)) T1 T0
theorem score4_threshold8_1 (E : Nat→Bool) : ((!g2146 E)=true) ↔ 2≤countTrue (score4_vals8 E) := by
  have rew : (!g2146 E) = ((!g2134 E) || ((g392 E) && (!g2132 E))) := by simp [g1,g2145,g2146,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold7_1 E
  have T0 := score4_threshold7_0 E
  exact threshold_step (g392 E) (!g2134 E) (!g2132 E) 1 (countTrue (score4_vals7 E)) T1 T0
theorem score4_threshold9_2 (E : Nat→Bool) : ((!g2162 E)=true) ↔ 3≤countTrue (score4_vals9 E) := by
  have rew : (!g2162 E) = ((!g2148 E) || ((g396 E) && (!g2146 E))) := by simp [g1,g2161,g2162,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold8_2 E
  have T0 := score4_threshold8_1 E
  exact threshold_step (g396 E) (!g2148 E) (!g2146 E) 2 (countTrue (score4_vals8 E)) T1 T0
theorem score4_threshold10_3 (E : Nat→Bool) : ((!g2180 E)=true) ↔ 4≤countTrue (score4_vals10 E) := by
  have rew : (!g2180 E) = ((!g2164 E) || ((g397 E) && (!g2162 E))) := by simp [g1,g2179,g2180,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold9_3 E
  have T0 := score4_threshold9_2 E
  exact threshold_step (g397 E) (!g2164 E) (!g2162 E) 3 (countTrue (score4_vals9 E)) T1 T0
theorem score4_threshold11_4 (E : Nat→Bool) : ((!g2200 E)=true) ↔ 5≤countTrue (score4_vals11 E) := by
  have rew : (!g2200 E) = ((!g2182 E) || ((g398 E) && (!g2180 E))) := by simp [g1,g2199,g2200,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold10_4 E
  have T0 := score4_threshold10_3 E
  exact threshold_step (g398 E) (!g2182 E) (!g2180 E) 4 (countTrue (score4_vals10 E)) T1 T0
theorem score4_threshold8_0 (E : Nat→Bool) : ((!g2144 E)=true) ↔ 1≤countTrue (score4_vals8 E) := by
  have rew : (!g2144 E) = ((!g2132 E) || ((g392 E) && (g1 E))) := by simp [g1,g2144,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold7_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score4_vals7 E) := by simp [g1]
  exact threshold_step (g392 E) (!g2132 E) (g1 E) 0 (countTrue (score4_vals7 E)) T1 T0
theorem score4_threshold9_1 (E : Nat→Bool) : ((!g2160 E)=true) ↔ 2≤countTrue (score4_vals9 E) := by
  have rew : (!g2160 E) = ((!g2146 E) || ((g396 E) && (!g2144 E))) := by simp [g1,g2159,g2160,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold8_1 E
  have T0 := score4_threshold8_0 E
  exact threshold_step (g396 E) (!g2146 E) (!g2144 E) 1 (countTrue (score4_vals8 E)) T1 T0
theorem score4_threshold10_2 (E : Nat→Bool) : ((!g2178 E)=true) ↔ 3≤countTrue (score4_vals10 E) := by
  have rew : (!g2178 E) = ((!g2162 E) || ((g397 E) && (!g2160 E))) := by simp [g1,g2177,g2178,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold9_2 E
  have T0 := score4_threshold9_1 E
  exact threshold_step (g397 E) (!g2162 E) (!g2160 E) 2 (countTrue (score4_vals9 E)) T1 T0
theorem score4_threshold11_3 (E : Nat→Bool) : ((!g2198 E)=true) ↔ 4≤countTrue (score4_vals11 E) := by
  have rew : (!g2198 E) = ((!g2180 E) || ((g398 E) && (!g2178 E))) := by simp [g1,g2197,g2198,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold10_3 E
  have T0 := score4_threshold10_2 E
  exact threshold_step (g398 E) (!g2180 E) (!g2178 E) 3 (countTrue (score4_vals10 E)) T1 T0
theorem score4_threshold12_4 (E : Nat→Bool) : ((!g2220 E)=true) ↔ 5≤countTrue (score4_vals12 E) := by
  have rew : (!g2220 E) = ((!g2200 E) || ((g402 E) && (!g2198 E))) := by simp [g1,g2219,g2220,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold11_4 E
  have T0 := score4_threshold11_3 E
  exact threshold_step (g402 E) (!g2200 E) (!g2198 E) 4 (countTrue (score4_vals11 E)) T1 T0
theorem score4_threshold9_0 (E : Nat→Bool) : ((!g2158 E)=true) ↔ 1≤countTrue (score4_vals9 E) := by
  have rew : (!g2158 E) = ((!g2144 E) || ((g396 E) && (g1 E))) := by simp [g1,g2158,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold8_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score4_vals8 E) := by simp [g1]
  exact threshold_step (g396 E) (!g2144 E) (g1 E) 0 (countTrue (score4_vals8 E)) T1 T0
theorem score4_threshold10_1 (E : Nat→Bool) : ((!g2176 E)=true) ↔ 2≤countTrue (score4_vals10 E) := by
  have rew : (!g2176 E) = ((!g2160 E) || ((g397 E) && (!g2158 E))) := by simp [g1,g2175,g2176,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold9_1 E
  have T0 := score4_threshold9_0 E
  exact threshold_step (g397 E) (!g2160 E) (!g2158 E) 1 (countTrue (score4_vals9 E)) T1 T0
theorem score4_threshold11_2 (E : Nat→Bool) : ((!g2196 E)=true) ↔ 3≤countTrue (score4_vals11 E) := by
  have rew : (!g2196 E) = ((!g2178 E) || ((g398 E) && (!g2176 E))) := by simp [g1,g2195,g2196,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold10_2 E
  have T0 := score4_threshold10_1 E
  exact threshold_step (g398 E) (!g2178 E) (!g2176 E) 2 (countTrue (score4_vals10 E)) T1 T0
theorem score4_threshold12_3 (E : Nat→Bool) : ((!g2218 E)=true) ↔ 4≤countTrue (score4_vals12 E) := by
  have rew : (!g2218 E) = ((!g2198 E) || ((g402 E) && (!g2196 E))) := by simp [g1,g2217,g2218,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold11_3 E
  have T0 := score4_threshold11_2 E
  exact threshold_step (g402 E) (!g2198 E) (!g2196 E) 3 (countTrue (score4_vals11 E)) T1 T0
theorem score4_threshold13_4 (E : Nat→Bool) : ((!g2242 E)=true) ↔ 5≤countTrue (score4_vals13 E) := by
  have rew : (!g2242 E) = ((!g2220 E) || ((g406 E) && (!g2218 E))) := by simp [g1,g2241,g2242,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold12_4 E
  have T0 := score4_threshold12_3 E
  exact threshold_step (g406 E) (!g2220 E) (!g2218 E) 4 (countTrue (score4_vals12 E)) T1 T0
theorem score4_threshold10_0 (E : Nat→Bool) : ((!g2174 E)=true) ↔ 1≤countTrue (score4_vals10 E) := by
  have rew : (!g2174 E) = ((!g2158 E) || ((g397 E) && (g1 E))) := by simp [g1,g2174,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold9_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score4_vals9 E) := by simp [g1]
  exact threshold_step (g397 E) (!g2158 E) (g1 E) 0 (countTrue (score4_vals9 E)) T1 T0
theorem score4_threshold11_1 (E : Nat→Bool) : ((!g2194 E)=true) ↔ 2≤countTrue (score4_vals11 E) := by
  have rew : (!g2194 E) = ((!g2176 E) || ((g398 E) && (!g2174 E))) := by simp [g1,g2193,g2194,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold10_1 E
  have T0 := score4_threshold10_0 E
  exact threshold_step (g398 E) (!g2176 E) (!g2174 E) 1 (countTrue (score4_vals10 E)) T1 T0
theorem score4_threshold12_2 (E : Nat→Bool) : ((!g2216 E)=true) ↔ 3≤countTrue (score4_vals12 E) := by
  have rew : (!g2216 E) = ((!g2196 E) || ((g402 E) && (!g2194 E))) := by simp [g1,g2215,g2216,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold11_2 E
  have T0 := score4_threshold11_1 E
  exact threshold_step (g402 E) (!g2196 E) (!g2194 E) 2 (countTrue (score4_vals11 E)) T1 T0
theorem score4_threshold13_3 (E : Nat→Bool) : ((!g2240 E)=true) ↔ 4≤countTrue (score4_vals13 E) := by
  have rew : (!g2240 E) = ((!g2218 E) || ((g406 E) && (!g2216 E))) := by simp [g1,g2239,g2240,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold12_3 E
  have T0 := score4_threshold12_2 E
  exact threshold_step (g406 E) (!g2218 E) (!g2216 E) 3 (countTrue (score4_vals12 E)) T1 T0
theorem score4_threshold14_4 (E : Nat→Bool) : ((!g2266 E)=true) ↔ 5≤countTrue (score4_vals14 E) := by
  have rew : (!g2266 E) = ((!g2242 E) || ((g407 E) && (!g2240 E))) := by simp [g1,g2265,g2266,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold13_4 E
  have T0 := score4_threshold13_3 E
  exact threshold_step (g407 E) (!g2242 E) (!g2240 E) 4 (countTrue (score4_vals13 E)) T1 T0
theorem score4_threshold11_0 (E : Nat→Bool) : ((!g2192 E)=true) ↔ 1≤countTrue (score4_vals11 E) := by
  have rew : (!g2192 E) = ((!g2174 E) || ((g398 E) && (g1 E))) := by simp [g1,g2192,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold10_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score4_vals10 E) := by simp [g1]
  exact threshold_step (g398 E) (!g2174 E) (g1 E) 0 (countTrue (score4_vals10 E)) T1 T0
theorem score4_threshold12_1 (E : Nat→Bool) : ((!g2214 E)=true) ↔ 2≤countTrue (score4_vals12 E) := by
  have rew : (!g2214 E) = ((!g2194 E) || ((g402 E) && (!g2192 E))) := by simp [g1,g2213,g2214,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold11_1 E
  have T0 := score4_threshold11_0 E
  exact threshold_step (g402 E) (!g2194 E) (!g2192 E) 1 (countTrue (score4_vals11 E)) T1 T0
theorem score4_threshold13_2 (E : Nat→Bool) : ((!g2238 E)=true) ↔ 3≤countTrue (score4_vals13 E) := by
  have rew : (!g2238 E) = ((!g2216 E) || ((g406 E) && (!g2214 E))) := by simp [g1,g2237,g2238,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold12_2 E
  have T0 := score4_threshold12_1 E
  exact threshold_step (g406 E) (!g2216 E) (!g2214 E) 2 (countTrue (score4_vals12 E)) T1 T0
theorem score4_threshold14_3 (E : Nat→Bool) : ((!g2264 E)=true) ↔ 4≤countTrue (score4_vals14 E) := by
  have rew : (!g2264 E) = ((!g2240 E) || ((g407 E) && (!g2238 E))) := by simp [g1,g2263,g2264,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold13_3 E
  have T0 := score4_threshold13_2 E
  exact threshold_step (g407 E) (!g2240 E) (!g2238 E) 3 (countTrue (score4_vals13 E)) T1 T0
theorem score4_threshold15_4 (E : Nat→Bool) : ((!g2292 E)=true) ↔ 5≤countTrue (score4_vals15 E) := by
  have rew : (!g2292 E) = ((!g2266 E) || ((g408 E) && (!g2264 E))) := by simp [g1,g2291,g2292,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold14_4 E
  have T0 := score4_threshold14_3 E
  exact threshold_step (g408 E) (!g2266 E) (!g2264 E) 4 (countTrue (score4_vals14 E)) T1 T0
theorem score4_threshold12_0 (E : Nat→Bool) : ((!g2212 E)=true) ↔ 1≤countTrue (score4_vals12 E) := by
  have rew : (!g2212 E) = ((!g2192 E) || ((g402 E) && (g1 E))) := by simp [g1,g2212,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold11_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score4_vals11 E) := by simp [g1]
  exact threshold_step (g402 E) (!g2192 E) (g1 E) 0 (countTrue (score4_vals11 E)) T1 T0
theorem score4_threshold13_1 (E : Nat→Bool) : ((!g2236 E)=true) ↔ 2≤countTrue (score4_vals13 E) := by
  have rew : (!g2236 E) = ((!g2214 E) || ((g406 E) && (!g2212 E))) := by simp [g1,g2235,g2236,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold12_1 E
  have T0 := score4_threshold12_0 E
  exact threshold_step (g406 E) (!g2214 E) (!g2212 E) 1 (countTrue (score4_vals12 E)) T1 T0
theorem score4_threshold14_2 (E : Nat→Bool) : ((!g2262 E)=true) ↔ 3≤countTrue (score4_vals14 E) := by
  have rew : (!g2262 E) = ((!g2238 E) || ((g407 E) && (!g2236 E))) := by simp [g1,g2261,g2262,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold13_2 E
  have T0 := score4_threshold13_1 E
  exact threshold_step (g407 E) (!g2238 E) (!g2236 E) 2 (countTrue (score4_vals13 E)) T1 T0
theorem score4_threshold15_3 (E : Nat→Bool) : ((!g2290 E)=true) ↔ 4≤countTrue (score4_vals15 E) := by
  have rew : (!g2290 E) = ((!g2264 E) || ((g408 E) && (!g2262 E))) := by simp [g1,g2289,g2290,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold14_3 E
  have T0 := score4_threshold14_2 E
  exact threshold_step (g408 E) (!g2264 E) (!g2262 E) 3 (countTrue (score4_vals14 E)) T1 T0
theorem score4_threshold16_4 (E : Nat→Bool) : ((!g2320 E)=true) ↔ 5≤countTrue (score4_vals16 E) := by
  have rew : (!g2320 E) = ((!g2292 E) || ((g412 E) && (!g2290 E))) := by simp [g1,g2319,g2320,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold15_4 E
  have T0 := score4_threshold15_3 E
  exact threshold_step (g412 E) (!g2292 E) (!g2290 E) 4 (countTrue (score4_vals15 E)) T1 T0
theorem score4_threshold13_0 (E : Nat→Bool) : ((!g2234 E)=true) ↔ 1≤countTrue (score4_vals13 E) := by
  have rew : (!g2234 E) = ((!g2212 E) || ((g406 E) && (g1 E))) := by simp [g1,g2234,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold12_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score4_vals12 E) := by simp [g1]
  exact threshold_step (g406 E) (!g2212 E) (g1 E) 0 (countTrue (score4_vals12 E)) T1 T0
theorem score4_threshold14_1 (E : Nat→Bool) : ((!g2260 E)=true) ↔ 2≤countTrue (score4_vals14 E) := by
  have rew : (!g2260 E) = ((!g2236 E) || ((g407 E) && (!g2234 E))) := by simp [g1,g2259,g2260,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold13_1 E
  have T0 := score4_threshold13_0 E
  exact threshold_step (g407 E) (!g2236 E) (!g2234 E) 1 (countTrue (score4_vals13 E)) T1 T0
theorem score4_threshold15_2 (E : Nat→Bool) : ((!g2288 E)=true) ↔ 3≤countTrue (score4_vals15 E) := by
  have rew : (!g2288 E) = ((!g2262 E) || ((g408 E) && (!g2260 E))) := by simp [g1,g2287,g2288,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold14_2 E
  have T0 := score4_threshold14_1 E
  exact threshold_step (g408 E) (!g2262 E) (!g2260 E) 2 (countTrue (score4_vals14 E)) T1 T0
theorem score4_threshold16_3 (E : Nat→Bool) : ((!g2318 E)=true) ↔ 4≤countTrue (score4_vals16 E) := by
  have rew : (!g2318 E) = ((!g2290 E) || ((g412 E) && (!g2288 E))) := by simp [g1,g2317,g2318,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold15_3 E
  have T0 := score4_threshold15_2 E
  exact threshold_step (g412 E) (!g2290 E) (!g2288 E) 3 (countTrue (score4_vals15 E)) T1 T0
theorem score4_threshold17_4 (E : Nat→Bool) : ((!g2350 E)=true) ↔ 5≤countTrue (score4_vals17 E) := by
  have rew : (!g2350 E) = ((!g2320 E) || ((g413 E) && (!g2318 E))) := by simp [g1,g2349,g2350,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold16_4 E
  have T0 := score4_threshold16_3 E
  exact threshold_step (g413 E) (!g2320 E) (!g2318 E) 4 (countTrue (score4_vals16 E)) T1 T0
theorem score4_threshold14_0 (E : Nat→Bool) : ((!g2258 E)=true) ↔ 1≤countTrue (score4_vals14 E) := by
  have rew : (!g2258 E) = ((!g2234 E) || ((g407 E) && (g1 E))) := by simp [g1,g2258,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold13_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score4_vals13 E) := by simp [g1]
  exact threshold_step (g407 E) (!g2234 E) (g1 E) 0 (countTrue (score4_vals13 E)) T1 T0
theorem score4_threshold15_1 (E : Nat→Bool) : ((!g2286 E)=true) ↔ 2≤countTrue (score4_vals15 E) := by
  have rew : (!g2286 E) = ((!g2260 E) || ((g408 E) && (!g2258 E))) := by simp [g1,g2285,g2286,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold14_1 E
  have T0 := score4_threshold14_0 E
  exact threshold_step (g408 E) (!g2260 E) (!g2258 E) 1 (countTrue (score4_vals14 E)) T1 T0
theorem score4_threshold16_2 (E : Nat→Bool) : ((!g2316 E)=true) ↔ 3≤countTrue (score4_vals16 E) := by
  have rew : (!g2316 E) = ((!g2288 E) || ((g412 E) && (!g2286 E))) := by simp [g1,g2315,g2316,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold15_2 E
  have T0 := score4_threshold15_1 E
  exact threshold_step (g412 E) (!g2288 E) (!g2286 E) 2 (countTrue (score4_vals15 E)) T1 T0
theorem score4_threshold17_3 (E : Nat→Bool) : ((!g2348 E)=true) ↔ 4≤countTrue (score4_vals17 E) := by
  have rew : (!g2348 E) = ((!g2318 E) || ((g413 E) && (!g2316 E))) := by simp [g1,g2347,g2348,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold16_3 E
  have T0 := score4_threshold16_2 E
  exact threshold_step (g413 E) (!g2318 E) (!g2316 E) 3 (countTrue (score4_vals16 E)) T1 T0
theorem score4_threshold18_4 (E : Nat→Bool) : ((!g2382 E)=true) ↔ 5≤countTrue (score4_vals18 E) := by
  have rew : (!g2382 E) = ((!g2350 E) || ((g414 E) && (!g2348 E))) := by simp [g1,g2381,g2382,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold17_4 E
  have T0 := score4_threshold17_3 E
  exact threshold_step (g414 E) (!g2350 E) (!g2348 E) 4 (countTrue (score4_vals17 E)) T1 T0
theorem score4_threshold15_0 (E : Nat→Bool) : ((!g2284 E)=true) ↔ 1≤countTrue (score4_vals15 E) := by
  have rew : (!g2284 E) = ((!g2258 E) || ((g408 E) && (g1 E))) := by simp [g1,g2284,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold14_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score4_vals14 E) := by simp [g1]
  exact threshold_step (g408 E) (!g2258 E) (g1 E) 0 (countTrue (score4_vals14 E)) T1 T0
theorem score4_threshold16_1 (E : Nat→Bool) : ((!g2314 E)=true) ↔ 2≤countTrue (score4_vals16 E) := by
  have rew : (!g2314 E) = ((!g2286 E) || ((g412 E) && (!g2284 E))) := by simp [g1,g2313,g2314,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold15_1 E
  have T0 := score4_threshold15_0 E
  exact threshold_step (g412 E) (!g2286 E) (!g2284 E) 1 (countTrue (score4_vals15 E)) T1 T0
theorem score4_threshold17_2 (E : Nat→Bool) : ((!g2346 E)=true) ↔ 3≤countTrue (score4_vals17 E) := by
  have rew : (!g2346 E) = ((!g2316 E) || ((g413 E) && (!g2314 E))) := by simp [g1,g2345,g2346,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold16_2 E
  have T0 := score4_threshold16_1 E
  exact threshold_step (g413 E) (!g2316 E) (!g2314 E) 2 (countTrue (score4_vals16 E)) T1 T0
theorem score4_threshold18_3 (E : Nat→Bool) : ((!g2380 E)=true) ↔ 4≤countTrue (score4_vals18 E) := by
  have rew : (!g2380 E) = ((!g2348 E) || ((g414 E) && (!g2346 E))) := by simp [g1,g2379,g2380,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold17_3 E
  have T0 := score4_threshold17_2 E
  exact threshold_step (g414 E) (!g2348 E) (!g2346 E) 3 (countTrue (score4_vals17 E)) T1 T0
theorem score4_threshold19_4 (E : Nat→Bool) : ((!g2416 E)=true) ↔ 5≤countTrue (score4_vals19 E) := by
  have rew : (!g2416 E) = ((!g2382 E) || ((g418 E) && (!g2380 E))) := by simp [g1,g2415,g2416,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold18_4 E
  have T0 := score4_threshold18_3 E
  exact threshold_step (g418 E) (!g2382 E) (!g2380 E) 4 (countTrue (score4_vals18 E)) T1 T0
theorem score4_threshold16_0 (E : Nat→Bool) : ((!g2312 E)=true) ↔ 1≤countTrue (score4_vals16 E) := by
  have rew : (!g2312 E) = ((!g2284 E) || ((g412 E) && (g1 E))) := by simp [g1,g2312,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold15_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score4_vals15 E) := by simp [g1]
  exact threshold_step (g412 E) (!g2284 E) (g1 E) 0 (countTrue (score4_vals15 E)) T1 T0
theorem score4_threshold17_1 (E : Nat→Bool) : ((!g2344 E)=true) ↔ 2≤countTrue (score4_vals17 E) := by
  have rew : (!g2344 E) = ((!g2314 E) || ((g413 E) && (!g2312 E))) := by simp [g1,g2343,g2344,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold16_1 E
  have T0 := score4_threshold16_0 E
  exact threshold_step (g413 E) (!g2314 E) (!g2312 E) 1 (countTrue (score4_vals16 E)) T1 T0
theorem score4_threshold18_2 (E : Nat→Bool) : ((!g2378 E)=true) ↔ 3≤countTrue (score4_vals18 E) := by
  have rew : (!g2378 E) = ((!g2346 E) || ((g414 E) && (!g2344 E))) := by simp [g1,g2377,g2378,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold17_2 E
  have T0 := score4_threshold17_1 E
  exact threshold_step (g414 E) (!g2346 E) (!g2344 E) 2 (countTrue (score4_vals17 E)) T1 T0
theorem score4_threshold19_3 (E : Nat→Bool) : ((!g2414 E)=true) ↔ 4≤countTrue (score4_vals19 E) := by
  have rew : (!g2414 E) = ((!g2380 E) || ((g418 E) && (!g2378 E))) := by simp [g1,g2413,g2414,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold18_3 E
  have T0 := score4_threshold18_2 E
  exact threshold_step (g418 E) (!g2380 E) (!g2378 E) 3 (countTrue (score4_vals18 E)) T1 T0
theorem score4_threshold20_4 (E : Nat→Bool) : ((!g2452 E)=true) ↔ 5≤countTrue (score4_vals20 E) := by
  have rew : (!g2452 E) = ((!g2416 E) || ((g419 E) && (!g2414 E))) := by simp [g1,g2451,g2452,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold19_4 E
  have T0 := score4_threshold19_3 E
  exact threshold_step (g419 E) (!g2416 E) (!g2414 E) 4 (countTrue (score4_vals19 E)) T1 T0
theorem score4_threshold17_0 (E : Nat→Bool) : ((!g2342 E)=true) ↔ 1≤countTrue (score4_vals17 E) := by
  have rew : (!g2342 E) = ((!g2312 E) || ((g413 E) && (g1 E))) := by simp [g1,g2342,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold16_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score4_vals16 E) := by simp [g1]
  exact threshold_step (g413 E) (!g2312 E) (g1 E) 0 (countTrue (score4_vals16 E)) T1 T0
theorem score4_threshold18_1 (E : Nat→Bool) : ((!g2376 E)=true) ↔ 2≤countTrue (score4_vals18 E) := by
  have rew : (!g2376 E) = ((!g2344 E) || ((g414 E) && (!g2342 E))) := by simp [g1,g2375,g2376,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold17_1 E
  have T0 := score4_threshold17_0 E
  exact threshold_step (g414 E) (!g2344 E) (!g2342 E) 1 (countTrue (score4_vals17 E)) T1 T0
theorem score4_threshold19_2 (E : Nat→Bool) : ((!g2412 E)=true) ↔ 3≤countTrue (score4_vals19 E) := by
  have rew : (!g2412 E) = ((!g2378 E) || ((g418 E) && (!g2376 E))) := by simp [g1,g2411,g2412,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold18_2 E
  have T0 := score4_threshold18_1 E
  exact threshold_step (g418 E) (!g2378 E) (!g2376 E) 2 (countTrue (score4_vals18 E)) T1 T0
theorem score4_threshold20_3 (E : Nat→Bool) : ((!g2450 E)=true) ↔ 4≤countTrue (score4_vals20 E) := by
  have rew : (!g2450 E) = ((!g2414 E) || ((g419 E) && (!g2412 E))) := by simp [g1,g2449,g2450,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold19_3 E
  have T0 := score4_threshold19_2 E
  exact threshold_step (g419 E) (!g2414 E) (!g2412 E) 3 (countTrue (score4_vals19 E)) T1 T0
theorem score4_threshold21_4 (E : Nat→Bool) : ((!g2490 E)=true) ↔ 5≤countTrue (score4_vals21 E) := by
  have rew : (!g2490 E) = ((!g2452 E) || ((g420 E) && (!g2450 E))) := by simp [g1,g2489,g2490,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold20_4 E
  have T0 := score4_threshold20_3 E
  exact threshold_step (g420 E) (!g2452 E) (!g2450 E) 4 (countTrue (score4_vals20 E)) T1 T0
theorem score4_threshold6_5 (E : Nat→Bool) : ((g2131 E)=true) ↔ 6≤countTrue (score4_vals6 E) := by
  have rew : (g2131 E) = ((!g1 E) || ((g383 E) && (g2121 E))) := by simp [g1,g2131,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 6≤countTrue (score4_vals5 E) := by
    have hh := count_true_bound (score4_vals5 E)
    change countTrue (score4_vals5 E)≤5 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬6≤countTrue (score4_vals5 E)
    omega
  have T0 := score4_threshold5_4 E
  exact threshold_step (g383 E) (!g1 E) (g2121 E) 5 (countTrue (score4_vals5 E)) T1 T0
theorem score4_threshold7_5 (E : Nat→Bool) : ((!g2142 E)=true) ↔ 6≤countTrue (score4_vals7 E) := by
  have rew : (!g2142 E) = ((g2131 E) || ((g388 E) && (!g2130 E))) := by simp [g1,g2141,g2142,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold6_5 E
  have T0 := score4_threshold6_4 E
  exact threshold_step (g388 E) (g2131 E) (!g2130 E) 5 (countTrue (score4_vals6 E)) T1 T0
theorem score4_threshold8_5 (E : Nat→Bool) : ((!g2154 E)=true) ↔ 6≤countTrue (score4_vals8 E) := by
  have rew : (!g2154 E) = ((!g2142 E) || ((g392 E) && (!g2140 E))) := by simp [g1,g2153,g2154,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold7_5 E
  have T0 := score4_threshold7_4 E
  exact threshold_step (g392 E) (!g2142 E) (!g2140 E) 5 (countTrue (score4_vals7 E)) T1 T0
theorem score4_threshold9_5 (E : Nat→Bool) : ((!g2168 E)=true) ↔ 6≤countTrue (score4_vals9 E) := by
  have rew : (!g2168 E) = ((!g2154 E) || ((g396 E) && (!g2152 E))) := by simp [g1,g2167,g2168,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold8_5 E
  have T0 := score4_threshold8_4 E
  exact threshold_step (g396 E) (!g2154 E) (!g2152 E) 5 (countTrue (score4_vals8 E)) T1 T0
theorem score4_threshold10_5 (E : Nat→Bool) : ((!g2184 E)=true) ↔ 6≤countTrue (score4_vals10 E) := by
  have rew : (!g2184 E) = ((!g2168 E) || ((g397 E) && (!g2166 E))) := by simp [g1,g2183,g2184,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold9_5 E
  have T0 := score4_threshold9_4 E
  exact threshold_step (g397 E) (!g2168 E) (!g2166 E) 5 (countTrue (score4_vals9 E)) T1 T0
theorem score4_threshold11_5 (E : Nat→Bool) : ((!g2202 E)=true) ↔ 6≤countTrue (score4_vals11 E) := by
  have rew : (!g2202 E) = ((!g2184 E) || ((g398 E) && (!g2182 E))) := by simp [g1,g2201,g2202,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold10_5 E
  have T0 := score4_threshold10_4 E
  exact threshold_step (g398 E) (!g2184 E) (!g2182 E) 5 (countTrue (score4_vals10 E)) T1 T0
theorem score4_threshold12_5 (E : Nat→Bool) : ((!g2222 E)=true) ↔ 6≤countTrue (score4_vals12 E) := by
  have rew : (!g2222 E) = ((!g2202 E) || ((g402 E) && (!g2200 E))) := by simp [g1,g2221,g2222,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold11_5 E
  have T0 := score4_threshold11_4 E
  exact threshold_step (g402 E) (!g2202 E) (!g2200 E) 5 (countTrue (score4_vals11 E)) T1 T0
theorem score4_threshold13_5 (E : Nat→Bool) : ((!g2244 E)=true) ↔ 6≤countTrue (score4_vals13 E) := by
  have rew : (!g2244 E) = ((!g2222 E) || ((g406 E) && (!g2220 E))) := by simp [g1,g2243,g2244,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold12_5 E
  have T0 := score4_threshold12_4 E
  exact threshold_step (g406 E) (!g2222 E) (!g2220 E) 5 (countTrue (score4_vals12 E)) T1 T0
theorem score4_threshold14_5 (E : Nat→Bool) : ((!g2268 E)=true) ↔ 6≤countTrue (score4_vals14 E) := by
  have rew : (!g2268 E) = ((!g2244 E) || ((g407 E) && (!g2242 E))) := by simp [g1,g2267,g2268,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold13_5 E
  have T0 := score4_threshold13_4 E
  exact threshold_step (g407 E) (!g2244 E) (!g2242 E) 5 (countTrue (score4_vals13 E)) T1 T0
theorem score4_threshold15_5 (E : Nat→Bool) : ((!g2294 E)=true) ↔ 6≤countTrue (score4_vals15 E) := by
  have rew : (!g2294 E) = ((!g2268 E) || ((g408 E) && (!g2266 E))) := by simp [g1,g2293,g2294,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold14_5 E
  have T0 := score4_threshold14_4 E
  exact threshold_step (g408 E) (!g2268 E) (!g2266 E) 5 (countTrue (score4_vals14 E)) T1 T0
theorem score4_threshold16_5 (E : Nat→Bool) : ((!g2322 E)=true) ↔ 6≤countTrue (score4_vals16 E) := by
  have rew : (!g2322 E) = ((!g2294 E) || ((g412 E) && (!g2292 E))) := by simp [g1,g2321,g2322,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold15_5 E
  have T0 := score4_threshold15_4 E
  exact threshold_step (g412 E) (!g2294 E) (!g2292 E) 5 (countTrue (score4_vals15 E)) T1 T0
theorem score4_threshold17_5 (E : Nat→Bool) : ((!g2352 E)=true) ↔ 6≤countTrue (score4_vals17 E) := by
  have rew : (!g2352 E) = ((!g2322 E) || ((g413 E) && (!g2320 E))) := by simp [g1,g2351,g2352,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold16_5 E
  have T0 := score4_threshold16_4 E
  exact threshold_step (g413 E) (!g2322 E) (!g2320 E) 5 (countTrue (score4_vals16 E)) T1 T0
theorem score4_threshold18_5 (E : Nat→Bool) : ((!g2384 E)=true) ↔ 6≤countTrue (score4_vals18 E) := by
  have rew : (!g2384 E) = ((!g2352 E) || ((g414 E) && (!g2350 E))) := by simp [g1,g2383,g2384,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold17_5 E
  have T0 := score4_threshold17_4 E
  exact threshold_step (g414 E) (!g2352 E) (!g2350 E) 5 (countTrue (score4_vals17 E)) T1 T0
theorem score4_threshold19_5 (E : Nat→Bool) : ((!g2418 E)=true) ↔ 6≤countTrue (score4_vals19 E) := by
  have rew : (!g2418 E) = ((!g2384 E) || ((g418 E) && (!g2382 E))) := by simp [g1,g2417,g2418,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold18_5 E
  have T0 := score4_threshold18_4 E
  exact threshold_step (g418 E) (!g2384 E) (!g2382 E) 5 (countTrue (score4_vals18 E)) T1 T0
theorem score4_threshold20_5 (E : Nat→Bool) : ((!g2454 E)=true) ↔ 6≤countTrue (score4_vals20 E) := by
  have rew : (!g2454 E) = ((!g2418 E) || ((g419 E) && (!g2416 E))) := by simp [g1,g2453,g2454,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold19_5 E
  have T0 := score4_threshold19_4 E
  exact threshold_step (g419 E) (!g2418 E) (!g2416 E) 5 (countTrue (score4_vals19 E)) T1 T0
theorem score4_threshold21_5 (E : Nat→Bool) : ((!g2492 E)=true) ↔ 6≤countTrue (score4_vals21 E) := by
  have rew : (!g2492 E) = ((!g2454 E) || ((g420 E) && (!g2452 E))) := by simp [g1,g2491,g2492,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold20_5 E
  have T0 := score4_threshold20_4 E
  exact threshold_step (g420 E) (!g2454 E) (!g2452 E) 5 (countTrue (score4_vals20 E)) T1 T0
theorem score4_threshold7_6 (E : Nat→Bool) : ((g2143 E)=true) ↔ 7≤countTrue (score4_vals7 E) := by
  have rew : (g2143 E) = ((!g1 E) || ((g388 E) && (g2131 E))) := by simp [g1,g2143,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 7≤countTrue (score4_vals6 E) := by
    have hh := count_true_bound (score4_vals6 E)
    change countTrue (score4_vals6 E)≤6 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬7≤countTrue (score4_vals6 E)
    omega
  have T0 := score4_threshold6_5 E
  exact threshold_step (g388 E) (!g1 E) (g2131 E) 6 (countTrue (score4_vals6 E)) T1 T0
theorem score4_threshold8_6 (E : Nat→Bool) : ((!g2156 E)=true) ↔ 7≤countTrue (score4_vals8 E) := by
  have rew : (!g2156 E) = ((g2143 E) || ((g392 E) && (!g2142 E))) := by simp [g1,g2155,g2156,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold7_6 E
  have T0 := score4_threshold7_5 E
  exact threshold_step (g392 E) (g2143 E) (!g2142 E) 6 (countTrue (score4_vals7 E)) T1 T0
theorem score4_threshold9_6 (E : Nat→Bool) : ((!g2170 E)=true) ↔ 7≤countTrue (score4_vals9 E) := by
  have rew : (!g2170 E) = ((!g2156 E) || ((g396 E) && (!g2154 E))) := by simp [g1,g2169,g2170,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold8_6 E
  have T0 := score4_threshold8_5 E
  exact threshold_step (g396 E) (!g2156 E) (!g2154 E) 6 (countTrue (score4_vals8 E)) T1 T0
theorem score4_threshold10_6 (E : Nat→Bool) : ((!g2186 E)=true) ↔ 7≤countTrue (score4_vals10 E) := by
  have rew : (!g2186 E) = ((!g2170 E) || ((g397 E) && (!g2168 E))) := by simp [g1,g2185,g2186,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold9_6 E
  have T0 := score4_threshold9_5 E
  exact threshold_step (g397 E) (!g2170 E) (!g2168 E) 6 (countTrue (score4_vals9 E)) T1 T0
theorem score4_threshold11_6 (E : Nat→Bool) : ((!g2204 E)=true) ↔ 7≤countTrue (score4_vals11 E) := by
  have rew : (!g2204 E) = ((!g2186 E) || ((g398 E) && (!g2184 E))) := by simp [g1,g2203,g2204,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold10_6 E
  have T0 := score4_threshold10_5 E
  exact threshold_step (g398 E) (!g2186 E) (!g2184 E) 6 (countTrue (score4_vals10 E)) T1 T0
theorem score4_threshold12_6 (E : Nat→Bool) : ((!g2224 E)=true) ↔ 7≤countTrue (score4_vals12 E) := by
  have rew : (!g2224 E) = ((!g2204 E) || ((g402 E) && (!g2202 E))) := by simp [g1,g2223,g2224,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold11_6 E
  have T0 := score4_threshold11_5 E
  exact threshold_step (g402 E) (!g2204 E) (!g2202 E) 6 (countTrue (score4_vals11 E)) T1 T0
theorem score4_threshold13_6 (E : Nat→Bool) : ((!g2246 E)=true) ↔ 7≤countTrue (score4_vals13 E) := by
  have rew : (!g2246 E) = ((!g2224 E) || ((g406 E) && (!g2222 E))) := by simp [g1,g2245,g2246,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold12_6 E
  have T0 := score4_threshold12_5 E
  exact threshold_step (g406 E) (!g2224 E) (!g2222 E) 6 (countTrue (score4_vals12 E)) T1 T0
theorem score4_threshold14_6 (E : Nat→Bool) : ((!g2270 E)=true) ↔ 7≤countTrue (score4_vals14 E) := by
  have rew : (!g2270 E) = ((!g2246 E) || ((g407 E) && (!g2244 E))) := by simp [g1,g2269,g2270,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold13_6 E
  have T0 := score4_threshold13_5 E
  exact threshold_step (g407 E) (!g2246 E) (!g2244 E) 6 (countTrue (score4_vals13 E)) T1 T0
theorem score4_threshold15_6 (E : Nat→Bool) : ((!g2296 E)=true) ↔ 7≤countTrue (score4_vals15 E) := by
  have rew : (!g2296 E) = ((!g2270 E) || ((g408 E) && (!g2268 E))) := by simp [g1,g2295,g2296,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold14_6 E
  have T0 := score4_threshold14_5 E
  exact threshold_step (g408 E) (!g2270 E) (!g2268 E) 6 (countTrue (score4_vals14 E)) T1 T0
theorem score4_threshold16_6 (E : Nat→Bool) : ((!g2324 E)=true) ↔ 7≤countTrue (score4_vals16 E) := by
  have rew : (!g2324 E) = ((!g2296 E) || ((g412 E) && (!g2294 E))) := by simp [g1,g2323,g2324,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold15_6 E
  have T0 := score4_threshold15_5 E
  exact threshold_step (g412 E) (!g2296 E) (!g2294 E) 6 (countTrue (score4_vals15 E)) T1 T0
theorem score4_threshold17_6 (E : Nat→Bool) : ((!g2354 E)=true) ↔ 7≤countTrue (score4_vals17 E) := by
  have rew : (!g2354 E) = ((!g2324 E) || ((g413 E) && (!g2322 E))) := by simp [g1,g2353,g2354,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold16_6 E
  have T0 := score4_threshold16_5 E
  exact threshold_step (g413 E) (!g2324 E) (!g2322 E) 6 (countTrue (score4_vals16 E)) T1 T0
theorem score4_threshold18_6 (E : Nat→Bool) : ((!g2386 E)=true) ↔ 7≤countTrue (score4_vals18 E) := by
  have rew : (!g2386 E) = ((!g2354 E) || ((g414 E) && (!g2352 E))) := by simp [g1,g2385,g2386,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold17_6 E
  have T0 := score4_threshold17_5 E
  exact threshold_step (g414 E) (!g2354 E) (!g2352 E) 6 (countTrue (score4_vals17 E)) T1 T0
theorem score4_threshold19_6 (E : Nat→Bool) : ((!g2420 E)=true) ↔ 7≤countTrue (score4_vals19 E) := by
  have rew : (!g2420 E) = ((!g2386 E) || ((g418 E) && (!g2384 E))) := by simp [g1,g2419,g2420,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold18_6 E
  have T0 := score4_threshold18_5 E
  exact threshold_step (g418 E) (!g2386 E) (!g2384 E) 6 (countTrue (score4_vals18 E)) T1 T0
theorem score4_threshold20_6 (E : Nat→Bool) : ((!g2456 E)=true) ↔ 7≤countTrue (score4_vals20 E) := by
  have rew : (!g2456 E) = ((!g2420 E) || ((g419 E) && (!g2418 E))) := by simp [g1,g2455,g2456,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold19_6 E
  have T0 := score4_threshold19_5 E
  exact threshold_step (g419 E) (!g2420 E) (!g2418 E) 6 (countTrue (score4_vals19 E)) T1 T0
theorem score4_threshold21_6 (E : Nat→Bool) : ((!g2494 E)=true) ↔ 7≤countTrue (score4_vals21 E) := by
  have rew : (!g2494 E) = ((!g2456 E) || ((g420 E) && (!g2454 E))) := by simp [g1,g2493,g2494,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold20_6 E
  have T0 := score4_threshold20_5 E
  exact threshold_step (g420 E) (!g2456 E) (!g2454 E) 6 (countTrue (score4_vals20 E)) T1 T0
theorem score4_threshold8_7 (E : Nat→Bool) : ((g2157 E)=true) ↔ 8≤countTrue (score4_vals8 E) := by
  have rew : (g2157 E) = ((!g1 E) || ((g392 E) && (g2143 E))) := by simp [g1,g2157,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 8≤countTrue (score4_vals7 E) := by
    have hh := count_true_bound (score4_vals7 E)
    change countTrue (score4_vals7 E)≤7 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬8≤countTrue (score4_vals7 E)
    omega
  have T0 := score4_threshold7_6 E
  exact threshold_step (g392 E) (!g1 E) (g2143 E) 7 (countTrue (score4_vals7 E)) T1 T0
theorem score4_threshold9_7 (E : Nat→Bool) : ((!g2172 E)=true) ↔ 8≤countTrue (score4_vals9 E) := by
  have rew : (!g2172 E) = ((g2157 E) || ((g396 E) && (!g2156 E))) := by simp [g1,g2171,g2172,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold8_7 E
  have T0 := score4_threshold8_6 E
  exact threshold_step (g396 E) (g2157 E) (!g2156 E) 7 (countTrue (score4_vals8 E)) T1 T0
theorem score4_threshold10_7 (E : Nat→Bool) : ((!g2188 E)=true) ↔ 8≤countTrue (score4_vals10 E) := by
  have rew : (!g2188 E) = ((!g2172 E) || ((g397 E) && (!g2170 E))) := by simp [g1,g2187,g2188,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold9_7 E
  have T0 := score4_threshold9_6 E
  exact threshold_step (g397 E) (!g2172 E) (!g2170 E) 7 (countTrue (score4_vals9 E)) T1 T0
theorem score4_threshold11_7 (E : Nat→Bool) : ((!g2206 E)=true) ↔ 8≤countTrue (score4_vals11 E) := by
  have rew : (!g2206 E) = ((!g2188 E) || ((g398 E) && (!g2186 E))) := by simp [g1,g2205,g2206,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold10_7 E
  have T0 := score4_threshold10_6 E
  exact threshold_step (g398 E) (!g2188 E) (!g2186 E) 7 (countTrue (score4_vals10 E)) T1 T0
theorem score4_threshold12_7 (E : Nat→Bool) : ((!g2226 E)=true) ↔ 8≤countTrue (score4_vals12 E) := by
  have rew : (!g2226 E) = ((!g2206 E) || ((g402 E) && (!g2204 E))) := by simp [g1,g2225,g2226,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold11_7 E
  have T0 := score4_threshold11_6 E
  exact threshold_step (g402 E) (!g2206 E) (!g2204 E) 7 (countTrue (score4_vals11 E)) T1 T0
theorem score4_threshold13_7 (E : Nat→Bool) : ((!g2248 E)=true) ↔ 8≤countTrue (score4_vals13 E) := by
  have rew : (!g2248 E) = ((!g2226 E) || ((g406 E) && (!g2224 E))) := by simp [g1,g2247,g2248,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold12_7 E
  have T0 := score4_threshold12_6 E
  exact threshold_step (g406 E) (!g2226 E) (!g2224 E) 7 (countTrue (score4_vals12 E)) T1 T0
theorem score4_threshold14_7 (E : Nat→Bool) : ((!g2272 E)=true) ↔ 8≤countTrue (score4_vals14 E) := by
  have rew : (!g2272 E) = ((!g2248 E) || ((g407 E) && (!g2246 E))) := by simp [g1,g2271,g2272,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold13_7 E
  have T0 := score4_threshold13_6 E
  exact threshold_step (g407 E) (!g2248 E) (!g2246 E) 7 (countTrue (score4_vals13 E)) T1 T0
theorem score4_threshold15_7 (E : Nat→Bool) : ((!g2298 E)=true) ↔ 8≤countTrue (score4_vals15 E) := by
  have rew : (!g2298 E) = ((!g2272 E) || ((g408 E) && (!g2270 E))) := by simp [g1,g2297,g2298,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold14_7 E
  have T0 := score4_threshold14_6 E
  exact threshold_step (g408 E) (!g2272 E) (!g2270 E) 7 (countTrue (score4_vals14 E)) T1 T0
theorem score4_threshold16_7 (E : Nat→Bool) : ((!g2326 E)=true) ↔ 8≤countTrue (score4_vals16 E) := by
  have rew : (!g2326 E) = ((!g2298 E) || ((g412 E) && (!g2296 E))) := by simp [g1,g2325,g2326,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold15_7 E
  have T0 := score4_threshold15_6 E
  exact threshold_step (g412 E) (!g2298 E) (!g2296 E) 7 (countTrue (score4_vals15 E)) T1 T0
theorem score4_threshold17_7 (E : Nat→Bool) : ((!g2356 E)=true) ↔ 8≤countTrue (score4_vals17 E) := by
  have rew : (!g2356 E) = ((!g2326 E) || ((g413 E) && (!g2324 E))) := by simp [g1,g2355,g2356,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold16_7 E
  have T0 := score4_threshold16_6 E
  exact threshold_step (g413 E) (!g2326 E) (!g2324 E) 7 (countTrue (score4_vals16 E)) T1 T0
theorem score4_threshold18_7 (E : Nat→Bool) : ((!g2388 E)=true) ↔ 8≤countTrue (score4_vals18 E) := by
  have rew : (!g2388 E) = ((!g2356 E) || ((g414 E) && (!g2354 E))) := by simp [g1,g2387,g2388,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold17_7 E
  have T0 := score4_threshold17_6 E
  exact threshold_step (g414 E) (!g2356 E) (!g2354 E) 7 (countTrue (score4_vals17 E)) T1 T0
theorem score4_threshold19_7 (E : Nat→Bool) : ((!g2422 E)=true) ↔ 8≤countTrue (score4_vals19 E) := by
  have rew : (!g2422 E) = ((!g2388 E) || ((g418 E) && (!g2386 E))) := by simp [g1,g2421,g2422,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold18_7 E
  have T0 := score4_threshold18_6 E
  exact threshold_step (g418 E) (!g2388 E) (!g2386 E) 7 (countTrue (score4_vals18 E)) T1 T0
theorem score4_threshold20_7 (E : Nat→Bool) : ((!g2458 E)=true) ↔ 8≤countTrue (score4_vals20 E) := by
  have rew : (!g2458 E) = ((!g2422 E) || ((g419 E) && (!g2420 E))) := by simp [g1,g2457,g2458,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold19_7 E
  have T0 := score4_threshold19_6 E
  exact threshold_step (g419 E) (!g2422 E) (!g2420 E) 7 (countTrue (score4_vals19 E)) T1 T0
theorem score4_threshold21_7 (E : Nat→Bool) : ((!g2496 E)=true) ↔ 8≤countTrue (score4_vals21 E) := by
  have rew : (!g2496 E) = ((!g2458 E) || ((g420 E) && (!g2456 E))) := by simp [g1,g2495,g2496,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold20_7 E
  have T0 := score4_threshold20_6 E
  exact threshold_step (g420 E) (!g2458 E) (!g2456 E) 7 (countTrue (score4_vals20 E)) T1 T0
theorem score4_threshold9_8 (E : Nat→Bool) : ((g2173 E)=true) ↔ 9≤countTrue (score4_vals9 E) := by
  have rew : (g2173 E) = ((!g1 E) || ((g396 E) && (g2157 E))) := by simp [g1,g2173,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 9≤countTrue (score4_vals8 E) := by
    have hh := count_true_bound (score4_vals8 E)
    change countTrue (score4_vals8 E)≤8 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬9≤countTrue (score4_vals8 E)
    omega
  have T0 := score4_threshold8_7 E
  exact threshold_step (g396 E) (!g1 E) (g2157 E) 8 (countTrue (score4_vals8 E)) T1 T0
theorem score4_threshold10_8 (E : Nat→Bool) : ((!g2190 E)=true) ↔ 9≤countTrue (score4_vals10 E) := by
  have rew : (!g2190 E) = ((g2173 E) || ((g397 E) && (!g2172 E))) := by simp [g1,g2189,g2190,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold9_8 E
  have T0 := score4_threshold9_7 E
  exact threshold_step (g397 E) (g2173 E) (!g2172 E) 8 (countTrue (score4_vals9 E)) T1 T0
theorem score4_threshold11_8 (E : Nat→Bool) : ((!g2208 E)=true) ↔ 9≤countTrue (score4_vals11 E) := by
  have rew : (!g2208 E) = ((!g2190 E) || ((g398 E) && (!g2188 E))) := by simp [g1,g2207,g2208,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold10_8 E
  have T0 := score4_threshold10_7 E
  exact threshold_step (g398 E) (!g2190 E) (!g2188 E) 8 (countTrue (score4_vals10 E)) T1 T0
theorem score4_threshold12_8 (E : Nat→Bool) : ((!g2228 E)=true) ↔ 9≤countTrue (score4_vals12 E) := by
  have rew : (!g2228 E) = ((!g2208 E) || ((g402 E) && (!g2206 E))) := by simp [g1,g2227,g2228,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold11_8 E
  have T0 := score4_threshold11_7 E
  exact threshold_step (g402 E) (!g2208 E) (!g2206 E) 8 (countTrue (score4_vals11 E)) T1 T0
theorem score4_threshold13_8 (E : Nat→Bool) : ((!g2250 E)=true) ↔ 9≤countTrue (score4_vals13 E) := by
  have rew : (!g2250 E) = ((!g2228 E) || ((g406 E) && (!g2226 E))) := by simp [g1,g2249,g2250,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold12_8 E
  have T0 := score4_threshold12_7 E
  exact threshold_step (g406 E) (!g2228 E) (!g2226 E) 8 (countTrue (score4_vals12 E)) T1 T0
theorem score4_threshold14_8 (E : Nat→Bool) : ((!g2274 E)=true) ↔ 9≤countTrue (score4_vals14 E) := by
  have rew : (!g2274 E) = ((!g2250 E) || ((g407 E) && (!g2248 E))) := by simp [g1,g2273,g2274,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold13_8 E
  have T0 := score4_threshold13_7 E
  exact threshold_step (g407 E) (!g2250 E) (!g2248 E) 8 (countTrue (score4_vals13 E)) T1 T0
theorem score4_threshold15_8 (E : Nat→Bool) : ((!g2300 E)=true) ↔ 9≤countTrue (score4_vals15 E) := by
  have rew : (!g2300 E) = ((!g2274 E) || ((g408 E) && (!g2272 E))) := by simp [g1,g2299,g2300,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold14_8 E
  have T0 := score4_threshold14_7 E
  exact threshold_step (g408 E) (!g2274 E) (!g2272 E) 8 (countTrue (score4_vals14 E)) T1 T0
theorem score4_threshold16_8 (E : Nat→Bool) : ((!g2328 E)=true) ↔ 9≤countTrue (score4_vals16 E) := by
  have rew : (!g2328 E) = ((!g2300 E) || ((g412 E) && (!g2298 E))) := by simp [g1,g2327,g2328,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold15_8 E
  have T0 := score4_threshold15_7 E
  exact threshold_step (g412 E) (!g2300 E) (!g2298 E) 8 (countTrue (score4_vals15 E)) T1 T0
theorem score4_threshold17_8 (E : Nat→Bool) : ((!g2358 E)=true) ↔ 9≤countTrue (score4_vals17 E) := by
  have rew : (!g2358 E) = ((!g2328 E) || ((g413 E) && (!g2326 E))) := by simp [g1,g2357,g2358,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold16_8 E
  have T0 := score4_threshold16_7 E
  exact threshold_step (g413 E) (!g2328 E) (!g2326 E) 8 (countTrue (score4_vals16 E)) T1 T0
theorem score4_threshold18_8 (E : Nat→Bool) : ((!g2390 E)=true) ↔ 9≤countTrue (score4_vals18 E) := by
  have rew : (!g2390 E) = ((!g2358 E) || ((g414 E) && (!g2356 E))) := by simp [g1,g2389,g2390,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold17_8 E
  have T0 := score4_threshold17_7 E
  exact threshold_step (g414 E) (!g2358 E) (!g2356 E) 8 (countTrue (score4_vals17 E)) T1 T0
theorem score4_threshold19_8 (E : Nat→Bool) : ((!g2424 E)=true) ↔ 9≤countTrue (score4_vals19 E) := by
  have rew : (!g2424 E) = ((!g2390 E) || ((g418 E) && (!g2388 E))) := by simp [g1,g2423,g2424,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold18_8 E
  have T0 := score4_threshold18_7 E
  exact threshold_step (g418 E) (!g2390 E) (!g2388 E) 8 (countTrue (score4_vals18 E)) T1 T0
theorem score4_threshold20_8 (E : Nat→Bool) : ((!g2460 E)=true) ↔ 9≤countTrue (score4_vals20 E) := by
  have rew : (!g2460 E) = ((!g2424 E) || ((g419 E) && (!g2422 E))) := by simp [g1,g2459,g2460,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold19_8 E
  have T0 := score4_threshold19_7 E
  exact threshold_step (g419 E) (!g2424 E) (!g2422 E) 8 (countTrue (score4_vals19 E)) T1 T0
theorem score4_threshold21_8 (E : Nat→Bool) : ((!g2498 E)=true) ↔ 9≤countTrue (score4_vals21 E) := by
  have rew : (!g2498 E) = ((!g2460 E) || ((g420 E) && (!g2458 E))) := by simp [g1,g2497,g2498,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold20_8 E
  have T0 := score4_threshold20_7 E
  exact threshold_step (g420 E) (!g2460 E) (!g2458 E) 8 (countTrue (score4_vals20 E)) T1 T0
theorem score4_threshold10_9 (E : Nat→Bool) : ((g2191 E)=true) ↔ 10≤countTrue (score4_vals10 E) := by
  have rew : (g2191 E) = ((!g1 E) || ((g397 E) && (g2173 E))) := by simp [g1,g2191,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 10≤countTrue (score4_vals9 E) := by
    have hh := count_true_bound (score4_vals9 E)
    change countTrue (score4_vals9 E)≤9 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬10≤countTrue (score4_vals9 E)
    omega
  have T0 := score4_threshold9_8 E
  exact threshold_step (g397 E) (!g1 E) (g2173 E) 9 (countTrue (score4_vals9 E)) T1 T0
theorem score4_threshold11_9 (E : Nat→Bool) : ((!g2210 E)=true) ↔ 10≤countTrue (score4_vals11 E) := by
  have rew : (!g2210 E) = ((g2191 E) || ((g398 E) && (!g2190 E))) := by simp [g1,g2209,g2210,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold10_9 E
  have T0 := score4_threshold10_8 E
  exact threshold_step (g398 E) (g2191 E) (!g2190 E) 9 (countTrue (score4_vals10 E)) T1 T0
theorem score4_threshold12_9 (E : Nat→Bool) : ((!g2230 E)=true) ↔ 10≤countTrue (score4_vals12 E) := by
  have rew : (!g2230 E) = ((!g2210 E) || ((g402 E) && (!g2208 E))) := by simp [g1,g2229,g2230,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold11_9 E
  have T0 := score4_threshold11_8 E
  exact threshold_step (g402 E) (!g2210 E) (!g2208 E) 9 (countTrue (score4_vals11 E)) T1 T0
theorem score4_threshold13_9 (E : Nat→Bool) : ((!g2252 E)=true) ↔ 10≤countTrue (score4_vals13 E) := by
  have rew : (!g2252 E) = ((!g2230 E) || ((g406 E) && (!g2228 E))) := by simp [g1,g2251,g2252,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold12_9 E
  have T0 := score4_threshold12_8 E
  exact threshold_step (g406 E) (!g2230 E) (!g2228 E) 9 (countTrue (score4_vals12 E)) T1 T0
theorem score4_threshold14_9 (E : Nat→Bool) : ((!g2276 E)=true) ↔ 10≤countTrue (score4_vals14 E) := by
  have rew : (!g2276 E) = ((!g2252 E) || ((g407 E) && (!g2250 E))) := by simp [g1,g2275,g2276,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold13_9 E
  have T0 := score4_threshold13_8 E
  exact threshold_step (g407 E) (!g2252 E) (!g2250 E) 9 (countTrue (score4_vals13 E)) T1 T0
theorem score4_threshold15_9 (E : Nat→Bool) : ((!g2302 E)=true) ↔ 10≤countTrue (score4_vals15 E) := by
  have rew : (!g2302 E) = ((!g2276 E) || ((g408 E) && (!g2274 E))) := by simp [g1,g2301,g2302,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold14_9 E
  have T0 := score4_threshold14_8 E
  exact threshold_step (g408 E) (!g2276 E) (!g2274 E) 9 (countTrue (score4_vals14 E)) T1 T0
theorem score4_threshold16_9 (E : Nat→Bool) : ((!g2330 E)=true) ↔ 10≤countTrue (score4_vals16 E) := by
  have rew : (!g2330 E) = ((!g2302 E) || ((g412 E) && (!g2300 E))) := by simp [g1,g2329,g2330,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold15_9 E
  have T0 := score4_threshold15_8 E
  exact threshold_step (g412 E) (!g2302 E) (!g2300 E) 9 (countTrue (score4_vals15 E)) T1 T0
theorem score4_threshold17_9 (E : Nat→Bool) : ((!g2360 E)=true) ↔ 10≤countTrue (score4_vals17 E) := by
  have rew : (!g2360 E) = ((!g2330 E) || ((g413 E) && (!g2328 E))) := by simp [g1,g2359,g2360,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold16_9 E
  have T0 := score4_threshold16_8 E
  exact threshold_step (g413 E) (!g2330 E) (!g2328 E) 9 (countTrue (score4_vals16 E)) T1 T0
theorem score4_threshold18_9 (E : Nat→Bool) : ((!g2392 E)=true) ↔ 10≤countTrue (score4_vals18 E) := by
  have rew : (!g2392 E) = ((!g2360 E) || ((g414 E) && (!g2358 E))) := by simp [g1,g2391,g2392,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold17_9 E
  have T0 := score4_threshold17_8 E
  exact threshold_step (g414 E) (!g2360 E) (!g2358 E) 9 (countTrue (score4_vals17 E)) T1 T0
theorem score4_threshold19_9 (E : Nat→Bool) : ((!g2426 E)=true) ↔ 10≤countTrue (score4_vals19 E) := by
  have rew : (!g2426 E) = ((!g2392 E) || ((g418 E) && (!g2390 E))) := by simp [g1,g2425,g2426,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold18_9 E
  have T0 := score4_threshold18_8 E
  exact threshold_step (g418 E) (!g2392 E) (!g2390 E) 9 (countTrue (score4_vals18 E)) T1 T0
theorem score4_threshold20_9 (E : Nat→Bool) : ((!g2462 E)=true) ↔ 10≤countTrue (score4_vals20 E) := by
  have rew : (!g2462 E) = ((!g2426 E) || ((g419 E) && (!g2424 E))) := by simp [g1,g2461,g2462,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold19_9 E
  have T0 := score4_threshold19_8 E
  exact threshold_step (g419 E) (!g2426 E) (!g2424 E) 9 (countTrue (score4_vals19 E)) T1 T0
theorem score4_threshold21_9 (E : Nat→Bool) : ((!g2500 E)=true) ↔ 10≤countTrue (score4_vals21 E) := by
  have rew : (!g2500 E) = ((!g2462 E) || ((g420 E) && (!g2460 E))) := by simp [g1,g2499,g2500,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score4_threshold20_9 E
  have T0 := score4_threshold20_8 E
  exact threshold_step (g420 E) (!g2462 E) (!g2460 E) 9 (countTrue (score4_vals20 E)) T1 T0
def score4_count (E : Nat→Bool) : Nat := countTrue (score4_vals21 E)
end Graffiti384b.DiversityEleven.PendantCircuit.K5
