#!/usr/bin/env python3
from pathlib import Path
from argparse import ArgumentParser
from functools import lru_cache
import json,re
ap=ArgumentParser();ap.add_argument('base',type=Path);ap.add_argument('dir',type=Path);ap.add_argument('k',type=int)
a=ap.parse_args(); k=a.k
b=a.base; src=a.dir
ns=f'Graffiti384b.DiversityEleven.PendantCircuit.K{k}'
mod=f'DiversityElevenPendantThresholds{k}384b'
wmod=f'DiversityElevenPendantWires{k}384b'
cmod=f'DiversityElevenPendantWireClauses{k}384b'
rmod=f'DiversityElevenPendantSemanticRoots{k}384b'
info=json.loads(b.with_suffix('.semantics.json').read_text())
meta,tracks,edges,triangles=(info[x] for x in ['meta','tracks','edges','triangles'])
gates=json.loads(b.with_suffix('.gates.json').read_text())
rootslist=list(map(int,b.with_name(b.name+'_slice').with_suffix('.roots').read_text().split()))
C=[tuple(map(int,row.split()[:-1])) for row in b.with_name(b.name+'_slice').with_suffix('.cnf').read_text().splitlines()[1:]]
semrows={int(i):meta[str(rootslist[int(i)]-1)] for i in re.findall(r'^    \(h_(\d+) :',(src/(cmod+'.lean')).read_text(),re.M)}
def bl(i):return ('!' if i<0 else '')+f'g{abs(i)} E'
def v(i):return '('+bl(i)+')'
def exprrow(C):return '['+', '.join(f'.{"pos" if i>0 else "neg"} {abs(i)-1}' for i in C)+']'
E={(i,j):idx for i,j,idx in edges}
def e(i,j):return E[tuple(sorted((i,j)))]
def pairmask(i,j,v):return tuple([e(v,x) for x in (i,j)])
# Tactic-safe constant names for DP groups.
groups={}
for row,m in semrows.items():
    kind=m[0]
    for g,n in ([('degree'+str(m[1]),2)] if kind=='degree' else
        [('score'+str(m[1]),1)] if kind=='score' else
        ([('score'+str(m[1]),m[3])]+
         ([('score'+str(m[2]),m[3]+1)] if m[3]+1<len(tracks['score'+str(m[2])]['inputs']) else []))
           if kind=='ordering' else []):
        groups.setdefault(g,set()).add(n)
def cname(gr,n):return f'{gr}_vals{n}'
def sname(gr,i,j):return f'{gr}_threshold{i}_{j}'
def bool_arity(gs):
    return ','.join(map(str,gs))
with (src/(mod+'.lean')).open('w') as fp:
    def w(s):fp.write(s+'\n')
    w(f'import {wmod}\nnamespace {ns}\nset_option maxHeartbeats 3000000')
    for gr, outputs in groups.items():
        inp=tracks[gr]['inputs']
        for i,x in enumerate(inp,1):
            prev=f'{cname(gr,i-1)} E' if i>1 else '[]'
            w(f'def {cname(gr,i)} (E : Nat→Bool) : List Bool := {v(x)} :: ({prev})')
        @lru_cache(None)
        def emit(i,j):
            if i<1 or j<0 or j>=i: return
            emit(i-1,j); emit(i-1,j-1)
            z,x,h,l,andresult,new=tracks[gr]['steps'][i-1][j]
            old=f'({cname(gr,i-1)} E)' if i>1 else '([] : List Bool)'
            w(f'theorem {sname(gr,i,j)} (E : Nat→Bool) : ({v(z)}=true) ↔ {j+1}≤countTrue ({cname(gr,i)} E) := by')
            defs=','.join(['g1',*(f'g{t}' for t in new)])
            w(f'  have rew : {v(z)} = ({v(h)} || ({v(x)} && {v(l)})) := by simp [{defs},Bool.and_comm, Bool.or_comm, Bool.not_and]')
            w('  rw [rew]')
            def local(name,lit,th,dpidx):
                if dpidx<0:
                    w(f'  have {name} : {v(lit)}=true ↔ {th}≤countTrue {old} := by simp [g1]')
                elif dpidx>=i-1:
                    w(f'  have {name} : {v(lit)}=true ↔ {th}≤countTrue {old} := by')
                    w(f'    have hh := count_true_bound {old}')
                    w(f'    change countTrue {old}≤{i-1} at hh')
                    w('    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]')
                    w(f'    change ¬{th}≤countTrue {old}')
                    w('    omega')
                else:
                    w(f'  have {name} := {sname(gr,i-1,dpidx)} E')
            local('T1',h,j+1,j)
            local('T0',l,j,j-1)
            w(f'  exact threshold_step {v(x)} {v(h)} {v(l)} {j} (countTrue {old}) T1 T0')
        for j in sorted(outputs):emit(len(inp),j)
        w(f'def {gr}_count (E : Nat→Bool) : Nat := countTrue ({cname(gr,len(inp))} E)')
    w(f'end {ns}')
print('Degree/score DP groups',str(groups))
def negterm(i):return f'(¬ ({v(i)}=true))' if i>0 else f'({v(-i)}=true)'
def ad(i,j):return f'edge E {i} {j}'
def degreeArg(i):return f'degree{i}_count E'
def scoreArg(i):return f'score{i}_count E'
def dtag(v):return 2 if v<k else 1
def rawcount(Q,v):
    return f'countTrue [{", ".join(ad(v,x) for x in Q)}]'
def data_gate(q):
    if abs(q)<30:return set()
    z=abs(q);ga=gates[z];return {z}|set.union(set(),*(data_gate(t) for t in ga[1:]))
with (src/(rmod+'.lean')).open('w') as fp:
    def w(s):fp.write(s+'\n')
    w(f'import {mod}\nimport {cmod}\nimport Mathlib.Data.Finset.Card\nimport Mathlib.Tactic.FinCases')
    w(f'namespace {ns}\nopen Sat Finset')
    w('set_option maxRecDepth 32768\nset_option maxHeartbeats 15000000')
    w('def edgeNumber (i j : Fin 8) : Nat :=\n  let a := min i.val j.val\n  let b := max i.val j.val\n  2 + (a*(15-a))/2 + (b-a-1)')
    w('def edge (E : Nat→Bool) (i j : Fin 8) : Bool := if i=j then false else E (edgeNumber i j)')
    w('def portRank (E : Nat→Bool) (i : Fin 8) : Nat :=\n  (if edge E 1 i then 1 else 0)+(if edge E 0 i then 2 else 0)')
    w('private theorem negWire (b : Bool) : ((!b)=true) ↔ ¬b=true := by cases b <;> decide')
    w(f'def HasTriple (E : Nat→Bool) : Prop :=\n  ∃ a b c : Fin 8, a<b ∧ b<c ∧ ∀ v : Fin 8, v≠a → v≠b → v≠c →\n    (if v.val < {k} then 2 else 1)≤countTrue [edge E v a,edge E v b,edge E v c]')
    for r,m in semrows.items():
        tag,*us=m
        rr=C[r]
        sig=f'private theorem root_{r} (E : Nat→Bool)'
        if tag=='degree':
            (i,)=us
            sig+=f' (h : 3≤{degreeArg(i)})'
        if tag=='score':
            (i,)=us
            sig+=f' (h : 2≤{scoreArg(i)})'
        if tag=='ordering':
            i,j,n=us
            sig+=f' (h : {scoreArg(i)}<{scoreArg(j)})'
        if tag=='port':
            i,j,A,B,ng=us
            sig+=f' (h : portRank E {i}≤portRank E {j})'
        if tag=='cover':
            Q,hits,ng=us
            sig+=' (h : ¬HasTriple E)'
        w(f'{sig} : (valuation E).satisfies {exprrow(rr)} := by')
        w('  change '+' → '.join([*map(negterm,rr),'False']))
        if tag in ('degree','score'):
            gr=tag+str(i); n=2 if tag=='degree' else 1
            target=f'(({sname(gr,len(tracks[gr]["inputs"]),n)} E).mpr h)'
            assert len(rr)==1
            w('  intro hn')
            if rr[0]>0: w(f'  exact hn {target}')
            else: w(f'  exact (negWire _).mp {target} hn')
        if tag=='ordering':
            gr,gq=map(lambda x:'score'+str(x),(i,j))
            si,sj=(tracks[g]['threshold'] for g in (gr,gq))
            wi=si[n]; wj=sj[n+1] if n+1<len(sj) else -1
            names={-wi:'old',wj:'fail'}
            w('  intro '+' '.join(names[x] for x in rr))
            sf='old' if wi>0 else '((negWire _).mpr old)'
            w(f'  have oldScore := ({sname(gr,len(si),n)} E).mp {sf}')
            if n+1<len(sj):
                w(f'  have newScore := threshold_of_strict _ _ {n} h oldScore')
                tf=f'(({sname(gq,len(sj),n+1)} E).mpr newScore)'
                if wj>0: w(f'  exact fail {tf}')
                else: w(f'  exact (negWire _).mp {tf} fail')
            else:
                w(f'  have m := count_true_bound ({cname(gq,len(sj))} E)')
                w(f'  change {scoreArg(j)}≤{len(sj)} at m')
                w('  omega')
        if tag=='port':
            w('  intro contrary')
            w(f'  change (if {v(A[0])} then 1 else 0) + (if {v(A[1])} then 2 else 0) ≤ '+
              f'(if {v(B[0])} then 1 else 0) + (if {v(B[1])} then 2 else 0) at h')
            vv=A+B
            cases=' <;> '.join(f'cases q{x} : {bl(x)}' for x in vv)
            gn=bool_arity(f'g{g}' for g in ng)
            qn=bool_arity(f'q{x}' for x in vv)
            w(f'  {cases} <;> simp [{gn},{qn}] at h contrary')
        if tag=='cover':
            outside=[v for v in range(8) if v not in Q]
            hd={h:v for h,v in zip(hits,outside)}
            assert set(-x for x in rr)==set(hd)
            w('  intro '+' '.join('c'+str(hd[-x]) for x in rr))
            aa,bb,cc=Q
            w(f'  apply h\n  refine ⟨{aa},{bb},{cc},by decide,by decide,?_⟩')
            w('  intro v va vb vc\n  fin_cases v')
            for v0 in range(8):
                if v0 in Q:
                    nd=['va','vb','vc'][Q.index(v0)]
                    w(f'  · exact ({nd} rfl).elim')
                else:
                    hit=hits[outside.index(v0)]
                    fld='one' if v0>=k else 'two'
                    expected=' || '.join(ad(v0,q) for q in Q) if fld=='one' else ' || '.join(
                        f'({ad(v0,i)} && {ad(v0,j)})' for i,j in [(aa,bb),(aa,cc),(bb,cc)])
                    # The score condition now has a concrete vertex, with exact arithmetic demand.
                    args=' '.join(f'({ad(v0,q)})' for q in Q)
                    w(f'  · change {dtag(v0)}≤{rawcount(Q,v0)}')
                    w(f'    apply (mask_ge_{fld} {args}).mp')
                    eargs=[e(v0,q) for q in Q]
                    gan=', '.join('g'+str(i) for i in sorted(data_gate(hit)))
                    expect=' || '.join(v(i) for i in eargs) if fld=='one' else ' || '.join(
                        f'({v(eargs[i])} && {v(eargs[j])})' for i,j in [(0,1),(0,2),(1,2)])
                    w(f'    change ({expect})=true')
                    cv=f'c{v0}' if hit>0 else f'((negWire _).mpr c{v0})'
                    w(f'    simpa [{gan}, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using {cv}')
    quals={'degree':set(),'score':set(),'ordering':set(),'port':set()}
    for m in semrows.values():
        tag,*us=m
        if tag in ('degree','score'): quals[tag].add(us[0])
        elif tag in ('ordering','port'): quals[tag].add((us[0],us[1]))
    w('theorem have_triple_of_exact_counts (E : Nat→Bool)')
    for i in sorted(quals['degree']): w(f'    (d{i} : 3≤{degreeArg(i)})')
    for i in sorted(quals['score']): w(f'    (s{i} : 2≤{scoreArg(i)})')
    for i,j in sorted(quals['ordering']): w(f'    (o{i}{j} : {scoreArg(i)}<{scoreArg(j)})')
    for i,j in sorted(quals['port']): w(f'    (p{i}{j} : portRank E {i}≤portRank E {j})')
    w('    : HasTriple E := by')
    w('  by_contra n')
    w('  apply contradiction_of_semantic_roots E')
    names={'degree':'d','score':'s','ordering':'o','port':'p'}
    for r,m in semrows.items():
        tag,*us=m
        par='n' if tag=='cover' else names[tag]+''.join(map(str,us[:2] if tag in ('ordering','port') else us[:1]))
        w(f'  · exact root_{r} E {par}')
    w('#print axioms have_triple_of_exact_counts')
    w(f'end {ns}')
