import DiversityElevenMathlibRup384b
import Lean.Elab.Tactic.Omega

namespace Graffiti384b.DiversityEleven.PendantCircuit
open Sat

/-- Numeric semantics used in degree, triangle-score and hitting counts. -/
def countTrue : List Bool → Nat
  | [] => 0
  | b::bs => countTrue bs + if b then 1 else 0

theorem count_true_bound (xs : List Bool) : countTrue xs≤xs.length := by
  induction xs with
  | nil => simp [countTrue]
  | cons a xs ih =>
      cases a <;> simp [countTrue] <;> omega

theorem threshold_step (a p q : Bool) (k d : Nat)
    (hp : p=true ↔ k+1≤d) (hq : q=true ↔ k≤d) :
    (p || (a && q))=true ↔ k+1≤d+(if a then 1 else 0) := by
  cases a <;> simp only [Bool.false_and, Bool.true_and, Bool.or_false, Bool.or_eq_true,
    Bool.false_eq_true, Bool.true_eq, ↓reduceIte, hp, hq] <;> omega

theorem strict_of_thresholds (m n bound : Nat) (hm : 1≤m) (hb : m≤bound)
    (step : ∀ k, k<bound → k+1≤m → k+2≤n) : m<n := by
  have h := step (m-1) (by omega) (by omega)
  omega

theorem threshold_of_strict (m n k : Nat) (lt : m<n) (h : k+1≤m) : k+2≤n := by omega

theorem mask_ge_one (a b c : Bool) :
    (a || b || c)=true ↔ 1≤countTrue [a,b,c] := by
  cases a <;> cases b <;> cases c <;> decide

theorem mask_ge_two (a b c : Bool) :
    ((a && b) || (a && c) || (b && c))=true ↔ 2≤countTrue [a,b,c] := by
  cases a <;> cases b <;> cases c <;> decide

theorem sat_mem (v : Valuation) :
    ∀ c : List Literal, (∃ l∈c,¬v.neg l) → v.satisfies c
  | [], h => by obtain ⟨_,h,_⟩ := h; cases h
  | l::ls, h => by
    intro no
    obtain ⟨u,um,hu⟩ := h
    rcases List.mem_cons.mp um with rfl|hm
    · exact (hu no).elim
    · exact sat_mem v ls ⟨u,hm,hu⟩

theorem fmla_and (v : Valuation) (f g : Fmla)
    (hf : v.satisfies_fmla f) (hg : v.satisfies_fmla g) :
    v.satisfies_fmla (Fmla.and f g) := by
  constructor
  intro c h
  rcases List.mem_append.mp h with h|h
  · exact hf.1 _ h
  · exact hg.1 _ h

theorem fmla_one (v : Valuation) (c : Clause)
    (h : v.satisfies c) : v.satisfies_fmla (Fmla.one c) := by
  constructor
  intro d dm
  exact (List.mem_singleton.mp dm).symm ▸ h

#print axioms threshold_step
#print axioms sat_mem
#print axioms fmla_and
end Graffiti384b.DiversityEleven.PendantCircuit
