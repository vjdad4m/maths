import Mathlib.Tactic.Sat.FromLRAT

/-! The Mathlib proof-term checker, without propositional reification.
The elaborator uses temporary computations to propose declarations;
the Lean kernel checks the generated concrete proof of unsatisfiability.
-/
open Lean Elab Meta
open Mathlib.Tactic.Sat

namespace Graffiti384b.DiversityEleven

elab "packed_rup " n:ident ppSpace cnf:term:max ppSpace trace:term:max : command => do
  let name := (← getCurrNamespace) ++ n.getId
  Command.liftTermElabM do
    let c ← unsafe Term.evalTerm String (mkConst ``String) cnf
    let t ← unsafe Term.evalTerm String (mkConst ``String) trace
    let (_,f,_,prf) ← fromLRATAux c t name
    let ctx := name ++ `formula
    addDecl <| .defnDecl {
      name := ctx, levelParams := [],
      type := mkConst ``_root_.Sat.Fmla, value := f,
      hints := .abbrev, safety := .safe }
    addDecl <| .thmDecl {
      name, levelParams := [],
      type := mkApp2 (mkConst ``_root_.Sat.Fmla.proof) (mkConst ctx) (mkConst ``_root_.Sat.Clause.nil),
      value := prf }

end Graffiti384b.DiversityEleven
