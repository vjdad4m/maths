import DiversityElevenPendantFinite384b
import Mathlib.Data.Fin.Tuple.Sort

namespace Graffiti384b.DiversityEleven
open Finset SimpleGraph
open private Repair.triangles_le_choose from Repair384b

/-- Any score-sorted labelling with a strict gap from all tags to all
nontags puts the three tags precisely at indices 0, 1, 2. -/
private theorem sorted_tag_prefix (Z : Finset (Fin 8)) (sz : Z.card=3)
    (e : Fin 8 ≃ Fin 8) (key : Fin 8 → Nat)
    (ord : Monotone (fun i => key (e i)))
    (sep : ∀ a∈Z,∀ b∉Z,key a<key b) :
    ∀ i : Fin 8, e i∈Z ↔ i.val<3 := by
  classical
  let Q := ({0,1,2}:Finset (Fin 8))
  have shape (i : Fin 8) : i∈Q ↔ i.val<3 := by
    exact (show ∀ j : Fin 8, j∈({0,1,2}:Finset (Fin 8)) ↔ j.val<3 by decide) i
  have Qc : Q.card=3 := by decide
  have two : e 2∈Z := by
    by_cases t : e 2∈Z
    · exact t
    exfalso
    let P := ({0,1}:Finset (Fin 8))
    have shape' (i : Fin 8) : i∈P ↔ i.val<2 :=
      (show ∀ j : Fin 8, j∈({0,1}:Finset (Fin 8)) ↔ j.val<2 by decide) i
    have sub : Z⊆P.map e.toEmbedding := by
      intro z zm
      let j := e.symm z
      have jz : e j=z := e.apply_symm_apply z
      have o : j.val<2 := by
        by_contra! ge
        have both := ord (show (2 : Fin 8)≤j from ge)
        change key (e 2)≤key (e j) at both
        rw [jz] at both
        exact (not_le_of_gt (sep z zm _ t)) both
      exact mem_map.mpr ⟨j,(shape' j).mpr o,jz⟩
    have c := card_le_card sub
    rw [sz,card_map,show P.card=2 by decide] at c
    omega
  have sub : Q.map e.toEmbedding ⊆ Z := by
    intro z zm
    obtain ⟨i,im,rfl⟩ := mem_map.mp zm
    have i2 : i≤(2 : Fin 8) := by
      have h := (shape i).mp im
      change i.val≤2
      omega
    by_cases z : e i∈Z
    · exact z
    exact False.elim ((not_le_of_gt (sep _ two _ z)) (ord i2))
  have eq : Q.map e.toEmbedding=Z := eq_of_subset_of_card_le sub (by rw [card_map,Qc,sz])
  intro i
  rw [←eq]
  change e.toEmbedding i∈Q.map e.toEmbedding ↔ _
  rw [mem_map']
  exact shape i

/-- Sort tags by triangle score and the other five labels by their
binary contacts to the first and second tag. Two sorts suffice: the
chosen contact ports are unchanged by the secondary sort. -/
theorem order_three_tags (G : SimpleGraph (Fin 8)) [DecidableRel G.Adj]
    (Z : Finset (Fin 8)) (sz : Z.card=3)
    (inj : Set.InjOn (trianglesAt G) (Z : Set (Fin 8))) :
    ∃ e : Fin 8 ≃ Fin 8,
      (∀ i : Fin 8,e i∈Z ↔ i.val<3) ∧
      (∀ i j : Fin 8, i<j → j.val<3 → trianglesAt G (e i)<trianglesAt G (e j)) ∧
      (∀ i j : Fin 8, i≤j → 3≤i.val →
        (if G.Adj (e 1) (e i) then 1 else 0)+(if G.Adj (e 0) (e i) then 2 else 0) ≤
          (if G.Adj (e 1) (e j) then 1 else 0)+(if G.Adj (e 0) (e j) then 2 else 0)) := by
  classical
  let key₁ (v : Fin 8) := if v∈Z then trianglesAt G v else 30
  have lim (v : Fin 8) : trianglesAt G v<30 := by
    have sub := card_le_card (show G.neighborFinset v⊆univ from subset_univ _)
    rw [G.card_neighborFinset_eq_degree,card_univ,Fintype.card_fin] at sub
    have x := (Repair.triangles_le_choose G v).trans (Nat.choose_le_choose 2 sub)
    exact x.trans_lt (by decide)
  have sep₁ : ∀ a∈Z,∀ b∉Z,key₁ a<key₁ b := by
    intro a ha b hb
    simpa [key₁,ha,hb] using lim a
  let e₁ := Tuple.sort key₁
  have mono₁ : Monotone (fun i => key₁ (e₁ i)) := Tuple.monotone_sort key₁
  have pre₁ := sorted_tag_prefix Z sz e₁ key₁ mono₁ sep₁
  let rank (v : Fin 8) : Nat :=
    (if G.Adj (e₁ 1) v then 1 else 0)+(if G.Adj (e₁ 0) v then 2 else 0)
  let key₂ (v : Fin 8) := if v∈Z then trianglesAt G v else 30+rank v
  have sep₂ : ∀ a∈Z,∀ b∉Z,key₂ a<key₂ b := by
    intro a ha b hb
    have x := lim a
    simp only [key₂,ha,hb,if_true,if_false]
    omega
  let e₂ := Tuple.sort key₂
  have mono₂ : Monotone (fun i => key₂ (e₂ i)) := Tuple.monotone_sort key₂
  have pre₂ := sorted_tag_prefix Z sz e₂ key₂ mono₂ sep₂
  have zero : e₁ 0=e₂ 0 := by
    let i := e₁.symm (e₂ 0)
    let j := e₂.symm (e₁ 0)
    have ei : e₁ i=e₂ 0 := e₁.apply_symm_apply _
    have ej : e₂ j=e₁ 0 := e₂.apply_symm_apply _
    have z₁ := (pre₁ 0).mpr (by decide)
    have z₂ := (pre₂ 0).mpr (by decide)
    have l := mono₁ (show (0:Fin 8)≤i from Fin.zero_le i)
    have r := mono₂ (show (0:Fin 8)≤j from Fin.zero_le j)
    change key₁ (e₁ 0)≤key₁ (e₁ i) at l
    change key₂ (e₂ 0)≤key₂ (e₂ j) at r
    rw [ei] at l
    rw [ej] at r
    have le : trianglesAt G (e₁ 0)≤trianglesAt G (e₂ 0) := by simpa [key₁,z₁,z₂] using l
    have ge : trianglesAt G (e₂ 0)≤trianglesAt G (e₁ 0) := by simpa [key₂,z₁,z₂] using r
    exact inj z₁ z₂ (Nat.le_antisymm le ge)
  have one : e₁ 1=e₂ 1 := by
    let i := e₁.symm (e₂ 1)
    let j := e₂.symm (e₁ 1)
    have ei : e₁ i=e₂ 1 := e₁.apply_symm_apply _
    have ej : e₂ j=e₁ 1 := e₂.apply_symm_apply _
    have pig : (1:Fin 8)≤i := by
      have nz : i≠0 := fun q => (by
        rw [q,zero] at ei
        have opposite : (0:Fin 8)=(1:Fin 8) := e₂.injective ei
        contradiction : False)
      have positive : 0<i.val := by
        by_contra! h
        have q : i.val=0 := by omega
        exact nz (Fin.ext q)
      exact positive
    have pjg : (1:Fin 8)≤j := by
      have nz : j≠0 := fun q => (by
        rw [q,←zero] at ej
        have opposite : (0:Fin 8)=(1:Fin 8) := e₁.injective ej
        contradiction : False)
      have positive : 0<j.val := by
        by_contra! h
        have q : j.val=0 := by omega
        exact nz (Fin.ext q)
      exact positive
    have z₁ := (pre₁ 1).mpr (by decide)
    have z₂ := (pre₂ 1).mpr (by decide)
    have l := mono₁ pig
    have r := mono₂ pjg
    change key₁ (e₁ 1)≤key₁ (e₁ i) at l
    change key₂ (e₂ 1)≤key₂ (e₂ j) at r
    rw [ei] at l
    rw [ej] at r
    have le : trianglesAt G (e₁ 1)≤trianglesAt G (e₂ 1) := by simpa [key₁,z₁,z₂] using l
    have ge : trianglesAt G (e₂ 1)≤trianglesAt G (e₁ 1) := by simpa [key₂,z₁,z₂] using r
    exact inj z₁ z₂ (Nat.le_antisymm le ge)
  refine ⟨e₂,pre₂,?_,?_⟩
  · intro i j ij sj
    have zi := (pre₂ i).mpr (by have h : i.val<j.val := ij; omega)
    have zj := (pre₂ j).mpr sj
    have mm := mono₂ (le_of_lt ij)
    have le : trianglesAt G (e₂ i)≤trianglesAt G (e₂ j) := by simpa [key₂,zi,zj] using mm
    exact lt_of_le_of_ne le (fun h => ij.ne (e₂.injective (inj zi zj h)))
  · intro i j ij si
    have ni : e₂ i∉Z := fun h => (not_lt_of_ge si) ((pre₂ i).mp h)
    have nj : e₂ j∉Z := fun h => by have h' := (pre₂ j).mp h; have ij' : i.val≤j.val := ij; omega
    have mm := mono₂ ij
    simp only [key₂,if_neg ni,if_neg nj,Nat.add_le_add_iff_left] at mm
    simpa [rank,zero,one] using mm

#print axioms order_three_tags
end Graffiti384b.DiversityEleven
