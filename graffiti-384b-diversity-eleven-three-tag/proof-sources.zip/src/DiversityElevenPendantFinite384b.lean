import DiversityElevenPendantTags384b
import DiversityElevenSixTriangleRange384b

namespace Graffiti384b.DiversityEleven
open Finset SimpleGraph ShorePairs
variable {V : Type*} [Fintype V] [DecidableEq V]
  (G : SimpleGraph V) [DecidableRel G.Adj]

private theorem triangle_range_eight (U : Finset V) (a : Fin 8 ≃ U) (i : Fin 8)
    (closed : ∀ x y, G.Adj (a i).val x → G.Adj (a i).val y → G.Adj x y → x∈U ∧ y∈U) :
    let H := G.comap (fun i => (a i).val)
    letI : DecidableRel H.Adj := fun x y => inferInstanceAs (Decidable (G.Adj (a x).val (a y).val))
    trianglesAt H i=trianglesAt G (a i).val := by
  classical
  let H := G.comap (fun i => (a i).val)
  letI : DecidableRel H.Adj := fun x y => inferInstanceAs (Decidable (G.Adj (a x).val (a y).val))
  let em : Fin 8 ↪ V := a.toEmbedding.trans (Function.Embedding.subtype _)
  change (pairs H (H.neighborFinset i)).card = (pairs G (G.neighborFinset (a i).val)).card
  have eq : (pairs H (H.neighborFinset i)).image (fun s=>s.map em)=
      pairs G (G.neighborFinset (a i).val) := by
    ext p
    constructor
    · intro pm
      obtain ⟨q,qs,rfl⟩ := mem_image.mp pm
      obtain ⟨x,xm,y,ym,xy,rfl⟩ := (pair_mem H).mp qs
      have x1 : (a x).val∈G.neighborFinset (a i).val := (G.mem_neighborFinset ..).mpr
        ((H.mem_neighborFinset ..).mp xm)
      have y1 : (a y).val∈G.neighborFinset (a i).val := (G.mem_neighborFinset ..).mpr
        ((H.mem_neighborFinset ..).mp ym)
      exact (pair_mem G).mpr ⟨(a x).val,x1,(a y).val,y1,xy,by simp [em]⟩
    · intro pm
      obtain ⟨x,xm,y,ym,xy,rfl⟩ := (pair_mem G).mp pm
      obtain ⟨xu,yu⟩ := closed x y ((G.mem_neighborFinset ..).mp xm) ((G.mem_neighborFinset ..).mp ym) xy
      let xi : Fin 8 := a.symm ⟨x,xu⟩
      let yi : Fin 8 := a.symm ⟨y,yu⟩
      have xx : (a xi).val=x := by simp [xi]
      have yy : (a yi).val=y := by simp [yi]
      have jx : xi∈H.neighborFinset i := (H.mem_neighborFinset ..).mpr
        (by change G.Adj (a i).val (a xi).val; rw [xx]; exact (G.mem_neighborFinset ..).mp xm)
      have jy : yi∈H.neighborFinset i := (H.mem_neighborFinset ..).mpr
        (by change G.Adj (a i).val (a yi).val; rw [yy]; exact (G.mem_neighborFinset ..).mp ym)
      have e : H.Adj xi yi := by change G.Adj (a xi).val (a yi).val; rwa [xx,yy]
      exact mem_image.mpr ⟨{xi,yi},(pair_mem H).mpr ⟨xi,jx,yi,jy,e,rfl⟩,by
        simp [em,xi,yi]⟩
  rw [←eq,card_image_of_injective _ (Finset.map_injective em)]

omit [Fintype V] [DecidableEq V] in
private theorem count_eight (U : Finset V) (a : Fin 8 ≃ U) (i : Fin 8) :
    let H := G.comap (fun i => (a i).val)
    letI : DecidableRel H.Adj := fun x y => inferInstanceAs (Decidable (G.Adj (a x).val (a y).val))
    H.degree i=nbr G (a i).val U := by
  classical
  let H := G.comap (fun i => (a i).val)
  letI : DecidableRel H.Adj := fun x y => inferInstanceAs (Decidable (G.Adj (a x).val (a y).val))
  let em : Fin 8 ↪ V := a.toEmbedding.trans (Function.Embedding.subtype _)
  have eq : (H.neighborFinset i).map em = U.filter (G.Adj (a i).val) := by
    ext x
    constructor
    · intro xm
      obtain ⟨j,jm,rfl⟩ := mem_map.mp xm
      exact mem_filter.mpr ⟨(a j).property,(H.mem_neighborFinset ..).mp jm⟩
    · intro xm
      obtain ⟨xu,ix⟩ := mem_filter.mp xm
      let j : Fin 8 := a.symm ⟨x,xu⟩
      have eq : (a j).val=x := by simp [j]
      refine mem_map.mpr ⟨j,(H.mem_neighborFinset ..).mpr ?_,eq⟩
      change G.Adj (a i).val (a j).val
      rwa [eq]
  change H.degree i=(U.filter (G.Adj (a i).val)).card
  rw [←eq,card_map,card_neighborFinset_eq_degree]

/-- Uniform finite remainder: dense labelled eight-board with 3–6
zero tags of distinct internal triangle scores at least two. A weighted
retained triple would close the remaining pendant branch. -/
def DenseEightSelector : Prop :=
  ∀ (H : SimpleGraph (Fin 8)) (dec : DecidableRel H.Adj) (Z : Finset (Fin 8)),
    letI := dec
    (∀ i,3≤H.degree i) → 3≤Z.card → Z.card≤6 →
    (∀ i∈Z,2≤trianglesAt H i) → Set.InjOn (trianglesAt H) (Z : Set (Fin 8)) →
    ∃ K : Finset (Fin 8), K.card=3 ∧ ∀ i∉K,
      (if i∈Z then 2 else 1)≤nbr H i K

/-- The finite eight-board selector implies the exact conjecture on
every remaining supported dense pendant branch. No solver certificate
is assumed by this structural transfer theorem. -/
theorem exact_pendant_of_dense_eight_selector (select : DenseEightSelector)
    (sup : Supported G) (t : (types G).card=11) (nine : (high G).card=9)
    {e f a : V} (ah : a∈high G) (low : nonleaves G \ high G={e,f})
    (en : G.neighborFinset e={f,a}) (fn : G.neighborFinset f={e,a})
    (scores : Set.InjOn (trianglesAt G) (high G : Set V))
    (mins : ∀ v∈high G, 2≤trianglesAt G v)
    (dense : ∀ v∈(high G).erase a, 3≤nbr G v ((high G).erase a))
    (tagmin : 3≤(((high G).erase a).filter (fun v => ¬G.Adj v a)).card) :
    gamma G≤bound G := by
  classical
  let B := (high G).erase a
  let U := B.filter (fun v => ¬G.Adj v a)
  have sz : B.card=8 := by dsimp [B]; rw [card_erase_of_mem ah,nine]
  let l : Fin 8 ≃ B := (Fintype.equivFinOfCardEq
    (show Fintype.card B=8 by rwa [Fintype.card_coe])).symm
  let H := G.comap (fun i => (l i).val)
  let dec : DecidableRel H.Adj := fun i j => inferInstanceAs (Decidable (G.Adj (l i).val (l j).val))
  letI := dec
  let F : Fin 8 ↪ V := l.toEmbedding.trans (Function.Embedding.subtype _)
  let Z := univ.filter (fun i : Fin 8 => ¬G.Adj (l i).val a)
  have tag (i : Fin 8) : i∈Z ↔ ¬G.Adj (l i).val a := by simp [Z]
  have eq : Z.map F=U := by
    ext v
    constructor
    · intro vm
      obtain ⟨i,iz,rfl⟩ := mem_map.mp vm
      exact mem_filter.mpr ⟨(l i).property,(tag i).mp iz⟩
    · intro vm
      obtain ⟨vB,va⟩ := mem_filter.mp vm
      let i := l.symm ⟨v,vB⟩
      have iv : (l i).val=v := by simp [i]
      exact mem_map.mpr ⟨i,(tag i).mpr (by rwa [iv]),iv⟩
  have UZ : U.card=Z.card := by rw [←eq,card_map]
  have zh : Z.card≤6 := by rw [←UZ]; exact pendant_zero_tags_le_six G sup nine ah (mins a ah) low en fn
  have zl : 3≤Z.card := by rw [←UZ]; exact tagmin
  have de (i : Fin 8) : 3≤H.degree i := by
    rw [count_eight G B l i]
    exact dense _ (l i).property
  have ht (i : Fin 8) (iz : i∈Z) : trianglesAt H i=trianglesAt G (l i).val := by
    apply triangle_range_eight G B l i
    intro x y ix iy _
    have hn := (pendant_board_local G sup ah low en fn (l i).property).1
    have sub {u : V} (iu : G.Adj (l i).val u) : u∈B :=
      mem_erase.mpr ⟨fun e => (tag i).mp iz (e ▸ iu),hn u iu⟩
    exact ⟨sub ix,sub iy⟩
  have hh (i : Fin 8) : (l i).val∈high G := (mem_erase.mp (l i).property).2
  have sc : Set.InjOn (trianglesAt H) (Z : Set (Fin 8)) := by
    intro i ih j jh he
    apply l.injective
    apply Subtype.ext
    exact scores (hh i) (hh j) ((ht i ih).symm.trans (he.trans (ht j jh)))
  obtain ⟨K,k3,good⟩ := select H dec Z de zl zh
    (fun i iz => (ht i iz).symm ▸ mins _ (hh i)) sc
  let M := K.map F
  have ms : M⊆B := by
    intro v vm
    obtain ⟨i,_,rfl⟩ := mem_map.mp vm
    exact (l i).property
  have m3 : M.card=3 := (card_map ..).trans k3
  have el : e∉high G := (mem_sdiff.mp (low ▸ mem_insert_self _ _)).2
  have fl : f∉high G := (mem_sdiff.mp (low ▸ mem_insert_of_mem (mem_singleton_self _))).2
  have ea : G.Adj e a := (G.mem_neighborFinset ..).mp (en ▸ mem_insert_of_mem (mem_singleton_self _))
  have ef : G.Adj e f := (G.mem_neighborFinset ..).mp (en ▸ mem_insert_self _ _)
  apply exact_of_pendant_triple G t nine ea ef ah el fl ms m3
  intro v vm
  obtain ⟨vB,vM⟩ := mem_sdiff.mp vm
  let i := l.symm ⟨v,vB⟩
  have iv : (l i).val=v := by simp [i]
  have ik : i∉K := fun h => vM (mem_map.mpr ⟨i,h,iv⟩)
  have ce : (K.filter (H.Adj i)).map F=M.filter (G.Adj v) := by
    ext w
    constructor
    · intro hw
      obtain ⟨j,jm,rfl⟩ := mem_map.mp hw
      exact mem_filter.mpr ⟨mem_map.mpr ⟨j,(mem_filter.mp jm).1,rfl⟩,
        by rw [←iv]; exact (mem_filter.mp jm).2⟩
    · intro hw
      obtain ⟨wm,vw⟩ := mem_filter.mp hw
      obtain ⟨j,jm,rfl⟩ := mem_map.mp wm
      exact mem_map.mpr ⟨j,mem_filter.mpr ⟨jm,by change G.Adj (l i).val _; rwa [iv]⟩,rfl⟩
  have cnt : nbr H i K=nbr G v M := (card_map ..).symm.trans (congrArg card ce)
  have g := good i ik
  rw [cnt] at g
  have z : i∈Z ↔ ¬G.Adj v a := (tag i).trans (by rw [iv])
  by_cases va : G.Adj v a
  · rw [if_neg (fun h => (z.mp h) va)] at g
    rw [if_pos va]
    omega
  · rw [if_pos (z.mpr va)] at g
    simpa [va] using g

#print axioms exact_pendant_of_dense_eight_selector
end Graffiti384b.DiversityEleven
