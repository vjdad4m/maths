import DiversityElevenMathlibRup384b

namespace Graffiti384b.DiversityEleven
set_option maxRecDepth 32768
set_option maxHeartbeats 100000000

packed_rup pendant_three_rup
  (include_str "../q11-study/dp3_slice.cnf")
  (include_str "../q11-study/dp3_slice.lrat")

#print axioms pendant_three_rup
end Graffiti384b.DiversityEleven
