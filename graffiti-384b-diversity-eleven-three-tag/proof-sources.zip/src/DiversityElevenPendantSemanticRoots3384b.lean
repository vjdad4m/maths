import DiversityElevenPendantThresholds3384b
import DiversityElevenPendantWireClauses3384b
import Mathlib.Data.Finset.Card
import Mathlib.Tactic.FinCases
namespace Graffiti384b.DiversityEleven.PendantCircuit.K3
open Sat Finset
set_option maxRecDepth 32768
set_option maxHeartbeats 15000000
def edgeNumber (i j : Fin 8) : Nat :=
  let a := min i.val j.val
  let b := max i.val j.val
  2 + (a*(15-a))/2 + (b-a-1)
def edge (E : Nat→Bool) (i j : Fin 8) : Bool := if i=j then false else E (edgeNumber i j)
def portRank (E : Nat→Bool) (i : Fin 8) : Nat :=
  (if edge E 1 i then 1 else 0)+(if edge E 0 i then 2 else 0)
private theorem negWire (b : Bool) : ((!b)=true) ↔ ¬b=true := by cases b <;> decide
def HasTriple (E : Nat→Bool) : Prop :=
  ∃ a b c : Fin 8, a<b ∧ b<c ∧ ∀ v : Fin 8, v≠a → v≠b → v≠c →
    (if v.val < 3 then 2 else 1)≤countTrue [edge E v a,edge E v b,edge E v c]
private theorem root_29 (E : Nat→Bool) (h : 3≤degree0_count E) : (valuation E).satisfies [.neg 63] := by
  change ((g64 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree0_threshold7_2 E).mpr h) hn
private theorem root_60 (E : Nat→Bool) (h : 3≤degree1_count E) : (valuation E).satisfies [.neg 105] := by
  change ((g106 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree1_threshold7_2 E).mpr h) hn
private theorem root_90 (E : Nat→Bool) (h : 3≤degree2_count E) : (valuation E).satisfies [.neg 147] := by
  change ((g148 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree2_threshold7_2 E).mpr h) hn
private theorem root_126 (E : Nat→Bool) (h : 3≤degree3_count E) : (valuation E).satisfies [.neg 189] := by
  change ((g190 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree3_threshold7_2 E).mpr h) hn
private theorem root_166 (E : Nat→Bool) (h : 3≤degree4_count E) : (valuation E).satisfies [.neg 231] := by
  change ((g232 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree4_threshold7_2 E).mpr h) hn
private theorem root_194 (E : Nat→Bool) (h : 3≤degree5_count E) : (valuation E).satisfies [.neg 273] := by
  change ((g274 E)=true) → False
  intro hn
  exact (negWire _).mp ((degree5_threshold7_2 E).mpr h) hn
private theorem root_746 (E : Nat→Bool) (h : 2≤score0_count E) : (valuation E).satisfies [.neg 803] := by
  change ((g804 E)=true) → False
  intro hn
  exact (negWire _).mp ((score0_threshold21_1 E).mpr h) hn
private theorem root_747 (E : Nat→Bool) (h : score0_count E<score1_count E) : (valuation E).satisfies [.neg 1225, .pos 803] := by
  change ((g1226 E)=true) → (¬ ((g804 E)=true)) → False
  intro fail old
  have oldScore := (score0_threshold21_1 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 1 h oldScore
  exact (negWire _).mp ((score1_threshold21_2 E).mpr newScore) fail
private theorem root_748 (E : Nat→Bool) (h : score0_count E<score1_count E) : (valuation E).satisfies [.neg 1227, .pos 805] := by
  change ((g1228 E)=true) → (¬ ((g806 E)=true)) → False
  intro fail old
  have oldScore := (score0_threshold21_2 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 2 h oldScore
  exact (negWire _).mp ((score1_threshold21_3 E).mpr newScore) fail
private theorem root_749 (E : Nat→Bool) (h : score1_count E<score2_count E) : (valuation E).satisfies [.neg 1647, .pos 1225] := by
  change ((g1648 E)=true) → (¬ ((g1226 E)=true)) → False
  intro fail old
  have oldScore := (score1_threshold21_2 E).mp ((negWire _).mpr old)
  have newScore := threshold_of_strict _ _ 2 h oldScore
  exact (negWire _).mp ((score2_threshold21_3 E).mpr newScore) fail
private theorem root_756 (E : Nat→Bool) (h : portRank E 3≤portRank E 4) : (valuation E).satisfies [.pos 1686] := by
  change (¬ ((g1687 E)=true)) → False
  intro contrary
  change (if (g10 E) then 1 else 0) + (if (g4 E) then 2 else 0) ≤ (if (g11 E) then 1 else 0) + (if (g5 E) then 2 else 0) at h
  cases q10 : g10 E <;> cases q4 : g4 E <;> cases q11 : g11 E <;> cases q5 : g5 E <;> simp [g1682,g1683,g1684,g1685,g1686,g1687,q10,q4,q11,q5] at h contrary
private theorem root_764 (E : Nat→Bool) (h : portRank E 4≤portRank E 5) : (valuation E).satisfies [.pos 1692] := by
  change (¬ ((g1693 E)=true)) → False
  intro contrary
  change (if (g11 E) then 1 else 0) + (if (g5 E) then 2 else 0) ≤ (if (g12 E) then 1 else 0) + (if (g6 E) then 2 else 0) at h
  cases q11 : g11 E <;> cases q5 : g5 E <;> cases q12 : g12 E <;> cases q6 : g6 E <;> simp [g1688,g1689,g1690,g1691,g1692,g1693,q11,q5,q12,q6] at h contrary
private theorem root_772 (E : Nat→Bool) (h : portRank E 5≤portRank E 6) : (valuation E).satisfies [.pos 1698] := by
  change (¬ ((g1699 E)=true)) → False
  intro contrary
  change (if (g12 E) then 1 else 0) + (if (g6 E) then 2 else 0) ≤ (if (g13 E) then 1 else 0) + (if (g7 E) then 2 else 0) at h
  cases q12 : g12 E <;> cases q6 : g6 E <;> cases q13 : g13 E <;> cases q7 : g7 E <;> simp [g1694,g1695,g1696,g1697,g1698,g1699,q12,q6,q13,q7] at h contrary
private theorem root_781 (E : Nat→Bool) (h : portRank E 6≤portRank E 7) : (valuation E).satisfies [.pos 1704] := by
  change (¬ ((g1705 E)=true)) → False
  intro contrary
  change (if (g13 E) then 1 else 0) + (if (g7 E) then 2 else 0) ≤ (if (g14 E) then 1 else 0) + (if (g8 E) then 2 else 0) at h
  cases q13 : g13 E <;> cases q7 : g7 E <;> cases q14 : g14 E <;> cases q8 : g8 E <;> simp [g1700,g1701,g1702,g1703,g1704,g1705,q13,q7,q14,q8] at h contrary
private theorem root_800 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 1705, .pos 1706, .pos 1707, .pos 1708, .pos 1709] := by
  change (¬ ((g1706 E)=true)) → (¬ ((g1707 E)=true)) → (¬ ((g1708 E)=true)) → (¬ ((g1709 E)=true)) → (¬ ((g1710 E)=true)) → False
  intro c3 c4 c5 c6 c7
  apply h
  refine ⟨0,1,2,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 3 0, edge E 3 1, edge E 3 2]
    apply (mask_ge_one (edge E 3 0) (edge E 3 1) (edge E 3 2)).mp
    change ((g4 E) || (g10 E) || (g15 E))=true
    simpa [g1706, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 0, edge E 4 1, edge E 4 2]
    apply (mask_ge_one (edge E 4 0) (edge E 4 1) (edge E 4 2)).mp
    change ((g5 E) || (g11 E) || (g16 E))=true
    simpa [g1707, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 1, edge E 5 2]
    apply (mask_ge_one (edge E 5 0) (edge E 5 1) (edge E 5 2)).mp
    change ((g6 E) || (g12 E) || (g17 E))=true
    simpa [g1708, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 1, edge E 6 2]
    apply (mask_ge_one (edge E 6 0) (edge E 6 1) (edge E 6 2)).mp
    change ((g7 E) || (g13 E) || (g18 E))=true
    simpa [g1709, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 1, edge E 7 2]
    apply (mask_ge_one (edge E 7 0) (edge E 7 1) (edge E 7 2)).mp
    change ((g8 E) || (g14 E) || (g19 E))=true
    simpa [g1710, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_817 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 1713, .pos 1714, .pos 1715, .pos 1716, .pos 1717] := by
  change (¬ ((g1714 E)=true)) → (¬ ((g1715 E)=true)) → (¬ ((g1716 E)=true)) → (¬ ((g1717 E)=true)) → (¬ ((g1718 E)=true)) → False
  intro c2 c4 c5 c6 c7
  apply h
  refine ⟨0,1,3,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 2 0, edge E 2 1, edge E 2 3]
    apply (mask_ge_two (edge E 2 0) (edge E 2 1) (edge E 2 3)).mp
    change (((g3 E) && (g9 E)) || ((g3 E) && (g15 E)) || ((g9 E) && (g15 E)))=true
    simpa [g1711, g1712, g1713, g1714, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 4 0, edge E 4 1, edge E 4 3]
    apply (mask_ge_one (edge E 4 0) (edge E 4 1) (edge E 4 3)).mp
    change ((g5 E) || (g11 E) || (g20 E))=true
    simpa [g1715, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 1, edge E 5 3]
    apply (mask_ge_one (edge E 5 0) (edge E 5 1) (edge E 5 3)).mp
    change ((g6 E) || (g12 E) || (g21 E))=true
    simpa [g1716, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 1, edge E 6 3]
    apply (mask_ge_one (edge E 6 0) (edge E 6 1) (edge E 6 3)).mp
    change ((g7 E) || (g13 E) || (g22 E))=true
    simpa [g1717, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 1, edge E 7 3]
    apply (mask_ge_one (edge E 7 0) (edge E 7 1) (edge E 7 3)).mp
    change ((g8 E) || (g14 E) || (g23 E))=true
    simpa [g1718, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_833 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 1721, .pos 1722, .pos 1723, .pos 1724, .pos 1725] := by
  change (¬ ((g1722 E)=true)) → (¬ ((g1723 E)=true)) → (¬ ((g1724 E)=true)) → (¬ ((g1725 E)=true)) → (¬ ((g1726 E)=true)) → False
  intro c2 c3 c5 c6 c7
  apply h
  refine ⟨0,1,4,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 2 0, edge E 2 1, edge E 2 4]
    apply (mask_ge_two (edge E 2 0) (edge E 2 1) (edge E 2 4)).mp
    change (((g3 E) && (g9 E)) || ((g3 E) && (g16 E)) || ((g9 E) && (g16 E)))=true
    simpa [g1719, g1720, g1721, g1722, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 1≤countTrue [edge E 3 0, edge E 3 1, edge E 3 4]
    apply (mask_ge_one (edge E 3 0) (edge E 3 1) (edge E 3 4)).mp
    change ((g4 E) || (g10 E) || (g20 E))=true
    simpa [g1723, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 5 0, edge E 5 1, edge E 5 4]
    apply (mask_ge_one (edge E 5 0) (edge E 5 1) (edge E 5 4)).mp
    change ((g6 E) || (g12 E) || (g24 E))=true
    simpa [g1724, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 1, edge E 6 4]
    apply (mask_ge_one (edge E 6 0) (edge E 6 1) (edge E 6 4)).mp
    change ((g7 E) || (g13 E) || (g25 E))=true
    simpa [g1725, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 1, edge E 7 4]
    apply (mask_ge_one (edge E 7 0) (edge E 7 1) (edge E 7 4)).mp
    change ((g8 E) || (g14 E) || (g26 E))=true
    simpa [g1726, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_844 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 1729, .pos 1730, .pos 1731, .pos 1732, .pos 1733] := by
  change (¬ ((g1730 E)=true)) → (¬ ((g1731 E)=true)) → (¬ ((g1732 E)=true)) → (¬ ((g1733 E)=true)) → (¬ ((g1734 E)=true)) → False
  intro c2 c3 c4 c6 c7
  apply h
  refine ⟨0,1,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 2 0, edge E 2 1, edge E 2 5]
    apply (mask_ge_two (edge E 2 0) (edge E 2 1) (edge E 2 5)).mp
    change (((g3 E) && (g9 E)) || ((g3 E) && (g17 E)) || ((g9 E) && (g17 E)))=true
    simpa [g1727, g1728, g1729, g1730, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 1≤countTrue [edge E 3 0, edge E 3 1, edge E 3 5]
    apply (mask_ge_one (edge E 3 0) (edge E 3 1) (edge E 3 5)).mp
    change ((g4 E) || (g10 E) || (g21 E))=true
    simpa [g1731, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 0, edge E 4 1, edge E 4 5]
    apply (mask_ge_one (edge E 4 0) (edge E 4 1) (edge E 4 5)).mp
    change ((g5 E) || (g11 E) || (g24 E))=true
    simpa [g1732, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 0, edge E 6 1, edge E 6 5]
    apply (mask_ge_one (edge E 6 0) (edge E 6 1) (edge E 6 5)).mp
    change ((g7 E) || (g13 E) || (g27 E))=true
    simpa [g1733, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 1, edge E 7 5]
    apply (mask_ge_one (edge E 7 0) (edge E 7 1) (edge E 7 5)).mp
    change ((g8 E) || (g14 E) || (g28 E))=true
    simpa [g1734, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_858 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 1737, .pos 1738, .pos 1739, .pos 1740, .pos 1741] := by
  change (¬ ((g1738 E)=true)) → (¬ ((g1739 E)=true)) → (¬ ((g1740 E)=true)) → (¬ ((g1741 E)=true)) → (¬ ((g1742 E)=true)) → False
  intro c2 c3 c4 c5 c7
  apply h
  refine ⟨0,1,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 2 0, edge E 2 1, edge E 2 6]
    apply (mask_ge_two (edge E 2 0) (edge E 2 1) (edge E 2 6)).mp
    change (((g3 E) && (g9 E)) || ((g3 E) && (g18 E)) || ((g9 E) && (g18 E)))=true
    simpa [g1735, g1736, g1737, g1738, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 1≤countTrue [edge E 3 0, edge E 3 1, edge E 3 6]
    apply (mask_ge_one (edge E 3 0) (edge E 3 1) (edge E 3 6)).mp
    change ((g4 E) || (g10 E) || (g22 E))=true
    simpa [g1739, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 0, edge E 4 1, edge E 4 6]
    apply (mask_ge_one (edge E 4 0) (edge E 4 1) (edge E 4 6)).mp
    change ((g5 E) || (g11 E) || (g25 E))=true
    simpa [g1740, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 1, edge E 5 6]
    apply (mask_ge_one (edge E 5 0) (edge E 5 1) (edge E 5 6)).mp
    change ((g6 E) || (g12 E) || (g27 E))=true
    simpa [g1741, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 0, edge E 7 1, edge E 7 6]
    apply (mask_ge_one (edge E 7 0) (edge E 7 1) (edge E 7 6)).mp
    change ((g8 E) || (g14 E) || (g29 E))=true
    simpa [g1742, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_868 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 1745, .pos 1746, .pos 1747, .pos 1748, .pos 1749] := by
  change (¬ ((g1746 E)=true)) → (¬ ((g1747 E)=true)) → (¬ ((g1748 E)=true)) → (¬ ((g1749 E)=true)) → (¬ ((g1750 E)=true)) → False
  intro c2 c3 c4 c5 c6
  apply h
  refine ⟨0,1,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 2≤countTrue [edge E 2 0, edge E 2 1, edge E 2 7]
    apply (mask_ge_two (edge E 2 0) (edge E 2 1) (edge E 2 7)).mp
    change (((g3 E) && (g9 E)) || ((g3 E) && (g19 E)) || ((g9 E) && (g19 E)))=true
    simpa [g1743, g1744, g1745, g1746, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 1≤countTrue [edge E 3 0, edge E 3 1, edge E 3 7]
    apply (mask_ge_one (edge E 3 0) (edge E 3 1) (edge E 3 7)).mp
    change ((g4 E) || (g10 E) || (g23 E))=true
    simpa [g1747, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 0, edge E 4 1, edge E 4 7]
    apply (mask_ge_one (edge E 4 0) (edge E 4 1) (edge E 4 7)).mp
    change ((g5 E) || (g11 E) || (g26 E))=true
    simpa [g1748, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 1, edge E 5 7]
    apply (mask_ge_one (edge E 5 0) (edge E 5 1) (edge E 5 7)).mp
    change ((g6 E) || (g12 E) || (g28 E))=true
    simpa [g1749, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 1, edge E 6 7]
    apply (mask_ge_one (edge E 6 0) (edge E 6 1) (edge E 6 7)).mp
    change ((g7 E) || (g13 E) || (g29 E))=true
    simpa [g1750, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_883 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 1753, .pos 1754, .pos 1755, .pos 1756, .pos 1757] := by
  change (¬ ((g1754 E)=true)) → (¬ ((g1755 E)=true)) → (¬ ((g1756 E)=true)) → (¬ ((g1757 E)=true)) → (¬ ((g1758 E)=true)) → False
  intro c1 c4 c5 c6 c7
  apply h
  refine ⟨0,2,3,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 2, edge E 1 3]
    apply (mask_ge_two (edge E 1 0) (edge E 1 2) (edge E 1 3)).mp
    change (((g2 E) && (g9 E)) || ((g2 E) && (g10 E)) || ((g9 E) && (g10 E)))=true
    simpa [g1751, g1752, g1753, g1754, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 4 0, edge E 4 2, edge E 4 3]
    apply (mask_ge_one (edge E 4 0) (edge E 4 2) (edge E 4 3)).mp
    change ((g5 E) || (g16 E) || (g20 E))=true
    simpa [g1755, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 2, edge E 5 3]
    apply (mask_ge_one (edge E 5 0) (edge E 5 2) (edge E 5 3)).mp
    change ((g6 E) || (g17 E) || (g21 E))=true
    simpa [g1756, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 2, edge E 6 3]
    apply (mask_ge_one (edge E 6 0) (edge E 6 2) (edge E 6 3)).mp
    change ((g7 E) || (g18 E) || (g22 E))=true
    simpa [g1757, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 2, edge E 7 3]
    apply (mask_ge_one (edge E 7 0) (edge E 7 2) (edge E 7 3)).mp
    change ((g8 E) || (g19 E) || (g23 E))=true
    simpa [g1758, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_897 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 1761, .pos 1762, .pos 1763, .pos 1764, .pos 1765] := by
  change (¬ ((g1762 E)=true)) → (¬ ((g1763 E)=true)) → (¬ ((g1764 E)=true)) → (¬ ((g1765 E)=true)) → (¬ ((g1766 E)=true)) → False
  intro c1 c3 c5 c6 c7
  apply h
  refine ⟨0,2,4,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 2, edge E 1 4]
    apply (mask_ge_two (edge E 1 0) (edge E 1 2) (edge E 1 4)).mp
    change (((g2 E) && (g9 E)) || ((g2 E) && (g11 E)) || ((g9 E) && (g11 E)))=true
    simpa [g1759, g1760, g1761, g1762, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 3 0, edge E 3 2, edge E 3 4]
    apply (mask_ge_one (edge E 3 0) (edge E 3 2) (edge E 3 4)).mp
    change ((g4 E) || (g15 E) || (g20 E))=true
    simpa [g1763, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 5 0, edge E 5 2, edge E 5 4]
    apply (mask_ge_one (edge E 5 0) (edge E 5 2) (edge E 5 4)).mp
    change ((g6 E) || (g17 E) || (g24 E))=true
    simpa [g1764, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 2, edge E 6 4]
    apply (mask_ge_one (edge E 6 0) (edge E 6 2) (edge E 6 4)).mp
    change ((g7 E) || (g18 E) || (g25 E))=true
    simpa [g1765, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 2, edge E 7 4]
    apply (mask_ge_one (edge E 7 0) (edge E 7 2) (edge E 7 4)).mp
    change ((g8 E) || (g19 E) || (g26 E))=true
    simpa [g1766, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_915 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 1769, .pos 1770, .pos 1771, .pos 1772, .pos 1773] := by
  change (¬ ((g1770 E)=true)) → (¬ ((g1771 E)=true)) → (¬ ((g1772 E)=true)) → (¬ ((g1773 E)=true)) → (¬ ((g1774 E)=true)) → False
  intro c1 c3 c4 c6 c7
  apply h
  refine ⟨0,2,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 2, edge E 1 5]
    apply (mask_ge_two (edge E 1 0) (edge E 1 2) (edge E 1 5)).mp
    change (((g2 E) && (g9 E)) || ((g2 E) && (g12 E)) || ((g9 E) && (g12 E)))=true
    simpa [g1767, g1768, g1769, g1770, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 3 0, edge E 3 2, edge E 3 5]
    apply (mask_ge_one (edge E 3 0) (edge E 3 2) (edge E 3 5)).mp
    change ((g4 E) || (g15 E) || (g21 E))=true
    simpa [g1771, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 0, edge E 4 2, edge E 4 5]
    apply (mask_ge_one (edge E 4 0) (edge E 4 2) (edge E 4 5)).mp
    change ((g5 E) || (g16 E) || (g24 E))=true
    simpa [g1772, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 0, edge E 6 2, edge E 6 5]
    apply (mask_ge_one (edge E 6 0) (edge E 6 2) (edge E 6 5)).mp
    change ((g7 E) || (g18 E) || (g27 E))=true
    simpa [g1773, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 2, edge E 7 5]
    apply (mask_ge_one (edge E 7 0) (edge E 7 2) (edge E 7 5)).mp
    change ((g8 E) || (g19 E) || (g28 E))=true
    simpa [g1774, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_931 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 1777, .pos 1778, .pos 1779, .pos 1780, .pos 1781] := by
  change (¬ ((g1778 E)=true)) → (¬ ((g1779 E)=true)) → (¬ ((g1780 E)=true)) → (¬ ((g1781 E)=true)) → (¬ ((g1782 E)=true)) → False
  intro c1 c3 c4 c5 c7
  apply h
  refine ⟨0,2,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 2, edge E 1 6]
    apply (mask_ge_two (edge E 1 0) (edge E 1 2) (edge E 1 6)).mp
    change (((g2 E) && (g9 E)) || ((g2 E) && (g13 E)) || ((g9 E) && (g13 E)))=true
    simpa [g1775, g1776, g1777, g1778, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 3 0, edge E 3 2, edge E 3 6]
    apply (mask_ge_one (edge E 3 0) (edge E 3 2) (edge E 3 6)).mp
    change ((g4 E) || (g15 E) || (g22 E))=true
    simpa [g1779, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 0, edge E 4 2, edge E 4 6]
    apply (mask_ge_one (edge E 4 0) (edge E 4 2) (edge E 4 6)).mp
    change ((g5 E) || (g16 E) || (g25 E))=true
    simpa [g1780, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 2, edge E 5 6]
    apply (mask_ge_one (edge E 5 0) (edge E 5 2) (edge E 5 6)).mp
    change ((g6 E) || (g17 E) || (g27 E))=true
    simpa [g1781, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 0, edge E 7 2, edge E 7 6]
    apply (mask_ge_one (edge E 7 0) (edge E 7 2) (edge E 7 6)).mp
    change ((g8 E) || (g19 E) || (g29 E))=true
    simpa [g1782, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_947 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 1785, .pos 1786, .pos 1787, .pos 1788, .pos 1789] := by
  change (¬ ((g1786 E)=true)) → (¬ ((g1787 E)=true)) → (¬ ((g1788 E)=true)) → (¬ ((g1789 E)=true)) → (¬ ((g1790 E)=true)) → False
  intro c1 c3 c4 c5 c6
  apply h
  refine ⟨0,2,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 2, edge E 1 7]
    apply (mask_ge_two (edge E 1 0) (edge E 1 2) (edge E 1 7)).mp
    change (((g2 E) && (g9 E)) || ((g2 E) && (g14 E)) || ((g9 E) && (g14 E)))=true
    simpa [g1783, g1784, g1785, g1786, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 3 0, edge E 3 2, edge E 3 7]
    apply (mask_ge_one (edge E 3 0) (edge E 3 2) (edge E 3 7)).mp
    change ((g4 E) || (g15 E) || (g23 E))=true
    simpa [g1787, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 0, edge E 4 2, edge E 4 7]
    apply (mask_ge_one (edge E 4 0) (edge E 4 2) (edge E 4 7)).mp
    change ((g5 E) || (g16 E) || (g26 E))=true
    simpa [g1788, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 0, edge E 5 2, edge E 5 7]
    apply (mask_ge_one (edge E 5 0) (edge E 5 2) (edge E 5 7)).mp
    change ((g6 E) || (g17 E) || (g28 E))=true
    simpa [g1789, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 2, edge E 6 7]
    apply (mask_ge_one (edge E 6 0) (edge E 6 2) (edge E 6 7)).mp
    change ((g7 E) || (g18 E) || (g29 E))=true
    simpa [g1790, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_955 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 1837, .pos 1841, .pos 1842, .pos 1843, .pos 1844] := by
  change (¬ ((g1838 E)=true)) → (¬ ((g1842 E)=true)) → (¬ ((g1843 E)=true)) → (¬ ((g1844 E)=true)) → (¬ ((g1845 E)=true)) → False
  intro c1 c2 c3 c6 c7
  apply h
  refine ⟨0,4,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 4, edge E 1 5]
    apply (mask_ge_two (edge E 1 0) (edge E 1 4) (edge E 1 5)).mp
    change (((g2 E) && (g11 E)) || ((g2 E) && (g12 E)) || ((g11 E) && (g12 E)))=true
    simpa [g1835, g1836, g1837, g1838, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 4, edge E 2 5]
    apply (mask_ge_two (edge E 2 0) (edge E 2 4) (edge E 2 5)).mp
    change (((g3 E) && (g16 E)) || ((g3 E) && (g17 E)) || ((g16 E) && (g17 E)))=true
    simpa [g1839, g1840, g1841, g1842, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 1≤countTrue [edge E 3 0, edge E 3 4, edge E 3 5]
    apply (mask_ge_one (edge E 3 0) (edge E 3 4) (edge E 3 5)).mp
    change ((g4 E) || (g20 E) || (g21 E))=true
    simpa [g1843, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 0, edge E 6 4, edge E 6 5]
    apply (mask_ge_one (edge E 6 0) (edge E 6 4) (edge E 6 5)).mp
    change ((g7 E) || (g25 E) || (g27 E))=true
    simpa [g1844, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 0, edge E 7 4, edge E 7 5]
    apply (mask_ge_one (edge E 7 0) (edge E 7 4) (edge E 7 5)).mp
    change ((g8 E) || (g26 E) || (g28 E))=true
    simpa [g1845, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_963 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 1848, .pos 1852, .pos 1853, .pos 1854, .pos 1855] := by
  change (¬ ((g1849 E)=true)) → (¬ ((g1853 E)=true)) → (¬ ((g1854 E)=true)) → (¬ ((g1855 E)=true)) → (¬ ((g1856 E)=true)) → False
  intro c1 c2 c3 c5 c7
  apply h
  refine ⟨0,4,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 4, edge E 1 6]
    apply (mask_ge_two (edge E 1 0) (edge E 1 4) (edge E 1 6)).mp
    change (((g2 E) && (g11 E)) || ((g2 E) && (g13 E)) || ((g11 E) && (g13 E)))=true
    simpa [g1846, g1847, g1848, g1849, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 4, edge E 2 6]
    apply (mask_ge_two (edge E 2 0) (edge E 2 4) (edge E 2 6)).mp
    change (((g3 E) && (g16 E)) || ((g3 E) && (g18 E)) || ((g16 E) && (g18 E)))=true
    simpa [g1850, g1851, g1852, g1853, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 1≤countTrue [edge E 3 0, edge E 3 4, edge E 3 6]
    apply (mask_ge_one (edge E 3 0) (edge E 3 4) (edge E 3 6)).mp
    change ((g4 E) || (g20 E) || (g22 E))=true
    simpa [g1854, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 5 0, edge E 5 4, edge E 5 6]
    apply (mask_ge_one (edge E 5 0) (edge E 5 4) (edge E 5 6)).mp
    change ((g6 E) || (g24 E) || (g27 E))=true
    simpa [g1855, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 0, edge E 7 4, edge E 7 6]
    apply (mask_ge_one (edge E 7 0) (edge E 7 4) (edge E 7 6)).mp
    change ((g8 E) || (g26 E) || (g29 E))=true
    simpa [g1856, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_980 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 1859, .pos 1863, .pos 1864, .pos 1865, .pos 1866] := by
  change (¬ ((g1860 E)=true)) → (¬ ((g1864 E)=true)) → (¬ ((g1865 E)=true)) → (¬ ((g1866 E)=true)) → (¬ ((g1867 E)=true)) → False
  intro c1 c2 c3 c5 c6
  apply h
  refine ⟨0,4,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 1 0, edge E 1 4, edge E 1 7]
    apply (mask_ge_two (edge E 1 0) (edge E 1 4) (edge E 1 7)).mp
    change (((g2 E) && (g11 E)) || ((g2 E) && (g14 E)) || ((g11 E) && (g14 E)))=true
    simpa [g1857, g1858, g1859, g1860, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 0, edge E 2 4, edge E 2 7]
    apply (mask_ge_two (edge E 2 0) (edge E 2 4) (edge E 2 7)).mp
    change (((g3 E) && (g16 E)) || ((g3 E) && (g19 E)) || ((g16 E) && (g19 E)))=true
    simpa [g1861, g1862, g1863, g1864, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 1≤countTrue [edge E 3 0, edge E 3 4, edge E 3 7]
    apply (mask_ge_one (edge E 3 0) (edge E 3 4) (edge E 3 7)).mp
    change ((g4 E) || (g20 E) || (g23 E))=true
    simpa [g1865, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 5 0, edge E 5 4, edge E 5 7]
    apply (mask_ge_one (edge E 5 0) (edge E 5 4) (edge E 5 7)).mp
    change ((g6 E) || (g24 E) || (g28 E))=true
    simpa [g1866, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 0, edge E 6 4, edge E 6 7]
    apply (mask_ge_one (edge E 6 0) (edge E 6 4) (edge E 6 7)).mp
    change ((g7 E) || (g25 E) || (g29 E))=true
    simpa [g1867, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_993 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 1903, .pos 1904, .pos 1905, .pos 1906, .pos 1907] := by
  change (¬ ((g1904 E)=true)) → (¬ ((g1905 E)=true)) → (¬ ((g1906 E)=true)) → (¬ ((g1907 E)=true)) → (¬ ((g1908 E)=true)) → False
  intro c0 c4 c5 c6 c7
  apply h
  refine ⟨1,2,3,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 2, edge E 0 3]
    apply (mask_ge_two (edge E 0 1) (edge E 0 2) (edge E 0 3)).mp
    change (((g2 E) && (g3 E)) || ((g2 E) && (g4 E)) || ((g3 E) && (g4 E)))=true
    simpa [g1901, g1902, g1903, g1904, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 4 1, edge E 4 2, edge E 4 3]
    apply (mask_ge_one (edge E 4 1) (edge E 4 2) (edge E 4 3)).mp
    change ((g11 E) || (g16 E) || (g20 E))=true
    simpa [g1905, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 1, edge E 5 2, edge E 5 3]
    apply (mask_ge_one (edge E 5 1) (edge E 5 2) (edge E 5 3)).mp
    change ((g12 E) || (g17 E) || (g21 E))=true
    simpa [g1906, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 1, edge E 6 2, edge E 6 3]
    apply (mask_ge_one (edge E 6 1) (edge E 6 2) (edge E 6 3)).mp
    change ((g13 E) || (g18 E) || (g22 E))=true
    simpa [g1907, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 1, edge E 7 2, edge E 7 3]
    apply (mask_ge_one (edge E 7 1) (edge E 7 2) (edge E 7 3)).mp
    change ((g14 E) || (g19 E) || (g23 E))=true
    simpa [g1908, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1009 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 1911, .pos 1912, .pos 1913, .pos 1914, .pos 1915] := by
  change (¬ ((g1912 E)=true)) → (¬ ((g1913 E)=true)) → (¬ ((g1914 E)=true)) → (¬ ((g1915 E)=true)) → (¬ ((g1916 E)=true)) → False
  intro c0 c3 c5 c6 c7
  apply h
  refine ⟨1,2,4,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 2, edge E 0 4]
    apply (mask_ge_two (edge E 0 1) (edge E 0 2) (edge E 0 4)).mp
    change (((g2 E) && (g3 E)) || ((g2 E) && (g5 E)) || ((g3 E) && (g5 E)))=true
    simpa [g1909, g1910, g1911, g1912, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 3 1, edge E 3 2, edge E 3 4]
    apply (mask_ge_one (edge E 3 1) (edge E 3 2) (edge E 3 4)).mp
    change ((g10 E) || (g15 E) || (g20 E))=true
    simpa [g1913, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 5 1, edge E 5 2, edge E 5 4]
    apply (mask_ge_one (edge E 5 1) (edge E 5 2) (edge E 5 4)).mp
    change ((g12 E) || (g17 E) || (g24 E))=true
    simpa [g1914, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 1, edge E 6 2, edge E 6 4]
    apply (mask_ge_one (edge E 6 1) (edge E 6 2) (edge E 6 4)).mp
    change ((g13 E) || (g18 E) || (g25 E))=true
    simpa [g1915, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 1, edge E 7 2, edge E 7 4]
    apply (mask_ge_one (edge E 7 1) (edge E 7 2) (edge E 7 4)).mp
    change ((g14 E) || (g19 E) || (g26 E))=true
    simpa [g1916, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1024 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 1919, .pos 1920, .pos 1921, .pos 1922, .pos 1923] := by
  change (¬ ((g1920 E)=true)) → (¬ ((g1921 E)=true)) → (¬ ((g1922 E)=true)) → (¬ ((g1923 E)=true)) → (¬ ((g1924 E)=true)) → False
  intro c0 c3 c4 c6 c7
  apply h
  refine ⟨1,2,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 2, edge E 0 5]
    apply (mask_ge_two (edge E 0 1) (edge E 0 2) (edge E 0 5)).mp
    change (((g2 E) && (g3 E)) || ((g2 E) && (g6 E)) || ((g3 E) && (g6 E)))=true
    simpa [g1917, g1918, g1919, g1920, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 3 1, edge E 3 2, edge E 3 5]
    apply (mask_ge_one (edge E 3 1) (edge E 3 2) (edge E 3 5)).mp
    change ((g10 E) || (g15 E) || (g21 E))=true
    simpa [g1921, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 1, edge E 4 2, edge E 4 5]
    apply (mask_ge_one (edge E 4 1) (edge E 4 2) (edge E 4 5)).mp
    change ((g11 E) || (g16 E) || (g24 E))=true
    simpa [g1922, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 1, edge E 6 2, edge E 6 5]
    apply (mask_ge_one (edge E 6 1) (edge E 6 2) (edge E 6 5)).mp
    change ((g13 E) || (g18 E) || (g27 E))=true
    simpa [g1923, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 1, edge E 7 2, edge E 7 5]
    apply (mask_ge_one (edge E 7 1) (edge E 7 2) (edge E 7 5)).mp
    change ((g14 E) || (g19 E) || (g28 E))=true
    simpa [g1924, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1043 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 1927, .pos 1928, .pos 1929, .pos 1930, .pos 1931] := by
  change (¬ ((g1928 E)=true)) → (¬ ((g1929 E)=true)) → (¬ ((g1930 E)=true)) → (¬ ((g1931 E)=true)) → (¬ ((g1932 E)=true)) → False
  intro c0 c3 c4 c5 c7
  apply h
  refine ⟨1,2,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 2, edge E 0 6]
    apply (mask_ge_two (edge E 0 1) (edge E 0 2) (edge E 0 6)).mp
    change (((g2 E) && (g3 E)) || ((g2 E) && (g7 E)) || ((g3 E) && (g7 E)))=true
    simpa [g1925, g1926, g1927, g1928, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 3 1, edge E 3 2, edge E 3 6]
    apply (mask_ge_one (edge E 3 1) (edge E 3 2) (edge E 3 6)).mp
    change ((g10 E) || (g15 E) || (g22 E))=true
    simpa [g1929, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 1, edge E 4 2, edge E 4 6]
    apply (mask_ge_one (edge E 4 1) (edge E 4 2) (edge E 4 6)).mp
    change ((g11 E) || (g16 E) || (g25 E))=true
    simpa [g1930, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 1, edge E 5 2, edge E 5 6]
    apply (mask_ge_one (edge E 5 1) (edge E 5 2) (edge E 5 6)).mp
    change ((g12 E) || (g17 E) || (g27 E))=true
    simpa [g1931, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 1, edge E 7 2, edge E 7 6]
    apply (mask_ge_one (edge E 7 1) (edge E 7 2) (edge E 7 6)).mp
    change ((g14 E) || (g19 E) || (g29 E))=true
    simpa [g1932, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1060 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 1935, .pos 1936, .pos 1937, .pos 1938, .pos 1939] := by
  change (¬ ((g1936 E)=true)) → (¬ ((g1937 E)=true)) → (¬ ((g1938 E)=true)) → (¬ ((g1939 E)=true)) → (¬ ((g1940 E)=true)) → False
  intro c0 c3 c4 c5 c6
  apply h
  refine ⟨1,2,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 2, edge E 0 7]
    apply (mask_ge_two (edge E 0 1) (edge E 0 2) (edge E 0 7)).mp
    change (((g2 E) && (g3 E)) || ((g2 E) && (g8 E)) || ((g3 E) && (g8 E)))=true
    simpa [g1933, g1934, g1935, g1936, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 3 1, edge E 3 2, edge E 3 7]
    apply (mask_ge_one (edge E 3 1) (edge E 3 2) (edge E 3 7)).mp
    change ((g10 E) || (g15 E) || (g23 E))=true
    simpa [g1937, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 1, edge E 4 2, edge E 4 7]
    apply (mask_ge_one (edge E 4 1) (edge E 4 2) (edge E 4 7)).mp
    change ((g11 E) || (g16 E) || (g26 E))=true
    simpa [g1938, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 1, edge E 5 2, edge E 5 7]
    apply (mask_ge_one (edge E 5 1) (edge E 5 2) (edge E 5 7)).mp
    change ((g12 E) || (g17 E) || (g28 E))=true
    simpa [g1939, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 1, edge E 6 2, edge E 6 7]
    apply (mask_ge_one (edge E 6 1) (edge E 6 2) (edge E 6 7)).mp
    change ((g13 E) || (g18 E) || (g29 E))=true
    simpa [g1940, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_1068 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 1987, .pos 1991, .pos 1992, .pos 1993, .pos 1994] := by
  change (¬ ((g1988 E)=true)) → (¬ ((g1992 E)=true)) → (¬ ((g1993 E)=true)) → (¬ ((g1994 E)=true)) → (¬ ((g1995 E)=true)) → False
  intro c0 c2 c3 c6 c7
  apply h
  refine ⟨1,4,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 4, edge E 0 5]
    apply (mask_ge_two (edge E 0 1) (edge E 0 4) (edge E 0 5)).mp
    change (((g2 E) && (g5 E)) || ((g2 E) && (g6 E)) || ((g5 E) && (g6 E)))=true
    simpa [g1985, g1986, g1987, g1988, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 4, edge E 2 5]
    apply (mask_ge_two (edge E 2 1) (edge E 2 4) (edge E 2 5)).mp
    change (((g9 E) && (g16 E)) || ((g9 E) && (g17 E)) || ((g16 E) && (g17 E)))=true
    simpa [g1989, g1990, g1991, g1992, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 1≤countTrue [edge E 3 1, edge E 3 4, edge E 3 5]
    apply (mask_ge_one (edge E 3 1) (edge E 3 4) (edge E 3 5)).mp
    change ((g10 E) || (g20 E) || (g21 E))=true
    simpa [g1993, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 1, edge E 6 4, edge E 6 5]
    apply (mask_ge_one (edge E 6 1) (edge E 6 4) (edge E 6 5)).mp
    change ((g13 E) || (g25 E) || (g27 E))=true
    simpa [g1994, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 1, edge E 7 4, edge E 7 5]
    apply (mask_ge_one (edge E 7 1) (edge E 7 4) (edge E 7 5)).mp
    change ((g14 E) || (g26 E) || (g28 E))=true
    simpa [g1995, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1076 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 1998, .pos 2002, .pos 2003, .pos 2004, .pos 2005] := by
  change (¬ ((g1999 E)=true)) → (¬ ((g2003 E)=true)) → (¬ ((g2004 E)=true)) → (¬ ((g2005 E)=true)) → (¬ ((g2006 E)=true)) → False
  intro c0 c2 c3 c5 c7
  apply h
  refine ⟨1,4,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 4, edge E 0 6]
    apply (mask_ge_two (edge E 0 1) (edge E 0 4) (edge E 0 6)).mp
    change (((g2 E) && (g5 E)) || ((g2 E) && (g7 E)) || ((g5 E) && (g7 E)))=true
    simpa [g1996, g1997, g1998, g1999, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 4, edge E 2 6]
    apply (mask_ge_two (edge E 2 1) (edge E 2 4) (edge E 2 6)).mp
    change (((g9 E) && (g16 E)) || ((g9 E) && (g18 E)) || ((g16 E) && (g18 E)))=true
    simpa [g2000, g2001, g2002, g2003, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 1≤countTrue [edge E 3 1, edge E 3 4, edge E 3 6]
    apply (mask_ge_one (edge E 3 1) (edge E 3 4) (edge E 3 6)).mp
    change ((g10 E) || (g20 E) || (g22 E))=true
    simpa [g2004, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 5 1, edge E 5 4, edge E 5 6]
    apply (mask_ge_one (edge E 5 1) (edge E 5 4) (edge E 5 6)).mp
    change ((g12 E) || (g24 E) || (g27 E))=true
    simpa [g2005, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 1, edge E 7 4, edge E 7 6]
    apply (mask_ge_one (edge E 7 1) (edge E 7 4) (edge E 7 6)).mp
    change ((g14 E) || (g26 E) || (g29 E))=true
    simpa [g2006, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1087 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2009, .pos 2013, .pos 2014, .pos 2015, .pos 2016] := by
  change (¬ ((g2010 E)=true)) → (¬ ((g2014 E)=true)) → (¬ ((g2015 E)=true)) → (¬ ((g2016 E)=true)) → (¬ ((g2017 E)=true)) → False
  intro c0 c2 c3 c5 c6
  apply h
  refine ⟨1,4,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 4, edge E 0 7]
    apply (mask_ge_two (edge E 0 1) (edge E 0 4) (edge E 0 7)).mp
    change (((g2 E) && (g5 E)) || ((g2 E) && (g8 E)) || ((g5 E) && (g8 E)))=true
    simpa [g2007, g2008, g2009, g2010, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 4, edge E 2 7]
    apply (mask_ge_two (edge E 2 1) (edge E 2 4) (edge E 2 7)).mp
    change (((g9 E) && (g16 E)) || ((g9 E) && (g19 E)) || ((g16 E) && (g19 E)))=true
    simpa [g2011, g2012, g2013, g2014, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 1≤countTrue [edge E 3 1, edge E 3 4, edge E 3 7]
    apply (mask_ge_one (edge E 3 1) (edge E 3 4) (edge E 3 7)).mp
    change ((g10 E) || (g20 E) || (g23 E))=true
    simpa [g2015, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 5 1, edge E 5 4, edge E 5 7]
    apply (mask_ge_one (edge E 5 1) (edge E 5 4) (edge E 5 7)).mp
    change ((g12 E) || (g24 E) || (g28 E))=true
    simpa [g2016, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 1, edge E 6 4, edge E 6 7]
    apply (mask_ge_one (edge E 6 1) (edge E 6 4) (edge E 6 7)).mp
    change ((g13 E) || (g25 E) || (g29 E))=true
    simpa [g2017, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_1095 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2020, .pos 2024, .pos 2025, .pos 2026, .pos 2027] := by
  change (¬ ((g2021 E)=true)) → (¬ ((g2025 E)=true)) → (¬ ((g2026 E)=true)) → (¬ ((g2027 E)=true)) → (¬ ((g2028 E)=true)) → False
  intro c0 c2 c3 c4 c7
  apply h
  refine ⟨1,5,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 1, edge E 0 5, edge E 0 6]
    apply (mask_ge_two (edge E 0 1) (edge E 0 5) (edge E 0 6)).mp
    change (((g2 E) && (g6 E)) || ((g2 E) && (g7 E)) || ((g6 E) && (g7 E)))=true
    simpa [g2018, g2019, g2020, g2021, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · exact (va rfl).elim
  · change 2≤countTrue [edge E 2 1, edge E 2 5, edge E 2 6]
    apply (mask_ge_two (edge E 2 1) (edge E 2 5) (edge E 2 6)).mp
    change (((g9 E) && (g17 E)) || ((g9 E) && (g18 E)) || ((g17 E) && (g18 E)))=true
    simpa [g2022, g2023, g2024, g2025, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 1≤countTrue [edge E 3 1, edge E 3 5, edge E 3 6]
    apply (mask_ge_one (edge E 3 1) (edge E 3 5) (edge E 3 6)).mp
    change ((g10 E) || (g21 E) || (g22 E))=true
    simpa [g2026, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 1, edge E 4 5, edge E 4 6]
    apply (mask_ge_one (edge E 4 1) (edge E 4 5) (edge E 4 6)).mp
    change ((g11 E) || (g24 E) || (g25 E))=true
    simpa [g2027, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 1, edge E 7 5, edge E 7 6]
    apply (mask_ge_one (edge E 7 1) (edge E 7 5) (edge E 7 6)).mp
    change ((g14 E) || (g28 E) || (g29 E))=true
    simpa [g2028, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1106 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2075, .pos 2079, .pos 2080, .pos 2081, .pos 2082] := by
  change (¬ ((g2076 E)=true)) → (¬ ((g2080 E)=true)) → (¬ ((g2081 E)=true)) → (¬ ((g2082 E)=true)) → (¬ ((g2083 E)=true)) → False
  intro c0 c1 c4 c5 c7
  apply h
  refine ⟨2,3,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 3, edge E 0 6]
    apply (mask_ge_two (edge E 0 2) (edge E 0 3) (edge E 0 6)).mp
    change (((g3 E) && (g4 E)) || ((g3 E) && (g7 E)) || ((g4 E) && (g7 E)))=true
    simpa [g2073, g2074, g2075, g2076, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 3, edge E 1 6]
    apply (mask_ge_two (edge E 1 2) (edge E 1 3) (edge E 1 6)).mp
    change (((g9 E) && (g10 E)) || ((g9 E) && (g13 E)) || ((g10 E) && (g13 E)))=true
    simpa [g2077, g2078, g2079, g2080, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 4 2, edge E 4 3, edge E 4 6]
    apply (mask_ge_one (edge E 4 2) (edge E 4 3) (edge E 4 6)).mp
    change ((g16 E) || (g20 E) || (g25 E))=true
    simpa [g2081, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 2, edge E 5 3, edge E 5 6]
    apply (mask_ge_one (edge E 5 2) (edge E 5 3) (edge E 5 6)).mp
    change ((g17 E) || (g21 E) || (g27 E))=true
    simpa [g2082, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 2, edge E 7 3, edge E 7 6]
    apply (mask_ge_one (edge E 7 2) (edge E 7 3) (edge E 7 6)).mp
    change ((g19 E) || (g23 E) || (g29 E))=true
    simpa [g2083, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1116 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2086, .pos 2090, .pos 2091, .pos 2092, .pos 2093] := by
  change (¬ ((g2087 E)=true)) → (¬ ((g2091 E)=true)) → (¬ ((g2092 E)=true)) → (¬ ((g2093 E)=true)) → (¬ ((g2094 E)=true)) → False
  intro c0 c1 c4 c5 c6
  apply h
  refine ⟨2,3,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 3, edge E 0 7]
    apply (mask_ge_two (edge E 0 2) (edge E 0 3) (edge E 0 7)).mp
    change (((g3 E) && (g4 E)) || ((g3 E) && (g8 E)) || ((g4 E) && (g8 E)))=true
    simpa [g2084, g2085, g2086, g2087, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 3, edge E 1 7]
    apply (mask_ge_two (edge E 1 2) (edge E 1 3) (edge E 1 7)).mp
    change (((g9 E) && (g10 E)) || ((g9 E) && (g14 E)) || ((g10 E) && (g14 E)))=true
    simpa [g2088, g2089, g2090, g2091, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 4 2, edge E 4 3, edge E 4 7]
    apply (mask_ge_one (edge E 4 2) (edge E 4 3) (edge E 4 7)).mp
    change ((g16 E) || (g20 E) || (g26 E))=true
    simpa [g2092, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 2, edge E 5 3, edge E 5 7]
    apply (mask_ge_one (edge E 5 2) (edge E 5 3) (edge E 5 7)).mp
    change ((g17 E) || (g21 E) || (g28 E))=true
    simpa [g2093, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 2, edge E 6 3, edge E 6 7]
    apply (mask_ge_one (edge E 6 2) (edge E 6 3) (edge E 6 7)).mp
    change ((g18 E) || (g22 E) || (g29 E))=true
    simpa [g2094, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_1124 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2097, .pos 2101, .pos 2102, .pos 2103, .pos 2104] := by
  change (¬ ((g2098 E)=true)) → (¬ ((g2102 E)=true)) → (¬ ((g2103 E)=true)) → (¬ ((g2104 E)=true)) → (¬ ((g2105 E)=true)) → False
  intro c0 c1 c3 c6 c7
  apply h
  refine ⟨2,4,5,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 4, edge E 0 5]
    apply (mask_ge_two (edge E 0 2) (edge E 0 4) (edge E 0 5)).mp
    change (((g3 E) && (g5 E)) || ((g3 E) && (g6 E)) || ((g5 E) && (g6 E)))=true
    simpa [g2095, g2096, g2097, g2098, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 4, edge E 1 5]
    apply (mask_ge_two (edge E 1 2) (edge E 1 4) (edge E 1 5)).mp
    change (((g9 E) && (g11 E)) || ((g9 E) && (g12 E)) || ((g11 E) && (g12 E)))=true
    simpa [g2099, g2100, g2101, g2102, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · change 1≤countTrue [edge E 3 2, edge E 3 4, edge E 3 5]
    apply (mask_ge_one (edge E 3 2) (edge E 3 4) (edge E 3 5)).mp
    change ((g15 E) || (g20 E) || (g21 E))=true
    simpa [g2103, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 6 2, edge E 6 4, edge E 6 5]
    apply (mask_ge_one (edge E 6 2) (edge E 6 4) (edge E 6 5)).mp
    change ((g18 E) || (g25 E) || (g27 E))=true
    simpa [g2104, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · change 1≤countTrue [edge E 7 2, edge E 7 4, edge E 7 5]
    apply (mask_ge_one (edge E 7 2) (edge E 7 4) (edge E 7 5)).mp
    change ((g19 E) || (g26 E) || (g28 E))=true
    simpa [g2105, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1137 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2119, .pos 2123, .pos 2124, .pos 2125, .pos 2126] := by
  change (¬ ((g2120 E)=true)) → (¬ ((g2124 E)=true)) → (¬ ((g2125 E)=true)) → (¬ ((g2126 E)=true)) → (¬ ((g2127 E)=true)) → False
  intro c0 c1 c3 c5 c6
  apply h
  refine ⟨2,4,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 4, edge E 0 7]
    apply (mask_ge_two (edge E 0 2) (edge E 0 4) (edge E 0 7)).mp
    change (((g3 E) && (g5 E)) || ((g3 E) && (g8 E)) || ((g5 E) && (g8 E)))=true
    simpa [g2117, g2118, g2119, g2120, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 4, edge E 1 7]
    apply (mask_ge_two (edge E 1 2) (edge E 1 4) (edge E 1 7)).mp
    change (((g9 E) && (g11 E)) || ((g9 E) && (g14 E)) || ((g11 E) && (g14 E)))=true
    simpa [g2121, g2122, g2123, g2124, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · change 1≤countTrue [edge E 3 2, edge E 3 4, edge E 3 7]
    apply (mask_ge_one (edge E 3 2) (edge E 3 4) (edge E 3 7)).mp
    change ((g15 E) || (g20 E) || (g23 E))=true
    simpa [g2125, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 5 2, edge E 5 4, edge E 5 7]
    apply (mask_ge_one (edge E 5 2) (edge E 5 4) (edge E 5 7)).mp
    change ((g17 E) || (g24 E) || (g28 E))=true
    simpa [g2126, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · change 1≤countTrue [edge E 6 2, edge E 6 4, edge E 6 7]
    apply (mask_ge_one (edge E 6 2) (edge E 6 4) (edge E 6 7)).mp
    change ((g18 E) || (g25 E) || (g29 E))=true
    simpa [g2127, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_1152 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2130, .pos 2134, .pos 2135, .pos 2136, .pos 2137] := by
  change (¬ ((g2131 E)=true)) → (¬ ((g2135 E)=true)) → (¬ ((g2136 E)=true)) → (¬ ((g2137 E)=true)) → (¬ ((g2138 E)=true)) → False
  intro c0 c1 c3 c4 c7
  apply h
  refine ⟨2,5,6,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 5, edge E 0 6]
    apply (mask_ge_two (edge E 0 2) (edge E 0 5) (edge E 0 6)).mp
    change (((g3 E) && (g6 E)) || ((g3 E) && (g7 E)) || ((g6 E) && (g7 E)))=true
    simpa [g2128, g2129, g2130, g2131, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 5, edge E 1 6]
    apply (mask_ge_two (edge E 1 2) (edge E 1 5) (edge E 1 6)).mp
    change (((g9 E) && (g12 E)) || ((g9 E) && (g13 E)) || ((g12 E) && (g13 E)))=true
    simpa [g2132, g2133, g2134, g2135, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · change 1≤countTrue [edge E 3 2, edge E 3 5, edge E 3 6]
    apply (mask_ge_one (edge E 3 2) (edge E 3 5) (edge E 3 6)).mp
    change ((g15 E) || (g21 E) || (g22 E))=true
    simpa [g2136, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 2, edge E 4 5, edge E 4 6]
    apply (mask_ge_one (edge E 4 2) (edge E 4 5) (edge E 4 6)).mp
    change ((g16 E) || (g24 E) || (g25 E))=true
    simpa [g2137, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
  · change 1≤countTrue [edge E 7 2, edge E 7 5, edge E 7 6]
    apply (mask_ge_one (edge E 7 2) (edge E 7 5) (edge E 7 6)).mp
    change ((g19 E) || (g28 E) || (g29 E))=true
    simpa [g2138, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c7)
private theorem root_1169 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2141, .pos 2145, .pos 2146, .pos 2147, .pos 2148] := by
  change (¬ ((g2142 E)=true)) → (¬ ((g2146 E)=true)) → (¬ ((g2147 E)=true)) → (¬ ((g2148 E)=true)) → (¬ ((g2149 E)=true)) → False
  intro c0 c1 c3 c4 c6
  apply h
  refine ⟨2,5,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 5, edge E 0 7]
    apply (mask_ge_two (edge E 0 2) (edge E 0 5) (edge E 0 7)).mp
    change (((g3 E) && (g6 E)) || ((g3 E) && (g8 E)) || ((g6 E) && (g8 E)))=true
    simpa [g2139, g2140, g2141, g2142, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 5, edge E 1 7]
    apply (mask_ge_two (edge E 1 2) (edge E 1 5) (edge E 1 7)).mp
    change (((g9 E) && (g12 E)) || ((g9 E) && (g14 E)) || ((g12 E) && (g14 E)))=true
    simpa [g2143, g2144, g2145, g2146, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · change 1≤countTrue [edge E 3 2, edge E 3 5, edge E 3 7]
    apply (mask_ge_one (edge E 3 2) (edge E 3 5) (edge E 3 7)).mp
    change ((g15 E) || (g21 E) || (g23 E))=true
    simpa [g2147, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 2, edge E 4 5, edge E 4 7]
    apply (mask_ge_one (edge E 4 2) (edge E 4 5) (edge E 4 7)).mp
    change ((g16 E) || (g24 E) || (g26 E))=true
    simpa [g2148, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (vb rfl).elim
  · change 1≤countTrue [edge E 6 2, edge E 6 5, edge E 6 7]
    apply (mask_ge_one (edge E 6 2) (edge E 6 5) (edge E 6 7)).mp
    change ((g18 E) || (g27 E) || (g29 E))=true
    simpa [g2149, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c6)
  · exact (vc rfl).elim
private theorem root_1197 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2152, .pos 2156, .pos 2157, .pos 2158, .pos 2159] := by
  change (¬ ((g2153 E)=true)) → (¬ ((g2157 E)=true)) → (¬ ((g2158 E)=true)) → (¬ ((g2159 E)=true)) → (¬ ((g2160 E)=true)) → False
  intro c0 c1 c3 c4 c5
  apply h
  refine ⟨2,6,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 2, edge E 0 6, edge E 0 7]
    apply (mask_ge_two (edge E 0 2) (edge E 0 6) (edge E 0 7)).mp
    change (((g3 E) && (g7 E)) || ((g3 E) && (g8 E)) || ((g7 E) && (g8 E)))=true
    simpa [g2150, g2151, g2152, g2153, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 2, edge E 1 6, edge E 1 7]
    apply (mask_ge_two (edge E 1 2) (edge E 1 6) (edge E 1 7)).mp
    change (((g9 E) && (g13 E)) || ((g9 E) && (g14 E)) || ((g13 E) && (g14 E)))=true
    simpa [g2154, g2155, g2156, g2157, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · exact (va rfl).elim
  · change 1≤countTrue [edge E 3 2, edge E 3 6, edge E 3 7]
    apply (mask_ge_one (edge E 3 2) (edge E 3 6) (edge E 3 7)).mp
    change ((g15 E) || (g22 E) || (g23 E))=true
    simpa [g2158, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 2, edge E 4 6, edge E 4 7]
    apply (mask_ge_one (edge E 4 2) (edge E 4 6) (edge E 4 7)).mp
    change ((g16 E) || (g25 E) || (g26 E))=true
    simpa [g2159, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · change 1≤countTrue [edge E 5 2, edge E 5 6, edge E 5 7]
    apply (mask_ge_one (edge E 5 2) (edge E 5 6) (edge E 5 7)).mp
    change ((g17 E) || (g27 E) || (g28 E))=true
    simpa [g2160, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c5)
  · exact (vb rfl).elim
  · exact (vc rfl).elim
private theorem root_1241 (E : Nat→Bool) (h : ¬HasTriple E) : (valuation E).satisfies [.pos 2289, .pos 2293, .pos 2297, .pos 2298, .pos 2299] := by
  change (¬ ((g2290 E)=true)) → (¬ ((g2294 E)=true)) → (¬ ((g2298 E)=true)) → (¬ ((g2299 E)=true)) → (¬ ((g2300 E)=true)) → False
  intro c0 c1 c2 c3 c4
  apply h
  refine ⟨5,6,7,by decide,by decide,?_⟩
  intro v va vb vc
  fin_cases v
  · change 2≤countTrue [edge E 0 5, edge E 0 6, edge E 0 7]
    apply (mask_ge_two (edge E 0 5) (edge E 0 6) (edge E 0 7)).mp
    change (((g6 E) && (g7 E)) || ((g6 E) && (g8 E)) || ((g7 E) && (g8 E)))=true
    simpa [g2287, g2288, g2289, g2290, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c0)
  · change 2≤countTrue [edge E 1 5, edge E 1 6, edge E 1 7]
    apply (mask_ge_two (edge E 1 5) (edge E 1 6) (edge E 1 7)).mp
    change (((g12 E) && (g13 E)) || ((g12 E) && (g14 E)) || ((g13 E) && (g14 E)))=true
    simpa [g2291, g2292, g2293, g2294, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c1)
  · change 2≤countTrue [edge E 2 5, edge E 2 6, edge E 2 7]
    apply (mask_ge_two (edge E 2 5) (edge E 2 6) (edge E 2 7)).mp
    change (((g17 E) && (g18 E)) || ((g17 E) && (g19 E)) || ((g18 E) && (g19 E)))=true
    simpa [g2295, g2296, g2297, g2298, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c2)
  · change 1≤countTrue [edge E 3 5, edge E 3 6, edge E 3 7]
    apply (mask_ge_one (edge E 3 5) (edge E 3 6) (edge E 3 7)).mp
    change ((g21 E) || (g22 E) || (g23 E))=true
    simpa [g2299, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c3)
  · change 1≤countTrue [edge E 4 5, edge E 4 6, edge E 4 7]
    apply (mask_ge_one (edge E 4 5) (edge E 4 6) (edge E 4 7)).mp
    change ((g24 E) || (g25 E) || (g26 E))=true
    simpa [g2300, Bool.not_and, Bool.and_comm, Bool.or_comm, Bool.or_left_comm, Bool.or_assoc] using ((negWire _).mpr c4)
  · exact (va rfl).elim
  · exact (vb rfl).elim
  · exact (vc rfl).elim
theorem have_triple_of_exact_counts (E : Nat→Bool)
    (d0 : 3≤degree0_count E)
    (d1 : 3≤degree1_count E)
    (d2 : 3≤degree2_count E)
    (d3 : 3≤degree3_count E)
    (d4 : 3≤degree4_count E)
    (d5 : 3≤degree5_count E)
    (s0 : 2≤score0_count E)
    (o01 : score0_count E<score1_count E)
    (o12 : score1_count E<score2_count E)
    (p34 : portRank E 3≤portRank E 4)
    (p45 : portRank E 4≤portRank E 5)
    (p56 : portRank E 5≤portRank E 6)
    (p67 : portRank E 6≤portRank E 7)
    : HasTriple E := by
  by_contra n
  apply contradiction_of_semantic_roots E
  · exact root_29 E d0
  · exact root_60 E d1
  · exact root_90 E d2
  · exact root_126 E d3
  · exact root_166 E d4
  · exact root_194 E d5
  · exact root_746 E s0
  · exact root_747 E o01
  · exact root_748 E o01
  · exact root_749 E o12
  · exact root_756 E p34
  · exact root_764 E p45
  · exact root_772 E p56
  · exact root_781 E p67
  · exact root_800 E n
  · exact root_817 E n
  · exact root_833 E n
  · exact root_844 E n
  · exact root_858 E n
  · exact root_868 E n
  · exact root_883 E n
  · exact root_897 E n
  · exact root_915 E n
  · exact root_931 E n
  · exact root_947 E n
  · exact root_955 E n
  · exact root_963 E n
  · exact root_980 E n
  · exact root_993 E n
  · exact root_1009 E n
  · exact root_1024 E n
  · exact root_1043 E n
  · exact root_1060 E n
  · exact root_1068 E n
  · exact root_1076 E n
  · exact root_1087 E n
  · exact root_1095 E n
  · exact root_1106 E n
  · exact root_1116 E n
  · exact root_1124 E n
  · exact root_1137 E n
  · exact root_1152 E n
  · exact root_1169 E n
  · exact root_1197 E n
  · exact root_1241 E n
#print axioms have_triple_of_exact_counts
end Graffiti384b.DiversityEleven.PendantCircuit.K3
