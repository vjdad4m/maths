import DiversityElevenPendantWires3384b
namespace Graffiti384b.DiversityEleven.PendantCircuit.K3
set_option maxHeartbeats 3000000
def degree0_vals1 (E : Nat→Bool) : List Bool := (g2 E) :: ([])
def degree0_vals2 (E : Nat→Bool) : List Bool := (g3 E) :: (degree0_vals1 E)
def degree0_vals3 (E : Nat→Bool) : List Bool := (g4 E) :: (degree0_vals2 E)
def degree0_vals4 (E : Nat→Bool) : List Bool := (g5 E) :: (degree0_vals3 E)
def degree0_vals5 (E : Nat→Bool) : List Bool := (g6 E) :: (degree0_vals4 E)
def degree0_vals6 (E : Nat→Bool) : List Bool := (g7 E) :: (degree0_vals5 E)
def degree0_vals7 (E : Nat→Bool) : List Bool := (g8 E) :: (degree0_vals6 E)
theorem degree0_threshold1_0 (E : Nat→Bool) : ((g2 E)=true) ↔ 1≤countTrue (degree0_vals1 E) := by
  have rew : (g2 E) = ((!g1 E) || ((g2 E) && (g1 E))) := by simp [g1,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 1≤countTrue ([] : List Bool) := by
    have hh := count_true_bound ([] : List Bool)
    change countTrue ([] : List Bool)≤0 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬1≤countTrue ([] : List Bool)
    omega
  have T0 : (g1 E)=true ↔ 0≤countTrue ([] : List Bool) := by simp [g1]
  exact threshold_step (g2 E) (!g1 E) (g1 E) 0 (countTrue ([] : List Bool)) T1 T0
theorem degree0_threshold2_1 (E : Nat→Bool) : ((g31 E)=true) ↔ 2≤countTrue (degree0_vals2 E) := by
  have rew : (g31 E) = ((!g1 E) || ((g3 E) && (g2 E))) := by simp [g1,g31,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 2≤countTrue (degree0_vals1 E) := by
    have hh := count_true_bound (degree0_vals1 E)
    change countTrue (degree0_vals1 E)≤1 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬2≤countTrue (degree0_vals1 E)
    omega
  have T0 := degree0_threshold1_0 E
  exact threshold_step (g3 E) (!g1 E) (g2 E) 1 (countTrue (degree0_vals1 E)) T1 T0
theorem degree0_threshold3_2 (E : Nat→Bool) : ((g35 E)=true) ↔ 3≤countTrue (degree0_vals3 E) := by
  have rew : (g35 E) = ((!g1 E) || ((g4 E) && (g31 E))) := by simp [g1,g35,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 3≤countTrue (degree0_vals2 E) := by
    have hh := count_true_bound (degree0_vals2 E)
    change countTrue (degree0_vals2 E)≤2 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬3≤countTrue (degree0_vals2 E)
    omega
  have T0 := degree0_threshold2_1 E
  exact threshold_step (g4 E) (!g1 E) (g31 E) 2 (countTrue (degree0_vals2 E)) T1 T0
theorem degree0_threshold2_0 (E : Nat→Bool) : ((!g30 E)=true) ↔ 1≤countTrue (degree0_vals2 E) := by
  have rew : (!g30 E) = ((g2 E) || ((g3 E) && (g1 E))) := by simp [g1,g30,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree0_threshold1_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree0_vals1 E) := by simp [g1]
  exact threshold_step (g3 E) (g2 E) (g1 E) 0 (countTrue (degree0_vals1 E)) T1 T0
theorem degree0_threshold3_1 (E : Nat→Bool) : ((!g34 E)=true) ↔ 2≤countTrue (degree0_vals3 E) := by
  have rew : (!g34 E) = ((g31 E) || ((g4 E) && (!g30 E))) := by simp [g1,g33,g34,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree0_threshold2_1 E
  have T0 := degree0_threshold2_0 E
  exact threshold_step (g4 E) (g31 E) (!g30 E) 1 (countTrue (degree0_vals2 E)) T1 T0
theorem degree0_threshold4_2 (E : Nat→Bool) : ((!g40 E)=true) ↔ 3≤countTrue (degree0_vals4 E) := by
  have rew : (!g40 E) = ((g35 E) || ((g5 E) && (!g34 E))) := by simp [g1,g39,g40,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree0_threshold3_2 E
  have T0 := degree0_threshold3_1 E
  exact threshold_step (g5 E) (g35 E) (!g34 E) 2 (countTrue (degree0_vals3 E)) T1 T0
theorem degree0_threshold3_0 (E : Nat→Bool) : ((!g32 E)=true) ↔ 1≤countTrue (degree0_vals3 E) := by
  have rew : (!g32 E) = ((!g30 E) || ((g4 E) && (g1 E))) := by simp [g1,g32,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree0_threshold2_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree0_vals2 E) := by simp [g1]
  exact threshold_step (g4 E) (!g30 E) (g1 E) 0 (countTrue (degree0_vals2 E)) T1 T0
theorem degree0_threshold4_1 (E : Nat→Bool) : ((!g38 E)=true) ↔ 2≤countTrue (degree0_vals4 E) := by
  have rew : (!g38 E) = ((!g34 E) || ((g5 E) && (!g32 E))) := by simp [g1,g37,g38,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree0_threshold3_1 E
  have T0 := degree0_threshold3_0 E
  exact threshold_step (g5 E) (!g34 E) (!g32 E) 1 (countTrue (degree0_vals3 E)) T1 T0
theorem degree0_threshold5_2 (E : Nat→Bool) : ((!g46 E)=true) ↔ 3≤countTrue (degree0_vals5 E) := by
  have rew : (!g46 E) = ((!g40 E) || ((g6 E) && (!g38 E))) := by simp [g1,g45,g46,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree0_threshold4_2 E
  have T0 := degree0_threshold4_1 E
  exact threshold_step (g6 E) (!g40 E) (!g38 E) 2 (countTrue (degree0_vals4 E)) T1 T0
theorem degree0_threshold4_0 (E : Nat→Bool) : ((!g36 E)=true) ↔ 1≤countTrue (degree0_vals4 E) := by
  have rew : (!g36 E) = ((!g32 E) || ((g5 E) && (g1 E))) := by simp [g1,g36,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree0_threshold3_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree0_vals3 E) := by simp [g1]
  exact threshold_step (g5 E) (!g32 E) (g1 E) 0 (countTrue (degree0_vals3 E)) T1 T0
theorem degree0_threshold5_1 (E : Nat→Bool) : ((!g44 E)=true) ↔ 2≤countTrue (degree0_vals5 E) := by
  have rew : (!g44 E) = ((!g38 E) || ((g6 E) && (!g36 E))) := by simp [g1,g43,g44,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree0_threshold4_1 E
  have T0 := degree0_threshold4_0 E
  exact threshold_step (g6 E) (!g38 E) (!g36 E) 1 (countTrue (degree0_vals4 E)) T1 T0
theorem degree0_threshold6_2 (E : Nat→Bool) : ((!g54 E)=true) ↔ 3≤countTrue (degree0_vals6 E) := by
  have rew : (!g54 E) = ((!g46 E) || ((g7 E) && (!g44 E))) := by simp [g1,g53,g54,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree0_threshold5_2 E
  have T0 := degree0_threshold5_1 E
  exact threshold_step (g7 E) (!g46 E) (!g44 E) 2 (countTrue (degree0_vals5 E)) T1 T0
theorem degree0_threshold5_0 (E : Nat→Bool) : ((!g42 E)=true) ↔ 1≤countTrue (degree0_vals5 E) := by
  have rew : (!g42 E) = ((!g36 E) || ((g6 E) && (g1 E))) := by simp [g1,g42,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree0_threshold4_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree0_vals4 E) := by simp [g1]
  exact threshold_step (g6 E) (!g36 E) (g1 E) 0 (countTrue (degree0_vals4 E)) T1 T0
theorem degree0_threshold6_1 (E : Nat→Bool) : ((!g52 E)=true) ↔ 2≤countTrue (degree0_vals6 E) := by
  have rew : (!g52 E) = ((!g44 E) || ((g7 E) && (!g42 E))) := by simp [g1,g51,g52,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree0_threshold5_1 E
  have T0 := degree0_threshold5_0 E
  exact threshold_step (g7 E) (!g44 E) (!g42 E) 1 (countTrue (degree0_vals5 E)) T1 T0
theorem degree0_threshold7_2 (E : Nat→Bool) : ((!g64 E)=true) ↔ 3≤countTrue (degree0_vals7 E) := by
  have rew : (!g64 E) = ((!g54 E) || ((g8 E) && (!g52 E))) := by simp [g1,g63,g64,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree0_threshold6_2 E
  have T0 := degree0_threshold6_1 E
  exact threshold_step (g8 E) (!g54 E) (!g52 E) 2 (countTrue (degree0_vals6 E)) T1 T0
def degree0_count (E : Nat→Bool) : Nat := countTrue (degree0_vals7 E)
def degree1_vals1 (E : Nat→Bool) : List Bool := (g2 E) :: ([])
def degree1_vals2 (E : Nat→Bool) : List Bool := (g9 E) :: (degree1_vals1 E)
def degree1_vals3 (E : Nat→Bool) : List Bool := (g10 E) :: (degree1_vals2 E)
def degree1_vals4 (E : Nat→Bool) : List Bool := (g11 E) :: (degree1_vals3 E)
def degree1_vals5 (E : Nat→Bool) : List Bool := (g12 E) :: (degree1_vals4 E)
def degree1_vals6 (E : Nat→Bool) : List Bool := (g13 E) :: (degree1_vals5 E)
def degree1_vals7 (E : Nat→Bool) : List Bool := (g14 E) :: (degree1_vals6 E)
theorem degree1_threshold1_0 (E : Nat→Bool) : ((g2 E)=true) ↔ 1≤countTrue (degree1_vals1 E) := by
  have rew : (g2 E) = ((!g1 E) || ((g2 E) && (g1 E))) := by simp [g1,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 1≤countTrue ([] : List Bool) := by
    have hh := count_true_bound ([] : List Bool)
    change countTrue ([] : List Bool)≤0 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬1≤countTrue ([] : List Bool)
    omega
  have T0 : (g1 E)=true ↔ 0≤countTrue ([] : List Bool) := by simp [g1]
  exact threshold_step (g2 E) (!g1 E) (g1 E) 0 (countTrue ([] : List Bool)) T1 T0
theorem degree1_threshold2_1 (E : Nat→Bool) : ((g73 E)=true) ↔ 2≤countTrue (degree1_vals2 E) := by
  have rew : (g73 E) = ((!g1 E) || ((g9 E) && (g2 E))) := by simp [g1,g73,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 2≤countTrue (degree1_vals1 E) := by
    have hh := count_true_bound (degree1_vals1 E)
    change countTrue (degree1_vals1 E)≤1 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬2≤countTrue (degree1_vals1 E)
    omega
  have T0 := degree1_threshold1_0 E
  exact threshold_step (g9 E) (!g1 E) (g2 E) 1 (countTrue (degree1_vals1 E)) T1 T0
theorem degree1_threshold3_2 (E : Nat→Bool) : ((g77 E)=true) ↔ 3≤countTrue (degree1_vals3 E) := by
  have rew : (g77 E) = ((!g1 E) || ((g10 E) && (g73 E))) := by simp [g1,g77,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 3≤countTrue (degree1_vals2 E) := by
    have hh := count_true_bound (degree1_vals2 E)
    change countTrue (degree1_vals2 E)≤2 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬3≤countTrue (degree1_vals2 E)
    omega
  have T0 := degree1_threshold2_1 E
  exact threshold_step (g10 E) (!g1 E) (g73 E) 2 (countTrue (degree1_vals2 E)) T1 T0
theorem degree1_threshold2_0 (E : Nat→Bool) : ((!g72 E)=true) ↔ 1≤countTrue (degree1_vals2 E) := by
  have rew : (!g72 E) = ((g2 E) || ((g9 E) && (g1 E))) := by simp [g1,g72,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree1_threshold1_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree1_vals1 E) := by simp [g1]
  exact threshold_step (g9 E) (g2 E) (g1 E) 0 (countTrue (degree1_vals1 E)) T1 T0
theorem degree1_threshold3_1 (E : Nat→Bool) : ((!g76 E)=true) ↔ 2≤countTrue (degree1_vals3 E) := by
  have rew : (!g76 E) = ((g73 E) || ((g10 E) && (!g72 E))) := by simp [g1,g75,g76,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree1_threshold2_1 E
  have T0 := degree1_threshold2_0 E
  exact threshold_step (g10 E) (g73 E) (!g72 E) 1 (countTrue (degree1_vals2 E)) T1 T0
theorem degree1_threshold4_2 (E : Nat→Bool) : ((!g82 E)=true) ↔ 3≤countTrue (degree1_vals4 E) := by
  have rew : (!g82 E) = ((g77 E) || ((g11 E) && (!g76 E))) := by simp [g1,g81,g82,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree1_threshold3_2 E
  have T0 := degree1_threshold3_1 E
  exact threshold_step (g11 E) (g77 E) (!g76 E) 2 (countTrue (degree1_vals3 E)) T1 T0
theorem degree1_threshold3_0 (E : Nat→Bool) : ((!g74 E)=true) ↔ 1≤countTrue (degree1_vals3 E) := by
  have rew : (!g74 E) = ((!g72 E) || ((g10 E) && (g1 E))) := by simp [g1,g74,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree1_threshold2_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree1_vals2 E) := by simp [g1]
  exact threshold_step (g10 E) (!g72 E) (g1 E) 0 (countTrue (degree1_vals2 E)) T1 T0
theorem degree1_threshold4_1 (E : Nat→Bool) : ((!g80 E)=true) ↔ 2≤countTrue (degree1_vals4 E) := by
  have rew : (!g80 E) = ((!g76 E) || ((g11 E) && (!g74 E))) := by simp [g1,g79,g80,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree1_threshold3_1 E
  have T0 := degree1_threshold3_0 E
  exact threshold_step (g11 E) (!g76 E) (!g74 E) 1 (countTrue (degree1_vals3 E)) T1 T0
theorem degree1_threshold5_2 (E : Nat→Bool) : ((!g88 E)=true) ↔ 3≤countTrue (degree1_vals5 E) := by
  have rew : (!g88 E) = ((!g82 E) || ((g12 E) && (!g80 E))) := by simp [g1,g87,g88,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree1_threshold4_2 E
  have T0 := degree1_threshold4_1 E
  exact threshold_step (g12 E) (!g82 E) (!g80 E) 2 (countTrue (degree1_vals4 E)) T1 T0
theorem degree1_threshold4_0 (E : Nat→Bool) : ((!g78 E)=true) ↔ 1≤countTrue (degree1_vals4 E) := by
  have rew : (!g78 E) = ((!g74 E) || ((g11 E) && (g1 E))) := by simp [g1,g78,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree1_threshold3_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree1_vals3 E) := by simp [g1]
  exact threshold_step (g11 E) (!g74 E) (g1 E) 0 (countTrue (degree1_vals3 E)) T1 T0
theorem degree1_threshold5_1 (E : Nat→Bool) : ((!g86 E)=true) ↔ 2≤countTrue (degree1_vals5 E) := by
  have rew : (!g86 E) = ((!g80 E) || ((g12 E) && (!g78 E))) := by simp [g1,g85,g86,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree1_threshold4_1 E
  have T0 := degree1_threshold4_0 E
  exact threshold_step (g12 E) (!g80 E) (!g78 E) 1 (countTrue (degree1_vals4 E)) T1 T0
theorem degree1_threshold6_2 (E : Nat→Bool) : ((!g96 E)=true) ↔ 3≤countTrue (degree1_vals6 E) := by
  have rew : (!g96 E) = ((!g88 E) || ((g13 E) && (!g86 E))) := by simp [g1,g95,g96,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree1_threshold5_2 E
  have T0 := degree1_threshold5_1 E
  exact threshold_step (g13 E) (!g88 E) (!g86 E) 2 (countTrue (degree1_vals5 E)) T1 T0
theorem degree1_threshold5_0 (E : Nat→Bool) : ((!g84 E)=true) ↔ 1≤countTrue (degree1_vals5 E) := by
  have rew : (!g84 E) = ((!g78 E) || ((g12 E) && (g1 E))) := by simp [g1,g84,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree1_threshold4_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree1_vals4 E) := by simp [g1]
  exact threshold_step (g12 E) (!g78 E) (g1 E) 0 (countTrue (degree1_vals4 E)) T1 T0
theorem degree1_threshold6_1 (E : Nat→Bool) : ((!g94 E)=true) ↔ 2≤countTrue (degree1_vals6 E) := by
  have rew : (!g94 E) = ((!g86 E) || ((g13 E) && (!g84 E))) := by simp [g1,g93,g94,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree1_threshold5_1 E
  have T0 := degree1_threshold5_0 E
  exact threshold_step (g13 E) (!g86 E) (!g84 E) 1 (countTrue (degree1_vals5 E)) T1 T0
theorem degree1_threshold7_2 (E : Nat→Bool) : ((!g106 E)=true) ↔ 3≤countTrue (degree1_vals7 E) := by
  have rew : (!g106 E) = ((!g96 E) || ((g14 E) && (!g94 E))) := by simp [g1,g105,g106,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree1_threshold6_2 E
  have T0 := degree1_threshold6_1 E
  exact threshold_step (g14 E) (!g96 E) (!g94 E) 2 (countTrue (degree1_vals6 E)) T1 T0
def degree1_count (E : Nat→Bool) : Nat := countTrue (degree1_vals7 E)
def degree2_vals1 (E : Nat→Bool) : List Bool := (g3 E) :: ([])
def degree2_vals2 (E : Nat→Bool) : List Bool := (g9 E) :: (degree2_vals1 E)
def degree2_vals3 (E : Nat→Bool) : List Bool := (g15 E) :: (degree2_vals2 E)
def degree2_vals4 (E : Nat→Bool) : List Bool := (g16 E) :: (degree2_vals3 E)
def degree2_vals5 (E : Nat→Bool) : List Bool := (g17 E) :: (degree2_vals4 E)
def degree2_vals6 (E : Nat→Bool) : List Bool := (g18 E) :: (degree2_vals5 E)
def degree2_vals7 (E : Nat→Bool) : List Bool := (g19 E) :: (degree2_vals6 E)
theorem degree2_threshold1_0 (E : Nat→Bool) : ((g3 E)=true) ↔ 1≤countTrue (degree2_vals1 E) := by
  have rew : (g3 E) = ((!g1 E) || ((g3 E) && (g1 E))) := by simp [g1,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 1≤countTrue ([] : List Bool) := by
    have hh := count_true_bound ([] : List Bool)
    change countTrue ([] : List Bool)≤0 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬1≤countTrue ([] : List Bool)
    omega
  have T0 : (g1 E)=true ↔ 0≤countTrue ([] : List Bool) := by simp [g1]
  exact threshold_step (g3 E) (!g1 E) (g1 E) 0 (countTrue ([] : List Bool)) T1 T0
theorem degree2_threshold2_1 (E : Nat→Bool) : ((g115 E)=true) ↔ 2≤countTrue (degree2_vals2 E) := by
  have rew : (g115 E) = ((!g1 E) || ((g9 E) && (g3 E))) := by simp [g1,g115,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 2≤countTrue (degree2_vals1 E) := by
    have hh := count_true_bound (degree2_vals1 E)
    change countTrue (degree2_vals1 E)≤1 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬2≤countTrue (degree2_vals1 E)
    omega
  have T0 := degree2_threshold1_0 E
  exact threshold_step (g9 E) (!g1 E) (g3 E) 1 (countTrue (degree2_vals1 E)) T1 T0
theorem degree2_threshold3_2 (E : Nat→Bool) : ((g119 E)=true) ↔ 3≤countTrue (degree2_vals3 E) := by
  have rew : (g119 E) = ((!g1 E) || ((g15 E) && (g115 E))) := by simp [g1,g119,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 3≤countTrue (degree2_vals2 E) := by
    have hh := count_true_bound (degree2_vals2 E)
    change countTrue (degree2_vals2 E)≤2 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬3≤countTrue (degree2_vals2 E)
    omega
  have T0 := degree2_threshold2_1 E
  exact threshold_step (g15 E) (!g1 E) (g115 E) 2 (countTrue (degree2_vals2 E)) T1 T0
theorem degree2_threshold2_0 (E : Nat→Bool) : ((!g114 E)=true) ↔ 1≤countTrue (degree2_vals2 E) := by
  have rew : (!g114 E) = ((g3 E) || ((g9 E) && (g1 E))) := by simp [g1,g114,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree2_threshold1_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree2_vals1 E) := by simp [g1]
  exact threshold_step (g9 E) (g3 E) (g1 E) 0 (countTrue (degree2_vals1 E)) T1 T0
theorem degree2_threshold3_1 (E : Nat→Bool) : ((!g118 E)=true) ↔ 2≤countTrue (degree2_vals3 E) := by
  have rew : (!g118 E) = ((g115 E) || ((g15 E) && (!g114 E))) := by simp [g1,g117,g118,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree2_threshold2_1 E
  have T0 := degree2_threshold2_0 E
  exact threshold_step (g15 E) (g115 E) (!g114 E) 1 (countTrue (degree2_vals2 E)) T1 T0
theorem degree2_threshold4_2 (E : Nat→Bool) : ((!g124 E)=true) ↔ 3≤countTrue (degree2_vals4 E) := by
  have rew : (!g124 E) = ((g119 E) || ((g16 E) && (!g118 E))) := by simp [g1,g123,g124,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree2_threshold3_2 E
  have T0 := degree2_threshold3_1 E
  exact threshold_step (g16 E) (g119 E) (!g118 E) 2 (countTrue (degree2_vals3 E)) T1 T0
theorem degree2_threshold3_0 (E : Nat→Bool) : ((!g116 E)=true) ↔ 1≤countTrue (degree2_vals3 E) := by
  have rew : (!g116 E) = ((!g114 E) || ((g15 E) && (g1 E))) := by simp [g1,g116,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree2_threshold2_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree2_vals2 E) := by simp [g1]
  exact threshold_step (g15 E) (!g114 E) (g1 E) 0 (countTrue (degree2_vals2 E)) T1 T0
theorem degree2_threshold4_1 (E : Nat→Bool) : ((!g122 E)=true) ↔ 2≤countTrue (degree2_vals4 E) := by
  have rew : (!g122 E) = ((!g118 E) || ((g16 E) && (!g116 E))) := by simp [g1,g121,g122,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree2_threshold3_1 E
  have T0 := degree2_threshold3_0 E
  exact threshold_step (g16 E) (!g118 E) (!g116 E) 1 (countTrue (degree2_vals3 E)) T1 T0
theorem degree2_threshold5_2 (E : Nat→Bool) : ((!g130 E)=true) ↔ 3≤countTrue (degree2_vals5 E) := by
  have rew : (!g130 E) = ((!g124 E) || ((g17 E) && (!g122 E))) := by simp [g1,g129,g130,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree2_threshold4_2 E
  have T0 := degree2_threshold4_1 E
  exact threshold_step (g17 E) (!g124 E) (!g122 E) 2 (countTrue (degree2_vals4 E)) T1 T0
theorem degree2_threshold4_0 (E : Nat→Bool) : ((!g120 E)=true) ↔ 1≤countTrue (degree2_vals4 E) := by
  have rew : (!g120 E) = ((!g116 E) || ((g16 E) && (g1 E))) := by simp [g1,g120,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree2_threshold3_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree2_vals3 E) := by simp [g1]
  exact threshold_step (g16 E) (!g116 E) (g1 E) 0 (countTrue (degree2_vals3 E)) T1 T0
theorem degree2_threshold5_1 (E : Nat→Bool) : ((!g128 E)=true) ↔ 2≤countTrue (degree2_vals5 E) := by
  have rew : (!g128 E) = ((!g122 E) || ((g17 E) && (!g120 E))) := by simp [g1,g127,g128,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree2_threshold4_1 E
  have T0 := degree2_threshold4_0 E
  exact threshold_step (g17 E) (!g122 E) (!g120 E) 1 (countTrue (degree2_vals4 E)) T1 T0
theorem degree2_threshold6_2 (E : Nat→Bool) : ((!g138 E)=true) ↔ 3≤countTrue (degree2_vals6 E) := by
  have rew : (!g138 E) = ((!g130 E) || ((g18 E) && (!g128 E))) := by simp [g1,g137,g138,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree2_threshold5_2 E
  have T0 := degree2_threshold5_1 E
  exact threshold_step (g18 E) (!g130 E) (!g128 E) 2 (countTrue (degree2_vals5 E)) T1 T0
theorem degree2_threshold5_0 (E : Nat→Bool) : ((!g126 E)=true) ↔ 1≤countTrue (degree2_vals5 E) := by
  have rew : (!g126 E) = ((!g120 E) || ((g17 E) && (g1 E))) := by simp [g1,g126,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree2_threshold4_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree2_vals4 E) := by simp [g1]
  exact threshold_step (g17 E) (!g120 E) (g1 E) 0 (countTrue (degree2_vals4 E)) T1 T0
theorem degree2_threshold6_1 (E : Nat→Bool) : ((!g136 E)=true) ↔ 2≤countTrue (degree2_vals6 E) := by
  have rew : (!g136 E) = ((!g128 E) || ((g18 E) && (!g126 E))) := by simp [g1,g135,g136,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree2_threshold5_1 E
  have T0 := degree2_threshold5_0 E
  exact threshold_step (g18 E) (!g128 E) (!g126 E) 1 (countTrue (degree2_vals5 E)) T1 T0
theorem degree2_threshold7_2 (E : Nat→Bool) : ((!g148 E)=true) ↔ 3≤countTrue (degree2_vals7 E) := by
  have rew : (!g148 E) = ((!g138 E) || ((g19 E) && (!g136 E))) := by simp [g1,g147,g148,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree2_threshold6_2 E
  have T0 := degree2_threshold6_1 E
  exact threshold_step (g19 E) (!g138 E) (!g136 E) 2 (countTrue (degree2_vals6 E)) T1 T0
def degree2_count (E : Nat→Bool) : Nat := countTrue (degree2_vals7 E)
def degree3_vals1 (E : Nat→Bool) : List Bool := (g4 E) :: ([])
def degree3_vals2 (E : Nat→Bool) : List Bool := (g10 E) :: (degree3_vals1 E)
def degree3_vals3 (E : Nat→Bool) : List Bool := (g15 E) :: (degree3_vals2 E)
def degree3_vals4 (E : Nat→Bool) : List Bool := (g20 E) :: (degree3_vals3 E)
def degree3_vals5 (E : Nat→Bool) : List Bool := (g21 E) :: (degree3_vals4 E)
def degree3_vals6 (E : Nat→Bool) : List Bool := (g22 E) :: (degree3_vals5 E)
def degree3_vals7 (E : Nat→Bool) : List Bool := (g23 E) :: (degree3_vals6 E)
theorem degree3_threshold1_0 (E : Nat→Bool) : ((g4 E)=true) ↔ 1≤countTrue (degree3_vals1 E) := by
  have rew : (g4 E) = ((!g1 E) || ((g4 E) && (g1 E))) := by simp [g1,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 1≤countTrue ([] : List Bool) := by
    have hh := count_true_bound ([] : List Bool)
    change countTrue ([] : List Bool)≤0 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬1≤countTrue ([] : List Bool)
    omega
  have T0 : (g1 E)=true ↔ 0≤countTrue ([] : List Bool) := by simp [g1]
  exact threshold_step (g4 E) (!g1 E) (g1 E) 0 (countTrue ([] : List Bool)) T1 T0
theorem degree3_threshold2_1 (E : Nat→Bool) : ((g157 E)=true) ↔ 2≤countTrue (degree3_vals2 E) := by
  have rew : (g157 E) = ((!g1 E) || ((g10 E) && (g4 E))) := by simp [g1,g157,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 2≤countTrue (degree3_vals1 E) := by
    have hh := count_true_bound (degree3_vals1 E)
    change countTrue (degree3_vals1 E)≤1 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬2≤countTrue (degree3_vals1 E)
    omega
  have T0 := degree3_threshold1_0 E
  exact threshold_step (g10 E) (!g1 E) (g4 E) 1 (countTrue (degree3_vals1 E)) T1 T0
theorem degree3_threshold3_2 (E : Nat→Bool) : ((g161 E)=true) ↔ 3≤countTrue (degree3_vals3 E) := by
  have rew : (g161 E) = ((!g1 E) || ((g15 E) && (g157 E))) := by simp [g1,g161,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 3≤countTrue (degree3_vals2 E) := by
    have hh := count_true_bound (degree3_vals2 E)
    change countTrue (degree3_vals2 E)≤2 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬3≤countTrue (degree3_vals2 E)
    omega
  have T0 := degree3_threshold2_1 E
  exact threshold_step (g15 E) (!g1 E) (g157 E) 2 (countTrue (degree3_vals2 E)) T1 T0
theorem degree3_threshold2_0 (E : Nat→Bool) : ((!g156 E)=true) ↔ 1≤countTrue (degree3_vals2 E) := by
  have rew : (!g156 E) = ((g4 E) || ((g10 E) && (g1 E))) := by simp [g1,g156,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree3_threshold1_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree3_vals1 E) := by simp [g1]
  exact threshold_step (g10 E) (g4 E) (g1 E) 0 (countTrue (degree3_vals1 E)) T1 T0
theorem degree3_threshold3_1 (E : Nat→Bool) : ((!g160 E)=true) ↔ 2≤countTrue (degree3_vals3 E) := by
  have rew : (!g160 E) = ((g157 E) || ((g15 E) && (!g156 E))) := by simp [g1,g159,g160,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree3_threshold2_1 E
  have T0 := degree3_threshold2_0 E
  exact threshold_step (g15 E) (g157 E) (!g156 E) 1 (countTrue (degree3_vals2 E)) T1 T0
theorem degree3_threshold4_2 (E : Nat→Bool) : ((!g166 E)=true) ↔ 3≤countTrue (degree3_vals4 E) := by
  have rew : (!g166 E) = ((g161 E) || ((g20 E) && (!g160 E))) := by simp [g1,g165,g166,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree3_threshold3_2 E
  have T0 := degree3_threshold3_1 E
  exact threshold_step (g20 E) (g161 E) (!g160 E) 2 (countTrue (degree3_vals3 E)) T1 T0
theorem degree3_threshold3_0 (E : Nat→Bool) : ((!g158 E)=true) ↔ 1≤countTrue (degree3_vals3 E) := by
  have rew : (!g158 E) = ((!g156 E) || ((g15 E) && (g1 E))) := by simp [g1,g158,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree3_threshold2_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree3_vals2 E) := by simp [g1]
  exact threshold_step (g15 E) (!g156 E) (g1 E) 0 (countTrue (degree3_vals2 E)) T1 T0
theorem degree3_threshold4_1 (E : Nat→Bool) : ((!g164 E)=true) ↔ 2≤countTrue (degree3_vals4 E) := by
  have rew : (!g164 E) = ((!g160 E) || ((g20 E) && (!g158 E))) := by simp [g1,g163,g164,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree3_threshold3_1 E
  have T0 := degree3_threshold3_0 E
  exact threshold_step (g20 E) (!g160 E) (!g158 E) 1 (countTrue (degree3_vals3 E)) T1 T0
theorem degree3_threshold5_2 (E : Nat→Bool) : ((!g172 E)=true) ↔ 3≤countTrue (degree3_vals5 E) := by
  have rew : (!g172 E) = ((!g166 E) || ((g21 E) && (!g164 E))) := by simp [g1,g171,g172,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree3_threshold4_2 E
  have T0 := degree3_threshold4_1 E
  exact threshold_step (g21 E) (!g166 E) (!g164 E) 2 (countTrue (degree3_vals4 E)) T1 T0
theorem degree3_threshold4_0 (E : Nat→Bool) : ((!g162 E)=true) ↔ 1≤countTrue (degree3_vals4 E) := by
  have rew : (!g162 E) = ((!g158 E) || ((g20 E) && (g1 E))) := by simp [g1,g162,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree3_threshold3_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree3_vals3 E) := by simp [g1]
  exact threshold_step (g20 E) (!g158 E) (g1 E) 0 (countTrue (degree3_vals3 E)) T1 T0
theorem degree3_threshold5_1 (E : Nat→Bool) : ((!g170 E)=true) ↔ 2≤countTrue (degree3_vals5 E) := by
  have rew : (!g170 E) = ((!g164 E) || ((g21 E) && (!g162 E))) := by simp [g1,g169,g170,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree3_threshold4_1 E
  have T0 := degree3_threshold4_0 E
  exact threshold_step (g21 E) (!g164 E) (!g162 E) 1 (countTrue (degree3_vals4 E)) T1 T0
theorem degree3_threshold6_2 (E : Nat→Bool) : ((!g180 E)=true) ↔ 3≤countTrue (degree3_vals6 E) := by
  have rew : (!g180 E) = ((!g172 E) || ((g22 E) && (!g170 E))) := by simp [g1,g179,g180,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree3_threshold5_2 E
  have T0 := degree3_threshold5_1 E
  exact threshold_step (g22 E) (!g172 E) (!g170 E) 2 (countTrue (degree3_vals5 E)) T1 T0
theorem degree3_threshold5_0 (E : Nat→Bool) : ((!g168 E)=true) ↔ 1≤countTrue (degree3_vals5 E) := by
  have rew : (!g168 E) = ((!g162 E) || ((g21 E) && (g1 E))) := by simp [g1,g168,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree3_threshold4_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree3_vals4 E) := by simp [g1]
  exact threshold_step (g21 E) (!g162 E) (g1 E) 0 (countTrue (degree3_vals4 E)) T1 T0
theorem degree3_threshold6_1 (E : Nat→Bool) : ((!g178 E)=true) ↔ 2≤countTrue (degree3_vals6 E) := by
  have rew : (!g178 E) = ((!g170 E) || ((g22 E) && (!g168 E))) := by simp [g1,g177,g178,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree3_threshold5_1 E
  have T0 := degree3_threshold5_0 E
  exact threshold_step (g22 E) (!g170 E) (!g168 E) 1 (countTrue (degree3_vals5 E)) T1 T0
theorem degree3_threshold7_2 (E : Nat→Bool) : ((!g190 E)=true) ↔ 3≤countTrue (degree3_vals7 E) := by
  have rew : (!g190 E) = ((!g180 E) || ((g23 E) && (!g178 E))) := by simp [g1,g189,g190,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree3_threshold6_2 E
  have T0 := degree3_threshold6_1 E
  exact threshold_step (g23 E) (!g180 E) (!g178 E) 2 (countTrue (degree3_vals6 E)) T1 T0
def degree3_count (E : Nat→Bool) : Nat := countTrue (degree3_vals7 E)
def degree4_vals1 (E : Nat→Bool) : List Bool := (g5 E) :: ([])
def degree4_vals2 (E : Nat→Bool) : List Bool := (g11 E) :: (degree4_vals1 E)
def degree4_vals3 (E : Nat→Bool) : List Bool := (g16 E) :: (degree4_vals2 E)
def degree4_vals4 (E : Nat→Bool) : List Bool := (g20 E) :: (degree4_vals3 E)
def degree4_vals5 (E : Nat→Bool) : List Bool := (g24 E) :: (degree4_vals4 E)
def degree4_vals6 (E : Nat→Bool) : List Bool := (g25 E) :: (degree4_vals5 E)
def degree4_vals7 (E : Nat→Bool) : List Bool := (g26 E) :: (degree4_vals6 E)
theorem degree4_threshold1_0 (E : Nat→Bool) : ((g5 E)=true) ↔ 1≤countTrue (degree4_vals1 E) := by
  have rew : (g5 E) = ((!g1 E) || ((g5 E) && (g1 E))) := by simp [g1,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 1≤countTrue ([] : List Bool) := by
    have hh := count_true_bound ([] : List Bool)
    change countTrue ([] : List Bool)≤0 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬1≤countTrue ([] : List Bool)
    omega
  have T0 : (g1 E)=true ↔ 0≤countTrue ([] : List Bool) := by simp [g1]
  exact threshold_step (g5 E) (!g1 E) (g1 E) 0 (countTrue ([] : List Bool)) T1 T0
theorem degree4_threshold2_1 (E : Nat→Bool) : ((g199 E)=true) ↔ 2≤countTrue (degree4_vals2 E) := by
  have rew : (g199 E) = ((!g1 E) || ((g11 E) && (g5 E))) := by simp [g1,g199,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 2≤countTrue (degree4_vals1 E) := by
    have hh := count_true_bound (degree4_vals1 E)
    change countTrue (degree4_vals1 E)≤1 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬2≤countTrue (degree4_vals1 E)
    omega
  have T0 := degree4_threshold1_0 E
  exact threshold_step (g11 E) (!g1 E) (g5 E) 1 (countTrue (degree4_vals1 E)) T1 T0
theorem degree4_threshold3_2 (E : Nat→Bool) : ((g203 E)=true) ↔ 3≤countTrue (degree4_vals3 E) := by
  have rew : (g203 E) = ((!g1 E) || ((g16 E) && (g199 E))) := by simp [g1,g203,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 3≤countTrue (degree4_vals2 E) := by
    have hh := count_true_bound (degree4_vals2 E)
    change countTrue (degree4_vals2 E)≤2 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬3≤countTrue (degree4_vals2 E)
    omega
  have T0 := degree4_threshold2_1 E
  exact threshold_step (g16 E) (!g1 E) (g199 E) 2 (countTrue (degree4_vals2 E)) T1 T0
theorem degree4_threshold2_0 (E : Nat→Bool) : ((!g198 E)=true) ↔ 1≤countTrue (degree4_vals2 E) := by
  have rew : (!g198 E) = ((g5 E) || ((g11 E) && (g1 E))) := by simp [g1,g198,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree4_threshold1_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree4_vals1 E) := by simp [g1]
  exact threshold_step (g11 E) (g5 E) (g1 E) 0 (countTrue (degree4_vals1 E)) T1 T0
theorem degree4_threshold3_1 (E : Nat→Bool) : ((!g202 E)=true) ↔ 2≤countTrue (degree4_vals3 E) := by
  have rew : (!g202 E) = ((g199 E) || ((g16 E) && (!g198 E))) := by simp [g1,g201,g202,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree4_threshold2_1 E
  have T0 := degree4_threshold2_0 E
  exact threshold_step (g16 E) (g199 E) (!g198 E) 1 (countTrue (degree4_vals2 E)) T1 T0
theorem degree4_threshold4_2 (E : Nat→Bool) : ((!g208 E)=true) ↔ 3≤countTrue (degree4_vals4 E) := by
  have rew : (!g208 E) = ((g203 E) || ((g20 E) && (!g202 E))) := by simp [g1,g207,g208,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree4_threshold3_2 E
  have T0 := degree4_threshold3_1 E
  exact threshold_step (g20 E) (g203 E) (!g202 E) 2 (countTrue (degree4_vals3 E)) T1 T0
theorem degree4_threshold3_0 (E : Nat→Bool) : ((!g200 E)=true) ↔ 1≤countTrue (degree4_vals3 E) := by
  have rew : (!g200 E) = ((!g198 E) || ((g16 E) && (g1 E))) := by simp [g1,g200,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree4_threshold2_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree4_vals2 E) := by simp [g1]
  exact threshold_step (g16 E) (!g198 E) (g1 E) 0 (countTrue (degree4_vals2 E)) T1 T0
theorem degree4_threshold4_1 (E : Nat→Bool) : ((!g206 E)=true) ↔ 2≤countTrue (degree4_vals4 E) := by
  have rew : (!g206 E) = ((!g202 E) || ((g20 E) && (!g200 E))) := by simp [g1,g205,g206,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree4_threshold3_1 E
  have T0 := degree4_threshold3_0 E
  exact threshold_step (g20 E) (!g202 E) (!g200 E) 1 (countTrue (degree4_vals3 E)) T1 T0
theorem degree4_threshold5_2 (E : Nat→Bool) : ((!g214 E)=true) ↔ 3≤countTrue (degree4_vals5 E) := by
  have rew : (!g214 E) = ((!g208 E) || ((g24 E) && (!g206 E))) := by simp [g1,g213,g214,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree4_threshold4_2 E
  have T0 := degree4_threshold4_1 E
  exact threshold_step (g24 E) (!g208 E) (!g206 E) 2 (countTrue (degree4_vals4 E)) T1 T0
theorem degree4_threshold4_0 (E : Nat→Bool) : ((!g204 E)=true) ↔ 1≤countTrue (degree4_vals4 E) := by
  have rew : (!g204 E) = ((!g200 E) || ((g20 E) && (g1 E))) := by simp [g1,g204,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree4_threshold3_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree4_vals3 E) := by simp [g1]
  exact threshold_step (g20 E) (!g200 E) (g1 E) 0 (countTrue (degree4_vals3 E)) T1 T0
theorem degree4_threshold5_1 (E : Nat→Bool) : ((!g212 E)=true) ↔ 2≤countTrue (degree4_vals5 E) := by
  have rew : (!g212 E) = ((!g206 E) || ((g24 E) && (!g204 E))) := by simp [g1,g211,g212,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree4_threshold4_1 E
  have T0 := degree4_threshold4_0 E
  exact threshold_step (g24 E) (!g206 E) (!g204 E) 1 (countTrue (degree4_vals4 E)) T1 T0
theorem degree4_threshold6_2 (E : Nat→Bool) : ((!g222 E)=true) ↔ 3≤countTrue (degree4_vals6 E) := by
  have rew : (!g222 E) = ((!g214 E) || ((g25 E) && (!g212 E))) := by simp [g1,g221,g222,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree4_threshold5_2 E
  have T0 := degree4_threshold5_1 E
  exact threshold_step (g25 E) (!g214 E) (!g212 E) 2 (countTrue (degree4_vals5 E)) T1 T0
theorem degree4_threshold5_0 (E : Nat→Bool) : ((!g210 E)=true) ↔ 1≤countTrue (degree4_vals5 E) := by
  have rew : (!g210 E) = ((!g204 E) || ((g24 E) && (g1 E))) := by simp [g1,g210,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree4_threshold4_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree4_vals4 E) := by simp [g1]
  exact threshold_step (g24 E) (!g204 E) (g1 E) 0 (countTrue (degree4_vals4 E)) T1 T0
theorem degree4_threshold6_1 (E : Nat→Bool) : ((!g220 E)=true) ↔ 2≤countTrue (degree4_vals6 E) := by
  have rew : (!g220 E) = ((!g212 E) || ((g25 E) && (!g210 E))) := by simp [g1,g219,g220,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree4_threshold5_1 E
  have T0 := degree4_threshold5_0 E
  exact threshold_step (g25 E) (!g212 E) (!g210 E) 1 (countTrue (degree4_vals5 E)) T1 T0
theorem degree4_threshold7_2 (E : Nat→Bool) : ((!g232 E)=true) ↔ 3≤countTrue (degree4_vals7 E) := by
  have rew : (!g232 E) = ((!g222 E) || ((g26 E) && (!g220 E))) := by simp [g1,g231,g232,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree4_threshold6_2 E
  have T0 := degree4_threshold6_1 E
  exact threshold_step (g26 E) (!g222 E) (!g220 E) 2 (countTrue (degree4_vals6 E)) T1 T0
def degree4_count (E : Nat→Bool) : Nat := countTrue (degree4_vals7 E)
def degree5_vals1 (E : Nat→Bool) : List Bool := (g6 E) :: ([])
def degree5_vals2 (E : Nat→Bool) : List Bool := (g12 E) :: (degree5_vals1 E)
def degree5_vals3 (E : Nat→Bool) : List Bool := (g17 E) :: (degree5_vals2 E)
def degree5_vals4 (E : Nat→Bool) : List Bool := (g21 E) :: (degree5_vals3 E)
def degree5_vals5 (E : Nat→Bool) : List Bool := (g24 E) :: (degree5_vals4 E)
def degree5_vals6 (E : Nat→Bool) : List Bool := (g27 E) :: (degree5_vals5 E)
def degree5_vals7 (E : Nat→Bool) : List Bool := (g28 E) :: (degree5_vals6 E)
theorem degree5_threshold1_0 (E : Nat→Bool) : ((g6 E)=true) ↔ 1≤countTrue (degree5_vals1 E) := by
  have rew : (g6 E) = ((!g1 E) || ((g6 E) && (g1 E))) := by simp [g1,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 1≤countTrue ([] : List Bool) := by
    have hh := count_true_bound ([] : List Bool)
    change countTrue ([] : List Bool)≤0 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬1≤countTrue ([] : List Bool)
    omega
  have T0 : (g1 E)=true ↔ 0≤countTrue ([] : List Bool) := by simp [g1]
  exact threshold_step (g6 E) (!g1 E) (g1 E) 0 (countTrue ([] : List Bool)) T1 T0
theorem degree5_threshold2_1 (E : Nat→Bool) : ((g241 E)=true) ↔ 2≤countTrue (degree5_vals2 E) := by
  have rew : (g241 E) = ((!g1 E) || ((g12 E) && (g6 E))) := by simp [g1,g241,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 2≤countTrue (degree5_vals1 E) := by
    have hh := count_true_bound (degree5_vals1 E)
    change countTrue (degree5_vals1 E)≤1 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬2≤countTrue (degree5_vals1 E)
    omega
  have T0 := degree5_threshold1_0 E
  exact threshold_step (g12 E) (!g1 E) (g6 E) 1 (countTrue (degree5_vals1 E)) T1 T0
theorem degree5_threshold3_2 (E : Nat→Bool) : ((g245 E)=true) ↔ 3≤countTrue (degree5_vals3 E) := by
  have rew : (g245 E) = ((!g1 E) || ((g17 E) && (g241 E))) := by simp [g1,g245,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 3≤countTrue (degree5_vals2 E) := by
    have hh := count_true_bound (degree5_vals2 E)
    change countTrue (degree5_vals2 E)≤2 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬3≤countTrue (degree5_vals2 E)
    omega
  have T0 := degree5_threshold2_1 E
  exact threshold_step (g17 E) (!g1 E) (g241 E) 2 (countTrue (degree5_vals2 E)) T1 T0
theorem degree5_threshold2_0 (E : Nat→Bool) : ((!g240 E)=true) ↔ 1≤countTrue (degree5_vals2 E) := by
  have rew : (!g240 E) = ((g6 E) || ((g12 E) && (g1 E))) := by simp [g1,g240,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree5_threshold1_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree5_vals1 E) := by simp [g1]
  exact threshold_step (g12 E) (g6 E) (g1 E) 0 (countTrue (degree5_vals1 E)) T1 T0
theorem degree5_threshold3_1 (E : Nat→Bool) : ((!g244 E)=true) ↔ 2≤countTrue (degree5_vals3 E) := by
  have rew : (!g244 E) = ((g241 E) || ((g17 E) && (!g240 E))) := by simp [g1,g243,g244,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree5_threshold2_1 E
  have T0 := degree5_threshold2_0 E
  exact threshold_step (g17 E) (g241 E) (!g240 E) 1 (countTrue (degree5_vals2 E)) T1 T0
theorem degree5_threshold4_2 (E : Nat→Bool) : ((!g250 E)=true) ↔ 3≤countTrue (degree5_vals4 E) := by
  have rew : (!g250 E) = ((g245 E) || ((g21 E) && (!g244 E))) := by simp [g1,g249,g250,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree5_threshold3_2 E
  have T0 := degree5_threshold3_1 E
  exact threshold_step (g21 E) (g245 E) (!g244 E) 2 (countTrue (degree5_vals3 E)) T1 T0
theorem degree5_threshold3_0 (E : Nat→Bool) : ((!g242 E)=true) ↔ 1≤countTrue (degree5_vals3 E) := by
  have rew : (!g242 E) = ((!g240 E) || ((g17 E) && (g1 E))) := by simp [g1,g242,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree5_threshold2_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree5_vals2 E) := by simp [g1]
  exact threshold_step (g17 E) (!g240 E) (g1 E) 0 (countTrue (degree5_vals2 E)) T1 T0
theorem degree5_threshold4_1 (E : Nat→Bool) : ((!g248 E)=true) ↔ 2≤countTrue (degree5_vals4 E) := by
  have rew : (!g248 E) = ((!g244 E) || ((g21 E) && (!g242 E))) := by simp [g1,g247,g248,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree5_threshold3_1 E
  have T0 := degree5_threshold3_0 E
  exact threshold_step (g21 E) (!g244 E) (!g242 E) 1 (countTrue (degree5_vals3 E)) T1 T0
theorem degree5_threshold5_2 (E : Nat→Bool) : ((!g256 E)=true) ↔ 3≤countTrue (degree5_vals5 E) := by
  have rew : (!g256 E) = ((!g250 E) || ((g24 E) && (!g248 E))) := by simp [g1,g255,g256,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree5_threshold4_2 E
  have T0 := degree5_threshold4_1 E
  exact threshold_step (g24 E) (!g250 E) (!g248 E) 2 (countTrue (degree5_vals4 E)) T1 T0
theorem degree5_threshold4_0 (E : Nat→Bool) : ((!g246 E)=true) ↔ 1≤countTrue (degree5_vals4 E) := by
  have rew : (!g246 E) = ((!g242 E) || ((g21 E) && (g1 E))) := by simp [g1,g246,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree5_threshold3_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree5_vals3 E) := by simp [g1]
  exact threshold_step (g21 E) (!g242 E) (g1 E) 0 (countTrue (degree5_vals3 E)) T1 T0
theorem degree5_threshold5_1 (E : Nat→Bool) : ((!g254 E)=true) ↔ 2≤countTrue (degree5_vals5 E) := by
  have rew : (!g254 E) = ((!g248 E) || ((g24 E) && (!g246 E))) := by simp [g1,g253,g254,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree5_threshold4_1 E
  have T0 := degree5_threshold4_0 E
  exact threshold_step (g24 E) (!g248 E) (!g246 E) 1 (countTrue (degree5_vals4 E)) T1 T0
theorem degree5_threshold6_2 (E : Nat→Bool) : ((!g264 E)=true) ↔ 3≤countTrue (degree5_vals6 E) := by
  have rew : (!g264 E) = ((!g256 E) || ((g27 E) && (!g254 E))) := by simp [g1,g263,g264,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree5_threshold5_2 E
  have T0 := degree5_threshold5_1 E
  exact threshold_step (g27 E) (!g256 E) (!g254 E) 2 (countTrue (degree5_vals5 E)) T1 T0
theorem degree5_threshold5_0 (E : Nat→Bool) : ((!g252 E)=true) ↔ 1≤countTrue (degree5_vals5 E) := by
  have rew : (!g252 E) = ((!g246 E) || ((g24 E) && (g1 E))) := by simp [g1,g252,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree5_threshold4_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (degree5_vals4 E) := by simp [g1]
  exact threshold_step (g24 E) (!g246 E) (g1 E) 0 (countTrue (degree5_vals4 E)) T1 T0
theorem degree5_threshold6_1 (E : Nat→Bool) : ((!g262 E)=true) ↔ 2≤countTrue (degree5_vals6 E) := by
  have rew : (!g262 E) = ((!g254 E) || ((g27 E) && (!g252 E))) := by simp [g1,g261,g262,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree5_threshold5_1 E
  have T0 := degree5_threshold5_0 E
  exact threshold_step (g27 E) (!g254 E) (!g252 E) 1 (countTrue (degree5_vals5 E)) T1 T0
theorem degree5_threshold7_2 (E : Nat→Bool) : ((!g274 E)=true) ↔ 3≤countTrue (degree5_vals7 E) := by
  have rew : (!g274 E) = ((!g264 E) || ((g28 E) && (!g262 E))) := by simp [g1,g273,g274,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := degree5_threshold6_2 E
  have T0 := degree5_threshold6_1 E
  exact threshold_step (g28 E) (!g264 E) (!g262 E) 2 (countTrue (degree5_vals6 E)) T1 T0
def degree5_count (E : Nat→Bool) : Nat := countTrue (degree5_vals7 E)
def score0_vals1 (E : Nat→Bool) : List Bool := (g366 E) :: ([])
def score0_vals2 (E : Nat→Bool) : List Bool := (g367 E) :: (score0_vals1 E)
def score0_vals3 (E : Nat→Bool) : List Bool := (g368 E) :: (score0_vals2 E)
def score0_vals4 (E : Nat→Bool) : List Bool := (g369 E) :: (score0_vals3 E)
def score0_vals5 (E : Nat→Bool) : List Bool := (g370 E) :: (score0_vals4 E)
def score0_vals6 (E : Nat→Bool) : List Bool := (g371 E) :: (score0_vals5 E)
def score0_vals7 (E : Nat→Bool) : List Bool := (g372 E) :: (score0_vals6 E)
def score0_vals8 (E : Nat→Bool) : List Bool := (g373 E) :: (score0_vals7 E)
def score0_vals9 (E : Nat→Bool) : List Bool := (g374 E) :: (score0_vals8 E)
def score0_vals10 (E : Nat→Bool) : List Bool := (g375 E) :: (score0_vals9 E)
def score0_vals11 (E : Nat→Bool) : List Bool := (g376 E) :: (score0_vals10 E)
def score0_vals12 (E : Nat→Bool) : List Bool := (g377 E) :: (score0_vals11 E)
def score0_vals13 (E : Nat→Bool) : List Bool := (g378 E) :: (score0_vals12 E)
def score0_vals14 (E : Nat→Bool) : List Bool := (g379 E) :: (score0_vals13 E)
def score0_vals15 (E : Nat→Bool) : List Bool := (g380 E) :: (score0_vals14 E)
def score0_vals16 (E : Nat→Bool) : List Bool := (g381 E) :: (score0_vals15 E)
def score0_vals17 (E : Nat→Bool) : List Bool := (g382 E) :: (score0_vals16 E)
def score0_vals18 (E : Nat→Bool) : List Bool := (g383 E) :: (score0_vals17 E)
def score0_vals19 (E : Nat→Bool) : List Bool := (g384 E) :: (score0_vals18 E)
def score0_vals20 (E : Nat→Bool) : List Bool := (g385 E) :: (score0_vals19 E)
def score0_vals21 (E : Nat→Bool) : List Bool := (g386 E) :: (score0_vals20 E)
theorem score0_threshold1_0 (E : Nat→Bool) : ((g366 E)=true) ↔ 1≤countTrue (score0_vals1 E) := by
  have rew : (g366 E) = ((!g1 E) || ((g366 E) && (g1 E))) := by simp [g1,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 1≤countTrue ([] : List Bool) := by
    have hh := count_true_bound ([] : List Bool)
    change countTrue ([] : List Bool)≤0 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬1≤countTrue ([] : List Bool)
    omega
  have T0 : (g1 E)=true ↔ 0≤countTrue ([] : List Bool) := by simp [g1]
  exact threshold_step (g366 E) (!g1 E) (g1 E) 0 (countTrue ([] : List Bool)) T1 T0
theorem score0_threshold2_1 (E : Nat→Bool) : ((g423 E)=true) ↔ 2≤countTrue (score0_vals2 E) := by
  have rew : (g423 E) = ((!g1 E) || ((g367 E) && (g366 E))) := by simp [g1,g423,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 2≤countTrue (score0_vals1 E) := by
    have hh := count_true_bound (score0_vals1 E)
    change countTrue (score0_vals1 E)≤1 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬2≤countTrue (score0_vals1 E)
    omega
  have T0 := score0_threshold1_0 E
  exact threshold_step (g367 E) (!g1 E) (g366 E) 1 (countTrue (score0_vals1 E)) T1 T0
theorem score0_threshold2_0 (E : Nat→Bool) : ((!g422 E)=true) ↔ 1≤countTrue (score0_vals2 E) := by
  have rew : (!g422 E) = ((g366 E) || ((g367 E) && (g1 E))) := by simp [g1,g422,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold1_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals1 E) := by simp [g1]
  exact threshold_step (g367 E) (g366 E) (g1 E) 0 (countTrue (score0_vals1 E)) T1 T0
theorem score0_threshold3_1 (E : Nat→Bool) : ((!g426 E)=true) ↔ 2≤countTrue (score0_vals3 E) := by
  have rew : (!g426 E) = ((g423 E) || ((g368 E) && (!g422 E))) := by simp [g1,g425,g426,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold2_1 E
  have T0 := score0_threshold2_0 E
  exact threshold_step (g368 E) (g423 E) (!g422 E) 1 (countTrue (score0_vals2 E)) T1 T0
theorem score0_threshold3_0 (E : Nat→Bool) : ((!g424 E)=true) ↔ 1≤countTrue (score0_vals3 E) := by
  have rew : (!g424 E) = ((!g422 E) || ((g368 E) && (g1 E))) := by simp [g1,g424,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold2_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals2 E) := by simp [g1]
  exact threshold_step (g368 E) (!g422 E) (g1 E) 0 (countTrue (score0_vals2 E)) T1 T0
theorem score0_threshold4_1 (E : Nat→Bool) : ((!g430 E)=true) ↔ 2≤countTrue (score0_vals4 E) := by
  have rew : (!g430 E) = ((!g426 E) || ((g369 E) && (!g424 E))) := by simp [g1,g429,g430,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold3_1 E
  have T0 := score0_threshold3_0 E
  exact threshold_step (g369 E) (!g426 E) (!g424 E) 1 (countTrue (score0_vals3 E)) T1 T0
theorem score0_threshold4_0 (E : Nat→Bool) : ((!g428 E)=true) ↔ 1≤countTrue (score0_vals4 E) := by
  have rew : (!g428 E) = ((!g424 E) || ((g369 E) && (g1 E))) := by simp [g1,g428,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold3_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals3 E) := by simp [g1]
  exact threshold_step (g369 E) (!g424 E) (g1 E) 0 (countTrue (score0_vals3 E)) T1 T0
theorem score0_threshold5_1 (E : Nat→Bool) : ((!g436 E)=true) ↔ 2≤countTrue (score0_vals5 E) := by
  have rew : (!g436 E) = ((!g430 E) || ((g370 E) && (!g428 E))) := by simp [g1,g435,g436,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold4_1 E
  have T0 := score0_threshold4_0 E
  exact threshold_step (g370 E) (!g430 E) (!g428 E) 1 (countTrue (score0_vals4 E)) T1 T0
theorem score0_threshold5_0 (E : Nat→Bool) : ((!g434 E)=true) ↔ 1≤countTrue (score0_vals5 E) := by
  have rew : (!g434 E) = ((!g428 E) || ((g370 E) && (g1 E))) := by simp [g1,g434,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold4_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals4 E) := by simp [g1]
  exact threshold_step (g370 E) (!g428 E) (g1 E) 0 (countTrue (score0_vals4 E)) T1 T0
theorem score0_threshold6_1 (E : Nat→Bool) : ((!g444 E)=true) ↔ 2≤countTrue (score0_vals6 E) := by
  have rew : (!g444 E) = ((!g436 E) || ((g371 E) && (!g434 E))) := by simp [g1,g443,g444,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold5_1 E
  have T0 := score0_threshold5_0 E
  exact threshold_step (g371 E) (!g436 E) (!g434 E) 1 (countTrue (score0_vals5 E)) T1 T0
theorem score0_threshold6_0 (E : Nat→Bool) : ((!g442 E)=true) ↔ 1≤countTrue (score0_vals6 E) := by
  have rew : (!g442 E) = ((!g434 E) || ((g371 E) && (g1 E))) := by simp [g1,g442,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold5_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals5 E) := by simp [g1]
  exact threshold_step (g371 E) (!g434 E) (g1 E) 0 (countTrue (score0_vals5 E)) T1 T0
theorem score0_threshold7_1 (E : Nat→Bool) : ((!g454 E)=true) ↔ 2≤countTrue (score0_vals7 E) := by
  have rew : (!g454 E) = ((!g444 E) || ((g372 E) && (!g442 E))) := by simp [g1,g453,g454,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold6_1 E
  have T0 := score0_threshold6_0 E
  exact threshold_step (g372 E) (!g444 E) (!g442 E) 1 (countTrue (score0_vals6 E)) T1 T0
theorem score0_threshold7_0 (E : Nat→Bool) : ((!g452 E)=true) ↔ 1≤countTrue (score0_vals7 E) := by
  have rew : (!g452 E) = ((!g442 E) || ((g372 E) && (g1 E))) := by simp [g1,g452,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold6_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals6 E) := by simp [g1]
  exact threshold_step (g372 E) (!g442 E) (g1 E) 0 (countTrue (score0_vals6 E)) T1 T0
theorem score0_threshold8_1 (E : Nat→Bool) : ((!g466 E)=true) ↔ 2≤countTrue (score0_vals8 E) := by
  have rew : (!g466 E) = ((!g454 E) || ((g373 E) && (!g452 E))) := by simp [g1,g465,g466,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold7_1 E
  have T0 := score0_threshold7_0 E
  exact threshold_step (g373 E) (!g454 E) (!g452 E) 1 (countTrue (score0_vals7 E)) T1 T0
theorem score0_threshold8_0 (E : Nat→Bool) : ((!g464 E)=true) ↔ 1≤countTrue (score0_vals8 E) := by
  have rew : (!g464 E) = ((!g452 E) || ((g373 E) && (g1 E))) := by simp [g1,g464,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold7_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals7 E) := by simp [g1]
  exact threshold_step (g373 E) (!g452 E) (g1 E) 0 (countTrue (score0_vals7 E)) T1 T0
theorem score0_threshold9_1 (E : Nat→Bool) : ((!g480 E)=true) ↔ 2≤countTrue (score0_vals9 E) := by
  have rew : (!g480 E) = ((!g466 E) || ((g374 E) && (!g464 E))) := by simp [g1,g479,g480,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold8_1 E
  have T0 := score0_threshold8_0 E
  exact threshold_step (g374 E) (!g466 E) (!g464 E) 1 (countTrue (score0_vals8 E)) T1 T0
theorem score0_threshold9_0 (E : Nat→Bool) : ((!g478 E)=true) ↔ 1≤countTrue (score0_vals9 E) := by
  have rew : (!g478 E) = ((!g464 E) || ((g374 E) && (g1 E))) := by simp [g1,g478,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold8_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals8 E) := by simp [g1]
  exact threshold_step (g374 E) (!g464 E) (g1 E) 0 (countTrue (score0_vals8 E)) T1 T0
theorem score0_threshold10_1 (E : Nat→Bool) : ((!g496 E)=true) ↔ 2≤countTrue (score0_vals10 E) := by
  have rew : (!g496 E) = ((!g480 E) || ((g375 E) && (!g478 E))) := by simp [g1,g495,g496,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold9_1 E
  have T0 := score0_threshold9_0 E
  exact threshold_step (g375 E) (!g480 E) (!g478 E) 1 (countTrue (score0_vals9 E)) T1 T0
theorem score0_threshold10_0 (E : Nat→Bool) : ((!g494 E)=true) ↔ 1≤countTrue (score0_vals10 E) := by
  have rew : (!g494 E) = ((!g478 E) || ((g375 E) && (g1 E))) := by simp [g1,g494,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold9_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals9 E) := by simp [g1]
  exact threshold_step (g375 E) (!g478 E) (g1 E) 0 (countTrue (score0_vals9 E)) T1 T0
theorem score0_threshold11_1 (E : Nat→Bool) : ((!g514 E)=true) ↔ 2≤countTrue (score0_vals11 E) := by
  have rew : (!g514 E) = ((!g496 E) || ((g376 E) && (!g494 E))) := by simp [g1,g513,g514,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold10_1 E
  have T0 := score0_threshold10_0 E
  exact threshold_step (g376 E) (!g496 E) (!g494 E) 1 (countTrue (score0_vals10 E)) T1 T0
theorem score0_threshold11_0 (E : Nat→Bool) : ((!g512 E)=true) ↔ 1≤countTrue (score0_vals11 E) := by
  have rew : (!g512 E) = ((!g494 E) || ((g376 E) && (g1 E))) := by simp [g1,g512,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold10_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals10 E) := by simp [g1]
  exact threshold_step (g376 E) (!g494 E) (g1 E) 0 (countTrue (score0_vals10 E)) T1 T0
theorem score0_threshold12_1 (E : Nat→Bool) : ((!g534 E)=true) ↔ 2≤countTrue (score0_vals12 E) := by
  have rew : (!g534 E) = ((!g514 E) || ((g377 E) && (!g512 E))) := by simp [g1,g533,g534,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold11_1 E
  have T0 := score0_threshold11_0 E
  exact threshold_step (g377 E) (!g514 E) (!g512 E) 1 (countTrue (score0_vals11 E)) T1 T0
theorem score0_threshold12_0 (E : Nat→Bool) : ((!g532 E)=true) ↔ 1≤countTrue (score0_vals12 E) := by
  have rew : (!g532 E) = ((!g512 E) || ((g377 E) && (g1 E))) := by simp [g1,g532,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold11_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals11 E) := by simp [g1]
  exact threshold_step (g377 E) (!g512 E) (g1 E) 0 (countTrue (score0_vals11 E)) T1 T0
theorem score0_threshold13_1 (E : Nat→Bool) : ((!g556 E)=true) ↔ 2≤countTrue (score0_vals13 E) := by
  have rew : (!g556 E) = ((!g534 E) || ((g378 E) && (!g532 E))) := by simp [g1,g555,g556,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold12_1 E
  have T0 := score0_threshold12_0 E
  exact threshold_step (g378 E) (!g534 E) (!g532 E) 1 (countTrue (score0_vals12 E)) T1 T0
theorem score0_threshold13_0 (E : Nat→Bool) : ((!g554 E)=true) ↔ 1≤countTrue (score0_vals13 E) := by
  have rew : (!g554 E) = ((!g532 E) || ((g378 E) && (g1 E))) := by simp [g1,g554,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold12_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals12 E) := by simp [g1]
  exact threshold_step (g378 E) (!g532 E) (g1 E) 0 (countTrue (score0_vals12 E)) T1 T0
theorem score0_threshold14_1 (E : Nat→Bool) : ((!g580 E)=true) ↔ 2≤countTrue (score0_vals14 E) := by
  have rew : (!g580 E) = ((!g556 E) || ((g379 E) && (!g554 E))) := by simp [g1,g579,g580,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold13_1 E
  have T0 := score0_threshold13_0 E
  exact threshold_step (g379 E) (!g556 E) (!g554 E) 1 (countTrue (score0_vals13 E)) T1 T0
theorem score0_threshold14_0 (E : Nat→Bool) : ((!g578 E)=true) ↔ 1≤countTrue (score0_vals14 E) := by
  have rew : (!g578 E) = ((!g554 E) || ((g379 E) && (g1 E))) := by simp [g1,g578,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold13_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals13 E) := by simp [g1]
  exact threshold_step (g379 E) (!g554 E) (g1 E) 0 (countTrue (score0_vals13 E)) T1 T0
theorem score0_threshold15_1 (E : Nat→Bool) : ((!g606 E)=true) ↔ 2≤countTrue (score0_vals15 E) := by
  have rew : (!g606 E) = ((!g580 E) || ((g380 E) && (!g578 E))) := by simp [g1,g605,g606,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold14_1 E
  have T0 := score0_threshold14_0 E
  exact threshold_step (g380 E) (!g580 E) (!g578 E) 1 (countTrue (score0_vals14 E)) T1 T0
theorem score0_threshold15_0 (E : Nat→Bool) : ((!g604 E)=true) ↔ 1≤countTrue (score0_vals15 E) := by
  have rew : (!g604 E) = ((!g578 E) || ((g380 E) && (g1 E))) := by simp [g1,g604,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold14_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals14 E) := by simp [g1]
  exact threshold_step (g380 E) (!g578 E) (g1 E) 0 (countTrue (score0_vals14 E)) T1 T0
theorem score0_threshold16_1 (E : Nat→Bool) : ((!g634 E)=true) ↔ 2≤countTrue (score0_vals16 E) := by
  have rew : (!g634 E) = ((!g606 E) || ((g381 E) && (!g604 E))) := by simp [g1,g633,g634,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold15_1 E
  have T0 := score0_threshold15_0 E
  exact threshold_step (g381 E) (!g606 E) (!g604 E) 1 (countTrue (score0_vals15 E)) T1 T0
theorem score0_threshold16_0 (E : Nat→Bool) : ((!g632 E)=true) ↔ 1≤countTrue (score0_vals16 E) := by
  have rew : (!g632 E) = ((!g604 E) || ((g381 E) && (g1 E))) := by simp [g1,g632,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold15_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals15 E) := by simp [g1]
  exact threshold_step (g381 E) (!g604 E) (g1 E) 0 (countTrue (score0_vals15 E)) T1 T0
theorem score0_threshold17_1 (E : Nat→Bool) : ((!g664 E)=true) ↔ 2≤countTrue (score0_vals17 E) := by
  have rew : (!g664 E) = ((!g634 E) || ((g382 E) && (!g632 E))) := by simp [g1,g663,g664,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold16_1 E
  have T0 := score0_threshold16_0 E
  exact threshold_step (g382 E) (!g634 E) (!g632 E) 1 (countTrue (score0_vals16 E)) T1 T0
theorem score0_threshold17_0 (E : Nat→Bool) : ((!g662 E)=true) ↔ 1≤countTrue (score0_vals17 E) := by
  have rew : (!g662 E) = ((!g632 E) || ((g382 E) && (g1 E))) := by simp [g1,g662,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold16_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals16 E) := by simp [g1]
  exact threshold_step (g382 E) (!g632 E) (g1 E) 0 (countTrue (score0_vals16 E)) T1 T0
theorem score0_threshold18_1 (E : Nat→Bool) : ((!g696 E)=true) ↔ 2≤countTrue (score0_vals18 E) := by
  have rew : (!g696 E) = ((!g664 E) || ((g383 E) && (!g662 E))) := by simp [g1,g695,g696,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold17_1 E
  have T0 := score0_threshold17_0 E
  exact threshold_step (g383 E) (!g664 E) (!g662 E) 1 (countTrue (score0_vals17 E)) T1 T0
theorem score0_threshold18_0 (E : Nat→Bool) : ((!g694 E)=true) ↔ 1≤countTrue (score0_vals18 E) := by
  have rew : (!g694 E) = ((!g662 E) || ((g383 E) && (g1 E))) := by simp [g1,g694,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold17_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals17 E) := by simp [g1]
  exact threshold_step (g383 E) (!g662 E) (g1 E) 0 (countTrue (score0_vals17 E)) T1 T0
theorem score0_threshold19_1 (E : Nat→Bool) : ((!g730 E)=true) ↔ 2≤countTrue (score0_vals19 E) := by
  have rew : (!g730 E) = ((!g696 E) || ((g384 E) && (!g694 E))) := by simp [g1,g729,g730,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold18_1 E
  have T0 := score0_threshold18_0 E
  exact threshold_step (g384 E) (!g696 E) (!g694 E) 1 (countTrue (score0_vals18 E)) T1 T0
theorem score0_threshold19_0 (E : Nat→Bool) : ((!g728 E)=true) ↔ 1≤countTrue (score0_vals19 E) := by
  have rew : (!g728 E) = ((!g694 E) || ((g384 E) && (g1 E))) := by simp [g1,g728,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold18_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals18 E) := by simp [g1]
  exact threshold_step (g384 E) (!g694 E) (g1 E) 0 (countTrue (score0_vals18 E)) T1 T0
theorem score0_threshold20_1 (E : Nat→Bool) : ((!g766 E)=true) ↔ 2≤countTrue (score0_vals20 E) := by
  have rew : (!g766 E) = ((!g730 E) || ((g385 E) && (!g728 E))) := by simp [g1,g765,g766,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold19_1 E
  have T0 := score0_threshold19_0 E
  exact threshold_step (g385 E) (!g730 E) (!g728 E) 1 (countTrue (score0_vals19 E)) T1 T0
theorem score0_threshold20_0 (E : Nat→Bool) : ((!g764 E)=true) ↔ 1≤countTrue (score0_vals20 E) := by
  have rew : (!g764 E) = ((!g728 E) || ((g385 E) && (g1 E))) := by simp [g1,g764,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold19_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score0_vals19 E) := by simp [g1]
  exact threshold_step (g385 E) (!g728 E) (g1 E) 0 (countTrue (score0_vals19 E)) T1 T0
theorem score0_threshold21_1 (E : Nat→Bool) : ((!g804 E)=true) ↔ 2≤countTrue (score0_vals21 E) := by
  have rew : (!g804 E) = ((!g766 E) || ((g386 E) && (!g764 E))) := by simp [g1,g803,g804,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold20_1 E
  have T0 := score0_threshold20_0 E
  exact threshold_step (g386 E) (!g766 E) (!g764 E) 1 (countTrue (score0_vals20 E)) T1 T0
theorem score0_threshold3_2 (E : Nat→Bool) : ((g427 E)=true) ↔ 3≤countTrue (score0_vals3 E) := by
  have rew : (g427 E) = ((!g1 E) || ((g368 E) && (g423 E))) := by simp [g1,g427,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 3≤countTrue (score0_vals2 E) := by
    have hh := count_true_bound (score0_vals2 E)
    change countTrue (score0_vals2 E)≤2 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬3≤countTrue (score0_vals2 E)
    omega
  have T0 := score0_threshold2_1 E
  exact threshold_step (g368 E) (!g1 E) (g423 E) 2 (countTrue (score0_vals2 E)) T1 T0
theorem score0_threshold4_2 (E : Nat→Bool) : ((!g432 E)=true) ↔ 3≤countTrue (score0_vals4 E) := by
  have rew : (!g432 E) = ((g427 E) || ((g369 E) && (!g426 E))) := by simp [g1,g431,g432,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold3_2 E
  have T0 := score0_threshold3_1 E
  exact threshold_step (g369 E) (g427 E) (!g426 E) 2 (countTrue (score0_vals3 E)) T1 T0
theorem score0_threshold5_2 (E : Nat→Bool) : ((!g438 E)=true) ↔ 3≤countTrue (score0_vals5 E) := by
  have rew : (!g438 E) = ((!g432 E) || ((g370 E) && (!g430 E))) := by simp [g1,g437,g438,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold4_2 E
  have T0 := score0_threshold4_1 E
  exact threshold_step (g370 E) (!g432 E) (!g430 E) 2 (countTrue (score0_vals4 E)) T1 T0
theorem score0_threshold6_2 (E : Nat→Bool) : ((!g446 E)=true) ↔ 3≤countTrue (score0_vals6 E) := by
  have rew : (!g446 E) = ((!g438 E) || ((g371 E) && (!g436 E))) := by simp [g1,g445,g446,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold5_2 E
  have T0 := score0_threshold5_1 E
  exact threshold_step (g371 E) (!g438 E) (!g436 E) 2 (countTrue (score0_vals5 E)) T1 T0
theorem score0_threshold7_2 (E : Nat→Bool) : ((!g456 E)=true) ↔ 3≤countTrue (score0_vals7 E) := by
  have rew : (!g456 E) = ((!g446 E) || ((g372 E) && (!g444 E))) := by simp [g1,g455,g456,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold6_2 E
  have T0 := score0_threshold6_1 E
  exact threshold_step (g372 E) (!g446 E) (!g444 E) 2 (countTrue (score0_vals6 E)) T1 T0
theorem score0_threshold8_2 (E : Nat→Bool) : ((!g468 E)=true) ↔ 3≤countTrue (score0_vals8 E) := by
  have rew : (!g468 E) = ((!g456 E) || ((g373 E) && (!g454 E))) := by simp [g1,g467,g468,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold7_2 E
  have T0 := score0_threshold7_1 E
  exact threshold_step (g373 E) (!g456 E) (!g454 E) 2 (countTrue (score0_vals7 E)) T1 T0
theorem score0_threshold9_2 (E : Nat→Bool) : ((!g482 E)=true) ↔ 3≤countTrue (score0_vals9 E) := by
  have rew : (!g482 E) = ((!g468 E) || ((g374 E) && (!g466 E))) := by simp [g1,g481,g482,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold8_2 E
  have T0 := score0_threshold8_1 E
  exact threshold_step (g374 E) (!g468 E) (!g466 E) 2 (countTrue (score0_vals8 E)) T1 T0
theorem score0_threshold10_2 (E : Nat→Bool) : ((!g498 E)=true) ↔ 3≤countTrue (score0_vals10 E) := by
  have rew : (!g498 E) = ((!g482 E) || ((g375 E) && (!g480 E))) := by simp [g1,g497,g498,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold9_2 E
  have T0 := score0_threshold9_1 E
  exact threshold_step (g375 E) (!g482 E) (!g480 E) 2 (countTrue (score0_vals9 E)) T1 T0
theorem score0_threshold11_2 (E : Nat→Bool) : ((!g516 E)=true) ↔ 3≤countTrue (score0_vals11 E) := by
  have rew : (!g516 E) = ((!g498 E) || ((g376 E) && (!g496 E))) := by simp [g1,g515,g516,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold10_2 E
  have T0 := score0_threshold10_1 E
  exact threshold_step (g376 E) (!g498 E) (!g496 E) 2 (countTrue (score0_vals10 E)) T1 T0
theorem score0_threshold12_2 (E : Nat→Bool) : ((!g536 E)=true) ↔ 3≤countTrue (score0_vals12 E) := by
  have rew : (!g536 E) = ((!g516 E) || ((g377 E) && (!g514 E))) := by simp [g1,g535,g536,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold11_2 E
  have T0 := score0_threshold11_1 E
  exact threshold_step (g377 E) (!g516 E) (!g514 E) 2 (countTrue (score0_vals11 E)) T1 T0
theorem score0_threshold13_2 (E : Nat→Bool) : ((!g558 E)=true) ↔ 3≤countTrue (score0_vals13 E) := by
  have rew : (!g558 E) = ((!g536 E) || ((g378 E) && (!g534 E))) := by simp [g1,g557,g558,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold12_2 E
  have T0 := score0_threshold12_1 E
  exact threshold_step (g378 E) (!g536 E) (!g534 E) 2 (countTrue (score0_vals12 E)) T1 T0
theorem score0_threshold14_2 (E : Nat→Bool) : ((!g582 E)=true) ↔ 3≤countTrue (score0_vals14 E) := by
  have rew : (!g582 E) = ((!g558 E) || ((g379 E) && (!g556 E))) := by simp [g1,g581,g582,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold13_2 E
  have T0 := score0_threshold13_1 E
  exact threshold_step (g379 E) (!g558 E) (!g556 E) 2 (countTrue (score0_vals13 E)) T1 T0
theorem score0_threshold15_2 (E : Nat→Bool) : ((!g608 E)=true) ↔ 3≤countTrue (score0_vals15 E) := by
  have rew : (!g608 E) = ((!g582 E) || ((g380 E) && (!g580 E))) := by simp [g1,g607,g608,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold14_2 E
  have T0 := score0_threshold14_1 E
  exact threshold_step (g380 E) (!g582 E) (!g580 E) 2 (countTrue (score0_vals14 E)) T1 T0
theorem score0_threshold16_2 (E : Nat→Bool) : ((!g636 E)=true) ↔ 3≤countTrue (score0_vals16 E) := by
  have rew : (!g636 E) = ((!g608 E) || ((g381 E) && (!g606 E))) := by simp [g1,g635,g636,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold15_2 E
  have T0 := score0_threshold15_1 E
  exact threshold_step (g381 E) (!g608 E) (!g606 E) 2 (countTrue (score0_vals15 E)) T1 T0
theorem score0_threshold17_2 (E : Nat→Bool) : ((!g666 E)=true) ↔ 3≤countTrue (score0_vals17 E) := by
  have rew : (!g666 E) = ((!g636 E) || ((g382 E) && (!g634 E))) := by simp [g1,g665,g666,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold16_2 E
  have T0 := score0_threshold16_1 E
  exact threshold_step (g382 E) (!g636 E) (!g634 E) 2 (countTrue (score0_vals16 E)) T1 T0
theorem score0_threshold18_2 (E : Nat→Bool) : ((!g698 E)=true) ↔ 3≤countTrue (score0_vals18 E) := by
  have rew : (!g698 E) = ((!g666 E) || ((g383 E) && (!g664 E))) := by simp [g1,g697,g698,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold17_2 E
  have T0 := score0_threshold17_1 E
  exact threshold_step (g383 E) (!g666 E) (!g664 E) 2 (countTrue (score0_vals17 E)) T1 T0
theorem score0_threshold19_2 (E : Nat→Bool) : ((!g732 E)=true) ↔ 3≤countTrue (score0_vals19 E) := by
  have rew : (!g732 E) = ((!g698 E) || ((g384 E) && (!g696 E))) := by simp [g1,g731,g732,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold18_2 E
  have T0 := score0_threshold18_1 E
  exact threshold_step (g384 E) (!g698 E) (!g696 E) 2 (countTrue (score0_vals18 E)) T1 T0
theorem score0_threshold20_2 (E : Nat→Bool) : ((!g768 E)=true) ↔ 3≤countTrue (score0_vals20 E) := by
  have rew : (!g768 E) = ((!g732 E) || ((g385 E) && (!g730 E))) := by simp [g1,g767,g768,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold19_2 E
  have T0 := score0_threshold19_1 E
  exact threshold_step (g385 E) (!g732 E) (!g730 E) 2 (countTrue (score0_vals19 E)) T1 T0
theorem score0_threshold21_2 (E : Nat→Bool) : ((!g806 E)=true) ↔ 3≤countTrue (score0_vals21 E) := by
  have rew : (!g806 E) = ((!g768 E) || ((g386 E) && (!g766 E))) := by simp [g1,g805,g806,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score0_threshold20_2 E
  have T0 := score0_threshold20_1 E
  exact threshold_step (g386 E) (!g768 E) (!g766 E) 2 (countTrue (score0_vals20 E)) T1 T0
def score0_count (E : Nat→Bool) : Nat := countTrue (score0_vals21 E)
def score1_vals1 (E : Nat→Bool) : List Bool := (g366 E) :: ([])
def score1_vals2 (E : Nat→Bool) : List Bool := (g367 E) :: (score1_vals1 E)
def score1_vals3 (E : Nat→Bool) : List Bool := (g368 E) :: (score1_vals2 E)
def score1_vals4 (E : Nat→Bool) : List Bool := (g369 E) :: (score1_vals3 E)
def score1_vals5 (E : Nat→Bool) : List Bool := (g370 E) :: (score1_vals4 E)
def score1_vals6 (E : Nat→Bool) : List Bool := (g371 E) :: (score1_vals5 E)
def score1_vals7 (E : Nat→Bool) : List Bool := (g387 E) :: (score1_vals6 E)
def score1_vals8 (E : Nat→Bool) : List Bool := (g388 E) :: (score1_vals7 E)
def score1_vals9 (E : Nat→Bool) : List Bool := (g389 E) :: (score1_vals8 E)
def score1_vals10 (E : Nat→Bool) : List Bool := (g390 E) :: (score1_vals9 E)
def score1_vals11 (E : Nat→Bool) : List Bool := (g391 E) :: (score1_vals10 E)
def score1_vals12 (E : Nat→Bool) : List Bool := (g392 E) :: (score1_vals11 E)
def score1_vals13 (E : Nat→Bool) : List Bool := (g393 E) :: (score1_vals12 E)
def score1_vals14 (E : Nat→Bool) : List Bool := (g394 E) :: (score1_vals13 E)
def score1_vals15 (E : Nat→Bool) : List Bool := (g395 E) :: (score1_vals14 E)
def score1_vals16 (E : Nat→Bool) : List Bool := (g396 E) :: (score1_vals15 E)
def score1_vals17 (E : Nat→Bool) : List Bool := (g397 E) :: (score1_vals16 E)
def score1_vals18 (E : Nat→Bool) : List Bool := (g398 E) :: (score1_vals17 E)
def score1_vals19 (E : Nat→Bool) : List Bool := (g399 E) :: (score1_vals18 E)
def score1_vals20 (E : Nat→Bool) : List Bool := (g400 E) :: (score1_vals19 E)
def score1_vals21 (E : Nat→Bool) : List Bool := (g401 E) :: (score1_vals20 E)
theorem score1_threshold1_0 (E : Nat→Bool) : ((g366 E)=true) ↔ 1≤countTrue (score1_vals1 E) := by
  have rew : (g366 E) = ((!g1 E) || ((g366 E) && (g1 E))) := by simp [g1,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 1≤countTrue ([] : List Bool) := by
    have hh := count_true_bound ([] : List Bool)
    change countTrue ([] : List Bool)≤0 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬1≤countTrue ([] : List Bool)
    omega
  have T0 : (g1 E)=true ↔ 0≤countTrue ([] : List Bool) := by simp [g1]
  exact threshold_step (g366 E) (!g1 E) (g1 E) 0 (countTrue ([] : List Bool)) T1 T0
theorem score1_threshold2_1 (E : Nat→Bool) : ((g843 E)=true) ↔ 2≤countTrue (score1_vals2 E) := by
  have rew : (g843 E) = ((!g1 E) || ((g367 E) && (g366 E))) := by simp [g1,g843,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 2≤countTrue (score1_vals1 E) := by
    have hh := count_true_bound (score1_vals1 E)
    change countTrue (score1_vals1 E)≤1 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬2≤countTrue (score1_vals1 E)
    omega
  have T0 := score1_threshold1_0 E
  exact threshold_step (g367 E) (!g1 E) (g366 E) 1 (countTrue (score1_vals1 E)) T1 T0
theorem score1_threshold3_2 (E : Nat→Bool) : ((g847 E)=true) ↔ 3≤countTrue (score1_vals3 E) := by
  have rew : (g847 E) = ((!g1 E) || ((g368 E) && (g843 E))) := by simp [g1,g847,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 3≤countTrue (score1_vals2 E) := by
    have hh := count_true_bound (score1_vals2 E)
    change countTrue (score1_vals2 E)≤2 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬3≤countTrue (score1_vals2 E)
    omega
  have T0 := score1_threshold2_1 E
  exact threshold_step (g368 E) (!g1 E) (g843 E) 2 (countTrue (score1_vals2 E)) T1 T0
theorem score1_threshold2_0 (E : Nat→Bool) : ((!g842 E)=true) ↔ 1≤countTrue (score1_vals2 E) := by
  have rew : (!g842 E) = ((g366 E) || ((g367 E) && (g1 E))) := by simp [g1,g842,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold1_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals1 E) := by simp [g1]
  exact threshold_step (g367 E) (g366 E) (g1 E) 0 (countTrue (score1_vals1 E)) T1 T0
theorem score1_threshold3_1 (E : Nat→Bool) : ((!g846 E)=true) ↔ 2≤countTrue (score1_vals3 E) := by
  have rew : (!g846 E) = ((g843 E) || ((g368 E) && (!g842 E))) := by simp [g1,g845,g846,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold2_1 E
  have T0 := score1_threshold2_0 E
  exact threshold_step (g368 E) (g843 E) (!g842 E) 1 (countTrue (score1_vals2 E)) T1 T0
theorem score1_threshold4_2 (E : Nat→Bool) : ((!g852 E)=true) ↔ 3≤countTrue (score1_vals4 E) := by
  have rew : (!g852 E) = ((g847 E) || ((g369 E) && (!g846 E))) := by simp [g1,g851,g852,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold3_2 E
  have T0 := score1_threshold3_1 E
  exact threshold_step (g369 E) (g847 E) (!g846 E) 2 (countTrue (score1_vals3 E)) T1 T0
theorem score1_threshold3_0 (E : Nat→Bool) : ((!g844 E)=true) ↔ 1≤countTrue (score1_vals3 E) := by
  have rew : (!g844 E) = ((!g842 E) || ((g368 E) && (g1 E))) := by simp [g1,g844,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold2_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals2 E) := by simp [g1]
  exact threshold_step (g368 E) (!g842 E) (g1 E) 0 (countTrue (score1_vals2 E)) T1 T0
theorem score1_threshold4_1 (E : Nat→Bool) : ((!g850 E)=true) ↔ 2≤countTrue (score1_vals4 E) := by
  have rew : (!g850 E) = ((!g846 E) || ((g369 E) && (!g844 E))) := by simp [g1,g849,g850,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold3_1 E
  have T0 := score1_threshold3_0 E
  exact threshold_step (g369 E) (!g846 E) (!g844 E) 1 (countTrue (score1_vals3 E)) T1 T0
theorem score1_threshold5_2 (E : Nat→Bool) : ((!g858 E)=true) ↔ 3≤countTrue (score1_vals5 E) := by
  have rew : (!g858 E) = ((!g852 E) || ((g370 E) && (!g850 E))) := by simp [g1,g857,g858,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold4_2 E
  have T0 := score1_threshold4_1 E
  exact threshold_step (g370 E) (!g852 E) (!g850 E) 2 (countTrue (score1_vals4 E)) T1 T0
theorem score1_threshold4_0 (E : Nat→Bool) : ((!g848 E)=true) ↔ 1≤countTrue (score1_vals4 E) := by
  have rew : (!g848 E) = ((!g844 E) || ((g369 E) && (g1 E))) := by simp [g1,g848,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold3_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals3 E) := by simp [g1]
  exact threshold_step (g369 E) (!g844 E) (g1 E) 0 (countTrue (score1_vals3 E)) T1 T0
theorem score1_threshold5_1 (E : Nat→Bool) : ((!g856 E)=true) ↔ 2≤countTrue (score1_vals5 E) := by
  have rew : (!g856 E) = ((!g850 E) || ((g370 E) && (!g848 E))) := by simp [g1,g855,g856,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold4_1 E
  have T0 := score1_threshold4_0 E
  exact threshold_step (g370 E) (!g850 E) (!g848 E) 1 (countTrue (score1_vals4 E)) T1 T0
theorem score1_threshold6_2 (E : Nat→Bool) : ((!g866 E)=true) ↔ 3≤countTrue (score1_vals6 E) := by
  have rew : (!g866 E) = ((!g858 E) || ((g371 E) && (!g856 E))) := by simp [g1,g865,g866,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold5_2 E
  have T0 := score1_threshold5_1 E
  exact threshold_step (g371 E) (!g858 E) (!g856 E) 2 (countTrue (score1_vals5 E)) T1 T0
theorem score1_threshold5_0 (E : Nat→Bool) : ((!g854 E)=true) ↔ 1≤countTrue (score1_vals5 E) := by
  have rew : (!g854 E) = ((!g848 E) || ((g370 E) && (g1 E))) := by simp [g1,g854,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold4_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals4 E) := by simp [g1]
  exact threshold_step (g370 E) (!g848 E) (g1 E) 0 (countTrue (score1_vals4 E)) T1 T0
theorem score1_threshold6_1 (E : Nat→Bool) : ((!g864 E)=true) ↔ 2≤countTrue (score1_vals6 E) := by
  have rew : (!g864 E) = ((!g856 E) || ((g371 E) && (!g854 E))) := by simp [g1,g863,g864,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold5_1 E
  have T0 := score1_threshold5_0 E
  exact threshold_step (g371 E) (!g856 E) (!g854 E) 1 (countTrue (score1_vals5 E)) T1 T0
theorem score1_threshold7_2 (E : Nat→Bool) : ((!g876 E)=true) ↔ 3≤countTrue (score1_vals7 E) := by
  have rew : (!g876 E) = ((!g866 E) || ((g387 E) && (!g864 E))) := by simp [g1,g875,g876,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold6_2 E
  have T0 := score1_threshold6_1 E
  exact threshold_step (g387 E) (!g866 E) (!g864 E) 2 (countTrue (score1_vals6 E)) T1 T0
theorem score1_threshold6_0 (E : Nat→Bool) : ((!g862 E)=true) ↔ 1≤countTrue (score1_vals6 E) := by
  have rew : (!g862 E) = ((!g854 E) || ((g371 E) && (g1 E))) := by simp [g1,g862,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold5_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals5 E) := by simp [g1]
  exact threshold_step (g371 E) (!g854 E) (g1 E) 0 (countTrue (score1_vals5 E)) T1 T0
theorem score1_threshold7_1 (E : Nat→Bool) : ((!g874 E)=true) ↔ 2≤countTrue (score1_vals7 E) := by
  have rew : (!g874 E) = ((!g864 E) || ((g387 E) && (!g862 E))) := by simp [g1,g873,g874,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold6_1 E
  have T0 := score1_threshold6_0 E
  exact threshold_step (g387 E) (!g864 E) (!g862 E) 1 (countTrue (score1_vals6 E)) T1 T0
theorem score1_threshold8_2 (E : Nat→Bool) : ((!g888 E)=true) ↔ 3≤countTrue (score1_vals8 E) := by
  have rew : (!g888 E) = ((!g876 E) || ((g388 E) && (!g874 E))) := by simp [g1,g887,g888,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold7_2 E
  have T0 := score1_threshold7_1 E
  exact threshold_step (g388 E) (!g876 E) (!g874 E) 2 (countTrue (score1_vals7 E)) T1 T0
theorem score1_threshold7_0 (E : Nat→Bool) : ((!g872 E)=true) ↔ 1≤countTrue (score1_vals7 E) := by
  have rew : (!g872 E) = ((!g862 E) || ((g387 E) && (g1 E))) := by simp [g1,g872,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold6_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals6 E) := by simp [g1]
  exact threshold_step (g387 E) (!g862 E) (g1 E) 0 (countTrue (score1_vals6 E)) T1 T0
theorem score1_threshold8_1 (E : Nat→Bool) : ((!g886 E)=true) ↔ 2≤countTrue (score1_vals8 E) := by
  have rew : (!g886 E) = ((!g874 E) || ((g388 E) && (!g872 E))) := by simp [g1,g885,g886,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold7_1 E
  have T0 := score1_threshold7_0 E
  exact threshold_step (g388 E) (!g874 E) (!g872 E) 1 (countTrue (score1_vals7 E)) T1 T0
theorem score1_threshold9_2 (E : Nat→Bool) : ((!g902 E)=true) ↔ 3≤countTrue (score1_vals9 E) := by
  have rew : (!g902 E) = ((!g888 E) || ((g389 E) && (!g886 E))) := by simp [g1,g901,g902,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold8_2 E
  have T0 := score1_threshold8_1 E
  exact threshold_step (g389 E) (!g888 E) (!g886 E) 2 (countTrue (score1_vals8 E)) T1 T0
theorem score1_threshold8_0 (E : Nat→Bool) : ((!g884 E)=true) ↔ 1≤countTrue (score1_vals8 E) := by
  have rew : (!g884 E) = ((!g872 E) || ((g388 E) && (g1 E))) := by simp [g1,g884,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold7_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals7 E) := by simp [g1]
  exact threshold_step (g388 E) (!g872 E) (g1 E) 0 (countTrue (score1_vals7 E)) T1 T0
theorem score1_threshold9_1 (E : Nat→Bool) : ((!g900 E)=true) ↔ 2≤countTrue (score1_vals9 E) := by
  have rew : (!g900 E) = ((!g886 E) || ((g389 E) && (!g884 E))) := by simp [g1,g899,g900,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold8_1 E
  have T0 := score1_threshold8_0 E
  exact threshold_step (g389 E) (!g886 E) (!g884 E) 1 (countTrue (score1_vals8 E)) T1 T0
theorem score1_threshold10_2 (E : Nat→Bool) : ((!g918 E)=true) ↔ 3≤countTrue (score1_vals10 E) := by
  have rew : (!g918 E) = ((!g902 E) || ((g390 E) && (!g900 E))) := by simp [g1,g917,g918,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold9_2 E
  have T0 := score1_threshold9_1 E
  exact threshold_step (g390 E) (!g902 E) (!g900 E) 2 (countTrue (score1_vals9 E)) T1 T0
theorem score1_threshold9_0 (E : Nat→Bool) : ((!g898 E)=true) ↔ 1≤countTrue (score1_vals9 E) := by
  have rew : (!g898 E) = ((!g884 E) || ((g389 E) && (g1 E))) := by simp [g1,g898,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold8_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals8 E) := by simp [g1]
  exact threshold_step (g389 E) (!g884 E) (g1 E) 0 (countTrue (score1_vals8 E)) T1 T0
theorem score1_threshold10_1 (E : Nat→Bool) : ((!g916 E)=true) ↔ 2≤countTrue (score1_vals10 E) := by
  have rew : (!g916 E) = ((!g900 E) || ((g390 E) && (!g898 E))) := by simp [g1,g915,g916,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold9_1 E
  have T0 := score1_threshold9_0 E
  exact threshold_step (g390 E) (!g900 E) (!g898 E) 1 (countTrue (score1_vals9 E)) T1 T0
theorem score1_threshold11_2 (E : Nat→Bool) : ((!g936 E)=true) ↔ 3≤countTrue (score1_vals11 E) := by
  have rew : (!g936 E) = ((!g918 E) || ((g391 E) && (!g916 E))) := by simp [g1,g935,g936,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold10_2 E
  have T0 := score1_threshold10_1 E
  exact threshold_step (g391 E) (!g918 E) (!g916 E) 2 (countTrue (score1_vals10 E)) T1 T0
theorem score1_threshold10_0 (E : Nat→Bool) : ((!g914 E)=true) ↔ 1≤countTrue (score1_vals10 E) := by
  have rew : (!g914 E) = ((!g898 E) || ((g390 E) && (g1 E))) := by simp [g1,g914,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold9_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals9 E) := by simp [g1]
  exact threshold_step (g390 E) (!g898 E) (g1 E) 0 (countTrue (score1_vals9 E)) T1 T0
theorem score1_threshold11_1 (E : Nat→Bool) : ((!g934 E)=true) ↔ 2≤countTrue (score1_vals11 E) := by
  have rew : (!g934 E) = ((!g916 E) || ((g391 E) && (!g914 E))) := by simp [g1,g933,g934,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold10_1 E
  have T0 := score1_threshold10_0 E
  exact threshold_step (g391 E) (!g916 E) (!g914 E) 1 (countTrue (score1_vals10 E)) T1 T0
theorem score1_threshold12_2 (E : Nat→Bool) : ((!g956 E)=true) ↔ 3≤countTrue (score1_vals12 E) := by
  have rew : (!g956 E) = ((!g936 E) || ((g392 E) && (!g934 E))) := by simp [g1,g955,g956,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold11_2 E
  have T0 := score1_threshold11_1 E
  exact threshold_step (g392 E) (!g936 E) (!g934 E) 2 (countTrue (score1_vals11 E)) T1 T0
theorem score1_threshold11_0 (E : Nat→Bool) : ((!g932 E)=true) ↔ 1≤countTrue (score1_vals11 E) := by
  have rew : (!g932 E) = ((!g914 E) || ((g391 E) && (g1 E))) := by simp [g1,g932,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold10_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals10 E) := by simp [g1]
  exact threshold_step (g391 E) (!g914 E) (g1 E) 0 (countTrue (score1_vals10 E)) T1 T0
theorem score1_threshold12_1 (E : Nat→Bool) : ((!g954 E)=true) ↔ 2≤countTrue (score1_vals12 E) := by
  have rew : (!g954 E) = ((!g934 E) || ((g392 E) && (!g932 E))) := by simp [g1,g953,g954,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold11_1 E
  have T0 := score1_threshold11_0 E
  exact threshold_step (g392 E) (!g934 E) (!g932 E) 1 (countTrue (score1_vals11 E)) T1 T0
theorem score1_threshold13_2 (E : Nat→Bool) : ((!g978 E)=true) ↔ 3≤countTrue (score1_vals13 E) := by
  have rew : (!g978 E) = ((!g956 E) || ((g393 E) && (!g954 E))) := by simp [g1,g977,g978,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold12_2 E
  have T0 := score1_threshold12_1 E
  exact threshold_step (g393 E) (!g956 E) (!g954 E) 2 (countTrue (score1_vals12 E)) T1 T0
theorem score1_threshold12_0 (E : Nat→Bool) : ((!g952 E)=true) ↔ 1≤countTrue (score1_vals12 E) := by
  have rew : (!g952 E) = ((!g932 E) || ((g392 E) && (g1 E))) := by simp [g1,g952,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold11_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals11 E) := by simp [g1]
  exact threshold_step (g392 E) (!g932 E) (g1 E) 0 (countTrue (score1_vals11 E)) T1 T0
theorem score1_threshold13_1 (E : Nat→Bool) : ((!g976 E)=true) ↔ 2≤countTrue (score1_vals13 E) := by
  have rew : (!g976 E) = ((!g954 E) || ((g393 E) && (!g952 E))) := by simp [g1,g975,g976,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold12_1 E
  have T0 := score1_threshold12_0 E
  exact threshold_step (g393 E) (!g954 E) (!g952 E) 1 (countTrue (score1_vals12 E)) T1 T0
theorem score1_threshold14_2 (E : Nat→Bool) : ((!g1002 E)=true) ↔ 3≤countTrue (score1_vals14 E) := by
  have rew : (!g1002 E) = ((!g978 E) || ((g394 E) && (!g976 E))) := by simp [g1,g1001,g1002,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold13_2 E
  have T0 := score1_threshold13_1 E
  exact threshold_step (g394 E) (!g978 E) (!g976 E) 2 (countTrue (score1_vals13 E)) T1 T0
theorem score1_threshold13_0 (E : Nat→Bool) : ((!g974 E)=true) ↔ 1≤countTrue (score1_vals13 E) := by
  have rew : (!g974 E) = ((!g952 E) || ((g393 E) && (g1 E))) := by simp [g1,g974,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold12_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals12 E) := by simp [g1]
  exact threshold_step (g393 E) (!g952 E) (g1 E) 0 (countTrue (score1_vals12 E)) T1 T0
theorem score1_threshold14_1 (E : Nat→Bool) : ((!g1000 E)=true) ↔ 2≤countTrue (score1_vals14 E) := by
  have rew : (!g1000 E) = ((!g976 E) || ((g394 E) && (!g974 E))) := by simp [g1,g999,g1000,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold13_1 E
  have T0 := score1_threshold13_0 E
  exact threshold_step (g394 E) (!g976 E) (!g974 E) 1 (countTrue (score1_vals13 E)) T1 T0
theorem score1_threshold15_2 (E : Nat→Bool) : ((!g1028 E)=true) ↔ 3≤countTrue (score1_vals15 E) := by
  have rew : (!g1028 E) = ((!g1002 E) || ((g395 E) && (!g1000 E))) := by simp [g1,g1027,g1028,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold14_2 E
  have T0 := score1_threshold14_1 E
  exact threshold_step (g395 E) (!g1002 E) (!g1000 E) 2 (countTrue (score1_vals14 E)) T1 T0
theorem score1_threshold14_0 (E : Nat→Bool) : ((!g998 E)=true) ↔ 1≤countTrue (score1_vals14 E) := by
  have rew : (!g998 E) = ((!g974 E) || ((g394 E) && (g1 E))) := by simp [g1,g998,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold13_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals13 E) := by simp [g1]
  exact threshold_step (g394 E) (!g974 E) (g1 E) 0 (countTrue (score1_vals13 E)) T1 T0
theorem score1_threshold15_1 (E : Nat→Bool) : ((!g1026 E)=true) ↔ 2≤countTrue (score1_vals15 E) := by
  have rew : (!g1026 E) = ((!g1000 E) || ((g395 E) && (!g998 E))) := by simp [g1,g1025,g1026,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold14_1 E
  have T0 := score1_threshold14_0 E
  exact threshold_step (g395 E) (!g1000 E) (!g998 E) 1 (countTrue (score1_vals14 E)) T1 T0
theorem score1_threshold16_2 (E : Nat→Bool) : ((!g1056 E)=true) ↔ 3≤countTrue (score1_vals16 E) := by
  have rew : (!g1056 E) = ((!g1028 E) || ((g396 E) && (!g1026 E))) := by simp [g1,g1055,g1056,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold15_2 E
  have T0 := score1_threshold15_1 E
  exact threshold_step (g396 E) (!g1028 E) (!g1026 E) 2 (countTrue (score1_vals15 E)) T1 T0
theorem score1_threshold15_0 (E : Nat→Bool) : ((!g1024 E)=true) ↔ 1≤countTrue (score1_vals15 E) := by
  have rew : (!g1024 E) = ((!g998 E) || ((g395 E) && (g1 E))) := by simp [g1,g1024,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold14_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals14 E) := by simp [g1]
  exact threshold_step (g395 E) (!g998 E) (g1 E) 0 (countTrue (score1_vals14 E)) T1 T0
theorem score1_threshold16_1 (E : Nat→Bool) : ((!g1054 E)=true) ↔ 2≤countTrue (score1_vals16 E) := by
  have rew : (!g1054 E) = ((!g1026 E) || ((g396 E) && (!g1024 E))) := by simp [g1,g1053,g1054,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold15_1 E
  have T0 := score1_threshold15_0 E
  exact threshold_step (g396 E) (!g1026 E) (!g1024 E) 1 (countTrue (score1_vals15 E)) T1 T0
theorem score1_threshold17_2 (E : Nat→Bool) : ((!g1086 E)=true) ↔ 3≤countTrue (score1_vals17 E) := by
  have rew : (!g1086 E) = ((!g1056 E) || ((g397 E) && (!g1054 E))) := by simp [g1,g1085,g1086,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold16_2 E
  have T0 := score1_threshold16_1 E
  exact threshold_step (g397 E) (!g1056 E) (!g1054 E) 2 (countTrue (score1_vals16 E)) T1 T0
theorem score1_threshold16_0 (E : Nat→Bool) : ((!g1052 E)=true) ↔ 1≤countTrue (score1_vals16 E) := by
  have rew : (!g1052 E) = ((!g1024 E) || ((g396 E) && (g1 E))) := by simp [g1,g1052,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold15_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals15 E) := by simp [g1]
  exact threshold_step (g396 E) (!g1024 E) (g1 E) 0 (countTrue (score1_vals15 E)) T1 T0
theorem score1_threshold17_1 (E : Nat→Bool) : ((!g1084 E)=true) ↔ 2≤countTrue (score1_vals17 E) := by
  have rew : (!g1084 E) = ((!g1054 E) || ((g397 E) && (!g1052 E))) := by simp [g1,g1083,g1084,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold16_1 E
  have T0 := score1_threshold16_0 E
  exact threshold_step (g397 E) (!g1054 E) (!g1052 E) 1 (countTrue (score1_vals16 E)) T1 T0
theorem score1_threshold18_2 (E : Nat→Bool) : ((!g1118 E)=true) ↔ 3≤countTrue (score1_vals18 E) := by
  have rew : (!g1118 E) = ((!g1086 E) || ((g398 E) && (!g1084 E))) := by simp [g1,g1117,g1118,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold17_2 E
  have T0 := score1_threshold17_1 E
  exact threshold_step (g398 E) (!g1086 E) (!g1084 E) 2 (countTrue (score1_vals17 E)) T1 T0
theorem score1_threshold17_0 (E : Nat→Bool) : ((!g1082 E)=true) ↔ 1≤countTrue (score1_vals17 E) := by
  have rew : (!g1082 E) = ((!g1052 E) || ((g397 E) && (g1 E))) := by simp [g1,g1082,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold16_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals16 E) := by simp [g1]
  exact threshold_step (g397 E) (!g1052 E) (g1 E) 0 (countTrue (score1_vals16 E)) T1 T0
theorem score1_threshold18_1 (E : Nat→Bool) : ((!g1116 E)=true) ↔ 2≤countTrue (score1_vals18 E) := by
  have rew : (!g1116 E) = ((!g1084 E) || ((g398 E) && (!g1082 E))) := by simp [g1,g1115,g1116,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold17_1 E
  have T0 := score1_threshold17_0 E
  exact threshold_step (g398 E) (!g1084 E) (!g1082 E) 1 (countTrue (score1_vals17 E)) T1 T0
theorem score1_threshold19_2 (E : Nat→Bool) : ((!g1152 E)=true) ↔ 3≤countTrue (score1_vals19 E) := by
  have rew : (!g1152 E) = ((!g1118 E) || ((g399 E) && (!g1116 E))) := by simp [g1,g1151,g1152,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold18_2 E
  have T0 := score1_threshold18_1 E
  exact threshold_step (g399 E) (!g1118 E) (!g1116 E) 2 (countTrue (score1_vals18 E)) T1 T0
theorem score1_threshold18_0 (E : Nat→Bool) : ((!g1114 E)=true) ↔ 1≤countTrue (score1_vals18 E) := by
  have rew : (!g1114 E) = ((!g1082 E) || ((g398 E) && (g1 E))) := by simp [g1,g1114,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold17_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals17 E) := by simp [g1]
  exact threshold_step (g398 E) (!g1082 E) (g1 E) 0 (countTrue (score1_vals17 E)) T1 T0
theorem score1_threshold19_1 (E : Nat→Bool) : ((!g1150 E)=true) ↔ 2≤countTrue (score1_vals19 E) := by
  have rew : (!g1150 E) = ((!g1116 E) || ((g399 E) && (!g1114 E))) := by simp [g1,g1149,g1150,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold18_1 E
  have T0 := score1_threshold18_0 E
  exact threshold_step (g399 E) (!g1116 E) (!g1114 E) 1 (countTrue (score1_vals18 E)) T1 T0
theorem score1_threshold20_2 (E : Nat→Bool) : ((!g1188 E)=true) ↔ 3≤countTrue (score1_vals20 E) := by
  have rew : (!g1188 E) = ((!g1152 E) || ((g400 E) && (!g1150 E))) := by simp [g1,g1187,g1188,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold19_2 E
  have T0 := score1_threshold19_1 E
  exact threshold_step (g400 E) (!g1152 E) (!g1150 E) 2 (countTrue (score1_vals19 E)) T1 T0
theorem score1_threshold19_0 (E : Nat→Bool) : ((!g1148 E)=true) ↔ 1≤countTrue (score1_vals19 E) := by
  have rew : (!g1148 E) = ((!g1114 E) || ((g399 E) && (g1 E))) := by simp [g1,g1148,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold18_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score1_vals18 E) := by simp [g1]
  exact threshold_step (g399 E) (!g1114 E) (g1 E) 0 (countTrue (score1_vals18 E)) T1 T0
theorem score1_threshold20_1 (E : Nat→Bool) : ((!g1186 E)=true) ↔ 2≤countTrue (score1_vals20 E) := by
  have rew : (!g1186 E) = ((!g1150 E) || ((g400 E) && (!g1148 E))) := by simp [g1,g1185,g1186,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold19_1 E
  have T0 := score1_threshold19_0 E
  exact threshold_step (g400 E) (!g1150 E) (!g1148 E) 1 (countTrue (score1_vals19 E)) T1 T0
theorem score1_threshold21_2 (E : Nat→Bool) : ((!g1226 E)=true) ↔ 3≤countTrue (score1_vals21 E) := by
  have rew : (!g1226 E) = ((!g1188 E) || ((g401 E) && (!g1186 E))) := by simp [g1,g1225,g1226,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold20_2 E
  have T0 := score1_threshold20_1 E
  exact threshold_step (g401 E) (!g1188 E) (!g1186 E) 2 (countTrue (score1_vals20 E)) T1 T0
theorem score1_threshold4_3 (E : Nat→Bool) : ((g853 E)=true) ↔ 4≤countTrue (score1_vals4 E) := by
  have rew : (g853 E) = ((!g1 E) || ((g369 E) && (g847 E))) := by simp [g1,g853,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 4≤countTrue (score1_vals3 E) := by
    have hh := count_true_bound (score1_vals3 E)
    change countTrue (score1_vals3 E)≤3 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬4≤countTrue (score1_vals3 E)
    omega
  have T0 := score1_threshold3_2 E
  exact threshold_step (g369 E) (!g1 E) (g847 E) 3 (countTrue (score1_vals3 E)) T1 T0
theorem score1_threshold5_3 (E : Nat→Bool) : ((!g860 E)=true) ↔ 4≤countTrue (score1_vals5 E) := by
  have rew : (!g860 E) = ((g853 E) || ((g370 E) && (!g852 E))) := by simp [g1,g859,g860,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold4_3 E
  have T0 := score1_threshold4_2 E
  exact threshold_step (g370 E) (g853 E) (!g852 E) 3 (countTrue (score1_vals4 E)) T1 T0
theorem score1_threshold6_3 (E : Nat→Bool) : ((!g868 E)=true) ↔ 4≤countTrue (score1_vals6 E) := by
  have rew : (!g868 E) = ((!g860 E) || ((g371 E) && (!g858 E))) := by simp [g1,g867,g868,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold5_3 E
  have T0 := score1_threshold5_2 E
  exact threshold_step (g371 E) (!g860 E) (!g858 E) 3 (countTrue (score1_vals5 E)) T1 T0
theorem score1_threshold7_3 (E : Nat→Bool) : ((!g878 E)=true) ↔ 4≤countTrue (score1_vals7 E) := by
  have rew : (!g878 E) = ((!g868 E) || ((g387 E) && (!g866 E))) := by simp [g1,g877,g878,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold6_3 E
  have T0 := score1_threshold6_2 E
  exact threshold_step (g387 E) (!g868 E) (!g866 E) 3 (countTrue (score1_vals6 E)) T1 T0
theorem score1_threshold8_3 (E : Nat→Bool) : ((!g890 E)=true) ↔ 4≤countTrue (score1_vals8 E) := by
  have rew : (!g890 E) = ((!g878 E) || ((g388 E) && (!g876 E))) := by simp [g1,g889,g890,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold7_3 E
  have T0 := score1_threshold7_2 E
  exact threshold_step (g388 E) (!g878 E) (!g876 E) 3 (countTrue (score1_vals7 E)) T1 T0
theorem score1_threshold9_3 (E : Nat→Bool) : ((!g904 E)=true) ↔ 4≤countTrue (score1_vals9 E) := by
  have rew : (!g904 E) = ((!g890 E) || ((g389 E) && (!g888 E))) := by simp [g1,g903,g904,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold8_3 E
  have T0 := score1_threshold8_2 E
  exact threshold_step (g389 E) (!g890 E) (!g888 E) 3 (countTrue (score1_vals8 E)) T1 T0
theorem score1_threshold10_3 (E : Nat→Bool) : ((!g920 E)=true) ↔ 4≤countTrue (score1_vals10 E) := by
  have rew : (!g920 E) = ((!g904 E) || ((g390 E) && (!g902 E))) := by simp [g1,g919,g920,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold9_3 E
  have T0 := score1_threshold9_2 E
  exact threshold_step (g390 E) (!g904 E) (!g902 E) 3 (countTrue (score1_vals9 E)) T1 T0
theorem score1_threshold11_3 (E : Nat→Bool) : ((!g938 E)=true) ↔ 4≤countTrue (score1_vals11 E) := by
  have rew : (!g938 E) = ((!g920 E) || ((g391 E) && (!g918 E))) := by simp [g1,g937,g938,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold10_3 E
  have T0 := score1_threshold10_2 E
  exact threshold_step (g391 E) (!g920 E) (!g918 E) 3 (countTrue (score1_vals10 E)) T1 T0
theorem score1_threshold12_3 (E : Nat→Bool) : ((!g958 E)=true) ↔ 4≤countTrue (score1_vals12 E) := by
  have rew : (!g958 E) = ((!g938 E) || ((g392 E) && (!g936 E))) := by simp [g1,g957,g958,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold11_3 E
  have T0 := score1_threshold11_2 E
  exact threshold_step (g392 E) (!g938 E) (!g936 E) 3 (countTrue (score1_vals11 E)) T1 T0
theorem score1_threshold13_3 (E : Nat→Bool) : ((!g980 E)=true) ↔ 4≤countTrue (score1_vals13 E) := by
  have rew : (!g980 E) = ((!g958 E) || ((g393 E) && (!g956 E))) := by simp [g1,g979,g980,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold12_3 E
  have T0 := score1_threshold12_2 E
  exact threshold_step (g393 E) (!g958 E) (!g956 E) 3 (countTrue (score1_vals12 E)) T1 T0
theorem score1_threshold14_3 (E : Nat→Bool) : ((!g1004 E)=true) ↔ 4≤countTrue (score1_vals14 E) := by
  have rew : (!g1004 E) = ((!g980 E) || ((g394 E) && (!g978 E))) := by simp [g1,g1003,g1004,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold13_3 E
  have T0 := score1_threshold13_2 E
  exact threshold_step (g394 E) (!g980 E) (!g978 E) 3 (countTrue (score1_vals13 E)) T1 T0
theorem score1_threshold15_3 (E : Nat→Bool) : ((!g1030 E)=true) ↔ 4≤countTrue (score1_vals15 E) := by
  have rew : (!g1030 E) = ((!g1004 E) || ((g395 E) && (!g1002 E))) := by simp [g1,g1029,g1030,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold14_3 E
  have T0 := score1_threshold14_2 E
  exact threshold_step (g395 E) (!g1004 E) (!g1002 E) 3 (countTrue (score1_vals14 E)) T1 T0
theorem score1_threshold16_3 (E : Nat→Bool) : ((!g1058 E)=true) ↔ 4≤countTrue (score1_vals16 E) := by
  have rew : (!g1058 E) = ((!g1030 E) || ((g396 E) && (!g1028 E))) := by simp [g1,g1057,g1058,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold15_3 E
  have T0 := score1_threshold15_2 E
  exact threshold_step (g396 E) (!g1030 E) (!g1028 E) 3 (countTrue (score1_vals15 E)) T1 T0
theorem score1_threshold17_3 (E : Nat→Bool) : ((!g1088 E)=true) ↔ 4≤countTrue (score1_vals17 E) := by
  have rew : (!g1088 E) = ((!g1058 E) || ((g397 E) && (!g1056 E))) := by simp [g1,g1087,g1088,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold16_3 E
  have T0 := score1_threshold16_2 E
  exact threshold_step (g397 E) (!g1058 E) (!g1056 E) 3 (countTrue (score1_vals16 E)) T1 T0
theorem score1_threshold18_3 (E : Nat→Bool) : ((!g1120 E)=true) ↔ 4≤countTrue (score1_vals18 E) := by
  have rew : (!g1120 E) = ((!g1088 E) || ((g398 E) && (!g1086 E))) := by simp [g1,g1119,g1120,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold17_3 E
  have T0 := score1_threshold17_2 E
  exact threshold_step (g398 E) (!g1088 E) (!g1086 E) 3 (countTrue (score1_vals17 E)) T1 T0
theorem score1_threshold19_3 (E : Nat→Bool) : ((!g1154 E)=true) ↔ 4≤countTrue (score1_vals19 E) := by
  have rew : (!g1154 E) = ((!g1120 E) || ((g399 E) && (!g1118 E))) := by simp [g1,g1153,g1154,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold18_3 E
  have T0 := score1_threshold18_2 E
  exact threshold_step (g399 E) (!g1120 E) (!g1118 E) 3 (countTrue (score1_vals18 E)) T1 T0
theorem score1_threshold20_3 (E : Nat→Bool) : ((!g1190 E)=true) ↔ 4≤countTrue (score1_vals20 E) := by
  have rew : (!g1190 E) = ((!g1154 E) || ((g400 E) && (!g1152 E))) := by simp [g1,g1189,g1190,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold19_3 E
  have T0 := score1_threshold19_2 E
  exact threshold_step (g400 E) (!g1154 E) (!g1152 E) 3 (countTrue (score1_vals19 E)) T1 T0
theorem score1_threshold21_3 (E : Nat→Bool) : ((!g1228 E)=true) ↔ 4≤countTrue (score1_vals21 E) := by
  have rew : (!g1228 E) = ((!g1190 E) || ((g401 E) && (!g1188 E))) := by simp [g1,g1227,g1228,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score1_threshold20_3 E
  have T0 := score1_threshold20_2 E
  exact threshold_step (g401 E) (!g1190 E) (!g1188 E) 3 (countTrue (score1_vals20 E)) T1 T0
def score1_count (E : Nat→Bool) : Nat := countTrue (score1_vals21 E)
def score2_vals1 (E : Nat→Bool) : List Bool := (g366 E) :: ([])
def score2_vals2 (E : Nat→Bool) : List Bool := (g372 E) :: (score2_vals1 E)
def score2_vals3 (E : Nat→Bool) : List Bool := (g373 E) :: (score2_vals2 E)
def score2_vals4 (E : Nat→Bool) : List Bool := (g374 E) :: (score2_vals3 E)
def score2_vals5 (E : Nat→Bool) : List Bool := (g375 E) :: (score2_vals4 E)
def score2_vals6 (E : Nat→Bool) : List Bool := (g376 E) :: (score2_vals5 E)
def score2_vals7 (E : Nat→Bool) : List Bool := (g387 E) :: (score2_vals6 E)
def score2_vals8 (E : Nat→Bool) : List Bool := (g388 E) :: (score2_vals7 E)
def score2_vals9 (E : Nat→Bool) : List Bool := (g389 E) :: (score2_vals8 E)
def score2_vals10 (E : Nat→Bool) : List Bool := (g390 E) :: (score2_vals9 E)
def score2_vals11 (E : Nat→Bool) : List Bool := (g391 E) :: (score2_vals10 E)
def score2_vals12 (E : Nat→Bool) : List Bool := (g402 E) :: (score2_vals11 E)
def score2_vals13 (E : Nat→Bool) : List Bool := (g403 E) :: (score2_vals12 E)
def score2_vals14 (E : Nat→Bool) : List Bool := (g404 E) :: (score2_vals13 E)
def score2_vals15 (E : Nat→Bool) : List Bool := (g405 E) :: (score2_vals14 E)
def score2_vals16 (E : Nat→Bool) : List Bool := (g406 E) :: (score2_vals15 E)
def score2_vals17 (E : Nat→Bool) : List Bool := (g407 E) :: (score2_vals16 E)
def score2_vals18 (E : Nat→Bool) : List Bool := (g408 E) :: (score2_vals17 E)
def score2_vals19 (E : Nat→Bool) : List Bool := (g409 E) :: (score2_vals18 E)
def score2_vals20 (E : Nat→Bool) : List Bool := (g410 E) :: (score2_vals19 E)
def score2_vals21 (E : Nat→Bool) : List Bool := (g411 E) :: (score2_vals20 E)
theorem score2_threshold1_0 (E : Nat→Bool) : ((g366 E)=true) ↔ 1≤countTrue (score2_vals1 E) := by
  have rew : (g366 E) = ((!g1 E) || ((g366 E) && (g1 E))) := by simp [g1,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 1≤countTrue ([] : List Bool) := by
    have hh := count_true_bound ([] : List Bool)
    change countTrue ([] : List Bool)≤0 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬1≤countTrue ([] : List Bool)
    omega
  have T0 : (g1 E)=true ↔ 0≤countTrue ([] : List Bool) := by simp [g1]
  exact threshold_step (g366 E) (!g1 E) (g1 E) 0 (countTrue ([] : List Bool)) T1 T0
theorem score2_threshold2_1 (E : Nat→Bool) : ((g1263 E)=true) ↔ 2≤countTrue (score2_vals2 E) := by
  have rew : (g1263 E) = ((!g1 E) || ((g372 E) && (g366 E))) := by simp [g1,g1263,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 2≤countTrue (score2_vals1 E) := by
    have hh := count_true_bound (score2_vals1 E)
    change countTrue (score2_vals1 E)≤1 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬2≤countTrue (score2_vals1 E)
    omega
  have T0 := score2_threshold1_0 E
  exact threshold_step (g372 E) (!g1 E) (g366 E) 1 (countTrue (score2_vals1 E)) T1 T0
theorem score2_threshold3_2 (E : Nat→Bool) : ((g1267 E)=true) ↔ 3≤countTrue (score2_vals3 E) := by
  have rew : (g1267 E) = ((!g1 E) || ((g373 E) && (g1263 E))) := by simp [g1,g1267,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 3≤countTrue (score2_vals2 E) := by
    have hh := count_true_bound (score2_vals2 E)
    change countTrue (score2_vals2 E)≤2 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬3≤countTrue (score2_vals2 E)
    omega
  have T0 := score2_threshold2_1 E
  exact threshold_step (g373 E) (!g1 E) (g1263 E) 2 (countTrue (score2_vals2 E)) T1 T0
theorem score2_threshold4_3 (E : Nat→Bool) : ((g1273 E)=true) ↔ 4≤countTrue (score2_vals4 E) := by
  have rew : (g1273 E) = ((!g1 E) || ((g374 E) && (g1267 E))) := by simp [g1,g1273,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 : (!g1 E)=true ↔ 4≤countTrue (score2_vals3 E) := by
    have hh := count_true_bound (score2_vals3 E)
    change countTrue (score2_vals3 E)≤3 at hh
    simp only [g1,Bool.not_true,Bool.false_eq_true,false_iff]
    change ¬4≤countTrue (score2_vals3 E)
    omega
  have T0 := score2_threshold3_2 E
  exact threshold_step (g374 E) (!g1 E) (g1267 E) 3 (countTrue (score2_vals3 E)) T1 T0
theorem score2_threshold2_0 (E : Nat→Bool) : ((!g1262 E)=true) ↔ 1≤countTrue (score2_vals2 E) := by
  have rew : (!g1262 E) = ((g366 E) || ((g372 E) && (g1 E))) := by simp [g1,g1262,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold1_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals1 E) := by simp [g1]
  exact threshold_step (g372 E) (g366 E) (g1 E) 0 (countTrue (score2_vals1 E)) T1 T0
theorem score2_threshold3_1 (E : Nat→Bool) : ((!g1266 E)=true) ↔ 2≤countTrue (score2_vals3 E) := by
  have rew : (!g1266 E) = ((g1263 E) || ((g373 E) && (!g1262 E))) := by simp [g1,g1265,g1266,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold2_1 E
  have T0 := score2_threshold2_0 E
  exact threshold_step (g373 E) (g1263 E) (!g1262 E) 1 (countTrue (score2_vals2 E)) T1 T0
theorem score2_threshold4_2 (E : Nat→Bool) : ((!g1272 E)=true) ↔ 3≤countTrue (score2_vals4 E) := by
  have rew : (!g1272 E) = ((g1267 E) || ((g374 E) && (!g1266 E))) := by simp [g1,g1271,g1272,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold3_2 E
  have T0 := score2_threshold3_1 E
  exact threshold_step (g374 E) (g1267 E) (!g1266 E) 2 (countTrue (score2_vals3 E)) T1 T0
theorem score2_threshold5_3 (E : Nat→Bool) : ((!g1280 E)=true) ↔ 4≤countTrue (score2_vals5 E) := by
  have rew : (!g1280 E) = ((g1273 E) || ((g375 E) && (!g1272 E))) := by simp [g1,g1279,g1280,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold4_3 E
  have T0 := score2_threshold4_2 E
  exact threshold_step (g375 E) (g1273 E) (!g1272 E) 3 (countTrue (score2_vals4 E)) T1 T0
theorem score2_threshold3_0 (E : Nat→Bool) : ((!g1264 E)=true) ↔ 1≤countTrue (score2_vals3 E) := by
  have rew : (!g1264 E) = ((!g1262 E) || ((g373 E) && (g1 E))) := by simp [g1,g1264,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold2_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals2 E) := by simp [g1]
  exact threshold_step (g373 E) (!g1262 E) (g1 E) 0 (countTrue (score2_vals2 E)) T1 T0
theorem score2_threshold4_1 (E : Nat→Bool) : ((!g1270 E)=true) ↔ 2≤countTrue (score2_vals4 E) := by
  have rew : (!g1270 E) = ((!g1266 E) || ((g374 E) && (!g1264 E))) := by simp [g1,g1269,g1270,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold3_1 E
  have T0 := score2_threshold3_0 E
  exact threshold_step (g374 E) (!g1266 E) (!g1264 E) 1 (countTrue (score2_vals3 E)) T1 T0
theorem score2_threshold5_2 (E : Nat→Bool) : ((!g1278 E)=true) ↔ 3≤countTrue (score2_vals5 E) := by
  have rew : (!g1278 E) = ((!g1272 E) || ((g375 E) && (!g1270 E))) := by simp [g1,g1277,g1278,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold4_2 E
  have T0 := score2_threshold4_1 E
  exact threshold_step (g375 E) (!g1272 E) (!g1270 E) 2 (countTrue (score2_vals4 E)) T1 T0
theorem score2_threshold6_3 (E : Nat→Bool) : ((!g1288 E)=true) ↔ 4≤countTrue (score2_vals6 E) := by
  have rew : (!g1288 E) = ((!g1280 E) || ((g376 E) && (!g1278 E))) := by simp [g1,g1287,g1288,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold5_3 E
  have T0 := score2_threshold5_2 E
  exact threshold_step (g376 E) (!g1280 E) (!g1278 E) 3 (countTrue (score2_vals5 E)) T1 T0
theorem score2_threshold4_0 (E : Nat→Bool) : ((!g1268 E)=true) ↔ 1≤countTrue (score2_vals4 E) := by
  have rew : (!g1268 E) = ((!g1264 E) || ((g374 E) && (g1 E))) := by simp [g1,g1268,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold3_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals3 E) := by simp [g1]
  exact threshold_step (g374 E) (!g1264 E) (g1 E) 0 (countTrue (score2_vals3 E)) T1 T0
theorem score2_threshold5_1 (E : Nat→Bool) : ((!g1276 E)=true) ↔ 2≤countTrue (score2_vals5 E) := by
  have rew : (!g1276 E) = ((!g1270 E) || ((g375 E) && (!g1268 E))) := by simp [g1,g1275,g1276,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold4_1 E
  have T0 := score2_threshold4_0 E
  exact threshold_step (g375 E) (!g1270 E) (!g1268 E) 1 (countTrue (score2_vals4 E)) T1 T0
theorem score2_threshold6_2 (E : Nat→Bool) : ((!g1286 E)=true) ↔ 3≤countTrue (score2_vals6 E) := by
  have rew : (!g1286 E) = ((!g1278 E) || ((g376 E) && (!g1276 E))) := by simp [g1,g1285,g1286,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold5_2 E
  have T0 := score2_threshold5_1 E
  exact threshold_step (g376 E) (!g1278 E) (!g1276 E) 2 (countTrue (score2_vals5 E)) T1 T0
theorem score2_threshold7_3 (E : Nat→Bool) : ((!g1298 E)=true) ↔ 4≤countTrue (score2_vals7 E) := by
  have rew : (!g1298 E) = ((!g1288 E) || ((g387 E) && (!g1286 E))) := by simp [g1,g1297,g1298,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold6_3 E
  have T0 := score2_threshold6_2 E
  exact threshold_step (g387 E) (!g1288 E) (!g1286 E) 3 (countTrue (score2_vals6 E)) T1 T0
theorem score2_threshold5_0 (E : Nat→Bool) : ((!g1274 E)=true) ↔ 1≤countTrue (score2_vals5 E) := by
  have rew : (!g1274 E) = ((!g1268 E) || ((g375 E) && (g1 E))) := by simp [g1,g1274,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold4_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals4 E) := by simp [g1]
  exact threshold_step (g375 E) (!g1268 E) (g1 E) 0 (countTrue (score2_vals4 E)) T1 T0
theorem score2_threshold6_1 (E : Nat→Bool) : ((!g1284 E)=true) ↔ 2≤countTrue (score2_vals6 E) := by
  have rew : (!g1284 E) = ((!g1276 E) || ((g376 E) && (!g1274 E))) := by simp [g1,g1283,g1284,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold5_1 E
  have T0 := score2_threshold5_0 E
  exact threshold_step (g376 E) (!g1276 E) (!g1274 E) 1 (countTrue (score2_vals5 E)) T1 T0
theorem score2_threshold7_2 (E : Nat→Bool) : ((!g1296 E)=true) ↔ 3≤countTrue (score2_vals7 E) := by
  have rew : (!g1296 E) = ((!g1286 E) || ((g387 E) && (!g1284 E))) := by simp [g1,g1295,g1296,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold6_2 E
  have T0 := score2_threshold6_1 E
  exact threshold_step (g387 E) (!g1286 E) (!g1284 E) 2 (countTrue (score2_vals6 E)) T1 T0
theorem score2_threshold8_3 (E : Nat→Bool) : ((!g1310 E)=true) ↔ 4≤countTrue (score2_vals8 E) := by
  have rew : (!g1310 E) = ((!g1298 E) || ((g388 E) && (!g1296 E))) := by simp [g1,g1309,g1310,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold7_3 E
  have T0 := score2_threshold7_2 E
  exact threshold_step (g388 E) (!g1298 E) (!g1296 E) 3 (countTrue (score2_vals7 E)) T1 T0
theorem score2_threshold6_0 (E : Nat→Bool) : ((!g1282 E)=true) ↔ 1≤countTrue (score2_vals6 E) := by
  have rew : (!g1282 E) = ((!g1274 E) || ((g376 E) && (g1 E))) := by simp [g1,g1282,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold5_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals5 E) := by simp [g1]
  exact threshold_step (g376 E) (!g1274 E) (g1 E) 0 (countTrue (score2_vals5 E)) T1 T0
theorem score2_threshold7_1 (E : Nat→Bool) : ((!g1294 E)=true) ↔ 2≤countTrue (score2_vals7 E) := by
  have rew : (!g1294 E) = ((!g1284 E) || ((g387 E) && (!g1282 E))) := by simp [g1,g1293,g1294,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold6_1 E
  have T0 := score2_threshold6_0 E
  exact threshold_step (g387 E) (!g1284 E) (!g1282 E) 1 (countTrue (score2_vals6 E)) T1 T0
theorem score2_threshold8_2 (E : Nat→Bool) : ((!g1308 E)=true) ↔ 3≤countTrue (score2_vals8 E) := by
  have rew : (!g1308 E) = ((!g1296 E) || ((g388 E) && (!g1294 E))) := by simp [g1,g1307,g1308,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold7_2 E
  have T0 := score2_threshold7_1 E
  exact threshold_step (g388 E) (!g1296 E) (!g1294 E) 2 (countTrue (score2_vals7 E)) T1 T0
theorem score2_threshold9_3 (E : Nat→Bool) : ((!g1324 E)=true) ↔ 4≤countTrue (score2_vals9 E) := by
  have rew : (!g1324 E) = ((!g1310 E) || ((g389 E) && (!g1308 E))) := by simp [g1,g1323,g1324,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold8_3 E
  have T0 := score2_threshold8_2 E
  exact threshold_step (g389 E) (!g1310 E) (!g1308 E) 3 (countTrue (score2_vals8 E)) T1 T0
theorem score2_threshold7_0 (E : Nat→Bool) : ((!g1292 E)=true) ↔ 1≤countTrue (score2_vals7 E) := by
  have rew : (!g1292 E) = ((!g1282 E) || ((g387 E) && (g1 E))) := by simp [g1,g1292,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold6_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals6 E) := by simp [g1]
  exact threshold_step (g387 E) (!g1282 E) (g1 E) 0 (countTrue (score2_vals6 E)) T1 T0
theorem score2_threshold8_1 (E : Nat→Bool) : ((!g1306 E)=true) ↔ 2≤countTrue (score2_vals8 E) := by
  have rew : (!g1306 E) = ((!g1294 E) || ((g388 E) && (!g1292 E))) := by simp [g1,g1305,g1306,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold7_1 E
  have T0 := score2_threshold7_0 E
  exact threshold_step (g388 E) (!g1294 E) (!g1292 E) 1 (countTrue (score2_vals7 E)) T1 T0
theorem score2_threshold9_2 (E : Nat→Bool) : ((!g1322 E)=true) ↔ 3≤countTrue (score2_vals9 E) := by
  have rew : (!g1322 E) = ((!g1308 E) || ((g389 E) && (!g1306 E))) := by simp [g1,g1321,g1322,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold8_2 E
  have T0 := score2_threshold8_1 E
  exact threshold_step (g389 E) (!g1308 E) (!g1306 E) 2 (countTrue (score2_vals8 E)) T1 T0
theorem score2_threshold10_3 (E : Nat→Bool) : ((!g1340 E)=true) ↔ 4≤countTrue (score2_vals10 E) := by
  have rew : (!g1340 E) = ((!g1324 E) || ((g390 E) && (!g1322 E))) := by simp [g1,g1339,g1340,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold9_3 E
  have T0 := score2_threshold9_2 E
  exact threshold_step (g390 E) (!g1324 E) (!g1322 E) 3 (countTrue (score2_vals9 E)) T1 T0
theorem score2_threshold8_0 (E : Nat→Bool) : ((!g1304 E)=true) ↔ 1≤countTrue (score2_vals8 E) := by
  have rew : (!g1304 E) = ((!g1292 E) || ((g388 E) && (g1 E))) := by simp [g1,g1304,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold7_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals7 E) := by simp [g1]
  exact threshold_step (g388 E) (!g1292 E) (g1 E) 0 (countTrue (score2_vals7 E)) T1 T0
theorem score2_threshold9_1 (E : Nat→Bool) : ((!g1320 E)=true) ↔ 2≤countTrue (score2_vals9 E) := by
  have rew : (!g1320 E) = ((!g1306 E) || ((g389 E) && (!g1304 E))) := by simp [g1,g1319,g1320,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold8_1 E
  have T0 := score2_threshold8_0 E
  exact threshold_step (g389 E) (!g1306 E) (!g1304 E) 1 (countTrue (score2_vals8 E)) T1 T0
theorem score2_threshold10_2 (E : Nat→Bool) : ((!g1338 E)=true) ↔ 3≤countTrue (score2_vals10 E) := by
  have rew : (!g1338 E) = ((!g1322 E) || ((g390 E) && (!g1320 E))) := by simp [g1,g1337,g1338,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold9_2 E
  have T0 := score2_threshold9_1 E
  exact threshold_step (g390 E) (!g1322 E) (!g1320 E) 2 (countTrue (score2_vals9 E)) T1 T0
theorem score2_threshold11_3 (E : Nat→Bool) : ((!g1358 E)=true) ↔ 4≤countTrue (score2_vals11 E) := by
  have rew : (!g1358 E) = ((!g1340 E) || ((g391 E) && (!g1338 E))) := by simp [g1,g1357,g1358,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold10_3 E
  have T0 := score2_threshold10_2 E
  exact threshold_step (g391 E) (!g1340 E) (!g1338 E) 3 (countTrue (score2_vals10 E)) T1 T0
theorem score2_threshold9_0 (E : Nat→Bool) : ((!g1318 E)=true) ↔ 1≤countTrue (score2_vals9 E) := by
  have rew : (!g1318 E) = ((!g1304 E) || ((g389 E) && (g1 E))) := by simp [g1,g1318,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold8_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals8 E) := by simp [g1]
  exact threshold_step (g389 E) (!g1304 E) (g1 E) 0 (countTrue (score2_vals8 E)) T1 T0
theorem score2_threshold10_1 (E : Nat→Bool) : ((!g1336 E)=true) ↔ 2≤countTrue (score2_vals10 E) := by
  have rew : (!g1336 E) = ((!g1320 E) || ((g390 E) && (!g1318 E))) := by simp [g1,g1335,g1336,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold9_1 E
  have T0 := score2_threshold9_0 E
  exact threshold_step (g390 E) (!g1320 E) (!g1318 E) 1 (countTrue (score2_vals9 E)) T1 T0
theorem score2_threshold11_2 (E : Nat→Bool) : ((!g1356 E)=true) ↔ 3≤countTrue (score2_vals11 E) := by
  have rew : (!g1356 E) = ((!g1338 E) || ((g391 E) && (!g1336 E))) := by simp [g1,g1355,g1356,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold10_2 E
  have T0 := score2_threshold10_1 E
  exact threshold_step (g391 E) (!g1338 E) (!g1336 E) 2 (countTrue (score2_vals10 E)) T1 T0
theorem score2_threshold12_3 (E : Nat→Bool) : ((!g1378 E)=true) ↔ 4≤countTrue (score2_vals12 E) := by
  have rew : (!g1378 E) = ((!g1358 E) || ((g402 E) && (!g1356 E))) := by simp [g1,g1377,g1378,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold11_3 E
  have T0 := score2_threshold11_2 E
  exact threshold_step (g402 E) (!g1358 E) (!g1356 E) 3 (countTrue (score2_vals11 E)) T1 T0
theorem score2_threshold10_0 (E : Nat→Bool) : ((!g1334 E)=true) ↔ 1≤countTrue (score2_vals10 E) := by
  have rew : (!g1334 E) = ((!g1318 E) || ((g390 E) && (g1 E))) := by simp [g1,g1334,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold9_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals9 E) := by simp [g1]
  exact threshold_step (g390 E) (!g1318 E) (g1 E) 0 (countTrue (score2_vals9 E)) T1 T0
theorem score2_threshold11_1 (E : Nat→Bool) : ((!g1354 E)=true) ↔ 2≤countTrue (score2_vals11 E) := by
  have rew : (!g1354 E) = ((!g1336 E) || ((g391 E) && (!g1334 E))) := by simp [g1,g1353,g1354,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold10_1 E
  have T0 := score2_threshold10_0 E
  exact threshold_step (g391 E) (!g1336 E) (!g1334 E) 1 (countTrue (score2_vals10 E)) T1 T0
theorem score2_threshold12_2 (E : Nat→Bool) : ((!g1376 E)=true) ↔ 3≤countTrue (score2_vals12 E) := by
  have rew : (!g1376 E) = ((!g1356 E) || ((g402 E) && (!g1354 E))) := by simp [g1,g1375,g1376,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold11_2 E
  have T0 := score2_threshold11_1 E
  exact threshold_step (g402 E) (!g1356 E) (!g1354 E) 2 (countTrue (score2_vals11 E)) T1 T0
theorem score2_threshold13_3 (E : Nat→Bool) : ((!g1400 E)=true) ↔ 4≤countTrue (score2_vals13 E) := by
  have rew : (!g1400 E) = ((!g1378 E) || ((g403 E) && (!g1376 E))) := by simp [g1,g1399,g1400,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold12_3 E
  have T0 := score2_threshold12_2 E
  exact threshold_step (g403 E) (!g1378 E) (!g1376 E) 3 (countTrue (score2_vals12 E)) T1 T0
theorem score2_threshold11_0 (E : Nat→Bool) : ((!g1352 E)=true) ↔ 1≤countTrue (score2_vals11 E) := by
  have rew : (!g1352 E) = ((!g1334 E) || ((g391 E) && (g1 E))) := by simp [g1,g1352,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold10_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals10 E) := by simp [g1]
  exact threshold_step (g391 E) (!g1334 E) (g1 E) 0 (countTrue (score2_vals10 E)) T1 T0
theorem score2_threshold12_1 (E : Nat→Bool) : ((!g1374 E)=true) ↔ 2≤countTrue (score2_vals12 E) := by
  have rew : (!g1374 E) = ((!g1354 E) || ((g402 E) && (!g1352 E))) := by simp [g1,g1373,g1374,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold11_1 E
  have T0 := score2_threshold11_0 E
  exact threshold_step (g402 E) (!g1354 E) (!g1352 E) 1 (countTrue (score2_vals11 E)) T1 T0
theorem score2_threshold13_2 (E : Nat→Bool) : ((!g1398 E)=true) ↔ 3≤countTrue (score2_vals13 E) := by
  have rew : (!g1398 E) = ((!g1376 E) || ((g403 E) && (!g1374 E))) := by simp [g1,g1397,g1398,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold12_2 E
  have T0 := score2_threshold12_1 E
  exact threshold_step (g403 E) (!g1376 E) (!g1374 E) 2 (countTrue (score2_vals12 E)) T1 T0
theorem score2_threshold14_3 (E : Nat→Bool) : ((!g1424 E)=true) ↔ 4≤countTrue (score2_vals14 E) := by
  have rew : (!g1424 E) = ((!g1400 E) || ((g404 E) && (!g1398 E))) := by simp [g1,g1423,g1424,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold13_3 E
  have T0 := score2_threshold13_2 E
  exact threshold_step (g404 E) (!g1400 E) (!g1398 E) 3 (countTrue (score2_vals13 E)) T1 T0
theorem score2_threshold12_0 (E : Nat→Bool) : ((!g1372 E)=true) ↔ 1≤countTrue (score2_vals12 E) := by
  have rew : (!g1372 E) = ((!g1352 E) || ((g402 E) && (g1 E))) := by simp [g1,g1372,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold11_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals11 E) := by simp [g1]
  exact threshold_step (g402 E) (!g1352 E) (g1 E) 0 (countTrue (score2_vals11 E)) T1 T0
theorem score2_threshold13_1 (E : Nat→Bool) : ((!g1396 E)=true) ↔ 2≤countTrue (score2_vals13 E) := by
  have rew : (!g1396 E) = ((!g1374 E) || ((g403 E) && (!g1372 E))) := by simp [g1,g1395,g1396,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold12_1 E
  have T0 := score2_threshold12_0 E
  exact threshold_step (g403 E) (!g1374 E) (!g1372 E) 1 (countTrue (score2_vals12 E)) T1 T0
theorem score2_threshold14_2 (E : Nat→Bool) : ((!g1422 E)=true) ↔ 3≤countTrue (score2_vals14 E) := by
  have rew : (!g1422 E) = ((!g1398 E) || ((g404 E) && (!g1396 E))) := by simp [g1,g1421,g1422,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold13_2 E
  have T0 := score2_threshold13_1 E
  exact threshold_step (g404 E) (!g1398 E) (!g1396 E) 2 (countTrue (score2_vals13 E)) T1 T0
theorem score2_threshold15_3 (E : Nat→Bool) : ((!g1450 E)=true) ↔ 4≤countTrue (score2_vals15 E) := by
  have rew : (!g1450 E) = ((!g1424 E) || ((g405 E) && (!g1422 E))) := by simp [g1,g1449,g1450,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold14_3 E
  have T0 := score2_threshold14_2 E
  exact threshold_step (g405 E) (!g1424 E) (!g1422 E) 3 (countTrue (score2_vals14 E)) T1 T0
theorem score2_threshold13_0 (E : Nat→Bool) : ((!g1394 E)=true) ↔ 1≤countTrue (score2_vals13 E) := by
  have rew : (!g1394 E) = ((!g1372 E) || ((g403 E) && (g1 E))) := by simp [g1,g1394,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold12_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals12 E) := by simp [g1]
  exact threshold_step (g403 E) (!g1372 E) (g1 E) 0 (countTrue (score2_vals12 E)) T1 T0
theorem score2_threshold14_1 (E : Nat→Bool) : ((!g1420 E)=true) ↔ 2≤countTrue (score2_vals14 E) := by
  have rew : (!g1420 E) = ((!g1396 E) || ((g404 E) && (!g1394 E))) := by simp [g1,g1419,g1420,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold13_1 E
  have T0 := score2_threshold13_0 E
  exact threshold_step (g404 E) (!g1396 E) (!g1394 E) 1 (countTrue (score2_vals13 E)) T1 T0
theorem score2_threshold15_2 (E : Nat→Bool) : ((!g1448 E)=true) ↔ 3≤countTrue (score2_vals15 E) := by
  have rew : (!g1448 E) = ((!g1422 E) || ((g405 E) && (!g1420 E))) := by simp [g1,g1447,g1448,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold14_2 E
  have T0 := score2_threshold14_1 E
  exact threshold_step (g405 E) (!g1422 E) (!g1420 E) 2 (countTrue (score2_vals14 E)) T1 T0
theorem score2_threshold16_3 (E : Nat→Bool) : ((!g1478 E)=true) ↔ 4≤countTrue (score2_vals16 E) := by
  have rew : (!g1478 E) = ((!g1450 E) || ((g406 E) && (!g1448 E))) := by simp [g1,g1477,g1478,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold15_3 E
  have T0 := score2_threshold15_2 E
  exact threshold_step (g406 E) (!g1450 E) (!g1448 E) 3 (countTrue (score2_vals15 E)) T1 T0
theorem score2_threshold14_0 (E : Nat→Bool) : ((!g1418 E)=true) ↔ 1≤countTrue (score2_vals14 E) := by
  have rew : (!g1418 E) = ((!g1394 E) || ((g404 E) && (g1 E))) := by simp [g1,g1418,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold13_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals13 E) := by simp [g1]
  exact threshold_step (g404 E) (!g1394 E) (g1 E) 0 (countTrue (score2_vals13 E)) T1 T0
theorem score2_threshold15_1 (E : Nat→Bool) : ((!g1446 E)=true) ↔ 2≤countTrue (score2_vals15 E) := by
  have rew : (!g1446 E) = ((!g1420 E) || ((g405 E) && (!g1418 E))) := by simp [g1,g1445,g1446,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold14_1 E
  have T0 := score2_threshold14_0 E
  exact threshold_step (g405 E) (!g1420 E) (!g1418 E) 1 (countTrue (score2_vals14 E)) T1 T0
theorem score2_threshold16_2 (E : Nat→Bool) : ((!g1476 E)=true) ↔ 3≤countTrue (score2_vals16 E) := by
  have rew : (!g1476 E) = ((!g1448 E) || ((g406 E) && (!g1446 E))) := by simp [g1,g1475,g1476,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold15_2 E
  have T0 := score2_threshold15_1 E
  exact threshold_step (g406 E) (!g1448 E) (!g1446 E) 2 (countTrue (score2_vals15 E)) T1 T0
theorem score2_threshold17_3 (E : Nat→Bool) : ((!g1508 E)=true) ↔ 4≤countTrue (score2_vals17 E) := by
  have rew : (!g1508 E) = ((!g1478 E) || ((g407 E) && (!g1476 E))) := by simp [g1,g1507,g1508,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold16_3 E
  have T0 := score2_threshold16_2 E
  exact threshold_step (g407 E) (!g1478 E) (!g1476 E) 3 (countTrue (score2_vals16 E)) T1 T0
theorem score2_threshold15_0 (E : Nat→Bool) : ((!g1444 E)=true) ↔ 1≤countTrue (score2_vals15 E) := by
  have rew : (!g1444 E) = ((!g1418 E) || ((g405 E) && (g1 E))) := by simp [g1,g1444,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold14_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals14 E) := by simp [g1]
  exact threshold_step (g405 E) (!g1418 E) (g1 E) 0 (countTrue (score2_vals14 E)) T1 T0
theorem score2_threshold16_1 (E : Nat→Bool) : ((!g1474 E)=true) ↔ 2≤countTrue (score2_vals16 E) := by
  have rew : (!g1474 E) = ((!g1446 E) || ((g406 E) && (!g1444 E))) := by simp [g1,g1473,g1474,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold15_1 E
  have T0 := score2_threshold15_0 E
  exact threshold_step (g406 E) (!g1446 E) (!g1444 E) 1 (countTrue (score2_vals15 E)) T1 T0
theorem score2_threshold17_2 (E : Nat→Bool) : ((!g1506 E)=true) ↔ 3≤countTrue (score2_vals17 E) := by
  have rew : (!g1506 E) = ((!g1476 E) || ((g407 E) && (!g1474 E))) := by simp [g1,g1505,g1506,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold16_2 E
  have T0 := score2_threshold16_1 E
  exact threshold_step (g407 E) (!g1476 E) (!g1474 E) 2 (countTrue (score2_vals16 E)) T1 T0
theorem score2_threshold18_3 (E : Nat→Bool) : ((!g1540 E)=true) ↔ 4≤countTrue (score2_vals18 E) := by
  have rew : (!g1540 E) = ((!g1508 E) || ((g408 E) && (!g1506 E))) := by simp [g1,g1539,g1540,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold17_3 E
  have T0 := score2_threshold17_2 E
  exact threshold_step (g408 E) (!g1508 E) (!g1506 E) 3 (countTrue (score2_vals17 E)) T1 T0
theorem score2_threshold16_0 (E : Nat→Bool) : ((!g1472 E)=true) ↔ 1≤countTrue (score2_vals16 E) := by
  have rew : (!g1472 E) = ((!g1444 E) || ((g406 E) && (g1 E))) := by simp [g1,g1472,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold15_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals15 E) := by simp [g1]
  exact threshold_step (g406 E) (!g1444 E) (g1 E) 0 (countTrue (score2_vals15 E)) T1 T0
theorem score2_threshold17_1 (E : Nat→Bool) : ((!g1504 E)=true) ↔ 2≤countTrue (score2_vals17 E) := by
  have rew : (!g1504 E) = ((!g1474 E) || ((g407 E) && (!g1472 E))) := by simp [g1,g1503,g1504,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold16_1 E
  have T0 := score2_threshold16_0 E
  exact threshold_step (g407 E) (!g1474 E) (!g1472 E) 1 (countTrue (score2_vals16 E)) T1 T0
theorem score2_threshold18_2 (E : Nat→Bool) : ((!g1538 E)=true) ↔ 3≤countTrue (score2_vals18 E) := by
  have rew : (!g1538 E) = ((!g1506 E) || ((g408 E) && (!g1504 E))) := by simp [g1,g1537,g1538,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold17_2 E
  have T0 := score2_threshold17_1 E
  exact threshold_step (g408 E) (!g1506 E) (!g1504 E) 2 (countTrue (score2_vals17 E)) T1 T0
theorem score2_threshold19_3 (E : Nat→Bool) : ((!g1574 E)=true) ↔ 4≤countTrue (score2_vals19 E) := by
  have rew : (!g1574 E) = ((!g1540 E) || ((g409 E) && (!g1538 E))) := by simp [g1,g1573,g1574,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold18_3 E
  have T0 := score2_threshold18_2 E
  exact threshold_step (g409 E) (!g1540 E) (!g1538 E) 3 (countTrue (score2_vals18 E)) T1 T0
theorem score2_threshold17_0 (E : Nat→Bool) : ((!g1502 E)=true) ↔ 1≤countTrue (score2_vals17 E) := by
  have rew : (!g1502 E) = ((!g1472 E) || ((g407 E) && (g1 E))) := by simp [g1,g1502,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold16_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals16 E) := by simp [g1]
  exact threshold_step (g407 E) (!g1472 E) (g1 E) 0 (countTrue (score2_vals16 E)) T1 T0
theorem score2_threshold18_1 (E : Nat→Bool) : ((!g1536 E)=true) ↔ 2≤countTrue (score2_vals18 E) := by
  have rew : (!g1536 E) = ((!g1504 E) || ((g408 E) && (!g1502 E))) := by simp [g1,g1535,g1536,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold17_1 E
  have T0 := score2_threshold17_0 E
  exact threshold_step (g408 E) (!g1504 E) (!g1502 E) 1 (countTrue (score2_vals17 E)) T1 T0
theorem score2_threshold19_2 (E : Nat→Bool) : ((!g1572 E)=true) ↔ 3≤countTrue (score2_vals19 E) := by
  have rew : (!g1572 E) = ((!g1538 E) || ((g409 E) && (!g1536 E))) := by simp [g1,g1571,g1572,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold18_2 E
  have T0 := score2_threshold18_1 E
  exact threshold_step (g409 E) (!g1538 E) (!g1536 E) 2 (countTrue (score2_vals18 E)) T1 T0
theorem score2_threshold20_3 (E : Nat→Bool) : ((!g1610 E)=true) ↔ 4≤countTrue (score2_vals20 E) := by
  have rew : (!g1610 E) = ((!g1574 E) || ((g410 E) && (!g1572 E))) := by simp [g1,g1609,g1610,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold19_3 E
  have T0 := score2_threshold19_2 E
  exact threshold_step (g410 E) (!g1574 E) (!g1572 E) 3 (countTrue (score2_vals19 E)) T1 T0
theorem score2_threshold18_0 (E : Nat→Bool) : ((!g1534 E)=true) ↔ 1≤countTrue (score2_vals18 E) := by
  have rew : (!g1534 E) = ((!g1502 E) || ((g408 E) && (g1 E))) := by simp [g1,g1534,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold17_0 E
  have T0 : (g1 E)=true ↔ 0≤countTrue (score2_vals17 E) := by simp [g1]
  exact threshold_step (g408 E) (!g1502 E) (g1 E) 0 (countTrue (score2_vals17 E)) T1 T0
theorem score2_threshold19_1 (E : Nat→Bool) : ((!g1570 E)=true) ↔ 2≤countTrue (score2_vals19 E) := by
  have rew : (!g1570 E) = ((!g1536 E) || ((g409 E) && (!g1534 E))) := by simp [g1,g1569,g1570,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold18_1 E
  have T0 := score2_threshold18_0 E
  exact threshold_step (g409 E) (!g1536 E) (!g1534 E) 1 (countTrue (score2_vals18 E)) T1 T0
theorem score2_threshold20_2 (E : Nat→Bool) : ((!g1608 E)=true) ↔ 3≤countTrue (score2_vals20 E) := by
  have rew : (!g1608 E) = ((!g1572 E) || ((g410 E) && (!g1570 E))) := by simp [g1,g1607,g1608,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold19_2 E
  have T0 := score2_threshold19_1 E
  exact threshold_step (g410 E) (!g1572 E) (!g1570 E) 2 (countTrue (score2_vals19 E)) T1 T0
theorem score2_threshold21_3 (E : Nat→Bool) : ((!g1648 E)=true) ↔ 4≤countTrue (score2_vals21 E) := by
  have rew : (!g1648 E) = ((!g1610 E) || ((g411 E) && (!g1608 E))) := by simp [g1,g1647,g1648,Bool.and_comm, Bool.or_comm, Bool.not_and]
  rw [rew]
  have T1 := score2_threshold20_3 E
  have T0 := score2_threshold20_2 E
  exact threshold_step (g411 E) (!g1610 E) (!g1608 E) 3 (countTrue (score2_vals20 E)) T1 T0
def score2_count (E : Nat→Bool) : Nat := countTrue (score2_vals21 E)
end Graffiti384b.DiversityEleven.PendantCircuit.K3
