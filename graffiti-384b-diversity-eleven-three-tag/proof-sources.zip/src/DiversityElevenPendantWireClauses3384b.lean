import DiversityElevenPendantWires3384b
import DiversityElevenPendantRupThree384b
namespace Graffiti384b.DiversityEleven.PendantCircuit.K3
open Sat
set_option maxRecDepth 32768
set_option maxHeartbeats 20000000

private theorem pattern_0 (x0 x1 : Bool) : (¬ (x0=true)) → (¬ (x1=true)) → (¬ (((!x1) && (!x0))=true)) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_0 (E : Nat → Bool) : (valuation E).satisfies [.pos 1, .pos 2, .pos 29] := by
  change (¬ (g2 E = true)) → (¬ (g3 E = true)) → (¬ (g30 E = true)) → False
  exact pattern_0 (g2 E) (g3 E)
private theorem pattern_1 (x0 x1 : Bool) : (((x0) && (x1))=true) → (¬ (x0=true)) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_1 (E : Nat → Bool) : (valuation E).satisfies [.neg 30, .pos 1] := by
  change (g31 E = true) → (¬ (g2 E = true)) → False
  exact pattern_1 (g2 E) (g3 E)
private theorem pattern_2 (x0 x1 : Bool) : (((x0) && (x1))=true) → (¬ (x1=true)) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_2 (E : Nat → Bool) : (valuation E).satisfies [.neg 30, .pos 2] := by
  change (g31 E = true) → (¬ (g3 E = true)) → False
  exact pattern_2 (g2 E) (g3 E)
private theorem pattern_3 (x0 x1 : Bool) : (x1=true) → (¬ (x0=true)) → (¬ (((!x0) && (x1))=true)) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_3 (E : Nat → Bool) : (valuation E).satisfies [.neg 29, .pos 3, .pos 31] := by
  change (g30 E = true) → (¬ (g4 E = true)) → (¬ (g32 E = true)) → False
  exact pattern_3 (g4 E) (g30 E)
private theorem pattern_4 (x0 x1 : Bool) : (((!x1) && (x0))=true) → (x1=true) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_4 (E : Nat → Bool) : (valuation E).satisfies [.neg 32, .neg 29] := by
  change (g33 E = true) → (g30 E = true) → False
  exact pattern_4 (g4 E) (g30 E)
private theorem pattern_5 (x0 x1 : Bool) : (((!x1) && (x0))=true) → (¬ (x0=true)) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_5 (E : Nat → Bool) : (valuation E).satisfies [.neg 32, .pos 3] := by
  change (g33 E = true) → (¬ (g4 E = true)) → False
  exact pattern_5 (g4 E) (g30 E)
private theorem sat_6 (E : Nat → Bool) : (valuation E).satisfies [.pos 30, .pos 32, .pos 33] := by
  change (¬ (g31 E = true)) → (¬ (g33 E = true)) → (¬ (g34 E = true)) → False
  exact pattern_0 (g31 E) (g33 E)
private theorem sat_7 (E : Nat → Bool) : (valuation E).satisfies [.neg 34, .pos 3] := by
  change (g35 E = true) → (¬ (g4 E = true)) → False
  exact pattern_1 (g4 E) (g31 E)
private theorem sat_8 (E : Nat → Bool) : (valuation E).satisfies [.neg 34, .pos 30] := by
  change (g35 E = true) → (¬ (g31 E = true)) → False
  exact pattern_2 (g4 E) (g31 E)
private theorem sat_9 (E : Nat → Bool) : (valuation E).satisfies [.neg 31, .pos 4, .pos 35] := by
  change (g32 E = true) → (¬ (g5 E = true)) → (¬ (g36 E = true)) → False
  exact pattern_3 (g5 E) (g32 E)
private theorem sat_10 (E : Nat → Bool) : (valuation E).satisfies [.neg 36, .pos 4] := by
  change (g37 E = true) → (¬ (g5 E = true)) → False
  exact pattern_5 (g5 E) (g32 E)
private theorem pattern_6 (x0 x1 : Bool) : (x0=true) → (¬ (x1=true)) → (¬ (((!x1) && (x0))=true)) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_11 (E : Nat → Bool) : (valuation E).satisfies [.neg 33, .pos 36, .pos 37] := by
  change (g34 E = true) → (¬ (g37 E = true)) → (¬ (g38 E = true)) → False
  exact pattern_6 (g34 E) (g37 E)
private theorem sat_12 (E : Nat → Bool) : (valuation E).satisfies [.neg 38, .neg 33] := by
  change (g39 E = true) → (g34 E = true) → False
  exact pattern_4 (g5 E) (g34 E)
private theorem sat_13 (E : Nat → Bool) : (valuation E).satisfies [.neg 38, .pos 4] := by
  change (g39 E = true) → (¬ (g5 E = true)) → False
  exact pattern_5 (g5 E) (g34 E)
private theorem sat_14 (E : Nat → Bool) : (valuation E).satisfies [.pos 34, .pos 38, .pos 39] := by
  change (¬ (g35 E = true)) → (¬ (g39 E = true)) → (¬ (g40 E = true)) → False
  exact pattern_0 (g35 E) (g39 E)
private theorem sat_15 (E : Nat → Bool) : (valuation E).satisfies [.neg 35, .pos 5, .pos 41] := by
  change (g36 E = true) → (¬ (g6 E = true)) → (¬ (g42 E = true)) → False
  exact pattern_3 (g6 E) (g36 E)
private theorem sat_16 (E : Nat → Bool) : (valuation E).satisfies [.neg 42, .pos 5] := by
  change (g43 E = true) → (¬ (g6 E = true)) → False
  exact pattern_5 (g6 E) (g36 E)
private theorem sat_17 (E : Nat → Bool) : (valuation E).satisfies [.neg 37, .pos 42, .pos 43] := by
  change (g38 E = true) → (¬ (g43 E = true)) → (¬ (g44 E = true)) → False
  exact pattern_6 (g38 E) (g43 E)
private theorem sat_18 (E : Nat → Bool) : (valuation E).satisfies [.neg 44, .pos 5] := by
  change (g45 E = true) → (¬ (g6 E = true)) → False
  exact pattern_5 (g6 E) (g38 E)
private theorem sat_19 (E : Nat → Bool) : (valuation E).satisfies [.neg 39, .pos 44, .pos 45] := by
  change (g40 E = true) → (¬ (g45 E = true)) → (¬ (g46 E = true)) → False
  exact pattern_6 (g40 E) (g45 E)
private theorem sat_20 (E : Nat → Bool) : (valuation E).satisfies [.neg 50, .neg 41] := by
  change (g51 E = true) → (g42 E = true) → False
  exact pattern_4 (g7 E) (g42 E)
private theorem sat_21 (E : Nat → Bool) : (valuation E).satisfies [.neg 50, .pos 6] := by
  change (g51 E = true) → (¬ (g7 E = true)) → False
  exact pattern_5 (g7 E) (g42 E)
private theorem sat_22 (E : Nat → Bool) : (valuation E).satisfies [.neg 43, .pos 50, .pos 51] := by
  change (g44 E = true) → (¬ (g51 E = true)) → (¬ (g52 E = true)) → False
  exact pattern_6 (g44 E) (g51 E)
private theorem sat_23 (E : Nat → Bool) : (valuation E).satisfies [.neg 52, .neg 43] := by
  change (g53 E = true) → (g44 E = true) → False
  exact pattern_4 (g7 E) (g44 E)
private theorem sat_24 (E : Nat → Bool) : (valuation E).satisfies [.neg 52, .pos 6] := by
  change (g53 E = true) → (¬ (g7 E = true)) → False
  exact pattern_5 (g7 E) (g44 E)
private theorem sat_25 (E : Nat → Bool) : (valuation E).satisfies [.neg 45, .pos 52, .pos 53] := by
  change (g46 E = true) → (¬ (g53 E = true)) → (¬ (g54 E = true)) → False
  exact pattern_6 (g46 E) (g53 E)
private theorem sat_26 (E : Nat → Bool) : (valuation E).satisfies [.neg 62, .neg 51] := by
  change (g63 E = true) → (g52 E = true) → False
  exact pattern_4 (g8 E) (g52 E)
private theorem sat_27 (E : Nat → Bool) : (valuation E).satisfies [.neg 62, .pos 7] := by
  change (g63 E = true) → (¬ (g8 E = true)) → False
  exact pattern_5 (g8 E) (g52 E)
private theorem sat_28 (E : Nat → Bool) : (valuation E).satisfies [.neg 53, .pos 62, .pos 63] := by
  change (g54 E = true) → (¬ (g63 E = true)) → (¬ (g64 E = true)) → False
  exact pattern_6 (g54 E) (g63 E)
private theorem sat_30 (E : Nat → Bool) : (valuation E).satisfies [.pos 1, .pos 8, .pos 71] := by
  change (¬ (g2 E = true)) → (¬ (g9 E = true)) → (¬ (g72 E = true)) → False
  exact pattern_0 (g2 E) (g9 E)
private theorem sat_31 (E : Nat → Bool) : (valuation E).satisfies [.neg 72, .pos 1] := by
  change (g73 E = true) → (¬ (g2 E = true)) → False
  exact pattern_1 (g2 E) (g9 E)
private theorem sat_32 (E : Nat → Bool) : (valuation E).satisfies [.neg 72, .pos 8] := by
  change (g73 E = true) → (¬ (g9 E = true)) → False
  exact pattern_2 (g2 E) (g9 E)
private theorem sat_33 (E : Nat → Bool) : (valuation E).satisfies [.neg 71, .pos 9, .pos 73] := by
  change (g72 E = true) → (¬ (g10 E = true)) → (¬ (g74 E = true)) → False
  exact pattern_3 (g10 E) (g72 E)
private theorem sat_34 (E : Nat → Bool) : (valuation E).satisfies [.neg 74, .pos 9] := by
  change (g75 E = true) → (¬ (g10 E = true)) → False
  exact pattern_5 (g10 E) (g72 E)
private theorem sat_35 (E : Nat → Bool) : (valuation E).satisfies [.pos 72, .pos 74, .pos 75] := by
  change (¬ (g73 E = true)) → (¬ (g75 E = true)) → (¬ (g76 E = true)) → False
  exact pattern_0 (g73 E) (g75 E)
private theorem sat_36 (E : Nat → Bool) : (valuation E).satisfies [.neg 76, .pos 9] := by
  change (g77 E = true) → (¬ (g10 E = true)) → False
  exact pattern_1 (g10 E) (g73 E)
private theorem sat_37 (E : Nat → Bool) : (valuation E).satisfies [.neg 76, .pos 72] := by
  change (g77 E = true) → (¬ (g73 E = true)) → False
  exact pattern_2 (g10 E) (g73 E)
private theorem sat_38 (E : Nat → Bool) : (valuation E).satisfies [.neg 73, .pos 10, .pos 77] := by
  change (g74 E = true) → (¬ (g11 E = true)) → (¬ (g78 E = true)) → False
  exact pattern_3 (g11 E) (g74 E)
private theorem sat_39 (E : Nat → Bool) : (valuation E).satisfies [.neg 78, .neg 73] := by
  change (g79 E = true) → (g74 E = true) → False
  exact pattern_4 (g11 E) (g74 E)
private theorem sat_40 (E : Nat → Bool) : (valuation E).satisfies [.neg 78, .pos 10] := by
  change (g79 E = true) → (¬ (g11 E = true)) → False
  exact pattern_5 (g11 E) (g74 E)
private theorem sat_41 (E : Nat → Bool) : (valuation E).satisfies [.neg 75, .pos 78, .pos 79] := by
  change (g76 E = true) → (¬ (g79 E = true)) → (¬ (g80 E = true)) → False
  exact pattern_6 (g76 E) (g79 E)
private theorem sat_42 (E : Nat → Bool) : (valuation E).satisfies [.neg 80, .neg 75] := by
  change (g81 E = true) → (g76 E = true) → False
  exact pattern_4 (g11 E) (g76 E)
private theorem sat_43 (E : Nat → Bool) : (valuation E).satisfies [.neg 80, .pos 10] := by
  change (g81 E = true) → (¬ (g11 E = true)) → False
  exact pattern_5 (g11 E) (g76 E)
private theorem sat_44 (E : Nat → Bool) : (valuation E).satisfies [.pos 76, .pos 80, .pos 81] := by
  change (¬ (g77 E = true)) → (¬ (g81 E = true)) → (¬ (g82 E = true)) → False
  exact pattern_0 (g77 E) (g81 E)
private theorem sat_45 (E : Nat → Bool) : (valuation E).satisfies [.neg 77, .pos 11, .pos 83] := by
  change (g78 E = true) → (¬ (g12 E = true)) → (¬ (g84 E = true)) → False
  exact pattern_3 (g12 E) (g78 E)
private theorem sat_46 (E : Nat → Bool) : (valuation E).satisfies [.neg 84, .pos 11] := by
  change (g85 E = true) → (¬ (g12 E = true)) → False
  exact pattern_5 (g12 E) (g78 E)
private theorem sat_47 (E : Nat → Bool) : (valuation E).satisfies [.neg 79, .pos 84, .pos 85] := by
  change (g80 E = true) → (¬ (g85 E = true)) → (¬ (g86 E = true)) → False
  exact pattern_6 (g80 E) (g85 E)
private theorem sat_48 (E : Nat → Bool) : (valuation E).satisfies [.neg 86, .neg 79] := by
  change (g87 E = true) → (g80 E = true) → False
  exact pattern_4 (g12 E) (g80 E)
private theorem sat_49 (E : Nat → Bool) : (valuation E).satisfies [.neg 86, .pos 11] := by
  change (g87 E = true) → (¬ (g12 E = true)) → False
  exact pattern_5 (g12 E) (g80 E)
private theorem sat_50 (E : Nat → Bool) : (valuation E).satisfies [.neg 81, .pos 86, .pos 87] := by
  change (g82 E = true) → (¬ (g87 E = true)) → (¬ (g88 E = true)) → False
  exact pattern_6 (g82 E) (g87 E)
private theorem sat_51 (E : Nat → Bool) : (valuation E).satisfies [.neg 92, .neg 83] := by
  change (g93 E = true) → (g84 E = true) → False
  exact pattern_4 (g13 E) (g84 E)
private theorem sat_52 (E : Nat → Bool) : (valuation E).satisfies [.neg 92, .pos 12] := by
  change (g93 E = true) → (¬ (g13 E = true)) → False
  exact pattern_5 (g13 E) (g84 E)
private theorem sat_53 (E : Nat → Bool) : (valuation E).satisfies [.neg 85, .pos 92, .pos 93] := by
  change (g86 E = true) → (¬ (g93 E = true)) → (¬ (g94 E = true)) → False
  exact pattern_6 (g86 E) (g93 E)
private theorem sat_54 (E : Nat → Bool) : (valuation E).satisfies [.neg 94, .neg 85] := by
  change (g95 E = true) → (g86 E = true) → False
  exact pattern_4 (g13 E) (g86 E)
private theorem sat_55 (E : Nat → Bool) : (valuation E).satisfies [.neg 94, .pos 12] := by
  change (g95 E = true) → (¬ (g13 E = true)) → False
  exact pattern_5 (g13 E) (g86 E)
private theorem sat_56 (E : Nat → Bool) : (valuation E).satisfies [.neg 87, .pos 94, .pos 95] := by
  change (g88 E = true) → (¬ (g95 E = true)) → (¬ (g96 E = true)) → False
  exact pattern_6 (g88 E) (g95 E)
private theorem sat_57 (E : Nat → Bool) : (valuation E).satisfies [.neg 104, .neg 93] := by
  change (g105 E = true) → (g94 E = true) → False
  exact pattern_4 (g14 E) (g94 E)
private theorem sat_58 (E : Nat → Bool) : (valuation E).satisfies [.neg 104, .pos 13] := by
  change (g105 E = true) → (¬ (g14 E = true)) → False
  exact pattern_5 (g14 E) (g94 E)
private theorem sat_59 (E : Nat → Bool) : (valuation E).satisfies [.neg 95, .pos 104, .pos 105] := by
  change (g96 E = true) → (¬ (g105 E = true)) → (¬ (g106 E = true)) → False
  exact pattern_6 (g96 E) (g105 E)
private theorem sat_61 (E : Nat → Bool) : (valuation E).satisfies [.pos 2, .pos 8, .pos 113] := by
  change (¬ (g3 E = true)) → (¬ (g9 E = true)) → (¬ (g114 E = true)) → False
  exact pattern_0 (g3 E) (g9 E)
private theorem sat_62 (E : Nat → Bool) : (valuation E).satisfies [.neg 114, .pos 2] := by
  change (g115 E = true) → (¬ (g3 E = true)) → False
  exact pattern_1 (g3 E) (g9 E)
private theorem sat_63 (E : Nat → Bool) : (valuation E).satisfies [.neg 114, .pos 8] := by
  change (g115 E = true) → (¬ (g9 E = true)) → False
  exact pattern_2 (g3 E) (g9 E)
private theorem sat_64 (E : Nat → Bool) : (valuation E).satisfies [.neg 113, .pos 14, .pos 115] := by
  change (g114 E = true) → (¬ (g15 E = true)) → (¬ (g116 E = true)) → False
  exact pattern_3 (g15 E) (g114 E)
private theorem sat_65 (E : Nat → Bool) : (valuation E).satisfies [.neg 116, .pos 14] := by
  change (g117 E = true) → (¬ (g15 E = true)) → False
  exact pattern_5 (g15 E) (g114 E)
private theorem sat_66 (E : Nat → Bool) : (valuation E).satisfies [.pos 114, .pos 116, .pos 117] := by
  change (¬ (g115 E = true)) → (¬ (g117 E = true)) → (¬ (g118 E = true)) → False
  exact pattern_0 (g115 E) (g117 E)
private theorem sat_67 (E : Nat → Bool) : (valuation E).satisfies [.neg 118, .pos 14] := by
  change (g119 E = true) → (¬ (g15 E = true)) → False
  exact pattern_1 (g15 E) (g115 E)
private theorem sat_68 (E : Nat → Bool) : (valuation E).satisfies [.neg 118, .pos 114] := by
  change (g119 E = true) → (¬ (g115 E = true)) → False
  exact pattern_2 (g15 E) (g115 E)
private theorem sat_69 (E : Nat → Bool) : (valuation E).satisfies [.neg 115, .pos 15, .pos 119] := by
  change (g116 E = true) → (¬ (g16 E = true)) → (¬ (g120 E = true)) → False
  exact pattern_3 (g16 E) (g116 E)
private theorem sat_70 (E : Nat → Bool) : (valuation E).satisfies [.neg 120, .neg 115] := by
  change (g121 E = true) → (g116 E = true) → False
  exact pattern_4 (g16 E) (g116 E)
private theorem sat_71 (E : Nat → Bool) : (valuation E).satisfies [.neg 120, .pos 15] := by
  change (g121 E = true) → (¬ (g16 E = true)) → False
  exact pattern_5 (g16 E) (g116 E)
private theorem sat_72 (E : Nat → Bool) : (valuation E).satisfies [.neg 117, .pos 120, .pos 121] := by
  change (g118 E = true) → (¬ (g121 E = true)) → (¬ (g122 E = true)) → False
  exact pattern_6 (g118 E) (g121 E)
private theorem sat_73 (E : Nat → Bool) : (valuation E).satisfies [.neg 122, .neg 117] := by
  change (g123 E = true) → (g118 E = true) → False
  exact pattern_4 (g16 E) (g118 E)
private theorem sat_74 (E : Nat → Bool) : (valuation E).satisfies [.neg 122, .pos 15] := by
  change (g123 E = true) → (¬ (g16 E = true)) → False
  exact pattern_5 (g16 E) (g118 E)
private theorem sat_75 (E : Nat → Bool) : (valuation E).satisfies [.pos 118, .pos 122, .pos 123] := by
  change (¬ (g119 E = true)) → (¬ (g123 E = true)) → (¬ (g124 E = true)) → False
  exact pattern_0 (g119 E) (g123 E)
private theorem sat_76 (E : Nat → Bool) : (valuation E).satisfies [.neg 126, .neg 119] := by
  change (g127 E = true) → (g120 E = true) → False
  exact pattern_4 (g17 E) (g120 E)
private theorem sat_77 (E : Nat → Bool) : (valuation E).satisfies [.neg 126, .pos 16] := by
  change (g127 E = true) → (¬ (g17 E = true)) → False
  exact pattern_5 (g17 E) (g120 E)
private theorem sat_78 (E : Nat → Bool) : (valuation E).satisfies [.neg 121, .pos 126, .pos 127] := by
  change (g122 E = true) → (¬ (g127 E = true)) → (¬ (g128 E = true)) → False
  exact pattern_6 (g122 E) (g127 E)
private theorem sat_79 (E : Nat → Bool) : (valuation E).satisfies [.neg 128, .neg 121] := by
  change (g129 E = true) → (g122 E = true) → False
  exact pattern_4 (g17 E) (g122 E)
private theorem sat_80 (E : Nat → Bool) : (valuation E).satisfies [.neg 128, .pos 16] := by
  change (g129 E = true) → (¬ (g17 E = true)) → False
  exact pattern_5 (g17 E) (g122 E)
private theorem sat_81 (E : Nat → Bool) : (valuation E).satisfies [.neg 123, .pos 128, .pos 129] := by
  change (g124 E = true) → (¬ (g129 E = true)) → (¬ (g130 E = true)) → False
  exact pattern_6 (g124 E) (g129 E)
private theorem sat_82 (E : Nat → Bool) : (valuation E).satisfies [.neg 134, .pos 17] := by
  change (g135 E = true) → (¬ (g18 E = true)) → False
  exact pattern_5 (g18 E) (g126 E)
private theorem sat_83 (E : Nat → Bool) : (valuation E).satisfies [.neg 127, .pos 134, .pos 135] := by
  change (g128 E = true) → (¬ (g135 E = true)) → (¬ (g136 E = true)) → False
  exact pattern_6 (g128 E) (g135 E)
private theorem sat_84 (E : Nat → Bool) : (valuation E).satisfies [.neg 136, .neg 127] := by
  change (g137 E = true) → (g128 E = true) → False
  exact pattern_4 (g18 E) (g128 E)
private theorem sat_85 (E : Nat → Bool) : (valuation E).satisfies [.neg 136, .pos 17] := by
  change (g137 E = true) → (¬ (g18 E = true)) → False
  exact pattern_5 (g18 E) (g128 E)
private theorem sat_86 (E : Nat → Bool) : (valuation E).satisfies [.neg 129, .pos 136, .pos 137] := by
  change (g130 E = true) → (¬ (g137 E = true)) → (¬ (g138 E = true)) → False
  exact pattern_6 (g130 E) (g137 E)
private theorem sat_87 (E : Nat → Bool) : (valuation E).satisfies [.neg 146, .neg 135] := by
  change (g147 E = true) → (g136 E = true) → False
  exact pattern_4 (g19 E) (g136 E)
private theorem sat_88 (E : Nat → Bool) : (valuation E).satisfies [.neg 146, .pos 18] := by
  change (g147 E = true) → (¬ (g19 E = true)) → False
  exact pattern_5 (g19 E) (g136 E)
private theorem sat_89 (E : Nat → Bool) : (valuation E).satisfies [.neg 137, .pos 146, .pos 147] := by
  change (g138 E = true) → (¬ (g147 E = true)) → (¬ (g148 E = true)) → False
  exact pattern_6 (g138 E) (g147 E)
private theorem pattern_7 (x0 x1 : Bool) : (((!x1) && (!x0))=true) → (x1=true) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_91 (E : Nat → Bool) : (valuation E).satisfies [.neg 155, .neg 9] := by
  change (g156 E = true) → (g10 E = true) → False
  exact pattern_7 (g4 E) (g10 E)
private theorem pattern_8 (x0 x1 : Bool) : (((!x1) && (!x0))=true) → (x0=true) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_92 (E : Nat → Bool) : (valuation E).satisfies [.neg 155, .neg 3] := by
  change (g156 E = true) → (g4 E = true) → False
  exact pattern_8 (g4 E) (g10 E)
private theorem sat_93 (E : Nat → Bool) : (valuation E).satisfies [.pos 3, .pos 9, .pos 155] := by
  change (¬ (g4 E = true)) → (¬ (g10 E = true)) → (¬ (g156 E = true)) → False
  exact pattern_0 (g4 E) (g10 E)
private theorem sat_94 (E : Nat → Bool) : (valuation E).satisfies [.neg 156, .pos 3] := by
  change (g157 E = true) → (¬ (g4 E = true)) → False
  exact pattern_1 (g4 E) (g10 E)
private theorem sat_95 (E : Nat → Bool) : (valuation E).satisfies [.neg 156, .pos 9] := by
  change (g157 E = true) → (¬ (g10 E = true)) → False
  exact pattern_2 (g4 E) (g10 E)
private theorem sat_96 (E : Nat → Bool) : (valuation E).satisfies [.neg 155, .pos 14, .pos 157] := by
  change (g156 E = true) → (¬ (g15 E = true)) → (¬ (g158 E = true)) → False
  exact pattern_3 (g15 E) (g156 E)
private theorem sat_97 (E : Nat → Bool) : (valuation E).satisfies [.neg 158, .neg 155] := by
  change (g159 E = true) → (g156 E = true) → False
  exact pattern_4 (g15 E) (g156 E)
private theorem sat_98 (E : Nat → Bool) : (valuation E).satisfies [.neg 158, .pos 14] := by
  change (g159 E = true) → (¬ (g15 E = true)) → False
  exact pattern_5 (g15 E) (g156 E)
private theorem sat_99 (E : Nat → Bool) : (valuation E).satisfies [.pos 156, .pos 158, .pos 159] := by
  change (¬ (g157 E = true)) → (¬ (g159 E = true)) → (¬ (g160 E = true)) → False
  exact pattern_0 (g157 E) (g159 E)
private theorem sat_100 (E : Nat → Bool) : (valuation E).satisfies [.neg 160, .pos 14] := by
  change (g161 E = true) → (¬ (g15 E = true)) → False
  exact pattern_1 (g15 E) (g157 E)
private theorem sat_101 (E : Nat → Bool) : (valuation E).satisfies [.neg 160, .pos 156] := by
  change (g161 E = true) → (¬ (g157 E = true)) → False
  exact pattern_2 (g15 E) (g157 E)
private theorem sat_102 (E : Nat → Bool) : (valuation E).satisfies [.neg 157, .pos 19, .pos 161] := by
  change (g158 E = true) → (¬ (g20 E = true)) → (¬ (g162 E = true)) → False
  exact pattern_3 (g20 E) (g158 E)
private theorem sat_103 (E : Nat → Bool) : (valuation E).satisfies [.neg 162, .neg 157] := by
  change (g163 E = true) → (g158 E = true) → False
  exact pattern_4 (g20 E) (g158 E)
private theorem sat_104 (E : Nat → Bool) : (valuation E).satisfies [.neg 162, .pos 19] := by
  change (g163 E = true) → (¬ (g20 E = true)) → False
  exact pattern_5 (g20 E) (g158 E)
private theorem sat_105 (E : Nat → Bool) : (valuation E).satisfies [.neg 159, .pos 162, .pos 163] := by
  change (g160 E = true) → (¬ (g163 E = true)) → (¬ (g164 E = true)) → False
  exact pattern_6 (g160 E) (g163 E)
private theorem sat_106 (E : Nat → Bool) : (valuation E).satisfies [.neg 164, .neg 159] := by
  change (g165 E = true) → (g160 E = true) → False
  exact pattern_4 (g20 E) (g160 E)
private theorem sat_107 (E : Nat → Bool) : (valuation E).satisfies [.neg 164, .pos 19] := by
  change (g165 E = true) → (¬ (g20 E = true)) → False
  exact pattern_5 (g20 E) (g160 E)
private theorem sat_108 (E : Nat → Bool) : (valuation E).satisfies [.pos 160, .pos 164, .pos 165] := by
  change (¬ (g161 E = true)) → (¬ (g165 E = true)) → (¬ (g166 E = true)) → False
  exact pattern_0 (g161 E) (g165 E)
private theorem sat_109 (E : Nat → Bool) : (valuation E).satisfies [.neg 161, .pos 20, .pos 167] := by
  change (g162 E = true) → (¬ (g21 E = true)) → (¬ (g168 E = true)) → False
  exact pattern_3 (g21 E) (g162 E)
private theorem sat_110 (E : Nat → Bool) : (valuation E).satisfies [.neg 168, .neg 161] := by
  change (g169 E = true) → (g162 E = true) → False
  exact pattern_4 (g21 E) (g162 E)
private theorem sat_111 (E : Nat → Bool) : (valuation E).satisfies [.neg 168, .pos 20] := by
  change (g169 E = true) → (¬ (g21 E = true)) → False
  exact pattern_5 (g21 E) (g162 E)
private theorem sat_112 (E : Nat → Bool) : (valuation E).satisfies [.neg 163, .pos 168, .pos 169] := by
  change (g164 E = true) → (¬ (g169 E = true)) → (¬ (g170 E = true)) → False
  exact pattern_6 (g164 E) (g169 E)
private theorem sat_113 (E : Nat → Bool) : (valuation E).satisfies [.neg 170, .neg 163] := by
  change (g171 E = true) → (g164 E = true) → False
  exact pattern_4 (g21 E) (g164 E)
private theorem sat_114 (E : Nat → Bool) : (valuation E).satisfies [.neg 170, .pos 20] := by
  change (g171 E = true) → (¬ (g21 E = true)) → False
  exact pattern_5 (g21 E) (g164 E)
private theorem sat_115 (E : Nat → Bool) : (valuation E).satisfies [.neg 165, .pos 170, .pos 171] := by
  change (g166 E = true) → (¬ (g171 E = true)) → (¬ (g172 E = true)) → False
  exact pattern_6 (g166 E) (g171 E)
private theorem sat_116 (E : Nat → Bool) : (valuation E).satisfies [.neg 176, .neg 167] := by
  change (g177 E = true) → (g168 E = true) → False
  exact pattern_4 (g22 E) (g168 E)
private theorem sat_117 (E : Nat → Bool) : (valuation E).satisfies [.neg 176, .pos 21] := by
  change (g177 E = true) → (¬ (g22 E = true)) → False
  exact pattern_5 (g22 E) (g168 E)
private theorem sat_118 (E : Nat → Bool) : (valuation E).satisfies [.neg 169, .pos 176, .pos 177] := by
  change (g170 E = true) → (¬ (g177 E = true)) → (¬ (g178 E = true)) → False
  exact pattern_6 (g170 E) (g177 E)
private theorem sat_119 (E : Nat → Bool) : (valuation E).satisfies [.neg 178, .neg 169] := by
  change (g179 E = true) → (g170 E = true) → False
  exact pattern_4 (g22 E) (g170 E)
private theorem sat_120 (E : Nat → Bool) : (valuation E).satisfies [.neg 178, .pos 21] := by
  change (g179 E = true) → (¬ (g22 E = true)) → False
  exact pattern_5 (g22 E) (g170 E)
private theorem sat_121 (E : Nat → Bool) : (valuation E).satisfies [.neg 21, .pos 169, .pos 178] := by
  change (g22 E = true) → (¬ (g170 E = true)) → (¬ (g179 E = true)) → False
  exact pattern_6 (g22 E) (g170 E)
private theorem sat_122 (E : Nat → Bool) : (valuation E).satisfies [.neg 171, .pos 178, .pos 179] := by
  change (g172 E = true) → (¬ (g179 E = true)) → (¬ (g180 E = true)) → False
  exact pattern_6 (g172 E) (g179 E)
private theorem sat_123 (E : Nat → Bool) : (valuation E).satisfies [.neg 188, .neg 177] := by
  change (g189 E = true) → (g178 E = true) → False
  exact pattern_4 (g23 E) (g178 E)
private theorem sat_124 (E : Nat → Bool) : (valuation E).satisfies [.neg 188, .pos 22] := by
  change (g189 E = true) → (¬ (g23 E = true)) → False
  exact pattern_5 (g23 E) (g178 E)
private theorem sat_125 (E : Nat → Bool) : (valuation E).satisfies [.neg 179, .pos 188, .pos 189] := by
  change (g180 E = true) → (¬ (g189 E = true)) → (¬ (g190 E = true)) → False
  exact pattern_6 (g180 E) (g189 E)
private theorem sat_127 (E : Nat → Bool) : (valuation E).satisfies [.neg 197, .neg 10] := by
  change (g198 E = true) → (g11 E = true) → False
  exact pattern_7 (g5 E) (g11 E)
private theorem sat_128 (E : Nat → Bool) : (valuation E).satisfies [.neg 197, .neg 4] := by
  change (g198 E = true) → (g5 E = true) → False
  exact pattern_8 (g5 E) (g11 E)
private theorem sat_129 (E : Nat → Bool) : (valuation E).satisfies [.pos 4, .pos 10, .pos 197] := by
  change (¬ (g5 E = true)) → (¬ (g11 E = true)) → (¬ (g198 E = true)) → False
  exact pattern_0 (g5 E) (g11 E)
private theorem sat_130 (E : Nat → Bool) : (valuation E).satisfies [.neg 198, .pos 4] := by
  change (g199 E = true) → (¬ (g5 E = true)) → False
  exact pattern_1 (g5 E) (g11 E)
private theorem sat_131 (E : Nat → Bool) : (valuation E).satisfies [.neg 198, .pos 10] := by
  change (g199 E = true) → (¬ (g11 E = true)) → False
  exact pattern_2 (g5 E) (g11 E)
private theorem pattern_9 (x0 x1 : Bool) : (x1=true) → (x0=true) → (¬ (((x0) && (x1))=true)) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_132 (E : Nat → Bool) : (valuation E).satisfies [.neg 10, .neg 4, .pos 198] := by
  change (g11 E = true) → (g5 E = true) → (¬ (g199 E = true)) → False
  exact pattern_9 (g5 E) (g11 E)
private theorem sat_133 (E : Nat → Bool) : (valuation E).satisfies [.neg 197, .pos 15, .pos 199] := by
  change (g198 E = true) → (¬ (g16 E = true)) → (¬ (g200 E = true)) → False
  exact pattern_3 (g16 E) (g198 E)
private theorem sat_134 (E : Nat → Bool) : (valuation E).satisfies [.neg 200, .neg 197] := by
  change (g201 E = true) → (g198 E = true) → False
  exact pattern_4 (g16 E) (g198 E)
private theorem sat_135 (E : Nat → Bool) : (valuation E).satisfies [.neg 200, .pos 15] := by
  change (g201 E = true) → (¬ (g16 E = true)) → False
  exact pattern_5 (g16 E) (g198 E)
private theorem sat_136 (E : Nat → Bool) : (valuation E).satisfies [.neg 15, .pos 197, .pos 200] := by
  change (g16 E = true) → (¬ (g198 E = true)) → (¬ (g201 E = true)) → False
  exact pattern_6 (g16 E) (g198 E)
private theorem sat_137 (E : Nat → Bool) : (valuation E).satisfies [.neg 201, .neg 200] := by
  change (g202 E = true) → (g201 E = true) → False
  exact pattern_7 (g199 E) (g201 E)
private theorem sat_138 (E : Nat → Bool) : (valuation E).satisfies [.pos 198, .pos 200, .pos 201] := by
  change (¬ (g199 E = true)) → (¬ (g201 E = true)) → (¬ (g202 E = true)) → False
  exact pattern_0 (g199 E) (g201 E)
private theorem sat_139 (E : Nat → Bool) : (valuation E).satisfies [.neg 202, .pos 15] := by
  change (g203 E = true) → (¬ (g16 E = true)) → False
  exact pattern_1 (g16 E) (g199 E)
private theorem sat_140 (E : Nat → Bool) : (valuation E).satisfies [.neg 202, .pos 198] := by
  change (g203 E = true) → (¬ (g199 E = true)) → False
  exact pattern_2 (g16 E) (g199 E)
private theorem sat_141 (E : Nat → Bool) : (valuation E).satisfies [.neg 199, .pos 19, .pos 203] := by
  change (g200 E = true) → (¬ (g20 E = true)) → (¬ (g204 E = true)) → False
  exact pattern_3 (g20 E) (g200 E)
private theorem sat_142 (E : Nat → Bool) : (valuation E).satisfies [.neg 204, .neg 199] := by
  change (g205 E = true) → (g200 E = true) → False
  exact pattern_4 (g20 E) (g200 E)
private theorem sat_143 (E : Nat → Bool) : (valuation E).satisfies [.neg 204, .pos 19] := by
  change (g205 E = true) → (¬ (g20 E = true)) → False
  exact pattern_5 (g20 E) (g200 E)
private theorem sat_144 (E : Nat → Bool) : (valuation E).satisfies [.neg 201, .pos 204, .pos 205] := by
  change (g202 E = true) → (¬ (g205 E = true)) → (¬ (g206 E = true)) → False
  exact pattern_6 (g202 E) (g205 E)
private theorem sat_145 (E : Nat → Bool) : (valuation E).satisfies [.neg 206, .neg 201] := by
  change (g207 E = true) → (g202 E = true) → False
  exact pattern_4 (g20 E) (g202 E)
private theorem sat_146 (E : Nat → Bool) : (valuation E).satisfies [.neg 206, .pos 19] := by
  change (g207 E = true) → (¬ (g20 E = true)) → False
  exact pattern_5 (g20 E) (g202 E)
private theorem sat_147 (E : Nat → Bool) : (valuation E).satisfies [.neg 19, .pos 201, .pos 206] := by
  change (g20 E = true) → (¬ (g202 E = true)) → (¬ (g207 E = true)) → False
  exact pattern_6 (g20 E) (g202 E)
private theorem sat_148 (E : Nat → Bool) : (valuation E).satisfies [.neg 207, .neg 206] := by
  change (g208 E = true) → (g207 E = true) → False
  exact pattern_7 (g203 E) (g207 E)
private theorem sat_149 (E : Nat → Bool) : (valuation E).satisfies [.pos 202, .pos 206, .pos 207] := by
  change (¬ (g203 E = true)) → (¬ (g207 E = true)) → (¬ (g208 E = true)) → False
  exact pattern_0 (g203 E) (g207 E)
private theorem sat_150 (E : Nat → Bool) : (valuation E).satisfies [.neg 203, .pos 23, .pos 209] := by
  change (g204 E = true) → (¬ (g24 E = true)) → (¬ (g210 E = true)) → False
  exact pattern_3 (g24 E) (g204 E)
private theorem sat_151 (E : Nat → Bool) : (valuation E).satisfies [.neg 210, .neg 203] := by
  change (g211 E = true) → (g204 E = true) → False
  exact pattern_4 (g24 E) (g204 E)
private theorem sat_152 (E : Nat → Bool) : (valuation E).satisfies [.neg 210, .pos 23] := by
  change (g211 E = true) → (¬ (g24 E = true)) → False
  exact pattern_5 (g24 E) (g204 E)
private theorem sat_153 (E : Nat → Bool) : (valuation E).satisfies [.neg 205, .pos 210, .pos 211] := by
  change (g206 E = true) → (¬ (g211 E = true)) → (¬ (g212 E = true)) → False
  exact pattern_6 (g206 E) (g211 E)
private theorem sat_154 (E : Nat → Bool) : (valuation E).satisfies [.neg 212, .neg 205] := by
  change (g213 E = true) → (g206 E = true) → False
  exact pattern_4 (g24 E) (g206 E)
private theorem sat_155 (E : Nat → Bool) : (valuation E).satisfies [.neg 212, .pos 23] := by
  change (g213 E = true) → (¬ (g24 E = true)) → False
  exact pattern_5 (g24 E) (g206 E)
private theorem sat_156 (E : Nat → Bool) : (valuation E).satisfies [.neg 207, .pos 212, .pos 213] := by
  change (g208 E = true) → (¬ (g213 E = true)) → (¬ (g214 E = true)) → False
  exact pattern_6 (g208 E) (g213 E)
private theorem sat_157 (E : Nat → Bool) : (valuation E).satisfies [.neg 218, .neg 209] := by
  change (g219 E = true) → (g210 E = true) → False
  exact pattern_4 (g25 E) (g210 E)
private theorem sat_158 (E : Nat → Bool) : (valuation E).satisfies [.neg 218, .pos 24] := by
  change (g219 E = true) → (¬ (g25 E = true)) → False
  exact pattern_5 (g25 E) (g210 E)
private theorem sat_159 (E : Nat → Bool) : (valuation E).satisfies [.neg 211, .pos 218, .pos 219] := by
  change (g212 E = true) → (¬ (g219 E = true)) → (¬ (g220 E = true)) → False
  exact pattern_6 (g212 E) (g219 E)
private theorem sat_160 (E : Nat → Bool) : (valuation E).satisfies [.neg 220, .neg 211] := by
  change (g221 E = true) → (g212 E = true) → False
  exact pattern_4 (g25 E) (g212 E)
private theorem sat_161 (E : Nat → Bool) : (valuation E).satisfies [.neg 220, .pos 24] := by
  change (g221 E = true) → (¬ (g25 E = true)) → False
  exact pattern_5 (g25 E) (g212 E)
private theorem sat_162 (E : Nat → Bool) : (valuation E).satisfies [.neg 213, .pos 220, .pos 221] := by
  change (g214 E = true) → (¬ (g221 E = true)) → (¬ (g222 E = true)) → False
  exact pattern_6 (g214 E) (g221 E)
private theorem sat_163 (E : Nat → Bool) : (valuation E).satisfies [.neg 230, .neg 219] := by
  change (g231 E = true) → (g220 E = true) → False
  exact pattern_4 (g26 E) (g220 E)
private theorem sat_164 (E : Nat → Bool) : (valuation E).satisfies [.neg 230, .pos 25] := by
  change (g231 E = true) → (¬ (g26 E = true)) → False
  exact pattern_5 (g26 E) (g220 E)
private theorem sat_165 (E : Nat → Bool) : (valuation E).satisfies [.neg 221, .pos 230, .pos 231] := by
  change (g222 E = true) → (¬ (g231 E = true)) → (¬ (g232 E = true)) → False
  exact pattern_6 (g222 E) (g231 E)
private theorem sat_167 (E : Nat → Bool) : (valuation E).satisfies [.pos 5, .pos 11, .pos 239] := by
  change (¬ (g6 E = true)) → (¬ (g12 E = true)) → (¬ (g240 E = true)) → False
  exact pattern_0 (g6 E) (g12 E)
private theorem sat_168 (E : Nat → Bool) : (valuation E).satisfies [.neg 240, .pos 5] := by
  change (g241 E = true) → (¬ (g6 E = true)) → False
  exact pattern_1 (g6 E) (g12 E)
private theorem sat_169 (E : Nat → Bool) : (valuation E).satisfies [.neg 240, .pos 11] := by
  change (g241 E = true) → (¬ (g12 E = true)) → False
  exact pattern_2 (g6 E) (g12 E)
private theorem sat_170 (E : Nat → Bool) : (valuation E).satisfies [.neg 239, .pos 16, .pos 241] := by
  change (g240 E = true) → (¬ (g17 E = true)) → (¬ (g242 E = true)) → False
  exact pattern_3 (g17 E) (g240 E)
private theorem sat_171 (E : Nat → Bool) : (valuation E).satisfies [.neg 242, .neg 239] := by
  change (g243 E = true) → (g240 E = true) → False
  exact pattern_4 (g17 E) (g240 E)
private theorem sat_172 (E : Nat → Bool) : (valuation E).satisfies [.neg 242, .pos 16] := by
  change (g243 E = true) → (¬ (g17 E = true)) → False
  exact pattern_5 (g17 E) (g240 E)
private theorem sat_173 (E : Nat → Bool) : (valuation E).satisfies [.pos 240, .pos 242, .pos 243] := by
  change (¬ (g241 E = true)) → (¬ (g243 E = true)) → (¬ (g244 E = true)) → False
  exact pattern_0 (g241 E) (g243 E)
private theorem sat_174 (E : Nat → Bool) : (valuation E).satisfies [.neg 244, .pos 240] := by
  change (g245 E = true) → (¬ (g241 E = true)) → False
  exact pattern_2 (g17 E) (g241 E)
private theorem sat_175 (E : Nat → Bool) : (valuation E).satisfies [.neg 246, .neg 241] := by
  change (g247 E = true) → (g242 E = true) → False
  exact pattern_4 (g21 E) (g242 E)
private theorem sat_176 (E : Nat → Bool) : (valuation E).satisfies [.neg 246, .pos 20] := by
  change (g247 E = true) → (¬ (g21 E = true)) → False
  exact pattern_5 (g21 E) (g242 E)
private theorem sat_177 (E : Nat → Bool) : (valuation E).satisfies [.neg 243, .pos 246, .pos 247] := by
  change (g244 E = true) → (¬ (g247 E = true)) → (¬ (g248 E = true)) → False
  exact pattern_6 (g244 E) (g247 E)
private theorem sat_178 (E : Nat → Bool) : (valuation E).satisfies [.neg 248, .neg 243] := by
  change (g249 E = true) → (g244 E = true) → False
  exact pattern_4 (g21 E) (g244 E)
private theorem sat_179 (E : Nat → Bool) : (valuation E).satisfies [.neg 248, .pos 20] := by
  change (g249 E = true) → (¬ (g21 E = true)) → False
  exact pattern_5 (g21 E) (g244 E)
private theorem sat_180 (E : Nat → Bool) : (valuation E).satisfies [.pos 244, .pos 248, .pos 249] := by
  change (¬ (g245 E = true)) → (¬ (g249 E = true)) → (¬ (g250 E = true)) → False
  exact pattern_0 (g245 E) (g249 E)
private theorem sat_181 (E : Nat → Bool) : (valuation E).satisfies [.neg 252, .pos 23] := by
  change (g253 E = true) → (¬ (g24 E = true)) → False
  exact pattern_5 (g24 E) (g246 E)
private theorem sat_182 (E : Nat → Bool) : (valuation E).satisfies [.neg 247, .pos 252, .pos 253] := by
  change (g248 E = true) → (¬ (g253 E = true)) → (¬ (g254 E = true)) → False
  exact pattern_6 (g248 E) (g253 E)
private theorem sat_183 (E : Nat → Bool) : (valuation E).satisfies [.neg 254, .neg 247] := by
  change (g255 E = true) → (g248 E = true) → False
  exact pattern_4 (g24 E) (g248 E)
private theorem sat_184 (E : Nat → Bool) : (valuation E).satisfies [.neg 254, .pos 23] := by
  change (g255 E = true) → (¬ (g24 E = true)) → False
  exact pattern_5 (g24 E) (g248 E)
private theorem sat_185 (E : Nat → Bool) : (valuation E).satisfies [.neg 249, .pos 254, .pos 255] := by
  change (g250 E = true) → (¬ (g255 E = true)) → (¬ (g256 E = true)) → False
  exact pattern_6 (g250 E) (g255 E)
private theorem sat_186 (E : Nat → Bool) : (valuation E).satisfies [.neg 260, .pos 26] := by
  change (g261 E = true) → (¬ (g27 E = true)) → False
  exact pattern_5 (g27 E) (g252 E)
private theorem sat_187 (E : Nat → Bool) : (valuation E).satisfies [.neg 253, .pos 260, .pos 261] := by
  change (g254 E = true) → (¬ (g261 E = true)) → (¬ (g262 E = true)) → False
  exact pattern_6 (g254 E) (g261 E)
private theorem sat_188 (E : Nat → Bool) : (valuation E).satisfies [.neg 262, .neg 253] := by
  change (g263 E = true) → (g254 E = true) → False
  exact pattern_4 (g27 E) (g254 E)
private theorem sat_189 (E : Nat → Bool) : (valuation E).satisfies [.neg 262, .pos 26] := by
  change (g263 E = true) → (¬ (g27 E = true)) → False
  exact pattern_5 (g27 E) (g254 E)
private theorem sat_190 (E : Nat → Bool) : (valuation E).satisfies [.neg 255, .pos 262, .pos 263] := by
  change (g256 E = true) → (¬ (g263 E = true)) → (¬ (g264 E = true)) → False
  exact pattern_6 (g256 E) (g263 E)
private theorem sat_191 (E : Nat → Bool) : (valuation E).satisfies [.neg 272, .neg 261] := by
  change (g273 E = true) → (g262 E = true) → False
  exact pattern_4 (g28 E) (g262 E)
private theorem sat_192 (E : Nat → Bool) : (valuation E).satisfies [.neg 272, .pos 27] := by
  change (g273 E = true) → (¬ (g28 E = true)) → False
  exact pattern_5 (g28 E) (g262 E)
private theorem sat_193 (E : Nat → Bool) : (valuation E).satisfies [.neg 263, .pos 272, .pos 273] := by
  change (g264 E = true) → (¬ (g273 E = true)) → (¬ (g274 E = true)) → False
  exact pattern_6 (g264 E) (g273 E)
private theorem pattern_10 (x0 x1 x2 : Bool) : (((x0) && (x1) && (x2))=true) → (¬ (x0=true)) → False := by cases x0 <;> cases x1 <;> cases x2 <;> decide
private theorem sat_195 (E : Nat → Bool) : (valuation E).satisfies [.neg 365, .pos 1] := by
  change (g366 E = true) → (¬ (g2 E = true)) → False
  exact pattern_10 (g2 E) (g3 E) (g9 E)
private theorem pattern_11 (x0 x1 x2 : Bool) : (((x0) && (x1) && (x2))=true) → (¬ (x1=true)) → False := by cases x0 <;> cases x1 <;> cases x2 <;> decide
private theorem sat_196 (E : Nat → Bool) : (valuation E).satisfies [.neg 365, .pos 2] := by
  change (g366 E = true) → (¬ (g3 E = true)) → False
  exact pattern_11 (g2 E) (g3 E) (g9 E)
private theorem pattern_12 (x0 x1 x2 : Bool) : (((x0) && (x1) && (x2))=true) → (¬ (x2=true)) → False := by cases x0 <;> cases x1 <;> cases x2 <;> decide
private theorem sat_197 (E : Nat → Bool) : (valuation E).satisfies [.neg 365, .pos 8] := by
  change (g366 E = true) → (¬ (g9 E = true)) → False
  exact pattern_12 (g2 E) (g3 E) (g9 E)
private theorem pattern_13 (x0 x1 x2 : Bool) : (x2=true) → (x1=true) → (x0=true) → (¬ (((x0) && (x1) && (x2))=true)) → False := by cases x0 <;> cases x1 <;> cases x2 <;> decide
private theorem sat_198 (E : Nat → Bool) : (valuation E).satisfies [.neg 8, .neg 2, .neg 1, .pos 365] := by
  change (g9 E = true) → (g3 E = true) → (g2 E = true) → (¬ (g366 E = true)) → False
  exact pattern_13 (g2 E) (g3 E) (g9 E)
private theorem sat_199 (E : Nat → Bool) : (valuation E).satisfies [.neg 366, .pos 1] := by
  change (g367 E = true) → (¬ (g2 E = true)) → False
  exact pattern_10 (g2 E) (g4 E) (g10 E)
private theorem sat_200 (E : Nat → Bool) : (valuation E).satisfies [.neg 366, .pos 3] := by
  change (g367 E = true) → (¬ (g4 E = true)) → False
  exact pattern_11 (g2 E) (g4 E) (g10 E)
private theorem sat_201 (E : Nat → Bool) : (valuation E).satisfies [.neg 366, .pos 9] := by
  change (g367 E = true) → (¬ (g10 E = true)) → False
  exact pattern_12 (g2 E) (g4 E) (g10 E)
private theorem sat_202 (E : Nat → Bool) : (valuation E).satisfies [.neg 367, .pos 1] := by
  change (g368 E = true) → (¬ (g2 E = true)) → False
  exact pattern_10 (g2 E) (g5 E) (g11 E)
private theorem sat_203 (E : Nat → Bool) : (valuation E).satisfies [.neg 367, .pos 4] := by
  change (g368 E = true) → (¬ (g5 E = true)) → False
  exact pattern_11 (g2 E) (g5 E) (g11 E)
private theorem sat_204 (E : Nat → Bool) : (valuation E).satisfies [.neg 367, .pos 10] := by
  change (g368 E = true) → (¬ (g11 E = true)) → False
  exact pattern_12 (g2 E) (g5 E) (g11 E)
private theorem sat_205 (E : Nat → Bool) : (valuation E).satisfies [.neg 368, .pos 1] := by
  change (g369 E = true) → (¬ (g2 E = true)) → False
  exact pattern_10 (g2 E) (g6 E) (g12 E)
private theorem sat_206 (E : Nat → Bool) : (valuation E).satisfies [.neg 368, .pos 5] := by
  change (g369 E = true) → (¬ (g6 E = true)) → False
  exact pattern_11 (g2 E) (g6 E) (g12 E)
private theorem sat_207 (E : Nat → Bool) : (valuation E).satisfies [.neg 368, .pos 11] := by
  change (g369 E = true) → (¬ (g12 E = true)) → False
  exact pattern_12 (g2 E) (g6 E) (g12 E)
private theorem sat_208 (E : Nat → Bool) : (valuation E).satisfies [.neg 369, .pos 1] := by
  change (g370 E = true) → (¬ (g2 E = true)) → False
  exact pattern_10 (g2 E) (g7 E) (g13 E)
private theorem sat_209 (E : Nat → Bool) : (valuation E).satisfies [.neg 369, .pos 6] := by
  change (g370 E = true) → (¬ (g7 E = true)) → False
  exact pattern_11 (g2 E) (g7 E) (g13 E)
private theorem sat_210 (E : Nat → Bool) : (valuation E).satisfies [.neg 369, .pos 12] := by
  change (g370 E = true) → (¬ (g13 E = true)) → False
  exact pattern_12 (g2 E) (g7 E) (g13 E)
private theorem sat_211 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 6, .neg 1, .pos 369] := by
  change (g13 E = true) → (g7 E = true) → (g2 E = true) → (¬ (g370 E = true)) → False
  exact pattern_13 (g2 E) (g7 E) (g13 E)
private theorem sat_212 (E : Nat → Bool) : (valuation E).satisfies [.neg 370, .pos 1] := by
  change (g371 E = true) → (¬ (g2 E = true)) → False
  exact pattern_10 (g2 E) (g8 E) (g14 E)
private theorem sat_213 (E : Nat → Bool) : (valuation E).satisfies [.neg 370, .pos 13] := by
  change (g371 E = true) → (¬ (g14 E = true)) → False
  exact pattern_12 (g2 E) (g8 E) (g14 E)
private theorem sat_214 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 7, .neg 1, .pos 370] := by
  change (g14 E = true) → (g8 E = true) → (g2 E = true) → (¬ (g371 E = true)) → False
  exact pattern_13 (g2 E) (g8 E) (g14 E)
private theorem sat_215 (E : Nat → Bool) : (valuation E).satisfies [.neg 371, .pos 2] := by
  change (g372 E = true) → (¬ (g3 E = true)) → False
  exact pattern_10 (g3 E) (g4 E) (g15 E)
private theorem sat_216 (E : Nat → Bool) : (valuation E).satisfies [.neg 371, .pos 3] := by
  change (g372 E = true) → (¬ (g4 E = true)) → False
  exact pattern_11 (g3 E) (g4 E) (g15 E)
private theorem sat_217 (E : Nat → Bool) : (valuation E).satisfies [.neg 371, .pos 14] := by
  change (g372 E = true) → (¬ (g15 E = true)) → False
  exact pattern_12 (g3 E) (g4 E) (g15 E)
private theorem sat_218 (E : Nat → Bool) : (valuation E).satisfies [.neg 372, .pos 2] := by
  change (g373 E = true) → (¬ (g3 E = true)) → False
  exact pattern_10 (g3 E) (g5 E) (g16 E)
private theorem sat_219 (E : Nat → Bool) : (valuation E).satisfies [.neg 372, .pos 4] := by
  change (g373 E = true) → (¬ (g5 E = true)) → False
  exact pattern_11 (g3 E) (g5 E) (g16 E)
private theorem sat_220 (E : Nat → Bool) : (valuation E).satisfies [.neg 372, .pos 15] := by
  change (g373 E = true) → (¬ (g16 E = true)) → False
  exact pattern_12 (g3 E) (g5 E) (g16 E)
private theorem sat_221 (E : Nat → Bool) : (valuation E).satisfies [.neg 373, .pos 2] := by
  change (g374 E = true) → (¬ (g3 E = true)) → False
  exact pattern_10 (g3 E) (g6 E) (g17 E)
private theorem sat_222 (E : Nat → Bool) : (valuation E).satisfies [.neg 373, .pos 5] := by
  change (g374 E = true) → (¬ (g6 E = true)) → False
  exact pattern_11 (g3 E) (g6 E) (g17 E)
private theorem sat_223 (E : Nat → Bool) : (valuation E).satisfies [.neg 374, .pos 2] := by
  change (g375 E = true) → (¬ (g3 E = true)) → False
  exact pattern_10 (g3 E) (g7 E) (g18 E)
private theorem sat_224 (E : Nat → Bool) : (valuation E).satisfies [.neg 374, .pos 6] := by
  change (g375 E = true) → (¬ (g7 E = true)) → False
  exact pattern_11 (g3 E) (g7 E) (g18 E)
private theorem sat_225 (E : Nat → Bool) : (valuation E).satisfies [.neg 375, .pos 2] := by
  change (g376 E = true) → (¬ (g3 E = true)) → False
  exact pattern_10 (g3 E) (g8 E) (g19 E)
private theorem sat_226 (E : Nat → Bool) : (valuation E).satisfies [.neg 375, .pos 18] := by
  change (g376 E = true) → (¬ (g19 E = true)) → False
  exact pattern_12 (g3 E) (g8 E) (g19 E)
private theorem sat_227 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 7, .neg 2, .pos 375] := by
  change (g19 E = true) → (g8 E = true) → (g3 E = true) → (¬ (g376 E = true)) → False
  exact pattern_13 (g3 E) (g8 E) (g19 E)
private theorem sat_228 (E : Nat → Bool) : (valuation E).satisfies [.neg 376, .pos 3] := by
  change (g377 E = true) → (¬ (g4 E = true)) → False
  exact pattern_10 (g4 E) (g5 E) (g20 E)
private theorem sat_229 (E : Nat → Bool) : (valuation E).satisfies [.neg 376, .pos 19] := by
  change (g377 E = true) → (¬ (g20 E = true)) → False
  exact pattern_12 (g4 E) (g5 E) (g20 E)
private theorem sat_230 (E : Nat → Bool) : (valuation E).satisfies [.neg 377, .pos 3] := by
  change (g378 E = true) → (¬ (g4 E = true)) → False
  exact pattern_10 (g4 E) (g6 E) (g21 E)
private theorem sat_231 (E : Nat → Bool) : (valuation E).satisfies [.neg 378, .pos 3] := by
  change (g379 E = true) → (¬ (g4 E = true)) → False
  exact pattern_10 (g4 E) (g7 E) (g22 E)
private theorem sat_232 (E : Nat → Bool) : (valuation E).satisfies [.neg 378, .pos 21] := by
  change (g379 E = true) → (¬ (g22 E = true)) → False
  exact pattern_12 (g4 E) (g7 E) (g22 E)
private theorem sat_233 (E : Nat → Bool) : (valuation E).satisfies [.neg 379, .pos 3] := by
  change (g380 E = true) → (¬ (g4 E = true)) → False
  exact pattern_10 (g4 E) (g8 E) (g23 E)
private theorem sat_234 (E : Nat → Bool) : (valuation E).satisfies [.neg 380, .pos 4] := by
  change (g381 E = true) → (¬ (g5 E = true)) → False
  exact pattern_10 (g5 E) (g6 E) (g24 E)
private theorem sat_235 (E : Nat → Bool) : (valuation E).satisfies [.neg 380, .pos 5] := by
  change (g381 E = true) → (¬ (g6 E = true)) → False
  exact pattern_11 (g5 E) (g6 E) (g24 E)
private theorem sat_236 (E : Nat → Bool) : (valuation E).satisfies [.neg 380, .pos 23] := by
  change (g381 E = true) → (¬ (g24 E = true)) → False
  exact pattern_12 (g5 E) (g6 E) (g24 E)
private theorem sat_237 (E : Nat → Bool) : (valuation E).satisfies [.neg 381, .pos 4] := by
  change (g382 E = true) → (¬ (g5 E = true)) → False
  exact pattern_10 (g5 E) (g7 E) (g25 E)
private theorem sat_238 (E : Nat → Bool) : (valuation E).satisfies [.neg 381, .pos 24] := by
  change (g382 E = true) → (¬ (g25 E = true)) → False
  exact pattern_12 (g5 E) (g7 E) (g25 E)
private theorem sat_239 (E : Nat → Bool) : (valuation E).satisfies [.neg 382, .pos 4] := by
  change (g383 E = true) → (¬ (g5 E = true)) → False
  exact pattern_10 (g5 E) (g8 E) (g26 E)
private theorem sat_240 (E : Nat → Bool) : (valuation E).satisfies [.neg 382, .pos 25] := by
  change (g383 E = true) → (¬ (g26 E = true)) → False
  exact pattern_12 (g5 E) (g8 E) (g26 E)
private theorem sat_241 (E : Nat → Bool) : (valuation E).satisfies [.neg 383, .pos 5] := by
  change (g384 E = true) → (¬ (g6 E = true)) → False
  exact pattern_10 (g6 E) (g7 E) (g27 E)
private theorem sat_242 (E : Nat → Bool) : (valuation E).satisfies [.neg 384, .pos 5] := by
  change (g385 E = true) → (¬ (g6 E = true)) → False
  exact pattern_10 (g6 E) (g8 E) (g28 E)
private theorem sat_243 (E : Nat → Bool) : (valuation E).satisfies [.neg 384, .pos 27] := by
  change (g385 E = true) → (¬ (g28 E = true)) → False
  exact pattern_12 (g6 E) (g8 E) (g28 E)
private theorem sat_244 (E : Nat → Bool) : (valuation E).satisfies [.neg 385, .pos 6] := by
  change (g386 E = true) → (¬ (g7 E = true)) → False
  exact pattern_10 (g7 E) (g8 E) (g29 E)
private theorem sat_245 (E : Nat → Bool) : (valuation E).satisfies [.neg 385, .pos 28] := by
  change (g386 E = true) → (¬ (g29 E = true)) → False
  exact pattern_12 (g7 E) (g8 E) (g29 E)
private theorem sat_246 (E : Nat → Bool) : (valuation E).satisfies [.neg 28, .neg 7, .neg 6, .pos 385] := by
  change (g29 E = true) → (g8 E = true) → (g7 E = true) → (¬ (g386 E = true)) → False
  exact pattern_13 (g7 E) (g8 E) (g29 E)
private theorem sat_247 (E : Nat → Bool) : (valuation E).satisfies [.neg 386, .pos 8] := by
  change (g387 E = true) → (¬ (g9 E = true)) → False
  exact pattern_10 (g9 E) (g10 E) (g15 E)
private theorem sat_248 (E : Nat → Bool) : (valuation E).satisfies [.neg 386, .pos 9] := by
  change (g387 E = true) → (¬ (g10 E = true)) → False
  exact pattern_11 (g9 E) (g10 E) (g15 E)
private theorem sat_249 (E : Nat → Bool) : (valuation E).satisfies [.neg 386, .pos 14] := by
  change (g387 E = true) → (¬ (g15 E = true)) → False
  exact pattern_12 (g9 E) (g10 E) (g15 E)
private theorem sat_250 (E : Nat → Bool) : (valuation E).satisfies [.neg 387, .pos 8] := by
  change (g388 E = true) → (¬ (g9 E = true)) → False
  exact pattern_10 (g9 E) (g11 E) (g16 E)
private theorem sat_251 (E : Nat → Bool) : (valuation E).satisfies [.neg 387, .pos 10] := by
  change (g388 E = true) → (¬ (g11 E = true)) → False
  exact pattern_11 (g9 E) (g11 E) (g16 E)
private theorem sat_252 (E : Nat → Bool) : (valuation E).satisfies [.neg 387, .pos 15] := by
  change (g388 E = true) → (¬ (g16 E = true)) → False
  exact pattern_12 (g9 E) (g11 E) (g16 E)
private theorem sat_253 (E : Nat → Bool) : (valuation E).satisfies [.neg 388, .pos 8] := by
  change (g389 E = true) → (¬ (g9 E = true)) → False
  exact pattern_10 (g9 E) (g12 E) (g17 E)
private theorem sat_254 (E : Nat → Bool) : (valuation E).satisfies [.neg 388, .pos 11] := by
  change (g389 E = true) → (¬ (g12 E = true)) → False
  exact pattern_11 (g9 E) (g12 E) (g17 E)
private theorem sat_255 (E : Nat → Bool) : (valuation E).satisfies [.neg 388, .pos 16] := by
  change (g389 E = true) → (¬ (g17 E = true)) → False
  exact pattern_12 (g9 E) (g12 E) (g17 E)
private theorem sat_256 (E : Nat → Bool) : (valuation E).satisfies [.neg 389, .pos 8] := by
  change (g390 E = true) → (¬ (g9 E = true)) → False
  exact pattern_10 (g9 E) (g13 E) (g18 E)
private theorem sat_257 (E : Nat → Bool) : (valuation E).satisfies [.neg 389, .pos 12] := by
  change (g390 E = true) → (¬ (g13 E = true)) → False
  exact pattern_11 (g9 E) (g13 E) (g18 E)
private theorem sat_258 (E : Nat → Bool) : (valuation E).satisfies [.neg 389, .pos 17] := by
  change (g390 E = true) → (¬ (g18 E = true)) → False
  exact pattern_12 (g9 E) (g13 E) (g18 E)
private theorem sat_259 (E : Nat → Bool) : (valuation E).satisfies [.neg 390, .pos 8] := by
  change (g391 E = true) → (¬ (g9 E = true)) → False
  exact pattern_10 (g9 E) (g14 E) (g19 E)
private theorem sat_260 (E : Nat → Bool) : (valuation E).satisfies [.neg 390, .pos 13] := by
  change (g391 E = true) → (¬ (g14 E = true)) → False
  exact pattern_11 (g9 E) (g14 E) (g19 E)
private theorem sat_261 (E : Nat → Bool) : (valuation E).satisfies [.neg 390, .pos 18] := by
  change (g391 E = true) → (¬ (g19 E = true)) → False
  exact pattern_12 (g9 E) (g14 E) (g19 E)
private theorem sat_262 (E : Nat → Bool) : (valuation E).satisfies [.neg 391, .pos 9] := by
  change (g392 E = true) → (¬ (g10 E = true)) → False
  exact pattern_10 (g10 E) (g11 E) (g20 E)
private theorem sat_263 (E : Nat → Bool) : (valuation E).satisfies [.neg 391, .pos 10] := by
  change (g392 E = true) → (¬ (g11 E = true)) → False
  exact pattern_11 (g10 E) (g11 E) (g20 E)
private theorem sat_264 (E : Nat → Bool) : (valuation E).satisfies [.neg 392, .pos 9] := by
  change (g393 E = true) → (¬ (g10 E = true)) → False
  exact pattern_10 (g10 E) (g12 E) (g21 E)
private theorem sat_265 (E : Nat → Bool) : (valuation E).satisfies [.neg 392, .pos 11] := by
  change (g393 E = true) → (¬ (g12 E = true)) → False
  exact pattern_11 (g10 E) (g12 E) (g21 E)
private theorem sat_266 (E : Nat → Bool) : (valuation E).satisfies [.neg 392, .pos 20] := by
  change (g393 E = true) → (¬ (g21 E = true)) → False
  exact pattern_12 (g10 E) (g12 E) (g21 E)
private theorem sat_267 (E : Nat → Bool) : (valuation E).satisfies [.neg 393, .pos 9] := by
  change (g394 E = true) → (¬ (g10 E = true)) → False
  exact pattern_10 (g10 E) (g13 E) (g22 E)
private theorem sat_268 (E : Nat → Bool) : (valuation E).satisfies [.neg 393, .pos 12] := by
  change (g394 E = true) → (¬ (g13 E = true)) → False
  exact pattern_11 (g10 E) (g13 E) (g22 E)
private theorem sat_269 (E : Nat → Bool) : (valuation E).satisfies [.neg 393, .pos 21] := by
  change (g394 E = true) → (¬ (g22 E = true)) → False
  exact pattern_12 (g10 E) (g13 E) (g22 E)
private theorem sat_270 (E : Nat → Bool) : (valuation E).satisfies [.neg 394, .pos 9] := by
  change (g395 E = true) → (¬ (g10 E = true)) → False
  exact pattern_10 (g10 E) (g14 E) (g23 E)
private theorem sat_271 (E : Nat → Bool) : (valuation E).satisfies [.neg 395, .pos 10] := by
  change (g396 E = true) → (¬ (g11 E = true)) → False
  exact pattern_10 (g11 E) (g12 E) (g24 E)
private theorem sat_272 (E : Nat → Bool) : (valuation E).satisfies [.neg 395, .pos 11] := by
  change (g396 E = true) → (¬ (g12 E = true)) → False
  exact pattern_11 (g11 E) (g12 E) (g24 E)
private theorem sat_273 (E : Nat → Bool) : (valuation E).satisfies [.neg 395, .pos 23] := by
  change (g396 E = true) → (¬ (g24 E = true)) → False
  exact pattern_12 (g11 E) (g12 E) (g24 E)
private theorem sat_274 (E : Nat → Bool) : (valuation E).satisfies [.neg 396, .pos 10] := by
  change (g397 E = true) → (¬ (g11 E = true)) → False
  exact pattern_10 (g11 E) (g13 E) (g25 E)
private theorem sat_275 (E : Nat → Bool) : (valuation E).satisfies [.neg 396, .pos 12] := by
  change (g397 E = true) → (¬ (g13 E = true)) → False
  exact pattern_11 (g11 E) (g13 E) (g25 E)
private theorem sat_276 (E : Nat → Bool) : (valuation E).satisfies [.neg 396, .pos 24] := by
  change (g397 E = true) → (¬ (g25 E = true)) → False
  exact pattern_12 (g11 E) (g13 E) (g25 E)
private theorem sat_277 (E : Nat → Bool) : (valuation E).satisfies [.neg 397, .pos 10] := by
  change (g398 E = true) → (¬ (g11 E = true)) → False
  exact pattern_10 (g11 E) (g14 E) (g26 E)
private theorem sat_278 (E : Nat → Bool) : (valuation E).satisfies [.neg 397, .pos 13] := by
  change (g398 E = true) → (¬ (g14 E = true)) → False
  exact pattern_11 (g11 E) (g14 E) (g26 E)
private theorem sat_279 (E : Nat → Bool) : (valuation E).satisfies [.neg 397, .pos 25] := by
  change (g398 E = true) → (¬ (g26 E = true)) → False
  exact pattern_12 (g11 E) (g14 E) (g26 E)
private theorem sat_280 (E : Nat → Bool) : (valuation E).satisfies [.neg 398, .pos 11] := by
  change (g399 E = true) → (¬ (g12 E = true)) → False
  exact pattern_10 (g12 E) (g13 E) (g27 E)
private theorem sat_281 (E : Nat → Bool) : (valuation E).satisfies [.neg 398, .pos 12] := by
  change (g399 E = true) → (¬ (g13 E = true)) → False
  exact pattern_11 (g12 E) (g13 E) (g27 E)
private theorem sat_282 (E : Nat → Bool) : (valuation E).satisfies [.neg 399, .pos 11] := by
  change (g400 E = true) → (¬ (g12 E = true)) → False
  exact pattern_10 (g12 E) (g14 E) (g28 E)
private theorem sat_283 (E : Nat → Bool) : (valuation E).satisfies [.neg 399, .pos 13] := by
  change (g400 E = true) → (¬ (g14 E = true)) → False
  exact pattern_11 (g12 E) (g14 E) (g28 E)
private theorem sat_284 (E : Nat → Bool) : (valuation E).satisfies [.neg 400, .pos 12] := by
  change (g401 E = true) → (¬ (g13 E = true)) → False
  exact pattern_10 (g13 E) (g14 E) (g29 E)
private theorem sat_285 (E : Nat → Bool) : (valuation E).satisfies [.neg 400, .pos 13] := by
  change (g401 E = true) → (¬ (g14 E = true)) → False
  exact pattern_11 (g13 E) (g14 E) (g29 E)
private theorem sat_286 (E : Nat → Bool) : (valuation E).satisfies [.neg 400, .pos 28] := by
  change (g401 E = true) → (¬ (g29 E = true)) → False
  exact pattern_12 (g13 E) (g14 E) (g29 E)
private theorem sat_287 (E : Nat → Bool) : (valuation E).satisfies [.neg 401, .pos 14] := by
  change (g402 E = true) → (¬ (g15 E = true)) → False
  exact pattern_10 (g15 E) (g16 E) (g20 E)
private theorem sat_288 (E : Nat → Bool) : (valuation E).satisfies [.neg 401, .pos 15] := by
  change (g402 E = true) → (¬ (g16 E = true)) → False
  exact pattern_11 (g15 E) (g16 E) (g20 E)
private theorem sat_289 (E : Nat → Bool) : (valuation E).satisfies [.neg 402, .pos 14] := by
  change (g403 E = true) → (¬ (g15 E = true)) → False
  exact pattern_10 (g15 E) (g17 E) (g21 E)
private theorem sat_290 (E : Nat → Bool) : (valuation E).satisfies [.neg 402, .pos 16] := by
  change (g403 E = true) → (¬ (g17 E = true)) → False
  exact pattern_11 (g15 E) (g17 E) (g21 E)
private theorem sat_291 (E : Nat → Bool) : (valuation E).satisfies [.neg 402, .pos 20] := by
  change (g403 E = true) → (¬ (g21 E = true)) → False
  exact pattern_12 (g15 E) (g17 E) (g21 E)
private theorem sat_292 (E : Nat → Bool) : (valuation E).satisfies [.neg 403, .pos 14] := by
  change (g404 E = true) → (¬ (g15 E = true)) → False
  exact pattern_10 (g15 E) (g18 E) (g22 E)
private theorem sat_293 (E : Nat → Bool) : (valuation E).satisfies [.neg 403, .pos 17] := by
  change (g404 E = true) → (¬ (g18 E = true)) → False
  exact pattern_11 (g15 E) (g18 E) (g22 E)
private theorem sat_294 (E : Nat → Bool) : (valuation E).satisfies [.neg 403, .pos 21] := by
  change (g404 E = true) → (¬ (g22 E = true)) → False
  exact pattern_12 (g15 E) (g18 E) (g22 E)
private theorem sat_295 (E : Nat → Bool) : (valuation E).satisfies [.neg 404, .pos 14] := by
  change (g405 E = true) → (¬ (g15 E = true)) → False
  exact pattern_10 (g15 E) (g19 E) (g23 E)
private theorem sat_296 (E : Nat → Bool) : (valuation E).satisfies [.neg 404, .pos 18] := by
  change (g405 E = true) → (¬ (g19 E = true)) → False
  exact pattern_11 (g15 E) (g19 E) (g23 E)
private theorem sat_297 (E : Nat → Bool) : (valuation E).satisfies [.neg 405, .pos 15] := by
  change (g406 E = true) → (¬ (g16 E = true)) → False
  exact pattern_10 (g16 E) (g17 E) (g24 E)
private theorem sat_298 (E : Nat → Bool) : (valuation E).satisfies [.neg 405, .pos 16] := by
  change (g406 E = true) → (¬ (g17 E = true)) → False
  exact pattern_11 (g16 E) (g17 E) (g24 E)
private theorem sat_299 (E : Nat → Bool) : (valuation E).satisfies [.neg 405, .pos 23] := by
  change (g406 E = true) → (¬ (g24 E = true)) → False
  exact pattern_12 (g16 E) (g17 E) (g24 E)
private theorem sat_300 (E : Nat → Bool) : (valuation E).satisfies [.neg 406, .pos 15] := by
  change (g407 E = true) → (¬ (g16 E = true)) → False
  exact pattern_10 (g16 E) (g18 E) (g25 E)
private theorem sat_301 (E : Nat → Bool) : (valuation E).satisfies [.neg 406, .pos 17] := by
  change (g407 E = true) → (¬ (g18 E = true)) → False
  exact pattern_11 (g16 E) (g18 E) (g25 E)
private theorem sat_302 (E : Nat → Bool) : (valuation E).satisfies [.neg 406, .pos 24] := by
  change (g407 E = true) → (¬ (g25 E = true)) → False
  exact pattern_12 (g16 E) (g18 E) (g25 E)
private theorem sat_303 (E : Nat → Bool) : (valuation E).satisfies [.neg 407, .pos 15] := by
  change (g408 E = true) → (¬ (g16 E = true)) → False
  exact pattern_10 (g16 E) (g19 E) (g26 E)
private theorem sat_304 (E : Nat → Bool) : (valuation E).satisfies [.neg 407, .pos 18] := by
  change (g408 E = true) → (¬ (g19 E = true)) → False
  exact pattern_11 (g16 E) (g19 E) (g26 E)
private theorem sat_305 (E : Nat → Bool) : (valuation E).satisfies [.neg 407, .pos 25] := by
  change (g408 E = true) → (¬ (g26 E = true)) → False
  exact pattern_12 (g16 E) (g19 E) (g26 E)
private theorem sat_306 (E : Nat → Bool) : (valuation E).satisfies [.neg 408, .pos 16] := by
  change (g409 E = true) → (¬ (g17 E = true)) → False
  exact pattern_10 (g17 E) (g18 E) (g27 E)
private theorem sat_307 (E : Nat → Bool) : (valuation E).satisfies [.neg 408, .pos 17] := by
  change (g409 E = true) → (¬ (g18 E = true)) → False
  exact pattern_11 (g17 E) (g18 E) (g27 E)
private theorem sat_308 (E : Nat → Bool) : (valuation E).satisfies [.neg 409, .pos 16] := by
  change (g410 E = true) → (¬ (g17 E = true)) → False
  exact pattern_10 (g17 E) (g19 E) (g28 E)
private theorem sat_309 (E : Nat → Bool) : (valuation E).satisfies [.neg 409, .pos 18] := by
  change (g410 E = true) → (¬ (g19 E = true)) → False
  exact pattern_11 (g17 E) (g19 E) (g28 E)
private theorem sat_310 (E : Nat → Bool) : (valuation E).satisfies [.neg 410, .pos 17] := by
  change (g411 E = true) → (¬ (g18 E = true)) → False
  exact pattern_10 (g18 E) (g19 E) (g29 E)
private theorem sat_311 (E : Nat → Bool) : (valuation E).satisfies [.neg 410, .pos 18] := by
  change (g411 E = true) → (¬ (g19 E = true)) → False
  exact pattern_11 (g18 E) (g19 E) (g29 E)
private theorem sat_312 (E : Nat → Bool) : (valuation E).satisfies [.neg 421, .neg 365] := by
  change (g422 E = true) → (g366 E = true) → False
  exact pattern_8 (g366 E) (g367 E)
private theorem sat_313 (E : Nat → Bool) : (valuation E).satisfies [.pos 365, .pos 366, .pos 421] := by
  change (¬ (g366 E = true)) → (¬ (g367 E = true)) → (¬ (g422 E = true)) → False
  exact pattern_0 (g366 E) (g367 E)
private theorem sat_314 (E : Nat → Bool) : (valuation E).satisfies [.neg 422, .pos 365] := by
  change (g423 E = true) → (¬ (g366 E = true)) → False
  exact pattern_1 (g366 E) (g367 E)
private theorem sat_315 (E : Nat → Bool) : (valuation E).satisfies [.neg 422, .pos 366] := by
  change (g423 E = true) → (¬ (g367 E = true)) → False
  exact pattern_2 (g366 E) (g367 E)
private theorem pattern_14 (x0 x1 : Bool) : (((!x0) && (x1))=true) → (¬ (x1=true)) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_316 (E : Nat → Bool) : (valuation E).satisfies [.neg 423, .pos 421] := by
  change (g424 E = true) → (¬ (g422 E = true)) → False
  exact pattern_14 (g368 E) (g422 E)
private theorem sat_317 (E : Nat → Bool) : (valuation E).satisfies [.neg 421, .pos 367, .pos 423] := by
  change (g422 E = true) → (¬ (g368 E = true)) → (¬ (g424 E = true)) → False
  exact pattern_3 (g368 E) (g422 E)
private theorem sat_318 (E : Nat → Bool) : (valuation E).satisfies [.neg 424, .neg 421] := by
  change (g425 E = true) → (g422 E = true) → False
  exact pattern_4 (g368 E) (g422 E)
private theorem sat_319 (E : Nat → Bool) : (valuation E).satisfies [.neg 424, .pos 367] := by
  change (g425 E = true) → (¬ (g368 E = true)) → False
  exact pattern_5 (g368 E) (g422 E)
private theorem sat_320 (E : Nat → Bool) : (valuation E).satisfies [.pos 422, .pos 424, .pos 425] := by
  change (¬ (g423 E = true)) → (¬ (g425 E = true)) → (¬ (g426 E = true)) → False
  exact pattern_0 (g423 E) (g425 E)
private theorem sat_321 (E : Nat → Bool) : (valuation E).satisfies [.neg 427, .pos 423] := by
  change (g428 E = true) → (¬ (g424 E = true)) → False
  exact pattern_14 (g369 E) (g424 E)
private theorem sat_322 (E : Nat → Bool) : (valuation E).satisfies [.neg 423, .pos 368, .pos 427] := by
  change (g424 E = true) → (¬ (g369 E = true)) → (¬ (g428 E = true)) → False
  exact pattern_3 (g369 E) (g424 E)
private theorem sat_323 (E : Nat → Bool) : (valuation E).satisfies [.neg 428, .neg 423] := by
  change (g429 E = true) → (g424 E = true) → False
  exact pattern_4 (g369 E) (g424 E)
private theorem sat_324 (E : Nat → Bool) : (valuation E).satisfies [.neg 428, .pos 368] := by
  change (g429 E = true) → (¬ (g369 E = true)) → False
  exact pattern_5 (g369 E) (g424 E)
private theorem sat_325 (E : Nat → Bool) : (valuation E).satisfies [.neg 425, .pos 428, .pos 429] := by
  change (g426 E = true) → (¬ (g429 E = true)) → (¬ (g430 E = true)) → False
  exact pattern_6 (g426 E) (g429 E)
private theorem pattern_15 (x0 x1 : Bool) : (((!x0) && (x1))=true) → (x0=true) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_326 (E : Nat → Bool) : (valuation E).satisfies [.neg 433, .neg 369] := by
  change (g434 E = true) → (g370 E = true) → False
  exact pattern_15 (g370 E) (g428 E)
private theorem sat_327 (E : Nat → Bool) : (valuation E).satisfies [.neg 433, .pos 427] := by
  change (g434 E = true) → (¬ (g428 E = true)) → False
  exact pattern_14 (g370 E) (g428 E)
private theorem sat_328 (E : Nat → Bool) : (valuation E).satisfies [.neg 427, .pos 369, .pos 433] := by
  change (g428 E = true) → (¬ (g370 E = true)) → (¬ (g434 E = true)) → False
  exact pattern_3 (g370 E) (g428 E)
private theorem sat_329 (E : Nat → Bool) : (valuation E).satisfies [.neg 434, .neg 427] := by
  change (g435 E = true) → (g428 E = true) → False
  exact pattern_4 (g370 E) (g428 E)
private theorem sat_330 (E : Nat → Bool) : (valuation E).satisfies [.neg 434, .pos 369] := by
  change (g435 E = true) → (¬ (g370 E = true)) → False
  exact pattern_5 (g370 E) (g428 E)
private theorem sat_331 (E : Nat → Bool) : (valuation E).satisfies [.neg 429, .pos 434, .pos 435] := by
  change (g430 E = true) → (¬ (g435 E = true)) → (¬ (g436 E = true)) → False
  exact pattern_6 (g430 E) (g435 E)
private theorem sat_332 (E : Nat → Bool) : (valuation E).satisfies [.neg 433, .pos 370, .pos 441] := by
  change (g434 E = true) → (¬ (g371 E = true)) → (¬ (g442 E = true)) → False
  exact pattern_3 (g371 E) (g434 E)
private theorem sat_333 (E : Nat → Bool) : (valuation E).satisfies [.neg 442, .neg 433] := by
  change (g443 E = true) → (g434 E = true) → False
  exact pattern_4 (g371 E) (g434 E)
private theorem sat_334 (E : Nat → Bool) : (valuation E).satisfies [.neg 442, .pos 370] := by
  change (g443 E = true) → (¬ (g371 E = true)) → False
  exact pattern_5 (g371 E) (g434 E)
private theorem sat_335 (E : Nat → Bool) : (valuation E).satisfies [.neg 370, .pos 433, .pos 442] := by
  change (g371 E = true) → (¬ (g434 E = true)) → (¬ (g443 E = true)) → False
  exact pattern_6 (g371 E) (g434 E)
private theorem sat_336 (E : Nat → Bool) : (valuation E).satisfies [.neg 443, .neg 442] := by
  change (g444 E = true) → (g443 E = true) → False
  exact pattern_4 (g436 E) (g443 E)
private theorem sat_337 (E : Nat → Bool) : (valuation E).satisfies [.neg 435, .pos 442, .pos 443] := by
  change (g436 E = true) → (¬ (g443 E = true)) → (¬ (g444 E = true)) → False
  exact pattern_6 (g436 E) (g443 E)
private theorem sat_338 (E : Nat → Bool) : (valuation E).satisfies [.neg 441, .pos 371, .pos 451] := by
  change (g442 E = true) → (¬ (g372 E = true)) → (¬ (g452 E = true)) → False
  exact pattern_3 (g372 E) (g442 E)
private theorem sat_339 (E : Nat → Bool) : (valuation E).satisfies [.neg 452, .pos 371] := by
  change (g453 E = true) → (¬ (g372 E = true)) → False
  exact pattern_5 (g372 E) (g442 E)
private theorem sat_340 (E : Nat → Bool) : (valuation E).satisfies [.neg 453, .pos 443] := by
  change (g454 E = true) → (¬ (g444 E = true)) → False
  exact pattern_5 (g444 E) (g453 E)
private theorem sat_341 (E : Nat → Bool) : (valuation E).satisfies [.neg 443, .pos 452, .pos 453] := by
  change (g444 E = true) → (¬ (g453 E = true)) → (¬ (g454 E = true)) → False
  exact pattern_6 (g444 E) (g453 E)
private theorem sat_342 (E : Nat → Bool) : (valuation E).satisfies [.neg 451, .pos 372, .pos 463] := by
  change (g452 E = true) → (¬ (g373 E = true)) → (¬ (g464 E = true)) → False
  exact pattern_3 (g373 E) (g452 E)
private theorem sat_343 (E : Nat → Bool) : (valuation E).satisfies [.neg 464, .neg 451] := by
  change (g465 E = true) → (g452 E = true) → False
  exact pattern_4 (g373 E) (g452 E)
private theorem sat_344 (E : Nat → Bool) : (valuation E).satisfies [.neg 464, .pos 372] := by
  change (g465 E = true) → (¬ (g373 E = true)) → False
  exact pattern_5 (g373 E) (g452 E)
private theorem sat_345 (E : Nat → Bool) : (valuation E).satisfies [.neg 465, .pos 453] := by
  change (g466 E = true) → (¬ (g454 E = true)) → False
  exact pattern_5 (g454 E) (g465 E)
private theorem sat_346 (E : Nat → Bool) : (valuation E).satisfies [.neg 453, .pos 464, .pos 465] := by
  change (g454 E = true) → (¬ (g465 E = true)) → (¬ (g466 E = true)) → False
  exact pattern_6 (g454 E) (g465 E)
private theorem sat_347 (E : Nat → Bool) : (valuation E).satisfies [.neg 463, .pos 373, .pos 477] := by
  change (g464 E = true) → (¬ (g374 E = true)) → (¬ (g478 E = true)) → False
  exact pattern_3 (g374 E) (g464 E)
private theorem sat_348 (E : Nat → Bool) : (valuation E).satisfies [.neg 478, .pos 373] := by
  change (g479 E = true) → (¬ (g374 E = true)) → False
  exact pattern_5 (g374 E) (g464 E)
private theorem sat_349 (E : Nat → Bool) : (valuation E).satisfies [.neg 479, .pos 465] := by
  change (g480 E = true) → (¬ (g466 E = true)) → False
  exact pattern_5 (g466 E) (g479 E)
private theorem sat_350 (E : Nat → Bool) : (valuation E).satisfies [.neg 465, .pos 478, .pos 479] := by
  change (g466 E = true) → (¬ (g479 E = true)) → (¬ (g480 E = true)) → False
  exact pattern_6 (g466 E) (g479 E)
private theorem sat_351 (E : Nat → Bool) : (valuation E).satisfies [.neg 477, .pos 374, .pos 493] := by
  change (g478 E = true) → (¬ (g375 E = true)) → (¬ (g494 E = true)) → False
  exact pattern_3 (g375 E) (g478 E)
private theorem sat_352 (E : Nat → Bool) : (valuation E).satisfies [.neg 494, .neg 477] := by
  change (g495 E = true) → (g478 E = true) → False
  exact pattern_4 (g375 E) (g478 E)
private theorem sat_353 (E : Nat → Bool) : (valuation E).satisfies [.neg 494, .pos 374] := by
  change (g495 E = true) → (¬ (g375 E = true)) → False
  exact pattern_5 (g375 E) (g478 E)
private theorem sat_354 (E : Nat → Bool) : (valuation E).satisfies [.neg 495, .pos 479] := by
  change (g496 E = true) → (¬ (g480 E = true)) → False
  exact pattern_5 (g480 E) (g495 E)
private theorem sat_355 (E : Nat → Bool) : (valuation E).satisfies [.neg 479, .pos 494, .pos 495] := by
  change (g480 E = true) → (¬ (g495 E = true)) → (¬ (g496 E = true)) → False
  exact pattern_6 (g480 E) (g495 E)
private theorem sat_356 (E : Nat → Bool) : (valuation E).satisfies [.neg 493, .pos 375, .pos 511] := by
  change (g494 E = true) → (¬ (g376 E = true)) → (¬ (g512 E = true)) → False
  exact pattern_3 (g376 E) (g494 E)
private theorem sat_357 (E : Nat → Bool) : (valuation E).satisfies [.neg 512, .pos 375] := by
  change (g513 E = true) → (¬ (g376 E = true)) → False
  exact pattern_5 (g376 E) (g494 E)
private theorem sat_358 (E : Nat → Bool) : (valuation E).satisfies [.neg 513, .pos 495] := by
  change (g514 E = true) → (¬ (g496 E = true)) → False
  exact pattern_5 (g496 E) (g513 E)
private theorem sat_359 (E : Nat → Bool) : (valuation E).satisfies [.neg 495, .pos 512, .pos 513] := by
  change (g496 E = true) → (¬ (g513 E = true)) → (¬ (g514 E = true)) → False
  exact pattern_6 (g496 E) (g513 E)
private theorem sat_360 (E : Nat → Bool) : (valuation E).satisfies [.neg 375, .pos 495, .pos 514] := by
  change (g376 E = true) → (¬ (g496 E = true)) → (¬ (g515 E = true)) → False
  exact pattern_6 (g376 E) (g496 E)
private theorem sat_361 (E : Nat → Bool) : (valuation E).satisfies [.neg 515, .neg 514] := by
  change (g516 E = true) → (g515 E = true) → False
  exact pattern_4 (g498 E) (g515 E)
private theorem sat_362 (E : Nat → Bool) : (valuation E).satisfies [.neg 511, .pos 376, .pos 531] := by
  change (g512 E = true) → (¬ (g377 E = true)) → (¬ (g532 E = true)) → False
  exact pattern_3 (g377 E) (g512 E)
private theorem sat_363 (E : Nat → Bool) : (valuation E).satisfies [.neg 532, .neg 511] := by
  change (g533 E = true) → (g512 E = true) → False
  exact pattern_4 (g377 E) (g512 E)
private theorem sat_364 (E : Nat → Bool) : (valuation E).satisfies [.neg 532, .pos 376] := by
  change (g533 E = true) → (¬ (g377 E = true)) → False
  exact pattern_5 (g377 E) (g512 E)
private theorem sat_365 (E : Nat → Bool) : (valuation E).satisfies [.neg 533, .pos 513] := by
  change (g534 E = true) → (¬ (g514 E = true)) → False
  exact pattern_5 (g514 E) (g533 E)
private theorem sat_366 (E : Nat → Bool) : (valuation E).satisfies [.neg 513, .pos 532, .pos 533] := by
  change (g514 E = true) → (¬ (g533 E = true)) → (¬ (g534 E = true)) → False
  exact pattern_6 (g514 E) (g533 E)
private theorem sat_367 (E : Nat → Bool) : (valuation E).satisfies [.neg 535, .pos 515] := by
  change (g536 E = true) → (¬ (g516 E = true)) → False
  exact pattern_5 (g516 E) (g535 E)
private theorem sat_368 (E : Nat → Bool) : (valuation E).satisfies [.neg 531, .pos 377, .pos 553] := by
  change (g532 E = true) → (¬ (g378 E = true)) → (¬ (g554 E = true)) → False
  exact pattern_3 (g378 E) (g532 E)
private theorem sat_369 (E : Nat → Bool) : (valuation E).satisfies [.neg 554, .pos 377] := by
  change (g555 E = true) → (¬ (g378 E = true)) → False
  exact pattern_5 (g378 E) (g532 E)
private theorem sat_370 (E : Nat → Bool) : (valuation E).satisfies [.neg 555, .pos 533] := by
  change (g556 E = true) → (¬ (g534 E = true)) → False
  exact pattern_5 (g534 E) (g555 E)
private theorem sat_371 (E : Nat → Bool) : (valuation E).satisfies [.neg 533, .pos 554, .pos 555] := by
  change (g534 E = true) → (¬ (g555 E = true)) → (¬ (g556 E = true)) → False
  exact pattern_6 (g534 E) (g555 E)
private theorem sat_372 (E : Nat → Bool) : (valuation E).satisfies [.neg 557, .pos 535] := by
  change (g558 E = true) → (¬ (g536 E = true)) → False
  exact pattern_5 (g536 E) (g557 E)
private theorem sat_373 (E : Nat → Bool) : (valuation E).satisfies [.neg 553, .pos 378, .pos 577] := by
  change (g554 E = true) → (¬ (g379 E = true)) → (¬ (g578 E = true)) → False
  exact pattern_3 (g379 E) (g554 E)
private theorem sat_374 (E : Nat → Bool) : (valuation E).satisfies [.neg 578, .pos 378] := by
  change (g579 E = true) → (¬ (g379 E = true)) → False
  exact pattern_5 (g379 E) (g554 E)
private theorem sat_375 (E : Nat → Bool) : (valuation E).satisfies [.neg 579, .pos 555] := by
  change (g580 E = true) → (¬ (g556 E = true)) → False
  exact pattern_5 (g556 E) (g579 E)
private theorem sat_376 (E : Nat → Bool) : (valuation E).satisfies [.neg 555, .pos 578, .pos 579] := by
  change (g556 E = true) → (¬ (g579 E = true)) → (¬ (g580 E = true)) → False
  exact pattern_6 (g556 E) (g579 E)
private theorem sat_377 (E : Nat → Bool) : (valuation E).satisfies [.neg 581, .pos 557] := by
  change (g582 E = true) → (¬ (g558 E = true)) → False
  exact pattern_5 (g558 E) (g581 E)
private theorem sat_378 (E : Nat → Bool) : (valuation E).satisfies [.neg 577, .pos 379, .pos 603] := by
  change (g578 E = true) → (¬ (g380 E = true)) → (¬ (g604 E = true)) → False
  exact pattern_3 (g380 E) (g578 E)
private theorem sat_379 (E : Nat → Bool) : (valuation E).satisfies [.neg 604, .pos 379] := by
  change (g605 E = true) → (¬ (g380 E = true)) → False
  exact pattern_5 (g380 E) (g578 E)
private theorem sat_380 (E : Nat → Bool) : (valuation E).satisfies [.neg 605, .pos 579] := by
  change (g606 E = true) → (¬ (g580 E = true)) → False
  exact pattern_5 (g580 E) (g605 E)
private theorem sat_381 (E : Nat → Bool) : (valuation E).satisfies [.neg 579, .pos 604, .pos 605] := by
  change (g580 E = true) → (¬ (g605 E = true)) → (¬ (g606 E = true)) → False
  exact pattern_6 (g580 E) (g605 E)
private theorem sat_382 (E : Nat → Bool) : (valuation E).satisfies [.neg 607, .pos 581] := by
  change (g608 E = true) → (¬ (g582 E = true)) → False
  exact pattern_5 (g582 E) (g607 E)
private theorem sat_383 (E : Nat → Bool) : (valuation E).satisfies [.neg 603, .pos 380, .pos 631] := by
  change (g604 E = true) → (¬ (g381 E = true)) → (¬ (g632 E = true)) → False
  exact pattern_3 (g381 E) (g604 E)
private theorem sat_384 (E : Nat → Bool) : (valuation E).satisfies [.neg 632, .neg 603] := by
  change (g633 E = true) → (g604 E = true) → False
  exact pattern_4 (g381 E) (g604 E)
private theorem sat_385 (E : Nat → Bool) : (valuation E).satisfies [.neg 632, .pos 380] := by
  change (g633 E = true) → (¬ (g381 E = true)) → False
  exact pattern_5 (g381 E) (g604 E)
private theorem sat_386 (E : Nat → Bool) : (valuation E).satisfies [.neg 633, .pos 605] := by
  change (g634 E = true) → (¬ (g606 E = true)) → False
  exact pattern_5 (g606 E) (g633 E)
private theorem sat_387 (E : Nat → Bool) : (valuation E).satisfies [.neg 605, .pos 632, .pos 633] := by
  change (g606 E = true) → (¬ (g633 E = true)) → (¬ (g634 E = true)) → False
  exact pattern_6 (g606 E) (g633 E)
private theorem sat_388 (E : Nat → Bool) : (valuation E).satisfies [.neg 635, .pos 607] := by
  change (g636 E = true) → (¬ (g608 E = true)) → False
  exact pattern_5 (g608 E) (g635 E)
private theorem sat_389 (E : Nat → Bool) : (valuation E).satisfies [.neg 631, .pos 381, .pos 661] := by
  change (g632 E = true) → (¬ (g382 E = true)) → (¬ (g662 E = true)) → False
  exact pattern_3 (g382 E) (g632 E)
private theorem sat_390 (E : Nat → Bool) : (valuation E).satisfies [.neg 662, .pos 381] := by
  change (g663 E = true) → (¬ (g382 E = true)) → False
  exact pattern_5 (g382 E) (g632 E)
private theorem sat_391 (E : Nat → Bool) : (valuation E).satisfies [.neg 663, .pos 633] := by
  change (g664 E = true) → (¬ (g634 E = true)) → False
  exact pattern_5 (g634 E) (g663 E)
private theorem sat_392 (E : Nat → Bool) : (valuation E).satisfies [.neg 633, .pos 662, .pos 663] := by
  change (g634 E = true) → (¬ (g663 E = true)) → (¬ (g664 E = true)) → False
  exact pattern_6 (g634 E) (g663 E)
private theorem sat_393 (E : Nat → Bool) : (valuation E).satisfies [.neg 665, .pos 635] := by
  change (g666 E = true) → (¬ (g636 E = true)) → False
  exact pattern_5 (g636 E) (g665 E)
private theorem sat_394 (E : Nat → Bool) : (valuation E).satisfies [.neg 661, .pos 382, .pos 693] := by
  change (g662 E = true) → (¬ (g383 E = true)) → (¬ (g694 E = true)) → False
  exact pattern_3 (g383 E) (g662 E)
private theorem sat_395 (E : Nat → Bool) : (valuation E).satisfies [.neg 694, .pos 382] := by
  change (g695 E = true) → (¬ (g383 E = true)) → False
  exact pattern_5 (g383 E) (g662 E)
private theorem sat_396 (E : Nat → Bool) : (valuation E).satisfies [.neg 695, .pos 663] := by
  change (g696 E = true) → (¬ (g664 E = true)) → False
  exact pattern_5 (g664 E) (g695 E)
private theorem sat_397 (E : Nat → Bool) : (valuation E).satisfies [.neg 663, .pos 694, .pos 695] := by
  change (g664 E = true) → (¬ (g695 E = true)) → (¬ (g696 E = true)) → False
  exact pattern_6 (g664 E) (g695 E)
private theorem sat_398 (E : Nat → Bool) : (valuation E).satisfies [.neg 697, .pos 665] := by
  change (g698 E = true) → (¬ (g666 E = true)) → False
  exact pattern_5 (g666 E) (g697 E)
private theorem sat_399 (E : Nat → Bool) : (valuation E).satisfies [.neg 693, .pos 383, .pos 727] := by
  change (g694 E = true) → (¬ (g384 E = true)) → (¬ (g728 E = true)) → False
  exact pattern_3 (g384 E) (g694 E)
private theorem sat_400 (E : Nat → Bool) : (valuation E).satisfies [.neg 728, .neg 693] := by
  change (g729 E = true) → (g694 E = true) → False
  exact pattern_4 (g384 E) (g694 E)
private theorem sat_401 (E : Nat → Bool) : (valuation E).satisfies [.neg 728, .pos 383] := by
  change (g729 E = true) → (¬ (g384 E = true)) → False
  exact pattern_5 (g384 E) (g694 E)
private theorem sat_402 (E : Nat → Bool) : (valuation E).satisfies [.neg 729, .pos 695] := by
  change (g730 E = true) → (¬ (g696 E = true)) → False
  exact pattern_5 (g696 E) (g729 E)
private theorem sat_403 (E : Nat → Bool) : (valuation E).satisfies [.neg 695, .pos 728, .pos 729] := by
  change (g696 E = true) → (¬ (g729 E = true)) → (¬ (g730 E = true)) → False
  exact pattern_6 (g696 E) (g729 E)
private theorem sat_404 (E : Nat → Bool) : (valuation E).satisfies [.neg 731, .pos 697] := by
  change (g732 E = true) → (¬ (g698 E = true)) → False
  exact pattern_5 (g698 E) (g731 E)
private theorem sat_405 (E : Nat → Bool) : (valuation E).satisfies [.neg 727, .pos 384, .pos 763] := by
  change (g728 E = true) → (¬ (g385 E = true)) → (¬ (g764 E = true)) → False
  exact pattern_3 (g385 E) (g728 E)
private theorem sat_406 (E : Nat → Bool) : (valuation E).satisfies [.neg 764, .pos 384] := by
  change (g765 E = true) → (¬ (g385 E = true)) → False
  exact pattern_5 (g385 E) (g728 E)
private theorem sat_407 (E : Nat → Bool) : (valuation E).satisfies [.neg 765, .pos 729] := by
  change (g766 E = true) → (¬ (g730 E = true)) → False
  exact pattern_5 (g730 E) (g765 E)
private theorem sat_408 (E : Nat → Bool) : (valuation E).satisfies [.neg 729, .pos 764, .pos 765] := by
  change (g730 E = true) → (¬ (g765 E = true)) → (¬ (g766 E = true)) → False
  exact pattern_6 (g730 E) (g765 E)
private theorem sat_409 (E : Nat → Bool) : (valuation E).satisfies [.neg 767, .pos 731] := by
  change (g768 E = true) → (¬ (g732 E = true)) → False
  exact pattern_5 (g732 E) (g767 E)
private theorem sat_410 (E : Nat → Bool) : (valuation E).satisfies [.neg 802, .neg 763] := by
  change (g803 E = true) → (g764 E = true) → False
  exact pattern_4 (g386 E) (g764 E)
private theorem sat_411 (E : Nat → Bool) : (valuation E).satisfies [.neg 802, .pos 385] := by
  change (g803 E = true) → (¬ (g386 E = true)) → False
  exact pattern_5 (g386 E) (g764 E)
private theorem sat_412 (E : Nat → Bool) : (valuation E).satisfies [.neg 765, .pos 802, .pos 803] := by
  change (g766 E = true) → (¬ (g803 E = true)) → (¬ (g804 E = true)) → False
  exact pattern_6 (g766 E) (g803 E)
private theorem sat_413 (E : Nat → Bool) : (valuation E).satisfies [.neg 385, .pos 765, .pos 804] := by
  change (g386 E = true) → (¬ (g766 E = true)) → (¬ (g805 E = true)) → False
  exact pattern_6 (g386 E) (g766 E)
private theorem sat_414 (E : Nat → Bool) : (valuation E).satisfies [.neg 805, .neg 804] := by
  change (g806 E = true) → (g805 E = true) → False
  exact pattern_4 (g768 E) (g805 E)
private theorem sat_415 (E : Nat → Bool) : (valuation E).satisfies [.neg 805, .pos 767] := by
  change (g806 E = true) → (¬ (g768 E = true)) → False
  exact pattern_5 (g768 E) (g805 E)
private theorem sat_416 (E : Nat → Bool) : (valuation E).satisfies [.pos 365, .pos 366, .pos 841] := by
  change (¬ (g366 E = true)) → (¬ (g367 E = true)) → (¬ (g842 E = true)) → False
  exact pattern_0 (g366 E) (g367 E)
private theorem sat_417 (E : Nat → Bool) : (valuation E).satisfies [.neg 842, .pos 365] := by
  change (g843 E = true) → (¬ (g366 E = true)) → False
  exact pattern_1 (g366 E) (g367 E)
private theorem sat_418 (E : Nat → Bool) : (valuation E).satisfies [.neg 842, .pos 366] := by
  change (g843 E = true) → (¬ (g367 E = true)) → False
  exact pattern_2 (g366 E) (g367 E)
private theorem sat_419 (E : Nat → Bool) : (valuation E).satisfies [.neg 841, .pos 367, .pos 843] := by
  change (g842 E = true) → (¬ (g368 E = true)) → (¬ (g844 E = true)) → False
  exact pattern_3 (g368 E) (g842 E)
private theorem sat_420 (E : Nat → Bool) : (valuation E).satisfies [.neg 844, .neg 841] := by
  change (g845 E = true) → (g842 E = true) → False
  exact pattern_4 (g368 E) (g842 E)
private theorem sat_421 (E : Nat → Bool) : (valuation E).satisfies [.neg 844, .pos 367] := by
  change (g845 E = true) → (¬ (g368 E = true)) → False
  exact pattern_5 (g368 E) (g842 E)
private theorem sat_422 (E : Nat → Bool) : (valuation E).satisfies [.pos 842, .pos 844, .pos 845] := by
  change (¬ (g843 E = true)) → (¬ (g845 E = true)) → (¬ (g846 E = true)) → False
  exact pattern_0 (g843 E) (g845 E)
private theorem sat_423 (E : Nat → Bool) : (valuation E).satisfies [.neg 846, .pos 367] := by
  change (g847 E = true) → (¬ (g368 E = true)) → False
  exact pattern_1 (g368 E) (g843 E)
private theorem sat_424 (E : Nat → Bool) : (valuation E).satisfies [.neg 846, .pos 842] := by
  change (g847 E = true) → (¬ (g843 E = true)) → False
  exact pattern_2 (g368 E) (g843 E)
private theorem sat_425 (E : Nat → Bool) : (valuation E).satisfies [.neg 843, .pos 368, .pos 847] := by
  change (g844 E = true) → (¬ (g369 E = true)) → (¬ (g848 E = true)) → False
  exact pattern_3 (g369 E) (g844 E)
private theorem sat_426 (E : Nat → Bool) : (valuation E).satisfies [.neg 848, .pos 368] := by
  change (g849 E = true) → (¬ (g369 E = true)) → False
  exact pattern_5 (g369 E) (g844 E)
private theorem sat_427 (E : Nat → Bool) : (valuation E).satisfies [.neg 845, .pos 848, .pos 849] := by
  change (g846 E = true) → (¬ (g849 E = true)) → (¬ (g850 E = true)) → False
  exact pattern_6 (g846 E) (g849 E)
private theorem sat_428 (E : Nat → Bool) : (valuation E).satisfies [.neg 850, .neg 845] := by
  change (g851 E = true) → (g846 E = true) → False
  exact pattern_4 (g369 E) (g846 E)
private theorem sat_429 (E : Nat → Bool) : (valuation E).satisfies [.neg 850, .pos 368] := by
  change (g851 E = true) → (¬ (g369 E = true)) → False
  exact pattern_5 (g369 E) (g846 E)
private theorem sat_430 (E : Nat → Bool) : (valuation E).satisfies [.pos 846, .pos 850, .pos 851] := by
  change (¬ (g847 E = true)) → (¬ (g851 E = true)) → (¬ (g852 E = true)) → False
  exact pattern_0 (g847 E) (g851 E)
private theorem sat_431 (E : Nat → Bool) : (valuation E).satisfies [.neg 852, .pos 846] := by
  change (g853 E = true) → (¬ (g847 E = true)) → False
  exact pattern_2 (g369 E) (g847 E)
private theorem sat_432 (E : Nat → Bool) : (valuation E).satisfies [.neg 847, .pos 369, .pos 853] := by
  change (g848 E = true) → (¬ (g370 E = true)) → (¬ (g854 E = true)) → False
  exact pattern_3 (g370 E) (g848 E)
private theorem sat_433 (E : Nat → Bool) : (valuation E).satisfies [.neg 854, .neg 847] := by
  change (g855 E = true) → (g848 E = true) → False
  exact pattern_4 (g370 E) (g848 E)
private theorem sat_434 (E : Nat → Bool) : (valuation E).satisfies [.neg 854, .pos 369] := by
  change (g855 E = true) → (¬ (g370 E = true)) → False
  exact pattern_5 (g370 E) (g848 E)
private theorem sat_435 (E : Nat → Bool) : (valuation E).satisfies [.neg 849, .pos 854, .pos 855] := by
  change (g850 E = true) → (¬ (g855 E = true)) → (¬ (g856 E = true)) → False
  exact pattern_6 (g850 E) (g855 E)
private theorem sat_436 (E : Nat → Bool) : (valuation E).satisfies [.neg 856, .neg 849] := by
  change (g857 E = true) → (g850 E = true) → False
  exact pattern_4 (g370 E) (g850 E)
private theorem sat_437 (E : Nat → Bool) : (valuation E).satisfies [.neg 856, .pos 369] := by
  change (g857 E = true) → (¬ (g370 E = true)) → False
  exact pattern_5 (g370 E) (g850 E)
private theorem sat_438 (E : Nat → Bool) : (valuation E).satisfies [.neg 851, .pos 856, .pos 857] := by
  change (g852 E = true) → (¬ (g857 E = true)) → (¬ (g858 E = true)) → False
  exact pattern_6 (g852 E) (g857 E)
private theorem sat_439 (E : Nat → Bool) : (valuation E).satisfies [.neg 858, .neg 851] := by
  change (g859 E = true) → (g852 E = true) → False
  exact pattern_4 (g370 E) (g852 E)
private theorem sat_440 (E : Nat → Bool) : (valuation E).satisfies [.neg 858, .pos 369] := by
  change (g859 E = true) → (¬ (g370 E = true)) → False
  exact pattern_5 (g370 E) (g852 E)
private theorem sat_441 (E : Nat → Bool) : (valuation E).satisfies [.pos 852, .pos 858, .pos 859] := by
  change (¬ (g853 E = true)) → (¬ (g859 E = true)) → (¬ (g860 E = true)) → False
  exact pattern_0 (g853 E) (g859 E)
private theorem sat_442 (E : Nat → Bool) : (valuation E).satisfies [.neg 853, .pos 370, .pos 861] := by
  change (g854 E = true) → (¬ (g371 E = true)) → (¬ (g862 E = true)) → False
  exact pattern_3 (g371 E) (g854 E)
private theorem sat_443 (E : Nat → Bool) : (valuation E).satisfies [.neg 862, .neg 853] := by
  change (g863 E = true) → (g854 E = true) → False
  exact pattern_4 (g371 E) (g854 E)
private theorem sat_444 (E : Nat → Bool) : (valuation E).satisfies [.neg 862, .pos 370] := by
  change (g863 E = true) → (¬ (g371 E = true)) → False
  exact pattern_5 (g371 E) (g854 E)
private theorem sat_445 (E : Nat → Bool) : (valuation E).satisfies [.neg 855, .pos 862, .pos 863] := by
  change (g856 E = true) → (¬ (g863 E = true)) → (¬ (g864 E = true)) → False
  exact pattern_6 (g856 E) (g863 E)
private theorem sat_446 (E : Nat → Bool) : (valuation E).satisfies [.neg 864, .neg 855] := by
  change (g865 E = true) → (g856 E = true) → False
  exact pattern_4 (g371 E) (g856 E)
private theorem sat_447 (E : Nat → Bool) : (valuation E).satisfies [.neg 864, .pos 370] := by
  change (g865 E = true) → (¬ (g371 E = true)) → False
  exact pattern_5 (g371 E) (g856 E)
private theorem sat_448 (E : Nat → Bool) : (valuation E).satisfies [.neg 857, .pos 864, .pos 865] := by
  change (g858 E = true) → (¬ (g865 E = true)) → (¬ (g866 E = true)) → False
  exact pattern_6 (g858 E) (g865 E)
private theorem sat_449 (E : Nat → Bool) : (valuation E).satisfies [.neg 866, .neg 857] := by
  change (g867 E = true) → (g858 E = true) → False
  exact pattern_4 (g371 E) (g858 E)
private theorem sat_450 (E : Nat → Bool) : (valuation E).satisfies [.neg 859, .pos 866, .pos 867] := by
  change (g860 E = true) → (¬ (g867 E = true)) → (¬ (g868 E = true)) → False
  exact pattern_6 (g860 E) (g867 E)
private theorem sat_451 (E : Nat → Bool) : (valuation E).satisfies [.neg 861, .pos 386, .pos 871] := by
  change (g862 E = true) → (¬ (g387 E = true)) → (¬ (g872 E = true)) → False
  exact pattern_3 (g387 E) (g862 E)
private theorem sat_452 (E : Nat → Bool) : (valuation E).satisfies [.neg 872, .neg 861] := by
  change (g873 E = true) → (g862 E = true) → False
  exact pattern_4 (g387 E) (g862 E)
private theorem sat_453 (E : Nat → Bool) : (valuation E).satisfies [.neg 872, .pos 386] := by
  change (g873 E = true) → (¬ (g387 E = true)) → False
  exact pattern_5 (g387 E) (g862 E)
private theorem sat_454 (E : Nat → Bool) : (valuation E).satisfies [.neg 863, .pos 872, .pos 873] := by
  change (g864 E = true) → (¬ (g873 E = true)) → (¬ (g874 E = true)) → False
  exact pattern_6 (g864 E) (g873 E)
private theorem sat_455 (E : Nat → Bool) : (valuation E).satisfies [.neg 874, .neg 863] := by
  change (g875 E = true) → (g864 E = true) → False
  exact pattern_4 (g387 E) (g864 E)
private theorem sat_456 (E : Nat → Bool) : (valuation E).satisfies [.neg 874, .pos 386] := by
  change (g875 E = true) → (¬ (g387 E = true)) → False
  exact pattern_5 (g387 E) (g864 E)
private theorem sat_457 (E : Nat → Bool) : (valuation E).satisfies [.neg 865, .pos 874, .pos 875] := by
  change (g866 E = true) → (¬ (g875 E = true)) → (¬ (g876 E = true)) → False
  exact pattern_6 (g866 E) (g875 E)
private theorem sat_458 (E : Nat → Bool) : (valuation E).satisfies [.neg 876, .neg 865] := by
  change (g877 E = true) → (g866 E = true) → False
  exact pattern_4 (g387 E) (g866 E)
private theorem sat_459 (E : Nat → Bool) : (valuation E).satisfies [.neg 876, .pos 386] := by
  change (g877 E = true) → (¬ (g387 E = true)) → False
  exact pattern_5 (g387 E) (g866 E)
private theorem sat_460 (E : Nat → Bool) : (valuation E).satisfies [.neg 867, .pos 876, .pos 877] := by
  change (g868 E = true) → (¬ (g877 E = true)) → (¬ (g878 E = true)) → False
  exact pattern_6 (g868 E) (g877 E)
private theorem sat_461 (E : Nat → Bool) : (valuation E).satisfies [.neg 871, .pos 387, .pos 883] := by
  change (g872 E = true) → (¬ (g388 E = true)) → (¬ (g884 E = true)) → False
  exact pattern_3 (g388 E) (g872 E)
private theorem sat_462 (E : Nat → Bool) : (valuation E).satisfies [.neg 884, .neg 871] := by
  change (g885 E = true) → (g872 E = true) → False
  exact pattern_4 (g388 E) (g872 E)
private theorem sat_463 (E : Nat → Bool) : (valuation E).satisfies [.neg 884, .pos 387] := by
  change (g885 E = true) → (¬ (g388 E = true)) → False
  exact pattern_5 (g388 E) (g872 E)
private theorem sat_464 (E : Nat → Bool) : (valuation E).satisfies [.neg 873, .pos 884, .pos 885] := by
  change (g874 E = true) → (¬ (g885 E = true)) → (¬ (g886 E = true)) → False
  exact pattern_6 (g874 E) (g885 E)
private theorem sat_465 (E : Nat → Bool) : (valuation E).satisfies [.neg 886, .neg 873] := by
  change (g887 E = true) → (g874 E = true) → False
  exact pattern_4 (g388 E) (g874 E)
private theorem sat_466 (E : Nat → Bool) : (valuation E).satisfies [.neg 886, .pos 387] := by
  change (g887 E = true) → (¬ (g388 E = true)) → False
  exact pattern_5 (g388 E) (g874 E)
private theorem sat_467 (E : Nat → Bool) : (valuation E).satisfies [.neg 875, .pos 886, .pos 887] := by
  change (g876 E = true) → (¬ (g887 E = true)) → (¬ (g888 E = true)) → False
  exact pattern_6 (g876 E) (g887 E)
private theorem sat_468 (E : Nat → Bool) : (valuation E).satisfies [.neg 888, .pos 387] := by
  change (g889 E = true) → (¬ (g388 E = true)) → False
  exact pattern_5 (g388 E) (g876 E)
private theorem sat_469 (E : Nat → Bool) : (valuation E).satisfies [.neg 877, .pos 888, .pos 889] := by
  change (g878 E = true) → (¬ (g889 E = true)) → (¬ (g890 E = true)) → False
  exact pattern_6 (g878 E) (g889 E)
private theorem sat_470 (E : Nat → Bool) : (valuation E).satisfies [.neg 883, .pos 388, .pos 897] := by
  change (g884 E = true) → (¬ (g389 E = true)) → (¬ (g898 E = true)) → False
  exact pattern_3 (g389 E) (g884 E)
private theorem sat_471 (E : Nat → Bool) : (valuation E).satisfies [.neg 898, .neg 883] := by
  change (g899 E = true) → (g884 E = true) → False
  exact pattern_4 (g389 E) (g884 E)
private theorem sat_472 (E : Nat → Bool) : (valuation E).satisfies [.neg 898, .pos 388] := by
  change (g899 E = true) → (¬ (g389 E = true)) → False
  exact pattern_5 (g389 E) (g884 E)
private theorem sat_473 (E : Nat → Bool) : (valuation E).satisfies [.neg 885, .pos 898, .pos 899] := by
  change (g886 E = true) → (¬ (g899 E = true)) → (¬ (g900 E = true)) → False
  exact pattern_6 (g886 E) (g899 E)
private theorem sat_474 (E : Nat → Bool) : (valuation E).satisfies [.neg 900, .neg 885] := by
  change (g901 E = true) → (g886 E = true) → False
  exact pattern_4 (g389 E) (g886 E)
private theorem sat_475 (E : Nat → Bool) : (valuation E).satisfies [.neg 900, .pos 388] := by
  change (g901 E = true) → (¬ (g389 E = true)) → False
  exact pattern_5 (g389 E) (g886 E)
private theorem sat_476 (E : Nat → Bool) : (valuation E).satisfies [.neg 887, .pos 900, .pos 901] := by
  change (g888 E = true) → (¬ (g901 E = true)) → (¬ (g902 E = true)) → False
  exact pattern_6 (g888 E) (g901 E)
private theorem sat_477 (E : Nat → Bool) : (valuation E).satisfies [.neg 902, .pos 388] := by
  change (g903 E = true) → (¬ (g389 E = true)) → False
  exact pattern_5 (g389 E) (g888 E)
private theorem sat_478 (E : Nat → Bool) : (valuation E).satisfies [.neg 889, .pos 902, .pos 903] := by
  change (g890 E = true) → (¬ (g903 E = true)) → (¬ (g904 E = true)) → False
  exact pattern_6 (g890 E) (g903 E)
private theorem sat_479 (E : Nat → Bool) : (valuation E).satisfies [.neg 897, .pos 389, .pos 913] := by
  change (g898 E = true) → (¬ (g390 E = true)) → (¬ (g914 E = true)) → False
  exact pattern_3 (g390 E) (g898 E)
private theorem sat_480 (E : Nat → Bool) : (valuation E).satisfies [.neg 914, .neg 897] := by
  change (g915 E = true) → (g898 E = true) → False
  exact pattern_4 (g390 E) (g898 E)
private theorem sat_481 (E : Nat → Bool) : (valuation E).satisfies [.neg 914, .pos 389] := by
  change (g915 E = true) → (¬ (g390 E = true)) → False
  exact pattern_5 (g390 E) (g898 E)
private theorem sat_482 (E : Nat → Bool) : (valuation E).satisfies [.neg 899, .pos 914, .pos 915] := by
  change (g900 E = true) → (¬ (g915 E = true)) → (¬ (g916 E = true)) → False
  exact pattern_6 (g900 E) (g915 E)
private theorem sat_483 (E : Nat → Bool) : (valuation E).satisfies [.neg 916, .neg 899] := by
  change (g917 E = true) → (g900 E = true) → False
  exact pattern_4 (g390 E) (g900 E)
private theorem sat_484 (E : Nat → Bool) : (valuation E).satisfies [.neg 916, .pos 389] := by
  change (g917 E = true) → (¬ (g390 E = true)) → False
  exact pattern_5 (g390 E) (g900 E)
private theorem sat_485 (E : Nat → Bool) : (valuation E).satisfies [.neg 901, .pos 916, .pos 917] := by
  change (g902 E = true) → (¬ (g917 E = true)) → (¬ (g918 E = true)) → False
  exact pattern_6 (g902 E) (g917 E)
private theorem sat_486 (E : Nat → Bool) : (valuation E).satisfies [.neg 918, .neg 901] := by
  change (g919 E = true) → (g902 E = true) → False
  exact pattern_4 (g390 E) (g902 E)
private theorem sat_487 (E : Nat → Bool) : (valuation E).satisfies [.neg 918, .pos 389] := by
  change (g919 E = true) → (¬ (g390 E = true)) → False
  exact pattern_5 (g390 E) (g902 E)
private theorem sat_488 (E : Nat → Bool) : (valuation E).satisfies [.neg 903, .pos 918, .pos 919] := by
  change (g904 E = true) → (¬ (g919 E = true)) → (¬ (g920 E = true)) → False
  exact pattern_6 (g904 E) (g919 E)
private theorem sat_489 (E : Nat → Bool) : (valuation E).satisfies [.neg 913, .pos 390, .pos 931] := by
  change (g914 E = true) → (¬ (g391 E = true)) → (¬ (g932 E = true)) → False
  exact pattern_3 (g391 E) (g914 E)
private theorem sat_490 (E : Nat → Bool) : (valuation E).satisfies [.neg 932, .neg 913] := by
  change (g933 E = true) → (g914 E = true) → False
  exact pattern_4 (g391 E) (g914 E)
private theorem sat_491 (E : Nat → Bool) : (valuation E).satisfies [.neg 932, .pos 390] := by
  change (g933 E = true) → (¬ (g391 E = true)) → False
  exact pattern_5 (g391 E) (g914 E)
private theorem sat_492 (E : Nat → Bool) : (valuation E).satisfies [.neg 915, .pos 932, .pos 933] := by
  change (g916 E = true) → (¬ (g933 E = true)) → (¬ (g934 E = true)) → False
  exact pattern_6 (g916 E) (g933 E)
private theorem sat_493 (E : Nat → Bool) : (valuation E).satisfies [.neg 934, .neg 915] := by
  change (g935 E = true) → (g916 E = true) → False
  exact pattern_4 (g391 E) (g916 E)
private theorem sat_494 (E : Nat → Bool) : (valuation E).satisfies [.neg 934, .pos 390] := by
  change (g935 E = true) → (¬ (g391 E = true)) → False
  exact pattern_5 (g391 E) (g916 E)
private theorem sat_495 (E : Nat → Bool) : (valuation E).satisfies [.neg 935, .pos 917] := by
  change (g936 E = true) → (¬ (g918 E = true)) → False
  exact pattern_5 (g918 E) (g935 E)
private theorem sat_496 (E : Nat → Bool) : (valuation E).satisfies [.neg 917, .pos 934, .pos 935] := by
  change (g918 E = true) → (¬ (g935 E = true)) → (¬ (g936 E = true)) → False
  exact pattern_6 (g918 E) (g935 E)
private theorem sat_497 (E : Nat → Bool) : (valuation E).satisfies [.neg 936, .neg 917] := by
  change (g937 E = true) → (g918 E = true) → False
  exact pattern_4 (g391 E) (g918 E)
private theorem sat_498 (E : Nat → Bool) : (valuation E).satisfies [.neg 936, .pos 390] := by
  change (g937 E = true) → (¬ (g391 E = true)) → False
  exact pattern_5 (g391 E) (g918 E)
private theorem sat_499 (E : Nat → Bool) : (valuation E).satisfies [.neg 919, .pos 936, .pos 937] := by
  change (g920 E = true) → (¬ (g937 E = true)) → (¬ (g938 E = true)) → False
  exact pattern_6 (g920 E) (g937 E)
private theorem sat_500 (E : Nat → Bool) : (valuation E).satisfies [.neg 931, .pos 391, .pos 951] := by
  change (g932 E = true) → (¬ (g392 E = true)) → (¬ (g952 E = true)) → False
  exact pattern_3 (g392 E) (g932 E)
private theorem sat_501 (E : Nat → Bool) : (valuation E).satisfies [.neg 952, .pos 391] := by
  change (g953 E = true) → (¬ (g392 E = true)) → False
  exact pattern_5 (g392 E) (g932 E)
private theorem sat_502 (E : Nat → Bool) : (valuation E).satisfies [.neg 933, .pos 952, .pos 953] := by
  change (g934 E = true) → (¬ (g953 E = true)) → (¬ (g954 E = true)) → False
  exact pattern_6 (g934 E) (g953 E)
private theorem sat_503 (E : Nat → Bool) : (valuation E).satisfies [.neg 954, .neg 933] := by
  change (g955 E = true) → (g934 E = true) → False
  exact pattern_4 (g392 E) (g934 E)
private theorem sat_504 (E : Nat → Bool) : (valuation E).satisfies [.neg 954, .pos 391] := by
  change (g955 E = true) → (¬ (g392 E = true)) → False
  exact pattern_5 (g392 E) (g934 E)
private theorem sat_505 (E : Nat → Bool) : (valuation E).satisfies [.neg 955, .pos 935] := by
  change (g956 E = true) → (¬ (g936 E = true)) → False
  exact pattern_5 (g936 E) (g955 E)
private theorem sat_506 (E : Nat → Bool) : (valuation E).satisfies [.neg 935, .pos 954, .pos 955] := by
  change (g936 E = true) → (¬ (g955 E = true)) → (¬ (g956 E = true)) → False
  exact pattern_6 (g936 E) (g955 E)
private theorem sat_507 (E : Nat → Bool) : (valuation E).satisfies [.neg 956, .neg 935] := by
  change (g957 E = true) → (g936 E = true) → False
  exact pattern_4 (g392 E) (g936 E)
private theorem sat_508 (E : Nat → Bool) : (valuation E).satisfies [.neg 956, .pos 391] := by
  change (g957 E = true) → (¬ (g392 E = true)) → False
  exact pattern_5 (g392 E) (g936 E)
private theorem sat_509 (E : Nat → Bool) : (valuation E).satisfies [.neg 937, .pos 956, .pos 957] := by
  change (g938 E = true) → (¬ (g957 E = true)) → (¬ (g958 E = true)) → False
  exact pattern_6 (g938 E) (g957 E)
private theorem sat_510 (E : Nat → Bool) : (valuation E).satisfies [.neg 951, .pos 392, .pos 973] := by
  change (g952 E = true) → (¬ (g393 E = true)) → (¬ (g974 E = true)) → False
  exact pattern_3 (g393 E) (g952 E)
private theorem sat_511 (E : Nat → Bool) : (valuation E).satisfies [.neg 974, .pos 392] := by
  change (g975 E = true) → (¬ (g393 E = true)) → False
  exact pattern_5 (g393 E) (g952 E)
private theorem sat_512 (E : Nat → Bool) : (valuation E).satisfies [.neg 953, .pos 974, .pos 975] := by
  change (g954 E = true) → (¬ (g975 E = true)) → (¬ (g976 E = true)) → False
  exact pattern_6 (g954 E) (g975 E)
private theorem sat_513 (E : Nat → Bool) : (valuation E).satisfies [.neg 976, .pos 392] := by
  change (g977 E = true) → (¬ (g393 E = true)) → False
  exact pattern_5 (g393 E) (g954 E)
private theorem sat_514 (E : Nat → Bool) : (valuation E).satisfies [.neg 977, .pos 955] := by
  change (g978 E = true) → (¬ (g956 E = true)) → False
  exact pattern_5 (g956 E) (g977 E)
private theorem sat_515 (E : Nat → Bool) : (valuation E).satisfies [.neg 955, .pos 976, .pos 977] := by
  change (g956 E = true) → (¬ (g977 E = true)) → (¬ (g978 E = true)) → False
  exact pattern_6 (g956 E) (g977 E)
private theorem sat_516 (E : Nat → Bool) : (valuation E).satisfies [.neg 978, .pos 392] := by
  change (g979 E = true) → (¬ (g393 E = true)) → False
  exact pattern_5 (g393 E) (g956 E)
private theorem sat_517 (E : Nat → Bool) : (valuation E).satisfies [.neg 957, .pos 978, .pos 979] := by
  change (g958 E = true) → (¬ (g979 E = true)) → (¬ (g980 E = true)) → False
  exact pattern_6 (g958 E) (g979 E)
private theorem sat_518 (E : Nat → Bool) : (valuation E).satisfies [.neg 973, .pos 393, .pos 997] := by
  change (g974 E = true) → (¬ (g394 E = true)) → (¬ (g998 E = true)) → False
  exact pattern_3 (g394 E) (g974 E)
private theorem sat_519 (E : Nat → Bool) : (valuation E).satisfies [.neg 998, .pos 393] := by
  change (g999 E = true) → (¬ (g394 E = true)) → False
  exact pattern_5 (g394 E) (g974 E)
private theorem sat_520 (E : Nat → Bool) : (valuation E).satisfies [.neg 975, .pos 998, .pos 999] := by
  change (g976 E = true) → (¬ (g999 E = true)) → (¬ (g1000 E = true)) → False
  exact pattern_6 (g976 E) (g999 E)
private theorem sat_521 (E : Nat → Bool) : (valuation E).satisfies [.neg 1000, .pos 393] := by
  change (g1001 E = true) → (¬ (g394 E = true)) → False
  exact pattern_5 (g394 E) (g976 E)
private theorem sat_522 (E : Nat → Bool) : (valuation E).satisfies [.neg 1001, .pos 977] := by
  change (g1002 E = true) → (¬ (g978 E = true)) → False
  exact pattern_5 (g978 E) (g1001 E)
private theorem sat_523 (E : Nat → Bool) : (valuation E).satisfies [.neg 977, .pos 1000, .pos 1001] := by
  change (g978 E = true) → (¬ (g1001 E = true)) → (¬ (g1002 E = true)) → False
  exact pattern_6 (g978 E) (g1001 E)
private theorem sat_524 (E : Nat → Bool) : (valuation E).satisfies [.neg 1002, .pos 393] := by
  change (g1003 E = true) → (¬ (g394 E = true)) → False
  exact pattern_5 (g394 E) (g978 E)
private theorem sat_525 (E : Nat → Bool) : (valuation E).satisfies [.neg 979, .pos 1002, .pos 1003] := by
  change (g980 E = true) → (¬ (g1003 E = true)) → (¬ (g1004 E = true)) → False
  exact pattern_6 (g980 E) (g1003 E)
private theorem sat_526 (E : Nat → Bool) : (valuation E).satisfies [.neg 997, .pos 394, .pos 1023] := by
  change (g998 E = true) → (¬ (g395 E = true)) → (¬ (g1024 E = true)) → False
  exact pattern_3 (g395 E) (g998 E)
private theorem sat_527 (E : Nat → Bool) : (valuation E).satisfies [.neg 1024, .pos 394] := by
  change (g1025 E = true) → (¬ (g395 E = true)) → False
  exact pattern_5 (g395 E) (g998 E)
private theorem sat_528 (E : Nat → Bool) : (valuation E).satisfies [.neg 999, .pos 1024, .pos 1025] := by
  change (g1000 E = true) → (¬ (g1025 E = true)) → (¬ (g1026 E = true)) → False
  exact pattern_6 (g1000 E) (g1025 E)
private theorem sat_529 (E : Nat → Bool) : (valuation E).satisfies [.neg 1026, .pos 394] := by
  change (g1027 E = true) → (¬ (g395 E = true)) → False
  exact pattern_5 (g395 E) (g1000 E)
private theorem sat_530 (E : Nat → Bool) : (valuation E).satisfies [.neg 1027, .pos 1001] := by
  change (g1028 E = true) → (¬ (g1002 E = true)) → False
  exact pattern_5 (g1002 E) (g1027 E)
private theorem sat_531 (E : Nat → Bool) : (valuation E).satisfies [.neg 1001, .pos 1026, .pos 1027] := by
  change (g1002 E = true) → (¬ (g1027 E = true)) → (¬ (g1028 E = true)) → False
  exact pattern_6 (g1002 E) (g1027 E)
private theorem sat_532 (E : Nat → Bool) : (valuation E).satisfies [.neg 1028, .pos 394] := by
  change (g1029 E = true) → (¬ (g395 E = true)) → False
  exact pattern_5 (g395 E) (g1002 E)
private theorem sat_533 (E : Nat → Bool) : (valuation E).satisfies [.neg 1003, .pos 1028, .pos 1029] := by
  change (g1004 E = true) → (¬ (g1029 E = true)) → (¬ (g1030 E = true)) → False
  exact pattern_6 (g1004 E) (g1029 E)
private theorem sat_534 (E : Nat → Bool) : (valuation E).satisfies [.neg 1052, .neg 1023] := by
  change (g1053 E = true) → (g1024 E = true) → False
  exact pattern_4 (g396 E) (g1024 E)
private theorem sat_535 (E : Nat → Bool) : (valuation E).satisfies [.neg 1052, .pos 395] := by
  change (g1053 E = true) → (¬ (g396 E = true)) → False
  exact pattern_5 (g396 E) (g1024 E)
private theorem sat_536 (E : Nat → Bool) : (valuation E).satisfies [.neg 1025, .pos 1052, .pos 1053] := by
  change (g1026 E = true) → (¬ (g1053 E = true)) → (¬ (g1054 E = true)) → False
  exact pattern_6 (g1026 E) (g1053 E)
private theorem sat_537 (E : Nat → Bool) : (valuation E).satisfies [.neg 1054, .neg 1025] := by
  change (g1055 E = true) → (g1026 E = true) → False
  exact pattern_4 (g396 E) (g1026 E)
private theorem sat_538 (E : Nat → Bool) : (valuation E).satisfies [.neg 1054, .pos 395] := by
  change (g1055 E = true) → (¬ (g396 E = true)) → False
  exact pattern_5 (g396 E) (g1026 E)
private theorem sat_539 (E : Nat → Bool) : (valuation E).satisfies [.neg 1055, .pos 1027] := by
  change (g1056 E = true) → (¬ (g1028 E = true)) → False
  exact pattern_5 (g1028 E) (g1055 E)
private theorem sat_540 (E : Nat → Bool) : (valuation E).satisfies [.neg 1027, .pos 1054, .pos 1055] := by
  change (g1028 E = true) → (¬ (g1055 E = true)) → (¬ (g1056 E = true)) → False
  exact pattern_6 (g1028 E) (g1055 E)
private theorem sat_541 (E : Nat → Bool) : (valuation E).satisfies [.neg 1056, .pos 395] := by
  change (g1057 E = true) → (¬ (g396 E = true)) → False
  exact pattern_5 (g396 E) (g1028 E)
private theorem sat_542 (E : Nat → Bool) : (valuation E).satisfies [.neg 1029, .pos 1056, .pos 1057] := by
  change (g1030 E = true) → (¬ (g1057 E = true)) → (¬ (g1058 E = true)) → False
  exact pattern_6 (g1030 E) (g1057 E)
private theorem sat_543 (E : Nat → Bool) : (valuation E).satisfies [.neg 1082, .pos 396] := by
  change (g1083 E = true) → (¬ (g397 E = true)) → False
  exact pattern_5 (g397 E) (g1052 E)
private theorem sat_544 (E : Nat → Bool) : (valuation E).satisfies [.neg 1053, .pos 1082, .pos 1083] := by
  change (g1054 E = true) → (¬ (g1083 E = true)) → (¬ (g1084 E = true)) → False
  exact pattern_6 (g1054 E) (g1083 E)
private theorem sat_545 (E : Nat → Bool) : (valuation E).satisfies [.neg 1084, .neg 1053] := by
  change (g1085 E = true) → (g1054 E = true) → False
  exact pattern_4 (g397 E) (g1054 E)
private theorem sat_546 (E : Nat → Bool) : (valuation E).satisfies [.neg 1084, .pos 396] := by
  change (g1085 E = true) → (¬ (g397 E = true)) → False
  exact pattern_5 (g397 E) (g1054 E)
private theorem sat_547 (E : Nat → Bool) : (valuation E).satisfies [.neg 1085, .pos 1055] := by
  change (g1086 E = true) → (¬ (g1056 E = true)) → False
  exact pattern_5 (g1056 E) (g1085 E)
private theorem sat_548 (E : Nat → Bool) : (valuation E).satisfies [.neg 1055, .pos 1084, .pos 1085] := by
  change (g1056 E = true) → (¬ (g1085 E = true)) → (¬ (g1086 E = true)) → False
  exact pattern_6 (g1056 E) (g1085 E)
private theorem sat_549 (E : Nat → Bool) : (valuation E).satisfies [.neg 1086, .pos 396] := by
  change (g1087 E = true) → (¬ (g397 E = true)) → False
  exact pattern_5 (g397 E) (g1056 E)
private theorem sat_550 (E : Nat → Bool) : (valuation E).satisfies [.neg 1057, .pos 1086, .pos 1087] := by
  change (g1058 E = true) → (¬ (g1087 E = true)) → (¬ (g1088 E = true)) → False
  exact pattern_6 (g1058 E) (g1087 E)
private theorem sat_551 (E : Nat → Bool) : (valuation E).satisfies [.neg 1114, .pos 397] := by
  change (g1115 E = true) → (¬ (g398 E = true)) → False
  exact pattern_5 (g398 E) (g1082 E)
private theorem sat_552 (E : Nat → Bool) : (valuation E).satisfies [.neg 1083, .pos 1114, .pos 1115] := by
  change (g1084 E = true) → (¬ (g1115 E = true)) → (¬ (g1116 E = true)) → False
  exact pattern_6 (g1084 E) (g1115 E)
private theorem sat_553 (E : Nat → Bool) : (valuation E).satisfies [.neg 1116, .pos 397] := by
  change (g1117 E = true) → (¬ (g398 E = true)) → False
  exact pattern_5 (g398 E) (g1084 E)
private theorem sat_554 (E : Nat → Bool) : (valuation E).satisfies [.neg 1117, .pos 1085] := by
  change (g1118 E = true) → (¬ (g1086 E = true)) → False
  exact pattern_5 (g1086 E) (g1117 E)
private theorem sat_555 (E : Nat → Bool) : (valuation E).satisfies [.neg 1085, .pos 1116, .pos 1117] := by
  change (g1086 E = true) → (¬ (g1117 E = true)) → (¬ (g1118 E = true)) → False
  exact pattern_6 (g1086 E) (g1117 E)
private theorem sat_556 (E : Nat → Bool) : (valuation E).satisfies [.neg 1118, .pos 397] := by
  change (g1119 E = true) → (¬ (g398 E = true)) → False
  exact pattern_5 (g398 E) (g1086 E)
private theorem sat_557 (E : Nat → Bool) : (valuation E).satisfies [.neg 1087, .pos 1118, .pos 1119] := by
  change (g1088 E = true) → (¬ (g1119 E = true)) → (¬ (g1120 E = true)) → False
  exact pattern_6 (g1088 E) (g1119 E)
private theorem sat_558 (E : Nat → Bool) : (valuation E).satisfies [.neg 1148, .pos 398] := by
  change (g1149 E = true) → (¬ (g399 E = true)) → False
  exact pattern_5 (g399 E) (g1114 E)
private theorem sat_559 (E : Nat → Bool) : (valuation E).satisfies [.neg 1115, .pos 1148, .pos 1149] := by
  change (g1116 E = true) → (¬ (g1149 E = true)) → (¬ (g1150 E = true)) → False
  exact pattern_6 (g1116 E) (g1149 E)
private theorem sat_560 (E : Nat → Bool) : (valuation E).satisfies [.neg 1150, .pos 398] := by
  change (g1151 E = true) → (¬ (g399 E = true)) → False
  exact pattern_5 (g399 E) (g1116 E)
private theorem sat_561 (E : Nat → Bool) : (valuation E).satisfies [.neg 1117, .pos 1150, .pos 1151] := by
  change (g1118 E = true) → (¬ (g1151 E = true)) → (¬ (g1152 E = true)) → False
  exact pattern_6 (g1118 E) (g1151 E)
private theorem sat_562 (E : Nat → Bool) : (valuation E).satisfies [.neg 1152, .pos 398] := by
  change (g1153 E = true) → (¬ (g399 E = true)) → False
  exact pattern_5 (g399 E) (g1118 E)
private theorem sat_563 (E : Nat → Bool) : (valuation E).satisfies [.neg 1119, .pos 1152, .pos 1153] := by
  change (g1120 E = true) → (¬ (g1153 E = true)) → (¬ (g1154 E = true)) → False
  exact pattern_6 (g1120 E) (g1153 E)
private theorem sat_564 (E : Nat → Bool) : (valuation E).satisfies [.neg 1184, .pos 399] := by
  change (g1185 E = true) → (¬ (g400 E = true)) → False
  exact pattern_5 (g400 E) (g1148 E)
private theorem sat_565 (E : Nat → Bool) : (valuation E).satisfies [.neg 1149, .pos 1184, .pos 1185] := by
  change (g1150 E = true) → (¬ (g1185 E = true)) → (¬ (g1186 E = true)) → False
  exact pattern_6 (g1150 E) (g1185 E)
private theorem sat_566 (E : Nat → Bool) : (valuation E).satisfies [.neg 1186, .pos 399] := by
  change (g1187 E = true) → (¬ (g400 E = true)) → False
  exact pattern_5 (g400 E) (g1150 E)
private theorem sat_567 (E : Nat → Bool) : (valuation E).satisfies [.neg 1151, .pos 1186, .pos 1187] := by
  change (g1152 E = true) → (¬ (g1187 E = true)) → (¬ (g1188 E = true)) → False
  exact pattern_6 (g1152 E) (g1187 E)
private theorem sat_568 (E : Nat → Bool) : (valuation E).satisfies [.neg 1188, .pos 399] := by
  change (g1189 E = true) → (¬ (g400 E = true)) → False
  exact pattern_5 (g400 E) (g1152 E)
private theorem sat_569 (E : Nat → Bool) : (valuation E).satisfies [.neg 1153, .pos 1188, .pos 1189] := by
  change (g1154 E = true) → (¬ (g1189 E = true)) → (¬ (g1190 E = true)) → False
  exact pattern_6 (g1154 E) (g1189 E)
private theorem sat_570 (E : Nat → Bool) : (valuation E).satisfies [.neg 1224, .neg 1185] := by
  change (g1225 E = true) → (g1186 E = true) → False
  exact pattern_4 (g401 E) (g1186 E)
private theorem sat_571 (E : Nat → Bool) : (valuation E).satisfies [.neg 1224, .pos 400] := by
  change (g1225 E = true) → (¬ (g401 E = true)) → False
  exact pattern_5 (g401 E) (g1186 E)
private theorem sat_572 (E : Nat → Bool) : (valuation E).satisfies [.neg 1187, .pos 1224, .pos 1225] := by
  change (g1188 E = true) → (¬ (g1225 E = true)) → (¬ (g1226 E = true)) → False
  exact pattern_6 (g1188 E) (g1225 E)
private theorem sat_573 (E : Nat → Bool) : (valuation E).satisfies [.neg 1226, .neg 1187] := by
  change (g1227 E = true) → (g1188 E = true) → False
  exact pattern_4 (g401 E) (g1188 E)
private theorem sat_574 (E : Nat → Bool) : (valuation E).satisfies [.neg 1226, .pos 400] := by
  change (g1227 E = true) → (¬ (g401 E = true)) → False
  exact pattern_5 (g401 E) (g1188 E)
private theorem sat_575 (E : Nat → Bool) : (valuation E).satisfies [.neg 1189, .pos 1226, .pos 1227] := by
  change (g1190 E = true) → (¬ (g1227 E = true)) → (¬ (g1228 E = true)) → False
  exact pattern_6 (g1190 E) (g1227 E)
private theorem sat_576 (E : Nat → Bool) : (valuation E).satisfies [.pos 365, .pos 371, .pos 1261] := by
  change (¬ (g366 E = true)) → (¬ (g372 E = true)) → (¬ (g1262 E = true)) → False
  exact pattern_0 (g366 E) (g372 E)
private theorem sat_577 (E : Nat → Bool) : (valuation E).satisfies [.neg 1262, .pos 365] := by
  change (g1263 E = true) → (¬ (g366 E = true)) → False
  exact pattern_1 (g366 E) (g372 E)
private theorem sat_578 (E : Nat → Bool) : (valuation E).satisfies [.neg 1262, .pos 371] := by
  change (g1263 E = true) → (¬ (g372 E = true)) → False
  exact pattern_2 (g366 E) (g372 E)
private theorem sat_579 (E : Nat → Bool) : (valuation E).satisfies [.neg 1261, .pos 372, .pos 1263] := by
  change (g1262 E = true) → (¬ (g373 E = true)) → (¬ (g1264 E = true)) → False
  exact pattern_3 (g373 E) (g1262 E)
private theorem sat_580 (E : Nat → Bool) : (valuation E).satisfies [.neg 1264, .neg 1261] := by
  change (g1265 E = true) → (g1262 E = true) → False
  exact pattern_4 (g373 E) (g1262 E)
private theorem sat_581 (E : Nat → Bool) : (valuation E).satisfies [.neg 1264, .pos 372] := by
  change (g1265 E = true) → (¬ (g373 E = true)) → False
  exact pattern_5 (g373 E) (g1262 E)
private theorem sat_582 (E : Nat → Bool) : (valuation E).satisfies [.pos 1262, .pos 1264, .pos 1265] := by
  change (¬ (g1263 E = true)) → (¬ (g1265 E = true)) → (¬ (g1266 E = true)) → False
  exact pattern_0 (g1263 E) (g1265 E)
private theorem sat_583 (E : Nat → Bool) : (valuation E).satisfies [.neg 1266, .pos 372] := by
  change (g1267 E = true) → (¬ (g373 E = true)) → False
  exact pattern_1 (g373 E) (g1263 E)
private theorem sat_584 (E : Nat → Bool) : (valuation E).satisfies [.neg 1266, .pos 1262] := by
  change (g1267 E = true) → (¬ (g1263 E = true)) → False
  exact pattern_2 (g373 E) (g1263 E)
private theorem sat_585 (E : Nat → Bool) : (valuation E).satisfies [.neg 1263, .pos 373, .pos 1267] := by
  change (g1264 E = true) → (¬ (g374 E = true)) → (¬ (g1268 E = true)) → False
  exact pattern_3 (g374 E) (g1264 E)
private theorem sat_586 (E : Nat → Bool) : (valuation E).satisfies [.neg 1268, .neg 1263] := by
  change (g1269 E = true) → (g1264 E = true) → False
  exact pattern_4 (g374 E) (g1264 E)
private theorem sat_587 (E : Nat → Bool) : (valuation E).satisfies [.neg 1268, .pos 373] := by
  change (g1269 E = true) → (¬ (g374 E = true)) → False
  exact pattern_5 (g374 E) (g1264 E)
private theorem sat_588 (E : Nat → Bool) : (valuation E).satisfies [.neg 1265, .pos 1268, .pos 1269] := by
  change (g1266 E = true) → (¬ (g1269 E = true)) → (¬ (g1270 E = true)) → False
  exact pattern_6 (g1266 E) (g1269 E)
private theorem sat_589 (E : Nat → Bool) : (valuation E).satisfies [.neg 1270, .neg 1265] := by
  change (g1271 E = true) → (g1266 E = true) → False
  exact pattern_4 (g374 E) (g1266 E)
private theorem sat_590 (E : Nat → Bool) : (valuation E).satisfies [.neg 1270, .pos 373] := by
  change (g1271 E = true) → (¬ (g374 E = true)) → False
  exact pattern_5 (g374 E) (g1266 E)
private theorem sat_591 (E : Nat → Bool) : (valuation E).satisfies [.pos 1266, .pos 1270, .pos 1271] := by
  change (¬ (g1267 E = true)) → (¬ (g1271 E = true)) → (¬ (g1272 E = true)) → False
  exact pattern_0 (g1267 E) (g1271 E)
private theorem sat_592 (E : Nat → Bool) : (valuation E).satisfies [.neg 1272, .pos 373] := by
  change (g1273 E = true) → (¬ (g374 E = true)) → False
  exact pattern_1 (g374 E) (g1267 E)
private theorem sat_593 (E : Nat → Bool) : (valuation E).satisfies [.neg 1272, .pos 1266] := by
  change (g1273 E = true) → (¬ (g1267 E = true)) → False
  exact pattern_2 (g374 E) (g1267 E)
private theorem sat_594 (E : Nat → Bool) : (valuation E).satisfies [.neg 1267, .pos 374, .pos 1273] := by
  change (g1268 E = true) → (¬ (g375 E = true)) → (¬ (g1274 E = true)) → False
  exact pattern_3 (g375 E) (g1268 E)
private theorem sat_595 (E : Nat → Bool) : (valuation E).satisfies [.neg 1274, .pos 374] := by
  change (g1275 E = true) → (¬ (g375 E = true)) → False
  exact pattern_5 (g375 E) (g1268 E)
private theorem sat_596 (E : Nat → Bool) : (valuation E).satisfies [.neg 1269, .pos 1274, .pos 1275] := by
  change (g1270 E = true) → (¬ (g1275 E = true)) → (¬ (g1276 E = true)) → False
  exact pattern_6 (g1270 E) (g1275 E)
private theorem sat_597 (E : Nat → Bool) : (valuation E).satisfies [.neg 1276, .neg 1269] := by
  change (g1277 E = true) → (g1270 E = true) → False
  exact pattern_4 (g375 E) (g1270 E)
private theorem sat_598 (E : Nat → Bool) : (valuation E).satisfies [.neg 1276, .pos 374] := by
  change (g1277 E = true) → (¬ (g375 E = true)) → False
  exact pattern_5 (g375 E) (g1270 E)
private theorem sat_599 (E : Nat → Bool) : (valuation E).satisfies [.neg 1271, .pos 1276, .pos 1277] := by
  change (g1272 E = true) → (¬ (g1277 E = true)) → (¬ (g1278 E = true)) → False
  exact pattern_6 (g1272 E) (g1277 E)
private theorem sat_600 (E : Nat → Bool) : (valuation E).satisfies [.neg 1278, .neg 1271] := by
  change (g1279 E = true) → (g1272 E = true) → False
  exact pattern_4 (g375 E) (g1272 E)
private theorem sat_601 (E : Nat → Bool) : (valuation E).satisfies [.neg 1278, .pos 374] := by
  change (g1279 E = true) → (¬ (g375 E = true)) → False
  exact pattern_5 (g375 E) (g1272 E)
private theorem sat_602 (E : Nat → Bool) : (valuation E).satisfies [.pos 1272, .pos 1278, .pos 1279] := by
  change (¬ (g1273 E = true)) → (¬ (g1279 E = true)) → (¬ (g1280 E = true)) → False
  exact pattern_0 (g1273 E) (g1279 E)
private theorem sat_603 (E : Nat → Bool) : (valuation E).satisfies [.neg 1273, .pos 375, .pos 1281] := by
  change (g1274 E = true) → (¬ (g376 E = true)) → (¬ (g1282 E = true)) → False
  exact pattern_3 (g376 E) (g1274 E)
private theorem sat_604 (E : Nat → Bool) : (valuation E).satisfies [.neg 1282, .pos 375] := by
  change (g1283 E = true) → (¬ (g376 E = true)) → False
  exact pattern_5 (g376 E) (g1274 E)
private theorem sat_605 (E : Nat → Bool) : (valuation E).satisfies [.neg 1275, .pos 1282, .pos 1283] := by
  change (g1276 E = true) → (¬ (g1283 E = true)) → (¬ (g1284 E = true)) → False
  exact pattern_6 (g1276 E) (g1283 E)
private theorem sat_606 (E : Nat → Bool) : (valuation E).satisfies [.neg 1284, .pos 375] := by
  change (g1285 E = true) → (¬ (g376 E = true)) → False
  exact pattern_5 (g376 E) (g1276 E)
private theorem sat_607 (E : Nat → Bool) : (valuation E).satisfies [.neg 1277, .pos 1284, .pos 1285] := by
  change (g1278 E = true) → (¬ (g1285 E = true)) → (¬ (g1286 E = true)) → False
  exact pattern_6 (g1278 E) (g1285 E)
private theorem sat_608 (E : Nat → Bool) : (valuation E).satisfies [.neg 1286, .neg 1277] := by
  change (g1287 E = true) → (g1278 E = true) → False
  exact pattern_4 (g376 E) (g1278 E)
private theorem sat_609 (E : Nat → Bool) : (valuation E).satisfies [.neg 1286, .pos 375] := by
  change (g1287 E = true) → (¬ (g376 E = true)) → False
  exact pattern_5 (g376 E) (g1278 E)
private theorem sat_610 (E : Nat → Bool) : (valuation E).satisfies [.neg 1279, .pos 1286, .pos 1287] := by
  change (g1280 E = true) → (¬ (g1287 E = true)) → (¬ (g1288 E = true)) → False
  exact pattern_6 (g1280 E) (g1287 E)
private theorem sat_611 (E : Nat → Bool) : (valuation E).satisfies [.neg 1281, .pos 386, .pos 1291] := by
  change (g1282 E = true) → (¬ (g387 E = true)) → (¬ (g1292 E = true)) → False
  exact pattern_3 (g387 E) (g1282 E)
private theorem sat_612 (E : Nat → Bool) : (valuation E).satisfies [.neg 1292, .neg 1281] := by
  change (g1293 E = true) → (g1282 E = true) → False
  exact pattern_4 (g387 E) (g1282 E)
private theorem sat_613 (E : Nat → Bool) : (valuation E).satisfies [.neg 1292, .pos 386] := by
  change (g1293 E = true) → (¬ (g387 E = true)) → False
  exact pattern_5 (g387 E) (g1282 E)
private theorem sat_614 (E : Nat → Bool) : (valuation E).satisfies [.neg 1283, .pos 1292, .pos 1293] := by
  change (g1284 E = true) → (¬ (g1293 E = true)) → (¬ (g1294 E = true)) → False
  exact pattern_6 (g1284 E) (g1293 E)
private theorem sat_615 (E : Nat → Bool) : (valuation E).satisfies [.neg 1294, .neg 1283] := by
  change (g1295 E = true) → (g1284 E = true) → False
  exact pattern_4 (g387 E) (g1284 E)
private theorem sat_616 (E : Nat → Bool) : (valuation E).satisfies [.neg 1294, .pos 386] := by
  change (g1295 E = true) → (¬ (g387 E = true)) → False
  exact pattern_5 (g387 E) (g1284 E)
private theorem sat_617 (E : Nat → Bool) : (valuation E).satisfies [.neg 1285, .pos 1294, .pos 1295] := by
  change (g1286 E = true) → (¬ (g1295 E = true)) → (¬ (g1296 E = true)) → False
  exact pattern_6 (g1286 E) (g1295 E)
private theorem sat_618 (E : Nat → Bool) : (valuation E).satisfies [.neg 1296, .neg 1285] := by
  change (g1297 E = true) → (g1286 E = true) → False
  exact pattern_4 (g387 E) (g1286 E)
private theorem sat_619 (E : Nat → Bool) : (valuation E).satisfies [.neg 1296, .pos 386] := by
  change (g1297 E = true) → (¬ (g387 E = true)) → False
  exact pattern_5 (g387 E) (g1286 E)
private theorem sat_620 (E : Nat → Bool) : (valuation E).satisfies [.neg 1287, .pos 1296, .pos 1297] := by
  change (g1288 E = true) → (¬ (g1297 E = true)) → (¬ (g1298 E = true)) → False
  exact pattern_6 (g1288 E) (g1297 E)
private theorem sat_621 (E : Nat → Bool) : (valuation E).satisfies [.neg 1291, .pos 387, .pos 1303] := by
  change (g1292 E = true) → (¬ (g388 E = true)) → (¬ (g1304 E = true)) → False
  exact pattern_3 (g388 E) (g1292 E)
private theorem sat_622 (E : Nat → Bool) : (valuation E).satisfies [.neg 1304, .neg 1291] := by
  change (g1305 E = true) → (g1292 E = true) → False
  exact pattern_4 (g388 E) (g1292 E)
private theorem sat_623 (E : Nat → Bool) : (valuation E).satisfies [.neg 1304, .pos 387] := by
  change (g1305 E = true) → (¬ (g388 E = true)) → False
  exact pattern_5 (g388 E) (g1292 E)
private theorem sat_624 (E : Nat → Bool) : (valuation E).satisfies [.neg 1293, .pos 1304, .pos 1305] := by
  change (g1294 E = true) → (¬ (g1305 E = true)) → (¬ (g1306 E = true)) → False
  exact pattern_6 (g1294 E) (g1305 E)
private theorem sat_625 (E : Nat → Bool) : (valuation E).satisfies [.neg 1306, .neg 1293] := by
  change (g1307 E = true) → (g1294 E = true) → False
  exact pattern_4 (g388 E) (g1294 E)
private theorem sat_626 (E : Nat → Bool) : (valuation E).satisfies [.neg 1306, .pos 387] := by
  change (g1307 E = true) → (¬ (g388 E = true)) → False
  exact pattern_5 (g388 E) (g1294 E)
private theorem sat_627 (E : Nat → Bool) : (valuation E).satisfies [.neg 1295, .pos 1306, .pos 1307] := by
  change (g1296 E = true) → (¬ (g1307 E = true)) → (¬ (g1308 E = true)) → False
  exact pattern_6 (g1296 E) (g1307 E)
private theorem sat_628 (E : Nat → Bool) : (valuation E).satisfies [.neg 1308, .neg 1295] := by
  change (g1309 E = true) → (g1296 E = true) → False
  exact pattern_4 (g388 E) (g1296 E)
private theorem sat_629 (E : Nat → Bool) : (valuation E).satisfies [.neg 1308, .pos 387] := by
  change (g1309 E = true) → (¬ (g388 E = true)) → False
  exact pattern_5 (g388 E) (g1296 E)
private theorem sat_630 (E : Nat → Bool) : (valuation E).satisfies [.neg 1297, .pos 1308, .pos 1309] := by
  change (g1298 E = true) → (¬ (g1309 E = true)) → (¬ (g1310 E = true)) → False
  exact pattern_6 (g1298 E) (g1309 E)
private theorem sat_631 (E : Nat → Bool) : (valuation E).satisfies [.neg 1303, .pos 388, .pos 1317] := by
  change (g1304 E = true) → (¬ (g389 E = true)) → (¬ (g1318 E = true)) → False
  exact pattern_3 (g389 E) (g1304 E)
private theorem sat_632 (E : Nat → Bool) : (valuation E).satisfies [.neg 1318, .neg 1303] := by
  change (g1319 E = true) → (g1304 E = true) → False
  exact pattern_4 (g389 E) (g1304 E)
private theorem sat_633 (E : Nat → Bool) : (valuation E).satisfies [.neg 1318, .pos 388] := by
  change (g1319 E = true) → (¬ (g389 E = true)) → False
  exact pattern_5 (g389 E) (g1304 E)
private theorem sat_634 (E : Nat → Bool) : (valuation E).satisfies [.neg 1305, .pos 1318, .pos 1319] := by
  change (g1306 E = true) → (¬ (g1319 E = true)) → (¬ (g1320 E = true)) → False
  exact pattern_6 (g1306 E) (g1319 E)
private theorem sat_635 (E : Nat → Bool) : (valuation E).satisfies [.neg 1320, .neg 1305] := by
  change (g1321 E = true) → (g1306 E = true) → False
  exact pattern_4 (g389 E) (g1306 E)
private theorem sat_636 (E : Nat → Bool) : (valuation E).satisfies [.neg 1320, .pos 388] := by
  change (g1321 E = true) → (¬ (g389 E = true)) → False
  exact pattern_5 (g389 E) (g1306 E)
private theorem sat_637 (E : Nat → Bool) : (valuation E).satisfies [.neg 1307, .pos 1320, .pos 1321] := by
  change (g1308 E = true) → (¬ (g1321 E = true)) → (¬ (g1322 E = true)) → False
  exact pattern_6 (g1308 E) (g1321 E)
private theorem sat_638 (E : Nat → Bool) : (valuation E).satisfies [.neg 1322, .neg 1307] := by
  change (g1323 E = true) → (g1308 E = true) → False
  exact pattern_4 (g389 E) (g1308 E)
private theorem sat_639 (E : Nat → Bool) : (valuation E).satisfies [.neg 1322, .pos 388] := by
  change (g1323 E = true) → (¬ (g389 E = true)) → False
  exact pattern_5 (g389 E) (g1308 E)
private theorem sat_640 (E : Nat → Bool) : (valuation E).satisfies [.neg 1309, .pos 1322, .pos 1323] := by
  change (g1310 E = true) → (¬ (g1323 E = true)) → (¬ (g1324 E = true)) → False
  exact pattern_6 (g1310 E) (g1323 E)
private theorem sat_641 (E : Nat → Bool) : (valuation E).satisfies [.neg 1317, .pos 389, .pos 1333] := by
  change (g1318 E = true) → (¬ (g390 E = true)) → (¬ (g1334 E = true)) → False
  exact pattern_3 (g390 E) (g1318 E)
private theorem sat_642 (E : Nat → Bool) : (valuation E).satisfies [.neg 1334, .neg 1317] := by
  change (g1335 E = true) → (g1318 E = true) → False
  exact pattern_4 (g390 E) (g1318 E)
private theorem sat_643 (E : Nat → Bool) : (valuation E).satisfies [.neg 1334, .pos 389] := by
  change (g1335 E = true) → (¬ (g390 E = true)) → False
  exact pattern_5 (g390 E) (g1318 E)
private theorem sat_644 (E : Nat → Bool) : (valuation E).satisfies [.neg 1319, .pos 1334, .pos 1335] := by
  change (g1320 E = true) → (¬ (g1335 E = true)) → (¬ (g1336 E = true)) → False
  exact pattern_6 (g1320 E) (g1335 E)
private theorem sat_645 (E : Nat → Bool) : (valuation E).satisfies [.neg 1336, .neg 1319] := by
  change (g1337 E = true) → (g1320 E = true) → False
  exact pattern_4 (g390 E) (g1320 E)
private theorem sat_646 (E : Nat → Bool) : (valuation E).satisfies [.neg 1336, .pos 389] := by
  change (g1337 E = true) → (¬ (g390 E = true)) → False
  exact pattern_5 (g390 E) (g1320 E)
private theorem sat_647 (E : Nat → Bool) : (valuation E).satisfies [.neg 1321, .pos 1336, .pos 1337] := by
  change (g1322 E = true) → (¬ (g1337 E = true)) → (¬ (g1338 E = true)) → False
  exact pattern_6 (g1322 E) (g1337 E)
private theorem sat_648 (E : Nat → Bool) : (valuation E).satisfies [.neg 1338, .neg 1321] := by
  change (g1339 E = true) → (g1322 E = true) → False
  exact pattern_4 (g390 E) (g1322 E)
private theorem sat_649 (E : Nat → Bool) : (valuation E).satisfies [.neg 1338, .pos 389] := by
  change (g1339 E = true) → (¬ (g390 E = true)) → False
  exact pattern_5 (g390 E) (g1322 E)
private theorem sat_650 (E : Nat → Bool) : (valuation E).satisfies [.neg 1323, .pos 1338, .pos 1339] := by
  change (g1324 E = true) → (¬ (g1339 E = true)) → (¬ (g1340 E = true)) → False
  exact pattern_6 (g1324 E) (g1339 E)
private theorem sat_651 (E : Nat → Bool) : (valuation E).satisfies [.neg 1333, .pos 390, .pos 1351] := by
  change (g1334 E = true) → (¬ (g391 E = true)) → (¬ (g1352 E = true)) → False
  exact pattern_3 (g391 E) (g1334 E)
private theorem sat_652 (E : Nat → Bool) : (valuation E).satisfies [.neg 1352, .neg 1333] := by
  change (g1353 E = true) → (g1334 E = true) → False
  exact pattern_4 (g391 E) (g1334 E)
private theorem sat_653 (E : Nat → Bool) : (valuation E).satisfies [.neg 1352, .pos 390] := by
  change (g1353 E = true) → (¬ (g391 E = true)) → False
  exact pattern_5 (g391 E) (g1334 E)
private theorem sat_654 (E : Nat → Bool) : (valuation E).satisfies [.neg 1335, .pos 1352, .pos 1353] := by
  change (g1336 E = true) → (¬ (g1353 E = true)) → (¬ (g1354 E = true)) → False
  exact pattern_6 (g1336 E) (g1353 E)
private theorem sat_655 (E : Nat → Bool) : (valuation E).satisfies [.neg 1354, .neg 1335] := by
  change (g1355 E = true) → (g1336 E = true) → False
  exact pattern_4 (g391 E) (g1336 E)
private theorem sat_656 (E : Nat → Bool) : (valuation E).satisfies [.neg 1354, .pos 390] := by
  change (g1355 E = true) → (¬ (g391 E = true)) → False
  exact pattern_5 (g391 E) (g1336 E)
private theorem sat_657 (E : Nat → Bool) : (valuation E).satisfies [.neg 1337, .pos 1354, .pos 1355] := by
  change (g1338 E = true) → (¬ (g1355 E = true)) → (¬ (g1356 E = true)) → False
  exact pattern_6 (g1338 E) (g1355 E)
private theorem sat_658 (E : Nat → Bool) : (valuation E).satisfies [.neg 1356, .neg 1337] := by
  change (g1357 E = true) → (g1338 E = true) → False
  exact pattern_4 (g391 E) (g1338 E)
private theorem sat_659 (E : Nat → Bool) : (valuation E).satisfies [.neg 1356, .pos 390] := by
  change (g1357 E = true) → (¬ (g391 E = true)) → False
  exact pattern_5 (g391 E) (g1338 E)
private theorem sat_660 (E : Nat → Bool) : (valuation E).satisfies [.neg 1339, .pos 1356, .pos 1357] := by
  change (g1340 E = true) → (¬ (g1357 E = true)) → (¬ (g1358 E = true)) → False
  exact pattern_6 (g1340 E) (g1357 E)
private theorem sat_661 (E : Nat → Bool) : (valuation E).satisfies [.neg 1351, .pos 401, .pos 1371] := by
  change (g1352 E = true) → (¬ (g402 E = true)) → (¬ (g1372 E = true)) → False
  exact pattern_3 (g402 E) (g1352 E)
private theorem sat_662 (E : Nat → Bool) : (valuation E).satisfies [.neg 1372, .neg 1351] := by
  change (g1373 E = true) → (g1352 E = true) → False
  exact pattern_4 (g402 E) (g1352 E)
private theorem sat_663 (E : Nat → Bool) : (valuation E).satisfies [.neg 1372, .pos 401] := by
  change (g1373 E = true) → (¬ (g402 E = true)) → False
  exact pattern_5 (g402 E) (g1352 E)
private theorem sat_664 (E : Nat → Bool) : (valuation E).satisfies [.neg 1353, .pos 1372, .pos 1373] := by
  change (g1354 E = true) → (¬ (g1373 E = true)) → (¬ (g1374 E = true)) → False
  exact pattern_6 (g1354 E) (g1373 E)
private theorem sat_665 (E : Nat → Bool) : (valuation E).satisfies [.neg 1374, .neg 1353] := by
  change (g1375 E = true) → (g1354 E = true) → False
  exact pattern_4 (g402 E) (g1354 E)
private theorem sat_666 (E : Nat → Bool) : (valuation E).satisfies [.neg 1374, .pos 401] := by
  change (g1375 E = true) → (¬ (g402 E = true)) → False
  exact pattern_5 (g402 E) (g1354 E)
private theorem sat_667 (E : Nat → Bool) : (valuation E).satisfies [.neg 1355, .pos 1374, .pos 1375] := by
  change (g1356 E = true) → (¬ (g1375 E = true)) → (¬ (g1376 E = true)) → False
  exact pattern_6 (g1356 E) (g1375 E)
private theorem sat_668 (E : Nat → Bool) : (valuation E).satisfies [.neg 1376, .neg 1355] := by
  change (g1377 E = true) → (g1356 E = true) → False
  exact pattern_4 (g402 E) (g1356 E)
private theorem sat_669 (E : Nat → Bool) : (valuation E).satisfies [.neg 1376, .pos 401] := by
  change (g1377 E = true) → (¬ (g402 E = true)) → False
  exact pattern_5 (g402 E) (g1356 E)
private theorem sat_670 (E : Nat → Bool) : (valuation E).satisfies [.neg 1357, .pos 1376, .pos 1377] := by
  change (g1358 E = true) → (¬ (g1377 E = true)) → (¬ (g1378 E = true)) → False
  exact pattern_6 (g1358 E) (g1377 E)
private theorem sat_671 (E : Nat → Bool) : (valuation E).satisfies [.neg 1371, .pos 402, .pos 1393] := by
  change (g1372 E = true) → (¬ (g403 E = true)) → (¬ (g1394 E = true)) → False
  exact pattern_3 (g403 E) (g1372 E)
private theorem sat_672 (E : Nat → Bool) : (valuation E).satisfies [.neg 1394, .neg 1371] := by
  change (g1395 E = true) → (g1372 E = true) → False
  exact pattern_4 (g403 E) (g1372 E)
private theorem sat_673 (E : Nat → Bool) : (valuation E).satisfies [.neg 1394, .pos 402] := by
  change (g1395 E = true) → (¬ (g403 E = true)) → False
  exact pattern_5 (g403 E) (g1372 E)
private theorem sat_674 (E : Nat → Bool) : (valuation E).satisfies [.neg 1373, .pos 1394, .pos 1395] := by
  change (g1374 E = true) → (¬ (g1395 E = true)) → (¬ (g1396 E = true)) → False
  exact pattern_6 (g1374 E) (g1395 E)
private theorem sat_675 (E : Nat → Bool) : (valuation E).satisfies [.neg 1396, .neg 1373] := by
  change (g1397 E = true) → (g1374 E = true) → False
  exact pattern_4 (g403 E) (g1374 E)
private theorem sat_676 (E : Nat → Bool) : (valuation E).satisfies [.neg 1396, .pos 402] := by
  change (g1397 E = true) → (¬ (g403 E = true)) → False
  exact pattern_5 (g403 E) (g1374 E)
private theorem sat_677 (E : Nat → Bool) : (valuation E).satisfies [.neg 1375, .pos 1396, .pos 1397] := by
  change (g1376 E = true) → (¬ (g1397 E = true)) → (¬ (g1398 E = true)) → False
  exact pattern_6 (g1376 E) (g1397 E)
private theorem sat_678 (E : Nat → Bool) : (valuation E).satisfies [.neg 1398, .neg 1375] := by
  change (g1399 E = true) → (g1376 E = true) → False
  exact pattern_4 (g403 E) (g1376 E)
private theorem sat_679 (E : Nat → Bool) : (valuation E).satisfies [.neg 1398, .pos 402] := by
  change (g1399 E = true) → (¬ (g403 E = true)) → False
  exact pattern_5 (g403 E) (g1376 E)
private theorem sat_680 (E : Nat → Bool) : (valuation E).satisfies [.neg 1377, .pos 1398, .pos 1399] := by
  change (g1378 E = true) → (¬ (g1399 E = true)) → (¬ (g1400 E = true)) → False
  exact pattern_6 (g1378 E) (g1399 E)
private theorem sat_681 (E : Nat → Bool) : (valuation E).satisfies [.neg 1393, .pos 403, .pos 1417] := by
  change (g1394 E = true) → (¬ (g404 E = true)) → (¬ (g1418 E = true)) → False
  exact pattern_3 (g404 E) (g1394 E)
private theorem sat_682 (E : Nat → Bool) : (valuation E).satisfies [.neg 1418, .neg 1393] := by
  change (g1419 E = true) → (g1394 E = true) → False
  exact pattern_4 (g404 E) (g1394 E)
private theorem sat_683 (E : Nat → Bool) : (valuation E).satisfies [.neg 1418, .pos 403] := by
  change (g1419 E = true) → (¬ (g404 E = true)) → False
  exact pattern_5 (g404 E) (g1394 E)
private theorem sat_684 (E : Nat → Bool) : (valuation E).satisfies [.neg 1395, .pos 1418, .pos 1419] := by
  change (g1396 E = true) → (¬ (g1419 E = true)) → (¬ (g1420 E = true)) → False
  exact pattern_6 (g1396 E) (g1419 E)
private theorem sat_685 (E : Nat → Bool) : (valuation E).satisfies [.neg 1420, .neg 1395] := by
  change (g1421 E = true) → (g1396 E = true) → False
  exact pattern_4 (g404 E) (g1396 E)
private theorem sat_686 (E : Nat → Bool) : (valuation E).satisfies [.neg 1420, .pos 403] := by
  change (g1421 E = true) → (¬ (g404 E = true)) → False
  exact pattern_5 (g404 E) (g1396 E)
private theorem sat_687 (E : Nat → Bool) : (valuation E).satisfies [.neg 1397, .pos 1420, .pos 1421] := by
  change (g1398 E = true) → (¬ (g1421 E = true)) → (¬ (g1422 E = true)) → False
  exact pattern_6 (g1398 E) (g1421 E)
private theorem sat_688 (E : Nat → Bool) : (valuation E).satisfies [.neg 1422, .neg 1397] := by
  change (g1423 E = true) → (g1398 E = true) → False
  exact pattern_4 (g404 E) (g1398 E)
private theorem sat_689 (E : Nat → Bool) : (valuation E).satisfies [.neg 1422, .pos 403] := by
  change (g1423 E = true) → (¬ (g404 E = true)) → False
  exact pattern_5 (g404 E) (g1398 E)
private theorem sat_690 (E : Nat → Bool) : (valuation E).satisfies [.neg 1399, .pos 1422, .pos 1423] := by
  change (g1400 E = true) → (¬ (g1423 E = true)) → (¬ (g1424 E = true)) → False
  exact pattern_6 (g1400 E) (g1423 E)
private theorem sat_691 (E : Nat → Bool) : (valuation E).satisfies [.neg 1417, .pos 404, .pos 1443] := by
  change (g1418 E = true) → (¬ (g405 E = true)) → (¬ (g1444 E = true)) → False
  exact pattern_3 (g405 E) (g1418 E)
private theorem sat_692 (E : Nat → Bool) : (valuation E).satisfies [.neg 1444, .pos 404] := by
  change (g1445 E = true) → (¬ (g405 E = true)) → False
  exact pattern_5 (g405 E) (g1418 E)
private theorem sat_693 (E : Nat → Bool) : (valuation E).satisfies [.neg 1419, .pos 1444, .pos 1445] := by
  change (g1420 E = true) → (¬ (g1445 E = true)) → (¬ (g1446 E = true)) → False
  exact pattern_6 (g1420 E) (g1445 E)
private theorem sat_694 (E : Nat → Bool) : (valuation E).satisfies [.neg 1446, .neg 1419] := by
  change (g1447 E = true) → (g1420 E = true) → False
  exact pattern_4 (g405 E) (g1420 E)
private theorem sat_695 (E : Nat → Bool) : (valuation E).satisfies [.neg 1446, .pos 404] := by
  change (g1447 E = true) → (¬ (g405 E = true)) → False
  exact pattern_5 (g405 E) (g1420 E)
private theorem sat_696 (E : Nat → Bool) : (valuation E).satisfies [.neg 1421, .pos 1446, .pos 1447] := by
  change (g1422 E = true) → (¬ (g1447 E = true)) → (¬ (g1448 E = true)) → False
  exact pattern_6 (g1422 E) (g1447 E)
private theorem sat_697 (E : Nat → Bool) : (valuation E).satisfies [.neg 1448, .neg 1421] := by
  change (g1449 E = true) → (g1422 E = true) → False
  exact pattern_4 (g405 E) (g1422 E)
private theorem sat_698 (E : Nat → Bool) : (valuation E).satisfies [.neg 1448, .pos 404] := by
  change (g1449 E = true) → (¬ (g405 E = true)) → False
  exact pattern_5 (g405 E) (g1422 E)
private theorem sat_699 (E : Nat → Bool) : (valuation E).satisfies [.neg 1423, .pos 1448, .pos 1449] := by
  change (g1424 E = true) → (¬ (g1449 E = true)) → (¬ (g1450 E = true)) → False
  exact pattern_6 (g1424 E) (g1449 E)
private theorem sat_700 (E : Nat → Bool) : (valuation E).satisfies [.neg 1443, .pos 405, .pos 1471] := by
  change (g1444 E = true) → (¬ (g406 E = true)) → (¬ (g1472 E = true)) → False
  exact pattern_3 (g406 E) (g1444 E)
private theorem sat_701 (E : Nat → Bool) : (valuation E).satisfies [.neg 1472, .neg 1443] := by
  change (g1473 E = true) → (g1444 E = true) → False
  exact pattern_4 (g406 E) (g1444 E)
private theorem sat_702 (E : Nat → Bool) : (valuation E).satisfies [.neg 1472, .pos 405] := by
  change (g1473 E = true) → (¬ (g406 E = true)) → False
  exact pattern_5 (g406 E) (g1444 E)
private theorem sat_703 (E : Nat → Bool) : (valuation E).satisfies [.neg 1445, .pos 1472, .pos 1473] := by
  change (g1446 E = true) → (¬ (g1473 E = true)) → (¬ (g1474 E = true)) → False
  exact pattern_6 (g1446 E) (g1473 E)
private theorem sat_704 (E : Nat → Bool) : (valuation E).satisfies [.neg 1474, .neg 1445] := by
  change (g1475 E = true) → (g1446 E = true) → False
  exact pattern_4 (g406 E) (g1446 E)
private theorem sat_705 (E : Nat → Bool) : (valuation E).satisfies [.neg 1474, .pos 405] := by
  change (g1475 E = true) → (¬ (g406 E = true)) → False
  exact pattern_5 (g406 E) (g1446 E)
private theorem sat_706 (E : Nat → Bool) : (valuation E).satisfies [.neg 1447, .pos 1474, .pos 1475] := by
  change (g1448 E = true) → (¬ (g1475 E = true)) → (¬ (g1476 E = true)) → False
  exact pattern_6 (g1448 E) (g1475 E)
private theorem sat_707 (E : Nat → Bool) : (valuation E).satisfies [.neg 1476, .neg 1447] := by
  change (g1477 E = true) → (g1448 E = true) → False
  exact pattern_4 (g406 E) (g1448 E)
private theorem sat_708 (E : Nat → Bool) : (valuation E).satisfies [.neg 1476, .pos 405] := by
  change (g1477 E = true) → (¬ (g406 E = true)) → False
  exact pattern_5 (g406 E) (g1448 E)
private theorem sat_709 (E : Nat → Bool) : (valuation E).satisfies [.neg 1449, .pos 1476, .pos 1477] := by
  change (g1450 E = true) → (¬ (g1477 E = true)) → (¬ (g1478 E = true)) → False
  exact pattern_6 (g1450 E) (g1477 E)
private theorem sat_710 (E : Nat → Bool) : (valuation E).satisfies [.neg 1471, .pos 406, .pos 1501] := by
  change (g1472 E = true) → (¬ (g407 E = true)) → (¬ (g1502 E = true)) → False
  exact pattern_3 (g407 E) (g1472 E)
private theorem sat_711 (E : Nat → Bool) : (valuation E).satisfies [.neg 1502, .neg 1471] := by
  change (g1503 E = true) → (g1472 E = true) → False
  exact pattern_4 (g407 E) (g1472 E)
private theorem sat_712 (E : Nat → Bool) : (valuation E).satisfies [.neg 1502, .pos 406] := by
  change (g1503 E = true) → (¬ (g407 E = true)) → False
  exact pattern_5 (g407 E) (g1472 E)
private theorem sat_713 (E : Nat → Bool) : (valuation E).satisfies [.neg 1473, .pos 1502, .pos 1503] := by
  change (g1474 E = true) → (¬ (g1503 E = true)) → (¬ (g1504 E = true)) → False
  exact pattern_6 (g1474 E) (g1503 E)
private theorem sat_714 (E : Nat → Bool) : (valuation E).satisfies [.neg 1504, .neg 1473] := by
  change (g1505 E = true) → (g1474 E = true) → False
  exact pattern_4 (g407 E) (g1474 E)
private theorem sat_715 (E : Nat → Bool) : (valuation E).satisfies [.neg 1504, .pos 406] := by
  change (g1505 E = true) → (¬ (g407 E = true)) → False
  exact pattern_5 (g407 E) (g1474 E)
private theorem sat_716 (E : Nat → Bool) : (valuation E).satisfies [.neg 1475, .pos 1504, .pos 1505] := by
  change (g1476 E = true) → (¬ (g1505 E = true)) → (¬ (g1506 E = true)) → False
  exact pattern_6 (g1476 E) (g1505 E)
private theorem sat_717 (E : Nat → Bool) : (valuation E).satisfies [.neg 1506, .neg 1475] := by
  change (g1507 E = true) → (g1476 E = true) → False
  exact pattern_4 (g407 E) (g1476 E)
private theorem sat_718 (E : Nat → Bool) : (valuation E).satisfies [.neg 1506, .pos 406] := by
  change (g1507 E = true) → (¬ (g407 E = true)) → False
  exact pattern_5 (g407 E) (g1476 E)
private theorem sat_719 (E : Nat → Bool) : (valuation E).satisfies [.neg 1477, .pos 1506, .pos 1507] := by
  change (g1478 E = true) → (¬ (g1507 E = true)) → (¬ (g1508 E = true)) → False
  exact pattern_6 (g1478 E) (g1507 E)
private theorem sat_720 (E : Nat → Bool) : (valuation E).satisfies [.neg 1501, .pos 407, .pos 1533] := by
  change (g1502 E = true) → (¬ (g408 E = true)) → (¬ (g1534 E = true)) → False
  exact pattern_3 (g408 E) (g1502 E)
private theorem sat_721 (E : Nat → Bool) : (valuation E).satisfies [.neg 1534, .pos 407] := by
  change (g1535 E = true) → (¬ (g408 E = true)) → False
  exact pattern_5 (g408 E) (g1502 E)
private theorem sat_722 (E : Nat → Bool) : (valuation E).satisfies [.neg 1503, .pos 1534, .pos 1535] := by
  change (g1504 E = true) → (¬ (g1535 E = true)) → (¬ (g1536 E = true)) → False
  exact pattern_6 (g1504 E) (g1535 E)
private theorem sat_723 (E : Nat → Bool) : (valuation E).satisfies [.neg 1536, .neg 1503] := by
  change (g1537 E = true) → (g1504 E = true) → False
  exact pattern_4 (g408 E) (g1504 E)
private theorem sat_724 (E : Nat → Bool) : (valuation E).satisfies [.neg 1536, .pos 407] := by
  change (g1537 E = true) → (¬ (g408 E = true)) → False
  exact pattern_5 (g408 E) (g1504 E)
private theorem sat_725 (E : Nat → Bool) : (valuation E).satisfies [.neg 1505, .pos 1536, .pos 1537] := by
  change (g1506 E = true) → (¬ (g1537 E = true)) → (¬ (g1538 E = true)) → False
  exact pattern_6 (g1506 E) (g1537 E)
private theorem sat_726 (E : Nat → Bool) : (valuation E).satisfies [.neg 1538, .neg 1505] := by
  change (g1539 E = true) → (g1506 E = true) → False
  exact pattern_4 (g408 E) (g1506 E)
private theorem sat_727 (E : Nat → Bool) : (valuation E).satisfies [.neg 1538, .pos 407] := by
  change (g1539 E = true) → (¬ (g408 E = true)) → False
  exact pattern_5 (g408 E) (g1506 E)
private theorem sat_728 (E : Nat → Bool) : (valuation E).satisfies [.neg 1507, .pos 1538, .pos 1539] := by
  change (g1508 E = true) → (¬ (g1539 E = true)) → (¬ (g1540 E = true)) → False
  exact pattern_6 (g1508 E) (g1539 E)
private theorem sat_729 (E : Nat → Bool) : (valuation E).satisfies [.neg 1568, .neg 1533] := by
  change (g1569 E = true) → (g1534 E = true) → False
  exact pattern_4 (g409 E) (g1534 E)
private theorem sat_730 (E : Nat → Bool) : (valuation E).satisfies [.neg 1535, .pos 1568, .pos 1569] := by
  change (g1536 E = true) → (¬ (g1569 E = true)) → (¬ (g1570 E = true)) → False
  exact pattern_6 (g1536 E) (g1569 E)
private theorem sat_731 (E : Nat → Bool) : (valuation E).satisfies [.neg 1570, .neg 1535] := by
  change (g1571 E = true) → (g1536 E = true) → False
  exact pattern_4 (g409 E) (g1536 E)
private theorem sat_732 (E : Nat → Bool) : (valuation E).satisfies [.neg 1570, .pos 408] := by
  change (g1571 E = true) → (¬ (g409 E = true)) → False
  exact pattern_5 (g409 E) (g1536 E)
private theorem sat_733 (E : Nat → Bool) : (valuation E).satisfies [.neg 1537, .pos 1570, .pos 1571] := by
  change (g1538 E = true) → (¬ (g1571 E = true)) → (¬ (g1572 E = true)) → False
  exact pattern_6 (g1538 E) (g1571 E)
private theorem sat_734 (E : Nat → Bool) : (valuation E).satisfies [.neg 1572, .neg 1537] := by
  change (g1573 E = true) → (g1538 E = true) → False
  exact pattern_4 (g409 E) (g1538 E)
private theorem sat_735 (E : Nat → Bool) : (valuation E).satisfies [.neg 1572, .pos 408] := by
  change (g1573 E = true) → (¬ (g409 E = true)) → False
  exact pattern_5 (g409 E) (g1538 E)
private theorem sat_736 (E : Nat → Bool) : (valuation E).satisfies [.neg 1539, .pos 1572, .pos 1573] := by
  change (g1540 E = true) → (¬ (g1573 E = true)) → (¬ (g1574 E = true)) → False
  exact pattern_6 (g1540 E) (g1573 E)
private theorem sat_737 (E : Nat → Bool) : (valuation E).satisfies [.neg 1606, .neg 1569] := by
  change (g1607 E = true) → (g1570 E = true) → False
  exact pattern_4 (g410 E) (g1570 E)
private theorem sat_738 (E : Nat → Bool) : (valuation E).satisfies [.neg 1606, .pos 409] := by
  change (g1607 E = true) → (¬ (g410 E = true)) → False
  exact pattern_5 (g410 E) (g1570 E)
private theorem sat_739 (E : Nat → Bool) : (valuation E).satisfies [.neg 1571, .pos 1606, .pos 1607] := by
  change (g1572 E = true) → (¬ (g1607 E = true)) → (¬ (g1608 E = true)) → False
  exact pattern_6 (g1572 E) (g1607 E)
private theorem sat_740 (E : Nat → Bool) : (valuation E).satisfies [.neg 1608, .neg 1571] := by
  change (g1609 E = true) → (g1572 E = true) → False
  exact pattern_4 (g410 E) (g1572 E)
private theorem sat_741 (E : Nat → Bool) : (valuation E).satisfies [.neg 1608, .pos 409] := by
  change (g1609 E = true) → (¬ (g410 E = true)) → False
  exact pattern_5 (g410 E) (g1572 E)
private theorem sat_742 (E : Nat → Bool) : (valuation E).satisfies [.neg 1573, .pos 1608, .pos 1609] := by
  change (g1574 E = true) → (¬ (g1609 E = true)) → (¬ (g1610 E = true)) → False
  exact pattern_6 (g1574 E) (g1609 E)
private theorem sat_743 (E : Nat → Bool) : (valuation E).satisfies [.neg 1646, .neg 1607] := by
  change (g1647 E = true) → (g1608 E = true) → False
  exact pattern_4 (g411 E) (g1608 E)
private theorem sat_744 (E : Nat → Bool) : (valuation E).satisfies [.neg 1646, .pos 410] := by
  change (g1647 E = true) → (¬ (g411 E = true)) → False
  exact pattern_5 (g411 E) (g1608 E)
private theorem sat_745 (E : Nat → Bool) : (valuation E).satisfies [.neg 1609, .pos 1646, .pos 1647] := by
  change (g1610 E = true) → (¬ (g1647 E = true)) → (¬ (g1648 E = true)) → False
  exact pattern_6 (g1610 E) (g1647 E)
private theorem sat_750 (E : Nat → Bool) : (valuation E).satisfies [.neg 9, .pos 10, .pos 1681] := by
  change (g10 E = true) → (¬ (g11 E = true)) → (¬ (g1682 E = true)) → False
  exact pattern_6 (g10 E) (g11 E)
private theorem sat_751 (E : Nat → Bool) : (valuation E).satisfies [.neg 3, .pos 4, .pos 1683] := by
  change (g4 E = true) → (¬ (g5 E = true)) → (¬ (g1684 E = true)) → False
  exact pattern_6 (g4 E) (g5 E)
private theorem pattern_16 (x0 x1 : Bool) : (((x1) ^^ (x0))=true) → (¬ (x0=true)) → (¬ (x1=true)) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_752 (E : Nat → Bool) : (valuation E).satisfies [.neg 1684, .pos 3, .pos 4] := by
  change (g1685 E = true) → (¬ (g4 E = true)) → (¬ (g5 E = true)) → False
  exact pattern_16 (g4 E) (g5 E)
private theorem sat_753 (E : Nat → Bool) : (valuation E).satisfies [.neg 1681, .pos 1684, .pos 1685] := by
  change (g1682 E = true) → (¬ (g1685 E = true)) → (¬ (g1686 E = true)) → False
  exact pattern_6 (g1682 E) (g1685 E)
private theorem sat_754 (E : Nat → Bool) : (valuation E).satisfies [.neg 1686, .neg 1685] := by
  change (g1687 E = true) → (g1686 E = true) → False
  exact pattern_7 (g1684 E) (g1686 E)
private theorem sat_755 (E : Nat → Bool) : (valuation E).satisfies [.neg 1686, .neg 1683] := by
  change (g1687 E = true) → (g1684 E = true) → False
  exact pattern_8 (g1684 E) (g1686 E)
private theorem sat_757 (E : Nat → Bool) : (valuation E).satisfies [.neg 10, .pos 11, .pos 1687] := by
  change (g11 E = true) → (¬ (g12 E = true)) → (¬ (g1688 E = true)) → False
  exact pattern_6 (g11 E) (g12 E)
private theorem sat_758 (E : Nat → Bool) : (valuation E).satisfies [.neg 4, .pos 5, .pos 1689] := by
  change (g5 E = true) → (¬ (g6 E = true)) → (¬ (g1690 E = true)) → False
  exact pattern_6 (g5 E) (g6 E)
private theorem sat_759 (E : Nat → Bool) : (valuation E).satisfies [.neg 1690, .pos 4, .pos 5] := by
  change (g1691 E = true) → (¬ (g5 E = true)) → (¬ (g6 E = true)) → False
  exact pattern_16 (g5 E) (g6 E)
private theorem pattern_17 (x0 x1 : Bool) : (((x1) ^^ (x0))=true) → (x1=true) → (x0=true) → False := by cases x0 <;> cases x1 <;> decide
private theorem sat_760 (E : Nat → Bool) : (valuation E).satisfies [.neg 1690, .neg 5, .neg 4] := by
  change (g1691 E = true) → (g6 E = true) → (g5 E = true) → False
  exact pattern_17 (g5 E) (g6 E)
private theorem sat_761 (E : Nat → Bool) : (valuation E).satisfies [.neg 1687, .pos 1690, .pos 1691] := by
  change (g1688 E = true) → (¬ (g1691 E = true)) → (¬ (g1692 E = true)) → False
  exact pattern_6 (g1688 E) (g1691 E)
private theorem sat_762 (E : Nat → Bool) : (valuation E).satisfies [.neg 1692, .neg 1691] := by
  change (g1693 E = true) → (g1692 E = true) → False
  exact pattern_7 (g1690 E) (g1692 E)
private theorem sat_763 (E : Nat → Bool) : (valuation E).satisfies [.neg 1692, .neg 1689] := by
  change (g1693 E = true) → (g1690 E = true) → False
  exact pattern_8 (g1690 E) (g1692 E)
private theorem sat_765 (E : Nat → Bool) : (valuation E).satisfies [.neg 11, .pos 12, .pos 1693] := by
  change (g12 E = true) → (¬ (g13 E = true)) → (¬ (g1694 E = true)) → False
  exact pattern_6 (g12 E) (g13 E)
private theorem sat_766 (E : Nat → Bool) : (valuation E).satisfies [.neg 5, .pos 6, .pos 1695] := by
  change (g6 E = true) → (¬ (g7 E = true)) → (¬ (g1696 E = true)) → False
  exact pattern_6 (g6 E) (g7 E)
private theorem sat_767 (E : Nat → Bool) : (valuation E).satisfies [.neg 1696, .pos 5, .pos 6] := by
  change (g1697 E = true) → (¬ (g6 E = true)) → (¬ (g7 E = true)) → False
  exact pattern_16 (g6 E) (g7 E)
private theorem sat_768 (E : Nat → Bool) : (valuation E).satisfies [.neg 1696, .neg 6, .neg 5] := by
  change (g1697 E = true) → (g7 E = true) → (g6 E = true) → False
  exact pattern_17 (g6 E) (g7 E)
private theorem sat_769 (E : Nat → Bool) : (valuation E).satisfies [.neg 1693, .pos 1696, .pos 1697] := by
  change (g1694 E = true) → (¬ (g1697 E = true)) → (¬ (g1698 E = true)) → False
  exact pattern_6 (g1694 E) (g1697 E)
private theorem sat_770 (E : Nat → Bool) : (valuation E).satisfies [.neg 1698, .neg 1697] := by
  change (g1699 E = true) → (g1698 E = true) → False
  exact pattern_7 (g1696 E) (g1698 E)
private theorem sat_771 (E : Nat → Bool) : (valuation E).satisfies [.neg 1698, .neg 1695] := by
  change (g1699 E = true) → (g1696 E = true) → False
  exact pattern_8 (g1696 E) (g1698 E)
private theorem sat_773 (E : Nat → Bool) : (valuation E).satisfies [.neg 1699, .pos 12] := by
  change (g1700 E = true) → (¬ (g13 E = true)) → False
  exact pattern_5 (g13 E) (g14 E)
private theorem sat_774 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .pos 13, .pos 1699] := by
  change (g13 E = true) → (¬ (g14 E = true)) → (¬ (g1700 E = true)) → False
  exact pattern_6 (g13 E) (g14 E)
private theorem sat_775 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .pos 7, .pos 1701] := by
  change (g7 E = true) → (¬ (g8 E = true)) → (¬ (g1702 E = true)) → False
  exact pattern_6 (g7 E) (g8 E)
private theorem sat_776 (E : Nat → Bool) : (valuation E).satisfies [.neg 1702, .pos 6, .pos 7] := by
  change (g1703 E = true) → (¬ (g7 E = true)) → (¬ (g8 E = true)) → False
  exact pattern_16 (g7 E) (g8 E)
private theorem sat_777 (E : Nat → Bool) : (valuation E).satisfies [.neg 1702, .neg 7, .neg 6] := by
  change (g1703 E = true) → (g8 E = true) → (g7 E = true) → False
  exact pattern_17 (g7 E) (g8 E)
private theorem sat_778 (E : Nat → Bool) : (valuation E).satisfies [.neg 1699, .pos 1702, .pos 1703] := by
  change (g1700 E = true) → (¬ (g1703 E = true)) → (¬ (g1704 E = true)) → False
  exact pattern_6 (g1700 E) (g1703 E)
private theorem sat_779 (E : Nat → Bool) : (valuation E).satisfies [.neg 1704, .neg 1703] := by
  change (g1705 E = true) → (g1704 E = true) → False
  exact pattern_7 (g1702 E) (g1704 E)
private theorem sat_780 (E : Nat → Bool) : (valuation E).satisfies [.neg 1704, .neg 1701] := by
  change (g1705 E = true) → (g1702 E = true) → False
  exact pattern_8 (g1702 E) (g1704 E)
private theorem pattern_18 (x0 x1 x2 : Bool) : (((!x2) && (!x1) && (!x0))=true) → (x2=true) → False := by cases x0 <;> cases x1 <;> cases x2 <;> decide
private theorem sat_782 (E : Nat → Bool) : (valuation E).satisfies [.neg 1705, .neg 14] := by
  change (g1706 E = true) → (g15 E = true) → False
  exact pattern_18 (g4 E) (g10 E) (g15 E)
private theorem pattern_19 (x0 x1 x2 : Bool) : (((!x2) && (!x1) && (!x0))=true) → (x1=true) → False := by cases x0 <;> cases x1 <;> cases x2 <;> decide
private theorem sat_783 (E : Nat → Bool) : (valuation E).satisfies [.neg 1705, .neg 9] := by
  change (g1706 E = true) → (g10 E = true) → False
  exact pattern_19 (g4 E) (g10 E) (g15 E)
private theorem pattern_20 (x0 x1 x2 : Bool) : (((!x2) && (!x1) && (!x0))=true) → (x0=true) → False := by cases x0 <;> cases x1 <;> cases x2 <;> decide
private theorem sat_784 (E : Nat → Bool) : (valuation E).satisfies [.neg 1705, .neg 3] := by
  change (g1706 E = true) → (g4 E = true) → False
  exact pattern_20 (g4 E) (g10 E) (g15 E)
private theorem pattern_21 (x0 x1 x2 : Bool) : (¬ (x0=true)) → (¬ (x1=true)) → (¬ (x2=true)) → (¬ (((!x2) && (!x1) && (!x0))=true)) → False := by cases x0 <;> cases x1 <;> cases x2 <;> decide
private theorem sat_785 (E : Nat → Bool) : (valuation E).satisfies [.pos 3, .pos 9, .pos 14, .pos 1705] := by
  change (¬ (g4 E = true)) → (¬ (g10 E = true)) → (¬ (g15 E = true)) → (¬ (g1706 E = true)) → False
  exact pattern_21 (g4 E) (g10 E) (g15 E)
private theorem sat_786 (E : Nat → Bool) : (valuation E).satisfies [.neg 1706, .neg 15] := by
  change (g1707 E = true) → (g16 E = true) → False
  exact pattern_18 (g5 E) (g11 E) (g16 E)
private theorem sat_787 (E : Nat → Bool) : (valuation E).satisfies [.neg 1706, .neg 10] := by
  change (g1707 E = true) → (g11 E = true) → False
  exact pattern_19 (g5 E) (g11 E) (g16 E)
private theorem sat_788 (E : Nat → Bool) : (valuation E).satisfies [.neg 1706, .neg 4] := by
  change (g1707 E = true) → (g5 E = true) → False
  exact pattern_20 (g5 E) (g11 E) (g16 E)
private theorem sat_789 (E : Nat → Bool) : (valuation E).satisfies [.pos 4, .pos 10, .pos 15, .pos 1706] := by
  change (¬ (g5 E = true)) → (¬ (g11 E = true)) → (¬ (g16 E = true)) → (¬ (g1707 E = true)) → False
  exact pattern_21 (g5 E) (g11 E) (g16 E)
private theorem sat_790 (E : Nat → Bool) : (valuation E).satisfies [.neg 1707, .neg 16] := by
  change (g1708 E = true) → (g17 E = true) → False
  exact pattern_18 (g6 E) (g12 E) (g17 E)
private theorem sat_791 (E : Nat → Bool) : (valuation E).satisfies [.neg 1707, .neg 11] := by
  change (g1708 E = true) → (g12 E = true) → False
  exact pattern_19 (g6 E) (g12 E) (g17 E)
private theorem sat_792 (E : Nat → Bool) : (valuation E).satisfies [.neg 1707, .neg 5] := by
  change (g1708 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g12 E) (g17 E)
private theorem sat_793 (E : Nat → Bool) : (valuation E).satisfies [.neg 1708, .neg 17] := by
  change (g1709 E = true) → (g18 E = true) → False
  exact pattern_18 (g7 E) (g13 E) (g18 E)
private theorem sat_794 (E : Nat → Bool) : (valuation E).satisfies [.neg 1708, .neg 12] := by
  change (g1709 E = true) → (g13 E = true) → False
  exact pattern_19 (g7 E) (g13 E) (g18 E)
private theorem sat_795 (E : Nat → Bool) : (valuation E).satisfies [.neg 1708, .neg 6] := by
  change (g1709 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g13 E) (g18 E)
private theorem sat_796 (E : Nat → Bool) : (valuation E).satisfies [.pos 6, .pos 12, .pos 17, .pos 1708] := by
  change (¬ (g7 E = true)) → (¬ (g13 E = true)) → (¬ (g18 E = true)) → (¬ (g1709 E = true)) → False
  exact pattern_21 (g7 E) (g13 E) (g18 E)
private theorem sat_797 (E : Nat → Bool) : (valuation E).satisfies [.neg 1709, .neg 18] := by
  change (g1710 E = true) → (g19 E = true) → False
  exact pattern_18 (g8 E) (g14 E) (g19 E)
private theorem sat_798 (E : Nat → Bool) : (valuation E).satisfies [.neg 1709, .neg 13] := by
  change (g1710 E = true) → (g14 E = true) → False
  exact pattern_19 (g8 E) (g14 E) (g19 E)
private theorem sat_799 (E : Nat → Bool) : (valuation E).satisfies [.neg 1709, .neg 7] := by
  change (g1710 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g14 E) (g19 E)
private theorem sat_801 (E : Nat → Bool) : (valuation E).satisfies [.neg 8, .neg 2, .pos 1710] := by
  change (g9 E = true) → (g3 E = true) → (¬ (g1711 E = true)) → False
  exact pattern_9 (g3 E) (g9 E)
private theorem sat_802 (E : Nat → Bool) : (valuation E).satisfies [.neg 14, .neg 2, .pos 1711] := by
  change (g15 E = true) → (g3 E = true) → (¬ (g1712 E = true)) → False
  exact pattern_9 (g3 E) (g15 E)
private theorem sat_803 (E : Nat → Bool) : (valuation E).satisfies [.neg 14, .neg 8, .pos 1712] := by
  change (g15 E = true) → (g9 E = true) → (¬ (g1713 E = true)) → False
  exact pattern_9 (g9 E) (g15 E)
private theorem sat_804 (E : Nat → Bool) : (valuation E).satisfies [.neg 1713, .neg 1712] := by
  change (g1714 E = true) → (g1713 E = true) → False
  exact pattern_18 (g1711 E) (g1712 E) (g1713 E)
private theorem sat_805 (E : Nat → Bool) : (valuation E).satisfies [.neg 1713, .neg 1711] := by
  change (g1714 E = true) → (g1712 E = true) → False
  exact pattern_19 (g1711 E) (g1712 E) (g1713 E)
private theorem sat_806 (E : Nat → Bool) : (valuation E).satisfies [.neg 1713, .neg 1710] := by
  change (g1714 E = true) → (g1711 E = true) → False
  exact pattern_20 (g1711 E) (g1712 E) (g1713 E)
private theorem sat_807 (E : Nat → Bool) : (valuation E).satisfies [.neg 1714, .neg 19] := by
  change (g1715 E = true) → (g20 E = true) → False
  exact pattern_18 (g5 E) (g11 E) (g20 E)
private theorem sat_808 (E : Nat → Bool) : (valuation E).satisfies [.neg 1714, .neg 10] := by
  change (g1715 E = true) → (g11 E = true) → False
  exact pattern_19 (g5 E) (g11 E) (g20 E)
private theorem sat_809 (E : Nat → Bool) : (valuation E).satisfies [.neg 1714, .neg 4] := by
  change (g1715 E = true) → (g5 E = true) → False
  exact pattern_20 (g5 E) (g11 E) (g20 E)
private theorem sat_810 (E : Nat → Bool) : (valuation E).satisfies [.pos 4, .pos 10, .pos 19, .pos 1714] := by
  change (¬ (g5 E = true)) → (¬ (g11 E = true)) → (¬ (g20 E = true)) → (¬ (g1715 E = true)) → False
  exact pattern_21 (g5 E) (g11 E) (g20 E)
private theorem sat_811 (E : Nat → Bool) : (valuation E).satisfies [.neg 1715, .neg 20] := by
  change (g1716 E = true) → (g21 E = true) → False
  exact pattern_18 (g6 E) (g12 E) (g21 E)
private theorem sat_812 (E : Nat → Bool) : (valuation E).satisfies [.neg 1715, .neg 11] := by
  change (g1716 E = true) → (g12 E = true) → False
  exact pattern_19 (g6 E) (g12 E) (g21 E)
private theorem sat_813 (E : Nat → Bool) : (valuation E).satisfies [.neg 1715, .neg 5] := by
  change (g1716 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g12 E) (g21 E)
private theorem sat_814 (E : Nat → Bool) : (valuation E).satisfies [.neg 1716, .neg 12] := by
  change (g1717 E = true) → (g13 E = true) → False
  exact pattern_19 (g7 E) (g13 E) (g22 E)
private theorem sat_815 (E : Nat → Bool) : (valuation E).satisfies [.neg 1716, .neg 6] := by
  change (g1717 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g13 E) (g22 E)
private theorem sat_816 (E : Nat → Bool) : (valuation E).satisfies [.neg 1717, .neg 7] := by
  change (g1718 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g14 E) (g23 E)
private theorem sat_818 (E : Nat → Bool) : (valuation E).satisfies [.neg 8, .neg 2, .pos 1718] := by
  change (g9 E = true) → (g3 E = true) → (¬ (g1719 E = true)) → False
  exact pattern_9 (g3 E) (g9 E)
private theorem sat_819 (E : Nat → Bool) : (valuation E).satisfies [.neg 15, .neg 2, .pos 1719] := by
  change (g16 E = true) → (g3 E = true) → (¬ (g1720 E = true)) → False
  exact pattern_9 (g3 E) (g16 E)
private theorem sat_820 (E : Nat → Bool) : (valuation E).satisfies [.neg 15, .neg 8, .pos 1720] := by
  change (g16 E = true) → (g9 E = true) → (¬ (g1721 E = true)) → False
  exact pattern_9 (g9 E) (g16 E)
private theorem sat_821 (E : Nat → Bool) : (valuation E).satisfies [.neg 1721, .neg 1720] := by
  change (g1722 E = true) → (g1721 E = true) → False
  exact pattern_18 (g1719 E) (g1720 E) (g1721 E)
private theorem sat_822 (E : Nat → Bool) : (valuation E).satisfies [.neg 1721, .neg 1719] := by
  change (g1722 E = true) → (g1720 E = true) → False
  exact pattern_19 (g1719 E) (g1720 E) (g1721 E)
private theorem sat_823 (E : Nat → Bool) : (valuation E).satisfies [.neg 1721, .neg 1718] := by
  change (g1722 E = true) → (g1719 E = true) → False
  exact pattern_20 (g1719 E) (g1720 E) (g1721 E)
private theorem sat_824 (E : Nat → Bool) : (valuation E).satisfies [.neg 1722, .neg 19] := by
  change (g1723 E = true) → (g20 E = true) → False
  exact pattern_18 (g4 E) (g10 E) (g20 E)
private theorem sat_825 (E : Nat → Bool) : (valuation E).satisfies [.pos 3, .pos 9, .pos 19, .pos 1722] := by
  change (¬ (g4 E = true)) → (¬ (g10 E = true)) → (¬ (g20 E = true)) → (¬ (g1723 E = true)) → False
  exact pattern_21 (g4 E) (g10 E) (g20 E)
private theorem sat_826 (E : Nat → Bool) : (valuation E).satisfies [.neg 1723, .neg 23] := by
  change (g1724 E = true) → (g24 E = true) → False
  exact pattern_18 (g6 E) (g12 E) (g24 E)
private theorem sat_827 (E : Nat → Bool) : (valuation E).satisfies [.neg 1723, .neg 11] := by
  change (g1724 E = true) → (g12 E = true) → False
  exact pattern_19 (g6 E) (g12 E) (g24 E)
private theorem sat_828 (E : Nat → Bool) : (valuation E).satisfies [.neg 1723, .neg 5] := by
  change (g1724 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g12 E) (g24 E)
private theorem sat_829 (E : Nat → Bool) : (valuation E).satisfies [.neg 1724, .neg 12] := by
  change (g1725 E = true) → (g13 E = true) → False
  exact pattern_19 (g7 E) (g13 E) (g25 E)
private theorem sat_830 (E : Nat → Bool) : (valuation E).satisfies [.neg 1724, .neg 6] := by
  change (g1725 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g13 E) (g25 E)
private theorem sat_831 (E : Nat → Bool) : (valuation E).satisfies [.neg 1725, .neg 13] := by
  change (g1726 E = true) → (g14 E = true) → False
  exact pattern_19 (g8 E) (g14 E) (g26 E)
private theorem sat_832 (E : Nat → Bool) : (valuation E).satisfies [.neg 1725, .neg 7] := by
  change (g1726 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g14 E) (g26 E)
private theorem sat_834 (E : Nat → Bool) : (valuation E).satisfies [.neg 16, .neg 2, .pos 1727] := by
  change (g17 E = true) → (g3 E = true) → (¬ (g1728 E = true)) → False
  exact pattern_9 (g3 E) (g17 E)
private theorem sat_835 (E : Nat → Bool) : (valuation E).satisfies [.neg 16, .neg 8, .pos 1728] := by
  change (g17 E = true) → (g9 E = true) → (¬ (g1729 E = true)) → False
  exact pattern_9 (g9 E) (g17 E)
private theorem sat_836 (E : Nat → Bool) : (valuation E).satisfies [.neg 1729, .neg 1728] := by
  change (g1730 E = true) → (g1729 E = true) → False
  exact pattern_18 (g1727 E) (g1728 E) (g1729 E)
private theorem sat_837 (E : Nat → Bool) : (valuation E).satisfies [.neg 1729, .neg 1727] := by
  change (g1730 E = true) → (g1728 E = true) → False
  exact pattern_19 (g1727 E) (g1728 E) (g1729 E)
private theorem sat_838 (E : Nat → Bool) : (valuation E).satisfies [.neg 1730, .neg 20] := by
  change (g1731 E = true) → (g21 E = true) → False
  exact pattern_18 (g4 E) (g10 E) (g21 E)
private theorem sat_839 (E : Nat → Bool) : (valuation E).satisfies [.neg 1731, .neg 23] := by
  change (g1732 E = true) → (g24 E = true) → False
  exact pattern_18 (g5 E) (g11 E) (g24 E)
private theorem sat_840 (E : Nat → Bool) : (valuation E).satisfies [.neg 1731, .neg 10] := by
  change (g1732 E = true) → (g11 E = true) → False
  exact pattern_19 (g5 E) (g11 E) (g24 E)
private theorem sat_841 (E : Nat → Bool) : (valuation E).satisfies [.neg 1731, .neg 4] := by
  change (g1732 E = true) → (g5 E = true) → False
  exact pattern_20 (g5 E) (g11 E) (g24 E)
private theorem sat_842 (E : Nat → Bool) : (valuation E).satisfies [.neg 1732, .neg 6] := by
  change (g1733 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g13 E) (g27 E)
private theorem sat_843 (E : Nat → Bool) : (valuation E).satisfies [.neg 1733, .neg 7] := by
  change (g1734 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g14 E) (g28 E)
private theorem sat_845 (E : Nat → Bool) : (valuation E).satisfies [.neg 8, .neg 2, .pos 1734] := by
  change (g9 E = true) → (g3 E = true) → (¬ (g1735 E = true)) → False
  exact pattern_9 (g3 E) (g9 E)
private theorem sat_846 (E : Nat → Bool) : (valuation E).satisfies [.neg 17, .neg 2, .pos 1735] := by
  change (g18 E = true) → (g3 E = true) → (¬ (g1736 E = true)) → False
  exact pattern_9 (g3 E) (g18 E)
private theorem sat_847 (E : Nat → Bool) : (valuation E).satisfies [.neg 17, .neg 8, .pos 1736] := by
  change (g18 E = true) → (g9 E = true) → (¬ (g1737 E = true)) → False
  exact pattern_9 (g9 E) (g18 E)
private theorem sat_848 (E : Nat → Bool) : (valuation E).satisfies [.neg 1737, .neg 1736] := by
  change (g1738 E = true) → (g1737 E = true) → False
  exact pattern_18 (g1735 E) (g1736 E) (g1737 E)
private theorem sat_849 (E : Nat → Bool) : (valuation E).satisfies [.neg 1737, .neg 1735] := by
  change (g1738 E = true) → (g1736 E = true) → False
  exact pattern_19 (g1735 E) (g1736 E) (g1737 E)
private theorem sat_850 (E : Nat → Bool) : (valuation E).satisfies [.neg 1737, .neg 1734] := by
  change (g1738 E = true) → (g1735 E = true) → False
  exact pattern_20 (g1735 E) (g1736 E) (g1737 E)
private theorem sat_851 (E : Nat → Bool) : (valuation E).satisfies [.neg 1738, .neg 21] := by
  change (g1739 E = true) → (g22 E = true) → False
  exact pattern_18 (g4 E) (g10 E) (g22 E)
private theorem sat_852 (E : Nat → Bool) : (valuation E).satisfies [.neg 1739, .neg 24] := by
  change (g1740 E = true) → (g25 E = true) → False
  exact pattern_18 (g5 E) (g11 E) (g25 E)
private theorem sat_853 (E : Nat → Bool) : (valuation E).satisfies [.neg 1739, .neg 10] := by
  change (g1740 E = true) → (g11 E = true) → False
  exact pattern_19 (g5 E) (g11 E) (g25 E)
private theorem sat_854 (E : Nat → Bool) : (valuation E).satisfies [.neg 1739, .neg 4] := by
  change (g1740 E = true) → (g5 E = true) → False
  exact pattern_20 (g5 E) (g11 E) (g25 E)
private theorem sat_855 (E : Nat → Bool) : (valuation E).satisfies [.neg 1740, .neg 11] := by
  change (g1741 E = true) → (g12 E = true) → False
  exact pattern_19 (g6 E) (g12 E) (g27 E)
private theorem sat_856 (E : Nat → Bool) : (valuation E).satisfies [.neg 1740, .neg 5] := by
  change (g1741 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g12 E) (g27 E)
private theorem sat_857 (E : Nat → Bool) : (valuation E).satisfies [.neg 1741, .neg 7] := by
  change (g1742 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g14 E) (g29 E)
private theorem sat_859 (E : Nat → Bool) : (valuation E).satisfies [.neg 8, .neg 2, .pos 1742] := by
  change (g9 E = true) → (g3 E = true) → (¬ (g1743 E = true)) → False
  exact pattern_9 (g3 E) (g9 E)
private theorem sat_860 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 8, .pos 1744] := by
  change (g19 E = true) → (g9 E = true) → (¬ (g1745 E = true)) → False
  exact pattern_9 (g9 E) (g19 E)
private theorem sat_861 (E : Nat → Bool) : (valuation E).satisfies [.neg 1745, .neg 1744] := by
  change (g1746 E = true) → (g1745 E = true) → False
  exact pattern_18 (g1743 E) (g1744 E) (g1745 E)
private theorem sat_862 (E : Nat → Bool) : (valuation E).satisfies [.neg 1745, .neg 1742] := by
  change (g1746 E = true) → (g1743 E = true) → False
  exact pattern_20 (g1743 E) (g1744 E) (g1745 E)
private theorem sat_863 (E : Nat → Bool) : (valuation E).satisfies [.neg 1746, .neg 22] := by
  change (g1747 E = true) → (g23 E = true) → False
  exact pattern_18 (g4 E) (g10 E) (g23 E)
private theorem sat_864 (E : Nat → Bool) : (valuation E).satisfies [.neg 1747, .neg 25] := by
  change (g1748 E = true) → (g26 E = true) → False
  exact pattern_18 (g5 E) (g11 E) (g26 E)
private theorem sat_865 (E : Nat → Bool) : (valuation E).satisfies [.neg 1748, .neg 11] := by
  change (g1749 E = true) → (g12 E = true) → False
  exact pattern_19 (g6 E) (g12 E) (g28 E)
private theorem sat_866 (E : Nat → Bool) : (valuation E).satisfies [.neg 1748, .neg 5] := by
  change (g1749 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g12 E) (g28 E)
private theorem sat_867 (E : Nat → Bool) : (valuation E).satisfies [.neg 1749, .neg 6] := by
  change (g1750 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g13 E) (g29 E)
private theorem sat_869 (E : Nat → Bool) : (valuation E).satisfies [.neg 8, .neg 1, .pos 1750] := by
  change (g9 E = true) → (g2 E = true) → (¬ (g1751 E = true)) → False
  exact pattern_9 (g2 E) (g9 E)
private theorem sat_870 (E : Nat → Bool) : (valuation E).satisfies [.neg 9, .neg 8, .pos 1752] := by
  change (g10 E = true) → (g9 E = true) → (¬ (g1753 E = true)) → False
  exact pattern_9 (g9 E) (g10 E)
private theorem sat_871 (E : Nat → Bool) : (valuation E).satisfies [.neg 1753, .neg 1752] := by
  change (g1754 E = true) → (g1753 E = true) → False
  exact pattern_18 (g1751 E) (g1752 E) (g1753 E)
private theorem sat_872 (E : Nat → Bool) : (valuation E).satisfies [.neg 1753, .neg 1750] := by
  change (g1754 E = true) → (g1751 E = true) → False
  exact pattern_20 (g1751 E) (g1752 E) (g1753 E)
private theorem sat_873 (E : Nat → Bool) : (valuation E).satisfies [.neg 1754, .neg 19] := by
  change (g1755 E = true) → (g20 E = true) → False
  exact pattern_18 (g5 E) (g16 E) (g20 E)
private theorem sat_874 (E : Nat → Bool) : (valuation E).satisfies [.neg 1754, .neg 15] := by
  change (g1755 E = true) → (g16 E = true) → False
  exact pattern_19 (g5 E) (g16 E) (g20 E)
private theorem sat_875 (E : Nat → Bool) : (valuation E).satisfies [.neg 1754, .neg 4] := by
  change (g1755 E = true) → (g5 E = true) → False
  exact pattern_20 (g5 E) (g16 E) (g20 E)
private theorem sat_876 (E : Nat → Bool) : (valuation E).satisfies [.pos 4, .pos 15, .pos 19, .pos 1754] := by
  change (¬ (g5 E = true)) → (¬ (g16 E = true)) → (¬ (g20 E = true)) → (¬ (g1755 E = true)) → False
  exact pattern_21 (g5 E) (g16 E) (g20 E)
private theorem sat_877 (E : Nat → Bool) : (valuation E).satisfies [.neg 1755, .neg 20] := by
  change (g1756 E = true) → (g21 E = true) → False
  exact pattern_18 (g6 E) (g17 E) (g21 E)
private theorem sat_878 (E : Nat → Bool) : (valuation E).satisfies [.neg 1755, .neg 16] := by
  change (g1756 E = true) → (g17 E = true) → False
  exact pattern_19 (g6 E) (g17 E) (g21 E)
private theorem sat_879 (E : Nat → Bool) : (valuation E).satisfies [.neg 1755, .neg 5] := by
  change (g1756 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g17 E) (g21 E)
private theorem sat_880 (E : Nat → Bool) : (valuation E).satisfies [.neg 1756, .neg 21] := by
  change (g1757 E = true) → (g22 E = true) → False
  exact pattern_18 (g7 E) (g18 E) (g22 E)
private theorem sat_881 (E : Nat → Bool) : (valuation E).satisfies [.neg 1756, .neg 6] := by
  change (g1757 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g18 E) (g22 E)
private theorem sat_882 (E : Nat → Bool) : (valuation E).satisfies [.neg 1757, .neg 7] := by
  change (g1758 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g19 E) (g23 E)
private theorem sat_884 (E : Nat → Bool) : (valuation E).satisfies [.neg 8, .neg 1, .pos 1758] := by
  change (g9 E = true) → (g2 E = true) → (¬ (g1759 E = true)) → False
  exact pattern_9 (g2 E) (g9 E)
private theorem sat_885 (E : Nat → Bool) : (valuation E).satisfies [.neg 10, .neg 1, .pos 1759] := by
  change (g11 E = true) → (g2 E = true) → (¬ (g1760 E = true)) → False
  exact pattern_9 (g2 E) (g11 E)
private theorem sat_886 (E : Nat → Bool) : (valuation E).satisfies [.neg 10, .neg 8, .pos 1760] := by
  change (g11 E = true) → (g9 E = true) → (¬ (g1761 E = true)) → False
  exact pattern_9 (g9 E) (g11 E)
private theorem sat_887 (E : Nat → Bool) : (valuation E).satisfies [.neg 1761, .neg 1760] := by
  change (g1762 E = true) → (g1761 E = true) → False
  exact pattern_18 (g1759 E) (g1760 E) (g1761 E)
private theorem sat_888 (E : Nat → Bool) : (valuation E).satisfies [.neg 1761, .neg 1759] := by
  change (g1762 E = true) → (g1760 E = true) → False
  exact pattern_19 (g1759 E) (g1760 E) (g1761 E)
private theorem sat_889 (E : Nat → Bool) : (valuation E).satisfies [.neg 1761, .neg 1758] := by
  change (g1762 E = true) → (g1759 E = true) → False
  exact pattern_20 (g1759 E) (g1760 E) (g1761 E)
private theorem sat_890 (E : Nat → Bool) : (valuation E).satisfies [.neg 1762, .neg 19] := by
  change (g1763 E = true) → (g20 E = true) → False
  exact pattern_18 (g4 E) (g15 E) (g20 E)
private theorem sat_891 (E : Nat → Bool) : (valuation E).satisfies [.neg 1762, .neg 14] := by
  change (g1763 E = true) → (g15 E = true) → False
  exact pattern_19 (g4 E) (g15 E) (g20 E)
private theorem sat_892 (E : Nat → Bool) : (valuation E).satisfies [.neg 1763, .neg 23] := by
  change (g1764 E = true) → (g24 E = true) → False
  exact pattern_18 (g6 E) (g17 E) (g24 E)
private theorem sat_893 (E : Nat → Bool) : (valuation E).satisfies [.neg 1763, .neg 16] := by
  change (g1764 E = true) → (g17 E = true) → False
  exact pattern_19 (g6 E) (g17 E) (g24 E)
private theorem sat_894 (E : Nat → Bool) : (valuation E).satisfies [.neg 1763, .neg 5] := by
  change (g1764 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g17 E) (g24 E)
private theorem sat_895 (E : Nat → Bool) : (valuation E).satisfies [.neg 1764, .neg 6] := by
  change (g1765 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g18 E) (g25 E)
private theorem sat_896 (E : Nat → Bool) : (valuation E).satisfies [.neg 1765, .neg 7] := by
  change (g1766 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g19 E) (g26 E)
private theorem sat_898 (E : Nat → Bool) : (valuation E).satisfies [.neg 8, .neg 1, .pos 1766] := by
  change (g9 E = true) → (g2 E = true) → (¬ (g1767 E = true)) → False
  exact pattern_9 (g2 E) (g9 E)
private theorem sat_899 (E : Nat → Bool) : (valuation E).satisfies [.neg 11, .neg 1, .pos 1767] := by
  change (g12 E = true) → (g2 E = true) → (¬ (g1768 E = true)) → False
  exact pattern_9 (g2 E) (g12 E)
private theorem sat_900 (E : Nat → Bool) : (valuation E).satisfies [.neg 11, .neg 8, .pos 1768] := by
  change (g12 E = true) → (g9 E = true) → (¬ (g1769 E = true)) → False
  exact pattern_9 (g9 E) (g12 E)
private theorem sat_901 (E : Nat → Bool) : (valuation E).satisfies [.neg 1769, .neg 1768] := by
  change (g1770 E = true) → (g1769 E = true) → False
  exact pattern_18 (g1767 E) (g1768 E) (g1769 E)
private theorem sat_902 (E : Nat → Bool) : (valuation E).satisfies [.neg 1769, .neg 1767] := by
  change (g1770 E = true) → (g1768 E = true) → False
  exact pattern_19 (g1767 E) (g1768 E) (g1769 E)
private theorem sat_903 (E : Nat → Bool) : (valuation E).satisfies [.neg 1769, .neg 1766] := by
  change (g1770 E = true) → (g1767 E = true) → False
  exact pattern_20 (g1767 E) (g1768 E) (g1769 E)
private theorem sat_904 (E : Nat → Bool) : (valuation E).satisfies [.neg 1770, .neg 20] := by
  change (g1771 E = true) → (g21 E = true) → False
  exact pattern_18 (g4 E) (g15 E) (g21 E)
private theorem sat_905 (E : Nat → Bool) : (valuation E).satisfies [.neg 1770, .neg 14] := by
  change (g1771 E = true) → (g15 E = true) → False
  exact pattern_19 (g4 E) (g15 E) (g21 E)
private theorem sat_906 (E : Nat → Bool) : (valuation E).satisfies [.pos 3, .pos 14, .pos 20, .pos 1770] := by
  change (¬ (g4 E = true)) → (¬ (g15 E = true)) → (¬ (g21 E = true)) → (¬ (g1771 E = true)) → False
  exact pattern_21 (g4 E) (g15 E) (g21 E)
private theorem sat_907 (E : Nat → Bool) : (valuation E).satisfies [.neg 1771, .neg 23] := by
  change (g1772 E = true) → (g24 E = true) → False
  exact pattern_18 (g5 E) (g16 E) (g24 E)
private theorem sat_908 (E : Nat → Bool) : (valuation E).satisfies [.neg 1771, .neg 15] := by
  change (g1772 E = true) → (g16 E = true) → False
  exact pattern_19 (g5 E) (g16 E) (g24 E)
private theorem sat_909 (E : Nat → Bool) : (valuation E).satisfies [.neg 1771, .neg 4] := by
  change (g1772 E = true) → (g5 E = true) → False
  exact pattern_20 (g5 E) (g16 E) (g24 E)
private theorem sat_910 (E : Nat → Bool) : (valuation E).satisfies [.neg 1772, .neg 26] := by
  change (g1773 E = true) → (g27 E = true) → False
  exact pattern_18 (g7 E) (g18 E) (g27 E)
private theorem sat_911 (E : Nat → Bool) : (valuation E).satisfies [.neg 1772, .neg 17] := by
  change (g1773 E = true) → (g18 E = true) → False
  exact pattern_19 (g7 E) (g18 E) (g27 E)
private theorem sat_912 (E : Nat → Bool) : (valuation E).satisfies [.neg 1772, .neg 6] := by
  change (g1773 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g18 E) (g27 E)
private theorem sat_913 (E : Nat → Bool) : (valuation E).satisfies [.neg 1773, .neg 18] := by
  change (g1774 E = true) → (g19 E = true) → False
  exact pattern_19 (g8 E) (g19 E) (g28 E)
private theorem sat_914 (E : Nat → Bool) : (valuation E).satisfies [.neg 1773, .neg 7] := by
  change (g1774 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g19 E) (g28 E)
private theorem sat_916 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 1, .pos 1775] := by
  change (g13 E = true) → (g2 E = true) → (¬ (g1776 E = true)) → False
  exact pattern_9 (g2 E) (g13 E)
private theorem sat_917 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 8, .pos 1776] := by
  change (g13 E = true) → (g9 E = true) → (¬ (g1777 E = true)) → False
  exact pattern_9 (g9 E) (g13 E)
private theorem sat_918 (E : Nat → Bool) : (valuation E).satisfies [.neg 1777, .neg 1776] := by
  change (g1778 E = true) → (g1777 E = true) → False
  exact pattern_18 (g1775 E) (g1776 E) (g1777 E)
private theorem sat_919 (E : Nat → Bool) : (valuation E).satisfies [.neg 1777, .neg 1775] := by
  change (g1778 E = true) → (g1776 E = true) → False
  exact pattern_19 (g1775 E) (g1776 E) (g1777 E)
private theorem sat_920 (E : Nat → Bool) : (valuation E).satisfies [.neg 1778, .neg 21] := by
  change (g1779 E = true) → (g22 E = true) → False
  exact pattern_18 (g4 E) (g15 E) (g22 E)
private theorem sat_921 (E : Nat → Bool) : (valuation E).satisfies [.neg 1778, .neg 14] := by
  change (g1779 E = true) → (g15 E = true) → False
  exact pattern_19 (g4 E) (g15 E) (g22 E)
private theorem sat_922 (E : Nat → Bool) : (valuation E).satisfies [.neg 1779, .neg 24] := by
  change (g1780 E = true) → (g25 E = true) → False
  exact pattern_18 (g5 E) (g16 E) (g25 E)
private theorem sat_923 (E : Nat → Bool) : (valuation E).satisfies [.neg 1779, .neg 15] := by
  change (g1780 E = true) → (g16 E = true) → False
  exact pattern_19 (g5 E) (g16 E) (g25 E)
private theorem sat_924 (E : Nat → Bool) : (valuation E).satisfies [.neg 1779, .neg 4] := by
  change (g1780 E = true) → (g5 E = true) → False
  exact pattern_20 (g5 E) (g16 E) (g25 E)
private theorem sat_925 (E : Nat → Bool) : (valuation E).satisfies [.neg 1780, .neg 26] := by
  change (g1781 E = true) → (g27 E = true) → False
  exact pattern_18 (g6 E) (g17 E) (g27 E)
private theorem sat_926 (E : Nat → Bool) : (valuation E).satisfies [.neg 1780, .neg 16] := by
  change (g1781 E = true) → (g17 E = true) → False
  exact pattern_19 (g6 E) (g17 E) (g27 E)
private theorem sat_927 (E : Nat → Bool) : (valuation E).satisfies [.neg 1780, .neg 5] := by
  change (g1781 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g17 E) (g27 E)
private theorem sat_928 (E : Nat → Bool) : (valuation E).satisfies [.pos 5, .pos 16, .pos 26, .pos 1780] := by
  change (¬ (g6 E = true)) → (¬ (g17 E = true)) → (¬ (g27 E = true)) → (¬ (g1781 E = true)) → False
  exact pattern_21 (g6 E) (g17 E) (g27 E)
private theorem sat_929 (E : Nat → Bool) : (valuation E).satisfies [.neg 1781, .neg 18] := by
  change (g1782 E = true) → (g19 E = true) → False
  exact pattern_19 (g8 E) (g19 E) (g29 E)
private theorem sat_930 (E : Nat → Bool) : (valuation E).satisfies [.neg 1781, .neg 7] := by
  change (g1782 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g19 E) (g29 E)
private theorem sat_932 (E : Nat → Bool) : (valuation E).satisfies [.neg 8, .neg 1, .pos 1782] := by
  change (g9 E = true) → (g2 E = true) → (¬ (g1783 E = true)) → False
  exact pattern_9 (g2 E) (g9 E)
private theorem sat_933 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 1, .pos 1783] := by
  change (g14 E = true) → (g2 E = true) → (¬ (g1784 E = true)) → False
  exact pattern_9 (g2 E) (g14 E)
private theorem sat_934 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 8, .pos 1784] := by
  change (g14 E = true) → (g9 E = true) → (¬ (g1785 E = true)) → False
  exact pattern_9 (g9 E) (g14 E)
private theorem sat_935 (E : Nat → Bool) : (valuation E).satisfies [.neg 1785, .neg 1784] := by
  change (g1786 E = true) → (g1785 E = true) → False
  exact pattern_18 (g1783 E) (g1784 E) (g1785 E)
private theorem sat_936 (E : Nat → Bool) : (valuation E).satisfies [.neg 1785, .neg 1783] := by
  change (g1786 E = true) → (g1784 E = true) → False
  exact pattern_19 (g1783 E) (g1784 E) (g1785 E)
private theorem sat_937 (E : Nat → Bool) : (valuation E).satisfies [.neg 1785, .neg 1782] := by
  change (g1786 E = true) → (g1783 E = true) → False
  exact pattern_20 (g1783 E) (g1784 E) (g1785 E)
private theorem sat_938 (E : Nat → Bool) : (valuation E).satisfies [.neg 1786, .neg 22] := by
  change (g1787 E = true) → (g23 E = true) → False
  exact pattern_18 (g4 E) (g15 E) (g23 E)
private theorem sat_939 (E : Nat → Bool) : (valuation E).satisfies [.neg 1786, .neg 14] := by
  change (g1787 E = true) → (g15 E = true) → False
  exact pattern_19 (g4 E) (g15 E) (g23 E)
private theorem sat_940 (E : Nat → Bool) : (valuation E).satisfies [.neg 1787, .neg 25] := by
  change (g1788 E = true) → (g26 E = true) → False
  exact pattern_18 (g5 E) (g16 E) (g26 E)
private theorem sat_941 (E : Nat → Bool) : (valuation E).satisfies [.neg 1787, .neg 15] := by
  change (g1788 E = true) → (g16 E = true) → False
  exact pattern_19 (g5 E) (g16 E) (g26 E)
private theorem sat_942 (E : Nat → Bool) : (valuation E).satisfies [.neg 1787, .neg 4] := by
  change (g1788 E = true) → (g5 E = true) → False
  exact pattern_20 (g5 E) (g16 E) (g26 E)
private theorem sat_943 (E : Nat → Bool) : (valuation E).satisfies [.neg 1788, .neg 27] := by
  change (g1789 E = true) → (g28 E = true) → False
  exact pattern_18 (g6 E) (g17 E) (g28 E)
private theorem sat_944 (E : Nat → Bool) : (valuation E).satisfies [.neg 1788, .neg 5] := by
  change (g1789 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g17 E) (g28 E)
private theorem sat_945 (E : Nat → Bool) : (valuation E).satisfies [.neg 1789, .neg 17] := by
  change (g1790 E = true) → (g18 E = true) → False
  exact pattern_19 (g7 E) (g18 E) (g29 E)
private theorem sat_946 (E : Nat → Bool) : (valuation E).satisfies [.neg 1789, .neg 6] := by
  change (g1790 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g18 E) (g29 E)
private theorem sat_948 (E : Nat → Bool) : (valuation E).satisfies [.neg 11, .neg 10, .pos 1836] := by
  change (g12 E = true) → (g11 E = true) → (¬ (g1837 E = true)) → False
  exact pattern_9 (g11 E) (g12 E)
private theorem sat_949 (E : Nat → Bool) : (valuation E).satisfies [.neg 1837, .neg 1836] := by
  change (g1838 E = true) → (g1837 E = true) → False
  exact pattern_18 (g1835 E) (g1836 E) (g1837 E)
private theorem sat_950 (E : Nat → Bool) : (valuation E).satisfies [.neg 16, .neg 15, .pos 1840] := by
  change (g17 E = true) → (g16 E = true) → (¬ (g1841 E = true)) → False
  exact pattern_9 (g16 E) (g17 E)
private theorem sat_951 (E : Nat → Bool) : (valuation E).satisfies [.neg 1841, .neg 1840] := by
  change (g1842 E = true) → (g1841 E = true) → False
  exact pattern_18 (g1839 E) (g1840 E) (g1841 E)
private theorem sat_952 (E : Nat → Bool) : (valuation E).satisfies [.neg 1842, .neg 19] := by
  change (g1843 E = true) → (g20 E = true) → False
  exact pattern_19 (g4 E) (g20 E) (g21 E)
private theorem sat_953 (E : Nat → Bool) : (valuation E).satisfies [.neg 1843, .neg 6] := by
  change (g1844 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g25 E) (g27 E)
private theorem sat_954 (E : Nat → Bool) : (valuation E).satisfies [.neg 1844, .neg 7] := by
  change (g1845 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g26 E) (g28 E)
private theorem sat_956 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 10, .pos 1847] := by
  change (g13 E = true) → (g11 E = true) → (¬ (g1848 E = true)) → False
  exact pattern_9 (g11 E) (g13 E)
private theorem sat_957 (E : Nat → Bool) : (valuation E).satisfies [.neg 1848, .neg 1847] := by
  change (g1849 E = true) → (g1848 E = true) → False
  exact pattern_18 (g1846 E) (g1847 E) (g1848 E)
private theorem sat_958 (E : Nat → Bool) : (valuation E).satisfies [.neg 17, .neg 15, .pos 1851] := by
  change (g18 E = true) → (g16 E = true) → (¬ (g1852 E = true)) → False
  exact pattern_9 (g16 E) (g18 E)
private theorem sat_959 (E : Nat → Bool) : (valuation E).satisfies [.neg 1852, .neg 1851] := by
  change (g1853 E = true) → (g1852 E = true) → False
  exact pattern_18 (g1850 E) (g1851 E) (g1852 E)
private theorem sat_960 (E : Nat → Bool) : (valuation E).satisfies [.neg 1853, .neg 19] := by
  change (g1854 E = true) → (g20 E = true) → False
  exact pattern_19 (g4 E) (g20 E) (g22 E)
private theorem sat_961 (E : Nat → Bool) : (valuation E).satisfies [.neg 1854, .neg 5] := by
  change (g1855 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g24 E) (g27 E)
private theorem sat_962 (E : Nat → Bool) : (valuation E).satisfies [.neg 1855, .neg 7] := by
  change (g1856 E = true) → (g8 E = true) → False
  exact pattern_20 (g8 E) (g26 E) (g29 E)
private theorem sat_964 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 1, .pos 1857] := by
  change (g14 E = true) → (g2 E = true) → (¬ (g1858 E = true)) → False
  exact pattern_9 (g2 E) (g14 E)
private theorem sat_965 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 10, .pos 1858] := by
  change (g14 E = true) → (g11 E = true) → (¬ (g1859 E = true)) → False
  exact pattern_9 (g11 E) (g14 E)
private theorem sat_966 (E : Nat → Bool) : (valuation E).satisfies [.neg 1859, .neg 1858] := by
  change (g1860 E = true) → (g1859 E = true) → False
  exact pattern_18 (g1857 E) (g1858 E) (g1859 E)
private theorem sat_967 (E : Nat → Bool) : (valuation E).satisfies [.neg 1859, .neg 1857] := by
  change (g1860 E = true) → (g1858 E = true) → False
  exact pattern_19 (g1857 E) (g1858 E) (g1859 E)
private theorem sat_968 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 2, .pos 1861] := by
  change (g19 E = true) → (g3 E = true) → (¬ (g1862 E = true)) → False
  exact pattern_9 (g3 E) (g19 E)
private theorem sat_969 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 15, .pos 1862] := by
  change (g19 E = true) → (g16 E = true) → (¬ (g1863 E = true)) → False
  exact pattern_9 (g16 E) (g19 E)
private theorem sat_970 (E : Nat → Bool) : (valuation E).satisfies [.neg 1863, .neg 1862] := by
  change (g1864 E = true) → (g1863 E = true) → False
  exact pattern_18 (g1861 E) (g1862 E) (g1863 E)
private theorem sat_971 (E : Nat → Bool) : (valuation E).satisfies [.neg 1863, .neg 1861] := by
  change (g1864 E = true) → (g1862 E = true) → False
  exact pattern_19 (g1861 E) (g1862 E) (g1863 E)
private theorem sat_972 (E : Nat → Bool) : (valuation E).satisfies [.neg 1864, .neg 22] := by
  change (g1865 E = true) → (g23 E = true) → False
  exact pattern_18 (g4 E) (g20 E) (g23 E)
private theorem sat_973 (E : Nat → Bool) : (valuation E).satisfies [.neg 1864, .neg 19] := by
  change (g1865 E = true) → (g20 E = true) → False
  exact pattern_19 (g4 E) (g20 E) (g23 E)
private theorem sat_974 (E : Nat → Bool) : (valuation E).satisfies [.pos 3, .pos 19, .pos 22, .pos 1864] := by
  change (¬ (g4 E = true)) → (¬ (g20 E = true)) → (¬ (g23 E = true)) → (¬ (g1865 E = true)) → False
  exact pattern_21 (g4 E) (g20 E) (g23 E)
private theorem sat_975 (E : Nat → Bool) : (valuation E).satisfies [.neg 1865, .neg 27] := by
  change (g1866 E = true) → (g28 E = true) → False
  exact pattern_18 (g6 E) (g24 E) (g28 E)
private theorem sat_976 (E : Nat → Bool) : (valuation E).satisfies [.neg 1865, .neg 23] := by
  change (g1866 E = true) → (g24 E = true) → False
  exact pattern_19 (g6 E) (g24 E) (g28 E)
private theorem sat_977 (E : Nat → Bool) : (valuation E).satisfies [.neg 1865, .neg 5] := by
  change (g1866 E = true) → (g6 E = true) → False
  exact pattern_20 (g6 E) (g24 E) (g28 E)
private theorem sat_978 (E : Nat → Bool) : (valuation E).satisfies [.pos 5, .pos 23, .pos 27, .pos 1865] := by
  change (¬ (g6 E = true)) → (¬ (g24 E = true)) → (¬ (g28 E = true)) → (¬ (g1866 E = true)) → False
  exact pattern_21 (g6 E) (g24 E) (g28 E)
private theorem sat_979 (E : Nat → Bool) : (valuation E).satisfies [.neg 1866, .neg 6] := by
  change (g1867 E = true) → (g7 E = true) → False
  exact pattern_20 (g7 E) (g25 E) (g29 E)
private theorem sat_981 (E : Nat → Bool) : (valuation E).satisfies [.neg 2, .neg 1, .pos 1900] := by
  change (g3 E = true) → (g2 E = true) → (¬ (g1901 E = true)) → False
  exact pattern_9 (g2 E) (g3 E)
private theorem sat_982 (E : Nat → Bool) : (valuation E).satisfies [.neg 3, .neg 2, .pos 1902] := by
  change (g4 E = true) → (g3 E = true) → (¬ (g1903 E = true)) → False
  exact pattern_9 (g3 E) (g4 E)
private theorem sat_983 (E : Nat → Bool) : (valuation E).satisfies [.neg 1903, .neg 1902] := by
  change (g1904 E = true) → (g1903 E = true) → False
  exact pattern_18 (g1901 E) (g1902 E) (g1903 E)
private theorem sat_984 (E : Nat → Bool) : (valuation E).satisfies [.neg 1903, .neg 1900] := by
  change (g1904 E = true) → (g1901 E = true) → False
  exact pattern_20 (g1901 E) (g1902 E) (g1903 E)
private theorem sat_985 (E : Nat → Bool) : (valuation E).satisfies [.neg 1904, .neg 19] := by
  change (g1905 E = true) → (g20 E = true) → False
  exact pattern_18 (g11 E) (g16 E) (g20 E)
private theorem sat_986 (E : Nat → Bool) : (valuation E).satisfies [.neg 1904, .neg 15] := by
  change (g1905 E = true) → (g16 E = true) → False
  exact pattern_19 (g11 E) (g16 E) (g20 E)
private theorem sat_987 (E : Nat → Bool) : (valuation E).satisfies [.neg 1905, .neg 20] := by
  change (g1906 E = true) → (g21 E = true) → False
  exact pattern_18 (g12 E) (g17 E) (g21 E)
private theorem sat_988 (E : Nat → Bool) : (valuation E).satisfies [.neg 1905, .neg 11] := by
  change (g1906 E = true) → (g12 E = true) → False
  exact pattern_20 (g12 E) (g17 E) (g21 E)
private theorem sat_989 (E : Nat → Bool) : (valuation E).satisfies [.neg 1906, .neg 12] := by
  change (g1907 E = true) → (g13 E = true) → False
  exact pattern_20 (g13 E) (g18 E) (g22 E)
private theorem sat_990 (E : Nat → Bool) : (valuation E).satisfies [.neg 1907, .neg 22] := by
  change (g1908 E = true) → (g23 E = true) → False
  exact pattern_18 (g14 E) (g19 E) (g23 E)
private theorem sat_991 (E : Nat → Bool) : (valuation E).satisfies [.neg 1907, .neg 18] := by
  change (g1908 E = true) → (g19 E = true) → False
  exact pattern_19 (g14 E) (g19 E) (g23 E)
private theorem sat_992 (E : Nat → Bool) : (valuation E).satisfies [.neg 1907, .neg 13] := by
  change (g1908 E = true) → (g14 E = true) → False
  exact pattern_20 (g14 E) (g19 E) (g23 E)
private theorem sat_994 (E : Nat → Bool) : (valuation E).satisfies [.neg 2, .neg 1, .pos 1908] := by
  change (g3 E = true) → (g2 E = true) → (¬ (g1909 E = true)) → False
  exact pattern_9 (g2 E) (g3 E)
private theorem sat_995 (E : Nat → Bool) : (valuation E).satisfies [.neg 4, .neg 2, .pos 1910] := by
  change (g5 E = true) → (g3 E = true) → (¬ (g1911 E = true)) → False
  exact pattern_9 (g3 E) (g5 E)
private theorem sat_996 (E : Nat → Bool) : (valuation E).satisfies [.neg 1911, .neg 1910] := by
  change (g1912 E = true) → (g1911 E = true) → False
  exact pattern_18 (g1909 E) (g1910 E) (g1911 E)
private theorem sat_997 (E : Nat → Bool) : (valuation E).satisfies [.neg 1911, .neg 1908] := by
  change (g1912 E = true) → (g1909 E = true) → False
  exact pattern_20 (g1909 E) (g1910 E) (g1911 E)
private theorem sat_998 (E : Nat → Bool) : (valuation E).satisfies [.neg 1912, .neg 19] := by
  change (g1913 E = true) → (g20 E = true) → False
  exact pattern_18 (g10 E) (g15 E) (g20 E)
private theorem sat_999 (E : Nat → Bool) : (valuation E).satisfies [.neg 1912, .neg 14] := by
  change (g1913 E = true) → (g15 E = true) → False
  exact pattern_19 (g10 E) (g15 E) (g20 E)
private theorem sat_1000 (E : Nat → Bool) : (valuation E).satisfies [.neg 1913, .neg 23] := by
  change (g1914 E = true) → (g24 E = true) → False
  exact pattern_18 (g12 E) (g17 E) (g24 E)
private theorem sat_1001 (E : Nat → Bool) : (valuation E).satisfies [.neg 1913, .neg 16] := by
  change (g1914 E = true) → (g17 E = true) → False
  exact pattern_19 (g12 E) (g17 E) (g24 E)
private theorem sat_1002 (E : Nat → Bool) : (valuation E).satisfies [.neg 1913, .neg 11] := by
  change (g1914 E = true) → (g12 E = true) → False
  exact pattern_20 (g12 E) (g17 E) (g24 E)
private theorem sat_1003 (E : Nat → Bool) : (valuation E).satisfies [.neg 1914, .neg 24] := by
  change (g1915 E = true) → (g25 E = true) → False
  exact pattern_18 (g13 E) (g18 E) (g25 E)
private theorem sat_1004 (E : Nat → Bool) : (valuation E).satisfies [.neg 1914, .neg 17] := by
  change (g1915 E = true) → (g18 E = true) → False
  exact pattern_19 (g13 E) (g18 E) (g25 E)
private theorem sat_1005 (E : Nat → Bool) : (valuation E).satisfies [.neg 1914, .neg 12] := by
  change (g1915 E = true) → (g13 E = true) → False
  exact pattern_20 (g13 E) (g18 E) (g25 E)
private theorem sat_1006 (E : Nat → Bool) : (valuation E).satisfies [.neg 1915, .neg 25] := by
  change (g1916 E = true) → (g26 E = true) → False
  exact pattern_18 (g14 E) (g19 E) (g26 E)
private theorem sat_1007 (E : Nat → Bool) : (valuation E).satisfies [.neg 1915, .neg 18] := by
  change (g1916 E = true) → (g19 E = true) → False
  exact pattern_19 (g14 E) (g19 E) (g26 E)
private theorem sat_1008 (E : Nat → Bool) : (valuation E).satisfies [.neg 1915, .neg 13] := by
  change (g1916 E = true) → (g14 E = true) → False
  exact pattern_20 (g14 E) (g19 E) (g26 E)
private theorem sat_1010 (E : Nat → Bool) : (valuation E).satisfies [.neg 2, .neg 1, .pos 1916] := by
  change (g3 E = true) → (g2 E = true) → (¬ (g1917 E = true)) → False
  exact pattern_9 (g2 E) (g3 E)
private theorem sat_1011 (E : Nat → Bool) : (valuation E).satisfies [.neg 5, .neg 1, .pos 1917] := by
  change (g6 E = true) → (g2 E = true) → (¬ (g1918 E = true)) → False
  exact pattern_9 (g2 E) (g6 E)
private theorem sat_1012 (E : Nat → Bool) : (valuation E).satisfies [.neg 5, .neg 2, .pos 1918] := by
  change (g6 E = true) → (g3 E = true) → (¬ (g1919 E = true)) → False
  exact pattern_9 (g3 E) (g6 E)
private theorem sat_1013 (E : Nat → Bool) : (valuation E).satisfies [.neg 1919, .neg 1918] := by
  change (g1920 E = true) → (g1919 E = true) → False
  exact pattern_18 (g1917 E) (g1918 E) (g1919 E)
private theorem sat_1014 (E : Nat → Bool) : (valuation E).satisfies [.neg 1919, .neg 1917] := by
  change (g1920 E = true) → (g1918 E = true) → False
  exact pattern_19 (g1917 E) (g1918 E) (g1919 E)
private theorem sat_1015 (E : Nat → Bool) : (valuation E).satisfies [.neg 1919, .neg 1916] := by
  change (g1920 E = true) → (g1917 E = true) → False
  exact pattern_20 (g1917 E) (g1918 E) (g1919 E)
private theorem sat_1016 (E : Nat → Bool) : (valuation E).satisfies [.neg 1920, .neg 20] := by
  change (g1921 E = true) → (g21 E = true) → False
  exact pattern_18 (g10 E) (g15 E) (g21 E)
private theorem sat_1017 (E : Nat → Bool) : (valuation E).satisfies [.neg 1920, .neg 14] := by
  change (g1921 E = true) → (g15 E = true) → False
  exact pattern_19 (g10 E) (g15 E) (g21 E)
private theorem sat_1018 (E : Nat → Bool) : (valuation E).satisfies [.neg 1921, .neg 23] := by
  change (g1922 E = true) → (g24 E = true) → False
  exact pattern_18 (g11 E) (g16 E) (g24 E)
private theorem sat_1019 (E : Nat → Bool) : (valuation E).satisfies [.neg 1921, .neg 15] := by
  change (g1922 E = true) → (g16 E = true) → False
  exact pattern_19 (g11 E) (g16 E) (g24 E)
private theorem sat_1020 (E : Nat → Bool) : (valuation E).satisfies [.neg 1922, .neg 17] := by
  change (g1923 E = true) → (g18 E = true) → False
  exact pattern_19 (g13 E) (g18 E) (g27 E)
private theorem sat_1021 (E : Nat → Bool) : (valuation E).satisfies [.neg 1922, .neg 12] := by
  change (g1923 E = true) → (g13 E = true) → False
  exact pattern_20 (g13 E) (g18 E) (g27 E)
private theorem sat_1022 (E : Nat → Bool) : (valuation E).satisfies [.neg 1923, .neg 18] := by
  change (g1924 E = true) → (g19 E = true) → False
  exact pattern_19 (g14 E) (g19 E) (g28 E)
private theorem sat_1023 (E : Nat → Bool) : (valuation E).satisfies [.neg 1923, .neg 13] := by
  change (g1924 E = true) → (g14 E = true) → False
  exact pattern_20 (g14 E) (g19 E) (g28 E)
private theorem sat_1025 (E : Nat → Bool) : (valuation E).satisfies [.neg 2, .neg 1, .pos 1924] := by
  change (g3 E = true) → (g2 E = true) → (¬ (g1925 E = true)) → False
  exact pattern_9 (g2 E) (g3 E)
private theorem sat_1026 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .neg 1, .pos 1925] := by
  change (g7 E = true) → (g2 E = true) → (¬ (g1926 E = true)) → False
  exact pattern_9 (g2 E) (g7 E)
private theorem sat_1027 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .neg 2, .pos 1926] := by
  change (g7 E = true) → (g3 E = true) → (¬ (g1927 E = true)) → False
  exact pattern_9 (g3 E) (g7 E)
private theorem sat_1028 (E : Nat → Bool) : (valuation E).satisfies [.neg 1927, .neg 1926] := by
  change (g1928 E = true) → (g1927 E = true) → False
  exact pattern_18 (g1925 E) (g1926 E) (g1927 E)
private theorem sat_1029 (E : Nat → Bool) : (valuation E).satisfies [.neg 1927, .neg 1925] := by
  change (g1928 E = true) → (g1926 E = true) → False
  exact pattern_19 (g1925 E) (g1926 E) (g1927 E)
private theorem sat_1030 (E : Nat → Bool) : (valuation E).satisfies [.neg 1927, .neg 1924] := by
  change (g1928 E = true) → (g1925 E = true) → False
  exact pattern_20 (g1925 E) (g1926 E) (g1927 E)
private theorem sat_1031 (E : Nat → Bool) : (valuation E).satisfies [.neg 1928, .neg 21] := by
  change (g1929 E = true) → (g22 E = true) → False
  exact pattern_18 (g10 E) (g15 E) (g22 E)
private theorem sat_1032 (E : Nat → Bool) : (valuation E).satisfies [.neg 1928, .neg 14] := by
  change (g1929 E = true) → (g15 E = true) → False
  exact pattern_19 (g10 E) (g15 E) (g22 E)
private theorem sat_1033 (E : Nat → Bool) : (valuation E).satisfies [.neg 1928, .neg 9] := by
  change (g1929 E = true) → (g10 E = true) → False
  exact pattern_20 (g10 E) (g15 E) (g22 E)
private theorem sat_1034 (E : Nat → Bool) : (valuation E).satisfies [.pos 9, .pos 14, .pos 21, .pos 1928] := by
  change (¬ (g10 E = true)) → (¬ (g15 E = true)) → (¬ (g22 E = true)) → (¬ (g1929 E = true)) → False
  exact pattern_21 (g10 E) (g15 E) (g22 E)
private theorem sat_1035 (E : Nat → Bool) : (valuation E).satisfies [.neg 1929, .neg 24] := by
  change (g1930 E = true) → (g25 E = true) → False
  exact pattern_18 (g11 E) (g16 E) (g25 E)
private theorem sat_1036 (E : Nat → Bool) : (valuation E).satisfies [.neg 1929, .neg 15] := by
  change (g1930 E = true) → (g16 E = true) → False
  exact pattern_19 (g11 E) (g16 E) (g25 E)
private theorem sat_1037 (E : Nat → Bool) : (valuation E).satisfies [.neg 1929, .neg 10] := by
  change (g1930 E = true) → (g11 E = true) → False
  exact pattern_20 (g11 E) (g16 E) (g25 E)
private theorem sat_1038 (E : Nat → Bool) : (valuation E).satisfies [.neg 1930, .neg 26] := by
  change (g1931 E = true) → (g27 E = true) → False
  exact pattern_18 (g12 E) (g17 E) (g27 E)
private theorem sat_1039 (E : Nat → Bool) : (valuation E).satisfies [.neg 1930, .neg 16] := by
  change (g1931 E = true) → (g17 E = true) → False
  exact pattern_19 (g12 E) (g17 E) (g27 E)
private theorem sat_1040 (E : Nat → Bool) : (valuation E).satisfies [.neg 1930, .neg 11] := by
  change (g1931 E = true) → (g12 E = true) → False
  exact pattern_20 (g12 E) (g17 E) (g27 E)
private theorem sat_1041 (E : Nat → Bool) : (valuation E).satisfies [.neg 1931, .neg 18] := by
  change (g1932 E = true) → (g19 E = true) → False
  exact pattern_19 (g14 E) (g19 E) (g29 E)
private theorem sat_1042 (E : Nat → Bool) : (valuation E).satisfies [.neg 1931, .neg 13] := by
  change (g1932 E = true) → (g14 E = true) → False
  exact pattern_20 (g14 E) (g19 E) (g29 E)
private theorem sat_1044 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 1, .pos 1933] := by
  change (g8 E = true) → (g2 E = true) → (¬ (g1934 E = true)) → False
  exact pattern_9 (g2 E) (g8 E)
private theorem sat_1045 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 2, .pos 1934] := by
  change (g8 E = true) → (g3 E = true) → (¬ (g1935 E = true)) → False
  exact pattern_9 (g3 E) (g8 E)
private theorem sat_1046 (E : Nat → Bool) : (valuation E).satisfies [.neg 1935, .neg 1934] := by
  change (g1936 E = true) → (g1935 E = true) → False
  exact pattern_18 (g1933 E) (g1934 E) (g1935 E)
private theorem sat_1047 (E : Nat → Bool) : (valuation E).satisfies [.neg 1935, .neg 1933] := by
  change (g1936 E = true) → (g1934 E = true) → False
  exact pattern_19 (g1933 E) (g1934 E) (g1935 E)
private theorem sat_1048 (E : Nat → Bool) : (valuation E).satisfies [.neg 1936, .neg 22] := by
  change (g1937 E = true) → (g23 E = true) → False
  exact pattern_18 (g10 E) (g15 E) (g23 E)
private theorem sat_1049 (E : Nat → Bool) : (valuation E).satisfies [.neg 1936, .neg 14] := by
  change (g1937 E = true) → (g15 E = true) → False
  exact pattern_19 (g10 E) (g15 E) (g23 E)
private theorem sat_1050 (E : Nat → Bool) : (valuation E).satisfies [.neg 1936, .neg 9] := by
  change (g1937 E = true) → (g10 E = true) → False
  exact pattern_20 (g10 E) (g15 E) (g23 E)
private theorem sat_1051 (E : Nat → Bool) : (valuation E).satisfies [.neg 1937, .neg 25] := by
  change (g1938 E = true) → (g26 E = true) → False
  exact pattern_18 (g11 E) (g16 E) (g26 E)
private theorem sat_1052 (E : Nat → Bool) : (valuation E).satisfies [.neg 1937, .neg 15] := by
  change (g1938 E = true) → (g16 E = true) → False
  exact pattern_19 (g11 E) (g16 E) (g26 E)
private theorem sat_1053 (E : Nat → Bool) : (valuation E).satisfies [.neg 1937, .neg 10] := by
  change (g1938 E = true) → (g11 E = true) → False
  exact pattern_20 (g11 E) (g16 E) (g26 E)
private theorem sat_1054 (E : Nat → Bool) : (valuation E).satisfies [.pos 10, .pos 15, .pos 25, .pos 1937] := by
  change (¬ (g11 E = true)) → (¬ (g16 E = true)) → (¬ (g26 E = true)) → (¬ (g1938 E = true)) → False
  exact pattern_21 (g11 E) (g16 E) (g26 E)
private theorem sat_1055 (E : Nat → Bool) : (valuation E).satisfies [.neg 1938, .neg 27] := by
  change (g1939 E = true) → (g28 E = true) → False
  exact pattern_18 (g12 E) (g17 E) (g28 E)
private theorem sat_1056 (E : Nat → Bool) : (valuation E).satisfies [.neg 1938, .neg 16] := by
  change (g1939 E = true) → (g17 E = true) → False
  exact pattern_19 (g12 E) (g17 E) (g28 E)
private theorem sat_1057 (E : Nat → Bool) : (valuation E).satisfies [.neg 1938, .neg 11] := by
  change (g1939 E = true) → (g12 E = true) → False
  exact pattern_20 (g12 E) (g17 E) (g28 E)
private theorem sat_1058 (E : Nat → Bool) : (valuation E).satisfies [.neg 1939, .neg 17] := by
  change (g1940 E = true) → (g18 E = true) → False
  exact pattern_19 (g13 E) (g18 E) (g29 E)
private theorem sat_1059 (E : Nat → Bool) : (valuation E).satisfies [.neg 1939, .neg 12] := by
  change (g1940 E = true) → (g13 E = true) → False
  exact pattern_20 (g13 E) (g18 E) (g29 E)
private theorem sat_1061 (E : Nat → Bool) : (valuation E).satisfies [.neg 5, .neg 4, .pos 1986] := by
  change (g6 E = true) → (g5 E = true) → (¬ (g1987 E = true)) → False
  exact pattern_9 (g5 E) (g6 E)
private theorem sat_1062 (E : Nat → Bool) : (valuation E).satisfies [.neg 1987, .neg 1986] := by
  change (g1988 E = true) → (g1987 E = true) → False
  exact pattern_18 (g1985 E) (g1986 E) (g1987 E)
private theorem sat_1063 (E : Nat → Bool) : (valuation E).satisfies [.neg 16, .neg 15, .pos 1990] := by
  change (g17 E = true) → (g16 E = true) → (¬ (g1991 E = true)) → False
  exact pattern_9 (g16 E) (g17 E)
private theorem sat_1064 (E : Nat → Bool) : (valuation E).satisfies [.neg 1991, .neg 1990] := by
  change (g1992 E = true) → (g1991 E = true) → False
  exact pattern_18 (g1989 E) (g1990 E) (g1991 E)
private theorem sat_1065 (E : Nat → Bool) : (valuation E).satisfies [.neg 1992, .neg 19] := by
  change (g1993 E = true) → (g20 E = true) → False
  exact pattern_19 (g10 E) (g20 E) (g21 E)
private theorem sat_1066 (E : Nat → Bool) : (valuation E).satisfies [.neg 1993, .neg 12] := by
  change (g1994 E = true) → (g13 E = true) → False
  exact pattern_20 (g13 E) (g25 E) (g27 E)
private theorem sat_1067 (E : Nat → Bool) : (valuation E).satisfies [.neg 1994, .neg 13] := by
  change (g1995 E = true) → (g14 E = true) → False
  exact pattern_20 (g14 E) (g26 E) (g28 E)
private theorem sat_1069 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .neg 4, .pos 1997] := by
  change (g7 E = true) → (g5 E = true) → (¬ (g1998 E = true)) → False
  exact pattern_9 (g5 E) (g7 E)
private theorem sat_1070 (E : Nat → Bool) : (valuation E).satisfies [.neg 1998, .neg 1997] := by
  change (g1999 E = true) → (g1998 E = true) → False
  exact pattern_18 (g1996 E) (g1997 E) (g1998 E)
private theorem sat_1071 (E : Nat → Bool) : (valuation E).satisfies [.neg 17, .neg 15, .pos 2001] := by
  change (g18 E = true) → (g16 E = true) → (¬ (g2002 E = true)) → False
  exact pattern_9 (g16 E) (g18 E)
private theorem sat_1072 (E : Nat → Bool) : (valuation E).satisfies [.neg 2002, .neg 2001] := by
  change (g2003 E = true) → (g2002 E = true) → False
  exact pattern_18 (g2000 E) (g2001 E) (g2002 E)
private theorem sat_1073 (E : Nat → Bool) : (valuation E).satisfies [.neg 2003, .neg 19] := by
  change (g2004 E = true) → (g20 E = true) → False
  exact pattern_19 (g10 E) (g20 E) (g22 E)
private theorem sat_1074 (E : Nat → Bool) : (valuation E).satisfies [.neg 2004, .neg 11] := by
  change (g2005 E = true) → (g12 E = true) → False
  exact pattern_20 (g12 E) (g24 E) (g27 E)
private theorem sat_1075 (E : Nat → Bool) : (valuation E).satisfies [.neg 2005, .neg 13] := by
  change (g2006 E = true) → (g14 E = true) → False
  exact pattern_20 (g14 E) (g26 E) (g29 E)
private theorem sat_1077 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 1, .pos 2007] := by
  change (g8 E = true) → (g2 E = true) → (¬ (g2008 E = true)) → False
  exact pattern_9 (g2 E) (g8 E)
private theorem sat_1078 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 4, .pos 2008] := by
  change (g8 E = true) → (g5 E = true) → (¬ (g2009 E = true)) → False
  exact pattern_9 (g5 E) (g8 E)
private theorem sat_1079 (E : Nat → Bool) : (valuation E).satisfies [.neg 2009, .neg 2008] := by
  change (g2010 E = true) → (g2009 E = true) → False
  exact pattern_18 (g2007 E) (g2008 E) (g2009 E)
private theorem sat_1080 (E : Nat → Bool) : (valuation E).satisfies [.neg 2009, .neg 2007] := by
  change (g2010 E = true) → (g2008 E = true) → False
  exact pattern_19 (g2007 E) (g2008 E) (g2009 E)
private theorem sat_1081 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 15, .pos 2012] := by
  change (g19 E = true) → (g16 E = true) → (¬ (g2013 E = true)) → False
  exact pattern_9 (g16 E) (g19 E)
private theorem sat_1082 (E : Nat → Bool) : (valuation E).satisfies [.neg 2013, .neg 2012] := by
  change (g2014 E = true) → (g2013 E = true) → False
  exact pattern_18 (g2011 E) (g2012 E) (g2013 E)
private theorem sat_1083 (E : Nat → Bool) : (valuation E).satisfies [.neg 2014, .neg 19] := by
  change (g2015 E = true) → (g20 E = true) → False
  exact pattern_19 (g10 E) (g20 E) (g23 E)
private theorem sat_1084 (E : Nat → Bool) : (valuation E).satisfies [.neg 2015, .neg 11] := by
  change (g2016 E = true) → (g12 E = true) → False
  exact pattern_20 (g12 E) (g24 E) (g28 E)
private theorem sat_1085 (E : Nat → Bool) : (valuation E).satisfies [.neg 2016, .neg 28] := by
  change (g2017 E = true) → (g29 E = true) → False
  exact pattern_18 (g13 E) (g25 E) (g29 E)
private theorem sat_1086 (E : Nat → Bool) : (valuation E).satisfies [.neg 2016, .neg 12] := by
  change (g2017 E = true) → (g13 E = true) → False
  exact pattern_20 (g13 E) (g25 E) (g29 E)
private theorem sat_1088 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .neg 5, .pos 2019] := by
  change (g7 E = true) → (g6 E = true) → (¬ (g2020 E = true)) → False
  exact pattern_9 (g6 E) (g7 E)
private theorem sat_1089 (E : Nat → Bool) : (valuation E).satisfies [.neg 2020, .neg 2019] := by
  change (g2021 E = true) → (g2020 E = true) → False
  exact pattern_18 (g2018 E) (g2019 E) (g2020 E)
private theorem sat_1090 (E : Nat → Bool) : (valuation E).satisfies [.neg 17, .neg 8, .pos 2022] := by
  change (g18 E = true) → (g9 E = true) → (¬ (g2023 E = true)) → False
  exact pattern_9 (g9 E) (g18 E)
private theorem sat_1091 (E : Nat → Bool) : (valuation E).satisfies [.neg 2024, .neg 2022] := by
  change (g2025 E = true) → (g2023 E = true) → False
  exact pattern_19 (g2022 E) (g2023 E) (g2024 E)
private theorem sat_1092 (E : Nat → Bool) : (valuation E).satisfies [.neg 2025, .neg 21] := by
  change (g2026 E = true) → (g22 E = true) → False
  exact pattern_18 (g10 E) (g21 E) (g22 E)
private theorem sat_1093 (E : Nat → Bool) : (valuation E).satisfies [.neg 2026, .neg 24] := by
  change (g2027 E = true) → (g25 E = true) → False
  exact pattern_18 (g11 E) (g24 E) (g25 E)
private theorem sat_1094 (E : Nat → Bool) : (valuation E).satisfies [.neg 2027, .neg 13] := by
  change (g2028 E = true) → (g14 E = true) → False
  exact pattern_20 (g14 E) (g28 E) (g29 E)
private theorem sat_1096 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .neg 2, .pos 2073] := by
  change (g7 E = true) → (g3 E = true) → (¬ (g2074 E = true)) → False
  exact pattern_9 (g3 E) (g7 E)
private theorem sat_1097 (E : Nat → Bool) : (valuation E).satisfies [.neg 2075, .neg 2073] := by
  change (g2076 E = true) → (g2074 E = true) → False
  exact pattern_19 (g2073 E) (g2074 E) (g2075 E)
private theorem sat_1098 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 8, .pos 2077] := by
  change (g13 E = true) → (g9 E = true) → (¬ (g2078 E = true)) → False
  exact pattern_9 (g9 E) (g13 E)
private theorem sat_1099 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 9, .pos 2078] := by
  change (g13 E = true) → (g10 E = true) → (¬ (g2079 E = true)) → False
  exact pattern_9 (g10 E) (g13 E)
private theorem sat_1100 (E : Nat → Bool) : (valuation E).satisfies [.neg 2079, .neg 2078] := by
  change (g2080 E = true) → (g2079 E = true) → False
  exact pattern_18 (g2077 E) (g2078 E) (g2079 E)
private theorem sat_1101 (E : Nat → Bool) : (valuation E).satisfies [.neg 2079, .neg 2077] := by
  change (g2080 E = true) → (g2078 E = true) → False
  exact pattern_19 (g2077 E) (g2078 E) (g2079 E)
private theorem sat_1102 (E : Nat → Bool) : (valuation E).satisfies [.neg 2080, .neg 15] := by
  change (g2081 E = true) → (g16 E = true) → False
  exact pattern_20 (g16 E) (g20 E) (g25 E)
private theorem sat_1103 (E : Nat → Bool) : (valuation E).satisfies [.neg 2081, .neg 20] := by
  change (g2082 E = true) → (g21 E = true) → False
  exact pattern_19 (g17 E) (g21 E) (g27 E)
private theorem sat_1104 (E : Nat → Bool) : (valuation E).satisfies [.neg 2082, .neg 28] := by
  change (g2083 E = true) → (g29 E = true) → False
  exact pattern_18 (g19 E) (g23 E) (g29 E)
private theorem sat_1105 (E : Nat → Bool) : (valuation E).satisfies [.neg 2082, .neg 18] := by
  change (g2083 E = true) → (g19 E = true) → False
  exact pattern_20 (g19 E) (g23 E) (g29 E)
private theorem sat_1107 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 2, .pos 2084] := by
  change (g8 E = true) → (g3 E = true) → (¬ (g2085 E = true)) → False
  exact pattern_9 (g3 E) (g8 E)
private theorem sat_1108 (E : Nat → Bool) : (valuation E).satisfies [.neg 2086, .neg 2084] := by
  change (g2087 E = true) → (g2085 E = true) → False
  exact pattern_19 (g2084 E) (g2085 E) (g2086 E)
private theorem sat_1109 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 8, .pos 2088] := by
  change (g14 E = true) → (g9 E = true) → (¬ (g2089 E = true)) → False
  exact pattern_9 (g9 E) (g14 E)
private theorem sat_1110 (E : Nat → Bool) : (valuation E).satisfies [.neg 2090, .neg 2088] := by
  change (g2091 E = true) → (g2089 E = true) → False
  exact pattern_19 (g2088 E) (g2089 E) (g2090 E)
private theorem sat_1111 (E : Nat → Bool) : (valuation E).satisfies [.neg 2091, .neg 25] := by
  change (g2092 E = true) → (g26 E = true) → False
  exact pattern_18 (g16 E) (g20 E) (g26 E)
private theorem sat_1112 (E : Nat → Bool) : (valuation E).satisfies [.neg 2091, .neg 19] := by
  change (g2092 E = true) → (g20 E = true) → False
  exact pattern_19 (g16 E) (g20 E) (g26 E)
private theorem sat_1113 (E : Nat → Bool) : (valuation E).satisfies [.neg 2092, .neg 27] := by
  change (g2093 E = true) → (g28 E = true) → False
  exact pattern_18 (g17 E) (g21 E) (g28 E)
private theorem sat_1114 (E : Nat → Bool) : (valuation E).satisfies [.neg 2092, .neg 20] := by
  change (g2093 E = true) → (g21 E = true) → False
  exact pattern_19 (g17 E) (g21 E) (g28 E)
private theorem sat_1115 (E : Nat → Bool) : (valuation E).satisfies [.neg 2093, .neg 21] := by
  change (g2094 E = true) → (g22 E = true) → False
  exact pattern_19 (g18 E) (g22 E) (g29 E)
private theorem sat_1117 (E : Nat → Bool) : (valuation E).satisfies [.neg 5, .neg 4, .pos 2096] := by
  change (g6 E = true) → (g5 E = true) → (¬ (g2097 E = true)) → False
  exact pattern_9 (g5 E) (g6 E)
private theorem sat_1118 (E : Nat → Bool) : (valuation E).satisfies [.neg 2097, .neg 2096] := by
  change (g2098 E = true) → (g2097 E = true) → False
  exact pattern_18 (g2095 E) (g2096 E) (g2097 E)
private theorem sat_1119 (E : Nat → Bool) : (valuation E).satisfies [.neg 11, .neg 10, .pos 2100] := by
  change (g12 E = true) → (g11 E = true) → (¬ (g2101 E = true)) → False
  exact pattern_9 (g11 E) (g12 E)
private theorem sat_1120 (E : Nat → Bool) : (valuation E).satisfies [.neg 2101, .neg 2100] := by
  change (g2102 E = true) → (g2101 E = true) → False
  exact pattern_18 (g2099 E) (g2100 E) (g2101 E)
private theorem sat_1121 (E : Nat → Bool) : (valuation E).satisfies [.neg 2102, .neg 19] := by
  change (g2103 E = true) → (g20 E = true) → False
  exact pattern_19 (g15 E) (g20 E) (g21 E)
private theorem sat_1122 (E : Nat → Bool) : (valuation E).satisfies [.neg 2103, .neg 17] := by
  change (g2104 E = true) → (g18 E = true) → False
  exact pattern_20 (g18 E) (g25 E) (g27 E)
private theorem sat_1123 (E : Nat → Bool) : (valuation E).satisfies [.neg 2104, .neg 18] := by
  change (g2105 E = true) → (g19 E = true) → False
  exact pattern_20 (g19 E) (g26 E) (g28 E)
private theorem sat_1125 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 2, .pos 2117] := by
  change (g8 E = true) → (g3 E = true) → (¬ (g2118 E = true)) → False
  exact pattern_9 (g3 E) (g8 E)
private theorem sat_1126 (E : Nat → Bool) : (valuation E).satisfies [.neg 2119, .neg 2117] := by
  change (g2120 E = true) → (g2118 E = true) → False
  exact pattern_19 (g2117 E) (g2118 E) (g2119 E)
private theorem sat_1127 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 8, .pos 2121] := by
  change (g14 E = true) → (g9 E = true) → (¬ (g2122 E = true)) → False
  exact pattern_9 (g9 E) (g14 E)
private theorem sat_1128 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 10, .pos 2122] := by
  change (g14 E = true) → (g11 E = true) → (¬ (g2123 E = true)) → False
  exact pattern_9 (g11 E) (g14 E)
private theorem sat_1129 (E : Nat → Bool) : (valuation E).satisfies [.neg 2123, .neg 2122] := by
  change (g2124 E = true) → (g2123 E = true) → False
  exact pattern_18 (g2121 E) (g2122 E) (g2123 E)
private theorem sat_1130 (E : Nat → Bool) : (valuation E).satisfies [.neg 2123, .neg 2121] := by
  change (g2124 E = true) → (g2122 E = true) → False
  exact pattern_19 (g2121 E) (g2122 E) (g2123 E)
private theorem sat_1131 (E : Nat → Bool) : (valuation E).satisfies [.neg 2124, .neg 19] := by
  change (g2125 E = true) → (g20 E = true) → False
  exact pattern_19 (g15 E) (g20 E) (g23 E)
private theorem sat_1132 (E : Nat → Bool) : (valuation E).satisfies [.neg 2124, .neg 14] := by
  change (g2125 E = true) → (g15 E = true) → False
  exact pattern_20 (g15 E) (g20 E) (g23 E)
private theorem sat_1133 (E : Nat → Bool) : (valuation E).satisfies [.neg 2125, .neg 27] := by
  change (g2126 E = true) → (g28 E = true) → False
  exact pattern_18 (g17 E) (g24 E) (g28 E)
private theorem sat_1134 (E : Nat → Bool) : (valuation E).satisfies [.neg 2125, .neg 23] := by
  change (g2126 E = true) → (g24 E = true) → False
  exact pattern_19 (g17 E) (g24 E) (g28 E)
private theorem sat_1135 (E : Nat → Bool) : (valuation E).satisfies [.neg 2125, .neg 16] := by
  change (g2126 E = true) → (g17 E = true) → False
  exact pattern_20 (g17 E) (g24 E) (g28 E)
private theorem sat_1136 (E : Nat → Bool) : (valuation E).satisfies [.neg 2126, .neg 17] := by
  change (g2127 E = true) → (g18 E = true) → False
  exact pattern_20 (g18 E) (g25 E) (g29 E)
private theorem sat_1138 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .neg 2, .pos 2128] := by
  change (g7 E = true) → (g3 E = true) → (¬ (g2129 E = true)) → False
  exact pattern_9 (g3 E) (g7 E)
private theorem sat_1139 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .neg 5, .pos 2129] := by
  change (g7 E = true) → (g6 E = true) → (¬ (g2130 E = true)) → False
  exact pattern_9 (g6 E) (g7 E)
private theorem sat_1140 (E : Nat → Bool) : (valuation E).satisfies [.neg 2130, .neg 2129] := by
  change (g2131 E = true) → (g2130 E = true) → False
  exact pattern_18 (g2128 E) (g2129 E) (g2130 E)
private theorem sat_1141 (E : Nat → Bool) : (valuation E).satisfies [.neg 2130, .neg 2128] := by
  change (g2131 E = true) → (g2129 E = true) → False
  exact pattern_19 (g2128 E) (g2129 E) (g2130 E)
private theorem sat_1142 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 8, .pos 2132] := by
  change (g13 E = true) → (g9 E = true) → (¬ (g2133 E = true)) → False
  exact pattern_9 (g9 E) (g13 E)
private theorem sat_1143 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 11, .pos 2133] := by
  change (g13 E = true) → (g12 E = true) → (¬ (g2134 E = true)) → False
  exact pattern_9 (g12 E) (g13 E)
private theorem sat_1144 (E : Nat → Bool) : (valuation E).satisfies [.neg 2134, .neg 2133] := by
  change (g2135 E = true) → (g2134 E = true) → False
  exact pattern_18 (g2132 E) (g2133 E) (g2134 E)
private theorem sat_1145 (E : Nat → Bool) : (valuation E).satisfies [.neg 2134, .neg 2132] := by
  change (g2135 E = true) → (g2133 E = true) → False
  exact pattern_19 (g2132 E) (g2133 E) (g2134 E)
private theorem sat_1146 (E : Nat → Bool) : (valuation E).satisfies [.neg 2135, .neg 21] := by
  change (g2136 E = true) → (g22 E = true) → False
  exact pattern_18 (g15 E) (g21 E) (g22 E)
private theorem sat_1147 (E : Nat → Bool) : (valuation E).satisfies [.neg 2135, .neg 20] := by
  change (g2136 E = true) → (g21 E = true) → False
  exact pattern_19 (g15 E) (g21 E) (g22 E)
private theorem sat_1148 (E : Nat → Bool) : (valuation E).satisfies [.neg 2135, .neg 14] := by
  change (g2136 E = true) → (g15 E = true) → False
  exact pattern_20 (g15 E) (g21 E) (g22 E)
private theorem sat_1149 (E : Nat → Bool) : (valuation E).satisfies [.neg 2136, .neg 15] := by
  change (g2137 E = true) → (g16 E = true) → False
  exact pattern_20 (g16 E) (g24 E) (g25 E)
private theorem sat_1150 (E : Nat → Bool) : (valuation E).satisfies [.neg 2137, .neg 28] := by
  change (g2138 E = true) → (g29 E = true) → False
  exact pattern_18 (g19 E) (g28 E) (g29 E)
private theorem sat_1151 (E : Nat → Bool) : (valuation E).satisfies [.neg 2137, .neg 18] := by
  change (g2138 E = true) → (g19 E = true) → False
  exact pattern_20 (g19 E) (g28 E) (g29 E)
private theorem sat_1153 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 2, .pos 2139] := by
  change (g8 E = true) → (g3 E = true) → (¬ (g2140 E = true)) → False
  exact pattern_9 (g3 E) (g8 E)
private theorem sat_1154 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 5, .pos 2140] := by
  change (g8 E = true) → (g6 E = true) → (¬ (g2141 E = true)) → False
  exact pattern_9 (g6 E) (g8 E)
private theorem sat_1155 (E : Nat → Bool) : (valuation E).satisfies [.neg 2141, .neg 2140] := by
  change (g2142 E = true) → (g2141 E = true) → False
  exact pattern_18 (g2139 E) (g2140 E) (g2141 E)
private theorem sat_1156 (E : Nat → Bool) : (valuation E).satisfies [.neg 2141, .neg 2139] := by
  change (g2142 E = true) → (g2140 E = true) → False
  exact pattern_19 (g2139 E) (g2140 E) (g2141 E)
private theorem sat_1157 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 8, .pos 2143] := by
  change (g14 E = true) → (g9 E = true) → (¬ (g2144 E = true)) → False
  exact pattern_9 (g9 E) (g14 E)
private theorem sat_1158 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 11, .pos 2144] := by
  change (g14 E = true) → (g12 E = true) → (¬ (g2145 E = true)) → False
  exact pattern_9 (g12 E) (g14 E)
private theorem sat_1159 (E : Nat → Bool) : (valuation E).satisfies [.neg 2145, .neg 2144] := by
  change (g2146 E = true) → (g2145 E = true) → False
  exact pattern_18 (g2143 E) (g2144 E) (g2145 E)
private theorem sat_1160 (E : Nat → Bool) : (valuation E).satisfies [.neg 2145, .neg 2143] := by
  change (g2146 E = true) → (g2144 E = true) → False
  exact pattern_19 (g2143 E) (g2144 E) (g2145 E)
private theorem sat_1161 (E : Nat → Bool) : (valuation E).satisfies [.neg 2146, .neg 22] := by
  change (g2147 E = true) → (g23 E = true) → False
  exact pattern_18 (g15 E) (g21 E) (g23 E)
private theorem sat_1162 (E : Nat → Bool) : (valuation E).satisfies [.neg 2146, .neg 20] := by
  change (g2147 E = true) → (g21 E = true) → False
  exact pattern_19 (g15 E) (g21 E) (g23 E)
private theorem sat_1163 (E : Nat → Bool) : (valuation E).satisfies [.neg 2146, .neg 14] := by
  change (g2147 E = true) → (g15 E = true) → False
  exact pattern_20 (g15 E) (g21 E) (g23 E)
private theorem sat_1164 (E : Nat → Bool) : (valuation E).satisfies [.neg 2147, .neg 25] := by
  change (g2148 E = true) → (g26 E = true) → False
  exact pattern_18 (g16 E) (g24 E) (g26 E)
private theorem sat_1165 (E : Nat → Bool) : (valuation E).satisfies [.neg 2147, .neg 23] := by
  change (g2148 E = true) → (g24 E = true) → False
  exact pattern_19 (g16 E) (g24 E) (g26 E)
private theorem sat_1166 (E : Nat → Bool) : (valuation E).satisfies [.neg 2147, .neg 15] := by
  change (g2148 E = true) → (g16 E = true) → False
  exact pattern_20 (g16 E) (g24 E) (g26 E)
private theorem sat_1167 (E : Nat → Bool) : (valuation E).satisfies [.neg 2148, .neg 28] := by
  change (g2149 E = true) → (g29 E = true) → False
  exact pattern_18 (g18 E) (g27 E) (g29 E)
private theorem sat_1168 (E : Nat → Bool) : (valuation E).satisfies [.neg 2148, .neg 17] := by
  change (g2149 E = true) → (g18 E = true) → False
  exact pattern_20 (g18 E) (g27 E) (g29 E)
private theorem sat_1170 (E : Nat → Bool) : (valuation E).satisfies [.neg 2150, .pos 2] := by
  change (g2151 E = true) → (¬ (g3 E = true)) → False
  exact pattern_1 (g3 E) (g8 E)
private theorem sat_1171 (E : Nat → Bool) : (valuation E).satisfies [.neg 2150, .pos 7] := by
  change (g2151 E = true) → (¬ (g8 E = true)) → False
  exact pattern_2 (g3 E) (g8 E)
private theorem sat_1172 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 2, .pos 2150] := by
  change (g8 E = true) → (g3 E = true) → (¬ (g2151 E = true)) → False
  exact pattern_9 (g3 E) (g8 E)
private theorem sat_1173 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 6, .pos 2151] := by
  change (g8 E = true) → (g7 E = true) → (¬ (g2152 E = true)) → False
  exact pattern_9 (g7 E) (g8 E)
private theorem sat_1174 (E : Nat → Bool) : (valuation E).satisfies [.neg 2152, .neg 2151] := by
  change (g2153 E = true) → (g2152 E = true) → False
  exact pattern_18 (g2150 E) (g2151 E) (g2152 E)
private theorem sat_1175 (E : Nat → Bool) : (valuation E).satisfies [.neg 2152, .neg 2150] := by
  change (g2153 E = true) → (g2151 E = true) → False
  exact pattern_19 (g2150 E) (g2151 E) (g2152 E)
private theorem sat_1176 (E : Nat → Bool) : (valuation E).satisfies [.neg 2153, .pos 8] := by
  change (g2154 E = true) → (¬ (g9 E = true)) → False
  exact pattern_1 (g9 E) (g13 E)
private theorem sat_1177 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 8, .pos 2153] := by
  change (g13 E = true) → (g9 E = true) → (¬ (g2154 E = true)) → False
  exact pattern_9 (g9 E) (g13 E)
private theorem sat_1178 (E : Nat → Bool) : (valuation E).satisfies [.neg 2154, .pos 13] := by
  change (g2155 E = true) → (¬ (g14 E = true)) → False
  exact pattern_2 (g9 E) (g14 E)
private theorem sat_1179 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 8, .pos 2154] := by
  change (g14 E = true) → (g9 E = true) → (¬ (g2155 E = true)) → False
  exact pattern_9 (g9 E) (g14 E)
private theorem sat_1180 (E : Nat → Bool) : (valuation E).satisfies [.neg 2155, .pos 12] := by
  change (g2156 E = true) → (¬ (g13 E = true)) → False
  exact pattern_1 (g13 E) (g14 E)
private theorem sat_1181 (E : Nat → Bool) : (valuation E).satisfies [.neg 2155, .pos 13] := by
  change (g2156 E = true) → (¬ (g14 E = true)) → False
  exact pattern_2 (g13 E) (g14 E)
private theorem sat_1182 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 12, .pos 2155] := by
  change (g14 E = true) → (g13 E = true) → (¬ (g2156 E = true)) → False
  exact pattern_9 (g13 E) (g14 E)
private theorem sat_1183 (E : Nat → Bool) : (valuation E).satisfies [.neg 2156, .neg 2155] := by
  change (g2157 E = true) → (g2156 E = true) → False
  exact pattern_18 (g2154 E) (g2155 E) (g2156 E)
private theorem sat_1184 (E : Nat → Bool) : (valuation E).satisfies [.neg 2156, .neg 2154] := by
  change (g2157 E = true) → (g2155 E = true) → False
  exact pattern_19 (g2154 E) (g2155 E) (g2156 E)
private theorem sat_1185 (E : Nat → Bool) : (valuation E).satisfies [.neg 2156, .neg 2153] := by
  change (g2157 E = true) → (g2154 E = true) → False
  exact pattern_20 (g2154 E) (g2155 E) (g2156 E)
private theorem sat_1186 (E : Nat → Bool) : (valuation E).satisfies [.pos 2153, .pos 2154, .pos 2155, .pos 2156] := by
  change (¬ (g2154 E = true)) → (¬ (g2155 E = true)) → (¬ (g2156 E = true)) → (¬ (g2157 E = true)) → False
  exact pattern_21 (g2154 E) (g2155 E) (g2156 E)
private theorem sat_1187 (E : Nat → Bool) : (valuation E).satisfies [.neg 2157, .neg 22] := by
  change (g2158 E = true) → (g23 E = true) → False
  exact pattern_18 (g15 E) (g22 E) (g23 E)
private theorem sat_1188 (E : Nat → Bool) : (valuation E).satisfies [.neg 2157, .neg 21] := by
  change (g2158 E = true) → (g22 E = true) → False
  exact pattern_19 (g15 E) (g22 E) (g23 E)
private theorem sat_1189 (E : Nat → Bool) : (valuation E).satisfies [.neg 2157, .neg 14] := by
  change (g2158 E = true) → (g15 E = true) → False
  exact pattern_20 (g15 E) (g22 E) (g23 E)
private theorem sat_1190 (E : Nat → Bool) : (valuation E).satisfies [.pos 14, .pos 21, .pos 22, .pos 2157] := by
  change (¬ (g15 E = true)) → (¬ (g22 E = true)) → (¬ (g23 E = true)) → (¬ (g2158 E = true)) → False
  exact pattern_21 (g15 E) (g22 E) (g23 E)
private theorem sat_1191 (E : Nat → Bool) : (valuation E).satisfies [.neg 2158, .neg 25] := by
  change (g2159 E = true) → (g26 E = true) → False
  exact pattern_18 (g16 E) (g25 E) (g26 E)
private theorem sat_1192 (E : Nat → Bool) : (valuation E).satisfies [.neg 2158, .neg 24] := by
  change (g2159 E = true) → (g25 E = true) → False
  exact pattern_19 (g16 E) (g25 E) (g26 E)
private theorem sat_1193 (E : Nat → Bool) : (valuation E).satisfies [.neg 2158, .neg 15] := by
  change (g2159 E = true) → (g16 E = true) → False
  exact pattern_20 (g16 E) (g25 E) (g26 E)
private theorem sat_1194 (E : Nat → Bool) : (valuation E).satisfies [.neg 2159, .neg 27] := by
  change (g2160 E = true) → (g28 E = true) → False
  exact pattern_18 (g17 E) (g27 E) (g28 E)
private theorem sat_1195 (E : Nat → Bool) : (valuation E).satisfies [.neg 2159, .neg 26] := by
  change (g2160 E = true) → (g27 E = true) → False
  exact pattern_19 (g17 E) (g27 E) (g28 E)
private theorem sat_1196 (E : Nat → Bool) : (valuation E).satisfies [.neg 2159, .neg 16] := by
  change (g2160 E = true) → (g17 E = true) → False
  exact pattern_20 (g17 E) (g27 E) (g28 E)
private theorem sat_1198 (E : Nat → Bool) : (valuation E).satisfies [.neg 2286, .pos 5] := by
  change (g2287 E = true) → (¬ (g6 E = true)) → False
  exact pattern_1 (g6 E) (g7 E)
private theorem sat_1199 (E : Nat → Bool) : (valuation E).satisfies [.neg 2286, .pos 6] := by
  change (g2287 E = true) → (¬ (g7 E = true)) → False
  exact pattern_2 (g6 E) (g7 E)
private theorem sat_1200 (E : Nat → Bool) : (valuation E).satisfies [.neg 6, .neg 5, .pos 2286] := by
  change (g7 E = true) → (g6 E = true) → (¬ (g2287 E = true)) → False
  exact pattern_9 (g6 E) (g7 E)
private theorem sat_1201 (E : Nat → Bool) : (valuation E).satisfies [.neg 2287, .pos 5] := by
  change (g2288 E = true) → (¬ (g6 E = true)) → False
  exact pattern_1 (g6 E) (g8 E)
private theorem sat_1202 (E : Nat → Bool) : (valuation E).satisfies [.neg 2287, .pos 7] := by
  change (g2288 E = true) → (¬ (g8 E = true)) → False
  exact pattern_2 (g6 E) (g8 E)
private theorem sat_1203 (E : Nat → Bool) : (valuation E).satisfies [.neg 2288, .pos 6] := by
  change (g2289 E = true) → (¬ (g7 E = true)) → False
  exact pattern_1 (g7 E) (g8 E)
private theorem sat_1204 (E : Nat → Bool) : (valuation E).satisfies [.neg 2288, .pos 7] := by
  change (g2289 E = true) → (¬ (g8 E = true)) → False
  exact pattern_2 (g7 E) (g8 E)
private theorem sat_1205 (E : Nat → Bool) : (valuation E).satisfies [.neg 7, .neg 6, .pos 2288] := by
  change (g8 E = true) → (g7 E = true) → (¬ (g2289 E = true)) → False
  exact pattern_9 (g7 E) (g8 E)
private theorem sat_1206 (E : Nat → Bool) : (valuation E).satisfies [.neg 2289, .neg 2288] := by
  change (g2290 E = true) → (g2289 E = true) → False
  exact pattern_18 (g2287 E) (g2288 E) (g2289 E)
private theorem sat_1207 (E : Nat → Bool) : (valuation E).satisfies [.neg 2289, .neg 2286] := by
  change (g2290 E = true) → (g2287 E = true) → False
  exact pattern_20 (g2287 E) (g2288 E) (g2289 E)
private theorem sat_1208 (E : Nat → Bool) : (valuation E).satisfies [.pos 2286, .pos 2287, .pos 2288, .pos 2289] := by
  change (¬ (g2287 E = true)) → (¬ (g2288 E = true)) → (¬ (g2289 E = true)) → (¬ (g2290 E = true)) → False
  exact pattern_21 (g2287 E) (g2288 E) (g2289 E)
private theorem sat_1209 (E : Nat → Bool) : (valuation E).satisfies [.neg 2290, .pos 11] := by
  change (g2291 E = true) → (¬ (g12 E = true)) → False
  exact pattern_1 (g12 E) (g13 E)
private theorem sat_1210 (E : Nat → Bool) : (valuation E).satisfies [.neg 2290, .pos 12] := by
  change (g2291 E = true) → (¬ (g13 E = true)) → False
  exact pattern_2 (g12 E) (g13 E)
private theorem sat_1211 (E : Nat → Bool) : (valuation E).satisfies [.neg 12, .neg 11, .pos 2290] := by
  change (g13 E = true) → (g12 E = true) → (¬ (g2291 E = true)) → False
  exact pattern_9 (g12 E) (g13 E)
private theorem sat_1212 (E : Nat → Bool) : (valuation E).satisfies [.neg 2291, .pos 11] := by
  change (g2292 E = true) → (¬ (g12 E = true)) → False
  exact pattern_1 (g12 E) (g14 E)
private theorem sat_1213 (E : Nat → Bool) : (valuation E).satisfies [.neg 2291, .pos 13] := by
  change (g2292 E = true) → (¬ (g14 E = true)) → False
  exact pattern_2 (g12 E) (g14 E)
private theorem sat_1214 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 11, .pos 2291] := by
  change (g14 E = true) → (g12 E = true) → (¬ (g2292 E = true)) → False
  exact pattern_9 (g12 E) (g14 E)
private theorem sat_1215 (E : Nat → Bool) : (valuation E).satisfies [.neg 2292, .pos 12] := by
  change (g2293 E = true) → (¬ (g13 E = true)) → False
  exact pattern_1 (g13 E) (g14 E)
private theorem sat_1216 (E : Nat → Bool) : (valuation E).satisfies [.neg 2292, .pos 13] := by
  change (g2293 E = true) → (¬ (g14 E = true)) → False
  exact pattern_2 (g13 E) (g14 E)
private theorem sat_1217 (E : Nat → Bool) : (valuation E).satisfies [.neg 13, .neg 12, .pos 2292] := by
  change (g14 E = true) → (g13 E = true) → (¬ (g2293 E = true)) → False
  exact pattern_9 (g13 E) (g14 E)
private theorem sat_1218 (E : Nat → Bool) : (valuation E).satisfies [.neg 2293, .neg 2292] := by
  change (g2294 E = true) → (g2293 E = true) → False
  exact pattern_18 (g2291 E) (g2292 E) (g2293 E)
private theorem sat_1219 (E : Nat → Bool) : (valuation E).satisfies [.neg 2293, .neg 2291] := by
  change (g2294 E = true) → (g2292 E = true) → False
  exact pattern_19 (g2291 E) (g2292 E) (g2293 E)
private theorem sat_1220 (E : Nat → Bool) : (valuation E).satisfies [.pos 2290, .pos 2291, .pos 2292, .pos 2293] := by
  change (¬ (g2291 E = true)) → (¬ (g2292 E = true)) → (¬ (g2293 E = true)) → (¬ (g2294 E = true)) → False
  exact pattern_21 (g2291 E) (g2292 E) (g2293 E)
private theorem sat_1221 (E : Nat → Bool) : (valuation E).satisfies [.neg 2294, .pos 16] := by
  change (g2295 E = true) → (¬ (g17 E = true)) → False
  exact pattern_1 (g17 E) (g18 E)
private theorem sat_1222 (E : Nat → Bool) : (valuation E).satisfies [.neg 2294, .pos 17] := by
  change (g2295 E = true) → (¬ (g18 E = true)) → False
  exact pattern_2 (g17 E) (g18 E)
private theorem sat_1223 (E : Nat → Bool) : (valuation E).satisfies [.neg 17, .neg 16, .pos 2294] := by
  change (g18 E = true) → (g17 E = true) → (¬ (g2295 E = true)) → False
  exact pattern_9 (g17 E) (g18 E)
private theorem sat_1224 (E : Nat → Bool) : (valuation E).satisfies [.neg 2295, .pos 16] := by
  change (g2296 E = true) → (¬ (g17 E = true)) → False
  exact pattern_1 (g17 E) (g19 E)
private theorem sat_1225 (E : Nat → Bool) : (valuation E).satisfies [.neg 2295, .pos 18] := by
  change (g2296 E = true) → (¬ (g19 E = true)) → False
  exact pattern_2 (g17 E) (g19 E)
private theorem sat_1226 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 16, .pos 2295] := by
  change (g19 E = true) → (g17 E = true) → (¬ (g2296 E = true)) → False
  exact pattern_9 (g17 E) (g19 E)
private theorem sat_1227 (E : Nat → Bool) : (valuation E).satisfies [.neg 2296, .pos 17] := by
  change (g2297 E = true) → (¬ (g18 E = true)) → False
  exact pattern_1 (g18 E) (g19 E)
private theorem sat_1228 (E : Nat → Bool) : (valuation E).satisfies [.neg 2296, .pos 18] := by
  change (g2297 E = true) → (¬ (g19 E = true)) → False
  exact pattern_2 (g18 E) (g19 E)
private theorem sat_1229 (E : Nat → Bool) : (valuation E).satisfies [.neg 18, .neg 17, .pos 2296] := by
  change (g19 E = true) → (g18 E = true) → (¬ (g2297 E = true)) → False
  exact pattern_9 (g18 E) (g19 E)
private theorem sat_1230 (E : Nat → Bool) : (valuation E).satisfies [.neg 2297, .neg 2296] := by
  change (g2298 E = true) → (g2297 E = true) → False
  exact pattern_18 (g2295 E) (g2296 E) (g2297 E)
private theorem sat_1231 (E : Nat → Bool) : (valuation E).satisfies [.neg 2297, .neg 2295] := by
  change (g2298 E = true) → (g2296 E = true) → False
  exact pattern_19 (g2295 E) (g2296 E) (g2297 E)
private theorem sat_1232 (E : Nat → Bool) : (valuation E).satisfies [.neg 2297, .neg 2294] := by
  change (g2298 E = true) → (g2295 E = true) → False
  exact pattern_20 (g2295 E) (g2296 E) (g2297 E)
private theorem sat_1233 (E : Nat → Bool) : (valuation E).satisfies [.pos 2294, .pos 2295, .pos 2296, .pos 2297] := by
  change (¬ (g2295 E = true)) → (¬ (g2296 E = true)) → (¬ (g2297 E = true)) → (¬ (g2298 E = true)) → False
  exact pattern_21 (g2295 E) (g2296 E) (g2297 E)
private theorem sat_1234 (E : Nat → Bool) : (valuation E).satisfies [.neg 2298, .neg 22] := by
  change (g2299 E = true) → (g23 E = true) → False
  exact pattern_18 (g21 E) (g22 E) (g23 E)
private theorem sat_1235 (E : Nat → Bool) : (valuation E).satisfies [.neg 2298, .neg 21] := by
  change (g2299 E = true) → (g22 E = true) → False
  exact pattern_19 (g21 E) (g22 E) (g23 E)
private theorem sat_1236 (E : Nat → Bool) : (valuation E).satisfies [.neg 2298, .neg 20] := by
  change (g2299 E = true) → (g21 E = true) → False
  exact pattern_20 (g21 E) (g22 E) (g23 E)
private theorem sat_1237 (E : Nat → Bool) : (valuation E).satisfies [.neg 2299, .neg 25] := by
  change (g2300 E = true) → (g26 E = true) → False
  exact pattern_18 (g24 E) (g25 E) (g26 E)
private theorem sat_1238 (E : Nat → Bool) : (valuation E).satisfies [.neg 2299, .neg 24] := by
  change (g2300 E = true) → (g25 E = true) → False
  exact pattern_19 (g24 E) (g25 E) (g26 E)
private theorem sat_1239 (E : Nat → Bool) : (valuation E).satisfies [.neg 2299, .neg 23] := by
  change (g2300 E = true) → (g24 E = true) → False
  exact pattern_20 (g24 E) (g25 E) (g26 E)
private theorem sat_1240 (E : Nat → Bool) : (valuation E).satisfies [.pos 23, .pos 24, .pos 25, .pos 2299] := by
  change (¬ (g24 E = true)) → (¬ (g25 E = true)) → (¬ (g26 E = true)) → (¬ (g2300 E = true)) → False
  exact pattern_21 (g24 E) (g25 E) (g26 E)
theorem contradiction_of_semantic_roots (E : Nat → Bool)
    (h_29 : (valuation E).satisfies [.neg 63])
    (h_60 : (valuation E).satisfies [.neg 105])
    (h_90 : (valuation E).satisfies [.neg 147])
    (h_126 : (valuation E).satisfies [.neg 189])
    (h_166 : (valuation E).satisfies [.neg 231])
    (h_194 : (valuation E).satisfies [.neg 273])
    (h_746 : (valuation E).satisfies [.neg 803])
    (h_747 : (valuation E).satisfies [.neg 1225, .pos 803])
    (h_748 : (valuation E).satisfies [.neg 1227, .pos 805])
    (h_749 : (valuation E).satisfies [.neg 1647, .pos 1225])
    (h_756 : (valuation E).satisfies [.pos 1686])
    (h_764 : (valuation E).satisfies [.pos 1692])
    (h_772 : (valuation E).satisfies [.pos 1698])
    (h_781 : (valuation E).satisfies [.pos 1704])
    (h_800 : (valuation E).satisfies [.pos 1705, .pos 1706, .pos 1707, .pos 1708, .pos 1709])
    (h_817 : (valuation E).satisfies [.pos 1713, .pos 1714, .pos 1715, .pos 1716, .pos 1717])
    (h_833 : (valuation E).satisfies [.pos 1721, .pos 1722, .pos 1723, .pos 1724, .pos 1725])
    (h_844 : (valuation E).satisfies [.pos 1729, .pos 1730, .pos 1731, .pos 1732, .pos 1733])
    (h_858 : (valuation E).satisfies [.pos 1737, .pos 1738, .pos 1739, .pos 1740, .pos 1741])
    (h_868 : (valuation E).satisfies [.pos 1745, .pos 1746, .pos 1747, .pos 1748, .pos 1749])
    (h_883 : (valuation E).satisfies [.pos 1753, .pos 1754, .pos 1755, .pos 1756, .pos 1757])
    (h_897 : (valuation E).satisfies [.pos 1761, .pos 1762, .pos 1763, .pos 1764, .pos 1765])
    (h_915 : (valuation E).satisfies [.pos 1769, .pos 1770, .pos 1771, .pos 1772, .pos 1773])
    (h_931 : (valuation E).satisfies [.pos 1777, .pos 1778, .pos 1779, .pos 1780, .pos 1781])
    (h_947 : (valuation E).satisfies [.pos 1785, .pos 1786, .pos 1787, .pos 1788, .pos 1789])
    (h_955 : (valuation E).satisfies [.pos 1837, .pos 1841, .pos 1842, .pos 1843, .pos 1844])
    (h_963 : (valuation E).satisfies [.pos 1848, .pos 1852, .pos 1853, .pos 1854, .pos 1855])
    (h_980 : (valuation E).satisfies [.pos 1859, .pos 1863, .pos 1864, .pos 1865, .pos 1866])
    (h_993 : (valuation E).satisfies [.pos 1903, .pos 1904, .pos 1905, .pos 1906, .pos 1907])
    (h_1009 : (valuation E).satisfies [.pos 1911, .pos 1912, .pos 1913, .pos 1914, .pos 1915])
    (h_1024 : (valuation E).satisfies [.pos 1919, .pos 1920, .pos 1921, .pos 1922, .pos 1923])
    (h_1043 : (valuation E).satisfies [.pos 1927, .pos 1928, .pos 1929, .pos 1930, .pos 1931])
    (h_1060 : (valuation E).satisfies [.pos 1935, .pos 1936, .pos 1937, .pos 1938, .pos 1939])
    (h_1068 : (valuation E).satisfies [.pos 1987, .pos 1991, .pos 1992, .pos 1993, .pos 1994])
    (h_1076 : (valuation E).satisfies [.pos 1998, .pos 2002, .pos 2003, .pos 2004, .pos 2005])
    (h_1087 : (valuation E).satisfies [.pos 2009, .pos 2013, .pos 2014, .pos 2015, .pos 2016])
    (h_1095 : (valuation E).satisfies [.pos 2020, .pos 2024, .pos 2025, .pos 2026, .pos 2027])
    (h_1106 : (valuation E).satisfies [.pos 2075, .pos 2079, .pos 2080, .pos 2081, .pos 2082])
    (h_1116 : (valuation E).satisfies [.pos 2086, .pos 2090, .pos 2091, .pos 2092, .pos 2093])
    (h_1124 : (valuation E).satisfies [.pos 2097, .pos 2101, .pos 2102, .pos 2103, .pos 2104])
    (h_1137 : (valuation E).satisfies [.pos 2119, .pos 2123, .pos 2124, .pos 2125, .pos 2126])
    (h_1152 : (valuation E).satisfies [.pos 2130, .pos 2134, .pos 2135, .pos 2136, .pos 2137])
    (h_1169 : (valuation E).satisfies [.pos 2141, .pos 2145, .pos 2146, .pos 2147, .pos 2148])
    (h_1197 : (valuation E).satisfies [.pos 2152, .pos 2156, .pos 2157, .pos 2158, .pos 2159])
    (h_1241 : (valuation E).satisfies [.pos 2289, .pos 2293, .pos 2297, .pos 2298, .pos 2299])
    : False := by
  exact pendant_three_rup (valuation E) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_0 E)) (fmla_one _ _ (sat_1 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_2 E)) (fmla_one _ _ (sat_3 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_4 E)) (fmla_one _ _ (sat_5 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_6 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_7 E)) (fmla_one _ _ (sat_8 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_9 E)) (fmla_one _ _ (sat_10 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_11 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_12 E)) (fmla_one _ _ (sat_13 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_14 E)) (fmla_one _ _ (sat_15 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_16 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_17 E)) (fmla_one _ _ (sat_18 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_19 E)) (fmla_one _ _ (sat_20 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_21 E)) (fmla_one _ _ (sat_22 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_23 E)) (fmla_one _ _ (sat_24 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_25 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_26 E)) (fmla_one _ _ (sat_27 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_28 E)) (fmla_one _ _ h_29)) (fmla_and _ _ _ (fmla_one _ _ (sat_30 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_31 E)) (fmla_one _ _ (sat_32 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_33 E)) (fmla_one _ _ (sat_34 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_35 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_36 E)) (fmla_one _ _ (sat_37 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_38 E)) (fmla_one _ _ (sat_39 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_40 E)) (fmla_one _ _ (sat_41 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_42 E)) (fmla_one _ _ (sat_43 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_44 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_45 E)) (fmla_one _ _ (sat_46 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_47 E)) (fmla_one _ _ (sat_48 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_49 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_50 E)) (fmla_one _ _ (sat_51 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_52 E)) (fmla_one _ _ (sat_53 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_54 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_55 E)) (fmla_one _ _ (sat_56 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_57 E)) (fmla_one _ _ (sat_58 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_59 E)) (fmla_and _ _ _ (fmla_one _ _ h_60) (fmla_one _ _ (sat_61 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_62 E)) (fmla_one _ _ (sat_63 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_64 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_65 E)) (fmla_one _ _ (sat_66 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_67 E)) (fmla_one _ _ (sat_68 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_69 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_70 E)) (fmla_one _ _ (sat_71 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_72 E)) (fmla_one _ _ (sat_73 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_74 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_75 E)) (fmla_one _ _ (sat_76 E))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_77 E)) (fmla_one _ _ (sat_78 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_79 E)) (fmla_one _ _ (sat_80 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_81 E)) (fmla_one _ _ (sat_82 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_83 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_84 E)) (fmla_one _ _ (sat_85 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_86 E)) (fmla_one _ _ (sat_87 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_88 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_89 E)) (fmla_one _ _ h_90)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_91 E)) (fmla_one _ _ (sat_92 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_93 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_94 E)) (fmla_one _ _ (sat_95 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_96 E)) (fmla_one _ _ (sat_97 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_98 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_99 E)) (fmla_one _ _ (sat_100 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_101 E)) (fmla_one _ _ (sat_102 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_103 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_104 E)) (fmla_one _ _ (sat_105 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_106 E)) (fmla_one _ _ (sat_107 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_108 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_109 E)) (fmla_one _ _ (sat_110 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_111 E)) (fmla_one _ _ (sat_112 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_113 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_114 E)) (fmla_one _ _ (sat_115 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_116 E)) (fmla_one _ _ (sat_117 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_118 E)) (fmla_one _ _ (sat_119 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_120 E)) (fmla_one _ _ (sat_121 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_122 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_123 E)) (fmla_one _ _ (sat_124 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_125 E)) (fmla_one _ _ h_126)) (fmla_and _ _ _ (fmla_one _ _ (sat_127 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_128 E)) (fmla_one _ _ (sat_129 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_130 E)) (fmla_one _ _ (sat_131 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_132 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_133 E)) (fmla_one _ _ (sat_134 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_135 E)) (fmla_one _ _ (sat_136 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_137 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_138 E)) (fmla_one _ _ (sat_139 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_140 E)) (fmla_one _ _ (sat_141 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_142 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_143 E)) (fmla_one _ _ (sat_144 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_145 E)) (fmla_one _ _ (sat_146 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_147 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_148 E)) (fmla_one _ _ (sat_149 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_150 E)) (fmla_one _ _ (sat_151 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_152 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_153 E)) (fmla_one _ _ (sat_154 E)))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_155 E)) (fmla_one _ _ (sat_156 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_157 E)) (fmla_one _ _ (sat_158 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_159 E)) (fmla_one _ _ (sat_160 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_161 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_162 E)) (fmla_one _ _ (sat_163 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_164 E)) (fmla_one _ _ (sat_165 E))) (fmla_and _ _ _ (fmla_one _ _ h_166) (fmla_and _ _ _ (fmla_one _ _ (sat_167 E)) (fmla_one _ _ (sat_168 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_169 E)) (fmla_one _ _ (sat_170 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_171 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_172 E)) (fmla_one _ _ (sat_173 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_174 E)) (fmla_one _ _ (sat_175 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_176 E)) (fmla_one _ _ (sat_177 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_178 E)) (fmla_one _ _ (sat_179 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_180 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_181 E)) (fmla_one _ _ (sat_182 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_183 E)) (fmla_one _ _ (sat_184 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_185 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_186 E)) (fmla_one _ _ (sat_187 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_188 E)) (fmla_one _ _ (sat_189 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_190 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_191 E)) (fmla_one _ _ (sat_192 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_193 E)) (fmla_one _ _ h_194)) (fmla_and _ _ _ (fmla_one _ _ (sat_195 E)) (fmla_one _ _ (sat_196 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_197 E)) (fmla_one _ _ (sat_198 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_199 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_200 E)) (fmla_one _ _ (sat_201 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_202 E)) (fmla_one _ _ (sat_203 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_204 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_205 E)) (fmla_one _ _ (sat_206 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_207 E)) (fmla_one _ _ (sat_208 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_209 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_210 E)) (fmla_one _ _ (sat_211 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_212 E)) (fmla_one _ _ (sat_213 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_214 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_215 E)) (fmla_one _ _ (sat_216 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_217 E)) (fmla_one _ _ (sat_218 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_219 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_220 E)) (fmla_one _ _ (sat_221 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_222 E)) (fmla_one _ _ (sat_223 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_224 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_225 E)) (fmla_one _ _ (sat_226 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_227 E)) (fmla_one _ _ (sat_228 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_229 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_230 E)) (fmla_one _ _ (sat_231 E))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_232 E)) (fmla_one _ _ (sat_233 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_234 E)) (fmla_one _ _ (sat_235 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_236 E)) (fmla_one _ _ (sat_237 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_238 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_239 E)) (fmla_one _ _ (sat_240 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_241 E)) (fmla_one _ _ (sat_242 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_243 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_244 E)) (fmla_one _ _ (sat_245 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_246 E)) (fmla_one _ _ (sat_247 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_248 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_249 E)) (fmla_one _ _ (sat_250 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_251 E)) (fmla_one _ _ (sat_252 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_253 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_254 E)) (fmla_one _ _ (sat_255 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_256 E)) (fmla_one _ _ (sat_257 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_258 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_259 E)) (fmla_one _ _ (sat_260 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_261 E)) (fmla_one _ _ (sat_262 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_263 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_264 E)) (fmla_one _ _ (sat_265 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_266 E)) (fmla_one _ _ (sat_267 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_268 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_269 E)) (fmla_one _ _ (sat_270 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_271 E)) (fmla_one _ _ (sat_272 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_273 E)) (fmla_one _ _ (sat_274 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_275 E)) (fmla_one _ _ (sat_276 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_277 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_278 E)) (fmla_one _ _ (sat_279 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_280 E)) (fmla_one _ _ (sat_281 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_282 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_283 E)) (fmla_one _ _ (sat_284 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_285 E)) (fmla_one _ _ (sat_286 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_287 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_288 E)) (fmla_one _ _ (sat_289 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_290 E)) (fmla_one _ _ (sat_291 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_292 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_293 E)) (fmla_one _ _ (sat_294 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_295 E)) (fmla_one _ _ (sat_296 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_297 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_298 E)) (fmla_one _ _ (sat_299 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_300 E)) (fmla_one _ _ (sat_301 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_302 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_303 E)) (fmla_one _ _ (sat_304 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_305 E)) (fmla_one _ _ (sat_306 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_307 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_308 E)) (fmla_one _ _ (sat_309 E))))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_310 E)) (fmla_one _ _ (sat_311 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_312 E)) (fmla_one _ _ (sat_313 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_314 E)) (fmla_one _ _ (sat_315 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_316 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_317 E)) (fmla_one _ _ (sat_318 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_319 E)) (fmla_one _ _ (sat_320 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_321 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_322 E)) (fmla_one _ _ (sat_323 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_324 E)) (fmla_one _ _ (sat_325 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_326 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_327 E)) (fmla_one _ _ (sat_328 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_329 E)) (fmla_one _ _ (sat_330 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_331 E)) (fmla_one _ _ (sat_332 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_333 E)) (fmla_one _ _ (sat_334 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_335 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_336 E)) (fmla_one _ _ (sat_337 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_338 E)) (fmla_one _ _ (sat_339 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_340 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_341 E)) (fmla_one _ _ (sat_342 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_343 E)) (fmla_one _ _ (sat_344 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_345 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_346 E)) (fmla_one _ _ (sat_347 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_348 E)) (fmla_one _ _ (sat_349 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_350 E)) (fmla_one _ _ (sat_351 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_352 E)) (fmla_one _ _ (sat_353 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_354 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_355 E)) (fmla_one _ _ (sat_356 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_357 E)) (fmla_one _ _ (sat_358 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_359 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_360 E)) (fmla_one _ _ (sat_361 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_362 E)) (fmla_one _ _ (sat_363 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_364 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_365 E)) (fmla_one _ _ (sat_366 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_367 E)) (fmla_one _ _ (sat_368 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_369 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_370 E)) (fmla_one _ _ (sat_371 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_372 E)) (fmla_one _ _ (sat_373 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_374 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_375 E)) (fmla_one _ _ (sat_376 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_377 E)) (fmla_one _ _ (sat_378 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_379 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_380 E)) (fmla_one _ _ (sat_381 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_382 E)) (fmla_one _ _ (sat_383 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_384 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_385 E)) (fmla_one _ _ (sat_386 E))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_387 E)) (fmla_one _ _ (sat_388 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_389 E)) (fmla_one _ _ (sat_390 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_391 E)) (fmla_one _ _ (sat_392 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_393 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_394 E)) (fmla_one _ _ (sat_395 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_396 E)) (fmla_one _ _ (sat_397 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_398 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_399 E)) (fmla_one _ _ (sat_400 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_401 E)) (fmla_one _ _ (sat_402 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_403 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_404 E)) (fmla_one _ _ (sat_405 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_406 E)) (fmla_one _ _ (sat_407 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_408 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_409 E)) (fmla_one _ _ (sat_410 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_411 E)) (fmla_one _ _ (sat_412 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_413 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_414 E)) (fmla_one _ _ (sat_415 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_416 E)) (fmla_one _ _ (sat_417 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_418 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_419 E)) (fmla_one _ _ (sat_420 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_421 E)) (fmla_one _ _ (sat_422 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_423 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_424 E)) (fmla_one _ _ (sat_425 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_426 E)) (fmla_one _ _ (sat_427 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_428 E)) (fmla_one _ _ (sat_429 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_430 E)) (fmla_one _ _ (sat_431 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_432 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_433 E)) (fmla_one _ _ (sat_434 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_435 E)) (fmla_one _ _ (sat_436 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_437 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_438 E)) (fmla_one _ _ (sat_439 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_440 E)) (fmla_one _ _ (sat_441 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_442 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_443 E)) (fmla_one _ _ (sat_444 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_445 E)) (fmla_one _ _ (sat_446 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_447 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_448 E)) (fmla_one _ _ (sat_449 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_450 E)) (fmla_one _ _ (sat_451 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_452 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_453 E)) (fmla_one _ _ (sat_454 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_455 E)) (fmla_one _ _ (sat_456 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_457 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_458 E)) (fmla_one _ _ (sat_459 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_460 E)) (fmla_one _ _ (sat_461 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_462 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_463 E)) (fmla_one _ _ (sat_464 E)))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_465 E)) (fmla_one _ _ (sat_466 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_467 E)) (fmla_one _ _ (sat_468 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_469 E)) (fmla_one _ _ (sat_470 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_471 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_472 E)) (fmla_one _ _ (sat_473 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_474 E)) (fmla_one _ _ (sat_475 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_476 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_477 E)) (fmla_one _ _ (sat_478 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_479 E)) (fmla_one _ _ (sat_480 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_481 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_482 E)) (fmla_one _ _ (sat_483 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_484 E)) (fmla_one _ _ (sat_485 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_486 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_487 E)) (fmla_one _ _ (sat_488 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_489 E)) (fmla_one _ _ (sat_490 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_491 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_492 E)) (fmla_one _ _ (sat_493 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_494 E)) (fmla_one _ _ (sat_495 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_496 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_497 E)) (fmla_one _ _ (sat_498 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_499 E)) (fmla_one _ _ (sat_500 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_501 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_502 E)) (fmla_one _ _ (sat_503 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_504 E)) (fmla_one _ _ (sat_505 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_506 E)) (fmla_one _ _ (sat_507 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_508 E)) (fmla_one _ _ (sat_509 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_510 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_511 E)) (fmla_one _ _ (sat_512 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_513 E)) (fmla_one _ _ (sat_514 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_515 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_516 E)) (fmla_one _ _ (sat_517 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_518 E)) (fmla_one _ _ (sat_519 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_520 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_521 E)) (fmla_one _ _ (sat_522 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_523 E)) (fmla_one _ _ (sat_524 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_525 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_526 E)) (fmla_one _ _ (sat_527 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_528 E)) (fmla_one _ _ (sat_529 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_530 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_531 E)) (fmla_one _ _ (sat_532 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_533 E)) (fmla_one _ _ (sat_534 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_535 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_536 E)) (fmla_one _ _ (sat_537 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_538 E)) (fmla_one _ _ (sat_539 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_540 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_541 E)) (fmla_one _ _ (sat_542 E))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_543 E)) (fmla_one _ _ (sat_544 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_545 E)) (fmla_one _ _ (sat_546 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_547 E)) (fmla_one _ _ (sat_548 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_549 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_550 E)) (fmla_one _ _ (sat_551 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_552 E)) (fmla_one _ _ (sat_553 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_554 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_555 E)) (fmla_one _ _ (sat_556 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_557 E)) (fmla_one _ _ (sat_558 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_559 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_560 E)) (fmla_one _ _ (sat_561 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_562 E)) (fmla_one _ _ (sat_563 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_564 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_565 E)) (fmla_one _ _ (sat_566 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_567 E)) (fmla_one _ _ (sat_568 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_569 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_570 E)) (fmla_one _ _ (sat_571 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_572 E)) (fmla_one _ _ (sat_573 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_574 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_575 E)) (fmla_one _ _ (sat_576 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_577 E)) (fmla_one _ _ (sat_578 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_579 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_580 E)) (fmla_one _ _ (sat_581 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_582 E)) (fmla_one _ _ (sat_583 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_584 E)) (fmla_one _ _ (sat_585 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_586 E)) (fmla_one _ _ (sat_587 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_588 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_589 E)) (fmla_one _ _ (sat_590 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_591 E)) (fmla_one _ _ (sat_592 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_593 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_594 E)) (fmla_one _ _ (sat_595 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_596 E)) (fmla_one _ _ (sat_597 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_598 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_599 E)) (fmla_one _ _ (sat_600 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_601 E)) (fmla_one _ _ (sat_602 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_603 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_604 E)) (fmla_one _ _ (sat_605 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_606 E)) (fmla_one _ _ (sat_607 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_608 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_609 E)) (fmla_one _ _ (sat_610 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_611 E)) (fmla_one _ _ (sat_612 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_613 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_614 E)) (fmla_one _ _ (sat_615 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_616 E)) (fmla_one _ _ (sat_617 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_618 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_619 E)) (fmla_one _ _ (sat_620 E)))))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_621 E)) (fmla_one _ _ (sat_622 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_623 E)) (fmla_one _ _ (sat_624 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_625 E)) (fmla_one _ _ (sat_626 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_627 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_628 E)) (fmla_one _ _ (sat_629 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_630 E)) (fmla_one _ _ (sat_631 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_632 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_633 E)) (fmla_one _ _ (sat_634 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_635 E)) (fmla_one _ _ (sat_636 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_637 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_638 E)) (fmla_one _ _ (sat_639 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_640 E)) (fmla_one _ _ (sat_641 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_642 E)) (fmla_one _ _ (sat_643 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_644 E)) (fmla_one _ _ (sat_645 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_646 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_647 E)) (fmla_one _ _ (sat_648 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_649 E)) (fmla_one _ _ (sat_650 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_651 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_652 E)) (fmla_one _ _ (sat_653 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_654 E)) (fmla_one _ _ (sat_655 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_656 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_657 E)) (fmla_one _ _ (sat_658 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_659 E)) (fmla_one _ _ (sat_660 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_661 E)) (fmla_one _ _ (sat_662 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_663 E)) (fmla_one _ _ (sat_664 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_665 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_666 E)) (fmla_one _ _ (sat_667 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_668 E)) (fmla_one _ _ (sat_669 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_670 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_671 E)) (fmla_one _ _ (sat_672 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_673 E)) (fmla_one _ _ (sat_674 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_675 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_676 E)) (fmla_one _ _ (sat_677 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_678 E)) (fmla_one _ _ (sat_679 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_680 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_681 E)) (fmla_one _ _ (sat_682 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_683 E)) (fmla_one _ _ (sat_684 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_685 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_686 E)) (fmla_one _ _ (sat_687 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_688 E)) (fmla_one _ _ (sat_689 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_690 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_691 E)) (fmla_one _ _ (sat_692 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_693 E)) (fmla_one _ _ (sat_694 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_695 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_696 E)) (fmla_one _ _ (sat_697 E))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_698 E)) (fmla_one _ _ (sat_699 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_700 E)) (fmla_one _ _ (sat_701 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_702 E)) (fmla_one _ _ (sat_703 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_704 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_705 E)) (fmla_one _ _ (sat_706 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_707 E)) (fmla_one _ _ (sat_708 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_709 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_710 E)) (fmla_one _ _ (sat_711 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_712 E)) (fmla_one _ _ (sat_713 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_714 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_715 E)) (fmla_one _ _ (sat_716 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_717 E)) (fmla_one _ _ (sat_718 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_719 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_720 E)) (fmla_one _ _ (sat_721 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_722 E)) (fmla_one _ _ (sat_723 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_724 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_725 E)) (fmla_one _ _ (sat_726 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_727 E)) (fmla_one _ _ (sat_728 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_729 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_730 E)) (fmla_one _ _ (sat_731 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_732 E)) (fmla_one _ _ (sat_733 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_734 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_735 E)) (fmla_one _ _ (sat_736 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_737 E)) (fmla_one _ _ (sat_738 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_739 E)) (fmla_one _ _ (sat_740 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_741 E)) (fmla_one _ _ (sat_742 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_743 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_744 E)) (fmla_one _ _ (sat_745 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ h_746) (fmla_one _ _ h_747)) (fmla_and _ _ _ (fmla_one _ _ h_748) (fmla_and _ _ _ (fmla_one _ _ h_749) (fmla_one _ _ (sat_750 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_751 E)) (fmla_one _ _ (sat_752 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_753 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_754 E)) (fmla_one _ _ (sat_755 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ h_756) (fmla_one _ _ (sat_757 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_758 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_759 E)) (fmla_one _ _ (sat_760 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_761 E)) (fmla_one _ _ (sat_762 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_763 E)) (fmla_and _ _ _ (fmla_one _ _ h_764) (fmla_one _ _ (sat_765 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_766 E)) (fmla_one _ _ (sat_767 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_768 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_769 E)) (fmla_one _ _ (sat_770 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_771 E)) (fmla_one _ _ h_772)) (fmla_and _ _ _ (fmla_one _ _ (sat_773 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_774 E)) (fmla_one _ _ (sat_775 E)))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_776 E)) (fmla_one _ _ (sat_777 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_778 E)) (fmla_one _ _ (sat_779 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_780 E)) (fmla_one _ _ h_781)) (fmla_and _ _ _ (fmla_one _ _ (sat_782 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_783 E)) (fmla_one _ _ (sat_784 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_785 E)) (fmla_one _ _ (sat_786 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_787 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_788 E)) (fmla_one _ _ (sat_789 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_790 E)) (fmla_one _ _ (sat_791 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_792 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_793 E)) (fmla_one _ _ (sat_794 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_795 E)) (fmla_one _ _ (sat_796 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_797 E)) (fmla_one _ _ (sat_798 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_799 E)) (fmla_one _ _ h_800)) (fmla_and _ _ _ (fmla_one _ _ (sat_801 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_802 E)) (fmla_one _ _ (sat_803 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_804 E)) (fmla_one _ _ (sat_805 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_806 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_807 E)) (fmla_one _ _ (sat_808 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_809 E)) (fmla_one _ _ (sat_810 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_811 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_812 E)) (fmla_one _ _ (sat_813 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_814 E)) (fmla_one _ _ (sat_815 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_816 E)) (fmla_one _ _ h_817))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_818 E)) (fmla_one _ _ (sat_819 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_820 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_821 E)) (fmla_one _ _ (sat_822 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_823 E)) (fmla_one _ _ (sat_824 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_825 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_826 E)) (fmla_one _ _ (sat_827 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_828 E)) (fmla_one _ _ (sat_829 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_830 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_831 E)) (fmla_one _ _ (sat_832 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ h_833) (fmla_one _ _ (sat_834 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_835 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_836 E)) (fmla_one _ _ (sat_837 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_838 E)) (fmla_one _ _ (sat_839 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_840 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_841 E)) (fmla_one _ _ (sat_842 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_843 E)) (fmla_one _ _ h_844)) (fmla_and _ _ _ (fmla_one _ _ (sat_845 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_846 E)) (fmla_one _ _ (sat_847 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_848 E)) (fmla_one _ _ (sat_849 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_850 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_851 E)) (fmla_one _ _ (sat_852 E))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_853 E)) (fmla_one _ _ (sat_854 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_855 E)) (fmla_one _ _ (sat_856 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_857 E)) (fmla_one _ _ h_858)) (fmla_and _ _ _ (fmla_one _ _ (sat_859 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_860 E)) (fmla_one _ _ (sat_861 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_862 E)) (fmla_one _ _ (sat_863 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_864 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_865 E)) (fmla_one _ _ (sat_866 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_867 E)) (fmla_one _ _ h_868)) (fmla_and _ _ _ (fmla_one _ _ (sat_869 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_870 E)) (fmla_one _ _ (sat_871 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_872 E)) (fmla_one _ _ (sat_873 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_874 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_875 E)) (fmla_one _ _ (sat_876 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_877 E)) (fmla_one _ _ (sat_878 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_879 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_880 E)) (fmla_one _ _ (sat_881 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_882 E)) (fmla_one _ _ h_883)) (fmla_and _ _ _ (fmla_one _ _ (sat_884 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_885 E)) (fmla_one _ _ (sat_886 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_887 E)) (fmla_one _ _ (sat_888 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_889 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_890 E)) (fmla_one _ _ (sat_891 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_892 E)) (fmla_one _ _ (sat_893 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_894 E)) (fmla_one _ _ (sat_895 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_896 E)) (fmla_one _ _ h_897)) (fmla_and _ _ _ (fmla_one _ _ (sat_898 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_899 E)) (fmla_one _ _ (sat_900 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_901 E)) (fmla_one _ _ (sat_902 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_903 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_904 E)) (fmla_one _ _ (sat_905 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_906 E)) (fmla_one _ _ (sat_907 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_908 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_909 E)) (fmla_one _ _ (sat_910 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_911 E)) (fmla_one _ _ (sat_912 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_913 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_914 E)) (fmla_one _ _ h_915)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_916 E)) (fmla_one _ _ (sat_917 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_918 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_919 E)) (fmla_one _ _ (sat_920 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_921 E)) (fmla_one _ _ (sat_922 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_923 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_924 E)) (fmla_one _ _ (sat_925 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_926 E)) (fmla_one _ _ (sat_927 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_928 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_929 E)) (fmla_one _ _ (sat_930 E))))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ h_931) (fmla_one _ _ (sat_932 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_933 E)) (fmla_one _ _ (sat_934 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_935 E)) (fmla_one _ _ (sat_936 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_937 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_938 E)) (fmla_one _ _ (sat_939 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_940 E)) (fmla_one _ _ (sat_941 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_942 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_943 E)) (fmla_one _ _ (sat_944 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_945 E)) (fmla_one _ _ (sat_946 E))) (fmla_and _ _ _ (fmla_one _ _ h_947) (fmla_and _ _ _ (fmla_one _ _ (sat_948 E)) (fmla_one _ _ (sat_949 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_950 E)) (fmla_one _ _ (sat_951 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_952 E)) (fmla_one _ _ (sat_953 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_954 E)) (fmla_one _ _ h_955)) (fmla_and _ _ _ (fmla_one _ _ (sat_956 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_957 E)) (fmla_one _ _ (sat_958 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_959 E)) (fmla_one _ _ (sat_960 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_961 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_962 E)) (fmla_one _ _ h_963)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_964 E)) (fmla_one _ _ (sat_965 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_966 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_967 E)) (fmla_one _ _ (sat_968 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_969 E)) (fmla_one _ _ (sat_970 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_971 E)) (fmla_one _ _ (sat_972 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_973 E)) (fmla_one _ _ (sat_974 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_975 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_976 E)) (fmla_one _ _ (sat_977 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_978 E)) (fmla_one _ _ (sat_979 E))) (fmla_and _ _ _ (fmla_one _ _ h_980) (fmla_and _ _ _ (fmla_one _ _ (sat_981 E)) (fmla_one _ _ (sat_982 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_983 E)) (fmla_one _ _ (sat_984 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_985 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_986 E)) (fmla_one _ _ (sat_987 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_988 E)) (fmla_one _ _ (sat_989 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_990 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_991 E)) (fmla_one _ _ (sat_992 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ h_993) (fmla_one _ _ (sat_994 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_995 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_996 E)) (fmla_one _ _ (sat_997 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_998 E)) (fmla_one _ _ (sat_999 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1000 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1001 E)) (fmla_one _ _ (sat_1002 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1003 E)) (fmla_one _ _ (sat_1004 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1005 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1006 E)) (fmla_one _ _ (sat_1007 E))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1008 E)) (fmla_one _ _ h_1009)) (fmla_and _ _ _ (fmla_one _ _ (sat_1010 E)) (fmla_one _ _ (sat_1011 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1012 E)) (fmla_one _ _ (sat_1013 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1014 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1015 E)) (fmla_one _ _ (sat_1016 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1017 E)) (fmla_one _ _ (sat_1018 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1019 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1020 E)) (fmla_one _ _ (sat_1021 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1022 E)) (fmla_one _ _ (sat_1023 E))) (fmla_and _ _ _ (fmla_one _ _ h_1024) (fmla_and _ _ _ (fmla_one _ _ (sat_1025 E)) (fmla_one _ _ (sat_1026 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1027 E)) (fmla_one _ _ (sat_1028 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1029 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1030 E)) (fmla_one _ _ (sat_1031 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1032 E)) (fmla_one _ _ (sat_1033 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1034 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1035 E)) (fmla_one _ _ (sat_1036 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1037 E)) (fmla_one _ _ (sat_1038 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1039 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1040 E)) (fmla_one _ _ (sat_1041 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1042 E)) (fmla_one _ _ h_1043)) (fmla_and _ _ _ (fmla_one _ _ (sat_1044 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1045 E)) (fmla_one _ _ (sat_1046 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1047 E)) (fmla_one _ _ (sat_1048 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1049 E)) (fmla_one _ _ (sat_1050 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1051 E)) (fmla_one _ _ (sat_1052 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1053 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1054 E)) (fmla_one _ _ (sat_1055 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1056 E)) (fmla_one _ _ (sat_1057 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1058 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1059 E)) (fmla_one _ _ h_1060)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1061 E)) (fmla_one _ _ (sat_1062 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1063 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1064 E)) (fmla_one _ _ (sat_1065 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1066 E)) (fmla_one _ _ (sat_1067 E))) (fmla_and _ _ _ (fmla_one _ _ h_1068) (fmla_and _ _ _ (fmla_one _ _ (sat_1069 E)) (fmla_one _ _ (sat_1070 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1071 E)) (fmla_one _ _ (sat_1072 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1073 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1074 E)) (fmla_one _ _ (sat_1075 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ h_1076) (fmla_one _ _ (sat_1077 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1078 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1079 E)) (fmla_one _ _ (sat_1080 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1081 E)) (fmla_one _ _ (sat_1082 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1083 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1084 E)) (fmla_one _ _ (sat_1085 E)))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1086 E)) (fmla_one _ _ h_1087)) (fmla_and _ _ _ (fmla_one _ _ (sat_1088 E)) (fmla_one _ _ (sat_1089 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1090 E)) (fmla_one _ _ (sat_1091 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1092 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1093 E)) (fmla_one _ _ (sat_1094 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ h_1095) (fmla_one _ _ (sat_1096 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1097 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1098 E)) (fmla_one _ _ (sat_1099 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1100 E)) (fmla_one _ _ (sat_1101 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1102 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1103 E)) (fmla_one _ _ (sat_1104 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1105 E)) (fmla_one _ _ h_1106)) (fmla_and _ _ _ (fmla_one _ _ (sat_1107 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1108 E)) (fmla_one _ _ (sat_1109 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1110 E)) (fmla_one _ _ (sat_1111 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1112 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1113 E)) (fmla_one _ _ (sat_1114 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1115 E)) (fmla_one _ _ h_1116)) (fmla_and _ _ _ (fmla_one _ _ (sat_1117 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1118 E)) (fmla_one _ _ (sat_1119 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1120 E)) (fmla_one _ _ (sat_1121 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1122 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1123 E)) (fmla_one _ _ h_1124))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1125 E)) (fmla_one _ _ (sat_1126 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1127 E)) (fmla_one _ _ (sat_1128 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1129 E)) (fmla_one _ _ (sat_1130 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1131 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1132 E)) (fmla_one _ _ (sat_1133 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1134 E)) (fmla_one _ _ (sat_1135 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1136 E)) (fmla_and _ _ _ (fmla_one _ _ h_1137) (fmla_one _ _ (sat_1138 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1139 E)) (fmla_one _ _ (sat_1140 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1141 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1142 E)) (fmla_one _ _ (sat_1143 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1144 E)) (fmla_one _ _ (sat_1145 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1146 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1147 E)) (fmla_one _ _ (sat_1148 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1149 E)) (fmla_one _ _ (sat_1150 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1151 E)) (fmla_and _ _ _ (fmla_one _ _ h_1152) (fmla_one _ _ (sat_1153 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1154 E)) (fmla_one _ _ (sat_1155 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1156 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1157 E)) (fmla_one _ _ (sat_1158 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1159 E)) (fmla_one _ _ (sat_1160 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1161 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1162 E)) (fmla_one _ _ (sat_1163 E))))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1164 E)) (fmla_one _ _ (sat_1165 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1166 E)) (fmla_one _ _ (sat_1167 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1168 E)) (fmla_one _ _ h_1169)) (fmla_and _ _ _ (fmla_one _ _ (sat_1170 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1171 E)) (fmla_one _ _ (sat_1172 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1173 E)) (fmla_one _ _ (sat_1174 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1175 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1176 E)) (fmla_one _ _ (sat_1177 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1178 E)) (fmla_one _ _ (sat_1179 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1180 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1181 E)) (fmla_one _ _ (sat_1182 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1183 E)) (fmla_one _ _ (sat_1184 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1185 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1186 E)) (fmla_one _ _ (sat_1187 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1188 E)) (fmla_one _ _ (sat_1189 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1190 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1191 E)) (fmla_one _ _ (sat_1192 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1193 E)) (fmla_one _ _ (sat_1194 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1195 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1196 E)) (fmla_one _ _ h_1197)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1198 E)) (fmla_one _ _ (sat_1199 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1200 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1201 E)) (fmla_one _ _ (sat_1202 E)))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1203 E)) (fmla_one _ _ (sat_1204 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1205 E)) (fmla_one _ _ (sat_1206 E)))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1207 E)) (fmla_one _ _ (sat_1208 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1209 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1210 E)) (fmla_one _ _ (sat_1211 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1212 E)) (fmla_one _ _ (sat_1213 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1214 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1215 E)) (fmla_one _ _ (sat_1216 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1217 E)) (fmla_one _ _ (sat_1218 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1219 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1220 E)) (fmla_one _ _ (sat_1221 E))))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1222 E)) (fmla_one _ _ (sat_1223 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1224 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1225 E)) (fmla_one _ _ (sat_1226 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1227 E)) (fmla_one _ _ (sat_1228 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1229 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1230 E)) (fmla_one _ _ (sat_1231 E)))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1232 E)) (fmla_one _ _ (sat_1233 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1234 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1235 E)) (fmla_one _ _ (sat_1236 E))))) (fmla_and _ _ _ (fmla_and _ _ _ (fmla_one _ _ (sat_1237 E)) (fmla_one _ _ (sat_1238 E))) (fmla_and _ _ _ (fmla_one _ _ (sat_1239 E)) (fmla_and _ _ _ (fmla_one _ _ (sat_1240 E)) (fmla_one _ _ h_1241))))))))))))
#print axioms contradiction_of_semantic_roots
end Graffiti384b.DiversityEleven.PendantCircuit.K3
