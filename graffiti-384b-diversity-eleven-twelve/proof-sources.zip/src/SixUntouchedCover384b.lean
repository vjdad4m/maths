import SixUntouchedData00384b
import SixUntouchedData01384b
import SixUntouchedData02384b
import SixUntouchedData03384b
import SixUntouchedData04384b
import SixUntouchedData05384b
import SixUntouchedData06384b
import SixUntouchedData07384b
import SixUntouchedData08384b
import SixUntouchedData09384b
import SixUntouchedData10384b
import SixUntouchedData11384b
import SixUntouchedData12384b
import SixUntouchedData13384b
import SixUntouchedData14384b
import SixUntouchedData15384b

namespace Graffiti384b.SixUntouched
set_option maxHeartbeats 0
set_option maxRecDepth 40000
theorem all_bands (b : Fin 128) : band b.val=true := by
  fin_cases b
  · exact band_000
  · exact band_001
  · exact band_002
  · exact band_003
  · exact band_004
  · exact band_005
  · exact band_006
  · exact band_007
  · exact band_008
  · exact band_009
  · exact band_010
  · exact band_011
  · exact band_012
  · exact band_013
  · exact band_014
  · exact band_015
  · exact band_016
  · exact band_017
  · exact band_018
  · exact band_019
  · exact band_020
  · exact band_021
  · exact band_022
  · exact band_023
  · exact band_024
  · exact band_025
  · exact band_026
  · exact band_027
  · exact band_028
  · exact band_029
  · exact band_030
  · exact band_031
  · exact band_032
  · exact band_033
  · exact band_034
  · exact band_035
  · exact band_036
  · exact band_037
  · exact band_038
  · exact band_039
  · exact band_040
  · exact band_041
  · exact band_042
  · exact band_043
  · exact band_044
  · exact band_045
  · exact band_046
  · exact band_047
  · exact band_048
  · exact band_049
  · exact band_050
  · exact band_051
  · exact band_052
  · exact band_053
  · exact band_054
  · exact band_055
  · exact band_056
  · exact band_057
  · exact band_058
  · exact band_059
  · exact band_060
  · exact band_061
  · exact band_062
  · exact band_063
  · exact band_064
  · exact band_065
  · exact band_066
  · exact band_067
  · exact band_068
  · exact band_069
  · exact band_070
  · exact band_071
  · exact band_072
  · exact band_073
  · exact band_074
  · exact band_075
  · exact band_076
  · exact band_077
  · exact band_078
  · exact band_079
  · exact band_080
  · exact band_081
  · exact band_082
  · exact band_083
  · exact band_084
  · exact band_085
  · exact band_086
  · exact band_087
  · exact band_088
  · exact band_089
  · exact band_090
  · exact band_091
  · exact band_092
  · exact band_093
  · exact band_094
  · exact band_095
  · exact band_096
  · exact band_097
  · exact band_098
  · exact band_099
  · exact band_100
  · exact band_101
  · exact band_102
  · exact band_103
  · exact band_104
  · exact band_105
  · exact band_106
  · exact band_107
  · exact band_108
  · exact band_109
  · exact band_110
  · exact band_111
  · exact band_112
  · exact band_113
  · exact band_114
  · exact band_115
  · exact band_116
  · exact band_117
  · exact band_118
  · exact band_119
  · exact band_120
  · exact band_121
  · exact band_122
  · exact band_123
  · exact band_124
  · exact band_125
  · exact band_126
  · exact band_127

theorem all_packed (g : Fin 32768) : packed g.val=true := by
  let b : Fin 128 := ⟨g.val/256,by have := g.isLt; omega⟩
  have h := all_bands b
  change ((List.range 256).all (fun i=>packed (256*(g.val/256)+i)))=true at h
  have c := List.all_eq_true.mp h (g.val%256) (List.mem_range.mpr (Nat.mod_lt _ (by decide)))
  have de : 256*(g.val/256)+g.val%256=g.val := Nat.div_add_mod _ _
  simpa only [de] using c

#print axioms all_packed
end Graffiti384b.SixUntouched
