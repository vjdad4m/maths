import SixUntouchedPacked384b

namespace Graffiti384b.SixUntouched
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem band_000 : band 0=true := by decide
theorem band_001 : band 1=true := by decide
theorem band_002 : band 2=true := by decide
theorem band_003 : band 3=true := by decide
theorem band_004 : band 4=true := by decide
theorem band_005 : band 5=true := by decide
theorem band_006 : band 6=true := by decide
theorem band_007 : band 7=true := by decide

#print axioms band_007
end Graffiti384b.SixUntouched
