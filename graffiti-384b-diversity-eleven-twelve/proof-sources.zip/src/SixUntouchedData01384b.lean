import SixUntouchedPacked384b

namespace Graffiti384b.SixUntouched
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem band_008 : band 8=true := by decide
theorem band_009 : band 9=true := by decide
theorem band_010 : band 10=true := by decide
theorem band_011 : band 11=true := by decide
theorem band_012 : band 12=true := by decide
theorem band_013 : band 13=true := by decide
theorem band_014 : band 14=true := by decide
theorem band_015 : band 15=true := by decide

#print axioms band_015
end Graffiti384b.SixUntouched
