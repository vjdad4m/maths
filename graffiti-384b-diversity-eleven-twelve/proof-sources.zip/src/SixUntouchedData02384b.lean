import SixUntouchedPacked384b

namespace Graffiti384b.SixUntouched
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem band_016 : band 16=true := by decide
theorem band_017 : band 17=true := by decide
theorem band_018 : band 18=true := by decide
theorem band_019 : band 19=true := by decide
theorem band_020 : band 20=true := by decide
theorem band_021 : band 21=true := by decide
theorem band_022 : band 22=true := by decide
theorem band_023 : band 23=true := by decide

#print axioms band_023
end Graffiti384b.SixUntouched
