import SixUntouchedPacked384b

namespace Graffiti384b.SixUntouched
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem band_024 : band 24=true := by decide
theorem band_025 : band 25=true := by decide
theorem band_026 : band 26=true := by decide
theorem band_027 : band 27=true := by decide
theorem band_028 : band 28=true := by decide
theorem band_029 : band 29=true := by decide
theorem band_030 : band 30=true := by decide
theorem band_031 : band 31=true := by decide

#print axioms band_031
end Graffiti384b.SixUntouched
