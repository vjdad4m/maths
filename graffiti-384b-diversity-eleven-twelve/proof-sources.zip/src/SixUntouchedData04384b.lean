import SixUntouchedPacked384b

namespace Graffiti384b.SixUntouched
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem band_032 : band 32=true := by decide
theorem band_033 : band 33=true := by decide
theorem band_034 : band 34=true := by decide
theorem band_035 : band 35=true := by decide
theorem band_036 : band 36=true := by decide
theorem band_037 : band 37=true := by decide
theorem band_038 : band 38=true := by decide
theorem band_039 : band 39=true := by decide

#print axioms band_039
end Graffiti384b.SixUntouched
