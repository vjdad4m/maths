import SixUntouchedPacked384b

namespace Graffiti384b.SixUntouched
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem band_040 : band 40=true := by decide
theorem band_041 : band 41=true := by decide
theorem band_042 : band 42=true := by decide
theorem band_043 : band 43=true := by decide
theorem band_044 : band 44=true := by decide
theorem band_045 : band 45=true := by decide
theorem band_046 : band 46=true := by decide
theorem band_047 : band 47=true := by decide

#print axioms band_047
end Graffiti384b.SixUntouched
