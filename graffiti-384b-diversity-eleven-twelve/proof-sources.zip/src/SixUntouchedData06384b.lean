import SixUntouchedPacked384b

namespace Graffiti384b.SixUntouched
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem band_048 : band 48=true := by decide
theorem band_049 : band 49=true := by decide
theorem band_050 : band 50=true := by decide
theorem band_051 : band 51=true := by decide
theorem band_052 : band 52=true := by decide
theorem band_053 : band 53=true := by decide
theorem band_054 : band 54=true := by decide
theorem band_055 : band 55=true := by decide

#print axioms band_055
end Graffiti384b.SixUntouched
