import SixUntouchedPacked384b

namespace Graffiti384b.SixUntouched
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem band_056 : band 56=true := by decide
theorem band_057 : band 57=true := by decide
theorem band_058 : band 58=true := by decide
theorem band_059 : band 59=true := by decide
theorem band_060 : band 60=true := by decide
theorem band_061 : band 61=true := by decide
theorem band_062 : band 62=true := by decide
theorem band_063 : band 63=true := by decide

#print axioms band_063
end Graffiti384b.SixUntouched
