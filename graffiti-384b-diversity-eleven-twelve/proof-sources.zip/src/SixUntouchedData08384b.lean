import SixUntouchedPacked384b

namespace Graffiti384b.SixUntouched
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem band_064 : band 64=true := by decide
theorem band_065 : band 65=true := by decide
theorem band_066 : band 66=true := by decide
theorem band_067 : band 67=true := by decide
theorem band_068 : band 68=true := by decide
theorem band_069 : band 69=true := by decide
theorem band_070 : band 70=true := by decide
theorem band_071 : band 71=true := by decide

#print axioms band_071
end Graffiti384b.SixUntouched
