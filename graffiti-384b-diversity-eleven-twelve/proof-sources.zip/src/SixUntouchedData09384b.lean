import SixUntouchedPacked384b

namespace Graffiti384b.SixUntouched
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem band_072 : band 72=true := by decide
theorem band_073 : band 73=true := by decide
theorem band_074 : band 74=true := by decide
theorem band_075 : band 75=true := by decide
theorem band_076 : band 76=true := by decide
theorem band_077 : band 77=true := by decide
theorem band_078 : band 78=true := by decide
theorem band_079 : band 79=true := by decide

#print axioms band_079
end Graffiti384b.SixUntouched
