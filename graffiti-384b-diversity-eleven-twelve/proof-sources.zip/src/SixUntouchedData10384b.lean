import SixUntouchedPacked384b

namespace Graffiti384b.SixUntouched
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem band_080 : band 80=true := by decide
theorem band_081 : band 81=true := by decide
theorem band_082 : band 82=true := by decide
theorem band_083 : band 83=true := by decide
theorem band_084 : band 84=true := by decide
theorem band_085 : band 85=true := by decide
theorem band_086 : band 86=true := by decide
theorem band_087 : band 87=true := by decide

#print axioms band_087
end Graffiti384b.SixUntouched
