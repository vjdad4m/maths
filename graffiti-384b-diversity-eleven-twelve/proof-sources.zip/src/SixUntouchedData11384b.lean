import SixUntouchedPacked384b

namespace Graffiti384b.SixUntouched
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem band_088 : band 88=true := by decide
theorem band_089 : band 89=true := by decide
theorem band_090 : band 90=true := by decide
theorem band_091 : band 91=true := by decide
theorem band_092 : band 92=true := by decide
theorem band_093 : band 93=true := by decide
theorem band_094 : band 94=true := by decide
theorem band_095 : band 95=true := by decide

#print axioms band_095
end Graffiti384b.SixUntouched
