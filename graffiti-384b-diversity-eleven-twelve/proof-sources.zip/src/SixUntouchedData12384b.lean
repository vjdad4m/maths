import SixUntouchedPacked384b

namespace Graffiti384b.SixUntouched
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem band_096 : band 96=true := by decide
theorem band_097 : band 97=true := by decide
theorem band_098 : band 98=true := by decide
theorem band_099 : band 99=true := by decide
theorem band_100 : band 100=true := by decide
theorem band_101 : band 101=true := by decide
theorem band_102 : band 102=true := by decide
theorem band_103 : band 103=true := by decide

#print axioms band_103
end Graffiti384b.SixUntouched
