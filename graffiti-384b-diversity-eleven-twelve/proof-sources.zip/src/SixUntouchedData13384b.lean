import SixUntouchedPacked384b

namespace Graffiti384b.SixUntouched
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem band_104 : band 104=true := by decide
theorem band_105 : band 105=true := by decide
theorem band_106 : band 106=true := by decide
theorem band_107 : band 107=true := by decide
theorem band_108 : band 108=true := by decide
theorem band_109 : band 109=true := by decide
theorem band_110 : band 110=true := by decide
theorem band_111 : band 111=true := by decide

#print axioms band_111
end Graffiti384b.SixUntouched
