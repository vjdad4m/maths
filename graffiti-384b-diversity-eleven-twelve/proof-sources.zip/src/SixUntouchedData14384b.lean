import SixUntouchedPacked384b

namespace Graffiti384b.SixUntouched
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem band_112 : band 112=true := by decide
theorem band_113 : band 113=true := by decide
theorem band_114 : band 114=true := by decide
theorem band_115 : band 115=true := by decide
theorem band_116 : band 116=true := by decide
theorem band_117 : band 117=true := by decide
theorem band_118 : band 118=true := by decide
theorem band_119 : band 119=true := by decide

#print axioms band_119
end Graffiti384b.SixUntouched
