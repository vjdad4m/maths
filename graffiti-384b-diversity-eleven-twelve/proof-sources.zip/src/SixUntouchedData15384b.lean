import SixUntouchedPacked384b

namespace Graffiti384b.SixUntouched
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem band_120 : band 120=true := by decide
theorem band_121 : band 121=true := by decide
theorem band_122 : band 122=true := by decide
theorem band_123 : band 123=true := by decide
theorem band_124 : band 124=true := by decide
theorem band_125 : band 125=true := by decide
theorem band_126 : band 126=true := by decide
theorem band_127 : band 127=true := by decide

#print axioms band_127
end Graffiti384b.SixUntouched
